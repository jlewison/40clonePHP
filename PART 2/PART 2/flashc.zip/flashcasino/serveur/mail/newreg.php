<?
$reg_reg_mail_subject="Nouveau client ";

$reg_reg_mail="Client: $r_login";
?>