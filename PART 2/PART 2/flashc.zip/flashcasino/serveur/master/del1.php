<? include ("header.php");
mysql_query("DELETE FROM categorie WHERE nom='$nom'");

echo "<script>document.location.href='boutique.php'; </script>";

include ("footer.php"); 
?>