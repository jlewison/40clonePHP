<?php
/**
 * Player settings Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 02/01/2008
 */
class PlayerSettings extends controller
{
		function PlayerSettings()
		{
				parent::controller();
				//check login
				if ($this->session->userdata('admin_logged_in') != 1 && $this->session->userdata('admin_id') == '') redirect('admin/login');
				//Load the language file
				$this->lang->load('admin/playerSettings', $this->config->item('language_code'));
		}
		function index()
		{
				$this->load->library('validation');
				$this->load->model('settingsmodel');
				$this->_playerSettingsFrm();
				if (!isset($_POST['player_settings']))
				{
						$outputData['settings'] = $this->settingsmodel->readAllSetting();
						if ($outputData['settings'] != false) $outputData['settingsArr'] = $outputData['settings'];
				}
				if ($this->validation->run() == false) $outputData['validationError'] = $this->validation->error_string;
				else
				{
						if (isset($_POST['player_settings']))
						{
								$this->settingsmodel->updateAdminSettings($_POST);
								$red5ServerPath = $_POST['red5_server_path'];
								$captureTime = $_POST['webcam_capture_time'];
								$this->_updatePlayerSettingsXML($red5ServerPath, $captureTime);
								//Set the flash data
								$this->session->set_flashdata('successMsg', $this->lang->line('playersettings_success_msg'));
								redirect('admin/playerSettings');
						}
				}
				$this->smartyextended->view('../admin/playerSettings', $outputData);
		}
		function _playerSettingsFrm()
		{
				$rules['mencoder_path'] = 'trim|required|alphanumeric';
				$rules['mplayer_path'] = 'trim|required|alphanumeric';
				$rules['webcam_capture_time'] = 'trim|required|numeric';
				$rules['red5_path'] = 'trim|required|alphanumeric';
				$rules['recorder_path'] = 'trim|required|alphanumeric';
				$rules['red5_flv_path'] = 'trim|required|alphanumeric';
				$rules['flvtool2_path'] = 'trim|required|alphanumeric';
				$rules['red5_server_path'] = 'trim|required|alphanumeric';
				$fields['mencoder_path'] = $this->lang->line('playersettings_mencoder_path');
				$fields['mplayer_path'] = $this->lang->line('playersettings_mplayer_path');
				$fields['webcam_capture_time'] = $this->lang->line('playersettings_webcam_capture_time');
				$fields['red5_path'] = $this->lang->line('playersettings_red5_path');
				$fields['recorder_path'] = $this->lang->line('playersettings_recorder_path');
				$fields['red5_flv_path'] = $this->lang->line('playersettings_red5_flv_path');
				$fields['flvtool2_path'] = $this->lang->line('playersettings_flvtool2_path');
				$fields['red5_server_path'] = $this->lang->line('playersettings_red5_server_path');
				$this->validation->set_rules($rules);
				$this->validation->set_fields($fields);
		}
		###################################################################################################
		#Method			: updatePlayerSettingsXML()
		#Type			: sub
		#Description	: Update the player setting xml file
		##################################################################################################
		function _updatePlayerSettingsXML($red5ServerPath, $timeLimitSeconds)
		{
				$settingsXML = '<SETTINGS>
							<!--SERVER path="rtmp://xxx.xxx.xxx.xxx/path" /-->

							<SERVER path="' . $red5ServerPath . '" />

							<PHP uploadpath="q" deletepath="w" />
							<STREAM name="myvideos" seconds="' . $timeLimitSeconds . '" />

							<!-- Best Settings are quality="100" width="160" height="120" framerate="15" bandwidth="0"/-->
							<!-- If you change Any of these may or maynot Cause Frame Loss of Quality Loss. width and height will be selected Native modes of ur webcam / -->

							<VIDEO quality="95" width="160" height="120" framerate="30" bandwidth="0"/>
						</SETTINGS>';
				if (trim($red5ServerPath) != '')
				{
						$filename = APPPATH . '/settings/videoplayer/settings.xml';
						$handle = fopen($filename, 'w+');
						if ($handle)
						{
								fwrite($handle, $settingsXML);
								fclose($handle);
						}
				}
		}
}
?>