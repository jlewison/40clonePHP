<?php
/**
*
*
*
* @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
* @license
* @version SVN:$Id
* @since 2007-06-18
*/
$lang['managefooters_title'] 					= 'Manage Footers';
$lang['managefooters_textarea_note'] 			= '(Put the html code or enter the text on the text area)';
$lang['managefooters_save'] 					= 'Save as';
$lang['managefooters_save_note'] 				= '(Enter save name without space. Example:aboutus, if u give as \'about us\', it will be stored as \'about\')';
$lang['managefooters_title_note'] 				= '(The title name will be given as link in the footer)';
$lang['managefooters_create'] 					= 'Create';
$lang['managefooters_page_name_edit_note'] 					= '(The save as name will be the file name(example):aboutus will be saved as aboutus.php)';
$lang['managefooters_title_lbl'] 				= 'Title';
$lang['managefooters_page_name'] 				= 'Page Name';
$lang['managefooters_date_added'] 				= 'Date Added';
$lang['managefooters_edit'] 					= 'Edit';
$lang['managefooters_content'] 					= 'Content';
$lang['managefooters_delete'] 					= 'Delete';
$lang['managefooters_action'] 					= 'Action';
$lang['managefooters_save_changes'] 			= 'Save changes';
$lang['managefooters_no_footer'] 				= 'No footers found!';
$lang['managefooters_add_success_msg'] 			= 'Footer added successfully!';
$lang['managefooters_delete_success_msg'] 		= 'Footer deleted successfully!';
$lang['managefooters_update_success_msg'] 		= 'Footer updated successfully!';
$lang['managefooters_page_content'] 			= 'Page Content';
?>