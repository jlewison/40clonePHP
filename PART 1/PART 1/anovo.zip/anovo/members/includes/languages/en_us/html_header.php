<?php
if (array_search($CFG['html']['current_script_name'], $CFG['admin']['light_window_pages']) and !$CFG['remote_client']['is_ie'])
{
		echo '<?xml version="1.0"?>' . "\n";
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html lang="en-US" dir="ltr" xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="Version" content="<?php echo $CFG['dev']['version']; ?>" />
<meta http-equiv="content-type" content="application/xhtml+xml; charset=UTF-8" />
<meta http-equiv="content-Language" content="en-US" />
<meta name="keywords" content="<?php echo $CFG['html']['meta']['keywords']; ?>" />
<meta name="description" content="<?php echo $CFG['html']['meta']['description']; ?>" />
<?php
if ($CFG['html']['meta']['MSSmartTagsPreventParsing'])
{
?>
<!-- Disable MSSmartTags -->
<meta name="MSSmartTagsPreventParsing" content="true" />
<?php
}
if (!$CFG['html']['meta']['imagetoolbar'])
{
?>
<!-- Disable IE6 image toolbar -->
<meta http-equiv="imagetoolbar" content="no" />
<?php
}
class HtmlHeaderFormHandler extends HeaderHandler
{
}
$headerfrm = new HtmlHeaderFormHandler();
$headerfrm->setDBObject($db);
$headerfrm->setCfgLangGlobal($CFG, $LANG);
$headerfrm->setFormField('forum_id', '');
$headerfrm->sanitizeFormInputs($_REQUEST);
if ($headerfrm->isFormGETed($_GET, 'qid'))
{
		$headerfrm->getHeaderQuestionDetails($CFG['db']['tbl']['questions'], $CFG['db']['tbl']['questions_category']);
}
if ($headerfrm->isFormGETed($_GET, 'cid'))
{
		$headerfrm->getCategoryDetails($CFG['db']['tbl']['questions_category']);
}
$default_style_name = $CFG['html']['stylesheet']['screen']['default'];
$default_style_title = $CFG['html']['stylesheet']['screen']['available_stylesheets'][$default_style_name];
$style_titles = array_values($CFG['html']['stylesheet']['screen']['available_stylesheets']);
$onLoadFunction = '';
if ($CFG['html']['stylesheet']['screen']['is_style_support'])
{
		$selected_style_title = '';
		if (!empty($_GET['style']))
		{
				$selected_style_title = $_GET['style'];
		}
		else
				if (!empty($_POST['style']))
				{
						$selected_style_title = $_POST['style'];
				}
				else
						if (!empty($_COOKIE['style']))
						{
								$selected_style_title = $_COOKIE['style'];
						}
						else
								if (!empty($_SESSION['user']['pref_style']))
								{
										$selected_style_title = $_SESSION['user']['pref_style'];
								}
		if (in_array($selected_style_title, $style_titles)) $default_style_title = $selected_style_title;
		if ($default_style_title == 'White') $default_style_name = 'screen_white';
}
$Default = $White = '';
$popupPosition = 330;
if ($default_style_title)
{
		$_SESSION['user']['pref_style'] = $default_style_title;
		setcookie('style', $default_style_title, time() + 4320000, '/');
		$$default_style_title = 'clsActiveTheme';
		if ($default_style_title == 'White')
		{
				$popupPosition = 300;
		}
?>
<link rel="stylesheet" type="text/css" href="<?php echo $CFG['site']['url']; ?>members/css/<?php echo $default_style_name; ?>.css" media="screen" title="<?php echo $default_style_title; ?>" />
<?php
}
if ($CFG['html']['stylesheet']['screen']['is_style_support'])
{
		foreach ($CFG['html']['stylesheet']['screen']['available_stylesheets'] as $style_name => $style_title)
		{
				if ($default_style_title != $style_title)
				{
?>
<link rel="alternate stylesheet" type="text/css" href="<?php echo $CFG['site']['url']; ?>members/css/<?php echo $style_name; ?>.css" media="screen" title="<?php echo $style_title; ?>" />
<?php
				}
		}
}


?>
<link href="<?php echo $CFG['site']['url']; ?>js/lightwindow/css/lightWindow.css" rel="stylesheet" type="text/css" />
<?php
if (chkToolTipAllowed())
{
?>
<link href="<?php echo $CFG['site']['url']; ?>css/tooltips.css" rel="stylesheet" type="text/css" />
<?php
}
?>
<link rel="stylesheet" type="text/css" href="<?php echo $CFG['site']['url']; ?>css/print.css" media="print" />
<link rel="shortcut icon" href="<?php echo $CFG['site']['url']; ?>favicon.ico" type="image/x-icon" />
<?php






?>
<!-- for link bar -->
<link rel="Home"     href="<?php echo URL($CFG['site']['url']); ?>" title="Home page" />
<link rel="Index"    href="<?php echo URL($CFG['site']['url']); ?>" title="Index" />
<link rel="search"   href="<?php echo '#'; ?>" title="Search this site" />
<link rel="contents" href="<?php echo '#'; ?>" title="Site map" />
<script type="text/javascript">
	var SITE_URL = '<?php echo $CFG['site']['url']; ?>';
	var loadingSrc = '<img src="<?php echo $CFG['site']['url'] . 'images/loader.gif'; ?>" alt="loading..."/>';
	var processingSrc = '<img src="<?php echo $CFG['site']['url'] . 'images/processing.gif'; ?>" alt="loading..."/>';
	var popupPosition = '<?php echo $popupPosition; ?>';
	var timeout	= 100;
	var infoTimer	= 0;
	var divObj	= 0;
	// close showed layer
	function closeUserPopup(){
		if(divObj) divObj.style.display = 'none';
	}

	// close user info and reset timer
	function closeUserPopupAndTimer(){
		infoTimer = window.setTimeout(closeUserPopup, timeout);
	}

	// reset timer
	function resetUserInfoTimer(){
		if(infoTimer)
		{
			window.clearTimeout(infoTimer);
			infoTimer = null;
		}
	}

	//for search text box
	displayDefaultValue = function(obj, dValue){
		var objValue = obj.value;
		if (objValue == '')
			obj.value = dValue;
	}
	//for search text box
	clearDefaultValue = function(obj, dValue){
		var objValue = obj.value;
		if (objValue == dValue)
			obj.value = '';
	}
</script>
<?php
if (!($CFG['html']['page_id'] == 'membersindex' or $CFG['html']['page_id'] == 'index'))
{
?>
<script type="text/javascript" src="<?php echo $CFG['site']['url']; ?>js/lib/prototype.js"></script>
<script type="text/javascript" src="<?php echo $CFG['site']['url']; ?>js/scriptaculous/scriptaculous.js"></script>
<script type="text/javascript" src="<?php echo $CFG['site']['url']; ?>js/lightwindow/javascript/prototype.js"></script>
<script type="text/javascript" src="<?php echo $CFG['site']['url']; ?>js/script.js"></script>
<?php
		if (chkToolTipAllowed())
		{
?>
<script type="text/javascript" src="<?php echo $CFG['site']['url']; ?>js/tooltips.js"></script>
<?php
		}
?>
<script type="text/javascript" src="<?php echo $CFG['site']['url']; ?>js/lightwindow/javascript/effects.js"></script>
<script type="text/javascript" src="<?php echo $CFG['site']['url']; ?>js/lightwindow/javascript/lightWindow.js"></script>
<?php
}
else
{
?>
<script type="text/javascript">
	function $(elmt){
		return document.getElementById(elmt);
	}
</script>
<?php
}
?>
<script type="text/javascript"	src="<?php echo $CFG['site']['url']; ?>js/swfobject.js"></script>
<script type="text/javascript"	src="<?php echo $CFG['site']['url']; ?>js/browsersniff.js"></script>
<script language="javascript" type="text/javascript">
/* ************** Start X functions ************** */
function xGetElementById(e) {
  if(typeof(e)!='string') return e;
  if(document.getElementById) e=document.getElementById(e);
  else if(document.all) e=document.all[e];
  else e=null;
  return e;
}
function createCookie(name,value,days) {
	if (days) {
		var exdate = new Date();
		exdate.setDate(exdate.getDate()+days);
		var expires = "; expires="+exdate.toGMTString();
	}
	else var expires = "";
	document.cookie = name+"="+escape(value)+expires+"; path=/";
}
function readCookie(c_name)
{
	if (document.cookie.length>0){
		c_start=document.cookie.indexOf(c_name + "=");
  		if (c_start!=-1){
    		c_start=c_start + c_name.length+1;
    		c_end=document.cookie.indexOf(";",c_start);
    		if (c_end==-1) c_end=document.cookie.length;
    		return unescape(document.cookie.substring(c_start,c_end));
    	}
  	}
return "";
}

function checkCookie(cookieName)
{
	if (cookieName!=null && cookieName!=""){
  		alert('Welcome again '+cookieName+'! : '+readCookie(cookieName));
  	}else{
  		alert('No cookie found');
  	}
}
/* ************** End X functions ************** */
</script>
<title><?php echo $CFG['site']['title']; ?></title>
</head>
<body>
<div id="selAlertbox" class="clsMsgAlert" style="display:none;position:absolute;">
  <p id="selAlertMessage"></p>
  <form name="formAlertBox" id="formAlertBox">
    <input type="button" class="clsSubmitButton" name="selAlertOkButton" id="selAlertOkButton" value="Ok" onClick="return hideAllBlocks();" />
  </form>
</div>
<!-- for ajax window -->
<div id="selAjaxWindow" class="clsVideoAudioUploadPopup" style="display:none;position:absolute;">
	<form name="frmAjaxWindow" id="frmAjaxWindow">
	</form>
	<div id="selAjaxWindowInnerDiv"></div>
</div>
<div id="hideScreen" style="z-index: 100; display: none;" class="VeilStyle1c">&nbsp;</div>
<div id="<?php echo $CFG['html']['page_id']; ?>" class="clsBodyContent">

<div id="selPageBody">

<!-- Accessibility Links -->
<div id="top">
  <ul>
    <li><a href="#main">Skip to main content</a></li>
    <li><a href="#selSubHeader">Skip to Navigation Links</a></li>
    <li><a href="#footer">Skip to Footer</a></li>
  </ul>
</div>
<!-- Header -->
<div id="header">


  <div class="clsTopHeader"><div class="clsLeftHeader"><h1><a href="<?php echo $CFG['site']['relative_url']; ?>" title="Browse to homepage"><?php echo $CFG['site']['name']; ?></a></h1>
   <?php

if ($CFG['html']['stylesheet']['screen']['is_style_support'])
{
		$REQ_URI = $_SERVER['REQUEST_URI'];
		if (isset($_GET['style']) and ($get_style = $_GET['style']))
		{
				$REQ_URI = str_replace('?style=' . $get_style, '', $REQ_URI);
				$REQ_URI = str_replace('&style=' . $get_style, '', $REQ_URI);
		}
		$REQ_URI .= (strpos($REQ_URI, '?')) ? '&style=' : '?style=';
?>
<div class="clsAlternateStyle"> <div id="selStyle" class="clsAlternateStyleSheet" lang="en">
    <h2>Choose Style</h2>
<div class="clsAlternateSheet"><ul>
<li class="clsChangeTheme">Change theme now:</li>
	<li id="themeDefault" class="<?php echo $Default; ?>"><a href="<?php echo $REQ_URI . 'Default'; ?>"><img src="<?php echo $CFG['site']['url'] . 'images/bg-defaulttheme.png'; ?>" alt="Default theme" title="Default theme" /></a></li>
	<li id="themeWhite" class="<?php echo $White; ?>"><a href="<?php echo $REQ_URI . 'White'; ?>"><img src="<?php echo $CFG['site']['url'] . 'images/bg-whitetheme.png'; ?>" alt="White theme" title="White theme" /></a></li>
</ul></div>
</div></div>
  <?php
}
?></div>
<div class="clsRightHeader">
  <?php if ($top_banner1 = getAdvertisement('top_banner1'))
{ ?>
  <!-- Header Banner -->
  <div id="selHeaderBanner"><p><?php echo $top_banner1; ?></p></div>
  <!-- End of Header Banner -->
  <?php } ?>

  <!-- Header Welcome -->
  <div id="selHeaderWelcome">
    <?php if (!$headerfrm->isMember())
{ ?>
    <div id="selRootWelcome" class="clsHeaderWelcomeSection">
     <div class="clsHeaderWelcomeImage">
     <p>user image</p>
	  </div>
     <div class="clsHeaderWelcomeContent">
      <h3 class="clsSignIn"><a href="<? echo getUrl($CFG['site']['url'] . 'login.php', $CFG['site']['url'] . 'login/', false); ?>">Sign In</a></h3>
	<?php if (chkAllowedModule(array('registration')))
		{ ?>
	  <p>New User? <a class="clsHighlightHeaderLink" href="<? echo getUrl($CFG['site']['url'] . 'signup.php', $CFG['site']['url'] . 'register/', false); ?>"><?php echo $LANG['signup']; ?></a></p>
	<?php } ?>
    </div></div>
    <?php } ?>
    <?php
if ($headerfrm->isMember())
{
		$userDetails = $headerfrm->getUserDetailsFromUsersTable($CFG['db']['tbl']['users'], $CFG['user']['user_id']);
?>
    <div id="selMembersWelcome" class="clsHeaderWelcomeSection">
      <?php if (chkUserImageAllowed())
		{ ?>
	  <div class="clsHeaderWelcomeImage">
	 <p id="selImageBorder"> <?php displayUserImage($userDetails, 'small', false); ?></p>
	  </div>
	  <?php } ?>
	  <div class="clsHeaderWelcomeContent"><h3>Hi <span><?php echo stripString($CFG['user']['name'], $CFG['username']['short_length']); ?></span></h3>
      <p><a href="<?php echo getUrl($CFG['site']['relative_url'] . 'manageSettings.php', $CFG['site']['relative_url'] . 'my/settings/', false); ?>">Manage Settings</a> </p>
<?php if ($CFG['user']['is_admin'])
		{ ?>
        <p class="admin"><a class="clsHighlightHeaderLink" href="<? echo $CFG['site']['url']; ?>admin/"><?php echo $LANG['admin']; ?></a></p>
        <?php } ?></div>    </div>
    <?php
}
?>
  </div>
  <!-- End of Header Welcome --></div>
</div>  <?php

if ($CFG['lang']['is_multi_lang_support'])
{
?>
  <div id="selLang" lang="en">
    <h2>Choose Language</h2>
    <form name="form_lang" id="selFormLang" method="get" action="<?php echo URL($_SERVER['SCRIPT_NAME']); ?>" autocomplete="off">
      <select class="clsListBox" name="lang" id="lang" tabindex="1">
        <?php
		foreach ($CFG['lang']['available_languages'] as $lang_code => $lang_name)
		{
?>
        <option value="<?php echo $lang_code; ?>"<?php echo ($lang_code == $CFG['lang']['default']) ? ' selected="selected"' : ''; ?>><?php echo $lang_name; ?></option>
        <?php
		}
?>
      </select>
      <input type="submit" class="clsSubmitButton" name="change_lang" id="change_lang" tabindex="1" value="Change" title="Change Language" />
    </form>
  </div>
  <?php
}
?></div>

<div id="selSubHeader" href="<? echo $CFG['site']['relative_url']; ?>">
  <?php $headerfrm->populateTopMenu(); ?>
</div>
</div>
<!-- End of Header -->
<!-- Side Bar -->

<?php
if ($CFG['side_bar']['show_hide'])
{
?>
<div class="clsShowHideTab"><p>
	<a class="clsShow" href="#" onClick="return toggleTab();" id="selLinkShow" style="display:none;">show</a>
	<a class="clsHide" href="#" onClick="return toggleTab();" id="selLinkHide" style="display:none;">hide</a>
</p></div>
<?php
}
?>

<div id="sideBar">
  <!-- Side Bar1 -->
  <div id="sideBar1" class="sideBar1">
  <div id="toggleDiv">
  	<?php $headerfrm->getRandVideo(); ?>
	<?php
if (!$headerfrm->isMember())
{
		$headerfrm->getStartMessage();
}
if ($headerfrm->isMember())
{
		$headerfrm->insertUsersAnswerLog();
		$headerfrm->insertAdvanceSearch();
		$headerfrm->updateUsersAnswerLog();
		$headerfrm->showUserInfo();
}
?>
	<?php if ($side_bar1 = getAdvertisement('side_bar1'))
{ ?>
	  <!-- side Banner1 -->
	  <div id="selSidebarBanner"><p><?php echo $side_bar1; ?></p></div>
	  <!-- End of side Banner1 -->
	  <?php } ?>
    <?php $headerfrm->populateMailRightNavigation(); ?>
    <?php $headerfrm->populateAlphabetPagingList($LANG_LIST_ARR['paging_list']); ?>
    <?php $headerfrm->getAllCategories($CFG['db']['tbl']['questions_category'], $CFG['admin']['index']['category_limit']); ?>
    <?php $headerfrm->showTopTags(); ?>
    <?php $headerfrm->showTopSearchedTags(); ?>
    <?php if ($side_bar2 = getAdvertisement('side_bar2'))
{ ?>
	  <!-- side Banner2 -->
	  <div id="selSidebarBanner"><p><?php echo $side_bar2; ?></p></div>
	  <!-- End of side Banner2 -->
	  <?php } ?>

    </div>
  </div>
  <!-- End of Side Bar1 -->
</div>
<?php
if ($CFG['side_bar']['show_hide'])
{
?>
<script language="javascript" type="text/javascript">
/* dock navigation panel functions */
function insertToggleButton() {
	var toggleDiv 	= xGetElementById('toggleDiv');
	var mainDiv 	= xGetElementById('main');
	var sideBar1Div = xGetElementById('sideBar1');

	//auto-hide if applicable
	if(readCookie("hidenav") == 1) {
		sideBar1Div.className = "clsHideSideBar";
		mainDiv.className = "clsExpandMain";

		createCookie("hidenav",1,365)
		document.getElementById('selLinkShow').style.display = 'block';
		document.getElementById('selLinkHide').style.display = 'none';
	}
	else{
		document.getElementById('selLinkShow').style.display = 'none';
		document.getElementById('selLinkHide').style.display = 'block';
	}
}

function toggleTab() {
	var toggleDiv 	= xGetElementById('toggleDiv');
	var mainDiv 	= xGetElementById('main');
	var sideBar1Div = xGetElementById('sideBar1');

	if (sideBar1Div.className == 'sideBar1') {
		sideBar1Div.className = "clsHideSideBar";
		mainDiv.className = "clsExpandMain";

		createCookie("hidenav",1,365)
		document.getElementById('selLinkShow').style.display = 'block';
		document.getElementById('selLinkHide').style.display = 'none';
	}
	else {
		sideBar1Div.className = "sideBar1";
		mainDiv.className = "";

		createCookie("hidenav",0,365)
		document.getElementById('selLinkShow').style.display = 'none';
		document.getElementById('selLinkHide').style.display = 'block';
	}
toggleNavBar();
return false;
}
</script>
<?php
}
?>
<!-- End of Side Bar -->
<div class="clsShowHide">
<!-- Main -->
<div id="main">
<?php
if ($CFG['side_bar']['show_hide'])
{
?>
<script language="javascript" type="text/javascript">//init the insert toggle function
insertToggleButton();
</script>
<?php
}
?>

<!-- Ask/Answer -->
<?php $headerfrm->showAskAnswersOption(); ?>

<!-- Search Begins -->
<?php $headerfrm->showAnswerSearchOption(); ?>
<?php $headerfrm->showForumsSearchOption(); ?>
<?php $headerfrm->showBlogsSearchOption(); ?>
<!-- Search ends -->
