<?php
////////////////////////////////////////////////////////////// 
// Rapidsendit Clone V.1.1  Purchased from Rapidsendit.com ///
// flatFileHost lives on! Credits To Jim For The Foundtion ///
//////////////////////////////////////////////////////////////

include("./config.php");
include("./header.php");

$filename = $_FILES['upfile']['name'];
$filesize = $_FILES['upfile']['size'];
$rand2=rand('10000','10000000');

$bans=file("./bans.txt");
foreach($bans as $line)
{
  if ($line==$rand2."\n"){
    echo "That file is not allowed to be uploaded.";
    include("./footer.php");
    die();
  }
  if ($line==$_SERVER['REMOTE_ADDR']."\n"){
    echo "You are not allowed to upload files.";
    include("./footer.php");
    die();
  }
}

//$checkfiles=file("./files.txt");
//foreach($checkfiles as $line)
//{
//  $thisline = explode('|', $line);
//  if ($thisline[0]==$rand2){
//    echo "That file has already been uploaded.<br />";
//    echo "Your download link is: <a href=\"" . $scripturl . "" . $rand2 . "\">". $scripturl . "" . $rand2 . "</a><br />";
//    echo "This file was originally uploaded by someone else, so you don't get a delete link.";
//    include("./footer.php");
//    die();
//  }
//}

// begin separate file mod
$dirname = "./storagedata";
$dh = opendir( $dirname ) or die("couldn't open directory");
while ( $file = readdir( $dh ) ) {
$fh = fopen ("./storagedata/".$file,r);
$filedata= explode('|', fgets($fh));
$newfilecrc = str_replace(".txt","",$file);
  if ($newfilecrc == $rand2){
    echo "That file has already been uploaded.<br /><br />";
    echo "Filename:<br> " . $filedata[0] . "<br /><br />";
    echo "Download Link:<br><BR><a href=\"" . $scripturl . "download.php?file=" . $rand2 . "\">". $scripturl . "download.php?file=" . $rand2 . "</a><br />";
    include("./footer.php");
    die();
  }
fclose ($fh);
}
closedir( $dh );
// end separate file mod

if(isset($allowedtypes)){
$allowed = 0;
foreach($allowedtypes as $ext) {
  if(substr($filename, (0 - (strlen($ext)+1) )) == ".".$ext)
    $allowed = 1;
}
if($allowed==0) {
   echo "That file type is not allowed to be uploaded.";
   include("./footer.php");
   die();
}
}

if($filesize==0) {
echo "You didn't pick a file to upload.";
include("./footer.php");
die();
}

$filesize = $filesize / 1048576;

if($filesize > $maxfilesize) {
echo "The file you uploaded is too large.";
include("./footer.php");
die();
}

$userip = $_SERVER['REMOTE_ADDR'];
$time = time();

if($filesize > $nolimitsize) {

$uploaders = fopen("./uploaders.txt","r+");
flock($uploaders,2);
while (!feof($uploaders)) { 
$user[] = chop(fgets($uploaders,65536));
}
fseek($uploaders,0,SEEK_SET);
ftruncate($uploaders,0);
foreach ($user as $line) {
@list($savedip,$savedtime) = explode("|",$line);
if ($savedip == $userip) {
if ($time < $savedtime + ($uploadtimelimit*60)) {
echo "You're trying to upload again too soon!";
include("./footer.php");
die();
}
}
if ($time < $savedtime + ($uploadtimelimit*60)) {
  fputs($uploaders,"$savedip|$savedtime\n");
}
}
fputs($uploaders,"$userip|$time\n");

}

$passkey = rand(100000, 999999);

if($emailoption && isset($_POST['myemail']) && $_POST['myemail']!="") {
$uploadmsg = "Your file (".$filename.") was uploaded.\n Your download link is: ". $scripturl . "download.xjoshandeep?file=" . $rand2 . "\n Your delete link is: ". $scripturl . "download.xjoshandeep?file=" . $rand2 . "&del=" . $passkey . "\n Thank you for using our service!";
mail($_POST['myemail'],"Your Uploaded File",$uploadmsg,"From: files@rapidsendit.com\n");
}

//$filelist = fopen("./files.txt","a+");
//fwrite($filelist, $rand2 ."|". basename($_FILES['upfile']['name']) ."|". $passkey ."|". $userip ."|". $time."|0\n");

// write file to storagedata directory
$filedata = fopen("./storagedata/".$rand2.".txt","w");
fwrite($filedata, basename($_FILES['upfile']['name']) ."|". $passkey ."|". $userip ."|". $time."|0\n");


$movefile = "./storage/" . $rand2;
move_uploaded_file($_FILES['upfile']['tmp_name'], $movefile);

echo "<b><font face='Verdana' size='2'>Your File Was Successfully Uploaded!</font></b><br /><br /><br />";
echo "<b><font face='Verdana' size='2'>Direct Download Link:</font></b></br> <textarea name='textarea' cols='65' wrap='soft' rows='1'>". $scripturl . "" . $rand2 . "</textarea><br /><br />";
echo "<b><font face='Verdana' size='2'>BB Code To Post On Message Boards:</font></b><br><textarea name='textarea' cols='65' wrap='soft' rows='2'>[url=". $scripturl . "" . $rand2 . "]Rapidsendit Download Link[/url]</textarea><br /><br />";
echo "<b><font face='Verdana' size='2'>HTML Code To Post On Websites:</font></b><br><textarea name='textarea' cols='65' wrap='soft' rows='2'><a href=". $scripturl . "" . $rand2 . ">Rapidsendit Download Link</a></textarea><br /><br />";
echo "<b><font face='Verdana' size='2'>Your delete link is:</font></b> </br><textarea name='textarea' cols='65' wrap='soft' rows='2'>" . $scripturl . "download.php?file=" . $rand2 . "&del=" . $passkey . "</textarea><br /><br />";
echo "<b><font face='Verdana' size='2'>Please remember these links.</font></b>";
		

include("./footer.php");
?>