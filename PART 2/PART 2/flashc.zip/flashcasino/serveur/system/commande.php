<? include ("header.php"); ?>








<? include ("menugames.php"); ?>











          <TD class=fgi_flsh vAlign=top><SPAN class=fgi_gttl>PLAYING FOR 
            REAL</SPAN><BR>
            <TABLE class=fgi_chips cellSpacing=0 cellPadding=0 width="100%" 
            border=0>
              <TBODY>
              <TR>
                <TD class=t><IMG 
                  src="fgi/chips_tl.jpg"></TD>
                <TD class=t align=right><IMG 
                  src="fgi/chips_tr.jpg"></TD></TR>
              <TR>
                <TD class=l>Welcome <B><? echo $l; ?></B>&nbsp;&nbsp;&nbsp;&nbsp;your balance 
                  account : <? echo $rog1[3]; ?></TD>
                <TD class=r align=right><A 
                  href="cashier.php"><IMG hspace=10 
                  src="fgi/cashier.jpg"></A><A 
                  href="logout.php"><IMG 
                  src="fgi/logout.jpg"></A></TD></TR>
              <TR>
                <TD class=b><IMG 
                  src="fgi/chips_bl.jpg"></TD>
                <TD class=b align=right><IMG 
                  src="fgi/chips_br.jpg"></TD></TR></TBODY></TABLE>
            <TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
              <TBODY>
              







               <?
include ("setup.php");
$resultg=mysql_query("select * from seting ");
$rog=mysql_fetch_array($resultg);
?>



	
	

	
	

	
		

            





		
               
            <TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
              <TBODY>
              <TR>
                <TD width=10><IMG 
                  src="fgi/d_tl.jpg"></TD>
                <TD class=fgdt colSpan=3><IMG 
                  src="fgi/d_t.jpg"></TD>
                <TD width=10><IMG 
                  src="fgi/d_tr.jpg"></TD></TR>
              <TR>
                <TD class=fgdl><IMG 
                  src="fgi/d_l.jpg"></TD>
                <TD class=fgd colSpan=3>
                  <center><H3>Withdrawal History </H3>












<BR>
<center>
<table border width="530" style="BORDER-COLLAPSE: collapse" cellspacing=0 cellpadding=3>
<tr><td class=fgd><b>Login</b><td class=fgd><b>Methode</b></td><td class=fgd><b>Amount</b></td><td class=fgd><b>Statut</b></td></tr>
<?
$result=mysql_query("select * from zakaz where login = '$l' ");
while($row=mysql_fetch_array($result))
{

if ( $row[5]==1 ) { $etat="Ongoing"; }

echo "
<tr><td class=fgd>$row[1]</td><td class=fgd>$row[3]</td><td class=fgd>$row[4]</td><td class=fgd>$etat</td></tr>
";
}
?>



















</table></center><br></center></TD>
                <TD class=fgdr><IMG 
                  src="fgi/d_r.jpg"></TD></TR>
              <TR>
                <TD class=fgdl><IMG 
                  src="fgi/d_l.jpg"></TD>
                <TD class=fgdb colSpan=3><IMG 
                  src="fgi/d_b.jpg"></TD>
                <TD class=fgdr><IMG 
                  src="fgi/d_r.jpg"></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></TD>
    <TD>&nbsp;</TD></TR>











  




<? include ("footer.php"); ?>





