<?php

/**
 * Account Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 16-12-2007
 */
class Account extends Controller
{
		//Constructor
		function Account()
		{
				parent::Controller();
				loginRequired();
				//Load the language file
				$this->lang->load('account', $this->config->item('language_code'));
		}
		//Default function
		function index()
		{
				$this->settings();
		}
		function settings()
		{
				//Load the required model, libraries, plugins.
				$this->load->library('validation');
				$this->load->model('usermodel');
				$outputData['activeTab'] = 1;
				$outputData['securityQuestions'] = $this->usermodel->getSecurityQuestions();
				$outputData['userQuestion'] = ($this->input->post('question')) ? $this->input->post('question') : $this->usermodel->getUserSecurityQuestion();
				$outputData['userName'] = ($this->input->post('new_name')) ? $this->input->post('new_name') : $this->session->userdata('username');
				$outputData['showPassword'] = str_repeat('*', strlen($this->session->userdata('show_password')));
				if ($this->input->post('change_password') == 'yes') $this->_changePasswordFrmRules();
				elseif ($this->input->post('change_question') == 'yes') $this->_changeSecurityQuestionFrmRules();
				elseif ($this->input->post('change_name') == 'yes') $this->_changeNameFrmRules();
				//Do the validation
				if ($this->validation->run() == false)
				{
						//Oops! validation Error.
						$outputData['validationError'] = $this->validation->error_string;
				}
				else
				{
						//Change password
						if ($this->input->post('change_password') == 'yes')
						{
								if ($this->usermodel->isValidPassword($this->input->post('old_password')))
								{
										if ($this->input->post('old_password') == $this->input->post('new_password')) $outputData['validationError'] = $this->lang->line('account_same_password');
										else
										{
												if ($this->session->userdata('email') != 'user@domain.tld') $this->usermodel->setPassword($this->input->post('new_password')); //Set the new password
												$outputData['successMsg'] = $this->lang->line('account_password_change_success');
										}
								}
								else  $outputData['validationError'] = $this->lang->line('account_password_wrong');
						}
						//Change Security Question
						elseif ($this->input->post('change_question') == 'yes')
						{
								//Set the new security answer
								$this->usermodel->setSecurityAnswer($this->input->post('question'), $this->input->post('answer'));
								$this->session->set_userdata(array('question_id' => $this->input->post('question'), 'security_answer' => $this->input->post('answer')));
								$outputData['successMsg'] = $this->lang->line('account_question_change_success');
						}
						//Change the name
						elseif ($this->input->post('change_name') == 'yes')
						{
								//Set the new security answer
								$this->usermodel->setName($this->input->post('new_name'));
								$this->session->set_userdata(array('username' => $this->input->post('new_name')));
								$outputData['successMsg'] = $this->lang->line('account_name_change_success');
						}
				}
				$this->smartyextended->view('account', $outputData);
		}
		function _changePasswordFrmRules()
		{
				$rules['old_password'] = 'trim|required|min_length[6]';
				$rules['new_password'] = 'trim|required|min_length[6]';
				$rules['confirm_password'] = 'trim|required|matches[new_password]';
				$this->validation->set_rules($rules);
				$fields['old_password'] = $this->lang->line('account_old_password');
				$fields['new_password'] = $this->lang->line('account_new_password');
				$fields['confirm_password'] = $this->lang->line('account_confirm_password');
				$this->validation->set_fields($fields);
		}
		function _changeSecurityQuestionFrmRules()
		{
				$rules['answer'] = 'trim|required|min_length[6]';
				$this->validation->set_rules($rules);
				$fields['answer'] = $this->lang->line('account_answer');
				$this->validation->set_fields($fields);
		}
		function _changeNameFrmRules()
		{
				$rules['new_name'] = 'trim|required|min_length[6]';
				$this->validation->set_rules($rules);
				$fields['new_name'] = $this->lang->line('account_name');
				$this->validation->set_fields($fields);
		}
		function notifications()
		{
				//Load the required model, libraries, plugins.
				$this->load->library('validation');
				$this->load->model('usermodel');
				$outputData['activeTab'] = 2;
				$outputData['notifications'] = $this->usermodel->getNotifications();
				if (isset($_POST['change_notification']) && $_POST['change_notification'] == 'yes')
				{
						//save the notifications
						if (isset($outputData['notifications']) && is_array($outputData['notifications']))
						{
								foreach ($outputData['notifications'] as $notificationId => $notificationValue)
								{
										$this->usermodel->setNotifications($notificationId, ($this->input->post('chk_notify_' . $notificationId) == 'on') ? 1 : 0);
								}
								$outputData['successMsg'] = $this->lang->line('account_notification_change_success');
						}
				}
				$outputData['userNotifications'] = $this->usermodel->getUserNotifications();
				$this->smartyextended->view('account', $outputData);
		}
}

?>