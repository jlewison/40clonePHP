<?
	$sitename = "My File Host";
	$siteurl = "YOURDOMAINNAME HERE/savefile_php/
	$admin25email = "emailaddress@localhost";
	$att_max_size = '5000';
	$att_filetypes = "gif|jpg|png|zip|rar|tar|gz|jar|";
	
      $dbServer = "localhost";
	$dbUser = "db user name here";
	$dbPass = "db password here";
	$dbName = "db name here";
	

	$requirepaid = "0"; // 1 for paid. 0 for free
	$paypal_email = "";
	$paypal_price = "1.50";
	$paypal_subcode = "M";
	$paypal_sub = "Monthly";

?>