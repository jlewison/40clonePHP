<html>
<head>
<title>Rapidsendit Clone - Free File Hosting Script</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body background="images/bg.gif" bgcolor="#5d5d5d" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" text="#37362f" link="#727169" vlink="#727169" alink="#727169">
<!-- ImageReady Slices Rapidsendit.com.psd) -->
<table align="center" id="Table_01" width="650" height="%100" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
			<img src="images/header.gif" width="650" height="90" alt=""></td>
	</tr>
	<tr>
		<td height="25" align="center" valign="middle" background="images/begin_content_top.gif">
		
			
				<font size="2" face="Verdana, Tahoma, Arial, Trebuchet MS, Sans-Serif, Georgia, Courier, Times New Roman, Serif">
			
		| <a href="index.php">Home</a> | <a href="index.php?page=tos">TOS</a> | <a href="index.php?page=faq">FAQ</a> | <a href="files.php">File List</a> |</font>	
		
	</td>
	</tr>
	<tr>
		<td align="center" valign="top" background="images/content_bg.gif" width="650" height="%100">
	<br>