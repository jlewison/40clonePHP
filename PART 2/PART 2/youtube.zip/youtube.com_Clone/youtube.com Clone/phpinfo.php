<?php
        phpinfo();
?>
