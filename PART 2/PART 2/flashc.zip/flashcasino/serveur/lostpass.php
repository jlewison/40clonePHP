<? include ("header1.php"); ?>

<table cellpadding="0" cellspacing="0" border="0" width="100%">
	<tr class="top4">
		<td>&nbsp;</td>
		<td width="778" valign="top">

<table cellpadding="0" cellspacing="0" border="0" width="778" class="log_tbl">
	<tr>
		<td valign="top" colspan="5"><img src="fgi/b.gif" height="62"></td>
	</tr>
	<tr>
		<td width="25" rowspan="3"><img src="fgi/b.gif" width="25"></td>
		<td class="flfield"  width="351"><h3>Lose password </h3><td>
		<td width="26" rowspan="2"><img src="fgi/b.gif" width="25"></td>
		
		<td width="25" rowspan="3"><img src="fgi/b.gif" width="25"></td>
	</tr>
	<tr>
		<td valign="top">
			<table cellpadding="0" cellspacing="0" border="0" width="100%">
				<tr>
					<td width="4"><img src="fgi/fl_tl.jpg"></td>
					<td class="flt"><img src="fgi/fl_t.jpg"></td>
					<td width="4"><img src="fgi/fl_tr.jpg"></td>
				</tr>
				<tr>
					<td class="fll"><img src="fgi/fl_l.jpg"></td>
					<td class="flc" height="155">









						 <FORM name=form action=lostpass.php method=post>
























<input type="hidden" name="submit" value="Login">







<table cellpadding="0" cellspacing="3" border="0" width="100%">


<tr>	<td class="flfield"> Please enter below your e-mail address indicated during registration<br>
</TD></tr>

</table>

<table cellpadding="0" cellspacing="3" border="0" width="100%">
<tr>
		<td class="flfield">Your email : </td>
		<td><input type="text" name="zapros" maxlength="128" value="" class="flinput" ID="Text1"></td>
	


		<td><input type="submit" name="Submit" value="Submit" id="SUBMIT" ></td>
	
<INPUT type=hidden value=1 name=send>

</tr>

</table>
						</form>








					</td>
					<td class="flr"><img src="fgi/fl_r.jpg"></td>
				</tr>
				<tr>
					<td><img src="fgi/fl_bl.jpg"></td>
					<td class="flb"><img src="fgi/fl_b.jpg"></td>
					<td><img src="fgi/fl_br.jpg"></td>
				</tr>
			</table>
		</td>
		
	</tr>
	<tr>
		<td colspan="3" class="fl_msg">&nbsp;</td>
	</tr>
</table>

		</td>
		<td>&nbsp;</td>
	</tr>


<?
if ($send=="1"){
$sqlr="select * from users where email='$zapros'";
$resultr=mysql_query($sqlr);
$rowr=mysql_fetch_array($resultr);
$r_login= $rowr[1];
$r_pass = $rowr[2];
include("mail/reg.php");
$to = $rowr[6];
$subject = $reg_reg_mail_subject;
$msg =$reg_reg_mail;
$mailheaders = "Content-Type: text/plain; charset=iso-8859-1\n";
$mailheaders .= "From:$con[2];\n";
mail($to, $subject, $msg, $mailheaders);
echo "<script> alert('Votre mot de passe vous a �t� envoy� !'); document.location.href='index.php'; </script>";
}
?>






















	<? include ("footer.php") ?>