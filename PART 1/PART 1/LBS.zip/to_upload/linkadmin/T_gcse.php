<?php include('restrict.php'); include('../settings.php'); require_once('../Connections/apound.php');
mysql_select_db($database_apound, $apound);
$query_gCSE = "SELECT * FROM google_cse";
$gCSE = mysql_query($query_gCSE, $apound) or die(mysql_error());
$row_gCSE = mysql_fetch_assoc($gCSE);
$totalRows_gCSE = mysql_num_rows($gCSE);
$cse_on = $row_gCSE['cse_on'];
$cse_main = $row_gCSE['cse_main'];
?>