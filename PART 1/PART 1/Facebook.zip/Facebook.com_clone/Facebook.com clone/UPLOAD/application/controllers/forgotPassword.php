<?php
/**
 * ForgotPassword Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 12/17/2007
 */
class ForgotPassword extends Controller
{
		//Constructor
		function ForgotPassword()
		{
				parent::Controller();
				loggedInTakeIn();
				//Load the language file
				$this->lang->load('login', $this->config->item('language_code'));
				$this->lang->load('forgotPassword', $this->config->item('language_code'));
		}
		//Default function
		function index()
		{
				$this->load->library('validation');
				$this->load->model('userModel');
				//Load the cookie helper
				$this->load->helper('cookie');
				$outputData['emailShow'] = false;
				//Get the e-mail from Cookie if set
				$outputData['user_email'] = get_cookie('kootali_email');
				if ($this->input->post('next') == 'next') $this->forgotPasswordFrm();
				else  $this->secretQuestionFrm();
				/* Validation */
				if ($this->validation->run() == false)
				{
						if ($this->input->post('next') == 'next' || empty($_POST)) $outputData['emailShow'] = true;
						else
						{
								$outputData['secret_question'] = $this->userModel->getUserSecretQuestion($this->input->post('user_id'));
								$outputData['user_id'] = $this->input->post('user_id');
								$outputData['user_name'] = $this->input->post('user_name');
								$outputData['user_email'] = $this->input->post('fp_email');
						}
						$outputData['validationError'] = trim($this->validation->error_string);
						$this->smartyextended->view('forgotPassword', $outputData);
				}
				else
				{
						$email = $this->input->post('fp_email');
						if ($this->input->post('next') == 'next')
						{
								$outputData['user_email'] = $email;
								$userData = $this->userModel->chkUserEmail($email);
								if ($userData == false)
								{
										$outputData['emailShow'] = true;
										$outputData['validationError'] = $this->lang->line('forgotpassword_invalid_email');
								}
								else
								{
										$outputData['user_id'] = $userData['user_id'];
										$outputData['user_name'] = $userData['username'];
										$outputData['secret_question'] = $this->userModel->getUserSecretQuestion($userData['user_id']);
								}
						}
						else
						{
								$outputData['secret_question'] = $this->userModel->getUserSecretQuestion($this->input->post('user_id'));
								$outputData['user_id'] = $this->input->post('user_id');
								$outputData['user_name'] = $this->input->post('user_name');
								$outputData['user_email'] = $this->input->post('fp_email');
								$user = $this->userModel->chkSecretAnswer($this->input->post('user_id'), $this->input->post('secret_answer'));
								if ($user != false)
								{
										$randNo = rand(100000, 999999);
										$newPassword = md5($randNo);
										$this->userModel->setPassword($randNo, $this->input->post('user_id'));
										$this->_sendResetPasswordEmail($this->input->post('user_name'), $randNo);
										//Set the flash data
										$this->session->set_flashdata('flash_msg', $this->lang->line('forgotpassword_success_msg'));
										redirect('login');
								}
								else  $outputData['validationError'] = $this->lang->line('forgotpassword_invalid_secret_answer');
						}
						$this->smartyextended->view('forgotPassword', $outputData);
				}
		}
		function _sendResetPasswordEmail($username, $newPassword)
		{
				//loads emailTemplate library
				$this->load->model('emailTemplateModel');
				//loads email library
				$this->load->library('email');
				$emailTemplate = $this->emailTemplateModel->readEmailTemplate('forget_password');
				//admin settings
				$fields = 'site_title,admin_name,admin_email';
				$adminData = $this->settingsmodel->readSetting($fields);
				$this->email->from($adminData['admin_email'], $adminData['admin_name']);
				$this->email->to($this->input->post('fp_email'));
				$splVars = array("~~siteName~~" => $adminData['site_title'], "~~receiverName~~" => ucwords($username), "~~NewPassword~~" => $newPassword, "~~adminName~~" => $adminData['admin_name']);
				$mailSubject = strtr($emailTemplate['template_subject'], $splVars);
				$mailContent = strtr($emailTemplate['template_content'], $splVars);
				$this->email->subject($mailSubject); //set subject to send mail
				$this->email->message(nl2br($mailContent)); //set message to send mail
				$this->email->send();
		}
		function forgotPasswordFrm()
		{
				$rules['fp_email'] = 'trim|required|valid_email';
				$fields['fp_email'] = $this->lang->line('forgotpassword_email');
				$this->validation->set_rules($rules);
				$this->validation->set_fields($fields);
		}
		function secretQuestionFrm()
		{
				$rules['secret_answer'] = 'trim|required';
				$fields['secret_answer'] = $this->lang->line('forgotpassword_secret_answer');
				$this->validation->set_rules($rules);
				$this->validation->set_fields($fields);
		}
}
?>