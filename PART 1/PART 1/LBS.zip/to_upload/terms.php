<?php include('ip_domain_ban.php'); include('settings.php'); if($onoff == 'N') { include('disabled.php'); exit; } else { } ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<?php echo("$lang_0");?>
<?php echo("$lang_01");?>
<title><?php echo("$terms_title");?> - <?php echo("$sitetitle");?></title>
<link rel="shortcut icon" href="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/favicon.ico" />
<link href="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/style.css" rel="stylesheet" type="text/css" />
<meta name="description" content="<?php echo("$terms_description");?>">
<meta name="keywords" content="<?php echo("$terms_keyword");?>">
</head>

<body>

<?php include("template/$lbdtemplate/a_main_terms.php"); ?>

</body>
</html>