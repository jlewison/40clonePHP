<?php

/**
 * Help Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 1/2/2008
 */
class Help extends Controller
{
		//Constructor
		function Help()
		{
				parent::Controller();
				//Load the language file
				$this->lang->load('login', $this->config->item('language_code'));
				$this->lang->load('help', $this->config->item('language_code'));
		}
		//Default function
		function index()
		{
				$this->smartyextended->view('help');
		}
}

?>