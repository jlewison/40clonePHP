<?php include('restrict.php'); include('../settings.php'); require_once('../Connections/apound.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO `language` (langu_name) VALUES (%s)",
                       GetSQLValueString($_POST['langu_name'], "text"));

  mysql_select_db($database_apound, $apound);
  $Result1 = mysql_query($insertSQL, $apound) or die(mysql_error());
  $done = "<div align='center'><font color='red'><b>Update ... DONE</b></font></div>";
}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Link Bid Script - Admin Control Panel</title>
<link rel="shortcut icon" href="img/favicon.ico" />
<link rel="stylesheet" type="text/css" href="admin.css" />
<style type="text/css">
<!--
#admnav li {
	padding-top: 0px;
	padding-bottom: 0px;
	margin-top: 0px;
	margin-bottom: 0px;
}
#admnav ul {
	padding-top: 0px;
	padding-bottom: 0px;
	margin-top: 0px;
	margin-bottom: 0px;
}
#stats {
	font-weight: normal;
	font-size: 11px;
}
-->
</style>
</head>

<body>
<?php include('header_tpl.php'); ?>

<table width="770"  border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="770" bgcolor="#FFFFFF"><?php $x = getenv("HTTP_HOST").getenv("REQUEST_URI"); echo("<font color=white>$x</font>"); ?></td>
  </tr>
</table>
<table width="760" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="760"><h2 class="style67">Language management</h2>
      
      <form method="post" name="form1" action="<?php echo $editFormAction; ?>">
      <?php echo("$done");?>
        <table align="center">
          <tr valign="baseline">
            <td nowrap align="right"><strong>Add language:</strong><br></td>
            <td><input type="text" name="langu_name" value="" size="32"> 
              <input type="submit" value="Insert record"></td>
          </tr>
          <tr valign="baseline">
            <td colspan="2" align="center" nowrap>(type the name of the laguage file
without .php extension ex: lang_english
              )</td>
            </tr>
        </table>
        <input type="hidden" name="MM_insert" value="form1">
      </form>
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td>&nbsp;</td>
        </tr>
      </table>
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td>
<?php
mysql_select_db($database_apound, $apound);
$query_LALI = "SELECT * FROM `language`";
$LALI = mysql_query($query_LALI, $apound) or die(mysql_error());
$row_LALI = mysql_fetch_assoc($LALI);
$totalRows_LALI = mysql_num_rows($LALI);
?>
<table border="0" align="center" cellpadding="3" cellspacing="0">
  <tr>
    <td bgcolor="#F1FFAE"><strong>Existing language files:</strong></td>
  </tr>
  <?php do { ?>
    <tr>
      <td><?php echo $row_LALI['langu_name']; ?>.php</td>
    </tr>
    <?php } while ($row_LALI = mysql_fetch_assoc($LALI)); ?>
</table>
<?php mysql_free_result($LALI); ?>
          </td>
        </tr>
      </table>
      </td>
  </tr>
</table>
<?php include('footer_tpl.php'); ?>
</body>
</html>