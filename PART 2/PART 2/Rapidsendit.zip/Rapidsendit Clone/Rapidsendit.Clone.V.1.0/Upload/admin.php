<?php
$i=0;
////////////////////////////////////////////////////////////// 
// Rapidsendit Clone V.1.1  Purchased from Rapidsendit.com ///
// flatFileHost lives on! Credits To Jim For The Foundtion ///
//////////////////////////////////////////////////////////////

include("./config.php");
if(isset($_GET['act'])){$act = $_GET['act'];}else{$act = "null";}
$contents = file("password.txt");
$pass = md5(implode($contents));

if(isset($_GET['act']) && ($act=="login")) {
  $entered = md5($_POST['passwordx']);
  $contents = file("password.txt");
  $adminpass = implode($contents);
  
  if($entered == $adminpass){ 
    $cookiepass = md5($adminpass);
    setcookie('logged', $cookiepass, 0, "/", $SERVER['SERVER_NAME'], 0);
    echo "<script>window.location=\"admin.php\";</script>";    
    } 
  else {
    include ("./header.php");
    echo "Invalid password<br>";
    echo "<p><center><a href=\"admin.php\"><font face='Verdana' size='2'>Try again</a></font>";
    include ("./footer.php");
    die();
  }
}

if(isset($_GET['act']) && $act=="nopass"){

  $password = md5($_POST['pass']);
  $fp = fopen("password.txt", 'w');
  fputs ($fp,$password);
  fclose ($fp);
  chmod("password.txt", 0777);
  echo "<script>window.location=\"admin.php\"</script>";
  break;
}

if(isset($_COOKIE['logged']) && $_COOKIE['logged'] == $pass) {

if(isset($_GET['act']) && ($act=="logout"))  {
setcookie('logged', "", time()-60, "/", $SERVER['SERVER_NAME'], 0);
session_unset();
include ("./header.php");
echo "You have been logged out.";
echo "<p><center><a href=\"admin.php\"><font face='Verdana' size='2'>Login again</font></a>";
include ("./footer.php");
die();
}

include("./header.php");
if(isset($_GET['act']) && ($act=="newpass")) {

if(isset($_POST['newpassword'])){
$fb = fopen( "password.txt", 'w');
$changedpass = md5($_POST['newpassword']);
fputs ($fb, $changedpass);
fclose ($fb);
@chmod("password.txt", 0777);
echo "<script>window.location=\"admin.php?act=logout\"</script>";
} 
?>
<font face='Verdana' size='3'><b><u>Change Password</u></b></font><p>
<center>
After changing the password you will be logged out and will have to log in again with the new password.
<p>
<form action="admin.php?act=newpass" method="post">
Enter a new password: <input type="password" name="newpassword">
<input type="submit" value="Change Password">
<br /></form></center>

<?php
include ("./footer.php");
die();
}

//if(isset($_GET['download'])){
//$checkfiles=file("./files.txt");
//foreach($checkfiles as $line){
//  $thisline = explode('|', $line);
//  if($thisline[0]==$_GET['download'])
//   $downloadfile=$thisline;
//}
//echo "<script>window.location='".$scripturl."download2.php?a=".$downloadfile[0]."&b=".md5($downloadfile[2].$_SERVER['REMOTE_ADDR'])."';</script>";
//}

// begin separate file mod:
if(isset($_GET['download'])){
$filecrc = $_GET['download'];
$filecrctxt = $filecrc . ".txt";
if (file_exists("./storagedata/" . $filecrctxt)) {
	$fh = fopen("./storagedata/" . $filecrctxt, r);
	$filedata= explode('|', fgets($fh));
}
echo "<script>window.location='".$scripturl."download2.php?a=".$filecrc."&b=".md5($filedata[1].$_SERVER['REMOTE_ADDR'])."';</script>";
fclose ($fh);
}
// end separate file mod

//if(isset($_GET['delete'])) {
//$fc=file("./files.txt");
//$f=fopen("./files.txt","w+");
//foreach($fc as $line)
//{
//  $thisline = explode('|', $line);
//  if ($thisline[0] != $_GET['delete'])
//    fputs($f,$line);
//}
//fclose($f);
//unlink("./storage/".$_GET['delete']);
//}

// begin separate file mod:
if(isset($_GET['delete'])) {
unlink("./storagedata/".$_GET['delete'].".txt");
unlink("./storage/".$_GET['delete']);
}
// end separate file mod

//if(isset($_GET['banreport'])) {
//$fc=file("./files.txt");
//$f=fopen("./files.txt","w+");
//foreach($fc as $line)
//{
//  $thisline = explode('|', $line);
//  if ($thisline[0] != $_GET['banreport'])
//    fputs($f,$line);
//  else
//    $deleted=$thisline;
//}
//fclose($f);

// begin separate file mod:
if(isset($_GET['banreport'])) {
$bannedfile = $_GET['banreport'];
if (file_exists("./storagedata/$bannedfile".".txt")) {
	unlink("./storagedata/".$bannedfile.".txt");
	unlink("./storage/".$bannedfile);
	$deleted=$bannedfile;
}
// end separate file mod

$fc=file("./reports.txt");
$f=fopen("./reports.txt","w+");
foreach($fc as $line)
{
  $thisline = explode('|', $line);
  if ($thisline[0] != $_GET['banreport'])
    fputs($f,$line);
}
fclose($f);
$f=fopen("./bans.txt","a+");
fputs($f,$deleted[3]."\n".$deleted[0]."\n");
unlink("./storage/".$_GET['banreport']);

}

if(isset($_GET['ignore'])) {

$fc=file("./reports.txt");
$f=fopen("./reports.txt","w+");
foreach($fc as $line)
{
  $thisline = explode('|', $line);
  if ($thisline[0] != $_GET['ignore'])
    fputs($f,$line);
}
fclose($f);
}

if(isset($_GET['act']) && $_GET['act']=="bans") {
if(isset($_GET['unban'])) {
$fc=file("./bans.txt");
$f=fopen("./bans.txt","w+");
foreach($fc as $line)
{
  if (md5($line) != $_GET['unban'])
    fputs($f,$line);
}
fclose($f);
}

if(isset($_POST['banthis'])) {
$f=fopen("./bans.txt","a+");
fputs($f,$_POST['banthis']."\n");
}


?>
<font face='Verdana' size='3'><b><u>Bans</u></b></font><p> <center><form action="admin.php?act=bans" method="post">enter an ip or file hash to ban:  
<input type="text" name="banthis"> 
<input type="submit" value="BAN!">
<br />
</form></center>
<?php

$fc=file("./bans.txt");
foreach($fc as $line)
{
  echo $line . " - <a href=\"admin.php?act=bans&unban=".md5($line)."\">unban</a><br />";
}

include("./footer.php");
die();
}

//delete old files
echo "Deleting old files...<BR>";
$deleteseconds = time() - ($deleteafter * 24 * 60 * 60);
$dirname = "./storagedata";
$dh = opendir( $dirname ) or die("couldn't open directory");
while ( $file = readdir( $dh ) ) {
if ($file != '.' && $file != '..' && $file != ".htaccess") {
  $fh=fopen("./storagedata/" . $file ,r);
  $filedata= explode('|', fgets($fh));
  if ($filedata[3] < $deleteseconds) {
    $deletedfiles="yes";
	echo "Deleting - " . $filedata[0] . ":<BR>"; 
    unlink("./storagedata/".$file);
	echo "Deleted /storagedata/" . $file . "<BR>"; 
    unlink("./storage/".str_replace(".txt","",$file));
	echo "Deleted /storage/" . str_replace(".txt","",$file) . "<BR><BR>"; 
  }
  fclose($fh);
}
}
closedir( $dh );
if (!$deletedfiles) echo "No old files to delete!<br /><br />";
//done deleting old files

?>

<center><font face='Verdana' size='2'>
<a href="admin.php?act=logout">Log out</a> 
| <a href="admin.php?act=bans">Manage bans</a>
| <a href="admin.php?act=newpass">Change password</a>
| <a href="filecheck.php" target=_blank>Check file integrity</a>
</center></font><br />


  <font face='Verdana' size='3'><b><u>Reports</u></b></font>
<table width="90%" cellpadding="0" cellspacing="0" border="0">
<tr><td><font face='Verdana' size='1'><b>Filename</b></font></td><td><b><font face='Verdana' size='1'>Uploader</font></b></td><td><font face='Verdana' size='1'><b>Delete&Ban</b></font></td><td><font face='Verdana' size='1'><b>Ignore Report</b></font></font></td></tr>
<?php

$checkreports=file("./reports.txt");
foreach($checkreports as $line)
{
  $thisreport = explode('|', $line);
//  $checkfiles=file("./files.txt");
//  foreach($checkfiles as $line)
//  {
//    $thisline = explode('|', $line);
//    if($thisline[0]==$thisreport[0]){
//	$foundfile=$thisline;
//    }
//  }

// begin separate file mod:

$filecrc = $thisreport[0];
if (file_exists("./storagedata/$filecrc".".txt")) {
	$fr=fopen("./storagedata/".$filecrc.".txt",r);
	   if($i % 2 == 0) { $bgcolor = "background-color: #d3dde7;"; } else if ($i % 2 != 0) {$bgcolor = "background-color: #f5f5dc;";}
$i++;

	$foundfile= explode('|', fgets($fr));
	fclose($fr);
}
// end separate file mod

echo "<tr style='$bgcolor'><td><font face='Verdana' size='1'><a href=\"admin.php?download=".$filecrc."\">".$foundfile[0]."</font></td>";
echo "<td><font face='Verdana' size='1'>".$foundfile[2]."</td>";
echo "<td><font face='Verdana' size='1'><a href=\"admin.php?banreport=".$filecrc."\">Delete&Ban</a></font></td>";
echo "<td><font face='Verdana' size='1'><a href=\"admin.php?ignore=".$filecrc."\">Ignore Report</a></font></td></tr>";

}

?>
</table>
<br />

  <font face='Verdana' size='3'><b><u>Files</u></b></font>
<table width="90%" cellpadding="0" cellspacing="0" border="0">
<tr><td><b><font face='Verdana' size='1'>Filename</b></font></td><td><b><font face='Verdana' size='1'>Size (MB)</b></font></td><td><b><font face='Verdana' size='1'>Uploader</b></font></td><td><font face='Verdana' size='1'><b>Bandwidth(MB)</b></font></td><td><font face='Verdana' size='1'><b>Delete</b></font></font></td></tr>
<?php

//$checkfiles=file("./files.txt");
//foreach($checkfiles as $line)
//{
//  $thisline = explode('|', $line);
//  $filesize = filesize("./storage/".$thisline[0]);
//  $filesize = ($filesize / 1048576);
//  echo "<tr style='$bgcolor'><td><a href=\"admin.php?download=".$thisline[0]."\">".$thisline[1]."</td><td>".round($filesize,2)."</td>";
//  echo "<td>".$thisline[3]."</td><td>".round($filesize*$thisline[5],2)."</td><td><a href=\"admin.php?delete=".$thisline[0]."\">delete</a></td></tr>";
//}

// begin separate file mod

$dirname = "./storagedata";
$dh = opendir( $dirname ) or die("couldn't open directory");
while ( $file = readdir( $dh ) ) {
if ($file != '.' && $file != '..' && $file != '.htaccess') {
	   if($i % 2 == 0) { $bgcolor = "background-color: #d3dde7;"; } else if ($i % 2 != 0) {$bgcolor = "background-color: #f5f5dc;";}
$i++;

  $filecrc = str_replace(".txt","",$file);
  $filesize = filesize("./storage/". $filecrc);
  $filesize = ($filesize / 1048576);
  $fh = fopen ("./storagedata/".$file, r);
  $filedata= explode('|', fgets($fh));
  echo "<tr style='$bgcolor'><td><font face='Verdana' size='1'><a href=\"admin.php?download=".$filecrc."\">".$filedata[0]."</a></font></td><td><font face='Verdana' size='1'>".round($filesize,2)."</font></td>";
  echo "<td><font face='Verdana' size='1'>".$filedata[2]."</font></td><td style=padding-left:5px><font face='Verdana' size='1'>&nbsp".$filedata[4]." </font></td><td style=padding-left:5px><font face='Verdana' size='1'>".round($filesize*$filedata[4],2)."</font></td><td style=padding-left:5px><a href=\"admin.php?delete=".$filecrc."\">[x]</a></td></tr>";
  fclose ($fh);
}
}
closedir( $dh );
// end separate file mod


echo "</table>";

} else {

  if (filesize("password.txt") != 0){
  	include("./header.php");?>
    <center>
    <font face='Verdana' size='3'><b><u>Admin Login</u></b></font><br />
    <form action="admin.php?act=login" method="post">Password:  
    <input type="password" name="passwordx"> 
    <input type="submit" value="Login">
    <br /><br />
    </form></center>
    <?php 
  } else { 
	include("./header.php");
  	?>
    <font face='Verdana' size='3'><b><u>Set Admin Password</u></b></font><p>
	<center>
	<form action="admin.php?act=nopass" method="post">
	Enter your admin password: <input type="password" name="pass">
	<input type="submit" value="Set Password">
	<br /></form></center>
	<?php 
  }

}
include("./footer.php");
?>