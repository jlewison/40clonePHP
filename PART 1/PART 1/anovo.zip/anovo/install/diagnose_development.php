<?php
session_start();
if (!isset($_SESSION['check']) or !$_SESSION['check']) header('Location: auth.php');
if (!defined('E_STRICT')) define('E_STRICT', 2048);
$expected_ini_settings = array('asp_tags' => false, 'output_buffering' => false, 'allow_call_time_pass_reference' => false, 'error_reporting' => E_ALL | E_STRICT, 'display_errors' => true, 'display_startup_errors' => true, 'ignore_repeated_errors' => false, 'ignore_repeated_source' => false, 'report_memleaks' => true, 'track_errors' => false, 'log_errors' => true, 'html_errors' => false, 'register_globals' => false, 'magic_quotes_gpc' => false, 'magic_quotes_runtime' => false, 'max_execution_time' => 60);
$expected_extensions = array('GD' => 'imagecolorat', 'ctype' => 'ctype_alnum');

?>
<h1>Diagnose Development Environment</h1>
  <h2>Expected INI Settings</h2>
<?php
foreach ($expected_ini_settings as $ini_key => $expected_ini_value)
{
		$current_ini_value = ini_get($ini_key);
?>
	<p>
		Expected: <?php echo $ini_key; ?>=<?php echo (string )$expected_ini_value; ?><br />
		Current: <?php echo $ini_key; ?>=<?php echo (string )$current_ini_value; ?>
	</p>
<?php
}
?>
  <h2>Expected Extensions</h2>
<?php
foreach ($expected_extensions as $extension_name => $extension_function)
{
?>
	<p>
		Current: <?php echo $extension_name; ?>=<?php echo (string )function_exists($extension_function); ?>
	</p>
<?php
}
?>
