<?
$config = array();
$config['BASE_DIR']        =  'C:/Program Files/xampp/htdocs/uploadgalaxyclone';
$config['BASE_URL']        =  'http://localhost/uploadgalaxyclone';
$config['TEMP_DIR']        = $config['BASE_DIR']."";
$config['baseurl']        =  $config['BASE_URL']; '';
$config['basedir']        =  $config['BASE_DIR'];  "temp";
$config['CONF_FILE']        =  $config['BASE_DIR'].'/include/conf.ini';
$config['IMG_DIR']        =  $config['BASE_DIR'].'/images';
$config['IMG_URL']        =  $config['BASE_URL'].'/images';
$config['imgurl']         =  $config['IMG_URL'];
$config['imgpath']        =  $config['IMG_DIR'];
$config['site_name']      ='www.SiteName.com';

require_once($config['BASE_DIR'].'/smarty/libs/Smarty.class.php');
require_once($config['BASE_DIR'].'/classes/mysmarty.class.php');
require_once($config['BASE_DIR'].'/classes/SConfig.php');
require_once($config['BASE_DIR'].'/classes/SError.php');
require_once($config['BASE_DIR'].'/include/adodb/adodb.inc.php');
require_once($config['BASE_DIR'].'/include/phpmailer/class.phpmailer.php');
require_once($config['BASE_DIR'].'/classes/SEmail.php');

$DBTYPE = 'mysql';
$DBHOST = SConfig::get("Database", "host");
$DBUSER = SConfig::get("Database", "user_name");
$DBPASSWORD = SConfig::get("Database", "password");
$DBNAME = SConfig::get("Database", "db_name");

$conn = &ADONewConnection($DBTYPE);
$conn->PConnect($DBHOST, $DBUSER, $DBPASSWORD, $DBNAME);

$sql = "SELECT * from configuration";
$rsc = $conn->Execute($sql);

if($rsc)
{
while(!$rsc->EOF)
{
$field = $rsc->fields['conf_name'];
$config[$field] = $rsc->fields['conf_value'];
STemplate::assign($field,$rsc->fields['conf_value']);
@$rsc->MoveNext();
}
}

//print_r($config);
STemplate::assign('payto',       $config['PAY_TO']);
STemplate::assign('baseurl',       $config['BASE_URL']);
STemplate::assign('imgurl',        $config['IMG_URL']);
STemplate::assign('site_name',        $config['site_name']);
STemplate::setCompileDir($config['basedir']."/templates_c");
STemplate::setTplDir($config['basedir']."/templates");
?>
