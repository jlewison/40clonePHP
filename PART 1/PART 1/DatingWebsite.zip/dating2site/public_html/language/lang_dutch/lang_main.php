<?php

$lang['ENCODING'] = 'iso-8859-1';
$lang['DIRECTION'] = 'ltr';
$lang['LEFT'] = 'links';
$lang['RIGHT'] = 'rechts';
$lang['DATE_FORMAT'] =  '%d %F, %Y'; // This should be changed to the default date format for your language, php date() format
$lang['DATE_TIME_FORMAT'] =  '%d %F, %Y %H:%i:%s'; // This should be changed to the default date format for your language, php date() format
$lang['DISPLAY_DATE_FORMAT'] =  'd M, Y';
$lang['DISPLAY_DATETIME_FORMAT'] = 'd M, Y H:i:s';
$lang['DB_ERROR'] = "Je aanvraag kon niet worden uitgevoerd door een fout in de databank.<br>Probeer a.u.b opnieuw.";

$lang['main_menu'] = 'Hoofdmenu';
$lang['homepage'] = 'Startpagina';
$lang['rate_photos'] = 'Beoordeel foto\'s';
$lang['forum'] = 'Forum';
$lang['manageforum'] = 'Forumbeheer';
$lang['chat'] = 'Chat';
$lang['managechat'] = 'Chatbeheer';
$lang['member_login'] = 'Login Leden';
$lang['featured_members'] = 'Leden in de schijnwerpers';
$lang['quick_search'] = 'Snel Zoeken';
$lang['my_searches'] = 'Mijn zoekopdrachten';
$lang['affiliates'] = 'Lidmaatschap';
$lang['already_affiliate'] = 'Ben je reeds lid?';
$lang['referals'] = 'Verwijzingen';
$lang['title_colon'] = 'Titel:';
$lang['comments_colon'] = 'Commentaar:';
$lang['feedback'] = 'Feedback';

$lang['profiles'] = 'Profielen';
$lang['profile_s'] = 'USERNAME\'s Profiel';
$lang['total_amt'] = 'Totaal bedrag';
$lang['banner_link'] = 'Banner/link';
$lang['clicks'] = 'Kliks';
$lang['finance_calc'] = 'Financieel calculator';
$lang['flash_chat_msg'] = 'FlashChat 4.1.0 en hoger bevatt een integratie-klasse voor osDate. Gelieve FlashChat te kopen via <a href="www.tufat.com/chat.php" target="_blank">www.tufat.com/chat.php</a> en de bestanden naar deze map te kopieren. 	Hierna moet u de FlashChat installer uitvoeren en osDate kiezen als de CMS waarmee deze moet integreren.';
$lang['flash_chat_admin_msg'] = 'FlashChat 4.1.0 en hoger bevat een integratie-klasse voor osDate. Gelieve FlashChat te kopen via <a href="www.tufat.com/chat.php" target="_blank">www.tufat.com/chat.php</a> en de bestanden naar deze map te kopieren. 	Hierna moet u de FlashChat installer uitvoeren en osDate kiezen als de CMS waarmee deze moet integreren.';
$lang['affiliate_head_msg'] = 'Word partner.';
$lang['affiliate_head_msg2'] = 'We bieden commissie aan webmasters die bezoekers naar onze site sturen.<br/>';
$lang['affiliate_success_msg1'] = 'Je partner-account id is:';
$lang['affiliate_success_msg2'] = 'Je mag nu inloggen op je account. ';
$lang['affiliate_login_title'] = "Partner Login";
$lang['password_changed_successfully'] = 'Wachtwoord succesvol aangepast.';
$lang['affiliate_registration_success'] = 'Registratie Partner voltooid';
$lang['login_now'] = 'Log hier in';
$lang['must_be_valid'] = 'Moet correct zijn';
$lang['characters'] = 'tekens';
$lang['email'] = 'Email:';
$lang['age'] = 'Leeftijd';
$lang['years'] = 'jaar';

$lang['all_states'] = 'Alle provincies';
//
// These terms are used at Signup page
//
$lang['welcome'] = 'Welkom';
$lang['admin_welcome'] = 'Welcome <br /> bij <br />' . 'SITENAME' . '<br /> Beheerderpaneel';
$lang['title'] = 'Welkom op ' . 'SITENAME';
$lang['site_links'] = array(
	'home' => 'Home',
	'signup_now' => 'Inschrijven',
	'chat' => 'Chat',
	'forum' => 'Forum',
	'login' => 'Login',
	'search' => 'Zoek',
	'aboutus' => 'Over Ons',
	'forgot' => 'Wachtwoord/Login vergeten?',
	'contactus' => 'Contacteer Ons',
	'privacy' => 'Privacy',
	'terms_of_use' => 'Gebruiksvoorwaarden',
	'services' => 'Diensten',
	'faq' => 'FAQ\'s',
	'articles' => 'Artikels',
	'affliates' => 'Partners',
	'invite_a_friend' => 'Nodig een vriend uit',
	'feedback' => 'Feedback'
	);

$lang['success_stories'] = 'Succesverhalen';
$lang['members_login'] = 'Login Leden';
$lang['poll'] = 'Poll';
$lang['news'] = 'Nieuws';
$lang['articles'] = 'Artikels';
$lang['poll_result'] = 'Resultaten Poll';
$lang['view_poll_archive'] = 'Vorige Polls';
$lang['member_panel'] = 'Ledenpaneel';
$lang['poll_errmsg1'] = 'Je hebt reeds op deze poll gestemd. Probeer een andere poll op een andere dag.';
$lang['close'] = 'Sluiten';
$lang['all_stories'] = 'Alle Verhalen';
$lang['all_news'] = 'Alle Nieuws';
$lang['more'] = 'meer';
$lang['by'] = 'door';

$lang['dont_stay_alone'] = 'Blijf niet alleen,';
$lang['join_now_for_free'] = 'Sluit je nu gratis aan';
$lang['special_offer'] = 'Speciale aanbieding!';
$lang['welcome_to'] = 'Welkom bij ';
$lang['welcome_to_site'] = 'Welkom bij '.'SITENAME';

$lang['offer_text'] = 'Zie zelf waarom ' . 'SITENAME' . ' de snelst groeiende datingsite op het net is. Maak uw ' . 'SITENAME' . ' profiel aan om de opwindende zoektocht naar je match te starten.';

$lang['newest_profiles'] = 'Nieuwste Profielen';

$lang['edit_profile'] = 'Pas profiel aan ';
$lang['total_profiles'] = 'Aantal profielen';
$lang['forgot'] = 'Login vergeten?';
$lang['hide'] = 'Verberg';
$lang['show'] = 'Toon';
$lang['sex'] = 'Geslacht:';
$lang['sex_without_colon'] = 'Geslacht';
$lang['pageno'] = 'Pagina ';
$lang['page'] = 'Pagina';
$lang['previous'] = 'Vorige';
$lang['next'] = 'Volgende';
$lang['time_col'] = 'Tijd:';

$lang['save_search'] = 'Zoekresultaten opslaan';
$lang['find_your_match'] = 'Zoek uw match';

$lang['extended_search'] = 'Uitgebreid zoeken';
$lang['matches_found'] = 'Volgende matches gevonden op basis van je gegevens.';
$lang['timezone'] = 'Tijdszone:';
$lang['next_section'] = 'Volgende onderdeel';
$lang['sign_in'] = 'Registratie Leden';
$lang['member_panel'] = 'Ledenmenu';
$lang['aff_panel'] = 'Partnerspaneel';
$lang['login_title'] = 'Login Leden Zone';
$lang['sign_out'] = 'Uitloggen';
$lang['login_submit'] = 'Login';

$lang['change_password'] = 'Verander wachtwoord';
$lang['old_password'] = 'Oud wachtwoord:';
$lang['new_password'] = 'Nieuw wachtwoord:';
$lang['confirm_password'] = 'Bevestig wachtwoord:';
$lang['password_change_msg'] = 'Uw wachtwoord is succesvol aangepast.';

$lang['section_signup_title'] = 'Registratie informatie';
$lang['signup'] = 'Registreren';
$lang['section_basic_title'] = 'Basis informatie';
$lang['section_appearance_title'] = 'Uiterlijk';
$lang['section_interests_title'] = 'Interesses';
$lang['section_lifestyle_title'] = 'Levensstijl';

$lang['signup_subtitle_login'] = 'Login details';
$lang['signup_subtitle_profile'] = 'Mijn profiel';
$lang['signup_subtitle_address'] = 'Adres';
$lang['signup_subtitle_appearacnce'] = 'Uiterlijk';
$lang['signup_subtitle_preference'] = 'Zoek voorkeuren';

$lang['signup_username'] = 'Gebruikersnaam:';
$lang['signup_password'] = 'Wachtwoord:';
$lang['signup_confirm_password'] = 'Bevestig Wachtwoord:';

$lang['signup_firstname'] = 'Voornaam:';
$lang['signup_lastname'] = 'Familienaam:';
$lang['signup_email'] = 'Email adres:';
$lang['section_mypicture'] = 'Mijn afbeeldingen';
$lang['upload'] = 'Upload';
$lang['upload_pictures'] = 'Upload afbeeldingen';
$lang['upload_format_msgs'] = 'Enkel .jpg, .gif, .bmp of .png bestanden zijn toegestaan.';
$lang['thumbnail'] = 'Kleine afbeelding';
$lang['picture'] = 'Afbeelding';
$lang['signup_picture'] = 'Mijn afbeelding';
$lang['signup_picture2'] = 'Mijn afbeelding 2:';
$lang['signup_picture3'] = 'Mijn afbeelding 3:';
$lang['signup_picture4'] = 'Mijn afbeelding 4:';
$lang['signup_picture5'] = 'Mijn afbeelding 5:';

$lang['signup_gender'] = 'Ik ben een';
$lang['signup_pref_age_range'] = 'Voorkeurs-leeftijd';
$lang['signup_year_old'] = 'jaar oud';
$lang['signup_birthday'] = 'Geboortedatum:';
$lang['signup_country'] = ' Land:';
$lang['signup_state_province'] = 'Provincie:';
$lang['signup_zip'] = 'Postcode:';
$lang['signup_city'] = 'Plaats:';
$lang['signup_address1'] = 'Adres, lijn 1:';
$lang['signup_address2'] = 'Adres, lijn 2:';
$lang['signup_height'] = 'Lengte: ';
$lang['signup_feet'] = 'voet';
$lang['signup_meter_inches'] = 'meter';
$lang['signup_weight'] = 'Gewicht:';
$lang['signup_pounds'] = 'kg';
$lang['signup_where_should_we_look'] = 'Waar zullen we zoeken?';
$lang['signup_view_online'] = "Andere leden mogen zien dat ik online ben?";

$lang['signup_gender_values'] = array(
	'M' => 'Man',
	'F' => 'Vrouw',
	'C' => 'Koppel',
	'G' => 'Groep'
	);

$lang['signup_gender_look'] = array(
	'M' => 'Man',
	'F' => 'Vrouw',
	'C' => 'Koppel',
	'G' => 'Groep',
	'B' => 'Man of vrouw',
	'A' => 'Alle'
	);

$lang['seeking'] = 'Zoek een';
$lang['looking_for_a'] = 'Zoekt naar een';
$lang['looking_for'] = 'Zoekt';

$lang['of'] = ' van ';
$lang['to'] = ' tot ';
$lang['from'] = ' van ';
$lang['for'] = ' voor ';
$lang['yes'] = 'Ja';
$lang['no'] = 'Nee';
$lang['cancel'] = 'Annuleren';

$lang['change'] = 'Pas aan';
$lang['reset'] = 'Reset';

//Commonly used words

$lang['required_info_indication'] = 'betekent verplichte informatie';
$lang['required_info_indicator'] = '* ';
$lang['required_info_indicator_color'] = 'rood';
$lang['click_here'] = 'Klik hier';

$lang['datetime_dayval']['Sun'] = 'Zo';
$lang['datetime_dayval']['Mon'] = 'Ma';
$lang['datetime_dayval']['Tue'] = 'Di';
$lang['datetime_dayval']['Wed'] = 'Wo';
$lang['datetime_dayval']['Thu'] = 'Do';
$lang['datetime_dayval']['Fri'] = 'Vr';
$lang['datetime_dayval']['Sat'] = 'Za';


$lang['error_msg_color'] = 'rood';
$lang['success_message'] = "De informatie die je ingevoerd hebt, is opgeslagen.<br>Je wordt binnen 5 seconden automatisch doorverbonden naar het volgende onderdeel. In het geval dat dit automatisch doorverbinden niet werkt, kan je de link hieronder gebruiken.";
$lang['sendletter_success'] = 'Het bericht is succesvol verstuurd.';


/*****************Beheerder Sectie Labels********************/

//Commonly used labels
$lang['admin_login_title'] = 'SITENAME' . ' Beheerderspaneel';
$lang['home_title'] = 'SITENAME' . ' Home';
$lang['admin_login_msg'] = 'Login Beheerder';
$lang['admin_title_msg'] = 'SITENAME' . ' Beheerderpaneel';
$lang['admin_panel'] = 'Beheerderpaneel';
$lang['back'] = 'Terug';
$lang['insert_msg'] = 'Voeg toe ';
$lang['question_mark'] = '?';
$lang['id'] = 'Id:';
$lang['name'] = 'Naam: ';
$lang['name_col'] = 'Naam';
$lang['enabled'] = 'Open:';
$lang['action'] = 'Actie';
$lang['edit'] = 'Wijzig';
$lang['delete'] = 'Verwijder';
$lang['section'] = 'Onderdeel:';
$lang['insert_section'] = 'Voeg onderdeel toe';
$lang['modify_section'] = 'Pas onderdeel aan';
$lang['modify_sections'] = 'Pas onderdelen aan';
$lang['delete_section'] = 'Verwijder onderdeel';
$lang['delete_sections'] = 'Verwijder onderdelen';
$lang['enable_selected'] = 'Open';
$lang['disable_selected'] = 'Sluit';
$lang['change_selected'] = 'Verander';
$lang['delete_selected'] = 'Verwijder';
$lang['no_select_msg'] = "Je hebt geen keuze gemaakt. Klik op terug om je keuze te maken.";
$lang['delete_confirm_msg'] = 'Weet je zeker dat je dit onderdeel wil verwijderen?';
$lang['delete_group_confirm_msg'] = 'Weet je zeker dat je dit onderdeel wil verwijderen? Deze actie kan niet ongedaan gemaakt worden.';
$lang['enabled_values'] = array(
	'Y' => 'Ja',
	'N' => 'Nee'
	);
$lang['display_control_type'] = array(
	'checkbox' => 'Checkbox',
	'radio' => 'Option button',
	'select' => 'Drop down lijst',
	'textarea' => 'Invoerveld'
	);
$lang['admin_error_color'] = 'rood';

$lang['col_head_srno'] = '#';
$lang['col_head_id'] = 'Id';
$lang['col_head_question'] = 'Vraag';
$lang['col_head_enabled'] = 'Open';
$lang['col_head_name'] = 'Naam';
$lang['col_head_username'] = 'Gebruikersnaam';
$lang['col_head_firstname'] = 'Eerste Naam';
$lang['col_head_lastname'] = 'Laatste Naam';
$lang['col_head_fullname'] = 'Volledige Naam';
$lang['col_head_status'] = 'Status';
$lang['col_head_gender'] = 'Geslacht';
$lang['col_head_email'] = 'Email';
$lang['col_head_country'] = 'Land';
$lang['col_head_city'] = 'Stad';
$lang['col_head_zip'] = 'Postcode';
$lang['col_head_register_at'] = 'Geregistreerd op';

$lang['section_title'] = 'Beheeronderdeel';
$lang['total_sections'] = 'Aantal onderdelen:';
$lang['profile_title'] = 'Profielbeheer';
$lang['total_profiles_found'] = 'Aantal profielen gevonden:';
$lang['modify_profile'] = 'Wijzig Profiel';

$lang['profile_signup_title'] = 'Informatie lidmaatschap';
$lang['profile_basic_title'] = 'Basis informatie';
$lang['profile_appearance_title'] = 'Uiterlijk';
$lang['profile_interests_title'] = 'Interesses';
$lang['profile_lifestyle_title'] = 'Levenswijze';

$lang['profile_subtitle_login'] = 'Details login';
$lang['profile_subtitle_profile'] = 'Profiel';
$lang['profile_subtitle_address'] = 'Adres';
$lang['profile_subtitle_appearacnce'] = 'Uiterlijk';
$lang['profile_subtitle_preference'] = 'Voorkeuren';
$lang['profile_delete_confirm_msg'] = 'Bent je zeker dat je dit profiel wil verwijderen?';
$lang['delete_profile'] = 'Verwijder profiel';
$lang['profile_username'] = 'Gebruikersnaam:';
$lang['profile_firstname'] = 'Voornaam:';
$lang['profile_lastname'] = 'Familienaam:';
$lang['profile_email'] = 'Emailadres:';
$lang['profile_gender'] = 'Geslacht:';
$lang['profile_birthday'] = 'Geboortedatum:';
$lang['profile_country'] = 'Land:';
$lang['profile_state_province'] = 'Provincie:';
$lang['profile_zip'] = 'Postcode:';
$lang['profile_city'] = 'Plaats';
$lang['profile_address1'] = 'Adres, regel 1:';
$lang['profile_address2'] = 'Adres, regel 2:';
$lang['find'] = 'Vind';
$lang['search'] = 'Zoek';
$lang['AND'] = 'en';
$lang['OR'] = 'of';
$lang['order_by'] = 'Orden op: ';
$lang['sort_by'] = 'Sorteer op';
$lang['sort_types'] = array(
	'asc' => 'Oplopend',
	'desc' => 'Aflopen'
	);
$lang['search_results'] = 'Zoekresultaten';
$lang['no_record_found'] = 'Geen matchende records gevonden.';
$lang['search_options'] = 'Zoekopties';
$lang['search_simple'] = 'Eenvoudig Zoeken';
$lang['search_advance'] = 'Uitgebreid zoeken';
$lang['search_advance_results'] = 'Uitgebreide zoekresultaten';
$lang['search_country'] = 'Zoek op land';
$lang['search_states'] = 'Zoek op provincie';
$lang['search_zip'] = 'Zoek op postcode';
$lang['search_city'] = 'Zoek op plaats';
$lang['search_wildcard_msg'] = 'Ja kan een * invoeren in het invoerveld om alle records te zoeken.';
$lang['search_location'] = '<b>Zoek op locatie:</b>';
$lang['select_state'] = 'Provincie:';
$lang['enter_city'] = 'Stad:';
$lang['enter_zip'] = 'Postcode:';
$lang['enter_username'] = 'Gebruikersnaam:';
$lang['results_per_page'] = 'Resultaten per Pagina';
$lang['search_results_per_page'] = array( 2 => 2, 5 => 5 , 10 => 10, 20 => 20, 50 => 50, 100 => 100 );
$lang['order'] = 'Sorteer';
$lang['up'] = 'Omhoog';
$lang['down'] = 'Naar beneden';

$lang['question'] = 'Vraag:';

$lang['maxlength'] = 'Maximum lengte:';
$lang['description'] = 'Omschrijving:';
$lang['mandatory'] = 'Verplicht:';
$lang['guideline'] = 'Richtlijn:';
$lang['control_type'] = 'Toon controle:';
$lang['include_extsearch'] = 'Opnemen in uitgebreid zoeken:';
$lang['head_extsearch'] = 'Uitgebreide zoek-header:';

$lang['delete_question'] = 'Verwijder vraag';
$lang['modify_question'] = 'Pas vraag aan';
$lang['questions_title'] = 'Vragen beheer';
$lang['total_options'] = 'Totaal opties:';
$lang['insert_question'] = 'Voeg nieuwe vraag toe';
$lang['total_questions'] = 'Totaal Vragen:';
$lang['delete_questions'] = 'Verwijder vragen';
$lang['delete_group_questions_confirm_msg'] = 'Ben je zeker dat je deze vragen wil verwijderen? Deze actie kan niet ongedaan gemaakt worden';

$lang['option'] = 'Opties';
$lang['answer'] = 'Antwoord';
$lang['options_title'] = 'Vragen Opties';
$lang['col_head_answer'] = 'Antwoord';
$lang['with_selected'] = 'Met geselecteerd';
$lang['ranging'] = 'Bereik';

// Instant messenger
$lang['instant_messenger'] = 'Instant messages';
$lang['instant_message'] = 'Instant message';
$lang['im_from'] = 'Van:';
$lang['im_message'] = 'Bericht:';
$lang['im_reply'] = 'Antwoord';
$lang['close_window'] = 'Sluit venster';

// my matches
$lang['my_matches'] = 'Mijn matches';
$lang['i_am_a'] = 'Ik ben een';
$lang['Between'] = 'tussen';
$lang['who_is_from'] = 'Leeftijd vanaf';
$lang['showing'] = 'Getoond';
$lang['your_search_preferences'] = 'Je huidige zoekvoorkeuren:';
$lang['to_edit_search_preferences'] = 'om je zoekvoorkeuren aan te passen';

$lang['unapproved_user'] = 'Profielen voor goedkeuring';
$lang['gbl_settings'] = 'Globale instellingen voor site';
$lang['configurations'] = 'Configuraties';
$lang['col_head_variable'] = 'Variabele';
$lang['col_head_value'] = 'Waarde';

$lang['affiliate_title'] = 'Partnerbeheer';
$lang['col_head_counter'] = 'Teller';
$lang['col_head_status'] = 'Status';

$lang['tell_later'] = 'Dit laat ik je later weten';
$lang['view_profile'] = 'Bekijk Profiel';
$lang['view_profile_errmsg1']  = 'Je hebt nog geen voorkeuren opgegegeven<br />Gelieve eerst je profiel van details te voorzien.<br />';
$lang['view_profile_errmsg2'] = '<br />Klik hier om je voorkeuren aan te geven.';
$lang['view_profile_errmsg3'] = 'De gebruiker heeft nog steeds geen profieldetails opgegeven';
$lang['view_profile_restricted'] = 'Sorry! Afgeschermd profiel. Bekijken is niet toegestaan';
$lang['profile_notset'] = 'Geen profielveld gevonden van de gebruiker.';
$lang['send_mail'] = 'Stuur bericht';
$lang['mail_messages'] = 'Berichten';
$lang['col_head_subject'] = 'Onderwerp';
$lang['col_head_sendtime'] = 'Datum';

$lang['inbox'] = 'Inbox';
$lang['sent'] = 'Verzonden';
$lang['trashcan'] = 'Prullenbak';
$lang['reply'] = 'Antwoord';
$lang['read'] = 'Lees';
$lang['unread'] = 'Ongelezen';
$lang['restore'] = 'Haal terug';
$lang['subject'] = 'Onderwerp';
$lang['subject_colon'] = 'Onderwerp:';
$lang['message'] = 'Bericht';
$lang['send'] = 'Verstuur';

$lang['send_letter'] = 'Verstuur brief';
$lang['image_browser'] = 'Browser afbeeldingen';
$lang['upload_image'] = 'Upload afbeelding';
$lang['delete_image'] = 'Verwijder afbeelding';
$lang['show_image'] = 'Laat afbeelding zien';
$lang['send_invite'] = 'Verstuur uitnodiging';
$lang['letter_title'] = 'Nieuwe brief';
$lang['from_email'] = 'Van Email:';
$lang['from_name'] = 'Van Naam:';
$lang['send_to'] = 'Stuur';
$lang['email_subject'] = 'onderwerp:';
$lang['save_as'] = 'Sla op als';

$lang['no_message'] = 'Geen nieuwe berichten gevonden in je inbox.';
$lang['descrip'] = 'Omschrijving';

//forgot Wachtwoord words
$lang['forgotpass_msg1'] = "Waarschuwing login";
$lang['forgotpass_msg2'] = "Geef het e-mailadres op dat je gebruikt hebt tijdens het aanmaken van je profiel zodat we je loginnaam en wachtwoord naar je kunnen verzenden.";
$lang['retreieve_info'] = 'Verstuur';
$lang['forgotpass'] = 'Wachtwoord vergeten';

//Tell a friend
$lang['tellafriend'] = 'Vertel een vriend(in)';
$lang['taf_msg1'] = 'Nodig een vriend(in) uit naar ' . 'SITENAME';
$lang['taf_yourname'] = 'Je naam:';
$lang['taf_youremail'] = 'Je email:';
$lang['taf_friendemail'] = "Vriend(in)'s email:";

//Auto-mail
$lang['confirm_your_profile'] = 'Bevestig je registratie';
$lang['letter_not_avail'] = 'Template brief niet aanwezig';
$lang['confirm_letter_sent'] = 'Er is een email gestuurd naar het adres dat je tijdens je registratie hebt opgegeven.<br />Reageer op deze mail om het registratieproces af te ronden.';
$lang['letter_not_sent'] = 'Er is een probleem met het verzenden van de mail. Neem contact op met de administrator';
$lang['or'] = 'Of';
$lang['enter_confirm_code'] = 'Vul je bevestigingscode hieronder in om je registratieproces af te ronden.';
// Affiliaat auto-mail

$lang['aff_email_subject'] = 'Bevestig je parnteraccount';
$lang['aff_email_body'] = 'Bedankt om een partneraccount bij ' . 'SITENAME' . 'aan te maken. Gelieve naar deze url te surfen om je account te bevestigen:<br><br>#ConfirmationLink#';

//Page management

$lang['manage_pages'] = 'Paginabeheer';
$lang['pagetitle'] = 'Titel:';
$lang['pagetext'] = 'Tekst:';
$lang['pagekey'] = 'Sleutel:';
$lang['addpage'] = 'Voeg pagina toe';
$lang['page'] = 'Pagina:';
$lang['addnew'] = 'Voeg nieuwe toe';
$lang['modpage'] = 'Bewerk Pagina';
$lang['pagekey_help'] = 'www.uwdomein.com/date/public_html/page.php?key=YOUR_KEY';

$lang['y_o'] = 'j/o';
$lang['lastlogged'] = 'Laatst ingelogd: ';
$lang['aff_stats'] = 'Partnerstatistieken';
$lang['total_referrals'] = 'Totaal verwijzingen';
$lang['regis_referals'] = 'Geregistreerde verwijzingen';
$lang['globalconfigurations'] = 'Algemene configuratie';

$lang['send_message_to'] = 'Bericht verzenden naar';
$lang['writing_message'] = 'Bericht schrijven naar';
$lang['search_at'] = 'Zoek op ';

//Rating module
$lang['rate_profile'] = 'Beoordeel profiel';
$lang['worst'] = 'Slecht';
$lang['excellent'] = 'Uitmuntend';
$lang['rating'] = 'Beoordeling';
$lang['submitrating'] = 'Verstuur beoordeling';

//Betalingsmodules
$lang['mship_changed'] = 'Niveau lidmaatschap is gewijzigd';
$lang['mship_changed_successfull'] = 'Je lidmaatschap is gewijzig naar gratis.';
$lang['no_payment'] = 'Geen betaling nodig (Gratis)';
$lang['payment_modules'] = 'Betalingsmodules';
$lang['payment_methods'] = 'Betalingsmethodes';
$lang['business'] = 'Bedrijf:';
$lang['siteid'] = 'Site Id:';
$lang['undefined_quantity'] = 'Onduidelijk aantal:';
$lang['no_shipping'] = 'Geen verzending:';
$lang['no_note'] = 'Geen Opmerking:';
$lang['on_off_values'] = array( 1 => 'Ja', 0 => 'Nee' );
$lang['edit_payment_modules'] = 'Bewerk betalingsmodule';
$lang['trans_key'] = 'Transactiesleutel:';
$lang['trans_mode'] = 'Transactiemodus:';
$lang['trans_method'] = 'Transactiemethode:';
$lang['username'] = 'Gebruikersnaam:';
$lang['username_without_colon'] = 'Gebruikersnaam';
$lang['country'] = 'Land';
$lang['country_colon'] = 'Land:';
$lang['state'] = 'Provincie';
$lang['city'] = 'Stad';
$lang['location_col'] = 'Locatie:';
$lang['location_no_col'] = 'Locatie';
$lang['zip_code'] = 'Postcode';
$lang['attached_files'] = 'Bijgevoegde bestanden';
$lang['cc_owner'] = 'Eigenaar kredietkaart:';
$lang['cc_number'] = 'Nummer kredietkaart:';
$lang['cc_type'] = 'Type kredietkaart:';
$lang['cc_exp_date'] = 'Vervaldatum kredietkaart:';
$lang['cc_cvv_number'] = 'CVC:';
$lang['cvv_help'] = '(op de achterkant van de kaart)';
$lang['continue'] = 'Verdergaan';
$lang['trans_method_vals'] = array(
	'CC' => 'Kredietkaart',
	'ECHECK' => 'Electronische Cheque'
	);
$lang['trans_mode_vals'] = array(
	'AUTH_CAPTURE' => 'AUTH_CAPTURE',
	'AUTH_ONLY' => 'AUTH_ONLY',
	'CAPTURE_ONLY' => 'CAPTURE_ONLY',
	'CREDIT' => 'CREDIT',
	'VOID' => 'VOID',
	'PRIOR_AUTH_CAPTURE' => 'PRIOR_AUTH_CAPTURE'
);
$lang['cc_unknown'] = 'Bedrijf van deze kredietkaart is onbekend. Probeer opnieuw met een geldige kredietkaart.';
$lang['cc_invalid_date'] = 'Einddatum kredietkaart is onjuist. Probeer opnieuw met een geldige kredietkaart.';
$lang['cc_invalid_number'] = 'Nummer kredietkaart is onjuist. Probeer opnieuw met een geldige kredietkaart.';
$lang['amount'] = 'Aantal:';
$lang['confirmation'] = 'Bevestiging';
$lang['confirm'] = 'Bevestig';
$lang['upgrade_membership'] = 'Status lidmaatschap';
$lang['changeto'] = 'Verander in';
$lang['current_mship_level'] = 'Huidig niveau lidmaatschap:';
$lang['membership_status'] = 'Status lidmaatschap';
$lang['you_currently'] = 'Je bent momenteel een : ';
$lang['info_confirm'] = 'Is volgende informatie correct?';
$lang['change_mship_to'] = 'Verander lidmaatschapsniveau naar ';
//Membership
$lang['permitmsg_1'] = 'Sorry, je lidmaatschapsniveau is niet toereikend';
$lang['permitmsg_2'] = 'Verhoog lidmaatschapsniveau om dit te gebruiken ';
$lang['permitmsg_3'] = 'Lidmaatschapsvergelijking';
$lang['permitmsg_4'] = 'Verberg Lidmaatschapsvergelijking';
$lang['membership_packages'] = 'Pakketten lidmaatschap';
$lang['membership_packages_compare'] = 'Vergelijking pakketten lidmaatschap';
$lang['modify'] = 'Sla wijzigingen op';
$lang['manage_membership'] = 'Beheer lidmaatschap';
$lang['privileges_msg'] = 'Privileges';
$lang['price'] = 'Prijs: ';
$lang['currency'] = 'Munteenheid: ';
$lang['choose_membership'] = 'Kies een lidmaatschapsniveau:';
$lang['add_membership'] = 'Voeg een nieuw lidmaatschap toe';
$lang['membership_types'] = 'Types lidmaatschap';
$lang['member'] = 'Lid';

$lang['select_letter'] = 'Selecteer brief:';
$lang['body'] = 'Inhoud:';
$lang['module'] = 'Module';
$lang['uninstall'] = 'Deïnstalleren';
$lang['install'] = 'Installeren';
$lang['modify_option'] = 'Optie bewerken';

$lang['only_jpg'] = 'Alleen jpg-, gif-, png- of bmp-bestanden zijn toegestaan.';
$lang['upload_unsuccessful'] = 'Afbeelding kan niet worden geupload.';
$lang['upload_successful'] = 'Afbeeldingen zijn geupload.';
$lang['between1'] = 'Tussen';
$lang['and'] = 'en';
$lang['profile_details'] = 'Details profiel';
$lang['personal_details'] = 'Persoonlijke details';


//Banner Beheer
$lang['manage_banners'] = 'Bannerbeheer';
$lang['add_banners'] = 'Voeg banner toe';
$lang['edit_banners'] = 'Wijzig banner';
$lang['size'] = 'Grootte';
$lang['size_px'] = 'Grootte (px)';
$lang['banner_linkurl'] = 'Banner / Link URL';
$lang['banner_sizes'] = array(
	'468X60' => '468 x 60',
	'100X500'=>'100 x 500',
	'120X120'=>'120 x 120'
);
$lang['banner_sizes_name'] = array( 'horizontaal', 'verticaal ', 'vierkant' );
$lang['startdate'] = 'Startdatum:';
$lang['enddate'] = 'Einddatum:';
$lang['tooltip'] = 'Tooltip:';
$lang['linkurl'] = 'Link Url:';
$lang['banner'] = 'Banner:';
$lang['total_banner'] = 'Totaal Banners:';
$lang['online_users'] = 'Leden online: ';
$lang['site_statistics'] = 'Statistieken site';
$lang['pending_profiles'] = 'Wachtende profielen';
$lang['active_profiles'] = 'Actieve profielen';
$lang['online_profiles'] = 'Online profielen';
$lang['pending_aff'] = 'Wachtende partners';
$lang['total_affiliates'] = 'Totaal partners';
$lang['active_aff'] = 'Actieve partners';
$lang['no_rating'] = 'Geen beoordeling';

//SEO Words
$lang['seo'] = 'Instellingen SEO';
$lang['seo_head'] = 'Optimalisatie voor zoekmachine';
$lang['sef_msg'] = 'Zoekmachine-vriendelijke URLs';
$lang['seo_enable'] = 'Activeer URL Rewriting door middel van mod_rewrite:';
$lang['yes_msg'] ='URL rewriting is een feature die enkel beschikbaar is indien men gebruik maakt van de apache web server, met de mod_rewrite extension ingeschakeld. Zorg ervoor dat uw webserver aan deze vereisten voldoet. Denk er ook aan het bestand .htaccess.txt naar .htaccess te hernoemen.';
$lang['keywords'] = 'Sleutelwoorden:';
$lang['page_tags_msg'] = 'Paginatitel & meta tags';
$lang['max_255'] = 'Maximum 255 tekens';

// Nieuws/ Verhaal / Artikel Manangement
$lang['manage_news'] = 'Beheer nieuws';
$lang['manage_story'] = 'Beheer verhalen';
$lang['manage_article'] = 'Beheer artikels';
$lang['news_header'] = 'Header';
$lang['total_news'] = 'Totaal nieuws:';
$lang['total_articles'] = 'Totaal artikels:';
$lang['total_stories'] = 'Totaal verhalen:';
$lang['article_title'] = 'Titel';
$lang['story_sender'] = 'Afzender';
$lang['story_sender_msg'] = 'Profiel Id [nummer]';
$lang['modify_article'] = 'Wijzig artikel';
$lang['modify_news'] = 'Wijzig nieuws';
$lang['modify_story'] = 'Wijzig verhaal';
$lang['insert_article'] = 'Voeg artikel toe';
$lang['insert_story'] = 'Voeg verhaal toe';
$lang['insert_news'] = 'Voeg nieuws toe';
$lang['dat'] = 'Datum:';

//Poll Words
$lang['manage_polls'] = 'Beheer poll';
$lang['modify_poll'] = 'Wijzig poll';
$lang['total_polls'] = 'Totaal polls';
$lang['poll'] = 'Poll';
$lang['add_polls'] = 'Voeg polls toe';
$lang['add_options'] = 'Voeg opties toe';
$lang['active'] = 'Actief';
$lang['activate'] = 'Activeer';
$lang['option'] = 'Optie';
$lang['modify_options'] = 'Wijzig opties';
$lang['add_option_now'] = 'Voeg nu optie toe.';
$lang['poll_options'] = 'Opties poll';
$lang['votes'] = 'Stem(men)';

//Filter Records
$lang['filter_options'] = array(
	'id' => 'Id',
	'username' => 'Gebruikersnaam',
	'city' => 'Stad',
	'zip' => 'Postcode',
	'status' => 'Status',
	'email'	=> 'E-mail',
	'gender' => 'Geslacht'
	);
$lang['loginagain'] = 'Log uit en log opnieuw in om je nieuwe lidmaatschap-status te gebruiken';
$lang['online_users_txt'] = 'Leden online';
$lang['first'] = 'Eerste';
$lang['last'] = 'Laatste';
$lang['filter_records'] = 'Filter records';
$lang['search_at'] = 'Zoek op';
$lang['criteria'] = 'Criteria';

//Beheerder Beheer
$lang['manage_admins'] = 'Beheer admins';
$lang['total_admins'] = 'Totaal admins';
$lang['add_admin'] = 'Voeg admin toe';
$lang['modify_admin'] = 'Wijzig admin';
$lang['fullname'] = 'Volledige naam';
$lang['please_be_sure'] = 'Let op:';
$lang['change_your_admin_pwd'] = 'Verander je admin-wachtwoord.';
$lang['superuser'] = 'Supergebruiker';
$lang['no_admin_user_msg1'] = 'Er zijn geen niet-supergebruiker admins. Gelieve er eerst een aan te maken.';
$lang['no_admin_user_msg2'] = 'Om nu een nieuwe beheerder aan te maken';
$lang['access_denied'] = 'Toegang gewijgerd';
$lang['not_authorize'] = 'Je hebt geen toegang tot deze pagina. Gelieve je superbeheerder te contacteren.';

//Beheerder Rechten Beheer
$lang['admin_permissions'] = 'Beheer Rechten';
$lang['manage_admin_permissions'] = 'Rechten administrators beheer';
$lang['admin_users'] = 'Beheer gebruikers';
$lang['permissions'] = 'Modules';
$lang['superuser_noteditable'] = 'Opmerking: supergebruiker(s) is(zijn) niet aanpasbaar.';
$lang['all'] = 'Alle';
$lang['selected'] = 'Geselecteerd';
$lang['selected_users'] = 'Geselecteerde gebruikers';
$lang['separate_users_by_coma'] = 'Geef gebruikersnamen in, gescheiden door kommas';
$lang['admin_rights'] = array(
		'site_stats' 				=> 'Statistieken site',
		'profie_approval'		 	=> 'Profielen voor goedkeuring',
		'profile_mgt' 				=> 'Profielbeheer',
		'section_mgt' 				=> 'Onderdelenbeheer',
		'affiliate_mgt' 			=> 'Partnerbeheer',
		'affiliate_stats'		 	=> 'Partnerstatistieken',
		'news_mgt' 					=> 'Nieuwsbeheer',
		'article_mgt' 				=> 'Artikelbeheer',
		'story_mgt'					=> 'Verhalenbeheer',
		'poll_mgt'		 			=> 'Pollbeheer',
		'search' 					=> 'Zoek',
		'ext_search'				=> 'Uitgebreid zoeken',
		'send_letter' 				=> 'Stuur bericht',
		'pages_mgt' 				=> 'Pagina-beheer',
		'chat' 						=> 'Chat',
		'chat_mgt' 					=> 'Chatbeheer',
		'forum_mgt' 				=> 'Forumbeheer',
		'mship_mgt' 				=> 'Ledenbeheer',
		'payment_mgt' 				=> 'Betalingsmodules',
		'banner_mgt' 				=> 'Bannerbeheer',
		'seo_mgt' 					=> 'Instellingen SEO',
		'admin_mgt' 				=> 'Beheer admins',
		'admin_permit_mgt'			=> 'Beheerd rechten',
		'global_mgt' 				=> 'Globale instellingen site',
		'change_pwd'				=> 'Wijzig wachtwoord',
		'cntry_mgt'					=> 'Beheer landen/steden',
		'snaps_require_approval'	=> 'Keur foto\'s goed',
		'featured_profiles_mgt'		=> 'Featured profielen',
		'calendar_mgt'				=> 'Kalenders',
		'event_mgt'					=> 'Keur afspraken goed',
		'import_mgt'				=> 'Importeer',
	/* Added in 2.0 */
      	'plugin_mgt'            	=> 'Pluginbeheer',
		'blog_mgt'					=> 'Blogbeheer',
		'profile_ratings'			=> 'Beheer Beoordelingen Profielen',
		);

$lang['cntry_mgt']	= 'Beheer Landen/ Steden';
$lang['register_now'] = 'Nog geen lid? Registreren kan hier.';
$lang['addtobuddylist'] = 'Voeg toe aan vriendenlijst';
$lang['addtobanlist'] = 'Voeg toe aan lijst met geblokkeerden';
$lang['addtohotlist'] = 'Voeg toe aan favorietenlijst';
$lang['buddylisthdr'] = 'Vriendenlijst';
$lang['banlisthdr'] = 'Lijst met geblokkeerden';
$lang['hotlisthdr'] = 'Favorietenlijst';
$lang['username_hdr'] = 'Gebruikersnaam';
$lang['fullname_hdr'] = 'Volledige naam';
$lang['register'] = 'Registreren';
$lang['featured_profiles'] = 'Featured profielen';
$lang['bigger_pic_size'] = 'Fotogrootte is meer dan de toegestane '.$config['upload_snap_maxsize'].' KB.';
$lang['snaps_require_approval'] = 'Keur foto\'s Goed';
$lang['events_require_approval'] = 'Keur afspraken goed';
$lang['upload_picture_caption'] = ' Hoofdfoto ';
$lang['upload_thumbnail_caption'] = 'Thumbnail ';
$lang['Approve'] = 'Keur goed';
$lang['Remove'] = 'Verwijder';
$lang['userdetails'] = 'Gebruikersinformatie';
$lang['pict'] = 'Foto';
$lang['tnail'] = 'Thumbnail';
$lang['reqact'] = 'Gewenste actie';
$lang['newmemberlist'] = 'Nieuwste leden';
$lang['yearsold'] = 'jaar oud';
$lang['Male'] = 'Man';
$lang['Female'] = 'Vrouw';
$lang['showfulllist'] = 'Toon volledige lijst';
$lang['featuredprofiles'] = 'Featured profielen';
$lang['featured_profiles_hdr'] = 'Profielen van featured leden';
$lang['nonfeatured_profiles_hdr'] = 'Normale leden';
$lang['level_hdr'] = 'Niveau';
$lang['date_from'] = 'Startdatum';
$lang['date_upto'] = 'Datum Tot';
$lang['must_show'] = 'Moet getoond worden';
$lang['reqd_exposures'] = 'Aantal keer tonen';
$lang['total_exposures'] = 'Totaal exposures';
$lang['add_featured'] = 'Voeg profiel toe aan lijst met featured profielen';
$lang['mod_featured'] = 'Wijzig profiel in lijst met featured profielen';
$lang['member_since'] = 'Lid sinds';
$lang['invalid_username'] = 'Ongeldige gebruikersnaam';
$lang['weekcnt'] = 'Leden sinds vorige week:';
$lang['totalgents'] = 'Totaal mannelijke leden:';
$lang['totalfemales'] = 'Totaal vrouwelijke leden:';
$lang['weeksnaps'] = 'Foto\'s sinds vorige week:';
$lang['since_last_login'] = 'Sinds laatste login';
$lang['sincelastlogin_hdr'] ='Sinds laatste login';
$lang['newmessages'] = 'Nieuwe berichten ontvangen:';
$lang['profileviewed'] = 'Aantal keer dat je profiel bekeken werd:';
$lang['winks_received'] = 'Aantal knipogen ontvangen:';
$lang['send_wink'] = 'Verstuur een knipoog';
$lang['listofviews'] = 'Lijst van leden die je profiel bekeken hebben';
$lang['listofwinks'] = 'Lijst van leden die knipogen naar jou verzonden hebben';
$lang['winkslist'] = 'Lijst met knipogen';
$lang['viewslist'] = 'Lijst bekeken door';
$lang['suggest_poll'] = 'Stel een poll voor';
$lang['savepoll'] = 'Voeg poll toe';
$lang['moreoptions'] = 'Meer opties';
$lang['minimum_options'] = 'Minimaal 2 opties nodig';
$lang['pollsuggested'] = 'Bedankt! Je suggestie voor een poll is verzonden naar een site-administrator.';
$lang['suggested_by'] = 'Gesuggereerd door:';
$lang['any_where'] = 'Overal';
$lang['memberpanel'] = "Startpagina lid";
$lang['feedback_thanks'] = 'Bedankt voor je feedback. Je bericht is verzonden naar een site-administrator.';
$lang['cancel_hdr'] = 'Annuleer lidmaatschap';
$lang['cancel_txt01'] = 'Ben je zeker dat je je lidmaatschap bij <b>'.'SITENAME'.'</b>.<br /><br />wil stopzetten? ';
$lang['cancel_opt01'] = 'Ja, ik ben zeker';
$lang['cancel_opt02'] = 'Nee, ik wil mijn lidmaatschap niet stopzetten';
$lang['cancel_domsg'] = 'Wij danken je voor het gebruik van '.'SITENAME'.'. <br /><br /> We vinden het jammer dat je ons verlaat, maar we zullen je graag weer welkom heten, en hopen dat deze site je toch behulpzaam heeft kunnen zijn.';
$lang['cancel_nomsg'] = 'Wij danken je voor het gebruik van '.'SITENAME'.'. <br /><br /> We zijn blij dat je nog niet opzegd, en hopen dat je nog veel van onze diensten gebruik zult maken.';
$lang['reject'] = 'Afwijzen';
$lang['unread'] = 'Ongelezen';
$lang['membership_hdr'] = 'Lidmaatschapsniveau';
$lang['edit_pict'] = 'Wijzig  hoofdfoto';
$lang['edit_thmpnail'] = 'Wijzig thumbnail';
$lang['letter_options'] = 'Berichtopties';
$lang['pic_gallery'] = 'Foto\'s';
$lang['reactivate'] = 'Heractiveer gebruiker';
$lang['cancel_list'] = 'Lijst geannuleerde leden';
$lang['cancel_date'] = 'Datum van annulering';
$lang['language_opt'] = 'Taaloptie' ;
$lang['change_language'] = 'Wijzig taal';
$lang['with_photo'] = 'die een foto heeft';
$lang['logintime'] = 'Login tijd';
$lang['manage_country_states'] = 'Beheer landen/provincies';
$lang['manage_countries'] = 'Beheer landen';
$lang['countries_count'] = 'Aantal landen';
$lang['insert_country'] = 'Voeg niew land toe';
$lang['modify_country'] = 'Wijzig land';
$lang['country_code'] = 'Code land';
$lang['country_name'] = 'Naam land';
$lang['manage_states'] = 'Beheer provincies';
$lang['states_count'] = 'Aantal provincies';
$lang['insert_state'] = 'Voeg nieuwe provincie toe';
$lang['modify_state'] = 'Wijzig provincie';
$lang['state_code'] = 'Code provincie';
$lang['state_name'] = 'Naam provincie';
$lang['totalcouples'] = 'Totaal koppels Llden:';
$lang['active_days'] = 'Geldig voor hoeveel dagen?';
$lang['activedays_array'] = array('1'=>'1','7'=>'7','30'=>'30','90'=>'90','180'=>'180','365'=>'365', '999'=>'999');
$lang['expired'] = 'Je lidmaatschap is verlopen. <a href="payment.php" class="errors">Hernieuw je lidmaatschap</a> en blijf recht hebben op de voordelen van '. 'SITENAME';
$lang['compose'] = 'Opstellen';

$lang['logout_login']='Gelieve eerst in en uit te loggen om je nieuwe wachtwoord te testen';
$lang['makefeatured'] = 'Klik hier om dit profiel aan de featured profielenlijst toe te voegen';
$lang['col_head_gender_short'] = 'Ge';
$lang['no_subject'] = 'Geen onderwerp';
$lang['admin_col_head_fullname'] = $lang['col_head_fullname'];
$lang['select_from_list'] = '--Selecteer--';

$lang['default_tz'] = '0.00';

$lang['manage_counties'] = 'Provincie';
$lang['counties_count'] = 'Aantal  provincies';
$lang['insert_county'] = 'Voeg nieuwe provincie toe';
$lang['modify_county'] = 'Wijzig provincie';
$lang['county_code'] = 'Code provincie';
$lang['county_name'] = 'Naam provincie';
$lang['manage_cities'] = 'Steden';
$lang['cities_count'] = ' Aantal steden';
$lang['insert_city'] = 'Voeg nieuwe stad toe';
$lang['modify_city'] = 'Wijzig stad';
$lang['city_code'] = 'Code stad';
$lang['city_name'] = 'Naam stad';
$lang['manage_zips'] = 'Postcodes';
$lang['zips_count'] = 'Aantal postcodes';
$lang['insert_zip'] = 'Voeg nieuwe postcode toe';
$lang['modify_zip'] = 'Wijzig postcode';
$lang['zip_code'] = 'Postcode';
$lang['show_form'] = 'Toon formulier:';
$lang['change_album'] = 'Aanpassen';


/* Following array is for Profiel Window display heading conversion */
$lang['extsearchhead'] = array(
	'Marital Status'		=> 'Huwelijksstatus',
	'Ethnicity'				=> 'Etniciteit',
	'Religion'				=> 'Religie',
	'Hobbies'				=> 'Hobby\'s',
	'Height'				=> 'Lengte',
	'Body Type'				=> 'Lichaamstype',
	'Zodiac Sign'			=> 'Sterrenbeeld',
	'Eye color'				=> 'Kleur ogen',
	'Hair color'			=> 'Kleur haar',
	'Body art'				=> 'Lichaamsversieringen',
	'Best feature'			=> 'Beste kenmerk',
	'Hot spots'				=> 'Hot spots',
	'Sports'				=> 'Sporten',
	'Favorite things'  		=> 'Favoriete dingen',
	'Last reading'			=> 'Laatst gelezen',
	'Common interests'		=> 'Interesses',
	'Sense of humor'		=> 'Gevoel voor humor',
	'Exercise'				=> 'Trainen',
	'Daily diet'			=> 'Dagelijks dieet',
	'Smoking'				=> 'Roken',
	'Drinking'				=> 'Drinken',
	'Job schedule'			=> 'Werkschema',
	'Current annual income' => 'Huidig jaarlijks inkomen',
	'Living situation'		=> 'Levensomstandigheden',
	'Kids'					=> 'Kinderen',
	'Want children'			=> 'Wil kinderen',
	'Weight'				=> 'Gewicht',
	'Employment status'		=> 'Werkstatus',
	'Education'				=> 'Educatie',
	'Languages'				=> 'Talen',
	'Referred by'			=> 'Doorgestuurd door',
);

/* user_stats */

$lang['your_user_stats'] = 'Je gebruikersstats';
$lang['other_user_stats'] = 'Gebruikersstats van anderen';

$lang['user_stats'] = 'Gebruikersstats';
$lang['users_match_your_search'] = 'Gebruikers die aan je criteria voldoen';
$lang['in_your_country'] = 'Gebruikers die in jouw land wonen';
$lang['in_your_state'] = 'Gebruikers die in jouw provincie wonen';
$lang['in_your_county'] = 'Gebruikers die in jouw provincie wonen';
$lang['in_your_city'] = 'Gebruikers die in jouw stad wonen';
$lang['in_your_zip'] = 'Gebruikers die in jouw postcode wonen';
$lang['in_same_gender'] = 'Gebruikers die jouw geslacht hebben';
$lang['in_same_age'] = 'Gebruikers die jouw leeftijd hebben';
$lang['above_lookagestart'] = 'Gebruikers die ouder zijn dan mijn minimum leeftijdslimiet';
$lang['below_lookageend'] = 'Gebruikers die jonger zijn dan mijn maximum leeftijdslimiet';
$lang['your_lookgender'] = 'Gebruikers die voldoen aan jouw geslachtsvoorkeur';
$lang['in_look_country'] = 'Gebruikers die in het door jou gezochte land wonen';
$lang['in_look_state'] = 'Gebruikers die in de door jou gezochte provincie wonen';
$lang['in_look_county'] = 'Gebruikers die in de door jou gezochte provincie wonen';
$lang['in_look_city'] = 'Gebruikers die in de door jou gezochte stad wonen';
$lang['in_look_zip'] = 'Gebruikers die in jouw postcode';
$lang['in_same_timezone'] = 'Gebruikers die in jouw tijdszone wonen';
$lang['album_hdr'] = 'Album';
$lang['public'] = 'Publiek';
$lang['calendar_admin'] = 'Kalenderbeheerder';

$lang['mysettings'] = 'Mijn instellingen';
$lang['user_lists'] = 'Folders';
$lang['login_settings'] = 'Login instellingen';
$lang['no_pics'] = 'Geen foto\'s';
$lang['my_page'] = 'Mijn pagina';
$lang['write_new_msg'] = 'Schrijf een nieuw bericht';
$lang['view_winkslist'] = 'Bekijk knipogen';

// Importeermodule
$lang['manage_import'] = 'Importeer';
$lang['manage_import_datingpro'] = 'Importeer vanuit DatingPro';
$lang['manage_import_aedating'] = 'Importeer vanuit aeDating';
$lang['manage_import_section'] = 'Selecteer importeermodule';
$lang['manage_import_select'] = 'Selecteer de te importeren items';
$lang['module'] = 'Module';
$lang['imported'] = 'Geimporteerd';
$lang['import'] = 'Importeer';
$lang['empty'] = 'Leeg';
$lang['select_section'] = 'Selecteer vragenonderdeel';
$lang['import_db_configuration'] = 'Stel de databank configuratie van de bron in';
$lang['db_name'] = 'DB naam:';
$lang['db_host'] = 'DB host:';
$lang['db_user'] = 'DB gebruiker:';
$lang['db_pass'] = 'DB passwoord:';
$lang['db_prefix'] = 'Prefix tabellen:';


// Calendar
$lang['calendar_title'] = 'Kalenderbeheer';
$lang['total_calendars'] = 'Totaal kalenders:';
$lang['modify_calendar'] = 'Wijzig kalender';
$lang['modify_calendars'] = 'Wijzig kalenders';
$lang['delete_calendar'] = 'Delete kalender';
$lang['delete_calendars'] = 'Delete kalenders';

// Kalender Gebeurtenissen
$lang['events_title'] = 'Evenementenbeheer';
$lang['insert_event'] = 'Voeg evenement toe';
$lang['modify_event'] = 'Wijzig evenement';
$lang['total_events'] = 'geselecteerde ';
$lang['event'] = 'evenement:';
$lang['calendar_field'] = 'Kalender:';
$lang['private_to'] = 'Priv&#233\; van:';
$lang['date_from'] = 'Datum van:';
$lang['date_to'] = 'Datum tot:';
$lang['col_head_calendar'] = 'Kalender';
$lang['col_head_username'] = 'Gebruiker';
$lang['col_head_fullname'] = 'Volledige naam';
$lang['col_head_event'] = 'Evenement';
$lang['col_head_datefrom'] = 'Datum van';
$lang['col_head_dateto'] = 'Datum tot';
$lang['col_head_date'] = 'Datum';
$lang['col_head_description'] = 'Omschrijving';

$lang['calendar_title'] = 'Kalender';
$lang['calendar'] = 'Kalender:';
$lang['event_title'] = 'Evenement';
$lang['add_event'] = 'Voeg evenement toe';
$lang['delete_calendar_group_confirm_msg'] = 'Ben je zeker dat je deze kalenders wil verwijderen? Deze actie kan niet ongedaan gemaakt worden.';
$lang['private_only'] = 'Enkel priv&#233\;';
$lang['public_only'] = 'Enkel publiek';
$lang['public_private'] = 'Publiek en priv&#233\;';
$lang['total_events_found'] = 'Totaal evenementen gevonden:';
$lang['start_date'] = 'Startdatum';
$lang['start_time'] = 'Starttijd';
$lang['end_date'] = 'Einddatum';
$lang['end_time'] = 'Eindtijd';
$lang['event_description'] = 'Omschrijving evenement';

$lang['more_events'] = 'Meer evenementen >>';
$lang['daily_events_list'] = "Lijst van evenementen op ";
$lang['add_to_private'] = "Voeg toe aan priv&#233\;-lijst";
$lang['close_window'] = "Sluit venster";
$lang['main_window_closed'] = "Sorry, je hebt het hoofdvenster gesloten.";
$lang['user_added1'] = "Gebruiker";
$lang['user_added2'] = "Toegevoegd aan priv&#233\;-lijst";
$lang['next_month'] = 'Volgende maand';
$lang['previous_month'] = 'Vorige maand';
$lang['next_week'] = 'Volgende week';
$lang['previous_week'] = 'Vorige week';
$lang['next_day'] = 'Volgende dag';
$lang['previous_day'] = ' Vorige dag';
$lang['view_day'] = 'Dag-overzicht';
$lang['view_week'] = 'Weekoverzicht';
$lang['view_month'] = 'Maandoverzicht';

$lang['watched_events'] = 'Evenementen die jij in het oog houdt';
$lang['event_notification'] = 'Melding evenementen';

$lang['jump_to'] = 'Ga naar';
$lang['ok'] = 'Ok';

$lang['recurring'] = "Terugkerend:";
$lang['recur_every'] = "elke";

$lang['recuring_labels'] = array(
	'0' => 'nooit',
	'1' => 'dagen',
	'2' => 'weken',
	'3' => 'maanden',
	'4' => 'jaren'
	);

$lang['calendat_filter_dates_range'] = "Geselecteerde tijdsspanne";
$lang['calendat_filter_last_year'] = "Vorig jaar";
$lang['calendat_filter_last_month'] = "Vorige maand";
$lang['calendat_filter_last_week'] = "Vorige week";
$lang['calendat_filter_yesterday'] = "Gisteren";


$lang['cannot_determine_membership'] = 'Je lidmaatschapsniveau kon niet worden vastgesteld';
$lang['no_previous_polls'] = 'Er zijn geen vorige polls.';
$lang['no_event_for_the_day'] = "Er zijn geen evenementen voor deze datum";
$lang['maxsize'] = 'Maximum toegestane grootte (KB)';
$lang['views'] = 'Bekeken';

/******************************************/
/* ALL ERROR MESSAGES ARE DEFINED BELOW.  */
/******************************************/

//Affiliaten error
$lang['affiliates_error'] = array(
	18 =>'Paswoorden komen niet overeen',
	20 =>'Benodigde informtie moet ingevuld worden.',
	21 =>'Benodigde informtie moet ingevuld worden.',
	25 =>'Het opgegeven emailadres is reeds geregistreerd.'
);


// Javascript error messages
$lang['admin_js_error_msgs'] = array(
	'',
	'Gelieve eerst een checkbox te selecteren.',
	'Ben je zeker dat je wil verdergaan met deze verwijdering?',
	'Ben je zeker dat je deze banner wil verwijderen?'
	);

$lang['admin_js__delete_error_msgs'] = array('',
	1=> 'Weet je zeker dat je dit onderdeel wil verwijderen?\nDeze actie kan niet ongedaan gemaakt worden.',
	2=> 'Weet je zeker dat je deze vraag uit dit onderdeel wil verwijderen?\nDeze actie kan niet ongedaan gemaakt worden.',
	3=> 'Weet je zeker dat je deze vraagoptie wil verwijderen?\nDeze actie kan niet ongedaan gemaakt worden.',
	4=> 'Weet je zeker dat je het profiel wil verwijderen?\nDeze actie kan niet ongedaan gemaakt worden.',
	5=> 'Weet je zeker dat je dit nieuwsbericht wil verwijderen?\nDeze actie kan niet ongedaan gemaakt worden.',
	6=> 'Weet je zeker dat je dit verhaal wil verwijderen?\nDeze actie kan niet ongedaan gemaakt worden.',
	7=> 'Weet je zeker dat je dit artikel wil verwijderen?\nDeze actie kan niet ongedaan gemaakt worden.',
	8=> 'Weet je zeker dat je deze poll wil verwijderen?\nDeze actie kan niet ongedaan gemaakt worden.',
	9=> 'Weet je zeker dat je deze poll optie wil verwijderen?\nDeze  actie kan niet ongedaan gemaakt worden.',
	10=> 'Weet je zeker dat je deze banner wil verwijderen?\nDeze actie kan niet ongedaan gemaakt worden.',
	11=> 'Weet je zeker dat je deze admin wil verwijderen?\nDeze actie kan niet ongedaan gemaakt worden.',
/* Added in RC6 */
	12=> 'Weet je zeker dat je dit land wil verwijderen?',
	13=> 'Weet je zeker dat je deze provincie wil verwijderen',
	14=> 'Weet je zeker dat je deze landen wilt verwijderen?',
	15=> 'Weet je zeker dat je deze provincies wil verwijderen?',
	16=> 'Het veld uitgebreid zoeken moet ingevuld worden als je uitgebreid wil zoeken.',
	17 => 'Gebruikersnamen moeten ingevoerd worden als gebruikersnaam reeks is geselecteerd.',
	18 => 'Weet je zeker dat u deze profielen wilt verwijderen?\nDeze actie kan niet ongedaan gemaakt worden.',
/* Added Release 1.0 */
	19=>'Ben je zeker dat je dit land wil verwijderen?',
	20=>'Ben je zeker dat je deze landen wil verwijderen?',
	21=>'Ben je zeker dat je deze stad wil verwijderen?',
	22=>'Ben je zeker dat je deze steden wil verwijderen?',
	23=>'Ben je zeker dat je deze postcode wil verwijderen?',
	24=>'Ben je zeker dat je deze postcodes wil verwijderen?',

	25 => 'Ben je zeker dat je dit evenement wil verwijderen?',
	26 => 'Ben je zeker dat je deze kalender wil verwijderen?',
	27 => 'Ben je zeker dat je deze pagina wil verwijderen?',
	);


// Don't use double qoutes(") in the item's text
$lang['signup_js_errors'] = array(
	'username_noblank' => 'Voer gebruikersnaam in.' ,
	'password_noblank' => 'Voer wachtwoord in.',
	'old_password_noblank' => 'Oud wachtwoord moet ingevoerd worden.',
	'new_password_noblank' => 'Nieuw wachtwoord moet ingevoerd worden.',
	'con_password_noblank' => 'Bevestig wachtwoord moet ingevuld worden.',
	'firstname_noblank' => 'Voornaam moet ingevuld worden.',
	'name_noblank' => 'Voer uw naam in.',
	'lastname_noblank' => 'Familienaam moet ingevoerd worden.',
	'email_noblank' => 'Emailadres moet ingevoerd worden.',
	'city_noblank' => 'Plaatsnaam moet ingevoerd worden.',
	'zip_noblank' => 'Postcode moet ingevoerd worden.',
	'address1_noblank' => 'Er moet minimaal 1 adres opgegeven worden.',
	'sectionname_noblank' => 'Geef naam opvoor dit onderdeel.',
	'sendname_noblank' => 'Voer afzender in!',
	'calendarname_noblank' => 'Gelieve een naam voor deze kalender in te voeren.',
	'comments_noblank' => 'Gelieve de commentaren in te voeren die je wil verzenden.',
	'question_noblank' => 'Gelieve een vraag in te voeren.',
	'extsearchhead_noblank' => 'Gelieve de hoofding voor uitgebreid zoeken in te vullen.',
	'username_charset' => 'Enkel letters, nummers en underscores \'_\' zijn toegestaan in de gebruikersnaam.',
	'password_charset' => 'Enkel letters, nummers en underscores \'_\' zijn toegestaan in het wachtwoord.',
	'firstname_charset' => 'Enkel letters zijn toegestaan in de voornaam.',
	'lastname_charset' => 'Enkel letters zijn toegestaan in de familienaam.',
	'city_charset' => 'Stadsnaam moet alfabetisch zijn',
	'zip_charset' => 'Alleen cijfers zijn toegestaan in de postcode.',
	'address_charset' => 'Voer een geldig adres in aub.',
	'sectionname_charset' => 'Alleen letters zijn toegestaan voor de naam van het onderdeel.',
	'calendarname_charset' => 'Alleen letters zijn toegestaan voor de kalendernaam.',
	'sendname_charset' => 'Alleen letters zijn toegestaan voor afzender.',
	'name_charset' => 'Gelieve letters te gebruiken voor de naamvelden.',
	'maxlength_charset' => 'Voer een getal in voor max. lengte.',
	'email_notvalid' => 'Emailaddres is niet geldig.',
	'password_nomatch' => 'Wachtwoorden zijn niet identiek.',
	'password_outrange' => 'Paswoordlengte moet binnen de gestelde grens liggen.',
	'username_outrange' => 'Gebruikersnaam moet binnen de gestelde grens liggen.',
	'username_start_alpha' => 'Gebruikersnaam moet met een letter beginnen.',
	'ccowner_noblank' => 'Eigenaar moet vermeld worden.',
	'ccnumber_noblank' => 'Nummer kredietkaart moet vermeld worden.',
	'cvvnumber_noblank' => 'CVC moet vermeld worden.',
	'select_payment' => 'Kies eerst een betalingsmethode.',
	'stateprovince_noblank' => 'Provincienaam moet beschikbaar zijn.',
	'subject_noblank'	=> 'Onderwerp van het bericht moet ingevuld worden!',
	'county_noblank' => 'Provincie moet ingevuld zijn.',
	'county_charset' => 'Provincie moet alfabetisch zijn.',
	'timezone_noblank' => 'Tijdszone moet geselecteerd worden.',
/* Added in 2.0 */
	'ratingname_noblank' => 'Beoordeling moet ingevuld zijn',
	'ratingname_charset' => 'Ongeldige tekens in naam van rating.',
	'about_me_noblank' 	=>  'Je moet informatie over jezelf opgeven.',
	);

$lang['letter_errormsgs'] = array(
		0 => 'Je wachtwoord werd verzonden. Controleer je email account.',
		1 => 'Voer je emailadres in dat je opgaf bij je registratie.',
		2 => 'Pagina wachtwoord vergeten niet gevonden. Neem contact op met de beheerder.',
		4 => 'Er schijnt een probleem te zijn met het versturen van de email. Neem contact op met de beheerder.',
		5 => 'Je bent geen geregistreerd lid van ' . 'SITENAME' . '.<br/>Voer je emailadres in dat je opgaf bij je registratie.'
	);

$lang['taf_errormsgs'] = array(
		0 => 'De uitnodiging werd verstuurd.',
		'sendername_noblank' => 'Gelieve je naam in te voeren.',
		'senderemail_noblank' => 'Gelieve je emailadres in te voeren.',
		'recipientemail_noblank' => 'Gelieve het emailadres van de ontvanger in te voeren.',
		'sendername_charset' => 'Je naam mag enkel uit letters bestaan.',
		'senderemail_charset' => 'Gelieve een correct emailadres in te voeren.',
		'recipientemail_charset' => 'Gelieve een geldig emailadres bij de ontvanger in te voeren.',
		2 => 'Vertel een vriend template niet gevonden. Gelieve een beheerder te contacteren.',
		3 => 'Er was een probleem met het verzenden van de uitnodiging. Gelieve contact op te nemen met een beheerder.',
	);
$lang['pages_errormsgs'] = array( '',
	1 => 'Geen paginatitel.',
	2 => 'Geen paginasleutel.',
	3 => 'Geen paginatekst.',
	4 => 'Paginasleutel bestaat reeds, gelieve een andere te kiezen.',
	5 => 'Pagina is verwijderd.',
	);

$lang['artile_error'] = array(
	1 => 'Artikeltitel is een verplicht veld.',
	2 => 'Artikeltekst is een verplicht veld.',
	3 => 'Artikeldatum is een verplicht veld.'
);
$lang['story_error'] = array(
	1 => 'Verhaaltitel is een verplicht veld.',
	2 => 'Verhaaltekst is een verplicht veld.',
	3 => 'Verhaaldatum is een verplicht veld.',
	4 => 'Verhaalschrijver is een verplicht veld.'
);
$lang['news_error'] = array(
	1 => 'Nieuwstitel is een verplicht veld.',
	2 => 'Nieuwstekst is een verplicht veld.',
	3 => 'Nieuwsdatum is een verplicht veld.'
);

$lang['mship_errors'] = array (
	1=> 'Naam is een verplicht veld.',
	2=> 'Prijs is een verplicht veld.',
	3=> 'Valuta is een verplicht veld.',
	4 => 'Geen betalingsmethode is alleen beschikbaar bij wijziging lidmmatschap naar gratis.'
);
$lang['admin_error_msgs'] = array (
	'',
	'Onderdeel is een verplicht veld.',
	'Gelieve alle verplichte velden in te vullen.'
	);
$lang['admin_error'] = array(
	'',
	1 => 'Gebruikersnaam van beheerder kan niet leeg zijn.',
	2 => 'Wachtwoord van beheerder kan niet leeg zijn',
	3 => 'Volledige naam van beheerder kan niet leeg zijn',
	4 => 'Oud wachtwoord van beheerder kan niet leeg zijn',
	5 => 'Nieuw wachtwoord van beheerder kan niet leeg zijn',
	6 => 'Bevestig wachtwoord van beheerder kan niet leeg zijn',
	7 => 'Nieuw wachtwoord en bevestig wachtwoord zijn niet gelijk.',
	8 => 'Het oude wachtwoord dat je ingaf is niet correct. Gelieve opnieuw te proberen',
	9 => 'De gekozen gebruikersnaam is reeds in gebruik. Gelieve een andere te kiezen',
	/* added in 1.1.0 */
	10 => 'Gelieve enkel tekstwaardes te gebruiken in de naam van het onderdeel'
);

$lang['banner_error_msgs'] = array( '',
	1 => 'Banner mag niet leeg zijn.',
	2 => 'Link URL mag niet leeg zijn.',
	3 => 'Tooltip mag niet leeg zijn.',
	4 => 'Alleen .jpg banners zijn toegestaan.',
	5 => 'De grootte van de banner is groter dan te toegestane grootte.'
);
$lang['poll_error'] = array(
	1 => 'Poll mag niet leeg zijn.',
	2 => 'Datum poll mag niet leeg zijn.',
	3 => 'Optie mag niet leeg zijn.',
	'txtpoll_noblank'  => 'Poll is een verplicht veld.',
	'txtpollopt_noblank'  => 'Polloptie is een verplicht veld.'
	);

$lang['datetime_month'] = array(
	1=>'Januari',
	2=>'Februari',
	3=>'Maart',
	4=>'April',
	5=>'Mei',
	6=>'Juni',
	7=>'Juli',
	8=>'Augustus',
	9=>'September',
	10=>'Oktober',
	11=>'November',
	12=>'December'
);
$lang['datetime_day'] = array(
	'sunday' => 'Zondag',
	'monday' => 'Maandag',
	'tuesday' => 'Dinsdag',
	'wednesday' => 'Woensdag',
	'thursday' => 'Donderdag',
	'friday' => 'Vrijdag',
	'saturday' => 'Zaterdag'
);

/* Release 1.0.2   */
$lang['settings_saved'] = 'Instellingen zijn opgeslaan';
$lang['select_image_first'] = 'Gelieve eerst de afbeelding te selecteren';

/* Release 1.1.0 additions */
$lang['day_names'] = array(
	'Sun' => 'Zondag',
	'Mon' => 'Maandag',
	'Tue' => 'Dinsdag',
	'Wed' => 'Woensdag',
	'Thu' => 'Donderdag',
	'Fri' => 'Vrijdag',
	'Sat' => 'Zaterdag'
);
$lang['view_type'] = 'Bekijk type';
$lang['remember_me'] = 'Herinner mij';
$lang['review'] = 'Controle';
$lang['spammers'] = 'Spammers';
$lang['addquestion'] = 'Voeg vraag toe';
$lang['mainstats'] = 'Hoofdstatistieken';
$lang['osdate_version'] = 'osDate versie';
$lang['signonstats'] = 'loginstatistieken';
$lang['usersinpastminute'] = 'Gebruikers vorige minuut';
$lang['usersinpasthour'] = 'Gebruikers vorig uur';
$lang['usersinpastday'] = 'Gebruikers vorige dag';
$lang['usersinpastweek'] = 'Gebruikers vorige week';
$lang['usersinpastmonth'] = 'Gebruikers vorige maand';
$lang['usersinpastyear'] = 'Gebruikers vorig jaar';
$lang['usersinpast2years'] = 'Gebruikers vorige 2 jaar';
$lang['usersinpast5years'] = 'Gebruikers vorige 5 jaar';
$lang['usersinpast10years'] = 'Gebruikers vorige 10 jaar';
$lang['userstats'] = 'Gebruikersstatistieken';
$lang['totalusers'] = 'Totaal gebruikers';
$lang['totalactiveusers'] = 'Totaal actieve gebruikers';
$lang['totalpendingusers'] = 'Totaal wachtende gebruikers';
$lang['totalsuspendedusers'] = 'Totaal uitgestelde gebruikers';
$lang['totalpictureusers'] = 'Totaal gebruikers met foto\'s';
$lang['totalonlineusers'] = 'Gebruikers online';
$lang['visitorstats'] = 'Bezoekersstatistieken';
$lang['sitestats'] = 'Site-statistieken';
$lang['visitorstosite'] = 'Bezoekers naar site';
$lang['mostactivepage'] = 'Meest actieve pagina';
$lang['timesfeedback'] = 'Aantal keer dat het feedbackformulier gebruikt is';
$lang['timesim'] = 'Aantal keer dat gebruiker IM kreeg';
$lang['timeswink'] = 'Aantal keer dat knipoog is verzonden';
$lang['timesmessage'] = 'Aantal keer bericht verzonden naar een mailbox';
$lang['timesinvitefriend'] = 'Aantal keer dat \'nodig een vriend uit\' is gebruikt';
$lang['timeshowprofile'] = 'Aantal keer \'toon profiel\' is gebruikt';
$lang['timesonlineusers'] = 'Aantal keer op \'online gebruikers\' geklikt';
$lang['timesbanner'] = 'Aantal keer op \'banner\' geklikt';
$lang['timesnewmember'] = 'Aantal keer op \'nieuwe ledenlijst\' geklikt';
$lang['timespoll'] = 'Aantal keer poll gebruikt';
$lang['timesgallery'] = 'Aantal keer fotogallerij gebruikt';
$lang['timesaffiliates'] = 'Aantal keer op \'partners\' geklikt';
$lang['timessignup'] = 'Aantal keer op \'registreren\' geklikt';
$lang['timesnews'] = 'Aantal keer op \'nieuws\' geklikt';
$lang['timesstories'] = 'Aantal keer \'verhalen\' geklikt';
$lang['timessearchmatch'] = 'Aantal keer op \'zoek match\' geklikt';
$lang['no_affiliates'] = 'Aantal partners';
$lang['no_affiliate_refs'] = 'Aantal verwijzingen partners';
$lang['no_pages_refs'] = 'Aantal paginaverwijzingen';
$lang['no_polls'] = 'Aantal polls';
$lang['no_news'] = 'Aantal nieuwsitems';
$lang['no_stories'] = 'Aantal verhalen';
$lang['no_langs'] = 'Aantal talen beschikbaar';
$lang['glblgroups'] = 'Groep algemene instellingen';
$lang['accept_tos'] = 'Ik heb de <a href="javascript:popUpScrollWindow('."'tos.php','center',650,600);".'">gebruiksvoorwaarden</a> gelezen';
$lang['tos_must'] = 'Gelieve de gebruiksvoorwaarden te lezen en te accepteren alvorens je in te schrijven';
$lang['private_event'] = 'Deze evenementinformatie is priv&#233\;';
$lang['posted_by'] = 'Gepost door';

$lang['countries01']='Landen';
$lang['states01'] = 'Provincies';
$lang['latitude'] = 'Breedte';
$lang['longitude'] = 'Lengte';
$lang['search_within'] = 'Zoek binnen';
$lang['miles'] = ' mijlen ';
$lang['kms'] = ' kilometers ';
$lang['no_search_results'] = '<font color=red><b>0 resultaten gevonden</b></font><br /><br />Er zijn geen resultaten die aan je zoekcriteria voldoen. Misschien wil je je zoekterm verbreden. Probeer het aantal criteria te verminderen, bv: zoek naar lengte en leeftijd, maar niet naar lengte, leeftijd en lichaamstype.<br /><br />';
$lang['expire_on'] = 'Lidmaatschap vervalt op';
$lang['expire_in'] = 'Aantal dagen tot lidmaatschap vervalt';
$lang['lang_to_load'] = 'Te laden taal';
$lang['load_lang'] = 'Laad taal';
$lang['manage_languages'] = 'Talenbeheer';
$lang['manage_zips'] = 'Postcodebeheer';
$lang['split_file_names_hdr'] = 'Deze bestanden worden nu ingeladen';
$lang['worst1'] = '(slechtste)';
$lang['best1'] = '(beste)';
$lang['profile_auto_confirmed'] = 'Bedankt om lid te worden van SITENAME.<br><br>Als extraatje werd je profiel automatisch goedgekeurd door ons systeem.<br><br>Gelieve <a href="index.php?page=login">in te loggen</a> om onze diensten te gebruiken.<br><br>';
$lang['zipfile'] = 'Bestand postcode';
$lang['zip_loaded'] = 'Postcodes zijn geladen uit het bestand ';
$lang['zip_load_over'] = 'Het laden van de zipcodes voor #COUNTRY# is compleet.';
$lang['file_not_found'] = 'Opgegeven bestand is niet gevonden';
/* Modified in 1.1.0 */
$lang['success_mship_change'] = 'Bedankt om je lidmaatschap aan te passen. <br /><br />Je lidmaatschapsniveau is nu ';
$lang['payment_cancel'] = 'Betaling geannuleerd';
$lang['checkout_cancel'] = 'Zoals verzocht, is je betaling nu geannuleerd.';
$lang['useronlinetext'] = array(
	'online_now'		=> 	'Nu Online',
	'active_24hours'	=> 	' Actief in de vorige 24 Uren',
	'active_3days'		=>	' Actief in de vorige 3 dagen',
	'active_1week'		=>	' Actief in de vorige 1 week',
	'active_1month'		=>	' Actief in de vorige 1 maand',
	'notactive'			=>	'Niet recent actief'
);
$lang['useronlinecolor'] = array(
	'online_now'		=> 	'#FF0000',
	'active_24hours'	=> 	'#00AA00',
	'active_3days'		=>	'#AA00A0',
	'active_1week'		=>	'#0000AA',
	'active_1month'		=>	'#000000',
	'notactive'			=>	'#838383'
);

$lang['transactions_report'] = 'Rapport betaligstransacties';
$lang['trans_count'] = 'Aantal transacties';
$lang['pay_no'] = 'Betalingsnr.';
$lang['ref_no'] = 'Ref. nr.';
$lang['paid_thru'] = 'Betaling door';
$lang['pay_status'] = 'Betalingsstatus';
$lang['trans_rep'] = 'Betalingsrapport';
$lang['expiry_interval'] = array(
	'1'		=> '24 uur',
	'3'		=>	'3 dagen',
	'7'		=>	'7 dagen',
	'15'	=>	'15 dagen',
	'30'	=>	'30 dagen',
	'0'		=>	'Verlopen'
	);
$lang['expiry_hdr'] = 'Herinneringsbericht vervallen lidmaatschap';
$lang['expiry_ltr'] = 'Brief vervallen lidmaatschap';
$lang['expiry_select'] = 'Selecteer vervalinterval';
$lang['expird'] = 'Vervallen';
$lang['expiry_ltr_sent'] = 'Herinneringsbrieven vervallen lidmaatschap zijn verzonden';
$lang['searching_within'] = 'Zoeken in';
$lang['payment_failed'] = 'Betalingsproces faalde. Gelieve opnieuw te proberen.';
$lang['payment_fail'] = 'Betaling faalde';
$lang['deactivate'] = 'Deactiveer';

$lang['open_search'] = 'Open zoeken';
$lang['replace'] = 'Vervang';
$lang['new'] = 'Nieuw';
$lang['no_save'] = 'Niet opslaan';
$lang['modify_curr_search'] = 'Wijzig huidige zoekcriteria';
$lang['perform_search'] = 'en voer zoekopdracht uit.';
$lang['start_new_search'] = 'Start een nieuwe zoekopdracht';
$lang['use_empty_form'] = 'met een leeg formulier.';
$lang['of_zip_code'] = 'van deze postcode';

/* MOD START */

$lang['profile_ratings'] = 'ProfielWaardering';
$lang['total_ratings'] = 'Totaal Waarderingen';
$lang['delete_ratings'] = 'Verwijder Waarderingen';
$lang['delete_rating_group_confirm_msg'] = 'Ben je zeker dat je deze waarderingen wil verwijderen? Deze actie kan niet ongedaan gemaakt worden.';
$lang['delete_rating_confirm_msg'] = 'Ben je zeker dat je deze waardering wil verwijderen? Deze actie kan niet ongedaan gemaakt worden.';
$lang['modify_rating'] = 'Wijzig waardering';
$lang['modify_ratings'] = 'Wijzig waarderingen';

$lang['glblsettings_groups']['50'] = 'ProfielWaarderingen';
$lang['mod_lowtohigh']['Low to High'] = 'Laag tot Hoog';
$lang['mod_lowtohigh']['High to Low'] = 'Hoog tot Laag';
$lang['admin_rights']['profile_ratings'] = 'ProfielWaarderingen';

$lang['custom_message'] = 'Aangepast bericht';
$lang['notify_me'] = 'Breng me op de hoogte wanneer mijn bericht gelezen is.';
$lang['include_profile'] = 'Verzend mijn profiel in dit bericht.';
$lang['message_templates'] = 'Templates berichten';
$lang['my_templates'] = 'Mijn Templates';
$lang['template_select'] = 'Gelieve een template te selecteren.';
$lang['template_intro'] = 'Indien je vaak dezelfde berichten naar je potentieële matches verzendt, kan je templates creëren voor deze berichten om zo minder te hoeven typen. Door gebruik te maken van template variabelen zoals [username] en [firstname] kan je de berichten een gepersonaliseerd tintje meegeven.';

$lang['add_template'] = 'Voeg template toe';
$lang['return_message'] = 'Terug naar bericht';
$lang['delete_template_confirm_msg'] = 'Ben je zeker dat je deze template wil verwijderen? Deze actie kan niet ongedaan gemaakt worden.';
$lang['edit_template'] = 'Wijzig template';

$lang['template_instructions'] = 'De volgende template-variabelen zijn beschikbaar: <br />
[username], [firstname], [city], [state], [country], [age]<br /><br />Je kan deze variabelen gebruiken om een persoonlijk tintje mee te geven, bijvoorbeeld:<br /><br />hi [firstname]!<br /><br />Ik merkte dat u in [city] woont.... ik ook! :) Ik denk dat we een goede match zouden zijn... stuur me een mailtje<br /><br />Groeten,<br />Jamie';

$lang['your_comment'] = 'Je opmerkingen';
$lang['your_reply'] = 'Je antwoord';
$lang['comment_note'] = 'Opmerkingen langer dan 255 tekens zullen worden ingekort';
$lang['chars_remaining'] = 'overblijvende karakters';

$lang['delete_comment_confirm_msg'] = 'Ben je zeker dat u deze opmerking wil verwijderen? Deze actie kan niet ongedaan gemaakt worden.';
$lang['no_msg_templates'] = 'Er zijn geen templates van berichten gevonden.';
/* MOD END */

$lang['select'] = '- Selecteer -';
$lang['select_country'] = 'Selecteer land';
$lang['select_state'] = 'Selecteer provincie';
$lang['select_county'] = 'Selecteer provincie';
$lang['select_city'] = 'Selecteer stad';
$lang['confirm_success'] = 'Log hier beneden in om te profiteren van de voordelen van het lidmaatschap.';
$lang['signup_success_message'] = '<b>Bedankt!</b><br /><br />&nbsp;Je bent nu een geregistreerd lid van SITENAME.';
$lang['noone_online'] = 'Geen leden online';
$lang['in_hot_list'] = 'Gebruiker zit in Hotlist';
$lang['in_buddy_list'] = 'Gebruiker zit in vriendenlijst';
$lang['in_ban_list'] = 'Gebruiker zit in lijst met gebande gebruikers';
$lang['delete_search'] = 'Verwijder deze zoekopdracht';
$lang['select_user_to_send_message'] = 'Selecteer een gebruiker om je bericht naar te verzenden';
$lang['no_im_msgs'] = 'Geen IM berichten';
$lang['public_event'] = 'Dit evenement is publiek zichtbaar';
$lang['no_event_description'] = 'Geen omschrijving aanwezig';
$lang['signup_js_errors']['country_noblank'] = 'Land moet geselecteerd worden';
$lang['msg_sent'] = 'Je bericht is verzonden';
$lang['forgotpass_msg4'] = 'Ben je je logingegevens vergeten? Je gebruikersnaam met een nieuw wachtwoord kan verzonden worden naar je mailadres. Gelieve het mailadres te gebruiken dat je bij registratie hebt opgegeven';

/* 	Additions for nieuweemail messaging interface
	Vijay Nair
*/
$lang['send_a_message'] = 'Stuur een bericht';
$lang['flagged'] = 'gemarkeerd';
$lang['un_flagged'] = 'Niet gemarkeerd';
$lang['unflagged_msg1'] = 'Niet-gemarkeerde berichten ouder dan ';
$lang['unflagged_msg2'] = ' dagen oud worden automatisch verwijderd.';
$lang['no_messages_in_box'] = 'Er zijn geen berichten in deze map van de mailbox';
$lang['no_flagged_messages_in_box'] = 'Er zijn geen gemarkeerde berichten in deze map';
$lang['no_unflagged_messages_in_box'] = 'Er zijn geen niet-gemarkeerde berichten in deze map';
$lang['mark'] = 'Markeer';
$lang['flag'] = 'Markeer';
$lang['unflag'] = 'Haal markering weg';
$lang['msg_flagged'] = 'Bericht is gemarkeerd';
$lang['msg_unflagged'] = 'Bericht is niet gemarkeerd';
$lang['msg_deleted'] = 'Bericht is verwijderd';
$lang['sel_msgs_flagged'] = 'Geselecteerde berichten zijn gemarkeerd';
$lang['sel_msgs_unflagged'] = 'Geselecteerde berichte zijn niet meer gemarkeerd';
$lang['sel_msgs_deleted'] = 'Geselecteerde berichten zijn verwijderd';
$lang['sel_msgs_undeleted'] = 'Geselecteerde berichten zijn niet meer verwijderd';
$lang['sel_msgs_read'] = 'Geselecteerde berichten zijn niet meer gemarkeerd als gelezen';
$lang['sel_msgs_unread'] = 'Geselecteerde berichten zijn gemarkeerd als nieuw';
$lang['FROM1'] = 'Van';
$lang['no_thanks'] = 'Zeg \"Nee dank u\"';
$lang['reply'] = 'Beantwoord';
$lang['undelete'] = 'Maak verwijdering ongedaan';
$lang['back_to_messages'] = 'Terug naar berichten';
$lang['replied'] = 'Antwoord verzonden';
$lang['no_thanks_subject'] = 'Danku, maar liever niet...';
$lang['total'] = 'Totaal';
$lang['max_allowed'] = 'Maximum toegestaan';
$lang['im_msg_long'] = 'IM bericht is groter dan de toegestane grootte ';
$lang['members'] = 'leden';
$lang['To1'] = 'Aan';

/* Items which are modified in 1.1.0 */


$lang['change_email'] = 'Verander email';

/* Changes made for letters  */
$lang['no_watched_event'] = 'Je houdt geen evenementen in het oog op dit moment.
<br /><br />Er vinden #eventcount# evenementen plaats gedurende de volgende 30 dagen. <a "#calenderlink#">Open de kalender</a> om deze evenementen te bekijken.
<br /><br />Om een evenement in het oog te houden kan je klikken op het evenement op de kalender, En daarna op het vergrootglas klikken. #glassicon#
<br /><br />Je zal een evenement niet langer in het oog kunnen houden na het verlopen van dit evenement.';

$lang['no_thanks_message']['text'] = 'Hallo #recipient_username#,

Bedankt voor je interesse maar ik moet je spijtig genoeg teleurstellen. Ik hoop dat je eventueel je match kan vinden op #site_name#.

Beste wensen,
#sender_username#';

$lang['message_read']['text'] = "Beste #FirstName#,

Het bericht dat je hebt verstuurd naar '#RecipientName#' is gelezen.

Veel success!
#AdminName#
SITENAME";


$lang['featured_profile_added']['text'] = "Beste #FirstName#,

Met veel plezier laten we je weten dat je profiel in de featured profielenLijst op <a href=\"#link#\">#siteName#</a> terecht is gekomen.

Je profiel zal in deze lijst staan van #FromDate# tot #UptoDate#.

Dit zal de zichtbaarheid van je profiel verhogen en kan resulteren in veel meer bezoekers van eventuele matches.

Veel Success!
#AdminName#
SITENAME";

$lang['wink_received']['text'] = "Beste #FirstName#,

Je hebt een knipoog ontvangen van #siteName# gebruiker '#SenderName#'.

Gelieve <a href=\"#link#\">#siteName#</a> te bezoeken om '#SenderName#' een bericht te verzenden of om een knipoog terug te sturen.

Veel Success!
#AdminName#
SITENAME";

$lang['invite_a_friend']['text'] = "Hi,

I heb onlangs een leuke datingsite gevonden: #SiteUrl#.
Ik dacht dat dit je zou interesseren.

Bezoek #SiteUrl#.

#FromName#";

$lang['profile_confirmation_email']['text'] = "Beste #FirstName#,

Bedankt om je te registreren bij #SiteName#! Als het nieuwste lid van onze site raad ik je aan onze services grondig te bekijken.

Om de aanmaak van je profiel te bevestigen vragen we je om op onderstande link te klikken. Indien de link niet klikbaar kan je de link naar de adresbalk van je browser kopiëren.

#ConfirmationLink#=#ConfCode#

Indien je nog steeds onze confirmatiewizzard open hebt staan, kan je daarr rechtstreeks je code intypen.

Je code is: #ConfCode#

We hebben volgende registratie info over jou:

Gebruikersnaam: #StrID#
Wachtwoord: #Password#
E-Mail: #Email#

Gelieve deze informatie op een veilige plaats te bewaren zodat je toegang kan hebben tot al onze beschikbare diensten . Voor sommige diensten kan het nodig zijn dat je je profiel laat opwaarderen naar een hoger lidmaatschapsniveau. Dit kan je hier doen:

#SiteUrl#payment.php

Nogmaals dank voor het gebruik van onze services en we wensen je veel succes met de zoektocht naar jouw match!

#AdminName#
#SiteName#";

/* Added in 1.1.1 */
$lang['loading'] = 'Laden..';


/* Changes in 1.1.3 */
$lang['support_currency'] = array(
		'USD' 	=> '$',
		'EUR'	=>'€',
		'INR'	=>'Rs.',
		'AUD'	=> 'AU$',
		'CD'	=> 'CAN$',
		'UKP'	=> chr(163)
		);


$lang['ratings'] = 'Waarderingen';
$lang['comment'] = 'Opmerking';
$lang['comments'] = 'Opmerkingen';
$lang['loadaction'] = 'Selecteer de gewenste actie';
$lang['loadintodb'] = 'Laad in de DB';
$lang['createsql'] = 'Genereer SQL-script';

$lang['load_zips'] = 'Verwerk postcodebestand';



/* Versie 2.0 additions and modifications */
/* Modifications */
$lang['zip_ensure'] = 'Gelieve alle postcodes te laden naar de map /zipcodes voordat je verdergaat. <br /><br />Dit bestand moet volgende gegevens bevatten POSTCODE, LATITUDE, LONGITUDE, STATECODE, COUNTYCODE, CITYCODE (in deze volgorde. STATECODE, COUNTYCODE and CITYCODE kunnen weggelaten worden en later aangepast) gescheiden door komma\'s.<br /><br />Om postcodes voor een land te verwijderen kan je dit land selecteren en op de ';
$lang['submit'] = 'Wijzig';
$lang['lang_ensure'] = 'Gelieve eerst een nieuwe taal en bestandsnaam in config.php te definiëren (zie definities van $language_options en $language_files). Hierna plaats je het talenbestand in de map /language/lang_xxxx/ als lang_main.php . (xxxx is de taalnaam in kleine letters. Bijvoorbeeld: english, dutch, etc.).<br /><br /><b>Indien je wijzigingen maakt in het taalbestand moet je het herladen.</b><br /><br />Om een taal te verwijderen kan je na het selecteren van de te wissen taal klikken op \'Verwijder taal\' uit db.';

/* $lang['rate_catefully'] is changed as below */
$lang['rate_carefully'] = 'De medewerkers van deze website maken geen claims in verband met de nauwkeurigheid of betrouwbaarheid van deze beoordelingen. Beoordelingen zijn gepost door gebruikers en worden niet nagekeken door de medewerkers.';


$lang['privileges'] = array (
	'chat' 				=> 'Neem deel aan chat.',
	'blog'				=> 'Neem deel aan blog.',
	'poll'				=> 'Neem deel aan poll.',
	'forum'				=> 'Neem deel aan forum.',
	'includeinsearch' 	=> 'Neem op in de zoekresultaten.',
	'message'			=> 'Stuur een bericht naar de mailbox.',
	/* Added in 1.1.0 */
	'message_keep_cnt'  => 'Aantal berichten te bewaren.',
	'message_keep_days' => 'Aantal dagen dat een bericht bewaard kan worden.',
	/* rel 2.0 */
	'messages_per_day' 	=> 'Aantal berichten dat per dag verzonden kan worden.',
	/* Rel 1.0 added  */
	'allowim'			=> 'Sta instant messaging toe.',
	'uploadpicture'		=> 'Upload foto\'s.',
	'uploadpicturecnt'	=> 'Upload foto\'s aantal',
	'allowalbum'		=> 'Sta prive-albums toe.',
	'event_mgt'			=> 'Sta evenementbeheer toe.',
	/* Above is added in 1.0 */
	'seepictureprofile' => 'Bekijk foto\'s profiel.',
	'favouritelist'		=> 'Beheer vrienden-/bannings-/hotlijsten.',
	'sendwinks'			=> 'Verstuur knipogen.',
	/* rel 2.0 */
	'winks_per_day' 	=> 'Aantal knipogen dat per dag verzonden kan worden.',
	'extsearch'			=> 'Voer uitgebreide zoekopdracht uit.',
	//'fullsignup' 		=> 'Volledige registratie.',
	/* RC6 Patch */
	'activedays'		=> 'Actieve dagen voor dit niveau.',
	/* added in 2.0 */
	'saveprofiles'		=> 'Sta het opslaan van profielen toe.',
	'saveprofilescnt'	=> 'Aantal profielen dat men mag opslaan.',
	'allow_videos'		=> 'Sta video-uploads toe.',
	'videoscnt'			=> 'Aantal video\'s dat men mag uploaden.',
	'allow_mysettings'	=> 'Sta toe om gebruikersinstellingen te wijzigen.',
	'allow_php121'		=> 'Sta gebruik php121 instant messenger toe.',

);

/* 	Signup Error Messages
	These are the signup error messages, Please do not change the sequence.
*/

$lang['errormsgs']= array(
	00 => '',
	01 => 'Gebruikersnaam is een verplicht veld.',
	02 => 'Wachtwoord is een verplicht veld.',
	03 => 'Bevestig wachtwoord is een verplicht veld.',
	04 => 'Voornaam is een verplicht veld.',
	05 => 'Familienaam is een verplicht veld.',
	06 => 'Email adres is een verplicht veld.',
	07 => 'Stad is een verplicht veld.',
	08 => 'Postcode is een verplicht veld.',
	09 => 'Addreslijn 1 is een verplicht veld.',
	10 => 'Maximum lengte van gebruikersnaam is 25 tekens.',
	11 => 'Maximum lengte van voornaam is 50 tekens.',
	12 => 'Maximum lengte van familienaam is 50 tekens.',
	13 => 'Maximum lengte van email is 255 karakters.',
	14 => 'Maximum lengte van stad is 100 karakters.',
	15 => 'Maximum lengte van adres lijn 1 is 255 tekens.',
	16 => 'Gebruikersnaam moet beginnen met een letter',
	17 => 'Wachtwoord moet beginnen met een letter',
	18 => 'Gelieve een correct emailadres in te voeren',
	19 => 'Gelieve een geldig mailadres op te geven',
	20 => 'Verplichte informatie moet ingegeven worden.',
	21 => 'De logingegevens die je hebt opgegeven zijn niet correct. Gelieve je invoer te controleren en opnieuw te proberen.',
	22 => 'Gebruikersnaam bestaat reeds, gelieve een andere te proberen.',
	23 => 'Het oude wachtwoord dat je opgaf is niet correct. Gelieve je oude wachtwoord te controleren en opnieuw te proberen.',
	25 => 'Email is reeds geregistreerd.' ,
//	26 => "Je status is 'Not Active'. Gelieve te wachten tot deze geactiveerd werd of neem contact op met de administrator." ,
	27 => 'Kon bericht niet vinden.',
	28 => 'Gelieve eerst een bestand te selecteren.',
	29 => 'Bestandsformaat wordt niet ondersteund, gelieve een ander te kiezen',
	30 => 'Vraag staat reeds hierboven.',
	31 => 'Vraag staat reeds beneden.',
	32 => 'Bedankt voor je opmerkingen, deze zullen snel verwerkt worden.',
	33 => 'De postcode komt niet overeen met de gevraagde provincie',
	34 => 'Postcode is incorrect',
	36 => 'Je account is geschorst. Gelieve contact op te nemen met een administrator voor verdere details.',
	37 => 'Je toevoeging is geweigerd. Gelieve contact op te nemen met een administrator voor verdere details.',
	38 => 'U hebt een ongeldige geboortedatum ingegevens. Gelieve deze na te kijken en opnieuw te proberen.',
	39 => 'Oud en nieuw wachtwoord mogen niet hetzelfde zijn',
	40 => 'De begin-leeftijd moet kleiner zijn dan de eind-leeftijd',
	51 => 'Startdatum moet voor de einddatum zijn',
	52 => 'Dit lid staat reeds op de lijst',
	53 => 'Ongeldige datum',
	54 => 'Ongeldige gebruikersnaam of wachtwoord',
	55 => 'Je moet inloggen om een bericht te verzenden',
	56 => $lang['bigger_pic_size'],
	57 => $lang['only_jpg'],
	58 => $lang['upload_unsuccessful'],
	59 => 'Dit profiel is aan de lijst toegevoegd',
	60 => 'Thumbnail-afmetingen overschreiden de maximum toegestande ('.$config['upload_snap_tnsize'].' X '.$config['upload_snap_tnsize'].')',
	61 => 'Ongeldige activatie-code',
	62 => 'De gebruikersnaam is van de lijst verwijderd',
	63 => 'Deze gebruiker is aan je vriendenlijst toegevoegd',
	64 => 'Deze gebruiker is aan je lijst met geblokkeerden toegvoegd',
	65 => 'Deze gebruiker is aan je Hotijst toegevoegd',
	66 => 'Je knipoog is verzonden naar deze gebruiker',
	67 => $lang['upload_successful'],
	68 => 'De foto is goedgekeurd',
	69 => 'De foto is afgekeurd',
	70 => 'Het aantal views is verwijderd',
	71 => 'Het aantal knipogen is verwijderd',
	/* Added in RC6  */
	72 => 'De gebruikersaccount werd opnieuw geactiveerd',
	73 => 'Het land is toegevoegd',
	74 => 'Het land is verwijderd',
	75 => 'Landcode of -naam is reeds in gebruik',
	76 => 'Het land is aangepast',
	77 => 'De provincie is aangepast',
	78 => 'De provincie is verwijderd',
	79 => 'Provinciecode of -naam is reeds in gebruik',
	80 => 'De provincie is aangepast',
	81 => 'Provincienaam moet ingevoerd worden',
	82 => 'Dit lid heeft geen foto\'s geupload. ',
	83 => 'Het profiel is verwijderd',
	84 => 'De geselecteerde profielen zijn verwijderd',

	85 => 'Geselecteerde profiel(en) zijn goedgekeurd.',
	86 => 'Geselecteerde profiel(en) zijn afgekeurd.',
	87 => 'Geselecteerde profiel(en) zijn in wacht.',

	26 => 'Je profiel is nog niet geactiveerd. <a href=\'completereg.php\'>Activeer je profiel</a> door je bevestigingscode in te voeren of of door de link in de registratiemail te volgen.',

//	26 => 'Je partneraccount werd nog niet geactiveerd door een administrator. Gelieve deze activatie af te wachten voor van deze account gebruik te maken.',

	35 => 'Je profiel is nog niet goedgekeurd.<br /> Gelieve op goedkeuring te wachten of contact met de site-beheerder op te nemen',

/* Release 1.0 additions/modifications  */

	88 => 'De provincie is toegevoegd',
	89 => 'De provincie is verwijderd',
	90 => 'De provinciecode of -naam is reeds in gebruik',
	91 => 'De provincie is aangepast',
	92 => 'De stad is toegevoegd',
	93 => 'De stad is verwijderd',
	94 => 'Stadscode of -naam is reeds in gebruik',
	95 => 'De stad is aangepast',
	96 => 'De postcode is toegevoegd',
	97 => 'De postcode is verwijderd',
	98 => 'Deze postcode is reeds in gebruik',
	99 => 'De postcode is aangepast',
	100 => 'Provincie is een verplicht veld',
	101 => 'Ongeldig wachtwoord',
	102 => 'Het evenement is goedgekeurd.',
	103 => 'Het evenement is afgekeurd.',
	111 => 'Dit lid komt reeds voor op de featured ledenlijst',
	301 => 'Ongeldige tijdszone',
	302 => 'Het album is bijgewerkt',
/* 1.1.0 additions */
	104 => 'De login die je gaf kon niet gevonden worden. Gelieve je invoer te controleren en opnieuw te proberen of gebruik de optie hierbeneden om eraan herinnerd te worden.',
	105 => 'Gebruiker zit in lijst met gebande personen',
	/* Added in 2.0 */
	120	=>	'Veiligheidscode moet ingevoerd worden',
	121 => 'Ongeldige veiligheidscode ',
	122 => 'Je hebt reeds het aantal toegestane berichten voor vandaag verzonden. Gelieve morgen nog eens te proberen.',
	123 => 'Je hebt reeds het aantal toegestane knipogen voor vandaag verzonden. Gelieve morgen nog eens te proberen.',
	124 => 'Videobestand is geladen',
	125 => 'Videobestand is niet geladen omdat de upload mislukt is.',
	126 => 'Je moet info over jezelf opgeven.',
	128 => 'Individuele gebruikersnamen van leden die een koppel vormen moet ingegeven worden.',
	129 => 'Gebruikersnamen moeten reeds beschikbaar zijn.',
	130 => 'Het videobestand kan niet geconverteerd worden. Gelieve videobestanden van het .flv-formaat te gebruiken.',
	131 => 'Je hebt het maximum aantal toegelaten berichten voor je lidmaatschap overschreden',
	201 => 'Je hebt reeds het aantal toegestane profielen in je volglijst geplaats',
	202 => 'Dit profiel is toegevoegd aan je volglijst',
	203 => 'Dit profiel bevindt zich reeds in je volglijst',
	);


$lang['alphanumeric'] = "0123456789.+-_#,/ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz ()_";
$lang['alphanum'] = "0123456789_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz ";
$lang['text'] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz '";
$lang['full_chars'] = "0123456789.+-_#,/ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz() _$+=\;:\?'";
/* Additions  in Versie 2.0 */

$lang['save'] = 'Opslaan';
$lang['delete_zips'] = 'Verwijder Postcodes';
$lang['zipcodes_sql_created'] = 'Sql-bestand postcodes aangemaakt ';
$lang['zipcodes_loaded'] = 'Postcodes geladen van ';
$lang['delzips_msg'] = 'Alle postcodes van dit land zullen verwijderd worden';
$lang['delzips_succ'] = 'Postcodes van #COUNTRY# zijn verwijderd';
$lang['wrong_zipfile'] = 'Dit bestand is niet voor het land #COUNTRY#';
$lang['load_states'] = 'Verwerk bestand provincies';
$lang['state_ensure'] = 'Gelieve het bestand met provinciecodes te laden naar /states voor over te gaan tot verwerking. <br /><br />Het bestand moet PROVINCIECODE en PROVINCIENAAM bevatten, gescheiden door komma\'s.(geen hoofding)<br /><br /> Om provinciecodes te verwijderen voor een provincie, selecteer de provincie en druk op de knop \"Verwijder provinciecodes\"';
$lang['statefile'] = 'Bestand provinciecodes';
$lang['delete_states'] = 'Verwijder provinciecodes';
$lang['delstates_msg'] = 'Alle provinciecodes voor dit land zullen verwijderd worden';
$lang['delstates_succ'] = 'Provinciecodes voor #COUNTRY# zijn verwijderd';
$lang['states_sql_created'] = 'Provinciecodes sql-bestand aangemaakt ';
$lang['states_loaded'] = 'Provinciecodes geladen van ';
$lang['delete_lang'] = 'Verwijder taal uit DB';
$lang['langfile_loaded'] = 'Taaldefinities voor #LANGUAGE# zijn geladen van ';
$lang['lang_deleted'] = 'Taaldefinities voor #LANGUAGE# zijn verwijderd';
$lang['load_counties'] = 'Verwerk plaats bestand';
$lang['countyfile'] = 'Plaatscodes bestand';
$lang['county_ensure'] = 'Laad het bestand met provinciecodes naar de map /counties voor verder te gaan. <br /><br />Het bestand moet COUNTYCODE, COUNTYNAME en STATECODE bevatten, gescheiden door comma\'.(in dezelfde volgorde, zonder hoofding)<br /><br /> Om provinciecodes te verwijderen voor een provincie, selecteer het land en druk op de knop \"Verwijder provinciecodes\"';
$lang['delete_counties'] = 'Verwijder provinciecodes';
$lang['delcounties_msg'] = 'Alle provinciecodes voor dit land zullen verwijderd worden';
$lang['delcounties_succ'] = 'Provinciecodes voor #COUNTRY# zijn verwijderd';
$lang['counties_sql_created'] = 'Provinciecodes sql-bestand aangemaakt ';
$lang['counties_loaded'] = 'Provinciecodes geladen van ';
$lang['load_cities'] = 'Verwerk stedenbestand';
$lang['cityfile'] = 'Bestand stedencodes';
$lang['city_ensure'] = 'Gelieve het bestand met stedencodes te laden naar /cities voor over te gaan tot verwerking. <br /><br />Het bestand moet CITYCODE, CITYNAME, COUNTYCODE en STATECODE bevatten, gescheiden door kommas.(in zelfde volgorde, geen hoofding)<br /><br /> Om alle stadscodes voor een land te verwijderen selecteer je dit land en druk je op \"Verwijder stadscodes\"';
$lang['delete_cities'] = 'Verwijder stadscodes';
$lang['delcities_msg'] = 'Alle stadscodes voor dit land zijn verwijderd';
$lang['delcities_succ'] = 'Stadscodes voor #COUNTRY# zijn verwijderd';
$lang['cities_sql_created'] = 'Stadscodes sql-bestand aangemaakt ';
$lang['cities_loaded'] = 'Stadscodes geladen van ';
$lang['online'] = 'Online';
$lang['watchedprofiles_1'] = 'Voeg toe aan geziene profielen';
$lang['watchedprofiles'] = 'Geziene profielen';


$lang['poll'] = 'Poll';
$lang['section_poll_title'] = 'Poll';
$lang['section_poll_list'] = 'Polllijst';
$lang['section_add_poll'] = 'Maak Poll';
$lang['poll_subtitle_list'] = 'Polllijst';
$lang['poll_subtitle_add'] = 'Maak poll';
$lang['poll_subtitle_edit'] = 'Wijzig poll';
$lang['poll_number'] = 'Nummer';
$lang['poll_active_hdr'] = 'Actief';
$lang['poll_question_hdr'] = 'Vragen';
$lang['poll_responses_hdr'] = 'Antwoorden';
$lang['no_poll_found'] = 'Geen polls gevonden';
$lang['poll_question'] = 'Vraag';
$lang['poll_options'] = 'Opties';
$lang['poll_active'] = 'Actief';
$lang['poll_minimum_two'] = 'ten minste twee benodigd.';
$lang['results_poll_title'] = 'Resultaten';
$lang['poll_subtitle_results'] = 'Resultaten poll';
$lang['take_poll_title'] = 'Neem poll';
$lang['poll_entries'] = 'Poll';


$lang['plugin'] = 'Plugins';
$lang['plugin_access'] = 'Lidmaatschapstoegang';
$lang['section_plugin_title'] = 'Plugins';
$lang['section_plugin_list'] = 'Pluginlijst';
$lang['section_add_plugin'] = 'Laad plugin';
$lang['plugin_subtitle_list'] = 'Pluginlijst';
$lang['plugin_number'] = 'Nummer';
$lang['plugin_name'] = 'Naam';
$lang['plugin_active'] = 'Actief';
$lang['plugin_installed'] = 'Geinstaleerd';
$lang['plugin_install'] = 'Instaleer';
$lang['no_plugin_found'] = 'Geen plugins gevonden';
$lang['plugin_file'] = 'Upload zip-bestand met plugin';
$lang['plugin_subtitle_edit'] = 'Wijzig Plugin';
$lang['add_plugin_summary'] = 'Documentatie over het maken van een plugin kan je vinden in de documentatie geleverd bij je osDate installatie.';

$lang['blog']['hdr'] = 'Blog';
$lang['admin_blog'] = 'Site blog';
$lang['blog_default_bad_words'] = 'xxx|levitra';
$lang['blog_bad_words'] = 'Slechte woorden';
$lang['blog_save_template'] = 'Opslaan als template';
$lang['blog_load_template'] = 'Laad template';
$lang['blog_bad_words_help'] = '(een woord per regel)';
$lang['blog_search_results'] = 'Zoekresultaten blog';
$lang['section_blog_info'] = 'Blog instellingen';
$lang['section_blog_list'] = 'Blog ingaven';
$lang['section_blog_title'] = 'Blog';
$lang['blog_search_menu'] = 'Blog zoeken';
$lang['blog_search_username'] = 'Gebruikersnaam';
$lang['blog_search_title'] = 'Titel';
$lang['blog_search_body'] = 'Tekst';
$lang['blog_search_Date'] = 'Datum';

$lang['blog_subtitle_list'] = 'Bloglijst';
$lang['blog_name'] = 'Blognaam';
$lang['blog_description'] = 'Blog omschrijving';
$lang['blog_members_comment'] = 'Leden opmerking';
$lang['blog_buddies_comment'] = 'Buddies opmerking';
$lang['blog_members_vote'] = 'Leden stem';
$lang['blog_gui_editor'] = 'WYSIWYG Editor';
$lang['blog_max_comments'] = 'Max opmerkingen';
$lang['no_blog_found'] = 'Geen ingaven gevonden';
$lang['section_add_blog'] = 'Maak blog ingave';
$lang['blog_subtitle_add'] = 'Maak blog ingave';
$lang['blog_subtitle_edit'] = 'Wijzig blog';
$lang['blog_title'] = 'Titel';
$lang['blog_story'] = 'Inhoud';
$lang['blog_posted_date'] = 'Postdatum';
$lang['blog_title_hdr'] = 'Titel';
$lang['blog_rating_list_hdr'] = 'Beoordeling';
$lang['blog_number'] = 'Nummer';
$lang['blog_date_posted_hdr'] = 'Datum';
$lang['blog_views_hdr'] = 'Bekeken';
$lang['blog_votes_hdr'] = 'Stemmen';
$lang['blog_votes1'] = 'stemmen';
$lang['blog_rating_hdr'] = 'gebaseerd op';
$lang['blog_submit_vote'] = 'Stem';
$lang['blog_add_vote'] = 'Stem nu';
$lang['view_blog'] = 'Bekijk Blog';
$lang['blog_entries'] = 'Blog:';
$lang['blog_creator'] = 'Auteur';
$lang['blog_comments'] = 'Opmerkingen';
$lang['add_comment'] = 'Je opmerkingen';
$lang['total_blogs_found'] = 'Totaal blog ingaven gevonden:';

$lang['blog_errors'] = array(
   'nosetup' => 'Initiële Bloginstellingen moeten gespecifieerd worden.' ,
   'name_noblank' => 'Blognaam moet gespecifieerd worden.' ,
   'description_noblank' => 'Blog omschrijving moeten gespecifieerd worden. ',
   'date_posted_noblank' => 'Een Postdatum moeten gespecifieerd worden.' ,
   'title_noblank' => 'Een titel moet gespecifieerd worden.' ,
   'story_noblank' => 'Een verhaal moet gespecifieerd worden.' ,
   'max_stories_warning' => 'Je hebt het maximum aantal verhalen bereikt. Je kan geen nieuw verhaal meer toevoegen.' ,
   'comment_bad_word' => 'Je opmerking bevat het niet toegestane woord : %s' ,
);
$lang['spell_check'] = 'Spellingscontrole';

$lang['manage_import_webdate'] = 'Importeer van Webdate';
$lang['import_config'] = 'Configureer';

$lang['forum_values'] = array(
   'None' => 'Geen',
   'phpBB' => 'phpBB',
   'vBulletin' => 'vBulletin',
   'myBB' => 'myBB',
   'Phorum' => 'Phorum',
   );

$lang['photos_url'] = 'Home Pagina URL:';
$lang['ftp_username'] = 'FTP Gebruikersnaam:';
$lang['ftp_password'] = 'FTP Wachtwoord:';
$lang['ftp_hostname'] = 'FTP Hostnaam:';
$lang['ftp_path'] = 'FTP aeDating Path:';
$lang['ftp_path_help'] = 'Map naar de aeDating directory wanneer men ingelogd is via FTP.  Bv. public_html/aeDating';

$lang['nopicsloaded'] = 'Geen foto\'s';
$lang['loadedpicscnt'] = '#PICSCNT# foto(\'s)';
$lang['loadedpicscnt1'] = '#PICSCNT# foto';
$lang['picsloaded'] = 'Foto\'s geladen';
$lang['since'] = 'sinds';
$lang['unknown'] = 'Onbekend';

$lang['glblsettings_groups'] = array(
1	=>	'Site Informatie',
2	=> 	'Gebruiker Controles',
3	=>	'Kalender Controles',
4	=>	'Mailinstellingen',
5	=>	'Profiel afbeeldingen en thumbnails',
6	=>	'Pagina- en tabellayout',
);

$lang['who_is_online'] = 'Enkel online gebruikers';
$lang['search_with_photo'] = 'Enkel gebruikers met foto\'s';
$lang['search_with_video'] = 'Enkel gebruikers met video\'s';
$lang['expire_on_hdr'] = 'Vervalt op';
$lang['expird'] = 'Vervalt';
$lang['pics'] = 'Foto\'s';
$lang['pic_deleted'] = 'Geselecteerde foto is verwijderd';
$lang['entrycode_chars'] = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
$lang['enter_spamcode'] = 'Veiligheidscode';

/* Beheerder emails portion */

$lang['newpic']['html'] = "Beste site beheerder,<br><br>De gebruiker #UserName# heeft een nieuwe foto geladen. <br><br>Gebruikersnaam: #UserName#.<br>Foto Nr.: #PicNo#<br><br>#AdminName#<br>SITENAME";

$lang['newpic']['text'] = "Beste site beheerder,

De gebruiker #UserName# heeft een nieuwe foto geladen.

Gebruikersnaam: #UserName#
Foto Nr.: #PicNo#

#AdminName#
SITENAME";

$lang['newpic_sub'] = 'SITENAME Bericht: Nieuwe foto geladen door gebruiker ';

$lang['newvideo']['html'] = "Beste site beheerder,<br><br>De gebruiker #UserName# heeft een nieuwe video geladen.  <br><br>Gebruikersnaam: #UserName#.<br>Video Nr.: #PicNo#<br><br>#AdminName#<br>SITENAME";

$lang['newvideo']['text'] = "Beste site beheerder,


De gebruiker #UserName# heeft een nieuwe video geladen.

Gebruikersnaam: #UserName#
Video Nr.: #PicNo#

#AdminName#
SITENAME";

$lang['newvideo_sub'] = 'SITENAME Bericht: Nieuwe video geladen door gebruiker ';

/* Modified in 2.0 */
$lang['payment_msg1'] = 'Beschikbare Betalingsmethodes:';

$lang['wrong_activationcode'] = 'De bevestigingscode is niet correct of het account is reeds bevestigd.';

$lang['security_code_txt'] = 'Gelieve de tekst in de afbeelding hier beneden te lezen en in het invoervak ernaast te vervolledigen. Dit is nodig zodat wij zeker zijn dat deze actie niet door een automatisch process wordt uitgevoerd.';
$lang['additional_pics'] = 'Bijkomende foto\'s';
$lang['view_all_pics'] = 'Bekijk alle foto\'s';
$lang['insufficientPrivileges'] = 'Je hebt niet genoeg privileges voor deze optie. Gelieve je lidmaatschapsniveau op te voeren.';
$lang['username_part_msg'] = "Indien je niet zeker bent over je gebruikersnaam kan je enkel het eerste deel invoeren om zo alle mogelijke namen te bekijken. Bijvoorbeeld, het invoeren van 'user' zal 'user123', 'someuser', ... tonen."
;
$lang['featured_profiles_msg01'] = "Moet getoond worden: \'Ja\' zal de voorkeur geven om dit profiel in de featured profielenlijst op te nemen. \'Nee\' zal de kans om hiervoor geselecteerd te worden doen verminderen. ";

$lang['featured_profiles_msg02'] = "Benodigde exposures: Dit is het aantal exposures dat ervoor zal zorgen dat het profiel uit de featured lijst kan verdwijnen, indien de exposures voor de einddatum bereikt zijn.";
$lang['lookup'] = 'Zoek';
/* for use in shoutbox */
$lang['sb_by'] = 'Gepost door:';
$lang['sb_hdr'] = 'Shoutbox';
$lang['sb_send'] = 'Verzend';
$lang['sb_error'] = 'Ingegeven tekst is langer dan toegestaan';
$lang['sb_msg_blank'] = 'Shoutbox-bericht leeg?';
$lang['sb_show_all'] = 'Toon alle';

$lang['upload_videos'] = 'Upload video\'s';
$lang['videoupload_format_msgs'] = 'Enkel .swf- of .flv-bestanden zijn toegestaan.';
$lang['video'] = 'Video';
$lang['upload_videos_ext'] = 'flv, swf';
$lang['upload_video_caption'] = 'Uploaden video';
$lang['video_file'] = 'Videobestand';
$lang['vds'] = 'Vds';
$lang['manage_videos'] = 'Beheer video\'s';
$lang['videos_loaded'] = 'Video\'s geladen';
$lang['novideos_loaded'] = 'Geen Video\'s';
$lang['loadedvdocnt'] = '#PICSCNT# video(\'s)';
$lang['loadedvdocnt1'] = '#PICSCNT# video';
$lang['video_gallery'] = 'Videogallerij';
$lang['picture_gallery'] = 'Fotogallerij';


/* New timezone display values Modified in 2.0 */
// These are displayed in the timezone select box
$lang['tz']['-25'] = '-- Selecteer --';
$lang['tz']['-12.00'] = '(GMT -12:00) Eniwetok, Kwajalein';
$lang['tz']['-11.00'] = '(GMT -11:00) Midway Island, Samoa';
$lang['tz']['-10.00'] = '(GMT -10:00) Hawaii';
$lang['tz']['-9.00'] = '(GMT -9:00) Alaska';
$lang['tz']['-8.00'] = '(GMT -8:00) Pacific Tijd (US & Canada)';
$lang['tz']['-7.00'] = '(GMT -7:00) Mountain Tijd (US & Canada)';
$lang['tz']['-6.00'] = '(GMT -6:00) Central Tijd (US & Canada), Mexico City';
$lang['tz']['-5.00'] = '(GMT -5:00) Eastern Tijd (US & Canada), Bogota, Lima';
$lang['tz']['-4.00'] = '(GMT -4:00) Atlantic Tijd (Canada), Caracas, La Paz';
$lang['tz']['-3.5'] = '(GMT -3:30) Newfoundland';
$lang['tz']['-3.00'] = '(GMT -3:00) Brazil, Buenos Aires, Georgetown';
$lang['tz']['-2.00'] = '(GMT -2:00) Mid-Atlantic';
$lang['tz']['-1.00'] = '(GMT -1:00) Azores, Cape Verde Islands';
$lang['tz']['0.00'] = '(GMT) West Europese Tijd, Londen, Lisbon, Casablanca';
$lang['tz']['1.00'] = '(GMT +1:00) Brussel, Copenhagen, Madrid, Parijs';
$lang['tz']['2.00'] = '(GMT +2:00) Kaliningrad, Zuid Africa';
$lang['tz']['3.00'] = '(GMT +3:00) Baghdad, Riyadh, Moskou, St. Petersburg';
$lang['tz']['3.5'] = '(GMT +3:30) Tehran';
$lang['tz']['4'] = '(GMT +4:00) Abu Dhabi, Muscat, Baku, Tbilisi';
$lang['tz']['4.5'] = '(GMT +4:30) Kabul';
$lang['tz']['5.00'] = '(GMT +5:00) Ekaterinburg, Islamabad, Karachi, Tashkent';
$lang['tz']['5.5'] = '(GMT +5:30) Bombay, Calcutta, Madras, New Delhi';
$lang['tz']['6.00'] = '(GMT +6:00) Almaty, Dhaka, Colombo';
$lang['tz']['6.5'] = 'GMT + 6.30) ';
$lang['tz']['7.00'] = '(GMT +7:00) Bangkok, Hanoi, Jakarta';
$lang['tz']['8.00'] = '(GMT +8:00) Beijing, Perth, Singapore, Hong Kong';
$lang['tz']['9'] = '(GMT +9:00) Tokyo, Seoul, Osaka, Sapporo, Yakutsk';
$lang['tz']['9.5'] = '(GMT +9:30) Adelaide, Darwin';
$lang['tz']['10.00'] = '(GMT +10:00) Eastern Australia, Guam, Vladivostok';
$lang['tz']['11.00'] = '(GMT +11:00) Magadan, Solomon Islands, New Caledonia';
$lang['tz']['12.00'] = '(GMT +12:00) Auckland, Wellington, Fiji, Kamchatka';
$lang['tz']['13.00'] = '(GMT + 13)';

$lang['myprofile'] = 'Mijn profiel';
$lang['myblog'] = 'Mijn blog';
$lang['profilesearch'] = 'Profiel zoeken';
$lang['mylists'] = 'Mijn lijsten';
$lang['bans'] = 'Bans';
$lang['mybuddies'] = 'Mijn vrienden';
$lang['hotprofiles'] = 'Hot profielen';
$lang['winks'] = 'Knipogen';
$lang['tools'] = 'Tools';
$lang['picturegallery'] = 'Mijn fotogallerij';
$lang['videogallery'] = 'Mijn videogallerij';
$lang['membership'] = 'Mijn lidmaatschap';
$lang['adminhome'] = 'Startpagina beheerder';
$lang['membershdr'] = 'Leden';
$lang['memberprofiles'] = 'Profielen leden';
$lang['membersearch'] = 'Leden zoeken';
$lang['blogs'] = 'Blogs';
$lang['blogsearch'] = 'Zoek blogs';
$lang['affiliateshdr'] = 'Partners';
$lang['localities'] = 'Plaatsen';
$lang['contenthdr'] = 'Inhoud';
$lang['financial'] = 'Financieel';
$lang['plugins_hlp'] = 'Administratieve plugins zijn enkel door admins en beheerders met voldoende rechten beschikbaar en verschijnen automatisch links-beneden in het admin-menu wanneer deze geactiveerd zijn. Ledenplugins zijn in het ledenpaneel beschikbaar';

/* HTML and some text emails */
$lang['no_thanks_message']['html'] = 'Hallo #recipient_username#,<br><br>Bedant voor je intresse maar ik moet je spijtig genoeg teleurstellen. Ik hoop dat je na verloop van tijd je match vindt op #site_name#.<br><br>Beste wensen,<br><br>#sender_username#';


/* old format
$lang['wink_received']['html'] = "Beste #FirstName#,<br><br>je ontving een knipoog via #siteName# van de gebruiker #SenderName#.<br><br>Bezoek <a href=\"#link#\">#siteName#</a> om eem bericht te sturen naar '#SenderName#' of om de knipoog te beantwoorden.<br><br>Veel Success!<br>#AdminName#";
$lang['letter_winkreceived_sub'] = '#SITENAME# - Je ontving een knipoog';

New format below
*/

$lang['mail']['hdr_text'] = '<font style="color:red; font-size: 9px;">Om dit type emails niet meer te ontvangen, <a href="#SiteUrl#">login in</a> en wijzig je mailvoorkeuren in het gebruikersmenu.<br>Om zeker te zijn dat je deze mails ontvangt, gelieve <a href="mailto:#AdminEmail#">#AdminEmail#</a> aan je adresboek toe te voegen.</font><br><br>';
$lang['mail']['hdr_html'] = '<table border=0 cellspacing=0 cellpadding=0 width="570"><tr><td style="padding: 5px;"><font style="color:red; font-size: 9px;">Om dit type mails niet meer te ontvangen,  <a href="#SiteUrl#">log in</a> en wijzig je mailvoorkeuren in het gebruikersmenu.<br>Om zeker te zijn dat je deze mails ontvangt, gelieve <a href="mailto:#AdminEmail#">#AdminEmail#</a> aan je adresboek toe te voegen.</font></td></tr><tr><td height="6"></td></tr></table>';

$lang['letter_winkreceived_sub'] = 'SITENAME bericht: #SenderName# heeft naar je geknipoogd! ';
$lang['wink_received']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td width="77" height="25px">#email_hdr_left#</td><td width="493" class="module_head" >&nbsp;&nbsp;#SenderName# Heeft zonet naar je geknipoogd! </td></tr><tr><td width="570" class="evenrow" colspan="2" style="padding: 5px;"><table border="0" cellspacing="2" cellpadding="2"><tr><td height="6"></td></tr><tr><td width="50%" valign="top">#smallProfile#</td><td width="50%" valign="top">Uit onze vele leden heeft #SenderName# jou gekozen om naar te knipogen! Je kan verder flirten door terug te knipogen of door een mail te verzenden.<br><br><a href="#SiteUrl#compose.php?recipient=#UserId#">E-mail #SenderName# now</a><br><br><a href="#SiteUrl#sendwinks.php?ref_id=#UserId#&amp;rtnurl=showprofile.php">Knipoog terug</a><br><br>
<b>Niet geïntereseerd?</b><br>Laat #SenderName# weten dat je geen intresse hebt door een \"Nee, bedankt\"-bericht te verzenden<br><br><a href="#SiteUrl#compose.php?recipient=#UserId#&amp;reply=11">Zeg \"Nee, dank je\"</a><br><br></td></tr></table></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

/* old format
$lang['profile_confirmation_email']['html'] = "Beste #FirstName#,<br><br>Bedankt om te registreren op #SiteName#! Als nieuzste lid van onze community, moedig ik je aan om onze diensten en features te verkennen.<br><br>Om je profiel te bevestigen, klik op onderstaande link of kopieer deze naar de adresbalk van de webbrowser wanneer je hem niet kan aanklikken.<br><br><a href=\"#ConfirmationLink#=#ConfCode#\">#ConfirmationLink#=#ConfCode#</a><br><br>Indien je nog steeds de registratie-wizard hebt openstaan, kan je je confirmatiecode meteen ingeven.<br><br>Je confirmatiecode is: #ConfCode#<br><br>We hebben de volgende informatie van jou gekregen:<br><br>Gebruikersnaam: #StrID#<br>Paswoord: #Password#<br>E-Mail: #Email#<br><br>Gelieve deze info goed te bewaren zodat je toegang houdt tot al onze diensten en features. Sommige diensten kunnen een hoger lidmaatschapsniveau vragen. Dit kan je hier upgraden:<br><br>#SiteUrl#payment.php<br><br>Bedankt voor je registratie en we hopen dat ook jij je match vindt!<br><br>#AdminName#<br>#SiteName#";

New format below
*/
$lang['profile_confirmation_email_sub'] = 'SITENAME Bericht: Bedankt om te registreren op SITENAME!';
$lang['profile_confirmation_email']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td width="77" height="25" class="module_head">#email_hdr_left#</td><td width="493" class="module_head" >&nbsp;&nbsp;#Welcome#!</td></tr><tr><td width="570" class="evenrow" colspan="2" style="padding: 5px;">Beste #FirstName#,<br><br>Bedankt voor je registratie op #SiteName#! Als ons nieuwste lid raad ik je aan onze diensten grondig te bestuderen.<br><br>Om je profiel te bevestigen kan je op de link hierbeneden klikken of indien de link niet klikbaar is, kan je hem naar je browser kopiëren.<br><br><a href=\"#ConfirmationLink#=#ConfCode#\">#ConfirmationLink#=#ConfCode#</a><br><br>Indien je de laatste stap van de registratie-wizard nog open hebt, kan je hier de bevestigingscode in plakken.<br><br>Uw bevestigingscode is: <b>#ConfCode#</b><br><br>We hebben volgende registratie-informatie over u:<br><br>Gebruikersnaam: <b>#StrID#</b><br>Wachtwoord: <b>#Password#</b><br>E-Mail: <b>#Email#</b><br><br>Gelieve deze informatie op een veilige plaats te bewaren, zodat je al onze services steeds kan bereiken. Voor sommige services kan het nodig zijn dat je een hoger lidmaatschapsniveau hebt, dit kan je hier behalen:<br><br><a href="#SiteUrl#payment.php">#Upgrade#</a><br><br>Nogmaals dank voor het gebruik van onze services en we hopen dat je snel je match vindt! <br><br>#AdminName#<br>#SiteName#</td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

/* old format
$lang['message_received']['text'] = "Beste #FirstName#,

Je ontving net een bericht via SITENAME van de gebruiker #SenderName#'.

Bezoek <a href=\"#link#\">SITENAME</a> om dit bericht te beantwoorden.

Veel Success!
#AdminName#";


$lang['message_received']['html'] = "Beste #FirstName#,<br><br>Je hebt een bericht ontvangen via #siteName# van gebruiker #SenderName#.<br><br>Bezoek <a href=\"#link#\">#siteName#</a> om dit bericht te beantwoorden.<br><br>Veel Success!<br>#AdminName#";

New format below
*/
$lang['message_received_sub'] = 'SITENAME Bericht: RE: ter info...';
$lang['message_received']['text'] = "Beste #FirstName#,

U hebt een bericht ontvangen van SITENAME lid '#SenderName#'.

Gelieve <a href=\"#link#\">SITENAME</a> te bezoeken om dit bericht te beantwrden.

Veel success!
#AdminName#
SITENAME";

$lang['message_received']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td width="77" height="25">#email_hdr_left#</td><td width="493" class="module_head" >&nbsp;&nbsp;Nieuw bericht van #SenderName#! </td></tr><tr><td width="570" class="evenrow" colspan="2" style="padding: 5px;"><table border="0" cellspacing="2" cellpadding="2"><tr><td height="6"></td></tr><tr><td width="50%" valign="top" class="evenrow">
<table width="100%" border=0 cellspacing=0 cellpadding=2><tr><td width="25%" class="newshead">#From#:</td><td width="75%">#SenderName#</td></tr><tr><td class="newshead" >#TO#:</td><td>#UserName#</td></tr><tr><td class="newshead" >#Date#:</td><td>#MESSAGE_DATE# </td></tr><tr><td class="newshead">#Subject#:</td><td>#MSG_SUBJECT#</td></tr><tr><td colspan="2" height="6"></td></tr><tr><td colspan=2>Beste #FirstName#,<br><br>Je hebt een bericht ontvangen van #SenderName#.<br><br>Gelieve <a href=\"#link#\">SITENAME</a> te bezoeken om op dit bericht te reageren. <br><br>Veel Success!<br>#AdminName#<br>SITENAME<br></td></tr></table></td><td width="50%" valign="top" class="oddrow">#smallProfile#</td></tr></table></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

/* Old format
$lang['letter_featuredprofile_sub'] = '#SITENAME# - Featured Profielenlijst';
$lang['featured_profile_added']['html'] = "Beste #FirstName#,<br><br>Tot ons genoegen kunnen we je meedelen dat je profiel opgenomen werd in de featured profielenlijst op <a href=\"#link#\">#siteName#</a>.<br><br>Je profiel zal daar getoond worden van #FromDate# tot #UptoDate#.<br><br>Dit zal de zichtbaarheid van je profiel verhogen en je aantal potentiele matches verhogen.<br><br>Veel Success!<br>#AdminName#";

nieuweformat
*/
$lang['letter_featuredprofile_sub'] = 'SITENAME bericht: Je profiel zal binnenkort gefeatured worden!';
$lang['featured_profile_added']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td width="77" height="25" class="module_head">#email_hdr_left#</td><td width="493" class="module_head" >&nbsp;&nbsp;Je profiel zal binnenkort gefeatured worden! </td></tr><tr><td width="100%" class="evenrow" colspan="2" style="padding: 6px;"><table border="0" cellspacing="0" cellpadding="6"><tr><td height="6"></td></tr><tr><td width="100%" valign="top" class="evenrow">Dear #FirstName#,<br><br>Met veel plezier melden wij je dat jouw profiel gefeatured zal worden op <a href=\"#link#\">SITENAME</a>.<br><br>Je profiel zal gefeatured worden van <b>#FromDate#</b> tot <b>#UptoDate#</b>.<br><br>Dit zal de zichtbaarheid van je profiel verhogen en meer eventuele matches kunnen opleveren.<br><br>Veel Success!<br>#AdminName# <br>SITENAME<br></td></tr></table></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

/* old format

$lang['profile_activated_sub'] = '#SITENAME# - Je profiel werd geactiveerd';
$lang['profile_activated']['html'] = "Beste #FirstName#,<br><br>Dit is een automatisch bericht om je te laten weten dat je profiel op #siteName# geactiveerd werd. Je hebt het lidmaatschapsniveau #MembershipLevel#. Bezoek snel <a href=\"#link#\">#siteName#</a>.<br><br>Veel Success!<br>#AdminName#";

nieuweformat */

$lang['profile_activated_sub'] = 'SITENAME Bericht:  Uw profiel is geactiveerd!';
$lang['profile_activated']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td width="77" height="25" class="module_head">#email_hdr_left#</td><td width="493" class="module_head" >&nbsp;&nbsp;Je profiel werd geactiveerd! </td></tr><tr><td width="100%" class="evenrow" colspan="2" style="padding: 6px;"><table border="0" cellspacing="0" cellpadding="6"><tr><td height="6"></td></tr><tr><td width="100%" valign="top" class="evenrow">Beste #FirstName#,<br><br>Wij verwelkomen je met veel plezier op SITENAME. <br><br>Je profiel is geactiveerd met als lidmaatschapsniveau : <b>#MembershipLevel#</b> geldig tot #ValidDate#.<br><br>Bezoek ons snel op <a href=\"#link#\">SITENAME</a>.<br><br>Veel success!<br>#AdminName# <br>SITENAME<br></td></tr></table></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';
$lang['profile_activated']['text'] = "Beste #FirstName#,

Met veel plezier verwelkomen wij je op SITENAME.

Je profiel is geactiveerd en heeft lidmaatschapsniveau : <b>#MembershipLevel#</b> geldig tot <b>#ValidDate#</b>.

Bezoek ons snel op <a href=\"#link#\">SITENAME</a>.

Veel Success!
#AdminName#
SITENAME";

/* old format
$lang['profile_reactivated_sub'] = '#SITENAME# - Je profiel werd opnieuw geactiveerd';
$lang['profile_reactivated']['html'] = "Beste #FirstName#,<br><br>Dit is een automatisch bericht om je te laten weten dat je profiel op #siteName# opnieuw geactiveerd werd. Je hebt het lidmaatschapsniveau #MembershipLevel#. Bezoek snel <a href=\"#link#\">#siteName#</a>.<br><br>Veel Success!<br>#AdminName#";

New format
*/
$lang['profile_reactivated_sub'] = 'SITENAME bericht: Je profiel is opnieuw geactiveerd!';
$lang['profile_reactivated']['text'] = "Beste #FirstName#,

We zijn blij je te informeren dat je profiel opnieuw geactiveerd is met als niveau : <b>#MembershipLevel#</b> dat geldig blijft tot <b>#ValidDate#</b>.

Bezoek ons gauw op <a href=\"#link#\">SITENAME</a>.

Veel success!
#AdminName#
SITENAME";


$lang['profile_reactivated']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td width="77" height="25" class="module_head">#email_hdr_left#</td><td width="493" class="module_head" >&nbsp;&nbsp;Je profiel is opnieuw geactiveerd! </td></tr><tr><td width="100%" class="evenrow" colspan="2" style="padding: 6px;"><table border="0" cellspacing="0" cellpadding="6"><tr><td height="6"></td></tr><tr><td width="100%" valign="top" class="evenrow">Beste #FirstName#,<br><br>We zijn blij je te informeren dat je profiel opnieuw geactiveerd is met als niveau : <b>#MembershipLevel#</b> dat geldig blijft tot <b>#ValidDate#</b>.<br><br>Bezoek ons snel op <a href=\"#link#\">SITENAME</a>.<br><br>Veel success!<br>#AdminName# <br>SITENAME<br></td></tr></table></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

/* old format
$lang['added_banlist_sub'] = '#SITENAME# - Bericht met informatie';
$lang['added_buddylist_sub'] = '#SITENAME# - Bericht met informatie';
$lang['added_hotlist_sub'] = '#SITENAME# - Bericht met informatie';

$lang['added_buddylist']['html'] = "Beste #FirstName#,<br><br>Je werd toegevoegd aan de vriendenlijst van #SenderName#.<br><br>Bezoek <a href=\"#link#\">#siteName#</a> om het profiel van deze gebruiker te zien.<br><br>Veel Success!<br>#AdminName#";

$lang['added_hotlist']['html'] = "Beste #FirstName#,<br><br>Je werd toegevoegd aan de hotlijst van #SenderName#.<br><br>Bezoek <a href=\"#link#\">#siteName#</a> om het profiel van deze gebruiker te zien.<br><br>Veel Success!<br>#AdminName#";

$lang['added_banlist']['html'] = "Beste #FirstName#,<br><br>Je werd toegevoegd aan de banlijst van #SenderName#.<br><br>Bezoek <a href=\"#link#\">#siteName#</a> om het profiel van deze gebruiker te zien.<br><br>#AdminName#";

$lang['added_buddylist']['text'] = "Beste #FirstName#,

Je werd toegevoegd aan de vriendenlijst van #SenderName#.<

Bezoek <a href=\"#link#\">#siteName#</a> om het profiel van deze gebruiker te zien.<

Veel Success!
#AdminName#
SITENAME";

$lang['added_hotlist']['text'] = "Beste #FirstName#,

Je werd toegevoegd aan de hotlijst van #SenderName#.

Bezoek <a href=\"#link#\">#siteName#</a> om het profiel van deze gebruiker te zien.

Veel Success!
#AdminName#
SITENAME";

$lang['added_banlist']['text'] = "Beste #FirstName#,

Je werd toegevoegd aan de banlijst van #SenderName#.

Bezoek <a href=\"#link#\">#siteName#</a> om het profiel van deze gebruiker te zien.

#AdminName#";

New format
*/
$lang['added_list_sub'] = "SITENAME Bericht: U bent toegevoegd aan #SenderName#'s #ListName#!";
$lang['added_list']['text'] = "Beste #FirstName#,

Het lid #SenderName# heeft u aan de #ListName# toegevoegd.

Bezoek <a href=\"#link#\">SITENAME</a> om het profiel van de gebruiker te bekijken .

Veel Success!
#AdminName#
SITENAME";
$lang['added_list']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td width="77" height="25px" class="module_head">#email_hdr_left#</td><td width="493" class="module_head" >&nbsp;&nbsp;You haven been added to #SenderName#\'s #ListName#!</td></tr><tr><td width="100%" class="evenrow" colspan="2" style="padding: 6px;"><table border="0" cellspacing="0" cellpadding="6"><tr><td height="6"></td></tr><tr><td width="50%" valign="top" class="evenrow">Beste #FirstName#,<br><br>Het lid <b>#SenderName#</b> heeft u aan de <b>#ListName#</b> toegevoegd.<br><br>Bezoek <a href=\"#link#\">SITENAME</a> om het profiel van de gebruiker te bekijken .<br><br>Veel success!<br>#AdminName# <br>SITENAME<br></td><td valign="top">#smallProfile#</td></tr></table></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

/* old format
$lang['invite_a_friend_sub'] = 'Inviteer een vriend';
$lang['invite_a_friend']['html'] = "Hey,<br><br>Ik vond een coole datingsite op: #Link#.<br>Ik dacht dat dit je misschien kon interesseren.<br><br>#FromName#";

New format
*/
$lang['invite_a_friend_sub'] = "SITENAME Bericht: Uitnodiging van #FromName#! ";
$lang['invite_a_friend']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td width="77"  class="module_head" valign="top">#email_hdr_left#</td><td width="493" class="module_head" >&nbsp;&nbsp;Uitnodiging van #FromName#! </td></tr><tr><td width="100%" class="evenrow" colspan="2" style="padding: 5px;"><table border="0" cellspacing="0" cellpadding="6" width="100%"><tr><td height="6"></td></tr><tr><td width="100%" valign="top" class="evenrow">Hallo,<br><br>Ik heb onlangs een coole datingsite gevonden: <a href=\"#SiteUrl#\"><b>SITENAME</b></a><br>Ik dacht dat dit wel iets voor jou zou kunnen zijn<br><br>Bezoek <a href=\"#SiteUrl#\">SITENAME</a>.<br><br>Veel success!<br>#FromName# <br><br></td></tr></table></td></tr><tr><td height="12" class="evenrow" colspan="2" ></td></tr></table>';

/* old format
$lang['message_read_sub'] = '#SITENAME# - Bericht met informatie';
$lang['message_read']['html'] = "Beste #FirstName#,<br><br>Het bericht verstuurd naar '#RecipientName#' werd gelezen.<br><br>Veel Success!<br>#AdminName#";

New format */
$lang['message_read_sub'] = 'SITENAME Bericht: Je bericht naar #RecipientName# is gelezen!';
$lang['message_read']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td width="77" height="25" class="module_head">#email_hdr_left#</td><td width="493" class="module_head" >&nbsp;&nbsp;Je bericht naar #RecipientName# is gelezen! </td></tr><tr><td width="100%" class="evenrow" colspan="2" style="padding: 5px;"><table border="0" cellspacing="0" cellpadding="6"><tr><td height="6"></td></tr><tr><td width="50%" valign="top" class="evenrow">Beste #FirstName#,<br><br>Het bericht dat je hebt verzonden naar <b>#RecipientName#</b> is gelezen.<br><br>Bezoek <a href=\"#link#\">SITENAME</a> om het profiel van de gebruiker te bekijken.<br><br>Veel Success!<br>#AdminName# <br>SITENAME<br></td><td valign="top">#smallProfile#</td></tr></table></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

/* old format
$lang['email_feedback_subject'] = 'Feedback van een gebruiker van '.SITENAME;
$lang['feedback_email_to_admin']['text'] = 'Beste site-beheerder,

Je ontving net commentaar van een bezoeker van je site. De details zijn:

Titel: #txttitle#
Naam: #txtname#
Email: #txtemail#
Land: #txtcountry#
Commentaar: #txtcomments#

Bedankt,
#SITENAME# Daemon';

$lang['feedback_email_to_admin']['html'] = 'Beste site-beheerder,<br><br>Je ontving net commentaar van een bezoeker van je site. De details zijn:<br><br>Titel: #txttitle#<br>Naam: #txtname#<br>Email: #txtemail#<br>Land: #txtcountry#<br>Commentaar: #txtcomments#<br><br>Bedankt,<br>#SITENAME# Daemon';

New format */
$lang['email_feedback_subject'] = 'SITENAME Bericht: Feedback van lid ';
$lang['feedback_email_to_admin']['text'] = 'Beste Site-beheerder,

U hebt zonet feedback ontvangen van een lid. De details zijn:

Titel: #txttitle#
Naam: #txtname#
Email: #txtemail#
Land: #txtcountry#
Opmerkingen: #txtcomments#

Bedankt,
SITENAME Daemon';
$lang['feedback_email_to_admin']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td width="77" height="25" class="module_head">#email_hdr_left#</td><td width="493" class="module_head" >&nbsp;&nbsp;Feedback van een gebruiker </td></tr><tr><td width="100%" class="evenrow" colspan="2" style="padding: 5px;"><table border="0" cellspacing="0" cellpadding="0"><tr><td height="6"></td></tr><tr><td width="100%" valign="top" class="evenrow">Beste site-beheerder,<br><br>Je hebt zonet feedback ontvangen van een lid. De details zijn:<br><br><table cellspacing="4" cellpadding="2" border="0" width="100%"><tr><td width="20%"> Titel:</td><td width="80%">#txttitle# </td></tr><tr><td>Name:</td> <td>#txtname#</td></tr><tr><td>Email:</td><td>#txtemail#</td></tr><tr><td>Land:</td><td>#txtcountry#</td></tr><tr><td>Opmerkingen:</td><td>#txtcomments#</td></tr></table><br>Bedankt,<br>SITENAME Daemon<br><br></td></tr></table></td></tr></table> ';

/* old format
$lang['forgot_password_sub'] = 'Verzoek om paswoord';
$lang['forgot_password']['text'] = "Beste #Name#,

Je leden-ID: #ID#
Je wachtwoord:  #Password#

om in te loggen, bezoek: #LoginLink#.

Bedankt voor het gebruik van onze diensten!

#SiteTitle# mail delivery system
<Automatisch gegenereede mail, gelieve niet te reageren>";
$lang['forgot_password']['html'] = "Beste #Name#,<br><br>Je leden-ID: #ID#<br>Je wachtwoord: #Password#<br><br>Om in te loggenm bezoek: #LoginLink#.<br><br>Bedankt om gebruik te maken van onze diensten!<br><br>#SiteTitle# mail delivery system<br><Automatisch gegenereerde mail, gelieve niet te antwoorden>";



New format */
$lang['forgot_password_sub'] = 'SITENAME Bericht: Je verzoek tot resetten van wachtwoord';
$lang['forgot_password']['text'] = "Beste #Name#,

Dit heeft betrekking tot je verzoek om je wachtwoord te resetten

Je leden-ID: #ID#
Je nieuwe wachtwoord:  #Password#

Om in te loggen, ga je naar: #LoginLink#.

Bedankt voor het gebruik van onze services!

#AdminName#
SITENAME";
$lang['forgot_password']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td width="77" height="25" class="module_head">#email_hdr_left#</td><td width="493" class="module_head" >&nbsp;&nbsp;Je verzoek tot resetten van je wachtwoord</td></tr><tr><td width="100%" class="evenrow" colspan="2" style="padding: 5px;"><table border="0" cellspacing="0" cellpadding="0"><tr><td height="6"></td></tr><tr><td width="100%" valign="top" class="evenrow">Beste #Name#,<br><br>Dit heeft betrekking tot uw verzoek om uw wachtwoord te resetten<br><br>Je leden-ID: <b>#ID#</b><br>Je nieuwe wachtwoord: <b>#Password#</b><br><br>Om in te loggen ga je naar: <a href=\"#LoginLink#\">SITENAME</a>.<br><br>Bedankt voor het gebruik van onze services!<br><br>#AdminName#<br>SITENAME<br></td></tr> </table></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

/* old format
$lang['expiry_ltr_sub'] = 'Herinnering vervallen lidmaatschap';
$lang['mship_expired_note']['text'] = "Beste #FirstName#,

Dit is een automatisch bericht om je te melden dat je lidmaatschap #MembershipLevel# op #siteName# verliep op #ExpiryDate#.

Gelive in te loggen op <a href=\"#link#\">#siteName#</a> om je lidmaatschap te vernieuwen en van onze diensten te blijven genieten.

Veel Success!
#AdminName#";
$lang['mship_expired_note']['html'] = "Beste #FirstName#,<br><br>Dit is een automatisch bericht om je te melden dat je lidmaatschap #MembershipLevel# op #siteName# verliep op #ExpiryDate#.<br><br>Gelieve in te loggen op <a href=\"#link#\"> #siteName#</a> om je lidmaatschap te vernieuwen en van onze diensten te blijven genieten.<br><br>Veel Success!<br>#AdminName#";

New format */
$lang['expiry_ltr_sub'] = 'SITENAME bericht: Herinnering van verval lidmaatschap';

$lang['mship_expired_note']['text'] = "Beste #FirstName#,

Bedankt voor het gebruik van SITENAME!

Dit is om je te informeren dat uw lidmaatschapsniveau #MembershipLevel# op SITENAME vervalt op #ExpiryDate#.

Gelieve <a href=\"#link#\">in te loggen op SITENAME</a> om uw lidmaatschap te vernieuwen en gebruik te blijven maken van onze diensten

Veel Success!
#AdminName#
SITENAME";

$lang['mship_expired_note']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td width="77" height="25" class="module_head">#email_hdr_left#</td><td width="493" class="module_head" >&nbsp;&nbsp;Je lidmaatschap is vervallen! </td></tr><tr><td width="100%" class="evenrow" colspan="2" style="padding: 5px;"><table border="0" cellspacing="0" cellpadding="6"><tr><td height="6"></td></tr><tr><td width="100%" valign="top" class="evenrow">Beste #FirstName#,<br><br>Bedankt om gebruik te maken van SITENAME!<br><br>Dit is om je te informeren dat je lidmaatschapsniveau van <b>#MembershipLevel#</b> op <a href="\"#link#\"><b>SITENAME</b></a> vervalt op <b>#ExpiryDate#</b>.<br><br>Gelieve <a href=\"#link#\">in te loggen op SITENAME</a> om je lidmaatschap te vernieuwen en gebruik te blijven maken van onze diensen.<br><br>Veel Success!<br>#AdminName# <br>SITENAME<br></td></tr></table></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

/* old format
$lang['mship_expiry_note']['text'] = 'Beste #FirstName#,

Dit is een automatische mail om je te informeren dat je lidmaatschap bij #siteName# verloopt op #ExpiryDate#.

Gelieve in te loggen op <a href="#link#">#siteName#</a> en vernieuw lidmaatschap.

Veel Success!
#AdminName#';

$lang['mship_expiry_note']['html'] = 'Beste #FirstName#,<br><br>Dit is een automatische mail om je te informeren dat je lidmaatschap bij #siteName# verloopt op #ExpiryDate#.<br><br>Gelieve in te loggen op <a href="#link#">#siteName#</a> en je lidmaatschap te vernieuwen.<br><br>Veel Success!<br>#AdminName#';


New format */
$lang['mship_expiry_note']['text'] = 'Beste #FirstName#,

Bedankt voor het gebruik van SITENAME!

Dit is om je te informeren dat je lidmaatschapsniveau van #MembershipLevel# op SITENAME zal vervallen op #ExpiryDate#.

Gelieve <a href="#link#">in te loggen op SITENAME</a> en je lidmaatschap te vernieuwen om zo van onze diensten gebruik te blijven maken.

Veel Success!
#AdminName#
SITENAME';

$lang['mship_expiry_note']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td width="77" height="25" class="module_head">#email_hdr_left#</td><td width="493" class="module_head" >&nbsp;&nbsp;Je lidmaatschap zal spoedig vervallen! </td></tr><tr><td width="100%" class="evenrow" colspan="2" style="padding: 5px;"><table border="0" cellspacing="0" cellpadding="6"><tr><td height="6"></td></tr><tr><td width="100%" valign="top" class="evenrow">Beste #FirstName#,<br><br>Bedankt om gebruik te maken van SITENAME!<br><br>Dit is om je te informeren dat je lidmaatschapsniveau van <b>#MembershipLevel#<b> op SITENAME zal vervallen op <b>#ExpiryDate#<b>.<br><br>Gelieve <a href=\"#link#\">in te loggen op SITENAME</a> en je lidmaatschap te vernieuwen om zo van onze diensten gebruik te blijven maken.<br><br>Veel Success!<br>#AdminName# <br>SITENAME<br></td></tr></table></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

/* Newly added - mail to be sent to member when admin changes lidmaatschap level */

$lang['profile_membership_changed_sub'] = 'SITENAME Bericht:  Je lidmaatschap niveau is gewijzigd!';
$lang['profile_membership_changed']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td width="77" height="25" class="module_head">#email_hdr_left#</td><td width="493" class="module_head" >&nbsp;&nbsp;Je lidmaatschapsniveau is gewijzigd! </td></tr><tr><td width="100%" class="evenrow" colspan="2" style="padding: 5px;"><table border="0" cellspacing="0" cellpadding="3"><tr><td height="4"></td></tr><tr><td width="100%" valign="top" class="evenrow">Beste #FirstName#,<br><br>Je huidig lidmaatschap is gewijzigd van <b>#CurrentLevel#</b> naar <b>#NewLevel#</b> dat zal vervallen op<b>#ValidDate#</b>.<br><br>Breng ons snel een bezoek : <a href=\"#link#\">SITENAME</a>.<br><br>Veel Success!<br>#AdminName# <br>SITENAME<br></td></tr></table></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';


$lang['profile_membership_changed']['text'] = "Beste #FirstName#,

Je huidig lidmaatschapsniveau <b>#CurrentLevel#</b> is gewijzigd naar <b>#NewLevel#</b> dat zal vervallen op <b>#ValidDate#</b>.

Breng ons snel een bezoek op <a href=\"#link#\">SITENAME</a>.

Veel Success!
#AdminName#
SITENAME
";

$lang['comment_received_sub'] = 'SITENAME Bericht: Een gebruiker heeft een nieuwe opmerking in je blog geplaatst';
$lang['comment_received']['text'] = "Beste #FirstName#,

Je hebt een opmerking ontvangen van SITENAME gebruiker '<b>#SenderName#</b>'.

Gelieve <a href=\"#link#\"><b>SITENAME</b></a> te bezoeken om de opmerking van '<b>#SenderName#</b> te lezen'.

Veel Success!
#AdminName#
SITENAME";

$lang['comment_received']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td width="77" height="25" class="module_head">#email_hdr_left#</td><td width="493" class="module_head" >&nbsp;&nbsp;Een gebruiker heeft zonet een nieuwe opmerking in je blog geplaatst! </td></tr><tr><td width="100%" class="evenrow" colspan="2" style="padding: 5px;"><table border="0" cellspacing="0" cellpadding="6"><tr><td height="6"></td></tr><tr><td width="100%" valign="top" class="evenrow">Beste #FirstName#,<br><br>Je hebt zonet een opmerking ontvangen via SITENAME van gebruiker <b>#SenderName#</b>.<br><br>Gelieve <a href=\"#link#\"><b>SITENAME</b></a> te bezoeken om de opmerking van <b>#SenderName#</b> te lezen.<br><br>Veel Success!<br>#AdminName# <br>SITENAME<br></td></tr></table></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';
$lang['aff_added_sub'] = 'SITENAME bericht: Je bent toegevoegd als partner!';
$lang['aff_added']['text'] = "Beste #Name#,

We zijn blij je te mogen meedelen dat je bent toegevoegd als partner op SITENAME.

Je ID: #Affid#
Je wachtwoord: #Password#

Gelieve <a href=\"#SiteUrl#\"><b>SITENAME</b></a> te bezoeken en in te loggen in de partnersectie en je wachtwoord zo spoedig mogelijk te wijzigen.

Veel Success!
#AdminName#
SITENAME";

$lang['aff_added']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td width="77" height="25" class="module_head">#email_hdr_left#</td><td width="493" class="module_head" >&nbsp;&nbsp;U bent toegevoegd als affiliaat! </td></tr><tr><td width="100%" class="evenrow" colspan="2" style="padding: 5px;"><table border="0" cellspacing="0" cellpadding="6"><tr><td height="6"></td></tr><tr><td width="100%" valign="top" class="evenrow">Beste #Name#,<br><br>Wij zijn blij je te mogen meedelen dat je bent toegevoegd als partner op SITENAME.<br><br><b>Je ID: #Affid#</b><br><b>Je Wachtwoord: #Password#</b><br><br>Gelieve <a href=\"#SiteUrl#\"><b>SITENAME</b></a> te bezoeken en in te loggen op de partnersectie en je wachtwoord zo spoedig mogelijk te wijzigen.<br><br>Veel Success!<br>#AdminName# <br>SITENAME<br></td></tr></table></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['aff_newpwd_sub'] = 'SITENAME Message: Uw affiliate account!';
$lang['aff_newpwd']['text'] = "Beste #Name#,

Een nieuw wachtwoord is gegenereerd voor je partneraccount op SITENAME zoals je hebt gevraagd.

Je nieuw wachtwoord: #Password#

Gelieve <a href=\"#SiteUrl#\"><b>SITENAME</b></a> te bezoeken, hierna kan je inloggen op de partnersectie. We raden aan het wachtwoord zo spoedig mogelijk te wijzigen.

Veel Success!
#AdminName#
SITENAME";

$lang['aff_newpwd']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td width="77" height="25" class="module_head">#email_hdr_left#</td><td width="493" class="module_head" >&nbsp;&nbsp;Je partneraccount! </td></tr><tr><td width="100%" class="evenrow" colspan="2" style="padding: 5px;"><table border="0" cellspacing="0" cellpadding="6"><tr><td height="6"></td></tr><tr><td width="100%" valign="top" class="evenrow">Beste #Name#,<br><br>Een nieuw wachtwoord is gegenereerd voor je partneraccount op SITENAME zoals je hebt gevraagd.<br><br><b>Je Wachtwoord: #Password#</b><br><br>Gelieve <a href=\"#SiteUrl#\"><b>SITENAME</b></a> te bezoeken, hierna kan je inloggen op de partnersectie. We raden aan het wachtwoord zo spoedig mogelijk te wijzigen.<br><br>Veel Success!<br>#AdminName# <br>SITENAME<br></td></tr></table></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['add_affiliate'] = 'Voeg een partner toe';
$lang['mod_affiliate'] = 'Wijzig een partner';
$lang['aff_modified'] = 'Partnersectie is gewijzigd';

$lang['newuser']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head"><div class="module_head">#email_hdr_left#</div></td><td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;Nieuwe gebruiker ingeschreven!</div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" ><div class="evenrow"><table border="0" cellspacing="0" cellpadding="5"><tr><td width="100%" valign="top" class="evenrow">Beste sitebeheerder,<br><br>Een nieuwe gebruiker heeft zich ingeschreven op #siteName#.<br><br>Gebruikersnaam: <a href="#SiteUrl#admin/showprofile.php?username=#UserName#">#UserName#</a><br><br>#AdminName# <br>#siteName#<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['newuser']['text'] = "Beste Site-beheerder,

Een nieuwe gebruiker heeft zich ingeschreven op #SiteName#.

Gebruikersnaam: #UserName#

#AdminName#
SITENAME";

$lang['newuser_sub'] = 'Nieuwe gebruiker ingeschreven';

/* Following user options are managed. Please modify only the description and not these keys */

$lang['user_choices'] = array(
	'email_message_received' 	=> "Stuur email wanneer nieuw bericht ontvangen is.",
	'email_wink_received'		=> "Stuur email wanneer naar me knipoogt.",
	'email_blog_commented'		=> "Stuur email wanneer iemand een opmerking in mijn blog plaatst.",
	'email_mship_expiry'		=> "Stuur lidmaatschap-verval emails.",
	'email_message_read'		=> "Stuur email wanneer ontvanger van mijn bericht het gelezen heeft.",
	'email_buddy_list'			=> "Stuur email wanneer iemand me aan zijn vriendenlijst toevoegd.",
	'email_ban_list'			=> "Stuur email wanneer iemand me aan zijn banlijst toevoegd.",
	'email_hot_list'			=> "Stuur email wanneer iemand me aan zijn hotlijst toevoegd.",
	"allow_buddy_view_album"	=> "Sta gebruikers in mijn vriendenlijst toe prive albums te bekijken.",
	"allow_hotlist_view_album"	=> "Sta gebruikers in mijn hot list toe prive albums te bekijken.",
	'email_match_mail_days'		=> "Frequentie, in dagen, waarop \'my matches\' emails verzonden mogen worden. Geef 0 in indien je deze emails niet wil ontvangen.",
	);
$lang['mysettings_updated'] = 'Je mail-ontvang voorkeuren zijn aangepast';
$lang['mysettings_updated'] = 'Je mail-ontvang voorkeuren zijn aangepast';
$lang['resend_conflink_hdr'] = 'Herzend de bevestigingsmail';
$lang['resend_conflink_hdr1'] = 'Je bevestigingsmail niet ontvangen of verloren? Geef het email adres in waarmee je geregistreerd hebt om de mail opnieuw te ontvangen';
$lang['resend_conflink_msg'] = 'Je bevestigingsmail is opnieuw verzonden.';
$lang['resend_conflink_msg1'] = 'Gelieve het email adres waarmee u hebt geregistreerd in te voeren.';
$lang['resend_conflink_err1'] = 'Je hebt je profiel reeds bevestigd. Gelieve gebruik te maken van de <a href="forgotpass.php">Wachtwoord vergeten</a> link om een nieuw wachtwoord te genereren.';
$lang['about_me'] = 'Over mezelf';
$lang['about_me_hlp'] = 'Geef een korte omschrijving van jezelf, op deze manier zullen anderen sneller intresse in jou tonen.';
$lang['aff_forgot_pass'] = 'Je wachtwoord vergeten? Geef je mailadres in om een nieuw wachtwoord te ontvangen:';
$lang['send_new_password'] = 'Verstuur nieuw wachtwoord';
$lang['not_a_member'] = 'Nog geen lid?';
$lang['login_reminded'] = 'Ontvang je gebruikersnaam en wachtwoord opnieuw.';
$lang['lost_confemail'] = 'De bevestigingsmail verloren?';
$lang['couple_usernames'] = 'Koppel / Groep gebruikersnamen';
$lang['couple_usernames_hlp'] = 'Een koppel of groep bestaat uit twee of meer individuen. Gelieve de gebruikersnamen van de leden van dit koppel of groep in het tekstveld hier benenden in te voeren. Bijvoorbeeld: gebruiker_1,gebruiker_2,gebruiker_3. Deze leden moeten reeds individuele profielen hebben.';
$lang['blog']['del01'] = 'Bent je zeker dat je deze opmerking wil verwijderen?';
$lang['blog']['del02'] = 'Bent je zeker dat je de geselecteerde opmerking wil verwijderen ';
$lang['blog']['del03'] = 'Wil je deze installatie werkelijk ongedaan maken?';
$lang['feat_prof_del_msg'] = 'Wil je dit profiel van de featured profielenlijst verwijderen?';
$lang['feat_prof_deleted'] = 'Het geselecteerde profiel is verwijderd van de featured profielenlijst.';

$lang['mymatches_sub'] = 'SITENAME Bericht: Profielen die bij uw zoekopdracht matchen!';
$lang['mymatches_body']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td width="77" height="25">#email_hdr_left#</td><td width="493" class="module_head" >&nbsp;&nbsp;Profielen die bij uw zoekopdracht matchen! </td></tr><tr><td width="570" class="evenrow" colspan="2" style="padding: 5px;"><table border="0" cellspacing="2" cellpadding="2"><tr><td height="6"></td></tr><tr><td class="evenrow">Beste #FirstName#,<br><br>Hier volgt een lijst van alle profielen die aan uw criteria voldoen.</td></tr><tr><td height="10" class="evenrow"> </td></tr><tr><td valign="top" class="evenrow">#matchedProfiles#</td></tr><tr><td height="10" class="evenrow"> </td></tr><tr><td class="evenrow">Gelieve <a href=\"#link#\">SITENAME</a> te bezoeken om deze profielen te bekijken.<br><br>Veel Success!<br>#AdminName#<br>SITENAME<br></td></tr></table> </td></tr></table>';
$lang['on'] = ' on ';

$lang['use_seo_username'] = 'Gebruik profiel gebruikersnaam als parameter in de URL. Deze optie gebruiken zal profiel URL\'s het formaat "domain/gebruikersnaam" geven. Deze optie niet gebruiken geeft URL\'s in het formaat "domain/id.htm"';
$lang['leave_blank_no_change'] = '(blanko laten indien niets verranderd)';

$lang['adminltr']['html']='<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td width="77" height="25" class="module_head">#email_hdr_left#</td><td width="493" class="module_head" >&nbsp;&nbsp;#Subject#</td></tr><tr><td width="100%" class="evenrow" colspan="2" style="padding: 5px;"><table border="0" cellspacing="0" cellpadding="6"><tr><td height="6"></td></tr><tr><td width="100%" valign="top" class="evenrow">#LetterContent#</td></tr></table></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['adminltr']['text'] = '#LetterContent#';

$lang['sections'] = array(
	'1'	=> 	'Basis informatie',
	'2'	=>	'Voorkomen',
	'3'	=>	'Carrière',
	'4'	=>	'Lifestyle',
	'5'	=>	'Interesses'
);

/* Following is for mail encoding */
$lang['mail_text_encoding'] = '7bit';
$lang['mail_html_encoding'] = '7bit';
$lang['mail_html_charset'] = 'ISO-8859-1';
$lang['mail_text_charset'] = 'ISO-8859-1';
$lang['mail_head_charset'] = 'ISO-8859-1';

$lang['status_disp'] = array(
	'approval' => 'Wachtend',
	'active' => 'Actief',
	'rejected' => 'Afgewezen',
	'suspended' => 'Afgeschaft',
	/* added in 1.1.0 */
	'cancel' => 'Annulatie'
	);

$lang['status_enum'] = array(
	'approval' => 'Wachtende',
	'active' => 'Actief',
	'rejected' => 'Afgewezen',
	'suspended' => 'Uitgesteld',
	);

$lang['status_act'] = array(
	'approval' => 'Wachtend',
	'active' => 'Actief',
	'rejected' => 'Afgewezen',
	'suspended' => 'Afgeschaft',
	/* added in 1.1.0 */
	'cancel' => 'Annulatie'
	);

?>