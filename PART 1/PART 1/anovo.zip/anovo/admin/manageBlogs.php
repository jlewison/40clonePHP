<?php
require_once ('../common/config.inc.php');
$CFG['lang']['include_files'][] = 'admin/includes/languages/%s/manageBlogs.php';
$CFG['html']['header'] = 'admin/includes/languages/%s/html_header.php';
$CFG['html']['footer'] = 'admin/includes/languages/%s/html_footer.php';
$CFG['lang']['include_files'][] = 'common/languages/%s/help.inc.php';
$CFG['lang']['include_files'][] = 'common/configs/config_article.inc.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['mods']['include_files'][] = 'common/classes/class_ListRecordsHandler.lib.php';
require ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class manageBlogs extends ListRecordsHandler
{
		public function buildSortQuery()
		{
				$this->sql_sort = $this->fields_arr['orderby_field'] . ' ' . $this->fields_arr['orderby'];
		}
		public function buildConditionQuery()
		{
				$this->sql_condition = '';
		}
		public function updateBlog()
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['blogs'] . ' SET subject=' . $this->dbObj->Param('subject') . ', message=' . $this->dbObj->Param('message') . ', status=' . $this->dbObj->Param('status') . ', blog_category_id=' . $this->dbObj->Param('blog_category_id') . ', accept_comments=' . $this->dbObj->Param('accept_comments') . ' WHERE blog_id=' . $this->dbObj->Param('blog_id');
				$param_arr = array($this->fields_arr['subject'], $this->fields_arr['message'], $this->fields_arr['status'], $this->fields_arr['blog_category_id'], $this->fields_arr['accept_comments'], $this->fields_arr['blog_id']);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, $param_arr);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function insertBlog()
		{
				$sql = 'INSERT ' . $this->CFG['db']['tbl']['blogs'] . ' SET subject=' . $this->dbObj->Param('subject') . ', message=' . $this->dbObj->Param('message') . ', accept_comments=' . $this->dbObj->Param('accept_comments') . ', user_id=' . $this->dbObj->Param('user_id') . ', blog_category_id=' . $this->dbObj->Param('blog_category_id') . ', status=' . $this->dbObj->Param('status') . ', date_added=NOW()';
				$param_arr = array($this->fields_arr['subject'], $this->fields_arr['message'], $this->fields_arr['accept_comments'], $this->CFG['user']['user_id'], $this->fields_arr['blog_category_id'], $this->fields_arr['status']);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, $param_arr);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function populateBlogsValue()
		{
				$sql = 'SELECT blog_id, subject, message, accept_comments, user_id,blog_category_id,  status, date_added' . ' FROM ' . $this->CFG['db']['tbl']['blogs'] . ' WHERE blog_id=' . $this->dbObj->Param('blog_id');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['blog_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($row = $rs->FetchRow())
				{
						$this->fields_arr['subject'] = $row['subject'];
						$this->fields_arr['message'] = $row['message'];
						$this->fields_arr['accept_comments'] = $row['accept_comments'];
						$this->fields_arr['status'] = $row['status'];
						$this->fields_arr['blog_category_id'] = $row['blog_category_id'];
						return true;
				}
				return false;
		}
		public function showBlogsList()
		{
				while ($row = $this->fetchResultRecord())
				{
						$anchor = 'anchor_' . $row['blog_id'];
						$div_id = 'selPreview' . $row['blog_id'];
?>
				<tr>
					<td><input type="checkbox" class="clsCheckRadio" name="blog_id[]" onClick="disableHeading('blogsListForm');" value="<?php echo $row['blog_id']; ?>"  tabindex="<?php echo $this->getTabIndex(); ?>" /></td>
					<td class="clsBlogDescription"><a target="_blank" href="<?php echo getUrl($this->CFG['site']['url'] . 'members/blogComment.php', $this->CFG['site']['url'] . 'members/blogcomment/', false); ?>?blog_id=<?php echo $row['blog_id']; ?>"><?php echo wordWrapManual($row['subject'], 35); ?></a></td>
					<td><?php echo $row['total_comments']; ?></td>
					<td><?php echo $row['total_views']; ?></td>
					<td><?php echo $row['accept_comments']; ?></td>
					<td><?php echo $row['abuse_count']; ?></td>
					<td><?php echo $row['status']; ?></td>
					<td><?php echo $row['date_added']; ?></td>
					<td class="clsPreviewEdit">
						<p><a id="<?php echo $anchor; ?>" href="<?php getUrl('manageBlogs.php', 'manageBlogs.php'); ?>?act=edt&amp;blog_id=<?php echo $row['blog_id']; ?>&amp;start=<?php echo $this->fields_arr['start']; ?>"><?php echo $this->LANG['edit']; ?></a></p>
					</td>
				</tr>
<?php
				}
		}
		public function deleteSelectedBlogs()
		{
				$blog_ids = addslashes($this->fields_arr['blog_id']);
				$blog_ids = explode(',', $blog_ids);
				$blog_ids = '\'' . implode('\',\'', $blog_ids) . '\'';
				$sql = 'DELETE FROM ' . $this->CFG['db']['tbl']['blogs'] . ' WHERE blog_id IN(' . $blog_ids . ')';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$sql = 'DELETE FROM ' . $this->CFG['db']['tbl']['blog_comment'] . ' WHERE blog_id IN(' . $blog_ids . ')';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function resetFieldsArray()
		{
				$this->setFormField('subject', '');
				$this->setFormField('message', '');
				$this->setFormField('accept_comments', 'Yes');
				$this->setFormField('act', '');
				$this->setFormField('blog_category_id', '');
				$this->setFormField('blog_id', '');
				$this->setFormField('status', 'Active');
		}
		public function doDefaultValidation()
		{
				$this->chkIsNotEmpty('subject', $this->LANG['err_tip_compulsory']);
				$this->chkIsNotEmpty('message', $this->LANG['err_tip_compulsory']);
				$this->chkIsNotEmpty('blog_category_id', $this->LANG['err_tip_compulsory']);
		}
		public function changeStatus($status)
		{
				$blog_ids = addslashes($this->fields_arr['blog_id']);
				$blog_ids = explode(',', $blog_ids);
				$blog_ids = '\'' . implode('\',\'', $blog_ids) . '\'';
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['blogs'] . ' SET status=' . $this->dbObj->Param('status') . ' WHERE blog_id IN(' . $blog_ids . ')';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($status));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function populateBlogCatagory($err_tip = '')
		{
				$sql = 'SELECT blog_category_id, blog_category_name FROM ' . $this->CFG['db']['tbl']['blog_category'] . ' WHERE  blog_category_status=\'Yes\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if (!$rs->PO_RecordCount()) return;
				$highlight_value = $this->fields_arr['blog_category_id'];
?>
				<select name="blog_category_id" id="blog_category_id" tabindex="<?php echo $this->getTabIndex(); ?>">
<?php
				$inc = 1;
				while ($row = $rs->FetchRow())
				{
						$selected = ($highlight_value == $row['blog_category_id']) ? ' SELECTED' : '';
?>
						<option value="<?php echo $row['blog_category_id']; ?>"<?php echo $selected; ?>><?php echo $row['blog_category_name']; ?></option>
<?php
				}
?>
				</select>
<?php
		}
}
$manageBlogs = new manageBlogs();
$manageBlogs->setDBObject($db);
$manageBlogs->makeGlobalize($CFG, $LANG);
if (!chkAllowedModule(array('blog'))) Redirect2URL($CFG['redirect']['dsabled_module_url']);
$manageBlogs->setPageBlockNames(array('msg_form_success', 'msg_form_error', 'blogsEditor', 'blogsEditBlock', 'selBlogsListBlock'));
$manageBlogs->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$manageBlogs->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$manageBlogs->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$manageBlogs->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$manageBlogs->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$manageBlogs->setFormField('orderby_field', 'blog_id');
$manageBlogs->setFormField('orderby', 'DESC');
$manageBlogs->setFormField('start', '0');
$manageBlogs->setFormField('numpg', $CFG['data_tbl']['numpg']);
$manageBlogs->setCSSColumnHeaderCellAscSortClasses(array('clsColumnHeaderCellAscSort1', 'clsColumnHeaderCellAscSort2', 'clsColumnHeaderCellAscSort3', 'clsColumnHeaderCellAscSort4', 'clsColumnHeaderCellAscSort5'));
$manageBlogs->setCSSColumnHeaderCellDefaultClass('clsColumnHeaderCellDefault');
$manageBlogs->setCSSColumnHeaderCellDescSortClasses(array('clsColumnHeaderCellDscSort1', 'clsColumnHeaderCellDscSort2', 'clsColumnHeaderCellDscSort3', 'clsColumnHeaderCellDscSort4', 'clsColumnHeaderCellDscSort5'));
$manageBlogs->setMinRecordSelectLimit(2);
$manageBlogs->setMaxRecordSelectLimit($CFG['data_tbl']['max_record_select_limit']);
$manageBlogs->setNumPerPageListArr($CFG['data_tbl']['numperpage_list_arr']);
$manageBlogs->setTableNames(array($CFG['db']['tbl']['blogs']));
$manageBlogs->setReturnColumns(array('blog_id', 'subject', 'accept_comments', 'total_comments', 'total_views', 'user_id', 'IF (status=\'Active\', \'Active\', \'Inactive\') AS status', 'date_added', 'abuse_count', 'abuse_count'));
$manageBlogs->resetFieldsArray();
$manageBlogs->setPageBlockShow('blogsEditor');
$manageBlogs->setPageBlockShow('selBlogsListBlock');
$manageBlogs->sanitizeFormInputs($_REQUEST);
if ($manageBlogs->isFormPOSTed($_POST, 'add_submit'))
{
		$manageBlogs->doDefaultValidation();
		if ($manageBlogs->isValidFormInputs())
		{
				$manageBlogs->setFormField('message', html_entity_decode($manageBlogs->getFormField('message'), ENT_QUOTES, $CFG['site']['charset']));
				$manageBlogs->insertBlog();
				$manageBlogs->setCommonErrorMsg($LANG['msg_success_added']);
				$manageBlogs->setPageBlockShow('msg_form_success');
				$manageBlogs->resetFieldsArray();
		}
		else
		{
				$manageBlogs->setCommonErrorMsg($LANG['msg_sorry_error']);
				$manageBlogs->setPageBlockShow('msg_form_error');
		}
}
else
		if ($manageBlogs->isFormPOSTed($_POST, 'update_submit'))
		{
				$manageBlogs->doDefaultValidation();
				if ($manageBlogs->isValidFormInputs())
				{
						$manageBlogs->setFormField('message', html_entity_decode($manageBlogs->getFormField('message'), ENT_QUOTES, $CFG['site']['charset']));
						$manageBlogs->updateBlog();
						$manageBlogs->setCommonErrorMsg($LANG['msg_success_update']);
						$manageBlogs->setPageBlockShow('msg_form_success');
						$manageBlogs->resetFieldsArray();
				}
				else
				{
						$manageBlogs->setCommonErrorMsg($LANG['msg_sorry_error']);
						$manageBlogs->setPageBlockShow('msg_form_error');
						$manageBlogs->setPageBlockShow('blogsEditBlock');
				}
		}
		else
				if ($manageBlogs->isFormGETed($_GET, 'act'))
				{
						if ($manageBlogs->getFormField('act') == 'edt')
						{
								if ($manageBlogs->populateBlogsValue()) $manageBlogs->setPageBlockShow('blogsEditBlock');
						}
				}
				else
						if ($manageBlogs->isFormPOSTed($_POST, 'action_blog'))
						{
								if ($manageBlogs->getFormField('act') == 'delete')
								{
										$manageBlogs->deleteSelectedBlogs();
										$manageBlogs->setCommonErrorMsg($LANG['success_deleted']);
								}
								if ($manageBlogs->getFormField('act') == 'Toactivate')
								{
										$manageBlogs->changeStatus('Toactivate');
										$manageBlogs->setCommonErrorMsg($LANG['success_toactivate']);
								}
								if ($manageBlogs->getFormField('act') == 'Active')
								{
										$manageBlogs->changeStatus('Active');
										$manageBlogs->setCommonErrorMsg($LANG['success_active']);
								}
								$manageBlogs->setPageBlockShow('msg_form_success');
								$manageBlogs->resetFieldsArray();
						}
						else
								if ($manageBlogs->isFormPOSTed($_POST, 'update_canecl'))
								{
										$manageBlogs->resetFieldsArray();
								}




?>
<script language="javascript">
	var block_arr= new Array('selMsgConfirm');
</script>
<div id="selmanageBlogs">
	<h2 class="clsBlogTitle"><?php echo $LANG['page_title']; ?></h2>
<?php
if ($manageBlogs->isShowPageBlock('msg_form_error'))
{
?>
  	<div id="selMsgError">
   		<p><?php echo $manageBlogs->getCommonErrorMsg(); ?></p>
  	</div>
<?php
}
if ($manageBlogs->isShowPageBlock('msg_form_success'))
{
?>
	<div id="selMsgSuccess">
		<p><?php echo $manageBlogs->getCommonErrorMsg(); ?></p>
	</div>
<?php
}
if ($manageBlogs->isShowPageBlock('blogsEditor'))
{
?>
		<div id="selBlogsEditor">
<?php
		if ($CFG['admin']['blogs_editor'])
		{
?>
			<form name="frmBlogsEditor" action="<?php echo getUrl('manageBlogs.php', 'manageBlogs.php'); ?>" method="post" onSubmit="return getHTMLSource('rte1', 'frmBlogsEditor', 'message');" autocomplete="off">
<?php
		}
		else
		{
?>
			<form name="frmBlogsEditor" action="<?php echo getUrl('manageBlogs.php', 'manageBlogs.php'); ?>" method="post" autocomplete="off">
<?php
		}
?>
				<table summary="<?php echo $LANG['tbl_summary']; ?>" class="clsRichTextTable">
					<tr>
						<td class="<?php echo $manageBlogs->getCSSFormLabelCellClass('subject'); ?>"><label for="subject"><?php echo $LANG['subject']; ?></label></td>
						<td class="<?php echo $manageBlogs->getCSSFormFieldCellClass('subject'); ?>"><?php echo $manageBlogs->getFormFieldErrorTip('subject'); ?>
							<input type="text" class="clsTextBox" name="subject" id="subject" tabindex="<?php echo $manageBlogs->getTabIndex(); ?>" value="<?php echo $manageBlogs->getFormField('subject'); ?>" />
						</td>
				   	</tr>
					<tr>
						<td class="<?php echo $manageBlogs->getCSSFormLabelCellClass('message'); ?>"><label for="message"><?php echo $LANG['message']; ?></label></td>
						<td class="<?php echo $manageBlogs->getCSSFormFieldCellClass('message'); ?>"><?php echo $manageBlogs->getFormFieldErrorTip('message'); ?>
<?php
		if ($CFG['admin']['blogs_editor'])
		{
				if (strchr(strtolower($_SERVER['HTTP_USER_AGENT']), "opera") == '')
				{
						populateRichTextEdit('message', $manageBlogs->getFormField('message'), $manageBlogs->isValidFormInputs());
				}
				else
				{
?>
					<textarea name="message" id="message" tabindex="<?php echo $manageBlogs->getTabIndex(); ?>" cols="100" rows="15"><?php echo $manageBlogs->getFormField('message'); ?></textarea>
					<p><?php echo $LANG['put_the_html_code']; ?></p>
<?php
				}
		}
		else
		{
?>
							<textarea name="message" id="message" tabindex="<?php echo $manageBlogs->getTabIndex(); ?>" cols="100" rows="15"><?php echo $manageBlogs->getFormField('message'); ?></textarea>
							<p><?php echo $LANG['put_the_html_code']; ?></p>
<?php
		}
?>
						</td>
				   	</tr>
					<tr>
						<td class="<?php echo $manageBlogs->getCSSFormLabelCellClass('accept_comments'); ?>"><label for="accept_comments"><?php echo $LANG['accept_comments']; ?></label></td>
						<td class="<?php echo $manageBlogs->getCSSFormFieldCellClass('accept_comments'); ?>"><?php echo $manageBlogs->getFormFieldErrorTip('accept_comments'); ?>
							<input type="radio" class="clsCheckRadio" name="accept_comments" id="accept_comments2" tabindex="<?php echo $manageBlogs->getTabIndex(); ?>" value="Yes"<?php echo $manageBlogs->isCheckedRadio('accept_comments', 'Yes'); ?> /><label for="accept_comments2"><?php echo $LANG['label_yes']; ?></label>&nbsp;
							<input type="radio" class="clsCheckRadio" name="accept_comments" id="accept_comments3" tabindex="<?php echo $manageBlogs->getTabIndex(); ?>" value="No"<?php echo $manageBlogs->isCheckedRadio('accept_comments', 'No'); ?> /><label for="accept_comments3"><?php echo $LANG['label_no']; ?></label>
						</td>
				   	</tr>

					<tr id="selCategoryBlock">
			         		<td class="<?php echo $manageBlogs->getCSSFormLabelCellClass('blog_category_id'); ?>">
								<label for="blog_category_id"><?php echo $LANG['blogwriting_blog_category_id']; ?></label>&nbsp;*&nbsp;
							</td>
			          		<td class="<?php echo $manageBlogs->getCSSFormFieldCellClass('blog_category_id'); ?>"><?php echo $manageBlogs->getFormFieldErrorTip('blog_category_id'); ?>
								<div id="selGeneralCategory">
									<?php $manageBlogs->populateBlogCatagory(); ?>
								</div>
							</td>
			        	</tr>

					<tr>
						<td class="<?php echo $manageBlogs->getCSSFormLabelCellClass('status'); ?>"><label for="status"><?php echo $LANG['status']; ?></label></td>
						<td class="<?php echo $manageBlogs->getCSSFormFieldCellClass('status'); ?>"><?php echo $manageBlogs->getFormFieldErrorTip('status'); ?>
							<input type="radio" class="clsCheckRadio" name="status" id="status2" tabindex="<?php echo $manageBlogs->getTabIndex(); ?>" value="Active"<?php echo $manageBlogs->isCheckedRadio('status', 'Active'); ?> /><label for="status2"><?php echo $LANG['label_activate']; ?></label>&nbsp;
							<input type="radio" class="clsCheckRadio" name="status" id="status3" tabindex="<?php echo $manageBlogs->getTabIndex(); ?>" value="Toactivate"<?php echo $manageBlogs->isCheckedRadio('status', 'Toactivate'); ?> /><label for="status3"><?php echo $LANG['label_toactivate']; ?></label>
						</td>
				   	</tr>
<?php
		if ($manageBlogs->isShowPageBlock('blogsEditBlock'))
		{
				$manageBlogs->populateHidden(array('start', 'blog_id'));
?>
					<tr>
						<td class="<?php echo $manageBlogs->getCSSFormFieldCellClass('update_submit'); ?>" colspan="2">
							<input type="submit" class="clsSubmitButton" name="update_submit" id="update_submit" tabindex="<?php echo $manageBlogs->getTabIndex(); ?>" value="<?php echo $LANG['update_submit']; ?>" />
							<input type="submit" class="clsCancelButton" name="update_canecl" id="update_canecl" tabindex="<?php echo $manageBlogs->getTabIndex(); ?>" value="<?php echo $LANG['update_canecl']; ?>" />
						</td>
					</tr>
<?php
		}
		else
		{
?>
					<tr>
                    <td>&nbsp;</td>
						<td class="<?php echo $manageBlogs->getCSSFormFieldCellClass('add_submit'); ?>">
							<input type="submit" class="clsSubmitButton" name="add_submit" id="add_submit" tabindex="<?php echo $manageBlogs->getTabIndex(); ?>" value="<?php echo $LANG['add_submit']; ?>" />
						</td>
					</tr>
<?php
		}
?>
				</table>
			</form>
		</div>
<?php
}
if ($manageBlogs->isShowPageBlock('selBlogsListBlock'))
{
		$manageBlogs->buildSelectQuery();
		$manageBlogs->buildConditionQuery();
		$manageBlogs->buildSortQuery();
		$manageBlogs->buildQuery();
		$manageBlogs->executeQuery();
		if ($manageBlogs->isResultsFound())
		{
				$anchor = 'dAltMlti';
?>
			<div id="selMsgConfirm" class="selMsgConfirm" style="display:none;position:absolute;">
	    		<h3 id="confirmation_msg"></h3>
		      	<form name="deleteForm" id="deleteForm" method="post" action="<?php echo getUrl('manageBlogs.php', 'manageBlogs.php'); ?>" autocomplete="off">
		        	<table summary="<?php echo $LANG['tbl_summary']; ?>">
					  	<tr>
			            	<td>
							  	<input type="submit" class="clsSubmitButton" name="action_blog" id="action_blog" value="<?php echo $LANG['yes']; ?>" tabindex="<?php echo $manageBlogs->getTabIndex(); ?>" /> &nbsp;
				              	<input type="button" class="clsCancelButton" name="cancel" id="cancel" value="<?php echo $LANG['no']; ?>" tabindex="<?php echo $manageBlogs->getTabIndex(); ?>"  onClick="return hideAllBlocks('blogsListForm');"/>
				              	<input type="hidden" name="blog_id" id="blog_id" />
								<input type="hidden" name="act" id="act" />
								<?php $manageBlogs->populateHidden(array('start')); ?>
							</td>
			          	</tr>
		        	</table>
		      	</form>
		    </div>
			<form name="blogsListForm" id="blogsListForm" method="post" action="<?php echo getUrl('manageBlogs.php', 'manageBlogs.php'); ?>" autocomplete="off">
<?php
				$paging_arr = array();
				if ($CFG['admin']['navigation']['top']) $manageBlogs->populatePageLinks($manageBlogs->getFormField('start'), $paging_arr);
?>
				<table border="1" summary="<?php echo $LANG['tbl_summary']; ?>">
					<tr>
						<th><input type="checkbox" class="clsCheckRadio" name="check_all" onclick = "CheckAll(document.blogsListForm.name, document.blogsListForm.check_all.name)" tabindex="<?php echo $manageBlogs->getTabIndex(); ?>" /></th>
						<th><?php echo $LANG['th_subject']; ?></th>
						<th><?php echo $LANG['th_total_comments']; ?></th>
						<th><?php echo $LANG['th_total_views']; ?></th>
						<th><?php echo $LANG['th_accept_comments']; ?></th>
						<th><?php echo $LANG['th_abuse_count']; ?></th>
						<th><?php echo $LANG['th_status']; ?></th>
						<th><?php echo $LANG['th_date_added']; ?></th>
						<th>&nbsp;</th>
					</tr>
			  		<?php $manageBlogs->showBlogsList(); ?>
					<tr>
						<td class="clsRight <?php echo $manageBlogs->getCSSFormFieldCellClass('add_delete'); ?>" colspan="9">
							<?php $manageBlogs->populateHidden(array('start')); ?>
							<a href="#" id="<?php echo $anchor; ?>"></a>
							<input type="button" class="clsSubmitButton" name="activate_submit" id="activate_submit" tabindex="<?php echo $manageBlogs->getTabIndex(); ?>" value="<?php echo $LANG['activate_submit']; ?>" onClick="if(getMultiCheckBoxValue('blogsListForm', 'check_all', '<?php echo $LANG['check_atleast_one']; ?>', '<?php echo $anchor; ?>', -200, -500)){Confirmation('<?php echo $anchor; ?>', 'selMsgConfirm', 'deleteForm', Array('blog_id', 'act', 'confirmation_msg'), Array(multiCheckValue, 'Active', '<?php echo nl2br($LANG['activate_confirmation']); ?>'), Array('value', 'value', 'innerHTML'), -200, -500, 'blogsListForm');}" />
							<input type="button" class="clsSubmitButton" name="toactivate_submit" id="toactivate_submit" tabindex="<?php echo $manageBlogs->getTabIndex(); ?>" value="<?php echo $LANG['toactivate_submit']; ?>" onClick="if(getMultiCheckBoxValue('blogsListForm', 'check_all', '<?php echo $LANG['check_atleast_one']; ?>', '<?php echo $anchor; ?>', -200, -500)){Confirmation('<?php echo $anchor; ?>', 'selMsgConfirm', 'deleteForm', Array('blog_id', 'act', 'confirmation_msg'), Array(multiCheckValue, 'Toactivate', '<?php echo nl2br($LANG['toactivate_confirmation']); ?>'), Array('value', 'value', 'innerHTML'), -200, -500, 'blogsListForm');}" />
							<input type="button" class="clsSubmitButton" name="delete_submit" id="delete_submit" tabindex="<?php echo $manageBlogs->getTabIndex(); ?>" value="<?php echo $LANG['delete_submit']; ?>" onClick="if(getMultiCheckBoxValue('blogsListForm', 'check_all', '<?php echo $LANG['check_atleast_one']; ?>', '<?php echo $anchor; ?>', -200, -500)){Confirmation('<?php echo $anchor; ?>', 'selMsgConfirm', 'deleteForm', Array('blog_id', 'act', 'confirmation_msg'), Array(multiCheckValue, 'delete', '<?php echo nl2br($LANG['delete_confirmation']); ?>'), Array('value', 'value', 'innerHTML'), -200, -500, 'blogsListForm');}" />
						</td>
				   	</tr>
				</table>
<?php
				if ($CFG['admin']['navigation']['bottom']) $manageBlogs->populatePageLinks($manageBlogs->getFormField('start'), $paging_arr);
?>
			</form>
<?php
		}
		else
		{
?>
			<div id="selMsgAlert">
				<p><?php echo $LANG['no_records_found']; ?></p>
			</div>
<?php
		}
?>
		</div>
<?php
}
?>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>
