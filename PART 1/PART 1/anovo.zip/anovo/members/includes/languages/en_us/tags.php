<?php
$LANG['page_title'] = 'Tag Cloud';
$LANG['no_tags_found'] = 'No tags found!';
$LANG['tags_frequency'] = 'Frequency';
$LANG['tags_alphabetically'] = 'Alphabetically';
?>