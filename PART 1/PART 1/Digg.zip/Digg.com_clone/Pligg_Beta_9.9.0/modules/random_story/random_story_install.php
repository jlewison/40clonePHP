<?php
	$module_info['name'] = 'Random Story';
	$module_info['desc'] = 'Allows the user to read a random unread story.';
	$module_info['version'] = 0.1;
	$module_info['requires'][] = array('PHP', 5);
?>