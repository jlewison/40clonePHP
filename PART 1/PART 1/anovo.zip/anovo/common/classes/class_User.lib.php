<?php

class User
{
		protected $db;
		protected $user_info = array();
		public function __construct()
		{
				global $Db_Link;
				$this->db = $Db_Link;
		}
		private function _getCurrentIP()
		{
				if (getenv("HTTP_CLIENT_IP") && strcasecmp(getenv("HTTP_CLIENT_IP"), "unknown")) $ip = getenv("HTTP_CLIENT_IP");
				else
						if (getenv("HTTP_X_FORWARDED_FOR") && strcasecmp(getenv("HTTP_X_FORWARDED_FOR"), "unknown")) $ip = getenv("HTTP_X_FORWARDED_FOR");
						else
								if (getenv("REMOTE_ADDR") && strcasecmp(getenv("REMOTE_ADDR"), "unknown")) $ip = getenv("REMOTE_ADDR");
								else
										if (isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], "unknown")) $ip = $_SERVER['REMOTE_ADDR'];
										else  $ip = "unknown";
				return ($ip);
		}
		public function isUserExists($username)
		{
				global $Tbl_User_Info;
				$sql = "SELECT COUNT(*) FROM " . $Tbl_User_Info . " WHERE username='" . $username . "'";
				$result = mysql_query($sql, $this->db);
				if (!$result) die("Query Error at isUserExists()" . mysql_error($this->db));
				$num_of_users = mysql_result($result, 0);
				return (($num_of_users != 0));
		}
		public function getUserStatus($username)
		{
				global $Tbl_User_Info;
				$sql = "SELECT usr_status FROM " . $Tbl_User_Info . " WHERE username='" . $username . "'";
				$result = mysql_query($sql, $this->db);
				return (mysql_result($result, 0));
		}
		public function getUserPassword($username)
		{
				global $Tbl_User_Info;
				$sql = "SELECT password FROM " . $Tbl_User_Info . " WHERE username='" . $username . "'";
				$result = mysql_query($sql, $this->db);
				return (mysql_result($result, 0));
		}
		public function isValidUser($username, $password, $turing)
		{
				global $Tbl_User_Info;
				$err_val = 0;
				$sql = "SELECT * FROM " . $Tbl_User_Info . " WHERE username='" . $username . "'";
				$result = mysql_query($sql, $this->db);
				if (!$result) die("Query Error at isValidUser()" . mysql_error($this->db));
				if ((!isset($_SESSION['sn_turing'])) || $_SESSION['sn_turing'] != $turing) $err_val = 9;
				else
						if (mysql_num_rows($result) == 0) $err_val = 3;
						else
						{
								$row = mysql_fetch_assoc($result);
								if ($row['password'] != $password) $err_val = 4;
								else
										if ($row['usr_status'] != 0) $err_val = intval($row['usr_status']);
						}
						if (isset($_SESSION['sn_turing'])) unset($_SESSION['sn_turing']);
				return ($err_val);
		}
		public function isValidSession()
		{
				global $Tbl_User_Info;
				$err_val = 0;
				if (isset($_SESSION['sn_logged']))
				{
						$sql = "SELECT * FROM " . $Tbl_User_Info . " WHERE id='" . $_SESSION['sn_uid'] . "'";
						$result = mysql_query($sql, $this->db);
						if (!$result) die("Query Error at isValidSession()" . mysql_error($this->db));
						if (mysql_num_rows($result) == 0) $err_val = 5;
						else
						{
								$row = mysql_fetch_assoc($result);
								if ($row['usr_status'] != 0) $err_val = intval($row['usr_status']);
								else
								{
										$ip = $row['ip'];
										$session = $row['session'];
										if ($ip != $this->_getCurrentIP()) $err_val = 6;
										else
												if ($session != session_id()) $err_val = 7;
								}
						}
				}
				else
						if (isset($_COOKIE['sn_login_cookie'])) $err_val = 7;
						else  $err_val = 8;
				return ($err_val);
		}
		private function _getUserInfo($username)
		{
				global $Tbl_User_Info;
				$sql = "SELECT * FROM " . $Tbl_User_Info . " WHERE username='" . $username . "'";
				$result = mysql_query($sql, $this->db);
				if (!$result) die("Query Error at _getUserInfo()" . mysql_error($this->db));
				$row = mysql_fetch_assoc($result);
				foreach ($row as $key => $value) $this->user_info[$key] = $value;
		}
		public function doLogin($username, $login2url)
		{
				global $Tbl_User_Info;
				$this->_getUserInfo($username);
				$_SESSION['sn_logged'] = true;
				$_SESSION['sn_uid'] = $this->user_info['id'];
				$_SESSION['sn_username'] = $this->user_info['username'];
				$_SESSION['sn_email'] = $this->user_info['email'];
				$_SESSION['sn_name'] = $this->user_info['name'];
				$_SESSION['sn_egold_account'] = $this->user_info['egold_account'];
				$_SESSION['sn_last_logged'] = $this->user_info['last_logged'];
				$_SESSION['sn_doj'] = $this->user_info['doj'];
				$_SESSION['sn_num_visits'] = $this->user_info['num_visits'];
				$_SESSION['sn_last_ip'] = $this->user_info['ip'];
				setcookie('sn_login_cookie', '1', 0, '/');
				$ip = $this->_getCurrentIP();
				$session = session_id();
				$sql = "UPDATE " . $Tbl_User_Info . " SET last_logged=NOW(), " . "num_visits=num_visits + 1 , " . "ip='" . $ip . "', " . "session='" . $session . "' " . "WHERE id='" . $_SESSION['sn_uid'] . "'";
				$result = mysql_query($sql, $this->db);
				if (!$result) die("UPDATE Query error at doLogin()" . mysql_error($this->db));
				if (isset($_COOKIE['url'])) Redirect2URL($_COOKIE['url']);
				else  Redirect2URL($login2url);
		}
		public function isUserLogined()
		{
				return (isset($_SESSION['sn_logged']));
		}
		public function doLogout()
		{
				global $Tbl_User_Info;
				$sql = "UPDATE " . $Tbl_User_Info . " SET " . "session='' WHERE id='" . $_SESSION['sn_uid'] . "'";
				@mysql_query($sql, $this->db);
				$_SESSION = array();
				if (isset($_COOKIE[session_name()])) unset($_COOKIE[session_name()]);
				if (isset($_REQUEST[session_name()])) unset($_REQUEST[session_name()]);
				setcookie('url', '', time() - 60 * 60 * 24 * 30 * 12, '/');
				setcookie('sn_login_cookie', '', time() - 60 * 60 * 24 * 30 * 12, '/');
				session_destroy();
		}
}


?>