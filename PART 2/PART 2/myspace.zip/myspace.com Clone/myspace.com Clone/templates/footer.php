<?

?>
<table width="960" border="0" cellpadding="0" cellspacing="0" bordercolor="#111111" id="AutoNumber1" style="border-collapse: collapse">
  <tr>
    <td width="100%"><table class="td-lined" width="103%">
        <tr align="center" class="maingray"> 
          <td colspan="2">
            <?=f_banners();?>
          </td>
        
        <tr class="maingray"> 
          <td align=center width="98%"><b><a href="index.php">
			<font size="1" color="#000080">Home</font></a></b><font size="1"><font color="#000080">
			</font><b><a href="index.php?mode=user&act=inv">
			<font color="#000080">Invite</font></a></b><font color="#000080">
			</font><b><a href="index.php?mode=messages&act=inbox">
			<font color="#000080">Messages</font></a></b><font color="#000080">
			</font><b><a href="index.php?mode=login&act=menu_err">
			<font color="#000080">Search</font></a></b><font color="#000080">
			</font><b><a href="index.php?mode=login&act=menu_err">
			<font color="#000080">Blog</font></a></b><font color="#000080">
			</font><b><a href="index.php?mode=login&act=menu_err">
			<font color="#000080">Classifieds</font></a></b><font color="#000080">
			</font><b><a href="index.php?mode=login&act=menu_err">
			<font color="#000080">Forums</font></a></b><font color="#000080">
			</font><b><a href="index.php?mode=login&act=menu_err">
			<font color="#000080">Events</font></a></b><font color="#000080">
			</font><b><a href="index.php?mode=login&act=menu_err">
			<font color="#000080">Groups</font></a></b><font color="#000080">
			</font><b><a href="index.php?mode=login&act=menu_err">
			<font color="#000080">Chat</font></a></b><font color="#000080">
			</font><b><a href="index.php?mode=login&act=menu_err">
			<font color="#000080">Calendar</font></a></b><font color="#000080">
			</font></font><b><a href="index.php?mode=login&act=menu_err">
			<font size="1" color="#000080">Browse</font></a><font size="1" color="#000080">
			</font><a href="index.php?mode=tour"><font size="1" color="#000080">Tour</font></a></b>
			<b> <a href="index.php?mode=privacy"><font size="1" color="#000080">Privacy 
            Policy</font></a></b> <b><a href="index.php?mode=terms">
			<font size="1" color="#000080">Terms</font></a></b><p>Powered By: <b>
			<a href="http://popscript.com">PopScript.com</a></b> �2005. All 
            Rights Reserved</td>
          <td align="center" width="1%">&nbsp;</td>
      </table></td>
  </tr>
</table>