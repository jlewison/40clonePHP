<?php
$LANG['ReplyToolTip'] = 'Repeat';
$LANG['ShareToolTip'] = 'Share';
$LANG['BufferToolTip'] = 'Buffering...';
$LANG['LoadingToolTip'] = 'Loading...';
$LANG['IniLoadingToolTip'] = 'Loading';
$LANG['LoaderToolTip'] = 'Loaded';
$LANG['NameTextToolTip'] = 'Name will come here';
$LANG['RatingTextToolTip'] = 'Rating :';
$LANG['FromTextToolTip'] = 'From :';
$LANG['ViewTextToolTip'] = 'Views :';
$LANG['NextTextToolTip'] = '>>Next';
$LANG['PlayButtonToolTip'] = 'Play';
$LANG['PauseButtonToolTip'] = 'Pause';
$LANG['ForwardButtonToolTip'] = 'Forward';
$LANG['BackwardButtonToolTip'] = 'Backward';
$LANG['VolumeButtonToolTip'] = 'Volume';
$LANG['ShareVidzToolTip'] = 'Share this video';
$LANG['ReplyVideoToolTip'] = 'Replay';
$LANG['StopButtonToolTip'] = 'Stop';
$LANG['MuteButtonToolTip'] = 'Mute';
$LANG['FullScreenToolTip'] = 'Full Screen';
$LANG['UnMuteButtonToolTip'] = 'Unmute';
$LANG['NextListToolTip'] = 'Next list';
$LANG['PreviousListToolTip'] = 'Previous List';
?>