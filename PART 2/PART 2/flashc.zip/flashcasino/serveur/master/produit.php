<? include "header.php"; ?>
<center>
<h4><font color=#7C87C2>La boutique<br><br></font></h4>


<h5><font color=#7C87C2>Cat�gorie : <? echo $nom; ?><br><br></font></h>

<a href=ajoutproduit.php?cat=<? echo $nom; ?>>ajouter un produit </a>


<br><br>

<table border style="BORDER-COLLAPSE: collapse" cellspacing=0 cellpadding=3><tr><td class=text1><b>ID</b></td><td class=text1><b>Nom produit</b></td><td class=text1><b>Action</b></td></tr>
<?
$result=mysql_query("select * from produit where cat ='$nom' ORDER BY `id`");
while($row=mysql_fetch_array($result))
{
echo "
<tr><td class=text1>$row[0]</td><td class=text1><a href=editproduit.php?nomp=$row[1]>$row[1]</a></td><td class=text1><a href=del11.php?nomp=$row[1]>Supprimer</a><br><a href=editproduit.php?nomp=$row[1]>Editer</a></td></tr>
";
}
?>

</table>
</center>
<? include "footer.php"; ?>