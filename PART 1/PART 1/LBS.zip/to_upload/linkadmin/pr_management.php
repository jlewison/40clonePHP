<?php include('restrict.php'); include('../settings.php'); require_once('../Connections/apound.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form1")) {
  $updateSQL = sprintf("UPDATE confset SET prenabled=%s, pr_google=%s, pr_yahoo=%s, pr_msn=%s, pr_alexa=%s, prp_latest=%s, prp_category=%s, prp_details=%s, prp_home=%s, prp_links=%s, prp_list=%s, prp_search=%s WHERE indc=%s",
                       GetSQLValueString($_POST['prenabled'], "text"),
                       GetSQLValueString($_POST['pr_google'], "text"),
                       GetSQLValueString($_POST['pr_yahoo'], "text"),
                       GetSQLValueString($_POST['pr_msn'], "text"),
                       GetSQLValueString($_POST['pr_alexa'], "text"),
                       GetSQLValueString($_POST['prp_latest'], "text"),
                       GetSQLValueString($_POST['prp_category'], "text"),
                       GetSQLValueString($_POST['prp_details'], "text"),
                       GetSQLValueString($_POST['prp_home'], "text"),
                       GetSQLValueString($_POST['prp_links'], "text"),
                       GetSQLValueString($_POST['prp_list'], "text"),
                       GetSQLValueString($_POST['prp_search'], "text"),
                       GetSQLValueString($_POST['indc'], "int"));

  mysql_select_db($database_apound, $apound);
  $Result1 = mysql_query($updateSQL, $apound) or die(mysql_error());
  $done = "<div align='center'><font color='red'><b>Update ... DONE</b></font></div>";
}

mysql_select_db($database_apound, $apound);
$query_PRMan = "SELECT confset.indc, confset.prenabled, confset.pr_google, confset.pr_yahoo, confset.pr_msn, confset.pr_alexa, confset.prp_latest, confset.prp_category, confset.prp_details, confset.prp_home, confset.prp_links, confset.prp_list, confset.prp_search FROM confset";
$PRMan = mysql_query($query_PRMan, $apound) or die(mysql_error());
$row_PRMan = mysql_fetch_assoc($PRMan);
$totalRows_PRMan = mysql_num_rows($PRMan);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>Manage PR Display and Website Statistics - Link Bid Script Admin Panel</title>
<link rel="shortcut icon" href="img/favicon.ico" />
<link rel="stylesheet" type="text/css" href="admin.css" />
</head>

<body>
<?php $x = getenv("HTTP_HOST").getenv("REQUEST_URI"); ?>
<?php include('header_tpl.php'); ?>

<h2>Manage PR Display and Website Statistics</h2>
<?php echo("$done");?>
<form action="<?php echo $editFormAction; ?>" method="post" name="form1" id="form1">
  <table align="center">
    <tr valign="baseline">
      <td align="right" valign="middle" nowrap="nowrap" bgcolor="#FFFFCC">Backlinks Global:</td>
      <td valign="baseline" bgcolor="#FFFFCC"><table>
        <tr>
          <td><input type="radio" name="prenabled" value="Y" <?php if (!(strcmp(htmlentities($row_PRMan['prenabled'], ENT_COMPAT, 'utf-8'),"Y"))) {echo "CHECKED";} ?> />
            Enable
              <input type="radio" name="prenabled" value="N" <?php if (!(strcmp(htmlentities($row_PRMan['prenabled'], ENT_COMPAT, 'utf-8'),"N"))) {echo "CHECKED";} ?> />
            Disable</td>
        </tr>
        
      </table></td>
    </tr>
    <tr valign="baseline">
      <td align="right" valign="middle" nowrap="nowrap" bgcolor="#FFFFFF">&nbsp;</td>
      <td valign="baseline" bgcolor="#FFFFFF">&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td align="right" valign="middle" nowrap="nowrap">Google back links:</td>
      <td valign="baseline"><table>
        <tr>
          <td><input type="radio" name="pr_google" value="Y" <?php if (!(strcmp(htmlentities($row_PRMan['pr_google'], ENT_COMPAT, 'utf-8'),"Y"))) {echo "CHECKED";} ?> />
            Enable
              <input type="radio" name="pr_google" value="N" <?php if (!(strcmp(htmlentities($row_PRMan['pr_google'], ENT_COMPAT, 'utf-8'),"N"))) {echo "CHECKED";} ?> />
            Disable</td>
        </tr>
        
      </table></td>
    </tr>
    <tr valign="baseline">
      <td align="right" valign="middle" nowrap="nowrap" bgcolor="#FFFFCC">Yahoo back links</td>
      <td valign="baseline" bgcolor="#FFFFCC"><table>
        <tr>
          <td><input type="radio" name="pr_yahoo" value="Y" <?php if (!(strcmp(htmlentities($row_PRMan['pr_yahoo'], ENT_COMPAT, 'utf-8'),"Y"))) {echo "CHECKED";} ?> />
            Enable
              <input type="radio" name="pr_yahoo" value="N" <?php if (!(strcmp(htmlentities($row_PRMan['pr_yahoo'], ENT_COMPAT, 'utf-8'),"N"))) {echo "CHECKED";} ?> />
            Disable</td>
        </tr>
        
      </table></td>
    </tr>
    <tr valign="baseline">
      <td align="right" valign="middle" nowrap="nowrap">MSN back links:</td>
      <td valign="baseline"><table>
        <tr>
          <td><input type="radio" name="pr_msn" value="Y" <?php if (!(strcmp(htmlentities($row_PRMan['pr_msn'], ENT_COMPAT, 'utf-8'),"Y"))) {echo "CHECKED";} ?> />
            Enable
              <input type="radio" name="pr_msn" value="N" <?php if (!(strcmp(htmlentities($row_PRMan['pr_msn'], ENT_COMPAT, 'utf-8'),"N"))) {echo "CHECKED";} ?> />
            Disable</td>
        </tr>
        
      </table></td>
    </tr>
    <tr valign="baseline">
      <td align="right" valign="middle" nowrap="nowrap" bgcolor="#FFFFCC">Alexa  back links:</td>
      <td valign="baseline" bgcolor="#FFFFCC"><table>
        <tr>
          <td><input type="radio" name="pr_alexa" value="Y" <?php if (!(strcmp(htmlentities($row_PRMan['pr_alexa'], ENT_COMPAT, 'utf-8'),"Y"))) {echo "CHECKED";} ?> />
            Enable
              <input type="radio" name="pr_alexa" value="N" <?php if (!(strcmp(htmlentities($row_PRMan['pr_alexa'], ENT_COMPAT, 'utf-8'),"N"))) {echo "CHECKED";} ?> />
            Disable</td>
        </tr>
        
      </table></td>
    </tr>
    <tr valign="baseline">
      <td align="right" valign="middle" nowrap="nowrap" bgcolor="#FFFFFF">&nbsp;</td>
      <td valign="baseline" bgcolor="#FFFFFF">&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td align="right" valign="middle" nowrap="nowrap">on page 'Latest Listings'</td>
      <td valign="baseline"><table>
        <tr>
          <td><input type="radio" name="prp_latest" value="Y" <?php if (!(strcmp(htmlentities($row_PRMan['prp_latest'], ENT_COMPAT, 'utf-8'),"Y"))) {echo "CHECKED";} ?> />
            Enable
              <input type="radio" name="prp_latest" value="N" <?php if (!(strcmp(htmlentities($row_PRMan['prp_latest'], ENT_COMPAT, 'utf-8'),"N"))) {echo "CHECKED";} ?> />
            Disable</td>
        </tr>
        
      </table></td>
    </tr>
    <tr valign="baseline">
      <td align="right" valign="middle" nowrap="nowrap" bgcolor="#FFFFCC">on page 'Category'</td>
      <td valign="baseline" bgcolor="#FFFFCC"><table>
        <tr>
          <td><input type="radio" name="prp_category" value="Y" <?php if (!(strcmp(htmlentities($row_PRMan['prp_category'], ENT_COMPAT, 'utf-8'),"Y"))) {echo "CHECKED";} ?> />
            Enable
              <input type="radio" name="prp_category" value="N" <?php if (!(strcmp(htmlentities($row_PRMan['prp_category'], ENT_COMPAT, 'utf-8'),"N"))) {echo "CHECKED";} ?> />
            Disable</td>
        </tr>
        
      </table></td>
    </tr>
    <tr valign="baseline">
      <td align="right" valign="middle" nowrap="nowrap">on page 'Listing Details'</td>
      <td valign="baseline"><table>
        <tr>
          <td><input type="radio" name="prp_details" value="Y" <?php if (!(strcmp(htmlentities($row_PRMan['prp_details'], ENT_COMPAT, 'utf-8'),"Y"))) {echo "CHECKED";} ?> />
            Enable
              <input type="radio" name="prp_details" value="N" <?php if (!(strcmp(htmlentities($row_PRMan['prp_details'], ENT_COMPAT, 'utf-8'),"N"))) {echo "CHECKED";} ?> />
            Disable</td>
        </tr>
        
      </table></td>
    </tr>
    <tr valign="baseline">
      <td align="right" valign="middle" nowrap="nowrap" bgcolor="#FFFFCC">on page 'home'</td>
      <td valign="baseline" bgcolor="#FFFFCC"><table>
        <tr>
          <td><input type="radio" name="prp_home" value="Y" <?php if (!(strcmp(htmlentities($row_PRMan['prp_home'], ENT_COMPAT, 'utf-8'),"Y"))) {echo "CHECKED";} ?> />
            Enable
              <input type="radio" name="prp_home" value="N" <?php if (!(strcmp(htmlentities($row_PRMan['prp_home'], ENT_COMPAT, 'utf-8'),"N"))) {echo "CHECKED";} ?> />
            Disable</td>
        </tr>
        
      </table></td>
    </tr>
    <tr valign="baseline">
      <td align="right" valign="middle" nowrap="nowrap">on page 'Top Links'</td>
      <td valign="baseline"><table>
        <tr>
          <td><input type="radio" name="prp_links" value="Y" <?php if (!(strcmp(htmlentities($row_PRMan['prp_links'], ENT_COMPAT, 'utf-8'),"Y"))) {echo "CHECKED";} ?> />
            Enable
              <input type="radio" name="prp_links" value="N" <?php if (!(strcmp(htmlentities($row_PRMan['prp_links'], ENT_COMPAT, 'utf-8'),"N"))) {echo "CHECKED";} ?> />
            Disable</td>
        </tr>
        
      </table></td>
    </tr>
    <tr valign="baseline">
      <td align="right" valign="middle" nowrap="nowrap" bgcolor="#FFFFCC">on page 'Alphabetic List'</td>
      <td valign="baseline" bgcolor="#FFFFCC"><table>
        <tr>
          <td><input type="radio" name="prp_list" value="Y" <?php if (!(strcmp(htmlentities($row_PRMan['prp_list'], ENT_COMPAT, 'utf-8'),"Y"))) {echo "CHECKED";} ?> />
            Enable
              <input type="radio" name="prp_list" value="N" <?php if (!(strcmp(htmlentities($row_PRMan['prp_list'], ENT_COMPAT, 'utf-8'),"N"))) {echo "CHECKED";} ?> />
            Disable</td>
        </tr>
        
      </table></td>
    </tr>
    <tr valign="baseline">
      <td align="right" valign="middle" nowrap="nowrap">on page 'search'</td>
      <td valign="baseline"><table>
        <tr>
          <td><input type="radio" name="prp_search" value="Y" <?php if (!(strcmp(htmlentities($row_PRMan['prp_search'], ENT_COMPAT, 'utf-8'),"Y"))) {echo "CHECKED";} ?> />
            Enable
              <input type="radio" name="prp_search" value="N" <?php if (!(strcmp(htmlentities($row_PRMan['prp_search'], ENT_COMPAT, 'utf-8'),"N"))) {echo "CHECKED";} ?> />
            Disable</td>
        </tr>
        
      </table></td>
    </tr>
    <tr valign="baseline">
      <td align="right" valign="middle" nowrap="nowrap">&nbsp;</td>
      <td><input type="submit" class="login-but" value="Update record" /></td>
    </tr>
  </table>
  <input type="hidden" name="MM_update" value="form1" />
  <input type="hidden" name="indc" value="<?php echo $row_PRMan['indc']; ?>" />
</form>
<p>&nbsp;</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>

<?php include('footer_tpl.php'); ?>
</body>
</html>
<?php
mysql_free_result($PRMan);
?>