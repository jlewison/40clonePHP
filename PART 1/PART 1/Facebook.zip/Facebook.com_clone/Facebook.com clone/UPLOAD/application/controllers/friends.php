<?php
/**
 * friends Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 2007-12-14
 */
class friends extends Controller
{
		//Constructor
		var $userId;
		function friends()
		{
				parent::Controller();
				loginRequired();
				//Load the language file
				$this->lang->load('search', $this->config->item('language_code'));
				$this->lang->load('friends', $this->config->item('language_code'));
				$this->userId = $this->session->userdata('user_id');
		}
		#***************************************************************************
		#Method			: index()---default method
		#Description	: show all friends for the current user
		#***************************************************************************
		function index()
		{
				$this->showfriends();
		} //end index()
		#***************************************************************************
		#Method			: showfriends
		#Description	: show all friends for the current user/given friend id
		#***************************************************************************
		function showfriends($userId = '')
		{
				$this->load->model('friendsModel');
				$this->load->model('userModel');
				$outputData = array();
				if ($userId == '') $userId = $this->userId;
				$friendsArray = $this->friendsModel->getFriends($userId);
				$friendsId = implode(",", $friendsArray);
				//Load the config file related to photo
				$this->config->load('photo');
				//Load the pagination model
				$this->load->model('paginationmodel');
				//Load the pagination language file
				$this->lang->load('pagination', $this->config->item('language_code'));
				$perPage = $this->paginationmodel->getPerPage('friends');
				$start = (trim($this->uri->segment(4)) != '' && is_numeric($this->uri->segment(4)) && $this->uri->segment(4) > 0) ? $this->uri->segment(4) : 1;
				$start = ($start - 1) * $perPage;
				if ($friendsId == '') $outputData['friends_list'] = array();
				else  $outputData['friends_list'] = $this->userModel->getDetails($friendsId, 'active', false, 'last_modified desc', $start, $perPage);
				$outputData['friends_list_count'] = count($outputData['friends_list']);
				$outputData['view_user_id'] = $userId; //user
				$outputData['view_user_name'] = $this->userModel->getName($userId);
				$outputData['view_user_avatar'] = $this->userModel->getAvatar($userId);
				$outputData['all_friends'] = true;
				$outputData['totalFriendsCount'] = count($this->userModel->getDetails($friendsId));
				$outputData['currentPage'] = (trim($this->uri->segment(4)) != '' && is_numeric($this->uri->segment(4))) ? $this->uri->segment(4) : 1;
				$outputData['totalPages'] = ($outputData['totalFriendsCount'] > $perPage) ? ceil(($outputData['totalFriendsCount'] / $perPage)) : 0;
				$outputData['pageUrl'] = base_url() . 'friends/showfriends/' . $userId . '/';
				$outputData['endCount'] = $start + $outputData['friends_list_count'];
				$outputData['startCount'] = $start + 1;
				if ($this->session->userdata('result_msg') != '')
				{
						$outputData['result_msg'] = $this->session->userdata('result_msg');
						$this->session->set_userdata(array("result_msg" => ''));
				}
				$this->smartyextended->view('friends', $outputData);
		} //end showfriends()
		#***************************************************************************
		#Method			: removefriend
		#Description	: remove the givn friend from the current users friend list
		#***************************************************************************
		function removefriend()
		{
				$this->load->model('friendsModel');
				if ($this->input->post('hdn_friend_id'))
				{
						if ($this->friendsModel->deleteFriend($this->input->post('hdn_friend_id'))) $this->session->set_userdata(array("result_msg" => $this->lang->line('friends_remove_friend_success_msg')));
						else  $this->session->set_userdata(array("result_msg" => $this->lang->line('friends_remove_friend_error_msg')));
				}
				redirect("friends");
		} //end removefriend()
		#***************************************************************************
		#Method			: invite
		#Description	: invite friends to join this site.
		#***************************************************************************
		function invite()
		{
				$this->load->model('userModel');
				$data = array();
				$data['current_user_email'] = $this->userModel->getEmail();
				$data['current_user_name'] = ucwords($this->userModel->getName());
				if ($this->input->post('invite_submit'))
				{
						$this->load->model('friendsModel');
						if (trim($this->input->post('to_ids')) == '') $resultMsg[] = $this->lang->line('friends_invite_email_validate_msg');
						else
						{
								$config = array('to_ids' => $this->input->post('to_ids'), 'message' => $this->input->post('message'));
								$resultMsg = $this->_sendInvitation($config);
						}
						echo json_encode(array('error' => 'no', 'msg' => implode("<br>", $resultMsg)));
				}
				else  $this->smartyextended->view('invitefriends', $data);
		} //end invite()
		###################################################################################################
		#Method			: _sendInvitation()
		#Type			: sub
		#Description	: to list all possible results while inviting friends, for the given bunk of emails
		#Author			: ilayaraja_22ag06
		##################################################################################################
		function _sendInvitation($config)
		{
				$this->load->model('settingsModel');
				$this->load->model('emailTemplateModel');
				$this->load->library('email');
				$this->load->model('userModel');
				$this->load->model('messageModel');
				//reads common site settings
				$settings = $this->settingsmodel->readSetting('admin_email, admin_name, site_name, site_title');
				$adminEmail = $settings['admin_email'];
				$adminName = $settings['admin_name'];
				$siteName = $settings['site_title'];
				//reads mail templates
				$emailTemplate = $this->emailTemplateModel->readEmailTemplate('invite_friend');
				$sendResultArray = $this->_getInviteResult($config['to_ids']);
				if (!empty($sendResultArray['invite_emails']))
				{
						foreach ($sendResultArray['invite_emails'] as $toEmail)
						{
								//send internal mail
								$usrDetail = $this->usermodel->getDetails($toEmail, 'active', true);
								$usrDetail = current($usrDetail);
								$friendId = 0;
								//send external mail
								$attachUrl = base_url() . 'invitations/friends';
								$splVars = array("~~senderName~~" => ucfirst($this->userModel->getName($this->session->userdata('user_id'))), "~~privateMessage~~" => $config['message'], "~~siteName~~" => $siteName, "~~attachUrl~~" => $attachUrl, "~~adminEmail~~" => $adminEmail, "~~adminName~~" => $adminName);
								$subject = strtr($emailTemplate['template_subject'], $splVars);
								$message = strtr($emailTemplate['template_content'], $splVars);
								$registeredUser = false;
								$sendExternalEmail = true;
								if (!empty($usrDetail))
								{
										$registeredUser = true;
										$msgConfig = array("to_id" => $usrDetail['user_id'], "subject" => $subject, "message" => $message);
										$this->messageModel->sendMessage($msgConfig);
										$friendId = $usrDetail['user_id'];
								} //end if
								if ($registeredUser)
								{
										$userNotifications = $this->usermodel->getUserNotifications($usrDetail['user_id']);
										if (isset($userNotifications[2]) && $userNotifications[2] == 1) $sendExternalEmail = true;
										else  $sendExternalEmail = false;
								}
								if ($sendExternalEmail)
								{
										$this->email->from($adminEmail, $adminName);
										$this->email->to($toEmail);
										$this->email->subject($subject);
										$this->email->message(nl2br($message));
										$this->email->send();
								}
								if ($this->friendsModel->isInvited($toEmail) == false)
								{
										//Send the invitation
										$inviteConfig = array("friend_id" => $friendId, "friend_email" => $toEmail, "invite_message" => $config['message']);
										$this->friendsModel->newInvitation($inviteConfig);
								}
						} //end foreach
				} //end if
				if (!empty($sendResultArray['blocked_emails'])) $resultMsg[] = $this->lang->line('friends_invite_blocked_user') . ", " . implode(", ", $sendResultArray['blocked_emails']);
				if (!empty($sendResultArray['not_registered_emails'])) $resultMsg[] = $this->lang->line('friends_invite_result_new') . " " . implode(", ", $sendResultArray['not_registered_emails']);
				if (!empty($sendResultArray['registered_emails'])) $resultMsg[] = $this->lang->line('friends_invite_result_registered') . " " . implode(", ", $sendResultArray['registered_emails']);
				if (!empty($sendResultArray['registered_not_confirmed_emails'])) $resultMsg[] = $this->lang->line('friends_invite_result_registered_sent') . " " . implode(", ", $sendResultArray['registered_not_confirmed_emails']);
				if (!empty($sendResultArray['confirmed_emails'])) $resultMsg[] = $this->lang->line('friends_invite_result_already_friend') . " " . implode(", ", $sendResultArray['confirmed_emails']);
				if (!empty($sendResultArray['self_emails'])) $resultMsg[] = $this->lang->line('friends_invite_result_self_account') . " " . implode(", ", $sendResultArray['self_emails']);
				if (!empty($sendResultArray['not_registered_not_confirmed_emails'])) $resultMsg[] = $this->lang->line('friends_invite_result_unregistered_sent') . " " . implode(", ", $sendResultArray['not_registered_not_confirmed_emails']);
				if (!empty($sendResultArray['invalid_emails'])) $resultMsg[] = $this->lang->line('friends_invite_result_invalid') . " " . implode(", ", $sendResultArray['invalid_emails']);
				return $resultMsg;
		} //end _sendInvitation()
		###################################################################################################
		#Method			: _getInviteResult()
		#Type			: sub
		#Description	: to list all possible results while inviting friends, for the given bunk of emails
		##################################################################################################
		function _getInviteResult($toIds)
		{
				$resultArray = array();
				$toIds = explode(",", $toIds);
				$usrDetail = $this->userModel->getDetails($this->session->userdata('user_id'));
				$curUserEmail = $usrDetail[$this->session->userdata('user_id')]['email'];
				if (is_array($toIds))
				{
						foreach ($toIds as $toEmail)
						{
								if ($this->friendsModel->isEmail($toEmail))
								{
										$blockedBy = $this->usermodel->chkUserEmail($toEmail);
										if ($this->friendsModel->isRegistered($toEmail) and $this->usermodel->isUserBlocked($this->session->userdata('user_id'), $blockedBy['user_id']))
										{ //this email account user blocked the current user
												$resultArray['blocked_emails'][] = $toEmail;
										} elseif ($this->friendsModel->isRegistered($toEmail) and $this->friendsModel->isInvited($toEmail) and !$this->friendsModel->isConfirmed($toEmail))
										{ //already sent invitation and not yet confirmed and registered emails
												$resultArray['registered_not_confirmed_emails'][] = $toEmail;
												$resultArray['invite_emails'][] = $toEmail;
										} elseif ($this->friendsModel->isRegistered($toEmail) and $this->friendsModel->isConfirmed($toEmail)) //already confirmed emails
 												$resultArray['confirmed_emails'][] = $toEmail;
										elseif ($curUserEmail == $toEmail) //check whether the user tried himself to send mail
 														$resultArray['self_emails'][] = $toEmail;
										elseif (!$this->friendsModel->isRegistered($toEmail) and $this->friendsModel->isInvited($toEmail) and !$this->friendsModel->isConfirmed($toEmail))
										{ //already sent invitation, not yet confirmed and not yet registered emails
												$resultArray['not_registered_not_confirmed_emails'][] = $toEmail;
												$resultArray['invite_emails'][] = $toEmail;
										} elseif ($this->friendsModel->isRegistered($toEmail) and !$this->friendsModel->isInvited($toEmail))
										{ //already sent invitation, not yet confirmed and not yet registered emails
												$resultArray['registered_emails'][] = $toEmail;
												$resultArray['invite_emails'][] = $toEmail;
										}
										else //not yet registered emails

										{
												$resultArray['not_registered_emails'][] = $toEmail;
												$resultArray['invite_emails'][] = $toEmail;
										}
								}
								else  $resultArray['invalid_emails'][] = $toEmail;
						} //end foreach
				} //end if
				return $resultArray;
		} //end _getInviteResult()
		#***************************************************************************
		#Method			: recentlyupdated
		#Description	: show recently updated friends list
		#***************************************************************************
		function recentlyupdated($userId = '')
		{
				$this->load->model('friendsmodel');
				$this->load->model('usermodel');
				if ($userId == '') $userId = $this->session->userdata('user_id');
				//Load the config file related to photo
				$this->config->load('photo');
				//Load the pagination model
				$this->load->model('paginationmodel');
				//Load the pagination language file
				$this->lang->load('pagination', $this->config->item('language_code'));
				$perPage = $this->paginationmodel->getPerPage('friends');
				$start = (trim($this->uri->segment(4)) != '' && is_numeric($this->uri->segment(4)) && $this->uri->segment(4) > 0) ? $this->uri->segment(4) : 1;
				$start = ($start - 1) * $perPage;
				$outputData['friends_list'] = $this->friendsmodel->recentlyupdated($userId, 'active', 'last_modified desc', $start, $perPage);
				$outputData['friends_list_count'] = count($outputData['friends_list']);
				$outputData['view_user_id'] = $userId; //user
				$outputData['view_user_name'] = $this->usermodel->getName($userId);
				$outputData['view_user_avatar'] = $this->usermodel->getAvatar($userId);
				$outputData['recently_updated'] = true;
				$outputData['friends_heading'] = $this->lang->line('friends_label_recently_updated');
				$outputData['totalFriendsCount'] = count($this->friendsmodel->recentlyupdatedCount($userId));
				$outputData['currentPage'] = (trim($this->uri->segment(4)) != '' && is_numeric($this->uri->segment(4))) ? $this->uri->segment(4) : 1;
				$outputData['totalPages'] = ($outputData['totalFriendsCount'] > $perPage) ? ceil(($outputData['totalFriendsCount'] / $perPage)) : 0;
				$outputData['pageUrl'] = base_url() . 'friends/recentlyupdated/' . $userId . '/';
				$outputData['endCount'] = $start + $outputData['friends_list_count'];
				$outputData['startCount'] = $start + 1;
				$this->smartyextended->view('friends', $outputData);
		} //end recentlyupdated
		#***************************************************************************
		#Method			: recentlyadded
		#Description	: show recently added friends in friends list
		#***************************************************************************
		function recentlyadded($userId = '')
		{
				$this->load->model('friendsmodel');
				$this->load->model('usermodel');
				if ($userId == '') $userId = $this->session->userdata('user_id');
				//Load the config file related to photo
				$this->config->load('photo');
				//Load the pagination model
				$this->load->model('paginationmodel');
				//Load the pagination language file
				$this->lang->load('pagination', $this->config->item('language_code'));
				$perPage = $this->paginationmodel->getPerPage('friends');
				$start = (trim($this->uri->segment(4)) != '' && is_numeric($this->uri->segment(4)) && $this->uri->segment(4) > 0) ? $this->uri->segment(4) : 1;
				$start = ($start - 1) * $perPage;
				$outputData['friends_list'] = $this->friendsmodel->recentlyadded($userId, $start, $perPage);
				$outputData['friends_list_count'] = count($outputData['friends_list']);
				$outputData['view_user_id'] = $userId; //user
				$outputData['view_user_name'] = $this->usermodel->getName($userId);
				$outputData['view_user_avatar'] = $this->usermodel->getAvatar($userId);
				$outputData['recently_added'] = true;
				$outputData['friends_heading'] = $this->lang->line('friends_label_recently_added');
				$outputData['totalFriendsCount'] = count($this->friendsmodel->recentlyadded($userId));
				$outputData['currentPage'] = (trim($this->uri->segment(4)) != '' && is_numeric($this->uri->segment(4))) ? $this->uri->segment(4) : 1;
				$outputData['totalPages'] = ($outputData['totalFriendsCount'] > $perPage) ? ceil(($outputData['totalFriendsCount'] / $perPage)) : 0;
				$outputData['pageUrl'] = base_url() . 'friends/recentlyadded/' . $userId . '/';
				$outputData['endCount'] = $start + $outputData['friends_list_count'];
				$outputData['startCount'] = $start + 1;
				$this->smartyextended->view('friends', $outputData);
		} //end recentlyadded
		#***************************************************************************
		#Method			: online
		#Description	: show all online friends
		#***************************************************************************
		function online($userId = '')
		{
				$this->load->model('friendsmodel');
				$this->load->model('usermodel');
				if ($userId == '') $userId = $this->session->userdata('user_id');
				//Load the config file related to photo
				$this->config->load('photo');
				//Load the pagination model
				$this->load->model('paginationmodel');
				//Load the pagination language file
				$this->lang->load('pagination', $this->config->item('language_code'));
				$perPage = $this->paginationmodel->getPerPage('friends');
				$start = (trim($this->uri->segment(4)) != '' && is_numeric($this->uri->segment(4)) && $this->uri->segment(4) > 0) ? $this->uri->segment(4) : 1;
				$start = ($start - 1) * $perPage;
				$outputData['friends_list'] = $this->friendsmodel->onlineNow($userId, 'active', 'last_modified desc', $start, $perPage);
				$outputData['friends_list_count'] = count($outputData['friends_list']);
				$outputData['view_user_id'] = $userId; //user
				$outputData['view_user_name'] = $this->usermodel->getName($userId);
				$outputData['view_user_avatar'] = $this->usermodel->getAvatar($userId);
				$outputData['online_now'] = true;
				$outputData['friends_heading'] = $this->lang->line('friends_label_online');
				$outputData['totalFriendsCount'] = count($this->friendsmodel->onlineNow($userId));
				$outputData['currentPage'] = (trim($this->uri->segment(4)) != '' && is_numeric($this->uri->segment(4))) ? $this->uri->segment(4) : 1;
				$outputData['totalPages'] = ($outputData['totalFriendsCount'] > $perPage) ? ceil(($outputData['totalFriendsCount'] / $perPage)) : 0;
				$outputData['pageUrl'] = base_url() . 'friends/online/' . $userId . '/';
				$outputData['endCount'] = $start + $outputData['friends_list_count'];
				$outputData['startCount'] = $start + 1;
				$this->smartyextended->view('friends', $outputData);
		} //end recentlyadded
		function addFriend()
		{
				$this->load->model('friendsModel');
				if ($this->input->post('hdn_friend_id'))
				{
						//			$newFriend	= array('friend_email'		=> $this->session->userdata('email'),
						//								'friend_id'			=> $this->input->post('hdn_friend_id'),
						//								'invite_message'	=> $this->input->post('hdn_friend_message')
						//								);
						$toIds = $this->usermodel->getEmail($this->input->post('hdn_friend_id'));
						$config = array('to_ids' => $toIds, 'message' => $this->input->post('hdn_friend_message'));
						$resultMsg = $this->_sendInvitation($config);
						$this->session->set_flashdata('flash_msg', implode('<br>', $resultMsg));
						//if($this->friendsModel->newInvitation($newFriend))
						//$this->session->set_flashdata('flash_msg', $this->lang->line($resultMsg));
						//else
						//$this->session->set_flashdata('flash_msg', $this->lang->line('friends_add_friend_error_msg'));
				}
				else  $this->session->set_flashdata('flash_msg', $this->lang->line('friends_add_friend_error_msg'));
				redirect("friends");
		}
}
?>