<?php /* Smarty version 2.6.18, created on 2007-12-17 20:02:35
         compiled from index.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'getdates', 'index.tpl', 23, false),array('function', 'getmovie', 'index.tpl', 55, false),array('function', 'getimage', 'index.tpl', 56, false),array('function', 'runtime', 'index.tpl', 60, false),)), $this); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<title id="title">Movie listings for <?php echo $this->_tpl_vars['data']->location->formattedname; ?>
</title>
<script type="text/javascript" src="/content/js/main.js"></script>
<link href="/content/styles/main.css" type="text/css" rel="stylesheet" />
</head>
<body>
<div id="wrapper">
<div id="left">
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "../advertisements/left.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
</div>
<div id="middle">
<form method="get" action="/">
	<div id="borderControl">
	<div id="logo"><img src="/content/images/logo.gif" alt="Movie Searcher" /></div>
	<div id="pushDown">
		<div id="dateContainer">
			<div id="dateDesc">Select Date:</div>
			<div id="date">
				<select id="dateSelect" name="date">
				<?php echo smarty_function_getdates(array('dates' => $this->_tpl_vars['dates'],'selected' => $this->_tpl_vars['date']), $this);?>

				</select>
			</div>
		</div>
		<div id="searchContainer">
			<div id="searchDesc">City, State or Zip code:</div>
			<div id="search">
				<input id="location" type="text" name="location" value="<?php echo $this->_tpl_vars['data']->location->formattedname; ?>
"  onblur="fieldClear(this);" onfocus="fieldClear(this);" />
				<input type="submit" name="submit" value="Go" />
			</div>
		</div>
	</div>
	<div class="clear"></div>
	</div>
</form>
<?php if ($this->_tpl_vars['notFound']): ?>
City not found. Please try again.
<?php else: ?>
<?php $this->assign('theaters', $this->_tpl_vars['data']->theaters->theater); ?>
<?php $_from = $this->_tpl_vars['theaters']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['theater']):
?>
<div class="theater">
	<div class="theaterName"><?php echo $this->_tpl_vars['theater']->name; ?>
</div>
	<div class="theaterInfo"><?php echo $this->_tpl_vars['theater']->address1; ?>
, <?php echo $this->_tpl_vars['theater']->city; ?>
, <?php echo $this->_tpl_vars['theater']->state; ?>
 <?php echo $this->_tpl_vars['theater']->postalcode; ?>
, <strong><?php echo $this->_tpl_vars['theater']->phonenumber; ?>
</strong> <a class="mapLink" href="http://maps.google.com/maps?f=d&amp;hl=en&amp;daddr=<?php echo $this->_tpl_vars['theater']->address1; ?>
, <?php echo $this->_tpl_vars['theater']->city; ?>
, <?php echo $this->_tpl_vars['theater']->state; ?>
 <?php echo $this->_tpl_vars['theater']->postalcode; ?>
&amp;saddr=&amp;ie=UTF8&amp;z=16&amp;om=1" target="_blank">Map &amp; Driving Directions</a></div>
	<table class="theaterTable" width="100%" cellpadding="0" cellspacing="0">
	<?php $count=1;$style=1; ?>
	<?php $_from = $this->_tpl_vars['theater']->movies->movie; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['movieattheater']):
?>
		<?php 
			if ($count % 2) {echo "<tr class=\"movieRow{$style}\">";
			if ($style==1) $style=2;
			else $style=1;}
		 ?>
		<td width="50%">
		<?php echo smarty_function_getmovie(array('var' => 'movie','value' => $this->_tpl_vars['movieattheater']), $this);?>

		<div class="poster"><img onmouseover="onHover(event,<?php echo $this->_tpl_vars['movie']['id']; ?>
)" onmouseout="unHover(<?php echo $this->_tpl_vars['movie']['id']; ?>
)" src="<?php echo smarty_function_getimage(array('href' => $this->_tpl_vars['movie']['posterhref']), $this);?>
" alt="<?php echo $this->_tpl_vars['movie']->title; ?>
" /></div>
		<div class="movieTitle"><a target="_blank" href="http://www.fandango.com/MoviePage.aspx?mid=<?php echo $this->_tpl_vars['movie']['id']; ?>
" onmouseover="onHover(event,<?php echo $this->_tpl_vars['movie']['id']; ?>
)" onmouseout="unHover(<?php echo $this->_tpl_vars['movie']['id']; ?>
)"><?php echo $this->_tpl_vars['movie']->title; ?>
</a></div>
		<div class="movieRuntime">
			<img src="/content/images/rating_<?php echo $this->_tpl_vars['movie']->rating; ?>
.gif" alt="<?php echo $this->_tpl_vars['movie']->rating; ?>
" />
			<?php echo smarty_function_runtime(array('time' => $this->_tpl_vars['movie']->runtime), $this);?>

		</div>
		<div class="showtimes">
		<strong>Showtimes:</strong>
		<?php $_from = $this->_tpl_vars['movieattheater']->performances->performance; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }$this->_foreach['performance'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['performance']['total'] > 0):
    foreach ($_from as $this->_tpl_vars['performance']):
        $this->_foreach['performance']['iteration']++;
?>
			<?php echo $this->_tpl_vars['performance']['showtime']; ?>
		<?php endforeach; endif; unset($_from); ?>
		</div>
		</td>
		<?php if (++$count % 2)echo '</tr>'; ?>
	<?php endforeach; else: ?>
		<table class="theaterTable" width="100%" cellpadding="0" cellspacing="0">
			<tr class="movieRow1"><td style="padding-left:4px">No movies listed. Please call for showtimes.</td></tr>
		</table>
	<?php endif; unset($_from); ?>
		<?php if (++$count % 2)echo '<td>&nbsp;</td></tr>'; ?>
		<tr class="moveRow<?php echo $style ?>">
			<td colspan="2">
				<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "../advertisements/bottom.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
			</td>
		</tr>
	</table>
</div>
<?php endforeach; else: ?>
No theaters found. Please try another city.
<?php endif; unset($_from); ?>
<?php $_from = $this->_tpl_vars['data']->movies->movie; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['movie']):
?>
<div id="movie<?php echo $this->_tpl_vars['movie']['id']; ?>
" class="popup">
	<div class="popupPoster"><img class="popupImage" src="<?php echo smarty_function_getimage(array('href' => $this->_tpl_vars['movie']['posterhref']), $this);?>
" alt="<?php echo $this->_tpl_vars['movie']->title; ?>
" /></div>
	<div class="popupTitle"><?php echo $this->_tpl_vars['movie']->title; ?>
 <img src="/content/images/rating_<?php echo $this->_tpl_vars['movie']->rating; ?>
.gif" alt="<?php echo $this->_tpl_vars['movie']->rating; ?>
" /></div>
	<div class="popupCast">
	<strong>Cast:</strong>
	<?php $_from = $this->_tpl_vars['movie']->cast->member; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }$this->_foreach['cast'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['cast']['total'] > 0):
    foreach ($_from as $this->_tpl_vars['cast']):
        $this->_foreach['cast']['iteration']++;
?>
		<?php echo $this->_tpl_vars['cast']; ?>
<?php if (! ($this->_foreach['cast']['iteration'] == $this->_foreach['cast']['total'])): ?>, <?php endif; ?>
	<?php endforeach; endif; unset($_from); ?>
	</div>
	<div class="popupRuntime"><strong>Running time:</strong> <?php echo smarty_function_runtime(array('time' => $this->_tpl_vars['movie']->runtime), $this);?>
</div>
	<div class="popupSynopsis"><?php echo $this->_tpl_vars['movie']->synopsis; ?>
</div>
</div>
<?php endforeach; endif; unset($_from); ?>
<?php endif; ?>
</div>
<div id="right">
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "../advertisements/right.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
</div>
</body>
</html>