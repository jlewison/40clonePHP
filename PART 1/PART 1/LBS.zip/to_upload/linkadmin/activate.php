<?php
include('restrict.php');
include('../settings.php');
require_once('../Connections/apound.php');

$id = $_GET[id];
$x = $_GET[x];
$avail = "Y";
$paid = "Y";

$link = mysql_pconnect($hostname_apound,$username_apound,$password_apound);
mysql_select_db($database_apound);
mysql_query("UPDATE main SET avail='$avail' WHERE dtu='$id'");
mysql_query("UPDATE main SET paid='$paid' WHERE dtu='$id'");

mysql_select_db($database_apound, $apound);
$query_SMTC = "SELECT * FROM main WHERE main.dtu = '$id'";
$SMTC = mysql_query($query_SMTC, $apound) or die(mysql_error());
$row_SMTC = mysql_fetch_assoc($SMTC);
$totalRows_SMTC = mysql_num_rows($SMTC);
$custm = $row_SMTC['email'];
$cbidid = $row_SMTC['dtu'];
$ckeyword = $row_SMTC['title'];
$curl = $row_SMTC['site'];


$kinek = "$custm";
$targy = "ACTIVATION - Thank you for your listing";
$uzenet = "Your Listing ID: $cbidid is ENABLED\n
Your Listing Title: $ckeyword\n
Your Listing URL: $curl\n
View details or upgrade your listing: http://$domainname$pathmail/upgrade.php?ucat=$cbidid
--------------------------------------------------------------------------
$bidmailmessage
--------------------------------------------------------------------------
Contact and Support: http://$domainname$pathmail/contact.php";
$fejlec = "From: $sitetitle <$frommail>\r\n";
mail($kinek, $targy, $uzenet, $fejlec);

mysql_free_result($SMTC);


/* ############################################## */
/*                                                */
/* Start overbid notification section for lbs 1.5 */
/*                                                */
/* ############################################## */


// Check if overbid notification are enabled or no

mysql_select_db($database_apound, $apound);
$query_OBST = "SELECT overbid FROM confset";
$OBST = mysql_query($query_OBST, $apound) or die(mysql_error());
$row_OBST = mysql_fetch_assoc($OBST);
$totalRows_OBST = mysql_num_rows($OBST);

$o_enabled = $row_OBST['overbid'];

mysql_free_result($OBST);


if($o_enabled == 'Y') {
						// Select the new bid details
						
						mysql_select_db($database_apound, $apound);
						$query_OBN = "SELECT * FROM main WHERE dtu = '$id'";
						$OBN = mysql_query($query_OBN, $apound) or die(mysql_error());
						$row_OBN = mysql_fetch_assoc($OBN);
						$totalRows_OBN = mysql_num_rows($OBN);
						
						$nb_dtu = $row_OBN['dtu'];
						$nb_categ = $row_OBN['categ'];
						$nb_bid = $row_OBN['bid'];
						$nb_maincategory = $row_OBN['maincategory'];
						
						mysql_free_result($OBN);
						
						// Using the new bid details, select the 'overbid record' for LETTER
						
						mysql_select_db($database_apound, $apound);
						$query_OLDa = "SELECT * FROM main WHERE categ = '$nb_categ' AND bid < '$nb_bid' AND avail = 'Y' ORDER BY bid DESC";
						$OLDa = mysql_query($query_OLDa, $apound) or die(mysql_error());
						$row_OLDa = mysql_fetch_assoc($OLDa);
						$totalRows_OLDa = mysql_num_rows($OLDa);
						
						$old_id_L = $row_OLDa['dtu'];
						$old_bid_L = $row_OLDa['bid'];
						$old_site_L = $row_OLDa['site'];
						$old_email_L = $row_OLDa['email'];
						
						mysql_free_result($OLDa);
						
						// Using the new bid details, select the 'overbid record' for CATEGORY
						
						mysql_select_db($database_apound, $apound);
						$query_OLDb = "SELECT * FROM main WHERE maincategory = '$nb_maincategory' AND bid < '$nb_bid' AND avail = 'Y' ORDER BY bid DESC";
						$OLDb = mysql_query($query_OLDb, $apound) or die(mysql_error());
						$row_OLDb = mysql_fetch_assoc($OLDb);
						$totalRows_OLDb = mysql_num_rows($OLDb);
						
						$old_id_C = $row_OLDb['dtu'];
						$old_bid_C = $row_OLDb['bid'];
						$old_site_C = $row_OLDb['site'];
						$old_email_C = $row_OLDb['email'];
						
						mysql_free_result($OLDb);
						
						$seo_name = $row_OLDb['title']; $seo_name = str_replace(" ", "-", $seo_name); $seo_name = "$seo_name";
						
						// Get the outbid message template from the database
						
						mysql_select_db($database_apound, $apound);
						$query_OBT = "SELECT overbid_L_s, overbid_L, overbid_C_s, overbid_C FROM confset";
						$OBT = mysql_query($query_OBT, $apound) or die(mysql_error());
						$row_OBT = mysql_fetch_assoc($OBT);
						$totalRows_OBT = mysql_num_rows($OBT);
						
						$overbid_L_s = $row_OBT['overbid_L_s'];
						$overbid_C_s = $row_OBT['overbid_C_s'];
						
						$overbid_L = $row_OBT['overbid_L'];
						eval("\$overbid_L = \"$overbid_L\";");
						
						$overbid_C = $row_OBT['overbid_C'];
						eval("\$overbid_C = \"$overbid_C\";");
						
						mysql_free_result($OBT);
						
						// Send out the overbid mail for LETTER
						
						$kinek  = "$old_email_L";
						$targy = "$overbid_L_s";
						$uzenet = "$overbid_L";
						$fejlec = "From: $sitetitle <$frommail>\r\n";
						mail($kinek, $targy, $uzenet, $fejlec);
						
						// Send out the overbid mail for CATEGORY
						
						$kinek  = "$old_email_C";
						$targy = "$overbid_L_s";
						$uzenet = "$overbid_L";
						$fejlec = "From: $sitetitle <$frommail>\r\n";
						mail($kinek, $targy, $uzenet, $fejlec);
}
else {}
/* #############################################*/
/*                                              */
/* End overbid notification section for lbs 1.5 */
/*                                              */
/* #############################################*/
header("Location: http://$x");
?>