</table>
</table>
</table>
<tr>
<td height="24" align="center" class="copyrights"><div style="font-size: 9px;">Powered by <a style="font-size: 9px" href="http://www.jeuxgagnants.com" target=_blank>xxxxxxxx</a></div></td>
</table>
</table>

</body>
</html>