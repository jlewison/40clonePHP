<?php include('restrict.php'); include('../settings.php'); ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>Add New Listing - Link Bid Script Admin Panel</title>
<link rel="shortcut icon" href="img/favicon.ico" />
<link rel="stylesheet" type="text/css" href="admin.css" />

<SCRIPT language=javascript>
function gurl(l){ 
	document.location.href='/'+l+'/';
}

function dodiv() { 
	var frm = document.pgfrm; 
	var tt=frm.keyword.value; 
	var dd1=frm.descr1.value; 
	var dd2=frm.descr2.value; 
	var dd3=frm.url.value; 
	var bbd=frm.bid.value; 
	
	if (tt) { document.getElementById('kw').innerHTML=tt; } 
	else {  document.getElementById('kw').innerHTML="Example Title"; } 
	
	if (dd1) { document.getElementById('d1').innerHTML=dd1; } 
	else {  document.getElementById('d1').innerHTML="Description line 1 sample"; } 
	
	if (dd3) { document.getElementById('d3').innerHTML=dd3; } 
	
	else {  document.getElementById('d3').innerHTML="http://your_site.com/"; } 
	
	if (bbd) { document.getElementById('bidd').innerHTML=bbd; } 
	else {  document.getElementById('bidd').innerHTML="<?php echo("$minbid");?>"; }
} 
	
function chknum(evt) { 
	var charCode = (evt.which) ? evt.which : event.keyCode; 
	
	if (charCode > 31 && (charCode < 48 || charCode > 57)) return false; return true;
} 
	
function chkfrm() { 
	var frm = document.pgfrm; 
	if (!frm.selectc.value.replace(/^\s*|\s*$/g,"")) { alert("Please selest category for your listing"); frm.selectc.focus(); return false; } 
	if (!frm.email.value.replace(/^\s*|\s*$/g,"")) { alert("You must provide an e-mail address."); frm.email.focus(); return false; } 
	if (!frm.url.value.replace(/^\s*|\s*$/g,"") || frm.url.value.replace(/^\s*|\s*$/g,"") == "http://") { alert("You must provide a website URL."); frm.url.focus(); return false; } 
	if (!frm.keyword.value.replace(/^\s*|\s*$/g,"")) { alert("Please enter the title for your listing"); frm.keyword.focus(); return false; } 
	if (!frm.descr1.value.replace(/^\s*|\s*$/g,"")) { alert("You must provide a brief description."); frm.descr1.focus(); return false; } 
	if (!frm.descr2.value.replace(/^\s*|\s*$/g,"")) { alert("You must provide an extended description."); frm.descr2.focus(); return false; } 
	if (!frm.bid.value.replace(/^\s*|\s*$/g,"")) { alert("You must provide a bid amount."); frm.bid.focus(); return false; } 
	if (!frm.gm_str.value.replace(/^\s*|\s*$/g,"")) { alert("You must provide a street name."); frm.gm_str.focus(); return false; } 
	if (!frm.gm_str_nr.value.replace(/^\s*|\s*$/g,"")) { alert("You must provide a street number."); frm.gm_str_nr.focus(); return false; } 
	if (!frm.gm_city.value.replace(/^\s*|\s*$/g,"")) { alert("You must provide a city."); frm.gm_city.focus(); return false; } 
	if (!frm.gm_county.value.replace(/^\s*|\s*$/g,"")) { alert("You must provide a county."); frm.gm_county.focus(); return false; } 
	if (!frm.gm_country.value.replace(/^\s*|\s*$/g,"")) { alert("You must provide a country."); frm.gm_country.focus(); return false; } 
} 
</SCRIPT>
<style type="text/css">
<!--
.style84 {font-size: 12px; color: #009933; }
-->
</style>
</head>

<body>
<?php $x = getenv("HTTP_HOST").getenv("REQUEST_URI"); ?>
<?php include('header_tpl.php'); ?>
<?php
mysql_select_db($database_apound, $apound);
$query_LboxCAT = "SELECT * FROM categorylisting ORDER BY categorylisting.categoryname ASC";
$LboxCAT = mysql_query($query_LboxCAT, $apound) or die(mysql_error());
$row_LboxCAT = mysql_fetch_assoc($LboxCAT);
$totalRows_LboxCAT = mysql_num_rows($LboxCAT);
?>
<h2>Add New Listing</h2>
<table width="770"  border="0" align="center" cellpadding="3" cellspacing="1" bgcolor="#FFFFFF">
  <tr>
    <td width="760" valign="top"><form action="admin_processing.php" method="post">
      <table border="0" align="center" cellpadding="6" cellspacing="1">
        <tr valign="baseline">
          <td align="right" nowrap class="style67 style82">Category:</td>
          <td bgcolor="#FFFFFF"><select name="selectc" id="selectc">
            <option value="" selected>Please select the category</option>
            <?php do { ?>
            <option value="<?php echo $row_LboxCAT['catlistid']?>"><?php echo $row_LboxCAT['categoryname']?></option>
            <?php } while ($row_LboxCAT = mysql_fetch_assoc($LboxCAT)); $rows = mysql_num_rows($LboxCAT); if($rows > 0) { mysql_data_seek($LboxCAT, 0); $row_LboxCAT = mysql_fetch_assoc($LboxCAT); } ?>
          </select></td>
        </tr>
        <tr valign="baseline">
          <td align="right" nowrap class="style67 style82">Email address:</td>
          <td bgcolor="#FFFFFF"><input name="email" type="text" class="edtab1" size="32" /></td>
        </tr>
        <tr valign="baseline">
          <td align="right" nowrap class="style67 style82">Website Title:</td>
          <td bgcolor="#FFFFFF"><input name="keyword" type="text" class="edtab1" size="32" /></td>
        </tr>
        <tr valign="baseline">
          <td align="right" nowrap class="style67 style82">Website URL:</td>
          <td bgcolor="#FFFFFF"><input name="url" type="text" class="edtab1" value="http://" size="32" /></td>
        </tr>
        <tr valign="baseline">
          <td align="right" valign="top" nowrap class="style67 style82">Brief Description :</td>
          <td bgcolor="#FFFFFF"><textarea name="descr1" class="edtab2"></textarea></td>
        </tr>
        <tr valign="baseline">
          <td align="right" valign="top" nowrap class="style67 style82">Extended Description :</td>
          <td bgcolor="#FFFFFF"><textarea  name="descr2" class="edtab22"></textarea></td>
        </tr>
        <tr valign="baseline">
          <td align="right" valign="top" nowrap class="style67 style82">Meta Description :</td>
          <td bgcolor="#FFFFFF"><textarea name="mdesc" class="edtab2"></textarea></td>
        </tr>
        <tr valign="baseline">
          <td align="right" nowrap class="style67 style82">Meta Keywords :</td>
          <td bgcolor="#FFFFFF"><input name="mword" type="text" class="edtab1" value="" size="32" /></td>
        </tr>
        <tr valign="baseline">
          <td align="right" nowrap class="style67 style82">Deep Title 1:</td>
          <td bgcolor="#FFFFFF"><input name="deeptf" type="text" class="edtab1" value="" size="32" /></td>
        </tr>
        <tr valign="baseline">
          <td align="right" nowrap class="style67 style82">Deep URL 1:</td>
          <td bgcolor="#FFFFFF"><input name="dfurl" type="text" class="edtab1" value="http://" size="32" /></td>
        </tr>
        <tr valign="baseline">
          <td align="right" nowrap class="style67 style82">Deep Title 2:</td>
          <td bgcolor="#FFFFFF"><input name="deepts" type="text" class="edtab1" value="" size="32" /></td>
        </tr>
        <tr valign="baseline">
          <td align="right" nowrap class="style67 style82">Deep URL 2:</td>
          <td bgcolor="#FFFFFF"><input name="dsurl" type="text" class="edtab1" value="http://" size="32" /></td>
        </tr>
        <tr valign="baseline">
          <td align="right" nowrap class="style67 style82">Deep Title 3:</td>
          <td bgcolor="#FFFFFF"><input name="deeptt" type="text" class="edtab1" value="" size="32" /></td>
        </tr>
        <tr valign="baseline">
          <td align="right" nowrap class="style67 style82">Deep URL 3:</td>
          <td bgcolor="#FFFFFF"><input name="dturl" type="text" class="edtab1" value="http://" size="32" /></td>
        </tr>
        <tr valign="baseline">
          <td align="right" nowrap class="style67 style82">Bid: <?php echo("$currency");?> </td>
          <td bgcolor="#FFFFFF"><input name="bid" value="0.00" class="edtab1" size="32" /></td>
        </tr>
        <?php /*?>        <tr valign="baseline">
          <td align="right" nowrap class="style67 style82">Start Date :</td>
          <td bgcolor="#FFFFFF"><input name="stad" type="text" class="edtab1" value="<?php echo date ("Y-m-d"); ?>" size="32"></td>
        </tr>
        <tr valign="baseline">
          <td align="right" nowrap class="style67 style82">End Date :</td>
          <td bgcolor="#FFFFFF"><input name="stod" type="text" class="edtab1" value="<?php echo date ("Y-m-d"); ?>" size="32"></td>
        </tr><?php */?>
        <tr valign="baseline">
          <td align="right" valign="middle" nowrap class="style67 style82">Available:</td>
          <td valign="baseline" bgcolor="#FFFFFF"><table>
            <tr>
              <td class="edtab"><input name="avail" type="radio" value="Y" checked="checked" />
                Yes</td>
              <td></td>
            </tr>
            <tr>
              <td class="edtab"><input type="radio" name="avail" value="N" />
                No</td>
              <td></td>
            </tr>
          </table></td>
        </tr>
        <tr valign="baseline">
          <td align="right" valign="middle" nowrap class="style67 style82">Paid:</td>
          <td valign="baseline" bgcolor="#FFFFFF"><table>
            <tr>
              <td class="edtab"><input name="paid" type="radio" value="Y" checked="checked" />
                Yes</td>
              <td></td>
            </tr>
            <tr>
              <td class="edtab"><input type="radio" name="paid" value="N" />
                No</td>
              <td></td>
            </tr>
          </table></td>
        </tr>
        <tr valign="baseline">
          <td align="right" valign="middle" nowrap class="style67 style82">House name or number:</td>
          <td><input name="gm_str_nr" type="text" id="gm_str_nr" size="10" /></td>
        </tr>
        <tr valign="baseline">
          <td align="right" valign="middle" nowrap class="style67 style82">Street:</td>
          <td><label>
            <input name="gm_str" type="text" id="gm_str" size="51" />
          </label></td>
        </tr>
        <tr valign="baseline">
          <td align="right" valign="middle" nowrap class="style67 style82">Town/City:</td>
          <td><input name="gm_city" type="text" id="gm_city" size="51" /></td>
        </tr>
        <tr valign="baseline">
          <td align="right" valign="middle" nowrap class="style67 style82">County:</td>
          <td><input name="gm_county" type="text" id="gm_county" size="51" /></td>
        </tr>
        <tr valign="baseline">
          <td align="right" valign="middle" nowrap class="style67 style82">Country:</td>
          <td><select name="gm_country" id="gm_country">
            <option value="0">Select Country</option>
            <option value="AF">AF - Afghanistan</option>
            <option value="AL">AL - Albania</option>
            <option value="DZ">DZ - Algeria</option>
            <option value="AS">AS - American Samoa</option>
            <option value="AD">AD - Andorra</option>
            <option value="AO">AO - Angola</option>
            <option value="AI">AI - Anguilla</option>
            <option value="AQ">AQ - Antarctica</option>
            <option value="AG">AG - Antigua and Bar</option>
            <option value="AR">AR - Argentina</option>
            <option value="AM">AM - Armenia</option>
            <option value="AW">AW - Aruba</option>
            <option value="AT">AT - Austria</option>
            <option value="AZ">AZ - Azerbaijan</option>
            <option value="BS">BS - Bahamas</option>
            <option value="BH">BH - Bahrain</option>
            <option value="BD">BD - Bangladesh</option>
            <option value="BB">BB - Barbados</option>
            <option value="BY">BY - Belarus</option>
            <option value="BE">BE - Belgium</option>
            <option value="BZ">BZ - Belize</option>
            <option value="BJ">BJ - Benin</option>
            <option value="BM">BM - Bermuda</option>
            <option value="BT">BT - Bhutan</option>
            <option value="BO">BO - Bolivia</option>
            <option value="BA">BA - Bosnia and Herz</option>
            <option value="BW">BW - Botswana</option>
            <option value="BV">BV - Bouvet Island</option>
            <option value="BR">BR - Brazil</option>
            <option value="IO">IO - British Indian </option>
            <option value="BN">BN - Brunei Darussal</option>
            <option value="BG">BG - Bulgaria</option>
            <option value="BF">BF - Burkina Faso</option>
            <option value="BI">BI - Burundi</option>
            <option value="KH">KH - Cambodia</option>
            <option value="CM">CM - Cameroon</option>
            <option value="CA">CA - Canada</option>
            <option value="CV">CV - Cape Verde</option>
            <option value="KY">KY - Cayman Islands</option>
            <option value="CF">CF - Central African</option>
            <option value="TD">TD - Chad</option>
            <option value="CL">CL - Chile</option>
            <option value="CN">CN - China</option>
            <option value="CX">CX - Christmas Islan</option>
            <option value="CC">CC - Cocos (Keeling)</option>
            <option value="CO">CO - Colombia</option>
            <option value="KM">KM - Comoros</option>
            <option value="CG">CG - Congo</option>
            <option value="CK">CK - Cook Islands</option>
            <option value="CR">CR - Costa Rica</option>
            <option value="CI">CI - Cote D'Ivoire</option>
            <option value="HR">HR - Croatia</option>
            <option value="CU">CU - Cuba</option>
            <option value="CY">CY - Cyprus</option>
            <option value="CZ">CZ - Czech Republic</option>
            <option value="DK">DK - Denmark</option>
            <option value="DJ">DJ - Djibouti</option>
            <option value="DM">DM - Dominica</option>
            <option value="DO">DO - Dominican Repub</option>
            <option value="TP">TP - East Timor</option>
            <option value="EC">EC - Ecuador</option>
            <option value="EG">EG - Egypt</option>
            <option value="SV">SV - El Salvador</option>
            <option value="GQ">GQ - Equatorial Guin</option>
            <option value="ER">ER - Eritrea</option>
            <option value="EE">EE - Estonia</option>
            <option value="ET">ET - Ethiopia</option>
            <option value="FK">FK - Falkland Island</option>
            <option value="FO">FO - Faroe Islands</option>
            <option value="FJ">FJ - Fiji</option>
            <option value="FI">FI - Finland</option>
            <option value="FR">FR - France</option>
            <option value="FX">FX - France, Metropo</option>
            <option value="GF">GF - French Guiana</option>
            <option value="PF">PF - French Polynesi</option>
            <option value="TF">TF - French Southern</option>
            <option value="GA">GA - Gabon</option>
            <option value="GM">GM - Gambia</option>
            <option value="GE">GE - Georgia</option>
            <option value="DE">DE - Germany</option>
            <option value="GH">GH - Ghana</option>
            <option value="GI">GI - Gibraltar</option>
            <option value="GR">GR - Greece</option>
            <option value="GL">GL - Greenland</option>
            <option value="GD">GD - Grenada</option>
            <option value="GP">GP - Guadeloupe</option>
            <option value="GU">GU - Guam</option>
            <option value="GT">GT - Guatemala</option>
            <option value="GN">GN - Guinea</option>
            <option value="GW">GW - Guinea-bissau</option>
            <option value="GY">GY - Guyana</option>
            <option value="HT">HT - Haiti</option>
            <option value="HM">HM - Heard and Mc Do</option>
            <option value="HN">HN - Honduras</option>
            <option value="HK">HK - Hong Kong</option>
            <option value="HU">HU - Hungary</option>
            <option value="IS">IS - Iceland</option>
            <option value="ID">ID - In&lt;font colo</option>
            <option value="IN">IN - India</option>
            <option value="IR">IR - Iran (Islamic R</option>
            <option value="IQ">IQ - Iraq</option>
            <option value="IE">IE - Ireland</option>
            <option value="IL">IL - Israel</option>
            <option value="IT">IT - Italy</option>
            <option value="JM">JM - Jamaica</option>
            <option value="JP">JP - Japan</option>
            <option value="JO">JO - Jordan</option>
            <option value="KZ">KZ - Kazakhstan</option>
            <option value="KE">KE - Kenya</option>
            <option value="KI">KI - Kiribati</option>
            <option value="KP">KP - Korea, Democrat</option>
            <option value="KR">KR - Korea, Republic</option>
            <option value="KW">KW - Kuwait</option>
            <option value="KG">KG - Kyrgyzstan</option>
            <option value="LA">LA - Lao People's De</option>
            <option value="LV">LV - Latvia</option>
            <option value="LB">LB - Lebanon</option>
            <option value="LS">LS - Lesotho</option>
            <option value="LR">LR - Liberia</option>
            <option value="LY">LY - Libyan Arab Jam</option>
            <option value="LI">LI - Liechtenstein</option>
            <option value="LT">LT - Lithuania</option>
            <option value="LU">LU - Luxembourg</option>
            <option value="MO">MO - Macau</option>
            <option value="MK">MK - Macedonia, The </option>
            <option value="MG">MG - Madagascar</option>
            <option value="MW">MW - Malawi</option>
            <option value="MY">MY - Malaysia</option>
            <option value="MV">MV - Maldives</option>
            <option value="ML">ML - Mali</option>
            <option value="MT">MT - Malta</option>
            <option value="MH">MH - Marshall Island</option>
            <option value="MQ">MQ - Martinique</option>
            <option value="MR">MR - Mauritania</option>
            <option value="MU">MU - Mauritius</option>
            <option value="YT">YT - Mayotte</option>
            <option value="MX">MX - Mexico</option>
            <option value="FM">FM - Micronesia, Fed</option>
            <option value="MD">MD - Moldova, Republ</option>
            <option value="MC">MC - Monaco</option>
            <option value="MN">MN - Mongolia</option>
            <option value="MS">MS - Montserrat</option>
            <option value="MA">MA - Morocco</option>
            <option value="MZ">MZ - Mozambique</option>
            <option value="MM">MM - Myanmar</option>
            <option value="NA">NA - Namibia</option>
            <option value="NR">NR - Nauru</option>
            <option value="NP">NP - Nepal</option>
            <option value="NL">NL - Netherlands</option>
            <option value="AN">AN - Netherlands Ant</option>
            <option value="NC">NC - New Caledonia</option>
            <option value="NZ">NZ - New Zealand</option>
            <option value="NI">NI - Nicaragua</option>
            <option value="NE">NE - Niger</option>
            <option value="NG">NG - Nigeria</option>
            <option value="NU">NU - Niue</option>
            <option value="NF">NF - Norfolk Island</option>
            <option value="MP">MP - Northern Marian</option>
            <option value="NO">NO - Norway</option>
            <option value="OM">OM - Oman</option>
            <option value="PK">PK - Pakistan</option>
            <option value="PW">PW - Palau</option>
            <option value="PA">PA - Panama</option>
            <option value="PG">PG - Papua New Guine</option>
            <option value="PY">PY - Paraguay</option>
            <option value="PE">PE - Peru</option>
            <option value="PH">PH - Philippines</option>
            <option value="PN">PN - Pitcairn</option>
            <option value="PL">PL - Poland</option>
            <option value="PT">PT - Portugal</option>
            <option value="PR">PR - Puerto Rico</option>
            <option value="QA">QA - Qatar</option>
            <option value="RE">RE - Reunion</option>
            <option value="RO">RO - Romania</option>
            <option value="RU">RU - Russian Federat</option>
            <option value="RW">RW - Rwanda</option>
            <option value="KN">KN - Saint Kitts and</option>
            <option value="LC">LC - Saint Lucia</option>
            <option value="VC">VC - Saint Vincent a</option>
            <option value="WS">WS - Samoa</option>
            <option value="SM">SM - San Marino</option>
            <option value="ST">ST - Sao Tome and Pr</option>
            <option value="SA">SA - Saudi Arabia</option>
            <option value="SN">SN - Senegal</option>
            <option value="SC">SC - Seychelles</option>
            <option value="SL">SL - Sierra Leone</option>
            <option value="SG">SG - Singapore</option>
            <option value="SK">SK - Slovakia (Slova</option>
            <option value="SI">SI - Slovenia</option>
            <option value="SB">SB - Solomon Islands</option>
            <option value="SO">SO - Somalia</option>
            <option value="ZA">ZA - South Africa</option>
            <option value="GS">GS - South Georgia a</option>
            <option value="ES">ES - Spain</option>
            <option value="LK">LK - Sri Lanka</option>
            <option value="SH">SH - St. Helena</option>
            <option value="PM">PM - St. Pierre and </option>
            <option value="SD">SD - Sudan</option>
            <option value="SR">SR - Suriname</option>
            <option value="SJ">SJ - Svalbard and Ja</option>
            <option value="SZ">SZ - Swaziland</option>
            <option value="SE">SE - Sweden</option>
            <option value="CH">CH - Switzerland</option>
            <option value="SY">SY - Syrian Arab Rep</option>
            <option value="TW">TW - Taiwan</option>
            <option value="TJ">TJ - Tajikistan</option>
            <option value="TZ">TZ - Tanzania, Unite</option>
            <option value="TH">TH - Thailand</option>
            <option value="TG">TG - Togo</option>
            <option value="TK">TK - Tokelau</option>
            <option value="TO">TO - Tonga</option>
            <option value="TT">TT - Trinidad and To</option>
            <option value="TN">TN - Tunisia</option>
            <option value="TR">TR - Turkey</option>
            <option value="TM">TM - Turkmenistan</option>
            <option value="TC">TC - Turks and Caico</option>
            <option value="TV">TV - Tuvalu</option>
            <option value="UG">UG - Uganda</option>
            <option value="UA">UA - Ukraine</option>
            <option value="AE">AE - United Arab Emi</option>
            <option value="UK" selected="selected">UK - United Kingdom</option>
            <option value="US">US - United States</option>
            <option value="UM">UM - United States M</option>
            <option value="UY">UY - Uruguay</option>
            <option value="UZ">UZ - Uzbekistan</option>
            <option value="VU">VU - Vanuatu</option>
            <option value="VA">VA - Vatican City St</option>
            <option value="VE">VE - Venezuela</option>
            <option value="VN">VN - Viet Nam</option>
            <option value="VG">VG - Virgin Islands </option>
            <option value="VI">VI - Virgin Islands </option>
            <option value="WF">WF - Wallis and Futu</option>
            <option value="EH">EH - Western Sahara</option>
            <option value="YE">YE - Yemen</option>
            <option value="YU">YU - Yugoslavia</option>
            <option value="ZR">ZR - Zaire</option>
            <option value="ZM">ZM - Zambia</option>
            <option value="ZW">ZW - Zimbabwe</option>
          </select>          </td>
        </tr>
        <tr valign="baseline" bgcolor="#FFFFFF">
          <td align="right" nowrap>&nbsp;</td>
          <td align="right" nowrap bgcolor="#FFFFFF"><input type="submit" class="login-but" value="Add Listing" /></td>
        </tr>
      </table>
      <input type="hidden" value="1" name="categ" />
    </form></td>
  </tr>
</table>
<?php include('footer_tpl.php'); ?>
</body>
</html>
