<?php
require_once ('../common/config.inc.php');
$CFG['lang']['include_files'][] = 'members/includes/languages/%s/mailCompose.php';
$CFG['lang']['include_files'][] = 'common/email_templates/languages/%s/email_notify.inc.php';
$CFG['lang']['include_files'][] = 'members/includes/languages/%s/mailRightLinks.php';
$CFG['html']['header'] = 'members/includes/languages/%s/html_header.php';
$CFG['html']['footer'] = 'members/includes/languages/%s/html_footer.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['mods']['include_files'][] = 'common/classes/class_MailHandler.lib.php';
$CFG['mods']['include_files'][] = 'common/classes/phpmailer/class_PHPMailer.lib.php';
$CFG['lang']['include_files'][] = 'common/languages/%s/help.inc.php';
$CFG['lang']['include_files'][] = 'common/configs/config_mails.inc.php';
$CFG['db']['is_use_db'] = true;
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class MailComposeFormHandler extends MailHandler
{
		private $custid;
		public $message_id;
		public $send_ids;
		public function getUserId($user_name)
		{
				$sql = 'SELECT ' . $this->getUserTableFields(array('user_id', 'name', 'email', 'image_path', 'gender', 'usr_status', 'user_access')) . ' FROM ' . $this->CFG['db']['tbl']['users'] . ' WHERE ' . $this->getUserTableField('name') . '=' . $this->dbObj->Param($user_name);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($user_name));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($row = $rs->FetchRow())
				{
						$this->user_details[$row['user_id']]['email'] = $row['email'];
						$this->user_details[$row['user_id']]['name'] = $row['name'];
						$this->send_ids[] = $row['user_id'];
						return $row['user_id'];
				}
				$err_tip = str_replace('{friend}', $user_name, $this->LANG['mailcompose_err_tip_username_not_exceeds']);
				$this->common_error_message = $err_tip;
				return 0;
		}
		public function sendMail($to_user_name, $subject, $message, $err_tip = '')
		{
				$add_contact = true;
				$to_user_name = $this->fields_arr[$to_user_name];
				if (!strpos($to_user_name, ',')) $to_user_name .= ',';
				$toArr = explode(',', $to_user_name);
				foreach ($toArr as $value)
				{
						$value = trim($value);
						if ($value == '') continue;
						$value = ' ' . $value;
						if (strpos($value, '(') == 1)
						{
								if (strpos($value, ')') == strlen($value) - 1)
								{
										$value = str_replace('(', '', $value);
										$value = str_replace(')', '', $value);
										$value = trim($value);
										if (!$this->getUserId($value))
										{
												return false;
										}
								}
								else
								{
										$value = str_replace('(', '', $value);
										$err_tip = str_replace('{friend}', $value, $this->LANG['mailcompose_err_tip_username_not_exceeds']);
										$this->common_error_message = $err_tip;
										return false;
								}
						}
						else
								if ($value != ' ')
								{
										$value = trim($value);
										if (!$curr_id = $this->getUserId($value))
										{
												$err_tip = str_replace('{friend}', $value, $this->LANG['mailcompose_err_tip_username_not_exceeds']);
												$this->common_error_message = $err_tip;
												return false;
										}
										if (!$this->chkIsIntenalMailAllowed($curr_id))
										{
												$err_tip = str_replace('{friend}', $value, $this->LANG['mailcompose_err_tip_username_not_allowed_to_send_mail']);
												$this->common_error_message = $err_tip;
												return false;
										}
								}
				}
				$this->send_ids = array_unique($this->send_ids);
				if (!$this->send_ids) return false;
				$this->message_id = $this->insertMessages($subject, $message);
				if ($this->message_id)
				{
						foreach ($this->send_ids as $to_id)
						{
								if (!$to_id) continue;
								$this->insertMessagesInfo($this->CFG['user']['user_id'], $to_id, $this->message_id);
								$mail_url = getUrl($this->CFG['admin']['mail_urls']['read_inbox']['normal'] . '&message_id=' . $this->message_id, $this->CFG['admin']['mail_urls']['read_inbox']['htaccess'] . '?message_id=' . $this->message_id);
								$mail_link = '<a href="' . $mail_url . '">' . $mail_url . '</a>';
								$link = '<a href="' . $this->CFG['site']['url'] . '">' . $this->CFG['site']['url'] . '</a>';
								$subject = $this->LANG['new_mail_received_subject'];
								$subject = str_replace('{site_name}', $this->CFG['site']['name'], $subject);
								$message = $this->LANG['new_mail_received_content'];
								$message = str_replace('{receiver_name}', $this->user_details[$to_id]['name'], $message);
								$message = str_replace('{sender_name}', $this->CFG['user']['name'], $message);
								$message = str_replace('{mail_link}', $mail_link, $message);
								$message = str_replace('{link}', $link, $message);
								$message = str_replace('{site_name}', $this->CFG['site']['name'], $message);
								$from = $this->CFG['site']['noreply_email'];
								$to = $this->user_details[$to_id]['email'];
								$this->_sendEmail($from, $to, $subject, $message, true);
						}
						switch ($this->fields_arr['action'])
						{
								case 'reply':
										$this->updateMessageStatus($this->fields_arr['message_id'], $this->fields_arr['answer_id'], 'Reply');
										break;
								case 'forward':
										$this->updateMessageStatus($this->fields_arr['message_id'], $this->fields_arr['answer_id'], 'Forward');
										break;
						}
						return true;
				}
				$this->setCommonErrorMsg($err_tip);
				return false;
		}
		public function _sendEmail($from, $to, $subject, $message, $html = false)
		{
				$mailSent = false;
				$mail = new PHPMailer();
				$mail->AddAddress($to);
				$mail->FromName = $this->CFG['site']['noreply_name'];
				$mail->From = $mail->Sender = $from;
				$mail->Subject = $subject;
				$mail->Body = nl2br($message);
				$mail->IsMail();
				$mail->IsHTML($html);
				$mailSent = $mail->Send();
				return true;
		}
		public function insertMessages($subject, $message)
		{
				($this->fields_arr[$subject] == '') ? $this->fields_arr[$subject] = 'No subject' : '';
				$message = $this->fields_arr[$message];
				$original_message = '';
				if ($this->fields_arr['include_original_message'] == 'Yes')
				{
						switch ($this->fields_arr['action'])
						{
								case 'reply':
								case 'forward':
										$original_message = $this->getOriginalMessage($this->fields_arr['msgFolder'], $this->fields_arr['message_id']);
										break;
						}
				}
				if ($original_message)
				{
						$message .= addslashes($original_message);
				}
				$sql = 'INSERT INTO ' . $this->CFG['db']['tbl']['messages'] . ' SET subject = ' . $this->dbObj->Param($this->fields_arr[$subject]) . ', message =' . $this->dbObj->Param($message) . ', mess_date = NOW()';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr[$subject], $message));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return $this->dbObj->Insert_ID();
		}
		public function updateMessageStatus($message_id, $answer_id, $value)
		{
				$answer_column = 'from_answer';
				if ($answer_id == $this->CFG['user']['user_id'])
				{
						$answer_column = 'to_answer';
				}
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['messages_info'] . ' SET ' . $answer_column . '=' . $this->dbObj->Param($value) . ' WHERE info_id=' . $this->dbObj->Param($message_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($value, $message_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return true;
		}
		public function getOriginalMessage($msgFolder, $message_id)
		{
				if (!$msgFolder && !$message_id)
				{
						return false;
				}
				$sql = $this->getQuery($msgFolder, $message_id);
				if (!$sql)
				{
						return false;
				}
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, $this->sql_field_values);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($row = $rs->FetchRow())
				{
						$name = $row['name'];
						$itlalic_start_tag = '&lt;span style=\&quot;font-style: italic;\&quot;&gt;';
						$itlalic_end_tag = '&lt;/span&gt;';
						$newline = '&lt;br /&gt;';
						$original_message = $newline . $newline . $newline;
						$original_message .= $itlalic_start_tag . $this->LANG['mailcompose_original_message'] . $itlalic_end_tag . $newline;
						$original_message .= $itlalic_start_tag . $this->LANG['mailcompose_from'] . ': ' . $name . $itlalic_end_tag . $newline;
						$original_message .= $itlalic_start_tag . $this->LANG['mailcompose_sent'] . ': ' . $row['mess_date'] . $itlalic_end_tag . $newline;
						$original_message .= $itlalic_start_tag . $this->LANG['mailcompose_subject'] . ': ' . $row['subject'] . $itlalic_end_tag . $newline . $newline;
						$original_message .= $row['message'];
						return $original_message;
				}
				return false;
		}
		public function getMessage($action, $msgFolder, $message_id)
		{
				if (!$action || !$msgFolder || !$message_id)
				{
						return false;
				}
				$sql = $this->getQuery($msgFolder, $message_id);
				if (!$sql)
				{
						return false;
				}
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, $this->sql_field_values);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($row = $rs->FetchRow())
				{
						$name = $row['name'];
						$original_message = $this->LANG['mailcompose_original_message'] . '
' . $this->LANG['mailcompose_from'] . ': ' . $name . '
' . $this->LANG['mailcompose_sent'] . ': ' . $row['mess_date'] . '
' . $this->LANG['mailcompose_subject'] . ': ' . $row['subject'] . '

' . html_entity_decode(stripslashes($row['message']), ENT_QUOTES, $this->CFG['site']['charset']);
						if ($action == 'reply')
						{
								$this->setFormField('username', $row['name']);
								if (strpos($row['subject'], $this->LANG['mailcompose_reply_subject']) === 0) $this->LANG['mailcompose_reply_subject'] = '';
								$this->setFormField('subject', $this->LANG['mailcompose_reply_subject'] . stripslashes($row['subject']));
								$this->setFormField('include_original_message', 'No');
						}
						else
						{
								if (strpos($row['subject'], $this->LANG['mailcompose_forward_subject']) === 0) $this->LANG['mailcompose_forward_subject'] = '';
								$this->setFormField('subject', $this->LANG['mailcompose_forward_subject'] . stripslashes($row['subject']));
								$this->setFormField('include_original_message', 'Yes');
						}
						$this->setFormField('answer_id', $row['to_id']);
						$this->setFormField('original_message', $original_message);
						return true;
				}
				return false;
		}
		public function getQuery($msgFolder, $message_id)
		{
				$sql = '';
				$this->sql_field_values = array();
				switch ($msgFolder)
				{
						case 'inbox':
								$sql = 'SELECT mi.info_id, mi.message_id, ' . $this->getUserTableFields(array('user_id', 'name', 'image_path', 'gender')) . ', m.subject, m.message, mi.to_viewed, mi.to_answer, attachment, mi.to_id, mi.from_id, mi.email_status' . ', DATE_FORMAT(m.mess_date, \'' . $this->CFG['format']['date'] . '\') AS mess_date, DATE_FORMAT(m.mess_date, \'%I:%i %p\') AS mess_time' . ' FROM ' . $this->CFG['db']['tbl']['users'] . ' AS u' . ', ' . $this->CFG['db']['tbl']['messages'] . ' AS m' . ', ' . $this->CFG['db']['tbl']['messages_info'] . ' AS mi' . ' WHERE mi.to_id = ' . $this->dbObj->Param($this->CFG['user']['user_id']) . ' AND mi.from_id = u.' . $this->getUserTableField('user_id') . ' AND mi.message_id = m.message_id' . ' AND mi.to_delete = \'No\'' . ' AND mi.to_stored = \'No\'' . ' AND mi.info_id = ' . $this->dbObj->Param($this->fields_arr['message_id']) . ' ORDER BY mi.info_id DESC';
								$fields_value_arr = array($this->CFG['user']['user_id'], $this->fields_arr['message_id']);
								break;
						case 'sent':
								$sql = 'SELECT mi.info_id, mi.message_id, ' . $this->getUserTableFields(array('user_id', 'name', 'image_path', 'gender')) . ', m.subject, m.message, mi.from_viewed, mi.from_answer, attachment, mi.to_id, mi.from_id' . ', DATE_FORMAT(m.mess_date, \'' . $this->CFG['format']['date'] . '\') AS mess_date, DATE_FORMAT(m.mess_date, \'%I:%i %p\') AS mess_time' . ' FROM ' . $this->CFG['db']['tbl']['users'] . ' AS u ' . ', ' . $this->CFG['db']['tbl']['messages'] . ' AS m ' . ', ' . $this->CFG['db']['tbl']['messages_info'] . ' AS mi ' . ' WHERE mi.from_id = ' . $this->dbObj->Param($this->CFG['user']['user_id']) . ' AND mi.to_id = u.' . $this->getUserTableField('user_id') . ' AND mi.message_id = m.message_id' . ' AND mi.from_delete = \'No\'' . ' AND mi.from_stored = \'No\'' . ' AND mi.info_id = ' . $this->dbObj->Param($this->fields_arr['message_id']) . ' ORDER BY mi.info_id DESC';
								$fields_value_arr = array($this->CFG['user']['user_id'], $this->fields_arr['message_id']);
								break;
				}
				$this->sql_field_values = $fields_value_arr;
				return $sql;
		}
}
$mailcompose = new MailComposeFormHandler();
if (!chkAllowedModule(array('mail'))) Redirect2URL($CFG['redirect']['dsabled_module_url']);
$mailcompose->setPageBlockNames(array('msg_form_error', 'msg_form_success', 'form_compose'));
$mailcompose->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$mailcompose->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$mailcompose->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$mailcompose->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$mailcompose->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$mailcompose->setFormField('username', '');
$mailcompose->setFormField('subject', '');
$mailcompose->setFormField('goto', 'compose');
$mailcompose->setFormField('message', '');
$mailcompose->setFormField('video', '');
$mailcompose->setFormField('answer_id', '');
$mailcompose->setFormField('action', '');
$mailcompose->setFormField('msgFolder', '');
$mailcompose->setFormField('message_id', '');
$mailcompose->setFormField('original_message', '');
$mailcompose->setFormField('include_original_message', '');
$mailcompose->setDBObject($db);
$mailcompose->setCfgLangGlobal($CFG, $LANG);
$mailcompose->setAllPageBlocksHide();
$mailcompose->setPageBlockShow('form_compose');
if ($mailcompose->isFormGETed($_GET, 'mcomp'))
{
		$mailcompose->setFormField('mcomp', '');
		$mailcompose->sanitizeFormInputs($_GET);
		$mailcompose->setIndirectFormField('username', $mailcompose->getFormField('mcomp'));
}
if ($mailcompose->isFormGETed($_GET, 'action'))
{
		$mailcompose->sanitizeFormInputs($_GET);
}
if ($mailcompose->isFormPOSTed($_POST, 'mailcompose_submit'))
{
		$mailcompose->sanitizeFormInputs($_POST);
		$mailcompose->chkIsNotEmpty('username', $LANG['mailcompose_err_tip_compulsory']);
		($mailcompose->getFormField('include_original_message') == 'Yes') or $mailcompose->chkIsNotEmpty('message', $LANG['mailcompose_err_tip_compulsory']);
		if ($mailcompose->isValidFormInputs())
		{
				$mailcompose->sendMail('username', 'subject', 'message', $LANG['mailcompose_err_tip_mail_not_sent']);
				if ($mailcompose->isValidFormInputs())
				{
						$mailcompose->setAllPageBlocksHide();
						$mailcompose->setPageBlockShow('msg_form_success');
						$mailcompose->setPageBlockShow('form_compose');
						switch ($mailcompose->getFormField('goto'))
						{
								case 'inbox':
										Redirect2URL(getUrl($CFG['admin']['mail_urls']['inbox']['normal'] . '&msg=1', $CFG['admin']['mail_urls']['inbox']['htaccess'] . '?msg=1'));
										break;
								case 'sent':
										Redirect2URL(getUrl($CFG['admin']['mail_urls']['sent']['normal'] . '&msg=1', $CFG['admin']['mail_urls']['sent']['htaccess'] . '?msg=1'));
										break;
								default:
										Redirect2URL(getUrl($CFG['admin']['mail_urls']['compose']['normal'] . '?msg=1', $CFG['admin']['mail_urls']['compose']['htaccess'] . '?msg=1'));
						}
				}
				else
				{
						$mailcompose->setAllPageBlocksHide();
						$mailcompose->setPageBlockShow('msg_form_error');
						$mailcompose->setPageBlockShow('form_compose');
				}
		}
		else
		{
				$mailcompose->setAllPageBlocksHide();
				$mailcompose->setPageBlockShow('msg_form_error');
				$mailcompose->setPageBlockShow('form_compose');
		}
}
if ($mailcompose->getFormField('action'))
{
		switch ($mailcompose->getFormField('action'))
		{
				case 'reply':
				case 'forward':
						if ($mailcompose->getFormField('message_id') && $mailcompose->getFormField('msgFolder'))
						{
								if (!$mailcompose->getMessage($mailcompose->getFormField('action'), $mailcompose->getFormField('msgFolder'), $mailcompose->getFormField('message_id')))
								{
										$mailcompose->setFormField('action', '');
										$mailcompose->setFormField('msgFolder', '');
										$mailcompose->setFormField('message_id', '');
								}
						}
						break;
		}
}
if ($mailcompose->isFormGETed($_GET, 'msg'))
{
		$mailcompose->sanitizeFormInputs($_GET);
		$mailcompose->setAllPageBlocksHide();
		$mailcompose->setPageBlockShow('msg_form_success');
		$mailcompose->setPageBlockShow('form_compose');
}



?>
<script type="text/javascript" language="javascript">
	var palette_url = '<?php echo $CFG['site']['url'] . 'admin/palette.htm'; ?>';
	var block_arr= new Array('selMsgConfirm');
</script>
<div id="selComposeMail">
	<h2><span><?php echo $LANG['mailcompose_title']; ?></span></h2>
    <div id="selLeftNavigation">
<?php
if ($mailcompose->isShowPageBlock('msg_form_error'))
{
?>
		<div id="selMsgError">
			 <p><?php echo $LANG['msg_error_sorry']; ?> <?php echo $mailcompose->getCommonErrorMsg(); ?></p>
		</div>
<?php
}
if ($mailcompose->isShowPageBlock('msg_form_success'))
{
?>
		<div id="selMsgSuccess">
			<p><?php echo $LANG['mailcompose_success_mail']; ?></p>
		</div>
<?php
}
if ($mailcompose->isShowPageBlock('form_compose'))
{
?>
	<form name="selFormCompose" id="selFormCompose" method="post" action="<?php echo getUrl($CFG['admin']['mail_urls']['compose']['normal'], $CFG['admin']['mail_urls']['compose']['htaccess']); ?>" autocomplete="off" onsubmit="return getHTMLSource('rte1', 'selFormCompose', 'message');">
		<table border="0" summary="<?php echo $LANG['mailcompose_tbl_summary']; ?>" class="clsRichTextTable">
		   <tr>
				<td class="<?php echo $mailcompose->getCSSFormLabelCellClass('username'); ?>"><?php ShowHelpTip('messages_to'); ?><label for="username"><?php echo $LANG['mailcompose_to']; ?></label></td>
				<td class="<?php echo $mailcompose->getCSSFormFieldCellClass('username'); ?>"><?php echo $mailcompose->getFormFieldErrorTip('username'); ?>
					<input type="text" class="clsTextBox" name="username" id="username" tabindex="<?php echo $mailcompose->getTabIndex(); ?>" maxlength="250"  value="<?php echo $mailcompose->getFormField('username'); ?>" />
				</td>
		   </tr>
		   <tr>
				<td class="<?php echo $mailcompose->getCSSFormLabelCellClass('subject'); ?>"><?php ShowHelpTip('messages_subject'); ?><label for="subject"><?php echo $LANG['mailcompose_subject']; ?></label></td>
				<td class="<?php echo $mailcompose->getCSSFormFieldCellClass('subject'); ?>"><?php echo $mailcompose->getFormFieldErrorTip('subject'); ?>
					<input type="text" class="clsTextBox" name="subject" id="subject" tabindex="<?php echo $mailcompose->getTabIndex(); ?>" maxlength="250"  value="<?php echo $mailcompose->getFormField('subject'); ?>" />
				</td>
		   </tr>
		   <?php if (strchr(strtolower($_SERVER['HTTP_USER_AGENT']), "opera") == '')
		{ ?>
		   <tr>
				<td colspan="2" class="<?php echo $mailcompose->getCSSFormFieldCellClass('message'); ?>"><?php echo $mailcompose->getFormFieldErrorTip('message'); ?>
					<?php populateRichTextEdit('message', $mailcompose->getFormField('message'), $mailcompose->isValidFormInputs()); ?>
				</td>
		   </tr>
			<?php }
		else
		{ ?>
			<tr>
				<td colspan="2" class="<?php echo $mailcompose->getCSSFormFieldCellClass('message'); ?>"><?php echo $mailcompose->getFormFieldErrorTip('message'); ?>
					<textarea class="clsCommonTextArea" name="message" id="message" cols="82" rows="5"><?php echo $mailcompose->getFormField('message'); ?></textarea>
				</td>
		   </tr>

			<?php } ?>
		   	<?php
		if ($mailcompose->getFormField('original_message'))
		{
?>
					<tr>
				   		<td colspan="2" class="<?php echo $mailcompose->getCSSFormFieldCellClass('original_message'); ?>">
							<textarea class="clsCommonTextArea" name="original_message" id="original_message" cols="82" rows="4" disabled readonly ><?php echo stripslashes($mailcompose->getFormField('original_message')); ?></textarea>
						</td>
				   	</tr>
				   <tr>
				   		<td class="<?php echo $mailcompose->getCSSFormLabelCellClass('include_original_message'); ?>"><?php ShowHelpTip('messages_include_original_message'); ?><label for="include_original_message_yes"><?php echo $LANG['mailcompose_include_message']; ?></label></td>
				        <td class="<?php echo $mailcompose->getCSSFormLabelCellClass('include_original_message'); ?>">
							<input type="radio" class="clsCheckRadio" name="include_original_message" id="include_original_message_yes" value="Yes" <?php echo ($mailcompose->getFormField('include_original_message') == 'Yes') ? 'CHECKED' : ''; ?> tabindex="<?php echo $mailcompose->getTabIndex(); ?>" />
				          	<label for="include_original_message_yes"><?php echo $LANG['mailcompose_include_message_yes']; ?></label>&nbsp;&nbsp;
		                  	<input type="radio" class="clsCheckRadio" name="include_original_message" id="include_original_message_no" value="No" <?php echo ($mailcompose->getFormField('include_original_message') == 'No') ? 'CHECKED' : ''; ?> tabindex="<?php echo $mailcompose->getTabIndex(); ?>" />
		                  	<label for="include_original_message_no"><?php echo $LANG['mailcompose_include_message_no']; ?></label>
						</td>
				   </tr>
			<?php
		}
		if ($CFG['admin']['mails']['redirect'])
		{
?>
				   <tr>
				   		<td colspan="2" class="<?php echo $mailcompose->getCSSFormFieldCellClass('goto'); ?>"><label for="gotocompose"><?php echo $LANG['mailcompose_go_to']; ?></label>&nbsp;&nbsp;
							<input type="radio" class="clsCheckRadio" name="goto" id="gotocompose" tabindex="<?php echo $mailcompose->getTabIndex(); ?>" value="compose" <?php if ($mailcompose->getFormField('goto') == 'compose') echo 'checked'; ?> /> <label for="gotocompose"><?php echo $LANG['mailcompose_goto_compose']; ?></label>&nbsp;&nbsp;
							<input type="radio" class="clsCheckRadio" name="goto" id="gotoinbox" tabindex="<?php echo $mailcompose->getTabIndex(); ?>" value="inbox" <?php if ($mailcompose->getFormField('goto') == 'inbox') echo 'checked'; ?> /> <label for="gotoinbox"><?php echo $LANG['mailcompose_goto_inbox']; ?></label>&nbsp;&nbsp;
							<input type="radio" class="clsCheckRadio" name="goto" id="gotosent" tabindex="<?php echo $mailcompose->getTabIndex(); ?>" value="sent" <?php if ($mailcompose->getFormField('goto') == 'sent') echo 'checked'; ?> /> <label for="gotosent"><?php echo $LANG['mailcompose_goto_sent']; ?></label>&nbsp;&nbsp;
						</td>
				   </tr>
		   	<?php
		}
?>
		   <tr>
				<td colspan="2" class="<?php echo $mailcompose->getCSSFormFieldCellClass('submit'); ?>">
					<input type="submit" class="clsSubmitButton" name="mailcompose_submit" id="mailcompose_submit" tabindex="<?php echo $mailcompose->getTabIndex(); ?>" value="<?php echo $LANG['mailcompose_send']; ?>" />
				</td>
		   </tr>
		</table>
		<input type="hidden" name="action" value="<?php echo $mailcompose->getFormField('action'); ?>" />
		<input type="hidden" name="msgFolder" value="<?php echo $mailcompose->getFormField('msgFolder'); ?>" />
		<input type="hidden" name="message_id" value="<?php echo $mailcompose->getFormField('message_id'); ?>" />
		<input type="hidden" name="answer_id" value="<?php echo $mailcompose->getFormField('answer_id'); ?>" />
	</form>
<?php
}
?>
	</div>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>