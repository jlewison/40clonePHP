SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL auto_increment,
  `admin_name` varchar(255) NOT NULL,
  `admin_password` varchar(255) NOT NULL,
  `admin_last_login` datetime NOT NULL,
  `admin_status` enum('active','blocked') NOT NULL default 'active',
  `admin_logged_in` bigint(20) NOT NULL,
  PRIMARY KEY  (`admin_id`)
);

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_name`, `admin_password`, `admin_last_login`, `admin_status`, `admin_logged_in`) VALUES(1, 'admin', 'admin', '2008-02-12 23:09:07', 'active', 1);

-- --------------------------------------------------------

--
-- Table structure for table `admin_settings`
--

DROP TABLE IF EXISTS `admin_settings`;
CREATE TABLE `admin_settings` (
  `settings_id` int(11) NOT NULL auto_increment,
  `admin_name` varchar(255) NOT NULL,
  `admin_email` varchar(255) NOT NULL,
  `site_name` varchar(255) NOT NULL,
  `site_title` varchar(255) NOT NULL,
  `records_per_page` int(11) NOT NULL,
  `albums_on_profile` int(11) NOT NULL,
  `posts_on_profile` int(11) NOT NULL,
  `posts_common` int(11) NOT NULL,
  `list_on_home` int(11) NOT NULL,
  `total_albums_per_user` int(11) NOT NULL,
  `total_photos_per_album` int(11) NOT NULL,
  `total_groups_user_create` int(11) NOT NULL,
  `total_groups_user_join` int(11) NOT NULL,
  `total_events_user_create` int(11) NOT NULL,
  `total_events_user_join` int(11) NOT NULL,
  `mencoder_path` text NOT NULL,
  `mplayer_path` text NOT NULL,
  `webcam_capture_time` int(11) NOT NULL,
  `red5_path` text NOT NULL,
  `recorder_path` text NOT NULL,
  `red5_flv_path` text NOT NULL,
  `flvtool2_path` text NOT NULL,
  `red5_server_path` text NOT NULL,
  PRIMARY KEY  (`settings_id`)
);

--
-- Dumping data for table `admin_settings`
--

INSERT INTO `admin_settings` (`settings_id`, `admin_name`, `admin_email`, `site_name`, `site_title`, `records_per_page`, `albums_on_profile`, `posts_on_profile`, `posts_common`, `list_on_home`, `total_albums_per_user`, `total_photos_per_album`, `total_groups_user_create`, `total_groups_user_join`, `total_events_user_create`, `total_events_user_join`, `mencoder_path`, `mplayer_path`, `webcam_capture_time`, `red5_path`, `recorder_path`, `red5_flv_path`, `flvtool2_path`, `red5_server_path`) VALUES(1, 'Kootali team', 'user@domain.ltd', 'Yourdomainname.com', 'kootali', 2, 5, 5, 2, 5, 2, 2, 5, 5, 10, 5, '/usr/local/bin/mencoder', '/usr/local/bin/mplayer', 50, '/kootali/application/settings/', '/testing/kootali/skin/', '/opt/red5/webapps/SOSample/streams', '/usr/bin/flvtool2', 'rtmp://www.domain.com/SOSample');

-- --------------------------------------------------------

--
-- Table structure for table `applications`
--

DROP TABLE IF EXISTS `applications`;
CREATE TABLE `applications` (
  `application_id` bigint(20) NOT NULL auto_increment,
  `application_name` varchar(50) NOT NULL,
  `application_desc` varchar(255) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `application_class` varchar(25) NOT NULL,
  `application_link` varchar(255) NOT NULL,
  PRIMARY KEY  (`application_id`)
);

--
-- Dumping data for table `applications`
--

INSERT INTO `applications` (`application_id`, `application_name`, `application_desc`, `user_id`, `application_class`, `application_link`) VALUES(1, 'Photos', 'Photos\r\n', 0, 'photoIcon', 'photos');
INSERT INTO `applications` (`application_id`, `application_name`, `application_desc`, `user_id`, `application_class`, `application_link`) VALUES(2, 'Groups', 'Groups', 0, 'groupIcon', 'groups');
INSERT INTO `applications` (`application_id`, `application_name`, `application_desc`, `user_id`, `application_class`, `application_link`) VALUES(3, 'Events', 'Events', 0, 'eventsIcon', 'events');
INSERT INTO `applications` (`application_id`, `application_name`, `application_desc`, `user_id`, `application_class`, `application_link`) VALUES(4, 'Marketplace', 'Marketplace', 0, 'marketPlaceLeftIcon', 'marketplace');
INSERT INTO `applications` (`application_id`, `application_name`, `application_desc`, `user_id`, `application_class`, `application_link`) VALUES(5, 'Videos', 'Videos', 0, 'videoIcon', 'videos');
INSERT INTO `applications` (`application_id`, `application_name`, `application_desc`, `user_id`, `application_class`, `application_link`) VALUES(6, 'Posted Items', 'Posted Items', 0, 'forwardIcon', 'posteditems');
INSERT INTO `applications` (`application_id`, `application_name`, `application_desc`, `user_id`, `application_class`, `application_link`) VALUES(7, 'Notes', 'Notes', 0, 'noteLeftIcon', 'notes');

-- --------------------------------------------------------

--
-- Table structure for table `birthday_visibility`
--

DROP TABLE IF EXISTS `birthday_visibility`;
CREATE TABLE `birthday_visibility` (
  `birthday_visibility_id` int(11) NOT NULL auto_increment,
  `birthday_option` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`birthday_visibility_id`)
);

--
-- Dumping data for table `birthday_visibility`
--

INSERT INTO `birthday_visibility` (`birthday_visibility_id`, `birthday_option`) VALUES(1, 'Show my full birthday');
INSERT INTO `birthday_visibility` (`birthday_visibility_id`, `birthday_option`) VALUES(2, 'Show only month and day');
INSERT INTO `birthday_visibility` (`birthday_visibility_id`, `birthday_option`) VALUES(3, 'Don''t show my birthday');

-- --------------------------------------------------------

--
-- Table structure for table `block_users`
--

DROP TABLE IF EXISTS `block_users`;
CREATE TABLE `block_users` (
  `block_id` int(3) NOT NULL auto_increment,
  `user_id` int(3) NOT NULL,
  `blocked_user_id` int(3) NOT NULL,
  PRIMARY KEY  (`block_id`)
);

--
-- Dumping data for table `block_users`
--

-- --------------------------------------------------------

--
-- Table structure for table `country`
--

DROP TABLE IF EXISTS `country`;
CREATE TABLE `country` (
  `country_id` int(11) NOT NULL auto_increment,
  `country_symbol` varchar(3) NOT NULL,
  `country_name` varchar(255) NOT NULL,
  PRIMARY KEY  (`country_id`)
);

--
-- Dumping data for table `country`
--

INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(1, 'US', 'United States');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(2, 'AF', 'Afghanistan');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(3, 'AL', 'Albania');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(4, 'DZ', 'Algeria');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(5, 'AS', 'American Samoa');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(6, 'AD', 'Andorra');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(7, 'AO', 'Angola');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(8, 'AI', 'Anguilla');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(9, 'AG', 'Antigua and Barbuda');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(10, 'AR', 'Argentina');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(11, 'AM', 'Armenia');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(12, 'AW', 'Aruba');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(13, 'AU', 'Australia');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(14, 'AT', 'Austria');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(15, 'AZ', 'Azerbaijan');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(16, 'BS', 'Bahamas');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(17, 'BH', 'Bahrain');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(18, 'BD', 'Bangladesh');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(19, 'BB', 'Barbados');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(20, 'BY', 'Belarus');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(21, 'BE', 'Belgium');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(22, 'BZ', 'Belize');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(23, 'BJ', 'Benin');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(24, 'BM', 'Bermuda');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(25, 'BT', 'Bhutan');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(26, 'BO', 'Bolivia');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(27, 'BA', 'Bosnia and Herzegovina');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(28, 'BW', 'Botswana');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(29, 'BV', 'Bouvet Island');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(30, 'BR', 'Brazil');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(31, 'IO', 'British Indian Ocean Territory');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(32, 'VG', 'British Virgin Islands');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(33, 'BN', 'Brunei');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(34, 'BG', 'Bulgaria');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(35, 'BF', 'Burkina Faso');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(36, 'BI', 'Burundi');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(37, 'KH', 'Cambodia');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(38, 'CM', 'Cameroon');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(39, 'CA', 'Canada');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(40, 'CV', 'Cape Verde');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(41, 'KY', 'Cayman Islands');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(42, 'CF', 'Central African Republic');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(43, 'TD', 'Chad');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(44, 'CL', 'Chile');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(45, 'CN', 'China');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(46, 'CX', 'Christmas Island');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(47, 'CC', 'Cocos (Keeling) Islands');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(48, 'CO', 'Colombia');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(49, 'KM', 'Comoros');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(50, 'CG', 'Congo');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(51, 'CD', 'Congo - Democratic Republic of');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(52, 'CK', 'Cook Islands');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(53, 'CR', 'Costa Rica');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(54, 'HR', 'Croatia');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(55, 'CU', 'Cuba');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(56, 'CY', 'Cyprus');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(57, 'CZ', 'Czech Republic');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(58, 'DK', 'Denmark');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(59, 'DJ', 'Djibouti');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(60, 'DM', 'Dominica');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(61, 'DO', 'Dominican Republic');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(62, 'TP', 'East Timor');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(63, 'EC', 'Ecuador');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(64, 'EG', 'Egypt');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(65, 'SV', 'El Salvador');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(66, 'GQ', 'Equitorial Guinea');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(67, 'ER', 'Eritrea');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(68, 'EE', 'Estonia');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(69, 'ET', 'Ethiopia');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(70, 'FK', 'Falkland Islands (Islas Malvinas)');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(71, 'FO', 'Faroe Islands');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(72, 'FJ', 'Fiji');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(73, 'FI', 'Finland');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(74, 'FR', 'France');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(75, 'GF', 'French Guyana');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(76, 'PF', 'French Polynesia');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(77, 'TF', 'French Southern and Antarctic Lands');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(78, 'GA', 'Gabon');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(79, 'GM', 'Gambia');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(80, 'GZ', 'Gaza Strip');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(81, 'GE', 'Georgia');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(82, 'DE', 'Germany');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(83, 'GH', 'Ghana');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(84, 'GI', 'Gibraltar');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(85, 'GR', 'Greece');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(86, 'GL', 'Greenland');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(87, 'GD', 'Grenada');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(88, 'GP', 'Guadeloupe');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(89, 'GU', 'Guam');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(90, 'GT', 'Guatemala');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(91, 'GN', 'Guinea');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(92, 'GW', 'Guinea-Bissau');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(93, 'GY', 'Guyana');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(94, 'HT', 'Haiti');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(95, 'HM', 'Heard Island and McDonald Islands');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(96, 'VA', 'Holy See (Vatican City)');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(97, 'HN', 'Honduras');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(98, 'HK', 'Hong Kong');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(99, 'HU', 'Hungary');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(100, 'IS', 'Iceland');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(101, 'IN', 'India');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(102, 'ID', 'Indonesia');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(103, 'IR', 'Iran');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(104, 'IQ', 'Iraq');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(105, 'IE', 'Ireland');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(106, 'IL', 'Israel');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(107, 'IT', 'Italy');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(108, 'JM', 'Jamaica');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(109, 'JP', 'Japan');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(110, 'JO', 'Jordan');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(111, 'KZ', 'Kazakhstan');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(112, 'KE', 'Kenya');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(113, 'KI', 'Kiribati');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(114, 'KW', 'Kuwait');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(115, 'KG', 'Kyrgyzstan');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(116, 'LA', 'Laos');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(117, 'LV', 'Latvia');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(118, 'LB', 'Lebanon');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(119, 'LS', 'Lesotho');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(120, 'LR', 'Liberia');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(121, 'LY', 'Libya');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(122, 'LI', 'Liechtenstein');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(123, 'LT', 'Lithuania');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(124, 'LU', 'Luxembourg');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(125, 'MO', 'Macau');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(126, 'MK', 'Macedonia - The Former Yugoslav Republic of');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(127, 'MG', 'Madagascar');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(128, 'MW', 'Malawi');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(129, 'MY', 'Malaysia');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(130, 'MV', 'Maldives');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(131, 'ML', 'Mali');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(132, 'MT', 'Malta');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(133, 'MH', 'Marshall Islands');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(134, 'MQ', 'Martinique');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(135, 'MR', 'Mauritania');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(136, 'MU', 'Mauritius');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(137, 'YT', 'Mayotte');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(138, 'MX', 'Mexico');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(139, 'FM', 'Micronesia - Federated States of');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(140, 'MD', 'Moldova');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(141, 'MC', 'Monaco');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(142, 'MN', 'Mongolia');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(143, 'MS', 'Montserrat');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(144, 'MA', 'Morocco');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(145, 'MZ', 'Mozambique');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(146, 'MM', 'Myanmar');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(147, 'NA', 'Namibia');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(148, 'NR', 'Naura');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(149, 'NP', 'Nepal');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(150, 'NL', 'Netherlands');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(151, 'AN', 'Netherlands Antilles');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(152, 'NC', 'New Caledonia');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(153, 'NZ', 'New Zealand');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(154, 'NI', 'Nicaragua');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(155, 'NE', 'Niger');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(156, 'NG', 'Nigeria');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(157, 'NU', 'Niue');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(158, 'NF', 'Norfolk Island');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(159, 'KP', 'North Korea');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(160, 'MP', 'Northern Mariana Islands');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(161, 'NO', 'Norway');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(162, 'OM', 'Oman');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(163, 'PK', 'Pakistan');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(164, 'PW', 'Palau');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(165, 'PA', 'Panama');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(166, 'PG', 'Papua New Guinea');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(167, 'PY', 'Paraguay');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(168, 'PE', 'Peru');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(169, 'PH', 'Philippines');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(170, 'PN', 'Pitcairn Islands');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(171, 'PL', 'Poland');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(172, 'PT', 'Portugal');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(173, 'PR', 'Puerto Rico');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(174, 'QA', 'Qatar');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(175, 'RE', 'Reunion');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(176, 'RO', 'Romania');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(177, 'RU', 'Russia');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(178, 'RW', 'wanda');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(179, 'KN', 'Saint Kitts and Nevis');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(180, 'LC', 'Saint Lucia');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(181, 'VC', 'Saint Vincent and the Grenadines');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(182, 'WS', 'Samoa');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(183, 'SM', 'San Marino');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(184, 'ST', 'Sao Tome and Principe');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(185, 'SA', 'Saudi Arabia');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(186, 'SN', 'Senegal');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(187, 'CS', 'Serbia and Montenegro');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(188, 'SC', 'Seychelles');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(189, 'SL', 'Sierra Leone');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(190, 'SG', 'Singapore');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(191, 'SK', 'Slovakia');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(192, 'SI', 'Slovenia');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(193, 'SB', 'Solomon Islands');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(194, 'SO', 'Somalia');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(195, 'ZA', 'South Africa');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(196, 'GS', 'South Georgia and the South Sandwich Islands');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(197, 'KR', 'South Korea');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(198, 'ES', 'Spain');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(199, 'LK', 'Sri Lanka');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(200, 'SH', 'St. Helena');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(201, 'PM', 'St. Pierre and Miquelon');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(202, 'SD', 'Sudan');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(203, 'SR', 'Suriname');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(204, 'SJ', 'Svalbard');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(205, 'SZ', 'Swaziland');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(206, 'SE', 'Sweden');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(207, 'CH', 'Switzerland');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(208, 'SY', 'Syria');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(209, 'TW', 'Taiwan');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(210, 'TJ', 'Tajikistan');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(211, 'TZ', 'Tanzania');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(212, 'TH', 'Thailand');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(213, 'TG', 'Togo');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(214, 'TK', 'Tokelau');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(215, 'TO', 'Tonga');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(216, 'TT', 'Trinidad and Tobago');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(217, 'TN', 'Tunisia');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(218, 'TR', 'Turkey');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(219, 'TM', 'Turkmenistan');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(220, 'TC', 'Turks and Caicos Islands');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(221, 'TV', 'Tuvalu');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(222, 'UG', 'Uganda');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(223, 'UA', 'Ukraine');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(224, 'AE', 'United Arab Emirates');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(225, 'GB', 'United Kingdom');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(226, 'VI', 'United States Virgin Islands');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(227, 'UY', 'Uruguay');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(228, 'UZ', 'Uzbekistan');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(229, 'VU', 'Vanuatu');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(230, 'VE', 'Venezuela');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(231, 'VN', 'Vietnam');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(232, 'WF', 'Wallis and Futuna');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(233, 'PS', 'West Bank');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(234, 'EH', 'Western Sahara');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(235, 'YE', 'Yemen');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(236, 'ZM', 'Zambia');
INSERT INTO `country` (`country_id`, `country_symbol`, `country_name`) VALUES(237, 'ZW', 'Zimbabwe');

-- --------------------------------------------------------

--
-- Table structure for table `discussion_post`
--

DROP TABLE IF EXISTS `discussion_post`;
CREATE TABLE `discussion_post` (
  `discussion_post_id` bigint(20) NOT NULL auto_increment,
  `parent_discussion_post_id` bigint(20) NOT NULL,
  `discussion_topic_id` bigint(20) NOT NULL,
  `posted_by` bigint(20) NOT NULL,
  `posted_content` text NOT NULL,
  `posted_date` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`discussion_post_id`)
);

--
-- Dumping data for table `discussion_post`
--

-- --------------------------------------------------------

--
-- Table structure for table `discussion_topic`
--

DROP TABLE IF EXISTS `discussion_topic`;
CREATE TABLE `discussion_topic` (
  `discussion_topic_id` bigint(20) NOT NULL auto_increment,
  `discussion_topic` varchar(255) NOT NULL,
  `created_by` bigint(20) NOT NULL,
  `posted_for` enum('group','event','photo','network','user','posteditem','notes','marketplace') NOT NULL,
  `posted_for_id` bigint(20) NOT NULL,
  `date_added` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `last_updated` datetime NOT NULL,
  `total_posts` bigint(20) NOT NULL,
  PRIMARY KEY  (`discussion_topic_id`)
);

--
-- Dumping data for table `discussion_topic`
--

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
CREATE TABLE `events` (
  `event_id` bigint(20) NOT NULL auto_increment,
  `user_id` bigint(20) NOT NULL default '0',
  `user_name` varchar(200) NOT NULL default '',
  `event_name` varchar(200) NOT NULL default '',
  `event_description` text NOT NULL,
  `event_tags` varchar(255) NOT NULL,
  `event_host` varchar(255) NOT NULL,
  `event_host_group` varchar(255) NOT NULL,
  `event_start_time` varchar(255) NOT NULL,
  `event_end_time` varchar(255) NOT NULL,
  `event_category_id` bigint(20) NOT NULL default '0',
  `event_sub_category_id` bigint(20) NOT NULL default '0',
  `event_email` varchar(250) NOT NULL,
  `event_location` varchar(255) NOT NULL,
  `event_street` varchar(250) NOT NULL,
  `event_city` varchar(250) NOT NULL,
  `event_state` varchar(250) NOT NULL,
  `event_country` varchar(250) NOT NULL,
  `event_bring_friends` enum('yes','no') NOT NULL default 'yes',
  `event_show_guest` enum('yes','no') NOT NULL default 'yes',
  `event_wall` enum('yes','no') NOT NULL default 'yes',
  `event_photos` enum('yes','no') NOT NULL default 'yes',
  `event_upload_permission` enum('members','admins') NOT NULL default 'members',
  `event_type` enum('open','secret','closed') NOT NULL default 'open',
  `event_publicize` enum('yes','no') NOT NULL default 'yes',
  `date_added` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `event_status` enum('ok','blocked','deleted') NOT NULL default 'ok',
  `event_photo_path` varchar(10) default NULL,
  `admin_rsvp_status` enum('attending','notattending','maybeattending') NOT NULL default 'attending',
  `event_start_unix_stamp` bigint(20) NOT NULL,
  `event_end_unix_stamp` bigint(20) NOT NULL,
  `network_id` bigint(20) default '0',
  `event_phone` varchar(20) NOT NULL,
  `date_modified` timestamp NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`event_id`)
);

--
-- Dumping data for table `events`
--

-- --------------------------------------------------------

--
-- Table structure for table `events_category`
--

DROP TABLE IF EXISTS `events_category`;
CREATE TABLE `events_category` (
  `event_category_id` bigint(20) NOT NULL auto_increment,
  `event_category_name` varchar(200) default NULL,
  `event_category_description` text NOT NULL,
  `event_category_status` enum('Yes','No') default 'Yes',
  `date_added` datetime default NULL,
  PRIMARY KEY  (`event_category_id`)
);

--
-- Dumping data for table `events_category`
--

INSERT INTO `events_category` (`event_category_id`, `event_category_name`, `event_category_description`, `event_category_status`, `date_added`) VALUES(1, 'Parties', 'Party', 'Yes', '2007-12-07 11:35:16');
INSERT INTO `events_category` (`event_category_id`, `event_category_name`, `event_category_description`, `event_category_status`, `date_added`) VALUES(2, 'Causes', 'Causes', 'Yes', NULL);
INSERT INTO `events_category` (`event_category_id`, `event_category_name`, `event_category_description`, `event_category_status`, `date_added`) VALUES(3, 'Education', 'Education', 'Yes', NULL);
INSERT INTO `events_category` (`event_category_id`, `event_category_name`, `event_category_description`, `event_category_status`, `date_added`) VALUES(4, 'Meetings', 'Meetings', 'Yes', NULL);
INSERT INTO `events_category` (`event_category_id`, `event_category_name`, `event_category_description`, `event_category_status`, `date_added`) VALUES(5, 'Music/Arts', 'Music/Arts', 'Yes', NULL);
INSERT INTO `events_category` (`event_category_id`, `event_category_name`, `event_category_description`, `event_category_status`, `date_added`) VALUES(6, 'Sports', 'Sports', 'No', '2007-12-07 11:40:23');
INSERT INTO `events_category` (`event_category_id`, `event_category_name`, `event_category_description`, `event_category_status`, `date_added`) VALUES(7, 'Trips', 'Trips', 'Yes', NULL);
INSERT INTO `events_category` (`event_category_id`, `event_category_name`, `event_category_description`, `event_category_status`, `date_added`) VALUES(8, 'Other', 'Other', 'Yes', NULL);
INSERT INTO `events_category` (`event_category_id`, `event_category_name`, `event_category_description`, `event_category_status`, `date_added`) VALUES(12, 'This is the long Category', 'This is the long Category name with Long Descripti', 'No', '2007-12-07 11:41:32');

-- --------------------------------------------------------

--
-- Table structure for table `events_invitation`
--

DROP TABLE IF EXISTS `events_invitation`;
CREATE TABLE `events_invitation` (
  `event_invitation_id` int(11) NOT NULL auto_increment,
  `sender_id` int(11) NOT NULL default '0',
  `receiver_id` int(11) NOT NULL default '0',
  `event_id` int(11) NOT NULL default '0',
  `invitation_message` text NOT NULL,
  `invitation_status` enum('sent','requested','not sent') NOT NULL default 'not sent',
  `datestamp` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `receiver_email` varchar(255) NOT NULL,
  `is_admin` enum('Y','N') default 'N',
  PRIMARY KEY  (`event_invitation_id`)
);

--
-- Dumping data for table `events_invitation`
--

-- --------------------------------------------------------

--
-- Table structure for table `events_sub_category`
--

DROP TABLE IF EXISTS `events_sub_category`;
CREATE TABLE `events_sub_category` (
  `event_sub_category_id` bigint(20) NOT NULL auto_increment,
  `event_category_id` bigint(20) NOT NULL default '0',
  `event_sub_category_name` varchar(200) default NULL,
  `event_sub_category_description` text NOT NULL,
  `event_sub_category_status` enum('Yes','No') default 'Yes',
  `date_added` datetime default NULL,
  PRIMARY KEY  (`event_sub_category_id`)
);

--
-- Dumping data for table `events_sub_category`
--

INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(1, 1, 'Birthday Party', 'Birthday Party', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(2, 1, 'Cocktail Party', 'Cocktail Party', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(3, 1, 'Club Party', 'Club Party', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(4, 1, 'Fraternity/Sorority Party', 'Fraternity/Sorority Party', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(5, 1, 'Barbecue', 'Barbecue', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(6, 1, 'Card Night', 'Card Night', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(7, 1, 'Dinner Party', 'Dinner Party', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(8, 1, 'Holiday Party', 'Holiday Party', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(9, 1, 'Night of Mayhem', 'Night of Mayhem', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(10, 1, 'Movie/TV Night', 'Movie/TV Night', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(11, 1, 'Drinking Games', 'Drinking Games', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(12, 1, 'Bar Night', 'Bar Night', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(13, 1, 'LAN Party', 'LAN Party', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(14, 1, 'Mixer', 'Mixer', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(15, 1, 'Slumber Party', 'Slumber Party', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(16, 1, 'Erotic Party', 'Erotic Party', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(17, 1, 'Benefit', 'Benefit', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(18, 1, 'Goodbye Party', 'Goodbye Party', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(19, 1, 'House Party', 'House Party', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(20, 1, 'Reunion', 'Reunion', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(21, 2, 'Fundraiser', 'Fundraiser', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(22, 2, 'Protest', 'Protest', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(23, 2, 'Rally', 'Rally', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(24, 3, 'Study Group', 'Study Group', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(25, 3, 'Class', 'Class', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(26, 3, 'Lecture', 'Lecture', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(27, 3, 'Office Hours', 'Office Hours', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(28, 3, 'Workshop', 'Workshop', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(29, 4, 'Business Meeting', 'Business Meeting', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(30, 4, 'Club/Group Meeting', 'Club/Group Meeting', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(31, 4, 'Convention', 'Convention', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(32, 4, 'Dorm/House Meeting', 'Dorm/House Meeting', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(33, 4, 'Informational Meeting', 'Informational Meeting', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(34, 5, 'Concert', 'Concert', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(35, 5, 'Audition', 'Audition', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(36, 5, 'Exhibit', 'Exhibit', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(37, 5, 'Jam Session', 'Jam Session', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(38, 5, 'Listening Party', 'Listening Party', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(39, 5, 'Opening', 'Opening', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(40, 5, 'Performance', 'Performance', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(41, 5, 'Preview', 'Preview', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(42, 5, 'Recital', 'Recital', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(43, 5, 'Rehearsal', 'Rehearsal', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(44, 6, 'Pep Rally', 'Pep Rally', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(45, 6, 'Pick-Up', 'Pick-Up', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(46, 6, 'Sporting Event', 'Sporting Event', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(47, 6, 'Sports Practice', 'Sports Practice', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(48, 6, 'Tournament', 'Tournament', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(49, 7, 'Camping Trip', 'Camping Trip', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(50, 7, 'Daytrip', 'Daytrip', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(51, 7, 'Group Trip', 'Group Trip', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(52, 7, 'Roadtrip', 'Roadtrip', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(53, 8, 'Carnival', 'Carnival', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(54, 8, 'Ceremony', 'Ceremony', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(55, 8, 'Festival', 'Festival', 'Yes', NULL);
INSERT INTO `events_sub_category` (`event_sub_category_id`, `event_category_id`, `event_sub_category_name`, `event_sub_category_description`, `event_sub_category_status`, `date_added`) VALUES(56, 8, 'Flea Market', 'Flea Market', 'Yes', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `event_members`
--

DROP TABLE IF EXISTS `event_members`;
CREATE TABLE `event_members` (
  `event_member_id` int(11) NOT NULL auto_increment,
  `event_id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `is_admin` enum('Y','N') NOT NULL default 'N',
  `member_status` enum('attending','notattending','maybeattending','blocked') NOT NULL default 'attending',
  `date_created` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `date_modified` timestamp NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`event_member_id`)
);

--
-- Dumping data for table `event_members`
--

-- --------------------------------------------------------

--
-- Table structure for table `friends_list`
--

DROP TABLE IF EXISTS `friends_list`;
CREATE TABLE `friends_list` (
  `friends_list_id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL default '0',
  `approved_status` enum('yes','no') NOT NULL default 'no',
  `datestamp` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `friend_id` int(11) NOT NULL,
  `friend_mail` varchar(255) NOT NULL,
  `invite_message` text NOT NULL,
  PRIMARY KEY  (`friends_list_id`)
);

--
-- Dumping data for table `friends_list`
--

-- --------------------------------------------------------

--
-- Table structure for table `global_detail`
--

DROP TABLE IF EXISTS `global_detail`;
CREATE TABLE `global_detail` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `header_id` varchar(255) NOT NULL,
  `detail_id` varchar(255) NOT NULL,
  `description` varchar(255) default NULL,
  `arg1` varchar(255) default NULL,
  `arg2` varchar(255) default NULL,
  `order` int(11) unsigned default NULL,
  `is_deleted` varchar(2) default 'N',
  `is_approved` varchar(2) default 'Y',
  `user_created` varchar(255) default 'admin',
  `date_created` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `user_modified` varchar(255) default 'admin',
  `date_modified` timestamp NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`)
);

--
-- Dumping data for table `global_detail`
--

INSERT INTO `global_detail` (`id`, `header_id`, `detail_id`, `description`, `arg1`, `arg2`, `order`, `is_deleted`, `is_approved`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(1, 'CONDITION_MP', 'COND1', 'New', NULL, NULL, NULL, 'N', 'Y', 'admin', '2007-10-19 08:53:50', 'admin', '0000-00-00 00:00:00');
INSERT INTO `global_detail` (`id`, `header_id`, `detail_id`, `description`, `arg1`, `arg2`, `order`, `is_deleted`, `is_approved`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(2, 'CONDITION_MP', 'COND2', 'Used', NULL, NULL, NULL, 'N', 'Y', 'admin', '2007-10-19 08:54:15', 'admin', '0000-00-00 00:00:00');
INSERT INTO `global_detail` (`id`, `header_id`, `detail_id`, `description`, `arg1`, `arg2`, `order`, `is_deleted`, `is_approved`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(3, 'ALLOWED_MP', 'ALLOWED1', 'Dogs', NULL, NULL, NULL, 'N', 'Y', 'admin', '2007-10-19 08:54:43', 'admin', '0000-00-00 00:00:00');
INSERT INTO `global_detail` (`id`, `header_id`, `detail_id`, `description`, `arg1`, `arg2`, `order`, `is_deleted`, `is_approved`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(4, 'ALLOWED_MP', 'ALLOWED2', 'Cats', NULL, NULL, NULL, 'N', 'Y', 'admin', '2007-10-19 08:55:24', 'admin', '0000-00-00 00:00:00');
INSERT INTO `global_detail` (`id`, `header_id`, `detail_id`, `description`, `arg1`, `arg2`, `order`, `is_deleted`, `is_approved`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(5, 'ALLOWED_MP', 'ALLOWED3', 'Smokers', NULL, NULL, NULL, 'N', 'Y', 'admin', '2007-10-19 08:55:41', 'admin', '0000-00-00 00:00:00');
INSERT INTO `global_detail` (`id`, `header_id`, `detail_id`, `description`, `arg1`, `arg2`, `order`, `is_deleted`, `is_approved`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(6, 'HOURS_MP', 'HOURS1', 'Part time', NULL, NULL, NULL, 'N', 'Y', 'admin', '2007-10-19 08:56:43', 'admin', '0000-00-00 00:00:00');
INSERT INTO `global_detail` (`id`, `header_id`, `detail_id`, `description`, `arg1`, `arg2`, `order`, `is_deleted`, `is_approved`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(7, 'HOURS_MP', 'HOURS2', 'Full time', NULL, NULL, NULL, 'N', 'Y', 'admin', '2007-10-19 08:56:59', 'admin', '0000-00-00 00:00:00');
INSERT INTO `global_detail` (`id`, `header_id`, `detail_id`, `description`, `arg1`, `arg2`, `order`, `is_deleted`, `is_approved`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(8, 'OTHERS_STUFF_MP', 'STUFF1', 'Internship', NULL, NULL, NULL, 'N', 'Y', 'admin', '2007-10-19 08:57:23', 'admin', '0000-00-00 00:00:00');
INSERT INTO `global_detail` (`id`, `header_id`, `detail_id`, `description`, `arg1`, `arg2`, `order`, `is_deleted`, `is_approved`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(9, 'OTHERS_STUFF_MP', 'STUFF2', 'Seasonal', NULL, NULL, NULL, 'N', 'Y', 'admin', '2007-10-19 08:57:55', 'admin', '0000-00-00 00:00:00');
INSERT INTO `global_detail` (`id`, `header_id`, `detail_id`, `description`, `arg1`, `arg2`, `order`, `is_deleted`, `is_approved`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(10, 'OTHERS_STUFF_MP', 'STUFF3', 'Non profit', NULL, NULL, NULL, 'N', 'Y', 'admin', '2007-10-19 08:58:16', 'admin', '0000-00-00 00:00:00');
INSERT INTO `global_detail` (`id`, `header_id`, `detail_id`, `description`, `arg1`, `arg2`, `order`, `is_deleted`, `is_approved`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(11, 'COMPENSATION_MP', 'COMPENSATION1', 'Salary', NULL, NULL, NULL, 'N', 'Y', 'admin', '2007-10-19 08:59:38', 'admin', '0000-00-00 00:00:00');
INSERT INTO `global_detail` (`id`, `header_id`, `detail_id`, `description`, `arg1`, `arg2`, `order`, `is_deleted`, `is_approved`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(12, 'COMPENSATION_MP', 'COMPENSATION2', 'Hourly', NULL, NULL, NULL, 'N', 'Y', 'admin', '2007-10-19 08:59:43', 'admin', '0000-00-00 00:00:00');
INSERT INTO `global_detail` (`id`, `header_id`, `detail_id`, `description`, `arg1`, `arg2`, `order`, `is_deleted`, `is_approved`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(13, 'COMPENSATION_MP', 'COMPENSATION3', 'One time', NULL, NULL, NULL, 'N', 'Y', 'admin', '2007-10-19 08:59:48', 'admin', '0000-00-00 00:00:00');
INSERT INTO `global_detail` (`id`, `header_id`, `detail_id`, `description`, `arg1`, `arg2`, `order`, `is_deleted`, `is_approved`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(14, 'CURRENCY_MP', 'CURR1', 'INR', NULL, NULL, NULL, 'N', 'Y', 'admin', '2007-10-22 09:56:47', 'admin', '0000-00-00 00:00:00');
INSERT INTO `global_detail` (`id`, `header_id`, `detail_id`, `description`, `arg1`, `arg2`, `order`, `is_deleted`, `is_approved`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(15, 'CURRENCY_MP', 'CURR2', 'USD', NULL, NULL, NULL, 'N', 'Y', 'admin', '2007-10-22 09:57:00', 'admin', '0000-00-00 00:00:00');
INSERT INTO `global_detail` (`id`, `header_id`, `detail_id`, `description`, `arg1`, `arg2`, `order`, `is_deleted`, `is_approved`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(16, 'CURRENCY_MP', 'CURR3', 'EURO', NULL, NULL, NULL, 'N', 'Y', 'admin', '2007-10-22 09:57:31', 'admin', '0000-00-00 00:00:00');
INSERT INTO `global_detail` (`id`, `header_id`, `detail_id`, `description`, `arg1`, `arg2`, `order`, `is_deleted`, `is_approved`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(17, 'ALIGNMENT_NT', 'ALIGN1', 'Full', NULL, NULL, NULL, 'N', 'Y', 'admin', '2007-11-20 21:27:41', 'admin', '0000-00-00 00:00:00');
INSERT INTO `global_detail` (`id`, `header_id`, `detail_id`, `description`, `arg1`, `arg2`, `order`, `is_deleted`, `is_approved`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(18, 'ALIGNMENT_NT', 'ALIGN2', 'Left', NULL, NULL, NULL, 'N', 'Y', 'admin', '2007-11-20 21:27:41', 'admin', '0000-00-00 00:00:00');
INSERT INTO `global_detail` (`id`, `header_id`, `detail_id`, `description`, `arg1`, `arg2`, `order`, `is_deleted`, `is_approved`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(19, 'ALIGNMENT_NT', 'ALIGN3', 'Center', NULL, NULL, NULL, 'N', 'Y', 'admin', '2007-11-20 21:27:41', 'admin', '0000-00-00 00:00:00');
INSERT INTO `global_detail` (`id`, `header_id`, `detail_id`, `description`, `arg1`, `arg2`, `order`, `is_deleted`, `is_approved`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(20, 'ALIGNMENT_NT', 'ALIGN4', 'Right', NULL, NULL, NULL, 'N', 'Y', 'admin', '2007-11-20 21:27:41', 'admin', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `global_header`
--

DROP TABLE IF EXISTS `global_header`;
CREATE TABLE `global_header` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `header_id` varchar(255) NOT NULL,
  `description` varchar(255) default NULL,
  `arg1` varchar(255) default NULL,
  `arg2` varchar(255) default NULL,
  `order` int(11) unsigned default NULL,
  `is_deleted` varchar(2) default 'N',
  `is_approved` varchar(2) default 'Y',
  `user_created` varchar(255) default 'admin',
  `date_created` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `user_modified` varchar(255) default 'admin',
  `date_modified` timestamp NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`)
);

--
-- Dumping data for table `global_header`
--

INSERT INTO `global_header` (`id`, `header_id`, `description`, `arg1`, `arg2`, `order`, `is_deleted`, `is_approved`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(1, 'CONDITION_MP', 'Item Condition', 'MARKET', NULL, NULL, 'N', 'Y', 'admin', '2007-10-19 08:48:36', 'admin', '0000-00-00 00:00:00');
INSERT INTO `global_header` (`id`, `header_id`, `description`, `arg1`, `arg2`, `order`, `is_deleted`, `is_approved`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(2, 'ALLOWED_MP', 'Allowed', 'MARKET', '', NULL, 'N', 'Y', 'admin', '2007-10-19 08:49:43', 'admin', '0000-00-00 00:00:00');
INSERT INTO `global_header` (`id`, `header_id`, `description`, `arg1`, `arg2`, `order`, `is_deleted`, `is_approved`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(3, 'HOURS_MP', 'Hours', 'MARKET', NULL, NULL, 'N', 'Y', 'admin', '2007-10-19 08:49:18', 'admin', '0000-00-00 00:00:00');
INSERT INTO `global_header` (`id`, `header_id`, `description`, `arg1`, `arg2`, `order`, `is_deleted`, `is_approved`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(4, 'OTHERS_STUFF_MP', 'Other Stuff', 'MARKET', NULL, NULL, 'N', 'Y', 'admin', '2007-10-19 08:50:17', 'admin', '0000-00-00 00:00:00');
INSERT INTO `global_header` (`id`, `header_id`, `description`, `arg1`, `arg2`, `order`, `is_deleted`, `is_approved`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(5, 'COMPENSATION_MP', 'Compensation', 'MARKET', NULL, NULL, 'N', 'Y', 'admin', '2007-10-19 08:50:59', 'admin', '0000-00-00 00:00:00');
INSERT INTO `global_header` (`id`, `header_id`, `description`, `arg1`, `arg2`, `order`, `is_deleted`, `is_approved`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(6, 'CURRENCY_MP', 'Currency Code', 'MARKET', NULL, NULL, 'N', 'Y', 'admin', '2007-10-22 09:56:14', 'admin', '0000-00-00 00:00:00');
INSERT INTO `global_header` (`id`, `header_id`, `description`, `arg1`, `arg2`, `order`, `is_deleted`, `is_approved`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(7, 'ALIGNMENT_NT', 'Photo Alignment', 'NOTES', NULL, NULL, 'N', 'Y', 'admin', '2007-11-20 21:27:41', 'admin', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

DROP TABLE IF EXISTS `groups`;
CREATE TABLE `groups` (
  `group_id` bigint(20) NOT NULL auto_increment,
  `user_id` bigint(20) NOT NULL default '0',
  `user_name` varchar(200) NOT NULL default '',
  `group_name` varchar(200) NOT NULL default '',
  `group_description` text NOT NULL,
  `group_category_id` bigint(20) NOT NULL default '0',
  `group_sub_category_id` bigint(20) NOT NULL default '0',
  `group_recentnews` text NOT NULL,
  `group_office` varchar(200) NOT NULL default '',
  `group_url` varchar(250) NOT NULL,
  `group_email` varchar(250) NOT NULL,
  `group_street` varchar(250) NOT NULL,
  `group_city` varchar(250) NOT NULL,
  `group_state` varchar(250) NOT NULL,
  `group_country` varchar(250) NOT NULL,
  `group_related` enum('yes','no') NOT NULL default 'yes',
  `group_discussionboard` enum('yes','no') NOT NULL default 'yes',
  `group_wall` enum('yes','no') NOT NULL default 'yes',
  `group_photos` enum('yes','no') NOT NULL default 'yes',
  `group_upload_permission` enum('members','admins') NOT NULL default 'members',
  `group_videos` enum('yes','no') NOT NULL default 'yes',
  `group_videos_permission` enum('members','admins') NOT NULL default 'members',
  `group_posted` enum('yes','no') NOT NULL default 'yes',
  `group_posted_permission` enum('members','admins') NOT NULL default 'members',
  `group_type` enum('open','secret','closed') NOT NULL default 'open',
  `group_publicize` enum('yes','no') NOT NULL default 'yes',
  `date_added` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `group_status` enum('ok','blocked','deleted') NOT NULL default 'ok',
  `group_photo_path` varchar(10) default NULL,
  `membership` enum('active','cancelled') NOT NULL default 'active',
  `network_id` bigint(20) default '0',
  `date_modified` timestamp NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`group_id`)
);

--
-- Dumping data for table `groups`
--

-- --------------------------------------------------------

--
-- Table structure for table `groups_category`
--

DROP TABLE IF EXISTS `groups_category`;
CREATE TABLE `groups_category` (
  `group_category_id` bigint(20) NOT NULL auto_increment,
  `group_category_name` varchar(200) default NULL,
  `group_category_description` text NOT NULL,
  `group_category_status` enum('Yes','No') default 'Yes',
  `date_added` datetime default NULL,
  PRIMARY KEY  (`group_category_id`)
);

--
-- Dumping data for table `groups_category`
--

INSERT INTO `groups_category` (`group_category_id`, `group_category_name`, `group_category_description`, `group_category_status`, `date_added`) VALUES(1, 'Business', 'Business', 'Yes', '2008-02-08 23:39:50');
INSERT INTO `groups_category` (`group_category_id`, `group_category_name`, `group_category_description`, `group_category_status`, `date_added`) VALUES(2, 'Common Interest', 'Common Interest', 'Yes', '2008-02-08 23:39:50');
INSERT INTO `groups_category` (`group_category_id`, `group_category_name`, `group_category_description`, `group_category_status`, `date_added`) VALUES(3, 'Entertainment & Arts,Geography', 'Entertainment & Arts,Geography', 'Yes', '2008-02-08 23:39:50');
INSERT INTO `groups_category` (`group_category_id`, `group_category_name`, `group_category_description`, `group_category_status`, `date_added`) VALUES(4, 'Internet & Technology', 'Internet & Technology', 'Yes', '2008-02-08 23:39:50');
INSERT INTO `groups_category` (`group_category_id`, `group_category_name`, `group_category_description`, `group_category_status`, `date_added`) VALUES(5, 'Just for Fun', 'Just for Fun', 'Yes', '2008-02-08 23:39:50');
INSERT INTO `groups_category` (`group_category_id`, `group_category_name`, `group_category_description`, `group_category_status`, `date_added`) VALUES(6, 'Music', 'Music', 'Yes', '2008-02-08 23:39:50');
INSERT INTO `groups_category` (`group_category_id`, `group_category_name`, `group_category_description`, `group_category_status`, `date_added`) VALUES(7, 'Organizations', 'Organizations', 'Yes', '2008-02-08 23:39:50');
INSERT INTO `groups_category` (`group_category_id`, `group_category_name`, `group_category_description`, `group_category_status`, `date_added`) VALUES(8, 'Sports & Recreation', 'Sports & Recreation', 'Yes', '2008-02-08 23:39:50');
INSERT INTO `groups_category` (`group_category_id`, `group_category_name`, `group_category_description`, `group_category_status`, `date_added`) VALUES(9, 'Student Groups', 'Student Groups', 'Yes', '2008-02-08 23:39:50');
INSERT INTO `groups_category` (`group_category_id`, `group_category_name`, `group_category_description`, `group_category_status`, `date_added`) VALUES(10, 'Group name with long char', 'group with long char and long description hqnhkdjk', 'Yes', '2008-02-08 23:39:50');
INSERT INTO `groups_category` (`group_category_id`, `group_category_name`, `group_category_description`, `group_category_status`, `date_added`) VALUES(11, 'business', 'business', 'Yes', '2008-02-08 23:39:50');

-- --------------------------------------------------------

--
-- Table structure for table `groups_invitation`
--

DROP TABLE IF EXISTS `groups_invitation`;
CREATE TABLE `groups_invitation` (
  `group_invitation_id` int(11) NOT NULL auto_increment,
  `sender_id` int(11) NOT NULL default '0',
  `receiver_id` int(11) NOT NULL default '0',
  `group_id` int(11) NOT NULL default '0',
  `invitation_message` text NOT NULL,
  `invitation_status` enum('sent','requested','not sent') NOT NULL default 'not sent',
  `datestamp` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `receiver_email` varchar(255) NOT NULL,
  `is_admin` enum('Y','N') default 'N',
  PRIMARY KEY  (`group_invitation_id`)
);

--
-- Dumping data for table `groups_invitation`
--

-- --------------------------------------------------------

--
-- Table structure for table `groups_sub_category`
--

DROP TABLE IF EXISTS `groups_sub_category`;
CREATE TABLE `groups_sub_category` (
  `group_sub_category_id` bigint(20) NOT NULL auto_increment,
  `group_category_id` bigint(20) NOT NULL default '0',
  `group_sub_category_name` varchar(200) default NULL,
  `group_sub_category_description` text NOT NULL,
  `group_sub_category_status` enum('Yes','No') default 'Yes',
  `date_added` datetime default NULL,
  PRIMARY KEY  (`group_sub_category_id`)
);

--
-- Dumping data for table `groups_sub_category`
--

INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(1, 1, 'Abroad/Overseas Groups', 'Abroad/Overseas Groups', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(2, 1, 'Academic Groups', 'Academic Groups', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(3, 1, 'Advising Groups', 'Advising Groups', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(4, 1, 'Alumni Groups', 'Alumni Groups', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(5, 1, 'Classes & Departments', 'Classes & Departments', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(6, 1, 'Clubs & Societies', 'Clubs & Societies', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(7, 1, 'Community Groups', 'Community Groups', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(8, 1, 'Creative Arts Groups', 'Creative Arts Groups', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(9, 1, 'Dorms & Residences', 'Dorms & Residences', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(10, 1, 'Ethnic/Cultural Groups', 'Ethnic/Cultural Groups', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(11, 1, 'Fraternities & Sororities', 'Fraternities & Sororities', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(12, 1, 'General', 'General', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(13, 1, 'Media/Publication Groups', 'Media/Publication Groups', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(14, 1, 'Musical Groups', 'Musical Groups', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(15, 1, 'Political Groups', 'Political Groups', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(16, 1, 'Pre-Professional Groups', 'Pre-Professional Groups', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(17, 1, 'Religious Groups', 'Religious Groups', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(18, 1, 'Service Groups', 'Service Groups', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(19, 1, 'Social Groups', 'Social Groups', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(20, 1, 'Student Government', 'Student Government', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(21, 1, 'Study Groups', 'Study Groups', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(22, 2, 'Automotive & Racing', 'Automotive & Racing', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(23, 2, 'Cheerleading', 'Cheerleading', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(24, 2, 'College Sports', 'College Sports', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(25, 2, 'Dance', 'Dance', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(26, 2, 'Extreme Sports', 'Extreme Sports', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(27, 2, 'Fantasy Sports', 'Fantasy Sports', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(28, 2, 'Fitness & Exercise', 'Fitness & Exercise', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(29, 2, 'Gambling', 'Gambling', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(30, 2, 'Games', 'Games', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(31, 2, 'General Sports', 'General Sports', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(32, 2, 'High School Sports', 'High School Sports', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(33, 2, 'International Sports', 'International Sports', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(34, 2, 'Intramural Sports', 'Intramural Sports', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(35, 2, 'Martial Arts', 'Martial Arts', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(36, 2, 'Olympic Sports', 'Olympic Sports', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(37, 2, 'Outdoor Sports', 'Outdoor Sports', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(38, 2, 'Professional Sports', 'Professional Sports', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(39, 2, 'Recreational Sports', 'Recreational Sports', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(40, 2, 'Sports Leagues', 'Sports Leagues', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(41, 2, 'Water Sports', 'Water Sports', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(42, 2, 'Weightlifting & Bodybuilding', 'Weightlifting & Bodybuilding', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(43, 2, 'Winter Sports', 'Winter Sports', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(44, 2, 'Yoga', 'Yoga', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(45, 3, 'Academic Organizations', 'Academic Organizations', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(46, 3, 'Advocacy Organizations', 'Advocacy Organizations', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(47, 3, 'Clubs & Societies', 'Clubs & Societies', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(48, 3, 'Community Organizations', 'Community Organizations', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(49, 3, 'General', 'General', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(50, 3, 'Non-Profit Organizations', 'Non-Profit Organizations', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(51, 3, 'Philanthropic Organizations', 'Philanthropic Organizations', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(52, 3, 'Political Organizations', 'Political Organizations', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(53, 3, 'Professional Organizations', 'Professional Organizations', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(54, 3, 'Religious Organizations', 'Religious Organizations', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(55, 3, 'Volunteer Organizations', 'Volunteer Organizations', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(56, 4, 'Activities', 'Activities', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(57, 4, 'Age', 'Age', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(58, 4, 'Beauty', 'Beauty', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(59, 4, 'Beliefs & Causes', 'Beliefs & Causes', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(60, 4, 'Current Events', 'Current Events', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(61, 4, 'Dating & Relationships', 'Dating & Relationships', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(62, 4, 'Families', 'Families', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(63, 4, 'Food & Drink', 'Food & Drink', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(64, 4, 'Friends', 'Friends', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(65, 4, 'Gardening', 'Gardening', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(66, 4, 'Health & Wellness', 'Health & Wellness', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(67, 4, 'History', 'History', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(68, 4, 'Hobbies & Crafts', 'Hobbies & Crafts', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(69, 4, 'Languages', 'Languages', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(70, 4, 'Pets & Animals', 'Pets & Animals', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(71, 4, 'Philosophy', 'Philosophy', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(72, 4, 'Politics', 'Politics', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(73, 4, 'Religion & Spirituality', 'Religion & Spirituality', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(74, 4, 'Science', 'Science', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(75, 4, 'Self-help', 'Self-help', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(76, 4, 'Sexuality', 'Sexuality', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(77, 4, 'Travel', 'Travel', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(78, 4, 'Wine', 'Wine', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(79, 5, 'Books & Literature', 'Books & Literature', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(80, 5, 'Celebrities', 'Celebrities', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(81, 5, 'Comics & Animation', 'Comics & Animation', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(82, 5, 'Dance', 'Dance', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(83, 5, 'Fashion', 'Fashion', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(84, 5, 'Fine Arts', 'Fine Arts', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(85, 5, 'General', 'General', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(86, 5, 'Humor', 'Humor', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(87, 5, 'Movies', 'Movies', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(88, 5, 'Nightlife', 'Nightlife', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(89, 5, 'Online Media', 'Online Media', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(90, 5, 'Performing Arts', 'Performing Arts', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(91, 5, 'Radio', 'Radio', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(92, 5, 'Television', 'Television', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(93, 5, 'Theater', 'Theater', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(94, 6, 'Cities', 'Cities', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(95, 6, 'Countries', 'Countries', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(96, 6, 'General', 'General', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(97, 6, 'Neighborhoods', 'Neighborhoods', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(98, 6, 'Places', 'Places', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(99, 6, 'Regions', 'Regions', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(100, 6, 'Ridesharing & Transportation', 'Ridesharing & Transportation', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(101, 6, 'States', 'States', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(102, 7, 'Computers & Hardware', 'Computers & Hardware', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(103, 7, 'Cyberculture', 'Cyberculture', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(104, 7, 'Gadgets', 'Gadgets', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(105, 7, 'Gaming', 'Gaming', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(106, 7, 'General', 'General', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(107, 7, 'Languages & Formats', 'Languages & Formats', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(108, 7, 'Mobile', 'Mobile', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(109, 7, 'Multimedia', 'Multimedia', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(110, 7, 'News', 'News', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(111, 7, 'Software', 'Software', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(112, 7, 'Websites', 'Websites', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(113, 8, 'Companies', 'Companies', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(114, 8, 'Consumer Groups', 'Consumer Groups', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(115, 8, 'Employment & Work', 'Employment & Work', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(116, 8, 'General', 'General', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(117, 8, 'Home Business', 'Home Business', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(118, 8, 'Investing', 'Investing', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(119, 8, 'Marketing & Advertising', 'Marketing & Advertising', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(120, 8, 'Public Relations', 'Public Relations', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(121, 8, 'Real Estate', 'Real Estate', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(122, 9, 'Blues', 'Blues', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(123, 9, 'Classical', 'Classical', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(124, 9, 'Country', 'Country', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(125, 9, 'Dance', 'Dance', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(126, 9, 'Electronic', 'Electronic', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(127, 9, 'Folk', 'Folk', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(128, 9, 'General', 'General', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(129, 9, 'Indie', 'Indie', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(130, 9, 'Instruments', 'Instruments', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(131, 9, 'International', 'International', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(132, 9, 'Jazz', 'Jazz', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(133, 9, 'Latin', 'Latin', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(134, 9, 'Live Music', 'Live Music', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(135, 9, 'Metal', 'Metal', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(136, 9, 'R&B & Soul', 'R&B & Soul', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(137, 9, 'Rap & Hip Hop', 'Rap & Hip Hop', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(138, 9, 'Reggae', 'Reggae', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(139, 9, 'Religious', 'Religious', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(140, 9, 'Rock', 'Rock', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(141, 9, 'Songwriting', 'Songwriting', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(142, 10, 'Facebook Classics', 'Facebook Classics', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(143, 10, 'Fan Clubs', 'Fan Clubs', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(144, 10, 'Inside Jokes', 'Inside Jokes', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(145, 10, 'Outlandish Statements', 'Outlandish Statements', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(146, 10, 'Too Much Information', 'Too Much Information', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(147, 10, 'Totally Pointless', 'Totally Pointless', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(148, 10, 'Totally Random', 'Totally Random', 'Yes', NULL);
INSERT INTO `groups_sub_category` (`group_sub_category_id`, `group_category_id`, `group_sub_category_name`, `group_sub_category_description`, `group_sub_category_status`, `date_added`) VALUES(149, 11, 'Sponsored', 'Sponsored', 'Yes', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `group_members`
--

DROP TABLE IF EXISTS `group_members`;
CREATE TABLE `group_members` (
  `group_member_id` int(11) NOT NULL auto_increment,
  `group_id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `is_admin` enum('Y','N') NOT NULL default 'N',
  `member_status` enum('accepted','blocked') NOT NULL default 'accepted',
  `date_created` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `date_modified` timestamp NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`group_member_id`)
);

--
-- Dumping data for table `group_members`
--

-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

DROP TABLE IF EXISTS `languages`;
CREATE TABLE `languages` (
  `lang_id` int(11) NOT NULL auto_increment,
  `lang_code` varchar(25) NOT NULL,
  `lang_name` varchar(255) NOT NULL,
  PRIMARY KEY  (`lang_id`)
);

--
-- Dumping data for table `languages`
--

INSERT INTO `languages` (`lang_id`, `lang_code`, `lang_name`) VALUES(1, 'en', 'English');

-- --------------------------------------------------------

--
-- Table structure for table `lifestage`
--

DROP TABLE IF EXISTS `lifestage`;
CREATE TABLE `lifestage` (
  `lifestage_id` int(11) NOT NULL auto_increment,
  `content` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`lifestage_id`)
);

--
-- Dumping data for table `lifestage`
--

INSERT INTO `lifestage` (`lifestage_id`, `content`) VALUES(1, 'in college/graduate school');
INSERT INTO `lifestage` (`lifestage_id`, `content`) VALUES(2, 'at a company');
INSERT INTO `lifestage` (`lifestage_id`, `content`) VALUES(3, 'in high school');
INSERT INTO `lifestage` (`lifestage_id`, `content`) VALUES(4, 'none of the above');

-- --------------------------------------------------------

--
-- Table structure for table `list_networks`
--

DROP TABLE IF EXISTS `list_networks`;
CREATE TABLE `list_networks` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `list_id` int(11) unsigned NOT NULL,
  `network_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned default NULL,
  `user_created` varchar(100) default NULL,
  `date_created` timestamp NOT NULL default CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
);

--
-- Dumping data for table `list_networks`
--

-- --------------------------------------------------------

--
-- Table structure for table `list_photos`
--

DROP TABLE IF EXISTS `list_photos`;
CREATE TABLE `list_photos` (
  `photo_id` int(11) unsigned NOT NULL auto_increment,
  `list_id` int(11) unsigned NOT NULL,
  `file_name` text,
  `remarks` text,
  `user_id` int(11) default NULL,
  `user_created` varchar(100) default NULL,
  `date_created` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `user_modified` varchar(100) default NULL,
  `date_modified` timestamp NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`photo_id`)
);

--
-- Dumping data for table `list_photos`
--

-- --------------------------------------------------------

--
-- Table structure for table `looking_for`
--

DROP TABLE IF EXISTS `looking_for`;
CREATE TABLE `looking_for` (
  `looking_id` int(11) NOT NULL auto_increment,
  `lookingfor` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`looking_id`)
);

--
-- Dumping data for table `looking_for`
--

INSERT INTO `looking_for` (`looking_id`, `lookingfor`) VALUES(1, 'Friendship');
INSERT INTO `looking_for` (`looking_id`, `lookingfor`) VALUES(2, 'Dating');
INSERT INTO `looking_for` (`looking_id`, `lookingfor`) VALUES(3, 'A Relationship');
INSERT INTO `looking_for` (`looking_id`, `lookingfor`) VALUES(4, 'Random Play');
INSERT INTO `looking_for` (`looking_id`, `lookingfor`) VALUES(5, 'Whatever I can get');

-- --------------------------------------------------------

--
-- Table structure for table `looking_for_map`
--

DROP TABLE IF EXISTS `looking_for_map`;
CREATE TABLE `looking_for_map` (
  `looking_for_map_id` bigint(20) NOT NULL auto_increment,
  `looking_id` bigint(20) NOT NULL,
  `basic_profile_id` bigint(20) NOT NULL,
  PRIMARY KEY  (`looking_for_map_id`)
);

--
-- Dumping data for table `looking_for_map`
--

-- --------------------------------------------------------

--
-- Table structure for table `mail_templates`
--

DROP TABLE IF EXISTS `mail_templates`;
CREATE TABLE `mail_templates` (
  `template_id` int(11) NOT NULL auto_increment,
  `template_key` varchar(255) NOT NULL,
  `template_title` text NOT NULL,
  `template_subject` text NOT NULL,
  `template_content` text NOT NULL,
  `special_variables` text NOT NULL,
  `template_language` varchar(255) NOT NULL,
  PRIMARY KEY  (`template_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci PACK_KEYS=0;

--
-- Dumping data for table `mail_templates`
--

INSERT INTO `mail_templates` (`template_id`, `template_key`, `template_title`, `template_subject`, `template_content`, `special_variables`, `template_language`) VALUES(1, 'register_confirm', 'Account Confirmation', '~~siteName~~ Registration Confirmation', 'Hey ~~receiverName~~\n\nYou recently registered for ~~siteTitle~~ using this email address. To complete your registration, follow the link below:\n\n\n<a href="~~attachUrl~~" target="_blank">Confirm</a>\n\n(If clicking on the link does not work, try copying and pasting the url below into your browser.)\n\n~~attachUrl~~\n\nIf you did not register for ~~siteTitle~~, please discard this message.\nPlease contact ~~adminEmail~~ with any questions.\n\nThanks,\n~~adminName~~', '~~receiverName~~,~~siteTitle~~,~~attachLink~~,~~adminEmail~~,~~adminName~~', 'en');
INSERT INTO `mail_templates` (`template_id`, `template_key`, `template_title`, `template_subject`, `template_content`, `special_variables`, `template_language`) VALUES(2, 'invite_friend', 'Invite Friends', 'Friend Request from ~~siteName~~', 'Hi\n\n~~senderName~~ has sent you a friend request from ~~siteName~~\n\nTo continue your access please use the following url.\n\n~~attachUrl~~\n\n\n~~senderName~~ private message:\n\n\n~~privateMessage~~\n\nThanks,\n~~adminName~~', '~~senderName~~,~~siteName~~,~~attachUrl~~,~~privateMessage~~,~~adminName~~', 'en');
INSERT INTO `mail_templates` (`template_id`, `template_key`, `template_title`, `template_subject`, `template_content`, `special_variables`, `template_language`) VALUES(3, '', 'Invite friends to join a group', '~~senderName~~ has invited you to join the group ~~groupName~~', '~~senderName~~ has invited you to join ~~siteName~~ group "~~groupName~~" To see more details and confirm this group invitation, follow the link below, ~~attachUrl~~ ~~privateMessage~~ Thanks, ~~adminName~~', '~~senderName~~,~~groupName~~,~~siteName~~,~~attachUrl~~,~~privateMessage~~,~~adminName~~', '');
INSERT INTO `mail_templates` (`template_id`, `template_key`, `template_title`, `template_subject`, `template_content`, `special_variables`, `template_language`) VALUES(4, '', 'Invite friends to join in an event', '~~senderName~~ has invited you to join the event ~~eventName~~', '~~senderName~~ has invited you to join ~~siteName~~ event "~~eventName~~"\r\n\r\nTo see more details and confirm this event invitation, follow the link below,\r\n\r\n~~attachUrl~~\r\n\r\n~~privateMessage~~\r\n\r\nThanks,\r\n~~adminName~~', '~~senderName~~,~~eventName~~,~~siteName~~,~~attachUrl~~,~~privateMessage~~,~~adminName~~', '');
INSERT INTO `mail_templates` (`template_id`, `template_key`, `template_title`, `template_subject`, `template_content`, `special_variables`, `template_language`) VALUES(5, '', 'Adds me as a friend', 'Invitation from ~~siteName~~', 'Hi\r\n\r\n~~senderName~~ has sent you the invitation to join ~~siteName~~.\r\n\r\nTo continue your access please use the following url,		\r\n						~~attachUrl~~\r\n\r\n~~privateMessage~~\r\n\r\nThanks,\r\n~~adminName~~', '~~senderName~~,~~siteName~~,~~attachUrl~~,~~privateMessage~~,~~adminName~~', '');
INSERT INTO `mail_templates` (`template_id`, `template_key`, `template_title`, `template_subject`, `template_content`, `special_variables`, `template_language`) VALUES(6, 'network_join_confirm', 'Network confirmation', 'Request to join ~~networkName~~ network.', 'To confirm and continue access to ~~networkName~~ network, please use the following url\r\n\r\n~~attachUrl~~\r\n\r\nIf you have not made the request, please ignore the email.\r\n\r\nThanks,\r\n~~adminName~~', '~~networkName~~,~~attachUrl~~,~~adminName~~', '');
INSERT INTO `mail_templates` (`template_id`, `template_key`, `template_title`, `template_subject`, `template_content`, `special_variables`, `template_language`) VALUES(7, '', 'Event Cancellation', 'Event cancellation From ~~siteName~~', 'Dear ~~receiverName~~,\r\n\r\nThe following event has been cancelled by the event owner.\r\n\r\n\r\n<table><tr><td>Event Name:</td><td>~~eventName~~</td></tr>\r\n<tr><td>Event start time:</td><td>~~eventStartTime~~</td></tr>\r\n<tr><td>Event end time:</td><td>~~eventEndTime~~</td></tr>\r\n<tr><td>Location:</td><td>~~eventLocation~~</td></tr>\r\n<tr><td colspan="2">~~privateMessage~~</td></tr></table>\r\n									\r\n\r\nThanks,\r\n~~adminName~~', '~~siteName~~,~~receiverName~~,~~eventName~~,~~eventStartTime~~,~~eventEndTime~~,~~eventLocation~~,~~privateMessage~~,~~adminName~~', '');
INSERT INTO `mail_templates` (`template_id`, `template_key`, `template_title`, `template_subject`, `template_content`, `special_variables`, `template_language`) VALUES(9, '', 'Notes Tagging ', '~~senderName~~ tagged you in a note on ~~siteName~~...', '~~senderName~~ tagged  you in the note ~~noteTitle~~:\n\n	To read the note, follow the link \n\nbelow:\n	~~attachUrl~~\n\nThanks,\n~~adminName~~\n\n', '~~senderName~~,~~noteTitle~~,~~siteName~~,~~attachUrl~~~~adminName~~', '');
INSERT INTO `mail_templates` (`template_id`, `template_key`, `template_title`, `template_subject`, `template_content`, `special_variables`, `template_language`) VALUES(10, 'group_invitation', 'Inviting members to a group', '~~senderName~~ invited you to join the ~~siteName~~ group ~~groupName~~.....', '~~senderName~~ invited you to join the ~~siteName~~ group ~~groupName~~.\r\n\r\n~~senderName~~ says, "~~message~~".\r\n\r\nTo see more details and \r\nconfirm this group invitation, follow the link\r\n below:\r\n~~attachURL~~\r\n\r\nThanks,\r\n~~adminName~~', '~~senderName~~,~~siteName~~,~~groupName~~\r\n,~~message~~,~~attachURL~~,~~adminName~~', 'en');
INSERT INTO `mail_templates` (`template_id`, `template_key`, `template_title`, `template_subject`, `template_content`, `special_variables`, `template_language`) VALUES(11, 'group_invitation', 'Inviting members to a group', '~~senderName~~ invited you to join the ~~siteName~~ group ~~groupName~~.....', '~~senderName~~ invited you to join the ~~siteName~~ group ~~groupName~~.\r\n\r\n~~senderName~~ says, "~~message~~".\r\n\r\nTo see more details and \r\nconfirm this group invitation, follow the link\r\n below:\r\n~~attachURL~~\r\n\r\nThanks,\r\n~~adminName~~', '~~senderName~~,~~siteName~~,~~groupName~~\r\n,~~message~~,~~attachURL~~,~~adminName~~', 'en');
INSERT INTO `mail_templates` (`template_id`, `template_key`, `template_title`, `template_subject`, `template_content`, `special_variables`, `template_language`) VALUES(12, 'group_invitation', 'Inviting members to a group', '~~senderName~~ invited you to join the ~~siteName~~ group ~~groupName~~.....', '~~senderName~~ invited you to join the ~~siteName~~ group ~~groupName~~.\r\n\r\n~~senderName~~ says, "~~message~~".\r\n\r\nTo see more details and \r\nconfirm this group invitation, follow the link\r\n below:\r\n~~attachURL~~\r\n\r\nThanks,\r\n~~adminName~~', '~~senderName~~,~~siteName~~,~~groupName~~\r\n,~~message~~,~~attachURL~~,~~adminName~~', 'en');
INSERT INTO `mail_templates` (`template_id`, `template_key`, `template_title`, `template_subject`, `template_content`, `special_variables`, `template_language`) VALUES(13, 'event_invitation', 'Inviting members to a event', '~~senderName~~ invited you to join the ~~siteName~~ event "~~eventName~~".....', '~~senderName~~ invited you to join the ~~siteName~~ event ~~eventName~~.\r\n\r\n~~senderName~~ says, "~~message~~".\r\n\r\nTo see more details and confirm this event invitation, follow the link\r\n below:\r\n~~attachURL~~\r\n\r\nThanks,\r\n~~adminName~~', '~~senderName~~,~~siteName~~,~~eventName~~,~~message~~,~~attachURL~~,~~adminName~~', 'en');
INSERT INTO `mail_templates` (`template_id`, `template_key`, `template_title`, `template_subject`, `template_content`, `special_variables`, `template_language`) VALUES(14, 'notes_tag', 'Notes Tagging ', '~~senderName~~ tagged you in a note on ~~siteName~~...', '~~senderName~~ tagged  you in the note ~~noteTitle~~:\n\n	To read the note, follow the link \n\nbelow:\n	~~attachUrl~~\n\nThanks,\n~~adminName~~\n\n', '~~senderName~~,~~noteTitle~~,~~siteName~~,~~attachUrl~~,~~adminName~~', 'en');

-- --------------------------------------------------------

--
-- Table structure for table `manage_static_page`
--

DROP TABLE IF EXISTS `manage_static_page`;
CREATE TABLE `manage_static_page` (
  `page_id` int(11) NOT NULL auto_increment,
  `page_name` varchar(50) NOT NULL,
  `title` varchar(15) NOT NULL,
  `date_added` datetime NOT NULL,
  `page_index` int(11) NOT NULL,
  `is_dynamic` tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (`page_id`)
);

--
-- Dumping data for table `manage_static_page`
--

INSERT INTO `manage_static_page` (`page_id`, `page_name`, `title`, `date_added`, `page_index`, `is_dynamic`) VALUES(1, 'help', 'Help', '2008-02-09 14:04:18', 1, 0);
INSERT INTO `manage_static_page` (`page_id`, `page_name`, `title`, `date_added`, `page_index`, `is_dynamic`) VALUES(2, 'policy', 'Privacy', '2008-02-09 14:04:18', 2, 0);
INSERT INTO `manage_static_page` (`page_id`, `page_name`, `title`, `date_added`, `page_index`, `is_dynamic`) VALUES(3, 'terms', 'Terms', '2008-02-09 14:04:18', 3, 0);
INSERT INTO `manage_static_page` (`page_id`, `page_name`, `title`, `date_added`, `page_index`, `is_dynamic`) VALUES(4, 'about', 'About', '2008-02-09 14:04:18', 4, 0);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
CREATE TABLE `messages` (
  `message_id` bigint(10) unsigned NOT NULL auto_increment,
  `message_parent_id` bigint(20) NOT NULL default '0',
  `from_id` bigint(20) unsigned NOT NULL default '0',
  `to_id` bigint(20) default NULL,
  `subject` varchar(255) default NULL,
  `message` text,
  `from_message_status` enum('read','unread') default 'unread',
  `to_message_status` enum('read','unread') NOT NULL default 'unread',
  `from_message_in` enum('inbox','sent','trash','delete') NOT NULL default 'inbox',
  `to_message_in` enum('inbox','sent','trash','delete') NOT NULL,
  `datestamp` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`message_id`)
);

--
-- Dumping data for table `messages`
--

-- --------------------------------------------------------

--
-- Table structure for table `message_setting`
--

DROP TABLE IF EXISTS `message_setting`;
CREATE TABLE `message_setting` (
  `message_setting_id` int(3) NOT NULL auto_increment,
  `message_setting_type` varchar(200) NOT NULL,
  PRIMARY KEY  (`message_setting_id`)
);

--
-- Dumping data for table `message_setting`
--

INSERT INTO `message_setting` (`message_setting_id`, `message_setting_type`) VALUES(1, 'Basic Info');
INSERT INTO `message_setting` (`message_setting_id`, `message_setting_type`) VALUES(2, 'Contact Info');
INSERT INTO `message_setting` (`message_setting_id`, `message_setting_type`) VALUES(3, 'Personal Info');
INSERT INTO `message_setting` (`message_setting_id`, `message_setting_type`) VALUES(4, 'Education Info');
INSERT INTO `message_setting` (`message_setting_id`, `message_setting_type`) VALUES(5, 'Work Info');
INSERT INTO `message_setting` (`message_setting_id`, `message_setting_type`) VALUES(6, 'Wall');
INSERT INTO `message_setting` (`message_setting_id`, `message_setting_type`) VALUES(7, 'Online Status');
INSERT INTO `message_setting` (`message_setting_id`, `message_setting_type`) VALUES(8, 'Status Updates');
INSERT INTO `message_setting` (`message_setting_id`, `message_setting_type`) VALUES(9, 'Friends');
INSERT INTO `message_setting` (`message_setting_id`, `message_setting_type`) VALUES(10, 'Groups');
INSERT INTO `message_setting` (`message_setting_id`, `message_setting_type`) VALUES(11, 'Photos Tagged of Me');
INSERT INTO `message_setting` (`message_setting_id`, `message_setting_type`) VALUES(12, 'Videos Tagged of Me');
INSERT INTO `message_setting` (`message_setting_id`, `message_setting_type`) VALUES(13, 'Posted Items');
INSERT INTO `message_setting` (`message_setting_id`, `message_setting_type`) VALUES(14, 'Notes');

-- --------------------------------------------------------

--
-- Table structure for table `message_setting_status`
--

DROP TABLE IF EXISTS `message_setting_status`;
CREATE TABLE `message_setting_status` (
  `message_setting_status_id` int(3) NOT NULL auto_increment,
  `user_id` int(3) NOT NULL,
  `message_setting_id` int(3) NOT NULL,
  `message_setting_value` enum('yes','no') NOT NULL default 'no',
  PRIMARY KEY  (`message_setting_status_id`)
);

--
-- Dumping data for table `message_setting_status`
--

-- --------------------------------------------------------

--
-- Table structure for table `messengers`
--

DROP TABLE IF EXISTS `messengers`;
CREATE TABLE `messengers` (
  `messenger_id` bigint(20) NOT NULL auto_increment,
  `messenger_name` varchar(250) NOT NULL,
  PRIMARY KEY  (`messenger_id`)
);

--
-- Dumping data for table `messengers`
--

INSERT INTO `messengers` (`messenger_id`, `messenger_name`) VALUES(1, 'AIM');
INSERT INTO `messengers` (`messenger_id`, `messenger_name`) VALUES(2, 'Google Talk');
INSERT INTO `messengers` (`messenger_id`, `messenger_name`) VALUES(3, 'Skype');
INSERT INTO `messengers` (`messenger_id`, `messenger_name`) VALUES(4, 'Windows Live');
INSERT INTO `messengers` (`messenger_id`, `messenger_name`) VALUES(5, 'Yahoo');
INSERT INTO `messengers` (`messenger_id`, `messenger_name`) VALUES(6, 'Gadu-Gadu');
INSERT INTO `messengers` (`messenger_id`, `messenger_name`) VALUES(7, 'ICQ');

-- --------------------------------------------------------

--
-- Table structure for table `mini_feed_log`
--

DROP TABLE IF EXISTS `mini_feed_log`;
CREATE TABLE `mini_feed_log` (
  `mini_feed_log_id` bigint(20) NOT NULL auto_increment,
  `log_content` text NOT NULL,
  `link1` text NOT NULL,
  `link2` text NOT NULL,
  `link3` text NOT NULL,
  `link4` text NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `datestamp` timestamp NOT NULL default CURRENT_TIMESTAMP,
  PRIMARY KEY  (`mini_feed_log_id`)
);

--
-- Dumping data for table `mini_feed_log`
--

-- --------------------------------------------------------

--
-- Table structure for table `mini_feed_setting`
--

DROP TABLE IF EXISTS `mini_feed_setting`;
CREATE TABLE `mini_feed_setting` (
  `mini_feed_settings_id` bigint(20) NOT NULL auto_increment,
  `mini_feed_label` varchar(255) NOT NULL,
  `mini_feed_code` enum('group','event','photo','network','profile','posteditem','notes','marketplace','friends','discussion','wall') NOT NULL,
  PRIMARY KEY  (`mini_feed_settings_id`)
);

--
-- Dumping data for table `mini_feed_setting`
--

INSERT INTO `mini_feed_setting` (`mini_feed_settings_id`, `mini_feed_label`, `mini_feed_code`) VALUES(1, 'Remove Profile Info', 'profile');
INSERT INTO `mini_feed_setting` (`mini_feed_settings_id`, `mini_feed_label`, `mini_feed_code`) VALUES(2, 'Write a Wall Post', 'wall');
INSERT INTO `mini_feed_setting` (`mini_feed_settings_id`, `mini_feed_label`, `mini_feed_code`) VALUES(3, 'Comment on a Note', 'notes');
INSERT INTO `mini_feed_setting` (`mini_feed_settings_id`, `mini_feed_label`, `mini_feed_code`) VALUES(4, 'Comment on a Photo', 'photo');
INSERT INTO `mini_feed_setting` (`mini_feed_settings_id`, `mini_feed_label`, `mini_feed_code`) VALUES(5, 'Comment on a Video', 'group');
INSERT INTO `mini_feed_setting` (`mini_feed_settings_id`, `mini_feed_label`, `mini_feed_code`) VALUES(6, 'Comment on a Posted Item', 'group');
INSERT INTO `mini_feed_setting` (`mini_feed_settings_id`, `mini_feed_label`, `mini_feed_code`) VALUES(7, 'Post on a Discussion Board', 'group');
INSERT INTO `mini_feed_setting` (`mini_feed_settings_id`, `mini_feed_label`, `mini_feed_code`) VALUES(8, 'Add a Friend', 'group');
INSERT INTO `mini_feed_setting` (`mini_feed_settings_id`, `mini_feed_label`, `mini_feed_code`) VALUES(9, 'Remove my Relationship Status', 'group');
INSERT INTO `mini_feed_setting` (`mini_feed_settings_id`, `mini_feed_label`, `mini_feed_code`) VALUES(10, 'Leave a Group', 'group');
INSERT INTO `mini_feed_setting` (`mini_feed_settings_id`, `mini_feed_label`, `mini_feed_code`) VALUES(11, 'Leave a Network', 'group');
INSERT INTO `mini_feed_setting` (`mini_feed_settings_id`, `mini_feed_label`, `mini_feed_code`) VALUES(12, 'Show times in my Mini-Feed', 'group');
INSERT INTO `mini_feed_setting` (`mini_feed_settings_id`, `mini_feed_label`, `mini_feed_code`) VALUES(13, 'Update the status', 'group');
INSERT INTO `mini_feed_setting` (`mini_feed_settings_id`, `mini_feed_label`, `mini_feed_code`) VALUES(14, 'Create a group', 'group');
INSERT INTO `mini_feed_setting` (`mini_feed_settings_id`, `mini_feed_label`, `mini_feed_code`) VALUES(15, 'Add a Photo', 'group');
INSERT INTO `mini_feed_setting` (`mini_feed_settings_id`, `mini_feed_label`, `mini_feed_code`) VALUES(16, 'Create a event', 'group');

-- --------------------------------------------------------

--
-- Table structure for table `mini_feed_setting_staus`
--

DROP TABLE IF EXISTS `mini_feed_setting_staus`;
CREATE TABLE `mini_feed_setting_staus` (
  `mini_feed_settings_staus_id` bigint(20) NOT NULL auto_increment,
  `user_id` bigint(11) NOT NULL,
  `mini_feed_settings_id` bigint(20) NOT NULL,
  `mini_feed_code` enum('group','event','photo','network','user','posteditem','notes','marketplace') NOT NULL,
  `mini_feed_settings_value` enum('yes','no') NOT NULL default 'no',
  PRIMARY KEY  (`mini_feed_settings_staus_id`)
);

--
-- Dumping data for table `mini_feed_setting_staus`
--

-- --------------------------------------------------------

--
-- Table structure for table `mini_feed_templates`
--

DROP TABLE IF EXISTS `mini_feed_templates`;
CREATE TABLE `mini_feed_templates` (
  `mini_feed_template_id` int(11) NOT NULL auto_increment,
  `mini_feed_key` varchar(255) NOT NULL,
  `mini_feed_settings_id` int(11) NOT NULL,
  `template_content` text NOT NULL,
  `special_variables` text NOT NULL,
  `template_language` varchar(5) NOT NULL,
  PRIMARY KEY  (`mini_feed_template_id`)
);

--
-- Dumping data for table `mini_feed_templates`
--

INSERT INTO `mini_feed_templates` (`mini_feed_template_id`, `mini_feed_key`, `mini_feed_settings_id`, `template_content`, `special_variables`, `template_language`) VALUES(1, 'WALL_POST', 2, '~~postedBy~~ wrote on the ~~link~~~~postedFor~~~~link~~ ~~postedIn~~ wall.', '~~postedBy~~,~~postedFor~~,~~postedIn~~', 'en');
INSERT INTO `mini_feed_templates` (`mini_feed_template_id`, `mini_feed_key`, `mini_feed_settings_id`, `template_content`, `special_variables`, `template_language`) VALUES(2, 'CREATE_GROUP', 14, '~~postedBy~~ Created a group "~~link~~~~groupName~~~~link~~".', '~~postedBy~~,~~groupName~~', 'en');
INSERT INTO `mini_feed_templates` (`mini_feed_template_id`, `mini_feed_key`, `mini_feed_settings_id`, `template_content`, `special_variables`, `template_language`) VALUES(3, 'CREATE_EVENT', 16, '~~postedBy~~ Created a event "~~link~~~~eventName~~~~link~~".', '~~postedBy~~,~~eventName~~', 'en');
INSERT INTO `mini_feed_templates` (`mini_feed_template_id`, `mini_feed_key`, `mini_feed_settings_id`, `template_content`, `special_variables`, `template_language`) VALUES(4, 'LEAVE_GROUP', 10, '~~postedBy~~ Leaved from group "~~link~~~~groupName~~~~link~~".', '~~postedBy~~,~~groupName~~', 'en');

-- --------------------------------------------------------

--
-- Table structure for table `networks`
--

DROP TABLE IF EXISTS `networks`;
CREATE TABLE `networks` (
  `network_id` bigint(20) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL default '0',
  `network_type` enum('school','college','work','region') NOT NULL default 'school',
  `network_status` enum('enabled','disabled') NOT NULL default 'disabled',
  `network_name` varchar(255) NOT NULL,
  `network_email` varchar(255) NOT NULL default '',
  `network_country` int(11) NOT NULL,
  `network_city` varchar(255) NOT NULL default '',
  `network_state` int(11) NOT NULL,
  `network_website` varchar(255) NOT NULL,
  `network_members` bigint(20) NOT NULL default '0',
  `contact_email` varchar(255) NOT NULL default '',
  `datestamp` timestamp NOT NULL default CURRENT_TIMESTAMP,
  PRIMARY KEY  (`network_id`)
);

INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(2, 0, 'region', 'enabled', 'Birmingham', '', 1, 'Birmingham, AL', 14, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(3, 0, 'region', 'enabled', 'Huntsville Decatur', '', 1, 'Huntsville / Decatur, AL', 14, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(4, 0, 'region', 'enabled', 'Mobile', '', 1, 'Mobile, AL', 14, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(5, 0, 'region', 'enabled', 'Montgomery', '', 1, 'Montgomery, AL', 14, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(6, 0, 'region', 'enabled', 'Anchorage', '', 1, 'Anchorage, AK', 15, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(7, 0, 'region', 'enabled', 'Central Alaska', '', 1, 'Central Alaska, AK', 15, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(8, 0, 'region', 'enabled', 'Juneau', '', 1, 'Juneau, AK', 15, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(9, 0, 'region', 'enabled', 'Northern Arizona', '', 1, 'Northern Arizona, AZ', 16, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(10, 0, 'region', 'enabled', 'Tucson', '', 1, 'Tucson, AZ', 16, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(11, 0, 'region', 'enabled', 'Western Arizona', '', 1, 'Western Arizona, AZ', 16, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(12, 0, 'region', 'enabled', 'Fayetteville', '', 1, 'Fayetteville, AR', 17, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(13, 0, 'region', 'enabled', 'Fort Smith', '', 1, 'Fort Smith, AR', 17, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(14, 0, 'region', 'enabled', 'Jonesboro', '', 1, 'Jonesboro, AR', 17, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(15, 0, 'region', 'enabled', 'Little Rock', '', 1, 'Little Rock, AR', 17, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(16, 0, 'region', 'enabled', 'Bakersfield', '', 1, 'Bakersfield, CA', 18, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(17, 0, 'region', 'enabled', 'Central Coast', '', 1, 'Central Coast, CA', 18, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(18, 0, 'region', 'enabled', 'Chico', '', 1, 'Chico, CA', 18, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(19, 0, 'region', 'enabled', 'East Bay', '', 1, 'East Bay, CA', 18, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(20, 0, 'region', 'enabled', 'Fresno', '', 1, 'Fresno, CA', 18, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(21, 0, 'region', 'enabled', 'Inland Empire', '', 1, 'Inland Empire, CA', 18, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(22, 0, 'region', 'enabled', 'Los Angeles', '', 1, 'Los Angeles, CA', 18, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(23, 0, 'region', 'enabled', 'Monterey Bay', '', 1, 'Monterey Bay, CA', 18, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(24, 0, 'region', 'enabled', 'Orange County', '', 1, 'Orange County, CA', 18, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(25, 0, 'region', 'enabled', 'Redding', '', 1, 'Redding, CA', 18, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(26, 0, 'region', 'enabled', 'Sacramento', '', 1, 'Sacramento, CA', 18, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(27, 0, 'region', 'enabled', 'San Diego', '', 1, 'San Diego, CA', 18, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(28, 0, 'region', 'enabled', 'San Francisco', '', 1, 'San Francisco, CA', 18, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(29, 0, 'region', 'enabled', 'Santa Barbara', '', 1, 'Santa Barbara, CA', 18, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(30, 0, 'region', 'enabled', 'Santa Cruz', '', 1, 'Santa Cruz, CA', 18, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(31, 0, 'region', 'enabled', 'Silicon Valley', '', 1, 'Silicon Valley, CA', 18, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(32, 0, 'region', 'enabled', 'Sonoma - Napa', '', 1, 'Sonoma / Napa, CA', 18, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(33, 0, 'region', 'enabled', 'Stockton - Modesto', '', 1, 'Stockton / Modesto, CA', 18, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(34, 0, 'region', 'enabled', 'Ventura County', '', 1, 'Ventura County, CA', 18, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(35, 0, 'region', 'enabled', 'Boulder', '', 1, 'Boulder, CO', 19, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(36, 0, 'region', 'enabled', 'Colorado Springs', '', 1, 'Colorado Springs, CO', 19, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(37, 0, 'region', 'enabled', 'Denver', '', 1, 'Denver, CO', 19, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(38, 0, 'region', 'enabled', 'Northern Colorado', '', 1, 'Northern Colorado, CO', 19, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(39, 0, 'region', 'enabled', 'Western Colorado', '', 1, 'Western Colorado, CO', 19, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(40, 0, 'region', 'enabled', 'Bridgeport - Stamford', '', 1, 'Bridgeport / Stamford, CT', 20, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(41, 0, 'region', 'enabled', 'Hartford', '', 1, 'Hartford, CT', 20, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(42, 0, 'region', 'enabled', 'New Haven', '', 1, 'New Haven, CT', 20, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(43, 0, 'region', 'enabled', 'Dover', '', 1, 'Dover, DE', 21, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(44, 0, 'region', 'enabled', 'Wilmington', '', 1, 'Wilmington, DE', 21, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(45, 0, 'region', 'enabled', 'Washington', '', 1, 'Washington, DC', 23, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(46, 0, 'region', 'enabled', 'Cape Coral - Fort Myers', '', 1, 'Cape Coral / Fort Myers, FL', 23, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(47, 0, 'region', 'enabled', 'Daytona Beach', '', 1, 'Daytona Beach, FL', 23, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(48, 0, 'region', 'enabled', 'Fort Lauderdale', '', 1, 'Fort Lauderdale, FL', 23, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(49, 0, 'region', 'enabled', 'Gainesville', '', 1, 'Gainesville, FL', 23, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(50, 0, 'region', 'enabled', 'Jacksonville', '', 1, 'Jacksonville, FL', 23, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(51, 0, 'region', 'enabled', 'Miami', '', 1, 'Miami, FL', 23, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(52, 0, 'region', 'enabled', 'Naples', '', 1, 'Naples, FL', 23, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(53, 0, 'region', 'enabled', 'Ocala', '', 1, 'Ocala, FL', 23, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(54, 0, 'region', 'enabled', 'Orlando', '', 1, 'Orlando, FL', 23, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(55, 0, 'region', 'enabled', 'Panama City', '', 1, 'Panama City, FL', 23, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(56, 0, 'region', 'enabled', 'Sarasota', '', 1, 'Sarasota, FL', 23, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(57, 0, 'region', 'enabled', 'Tallahassee', '', 1, 'Tallahassee, FL', 23, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(58, 0, 'region', 'enabled', 'Tampa Bay', '', 1, 'Tampa Bay, FL', 23, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(59, 0, 'region', 'enabled', 'West Palm Beach', '', 1, 'West Palm Beach, FL', 23, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(60, 0, 'region', 'enabled', 'Athens', '', 1, 'Athens, GA', 24, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(61, 0, 'region', 'enabled', 'Atlanta', '', 1, 'Atlanta, GA', 24, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(62, 0, 'region', 'enabled', 'Augusta', '', 1, 'Augusta, GA', 24, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(63, 0, 'region', 'enabled', 'Macon - Warner Robins', '', 1, 'Macon / Warner Robins, GA', 24, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(64, 0, 'region', 'enabled', 'Savannah', '', 1, 'Savannah, GA', 24, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(65, 0, 'region', 'enabled', 'Southern Georgia', '', 1, 'Southern Georgia, GA', 24, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(66, 0, 'region', 'enabled', 'Guam', '', 1, 'Guam', 0, '25', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(67, 0, 'region', 'enabled', 'Hawaii', '', 1, 'Hawaii, HI', 26, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(68, 0, 'region', 'enabled', 'Boise', '', 1, 'Boise, ID', 27, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(69, 0, 'region', 'enabled', 'Eastern Idaho', '', 1, 'Eastern Idaho, ID', 27, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(70, 0, 'region', 'enabled', 'Chicago', '', 1, 'Chicago, IL', 28, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(71, 0, 'region', 'enabled', 'Peoria', '', 1, 'Peoria, IL', 28, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(72, 0, 'region', 'enabled', 'Rockford', '', 1, 'Rockford, IL', 28, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(73, 0, 'region', 'enabled', 'Urbana - Champaign', '', 1, 'Urbana / Champaign, IL', 28, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(74, 0, 'region', 'enabled', 'Bloomington', '', 1, 'Bloomington, IN', 29, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(75, 0, 'region', 'enabled', 'Evansville', '', 1, 'Evansville, IN', 29, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(76, 0, 'region', 'enabled', 'Fort Wayne', '', 1, 'Fort Wayne, IN', 29, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(77, 0, 'region', 'enabled', 'Indianapolis', '', 1, 'Indianapolis, IN', 29, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(78, 0, 'region', 'enabled', 'Lafayette', '', 1, 'Lafayette, IN', 29, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(79, 0, 'region', 'enabled', 'Northern Indiana', '', 1, 'Northern Indiana, IN', 29, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(80, 0, 'region', 'enabled', 'Terre Haute', '', 1, 'Terre Haute, IN', 29, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(81, 0, 'region', 'enabled', 'Cedar Rapids', '', 1, 'Cedar Rapids, IA', 30, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(82, 0, 'region', 'enabled', 'Davenport', '', 1, 'Davenport, IA', 30, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(83, 0, 'region', 'enabled', 'Des Moines', '', 1, 'Des Moines, IA', 30, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(84, 0, 'region', 'enabled', 'Sioux City', '', 1, 'Sioux City, IA', 30, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(85, 0, 'region', 'enabled', 'Waterloo', '', 1, 'Waterloo, IA', 30, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(86, 0, 'region', 'enabled', 'Topeka', '', 1, 'Topeka, KS', 31, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(87, 0, 'region', 'enabled', 'Wichita', '', 1, 'Wichita, KS', 31, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(88, 0, 'region', 'enabled', 'Bowling Green', '', 1, 'Bowling Green, KY', 32, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(89, 0, 'region', 'enabled', 'Lexington', '', 1, 'Lexington, KY', 32, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(90, 0, 'region', 'enabled', 'Louisville', '', 1, 'Louisville, KY', 32, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(91, 0, 'region', 'enabled', 'Alexandria', '', 1, 'Alexandria, LA', 33, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(92, 0, 'region', 'enabled', 'Baton Rouge', '', 1, 'Baton Rouge, LA', 33, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(93, 0, 'region', 'enabled', 'Lafayette', '', 1, 'Lafayette, LA', 33, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(94, 0, 'region', 'enabled', 'Lake Charles', '', 1, 'Lake Charles, LA', 33, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(95, 0, 'region', 'enabled', 'Monroe', '', 1, 'Monroe, LA', 33, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(96, 0, 'region', 'enabled', 'New Orleans', '', 1, 'New Orleans, LA', 33, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(97, 0, 'region', 'enabled', 'Shreveport', '', 1, 'Shreveport, LA', 33, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(98, 0, 'region', 'enabled', 'Auburn - Lewiston', '', 1, 'Auburn / Lewiston, ME', 34, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(99, 0, 'region', 'enabled', 'Bangor', '', 1, 'Bangor, ME', 34, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(100, 0, 'region', 'enabled', 'Portland', '', 1, 'Portland, ME', 34, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(101, 0, 'region', 'enabled', 'Baltimore', '', 1, 'Baltimore, MD', 35, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(102, 0, 'region', 'enabled', 'Salisbury', '', 1, 'Salisbury, MD', 35, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(103, 0, 'region', 'enabled', 'Boston', '', 1, 'Boston, MA', 36, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(104, 0, 'region', 'enabled', 'Cape Cod', '', 1, 'Cape Cod, MA', 36, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(105, 0, 'region', 'enabled', 'Lowell', '', 1, 'Lowell, MA', 36, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(106, 0, 'region', 'enabled', 'Springfield', '', 1, 'Springfield, MA', 36, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(107, 0, 'region', 'enabled', 'Worcester', '', 1, 'Worcester, MA', 36, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(108, 0, 'region', 'enabled', 'Ann Arbor', '', 1, 'Ann Arbor, MI', 37, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(109, 0, 'region', 'enabled', 'Detroit', '', 1, 'Detroit, MI', 37, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(110, 0, 'region', 'enabled', 'Flint', '', 1, 'Flint, MI', 37, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(111, 0, 'region', 'enabled', 'Grand Rapids', '', 1, 'Grand Rapids, MI', 37, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(112, 0, 'region', 'enabled', 'Kalamazoo - Battle Creek', '', 1, 'Kalamazoo / Battle Creek, MI', 37, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(113, 0, 'region', 'enabled', 'Lansing - East Lansing', '', 1, 'Lansing / East Lansing, MI', 37, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(114, 0, 'region', 'enabled', 'Saginaw - Bay City', '', 1, 'Saginaw / Bay City, MI', 37, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(115, 0, 'region', 'enabled', 'Duluth', '', 1, 'Duluth, MN', 38, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(116, 0, 'region', 'enabled', 'Minneapolis - St. Paul', '', 1, 'Minneapolis / St. Paul, MN', 38, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(117, 0, 'region', 'enabled', 'St. Cloud', '', 1, 'St. Cloud, MN', 38, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(118, 0, 'region', 'enabled', 'Gulfport - Biloxi', '', 1, 'Gulfport / Biloxi, MS', 39, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(119, 0, 'region', 'enabled', 'Hattiesburg', '', 1, 'Hattiesburg, MS', 39, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(120, 0, 'region', 'enabled', 'Jackson', '', 1, 'Jackson, MS', 39, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(121, 0, 'region', 'enabled', 'Tupelo', '', 1, 'Tupelo, MS', 39, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(122, 0, 'region', 'enabled', 'Jefferson City - Columbia', '', 1, 'Jefferson City / Columbia, MO', 40, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(123, 0, 'region', 'enabled', 'Kansas City', '', 1, 'Kansas City, MO', 40, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(124, 0, 'region', 'enabled', 'Springfield', '', 1, 'Springfield, MO', 40, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(125, 0, 'region', 'enabled', 'St. Louis', '', 1, 'St. Louis, MO', 40, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(126, 0, 'region', 'enabled', 'Billings', '', 1, 'Billings, MT', 41, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(127, 0, 'region', 'enabled', 'Bozeman', '', 1, 'Bozeman, MT', 41, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(128, 0, 'region', 'enabled', 'Great Falls', '', 1, 'Great Falls, MT', 41, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(129, 0, 'region', 'enabled', 'Missoula', '', 1, 'Missoula, MT', 41, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(130, 0, 'region', 'enabled', 'Kearney', '', 1, 'Kearney, NE', 42, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(131, 0, 'region', 'enabled', 'Lincoln', '', 1, 'Lincoln, NE', 42, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(132, 0, 'region', 'enabled', 'North Platte', '', 1, 'North Platte, NE', 42, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(133, 0, 'region', 'enabled', 'Omaha', '', 1, 'Omaha, NE', 42, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(134, 0, 'region', 'enabled', 'Scottsbluff', '', 1, 'Scottsbluff, NE', 42, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(135, 0, 'region', 'enabled', 'Carson City', '', 1, 'Carson City, NV', 43, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(136, 0, 'region', 'enabled', 'Las Vegas', '', 1, 'Las Vegas, NV', 43, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(137, 0, 'region', 'enabled', 'Reno', '', 1, 'Reno, NV', 43, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(138, 0, 'region', 'enabled', 'Concord', '', 1, 'Concord, NH', 44, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(139, 0, 'region', 'enabled', 'Manchester', '', 1, 'Manchester, NH', 44, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(140, 0, 'region', 'enabled', 'Central Jersey', '', 1, 'Central Jersey, NJ', 45, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(141, 0, 'region', 'enabled', 'Hoboken - Jersey City', '', 1, 'Hoboken / Jersey City, NJ', 45, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(142, 0, 'region', 'enabled', 'Jersey Shore', '', 1, 'Jersey Shore, NJ', 45, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(143, 0, 'region', 'enabled', 'Newark', '', 1, 'Newark, NJ', 45, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(144, 0, 'region', 'enabled', 'North Jersey', '', 1, 'North Jersey, NJ', 45, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(145, 0, 'region', 'enabled', 'South Jersey', '', 1, 'South Jersey, NJ', 45, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(146, 0, 'region', 'enabled', 'Trenton - Princeton', '', 1, 'Trenton / Princeton, NJ', 45, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(147, 0, 'region', 'enabled', 'Albuquerque', '', 1, 'Albuquerque, NM', 46, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(148, 0, 'region', 'enabled', 'Farmington', '', 1, 'Farmington, NM', 46, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(149, 0, 'region', 'enabled', 'Las Cruces', '', 1, 'Las Cruces, NM', 46, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(150, 0, 'region', 'enabled', 'Santa Fe', '', 1, 'Santa Fe, NM', 46, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(151, 0, 'region', 'enabled', 'Albany', '', 1, 'Albany, NY', 47, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(152, 0, 'region', 'enabled', 'Binghamton', '', 1, 'Binghamton, NY', 47, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(153, 0, 'region', 'enabled', 'Buffalo', '', 1, 'Buffalo, NY', 47, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(154, 0, 'region', 'enabled', 'Ithaca', '', 1, 'Ithaca, NY', 47, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(155, 0, 'region', 'enabled', 'Nassau County', '', 1, 'Nassau County, NY', 47, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(156, 0, 'region', 'enabled', 'New York', '', 1, 'New York, NY', 47, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(157, 0, 'region', 'enabled', 'Poughkeepsie', '', 1, 'Poughkeepsie, NY', 47, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(158, 0, 'region', 'enabled', 'Rochester', '', 1, 'Rochester, NY', 47, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(159, 0, 'region', 'enabled', 'Suffolk County', '', 1, 'Suffolk County, NY', 47, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(160, 0, 'region', 'enabled', 'Syracuse', '', 1, 'Syracuse, NY', 47, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(161, 0, 'region', 'enabled', 'Utica', '', 1, 'Utica, NY', 47, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(162, 0, 'region', 'enabled', 'Westchester', '', 1, 'Westchester, NY', 47, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(163, 0, 'region', 'enabled', 'Asheville', '', 1, 'Asheville, NC', 48, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(164, 0, 'region', 'enabled', 'Charlotte', '', 1, 'Charlotte, NC', 48, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(165, 0, 'region', 'enabled', 'Fayetteville', '', 1, 'Fayetteville, NC', 48, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(166, 0, 'region', 'enabled', 'Greensboro', '', 1, 'Greensboro, NC', 48, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(167, 0, 'region', 'enabled', 'Greenville', '', 1, 'Greenville, NC', 48, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(168, 0, 'region', 'enabled', 'Raleigh - Durham', '', 1, 'Raleigh / Durham, NC', 48, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(169, 0, 'region', 'enabled', 'Wilmington', '', 1, 'Wilmington, NC', 48, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(170, 0, 'region', 'enabled', 'Winston-Salem', '', 1, 'Winston-Salem, NC', 48, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(171, 0, 'region', 'enabled', 'Bismarck', '', 1, 'Bismarck, ND', 49, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(172, 0, 'region', 'enabled', 'Fargo', '', 1, 'Fargo, ND', 49, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(173, 0, 'region', 'enabled', 'Grand Forks', '', 1, 'Grand Forks, ND', 49, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(174, 0, 'region', 'enabled', 'Akron', '', 1, 'Akron, OH', 50, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(175, 0, 'region', 'enabled', 'Cincinnati', '', 1, 'Cincinnati, OH', 50, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(176, 0, 'region', 'enabled', 'Cleveland', '', 1, 'Cleveland, OH', 50, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(177, 0, 'region', 'enabled', 'Columbus', '', 1, 'Columbus, OH', 50, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(178, 0, 'region', 'enabled', 'Dayton', '', 1, 'Dayton, OH', 50, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(179, 0, 'region', 'enabled', 'Lima', '', 1, 'Lima, OH', 50, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(180, 0, 'region', 'enabled', 'Mansfield', '', 1, 'Mansfield, OH', 50, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(181, 0, 'region', 'enabled', 'Toledo', '', 1, 'Toledo, OH', 50, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(182, 0, 'region', 'enabled', 'Youngstown', '', 1, 'Youngstown, OH', 50, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(183, 0, 'region', 'enabled', 'Lawton', '', 1, 'Lawton, OK', 51, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(184, 0, 'region', 'enabled', 'Oklahoma City', '', 1, 'Oklahoma City, OK', 51, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(185, 0, 'region', 'enabled', 'Tulsa', '', 1, 'Tulsa, OK', 51, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(186, 0, 'region', 'enabled', 'Bend', '', 1, 'Bend, OR', 52, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(187, 0, 'region', 'enabled', 'Corvallis', '', 1, 'Corvallis, OR', 52, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(188, 0, 'region', 'enabled', 'Eugene', '', 1, 'Eugene, OR', 52, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(189, 0, 'region', 'enabled', 'Medford', '', 1, 'Medford, OR', 52, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(190, 0, 'region', 'enabled', 'Portland', '', 1, 'Portland, OR', 52, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(191, 0, 'region', 'enabled', 'Salem', '', 1, 'Salem, OR', 52, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(192, 0, 'region', 'enabled', 'Allentown', '', 1, 'Allentown, PA', 53, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(193, 0, 'region', 'enabled', 'Erie', '', 1, 'Erie, PA', 53, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(194, 0, 'region', 'enabled', 'Harrisburg', '', 1, 'Harrisburg, PA', 53, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(195, 0, 'region', 'enabled', 'Lancaster', '', 1, 'Lancaster, PA', 53, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(196, 0, 'region', 'enabled', 'Philadelphia', '', 1, 'Philadelphia, PA', 53, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(197, 0, 'region', 'enabled', 'Pittsburgh', '', 1, 'Pittsburgh, PA', 53, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(198, 0, 'region', 'enabled', 'Reading', '', 1, 'Reading, PA', 53, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(199, 0, 'region', 'enabled', 'Scranton', '', 1, 'Scranton, PA', 53, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(200, 0, 'region', 'enabled', 'State College', '', 1, 'State College, PA', 53, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(201, 0, 'region', 'enabled', 'Williamsport', '', 1, 'Williamsport, PA', 53, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(202, 0, 'region', 'enabled', 'York', '', 1, 'York, PA', 53, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(203, 0, 'region', 'enabled', 'San Juan', '', 1, 'San Juan, PR', 54, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(204, 0, 'region', 'enabled', 'Newport', '', 1, 'Newport, RI', 55, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(205, 0, 'region', 'enabled', 'Providence', '', 1, 'Providence, RI', 55, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(206, 0, 'region', 'enabled', 'Charleston', '', 1, 'Charleston, SC', 56, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(207, 0, 'region', 'enabled', 'Columbia', '', 1, 'Columbia, SC', 56, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(208, 0, 'region', 'enabled', 'Florence', '', 1, 'Florence, SC', 56, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(209, 0, 'region', 'enabled', 'Greenville', '', 1, 'Greenville, SC', 56, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(210, 0, 'region', 'enabled', 'Myrtle Beach', '', 1, 'Myrtle Beach, SC', 56, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(211, 0, 'region', 'enabled', 'Pierre', '', 1, 'Pierre, SD', 57, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(212, 0, 'region', 'enabled', 'Rapid City', '', 1, 'Rapid City, SD', 57, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(213, 0, 'region', 'enabled', 'Sioux Falls', '', 1, 'Sioux Falls, SD', 57, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(214, 0, 'region', 'enabled', 'Chattanooga', '', 1, 'Chattanooga, TN', 58, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(215, 0, 'region', 'enabled', 'Kingsport', '', 1, 'Kingsport, TN', 58, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(216, 0, 'region', 'enabled', 'Knoxville', '', 1, 'Knoxville, TN', 58, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(217, 0, 'region', 'enabled', 'Memphis', '', 1, 'Memphis, TN', 58, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(218, 0, 'region', 'enabled', 'Nashville', '', 1, 'Nashville, TN', 58, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(219, 0, 'region', 'enabled', 'Abilene', '', 1, 'Abilene, TX', 59, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(220, 0, 'region', 'enabled', 'Amarillo', '', 1, 'Amarillo, TX', 59, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(221, 0, 'region', 'enabled', 'Austin', '', 1, 'Austin, TX', 59, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(222, 0, 'region', 'enabled', 'Beaumont', '', 1, 'Beaumont, TX', 59, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(223, 0, 'region', 'enabled', 'College Station', '', 1, 'College Station, TX', 59, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(224, 0, 'region', 'enabled', 'Corpus Christi', '', 1, 'Corpus Christi, TX', 59, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(225, 0, 'region', 'enabled', 'Dallas - Fort Worth', '', 1, 'Dallas / Fort Worth, TX', 59, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(226, 0, 'region', 'enabled', 'El Paso', '', 1, 'El Paso, TX', 59, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(227, 0, 'region', 'enabled', 'Houston', '', 1, 'Houston, TX', 59, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(228, 0, 'region', 'enabled', 'Laredo', '', 1, 'Laredo, TX', 59, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(229, 0, 'region', 'enabled', 'Longview - Tyler', '', 1, 'Longview / Tyler, TX', 59, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(230, 0, 'region', 'enabled', 'Lubbock', '', 1, 'Lubbock, TX', 59, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(231, 0, 'region', 'enabled', 'Midland - Odessa', '', 1, 'Midland / Odessa, TX', 59, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(232, 0, 'region', 'enabled', 'Rio Grande Valley', '', 1, 'Rio Grande Valley, TX', 59, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(233, 0, 'region', 'enabled', 'San Angelo', '', 1, 'San Angelo, TX', 59, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(234, 0, 'region', 'enabled', 'San Antonio', '', 1, 'San Antonio, TX', 59, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(235, 0, 'region', 'enabled', 'Victoria', '', 1, 'Victoria, TX', 59, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(236, 0, 'region', 'enabled', 'Waco', '', 1, 'Waco, TX', 59, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(237, 0, 'region', 'enabled', 'Wichita Falls', '', 1, 'Wichita Falls, TX', 59, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(238, 0, 'region', 'enabled', 'Logan', '', 1, 'Logan, UT', 60, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(239, 0, 'region', 'enabled', 'Ogden', '', 1, 'Ogden, UT', 60, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(240, 0, 'region', 'enabled', 'Provo', '', 1, 'Provo, UT', 60, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(241, 0, 'region', 'enabled', 'Salt Lake City', '', 1, 'Salt Lake City, UT', 60, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(242, 0, 'region', 'enabled', 'St. George', '', 1, 'St. George, UT', 60, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(243, 0, 'region', 'enabled', 'Burlington', '', 1, 'Burlington, VT', 61, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(244, 0, 'region', 'enabled', 'Charlottesville', '', 1, 'Charlottesville, VA', 62, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(245, 0, 'region', 'enabled', 'Lynchburg', '', 1, 'Lynchburg, VA', 62, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(246, 0, 'region', 'enabled', 'Richmond', '', 1, 'Richmond, VA', 62, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(247, 0, 'region', 'enabled', 'Roanoke', '', 1, 'Roanoke, VA', 62, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(248, 0, 'region', 'enabled', 'Virginia Beach - Norfolk', '', 1, 'Virginia Beach / Norfolk, VA', 62, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(249, 0, 'region', 'enabled', 'Bellevue', '', 1, 'Bellevue, WA', 63, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(250, 0, 'region', 'enabled', 'Bellingham', '', 1, 'Bellingham, WA', 63, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(251, 0, 'region', 'enabled', 'Olympia', '', 1, 'Olympia, WA', 63, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(252, 0, 'region', 'enabled', 'Seattle', '', 1, 'Seattle, WA', 63, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(253, 0, 'region', 'enabled', 'Spokane', '', 1, 'Spokane, WA', 63, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(254, 0, 'region', 'enabled', 'Tacoma', '', 1, 'Tacoma, WA', 63, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(255, 0, 'region', 'enabled', 'Tri-Cities', '', 1, 'Tri-Cities, WA', 63, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(256, 0, 'region', 'enabled', 'Wenatchee', '', 1, 'Wenatchee, WA', 63, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(257, 0, 'region', 'enabled', 'Yakima', '', 1, 'Yakima, WA', 63, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(258, 0, 'region', 'enabled', 'Charleston', '', 1, 'Charleston, WV', 64, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(259, 0, 'region', 'enabled', 'Huntington', '', 1, 'Huntington, WV', 64, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(260, 0, 'region', 'enabled', 'Morgantown', '', 1, 'Morgantown, WV', 64, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(261, 0, 'region', 'enabled', 'Parkersburg', '', 1, 'Parkersburg, WV', 64, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(262, 0, 'region', 'enabled', 'Wheeling', '', 1, 'Wheeling, WV', 64, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(263, 0, 'region', 'enabled', 'Appleton', '', 1, 'Appleton, WI', 65, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(264, 0, 'region', 'enabled', 'Eau Claire', '', 1, 'Eau Claire, WI', 65, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(265, 0, 'region', 'enabled', 'Green Bay', '', 1, 'Green Bay, WI', 65, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(266, 0, 'region', 'enabled', 'La Crosse', '', 1, 'La Crosse, WI', 65, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(267, 0, 'region', 'enabled', 'Madison', '', 1, 'Madison, WI', 65, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(268, 0, 'region', 'enabled', 'Milwaukee', '', 1, 'Milwaukee, WI', 65, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(269, 0, 'region', 'enabled', 'Oshkosh', '', 1, 'Oshkosh, WI', 65, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(270, 0, 'region', 'enabled', 'Sheboygan', '', 1, 'Sheboygan, WI', 65, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(271, 0, 'region', 'enabled', 'Wausau', '', 1, 'Wausau, WI', 65, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(272, 0, 'region', 'enabled', 'Casper', '', 1, 'Casper, WY', 66, '', 0, '', '2008-03-03 10:26:34');
INSERT INTO `networks` (`network_id`, `user_id`, `network_type`, `network_status`, `network_name`, `network_email`, `network_country`, `network_city`, `network_state`, `network_website`, `network_members`, `contact_email`, `datestamp`) VALUES(273, 0, 'region', 'enabled', 'Cheyenne', '', 1, 'Cheyenne, WY', 66, '', 0, '', '2008-03-03 10:26:34');

DROP TABLE IF EXISTS `network_users`;
CREATE TABLE `network_users` (
  `network_user_id` bigint(20) NOT NULL auto_increment,
  `network_id` bigint(20) NOT NULL default '0',
  `user_id` int(11) NOT NULL default '0',
  `user_email` varchar(255) NOT NULL default '',
  `user_status` enum('approved','pending','inactive') NOT NULL default 'pending',
  `date_joined` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `confirm_key` varchar(255) NOT NULL default '',
  `is_deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`network_user_id`)
);

--
-- Dumping data for table `network_users`
--

-- --------------------------------------------------------

--
-- Table structure for table `notes`
--

DROP TABLE IF EXISTS `notes`;
CREATE TABLE `notes` (
  `notes_id` int(11) unsigned NOT NULL auto_increment,
  `title` varchar(255) default NULL,
  `message` text,
  `user_id` int(11) NOT NULL,
  `is_approved` varchar(2) default 'Y',
  `is_deleted` int(4) default '0',
  `date_created` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `date_modified` timestamp NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`notes_id`)
);

--
-- Dumping data for table `notes`
--

-- --------------------------------------------------------

--
-- Table structure for table `notes_comments`
--

DROP TABLE IF EXISTS `notes_comments`;
CREATE TABLE `notes_comments` (
  `comment_id` int(11) unsigned NOT NULL auto_increment,
  `notes_id` int(11) unsigned default NULL,
  `user_id` int(11) default NULL,
  `message` text,
  `date_created` timestamp NOT NULL default CURRENT_TIMESTAMP,
  PRIMARY KEY  (`comment_id`)
);

--
-- Dumping data for table `notes_comments`
--

-- --------------------------------------------------------

--
-- Table structure for table `notes_photos`
--

DROP TABLE IF EXISTS `notes_photos`;
CREATE TABLE `notes_photos` (
  `photo_id` int(11) unsigned NOT NULL auto_increment,
  `notes_id` int(11) unsigned default NULL,
  `file_name` text,
  `file_align` varchar(10) default NULL,
  `date_created` timestamp NOT NULL default CURRENT_TIMESTAMP,
  PRIMARY KEY  (`photo_id`)
);

--
-- Dumping data for table `notes_photos`
--

-- --------------------------------------------------------

--
-- Table structure for table `notes_tags`
--

DROP TABLE IF EXISTS `notes_tags`;
CREATE TABLE `notes_tags` (
  `tag_id` int(11) unsigned NOT NULL auto_increment,
  `notes_id` int(11) unsigned NOT NULL,
  `user_id` int(11) NOT NULL,
  `date_created` timestamp NOT NULL default CURRENT_TIMESTAMP,
  PRIMARY KEY  (`tag_id`)
);

--
-- Dumping data for table `notes_tags`
--

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `notification_id` int(3) NOT NULL auto_increment,
  `notification_name` varchar(200) NOT NULL,
  PRIMARY KEY  (`notification_id`)
);

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`notification_id`, `notification_name`) VALUES(1, 'Sends me a message');
INSERT INTO `notifications` (`notification_id`, `notification_name`) VALUES(2, 'Adds me as a friend');
INSERT INTO `notifications` (`notification_id`, `notification_name`) VALUES(3, 'Invites me to join a group');
INSERT INTO `notifications` (`notification_id`, `notification_name`) VALUES(4, 'Invites me to an event');

-- --------------------------------------------------------

--
-- Table structure for table `pagination`
--

DROP TABLE IF EXISTS `pagination`;
CREATE TABLE `pagination` (
  `pagination_id` int(11) NOT NULL auto_increment,
  `page` varchar(255) NOT NULL,
  `page_desc` varchar(255) NOT NULL,
  `page_max` int(11) NOT NULL default '10',
  PRIMARY KEY  (`pagination_id`)
);

--
-- Dumping data for table `pagination`
--

INSERT INTO `pagination` (`pagination_id`, `page`, `page_desc`, `page_max`) VALUES(1, 'discussion_board', 'Discussion board', 5);
INSERT INTO `pagination` (`pagination_id`, `page`, `page_desc`, `page_max`) VALUES(2, 'wall', 'wall', 5);
INSERT INTO `pagination` (`pagination_id`, `page`, `page_desc`, `page_max`) VALUES(3, 'photos', 'photos', 5);
INSERT INTO `pagination` (`pagination_id`, `page`, `page_desc`, `page_max`) VALUES(4, 'message', 'message', 5);
INSERT INTO `pagination` (`pagination_id`, `page`, `page_desc`, `page_max`) VALUES(5, 'notes', 'notes', 5);
INSERT INTO `pagination` (`pagination_id`, `page`, `page_desc`, `page_max`) VALUES(6, 'posteditems', 'posteditems', 5);
INSERT INTO `pagination` (`pagination_id`, `page`, `page_desc`, `page_max`) VALUES(7, 'marketplace', 'marketplace', 5);
INSERT INTO `pagination` (`pagination_id`, `page`, `page_desc`, `page_max`) VALUES(8, 'events', 'events', 5);
INSERT INTO `pagination` (`pagination_id`, `page`, `page_desc`, `page_max`) VALUES(9, 'groups', 'groups', 5);
INSERT INTO `pagination` (`pagination_id`, `page`, `page_desc`, `page_max`) VALUES(10, 'minifeed', 'minifeed', 10);

-- --------------------------------------------------------

--
-- Table structure for table `photos`
--

DROP TABLE IF EXISTS `photos`;
CREATE TABLE `photos` (
  `photo_id` int(11) NOT NULL auto_increment,
  `album_id` int(11) NOT NULL default '0',
  `caption` text NOT NULL,
  `user_id` int(11) NOT NULL default '0',
  `photo_ext` varchar(6) NOT NULL,
  `photo_status` enum('active','deactive') NOT NULL default 'active',
  `datetime` timestamp NOT NULL default CURRENT_TIMESTAMP,
  PRIMARY KEY  (`photo_id`)
);

--
-- Dumping data for table `photos`
--

-- --------------------------------------------------------

--
-- Table structure for table `photo_album`
--

DROP TABLE IF EXISTS `photo_album`;
CREATE TABLE `photo_album` (
  `album_id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `location` varchar(255) NOT NULL default '',
  `description` text NOT NULL,
  `user_id` int(11) NOT NULL default '0',
  `album_cover` bigint(20) NOT NULL,
  `album_cover_ext` varchar(6) NOT NULL,
  `visibility_id` int(11) NOT NULL,
  `photo_order` text NOT NULL,
  `datestamp` timestamp NOT NULL default CURRENT_TIMESTAMP,
  PRIMARY KEY  (`album_id`)
);

--
-- Dumping data for table `photo_album`
--

-- --------------------------------------------------------

--
-- Table structure for table `photo_album_visibility`
--

DROP TABLE IF EXISTS `photo_album_visibility`;
CREATE TABLE `photo_album_visibility` (
  `visibility_id` int(11) NOT NULL auto_increment,
  `visible_to` varchar(255) NOT NULL,
  PRIMARY KEY  (`visibility_id`)
);

--
-- Dumping data for table `photo_album_visibility`
--

INSERT INTO `photo_album_visibility` (`visibility_id`, `visible_to`) VALUES(1, 'Everyone');
INSERT INTO `photo_album_visibility` (`visibility_id`, `visible_to`) VALUES(2, 'All my networks and all my friends');
INSERT INTO `photo_album_visibility` (`visibility_id`, `visible_to`) VALUES(3, 'Some of my networks and all my friends');
INSERT INTO `photo_album_visibility` (`visibility_id`, `visible_to`) VALUES(4, 'Only my friends');

-- --------------------------------------------------------

--
-- Table structure for table `photo_album_visibility_setting`
--

DROP TABLE IF EXISTS `photo_album_visibility_setting`;
CREATE TABLE `photo_album_visibility_setting` (
  `photo_album_visibility__setting_id` int(11) NOT NULL auto_increment,
  `album_id` int(11) NOT NULL,
  `network_id` int(11) NOT NULL,
  PRIMARY KEY  (`photo_album_visibility__setting_id`)
);

--
-- Dumping data for table `photo_album_visibility_setting`
--


-- --------------------------------------------------------

--
-- Table structure for table `political_views`
--

DROP TABLE IF EXISTS `political_views`;
CREATE TABLE `political_views` (
  `political_id` int(11) NOT NULL auto_increment,
  `political_view` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`political_id`)
);

--
-- Dumping data for table `political_views`
--

INSERT INTO `political_views` (`political_id`, `political_view`) VALUES(1, 'Very Liberal');
INSERT INTO `political_views` (`political_id`, `political_view`) VALUES(2, 'Liberal');
INSERT INTO `political_views` (`political_id`, `political_view`) VALUES(3, 'Moderate');
INSERT INTO `political_views` (`political_id`, `political_view`) VALUES(4, 'Conservative');
INSERT INTO `political_views` (`political_id`, `political_view`) VALUES(5, 'Very Conservative');
INSERT INTO `political_views` (`political_id`, `political_view`) VALUES(6, 'Apathetic');
INSERT INTO `political_views` (`political_id`, `political_view`) VALUES(7, 'Libertarian');
INSERT INTO `political_views` (`political_id`, `political_view`) VALUES(8, 'Other');

-- --------------------------------------------------------

--
-- Table structure for table `posted_items`
--

DROP TABLE IF EXISTS `posted_items`;
CREATE TABLE `posted_items` (
  `post_id` int(11) NOT NULL auto_increment,
  `posted_by` int(11) NOT NULL,
  `post_url` text NOT NULL,
  `post_description` text NOT NULL,
  `post_date` datetime NOT NULL,
  `post_type` enum('link','group','event','network','photo','marketplace_list','marketplace_want','note') default NULL,
  `post_status` enum('active','deactive') NOT NULL default 'active',
  `post_for_id` int(11) NOT NULL,
  PRIMARY KEY  (`post_id`)
);

--
-- Dumping data for table `posted_items`
--

-- --------------------------------------------------------

--
-- Table structure for table `posted_item_comments`
--

DROP TABLE IF EXISTS `posted_item_comments`;
CREATE TABLE `posted_item_comments` (
  `comment_id` int(11) NOT NULL auto_increment,
  `post_id` int(11) NOT NULL,
  `description` text NOT NULL,
  `comment_by` int(11) NOT NULL,
  `comment_on` datetime NOT NULL,
  PRIMARY KEY  (`comment_id`)
);

--
-- Dumping data for table `posted_item_comments`
--

-- --------------------------------------------------------

--
-- Table structure for table `privacy`
--

DROP TABLE IF EXISTS `privacy`;
CREATE TABLE `privacy` (
  `privacy_id` int(11) NOT NULL auto_increment,
  `privacy_name` varchar(255) NOT NULL,
  PRIMARY KEY  (`privacy_id`)
);

--
-- Dumping data for table `privacy`
--

INSERT INTO `privacy` (`privacy_id`, `privacy_name`) VALUES(1, 'All my networks and all my friends');
INSERT INTO `privacy` (`privacy_id`, `privacy_name`) VALUES(2, 'Some of my networks and all my friends');
INSERT INTO `privacy` (`privacy_id`, `privacy_name`) VALUES(3, 'Only my friends');
INSERT INTO `privacy` (`privacy_id`, `privacy_name`) VALUES(4, 'Only me');
INSERT INTO `privacy` (`privacy_id`, `privacy_name`) VALUES(5, 'No one');

-- --------------------------------------------------------

--
-- Table structure for table `privacy_setting`
--

DROP TABLE IF EXISTS `privacy_setting`;
CREATE TABLE `privacy_setting` (
  `privacy_setting_id` int(3) NOT NULL auto_increment,
  `privacy_name` varchar(200) NOT NULL,
  `network_related` tinyint(1) NOT NULL default '0',
  `privacy_desc` varchar(255) NOT NULL,
  PRIMARY KEY  (`privacy_setting_id`)
);

--
-- Dumping data for table `privacy_setting`
--

INSERT INTO `privacy_setting` (`privacy_setting_id`, `privacy_name`, `network_related`, `privacy_desc`) VALUES(1, 'profile_privacy', 0, 'Profile');
INSERT INTO `privacy_setting` (`privacy_setting_id`, `privacy_name`, `network_related`, `privacy_desc`) VALUES(2, 'onlinestatus_privacy', 1, 'Online Status');
INSERT INTO `privacy_setting` (`privacy_setting_id`, `privacy_name`, `network_related`, `privacy_desc`) VALUES(3, 'friends_privacy', 0, 'Friends');
INSERT INTO `privacy_setting` (`privacy_setting_id`, `privacy_name`, `network_related`, `privacy_desc`) VALUES(4, 'wall_privacy', 1, 'Wall');
INSERT INTO `privacy_setting` (`privacy_setting_id`, `privacy_name`, `network_related`, `privacy_desc`) VALUES(5, 'mobile_privacy', 0, 'Mobile Phone');
INSERT INTO `privacy_setting` (`privacy_setting_id`, `privacy_name`, `network_related`, `privacy_desc`) VALUES(6, 'phone_privacy', 0, 'Land Phone');
INSERT INTO `privacy_setting` (`privacy_setting_id`, `privacy_name`, `network_related`, `privacy_desc`) VALUES(7, 'address_privacy', 0, 'Current Address');
INSERT INTO `privacy_setting` (`privacy_setting_id`, `privacy_name`, `network_related`, `privacy_desc`) VALUES(8, 'website_privacy', 0, 'Website');
INSERT INTO `privacy_setting` (`privacy_setting_id`, `privacy_name`, `network_related`, `privacy_desc`) VALUES(9, 'email_privacy', 1, 'Select who can see your contact emails');
INSERT INTO `privacy_setting` (`privacy_setting_id`, `privacy_name`, `network_related`, `privacy_desc`) VALUES(10, 'aim_privacy', 0, 'IM Screen Name');

-- --------------------------------------------------------

--
-- Table structure for table `privacy_setting_network`
--

DROP TABLE IF EXISTS `privacy_setting_network`;
CREATE TABLE `privacy_setting_network` (
  `privacy_setting_network_id` bigint(20) NOT NULL auto_increment,
  `user_id` bigint(20) NOT NULL,
  `network_id` bigint(20) NOT NULL,
  `privacy_setting_id` int(11) NOT NULL,
  PRIMARY KEY  (`privacy_setting_network_id`)
);

--
-- Dumping data for table `privacy_setting_network`
--


-- --------------------------------------------------------

--
-- Table structure for table `privacy_setting_status`
--

DROP TABLE IF EXISTS `privacy_setting_status`;
CREATE TABLE `privacy_setting_status` (
  `privacy_setting_status_id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `privacy_setting_id` int(11) NOT NULL,
  `privacy_setting_value` int(11) NOT NULL,
  PRIMARY KEY  (`privacy_setting_status_id`)
);

--
-- Dumping data for table `privacy_setting_status`
--

-- --------------------------------------------------------

--
-- Table structure for table `products_list`
--

DROP TABLE IF EXISTS `products_list`;
CREATE TABLE `products_list` (
  `list_id` int(11) unsigned NOT NULL auto_increment,
  `cat_id` int(11) default NULL,
  `sub_cat_id` int(11) default NULL,
  `tag_id` varchar(255) default NULL,
  `item_title` text,
  `item_description` text,
  `item_type` varchar(255) default NULL,
  `item_cost` float default NULL,
  `cost_code` varchar(255) default NULL,
  `ISBN_Code` varchar(255) default NULL,
  `profile_list_flag` varchar(2) default 'N',
  `list_nt_ids` varchar(255) default NULL,
  `list_nt_group_id` int(11) default NULL,
  `privacy_list_flag` varchar(2) default 'N',
  `list_photos_ids` varchar(255) default NULL,
  `list_photos_group_id` int(11) default NULL,
  `bed_rooms` smallint(6) default NULL,
  `bath_rooms` smallint(6) default NULL,
  `street` text,
  `cross_street` text,
  `postal_code` varchar(255) default NULL,
  `square_feet` float default NULL,
  `allowed_flag_ids` varchar(255) default NULL,
  `allowed_flag_group_id` int(11) default NULL,
  `hours_choice` varchar(255) default NULL,
  `other_stuff_ids` varchar(255) default NULL,
  `compensation_type` varchar(255) default NULL,
  `user_id` int(11) default NULL,
  `is_approved` varchar(2) default 'Y',
  `is_deleted` tinyint(4) default '0',
  `date_created` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `date_modified` timestamp NOT NULL default '0000-00-00 00:00:00',
  `list_status` varchar(5) default NULL,
  `views` int(11) unsigned default NULL,
  PRIMARY KEY  (`list_id`)
);

--
-- Dumping data for table `products_list`
--

-- --------------------------------------------------------

--
-- Table structure for table `products_wanted`
--

DROP TABLE IF EXISTS `products_wanted`;
CREATE TABLE `products_wanted` (
  `wanted_id` int(11) unsigned NOT NULL auto_increment,
  `cat_id` int(11) default NULL,
  `sub_cat_id` int(11) default NULL,
  `tag_id` varchar(255) default NULL,
  `item_title` text,
  `item_description` text,
  `item_type` varchar(255) default NULL,
  `item_cost` float default NULL,
  `cost_code` varchar(255) default NULL,
  `ISBN_Code` varchar(255) default NULL,
  `profile_want_flag` varchar(2) default 'N',
  `want_nt_ids` varchar(255) default NULL,
  `want_nt_group_id` int(11) default NULL,
  `privacy_want_flag` varchar(2) default 'N',
  `want_photos_ids` varchar(255) default NULL,
  `want_photos_group_id` int(11) default NULL,
  `bed_rooms` smallint(6) default NULL,
  `bath_rooms` smallint(6) default NULL,
  `street` text,
  `cross_street` text,
  `postal_code` varchar(255) default NULL,
  `square_feet` float default NULL,
  `allowed_flag_ids` varchar(255) default NULL,
  `allowed_flag_group_id` int(11) default NULL,
  `hours_choice` varchar(255) default NULL,
  `other_stuff_ids` varchar(255) default NULL,
  `compensation_type` varchar(255) default NULL,
  `user_id` int(11) default NULL,
  `is_approved` varchar(2) default 'Y',
  `is_deleted` tinyint(4) default '0',
  `date_created` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `date_modified` timestamp NOT NULL default '0000-00-00 00:00:00',
  `list_status` varchar(5) default NULL,
  `views` int(11) unsigned default NULL,
  PRIMARY KEY  (`wanted_id`)
);

--
-- Dumping data for table `products_wanted`
--

-- --------------------------------------------------------

--
-- Table structure for table `prod_category`
--

DROP TABLE IF EXISTS `prod_category`;
CREATE TABLE `prod_category` (
  `cat_id` int(11) NOT NULL auto_increment,
  `cat_code` varchar(50) NOT NULL,
  `cat_name` varchar(255) NOT NULL,
  `cat_alias_name` varchar(255) NOT NULL,
  `cat_desc` text,
  `cat_logo` text,
  `is_approved` varchar(10) default 'Y',
  `is_deleted` smallint(6) default '0',
  `user_created` varchar(255) default 'admin',
  `date_created` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `user_modified` varchar(255) default NULL,
  `date_modified` timestamp NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`cat_id`)
);

--
-- Dumping data for table `prod_category`
--

INSERT INTO `prod_category` (`cat_id`, `cat_code`, `cat_name`, `cat_alias_name`, `cat_desc`, `cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(1, 'SALE', 'For Sale', 'Item Wanted', ' books, furniture, electronics, tickets, etc.', 'forsale_icon.gif', 'Y', 0, 'admin', '2007-10-18 08:31:53', NULL, '0000-00-00 00:00:00');
INSERT INTO `prod_category` (`cat_id`, `cat_code`, `cat_name`, `cat_alias_name`, `cat_desc`, `cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(2, 'HOUSE', 'Housing', 'Housing Wanted', 'apartments for rent, sublets to offer, etc.', 'housing_icon.gif', 'Y', 0, 'admin', '2007-10-18 08:32:30', NULL, '0000-00-00 00:00:00');
INSERT INTO `prod_category` (`cat_id`, `cat_code`, `cat_name`, `cat_alias_name`, `cat_desc`, `cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(3, 'JOB', 'Jobs', 'Looking for Work', 'career opportunities, part-time work, internships, etc.', 'jobs_icon.gif', 'Y', 0, 'admin', '2007-10-18 08:33:01', NULL, '0000-00-00 00:00:00');
INSERT INTO `prod_category` (`cat_id`, `cat_code`, `cat_name`, `cat_alias_name`, `cat_desc`, `cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(4, 'OTHER', 'Other', 'Other Wanted', 'everything else, lost items found, ridesharing, etc.', 'general_icon.gif', 'Y', 0, 'admin', '2007-10-18 08:33:25', NULL, '0000-00-00 00:00:00');
INSERT INTO `prod_category` (`cat_id`, `cat_code`, `cat_name`, `cat_alias_name`, `cat_desc`, `cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(5, 'FREE', 'Free Stuff', 'Free Items', 'things you''d like to give away.', 'free_icon.gif', 'Y', 0, 'admin', '2007-10-18 08:33:48', NULL, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `prod_sub_category`
--

DROP TABLE IF EXISTS `prod_sub_category`;
CREATE TABLE `prod_sub_category` (
  `sub_cat_id` int(11) NOT NULL auto_increment,
  `cat_id` int(11) NOT NULL,
  `sub_cat_code` varchar(50) NOT NULL,
  `sub_cat_name` varchar(255) NOT NULL,
  `sub_cat_desc` text,
  `sub_cat_logo` text,
  `is_approved` varchar(10) default 'Y',
  `is_deleted` smallint(6) default '0',
  `user_created` varchar(255) default 'admin',
  `date_created` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `user_modified` varchar(255) default NULL,
  `date_modified` timestamp NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`sub_cat_id`)
);

--
-- Dumping data for table `prod_sub_category`
--

INSERT INTO `prod_sub_category` (`sub_cat_id`, `cat_id`, `sub_cat_code`, `sub_cat_name`, `sub_cat_desc`, `sub_cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(1, 1, 'BOOK', 'Books', NULL, NULL, 'Y', 0, 'admin', '2007-10-18 08:37:04', NULL, '0000-00-00 00:00:00');
INSERT INTO `prod_sub_category` (`sub_cat_id`, `cat_id`, `sub_cat_code`, `sub_cat_name`, `sub_cat_desc`, `sub_cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(2, 1, 'FURNITURE', 'Furniture', NULL, NULL, 'Y', 0, 'admin', '2007-10-18 08:37:21', NULL, '0000-00-00 00:00:00');
INSERT INTO `prod_sub_category` (`sub_cat_id`, `cat_id`, `sub_cat_code`, `sub_cat_name`, `sub_cat_desc`, `sub_cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(3, 1, 'TICKET', 'Tickets', NULL, NULL, 'Y', 0, 'admin', '2007-10-18 08:37:39', NULL, '0000-00-00 00:00:00');
INSERT INTO `prod_sub_category` (`sub_cat_id`, `cat_id`, `sub_cat_code`, `sub_cat_name`, `sub_cat_desc`, `sub_cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(4, 1, 'ELECTRONIC', 'Electronics', NULL, NULL, 'Y', 0, 'admin', '2007-10-18 08:37:54', NULL, '0000-00-00 00:00:00');
INSERT INTO `prod_sub_category` (`sub_cat_id`, `cat_id`, `sub_cat_code`, `sub_cat_name`, `sub_cat_desc`, `sub_cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(5, 1, 'CAR', 'Cars', NULL, NULL, 'Y', 0, 'admin', '2007-10-18 08:38:03', NULL, '0000-00-00 00:00:00');
INSERT INTO `prod_sub_category` (`sub_cat_id`, `cat_id`, `sub_cat_code`, `sub_cat_name`, `sub_cat_desc`, `sub_cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(6, 1, 'OTHERSALE', 'Other', NULL, NULL, 'Y', 0, 'admin', '2007-10-18 08:38:18', NULL, '0000-00-00 00:00:00');
INSERT INTO `prod_sub_category` (`sub_cat_id`, `cat_id`, `sub_cat_code`, `sub_cat_name`, `sub_cat_desc`, `sub_cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(7, 2, 'RENTAL', 'Rentals/Apartment', NULL, NULL, 'Y', 0, 'admin', '2007-10-18 08:40:48', NULL, '0000-00-00 00:00:00');
INSERT INTO `prod_sub_category` (`sub_cat_id`, `cat_id`, `sub_cat_code`, `sub_cat_name`, `sub_cat_desc`, `sub_cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(8, 2, 'SUBLET', 'Sublets', NULL, NULL, 'Y', 0, 'admin', '2007-10-18 08:40:57', NULL, '0000-00-00 00:00:00');
INSERT INTO `prod_sub_category` (`sub_cat_id`, `cat_id`, `sub_cat_code`, `sub_cat_name`, `sub_cat_desc`, `sub_cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(9, 2, 'REALESTATE', 'Real Estate', NULL, NULL, 'Y', 0, 'admin', '2007-10-18 08:41:18', NULL, '0000-00-00 00:00:00');
INSERT INTO `prod_sub_category` (`sub_cat_id`, `cat_id`, `sub_cat_code`, `sub_cat_name`, `sub_cat_desc`, `sub_cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(10, 2, 'OTHERHOUSING', 'Other', NULL, NULL, 'Y', 0, 'admin', '2007-10-18 08:41:30', NULL, '0000-00-00 00:00:00');
INSERT INTO `prod_sub_category` (`sub_cat_id`, `cat_id`, `sub_cat_code`, `sub_cat_name`, `sub_cat_desc`, `sub_cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(11, 3, 'ACCFIN', 'Accounting/Finance', NULL, NULL, 'Y', 0, 'admin', '2007-10-18 08:45:43', NULL, '0000-00-00 00:00:00');
INSERT INTO `prod_sub_category` (`sub_cat_id`, `cat_id`, `sub_cat_code`, `sub_cat_name`, `sub_cat_desc`, `sub_cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(12, 3, 'ADMINCLERK', 'Administrative/Clerical', NULL, NULL, 'Y', 0, 'admin', '2007-10-18 08:46:27', NULL, '0000-00-00 00:00:00');
INSERT INTO `prod_sub_category` (`sub_cat_id`, `cat_id`, `sub_cat_code`, `sub_cat_name`, `sub_cat_desc`, `sub_cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(13, 3, 'ARCHMECH', 'Architecture/Mechanical Engineering', NULL, NULL, 'Y', 0, 'admin', '2007-10-18 08:47:34', NULL, '0000-00-00 00:00:00');
INSERT INTO `prod_sub_category` (`sub_cat_id`, `cat_id`, `sub_cat_code`, `sub_cat_name`, `sub_cat_desc`, `sub_cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(14, 3, 'ADVPR', 'Advertising/PR', NULL, NULL, 'Y', 0, 'admin', '2007-10-18 08:48:07', NULL, '0000-00-00 00:00:00');
INSERT INTO `prod_sub_category` (`sub_cat_id`, `cat_id`, `sub_cat_code`, `sub_cat_name`, `sub_cat_desc`, `sub_cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(15, 3, 'ARTDESIGN', 'Art/Media/Design', NULL, NULL, 'Y', 0, 'admin', '2007-10-18 08:48:37', NULL, '0000-00-00 00:00:00');
INSERT INTO `prod_sub_category` (`sub_cat_id`, `cat_id`, `sub_cat_code`, `sub_cat_name`, `sub_cat_desc`, `sub_cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(16, 3, 'BIOSCIENCE', 'Biotechnology/Science', NULL, NULL, 'Y', 0, 'admin', '2007-10-18 08:49:21', NULL, '0000-00-00 00:00:00');
INSERT INTO `prod_sub_category` (`sub_cat_id`, `cat_id`, `sub_cat_code`, `sub_cat_name`, `sub_cat_desc`, `sub_cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(17, 3, 'BUSINESSMGMT', 'Business/Management', NULL, NULL, 'Y', 0, 'admin', '2007-10-18 08:50:06', NULL, '0000-00-00 00:00:00');
INSERT INTO `prod_sub_category` (`sub_cat_id`, `cat_id`, `sub_cat_code`, `sub_cat_name`, `sub_cat_desc`, `sub_cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(18, 3, 'CONSULTING', 'Consulting', NULL, NULL, 'Y', 0, 'admin', '2007-10-18 08:50:24', NULL, '0000-00-00 00:00:00');
INSERT INTO `prod_sub_category` (`sub_cat_id`, `cat_id`, `sub_cat_code`, `sub_cat_name`, `sub_cat_desc`, `sub_cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(19, 3, 'SUPPORT', 'Customer Support', NULL, NULL, 'Y', 0, 'admin', '2007-10-18 09:35:22', NULL, '0000-00-00 00:00:00');
INSERT INTO `prod_sub_category` (`sub_cat_id`, `cat_id`, `sub_cat_code`, `sub_cat_name`, `sub_cat_desc`, `sub_cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(20, 3, 'EDUCATION', 'Education', NULL, NULL, 'Y', 0, 'admin', '2007-10-18 09:35:37', NULL, '0000-00-00 00:00:00');
INSERT INTO `prod_sub_category` (`sub_cat_id`, `cat_id`, `sub_cat_code`, `sub_cat_name`, `sub_cat_desc`, `sub_cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(21, 3, 'ELECTRICAL', 'Electrical Engineering', NULL, NULL, 'Y', 0, 'admin', '2007-10-18 09:36:04', NULL, '0000-00-00 00:00:00');
INSERT INTO `prod_sub_category` (`sub_cat_id`, `cat_id`, `sub_cat_code`, `sub_cat_name`, `sub_cat_desc`, `sub_cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(22, 3, 'LABOR', 'General Labor', NULL, NULL, 'Y', 0, 'admin', '2007-10-18 09:36:25', NULL, '0000-00-00 00:00:00');
INSERT INTO `prod_sub_category` (`sub_cat_id`, `cat_id`, `sub_cat_code`, `sub_cat_name`, `sub_cat_desc`, `sub_cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(23, 3, 'GOVTMILITARY', 'Government Military', NULL, NULL, 'Y', 0, 'admin', '2007-10-18 09:37:06', NULL, '0000-00-00 00:00:00');
INSERT INTO `prod_sub_category` (`sub_cat_id`, `cat_id`, `sub_cat_code`, `sub_cat_name`, `sub_cat_desc`, `sub_cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(24, 3, 'HR', 'Human Resources', NULL, NULL, 'Y', 0, 'admin', '2007-10-18 09:37:22', NULL, '0000-00-00 00:00:00');
INSERT INTO `prod_sub_category` (`sub_cat_id`, `cat_id`, `sub_cat_code`, `sub_cat_name`, `sub_cat_desc`, `sub_cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(25, 3, 'BANKEQUITY', 'Investment Banking/Private Equity', NULL, NULL, 'Y', 0, 'admin', '2007-10-18 09:38:04', NULL, '0000-00-00 00:00:00');
INSERT INTO `prod_sub_category` (`sub_cat_id`, `cat_id`, `sub_cat_code`, `sub_cat_name`, `sub_cat_desc`, `sub_cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(26, 3, 'LEGAL', 'Legal/Paralegal', NULL, NULL, 'Y', 0, 'admin', '2007-10-18 09:38:24', NULL, '0000-00-00 00:00:00');
INSERT INTO `prod_sub_category` (`sub_cat_id`, `cat_id`, `sub_cat_code`, `sub_cat_name`, `sub_cat_desc`, `sub_cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(27, 3, 'MANUFACTURE', 'Manufacturing/Operations', NULL, NULL, 'Y', 0, 'admin', '2007-10-18 09:38:53', NULL, '0000-00-00 00:00:00');
INSERT INTO `prod_sub_category` (`sub_cat_id`, `cat_id`, `sub_cat_code`, `sub_cat_name`, `sub_cat_desc`, `sub_cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(28, 3, 'MARKETING', 'Marketing', NULL, NULL, 'Y', 0, 'admin', '2007-10-18 09:39:07', NULL, '0000-00-00 00:00:00');
INSERT INTO `prod_sub_category` (`sub_cat_id`, `cat_id`, `sub_cat_code`, `sub_cat_name`, `sub_cat_desc`, `sub_cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(29, 3, 'MEDICAL', 'Medical/Healthcare', NULL, NULL, 'Y', 0, 'admin', '2007-10-18 09:39:31', NULL, '0000-00-00 00:00:00');
INSERT INTO `prod_sub_category` (`sub_cat_id`, `cat_id`, `sub_cat_code`, `sub_cat_name`, `sub_cat_desc`, `sub_cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(30, 3, 'REALESTATES', 'Real Estate', NULL, NULL, 'Y', 0, 'admin', '2007-10-18 09:40:15', NULL, '0000-00-00 00:00:00');
INSERT INTO `prod_sub_category` (`sub_cat_id`, `cat_id`, `sub_cat_code`, `sub_cat_name`, `sub_cat_desc`, `sub_cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(31, 3, 'RESEARCH', 'Research', NULL, NULL, 'Y', 0, 'admin', '2007-10-18 09:40:29', NULL, '0000-00-00 00:00:00');
INSERT INTO `prod_sub_category` (`sub_cat_id`, `cat_id`, `sub_cat_code`, `sub_cat_name`, `sub_cat_desc`, `sub_cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(32, 3, 'RESTAURANT', 'Restaurant/Retail', NULL, NULL, 'Y', 0, 'admin', '2007-10-18 09:41:05', NULL, '0000-00-00 00:00:00');
INSERT INTO `prod_sub_category` (`sub_cat_id`, `cat_id`, `sub_cat_code`, `sub_cat_name`, `sub_cat_desc`, `sub_cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(33, 3, 'SALESDEVELOP', 'Sales/Business Development', NULL, NULL, 'Y', 0, 'admin', '2007-10-18 09:41:41', NULL, '0000-00-00 00:00:00');
INSERT INTO `prod_sub_category` (`sub_cat_id`, `cat_id`, `sub_cat_code`, `sub_cat_name`, `sub_cat_desc`, `sub_cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(34, 3, 'SECURITY', 'Security', NULL, NULL, 'Y', 0, 'admin', '2007-10-18 09:42:05', NULL, '0000-00-00 00:00:00');
INSERT INTO `prod_sub_category` (`sub_cat_id`, `cat_id`, `sub_cat_code`, `sub_cat_name`, `sub_cat_desc`, `sub_cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(35, 3, 'CRAFT', 'Skilled Trade/Craft', NULL, NULL, 'Y', 0, 'admin', '2007-10-18 09:42:44', NULL, '0000-00-00 00:00:00');
INSERT INTO `prod_sub_category` (`sub_cat_id`, `cat_id`, `sub_cat_code`, `sub_cat_name`, `sub_cat_desc`, `sub_cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(36, 3, 'SWQADBA', 'Software/QA/DBA', NULL, NULL, 'Y', 0, 'admin', '2007-10-18 09:43:11', NULL, '0000-00-00 00:00:00');
INSERT INTO `prod_sub_category` (`sub_cat_id`, `cat_id`, `sub_cat_code`, `sub_cat_name`, `sub_cat_desc`, `sub_cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(37, 3, 'SYSTEMSNTIT', 'Systems/Network/IT', NULL, NULL, 'Y', 0, 'admin', '2007-10-18 09:43:55', NULL, '0000-00-00 00:00:00');
INSERT INTO `prod_sub_category` (`sub_cat_id`, `cat_id`, `sub_cat_code`, `sub_cat_name`, `sub_cat_desc`, `sub_cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(38, 3, 'TVFILM', 'Television/Film', NULL, NULL, 'Y', 0, 'admin', '2007-10-18 09:44:15', NULL, '0000-00-00 00:00:00');
INSERT INTO `prod_sub_category` (`sub_cat_id`, `cat_id`, `sub_cat_code`, `sub_cat_name`, `sub_cat_desc`, `sub_cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(39, 3, 'TRANSPORT', 'Transportation', NULL, NULL, 'Y', 0, 'admin', '2007-10-18 09:44:43', NULL, '0000-00-00 00:00:00');
INSERT INTO `prod_sub_category` (`sub_cat_id`, `cat_id`, `sub_cat_code`, `sub_cat_name`, `sub_cat_desc`, `sub_cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(40, 3, 'WEBDESIGN', 'Web Development/Design', NULL, NULL, 'Y', 0, 'admin', '2007-10-18 09:45:08', NULL, '0000-00-00 00:00:00');
INSERT INTO `prod_sub_category` (`sub_cat_id`, `cat_id`, `sub_cat_code`, `sub_cat_name`, `sub_cat_desc`, `sub_cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(41, 3, 'WRITING', 'Writing/Editing', NULL, NULL, 'Y', 0, 'admin', '2007-10-18 09:45:31', NULL, '0000-00-00 00:00:00');
INSERT INTO `prod_sub_category` (`sub_cat_id`, `cat_id`, `sub_cat_code`, `sub_cat_name`, `sub_cat_desc`, `sub_cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(42, 3, 'OTHER', 'Other', NULL, NULL, 'Y', 0, 'admin', '2007-10-18 09:45:43', NULL, '0000-00-00 00:00:00');
INSERT INTO `prod_sub_category` (`sub_cat_id`, `cat_id`, `sub_cat_code`, `sub_cat_name`, `sub_cat_desc`, `sub_cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(43, 4, 'FOUNDITEM', 'Found Items', NULL, NULL, 'Y', 0, 'admin', '2007-10-18 09:47:46', NULL, '0000-00-00 00:00:00');
INSERT INTO `prod_sub_category` (`sub_cat_id`, `cat_id`, `sub_cat_code`, `sub_cat_name`, `sub_cat_desc`, `sub_cat_logo`, `is_approved`, `is_deleted`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES(44, 4, 'EVERYTHING', 'Everything Else', NULL, NULL, 'Y', 0, 'admin', '2007-10-18 09:48:10', NULL, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `profile_basic`
--

DROP TABLE IF EXISTS `profile_basic`;
CREATE TABLE `profile_basic` (
  `basic_profile_id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL default '0',
  `sex` enum('male','female') NOT NULL,
  `interested_in` enum('male','female','both') NOT NULL,
  `relation_id` int(11) NOT NULL default '0',
  `birthday_visibility_id` int(11) NOT NULL default '1',
  `hometown` varchar(255) NOT NULL default '',
  `state` varchar(255) NOT NULL default '',
  `country` varchar(255) NOT NULL,
  `political_id` int(11) NOT NULL default '0',
  `religious_view` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`basic_profile_id`)
);

--
-- Dumping data for table `profile_basic`
--

-- --------------------------------------------------------

--
-- Table structure for table `profile_contact`
--

DROP TABLE IF EXISTS `profile_contact`;
CREATE TABLE `profile_contact` (
  `contact_id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `mobile_privacy` int(11) NOT NULL,
  `land_line` varchar(255) NOT NULL,
  `land_line_privacy` int(11) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(255) NOT NULL,
  `state_province` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `zip_code` varchar(255) NOT NULL,
  `zip_code_privacy` int(11) NOT NULL,
  `website` text NOT NULL,
  `website_privacy` int(11) NOT NULL,
  `email_privacy` int(11) NOT NULL,
  `screen_privacy` int(11) NOT NULL,
  `datestamp` datetime NOT NULL,
  PRIMARY KEY  (`contact_id`)
);

--
-- Dumping data for table `profile_contact`
--

-- --------------------------------------------------------

--
-- Table structure for table `profile_education`
--

DROP TABLE IF EXISTS `profile_education`;
CREATE TABLE `profile_education` (
  `education_id` int(11) NOT NULL auto_increment,
  `user_id` bigint(11) NOT NULL,
  `high_school` varchar(255) NOT NULL,
  `datestamp` datetime NOT NULL,
  PRIMARY KEY  (`education_id`)
);

--
-- Dumping data for table `profile_education`
--

-- --------------------------------------------------------

--
-- Table structure for table `profile_personal`
--

DROP TABLE IF EXISTS `profile_personal`;
CREATE TABLE `profile_personal` (
  `personal_id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL default '0',
  `activities` text NOT NULL,
  `interests` text NOT NULL,
  `favorite_music` text NOT NULL,
  `favorite_tv_shows` text NOT NULL,
  `favorite_movies` text NOT NULL,
  `favorite_books` text NOT NULL,
  `favorite_quotes` text NOT NULL,
  `about_me` text NOT NULL,
  `datestamp` text NOT NULL,
  PRIMARY KEY  (`personal_id`)
);

--
-- Dumping data for table `profile_personal`
--

-- --------------------------------------------------------

--
-- Table structure for table `profile_work`
--

DROP TABLE IF EXISTS `profile_work`;
CREATE TABLE `profile_work` (
  `work_id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `employer` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `city` varchar(255) NOT NULL,
  `state_province` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `current_job` enum('yes','no') NOT NULL default 'yes',
  `start_month` varchar(3) NOT NULL,
  `start_year` varchar(5) NOT NULL,
  `end_month` varchar(3) NOT NULL,
  `end_year` varchar(5) NOT NULL,
  `datestamp` datetime NOT NULL,
  `job_type` varchar(255) NOT NULL,
  PRIMARY KEY  (`work_id`)
);

--
-- Dumping data for table `profile_work`
--

-- --------------------------------------------------------

--
-- Table structure for table `relation_status`
--

DROP TABLE IF EXISTS `relation_status`;
CREATE TABLE `relation_status` (
  `relation_id` int(11) NOT NULL auto_increment,
  `relation` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`relation_id`)
);

--
-- Dumping data for table `relation_status`
--

INSERT INTO `relation_status` (`relation_id`, `relation`) VALUES(1, 'Single');
INSERT INTO `relation_status` (`relation_id`, `relation`) VALUES(2, 'In a Relationship');
INSERT INTO `relation_status` (`relation_id`, `relation`) VALUES(3, 'In an Open Relationship');
INSERT INTO `relation_status` (`relation_id`, `relation`) VALUES(4, 'Engaged');
INSERT INTO `relation_status` (`relation_id`, `relation`) VALUES(5, 'Married');
INSERT INTO `relation_status` (`relation_id`, `relation`) VALUES(6, 'It''s Complicated');

-- --------------------------------------------------------

--
-- Table structure for table `religious_views`
--

DROP TABLE IF EXISTS `religious_views`;
CREATE TABLE `religious_views` (
  `religion_id` int(11) NOT NULL auto_increment,
  `religion` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`religion_id`)
);

--
-- Dumping data for table `religious_views`
--

INSERT INTO `religious_views` (`religion_id`, `religion`) VALUES(1, 'Christian');
INSERT INTO `religious_views` (`religion_id`, `religion`) VALUES(2, 'Christian - Protestant');
INSERT INTO `religious_views` (`religion_id`, `religion`) VALUES(3, 'Christian - Catholic');
INSERT INTO `religious_views` (`religion_id`, `religion`) VALUES(4, 'Christian - Amish');
INSERT INTO `religious_views` (`religion_id`, `religion`) VALUES(5, 'Christian - Assemblies of God');
INSERT INTO `religious_views` (`religion_id`, `religion`) VALUES(6, 'Christian - Baptist');
INSERT INTO `religious_views` (`religion_id`, `religion`) VALUES(7, 'Christian - Latter-day Saints');
INSERT INTO `religious_views` (`religion_id`, `religion`) VALUES(8, 'Christian - Church of Christ');
INSERT INTO `religious_views` (`religion_id`, `religion`) VALUES(9, 'Christian - Lutheran');
INSERT INTO `religious_views` (`religion_id`, `religion`) VALUES(10, 'Christian - Jehovah''s Witness');
INSERT INTO `religious_views` (`religion_id`, `religion`) VALUES(11, 'Christian - Mennonite');
INSERT INTO `religious_views` (`religion_id`, `religion`) VALUES(12, 'Christian - Methodist');
INSERT INTO `religious_views` (`religion_id`, `religion`) VALUES(13, 'Christian - Pentecostal');
INSERT INTO `religious_views` (`religion_id`, `religion`) VALUES(14, 'Christian - Presbyterian');
INSERT INTO `religious_views` (`religion_id`, `religion`) VALUES(15, 'Christian - Seventh-Day Adventist');
INSERT INTO `religious_views` (`religion_id`, `religion`) VALUES(16, 'Christian - Episcopalian');
INSERT INTO `religious_views` (`religion_id`, `religion`) VALUES(17, 'Christian - Greek Orthodox');
INSERT INTO `religious_views` (`religion_id`, `religion`) VALUES(18, 'Christian - Anglican');
INSERT INTO `religious_views` (`religion_id`, `religion`) VALUES(19, 'Jewish');
INSERT INTO `religious_views` (`religion_id`, `religion`) VALUES(20, 'Jewish - Reform');
INSERT INTO `religious_views` (`religion_id`, `religion`) VALUES(21, 'Jewish - Conservative');
INSERT INTO `religious_views` (`religion_id`, `religion`) VALUES(22, 'Jewish - Orthodox');
INSERT INTO `religious_views` (`religion_id`, `religion`) VALUES(23, 'Buddhist');
INSERT INTO `religious_views` (`religion_id`, `religion`) VALUES(24, 'Buddhist - Theravada');
INSERT INTO `religious_views` (`religion_id`, `religion`) VALUES(25, 'Buddhist - Mahayana');
INSERT INTO `religious_views` (`religion_id`, `religion`) VALUES(26, 'Buddhist - Vajrayana');
INSERT INTO `religious_views` (`religion_id`, `religion`) VALUES(27, 'Muslim');
INSERT INTO `religious_views` (`religion_id`, `religion`) VALUES(28, 'Muslim - Sunni');
INSERT INTO `religious_views` (`religion_id`, `religion`) VALUES(29, 'Muslim - Shiite');
INSERT INTO `religious_views` (`religion_id`, `religion`) VALUES(30, 'Muslim - Sufi');
INSERT INTO `religious_views` (`religion_id`, `religion`) VALUES(31, 'Hindu');
INSERT INTO `religious_views` (`religion_id`, `religion`) VALUES(32, 'Hindu - Vaishnavism');
INSERT INTO `religious_views` (`religion_id`, `religion`) VALUES(33, 'Hindu - Saivite');
INSERT INTO `religious_views` (`religion_id`, `religion`) VALUES(34, 'Hindu - Shakta');
INSERT INTO `religious_views` (`religion_id`, `religion`) VALUES(35, 'Hindu - Smartha');
INSERT INTO `religious_views` (`religion_id`, `religion`) VALUES(36, 'Agnostic');
INSERT INTO `religious_views` (`religion_id`, `religion`) VALUES(37, 'Atheist');
INSERT INTO `religious_views` (`religion_id`, `religion`) VALUES(38, 'Pastafarian');
INSERT INTO `religious_views` (`religion_id`, `religion`) VALUES(39, 'Pagan');
INSERT INTO `religious_views` (`religion_id`, `religion`) VALUES(40, 'Wiccan');
INSERT INTO `religious_views` (`religion_id`, `religion`) VALUES(41, 'Daoist');
INSERT INTO `religious_views` (`religion_id`, `religion`) VALUES(42, 'Confucian');
INSERT INTO `religious_views` (`religion_id`, `religion`) VALUES(43, 'Jain');
INSERT INTO `religious_views` (`religion_id`, `religion`) VALUES(44, 'Unitarian Universalist');
INSERT INTO `religious_views` (`religion_id`, `religion`) VALUES(45, 'Sikh');
INSERT INTO `religious_views` (`religion_id`, `religion`) VALUES(46, 'Other');

-- --------------------------------------------------------

--
-- Table structure for table `report`
--

DROP TABLE IF EXISTS `report`;
CREATE TABLE `report` (
  `report_id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `report_type_id` int(11) NOT NULL,
  `report_comment` text NOT NULL,
  `report_for` enum('group','event','photo','network','user','posteditem','notes','marketplace','general') NOT NULL default 'group',
  `report_for_id` int(11) NOT NULL,
  `report_date` timestamp NOT NULL default CURRENT_TIMESTAMP,
  PRIMARY KEY  (`report_id`)
);

--
-- Dumping data for table `report`
--

-- --------------------------------------------------------

--
-- Table structure for table `report_type`
--

DROP TABLE IF EXISTS `report_type`;
CREATE TABLE `report_type` (
  `report_type_id` int(11) NOT NULL auto_increment,
  `report_type` varchar(255) NOT NULL,
  PRIMARY KEY  (`report_type_id`)
);

--
-- Dumping data for table `report_type`
--

INSERT INTO `report_type` (`report_type_id`, `report_type`) VALUES(1, 'Inappropriate or pornographic picture');
INSERT INTO `report_type` (`report_type_id`, `report_type`) VALUES(2, 'Attacks individual or group');
INSERT INTO `report_type` (`report_type_id`, `report_type`) VALUES(3, 'Drug use');
INSERT INTO `report_type` (`report_type_id`, `report_type`) VALUES(4, 'Violence');
INSERT INTO `report_type` (`report_type_id`, `report_type`) VALUES(5, 'Advertisement/Spam');

-- --------------------------------------------------------

--
-- Table structure for table `school_education`
--

DROP TABLE IF EXISTS `school_education`;
CREATE TABLE `school_education` (
  `school_edu_id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `class_year` bigint(20) NOT NULL,
  `attended_for` enum('college','gradschool','') NOT NULL,
  `concentration1` text NOT NULL,
  `concentration2` text NOT NULL,
  `concentration3` text NOT NULL,
  `college_name` varchar(255) NOT NULL,
  PRIMARY KEY  (`school_edu_id`)
);

--
-- Dumping data for table `school_education`
--

-- --------------------------------------------------------

--
-- Table structure for table `school_status`
--

DROP TABLE IF EXISTS `school_status`;
CREATE TABLE `school_status` (
  `school_status_id` int(11) NOT NULL auto_increment,
  `status` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`school_status_id`)
);

--
-- Dumping data for table `school_status`
--

INSERT INTO `school_status` (`school_status_id`, `status`) VALUES(1, 'Undergrad');
INSERT INTO `school_status` (`school_status_id`, `status`) VALUES(2, 'Grad Student');
INSERT INTO `school_status` (`school_status_id`, `status`) VALUES(3, 'Alumnus/Alumna');
INSERT INTO `school_status` (`school_status_id`, `status`) VALUES(4, 'Faculty');
INSERT INTO `school_status` (`school_status_id`, `status`) VALUES(5, 'Staff');

-- --------------------------------------------------------

--
-- Table structure for table `screens`
--

DROP TABLE IF EXISTS `screens`;
CREATE TABLE `screens` (
  `screen_id` bigint(20) NOT NULL auto_increment,
  `user_id` bigint(20) NOT NULL,
  `screen_name` varchar(250) NOT NULL,
  `messenger_id` bigint(20) NOT NULL,
  PRIMARY KEY  (`screen_id`)
);

--
-- Dumping data for table `screens`
--

-- --------------------------------------------------------

--
-- Table structure for table `screen_status`
--

DROP TABLE IF EXISTS `screen_status`;
CREATE TABLE `screen_status` (
  `screen_status_id` int(11) NOT NULL auto_increment,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY  (`screen_status_id`)
);

--
-- Dumping data for table `screen_status`
--

INSERT INTO `screen_status` (`screen_status_id`, `status`) VALUES(1, 'at the library');
INSERT INTO `screen_status` (`screen_status_id`, `status`) VALUES(2, 'in class');
INSERT INTO `screen_status` (`screen_status_id`, `status`) VALUES(3, 'out at a party');
INSERT INTO `screen_status` (`screen_status_id`, `status`) VALUES(4, 'sleeping');
INSERT INTO `screen_status` (`screen_status_id`, `status`) VALUES(5, 'at home');
INSERT INTO `screen_status` (`screen_status_id`, `status`) VALUES(6, 'at work');

-- --------------------------------------------------------

--
-- Table structure for table `search_profile`
--

DROP TABLE IF EXISTS `search_profile`;
CREATE TABLE `search_profile` (
  `profile_search_id` bigint(20) NOT NULL auto_increment,
  `user_id` bigint(20) NOT NULL,
  `search_profile` text NOT NULL,
  `search_network` text NOT NULL,
  `college_network` tinyint(1) NOT NULL,
  `school_network` tinyint(1) NOT NULL,
  `company_network` tinyint(1) NOT NULL,
  `regional_network` tinyint(1) NOT NULL,
  `no_network` tinyint(1) NOT NULL,
  PRIMARY KEY  (`profile_search_id`)
);

--
-- Dumping data for table `search_profile`
--


-- --------------------------------------------------------

--
-- Table structure for table `search_setting`
--

DROP TABLE IF EXISTS `search_setting`;
CREATE TABLE `search_setting` (
  `search_setting_id` int(3) NOT NULL auto_increment,
  `search_setting_name` varchar(200) NOT NULL,
  `search_setting_type` varchar(255) default NULL,
  PRIMARY KEY  (`search_setting_id`)
);

--
-- Dumping data for table `search_setting`
--

INSERT INTO `search_setting` (`search_setting_id`, `search_setting_name`, `search_setting_type`) VALUES(1, 'Everyone', 'view');
INSERT INTO `search_setting` (`search_setting_id`, `search_setting_name`, `search_setting_type`) VALUES(2, 'All my networks and all my friends', 'view');
INSERT INTO `search_setting` (`search_setting_id`, `search_setting_name`, `search_setting_type`) VALUES(3, 'Some of my networks and all my friends', 'view');
INSERT INTO `search_setting` (`search_setting_id`, `search_setting_name`, `search_setting_type`) VALUES(4, 'Only my friends', 'view');
INSERT INTO `search_setting` (`search_setting_id`, `search_setting_name`, `search_setting_type`) VALUES(5, 'See your picture', 'profile');
INSERT INTO `search_setting` (`search_setting_id`, `search_setting_name`, `search_setting_type`) VALUES(6, 'Send you a message', 'profile');
INSERT INTO `search_setting` (`search_setting_id`, `search_setting_name`, `search_setting_type`) VALUES(7, 'Add you as a friend', 'profile');
INSERT INTO `search_setting` (`search_setting_id`, `search_setting_name`, `search_setting_type`) VALUES(8, 'View your friend list', 'profile');
INSERT INTO `search_setting` (`search_setting_id`, `search_setting_name`, `search_setting_type`) VALUES(9, 'People in college networks ', 'network');
INSERT INTO `search_setting` (`search_setting_id`, `search_setting_name`, `search_setting_type`) VALUES(10, 'People in high school networks ', 'network');
INSERT INTO `search_setting` (`search_setting_id`, `search_setting_name`, `search_setting_type`) VALUES(11, 'People in company networks ', 'network');
INSERT INTO `search_setting` (`search_setting_id`, `search_setting_name`, `search_setting_type`) VALUES(12, 'People in regional networks ', 'network');
INSERT INTO `search_setting` (`search_setting_id`, `search_setting_name`, `search_setting_type`) VALUES(13, 'People with no networks ', 'network');

-- --------------------------------------------------------

--
-- Table structure for table `search_setting_network`
--

DROP TABLE IF EXISTS `search_setting_network`;
CREATE TABLE `search_setting_network` (
  `search_setting_network_id` bigint(20) NOT NULL auto_increment,
  `user_id` bigint(20) NOT NULL,
  `network_id` bigint(20) NOT NULL,
  PRIMARY KEY  (`search_setting_network_id`)
);

--
-- Dumping data for table `search_setting_network`
--


-- --------------------------------------------------------

--
-- Table structure for table `search_setting_status`
--

DROP TABLE IF EXISTS `search_setting_status`;
CREATE TABLE `search_setting_status` (
  `search_setting_status_id` int(3) NOT NULL auto_increment,
  `user_id` bigint(20) NOT NULL,
  `search_setting_id` int(3) NOT NULL,
  `search_setting_value` enum('yes','no') NOT NULL default 'no',
  PRIMARY KEY  (`search_setting_status_id`)
);

--
-- Dumping data for table `search_setting_status`
--

-- --------------------------------------------------------

--
-- Table structure for table `security_question`
--

DROP TABLE IF EXISTS `security_question`;
CREATE TABLE `security_question` (
  `question_id` int(11) NOT NULL auto_increment,
  `question` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`question_id`)
);

--
-- Dumping data for table `security_question`
--

INSERT INTO `security_question` (`question_id`, `question`) VALUES(1, 'What was the name of your first stuffed animal?');
INSERT INTO `security_question` (`question_id`, `question`) VALUES(2, 'Who was your first kiss?');
INSERT INTO `security_question` (`question_id`, `question`) VALUES(3, 'What time were you born?');
INSERT INTO `security_question` (`question_id`, `question`) VALUES(4, 'Who was your third grade teacher?');
INSERT INTO `security_question` (`question_id`, `question`) VALUES(5, 'What is your least favorite nickname?');
INSERT INTO `security_question` (`question_id`, `question`) VALUES(6, 'What was the first concert you attended?');
INSERT INTO `security_question` (`question_id`, `question`) VALUES(7, 'What is your mother''s maiden name?');
INSERT INTO `security_question` (`question_id`, `question`) VALUES(8, 'What was your favourite pets name ?');

-- --------------------------------------------------------

--
-- Table structure for table `state_province`
--

DROP TABLE IF EXISTS `state_province`;
CREATE TABLE `state_province` (
  `state_id` int(11) NOT NULL auto_increment,
  `state_name` varchar(255) NOT NULL,
  `state_symbol` varchar(10) NOT NULL,
  `country_symbol` varchar(10) NOT NULL,
  PRIMARY KEY  (`state_id`)
);

--
-- Dumping data for table `state_province`
--

INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(1, 'Alberta', 'AB', 'CA');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(2, 'British Columbia', 'BC', 'CA');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(3, 'Manitoba', 'MB', 'CA');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(4, 'New Brunswick', 'NB', 'CA');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(5, 'Newfoundland', 'NL', 'CA');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(6, 'Northwest Territories', 'NT', 'CA');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(7, 'Nova Scotia', 'NS', 'CA');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(8, 'Nunavut', 'NU', 'CA');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(9, 'Ontario', 'ON', 'CA');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(10, 'Prince Edward Island', 'PE', 'CA');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(11, 'Quebec', 'QC', 'CA');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(12, 'Saskatchewan', 'SK', 'CA');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(13, 'Yukon Territory', 'YT', 'CA');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(14, 'Alabama', 'AL', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(15, 'Alaska', 'AK', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(16, 'Arizona', 'AZ', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(17, 'Arkansas', 'AR', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(18, 'California', 'CA', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(19, 'Colorado', 'CO', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(20, 'Connecticut', 'CT', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(21, 'Delaware', 'DE', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(22, 'District Of Columbia', 'DC', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(23, 'Florida', 'FL', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(24, 'Georgia', 'GE', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(25, 'Guam', 'GUAM', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(26, 'Hawaii', 'HI', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(27, 'Idaho', 'ID', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(28, 'Illinois', 'IL', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(29, 'Indiana', 'IN', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(30, 'Iowa', 'IA', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(31, 'Kansas', 'KS', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(32, 'Kentucky', 'KY', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(33, 'Louisiana', 'LA', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(34, 'Maine', 'ME', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(35, 'Maryland', 'MD', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(36, 'Massachusetts', 'MA', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(37, 'Michigan', 'MI', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(38, 'Minnesota', 'MN', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(39, 'Mississippi', 'MS', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(40, 'Missouri', 'MO', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(41, 'Montana', 'MT', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(42, 'Nebraska', 'NE', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(43, 'Nevada', 'NV', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(44, 'New Hampshire', 'NH', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(45, 'New Jersey', 'NJ', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(46, 'New Mexico', 'NM', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(47, 'New York', 'NY', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(48, 'North Carolina', 'NC', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(49, 'North Dakota', 'ND', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(50, 'Ohio', 'OH', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(51, 'Oklahoma', 'OK', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(52, 'Oregon', 'OR', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(53, 'Pennsylvania', 'PA', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(54, 'Puerto Rico', 'PR', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(55, 'Rhode Island', 'RI', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(56, 'South Carolina', 'SC', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(57, 'South Dakota', 'SD', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(58, 'Tennessee', 'TN', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(59, 'Texas', 'TX', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(60, 'Utah', 'UT', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(61, 'Vermont', 'VT', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(62, 'Virginia', 'VA', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(63, 'Washington', 'WA', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(64, 'West Virginia', 'WV', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(65, 'Wisconsin', 'WI', 'US');
INSERT INTO `state_province` (`state_id`, `state_name`, `state_symbol`, `country_symbol`) VALUES(66, 'Wyoming', 'WY', 'US');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `user_id` int(11) NOT NULL auto_increment,
  `username` varchar(75) NOT NULL,
  `show_password` varchar(25) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` text NOT NULL,
  `avatar_ext` varchar(5) NOT NULL default '.jpg',
  `user_status` enum('active','deactive','pending') NOT NULL default 'pending',
  `registered_date` datetime NOT NULL default '0000-00-00 00:00:00',
  `last_modified` datetime NOT NULL,
  `last_login` datetime default NULL,
  `question_id` int(11) NOT NULL default '0',
  `security_answer` varchar(255) NOT NULL default '',
  `zone_id` int(11) NOT NULL default '16',
  `lifestage_id` int(11) NOT NULL default '0',
  `school_status_id` int(11) NOT NULL default '0',
  `college_year` int(11) NOT NULL default '0',
  `high_school` varchar(255) NOT NULL default '',
  `school_year` int(11) NOT NULL default '0',
  `birthday` varchar(255) NOT NULL default '',
  `activation_key` varchar(255) NOT NULL,
  `screen_status_id` int(11) NOT NULL,
  `screen_status_changed_date` datetime NOT NULL,
  `logged_in` smallint(6) NOT NULL default '0',
  PRIMARY KEY  (`user_id`)
);

--
-- Dumping data for table `users`
--

-- --------------------------------------------------------

--
-- Table structure for table `users_applications`
--

DROP TABLE IF EXISTS `users_applications`;
CREATE TABLE `users_applications` (
  `users_applications_id` bigint(20) NOT NULL auto_increment,
  `user_id` bigint(20) NOT NULL,
  `application_ids` text NOT NULL,
  PRIMARY KEY  (`users_applications_id`)
);

--
-- Dumping data for table `users_applications`
--


-- --------------------------------------------------------

--
-- Table structure for table `users_status`
--

DROP TABLE IF EXISTS `users_status`;
CREATE TABLE `users_status` (
  `id` int(3) NOT NULL auto_increment,
  `user_id` int(3) NOT NULL,
  `notification_id` int(3) NOT NULL,
  `notification_status` smallint(6) NOT NULL default '1',
  PRIMARY KEY  (`id`)
);

--
-- Dumping data for table `users_status`
--


-- --------------------------------------------------------

--
-- Table structure for table `videos`
--

DROP TABLE IF EXISTS `videos`;
CREATE TABLE `videos` (
  `video_id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `video_title` varchar(255) NOT NULL,
  `video_tags` varchar(255) NOT NULL,
  `video_visibility_code` varchar(255) NOT NULL,
  `video_description` text NOT NULL,
  `views` int(11) NOT NULL,
  `rate_count` int(11) NOT NULL,
  `rate_value` int(11) NOT NULL,
  `rate_avg` double NOT NULL,
  `video_status` enum('active','inactive','deleted') NOT NULL default 'inactive',
  `video_type` enum('uploaded','recorded') NOT NULL default 'uploaded',
  `created_on` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `updated_on` timestamp NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`video_id`)
);

--
-- Dumping data for table `videos`
--

-- --------------------------------------------------------

--
-- Table structure for table `videos_rate`
--

DROP TABLE IF EXISTS `videos_rate`;
CREATE TABLE `videos_rate` (
  `video_rate_id` int(11) NOT NULL auto_increment,
  `video_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `rate_value` int(11) NOT NULL,
  `datestamp` timestamp NOT NULL default CURRENT_TIMESTAMP,
  PRIMARY KEY  (`video_rate_id`)
);

--
-- Dumping data for table `videos_rate`
--

-- --------------------------------------------------------

--
-- Table structure for table `videos_visibility`
--

DROP TABLE IF EXISTS `videos_visibility`;
CREATE TABLE `videos_visibility` (
  `video_visibility_id` int(11) NOT NULL auto_increment,
  `video_visibility_code` varchar(255) NOT NULL,
  `video_visibility_label` varchar(255) NOT NULL,
  PRIMARY KEY  (`video_visibility_id`)
);

--
-- Dumping data for table `videos_visibility`
--

INSERT INTO `videos_visibility` (`video_visibility_id`, `video_visibility_code`, `video_visibility_label`) VALUES(1, 'private', 'Only Me');
INSERT INTO `videos_visibility` (`video_visibility_id`, `video_visibility_code`, `video_visibility_label`) VALUES(2, 'public', 'Everyone');
INSERT INTO `videos_visibility` (`video_visibility_id`, `video_visibility_code`, `video_visibility_label`) VALUES(3, 'friends', 'Only my friends');

-- --------------------------------------------------------

--
-- Table structure for table `wall`
--

DROP TABLE IF EXISTS `wall`;
CREATE TABLE `wall` (
  `wall_id` bigint(20) NOT NULL auto_increment,
  `wall_for` enum('group','event','photo','network','profile','posteditem','notes','marketplace','video') NOT NULL,
  `wall_for_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `wall_content` text NOT NULL,
  `wall_date` timestamp NOT NULL default CURRENT_TIMESTAMP,
  PRIMARY KEY  (`wall_id`)
);

--
-- Dumping data for table `wall`
--

-- --------------------------------------------------------

--
-- Table structure for table `want_networks`
--

DROP TABLE IF EXISTS `want_networks`;
CREATE TABLE `want_networks` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `wanted_id` int(11) unsigned NOT NULL,
  `network_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned default NULL,
  `user_created` varchar(100) default NULL,
  `date_created` timestamp NOT NULL default CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
);

--
-- Dumping data for table `want_networks`
--

-- --------------------------------------------------------

--
-- Table structure for table `want_photos`
--

DROP TABLE IF EXISTS `want_photos`;
CREATE TABLE `want_photos` (
  `photo_id` int(11) unsigned NOT NULL auto_increment,
  `wanted_id` int(11) unsigned NOT NULL,
  `file_name` text,
  `remarks` text,
  `user_id` int(11) default NULL,
  `user_created` varchar(100) default NULL,
  `date_created` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `user_modified` varchar(100) default NULL,
  `date_modified` timestamp NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`photo_id`)
);

--
-- Dumping data for table `want_photos`
--
