<?php //00461
// Copyright Notice
// Web Site URL:  http://www.zeeways.com
// Script Owner eMail: mail@zeeways.com
// Date: April, 2007
// Script Name: Zeeways Auction Website PHP Script
// Copyright Details: This script is not free.  Do not Remove this Copy Right notice.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the site administrator.');exit(199);
?>
4+oV5DwdyEOkZyd98nDbnHFjVoDef+KqU0GdLvYiVgdDV1/crcnOlygQO2wzni1bgBnYGgiSEHcD
xMx5vGBgWn4dSBOiss0m50SVtIh+SY3P8Iriysvy0MGjBlOwHGw0Li7lVjvxsAeOJE6M3zC6Nn2x
seET25FoU+yYGhXd7f5YVwgjJ8zPnrxCX9RF2+YQKN1Cnp/hezSBrx9XtKCgPb3jhHkZoYMXs4BC
fBy0qcDj70YZwrzv5GDXbgOq34npzoskINwscd0HWnDW5VuICXJuqg0SvvoPXX1Q4gl7SO1oUDV+
Yy6khTed9zqlg9gkSSepL5/DrBAnizjzJtxj2nfvshvW734XHvQX7YZYigD0yurYn69T3Lsylesd
EjLXtmRk0stutCClvE+sTAwZWBs0N0WZWDFM+XssVOe/5Jr4zTGXJL+GUx6eCRHamnKs+7jFiSLs
Y5zhgpO+mXvg5TvS5Wqk2dmt/mRL2R62s2kyDnAIqTL6S6/u+DatmHSY6KkpYceJIZqAqjrvsG82
b30VI+uWOY88UtsBHT9XmgncVvgkbQEzYXJtfs2/cguXHVYmL2KoRr/lG4ROaH598TCSe5hn0KDn
wolE5enl2RUBjLgdz+PeNY2oQGsBIt7xq0Nu6PL6n27LVAEMyJQvZyx8WvDI/A9s3vtG3dbp3Gnf
NHEfIfVfM3Fn7vc8N0GlwMlq3XXaDcWNls2cixkeioog9f5s1iqWRs6YWUcT53WQZay2rp3kaZW3
nncWaZdLFYJ8XDHY7sKeeNIETQ+lrZ5QN9TuTB8S0Pkevqe65YVtnDO3QPyxTdOnuhj5xuk41qJC
VnLYIZPlBDTXW+lEMKYF8SjBzIsi4axHYvOPtdZaD4LRDkPJpJGUTbvXmCrNn+MRNF2Sl22rWG50
vfvPkP6+ROxrUn/IdoupFZTZBB0mTZloK5bK2ETeGq9XLShNTMydeS+X1G+YzP65xce6LTwiYvN3
10fpVtKZO6Gu0U8UXDzaey6bPXkXZRtJimx4ETsphEjrMMp2PD4MG77yQtV09c9u9VwI2L64zOog
qsj31p9KpmL1H4B5lmWwtjTWSwTYaOGofXRP+mo3biRqjbszMNXuvZs2tpVi5oo/OzgXS2tv7SEZ
x6Tk0UJI4j78T11IYMQKcIgNGQaYfdGs1isdyJCDCXZ/FSdfbNz0VD2J2nAiqK3f4EU22qwmFiyr
wQuDQASVS8Av75AUOG==