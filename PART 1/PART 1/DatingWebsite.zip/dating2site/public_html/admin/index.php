<?php

if ( !defined( 'SMARTY_DIR' ) ) {
	include_once( '../init.php' );
}

if (isset($_SESSION['AdminId'])) {
	if ($_GET['page'] == 'credits') {
		/* Display credits page */
		$t->assign('rendered_page', $t->fetch('admin/osdate_credits.tpl'));

		$t->display ( 'admin/index.tpl' );

		exit;
	} else {

		header("location: panel.php");
		exit;
	}
}

if ($_GET['errid']) {
	$t->assign ( 'login_error', get_lang('errormsgs',$_GET['errid']) );
}
$t->assign('rendered_page', $t->fetch('admin/statistics.tpl'));

$t->display ( 'admin/index.tpl' );

?>
