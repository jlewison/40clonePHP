# phpMyAdmin MySQL-Dump
# version 2.3.2
# http://www.phpmyadmin.net/ (download page)
#
# Host: localhost
# Generation Time: May 01, 2004 at 12:16 PM
# Server version: 4.00.04
# PHP Version: 4.2.3
# Database : `zeeauctions`
# --------------------------------------------------------

#
# Table structure for table `zeeauctions_admin`
#

DROP TABLE IF EXISTS `zeeauctions_admin`;
CREATE TABLE `zeeauctions_admin` (
  `id` bigint(20) NOT NULL auto_increment,
  `admin_name` varchar(255) default NULL,
  `pwd` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_admin`
#

INSERT INTO `zeeauctions_admin` (`id`, `admin_name`, `pwd`) VALUES (1, 'admin', 'admin');
# --------------------------------------------------------

#
# Table structure for table `zeeauctions_ads`
#

DROP TABLE IF EXISTS `zeeauctions_ads`;
CREATE TABLE `zeeauctions_ads` (
  `id` bigint(20) NOT NULL auto_increment,
  `url` varchar(255) NOT NULL default '',
  `bannerurl` varchar(255) NOT NULL default '',
  `adv_id` bigint(20) NOT NULL default '0',
  `credits` bigint(20) NOT NULL default '0',
  `displays` bigint(20) NOT NULL default '0',
  `paid` varchar(255) NOT NULL default '',
  `approved` varchar(255) NOT NULL default '',
  `clicks` bigint(20) default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_ads`
#

INSERT INTO `zeeauctions_ads` (`id`, `url`, `bannerurl`, `adv_id`, `credits`, `displays`, `paid`, `approved`, `clicks`) VALUES (13, 'http://zeeauctions.com', 'http://localhost/zeeauctions/images/image1.jpg', 2, 1, 1, 'yes', 'yes', 0),
(5, 'http://ZXCZX', 'http://ZXCZX', 2, 1000, 0, 'no', 'yes', 0),
(6, 'http://www.evitasoft.com', 'http://bhh.com', 2, 10000, 0, 'no', 'yes', 0),
(7, 'http://www.evitasoft.com', 'http://bhh.com', 2, 10000, 0, 'no', 'yes', 0),
(9, 'http://a.com', 'http://b.com', 2, 10000, 0, 'no', 'yes', 0),
(10, 'http://asd.com', 'http://p.dod', 2, 1000, 0, 'no', 'yes', 0),
(11, 'http://ggggf.com', 'http://', 2, 1000, 0, 'no', 'yes', 0),
(14, 'http://sdff', 'http://hgf', 2, 1000, 0, 'no', 'yes', 0),
(15, 'http://cc', 'http://ccc', 2, 1000, 0, 'no', 'yes', 0),
(16, 'http://cc', 'http://ccc', 2, 1000, 0, 'no', 'yes', 0),
(21, 'http://sdsd', 'http://sdsd', 0, 1222, 42, 'yes', 'yes', 0),
(18, 'http://vvv1.com', 'http://bbb1.com', 2, 2000, 209, 'yes', 'no', 3),
(19, 'http://mysite.com', 'http://mybanner.com', 0, 1000, 189, 'yes', 'yes', 0),
(20, 'http://mysite.com', 'http://mybanner.com', 2, 1000, 6, 'yes', 'no', 2),
(22, 'http://mysisisii.com', 'http://assd', 0, 1234, 1, 'yes', 'yes', 0),
(23, 'http://vinbit.com', 'http://vin.com', 2, 12000, 13, 'yes', 'yes', 0);
# --------------------------------------------------------

#
# Table structure for table `zeeauctions_adv_transactions`
#

DROP TABLE IF EXISTS `zeeauctions_adv_transactions`;
CREATE TABLE `zeeauctions_adv_transactions` (
  `id` bigint(20) NOT NULL auto_increment,
  `description` varchar(255) default NULL,
  `amount` decimal(10,2) default NULL,
  `adv_id` bigint(20) default NULL,
  `date_submitted` timestamp(14) NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_adv_transactions`
#

INSERT INTO `zeeauctions_adv_transactions` (`id`, `description`, `amount`, `adv_id`, `date_submitted`) VALUES (8, 'Banner Posting Charges', '-9.00', 2, 20040327161746),
(9, 'Money added through paypal', '10.00', 2, 20040327044504),
(10, 'Purchased More Impressions', '-9.00', 2, 20040327050022),
(16, 'Added by admin', '10.00', 2, 20040329051138),
(17, 'Banner Posting Charges', '-9.00', 2, 20040329051156),
(7, 'Added Money', '10.00', 2, 20040327155703),
(18, 'Added by admin', '10.00', 2, 20040410094243),
(19, 'Added by admin', '1.00', 2, 20040410055904);
# --------------------------------------------------------

#
# Table structure for table `zeeauctions_advertisers`
#

DROP TABLE IF EXISTS `zeeauctions_advertisers`;
CREATE TABLE `zeeauctions_advertisers` (
  `id` bigint(20) NOT NULL auto_increment,
  `uname` varchar(255) default NULL,
  `email` varchar(255) default NULL,
  `pwd` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_advertisers`
#

INSERT INTO `zeeauctions_advertisers` (`id`, `uname`, `email`, `pwd`) VALUES (2, 'vine', 'vin@qq.com', 'vin'),
(4, 'savvy', 'savvy@ww.com', 'a'),
(6, 'vikas', 'vikk@vik.com', 'aaaa'),
(7, 'vin', 'vin@qq1.com', 'vini');
# --------------------------------------------------------

#
# Table structure for table `zeeauctions_auction_types`
#

DROP TABLE IF EXISTS `zeeauctions_auction_types`;
CREATE TABLE `zeeauctions_auction_types` (
  `id` bigint(20) NOT NULL auto_increment,
  `auction_name` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_auction_types`
#

INSERT INTO `zeeauctions_auction_types` (`id`, `auction_name`) VALUES (3, 'fixed'),
(2, 'dutch'),
(1, 'auction'),
(4, 'classified');
# --------------------------------------------------------

#
# Table structure for table `zeeauctions_banners`
#

DROP TABLE IF EXISTS `zeeauctions_banners`;
CREATE TABLE `zeeauctions_banners` (
  `id` bigint(20) NOT NULL auto_increment,
  `img_url` varchar(255) default NULL,
  `banner_link` varchar(255) default NULL,
  `width` int(11) default NULL,
  `height` int(11) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_banners`
#

INSERT INTO `zeeauctions_banners` (`id`, `img_url`, `banner_link`, `width`, `height`) VALUES (1, 'www.gif', 'www.wmd.com', 30, 20),
(2, 'www.gif', 'www.wmd.com', 30, 20),
(3, 'www.gif', 'www.wmd.com', 30, 20);
# --------------------------------------------------------

#
# Table structure for table `zeeauctions_bids`
#

DROP TABLE IF EXISTS `zeeauctions_bids`;
CREATE TABLE `zeeauctions_bids` (
  `id` bigint(20) NOT NULL auto_increment,
  `pid` bigint(20) default NULL,
  `amount` decimal(10,2) default NULL,
  `uid` bigint(20) default NULL,
  `date_submitted` timestamp(14) NOT NULL,
  `notify_me` varchar(255) default 'no',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_bids`
#

INSERT INTO `zeeauctions_bids` (`id`, `pid`, `amount`, `uid`, `date_submitted`, `notify_me`) VALUES (1, 63, '44.00', 12, 20040121144401, 'no'),
(2, 63, '40.00', 9, 20040121140027, 'no'),
(3, 68, '80.00', 9, 20040121030146, 'no'),
(15, 101, '2400.00', 12, 20040407061238, 'no'),
(6, 60, '50.00', 12, 20040129101546, 'yes'),
(7, 60, '16.00', 9, 20040124201028, 'yes'),
(16, 99, '1300.00', 12, 20040407063720, 'no'),
(10, 73, '20.00', 12, 20040124192304, 'no'),
(11, 60, '50.00', 28, 20040124202539, 'yes'),
(14, 94, '1900.00', 12, 20040407054926, 'no'),
(17, 99, '1301.00', 9, 20040407183912, 'no'),
(18, 103, '2512.00', 8, 20040409182807, 'no'),
(25, 100, '1500.00', 12, 20040410130854, 'no'),
(24, 100, '1234.00', 9, 20040410124227, 'no'),
(26, 100, '1492.00', 29, 20040410131006, 'no'),
(34, 100, '1512.00', 15, 20040410161934, 'no');
# --------------------------------------------------------

#
# Table structure for table `zeeauctions_blocked`
#

DROP TABLE IF EXISTS `zeeauctions_blocked`;
CREATE TABLE `zeeauctions_blocked` (
  `id` bigint(20) NOT NULL auto_increment,
  `uid` bigint(20) default NULL,
  `blocked_user` bigint(20) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_blocked`
#

INSERT INTO `zeeauctions_blocked` (`id`, `uid`, `blocked_user`) VALUES (7, 8, 9),
(14, 15, 16),
(13, 8, 10);
# --------------------------------------------------------

#
# Table structure for table `zeeauctions_categories`
#

DROP TABLE IF EXISTS `zeeauctions_categories`;
CREATE TABLE `zeeauctions_categories` (
  `id` bigint(20) NOT NULL auto_increment,
  `cat_name` varchar(255) default NULL,
  `pid` bigint(20) default NULL,
  `clicks` bigint(20) default NULL,
  `order_index` bigint(20) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_categories`
#

INSERT INTO `zeeauctions_categories` (`id`, `cat_name`, `pid`, `clicks`, `order_index`) VALUES (11, 'DVDs', 2, NULL, 16),
(2, 'Electronics', 0, NULL, 15),
(3, 'Furniture Goods', 0, NULL, 3),
(7, 'Monitors', 2, NULL, 11),
(9, 'Antiques', 0, NULL, 13),
(10, 'Books', 0, NULL, 14),
(12, 'Video Games', 0, NULL, 20),
(13, 'Travel', 0, NULL, 22),
(14, 'Toys', 0, NULL, 0),
(15, 'Household', 0, NULL, 2),
(16, 'new2', 15, NULL, 2),
(17, 'new1', 15, NULL, 2),
(19, 'newone', 16, NULL, -2),
(20, 'newtwo', 16, NULL, -1);
# --------------------------------------------------------

#
# Table structure for table `zeeauctions_config`
#

DROP TABLE IF EXISTS `zeeauctions_config`;
CREATE TABLE `zeeauctions_config` (
  `id` bigint(20) NOT NULL auto_increment,
  `admin_email` varchar(255) default NULL,
  `site_name` varchar(255) default NULL,
  `recperpage` int(11) default NULL,
  `pay_pal` varchar(255) default NULL,
  `no_of_images` int(11) default NULL,
  `agreement` longtext,
  `recinpanel` int(11) default NULL,
  `null_char` varchar(255) default NULL,
  `privacy` longtext,
  `legal` longtext,
  `terms` longtext,
  `username_len` int(11) default NULL,
  `pwd_len` int(11) default NULL,
  `site_root` varchar(255) default NULL,
  `featured_items` int(11) default NULL,
  `fp_images` int(11) default '0',
  `bonus` decimal(10,2) default NULL,
  `bold_rate` decimal(10,2) default NULL,
  `featured_rate` decimal(10,2) default NULL,
  `highlight_rate` decimal(10,2) default NULL,
  `free_images` int(10) default NULL,
  `image_rate` decimal(10,2) default NULL,
  `buy_images` int(10) default NULL,
  `welcome_msg` longtext,
  `max_period` int(10) default NULL,
  `fp_featured_rate` decimal(10,2) default NULL,
  `gallery_featured_rate` decimal(10,2) default NULL,
  `auction_item_fees` decimal(10,2) default '0.00',
  `fixed_item_fees` decimal(10,2) default '0.00',
  `classified_item_fees` decimal(10,2) default '0.00',
  `dutch_item_fees` decimal(10,2) default '0.00',
  `cur_id` bigint(20) default '1',
  `max_ext_period` int(11) default '0',
  `ext_cost` decimal(10,2) NOT NULL default '0.00',
  `image_size` bigint(20) default '0',
  `buy_now` decimal(10,2) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_config`
#

INSERT INTO `zeeauctions_config` (`id`, `admin_email`, `site_name`, `recperpage`, `pay_pal`, `no_of_images`, `agreement`, `recinpanel`, `null_char`, `privacy`, `legal`, `terms`, `username_len`, `pwd_len`, `site_root`, `featured_items`, `fp_images`, `bonus`, `bold_rate`, `featured_rate`, `highlight_rate`, `free_images`, `image_rate`, `buy_images`, `welcome_msg`, `max_period`, `fp_featured_rate`, `gallery_featured_rate`, `auction_item_fees`, `fixed_item_fees`, `classified_item_fees`, `dutch_item_fees`, `cur_id`, `max_ext_period`, `ext_cost`, `image_size`, `buy_now`) VALUES (1, 'admin@zeeauctions.com', 'The Web Site Header', 10, 'zeeauctions@rediffmail.com', 10, 'Your Agreement Here\r\n', 6, '- -', '<font type=\'arial\' size=4><b>Privacy Policy</b></font>\r\n<font type=\'arial\' size=2><br>Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. <p>\r\nAdmin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. <p>Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. <p>\r\n</font>', '<font type=\'arial\' size=4><b>Legal Policy</b></font>\r\n<font type=\'arial\' size=2><br>Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.<p>Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.<p>Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.<p>Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.<p>Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.<p>', '<font type=\'arial\' size=4><b>Terms and Conditions</b></font>\r\n<font type=\'arial\' size=2><br>Terms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions here<p>Terms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions here<p>Terms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions here<p>Terms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions here<p>Terms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions here<p>Terms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions here<p>Terms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions here<p>Terms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions here<p>', 4, 4, 'http://www.zeeauctions.com', 5, 5, '1.00', '2.00', '1.00', '7.00', 3, '5.00', 3, 'Welcome to ZeeAuctions', 15, '1.00', '1.80', '0.50', '0.75', '1.50', '2.00', 1, 15, '0.05', 50000, '1.00');
# --------------------------------------------------------

#
# Table structure for table `zeeauctions_contacts`
#

DROP TABLE IF EXISTS `zeeauctions_contacts`;
CREATE TABLE `zeeauctions_contacts` (
  `id` bigint(20) NOT NULL auto_increment,
  `uid` bigint(20) default NULL,
  `contact_user` bigint(20) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_contacts`
#

INSERT INTO `zeeauctions_contacts` (`id`, `uid`, `contact_user`) VALUES (6, 8, 9),
(5, 9, 8),
(7, 17, 16),
(17, 12, 15),
(11, 8, 10),
(14, 8, 16),
(15, 15, 16);
# --------------------------------------------------------

#
# Table structure for table `zeeauctions_counters`
#

DROP TABLE IF EXISTS `zeeauctions_counters`;
CREATE TABLE `zeeauctions_counters` (
  `id` bigint(20) NOT NULL auto_increment,
  `zero` varchar(255) default NULL,
  `one` varchar(255) default NULL,
  `two` varchar(255) default NULL,
  `three` varchar(255) default NULL,
  `four` varchar(255) default NULL,
  `five` varchar(255) default NULL,
  `six` varchar(255) default NULL,
  `seven` varchar(255) default NULL,
  `eight` varchar(255) default NULL,
  `nine` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_counters`
#

INSERT INTO `zeeauctions_counters` (`id`, `zero`, `one`, `two`, `three`, `four`, `five`, `six`, `seven`, `eight`, `nine`) VALUES (1, '0.gif', '1.gif', '2.gif', '3.gif', '4.gif', '5.gif', '6.gif', '7.gif', '8.gif', '9.gif'),
(2, 'a0.gif', 'a1.gif', 'a2.gif', 'a3.gif', 'a4.gif', 'a5.gif', 'a6.gif', 'a7.gif', 'a8.gif', 'a9.gif');
# --------------------------------------------------------

#
# Table structure for table `zeeauctions_country`
#

DROP TABLE IF EXISTS `zeeauctions_country`;
CREATE TABLE `zeeauctions_country` (
  `country` varchar(255) NOT NULL default '',
  `id` bigint(20) NOT NULL auto_increment,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_country`
#

INSERT INTO `zeeauctions_country` (`country`, `id`) VALUES ('Afghanistan', 1),
('Albania', 2),
('Algeria', 3),
('Andorra', 4),
('Angola', 5),
('Anguilla', 6),
('Antigua & Barbuda', 7),
('Argentina', 8),
('Armenia', 9),
('Austria', 10),
('Azerbaijan', 11),
('Bahamas', 12),
('Bahrain', 13),
('Bangladesh', 14),
('Barbados', 15),
('Belarus', 16),
('Belgium', 17),
('Belize', 18),
('Belize', 19),
('Bermuda', 20),
('Bhutan', 21),
('Bolivia', 22),
('Bosnia and Herzegovina', 23),
('Botswana', 24),
('Brazil', 25),
('Brunei', 26),
('Bulgaria', 27),
('Burkina Faso', 28),
('Burundi', 29),
('Cambodia', 30),
('Cameroon', 31),
('Canada', 32),
('Cape Verde', 33),
('Cayman Islands', 34),
('Central African Republic', 35),
('Chad', 36),
('Chile', 37),
('China', 38),
('Colombia', 39),
('Comoros', 40),
('Congo', 41),
('Congo (DRC)', 42),
('Cook Islands', 43),
('Costa Rica', 44),
('Cote d\'Ivoire', 45),
('Croatia (Hrvatska)', 46),
('Cuba', 47),
('Cyprus', 48),
('Czech Republic', 49),
('Denmark', 50),
('Djibouti', 51),
('Dominica', 52),
('Dominican Republic', 53),
('East Timor', 54),
('Ecuador', 55),
('Egypt', 56),
('El Salvador', 57),
('Equatorial Guinea', 58),
('Eritrea', 59),
('Estonia', 60),
('Ethiopia', 61),
('Falkland Islands', 62),
('Faroe Islands', 63),
('Fiji Islands', 64),
('Finland', 65),
('France', 66),
('French Guiana', 67),
('French Polynesia', 68),
('Gabon', 69),
('Gambia', 70),
('Georgia', 71),
('Germany', 72),
('Ghana', 73),
('Gibraltar', 74),
('Greece', 75),
('Greenland', 76),
('Grenada', 77),
('Guadeloupe', 78),
('Guam', 79),
('Guatemala', 80),
('Guinea', 81),
('Guinea-Bissau', 82),
('Guyana', 83),
('Haiti', 84),
('Honduras', 85),
('Hong Kong SAR', 86),
('Hungary', 87),
('Iceland', 88),
('India', 89),
('Indonesia', 90),
('Iran', 91),
('Iraq', 92),
('Ireland', 93),
('Israel', 94),
('Italy', 95),
('Jamaica', 96),
('Japan', 97),
('Jordan', 98),
('Kazakhstan', 99),
('Kenya', 100),
('Kiribati', 101),
('Korea', 102),
('Kuwait', 103),
('Kyrgyzstan', 104),
('Laos', 105),
('Latvia', 106),
('Lebanon', 107),
('Lesotho', 108),
('Liberia', 109),
('Libya', 110),
('Liechtenstein', 111),
('Lithuania', 112),
('Luxembourg', 113),
('Macao SAR', 114),
('Macedonia', 115),
('Madagascar', 116),
('Malawi', 117),
('Malaysia', 118),
('Maldives', 119),
('Mali', 120),
('Malta', 121),
('Martinique', 122),
('Mauritania', 123),
('Mauritius', 124),
('Mayotte', 125),
('Mexico', 126),
('Micronesia', 127),
('Moldova', 128),
('Monaco', 129),
('Mongolia', 130),
('Montserrat', 131),
('Morocco', 132),
('Mozambique', 133),
('Myanmar', 134),
('Namibia', 135),
('Nauru', 136),
('Nepal', 137),
('Netherlands', 138),
('Netherlands Antilles', 139),
('New Caledonia', 140),
('New Zealand', 141),
('Nicaragua', 142),
('Niger', 143),
('Nigeria', 144),
('Niue', 145),
('Norfolk Island', 146),
('North Korea', 147),
('Norway', 148),
('Oman', 149),
('Pakistan', 150),
('Panama', 151),
('Papua New Guinea', 152),
('Paraguay', 153),
('Peru', 154),
('Philippines', 155),
('Pitcairn Islands', 156),
('Poland', 157),
('Portugal', 158),
('Puerto Rico', 159),
('Qatar', 160),
('Reunion', 161),
('Romania', 162),
('Russia', 163),
('Rwanda', 164),
('Samoa', 165),
('San Marino', 166),
('Sao Tome and Principe', 167),
('Saudi Arabia', 168),
('Senegal', 169),
('Serbia and Montenegro', 170),
('Seychelles', 171),
('Sierra Leone', 172),
('Singapore', 173),
('Slovakia', 174),
('Slovenia', 175),
('Solomon Islands', 176),
('Somalia', 177),
('South Africa', 178),
('Spain', 179),
('Sri Lanka', 180),
('St. Helena', 181),
('St. Kitts and Nevis', 182),
('St. Lucia', 183),
('St. Pierre and Miquelon', 184),
('St. Vincent & Grenadines', 185),
('Sudan', 186),
('Suriname', 187),
('Swaziland', 188),
('Sweden', 189),
('Switzerland', 190),
('Syria', 191),
('Taiwan', 192),
('Tajikistan', 193),
('Tanzania', 194),
('Thailand', 195),
('Togo', 196),
('Tokelau', 197),
('Tonga', 198),
('Trinidad and Tobago', 199),
('Tunisia', 200),
('Turkey', 201),
('Turkmenistan', 202),
('Turks and Caicos Islands', 203),
('Tuvalu', 204),
('Uganda', 205),
('Ukraine', 206),
('United Arab Emirates', 207),
('United Kingdom', 208),
('Uruguay', 209),
('USA', 210),
('Uzbekistan', 211),
('Vanuatu', 212),
('Venezuela', 213),
('Vietnam', 214),
('Virgin Islands', 215),
('Virgin Islands (British)', 216),
('Wallis and Futuna', 217),
('Yemen', 218),
('Yugoslavia', 219),
('Zambia', 220),
('Zimbabwe', 221);
# --------------------------------------------------------

#
# Table structure for table `zeeauctions_currency`
#

DROP TABLE IF EXISTS `zeeauctions_currency`;
CREATE TABLE `zeeauctions_currency` (
  `id` bigint(20) NOT NULL auto_increment,
  `cur_name` varchar(255) default NULL,
  `paypal_code` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_currency`
#

INSERT INTO `zeeauctions_currency` (`id`, `cur_name`, `paypal_code`) VALUES (1, '$', 'USD');
# --------------------------------------------------------

#
# Table structure for table `zeeauctions_desc`
#

DROP TABLE IF EXISTS `zeeauctions_desc`;
CREATE TABLE `zeeauctions_desc` (
  `id` bigint(20) NOT NULL auto_increment,
  `pid` bigint(20) default NULL,
  `add_desc` longtext,
  `date_submitted` timestamp(14) NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_desc`
#

INSERT INTO `zeeauctions_desc` (`id`, `pid`, `add_desc`, `date_submitted`) VALUES (5, 23, 'I forgot to mention that it was a CD1111', 20040206155808),
(2, 23, 'I forgot to mention that it is a CD', 20040101070841),
(3, 29, 'koi nahin', 20040204065128),
(4, 29, 'bahut mehnga hai please bid theek karna nahin to daffa ho jao', 20040204082008),
(7, 38, 'edited\r\n', 20040210162843),
(8, 38, 'very very warm', 20040206060528),
(9, 41, 'great 1\r\n', 20040206075642),
(10, 41, 'Remember this:\r\n1. Take care\r\n2. TC', 20040206075701),
(11, 32, 'hahahaha', 20040208065749),
(12, 32, 'ok', 20040208065807),
(13, 42, 'fixed by admin', 20040210044412),
(16, 69, '<P><FONT face="Verdana, Arial, Helvetica, sans-serif" color=#ff0000 size=5>colors <STRONG>sjjhjhds</STRONG></FONT></P>', 20040122115400),
(17, 71, '<P><STRONG>dff</STRONG></P>', 20040122120246),
(18, 80, '$add_desc=str_replace("\'","\'\'",quotemeta($_REQUEST["rte1"]));<BR>', 20040216054115),
(19, 80, 'test $$\r\n', 20040216174343),
(23, 105, '<FONT color=#ff6600>sscc cd c cd cc </FONT>', 20040409202847),
(24, 104, 'hjhjfdjhfdj fdjhhjf fdjhhjfd ', 20040410050743);
# --------------------------------------------------------

#
# Table structure for table `zeeauctions_email_id`
#

DROP TABLE IF EXISTS `zeeauctions_email_id`;
CREATE TABLE `zeeauctions_email_id` (
  `id` bigint(20) NOT NULL auto_increment,
  `fname` varchar(255) default NULL,
  `lname` varchar(255) default NULL,
  `useremail` varchar(255) default NULL,
  `friend_email` longtext,
  `no_of_friends` int(11) default NULL,
  `sid` bigint(20) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_email_id`
#

INSERT INTO `zeeauctions_email_id` (`id`, `fname`, `lname`, `useremail`, `friend_email`, `no_of_friends`, `sid`) VALUES (5, NULL, NULL, 'vv@vv.com', 'friend1@vv.com,friend2@vv.com', 2, 14),
(6, NULL, NULL, 'asasa@www.com', 'sadasd@ww.com,ssss@www.cvom', 2, 14),
(7, NULL, NULL, 'aa@www.com', ',', 2, 14),
(8, NULL, NULL, '23423423', '23423,4234,23423,423423,4234', 5, 14),
(9, 'vikas', 'sharma', 'vik@gg.com', 'friend1@vv.com,friend2@vv.com,friend3@vv.com,friend1@vv.com,friend1@vv.com', 5, 2);
# --------------------------------------------------------

#
# Table structure for table `zeeauctions_favourites`
#

DROP TABLE IF EXISTS `zeeauctions_favourites`;
CREATE TABLE `zeeauctions_favourites` (
  `id` bigint(20) NOT NULL auto_increment,
  `pid` bigint(20) default NULL,
  `uid` bigint(20) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_favourites`
#

INSERT INTO `zeeauctions_favourites` (`id`, `pid`, `uid`) VALUES (6, 23, 8),
(9, 20, 8),
(8, 29, 17),
(10, 69, 12),
(12, 74, 12),
(13, 43, 8),
(14, 108, 15),
(15, 109, 17),
(16, 109, 15);
# --------------------------------------------------------

#
# Table structure for table `zeeauctions_feedback`
#

DROP TABLE IF EXISTS `zeeauctions_feedback`;
CREATE TABLE `zeeauctions_feedback` (
  `id` bigint(20) NOT NULL auto_increment,
  `username` varchar(255) default NULL,
  `rating` varchar(50) default NULL,
  `comment` longtext,
  `by_id` varchar(255) default NULL,
  `pid` bigint(20) default '0',
  `date_submitted` timestamp(14) NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_feedback`
#

INSERT INTO `zeeauctions_feedback` (`id`, `username`, `rating`, `comment`, `by_id`, `pid`, `date_submitted`) VALUES (1, 'viney', 'positive', 'Very Effecient', 'vikas', 63, 20040122134508),
(28, 'viney', 'positive', 'Checked Checked', 'admin', 74, 20040406123135),
(11, 'vikas', 'average', 'soso', 'dddd', 0, 20040122134542),
(13, 'vikas', 'average', 'goodie', 'viney', 0, 20040406110221),
(15, 'viney', 'positive', 'good good goodies11', 'admin', 63, 20040124160427),
(26, 'viney', 'negative', 'What is this???', 'vikas', 43, 20040406110326),
(35, 'viney', 'positive', 'a nice person with a huge listing of products, nice person with a huge listing o', 'admin', 74, 20040410113812),
(37, 'mine', 'positive', 'coooooooooool', 'micx', 106, 20040410153433),
(36, 'vikas', 'positive', 'jhfj', 'admin', 34, 20040410115426),
(40, 'viney', 'positive', 'you are gooooooooooooooooooooood', 'mics', 100, 20040410162503),
(41, 'dddd', 'average', 'by vikas by vikas by vikas ', 'vikas', 43, 20040410165944);
# --------------------------------------------------------

#
# Table structure for table `zeeauctions_forum_ans`
#

DROP TABLE IF EXISTS `zeeauctions_forum_ans`;
CREATE TABLE `zeeauctions_forum_ans` (
  `id` bigint(20) NOT NULL auto_increment,
  `ques_id` bigint(20) default NULL,
  `ans` longtext,
  `uid` bigint(20) default NULL,
  `postedon` timestamp(14) NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_forum_ans`
#

INSERT INTO `zeeauctions_forum_ans` (`id`, `ques_id`, `ans`, `uid`, `postedon`) VALUES (13, 6, '<EM><U>good dfgdf</U></EM>', 0, 20040221211509),
(3, 3, '<P><STRONG><FONT color=#990000>this ffforum is started by viney jdfdc</FONT></STRONG></P>', 1, 20040221211616),
(12, 5, '<P>another111</P>\r\n<P>&nbsp;</P>', 0, 20040221210343),
(14, 3, 'dfgdfgdf', 0, 20040221211604),
(11, 6, 'this is a test gdfgdfg', 0, 20040221211356),
(7, 3, 'jhfds<STRONG>hjkdfhfd<FONT color=#cc0000>js</FONT></STRONG><FONT color=#cc0000> </FONT>', 0, 20040221204944),
(8, 5, 'h<STRONG>jsdfhbfnjfnj 11</STRONG>', 0, 20040221211313),
(15, 5, 'thank you admin!!!', 1, 20040221211858),
(16, 5, 'good', 1, 20040221212105),
(17, 3, 'rthanks everybody', 1, 20040221212147),
(18, 7, 'Kwelllllllll<STRONG><EM><U>llllllllllllllllllllllllllllllll</U></EM></STRONG>', 1, 20040221212215),
(19, 7, 'ftyftyft', 1, 20040221212227),
(20, 8, 'Great test', 1, 20040222023141),
(21, 8, 'Nice', 2, 20040222134941);
# --------------------------------------------------------

#
# Table structure for table `zeeauctions_forum_ques`
#

DROP TABLE IF EXISTS `zeeauctions_forum_ques`;
CREATE TABLE `zeeauctions_forum_ques` (
  `id` bigint(20) NOT NULL auto_increment,
  `uid` bigint(20) default NULL,
  `ques` longtext,
  `can_comment` longtext,
  `postedon` timestamp(14) NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_forum_ques`
#

INSERT INTO `zeeauctions_forum_ques` (`id`, `uid`, `ques`, `can_comment`, `postedon`) VALUES (6, 0, 'Announcements', 'no', 20040221210237),
(3, 1, 'forum1', 'yes', 20040221172909),
(5, 0, 'readonlsy by admin', 'yes', 20040221201419),
(7, 1, 'another forum', 'yes', 20040221212215),
(8, 1, 'Test', 'yes', 20040222023141);
# --------------------------------------------------------

#
# Table structure for table `zeeauctions_images`
#

DROP TABLE IF EXISTS `zeeauctions_images`;
CREATE TABLE `zeeauctions_images` (
  `id` bigint(20) NOT NULL auto_increment,
  `pid` bigint(20) default NULL,
  `url` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_images`
#

INSERT INTO `zeeauctions_images` (`id`, `pid`, `url`) VALUES (5, 19, 'preimage1.gif'),
(4, 19, 'preimage.jpg'),
(6, 21, 'preimage2.gif'),
(7, 22, '615733COINS.jpg'),
(12, 32, '141507star1.gif'),
(13, 33, 'preimage1.gif'),
(14, 34, 'preimage.jpg'),
(15, 35, 'preimage2.gif'),
(16, 36, '615733COINS.jpg'),
(20, 38, '69162166801cell.gif'),
(19, 38, '87094_thehobbit.jpg'),
(21, 38, '633853843924COINS.jpg'),
(22, 38, '721687preimage2.gif'),
(23, 38, '389922141507star1.gif'),
(24, 38, '570466preimage3.jpg'),
(25, 40, '915757preimage1.gif'),
(36, 56, '894683camera.jpg.jpg'),
(37, 56, '762052camera1.jpg.jpg'),
(38, 56, '735992camera2.jpg.jpg'),
(39, 56, '185110camera3.jpg.jpg'),
(34, 48, '260465watchicon.gif'),
(58, 71, '285858iiwarnd4.gif'),
(57, 71, '81978colorize_full.gif'),
(56, 71, '113699a6.gif'),
(53, 71, '706129ct_17.gif'),
(47, 59, '965296connected_data_big.jpg'),
(48, 68, '351466php.gif'),
(49, 63, '877517php.gif'),
(50, 60, '421171wpakey.jpg'),
(52, 70, '321233lvback.gif'),
(59, 71, '541800pen_icon.jpg'),
(62, 100, '853522post_button_right_just.gif'),
(64, 103, '477705a1.gif'),
(65, 104, '672250hwa_25.gif'),
(66, 93, '695097386429camera3.jpg.jpg'),
(68, 111, '128101star1.gif'),
(69, 111, '818176star2.gif'),
(70, 111, '72515star1.gif'),
(71, 111, '729624star2.gif'),
(72, 111, '373002star1.gif'),
(73, 111, '795910star2.gif');
# --------------------------------------------------------

#
# Table structure for table `zeeauctions_mails`
#

DROP TABLE IF EXISTS `zeeauctions_mails`;
CREATE TABLE `zeeauctions_mails` (
  `id` bigint(20) NOT NULL auto_increment,
  `mailid` bigint(20) NOT NULL default '0',
  `fromid` varchar(255) NOT NULL default '',
  `subject` varchar(255) NOT NULL default '',
  `mail` longtext NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_mails`
#

INSERT INTO `zeeauctions_mails` (`id`, `mailid`, `fromid`, `subject`, `mail`) VALUES (2, 2, 'approval@zeeauctions.com', 'Your product has been Approved', 'Hi <fname> <lname>,\r\n\r\nYour product <productname> has been Approved for inclusion on the site.\r\nYou can view this product on <producturl>\r\n\r\nRegards,\r\nAdmin'),
(3, 3, 'disapproval@zeeauctions.com', 'Your product has been disapproved', 'Hi <fname> <lname>,\r\n\r\nYour product <productname> has been disapproved from inclusion on the site.\r\n\r\n\r\nRegards,\r\nAdmin\r\n'),
(4, 4, 'password@zeeauctions.com', 'Your password', 'Hi <fname> <lname>,\r\n\r\nHere is your login information:\r\n\r\nUsername:        <username>\r\nPassword:        <password>\r\nEmail:           <email>\r\n\r\n\r\nThanks for being part of our website.\r\n\r\nRegards,\r\nAdmin\r\nFor login click <loginurl>'),
(1, 1, 'welcome@zeeauctions.com', 'Welcome to zeeauctions.com', 'Hi <fname> <lname>,\r\n\r\nWelcome to zeeauctions.com.\r\n\r\nYour registration information is as follows:\r\n\r\nUsername:        <username>\r\nPassword:        <password>\r\nEmail:           <email>\r\n\r\nThanks for being part of our website.\r\n\r\nRegards,\r\nAdmin\r\nFor login click <loginurl>\r\n'),
(5, 5, 'admin@zeeauctions.com', 'Your product has been Posted', 'Hi <fname> <lname>,\r\n\r\nYour product <productname> has been Posted to our site.You can view this product at <producturl>.\r\n\r\n\r\nRegards,\r\nAdmin'),
(6, 6, 'admin@zeeauctions.com', 'A bid has been placed against your product', 'Hi <fname> <lname>,\r\n\r\nA bid of amount <currentbid> has been placed against your product <productname> from member <bidder_username>.\r\nTotal no of bids <noofbids> \r\n\r\n\r\nRegards,\r\nAdmin'),
(7, 7, 'admin@zeeauctions.com', 'Auction End', 'Hi <fname> <lname>,\r\nYour auction for product <productname> has been expired on <expired_date>.\r\n\r\n\r\nRegards,\r\nAdmin'),
(8, 8, 'admin@zeeauctions.com', 'Message from user.', 'Hi <fname> <lname>,\r\n\r\nYou have been recieved a message\r\nFrom ::  <sender_username>\r\nTitle :: <message_title>\r\nMessage :: <message_text>\r\nTime :: <message_time>\r\nDate :: <message_date>\r\n\r\n\r\nRegards,\r\nAdmin'),
(9, 9, 'admin@zeeauctions.com', 'Auction Winner', 'Hi <fname> <lname>,\r\n\r\nYou have been won the auction for the product <productname>.\r\nYou can order the product through email <seller_email>\r\n\r\nRegards,\r\nAdmin'),
(10, 10, 'admin@zeeauctions.com', 'Auction Closed', 'Hi <fname> <lname>,\r\n\r\nYou have closed the auction for the product <productname>.\r\nYou can contact buyer(s) contact information is as follows:\r\n <contact_information>\r\n\r\nRegards,\r\nAdmin'),
(11, 11, 'admin@zeeauctions.com', 'Auction Looser', 'Hi <fname> <lname>,\r\n\r\nUnfortunately your bid for product <productname> has not been choosed.\r\n\r\nRegards,\r\nAdmin'),
(12, 12, 'admin@zeeauctions.com', 'Purchase Request', 'Hi <fname> <lname>,\r\n\r\nAn order for your product <productname> of quantity <quantity> items @ <amount>  has been placed by <buyer_username>.\r\nYou can contact him/her at <contact_information>.\r\n\r\nRegards,\r\nAdmin'),
(13, 13, 'admin@zeeauctions.com', 'Order Placed', 'Hi <fname> <lname>,\r\n\r\nYour order of quantity <quantity> items @ <amount> of product <productname> has been placed.\r\nYou can contact seller at <seller_email>.\r\n\r\nRegards,\r\nAdmin'),
(14, 14, 'admin@zeeauctions.com', 'outbid mail', 'Hi <fname> <lname>,\r\n\r\nA bid more than your bid for the product <productname> has been placed.\r\n\r\nRegards,\r\nAdmin\r\n'),
(15, 15, 'admin@zeeauctions.com', 'Send Stat Mail', 'Hi \r\n\r\nThere are statistics information regarding your banner display on our site::\r\nBanner ::<bannerurl>\r\nDisplays::<displays>\r\ncredits ::<credits>\r\nbalance ::<balance>\r\n\r\nRegards,\r\nAdmin');
# --------------------------------------------------------

#
# Table structure for table `zeeauctions_member_feedback`
#

DROP TABLE IF EXISTS `zeeauctions_member_feedback`;
CREATE TABLE `zeeauctions_member_feedback` (
  `id` bigint(20) NOT NULL auto_increment,
  `fname` varchar(255) default NULL,
  `lname` varchar(255) default NULL,
  `email` varchar(255) default NULL,
  `url` varchar(255) default NULL,
  `title` varchar(255) default NULL,
  `comment` longtext,
  `uid` bigint(20) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_member_feedback`
#

INSERT INTO `zeeauctions_member_feedback` (`id`, `fname`, `lname`, `email`, `url`, `title`, `comment`, `uid`) VALUES (1, 'ss', 'sss', 'sss', 'ddd', NULL, 'this is try for the submission of members request', 7),
(2, 'fsdfsd', 'fsdfsdf', 'sdfsdf', 'sdfsdf', NULL, 'sdfsdfsdfsdf\r\nsdf\r\nsdf\r\nsdf', 7),
(4, 'ASa', 'sASa', 'sASa', 's', 'asAS', 'asASas\r\nAS\r\nas\r\nASa\r\nsA\r\nSA\r\nS', 7),
(5, 'VVVV', 'FFFFF', 'dddd', 'ddddd', 'ddddd', 'ddddddd', 9),
(6, 'cc', 'cc', 'cc@cv', '', 'title', 'this is no joke', 16),
(7, 'mein', 'hoon', 'kya@hai', '', 'namaste', 'koi nahin', 16),
(11, 'wwww', 'qqqqq', 'qqqq@qq.com', 'qwe', 'qwe', 'fdgdgfd dfg dghf hgd\r\ngdhgd\r\ngdhd\r\ndjd\r\nkjdk', 8);
# --------------------------------------------------------

#
# Table structure for table `zeeauctions_members`
#

DROP TABLE IF EXISTS `zeeauctions_members`;
CREATE TABLE `zeeauctions_members` (
  `id` bigint(20) NOT NULL auto_increment,
  `c_name` varchar(255) default NULL,
  `add1` varchar(255) default NULL,
  `add2` varchar(255) default NULL,
  `city` varchar(255) default NULL,
  `state` varchar(255) default NULL,
  `zip` varchar(50) default NULL,
  `country` varchar(255) default NULL,
  `home_phone` varchar(50) default NULL,
  `email` varchar(255) default NULL,
  `username` varchar(255) default NULL,
  `pwd` varchar(255) default NULL,
  `fname` varchar(255) default NULL,
  `lname` varchar(255) default NULL,
  `work_phone` varchar(50) default NULL,
  `logo_url` varchar(255) default NULL,
  `store_title` varchar(255) default NULL,
  `store_desc` longtext,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_members`
#

INSERT INTO `zeeauctions_members` (`id`, `c_name`, `add1`, `add2`, `city`, `state`, `zip`, `country`, `home_phone`, `email`, `username`, `pwd`, `fname`, `lname`, `work_phone`, `logo_url`, `store_title`, `store_desc`) VALUES (8, 'Evita pvt. ltd.', 'sec 17, barista', 'chandigarh', 'fffff', 'ffff', '123424', '2', 'qweqwe', 'vv@vv.com', 'viney', 'viney', 'viney', 'Singla', 'ssss', '406807Coffee_Bean.bmp', 'Big B\'s Coffee House', '<P><FONT color=#66cccc size=7><STRONG><FONT color=#cc0000>East</FONT> or <FONT color=#cc0000>West</FONT> We r the best</STRONG></FONT></P>'),
(9, '', 'ddddd', '', 'ddd', 'dd', '1233', '1', '1233', 'ddddddd', 'dddd', 'dddd', 'd', 'd', '2233', NULL, NULL, NULL),
(10, 'ss1', 'aa1', 'aa1', 'aa1', 'asdasd1', '111', '1', '1233451', 'aa@ww.com1', 'savvy', 'aaaaa', 'aa1', 'asdas1', '1', NULL, NULL, NULL),
(11, 'ss', 'aa', 'aa', 'aa', 'asdasd', '11', '1', '123345', 'aa@ww.com', 'savvy1', 'aaaa', 'aa', 'asdas', '', NULL, NULL, NULL),
(12, 'dddd', '111 juhu', '', 'bombay', 'mmmmm', '1223', '1', '1223', '', 'vikas', 'vikas', 'vikas', 'sharma', '1122', '712827Gone_Fishing.bmp', 'Yours\' Own Store', '<FONT color=#ff0000><STRONG>1. 2. 3. 4. 5. 6.</STRONG> </FONT>'),
(13, 'dddd', '111 juhu', '', 'bombay', 'mmmmm', '1223', '1', '1223', 'vikk@vik.com', 'vikas1', 'vikas', 'vikas', 'sharma', '1122', NULL, NULL, NULL),
(14, 'dddd', '111 juhu', '', 'bombay', 'mmmmm', '1223', '1', '1223', 'vikk@vik.com', 'vikas2', 'vikas', 'vikas', 'sharma', '1122', NULL, NULL, NULL),
(15, '', 'aa1', '', 'AA', 'AA', '1223', '1', '01890', 'mics@LOCALHOST', 'mics', 'asdfgh', 'mic', 'xing', '', NULL, NULL, NULL),
(17, '', 'm', '', 'm', 'm', '12345678995', '0', '91873045', 'm', 'mine', 'asdfgh', 'm', 'm', '', NULL, NULL, NULL),
(28, 'aaa', 'aaaa', '', 'aaa', 'aaaa', '123aa', '29', '121233', 'asdf@ss.com', 'asdf1', 'asdf', 'asdf', 'aaa', '112232', NULL, NULL, NULL),
(25, 'dfdd', 'fdfdgsdg', '', 'fdfdg', 'fdfdf', '1423re4', '2', '4353tet', 'vin@ss.com', 'vaneet', 'vaneet', 'vaneet', 'gupta', '1233434', NULL, NULL, NULL),
(26, 'vvv', 'vvvv', '', 'vvvv', 'vvvv', 'vv44', '1', '334ee', 'vv@vv.com', 'vvvv', 'vvvv', 'vvv', 'vvvv', '2233', NULL, NULL, NULL),
(31, '', 'asdas', '', 'ads', 'sdas', 'sasa', '5', 'tyty', '2vv@vv.com', 'asdf', 'aaaa', 'asd', 'fdgfd', '', '', '', ''),
(29, '', 'fgdfgsd', '', 'delhi', 'delhi', '111111', '89', '11233', 'vita@vv.com', 'vita', 'vita', 'vita', 'jain', '3653265', '', '', ''),
(32, 'vv', 'vv', 'vv', 'vv', 'vv', 'vv', '89', 'cc', 'vv@vv.com', 'viney2', 'aaaa', 'vv', 'vv', 'ff', '', '', ''),
(33, 'vds', 'vfd', '', 'fd', 'fd', 'df', '13', 'dsf', 'vv@vv.com', 'vinu', 'aaaa', 'viney', 'singla', 'fd', '', '', ''),
(35, 'asas', 'asas', 'asas', 'asas', 'asas', 'asas', '28', 'asas', 'vin@ss.co.in', 'zzzz', 'zzzz', 'as', 'assa', 'asas', '', '', ''),
(36, '', 'kjsajk', '', 'jksakj', 'jj', 'sa2', '1', '12dw23', 'vv@vv1.com', 'vika', 'aaaa', 'dasdf', 'hashj', '', '', '', '');
# --------------------------------------------------------

#
# Table structure for table `zeeauctions_messages`
#

DROP TABLE IF EXISTS `zeeauctions_messages`;
CREATE TABLE `zeeauctions_messages` (
  `id` bigint(20) NOT NULL auto_increment,
  `fid` bigint(20) NOT NULL default '0',
  `tid` bigint(20) NOT NULL default '0',
  `subject` mediumtext NOT NULL,
  `message` longtext NOT NULL,
  `tempdate` timestamp(14) NOT NULL,
  `onstamp` timestamp(14) NOT NULL,
  `msg_read` varchar(10) NOT NULL default '',
  `f_del` varchar(10) NOT NULL default '',
  `t_del` varchar(10) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_messages`
#

INSERT INTO `zeeauctions_messages` (`id`, `fid`, `tid`, `subject`, `message`, `tempdate`, `onstamp`, `msg_read`, `f_del`, `t_del`) VALUES (28, 8, 9, 'nbcnbcbnv hvcnv  hvh hvcn', 'vcnjvcn vcjnvc nbvcbnvc vcnbbnvc vcbnnbvc vcbnvcbnvcbncv ', 20040409194033, 20040409073705, 'Yes', 'No', 'No'),
(4, 8, 9, 'fdgfdghsdhghdsf', 'e\r\nfds\r\ndf\r\nsdf\r\nsd\r\nfs\r\ndfs', 20040206175256, 20040102055109, 'Yes', 'yes', 'No'),
(11, 8, 12, 'urgent', 'fdsgsdfgsdfgsd', 20040129123434, 20040103020545, 'Yes', 'yes', 'No'),
(8, 8, 12, 'urgent', 'fdsgsdfgsdfgsd', 20040103140622, 20040103020305, 'No', 'yes', 'No'),
(12, 8, 9, 'to dddd', 'grghdfgdghdfj', 20040206175256, 20040103020701, 'Yes', 'yes', 'No'),
(32, 16, 15, 'fisrt to mics kya hua', 'fisrt to mics kya hua', 20040410155926, 20040410034906, 'Yes', 'yes', 'No'),
(30, 16, 17, 'first msg to mine', 'first msg to mine', 20040410155926, 20040410034739, 'Yes', 'yes', 'No'),
(20, 8, 9, 'uhuh', 'iuyghuygyg', 20040129135123, 20040205104022, 'No', 'yes', 'No'),
(22, 9, 8, 'dddd', 'ddddd', 20040129134523, 20040205120816, 'No', 'No', 'yes'),
(23, 9, 8, 'Re:ddddd', 'MESSAGE:: ddddddddddddddddddddd', 20040206175250, 20040205120930, 'No', 'No', 'yes'),
(24, 9, 8, 'Re:ddddd', 'MESSAGE:: ddddddddddddddddddddd', 20040409183637, 20040205121020, 'Yes', 'No', 'yes'),
(25, 8, 9, 'Re:Re:ddddd', 'MESSAGE:: MESSAGE:: ddddddddddddddddddddd', 20040409193850, 20040206055323, 'No', 'yes', 'No'),
(34, 12, 8, 'Re:MESSAGE:: fdsgsdfgsdfgsdMESSAGE:: fdsgsdfgsdfgsdMESSAGE:: fdsgsdfgsdfgsdurgent', 'MESSAGE:: fdsgsdfgsdfgsd', 20040410170114, 20040410050114, 'No', 'No', 'No'),
(35, 12, 15, 'sdjfxn', 'vccvcvvc', 20040410171246, 20040410051246, 'No', 'No', 'No');
# --------------------------------------------------------

#
# Table structure for table `zeeauctions_plans`
#

DROP TABLE IF EXISTS `zeeauctions_plans`;
CREATE TABLE `zeeauctions_plans` (
  `id` bigint(20) NOT NULL auto_increment,
  `credits` bigint(20) NOT NULL default '0',
  `price` bigint(20) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_plans`
#

INSERT INTO `zeeauctions_plans` (`id`, `credits`, `price`) VALUES (8, 1000, 7),
(7, 10000, 36),
(6, 5000, 20);
# --------------------------------------------------------

#
# Table structure for table `zeeauctions_products`
#

DROP TABLE IF EXISTS `zeeauctions_products`;
CREATE TABLE `zeeauctions_products` (
  `id` bigint(20) NOT NULL auto_increment,
  `uid` bigint(20) NOT NULL default '0',
  `product_name` varchar(255) default NULL,
  `cid` bigint(20) default NULL,
  `aucid` bigint(20) default NULL,
  `auction_period` varchar(255) default NULL,
  `featured` varchar(10) default NULL,
  `approved` varchar(10) default NULL,
  `tmpdate` timestamp(14) NOT NULL,
  `date_submitted` timestamp(14) NOT NULL,
  `date_closed` timestamp(14) NOT NULL,
  `product_desc` longtext,
  `quantity` bigint(20) default NULL,
  `location` varchar(255) default NULL,
  `bid_inc` decimal(10,2) default NULL,
  `min_bid` decimal(10,2) default NULL,
  `no_of_views` bigint(20) default NULL,
  `ship_cost` decimal(10,2) default NULL,
  `who_pay_sc` varchar(255) default NULL,
  `status` varchar(255) default NULL,
  `winner` varchar(255) default NULL,
  `bold` varchar(10) default NULL,
  `highlight` varchar(10) default NULL,
  `purchased_images` int(10) default '0',
  `fp_featured` varchar(10) default NULL,
  `gallery_featured` varchar(10) default NULL,
  `auto_list` int(11) default '0',
  `done` int(11) default '0',
  `paypal_id` varchar(255) default NULL,
  `counter_id` bigint(20) default '0',
  `reserve_price` decimal(10,2) default '0.00',
  `buy_price` decimal(10,2) default '0.00',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_products`
#

INSERT INTO `zeeauctions_products` (`id`, `uid`, `product_name`, `cid`, `aucid`, `auction_period`, `featured`, `approved`, `tmpdate`, `date_submitted`, `date_closed`, `product_desc`, `quantity`, `location`, `bid_inc`, `min_bid`, `no_of_views`, `ship_cost`, `who_pay_sc`, `status`, `winner`, `bold`, `highlight`, `purchased_images`, `fp_featured`, `gallery_featured`, `auto_list`, `done`, `paypal_id`, `counter_id`, `reserve_price`, `buy_price`) VALUES (21, 12, 'A Super Product', 7, 1, '180', 'yes', 'yes', 20040429205302, 20040205114732, 20040429205302, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 12, 'aaa', '1.00', '12.00', 34, '0.00', 'seller', 'closed', '16', 'no', 'no', 0, 'no', 'no', 0, 0, NULL, 0, '0.00', '0.00'),
(44, 12, 'Family Game', 14, 3, '180', 'no', 'yes', 20040429205302, 20040208030551, 20040429205302, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 123, 'sss', '0.00', '145.00', 6, '0.00', 'seller', 'closed', '0', 'no', 'no', 0, 'no', 'no', 0, 0, NULL, 0, '0.00', '0.00'),
(45, 12, 'Pen For writing', 14, 4, '180', 'no', 'yes', 20040429205302, 20040208033315, 20040429205302, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 25, 'dddd', '0.00', '200.00', 3, '0.00', 'seller', 'closed', '0', 'no', 'no', 0, 'no', 'no', 0, 0, NULL, 0, '0.00', '0.00'),
(46, 8, 'Graphics Card', 11, 1, '180', 'no', 'yes', 20040417212938, 20040208052104, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 10, 'india', '5.00', '12.00', 30, '12.00', 'buyer', 'open', '0', 'no', 'no', 0, 'no', 'no', 0, 0, NULL, 0, '0.00', '0.00'),
(38, 8, 'sleeping bags', 13, 2, '180', 'no', 'yes', 20040429205302, 20040206054200, 20040429205302, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 125, 'India', '100.00', '900.00', 40, '12.00', 'buyer', 'closed', '14,9,12', 'no', 'no', 0, 'no', 'no', 0, 0, NULL, 0, '0.00', '0.00'),
(39, 8, 'Vacume Cleaner', 14, 1, '180', 'yes', 'yes', 20040429205302, 20040206064317, 20040429205302, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 122, 'aa', '1.00', '12.00', 6, '0.00', 'seller', 'closed', '9', 'no', 'no', 0, 'no', 'no', 0, 0, NULL, 0, '0.00', '0.00'),
(40, 8, 'Vacume Bags', 14, 1, '180', 'yes', 'yes', 20040417212959, 20040206064351, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 122, 'aa', '1.00', '12.00', 19, '0.00', 'seller', 'canceled', '0', 'no', 'no', 0, 'no', 'no', 0, 0, NULL, 0, '0.00', '0.00'),
(32, 12, 'Classic Statue', 9, 1, '180', 'yes', 'yes', 20040417213008, 20040205114732, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 12, 'aaa', '1.00', '12.00', 22, '0.00', 'seller', 'open', '0', 'no', 'no', 0, 'no', 'no', 0, 0, NULL, 0, '0.00', '0.00'),
(33, 12, 'Easy Chair', 3, 1, '180', 'yes', 'yes', 20040429205302, 20040205114732, 20040429205302, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 12, 'aaa', '1.00', '12.00', 19, '0.00', 'seller', 'closed', '9', 'no', 'no', 0, 'no', 'no', 0, 0, NULL, 0, '0.00', '0.00'),
(34, 12, 'Round Table', 3, 1, '180', 'yes', 'yes', 20040417213027, 20040205114732, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 12, 'aaa', '1.00', '12.00', 13, '0.00', 'seller', 'open', '0', 'no', 'no', 0, 'no', 'no', 0, 0, NULL, 0, '0.00', '0.00'),
(35, 12, 'Silver Spoon', 9, 1, '180', 'no', 'yes', 20040417213037, 20040205114732, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 12, 'aaa', '1.00', '12.00', 7, '0.00', 'seller', 'canceled', '0', 'no', 'no', 0, 'no', 'no', 0, 0, NULL, 0, '0.00', '0.00'),
(47, 8, 'Gold and Jewels', 12, 4, '180', 'yes', 'yes', 20040417213053, 20040208052213, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 5, 'india', '0.00', '1200.00', 13, '12.00', 'buyer', 'open', '0', 'no', 'no', 0, 'no', 'no', 0, 0, NULL, 0, '0.00', '0.00'),
(43, 12, 'Marketing Ebook', 14, 3, '180', 'yes', 'yes', 20040417213144, 20040208014218, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 123, 'dddd', '0.00', '123.00', 51, '0.00', 'seller', 'open', '0', 'no', 'yes', 0, 'no', 'no', 0, 0, NULL, 0, '0.00', '0.00'),
(42, 8, 'Soccer Ball', 10, 3, '180', 'no', 'yes', 20040417213206, 20040207074649, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 12, 'qq', '0.00', '123.00', 45, '12.00', 'seller', 'open', '0', 'no', 'no', 0, 'no', 'no', 0, 0, NULL, 0, '0.00', '0.00'),
(48, 8, 'CD Cover', 14, 1, '180', 'no', 'yes', 20040417213310, 20040205052518, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 10, 'sssss', '10.00', '120.00', 11, '12.00', 'seller', 'open', '0', 'no', 'no', 0, 'no', 'no', 0, 0, NULL, 0, '0.00', '0.00'),
(49, 8, 'Photo Album', 14, 1, '180', 'no', 'yes', 20040417213241, 20040208063208, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 123, '\'', '12.00', '123.00', 5, '0.00', 'seller', 'open', '0', 'no', 'no', 0, 'no', 'no', 0, 0, NULL, 0, '0.00', '0.00'),
(56, 8, 'Digital camera', 7, 1, '180', 'yes', 'yes', 20040430004839, 20040210114358, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 10, 'NY', '20.00', '300.00', 51, '10.00', 'buyer', 'open', '0', 'yes', 'yes', 6, 'yes', 'yes', 0, 0, NULL, 0, '0.00', '0.00'),
(59, 8, 'Multimedia Keyboard', 7, 1, '180', 'yes', 'yes', 20040417224848, 20040212043339, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 1200, 'India', '5.00', '10.00', 12, '0.00', 'buyer', 'open', '0', 'yes', 'yes', 0, 'yes', 'no', 0, 0, NULL, 0, '0.00', '0.00'),
(60, 8, 'Diamond Pen', 9, 1, '180', 'yes', 'yes', 20040417213323, 20040212044802, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 20, 'DEN', '2.00', '10.00', 44, '10.00', 'buyer', 'open', '0', 'no', 'no', 0, 'yes', 'no', 0, 0, NULL, 0, '0.00', '0.00'),
(61, 8, 'Golden Keys', 9, 1, '180', 'yes', 'yes', 20040417213335, 20040212062452, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 10, 'ind', '1.00', '10.00', 11, '10.00', 'buyer', 'open', '0', 'yes', 'yes', 0, 'yes', 'yes', 0, 0, NULL, 0, '0.00', '0.00'),
(62, 8, 'Duplicate Keys', 14, 1, '180', 'yes', 'yes', 20040417213349, 20040212062624, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 12, 'sss', '2.00', '12.00', 6, '10.00', 'buyer', 'open', '0', 'yes', 'no', 0, 'yes', 'no', 0, 0, NULL, 0, '0.00', '0.00'),
(63, 8, 'Ice Box', 14, 1, '180', 'no', 'yes', 20040429205302, 20040213100140, 20040429205302, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 12, 'NY', '4.00', '11.00', 75, '11.00', 'buyer', 'closed', '12', 'no', 'no', 0, 'yes', 'yes', 1, 0, NULL, 0, '0.00', '0.00'),
(64, 8, 'HP Printer', 14, 4, '180', 'no', 'yes', 20040417213508, 20040213023349, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 10, '12', '0.00', '1234.00', 9, '10.00', 'buyer', 'open', '0', 'no', 'no', 0, 'yes', 'yes', 2, 2, '', 0, '0.00', '0.00'),
(65, 8, 'Juice Maker', 14, 3, '180', 'no', 'yes', 20040417213527, 20040213024603, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 12, 'aaa', '0.00', '12.00', 9, '12.00', 'buyer', 'open', '0', 'no', 'no', 0, 'no', 'no', 3, 0, 'aaa@aa.com', 0, '0.00', '0.00'),
(68, 8, 'Wrist Watch', 14, 2, '180', 'no', 'yes', 20040429205302, 20040213030553, 20040429205302, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 12, 'india', '10.00', '12.00', 2834, '10.00', 'buyer', 'closed', '27,9', 'no', 'no', 0, 'yes', 'no', 3, 0, 'dddd@dd.com', 2, '0.00', '0.00'),
(69, 8, 'Spotless Mirror', 14, 2, '180', 'no', 'yes', 20040417213608, 20040214050322, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 110, 'ind', '6.00', '12.00', 55148, '0.00', 'buyer', 'open', '12,27', 'no', 'no', 0, 'yes', 'no', 3, 2, '', 1, '0.00', '0.00'),
(70, 8, 'Coffee Maker', 11, 4, '180', 'no', 'yes', 20040417224836, 20040214060700, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 10, 'Delhi-India', '500.00', '5000.00', 43, '10.00', 'buyer', 'open', '0', 'no', 'no', 0, 'yes', 'no', 3, 2, 'yours@yours.com', 1, '0.00', '0.00'),
(71, 8, 'Health Jeans', 13, 1, '180', 'no', 'yes', 20040430113506, 20040122120102, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 12, 'dsdsf', '1.00', '12.00', 25, '0.00', 'buyer', 'open', '0', 'no', 'no', 3, 'yes', 'no', 2, 2, '', 0, '0.00', '0.00'),
(73, 8, 'Popup Toaster', 14, 1, '180', 'no', 'yes', 20040429205302, 20040124071029, 20040429205302, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 11, 'aa', '1.00', '12.00', 8, '0.00', 'seller', 'closed', '12', 'no', 'no', 0, 'no', 'no', 2, 0, '', 1, '20.00', '0.00'),
(74, 8, 'Designer Watch', 14, 3, '180', 'no', 'yes', 20040417215123, 20040124083953, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 12, 'aa', '0.00', '20.00', 26, '12.00', 'seller', 'open', '0', 'yes', 'no', 0, 'no', 'yes', 0, 0, 'pay1@paaa.com', 2, '0.00', '0.00'),
(75, 8, 'Speakers', 14, 1, '180', 'no', 'yes', 20040417213727, 20040216043604, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 5, 'india', '5.00', '25.00', 0, '0.00', 'seller', 'open', '0', 'no', 'no', 0, 'no', 'no', 0, 0, '', 0, '0.00', '0.00'),
(76, 8, 'Classic Painting', 14, 3, '180', 'yes', 'yes', 20040417213756, 20040216043741, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 25, 'INDIA', '2.00', '5.00', 6, '0.00', 'seller', 'open', '0', 'yes', 'no', 0, 'no', 'no', 0, 0, '', 0, '0.00', '0.00'),
(77, 8, 'Pitch Roller', 14, 1, '180', 'no', 'yes', 20040417213817, 20040216043927, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 25, 'ewr', '5.00', '5.00', 0, '0.00', 'seller', 'open', '0', 'no', 'no', 0, 'no', 'no', 0, 0, '', 0, '0.00', '0.00'),
(78, 8, 'Fashion Gear', 14, 1, '180', 'no', 'yes', 20040417213841, 20040216050841, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 25, 'ewr', '5.00', '5.00', 1, '0.00', 'seller', 'open', '0', 'no', 'no', 0, 'no', 'no', 0, 0, '', 0, '0.00', '0.00'),
(79, 8, 'Car Graphics', 14, 2, '180', 'no', 'yes', 20040417213854, 20040216052528, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 25, 'INDIA', '5.00', '5.00', 0, '0.00', 'seller', 'open', '0', 'no', 'no', 0, 'no', 'no', 0, 0, '', 1, '0.00', '0.00'),
(80, 8, 'Car Accessories', 14, 2, '180', 'no', 'yes', 20040417213913, 20040216052638, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 25, 'INDIA', '5.00', '25.00', 1, '0.00', 'seller', 'open', '0', 'no', 'no', 0, 'no', 'no', 0, 0, '', 0, '100.00', '0.00'),
(81, 8, 'Table and Chair', 14, 1, '180', 'no', 'yes', 20040417212105, 20040217121129, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 44, '34534', '5.00', '35.00', 0, '0.00', 'seller', 'open', '0', 'no', 'no', 0, 'no', 'no', 0, 0, '', 2, '55.00', '0.00'),
(82, 8, 'Test Pin', 14, 2, '180', 'no', 'yes', 20040417212116, 20040217053443, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 25, 'dsfsd', '5.00', '25.00', 3, '0.00', 'seller', 'open', '0', 'no', 'no', 0, 'no', 'no', 0, 0, '', 0, '0.00', '0.00'),
(83, 8, 'Telephone Set', 14, 3, '180', 'no', 'yes', 20040417212125, 20040217063427, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 25, 'asdas', '5.00', '25.00', 1, '25.00', 'seller', 'open', '0', 'no', 'no', 0, 'no', 'no', 0, 0, '', 1, '5.00', '0.00'),
(84, 8, 'Mobile Phine', 14, 2, '180', 'no', 'yes', 20040417212134, 20040217063514, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 25, 'fdgdfgd', '5.00', '35.00', 1, '5.00', 'seller', 'open', '0', 'no', 'no', 0, 'no', 'no', 3, 3, '', 2, '5.00', '0.00'),
(85, 8, 'Computer P4 2.8', 14, 2, '180', 'no', 'yes', 20040417212159, 20040217063711, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 35, ';lkl;', '5.00', '5.00', 0, '0.00', 'seller', 'open', '0', 'no', 'no', 0, 'no', 'no', 0, 0, '', 0, '0.00', '0.00'),
(87, 8, 'Wireless Handset', 14, 1, '180', 'no', 'yes', 20040417212217, 20040217103548, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 25, 'INDIA', '5.00', '5.00', 1, '0.00', 'seller', 'open', '0', 'no', 'no', 0, 'no', 'no', 0, 0, '', 0, '0.00', '0.00'),
(88, 8, 'Joke Machine', 14, 2, '180', 'no', 'yes', 20040417212229, 20040217110336, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 24, 'sdf', '5.00', '25.00', 1, '0.00', 'seller', 'open', '0', 'no', 'no', 0, 'no', 'no', 0, 0, '', 0, '6.00', '0.00'),
(89, 8, 'Money Multiplier', 11, 1, '180', 'no', 'yes', 20040417212246, 20040217111609, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 24, 'ind', '25.00', '25.00', 2, '0.00', 'seller', 'open', '0', 'no', 'no', 0, 'no', 'no', 0, 0, '', 0, '5.00', '0.00'),
(90, 8, 'Ultimate bike', 11, 4, '180', 'no', 'yes', 20040417212317, 20040217111943, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 25, 'asdas', '5.00', '5.00', 0, '5.00', 'seller', 'open', '0', 'no', 'no', 0, 'no', 'no', 0, 0, '', 0, '55.00', '0.00'),
(91, 8, 'Luxury Car', 12, 4, '180', 'no', 'yes', 20040417212334, 20040217112352, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 23, 'wdfsdf', '5.00', '5.00', 4, '34.00', 'seller', 'open', '0', 'no', 'no', 0, 'no', 'no', 0, 0, '', 0, '5.00', '0.00'),
(92, 8, 'NotStop Music CDs', 11, 2, '180', 'no', 'yes', 20040417212350, 20040217115658, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 25, 'india', '5.00', '25.00', 1, '0.00', 'seller', 'open', '0', 'no', 'no', 0, 'no', 'no', 0, 0, '', 0, '5.00', '0.00'),
(93, 8, 'DVD Player', 11, 1, '180', 'no', 'yes', 20040430104950, 20040218122937, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 25, 'INDIA', '5.00', '25.00', 10, '0.00', 'seller', 'open', '0', 'no', 'no', 0, 'yes', 'no', 0, 0, 'dddd@dd.com', 0, '2.00', '123.00'),
(97, 8, 'Cooling Solution', 14, 1, '180', 'yes', 'yes', 20040417212428, 20040407020215, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 123, 'Delhi-India', '12.00', '1234.00', 15, '123.00', 'buyer', 'open', '0', 'no', 'no', 0, 'no', 'no', 3, 0, 'zeeauctions@rediffmail.com', 1, '1600.00', '0.00'),
(94, 8, 'PC Monitor', 14, 1, '180', 'yes', 'yes', 20040429205302, 20040406052501, 20040429205302, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 123, 'Delhi-India', '11.00', '1234.00', 10, '124.00', 'buyer', 'closed', '12', 'no', 'no', 0, 'yes', 'no', 3, 0, 'zeeauctions@rediffmail.com', 0, '1900.00', '0.00'),
(96, 8, 'Slim Laptop', 14, 3, '180', 'no', 'yes', 20040417212520, 20040407123002, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 1234, 'Delhi-India', '10.00', '1100.00', 16, '0.00', 'seller', 'open', '0', 'no', 'no', 0, 'no', 'no', 3, 0, 'zeeauctions@rediffmail.com', 1, '1600.00', '0.00'),
(99, 8, 'Free Tshirts', 14, 2, '180', 'no', 'yes', 20040429205302, 20040407042320, 20040429205302, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 123, 'AZ', '1.00', '1234.00', 13, '0.00', 'seller', 'closed', '9,12', 'no', 'no', 0, 'no', 'no', 1, 0, '', 2, '2000.00', '0.00'),
(100, 8, 'proviney3', 9, 1, '180', 'no', 'yes', 20040429205302, 20040407045129, 20040429205302, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 123, 'qwe', '12.00', '1234.00', 87, '0.00', 'seller', 'closed', '15', 'no', 'no', 0, 'yes', 'yes', 2, 0, '', 0, '12334.00', '0.00'),
(101, 8, 'WYSIWYG Editor', 9, 1, '180', 'no', 'yes', 20040417212555, 20040407045131, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 123, 'qwe', '12.00', '1234.00', 11, '0.00', 'seller', 'open', '0', 'yes', 'no', 0, 'no', 'yes', 2, 0, '', 0, '12334.00', '0.00'),
(102, 8, 'The Money Machine', 14, 3, '180', 'yes', 'yes', 20040417225225, 20040407052322, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 1223, 'DEN', '9.00', '1224.00', 8, '0.00', 'seller', 'open', '0', 'no', 'no', 0, 'no', 'no', 2, 1, '', 0, '0.00', '0.00'),
(103, 12, 'FUN Game', 20, 1, '180', 'no', 'yes', 20040429221918, 20040408122713, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 123, '1223', '11.00', '2500.00', 33, '0.00', 'seller', 'open', '0', 'no', 'no', 0, 'yes', 'yes', 2, 0, '', 2, '5000.00', '0.00'),
(104, 12, '104-Key Keyboard', 20, 2, '180', 'no', 'yes', 20040417212658, 20040408123207, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 1233, 'Delhi-India', '12.00', '2500.00', 13, '12.00', 'buyer', 'open', '0', 'no', 'no', 0, 'no', 'yes', 3, 0, '', 2, '6000.00', '0.00'),
(105, 8, 'Emulate Monkey', 7, 2, '180', 'no', 'no', 20040417212856, 20040409055704, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 123, 'B', '0.50', '1.00', 6, '0.00', 'seller', 'open', '0', 'no', 'no', 0, 'yes', 'yes', 0, 0, '', 0, '0.00', '0.00'),
(111, 8, 'Funky Dresses', 3, 3, '180', 'no', 'yes', 20040417212839, 20040410045235, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 122, 'qwe', '0.00', '1234.00', 4, '0.00', 'seller', 'open', '0', 'no', 'no', 3, 'no', 'no', 0, 0, '', 0, '0.00', '0.00'),
(112, 8, 'Affiliate Opportunity', 9, 1, '180', 'no', 'yes', 20040417212816, 20040417043929, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 25, 'INDIA', '25.00', '2500.00', 2, '0.00', 'seller', 'open', '0', 'no', 'no', 0, 'no', 'no', 0, 0, 'dummy@dummy.com', 0, '0.00', '15.00'),
(113, 8, 'Cool Game', 3, 4, '180', 'no', 'yes', 20040417212802, 20040417044522, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 25, 'india', '50.00', '5.00', 7, '0.00', 'seller', 'open', '0', 'no', 'no', 0, 'no', 'no', 0, 0, 'dummy@www.com', 0, '0.00', '70.00'),
(114, 8, 'Styler Wears', 3, 1, '1', 'no', 'yes', 20040417224840, 20040417090323, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 25, 'sdfsd', '3.00', '5.00', 2, '0.00', 'seller', 'open', '0', 'no', 'no', 0, 'no', 'no', 0, 0, '', 0, '0.00', '0.00'),
(115, 8, 'Super Game', 3, 2, '1', 'no', 'yes', 20040417212053, 20040417090420, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 25, 'fff', '5.00', '25.00', 1, '5.00', 'seller', 'open', '0', 'no', 'no', 0, 'no', 'no', 0, 0, '', 0, '0.00', '0.00'),
(117, 8, 'Mobile phone', 3, 4, '1', 'no', 'yes', 20040417212713, 20040417090551, 00000000000000, '<p><font color="#FF0000" size="5" face="Times New Roman, Times, serif"><br> This is sample description of the product.</font></p> <p><font color="#0066FF" size="2" face="Arial, Helvetica, sans-serif">It can be formatted in a great way</font><font color="#0000FF">!</font><font color="#003399">!</font><font color="#333333">!</font></p> <p><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">T</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">H</font><font color="#009966" size="4" face="Arial, Helvetica, sans-serif">I</font><font color="#FF00FF" size="4" face="Arial, Helvetica, sans-serif">S</font><font color="#FF00FF" size="4"> </font> <font color="#0000FF" size="4" face="Verdana, Arial, Helvetica, sans-serif">Auctions <font size="5" face="Arial, Helvetica, sans-serif">Script is </font></font><font size="5" face="Arial, Helvetica, sans-serif">highly FLEXIBLE !!</font></p> <p><font size="5" face="Arial, Helvetica, sans-serif">It <font color="#FF0000">will</font> <font color="#0000FF">Make</font> you <font color="#009933">really</font>......</font></p> <p><font size="+6" face="Times New Roman, Times, serif"><strong><font color="#996600">:</font></strong><font color="#0000FF" size="7">-</font><font color="#FF0000">)</font></font></p> <p>&nbsp;</p>', 25, 'aaa', '5.00', '25.00', 0, '0.00', 'seller', 'open', '0', 'no', 'no', 0, 'no', 'no', 0, 0, '', 0, '0.00', '0.00'),
(118, 8, 'Quality Product', 12, 1, '1', 'no', 'yes', 20040417225109, 20040417091322, 00000000000000, '<P><FONT face="Times New Roman, Times, serif" color=#ff0000 size=5><BR>This is sample description of the product.</FONT></P>\r\n<P><FONT face="Arial, Helvetica, sans-serif" color=#0066ff size=2>It can be formatted in a great way</FONT><FONT color=#0000ff>!</FONT><FONT color=#003399>!</FONT><FONT color=#333333>!</FONT></P>\r\n<P><FONT face="Arial, Helvetica, sans-serif" color=#009966 size=4>T</FONT><FONT face="Arial, Helvetica, sans-serif" color=#ff00ff size=4>H</FONT><FONT face="Arial, Helvetica, sans-serif" color=#009966 size=4>I</FONT><FONT face="Arial, Helvetica, sans-serif" color=#ff00ff size=4>S</FONT><FONT color=#ff00ff size=4> </FONT><FONT face="Verdana, Arial, Helvetica, sans-serif" color=#0000ff size=4>Auctions <FONT face="Arial, Helvetica, sans-serif" size=5>Script is </FONT></FONT><FONT face="Arial, Helvetica, sans-serif" size=5>highly FLEXIBLE !!</FONT></P>\r\n<P><FONT face="Arial, Helvetica, sans-serif" size=5>It <FONT color=#ff0000>will</FONT> <FONT color=#0000ff>Make</FONT> you <FONT color=#009933>really</FONT>......</FONT></P>\r\n<P><FONT face="Times New Roman, Times, serif" size=+6><STRONG><FONT color=#996600>:</FONT></STRONG><FONT color=#0000ff size=7>-</FONT><FONT color=#ff0000>)</FONT></FONT></P>\r\n<P>&nbsp;</P>', 25, 'CA,US', '5.00', '25.00', 1, '5.00', 'seller', 'open', '0', 'yes', 'no', 0, 'no', 'no', 0, 0, '', 0, '0.00', '0.00');
# --------------------------------------------------------

#
# Table structure for table `zeeauctions_purchased`
#

DROP TABLE IF EXISTS `zeeauctions_purchased`;
CREATE TABLE `zeeauctions_purchased` (
  `id` bigint(20) NOT NULL auto_increment,
  `pid` bigint(20) default NULL,
  `uid` bigint(20) default NULL,
  `quantity` bigint(20) default NULL,
  `date_submitted` timestamp(14) NOT NULL,
  `email` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_purchased`
#

INSERT INTO `zeeauctions_purchased` (`id`, `pid`, `uid`, `quantity`, `date_submitted`, `email`) VALUES (15, 42, 9, 10, 20040212131755, 'ddddddd'),
(23, 42, 27, 10, 20040213033522, 'har@har.com'),
(14, 43, 9, 15, 20040212131735, 'ddddddd'),
(13, 43, 8, 12, 20040212131724, 'vv@vv.com'),
(12, 42, 12, 12, 20040212131537, 'vikk@vik.com'),
(11, 42, 12, 10, 20040212131526, 'vikk@vik.com'),
(19, 43, 8, 12, 20040212114221, 'vv@vv.com'),
(22, 65, 27, 1, 20040213032206, 'har@har.com'),
(21, 43, 8, 11, 20040212034028, 'vv@vv.com'),
(24, 42, 27, 10, 20040213034450, 'har@har.com'),
(25, 74, 12, 10, 20040124084044, 'vikk@vik.com'),
(31, 108, 17, 7, 20040410034147, 'm'),
(30, 108, 15, 3, 20040410034122, 'mics@LOCALHOST'),
(29, 74, 9, 12, 20040124085018, 'ddddddd');
# --------------------------------------------------------

#
# Table structure for table `zeeauctions_ratings`
#

DROP TABLE IF EXISTS `zeeauctions_ratings`;
CREATE TABLE `zeeauctions_ratings` (
  `id` bigint(20) NOT NULL auto_increment,
  `sid` bigint(20) default NULL,
  `rating` int(11) default NULL,
  `ip` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_ratings`
#

INSERT INTO `zeeauctions_ratings` (`id`, `sid`, `rating`, `ip`) VALUES (1, 1, 10, NULL),
(2, 2, 5, NULL),
(3, 3, 7, NULL),
(4, 1, 5, NULL),
(5, 14, 5, '127.0.0.1'),
(15, 14, 7, '127.0.0.1'),
(14, 14, 6, '127.0.0.1'),
(13, 2, 9, '127.0.0.1'),
(16, 14, 10, '127.0.0.1'),
(17, 14, 5, '127.0.0.1');
# --------------------------------------------------------

#
# Table structure for table `zeeauctions_transactions`
#

DROP TABLE IF EXISTS `zeeauctions_transactions`;
CREATE TABLE `zeeauctions_transactions` (
  `id` bigint(20) NOT NULL auto_increment,
  `uid` bigint(20) default NULL,
  `amount` decimal(10,2) default NULL,
  `date_submitted` timestamp(14) NOT NULL,
  `description` longtext,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_transactions`
#

INSERT INTO `zeeauctions_transactions` (`id`, `uid`, `amount`, `date_submitted`, `description`) VALUES (5, 27, '5.00', 20040209120054, 'Added Money To Your Account'),
(4, 27, '10.00', 20040209120003, 'Sign Up Bonus'),
(3, 8, '20.00', 20040209113805, 'Added Money To Your Account'),
(6, 27, '20.00', 20040209012844, 'Added Money To Your Account'),
(7, 27, '-22.00', 20040209015459, 'Made Your Product notfeatured to be Appeared as Bold'),
(8, 27, '-7.00', 20040209015459, 'Made Your Product notfeatured to be Appeared as Highlighted'),
(9, 27, '-2.00', 20040209020732, 'Made Your Product \'make bold\' to be Appeared as Bold'),
(10, 8, '-2.00', 20040210114357, 'Made Your Product \'Digital camera\' to be Appeared as Bold'),
(11, 8, '-5.00', 20040210114358, 'Made Your Product \'Digital camera\' to be Appeared as Featured'),
(12, 8, '-7.00', 20040210114358, 'Made Your Product \'Digital camera\' to be Appeared as Highlighted'),
(19, 8, '-5.00', 20040210011537, 'Purchased 3 images for Product \'Digital camera\'.'),
(18, 8, '2.00', 20040210011514, 'Added Money To Your Account'),
(17, 8, '-5.00', 20040210010335, 'Purchased 3 images for Product \'Digital camera\'.'),
(16, 8, '2.00', 20040210122928, 'Added Money To Your Account'),
(20, 27, '-2.00', 20040210081341, 'Made Your Product \'abc\' to be Appeared as Bold'),
(21, 27, '60.00', 20040210081454, 'Added Money To Your Account'),
(22, 27, '0.00', 20040210081533, 'Added Money To Your Account'),
(23, 27, '-5.00', 20040210081841, 'Purchased 3 images for Product \'abc\'.'),
(24, 27, '1.00', 20040210083024, 'Added Money To Your Account'),
(25, 27, '-5.00', 20040210083155, 'Made Your Product \'bb\' to be Appeared as Featured'),
(26, 27, '-7.00', 20040210083155, 'Made Your Product \'bb\' to be Appeared as Highlighted'),
(27, 28, '10.00', 20040212121536, 'Sign Up Bonus'),
(28, 8, '20.00', 20040212040032, 'Added Money To Your Account'),
(29, 8, '-2.00', 20040212043339, 'Made Your Product \'keyboard\' to be Appeared as Bold'),
(30, 8, '-5.00', 20040212043339, 'Made Your Product \'keyboard\' to be Appeared as Featured'),
(31, 8, '-5.00', 20040212043339, 'Made Your Product \'keyboard\' to be Appeared  as   Featured on Front Page'),
(32, 8, '-7.00', 20040212043339, 'Made Your Product \'keyboard\' to be Appeared as Highlighted'),
(33, 8, '20.00', 20040212053630, 'Added Money To Your Account'),
(34, 8, '-2.00', 20040212062624, 'Made Your Product \'keys2\' to be Appeared as Bold'),
(35, 8, '-5.00', 20040212062624, 'Made Your Product \'keys2\' to be Appeared as Featured'),
(36, 8, '-5.00', 20040212062624, 'Made Your Product \'keys2\' to be Appeared  as   Featured on Front Page'),
(37, 8, '-5.00', 20040212062624, 'Made Your Product \'keys2\' to be Appeared as Featured in Gallery '),
(38, 8, '-3.00', 20040212081706, 'Made Your Product \'keys\' to be Appeared as front page  featured item'),
(39, 8, '10.00', 20040212082045, 'Added Money To Your Account'),
(40, 8, '-6.00', 20040212082220, 'Made Your Product \'keys\' to be Appeared as gallery  featured item'),
(41, 8, '-2.00', 20040212082515, 'Made Your Product \'keys\' to be Appeared as bold item'),
(42, 8, '5.00', 20040212082912, 'Added Money To Your Account'),
(43, 8, '-7.00', 20040212082918, 'Made Your Product \'keys\' to be Appeared as highlighted item'),
(44, 29, '10.00', 20040213052508, 'Sign Up Bonus'),
(45, 8, '20.00', 20040214115100, 'Added Money To Your Account'),
(46, 8, '-3.00', 20040214115112, 'Made Your Product \'testzzzzz3\' to be Appeared as front page  featured item'),
(47, 8, '-3.00', 20040214115114, 'Made Your Product \'relist test\' to be Appeared as front page  featured item'),
(48, 8, '-3.00', 20040214115122, 'Made Your Product \'pen\' to be Appeared as front page  featured item'),
(49, 8, '-3.00', 20040214115129, 'Made Your Product \'Digital camera\' to be Appeared as front page  featured item'),
(50, 8, '-3.00', 20040214115134, 'Made Your Product \'testzzzz\' to be Appeared as front page  featured item'),
(51, 8, '-6.00', 20040214115137, 'Made Your Product \'relist test\' to be Appeared as gallery  featured item'),
(52, 8, '10.00', 20040214060928, 'Added Money To Your Account'),
(53, 8, '-3.00', 20040214060936, 'Made Your Product \'Coffee Maker\' to be Appeared as front page  featured item'),
(54, 29, '10.00', 20040121101406, 'Added Money To Your Account By Admin'),
(55, 29, '5.00', 20040121102457, 'Added Money To Your Account By Admin'),
(56, 30, '10.00', 20040121105409, 'Sign Up Bonus'),
(57, 8, '-3.00', 20040121081251, 'Made Your Product \'testing counter\' to be Appeared as front page  featured item'),
(58, 8, '-3.00', 20040122120102, 'Made Your Product \'testing formating\' to be Appeared  as   Featured on Front Page'),
(65, 8, '2.00', 20040124060218, 'Added Money To Your Account'),
(66, 8, '-2.00', 20040124064832, 'Uploaded product \'eee\''),
(67, 8, '10.00', 20040124070244, 'Added Money To Your Account'),
(68, 8, '-2.00', 20040124070358, 'Uploaded product \'aaa\''),
(69, 8, '-2.00', 20040124070628, 'Uploaded product \'test\''),
(70, 8, '-2.00', 20040124071029, 'Uploaded product \'saa\''),
(71, 8, '-2.00', 20040124083953, 'Uploaded product \'fixxxx\''),
(72, 8, '-2.00', 20040124083953, 'Made Your Product \'fixxxx\' to be Appeared as Bold'),
(74, 8, '10.00', 20040129145216, 'Added to your Account\r\n'),
(75, 8, '-5.00', 20040129025229, 'Purchased 3 images for Product \'testing formating\'.'),
(76, 32, '1.00', 20040129034357, 'Sign Up Bonus'),
(77, 33, '1.00', 20040129042231, 'Sign Up Bonus'),
(78, 8, '-2.00', 20040216043741, 'Made Your Product \'Great\' to be Appeared as Bold'),
(79, 8, '-1.00', 20040216043741, 'Made Your Product \'Great\' to be Appeared as Featured'),
(80, 8, '3.00', 20040329200859, 'Made Your Product \'d1\' to be Appeared  as   Featured on Front Page'),
(82, 8, '3.00', 20040329080921, 'Added by admin'),
(85, 8, '1.00', 20040405062805, 'Added by admin'),
(86, 8, '-3.00', 20040406052521, 'Made Your Product \'\' to be Appeared as front page  featured item'),
(87, 8, '-3.00', 20040406053200, 'Made Your Product \'postedon_6april\' to be Appeared as front page  featured item'),
(88, 8, '-1.00', 20040406053502, 'Made Your Product \'postedon_6april\' to be Appeared as category featured'),
(89, 8, '-1.00', 20040407020215, 'Made Your Product \'preview_product\' to be Appeared as Featured'),
(90, 8, '10.00', 20040407040547, 'Added by admin'),
(91, 8, '-2.00', 20040407040702, 'Made Your Product \'postedon_7april2\' to be Appeared as Bold'),
(92, 8, '-1.00', 20040407040702, 'Made Your Product \'postedon_7april2\' to be Appeared as Featured'),
(93, 8, '-2.00', 20040407042320, 'Uploaded product \'postedon_7april2\''),
(94, 8, '-0.50', 20040407045129, 'Uploaded product \'proviney3\''),
(95, 8, '-0.50', 20040407045131, 'Uploaded product \'proviney3\''),
(96, 8, '-0.75', 20040407052322, 'Uploaded product \'proviney3\''),
(97, 8, '-1.00', 20040407052322, 'Made Your Product \'proviney3\' to be Appeared as Featured'),
(100, 8, '-1.00', 20040407073916, 'Made Your Product \'proviney3\' to be Appeared as front page  featured item'),
(99, 8, '-1.80', 20040407073641, 'Made Your Product \'proviney3\' to be Appeared as gallery  featured item'),
(101, 35, '1.00', 20040407082312, 'Sign Up Bonus'),
(102, 8, '10.00', 20040407083049, 'Added by admin'),
(103, 8, '-2.00', 20040407083055, 'Made Your Product \'proviney3\' to be Appeared as bold item'),
(104, 36, '1.00', 20040407093003, 'Sign Up Bonus'),
(105, 12, '10.00', 20040408112740, 'Added by admin'),
(106, 12, '-0.50', 20040408122713, 'Uploaded product \'provikas3\''),
(107, 12, '-1.80', 20040408122856, 'Made Your Product \'provikas3\' to be Appeared as gallery  featured item'),
(108, 12, '-1.00', 20040408122859, 'Made Your Product \'provikas3\' to be Appeared as front page  featured item'),
(109, 12, '-2.00', 20040408123207, 'Uploaded product \'provikas2\''),
(110, 12, '-1.80', 20040408123244, 'Made Your Product \'provikas2\' to be Appeared as gallery  featured item'),
(111, 8, '-2.00', 20040409055704, 'Uploaded product \'proviney6\''),
(112, 8, '-1.00', 20040409085735, 'Made Your Product \'stupid\' to be Appeared as front page  featured item'),
(113, 16, '70.00', 20040410152820, 'Made Your Product notfeatured to be Appeared as Highlighted'),
(114, 16, '-0.50', 20040410032903, 'Uploaded product \'p1\''),
(115, 16, '-1.00', 20040410032903, 'Made Your Product \'p1\' to be Appeared  as   Featured on Front Page'),
(116, 16, '-0.50', 20040410033521, 'Uploaded product \'p2\''),
(117, 16, '-1.00', 20040410033521, 'Made Your Product \'p2\' to be Appeared  as   Featured on Front Page'),
(118, 16, '-0.75', 20040410033920, 'Uploaded product \'p3fixed\''),
(119, 16, '-1.00', 20040410033920, 'Made Your Product \'p3fixed\' to be Appeared  as   Featured on Front Page'),
(120, 16, '-0.75', 20040410034033, 'Uploaded product \'p4fixed\''),
(121, 16, '-1.00', 20040410034033, 'Made Your Product \'p4fixed\' to be Appeared  as   Featured on Front Page'),
(122, 16, '-0.50', 20040410035158, 'Uploaded product \'p5\''),
(123, 16, '-1.00', 20040410035158, 'Made Your Product \'p5\' to be Appeared  as   Featured on Front Page'),
(124, 16, '-0.50', 20040410035329, 'Uploaded product \'p6\''),
(125, 16, '-1.00', 20040410035329, 'Made Your Product \'p6\' to be Appeared  as   Featured on Front Page'),
(126, 8, '-1.00', 20040410044002, 'Made Your Product \'proviney6 proviney6 proviney6 proviney6 proviney6 proviney6 proviney6\' to be Appeared as front page  featured item'),
(127, 8, '-1.80', 20040410044134, 'Made Your Product \'proviney6 proviney6 proviney6 proviney6 proviney6 proviney6 proviney6\' to be Appeared as gallery  featured item'),
(128, 8, '-1.45', 20040410044245, 'Extend duration of product \'stupid\''),
(129, 8, '-0.75', 20040410045235, 'Uploaded product \'product3\'');

