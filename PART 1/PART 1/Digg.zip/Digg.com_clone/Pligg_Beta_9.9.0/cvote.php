<?php
// The source code packaged with this file is Free Software, Copyright (C) 2005 by
// Ricardo Galli <gallir at uib dot es>.
// It's licensed under the AFFERO GENERAL PUBLIC LICENSE unless stated otherwise.
// You can get copies of the licenses here:
// 		http://www.affero.org/oagpl.html
// AFFERO GENERAL PUBLIC LICENSE is also included in the file called "COPYING".

if($_POST['id']){

	include_once('Smarty.class.php');
	$main_smarty = new Smarty;

	include('config.php');
	include(mnminclude.'comment.php');
	include(mnminclude.'html1.php');
	include(mnminclude.'smartyvariables.php');
	
	$comment = new Comment;
	$comment->id=$_POST['id'];
	$comment->read();
	
	if ($current_user->user_id == 0 && !anonnymous_vote) {
	error($main_smarty->get_config_vars('PLIGG_Visual_Vote_NoAnon'));
	}

	if($current_user->user_id != $_POST['user']) {
	error($main_smarty->get_config_vars('PLIGG_Visual_Vote_BadUser'). $current_user->user_id . '-'. $_POST['user']);
	}

	$md5=md5($_POST['user'].$comment->randkey);
	if($md5 !== $_POST['md5']){
	error($main_smarty->get_config_vars('PLIGG_Visual_Vote_BadKey'));
	}

	if($comment->votes($current_user->user_id) <> 0) {
	error($main_smarty->get_config_vars('PLIGG_Visual_Vote_AlreadyVoted'));
	}
	
	$value = $_POST['value'];

	$votes = $comment->insert_vote($current_user->user_id, $value);

	$comment->votes = $votes;
	$comment->store();

	$count=$comment->votes;
	echo "$count ~--~".$_POST['id'];

}

function error($mess) {
	header('Content-Type: text/plain; charset=UTF-8');
	echo "ERROR: $mess";
	die;
}
?>