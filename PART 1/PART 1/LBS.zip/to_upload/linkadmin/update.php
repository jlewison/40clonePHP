<?php include('restrict.php');
require_once('../Connections/apound.php');
$ujid = $_GET[ujid];
$mujbid = $_GET[mujbid];
$x = $_GET[x];
$link = mysql_pconnect($hostname_apound,$username_apound,$password_apound);
mysql_select_db($database_apound);
mysql_query("UPDATE main SET ujbid='' WHERE dtu='$ujid'");
mysql_query("UPDATE main SET bid='$mujbid' WHERE dtu='$ujid'");
mysql_query("UPDATE main SET stup=NOW()");
header("Location: http://$x");?>