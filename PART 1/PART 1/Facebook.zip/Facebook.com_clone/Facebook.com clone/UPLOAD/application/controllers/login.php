<?php

/**
 * Login Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 2007-12-13
 */
class Login extends Controller
{
		//Constructor
		function Login()
		{
				parent::Controller();
				if ($this->uri->uri_string() != 'login/success') loggedInTakeIn();
				//Load the language file
				$this->lang->load('login', $this->config->item('language_code'));
		}
		function index()
		{
				//Load the required model, libraries, plugins.
				$this->load->model('registerModel');
				$this->load->library('validation');
				$this->load->helper('cookie');
				//Set the validation rules
				$this->_loginFrmRules();
				//Do the validation
				if ($this->validation->run() == false)
				{
						//Oops! validation Error.
						$outputData['validationError'] = $this->validation->error_string;
						//Get the e-mail from Cookie if set
						$outputData['user_email'] = get_cookie('kootali_email');
						$this->smartyextended->view('login', $outputData);
				}
				else
				{
						//Load the user model
						$this->load->model('usermodel');
						$loginStatus = $this->usermodel->login($this->input->post('email'), $this->input->post('pass'));
						if (!is_array($loginStatus))
						{
								//Login failed
								$outputData['validationError'] = $this->lang->line($loginStatus);
								//Get the e-mail from Cookie if set
								$outputData['user_email'] = get_cookie('kootali_email');
								$this->smartyextended->view('login', $outputData);
						}
						else
						{
								$userAvatar = $this->usermodel->getAvatar($loginStatus['user_id']);
								$loginStatus['avatar'] = $userAvatar;
								//get the user network if, any.
								$userNetworks = $this->usermodel->getUserNetworks($loginStatus['user_id'], 'region', 'datestamp desc', 0, 1);
								if (count($userNetworks) > 0)
								{
										$network = current($userNetworks);
										$loginStatus['user_network'] = (strlen($network['network_name']) > 10) ? (substr($network['network_name'], 0, 10) . '...') : $network['network_name'];
										$loginStatus['user_network_id'] = $network['network_id'];
								}
								else  $loginStatus['user_network'] = '';
								//Set the logged in user details in the session
								$this->session->set_userdata($loginStatus);
								//Set the e-mail in cookie
								if ($this->input->post('rememberme') == 'yes')
								{
										set_cookie('email', $this->input->post('email'), 3600 * 24 * 30); // set the cookie for 1 month
								}
								redirect('login/success');
						}
				}
		}
		function _loginFrmRules()
		{
				$rules['email'] = 'trim|required|valid_email';
				$rules['pass'] = 'required';
				$this->validation->set_rules($rules);
				$fields['email'] = $this->lang->line('login_email');
				$fields['pass'] = $this->lang->line('login_password');
				$this->validation->set_fields($fields);
		}
		function success()
		{
				doLogin();
		}
}



?>