-- phpMyAdmin SQL Dump
-- version 2.6.1
-- http://www.phpmyadmin.net
-- 
-- Serveur: localhost
-- Généré le : Dimanche 28 Juillet 2002 à 17:34
-- Version du serveur: 4.1.9
-- Version de PHP: 4.3.10
-- 
-- Base de données: `m`
-- 

-- --------------------------------------------------------


-- 
-- Structure de la table `crzsettings`
-- 

CREATE TABLE `crzsettings` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(80) NOT NULL default '',
  `value` varchar(100) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=45 ;

-- 
-- Contenu de la table `crzsettings`
-- 

INSERT INTO `crzsettings` VALUES (1, 'bonus_freq', '50');
INSERT INTO `crzsettings` VALUES (2, 'banana_freq', '50');
INSERT INTO `crzsettings` VALUES (3, 'bonus_min', '22');
INSERT INTO `crzsettings` VALUES (4, 'bonus_max', '50');
INSERT INTO `crzsettings` VALUES (5, 'bonus2_50', '50');
INSERT INTO `crzsettings` VALUES (6, 'bonus2_100', '100');
INSERT INTO `crzsettings` VALUES (7, 'bonus2_150', '150');
INSERT INTO `crzsettings` VALUES (8, 'bonus2_200', '200');
INSERT INTO `crzsettings` VALUES (9, 'bonus2_250', '250');
INSERT INTO `crzsettings` VALUES (11, 'wl,1,1', '500');
INSERT INTO `crzsettings` VALUES (12, 'wl,1,2', '400');
INSERT INTO `crzsettings` VALUES (13, 'wl,1,3', '500');
INSERT INTO `crzsettings` VALUES (14, 'wl,2,1', '800');
INSERT INTO `crzsettings` VALUES (15, 'wl,2,2', '900');
INSERT INTO `crzsettings` VALUES (16, 'wl,2,3', '1000');
INSERT INTO `crzsettings` VALUES (17, 'wl,3,1', '300');
INSERT INTO `crzsettings` VALUES (18, 'wl,3,2', '800');
INSERT INTO `crzsettings` VALUES (19, 'wl,3,3', '900');
INSERT INTO `crzsettings` VALUES (20, 'wl,4,1', '900');
INSERT INTO `crzsettings` VALUES (21, 'wl,4,2', '1000');
INSERT INTO `crzsettings` VALUES (22, 'wl,4,3', '900');
INSERT INTO `crzsettings` VALUES (23, 'wl,5,1', '900');
INSERT INTO `crzsettings` VALUES (24, 'wl,5,2', '170');
INSERT INTO `crzsettings` VALUES (25, 'wl,5,3', '300');
INSERT INTO `crzsettings` VALUES (26, 'wl,6,1', '60');
INSERT INTO `crzsettings` VALUES (27, 'wl,6,2', '70');
INSERT INTO `crzsettings` VALUES (28, 'wl,6,3', '80');
INSERT INTO `crzsettings` VALUES (29, 'wl,7,1', '70');
INSERT INTO `crzsettings` VALUES (30, 'wl,7,2', '90');
INSERT INTO `crzsettings` VALUES (31, 'wl,7,3', '100');
INSERT INTO `crzsettings` VALUES (32, 'wl,8,1', '70');
INSERT INTO `crzsettings` VALUES (33, 'wl,8,2', '123');
INSERT INTO `crzsettings` VALUES (34, 'wl,8,3', '345');
INSERT INTO `crzsettings` VALUES (35, 'wl,9,1', '50');
INSERT INTO `crzsettings` VALUES (36, 'wl,9,2', '51');
INSERT INTO `crzsettings` VALUES (37, 'wl,9,3', '52');
INSERT INTO `crzsettings` VALUES (38, 'double_freq', '7');
INSERT INTO `crzsettings` VALUES (39, 'get_more_than_bet_freq', '52');
INSERT INTO `crzsettings` VALUES (40, 'max_part_of_bank_at_once', '7');
INSERT INTO `crzsettings` VALUES (41, 'max_gain_at_once', '52');
INSERT INTO `crzsettings` VALUES (42, 'max_gain_in_double', '7');
INSERT INTO `crzsettings` VALUES (43, 'max_gain_on_rope', '52');
INSERT INTO `crzsettings` VALUES (44, 'max_super_prize', '7');

-- --------------------------------------------------------



-- 
-- Structure de la table `game_bank`
-- 

CREATE TABLE `game_bank` (
  `name` varchar(10) NOT NULL default 'ttuz',
  `bank` decimal(12,2) NOT NULL default '0.00',
  `proc` decimal(3,0) NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `game_bank`
-- 

INSERT INTO `game_bank` VALUES ('ttuz', 100000, 90);

-- --------------------------------------------------------




-- 
-- Structure de la table `game_sessions`
-- 

CREATE TABLE `game_sessions` (
  `id` bigint(20) NOT NULL auto_increment,
  `login` varchar(12) default NULL,
  `state` varchar(250) default NULL,
  `cr_tstamp` datetime default NULL,
  `cashin` decimal(12,2) default NULL,
  `cashchange` decimal(12,2) default NULL,
  `lastact_tstamp` datetime default NULL,
  `gameid` bigint(20) default NULL,
  `active` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1364 ;

-- 
-- Contenu de la table `game_sessions`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `jackpot`
-- 

CREATE TABLE `jackpot` (
  `name` varchar(10) NOT NULL default 'ttuz',
  `astro` decimal(12,2) NOT NULL default '0.00',
  `birds` decimal(12,2) NOT NULL default '0.00',
  `farwest` decimal(12,2) NOT NULL default '0.00',
  `fruit` decimal(12,2) NOT NULL default '0.00',
  `ice` decimal(12,2) NOT NULL default '0.00',
  `magicien` decimal(12,2) NOT NULL default '0.00',
  `shuki` decimal(12,2) NOT NULL default '0.00',
  `strip` decimal(12,2) NOT NULL default '0.00',
  `tomraider` decimal(12,2) NOT NULL default '0.00',
  `pirate` decimal(12,2) NOT NULL default '0.00',
  `sea` decimal(12,2) NOT NULL default '0.00',
  `skull` decimal(12,2) NOT NULL default '0.00',
  `fairy` decimal(12,2) NOT NULL default '0.00',
  `total` decimal(12,2) NOT NULL default '0.00'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `jackpot`
-- 

INSERT INTO `jackpot` VALUES ('ttuz', 1005.52, 1060.12, 1050.14, 1015.52, 1000.00, 1001.26, 1001.12, 1002.72, 1000.40, 1073.62, 1022.52, 1002.24, 1010.02, 1000.00);

-- --------------------------------------------------------



-- 
-- Structure de la table `partner`
-- 

CREATE TABLE `partner` (
  `pus` varchar(50) default NULL,
  `user` varchar(50) default NULL,
  `data` varchar(8) default NULL,
  `cash` varchar(10) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `partner`
-- 


-- --------------------------------------------------------



-- 
-- Structure de la table `seting`
-- 

CREATE TABLE `seting` (
  `alog` varchar(10) NOT NULL default 'admin',
  `apas` varchar(10) NOT NULL default 'admin',
  `adm_email` varchar(200) NOT NULL default '',
  `cas_url` varchar(200) NOT NULL default 'http://',
  `cas_name` varchar(40) NOT NULL default '',
  `mrh_login` varchar(200) NOT NULL default '',
  `mrh_pass1` varchar(200) NOT NULL default '',
  `mrh_pass2` varchar(200) NOT NULL default '',
  `pcash` char(3) NOT NULL default '20',
  `paymail` char(3) NOT NULL default 'yes',
  `regmail` char(3) NOT NULL default 'yes',
  `zakmail` char(3) NOT NULL default 'yes',
  `icq` varchar(10) NOT NULL default '',
  `cas_bon` char(1) NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `seting`
-- 

INSERT INTO `seting` VALUES ('admin', 'admin', 'flashcasino@gmail.com', 'http://flashcasino.6te.net', 'flashcasino.6te.net', '1', 'http://flashcasino.6te.net', 'http://flashcasino.6te.net', '20', 'yes', 'yes', 'yes', '200', '0');

-- --------------------------------------------------------

-- 
-- Structure de la table `stat_game`
-- 

CREATE TABLE `stat_game` (
  `id` int(11) NOT NULL auto_increment,
  `data` varchar(8) NOT NULL default '',
  `vrem` time NOT NULL default '00:00:00',
  `login` varchar(20) NOT NULL default '',
  `balans` varchar(10) NOT NULL default '',
  `stav` char(3) NOT NULL default '',
  `win` varchar(6) NOT NULL default '',
  `game` varchar(20) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=371 ;



-- --------------------------------------------------------

-- 
-- Structure de la table `stat_pay`
-- 

CREATE TABLE `stat_pay` (
  `user` varchar(20) NOT NULL default '',
  `data` varchar(8) NOT NULL default '',
  `vremya` time NOT NULL default '00:00:00',
  `inm` varchar(12) NOT NULL default '',
  `outm` varchar(12) NOT NULL default '',
  KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `stat_pay`
-- 



-- --------------------------------------------------------

-- 
-- Structure de la table `users`
-- 

CREATE TABLE `users` (
  `id` int(11) NOT NULL auto_increment,
  `login` varchar(12) default NULL,
  `pass` varchar(12) default NULL,
  `cash` decimal(12,2) default '0.00',
  `cashin` decimal(12,2) default '0.00',
  `cashout` decimal(12,2) default '0.00',
  `email` varchar(50) default NULL,
  `name` varchar(50) default NULL,
  `fam` varchar(50) default NULL,
  `date` varchar(12) default NULL,
  `pcash` varchar(6) default '0.00',
  `prenom` varchar(100) default NULL,
  `nom` varchar(100) default NULL,
  `adresse` varchar(100) default NULL,
  `codepostal` varchar(100) default NULL,
  `ville` varchar(100) default NULL,
  `pays` varchar(100) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

-- 
-- Contenu de la table `users`
-- 

INSERT INTO `users` VALUES (1, 'a', 'a', 95351.73, 1.00, 3000.00, 'a@a.com', '', '', '02.07.2002', '0.00', '', '', '', '', '', '');
INSERT INTO `users` VALUES (2, 'demo', 'demo', 1000.00, 0.00, 0.00, 'demo@demo.com', '', '', '03.07.2002', '0.00', '', '', '', '', '', '');
-- --------------------------------------------------------

-- 
-- Structure de la table `zakaz`
-- 

CREATE TABLE `zakaz` (
  `id` int(11) NOT NULL auto_increment,
  `login` varchar(12) default NULL,
  `cash` varchar(30) default NULL,
  `rekvizit` varchar(20) default NULL,
  `sumout` varchar(10) default NULL,
  `flag` char(1) default '1',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

-- 
-- Contenu de la table `zakaz`
-- 


INSERT INTO `zakaz` VALUES (5, 'a', '', 'Checks  ', '3000', '1');
