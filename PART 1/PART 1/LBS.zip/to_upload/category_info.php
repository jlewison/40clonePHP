<?php require_once('Connections/apound.php'); // include the database connection script ?>


<?php
$cat1 = $_GET[cat1];
$cat2 = $_GET[cat2];
$cat3 = $_GET[cat3];

if($cat1 <> '' and $cat2 <> '' and $cat3 <> '' and $category <> '') {

mysql_select_db($database_apound, $apound);
$query_catA = "SELECT catlistid, categoryname, categdescription, categkeyword, categseoname, parentid FROM categorylisting WHERE categorylisting.categenable = 'Y' AND categorylisting.categseoname = '$cat1' AND categorylisting.parentid = '0' ORDER BY categorylisting.categoryname ASC";
$catA = mysql_query($query_catA, $apound) or die(mysql_error());
$row_catA = mysql_fetch_assoc($catA);
$totalRows_catA = mysql_num_rows($catA);
$categnumA = $row_catA['catlistid'];
$categNA = $row_catA['categseoname'];

if($totalRows_catA == '') { $nocat = "Y"; } else {}


mysql_select_db($database_apound, $apound);
$query_catB = "SELECT catlistid, categoryname, categdescription, categkeyword, categseoname, parentid FROM categorylisting WHERE categorylisting.categenable = 'Y' AND categorylisting.categseoname = '$cat2' AND categorylisting.parentid = '$categnumA' ORDER BY categorylisting.categoryname ASC";
$catB = mysql_query($query_catB, $apound) or die(mysql_error());
$row_catB = mysql_fetch_assoc($catB);
$totalRows_catB = mysql_num_rows($catB);
$categnumB = $row_catB['catlistid'];
$categNB = $row_catB['categseoname'];

if($totalRows_catB == '') { $nocat = "Y"; } else {}


mysql_select_db($database_apound, $apound);
$query_catC = "SELECT catlistid, categoryname, categdescription, categkeyword, categseoname, parentid FROM categorylisting WHERE categorylisting.categenable = 'Y' AND categorylisting.categseoname = '$cat3' AND categorylisting.parentid = '$categnumB' ORDER BY categorylisting.categoryname ASC";
$catC = mysql_query($query_catC, $apound) or die(mysql_error());
$row_catC = mysql_fetch_assoc($catC);
$totalRows_catC = mysql_num_rows($catC);
$categnumC = $row_catC['catlistid'];
$categNC = $row_catC['categseoname'];

if($totalRows_catC == '') { $nocat = "Y"; } else {}


mysql_select_db($database_apound, $apound);
$query_catPcatL = "SELECT catlistid, categoryname, categdescription, categkeyword, categseoname, parentid FROM categorylisting WHERE categorylisting.categenable = 'Y' AND categorylisting.categseoname = '$category' AND categorylisting.parentid = '$categnumC' ORDER BY categorylisting.categoryname ASC";
$catPcatL = mysql_query($query_catPcatL, $apound) or die(mysql_error());
$row_catPcatL = mysql_fetch_assoc($catPcatL);
$totalRows_catPcatL = mysql_num_rows($catPcatL); 
$categnum = $row_catPcatL['catlistid'];

if($totalRows_catPcatL == '') { $nocat = "Y"; } else {}

}

elseif($cat1 <> '' and $cat2 <> '' and $category <> '') {

mysql_select_db($database_apound, $apound);
$query_catA = "SELECT catlistid, categoryname, categdescription, categkeyword, categseoname, parentid FROM categorylisting WHERE categorylisting.categenable = 'Y' AND categorylisting.categseoname = '$cat1' AND categorylisting.parentid = '0' ORDER BY categorylisting.categoryname ASC";
$catA = mysql_query($query_catA, $apound) or die(mysql_error());
$row_catA = mysql_fetch_assoc($catA);
$totalRows_catA = mysql_num_rows($catA);
$categnumA = $row_catA['catlistid'];
$categNA = $row_catA['categseoname'];

if($totalRows_catA == '') { $nocat = "Y"; } else {}


mysql_select_db($database_apound, $apound);
$query_catB = "SELECT catlistid, categoryname, categdescription, categkeyword, categseoname, parentid FROM categorylisting WHERE categorylisting.categenable = 'Y' AND categorylisting.categseoname = '$cat2' AND categorylisting.parentid = '$categnumA' ORDER BY categorylisting.categoryname ASC";
$catB = mysql_query($query_catB, $apound) or die(mysql_error());
$row_catB = mysql_fetch_assoc($catB);
$totalRows_catB = mysql_num_rows($catB);
$categnumB = $row_catB['catlistid'];
$categNB = $row_catB['categseoname'];

if($totalRows_catB == '') { $nocat = "Y"; } else {}


mysql_select_db($database_apound, $apound);
$query_catPcatL = "SELECT catlistid, categoryname, categdescription, categkeyword, categseoname, parentid FROM categorylisting WHERE categorylisting.categenable = 'Y' AND categorylisting.categseoname = '$category' AND categorylisting.parentid = '$categnumB' ORDER BY categorylisting.categoryname ASC";
$catPcatL = mysql_query($query_catPcatL, $apound) or die(mysql_error());
$row_catPcatL = mysql_fetch_assoc($catPcatL);
$totalRows_catPcatL = mysql_num_rows($catPcatL); 
$categnum = $row_catPcatL['catlistid'];

if($totalRows_catPcatL == '') { $nocat = "Y"; } else {}

}
elseif($cat1 <> '' and $category <> '') {

mysql_select_db($database_apound, $apound);
$query_catA = "SELECT catlistid, categoryname, categdescription, categkeyword, categseoname, parentid FROM categorylisting WHERE categorylisting.categenable = 'Y' AND categorylisting.categseoname = '$cat1' AND categorylisting.parentid = '0' ORDER BY categorylisting.categoryname ASC";
$catA = mysql_query($query_catA, $apound) or die(mysql_error());
$row_catA = mysql_fetch_assoc($catA);
$totalRows_catA = mysql_num_rows($catA);
$categnumA = $row_catA['catlistid'];
$categNA = $row_catA['categseoname'];

if($totalRows_catA == '') { $nocat = "Y"; } else {}


mysql_select_db($database_apound, $apound);
$query_catPcatL = "SELECT catlistid, categoryname, categdescription, categkeyword, categseoname, parentid FROM categorylisting WHERE categorylisting.categenable = 'Y' AND categorylisting.categseoname = '$category' AND categorylisting.parentid = '$categnumA' ORDER BY categorylisting.categoryname ASC";
$catPcatL = mysql_query($query_catPcatL, $apound) or die(mysql_error());
$row_catPcatL = mysql_fetch_assoc($catPcatL);
$totalRows_catPcatL = mysql_num_rows($catPcatL); 
$categnum = $row_catPcatL['catlistid'];

if($totalRows_catPcatL == '') { $nocat = "Y"; } else {}
}

else {
// query for category list - start - categRL -> catPcatL
mysql_select_db($database_apound, $apound);
$query_catPcatL = "SELECT catlistid, categoryname, categdescription, categkeyword, categseoname FROM categorylisting WHERE categorylisting.categenable = 'Y' AND categorylisting.categseoname = '$category' ORDER BY categorylisting.categoryname ASC";
$catPcatL = mysql_query($query_catPcatL, $apound) or die(mysql_error());
$row_catPcatL = mysql_fetch_assoc($catPcatL);
$totalRows_catPcatL = mysql_num_rows($catPcatL);

if($totalRows_catPcatL == '') { $nocat = "Y"; } else {}

$categnum = $row_catPcatL['catlistid'];
// query for category list - end
}
?>

<?php
// SUB categories start - home page
//mysql_select_db($database_apound, $apound);
$query_categSRL = "SELECT * FROM categorylisting WHERE categorylisting.categenable = 'Y' AND categorylisting.parentid = '$categnum' ORDER BY categorylisting.categoryname ASC";
$categSRL = mysql_query($query_categSRL, $apound) or die(mysql_error());
$row_categSRL = mysql_fetch_assoc($categSRL);
$totalRows_categSRL = mysql_num_rows($categSRL);
// SUB categories end - homepage
?>


<?php 
$categoryname = $row_catPcatL['categoryname'];          // set variable for category name
$categkeyword = $row_catPcatL['categkeyword'];          // set variable for category keywords
$categdescription = $row_catPcatL['categdescription'];  // set variable for category description
$categseoname = $row_catPcatL['categseoname'];          //set variable for category seo name, for the URL line
$su_categ = $row_catPcatL['catlistid'];
?>

<?php
// start section for page number divide
$currentPage = $_SERVER["PHP_SELF"];
$maxRows_catPcatLN = "$lnbcategory";
$pageNum_catPcatLN = 0;
if (isset($_GET['pageNum_catPcatLN'])) {
  $pageNum_catPcatLN = $_GET['pageNum_catPcatLN'];
}
$startRow_catPcatLN = $pageNum_catPcatLN * $maxRows_catPcatLN;

mysql_select_db($database_apound, $apound);
if($lexv == 'LIMITED') {
$query_catPcatLN = "SELECT * FROM main WHERE main.maincategory = '$categnum' AND main.avail = 'Y' AND main.paid = 'Y' AND TO_DAYS(NOW()) < TO_DAYS(stod) ORDER BY main.$CL_ordby_F $CL_ordby_O";
}
else {
$query_catPcatLN = "SELECT * FROM main WHERE main.maincategory = '$categnum' AND main.avail = 'Y' AND main.paid = 'Y' ORDER BY main.$CL_ordby_F $CL_ordby_O";
}
$query_limit_catPcatLN = sprintf("%s LIMIT %d, %d", $query_catPcatLN, $startRow_catPcatLN, $maxRows_catPcatLN);
$catPcatLN = mysql_query($query_limit_catPcatLN, $apound) or die(mysql_error());
$row_catPcatLN = mysql_fetch_assoc($catPcatLN);

if (isset($_GET['totalRows_catPcatLN'])) {
  $totalRows_catPcatLN = $_GET['totalRows_catPcatLN'];
} else {
  $all_catPcatLN = mysql_query($query_catPcatLN);
  $totalRows_catPcatLN = mysql_num_rows($all_catPcatLN);
}
$totalPages_catPcatLN = ceil($totalRows_catPcatLN/$maxRows_catPcatLN)-1;

$queryString_catPcatLN = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_catPcatLN") == false && 
        stristr($param, "totalRows_catPcatLN") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_catPcatLN = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_catPcatLN = sprintf("&totalRows_catPcatLN=%d%s", $totalRows_catPcatLN, $queryString_catPcatLN);
 $srf = "/";
// end section for page number divide
?>