This folder should be writable.
