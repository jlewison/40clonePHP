<?php

// the path to the module. the probably shouldn't be changed unless you rename the captcha folder(s)
define('captcha_path', my_pligg_base . '/modules/captcha/');

// the path to the module. the probably shouldn't be changed unless you rename the captcha folder(s)
define('captcha_lang_conf', '/modules/captcha/lang.conf');

// the path to the modules templates. the probably shouldn't be changed unless you rename the captcha folder(s)
define('captcha_tpl_path', '../modules/captcha/templates/');

// the path to the modules libraries. the probably shouldn't be changed unless you rename the captcha folder(s)
define('captcha_lib_path', './modules/captcha/libs/');

// the path to the captchas. the probably shouldn't be changed unless you rename the captcha folder(s)
define('captcha_captchas_path', './modules/captcha/captchas/');

// the path to the images. the probably shouldn't be changed unless you rename the captcha folder(s)
define('captcha_img_path', './modules/captcha/images/');

$captcha_single_step = (get_misc_data('reg_single_step') == '') ? false : get_misc_data('reg_single_step');
$captcha_single_step = ($captcha_single_step == 'true') ? true : false;
define('captcha_single_step', $captcha_single_step);

$captcha_reg_enabled = (get_misc_data('captcha_reg_en') == '') ? true : get_misc_data('captcha_reg_en');
$captcha_reg_enabled = ($captcha_reg_enabled == 'true') ? true : false;
define('captcha_reg_enabled', $captcha_reg_enabled);

define('URL_captcha', 'module.php?module=captcha');

// don't touch anything past this line.

if(isset($main_smarty) && is_object($main_smarty)){
	$main_smarty->assign('captcha_path', captcha_path);
	$main_smarty->assign('captcha_lang_conf', captcha_lang_conf);
	$main_smarty->assign('captcha_tpl_path', captcha_tpl_path);
	$main_smarty->assign('captcha_lib_path', captcha_lib_path);
	$main_smarty->assign('captcha_img_path', captcha_img_path);
	$main_smarty->assign('captcha_captchas_path', captcha_captchas_path);
	$main_smarty->assign('captcha_single_step_reg', captcha_single_step);
	$main_smarty->assign('captcha_reg_enabled', captcha_reg_enabled);

	$main_smarty->assign('URL_captcha', URL_captcha);
}

?>
