<?php

	$lang['page_title']	= 'Terms';

?>