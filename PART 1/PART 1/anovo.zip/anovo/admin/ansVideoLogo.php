<?php
require_once ('../common/config.inc.php');
require_once ('../common/configs/config_ans_video.inc.php');
$CFG['lang']['include_files'][] = 'admin/includes/languages/%s/ansVideoLogo.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['lang']['include_files'][] = 'common/languages/%s/help.inc.php';
$CFG['html']['header'] = 'admin/includes/languages/%s/html_header.php';
$CFG['html']['footer'] = 'admin/includes/languages/%s/html_footer.php';
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class logoupload extends FormHandler
{
		public function chkFileNameIsNotEmpty($field_name, $err_tip = '')
		{
				if (!$_FILES[$field_name]['name'])
				{
						return false;
				}
				return true;
		}
		public function chkValidFileType($field_name, $err_tip = '')
		{
				$extern = strtolower(substr($_FILES[$field_name]['name'], strrpos($_FILES[$field_name]['name'], '.') + 1));
				if (!in_array(strtolower($extern), $this->CFG['admin']['ans_videos']['logo_format_arr']))
				{
						$this->fields_err_tip_arr[$field_name] = $err_tip;
						return false;
				}
				return true;
		}
		public function chkValideFileSize($field_name, $logo_size, $err_tip = '')
		{
				$max_size = $logo_size * 1024;
				if ($_FILES[$field_name]['size'] > $max_size)
				{
						$this->fields_err_tip_arr[$field_name] = $err_tip;
						return false;
				}
				return true;
		}
		public function chkErrorInFile($field_name, $err_tip = '')
		{
				if ($_FILES[$field_name]['error'])
				{
						$this->fields_err_tip_arr[$field_name] = $err_tip;
						return false;
				}
				return true;
		}
		public function resetFieldsArray()
		{
				$this->setFormField('logo_id', '');
				$this->setFormField('logo_name', '');
				$this->setFormField('logo_description', '');
				$this->setFormField('logo_url', '');
				$this->setFormField('logo_position', 'Left_bottom');
				$this->setFormField('logo_transparency', '');
				$this->setFormField('logo_rollover_transparency', '');
				$this->setFormField('logo_image', '');
				$this->setFormField('logo_ext', '');
				$this->setFormField('logo_file', '');
				$this->setFormField('date_added', '');
				$this->setFormField('animated_logo', 'no');
		}
		public function populateLogoDetails()
		{
				$sql = 'SELECT logo_id, logo_name, logo_description, logo_url, logo_position, logo_transparency,' . ' logo_rollover_transparency, logo_image, logo_ext,' . ' animated_logo FROM ' . $this->CFG['db']['tbl']['ans_video_logo'];
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($row = $rs->FetchRow())
				{
						$this->fields_arr['logo_id'] = $row['logo_id'];
						$this->fields_arr['logo_name'] = $row['logo_name'];
						$this->fields_arr['logo_description'] = $row['logo_description'];
						$this->fields_arr['logo_url'] = $row['logo_url'];
						$this->fields_arr['logo_position'] = $row['logo_position'];
						$this->fields_arr['logo_transparency'] = $row['logo_transparency'];
						$this->fields_arr['logo_rollover_transparency'] = $row['logo_rollover_transparency'];
						$this->fields_arr['logo_image'] = $row['logo_image'];
						$this->fields_arr['logo_ext'] = $row['logo_ext'];
						$this->fields_arr['animated_logo'] = $row['animated_logo'];
				}
		}
		public function getLogoImage()
		{
				switch ($this->fields_arr['logo_ext'])
				{
						case 'jpg':
								$image_path = $this->CFG['site']['url'] . $this->CFG['admin']['ans_videos']['logo_folder'] . $this->fields_arr['logo_image'] . '.' . $this->fields_arr['logo_ext'];
								break;
						case 'swf':
								$image_path = $this->CFG['site']['url'] . 'images/swflogo.jpg';
								break;
						default:
								$image_path = $this->CFG['site']['url'] . 'images/nologo.jpg';
								break;
				}
?>
	<img src="<?php echo $image_path; ?>" alt="<?php echo $this->LANG['logo']; ?>" width="66px" height="66px" />
<?php
		}
		public function updateLogoTable()
		{
				$add_arr = array();
				$add_field = '';
				if ($this->logoUpload)
				{
						$extern = strtolower(substr($_FILES['logo_file']['name'], strrpos($_FILES['logo_file']['name'], '.') + 1));
						$dir = '../' . $this->CFG['admin']['ans_videos']['logo_folder'];
						$this->chkAndCreateFolder($dir);
						move_uploaded_file($_FILES['logo_file']['tmp_name'], $dir . $this->CFG['admin']['ans_videos']['logo_name'] . '.' . strtolower($extern));
						$this->fields_arr['logo_image'] = $this->CFG['admin']['ans_videos']['logo_name'];
						$this->fields_arr['logo_ext'] = $extern;
						$add_arr = array($this->CFG['admin']['ans_videos']['logo_name'], $extern);
						$add_field = ', logo_image=' . $this->dbObj->Param('logo_image') . ',' . ' logo_ext=' . $this->dbObj->Param('logo_ext');
				}
				$sql = 'SELECT 1 FROM ' . $this->CFG['db']['tbl']['ans_video_logo'];
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount())
				{
						$sql = 'UPDATE ' . $this->CFG['db']['tbl']['ans_video_logo'] . ' SET' . ' logo_name=' . $this->dbObj->Param('logo_name') . ',' . ' logo_description=' . $this->dbObj->Param('logo_description') . ',' . ' animated_logo=' . $this->dbObj->Param('animated_logo') . ',' . ' logo_url=' . $this->dbObj->Param('logo_url') . ',' . ' logo_position=' . $this->dbObj->Param('logo_position') . ',' . ' logo_transparency=' . $this->dbObj->Param('logo_transparency') . ',' . ' logo_rollover_transparency=' . $this->dbObj->Param('logo_rollover_transparency') . $add_field;
						$array = array($this->fields_arr['logo_name'], $this->fields_arr['logo_description'], $this->fields_arr['animated_logo'], $this->fields_arr['logo_url'], $this->fields_arr['logo_position'], $this->fields_arr['logo_transparency'], $this->fields_arr['logo_rollover_transparency']);
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array_merge($array, $add_arr));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				}
				else
				{
						$sql = 'INSERT INTO ' . $this->CFG['db']['tbl']['ans_video_logo'] . ' SET' . ' logo_name=' . $this->dbObj->Param('logo_name') . ',' . ' logo_description=' . $this->dbObj->Param('logo_description') . ',' . ' animated_logo=' . $this->dbObj->Param('animated_logo') . ',' . ' logo_url=' . $this->dbObj->Param('logo_url') . ',' . ' logo_position=' . $this->dbObj->Param('logo_position') . ',' . ' logo_transparency=' . $this->dbObj->Param('logo_transparency') . ',' . ' logo_rollover_transparency=' . $this->dbObj->Param('logo_rollover_transparency') . ',' . ' date_added=NOW()' . $add_field;
						$array = array($this->fields_arr['logo_name'], $this->fields_arr['logo_description'], $this->fields_arr['animated_logo'], $this->fields_arr['logo_url'], $this->fields_arr['logo_position'], $this->fields_arr['logo_transparency'], $this->fields_arr['logo_rollover_transparency']);
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array_merge($array, $add_arr));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				}
		}
		public function isValidURL($field_name, $err_tip = '')
		{
				$urlregex = "^(https?|ftp)\:\/\/([a-z0-9+!*(),;?&=\$_.-]+(\:[a-z0-9+!*(),;?&=\$_.-]+)?@)?[a-z0-9+\$_-]+(\.[a-z0-9+\$_-]+)*(\:[0-9]{2,5})?(\/([a-z0-9+\$_-]\.?)+)*\/?(\?[a-z+&\$_.-][a-z0-9;:@/&%=+\$_.-]*)?(#[a-z_.-][a-z0-9+\$_.-]*)?\$";
				if (eregi($urlregex, $this->fields_arr[$field_name]))
				{
						return true;
				}
				else
				{
						$this->fields_err_tip_arr[$field_name] = $err_tip;
						return false;
				}
		}
}
$logoupload = new logoupload();
$logoupload->setDBObject($db);
$logoupload->makeGlobalize($CFG, $LANG);
$logo_position_array = array('Left_bottom' => $LANG['left_bottom'], 'Left_top' => $LANG['left_top'], 'Right_bottom' => $LANG['right_bottom'], 'Right_top' => $LANG['right_top']);
$logoupload->setPageBlockNames(array('msg_form_error', 'msg_form_success', 'logo_upload_form'));
$logoupload->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$logoupload->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$logoupload->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$logoupload->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$logoupload->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$logoupload->resetFieldsArray();
$logoupload->setAllPageBlocksHide();
$logoupload->setPageBlockShow('logo_upload_form');
$logoupload->sanitizeFormInputs($_REQUEST);
if ($logoupload->isFormPOSTed($_POST, 'upload'))
{
		$logoupload->logoUpload = $logoupload->chkFileNameIsNotEmpty('logo_file', $LANG['err_tip_compulsory']) and $logoupload->chkValidFileType('logo_file', $LANG['err_tip_invalid_file_type']) and $logoupload->chkValideFileSize('logo_file', $CFG['admin']['ans_videos']['logo_max_size'], $LANG['err_tip_invalid_file_size']) and $logoupload->chkErrorInFile('logo_file', $LANG['err_tip_invalid_file']);
		$logoupload->isValidURL('logo_url', $LANG['err_tip_invalid_url']);
		$logoupload->getFormField('logo_transparency') and $logoupload->chkIsNumeric('logo_transparency', $LANG['err_tip_numeric']);
		$logoupload->getFormField('logo_rollover_transparency') and $logoupload->chkIsNumeric('logo_rollover_transparency', $LANG['err_tip_numeric']);
		if ($logoupload->isValidFormInputs())
		{
				$logoupload->updateLogoTable();
				$logoupload->setCommonErrorMsg($LANG['msg_success_updated']);
				$logoupload->setPageBlockShow('msg_form_success');
		}
		else
		{
				$logoupload->setCommonErrorMsg($LANG['msg_error_sorry']);
				$logoupload->setPageBlockShow('msg_form_error');
		}
}
else
{
		$logoupload->populateLogoDetails();
}



?>
<div id="sellogoupload">
  <h2 class="clsVideoLogo"><span><?php echo $LANG['page_title']; ?></span></h2>
  <div id="selLeftNavigation">
<?php
if ($logoupload->isShowPageBlock('msg_form_error'))
{
?>
    <div id="selMsgError">
      <p><?php echo $logoupload->getCommonErrorMsg(); ?></p>
    </div>
<?php
}
if ($logoupload->isShowPageBlock('msg_form_success'))
{
?>
    <div id="selMsgSuccess">
      <p><?php echo $logoupload->getCommonErrorMsg(); ?></p>
    </div>
<?php
}
if ($logoupload->isShowPageBlock('logo_upload_form'))
{
?>
    <div id="selUpload">
	  <form name="logo_upload_form" id="logo_upload_form" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" autocomplete="off" enctype="multipart/form-data">
		<div id="selUploadBlock">
          <table class="clsCommonTable" summary="<?php echo $LANG['logoupload_tbl_summary']; ?>" id="selUploadTbl" class="clsUploadBlock">
		  	<tr>
              <td class="<?php echo $logoupload->getCSSFormLabelCellClass('logo_name'); ?>">
                <label for="logo_name"><?php echo $LANG['logo_name']; ?></label> </td>
              <td class="<?php echo $logoupload->getCSSFormFieldCellClass('logo_name'); ?>"><?php echo $logoupload->getFormFieldErrorTip('logo_name'); ?>
                <input type="text" class="clsTextBox" name="logo_name" id="logo_name" tabindex="<?php echo $logoupload->getTabIndex(); ?>" value="<?php echo $logoupload->getFormField('logo_name'); ?>" /></td>
            </tr>
			<tr>
              <td class="<?php echo $logoupload->getCSSFormLabelCellClass('logo_description'); ?>">
                <label for="logo_description"><?php echo $LANG['logo_description']; ?></label> </td>
              <td class="<?php echo $logoupload->getCSSFormFieldCellClass('logo_description'); ?>"><?php echo $logoupload->getFormFieldErrorTip('logo_description'); ?>
                <textarea name="logo_description" id="logo_description" tabindex="<?php echo $logoupload->getTabIndex(); ?>"><?php echo $logoupload->getFormField('logo_description'); ?></textarea></td>
            </tr>
			<tr>
              <td class="<?php echo $logoupload->getCSSFormLabelCellClass('logo_url'); ?>">
                <label for="logo_url"><?php echo $LANG['logo_url']; ?></label> </td>
              <td class="<?php echo $logoupload->getCSSFormFieldCellClass('logo_url'); ?>"><?php echo $logoupload->getFormFieldErrorTip('logo_url'); ?>
                <input type="text" class="clsTextBox" name="logo_url" id="logo_url" tabindex="<?php echo $logoupload->getTabIndex(); ?>" value="<?php echo $logoupload->getFormField('logo_url'); ?>" /><p>http://www.example.com</p></td>
            </tr>
			<tr>
              <td class="<?php echo $logoupload->getCSSFormLabelCellClass('logo_position'); ?>">
                <label for="logo_position"><?php echo $LANG['logo_position']; ?></label> </td>
              <td class="<?php echo $logoupload->getCSSFormFieldCellClass('logo_position'); ?>"><?php echo $logoupload->getFormFieldErrorTip('logo_position'); ?>
                <select name="logo_position" id="logo_position" tabindex="<?php echo $logoupload->getTabIndex(); ?>">
					<?php $logoupload->generalPopulateArray($logo_position_array, $logoupload->getFormField('logo_position')); ?>
				</select></td>
            </tr>
			<tr>
              <td class="<?php echo $logoupload->getCSSFormLabelCellClass('logo_transparency'); ?>">
                <label for="logo_transparency"><?php echo $LANG['logo_transparency']; ?></label> </td>
              <td class="<?php echo $logoupload->getCSSFormFieldCellClass('logo_transparency'); ?>"><?php echo $logoupload->getFormFieldErrorTip('logo_transparency'); ?>
                <input type="text" class="clsTextBox" name="logo_transparency" id="logo_transparency" tabindex="<?php echo $logoupload->getTabIndex(); ?>" value="<?php echo $logoupload->getFormField('logo_transparency'); ?>" />(<?php echo $LANG['recommended']; ?> 30)</td>
            </tr>
			<tr>
              <td class="<?php echo $logoupload->getCSSFormLabelCellClass('logo_rollover_transparency'); ?>">
                <label for="logo_rollover_transparency"><?php echo $LANG['logo_rollover_transparency']; ?></label> </td>
              <td class="<?php echo $logoupload->getCSSFormFieldCellClass('logo_rollover_transparency'); ?>"><?php echo $logoupload->getFormFieldErrorTip('logo_rollover_transparency'); ?>
                <input type="text" class="clsTextBox" name="logo_rollover_transparency" id="logo_rollover_transparency" tabindex="<?php echo $logoupload->getTabIndex(); ?>" value="<?php echo $logoupload->getFormField('logo_rollover_transparency'); ?>" />(<?php echo $LANG['recommended']; ?> 80)</td>
            </tr>
			<tr>
              <td class="<?php echo $logoupload->getCSSFormLabelCellClass('animated_logo'); ?>">
                <label for="animated_logo1"><?php echo $LANG['animated_logo']; ?></label> </td>
              <td class="<?php echo $logoupload->getCSSFormFieldCellClass('animated_logo'); ?>"><?php echo $logoupload->getFormFieldErrorTip('animated_logo'); ?>
                <input type="radio" class="clsCheckRadio" name="animated_logo" id="animated_logo1" tabindex="<?php echo $logoupload->getTabIndex(); ?>" value="yes" <?php echo $logoupload->isCheckedRadio('animated_logo', 'yes'); ?> />&nbsp;<label for="animated_logo1"><?php echo $LANG['yes']; ?></label>
				<input type="radio" class="clsCheckRadio" name="animated_logo" id="animated_logo2" tabindex="<?php echo $logoupload->getTabIndex(); ?>" value="no" <?php echo $logoupload->isCheckedRadio('animated_logo', 'no'); ?> />&nbsp;<label for="animated_logo2"><?php echo $LANG['no']; ?></label>
			  </td>
            </tr>
			<tr>
              <td class="<?php echo $logoupload->getCSSFormLabelCellClass('logo_file'); ?>">
                <label for="logo_file"><?php echo $LANG['logoupload_logo_file']; ?></label> </td>
              <td class="<?php echo $logoupload->getCSSFormFieldCellClass('logo_file'); ?>"><?php echo $logoupload->getFormFieldErrorTip('logo_file'); ?>
               <div id="selLeftPlainImage">
					<p id="selImageBorder"><span id="selPlainCenterImage"><?php $logoupload->getLogoImage(); ?></span></p>
			   </div>
			   <input type="file" class="clsFileBox" accept="image/<?php echo implode(', ', $CFG['admin']['ans_videos']['logo_format_arr']); ?>" name="logo_file" id="logo_file" tabindex="<?php echo $logoupload->getTabIndex(); ?>" />
                (<?php echo $CFG['admin']['ans_videos']['logo_max_size']; ?>&nbsp;KB)</td>
            </tr>
            <tr>
            <td>&nbsp;</td>
              <td class="clsFormFieldCellDefault">
			  	<?php $logoupload->populateHidden(array('logo_ext', 'logo_image')); ?>
              	<input type="submit" class="clsSubmitButton" name="upload" id="upload" tabindex="<?php echo $logoupload->getTabIndex(); ?>" value="<?php echo $LANG['upload']; ?>" /></td>
            </tr>
          </table>
        </div>
      </form>
    </div>
<?php
}
?>
  </div>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>
