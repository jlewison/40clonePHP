<?php

$currentPage = $_SERVER["PHP_SELF"];

require_once('Connections/apound.php');

$maxRows_NLlista = "$lnbnewlinks";
$pageNum_NLlista = 0;

if (isset($_GET['pageNum_NLlista'])) {
  $pageNum_NLlista = $_GET['pageNum_NLlista'];
}

$startRow_NLlista = $pageNum_NLlista * $maxRows_NLlista;

mysql_select_db($database_apound, $apound);
if($lexv == 'LIMITED') {
$query_NLlista = "SELECT * FROM main WHERE main.avail = 'Y' AND main.paid = 'Y' AND TO_DAYS(NOW()) < TO_DAYS(stod) ORDER BY main.stad DESC";
}
else {
$query_NLlista = "SELECT * FROM main WHERE main.avail = 'Y' AND main.paid = 'Y' ORDER BY main.stad DESC";
}
$query_limit_NLlista = sprintf("%s LIMIT %d, %d", $query_NLlista, $startRow_NLlista, $maxRows_NLlista);
$NLlista = mysql_query($query_limit_NLlista, $apound) or die(mysql_error());
$row_NLlista = mysql_fetch_assoc($NLlista);

if (isset($_GET['totalRows_NLlista'])) {
  $totalRows_NLlista = $_GET['totalRows_NLlista'];
} else {
  $all_NLlista = mysql_query($query_NLlista);
  $totalRows_NLlista = mysql_num_rows($all_NLlista);
}

$totalPages_NLlista = ceil($totalRows_NLlista/$maxRows_NLlista)-1;

$queryString_NLlista = "";

if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_NLlista") == false && 
        stristr($param, "totalRows_NLlista") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_NLlista = "&" . htmlentities(implode("&", $newParams));
  }
}

$queryString_NLlista = sprintf("&totalRows_NLlista=%d%s", $totalRows_NLlista, $queryString_NLlista);
$srf = "/";

?>