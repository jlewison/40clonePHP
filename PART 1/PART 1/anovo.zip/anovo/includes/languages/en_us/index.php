<?php
$LANG['login_title'] = 'Anova Answers';
$LANG['login_error'] = 'Error in login!';
$LANG['login_user_name'] = 'Email';
$LANG['login_password'] = 'Password';
$LANG['login_submit'] = 'Login';
$LANG['login_tbl_summary'] = 'Container for login form';
$LANG['login_err_tip_compulsory'] = 'Required';
$LANG['login_err_tip_invalid'] = 'Invalid user name or password';
$LANG['login_err_cookies_not_set'] = 'Need to enable cookies to login.';
$LANG['login_err_invalid_login'] = 'Invalid login details provided. Invalid username or password. Reason not displayed for security reasons.';
$LANG['login_err_sorry'] = 'Sorry, errors detected!';
$LANG['login_err_authorization_required'] = 'Authorization required.';
$LANG['login_err_session_expired'] = 'Session expired.';
$LANG['login_err_invalid_user_session'] = 'Invalid user session.';
$LANG['login_err_invalid_session'] = 'Invalid session.';
$LANG['login_err_wrong_ip'] = 'Change in IP detected.';
$LANG['login_err_wrong_user_agent'] = 'Change in IP detected.';
$LANG['index_title'] = 'Anova - Answers';
$LANG['index_submit'] = 'Next';
$LANG['index_tbl_summary'] = 'Add Stock picks';
$LANG['index_stock_symbol'] = 'Stock Symbol';
$LANG['index_signup_heading'] = 'Not a Member Yet?';
$LANG['index_signup_sub_heading'] = 'Sign up below and get recommendations within seconds.';
$LANG['index_pick_heading'] = 'Enter 3 stock symbols to get started.';
$LANG['index_pick_sub_heading'] = '- (You can enter more later)<br />

- The system finds the portfolios most correlated with yours.<br />

- The algorithm generates five recommendations.';
$LANG['index_pick_text'] = '';
$LANG['index_pick_text_free'] = '';
$LANG['index_login_email'] = 'Email';
$LANG['index_already_member'] = 'Already a member?';
$LANG['index_login_password'] = 'Password';
$LANG['login_remember'] = 'Remember login?';
$LANG['index_login_submit'] = 'Login';
$LANG['index_forget_password'] = 'Forget Password?';
?>