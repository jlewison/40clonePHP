<?php

	$lang['page_title']	= 'Minifeed';
	
	$lang['mini_feed']	= 'Minifeed';
	
	$lang['minifeed_delete_success']	= 'Your minifeed has been deleted Successfully.';
	$lang['minifeed_delete_confirm']	= 'Delete Minifeed confirmation';
	$lang['minifeed_delete_question']	= 'Are you sure, you want to delete this minifeed';
	
	$lang['minifeed_none']	= 'No minifeeds';

?>