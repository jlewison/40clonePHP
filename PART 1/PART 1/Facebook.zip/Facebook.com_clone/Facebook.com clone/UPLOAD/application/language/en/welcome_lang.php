<?php

/**
* Language File for welcome
*
*
* @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
* @license
* @since 2007-12-10
*/
$lang['welcome_title']					= 'Welcome to Kootali';
$lang['welcome_name']					= 'Welcome';
$lang['welcome_explore']				= 'You\'re now ready to explore Kootali.';
$lang['welcome_find_friends']			= 'Find Friends';
$lang['welcome_friends_note']			= 'Finding your friends makes your Kootali experience better. You can search for classmates or coworkers or look for friends by name.';
$lang['welcome_requests']				= 'Requests';
$lang['welcome_grioups']				= 'groups';
$lang['welcome_events']					= 'events';
$lang['welcome_friends']				= 'friends';
$lang['welcome_invitations']			= 'invitations';
$lang['welcome_no_requests']			= 'No requests';
$lang['welcome_status_update']			= 'Status Updates';
$lang['welcome_status_note']			= 'Update your status..';
$lang['welcome_cancel']					= 'Cancel';
$lang['welcome_invite_friends']			= 'Invite your Friends';
$lang['welcome_invite_friends_join']	= 'Invite your friends to join Kootali.';
?>