<?php include('settings.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php echo("$lang_0");?>
<?php echo("$lang_01");?>
<title>Under Maintenance</title>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
-->
</style></head>

<body>
<div align="center"><img src="<?php echo("$path");?>img/disabled.gif" alt="Under Maintenance" width="460" height="466" /></div>
</body>
</html>
