<?php
$file = 'somefile.txt';
$remote_file = 'l.php';

// set up basic connection
$conn_id = ftp_connect("localhost");

// login with username and password
$login_result = ftp_login($conn_id, "root", "triadpass");

// upload a file
if (ftp_put($conn_id, $remote_file, $file, FTP_ASCII)) {
echo "successfully uploaded $file\n";
} else {
echo "There was a problem while uploading $file\n";
}

// close the connection
ftp_close($conn_id);
?>
