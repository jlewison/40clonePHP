<?php
error_reporting(0);
include_once ('functions.php');
//******************************** START OF SCRIPT - SETTING VARIABLE ****************************\\
$username = $_POST["username"];
$password = $_POST["password"];
$refering_site = "http://mail.live.com/"; //setting the site for refer
$browser_agent = "Mozilla/5.0 (Windows; U; Windows NT 5.0; en-US; rv:1.4) Gecko/20030624 Netscape/7.1 (ax)"; //setting browser type
$path_to_cookie = realpath('livecookie.txt');
$setcookie = fopen($path_to_cookie, 'wb'); //this opens the file and resets it to zero length
fclose($setcookie);
//*********************** | LOGGING ONTO HOTMAIL STEP 1 | ***********************************\\
$login_page = "http://login.live.com/login.srf?id=64855";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $login_page);
curl_setopt($ch, CURLOPT_USERAGENT, $browser_agent);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_REFERER, $login_page);
curl_setopt($ch, CURLOPT_COOKIEFILE, $path_to_cookie);
curl_setopt($ch, CURLOPT_COOKIEJAR, $path_to_cookie);
$page_result = curl_exec($ch);
curl_close($ch);
//echo $page_result;
//echo "<textarea rows=30 cols=120>".$page_result."</textarea>";       //DEBUG -- this will pages html in nice box
preg_match_all("/name=\"PPFT\" id=\"i0327\" value=\"(.*?)\"/", $page_result, $matches1);
//print_r($matches1);                     // DEBUG -- this will print the whole array
$found1 = $matches1[1][0]; // stores the hidden text in a ariable to use later in POST
//echo $found1;
preg_match_all("/srf_uPost='(.*?)';var/", $page_result, $matches2);
//print_r($matches2);                     // DEBUG -- this will print the whole array
$found2 = $matches2[1][0]; // stores the hidden text in a ariable to use later in POST
//echo $found2;
//******************************* | SUBMIT LOGIN INFORMATION | ************************************\\
$login_page2 = $found2;
$postdata1 = 'idsbho=1&PwdPad=IfYouAreReadingThisYouHaveTooMuc&LoginOptions=3&login=' . $username . '&passwd=' . $password . '&NewUser=1&PPFT=' . $found1;
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $login_page2);
curl_setopt($ch, CURLOPT_USERAGENT, $browser_agent);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_REFERER, $login_page);
curl_setopt($ch, CURLOPT_COOKIEFILE, $path_to_cookie);
curl_setopt($ch, CURLOPT_COOKIEJAR, $path_to_cookie);
$page_result2 = curl_exec($ch);
curl_close($ch);
//echo "<textarea rows=30 cols=120>".$page_result2."</textarea>";       //DEBUG -- this will pages html in nice box
//echo $page_result2;
// ********  GET REDIRECT URL 1  *******
preg_match_all("/replace\(\"(.*?)\"/", $page_result2, $matches3);
//print_r($matches3);                     // DEBUG -- this will print the whole array
$found3 = $matches3[1][0]; // stores the hidden text in a ariable to use later in POST
//echo $found3;
//***************************************** | REDIRECT 1 | *****************************************\\
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $found3);
curl_setopt($ch, CURLOPT_USERAGENT, $browser_agent);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_REFERER, $login_page2);
curl_setopt($ch, CURLOPT_COOKIEFILE, $path_to_cookie);
curl_setopt($ch, CURLOPT_COOKIEJAR, $path_to_cookie);
$page_result3 = curl_exec($ch);
curl_close($ch);
//echo "<textarea rows=30 cols=120>".$page_result3."</textarea>";       //DEBUG -- this will pages html in nice box
//echo $page_result3;
preg_match_all("/href=\"(.*?)\"/", $page_result3, $matches4);
//print_r($matches4);                     // DEBUG -- this will print the whole array
$found4 = $matches4[1][0]; // stores the hidden text in a ariable to use later in POST
//echo $found4;
$found100 = preg_replace("/\/mail.*/", '', $found4);
//echo $found100;
//echo '</p><p>';
$found101 = $found100 . '/mail/mail.aspx';
//echo $found101;
//***************************************** | OPENING INBOX | *****************************************\\
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $found101);
curl_setopt($ch, CURLOPT_USERAGENT, $browser_agent);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_REFERER, $found3);
curl_setopt($ch, CURLOPT_COOKIEFILE, $path_to_cookie);
curl_setopt($ch, CURLOPT_COOKIEJAR, $path_to_cookie);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 0);
$page_result4 = curl_exec($ch);
curl_close($ch);
//echo "<textarea rows=30 cols=120>".$page_result4."</textarea>";       //DEBUG -- this will pages html in nice box
//echo $page_result4;
preg_match_all("/\"\/(.*?)\"/", $page_result4, $matches4);
//print_r($matches4);                     // DEBUG -- this will print the whole array
$found = $matches4[1][0]; // stores the hidden text in a ariable to use later in POST
//echo $found;
$found101 = $found100 . '/' . $found;
//***************************************** | OPENING INBOX | *****************************************\\
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $found101);
curl_setopt($ch, CURLOPT_USERAGENT, $browser_agent);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_REFERER, $found3);
curl_setopt($ch, CURLOPT_COOKIEFILE, $path_to_cookie);
curl_setopt($ch, CURLOPT_COOKIEJAR, $path_to_cookie);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 0);
$page_result4 = curl_exec($ch);
curl_close($ch);
//echo "<textarea rows=30 cols=120>".$page_result4."</textarea>";       //DEBUG -- this will pages html in nice box
//echo $page_result4;
preg_match_all("/InboxLight.aspx.n=(.*?)\"/", $page_result4, $matches4);
//print_r($matches4);                     // DEBUG -- this will print the whole array
$found = $matches4[1][0]; // stores the hidden text in a ariable to use later in POST
//echo $found;
$found101 = $found100 . '/mail/InboxLight.aspx?n=' . $found;
//***************************************** | OPENING INBOX | *****************************************\\
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $found101);
curl_setopt($ch, CURLOPT_USERAGENT, $browser_agent);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_REFERER, $found3);
curl_setopt($ch, CURLOPT_COOKIEFILE, $path_to_cookie);
curl_setopt($ch, CURLOPT_COOKIEJAR, $path_to_cookie);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 0);
$page_result4 = curl_exec($ch);
curl_close($ch);
//echo "<textarea rows=30 cols=120>".$page_result4."</textarea>";       //DEBUG -- this will pages html in nice box
//echo $page_result4;
//***************************************** | OPENING INBOX | *****************************************\\
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $found101);
curl_setopt($ch, CURLOPT_USERAGENT, $browser_agent);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_REFERER, $found3);
curl_setopt($ch, CURLOPT_COOKIEFILE, $path_to_cookie);
curl_setopt($ch, CURLOPT_COOKIEJAR, $path_to_cookie);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 0);
$page_result4 = curl_exec($ch);
curl_close($ch);
//echo "<textarea rows=30 cols=120>".$page_result4."</textarea>";       //DEBUG -- this will pages html in nice box
//echo $page_result4;
preg_match_all("/EditMessageLight.aspx._ec=1&n.(.*?)\"/", $page_result4, $matches4);
//print_r($matches4);                     // DEBUG -- this will print the whole array
$found = $matches4[1][0]; // stores the hidden text in a ariable to use later in POST
//echo $found;
$found101 = $found100 . '/mail/EditMessageLight.aspx?_ec=1&n=' . $found;
//***************************************** | OPENING INBOX | *****************************************\\
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $found101);
curl_setopt($ch, CURLOPT_USERAGENT, $browser_agent);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_REFERER, $found3);
curl_setopt($ch, CURLOPT_COOKIEFILE, $path_to_cookie);
curl_setopt($ch, CURLOPT_COOKIEJAR, $path_to_cookie);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 0);
$page_result4 = curl_exec($ch);
curl_close($ch);
//echo "<textarea rows=30 cols=120>".$page_result4."</textarea>";       //DEBUG -- this will pages html in nice box
//echo $page_result4;
//WRITING THE RESULTS TO A CSV FILE ON THE SERVER
preg_match_all("/href=\"javascript:pickContact.'(.*?)', '(.*?)'/", $page_result4, $matches, PREG_SET_ORDER);
//print_r($matches);
// CHECKING IF ANY CONTACTS EXIST
$checkarray = $matches[1][1];
if (empty($checkarray))
{
?>
<p align="center"><font face="Verdana" size="2"><b>No Details Found:</b> Please make sure you have entered correct login details and try again.</font></p><p align="center">
<?php
}
else
{
		//***************** | LOGGING ONTO GMAIL STEP 8 [html display] | ********************\\
		//
		//
		//
		//
		//
		//***********************************************************************************\\



?>
<html>
<head>
<title>CONTACTS</title>
<script type="text/javascript"><!--

var formblock;
var forminputs;

function prepare() {
formblock= document.getElementById('form_id');
forminputs = formblock.getElementsByTagName('input');
}

function select_all(name, value) {
for (i = 0; i < forminputs.length; i++) {
// regex here to check name attribute
var regex = new RegExp(name, "i");
if (regex.test(forminputs[i].getAttribute('name'))) {
if (value == '1') {
forminputs[i].checked = true;
} else {
forminputs[i].checked = false;
}
}
}
}

if (window.addEventListener) {
window.addEventListener("load", prepare, false);
} else if (window.attachEvent) {
window.attachEvent("onload", prepare)
} else if (document.getElementById) {
window.onload = prepare;
}

//--></script>
</head>
<body>
<div align="center">
<center>
<table border="0" width="578" bgcolor="#FFFFFF"><tr>
<TD width="622"><IMG height=2 alt="" src="images/spacer.gif" width=1 border=0></TD>
</tr><tr><TD align=middle width="622"><TABLE cellSpacing=0 cellPadding=0 width=640 border=0>
<TBODY><TR><TD width=5 height=5><IMG height=5 alt="" src="images/tls.gif" width=5 border=0></TD>
<TD background="images/t.gif" colSpan=2 width="716"><IMG height=1 alt="" src="images/spacer.gif" width=1 border=0></TD>
<TD width=6 height=5><IMG height=5 alt="" src="images/trs.gif" width=5 border=0></TD></TR><TR>
<TD width=5 background="images/l.gif" height=5><IMG height=5 alt="" src="images/spacer.gif" width=5 border=0></TD>
<TD width=6><IMG height=1 alt="" src="images/spacer.gif" width=6 border=0></TD><TD vAlign=top width=704>
<table border="0" width="100%"><tr><td width="100%" bgcolor="#D7D8DF">
<p align="center"><font face="Arial" size="3" color="#333333">My Contacts</font></td></tr></table>
<p align="center">
 <form id="form_id" name="myform" method="post" action="postage.php" onSubmit="return false">
	<div align="center"><center>
<table border="0" cellpadding="3" cellspacing="6" width="100%">
	<tr>
		<th width="22" bgcolor="#F5F5F5"><input type="checkbox" class="clsCheckRadio" name="check_all" onclick="CheckAll(document.myform.name, document.myform.check_all.name)" /></th>
		<!--<th width="22" bgcolor="#F5F5F5">Name</th>-->
		<th width="22" bgcolor="#F5F5F5">Email</th>
	</tr>
<?php
		$i = 0;
		while (isset($matches[$i]))
		{
				//  [RESULTS - START OF CONTACTS LIST]
				$name = $matches[$i][2];
				if (empty($name))
				{
						$longname = str_replace('%40', '@', ($matches[$i][1]));
						list($name, $domains) = split('@', $longname);
						$email = $matches[$i][1];
						$email = str_replace('\x40', '@', $email);
						$email = getEmailAddress($email);
				}
				if (strlen($email) < 5)
				{
						$i++;
						continue;
				}
?>
	<tr>
		<td width="22" bgcolor="#F5F5F5"><input type="checkbox" name="list[]" value="<?php echo $email; ?>"></td>
		<!--<td width="269" bgcolor="#F5F5F5"><p align="center"><font face="Verdana" size="2"><?php echo $name; ?></font></td>-->
		<td width="296" bgcolor="#F5F5F5"><p align="center"><font face="Verdana" size="2"><?php echo $email; ?></font></td>
	</tr>
<?php
				$i++;
		}
		//  [RESULTS - START OF FOOTER]

?>
</table></center></div>
<table border="0" width="100%"><tr><td width="100%">
<p align="center"><font face="Arial" size="2"><br></font><br>
<p></p><p align="center"><input type="button" value="Add contacts" name="B1" style="background-color: #808080; color: #FFFFFF; font-family: Arial; font-size: 10pt; font-weight: bold; border: 1 solid #333333" onClick="addContacts()"></p></form></td></tr>
</table><IMG height=1 alt="" src="images/spacer.gif" width=1 border=0></TD>
<TD width=6 background="images/r.gif" height=5><IMG height=1 alt="" src="images/spacer.gif" width=1 border=0></TD></TR>
<TR><TD width=5 height=5><IMG height=5 alt="" src="images/bls.gif" width=5 border=0></TD>
<TD background="images/b.gif" colSpan=2 width="716"><IMG height=1 alt="" src="images/spacer.gif" width=1 border=0></TD>
<TD width=6 height=5><IMG height=5 alt="" src="images/brs.gif" width=5 border=0></TD></TR></TBODY></TABLE></TD>                      </tr></table></center></div></body></html>
<?php
		//*********************** | END OF SCRIPT | ***********************************\\
}
?>