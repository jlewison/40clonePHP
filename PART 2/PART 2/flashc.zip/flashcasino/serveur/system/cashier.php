<? include ("header.php"); ?>








<? include ("menugames.php"); ?>













          <TD class=fgi_flsh vAlign=top><SPAN class=fgi_gttl>PLAYING FOR 
            REAL</SPAN><BR>
            <TABLE class=fgi_chips cellSpacing=0 cellPadding=0 width="100%" 
            border=0>
              <TBODY>
              <TR>
                <TD class=t><IMG 
                  src="fgi/chips_tl.jpg"></TD>
                <TD class=t align=right><IMG 
                  src="fgi/chips_tr.jpg"></TD></TR>
              <TR>
                <TD class=l>Welcome <B><? echo $l; ?></B>&nbsp;&nbsp;&nbsp;&nbsp;your balance 
                  account : <? echo $rog1[3]; ?></TD>
                <TD class=r align=right><A 
                  href="cashier.php"><IMG hspace=10 
                  src="fgi/cashier.jpg"></A><A 
                  href="logout.php"><IMG 
                  src="fgi/logout.jpg"></A></TD></TR>
              <TR>
                <TD class=b><IMG 
                  src="fgi/chips_bl.jpg"></TD>
                <TD class=b align=right><IMG 
                  src="fgi/chips_br.jpg"></TD></TR></TBODY></TABLE>
            <TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
              <TBODY>
              







               <?
include ("setup.php");
$resultg=mysql_query("select * from seting ");
$rog=mysql_fetch_array($resultg);
?>



	
	

	
	

	
		

             
            <TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
              <TBODY>
              <TR>
                <TD width=10><IMG 
                  src="fgi/d_tl.jpg"></TD>
                <TD class=fgdt colSpan=3><IMG 
                  src="fgi/d_t.jpg"></TD>
                <TD width=10><IMG 
                  src="fgi/d_tr.jpg"></TD></TR>
              <TR>
                <TD class=fgdl><IMG 
                  src="fgi/d_l.jpg"></TD>
                <TD class=fgd colSpan=3>
                  <center><H3><a class=fga  href='javascript:OuvrirPop("<? echo $rog[3]; ?>/system/in.php","fencent",10,10,650,650,"menubar=no,scrollbars=yes,statusbar=no")'> Deposit Funds </a></H3>



</center></TD>
                <TD class=fgdr><IMG 
                  src="fgi/d_r.jpg"></TD></TR>
              <TR>
                <TD class=fgdl><IMG 
                  src="fgi/d_l.jpg"></TD>
                <TD class=fgdb colSpan=3><IMG 
                  src="fgi/d_b.jpg"></TD>
                <TD class=fgdr><IMG 
                  src="fgi/d_r.jpg"></TD></TR>	


<TR><TD><BR></TR></TD>


<TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
              <TBODY>
              <TR>
                <TD width=10><IMG 
                  src="fgi/d_tl.jpg"></TD>
                <TD class=fgdt colSpan=3><IMG 
                  src="fgi/d_t.jpg"></TD>
                <TD width=10><IMG 
                  src="fgi/d_tr.jpg"></TD></TR>
              <TR>
                <TD class=fgdl><IMG 
                  src="fgi/d_l.jpg"></TD>
                <TD class=fgd colSpan=3>
                  <center><H3><a  class=fga href="<? echo $rog[3]; ?>/system/command.php">Deposit History </a></H3>

</center></TD>
                <TD class=fgdr><IMG 
                  src="fgi/d_r.jpg"></TD></TR>
              <TR>
                <TD class=fgdl><IMG 
                  src="fgi/d_l.jpg"></TD>
                <TD class=fgdb colSpan=3><IMG 
                  src="fgi/d_b.jpg"></TD>
                <TD class=fgdr><IMG 
                  src="fgi/d_r.jpg"></TD></TR>	


<TR><TD><BR></TR></TD>

<TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
              <TBODY>
              <TR>
                <TD width=10><IMG 
                  src="fgi/d_tl.jpg"></TD>
                <TD class=fgdt colSpan=3><IMG 
                  src="fgi/d_t.jpg"></TD>
                <TD width=10><IMG 
                  src="fgi/d_tr.jpg"></TD></TR>
              <TR>
                <TD class=fgdl><IMG 
                  src="fgi/d_l.jpg"></TD>
                <TD class=fgd colSpan=3>
                  
<SCRIPT language=javascript>
    function OuvrirPopup(page,nom,option) {
       window.open(page,nom,option);
    }


  </SCRIPT>








<center><H3><a class=fga  href='javascript:OuvrirPop("<? echo $rog[3]; ?>/system/out.php","fencent",10,10,650,550,"menubar=no,scrollbars=no,statusbar=no")'> Withdraw Funds </a></H3>




</center></TD>
                <TD class=fgdr><IMG 
                  src="fgi/d_r.jpg"></TD></TR>
              <TR>
                <TD class=fgdl><IMG 
                  src="fgi/d_l.jpg"></TD>
                <TD class=fgdb colSpan=3><IMG 
                  src="fgi/d_b.jpg"></TD>
                <TD class=fgdr><IMG 
                  src="fgi/d_r.jpg"></TD></TR>	


<TR><TD><BR></TR></TD>

<TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
              <TBODY>
              <TR>
                <TD width=10><IMG 
                  src="fgi/d_tl.jpg"></TD>
                <TD class=fgdt colSpan=3><IMG 
                  src="fgi/d_t.jpg"></TD>
                <TD width=10><IMG 
                  src="fgi/d_tr.jpg"></TD></TR>
              <TR>
                <TD class=fgdl><IMG 
                  src="fgi/d_l.jpg"></TD>
                <TD class=fgd colSpan=3>
                  <center><H3><a  class=fga href="<? echo $rog[3]; ?>/system/commande.php">Withdrawal History  </a></H3>

</center></TD>
                <TD class=fgdr><IMG 
                  src="fgi/d_r.jpg"></TD></TR>
              <TR>
                <TD class=fgdl><IMG 
                  src="fgi/d_l.jpg"></TD>
                <TD class=fgdb colSpan=3><IMG 
                  src="fgi/d_b.jpg"></TD>
                <TD class=fgdr><IMG 
                  src="fgi/d_r.jpg"></TD></TR>	


<TR><TD><BR></TR></TD>

<TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
              <TBODY>
              <TR>
                <TD width=10><IMG 
                  src="fgi/d_tl.jpg"></TD>
                <TD class=fgdt colSpan=3><IMG 
                  src="fgi/d_t.jpg"></TD>
                <TD width=10><IMG 
                  src="fgi/d_tr.jpg"></TD></TR>
              <TR>
                <TD class=fgdl><IMG 
                  src="fgi/d_l.jpg"></TD>
                <TD class=fgd colSpan=3>
                  <center><H3><a  class=fga class="buttonlink" href="<? echo $rog[3]; ?>/system/stat.php">Game cash History </a></H3>

</center></TD>
                <TD class=fgdr><IMG 
                  src="fgi/d_r.jpg"></TD></TR>
              <TR>
                <TD class=fgdl><IMG 
                  src="fgi/d_l.jpg"></TD>
                <TD class=fgdb colSpan=3><IMG 
                  src="fgi/d_b.jpg"></TD>
                <TD class=fgdr><IMG 
                  src="fgi/d_r.jpg"></TD></TR>	


<TR><TD><BR></TR></TD>

<TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
              <TBODY>
              <TR>
                <TD width=10><IMG 
                  src="fgi/d_tl.jpg"></TD>
                <TD class=fgdt colSpan=3><IMG 
                  src="fgi/d_t.jpg"></TD>
                <TD width=10><IMG 
                  src="fgi/d_tr.jpg"></TD></TR>
              <TR>
                <TD class=fgdl><IMG 
                  src="fgi/d_l.jpg"></TD>
                <TD class=fgd colSpan=3>
                  <center><H3><a  class=fga href="<? echo $rog[3]; ?>/system/config.php">PERSONAL DATA</a></H3>

</center></TD>
                <TD class=fgdr><IMG 
                  src="fgi/d_r.jpg"></TD></TR>
              <TR>
                <TD class=fgdl><IMG 
                  src="fgi/d_l.jpg"></TD>
                <TD class=fgdb colSpan=3><IMG 
                  src="fgi/d_b.jpg"></TD>
                <TD class=fgdr><IMG 
                  src="fgi/d_r.jpg"></TD></TR>	


<TR><TD><BR></TR></TD>







		
               
            <TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
              <TBODY>
              <TR>
                <TD width=10><IMG 
                  src="fgi/d_tl.jpg"></TD>
                <TD class=fgdt colSpan=3><IMG 
                  src="fgi/d_t.jpg"></TD>
                <TD width=10><IMG 
                  src="fgi/d_tr.jpg"></TD></TR>
              <TR>
                <TD class=fgdl><IMG 
                  src="fgi/d_l.jpg"></TD>
                <TD class=fgd colSpan=3>
                  <center><H3><a  class=fga class="buttonlink" href="<? echo $rog[3]; ?>/system/partner.php">Casino Affiliate Program </a></H3>

</center></TD>
                <TD class=fgdr><IMG 
                  src="fgi/d_r.jpg"></TD></TR>
              <TR>
                <TD class=fgdl><IMG 
                  src="fgi/d_l.jpg"></TD>
                <TD class=fgdb colSpan=3><IMG 
                  src="fgi/d_b.jpg"></TD>
                <TD class=fgdr><IMG 
                  src="fgi/d_r.jpg"></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></TD>
    <TD>&nbsp;</TD></TR>











  




<? include ("footer.php"); ?>





