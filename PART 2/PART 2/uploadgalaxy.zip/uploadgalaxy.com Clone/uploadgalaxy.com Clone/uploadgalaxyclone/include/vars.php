<?
define("SITE","filebyemail.com");                  //Site
define("SITE_NAME","FileByEmail");             //Name of your Site
define("SITE_SLOGUN","Files to big for email?");                    //Slogan of your site(can be left blank)
define("SITE_URL","filebyemail.com");   //URL of site
define("ADMIN_INSTALL_USERNAME", "admin");   //Username of admin to be created with installation

////////////////////////////////////
//NO USER EDITING PAST THIS POINT
////////////////////////////////////
define("NO_PASS_THRU","1");
define("PARTIAL_TRANSFER","1");
define("SPEED_LIMIT","");
?>
