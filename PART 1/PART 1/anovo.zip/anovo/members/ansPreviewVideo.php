<?php
require_once ('../common/config.inc.php');
require_once ('../common/configs/config_encoder.inc.php');
require_once ('../common/configs/config_ans_video.inc.php');
$CFG['lang']['include_files'][] = 'members/includes/languages/%s/ansViewVideo.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['mods']['is_include_only']['non_html_header_files'] = true;
$CFG['is']['ajax_page'] = true;
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class VideoUpload extends FormHandler
{
		public $video_details;
		public function chkIsValidPreviewVideo()
		{
				$param_arr = explode('_', $this->fields_arr['pg']);
				$this->fields_arr['video_for'] = $param_arr[0];
				$this->fields_arr['vid'] = $param_arr[1];
				$file_name = $this->CFG['admin']['video']['red5_flv_path'] . $this->fields_arr['vid'] . '.flv';
				if (is_file($file_name))
				{
						$temp_dir = '../' . $this->CFG['admin']['ans_videos']['temp_folder'];
						$this->chkAndCreateFolder($temp_dir);
						$temp_file = $temp_dir . $this->fields_arr['vid'] . '.flv';
						if (file_exists($temp_file)) @unlink($temp_file);
						copy($file_name, $temp_file);
						return true;
				}
				return false;
		}
		public function resetFieldsArray()
		{
				$this->setFormField('pg', '');
		}
}
$VideoUpload = new VideoUpload();
$VideoUpload->setDBObject($db);
$VideoUpload->makeGlobalize($CFG, $LANG);
if (!isAjax()) Redirect2URL($CFG['site']['url']);
$VideoUpload->setHeaderStart();
$VideoUpload->setPageBlockNames(array('msg_form_error', 'msg_form_success', 'video_display'));
$VideoUpload->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$VideoUpload->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$VideoUpload->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$VideoUpload->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$VideoUpload->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$VideoUpload->resetFieldsArray();
$VideoUpload->setAllPageBlocksHide();
$VideoUpload->sanitizeFormInputs($_REQUEST);
if ($VideoUpload->isFormGETed($_REQUEST, 'pg'))
{
		if (!$VideoUpload->chkIsValidPreviewVideo())
		{
				$VideoUpload->setAllPageBlocksHide();
				$VideoUpload->setCommonErrorMsg($LANG['error_video']);
				$VideoUpload->setPageBlockShow('msg_form_error');
		}
		else
		{
				$VideoUpload->setPageBlockShow('video_display');
		}
}



?>
<div id="selVideoUpload" class="">
	<p class="clsPopupClose"><a href="#" onClick="return closLightWindow()"><?php echo $LANG['close']; ?></a></p>
	<div id="selLeftNavigation">
<?php
if ($VideoUpload->isShowPageBlock('msg_form_error'))
{
?>
		  <div id="selMsgError">
		    <p><?php echo $VideoUpload->getCommonErrorMsg(); ?></p>
		  </div>
<?php
}
if ($VideoUpload->isShowPageBlock('video_display'))
{
		$videos_folder = $CFG['admin']['ans_videos']['folder'];
		$flv_player_url = $CFG['site']['url'] . 'files/flash/flv_player/flvplayer.swf';
		$arguments_play = 'pg=previewvideo_' . $VideoUpload->getFormField('vid');
		$configXmlcode_url = $CFG['site']['url'] . 'ansVideoConfigXmlCode.php?';
		echo '<embed src="' . $flv_player_url . '" FlashVars="config=' . $configXmlcode_url . $arguments_play . '" quality="high" allowFullScreen="true" bgcolor="#000000" width="450" height="370" name="flvplayer" align="middle" allowScriptAccess="always" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" wmode="' . $CFG['admin']['wmode_value'] . '" />';
}
?>
	</div>
</div>
<?php


$VideoUpload->setHeaderEnd();
?>