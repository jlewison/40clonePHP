<?php
require_once ('../common/config.inc.php');
require_once ('../common/configs/config_ans_photo.inc.php');
require_once ('../common/configs/config_index.inc.php');
$CFG['lang']['include_files'][] = 'admin/includes/languages/%s/editMembers.php';
$CFG['lang']['include_files'][] = 'common/email_templates/languages/%s/email_notify.inc.php';
$CFG['html']['header'] = 'admin/includes/languages/%s/html_header.php';
$CFG['html']['footer'] = 'admin/includes/languages/%s/html_footer.php';
$CFG['mods']['include_files'][] = 'common/classes/class_Image.lib.php';
$CFG['mods']['include_files'][] = 'common/classes/class_ftp.lib.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['lang']['include_files'][] = 'common/languages/%s/help.inc.php';
$CFG['db']['is_use_db'] = true;
$CFG['mods']['is_include_only']['non_html_header_files'] = true;
if ($_POST) $CFG['mods']['include_files'][] = 'common/classes/phpmailer/class_PHPMailer.lib.php';
require ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class EditMembersHandler extends FormHandler
{
		public function updateFormFieldsInTable($table_name, $user_id, $fields_to_insert_arr = array())
		{
				$this->fields_arr['subscribe_keywords'] = $this->removeDuplicateKeywords($this->fields_arr['subscribe_keywords']);
				$field_names_separated_by_comma = '';
				$parameters_separated_by_comma = '';
				$field_values_arr = array();
				foreach ($fields_to_insert_arr as $field_name)
						if (isset($this->fields_arr[$field_name]))
						{
								$field_names_separated_by_comma .= $field_name . '=' . $this->dbObj->Param($field_name) . ', ';
								$field_values_arr[] = $this->fields_arr[$field_name];
						}
				$field_names_separated_by_comma = substr($field_names_separated_by_comma, 0, strrpos($field_names_separated_by_comma, ','));
				$sql = 'UPDATE ' . $table_name . ' SET ' . $field_names_separated_by_comma;
				$sql .= ' WHERE user_id =' . $this->dbObj->Param($user_id);
				$field_values_arr[] = $user_id;
				$stmt = $this->dbObj->Prepare($sql);
				$result = $this->dbObj->Execute($stmt, $field_values_arr);
				if (!$result) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function updateFormFieldsInUserTable($table_name, $user_id, $fields_to_insert_arr = array())
		{
				$this->fields_arr['subscribe_keywords'] = $this->removeDuplicateKeywords($this->fields_arr['subscribe_keywords']);
				$field_names_separated_by_comma = '';
				$parameters_separated_by_comma = '';
				$field_values_arr = array();
				foreach ($fields_to_insert_arr as $field_name)
						if (isset($this->fields_arr[$field_name]))
						{
								$field_names_separated_by_comma .= $this->getUserTableField($field_name) . '=' . $this->dbObj->Param($field_name) . ', ';
								$field_values_arr[] = $this->fields_arr[$field_name];
						}
				$field_names_separated_by_comma = substr($field_names_separated_by_comma, 0, strrpos($field_names_separated_by_comma, ','));
				$sql = 'UPDATE ' . $table_name . ' SET ' . $field_names_separated_by_comma;
				$sql .= ' WHERE user_id =' . $this->dbObj->Param($user_id);
				$field_values_arr[] = $user_id;
				$stmt = $this->dbObj->Prepare($sql);
				$result = $this->dbObj->Execute($stmt, $field_values_arr);
				if (!$result) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function updateUserImagePath()
		{
				$image_path = $this->fields_arr['image_path'];
				$user_id = $this->fields_arr['uid'];
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['users'] . ' SET ' . $this->getUserTableField('image_path') . '=' . $this->dbObj->Param($image_path) . ' WHERE ' . $this->getUserTableField('user_id') . '=' . $this->dbObj->Param($user_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($image_path, $user_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function getUserDetailsArrFromDB($table_name, $fields_arr = array(), $user_id)
		{
				$sql = 'SELECT ';
				foreach ($fields_arr as $field_name) $sql .= $field_name . ', ';
				$sql = substr($sql, 0, strrpos($sql, ','));
				$sql .= ' FROM ' . $table_name . ' WHERE user_id=' . $this->dbObj->Param($user_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($user_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = array();
				if ($rs->PO_RecordCount()) $row = $rs->FetchRow();
				$ret_fields_arr = array();
				foreach ($fields_arr as $field_name) $ret_fields_arr[$field_name] = isset($row[$field_name]) ? $row[$field_name] : '';
				return $ret_fields_arr;
		}
		public function setIHObject($imObj)
		{
				$this->imageObj = $imObj;
		}
		public function chkValidFileType($field_name, $err_tip = '')
		{
				$this->EXTERN = strtolower(substr($_FILES[$field_name]['name'], strrpos($_FILES[$field_name]['name'], '.') + 1));
				if (!in_array($this->EXTERN, $this->CFG['admin']['ans_photos']['format_arr']))
				{
						$this->fields_err_tip_arr[$field_name] = $err_tip;
						return false;
				}
				return true;
		}
		public function chkValideFileSize($field_name, $err_tip = '')
		{
				$max_size = $this->CFG['admin']['ans_photos']['max_size'] * 1024;
				if ($_FILES[$field_name]['size'] > $max_size)
				{
						$this->fields_err_tip_arr[$field_name] = $err_tip;
						return false;
				}
				return true;
		}
		public function chkErrorInFile($field_name, $err_tip = '')
		{
				if ($_FILES[$field_name]['error'])
				{
						$this->fields_err_tip_arr[$field_name] = $err_tip;
						return false;
				}
				return true;
		}
		public function getServerDetails()
		{
				$sql = 'SELECT server_url, ftp_server, ftp_usrename, ftp_password' . ' FROM ' . $this->CFG['db']['tbl']['server_settings'] . ' WHERE server_for=\'Ans_photo\' AND server_status=\'Yes\' LIMIT 0,1';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = array();
				if ($rs->PO_RecordCount())
				{
						$row = $rs->FetchRow();
						$this->fields_arr['ftp_server'] = $row['ftp_server'];
						$this->fields_arr['ftp_usrename'] = $row['ftp_usrename'];
						$this->fields_arr['ftp_password'] = $row['ftp_password'];
						$this->fields_arr['server_url'] = $row['server_url'];
						return true;
				}
				return false;
		}
		public function storeImagesTempServer($uploadUrl, $extern)
		{
				if ($this->CFG['admin']['ans_photos']['large_name'] == 'L')
				{
						if ($this->CFG['admin']['ans_photos']['large_height'] or $this->CFG['admin']['ans_photos']['large_width'])
						{
								$this->imageObj->resize($this->CFG['admin']['ans_photos']['large_width'], $this->CFG['admin']['ans_photos']['large_height'], '-');
								$this->imageObj->output_resized($uploadUrl . 'L.' . $extern, strtoupper($extern));
								$image_info = getImageSize($uploadUrl . 'L.' . $extern);
								$this->L_WIDTH = $image_info[0];
								$this->L_HEIGHT = $image_info[1];
						}
						else
						{
								$this->imageObj->output_original($uploadUrl . 'L.' . $extern, strtoupper($extern));
								$image_info = getImageSize($uploadUrl . 'L.' . $extern);
								$this->L_WIDTH = $image_info[0];
								$this->L_HEIGHT = $image_info[1];
						}
				}
				if ($this->CFG['admin']['ans_photos']['thumb_name'] == 'T')
				{
						$this->imageObj->resize($this->CFG['admin']['ans_photos']['thumb_width'], $this->CFG['admin']['ans_photos']['thumb_height'], '-');
						$this->imageObj->output_resized($uploadUrl . 'T.' . $extern, strtoupper($extern));
						$image_info = getImageSize($uploadUrl . 'T.' . $extern);
						$this->T_WIDTH = $image_info[0];
						$this->T_HEIGHT = $image_info[1];
				}
				if ($this->CFG['admin']['ans_photos']['small_name'] == 'S')
				{
						$this->imageObj->resize($this->CFG['admin']['ans_photos']['small_width'], $this->CFG['admin']['ans_photos']['small_height'], '-');
						$this->imageObj->output_resized($uploadUrl . 'S.' . $extern, strtoupper($extern));
						$image_info = getImageSize($uploadUrl . 'S.' . $extern);
						$this->S_WIDTH = $image_info[0];
						$this->S_HEIGHT = $image_info[1];
				}
				$wname = $this->CFG['admin']['ans_photos']['large_name'] . '_WIDTH';
				$hname = $this->CFG['admin']['ans_photos']['large_name'] . '_HEIGHT';
				$this->L_WIDTH = $this->$wname;
				$this->L_HEIGHT = $this->$hname;
				$wname = $this->CFG['admin']['ans_photos']['thumb_name'] . '_WIDTH';
				$hname = $this->CFG['admin']['ans_photos']['thumb_name'] . '_HEIGHT';
				$this->T_WIDTH = $this->$wname;
				$this->T_HEIGHT = $this->$hname;
				$wname = $this->CFG['admin']['ans_photos']['small_name'] . '_WIDTH';
				$hname = $this->CFG['admin']['ans_photos']['small_name'] . '_HEIGHT';
				$this->S_WIDTH = $this->$wname;
				$this->S_HEIGHT = $this->$hname;
		}
		public function photoUpload()
		{
				$extern = strtolower(substr($_FILES['photo']['name'], strrpos($_FILES['photo']['name'], '.') + 1));
				$this->setFormField('user_id', $this->fields_arr['uid']);
				$this->setFormField('photo_ext', $extern);
				$image_name = getImageName($this->fields_arr['uid']);
				$imageObj = new ImageHandler($_FILES['photo']['tmp_name']);
				$this->setIHObject($imageObj);
				$temp_dir = '../' . $this->CFG['admin']['ans_photos']['temp_folder'];
				$this->chkAndCreateFolder($temp_dir);
				$temp_file = $temp_dir . $image_name;
				$this->storeImagesTempServer($temp_file, $extern);
				$dir = $this->CFG['admin']['ans_photos']['folder'];
				$local_upload = true;
				if ($this->getServerDetails())
				{
						if ($FtpObj = new FtpHandler($this->getFormField('ftp_server'), $this->getFormField('ftp_usrename'), $this->getFormField('ftp_password')))
						{
								$FtpObj->makeDirectory($dir);
								$FtpObj->changeDirectory($dir);
								$FtpObj->moveTo($temp_file . '.' . $extern, $dir . $image_name . '.' . $extern);
								unlink($temp_file . '.' . $extern);
								if ($this->CFG['admin']['ans_photos']['large_name'] == 'L')
								{
										$FtpObj->moveTo($temp_file . 'L.' . $extern, $dir . $image_name . 'L.' . $extern);
										unlink($temp_file . 'L.' . $extern);
								}
								if ($this->CFG['admin']['ans_photos']['thumb_name'] == 'T')
								{
										$FtpObj->moveTo($temp_file . 'T.' . $extern, $dir . $image_name . 'T.' . $extern);
										unlink($temp_file . 'T.' . $extern);
								}
								if ($this->CFG['admin']['ans_photos']['small_name'] == 'S')
								{
										$FtpObj->moveTo($temp_file . 'S.' . $extern, $dir . $image_name . 'S.' . $extern);
										unlink($temp_file . 'S.' . $extern);
								}
								$this->setFormField('server_url', $this->getFormField('server_url'));
								$local_upload = false;
								return;
						}
				}
				if ($local_upload)
				{
						$dir = '../' . $this->CFG['admin']['ans_photos']['folder'];
						$this->chkAndCreateFolder($dir);
						$uploadUrl = $dir . $image_name;
						if ($this->CFG['admin']['ans_photos']['large_name'] == 'L')
						{
								copy($temp_file . 'L.' . $extern, $uploadUrl . 'L.' . $extern);
								unlink($temp_file . 'L.' . $extern);
						}
						if ($this->CFG['admin']['ans_photos']['thumb_name'] == 'T')
						{
								copy($temp_file . 'T.' . $extern, $uploadUrl . 'T.' . $extern);
								unlink($temp_file . 'T.' . $extern);
						}
						if ($this->CFG['admin']['ans_photos']['small_name'] == 'S')
						{
								copy($temp_file . 'S.' . $extern, $uploadUrl . 'S.' . $extern);
								unlink($temp_file . 'S.' . $extern);
						}
						$this->setFormField('server_url', $this->CFG['site']['url']);
				}
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['users'] . ' SET' . ' ' . $this->CFG['users']['t_width'] . '=\'' . $this->T_WIDTH . '\',' . ' ' . $this->CFG['users']['t_height'] . '=' . '\'' . $this->T_HEIGHT . '\',' . ' ' . $this->CFG['users']['l_width'] . '=\'' . $this->L_WIDTH . '\',' . ' ' . $this->CFG['users']['l_height'] . '=' . '\'' . $this->L_HEIGHT . '\',' . ' ' . $this->CFG['users']['s_width'] . '=' . '\'' . $this->S_HEIGHT . '\',' . ' ' . $this->CFG['users']['s_height'] . '=' . '\'' . $this->S_HEIGHT . '\',' . ' ' . $this->CFG['users']['photo_ext'] . '=' . '\'' . $extern . '\',' . ' ' . $this->CFG['users']['image_path'] . '=\'\',' . ' ' . $this->CFG['users']['photo_server_url'] . '=\'' . $this->fields_arr['server_url'] . '\'' . ' WHERE ' . $this->CFG['users']['user_id'] . '=\'' . $this->fields_arr['uid'] . '\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function setIndexBlockFormField($index_block_arr)
		{
				foreach ($index_block_arr as $value)
				{
						$this->setFormField($value, $this->CFG['admin']['index'][$value]);
				}
		}
		public function populateIndexBlockValues($index_block_value)
		{
				$index_block_value_arr = unserialize($index_block_value);
				if (!is_array($index_block_value_arr)) return;
				foreach ($index_block_value_arr as $key => $value)
				{
						if (!($this->fields_arr[$key] == 'compulsory' or $value == 'compulsory')) $this->fields_arr[$key] = $value;
						else  $this->fields_arr[$key] = $this->CFG['admin']['index'][$key];
				}
		}
		public function populateIndexPageFields($index_block_arr)
		{
				foreach ($index_block_arr as $value)
				{
						$label = $this->LANG[$value];
						if (!$this->isShowIndexBlock($this->CFG['admin']['index'][$value])) continue;
?>
<tr>
	<td class="<?php echo $this->getCSSFormLabelCellClass($value); ?>"><label for="<?php echo $value; ?>"><?php echo $label; ?></label></td>
	<td class="<?php echo $this->getCSSFormFieldCellClass($value); ?>"><?php echo $this->getFormFieldErrorTip($value); ?>
		<input type="radio" name="<?php echo $value; ?>" id="<?php echo $value; ?>_yes" tabindex="<?php echo $this->getTabIndex(); ?>" value="yes"<?php echo ($this->getFormField($value) == 'yes') ? ' checked' : ''; ?> /><label for="<?php echo $value; ?>_yes"><?php echo $this->LANG['editmembers_yes']; ?></label>
		<input type="radio" name="<?php echo $value; ?>" id="<?php echo $value; ?>_no" tabindex="<?php echo $this->getTabIndex(); ?>"  value="no"<?php echo ($this->getFormField($value) == 'no') ? ' checked' : ''; ?> /><label for="<?php echo $value; ?>_no"><?php echo $this->LANG['editmembers_no']; ?></label>
	</td>
</tr>
<?php
				}
		}
		public function serializeIndexBlockValues($index_block_arr)
		{
				$array = array();
				foreach ($index_block_arr as $value)
				{
						$array[$value] = $this->fields_arr[$value];
				}
				$this->fields_arr['index_block'] = serialize($array);
		}
		public function chkIsValidUser()
		{
				$uid = $this->fields_arr['uid'];
				$sql = 'SELECT 1 FROM ' . $this->CFG['db']['tbl']['users'] . ' WHERE ' . $this->getUserTableField('user_id') . '=' . $this->dbObj->Param($uid);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($uid));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount()) return true;
				return false;
		}
		public function chkIsNotDuplicateEmail($table_name, $field_name, $err_tip = '')
		{
				$uid = $this->fields_arr['uid'];
				$sql = 'SELECT ' . $this->getUserTableField('user_id') . ' FROM ' . $table_name . ' WHERE ' . $this->getUserTableField('email') . ' =' . $this->dbObj->Param($field_name) . ' AND ' . $this->getUserTableField('user_id') . '!=' . $this->dbObj->Param($uid);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr[$field_name], $uid));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$numrows = $rs->PO_RecordCount();
				$is_ok = ($numrows == 0);
				if (!$is_ok) $this->fields_err_tip_arr[$field_name] = $err_tip;
				return $is_ok;
		}
		public function chkIsNotDuplicateName($table_name, $field_name, $err_tip = '')
		{
				$uid = $this->fields_arr['uid'];
				$sql = 'SELECT ' . $this->getUserTableField('user_id') . ' FROM ' . $table_name . ' WHERE ' . $this->getUserTableField('name') . ' =' . $this->dbObj->Param($field_name) . ' AND ' . $this->getUserTableField('user_id') . '!=' . $this->dbObj->Param($uid);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr[$field_name], $uid));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$numrows = $rs->PO_RecordCount();
				$is_ok = ($numrows == 0);
				if (!$is_ok) $this->fields_err_tip_arr[$field_name] = $err_tip;
				return $is_ok;
		}
		public function chkIsSamePasswords($field_name1, $field_name2, $err_tip = '')
		{
				$is_ok = ($this->fields_arr[$field_name1] == $this->fields_arr[$field_name2]);
				if (!$is_ok) $this->fields_err_tip_arr[$field_name1] = $this->fields_err_tip_arr[$field_name2] = $err_tip;
				return $is_ok;
		}
		public function chkIsPasswordAndUserNameAreSame($err_tip = '')
		{
				if ($this->fields_arr['name'] and $this->fields_arr['password'])
				{
						if ($this->fields_arr['name'] == $this->fields_arr['password'])
						{
								$this->fields_err_tip_arr['password'] = $err_tip;
								return false;
						}
				}
				return true;
		}
		public function chkIsValidSize($field_name, $min, $max, $err_tip = '')
		{
				if ((strlen($this->fields_arr[$field_name]) < $min) or (strlen($this->fields_arr[$field_name]) > $max))
				{
						$this->fields_err_tip_arr[$field_name] = $err_tip;
						return false;
				}
				return true;
		}
		public function chkIsAllowedUserName($err_tip = '')
		{
				$user_name = strtolower($this->fields_arr['name']);
				if (in_array($user_name, $this->CFG['admin']['not_allowed_usernames']))
				{
						$this->fields_err_tip_arr['name'] = $err_tip;
						return false;
				}
				return true;
		}
		public function sendChangeMailAlert()
		{
				$activation_link = "<a target=\"_blank\" href=\"" . URL($this->CFG['site']['url']) . "\">" . URL($this->CFG['site']['url']) . "</a>";
				$subject = $this->getMailContent($this->LANG['admin_changemail_subject'], array('username' => $this->fields_arr['name'], 'email' => $this->fields_arr['email'], 'sitename' => $this->CFG['site']['name'], 'link' => $activation_link));
				$content = $this->getMailContent($this->LANG['admin_mailchange_message'], array('username' => $this->fields_arr['name'], 'email' => $this->fields_arr['email'], 'sitename' => $this->CFG['site']['name'], 'link' => $activation_link));
				$this->_sendMail($this->fields_arr['old_email'], $subject, $content, $this->CFG['site']['noreply_name'], $this->CFG['site']['noreply_email']);
		}
		private function _sendMail($to_email, $subject, $body, $sender_name, $sender_email)
		{
				$mail = new PHPMailer();
				$mail->AddAddress($to_email);
				$mail->FromName = $sender_name;
				$mail->From = $mail->Sender = $sender_email;
				$mail->Subject = $subject;
				$mail->Body = $body;
				$mail->IsMail();
				$mail->IsHTML(true);
				return ($mail->Send());
		}
}
$editmember = new EditMembersHandler();
$editmember->makeGlobalize($CFG, $LANG);
$index_block_arr = array('recent_questions', 'popular_questions', 'questions_with_videos', 'questions_with_audios', 'best_of_answer', 'recent_forums', 'forums_with_most_replies', 'recent_blogs', 'blogs_with_most_comment', 'top_analyst', 'featured_analyst');
$editmember->setPageBlockNames(array('form_search', 'form_settings', 'msg_form_error', 'msg_form_success'));
$editmember->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$editmember->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$editmember->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$editmember->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$editmember->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$editmember->setDBObject($db);
$editmember->setFormField('subscribe_keywords', '');
$editmember->setFormField('keyword_mail', '');
$editmember->setFormField('reply_mail', '');
$editmember->setFormField('favorite_mail', '');
$editmember->setFormField('best_ans_mail', '');
$editmember->setFormField('abuse_mail', '');
$editmember->setFormField('internal_mail', '');
$editmember->setFormField('all_email_notification', '');
$editmember->setFormField('search_question', '');
$editmember->setFormField('image_path', '');
$editmember->setFormField('msg', '');
$editmember->setFormField('uid', '');
$editmember->setFormField('name', '');
$editmember->setFormField('password', '');
$editmember->setFormField('confirm_password', '');
$editmember->setFormField('email', '');
$editmember->setFormField('old_email', '');
$editmember->setFormField('gender', 'Female');
$editmember->setFormField('bio', '');
$editmember->setFormField('user_access', '');
$editmember->setFormField('photo', '');
$editmember->setFormField('photo_ext', '');
$editmember->setFormField('photo_server_url', '');
$editmember->setFormField('index_block', '');
$editmember->setFormField('avatar', '');
$editmember->setIndexBlockFormField($index_block_arr);
$pagename = 'Manage Settings';
$editmember->setDBObject($db);
$editmember->sanitizeFormInputs($_REQUEST);
$editmember->setAllPageBlocksHide();
$title = $LANG['editmembers_title'];
if ($editmember->chkIsValidUser())
{
		$editmember->setPageBlockShow('form_settings');
		$LANG['signup_name'] = str_replace('{min_count}', $CFG['admin']['username_min_size'], $LANG['signup_name']);
		$LANG['signup_name'] = str_replace('{max_count}', $CFG['admin']['username_max_size'], $LANG['signup_name']);
		$LANG['signup_password'] = str_replace('{min_count}', $CFG['admin']['password_min_size'], $LANG['signup_password']);
		$LANG['signup_password'] = str_replace('{max_count}', $CFG['admin']['password_max_size'], $LANG['signup_password']);
		if ($editmember->isFormPOSTed($_POST, 'editmembers_submit'))
		{
				$user_details_arr = $editmember->getUserDetailsFromUsersTable($CFG['db']['tbl']['users'], $editmember->getFormField('uid'));
				$editmember->sanitizeFormInputs($_POST);
				if (!$CFG['admin']['use_profile_external_image'])
				{
						if (isset($_FILES['photo']) and $_FILES['photo']['tmp_name'])
						{
								$editmember->chkValidFileType('photo', $LANG['err_tip_invalid_file_type']) and $editmember->chkValideFileSize('photo', $LANG['err_tip_invalid_file_size']) and $editmember->chkErrorInFile('photo', $LANG['err_tip_invalid_file']);
						}
				}
				$editmember->chkIsNotEmpty('name', $LANG['signup_err_tip_compulsory']) and $editmember->chkIsAlphaNumeric('name', $LANG['signup_err_tip_invalid_username']) and $editmember->chkIsValidSize('name', $CFG['admin']['username_min_size'], $CFG['admin']['username_max_size'], $LANG['signup_err_tip_invalid_size']) and $editmember->chkIsAllowedUserName($LANG['not_allowed_username']) and $editmember->chkIsNotDuplicateName($CFG['db']['tbl']['users'], 'name', $LANG['signup_err_tip_name_already_exists']);
				if ($editmember->getFormField('email'))
				{
						$editmember->chkIsNotEmpty('email', $LANG['signup_err_tip_compulsory']) and $editmember->chkIsValidEmail('email', $LANG['signup_err_tip_invalid_email']) and ($editmember->chkIsNotDuplicateEmail($CFG['db']['tbl']['users'], 'email', $LANG['signup_err_tip_email_already_exists']) or $editmember->setCommonErrorMsg($LANG['signup_err_tip_email_already_exists']));
				}
				if ($editmember->getFormField('password') or $editmember->getFormField('confirm_password'))
				{
						$editmember->chkIsNotEmpty('password', $LANG['signup_err_tip_compulsory']) and $editmember->chkIsValidSize('password', $CFG['admin']['password_min_size'], $CFG['admin']['password_max_size'], $LANG['signup_err_tip_invalid_size']);
						$editmember->chkIsNotEmpty('confirm_password', $LANG['signup_err_tip_compulsory']) and $editmember->chkIsSamePasswords('password', 'confirm_password', $LANG['signup_err_tip_same_password']);
						$editmember->chkIsPasswordAndUserNameAreSame($LANG['password_user_name']);
				}
				if ($editmember->isValidFormInputs())
				{
						$editmember->serializeIndexBlockValues($index_block_arr);
						$editmember->updateFormFieldsInTable($CFG['db']['tbl']['users_ans_log'], $editmember->getFormField('uid'), array('subscribe_keywords', 'keyword_mail', 'reply_mail', 'favorite_mail', 'best_ans_mail', 'abuse_mail', 'internal_mail', 'index_block'));
						$bio = html_entity_decode($editmember->getFormField('bio'));
						$bio = strip_tags($bio, $CFG['html']['allowed_tags']);
						$editmember->setFormField('bio', $bio);
						$update_fields = array('name', 'gender', 'bio', 'user_access');
						if ($editmember->getFormField('password'))
						{
								$editmember->setFormField('password', md5($editmember->getFormField('password')));
								$update_fields[] = 'password';
						}
						if ($editmember->getFormField('email') != $editmember->getFormField('old_email'))
						{
								$update_fields[] = 'email';
								$editmember->sendChangeMailAlert();
						}
						$editmember->updateFormFieldsInUserTable($CFG['db']['tbl']['users'], $editmember->getFormField('uid'), $update_fields);
						if ($CFG['admin']['use_profile_external_image'])
						{
								$editmember->updateUserImagePath();
						}
						else
								if (isset($_FILES['photo']) and $_FILES['photo']['tmp_name'])
								{
										$editmember->photoUpload();
								}
								else
										if ($editmember->getFormField('avatar'))
										{
												$avatarImagePath = $CFG['site']['url'] . $CFG['admin']['avatar_path'] . $editmember->getFormField('avatar');
												$editmember->setFormField('image_path', $avatarImagePath);
												$editmember->updateUserImagePath();
										}
						$editmember->setPageBlockShow('msg_form_success');
						$editmember->setCommonSuccessMsg($LANG['editmembers_updated_successfully']);
						Redirect2URL('editMembers.php?uid=' . $editmember->getFormField('uid') . '&msg=1');
				}
				else
				{
						$editmember->setPageBlockShow('msg_form_error');
						$editmember->setPageBlockShow('form_editprofile');
				}
				$editmember->setFormField('password', '');
				$editmember->setFormField('confirm_password', '');
		} elseif ($editmember->isFormPOSTed($_POST, 'editmembers_cancel'))
		{
				Redirect2URL($CFG['site']['relative_url'] . 'manageAnswersMembers.php');
		}
		else
		{
				$user_settings_arr = $editmember->getUserDetailsArrFromDB($CFG['db']['tbl']['users_ans_log'], array('subscribe_keywords', 'keyword_mail', 'reply_mail', 'favorite_mail', 'best_ans_mail', 'abuse_mail', 'internal_mail', 'index_block'), $editmember->getFormField('uid'));
				$editmember->populateIndexBlockValues($user_settings_arr['index_block']);
				$editmember->setFormField('subscribe_keywords', $user_settings_arr['subscribe_keywords']);
				$editmember->setFormField('keyword_mail', $user_settings_arr['keyword_mail']);
				$editmember->setFormField('reply_mail', $user_settings_arr['reply_mail']);
				$editmember->setFormField('favorite_mail', $user_settings_arr['favorite_mail']);
				$editmember->setFormField('best_ans_mail', $user_settings_arr['best_ans_mail']);
				$editmember->setFormField('abuse_mail', $user_settings_arr['abuse_mail']);
				$editmember->setFormField('internal_mail', $user_settings_arr['internal_mail']);
				$user_details_arr = $editmember->getUserDetailsFromUsersTable($CFG['db']['tbl']['users'], $editmember->getFormField('uid'));
				$editmember->setFormField('image_path', $user_details_arr['image_path']);
				$editmember->setFormField('name', $user_details_arr['name']);
				$editmember->setFormField('email', $user_details_arr['email']);
				$editmember->setFormField('old_email', $user_details_arr['email']);
				$editmember->setFormField('bio', $user_details_arr['bio']);
				$editmember->setFormField('gender', $user_details_arr['gender']);
				$editmember->setFormField('user_access', $user_details_arr['user_access']);
		}
		if ($editmember->isFormPOSTed($_GET, 'msg') and $editmember->isValidFormInputs())
		{
				$editmember->setPageBlockShow('msg_form_success');
				$editmember->setCommonSuccessMsg($LANG['editmembers_updated_successfully']);
		}
}
else
{
		$editmember->setPageBlockShow('msg_form_error');
		$editmember->setCommonErrorMsg($LANG['err_tip_invalid_user']);
}
$CFG['mods']['is_include_only']['non_html_header_files'] = false;
$CFG['mods']['is_include_only']['html_header'] = true;
require ($CFG['site']['project_path'] . 'common/application_top.inc.php');
?>
<div id="selListAll">
	<h2 class="clsManageAnswers"><?php echo $title; ?></h2>
<?php
if ($editmember->isShowPageBlock('form_settings'))
{
?>
	<p><a href="viewMembers.php?uid=<?php echo $editmember->getFormField('uid'); ?>"><?php echo $LANG['view_this_member']; ?></a></p>
<?php
}
if ($editmember->isShowPageBlock('msg_form_error'))
{
?>
    	<div id="selMsgError">
      		<p>
<?php
		echo $LANG['editmembers_err_sorry'] . ' ' . $editmember->getCommonErrorMsg();
?>
      		</p>
    	</div>
<?php
}
if ($editmember->isShowPageBlock('msg_form_success'))
{
?>
	    <div id="selMsgSuccess">
	      	<p>
<?php
		echo $editmember->getCommonSuccessMsg();
?>
	      	</p>
	    </div>
    <?php
}
if ($editmember->isShowPageBlock('form_settings'))
{
		$LANG['tag_size'] = str_replace('{min_size}', $CFG['admin']['tag_min_size'], $LANG['tag_size']);
		$LANG['tag_size'] = str_replace('{max_size}', $CFG['admin']['tag_max_size'], $LANG['tag_size']);
?>
	<form name="form_edit_settings" id="form_edit_settings" enctype="multipart/form-data" method="post" action="<?php echo URL($_SERVER['REQUEST_URI']); ?>">
		<table summary="<?php echo $LANG['editmembers_tbl_summary']; ?>" class="clsManageSettings">
          <tr>
            <th colspan="2"><?php echo $LANG['signup_personal']; ?></th>
          </tr>
          <tr>
            <td class="<?php echo $editmember->getCSSFormLabelCellClass('email'); ?>"><?php ShowHelpTip('email'); ?>
              <label for="email"><?php echo $LANG['signup_email']; ?></label></td>
            <td class="<?php echo $editmember->getCSSFormFieldCellClass('email'); ?>"><?php echo $editmember->getFormFieldErrorTip('email'); ?>
              <input type="text" class="clsTextBox help" name="email" id="email" title="<?php ShowToolTip('email'); ?>" tabindex="<?php echo $editmember->getTabIndex(); ?>" value="<?php echo $editmember->getFormField('email'); ?>" /></td>
          </tr>
          <!--
		  <tr>
            <td class="<?php echo $editmember->getCSSFormLabelCellClass('name'); ?>"><?php ShowHelpTip('name'); ?>
              <label for="name"><?php echo $LANG['signup_name']; ?></label>
              <span id="selCompulsoryField">*</span></td>
            <td class="<?php echo $editmember->getCSSFormFieldCellClass('name'); ?>"><?php echo $editmember->getFormFieldErrorTip('name'); ?>
              <input type="text" class="clsTextBox help" name="name" id="name" maxlength="<?php echo $CFG['admin']['username_max_size']; ?>" title="<?php ShowToolTip('name'); ?>" tabindex="<?php echo $editmember->getTabIndex(); ?>" value="<?php echo $editmember->getFormField('name'); ?>" /></td>
          </tr>-->
          <tr>
            <td class="<?php echo $editmember->getCSSFormLabelCellClass('password'); ?>"><?php ShowHelpTip('password'); ?>
              <label for="password"><?php echo $LANG['signup_password']; ?></label></td>
            <td class="<?php echo $editmember->getCSSFormFieldCellClass('password'); ?>"><?php echo $editmember->getFormFieldErrorTip('password'); ?>
              <input type="password" class="clsTextBox help" name="password" id="password" title="<?php ShowToolTip('password'); ?>" tabindex="<?php echo $editmember->getTabIndex(); ?>" value="<?php echo $editmember->getFormField('password'); ?>" /></td>
          </tr>
          <tr>
            <td class="<?php echo $editmember->getCSSFormLabelCellClass('confirm_password'); ?>"><?php ShowHelpTip('confirmpassword'); ?>
              <label for="confirm_password"><?php echo $LANG['signup_confirm_password']; ?></label>
              <span id="selCompulsoryField">*</span></td>
            <td class="<?php echo $editmember->getCSSFormFieldCellClass('confirm_password'); ?>"><?php echo $editmember->getFormFieldErrorTip('confirm_password'); ?>
              <input type="password" class="clsTextBox help" name="confirm_password" id="confirm_password" title="<?php ShowToolTip('confirmpassword'); ?>" tabindex="<?php echo $editmember->getTabIndex(); ?>" value="<?php echo $editmember->getFormField('confirm_password'); ?>" /></td>
          </tr>
          <tr>
            <td class="<?php echo $editmember->getCSSFormLabelCellClass('gender'); ?>"><?php ShowHelpTip('gender'); ?>
              <label for="sex_male"><?php echo $LANG['signup_sex']; ?></label></td>
            <td class="<?php echo $editmember->getCSSFormFieldCellClass('gender'); ?>"><?php echo $editmember->getFormFieldErrorTip('gender'); ?>
              <input type="radio" name="gender" id="sex_male" value="Male" tabindex="<?php echo $editmember->getTabIndex(); ?>" <?php if ($editmember->getFormField('gender') == 'Male') echo 'CHECKED'; ?> />
              <?php echo $LANG['signup_sex_male']; ?>
              <input type="radio" name="gender" id="sex_female" value="Female" tabindex="<?php echo $editmember->getTabIndex(); ?>" <?php if ($editmember->getFormField('gender') == 'Female') echo 'CHECKED'; ?> />
              <?php echo $LANG['signup_sex_female']; ?></td>
          </tr>
          <tr>
            <td class="<?php echo $editmember->getCSSFormLabelCellClass('user_access'); ?>"><?php ShowHelpTip('user_access'); ?>
              <label for="sex_male"><?php echo $LANG['signup_user_access']; ?></label></td>
            <td class="<?php echo $editmember->getCSSFormFieldCellClass('user_access'); ?>"><?php echo $editmember->getFormFieldErrorTip('user_access'); ?>
              <input type="radio" name="user_access" id="user_access_admin" value="Admin" tabindex="<?php echo $editmember->getTabIndex(); ?>" <?php if ($editmember->getFormField('user_access') == 'Admin') echo 'CHECKED'; ?> />
              <?php echo $LANG['signup_user_access_admin']; ?>
              <input type="radio" name="user_access" id="user_access_user" value="User" tabindex="<?php echo $editmember->getTabIndex(); ?>" <?php if ($editmember->getFormField('user_access') == 'User') echo 'CHECKED'; ?> />
              <?php echo $LANG['signup_user_access_user']; ?></td>
          </tr>
          <tr>
            <td class="<?php echo $editmember->getCSSFormLabelCellClass('bio'); ?>"><label for="bio">
              <?php ShowHelpTip('bio'); ?>
              <?php echo $LANG['signup_bio']; ?></label></td>
            <td class="<?php echo $editmember->getCSSFormFieldCellClass('bio'); ?>"><?php echo $editmember->getFormFieldErrorTip('bio'); ?>
              <p><?php echo $LANG['stock_allowed_htmltags']; ?> <?php echo htmlspecialchars($CFG['html']['allowed_tags']); ?></p>
              <textarea name="bio" id="bio" tabindex="<?php echo $editmember->getTabIndex(); ?>"><?php echo $editmember->getFormField('bio'); ?></textarea></td>
          </tr>
		   <tr>
				<td class="<?php echo $editmember->getCSSFormLabelCellClass('subscribe_keywords'); ?>"><?php ShowHelpTip('subscribe_keywords'); ?><label for="subscribe_keywords"><?php echo $LANG['editmembers_subscribe_keywords']; ?></label></td>
				<td class="<?php echo $editmember->getCSSFormFieldCellClass('subscribe_keywords'); ?>"><?php echo $editmember->getFormFieldErrorTip('subscribe_keywords'); ?>
					<input type="text" class="clsTextBox" name="subscribe_keywords" id="subscribe_keywords" maxlength="250" tabindex="<?php echo $editmember->getTabIndex(); ?>" value="<?php echo $editmember->getFormField('subscribe_keywords'); ?>" />
					<p><?php echo $LANG['editmembers_subscribe_keywords_info'] . ' ' . $LANG['tag_size']; ?></p>
				</td>
		   </tr>
<?php
		if (chkUserImageAllowed())
		{
?>
			<tr>
				<td class="clsFormFieldCellDefault"></td>
				<td class="clsFormFieldCellDefault">
					<div id="selUserImage">
					<?php
				if (($user_details_arr['photo_server_url'] and $user_details_arr['photo_ext']) or $user_details_arr['image_path'])
				{
?>
						<p id="selImageBorder"><?php displayUserImage($user_details_arr, 'thumb', false); ?></p>
					<?php
				}
?>
					</div>
				</td>
			</tr>
		   <tr>
<?php
				if ($CFG['admin']['use_profile_external_image'])
				{
?>
				<td class="<?php echo $editmember->getCSSFormLabelCellClass('image_path'); ?>"><?php ShowHelpTip('image_path'); ?><label for="image_path"><?php echo $LANG['editmembers_image_path']; ?></label></td>
				<td class="<?php echo $editmember->getCSSFormFieldCellClass('image_path'); ?>"><?php echo $editmember->getFormFieldErrorTip('image_path'); ?>
					<p><input type="text" class="clsTextBox" name="image_path" id="image_path" tabindex="<?php echo $editmember->getTabIndex(); ?>" value="<?php echo $editmember->getFormField('image_path'); ?>" /></p>
					<p><?php echo $LANG['editmembers_image_path_info']; ?></p>
				</td>
<?php
				}
				else
				{
?>
				<td class="<?php echo $editmember->getCSSFormLabelCellClass('photo'); ?>"><label for="photo"><?php echo $LANG['upload_photo']; ?></label></td>
				<td class="<?php echo $editmember->getCSSFormFieldCellClass('photo'); ?>"><?php echo $editmember->getFormFieldErrorTip('photo'); ?>
					<input type="file" class="clsFileBox" name="photo" id="photo" tabindex="<?php echo $editmember->getTabIndex(); ?>" />
					<p><?php echo str_replace('{size}', $CFG['admin']['ans_photos']['max_size'], $LANG['photo_allowed_size']); ?></p>
				</td>
<?php
				}
?>
		   </tr>
		   <tr>
				<td colspan="2" class="clsVerticalAlign <?php echo $editmember->getCSSFormLabelCellClass('avatar'); ?>"><?php echo $LANG['select_avartar']; ?></td>
		   </tr>
		   <tr>
				<td colspan="2" class="<?php echo $editmember->getCSSFormFieldCellClass('avatar'); ?>"><div id="selShowAvatarImages"></div></td>
		   </tr>
<?php
		}
?>
		   <tr>
		   		<td class="clsAllEmail"><label for="all_email_notification"><?php echo $LANG['editmembers_all_email_notification']; ?></label></td>
		   		<td class="clsAllEmail"><p class="clsBgCheckBox"><input type="checkbox" name="all_email_notification" id="all_email_notification" onClick="checkAllMail(this.form);" tabindex="<?php echo $editmember->getTabIndex(); ?>"  /></p></td>
		   </tr>
		   <tr>
				<td class="<?php echo $editmember->getCSSFormLabelCellClass('keyword_mail'); ?>"><?php ShowHelpTip('keyword_mail'); ?><label for="keyword_mail_yes"><?php echo $LANG['editmembers_keyword_mail']; ?></label></td>
				<td class="<?php echo $editmember->getCSSFormFieldCellClass('keyword_mail'); ?>"><?php echo $editmember->getFormFieldErrorTip('keyword_mail'); ?>
					<input type="radio" name="keyword_mail" id="keyword_mail_yes" tabindex="<?php echo $editmember->getTabIndex(); ?>" value="Yes"<?php echo ($editmember->getFormField('keyword_mail') == 'Yes') ? ' checked' : ''; ?> /><label for="keyword_mail_yes"><?php echo $LANG['editmembers_yes']; ?></label>
					<input type="radio" name="keyword_mail" id="keyword_mail_no" tabindex="<?php echo $editmember->getTabIndex(); ?>" value="No"<?php echo ($editmember->getFormField('keyword_mail') == 'No') ? ' checked' : ''; ?> /><label for="keyword_mail_no"><?php echo $LANG['editmembers_no']; ?></label>
				</td>
		   </tr>
		   <tr>
				<td class="<?php echo $editmember->getCSSFormLabelCellClass('reply_mail'); ?>"><?php ShowHelpTip('reply_mail'); ?><label for="reply_mail_yes"><?php echo $LANG['editmembers_reply_mail']; ?></label></td>
				<td class="<?php echo $editmember->getCSSFormFieldCellClass('reply_mail'); ?>"><?php echo $editmember->getFormFieldErrorTip('reply_mail'); ?>
					<input type="radio" name="reply_mail" id="reply_mail_yes" tabindex="<?php echo $editmember->getTabIndex(); ?>" value="Yes"<?php echo ($editmember->getFormField('reply_mail') == 'Yes') ? ' checked' : ''; ?> /><label for="reply_mail_yes"><?php echo $LANG['editmembers_yes']; ?></label>
					<input type="radio" name="reply_mail" id="reply_mail_no" tabindex="<?php echo $editmember->getTabIndex(); ?>" value="No"<?php echo ($editmember->getFormField('reply_mail') == 'No') ? ' checked' : ''; ?> /><label for="reply_mail_no"><?php echo $LANG['editmembers_no']; ?></label>
				</td>
		   </tr>
		   <tr>
				<td class="<?php echo $editmember->getCSSFormLabelCellClass('favorite_mail'); ?>"><?php ShowHelpTip('favorite_mail'); ?><label for="favorite_mail_yes"><?php echo $LANG['editmembers_favorite_mail']; ?></label></td>
				<td class="<?php echo $editmember->getCSSFormFieldCellClass('favorite_mail'); ?>"><?php echo $editmember->getFormFieldErrorTip('favorite_mail'); ?>
					<input type="radio" name="favorite_mail" id="favorite_mail_yes" tabindex="<?php echo $editmember->getTabIndex(); ?>" value="Yes"<?php echo ($editmember->getFormField('favorite_mail') == 'Yes') ? ' checked' : ''; ?> /><label for="favorite_mail_yes"><?php echo $LANG['editmembers_yes']; ?></label>
					<input type="radio" name="favorite_mail" id="favorite_mail_no" tabindex="<?php echo $editmember->getTabIndex(); ?>"  value="No"<?php echo ($editmember->getFormField('favorite_mail') == 'No') ? ' checked' : ''; ?> /><label for="favorite_mail_no"><?php echo $LANG['editmembers_no']; ?></label>
				</td>
		   </tr>
		   <tr>
				<td class="<?php echo $editmember->getCSSFormLabelCellClass('best_ans_mail'); ?>"><?php ShowHelpTip('best_ans_mail'); ?><label for="best_ans_mail_yes"><?php echo $LANG['editmembers_best_answer_mail']; ?></label></td>
				<td class="<?php echo $editmember->getCSSFormFieldCellClass('best_ans_mail'); ?>"><?php echo $editmember->getFormFieldErrorTip('best_ans_mail'); ?>
					<input type="radio" name="best_ans_mail" id="best_ans_mail_yes" tabindex="<?php echo $editmember->getTabIndex(); ?>" value="Yes"<?php echo ($editmember->getFormField('best_ans_mail') == 'Yes') ? ' checked' : ''; ?> /><label for="best_ans_mail_yes"><?php echo $LANG['editmembers_yes']; ?></label>
					<input type="radio" name="best_ans_mail" id="best_ans_mail_no" tabindex="<?php echo $editmember->getTabIndex(); ?>" value="No"<?php echo ($editmember->getFormField('best_ans_mail') == 'No') ? ' checked' : ''; ?> /><label for="best_ans_mail_no"><?php echo $LANG['editmembers_no']; ?></label>
				</td>
		   </tr>
		   <tr>
				<td class="<?php echo $editmember->getCSSFormLabelCellClass('abuse_mail'); ?>"><?php ShowHelpTip('abuse_mail'); ?><label for="abuse_mail_yes"><?php echo $LANG['editmembers_abuse_mail']; ?></label></td>
				<td class="<?php echo $editmember->getCSSFormFieldCellClass('abuse_mail'); ?>"><?php echo $editmember->getFormFieldErrorTip('abuse_mail'); ?>
					<input type="radio" name="abuse_mail" id="abuse_mail_yes" tabindex="<?php echo $editmember->getTabIndex(); ?>" value="Yes"<?php echo ($editmember->getFormField('abuse_mail') == 'Yes') ? ' checked' : ''; ?> /><label for="abuse_mail_yes"><?php echo $LANG['editmembers_yes']; ?></label>
					<input type="radio" name="abuse_mail" id="abuse_mail_no" tabindex="<?php echo $editmember->getTabIndex(); ?>" value="No"<?php echo ($editmember->getFormField('abuse_mail') == 'No') ? ' checked' : ''; ?> /><label for="abuse_mail_no"><?php echo $LANG['editmembers_no']; ?></label>
				</td>
		   </tr>
		   <tr>
				<td class="<?php echo $editmember->getCSSFormLabelCellClass('internal_mail'); ?>"><?php ShowHelpTip('internal_mail'); ?><label for="internal_mail_yes"><?php echo $LANG['editmembers_internal_mail']; ?></label></td>
				<td class="<?php echo $editmember->getCSSFormFieldCellClass('internal_mail'); ?>"><?php echo $editmember->getFormFieldErrorTip('internal_mail'); ?>
					<input type="radio" name="internal_mail" id="internal_mail_yes" tabindex="<?php echo $editmember->getTabIndex(); ?>" value="Yes"<?php echo ($editmember->getFormField('internal_mail') == 'Yes') ? ' checked' : ''; ?> /><label for="internal_mail_yes"><?php echo $LANG['editmembers_yes']; ?></label>
					<input type="radio" name="internal_mail" id="internal_mail_no" tabindex="<?php echo $editmember->getTabIndex(); ?>" value="No"<?php echo ($editmember->getFormField('internal_mail') == 'No') ? ' checked' : ''; ?> /><label for="internal_mail_no"><?php echo $LANG['editmembers_no']; ?></label>
				</td>
		   </tr>
		   <tr>
		   	<td class="clsAllEmail"><label for="all_home_settings"><?php echo $LANG['index_block_settings']; ?></label></td>
		   	<td class="clsAllEmail"><p class="clsBgCheckBox"><input type="checkbox" name="all_home_settings" id="all_home_settings" onClick="checkAllSettings(this.form, '_home');" tabindex="<?php echo $editmember->getTabIndex(); ?>"  /></p></td>
		   </tr>
		   <?php $editmember->populateIndexPageFields($index_block_arr); ?>
		   <tr>
		   		<td class="clsFormFieldCellDefault">&nbsp;</td>
				<td class="<?php echo $editmember->getCSSFormFieldCellClass('submit'); ?>">
					<input type="submit" class="clsSubmitButton" name="editmembers_submit" id="editmembers_submit" tabindex="<?php echo $editmember->getTabIndex(); ?>" value="<?php echo $LANG['editmembers_submit']; ?>" />
					&nbsp;&nbsp;
					<input type="submit" class="clsCancelButton" name="editmembers_cancel" id="editmembers_cancel" tabindex="<?php echo $editmember->getTabIndex(); ?>" value="<?php echo $LANG['editmembers_cancel']; ?>" />
				</td>
		   </tr>
		</table>
		<input type="hidden" name="avatar" value="<?php echo $editmember->getFormField('avatar'); ?>" />
		<input type="hidden" name="old_email" value="<?php echo $editmember->getFormField('old_email'); ?>" />
		<input type="hidden" name="name" value="<?php echo $editmember->getFormField('name'); ?>" />
	</form>
<?php
}
?>
</div>
<script language="javascript" type="text/javascript">
function checkAllMail(frm)
	{
		var frmLength = frm.elements.length;
		var rdId = '';
		var rdVal = '_no';
		if (($('all_email_notification').checked))
			rdVal = '_yes';
		for ( var i=0; i<frmLength; i++)
			{
				if ((frm.elements[i].name.indexOf('_mail')!=-1) && (frm.elements[i].type == 'radio')){
					rdId = frm.elements[i].name + rdVal;
					$(rdId).checked = true;
				}
			}
	}
function checkAllSettings(frm)
	{
		var frmLength = frm.elements.length;
		var rdId = '';
		var rdVal = '_no';
		if (($('all_home_settings').checked))
			rdVal = '_yes';
		for ( var i=0; i<frmLength; i++)
			{
				if ((frm.elements[i].name.indexOf('_mail')==-1) && (frm.elements[i].type == 'radio')){
					rdId = frm.elements[i].name + rdVal;
					if (($(rdId)))
						$(rdId).checked = true;
				}
			}
	}
</script>
<?php
if ($editmember->isShowPageBlock('form_settings') and chkUserImageAllowed())
{
?>
<script language="javascript" type="text/javascript">
ajaxUpdateDiv('<?php echo $CFG['site']['url'] ?>members/avatars.php?uid=<?php echo $editmember->getFormField('uid') ?>', '', 'selShowAvatarImages');
</script>
<?php
}
require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>