<form name="form1sea" method="post" action="<?php echo("$path");?>search.php">
	<input name="q" type="text" id="q" class="search_input" onFocus="this.value='';" value=" Enter search term" />  
	<input type="image" class="search-btn" src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/images/search-button.gif" name="Submit" value="Search" />
</form>