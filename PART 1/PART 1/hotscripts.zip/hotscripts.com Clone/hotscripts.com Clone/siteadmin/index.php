<?



?> 
<SCRIPT language=javascript>
function submit_check() {
	  loginForm.submit();
}

</SCRIPT>
<table width="100%" border="0" cellpadding="0" cellspacing="0" dwcopytype="CopyTableCell">
  <tr>
    <td valign="top">&nbsp; </td>
    <td valign="top"><FORM name=loginForm  action="login.php"
      method=post>
        <div align="center"></div>
        <TABLE width="289" border=0 align=center cellPadding=5 cellSpacing=0>
          <TBODY>
            <TR vAlign=center> 
              <TD>&nbsp;</TD>
            </TR>
            <TR vAlign=center bgcolor="#666666"> 
              <TD colspan="2"><font color="#ffffff" size="4" face="Verdana, Arial, Helvetica, sans-serif"><strong>Admin 
                Login</strong></font></TD>
            </TR>
            <TR vAlign=center bgcolor="#CCCCCC"> 
              <TD> <DIV align=right><strong><FONT color="#000000" 
            size=2 face="Verdana, Arial, Helvetica, sans-serif">Name</FONT></strong></DIV></TD>
              <TD><INPUT  class="box1"  name=UserName></TD>
            </TR>
            <TR vAlign=center bgcolor="#CCCCCC"> 
              <TD> <DIV align=right><strong><FONT color="#000000" 
            size=2 face="Verdana, Arial, Helvetica, sans-serif">Password</FONT></strong></DIV></TD>
              <TD><INPUT  class="box1"  type=password name=Password></TD>
            </TR>
            <TR align=right bgcolor="#CCCCCC"> 
              <TD 
        colSpan=2><table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr> 
                    <td width="33%" align="right"> <div align="center">
                        <input type="submit" name="Submit" value="Sign In" class="btn">
                      </div></td>
                  </tr>
                </table>
                <a href="#"> </a> </TD>
            </TR>
            <TR align=right> 
              <TD colSpan=2>&nbsp; </TD>
            </TR>
          </TBODY>
        </TABLE>
        <div align="center"></div>
      </FORM></td>
    <td valign="top">&nbsp; </td>
  </tr>
</table>
