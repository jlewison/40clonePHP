<?php //00461
// Copyright Notice
// Web Site URL:  http://www.zeeways.com
// Script Owner eMail: mail@zeeways.com
// Date: April, 2007
// Script Name: Zeeways Auction Website PHP Script
// Copyright Details: This script is not free.  Do not Remove this Copy Right notice.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the site administrator.');exit(199);
?>
4+oV54HO7CGJl+Jh/kE9vznxLcorqB70Lwy9/C6IOEA//+1P/1V7OhEGXnQx/oliQZgI2n1RbAK9
XK0Gk8YRkgyURlRnLdWajK9To4P8JPt+OTILCoCBYbPzgr3v146tWF3sS4mHYK+v/e8QbP9ry1iw
hcxABCyu/4GlxSDTdA1/08kyHwHLfshyEoAfuSARnsFwe4AfPTOQsJjlVUO5GED8mrtHrIhf5wvz
YOw/jFYu6Nn5s7FmadVS/9QcD0nCS/Sjhab+jffm4OEyQLpC5pIi2gC5Q5+SQGmC4lyCHc09btzW
Wyqg8+GxdovXd1i6Wj8SkJKUJAN3lClPoed/UFaKGebiYlB8eFkuYdbG1aUA65mwaMUUPlTppXfz
J0sdCdMzjmzCurThfUYAKezzBZO+xrA1CaOhKqXCcu8qzcLNOpbbi9kP9UysHazJItbNiNW+8Nib
zJ9+qx/8acvjOABXCG9SvK13GsI53aq4qOVQZfaNy0u4Ee9zlE9ahU2cJwbiQmUltYPOV1Hr5PrT
7h7y2dZeE1BF4uOvSGoUNJGX0369t4yrC7Be6EIsgn3QzqPsWGek6m7lKSzjh0CvuTu+ER4899MX
QY5MX8zI+MdShZ0iAmIdhGPMr0OTcujc/q8FkocjL2B098xJsDTFCuVgWEQA93PyIiY3MJYyNqdZ
u/hrOPOm0NlCjWrkHWRM5V0VYiLpG0wdv2vZpGcCmygfAZ/fnvMr21JrNRurKRy5ZTaEdY1YanFz
NCN/I9P6WFtp4o/0DSwfiNxQa5B4b52vnWwQ9g1LPjun0672IiYD5NwrGsZq3/+PJgw59Zsf8paM
JYtfMRbpdIb0DqC2qyLR+sheLd89lU0VLJsNCEV+/agK2kKzpNkxdQxB3SSmYnPGviHBBJz9AB6Y
brGUROedNIU0ln0XbP03BRd3YqR5znAohF+LaommDxKIraz7/QRLggTcZUoYg0ZkIOO=