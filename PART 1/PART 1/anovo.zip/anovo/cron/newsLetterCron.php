<?php
require_once ('../common/config.inc.php');
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['mods']['is_include_only']['non_html_header_files'] = true;
$CFG['mods']['include_files'][] = 'common/classes/phpmailer/class_PHPMailer.lib.php';
$CFG['auth']['is_authenticate'] = false;
require ($CFG['site']['project_path'] . 'common/application_top.inc.php');
set_time_limit(0);
class LoginFormHandler extends FormHandler
{
		public function getNewsLetter($table_name, $fields_arr = array())
		{
				$sql = 'SELECT ';
				foreach ($fields_arr as $field_name) $sql .= $field_name . ', ';
				$sql = substr($sql, 0, strrpos($sql, ','));
				$sql .= ' FROM ' . $table_name . ' WHERE status != \'Finished\' ORDER BY news_letter_id limit 0,1';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = array();
				if ($rs->PO_RecordCount()) $row = $rs->FetchRow();
				else  return $row;
				$ret_fields_arr = array();
				foreach ($fields_arr as $field_name) $ret_fields_arr[$field_name] = isset($row[$field_name]) ? $row[$field_name] : '';
				return $ret_fields_arr;
		}
		public function getNewsLetterSetting($user_id)
		{
				$sql = 'SELECT news_letter FROM ' . $this->CFG['db']['tbl']['users_ans_log'] . ' WHERE user_id = ' . $this->dbObj->Param('user_id');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($user_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($row = $rs->FetchRow()) return $row['news_letter'];
		}
		public function sendNewLetter($table_name, $fields_arr = array(), $new_letter_arr, $CFG)
		{
				$new_letter_arr['sql_condition'] = ($new_letter_arr['sql_condition'] == '') ? '1 ' : $new_letter_arr['sql_condition'];
				$sql = 'SELECT ';
				foreach ($fields_arr as $field_name) $sql .= $field_name . ', ';
				$sql = substr($sql, 0, strrpos($sql, ','));
				$sql .= " FROM " . $table_name . " WHERE user_id > " . $this->dbObj->Param($new_letter_arr['upto_user_id']) . " AND " . html_entity_decode(stripslashes($new_letter_arr['sql_condition'])) . " ORDER BY user_id limit 0," . $this->dbObj->Param($CFG['news_letter']['send_count']);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($new_letter_arr['upto_user_id'], $CFG['news_letter']['send_count']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = array();
				if ($count = $rs->PO_RecordCount())
				{
						while ($row = $rs->FetchRow())
						{
								if ($new_letter_arr['based_user_settings'] == 'Yes')
								{
										if ($this->getNewsLetterSetting($row['user_id']) == 'No') continue;
								}
								$subject = $this->getMailContent($new_letter_arr['subject'], array('username' => $row['name'], 'email' => $row['email'], 'password' => $row['password']));
								$content = $this->getMailContent($new_letter_arr['body'], array('username' => $row['name'], 'email' => $row['email'], 'password' => $row['password']));
								$is_ok = $this->_sendMail($row['email'], $subject, $content, $CFG['site']['noreply_name'], $CFG['site']['noreply_email']);
								$ret_arr = array('user_id' => $row['user_id'], 'total' => $count);
						}
						return $ret_arr;
				}
				return false;
		}
		private function _sendMail($to_email, $subject, $body, $sender_name, $sender_email)
		{
				$mail = new PHPMailer();
				$mail->AddAddress($to_email);
				$mail->FromName = $sender_name;
				$mail->From = $mail->Sender = $sender_email;
				$mail->Subject = $subject;
				$mail->Body = $body;
				$mail->IsMail();
				$mail->IsHTML(true);
				return ($mail->Send());
		}
		public function getMailContent($content, $fieldsArr)
		{
				$content = nl2br($content);
				$chkArray = array('email', 'password', 'username');
				foreach ($chkArray as $value)
				{
						$toReplace = '{' . $value . '}';
						if (array_key_exists($value, $fieldsArr)) $content = str_replace($toReplace, $fieldsArr[$value], $content);
						else  $content = str_replace($toReplace, '', $content);
				}
				return $content;
		}
		public function updateNewsLetter($table_name, $new_letter_id, $status, $upto = 0, $total = 0)
		{
				$val_arr = array();
				$val_arr[] = $status;
				$sql = 'UPDATE ' . $table_name . ' SET ' . 'status=' . $this->dbObj->Param($status);
				if ($upto != 0)
				{
						$sql .= ', upto_user_id = ' . $this->dbObj->Param($upto);
						$val_arr[] = $upto;
				}
				if ($total != 0)
				{
						$sql .= ', total_sent = total_sent + ' . $this->dbObj->Param($total);
						$val_arr[] = $total;
				}
				$sql .= ' WHERE news_letter_id=' . $this->dbObj->Param($new_letter_id);
				$val_arr[] = $new_letter_id;
				$stmt = $this->dbObj->Prepare($sql);
				$result = $this->dbObj->Execute($stmt, $val_arr);
				if (!$result) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
}
$loginfrm = new LoginFormHandler();
$loginfrm->setDBObject($db);
$loginfrm->makeGlobalize($CFG, $LANG);
$loginfrm->setFormField('news_letter_id', '');
$loginfrm->setFormField('subject', '');
$loginfrm->setFormField('body', '');
$loginfrm->setFormField('upto_user_id', '');
$new_letter_arr = $loginfrm->getNewsLetter($CFG['db']['tbl']['news_letter'], array('news_letter_id', 'subject', 'body', 'upto_user_id', 'sql_condition', 'based_user_settings'));
if ($new_letter_arr)
{
		if ($user_arr = $loginfrm->sendNewLetter($CFG['db']['tbl']['users'], array('user_id', $loginfrm->getUserTableField('name') . ' AS name', 'password', 'email'), $new_letter_arr, $CFG)) $loginfrm->updateNewsLetter($CFG['db']['tbl']['news_letter'], $new_letter_arr['news_letter_id'], 'Started', $user_arr['user_id'], $user_arr['total']);
		else  $loginfrm->updateNewsLetter($CFG['db']['tbl']['news_letter'], $new_letter_arr['news_letter_id'], 'Finished');
}


?>