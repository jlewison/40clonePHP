<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Forgot Password</title>
<link rel="shortcut icon" href="img/favicon.ico" />
<link rel="stylesheet" type="text/css" href="admin.css" />
</head>
<body>
<div class="login-top">
	<div class="login-logo"><a href="../linkadmin/home.php"><img src="img/login-top.gif" alt="Link Bid Script Admin Home" /></a></div>
	<div class="login-form">
	<form name="form1" method="post" action="forgot_send.php">
		<table valign="top"  border="0" align="center" cellpadding="2" cellspacing="2">
			<tr>
				<td>Please enter your email address:</td>
			</tr>
			<tr>
				<td><input name="emadd" type="text" class="login-inp" id="emadd"  /></td>
			</tr>
			<tr>
				<td align="right"><input name="Submit" type="submit" class="login-but" value="Submit" /></td>
			</tr>
		</table>
	</form>
	</div>
</div>
</body>
</html>
