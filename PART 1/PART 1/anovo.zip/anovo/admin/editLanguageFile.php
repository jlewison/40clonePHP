<?php
require_once ('../common/config.inc.php');
$CFG['lang']['include_files'][] = 'admin/includes/languages/%s/editLanguageFile.php';
$CFG['html']['header'] = 'admin/includes/languages/%s/html_header.php';
$CFG['html']['footer'] = 'admin/includes/languages/%s/html_footer.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class EditLanguageHandler extends FormHandler
{
		public function populateList($list_arr, $highlight_value = '')
		{
				foreach ($list_arr as $key => $value)
				{
?>  <option value="<?php echo $key; ?>"<?php echo ($highlight_value == $key) ? ' selected="selected"' : ''; ?>><?php echo $value; ?></option>
<?php
				}
		}
		public function populateHiddenFormFields($field_names_arr = array())
		{
				foreach ($field_names_arr as $field_name)
				{
						if (is_array($this->fields_arr[$field_name]))
						{
								foreach ($this->fields_arr[$field_name] as $sub_field_value)
								{
?>  <input type="hidden" name="<?php echo $field_name; ?>[]" value="<?php echo $sub_field_value; ?>" />
<?php
								}
						}
						else
						{
?>  <input type="hidden" name="<?php echo $field_name; ?>" value="<?php echo $this->fields_arr[$field_name]; ?>" />
<?php
						}
				}
		}
		public function setDirectoryPath($dir_path_arr)
		{
				$this->dir_path_arr = $dir_path_arr;
		}
		public function populateFileNamesList($highlight_value, $unwanted_files_list_arr)
		{
				if ($handle = opendir($this->dir_path_arr[$this->fields_arr['directory']] . $this->fields_arr['language']))
				{
						while (($file = readdir($handle)) !== false)
						{
								if (strpos($file, '.php') !== false and (array_search($file, $unwanted_files_list_arr) === false))
								{
?>	<option value="<?php echo $file; ?>"<?php echo ($file == $highlight_value) ? ' selected="selected"' : ''; ?>><?php echo $file; ?></option>
<?php
								}
						}
						closedir($handle);
				}
		}
		public function chkIsFromList($option_arr, $field_name, $err_tip = '')
		{
				$is_ok = isset($option_arr[$this->fields_arr[$field_name]]);
				if (!$is_ok) $this->fields_err_tip_arr[$field_name] = $err_tip;
				return $is_ok;
		}
		public function chkIsFileExist($file, $unwanted_files_list_arr, $err_tip, $read_err_tip, $write_err_tip)
		{
				$file_path = $this->dir_path_arr[$this->fields_arr['directory']] . $this->fields_arr['language'] . '/' . $this->fields_arr[$file];
				$is_ok = ((array_search($this->fields_arr[$file], $unwanted_files_list_arr) === false) and file_exists($file_path));
				if (!$is_ok) $this->fields_err_tip_arr[$file] = $err_tip;
				else
						if (!is_readable($file_path)) $this->fields_err_tip_arr[$file] = $read_err_tip;
						else
								if (!is_writable($file_path)) $this->fields_err_tip_arr[$file] = $write_err_tip;
				return $is_ok;
		}
		public function updateFileContent($post_arr)
		{
				$file_path = $this->dir_path_arr[$this->fields_arr['directory']] . $this->fields_arr['language'] . '/' . $this->fields_arr['file'];
				$content = file_get_contents($file_path);
				require ($file_path);
				$is_file_edited = false;
				foreach ($post_arr as $varname => $value)
				{
						if (isset($LANG[$varname]) and isset($post_arr[$varname]) and $LANG[$varname] != $post_arr[$varname])
						{
								$is_file_edited = true;
								$variable_start = strpos($content, $varname, 0);
								$end_of_variable = strpos($content, '=', $variable_start) + 1;
								$content_before_value = trim(substr($content, 0, $end_of_variable));
								$variable_end_pos = strpos($content, ';', $end_of_variable);
								$content_after_value = trim(substr($content, $variable_end_pos));
								$content = $content_before_value . ' \'' . addslashes($post_arr[$varname]) . '\'' . $content_after_value;
						}
				}
				if ($is_file_edited)
				{
						$fw = fopen($file_path, 'w');
						fwrite($fw, $content);
						fclose($fw);
				}
		}
		public function updateFAQIntoFAQListArray($question, $answer)
		{
				$file_path = sprintf($this->dir_path_arr[$this->fields_arr['directory']], $this->fields_arr['language']);
				$content = file_get_contents($file_path);
				$comments = substr($content, strpos($content, '/**'), (strrpos($content, '*/') - strpos($content, '/**') + 2));
				$arraycode = '<?php ' . "\n\n" . $comments . "\n\n" . '$LANG_LIST_ARR[\'faq\'] = array(' . "\n";
				foreach ($this->fields_arr[$question] as $key => $value)
				{
						if ($value) $arraycode .= '\'' . addslashes($value) . '\' => ' . '\'' . addslashes((isset($this->fields_arr[$answer][$key])) ? $this->fields_arr[$answer][$key] : '') . '\', ' . "\r\n";
				}
				$arraycode = substr($arraycode, 0, strrpos($arraycode, ','));
				$arraycode .= "\n" . '); ' . "\n" . '?>';
				$fw = fopen($file_path, 'w');
				fwrite($fw, $arraycode);
				fclose($fw);
		}
		public function stripslashesNew($value)
		{
				$value = str_replace('\\', '~*@', $value);
				$value = stripslashes($value);
				$value = str_replace('~*@', '\\', $value);
				$value = str_replace('\"', '"', $value);
				return $value;
		}
}
$editLanguageObj = new EditLanguageHandler();
$editLanguageObj->setPageBlockNames(array('msg_form_success', 'msg_form_error', 'form_directory_list', 'form_files_list', 'form_edit_phrases', 'page_list_phrases', 'form_faq_list'));
$editLanguageObj->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$editLanguageObj->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$editLanguageObj->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$editLanguageObj->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$editLanguageObj->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$editLanguageObj->setFormField('language', $CFG['lang']['default']);
$editLanguageObj->setFormField('directory', 'root');
$editLanguageObj->setFormField('file', '');
$editLanguageObj->setFormField('success_msg', '');
$editLanguageObj->setFormField('question', array());
$editLanguageObj->setFormField('answer', array());
$editLanguageObj->setFormField('add_new_faq', 0);
$editLanguageObj->setFormField('action', '');
$lang_folders_arr = array('root' => 'Root', 'members' => $LANG['langedit_members']);
$directory_path_arr = array('root' => '../includes/languages/', 'members' => '../members/includes/languages/', 'faq' => '../common/languages/%s/lists_array/faq_list_array.inc.php');
$editLanguageObj->setDirectoryPath($directory_path_arr);
$unwanted_files_list_arr = array('html_header.php', 'html_footer.php', 'accessibility.php', 'useTerms.php', 'privacyPolicy.php');
$editLanguageObj->setAllPageBlocksHide();
$editLanguageObj->setPageBlockShow('form_directory_list');
if ($editLanguageObj->isFormPOSTed($_POST, 'submit_directory'))
{
		$editLanguageObj->sanitizeFormInputs($_POST);
		$editLanguageObj->chkIsNotEmpty('language', $LANG['langedit_err_tip_compulsory']) and $editLanguageObj->chkIsFromList($CFG['lang']['available_languages'], 'language', $LANG['langedit_err_tip_invalid']);
		$editLanguageObj->chkIsNotEmpty('directory', $LANG['langedit_err_tip_compulsory']) and $editLanguageObj->chkIsFromList($lang_folders_arr, 'directory', $LANG['langedit_err_tip_invalid']);
		if ($editLanguageObj->isValidFormInputs())
		{
				if ($editLanguageObj->getFormField('directory') != 'faq')
				{
						$editLanguageObj->setAllPageBlocksHide();
						$editLanguageObj->setPageBlockShow('form_files_list');
				}
				else
				{
						$editLanguageObj->setAllPageBlocksHide();
						$editLanguageObj->setPageBlockShow('form_faq_list');
						require (sprintf($directory_path_arr[$editLanguageObj->getFormField('directory')], $editLanguageObj->getFormField('language')));
				}
		}
		else
		{
				$editLanguageObj->setAllPageBlocksHide();
				$editLanguageObj->setPageBlockShow('form_directory_list');
				$editLanguageObj->setPageBlockShow('msg_form_error');
		}
}
if ($editLanguageObj->isFormPOSTed($_POST, 'submit_files'))
{
		$editLanguageObj->sanitizeFormInputs($_POST);
		$editLanguageObj->chkIsNotEmpty('language', $LANG['langedit_err_tip_compulsory']) and $editLanguageObj->chkIsFromList($CFG['lang']['available_languages'], 'language', $LANG['langedit_err_tip_invalid']);
		$editLanguageObj->chkIsNotEmpty('directory', $LANG['langedit_err_tip_compulsory']) and $editLanguageObj->chkIsFromList($lang_folders_arr, 'directory', $LANG['langedit_err_tip_invalid']);
		$editLanguageObj->chkIsNotEmpty('file', $LANG['langedit_err_tip_compulsory']) and $editLanguageObj->chkIsFileExist('file', $unwanted_files_list_arr, $LANG['langedit_err_tip_invalid'], $LANG['langedit_read_err_tip_invalid'], $LANG['langedit_write_err_tip_invalid']);
		if ($editLanguageObj->isValidFormInputs())
		{
				$editLanguageObj->setAllPageBlocksHide();
				$editLanguageObj->setPageBlockShow('form_edit_phrases');
		}
		else
		{
				$editLanguageObj->setAllPageBlocksHide();
				$editLanguageObj->setPageBlockShow('form_files_list');
				$editLanguageObj->setPageBlockShow('msg_form_error');
		}
}
if ($editLanguageObj->isFormPOSTed($_POST, 'submit_phrases'))
{
		$editLanguageObj->sanitizeFormInputs($_POST);
		$editLanguageObj->chkIsNotEmpty('language', $LANG['langedit_err_tip_compulsory']) and $editLanguageObj->chkIsFromList($CFG['lang']['available_languages'], 'language', $LANG['langedit_err_tip_invalid']);
		$editLanguageObj->chkIsNotEmpty('directory', $LANG['langedit_err_tip_compulsory']) and $editLanguageObj->chkIsFromList($lang_folders_arr, 'directory', $LANG['langedit_err_tip_invalid']);
		$editLanguageObj->chkIsNotEmpty('file', $LANG['langedit_err_tip_compulsory']) and $editLanguageObj->chkIsFileExist('file', $unwanted_files_list_arr, $LANG['langedit_err_tip_invalid'], $LANG['langedit_read_err_tip_invalid'], $LANG['langedit_write_err_tip_invalid']);
		$editLanguageObj->updateFileContent($_POST);
		$editLanguageObj->setAllPageBlocksHide();
		$editLanguageObj->setPageBlockShow('form_directory_list');
		$editLanguageObj->setPageBlockShow('msg_form_success');
		$editLanguageObj->setPageBlockShow('page_list_phrases');
		$editLanguageObj->setFormField('success_msg', sprintf($LANG['langedit_msg_success'], $editLanguageObj->getFormField('file')));
}
if ($editLanguageObj->isFormPOSTed($_GET, 'language') and $editLanguageObj->isFormPOSTed($_GET, 'directory'))
{
		$editLanguageObj->sanitizeFormInputs($_GET);
		$editLanguageObj->chkIsNotEmpty('language', $LANG['langedit_err_tip_compulsory']) and $editLanguageObj->chkIsFromList($CFG['lang']['available_languages'], 'language', $LANG['langedit_err_tip_invalid']);
		$editLanguageObj->chkIsNotEmpty('directory', $LANG['langedit_err_tip_compulsory']) and $editLanguageObj->chkIsFromList($lang_folders_arr, 'directory', $LANG['langedit_err_tip_invalid']);
		if ($editLanguageObj->isValidFormInputs())
		{
				$editLanguageObj->setAllPageBlocksHide();
				$editLanguageObj->setPageBlockShow('form_files_list');
		}
		else
		{
				$editLanguageObj->setAllPageBlocksHide();
				$editLanguageObj->setPageBlockShow('form_directory_list');
				$editLanguageObj->setPageBlockShow('msg_form_error');
		}
}
if ($editLanguageObj->isFormPOSTed($_GET, 'action'))
{
		$editLanguageObj->sanitizeFormInputs($_POST);
		$editLanguageObj->chkIsNotEmpty('language', $LANG['langedit_err_tip_compulsory']) and $editLanguageObj->chkIsFromList($CFG['lang']['available_languages'], 'language', $LANG['langedit_err_tip_invalid']);
		$editLanguageObj->chkIsNotEmpty('directory', $LANG['langedit_err_tip_compulsory']) and $editLanguageObj->chkIsFromList($lang_folders_arr, 'directory', $LANG['langedit_err_tip_invalid']);
		if ($editLanguageObj->isValidFormInputs())
		{
				if ($editLanguageObj->getFormField('action') == 'addFAQ') $editLanguageObj->setFormField('add_new_faq', $editLanguageObj->getFormField('add_new_faq') + 1);
				require (sprintf($directory_path_arr[$editLanguageObj->getFormField('directory')], $editLanguageObj->getFormField('language')));
				$editLanguageObj->setAllPageBlocksHide();
				$editLanguageObj->setPageBlockShow('form_faq_list');
		}
		else
		{
				$editLanguageObj->setAllPageBlocksHide();
				$editLanguageObj->setPageBlockShow('form_faq_list');
				$editLanguageObj->setPageBlockShow('msg_form_error');
		}
}
if ($editLanguageObj->isFormPOSTed($_POST, 'submit_faq'))
{
		$editLanguageObj->sanitizeFormInputs($_POST);
		$editLanguageObj->chkIsNotEmpty('language', $LANG['langedit_err_tip_compulsory']) and $editLanguageObj->chkIsFromList($CFG['lang']['available_languages'], 'language', $LANG['langedit_err_tip_invalid']);
		$editLanguageObj->chkIsNotEmpty('directory', $LANG['langedit_err_tip_compulsory']) and $editLanguageObj->chkIsFromList($lang_folders_arr, 'directory', $LANG['langedit_err_tip_invalid']);
		if ($editLanguageObj->isValidFormInputs())
		{
				$editLanguageObj->updateFAQIntoFAQListArray('question', 'answer');
				$editLanguageObj->setAllPageBlocksHide();
				$editLanguageObj->setPageBlockShow('form_directory_list');
				$editLanguageObj->setPageBlockShow('msg_form_success');
				$editLanguageObj->setFormField('success_msg', $LANG['langedit_faq_edit_success']);
		}
		else
		{
				$editLanguageObj->setAllPageBlocksHide();
				$editLanguageObj->setPageBlockShow('form_faq_list');
				$editLanguageObj->setPageBlockShow('msg_form_error');
		}
}



?>
<div id="selHelpLangEdit">
	<div id="selManageLaguageFile">
	<h2><?php echo $LANG['langedit_lang_editing']; ?></h2>
<?php
if ($editLanguageObj->isShowPageBlock('msg_form_error'))
{
?>  <div id="selMsgError">
	   <p><?php echo $LANG['msg_error_sorry'] . ' ' . $editLanguageObj->getCommonErrorMsg(); ?></p>
	</div>
<?php
}
if ($editLanguageObj->isShowPageBlock('msg_form_success'))
{
?>  <div id="selMsgSuccess">
    	<p><?php echo $editLanguageObj->getFormField('success_msg'); ?></p>
    </div>
<?php
}
if ($editLanguageObj->isShowPageBlock('form_directory_list'))
{
?>
	<div id="selDirectoryList">
		<form name="form_directory_list" id="form_directory_list" method="post" action="editLanguageFile.php" autocomplete="off">
			<table summary="<?php echo $LANG['langedit_directory_table']; ?>">
				<tr>
					<td class="<?php echo $editLanguageObj->getCSSFormLabelCellClass('language'); ?>"><label for="selLanguage"><?php echo $LANG['langedit_language']; ?></label></td>
					<td class="<?php echo $editLanguageObj->getCSSFormFieldCellClass('language'); ?>"><?php echo $editLanguageObj->getFormFieldErrorTip('language'); ?>
						<select name="language" id="selLanguage" tabindex="1000">
							<?php $editLanguageObj->populateList($CFG['lang']['available_languages'], $editLanguageObj->getFormField('language')); ?>
						</select></td>
				</tr>
	       		<tr>
					<td class="<?php echo $editLanguageObj->getCSSFormLabelCellClass('directory'); ?>"><label for="selDirectory"><?php echo $LANG['langedit_directory']; ?></label></td>
					<td class="<?php echo $editLanguageObj->getCSSFormFieldCellClass('directory'); ?>"><?php echo $editLanguageObj->getFormFieldErrorTip('directory'); ?>
						<select name="directory" id="selDirectory" tabindex="1005">
							<?php $editLanguageObj->populateList($lang_folders_arr, $editLanguageObj->getFormField('directory')); ?>
						</select></td>
				</tr>
				<tr>
					<td class="<?php echo $editLanguageObj->getCSSFormFieldCellClass('submit'); ?>" colspan="2"><input type="submit" class="clsSubmitButton" name="submit_directory" id="submit_directory" value="<?php echo $LANG['langedit_submit']; ?>" tabindex="1010" /></td>
				</tr>
			</table>
		</form>
	</div>
<?php
}
if ($editLanguageObj->isShowPageBlock('form_files_list'))
{
?>
	<div id="selFilesList">
		<form name="form_files_list" id="form_files_list" method="post" action="editLanguageFile.php" autocomplete="off">
			<table summary="<?php echo $LANG['langedit_files_table']; ?>">
				<tr>
        			<td class="<?php echo $editLanguageObj->getCSSFormLabelCellClass('language'); ?>"><label for="selLanguage"><?php echo $LANG['langedit_language']; ?></label></td>
        			<td class="<?php echo $editLanguageObj->getCSSFormFieldCellClass('language'); ?>"><?php echo $CFG['lang']['available_languages'][$editLanguageObj->getFormField('language')]; ?></td>
				</tr>
        		<tr>
        			<td class="<?php echo $editLanguageObj->getCSSFormLabelCellClass('directory'); ?>"><label for="selDirectory"><?php echo $LANG['langedit_directory']; ?></label></td>
        			<td class="<?php echo $editLanguageObj->getCSSFormFieldCellClass('directory'); ?>"><?php echo $lang_folders_arr[$editLanguageObj->getFormField('directory')]; ?></td>
				</tr>
				<tr>
					<td class="<?php echo $editLanguageObj->getCSSFormLabelCellClass('file'); ?>">
						<label for="selFile"><?php echo $LANG['langedit_file']; ?></label>
					</td>
					<td class="<?php echo $editLanguageObj->getCSSFormFieldCellClass('file'); ?>"><?php echo $editLanguageObj->getFormFieldErrorTip('file'); ?>
						<select name="file" id="selFile" tabindex="1000">
							<?php $editLanguageObj->populateFileNamesList($editLanguageObj->getFormField('file'), $unwanted_files_list_arr); ?>
						</select>
	  				</td>
	  			</tr>
				<tr>
					<td class="<?php echo $editLanguageObj->getCSSFormFieldCellClass('submit'); ?>" colspan="2">
						<?php $editLanguageObj->populateHiddenFormFields(array('language', 'directory')); ?>
						<input type="submit" class="clsSubmitButton" name="submit_files" id="selSubmitFiles" value="<?php echo $LANG['langedit_submit']; ?>" tabindex="1005" /></td>
				</tr>
			</table>
		</form>
	</div>
<?php
}
if ($editLanguageObj->isShowPageBlock('form_edit_phrases'))
{
?>
	<div id="selEditForm">
		<h3><a href="editLanguageFile.php"><?php echo $CFG['lang']['available_languages'][$editLanguageObj->getFormField('language')]; ?></a>/<a href="<?php echo 'editLanguageFile.php?language=' . $editLanguageObj->getFormField('language') . '&directory=' . $editLanguageObj->getFormField('directory') . '&file=' . $editLanguageObj->getFormField('file'); ?>"><?php echo $lang_folders_arr[$editLanguageObj->getFormField('directory')]; ?></a><?php echo '/' . $editLanguageObj->getFormField('file'); ?></h3>
		<form name="editFrm" id="editFrm" method="post" action="editLanguageFile.php">
		<table summary="<?php echo $LANG['langedit_edit_table']; ?>">
			<tr>
				<th><?php echo $LANG['langedit_variable_name']; ?></th>
				<th><?php echo $LANG['langedit_new_value']; ?></th>
			</tr>
<?php $lang_update = $LANG['langedit_update'];
		unset($LANG);
		require ($directory_path_arr[$editLanguageObj->getFormField('directory')] . $editLanguageObj->getFormField('language') . '/' . $editLanguageObj->getFormField('file'));
		foreach ($LANG as $key => $value)
		{
?>			<tr>
				<td class="<?php echo $editLanguageObj->getCSSFormLabelCellClass('varable'); ?>"><label for="<?php echo $key; ?>"><?php echo $key; ?></label></td>
				<td class="<?php echo $editLanguageObj->getCSSFormFieldCellClass('phrase'); ?>"><textarea name="<?php echo $key; ?>" id="<?php echo $key; ?>" tabindex="1000" rows="3" cols="50"><?php echo $editLanguageObj->stripslashesNew($value); ?></textarea></td>
			</tr>
<?php }
?>			<tr>
				<td class="<?php echo $editLanguageObj->getCSSFormFieldCellClass('submit'); ?>" colspan="2">
					<?php $editLanguageObj->populateHiddenFormFields(array('language', 'directory', 'file')); ?>
					<input type="submit" class="clsSubmitButton" name="submit_phrases" id="selSubmitPhrases" value="<?php echo $lang_update; ?>" tabindex="1005" /></td>
			</tr>
			</table>
		</form>
	</div>
<?php
}
if ($editLanguageObj->isShowPageBlock('page_list_phrases'))
{
?>	<div id="selPhrasesList">
		<h3><?php echo $CFG['lang']['available_languages'][$editLanguageObj->getFormField('language')] . '/' . $lang_folders_arr[$editLanguageObj->getFormField('directory')] . '/' . $editLanguageObj->getFormField('file'); ?></h3>
			<table summary="<?php echo $LANG['langedit_edit_table']; ?>">
			<tr>
				<th><?php echo $LANG['langedit_variable_name']; ?></th>
				<th><?php echo $LANG['langedit_new_value']; ?></th>
			</tr>
<?php unset($LANG);
		require ($directory_path_arr[$editLanguageObj->getFormField('directory')] . $editLanguageObj->getFormField('language') . '/' . $editLanguageObj->getFormField('file'));
		foreach ($LANG as $key => $value)
		{
?>			<tr>
				<td><?php echo $key; ?></td>
				<td><?php echo $editLanguageObj->stripslashesNew($value); ?></td>
			</tr>
<?php }
?>			</table>
	</div>
<?php
}
if ($editLanguageObj->isShowPageBlock('form_faq_list'))
{
?>
	<div id="selEditForm">
		<p><a href="<?php echo 'editLanguageFile.php?action=addFAQ&amp;directory=' . $editLanguageObj->getFormField('directory') . '&amp;language=' . $editLanguageObj->getFormField('language'); ?>"><?php echo $LANG['langedit_add_faq']; ?></a></p>
		<p><?php echo $LANG['langedit_faq_delete_note']; ?></p>
		<form name="form_edit_faq" id="form_edit_faq" method="post" action="editLanguageFile.php">
			<input type="hidden" name="add_new_faq" value="<?php echo $editLanguageObj->getFormField('add_new_faq'); ?>" />
			<input type="hidden" name="directory" value="<?php echo $editLanguageObj->getFormField('directory'); ?>" />
			<input type="hidden" name="language" value="<?php echo $editLanguageObj->getFormField('language'); ?>" />
		<table summary="<?php echo $LANG['langedit_edit_table']; ?>">
			<tr>
				<th><?php echo $LANG['langedit_question']; ?></th>
				<th><?php echo $LANG['langedit_answer']; ?></th>
			</tr>
<?php

		foreach ($LANG_LIST_ARR['faq'] as $key => $value)
		{
?>			<tr>
				<td class="<?php echo $editLanguageObj->getCSSFormFieldCellClass('question'); ?>"><textarea name="question[]" tabindex="1000" rows="3" cols="50"><?php echo $key; ?></textarea></td>
				<td class="<?php echo $editLanguageObj->getCSSFormFieldCellClass('answer'); ?>"><textarea name="answer[]" tabindex="1000" rows="3" cols="50"><?php echo $value; ?></textarea></td>
			</tr>
<?php }
		for ($i = 0; $i < $editLanguageObj->getFormField('add_new_faq'); $i++)
		{
?>			<tr>
				<td class="<?php echo $editLanguageObj->getCSSFormFieldCellClass('question'); ?>"><textarea name="question[]" tabindex="1000" rows="3" cols="50"></textarea></td>
				<td class="<?php echo $editLanguageObj->getCSSFormFieldCellClass('answer'); ?>"><textarea name="answer[]" tabindex="1000" rows="3" cols="50"></textarea></td>
			</tr>
<?php }
?>			<tr>
				<td class="<?php echo $editLanguageObj->getCSSFormFieldCellClass('submit'); ?>" colspan="2">
					<?php $editLanguageObj->populateHiddenFormFields(array('language', 'directory', 'file')); ?>
					<input type="submit" class="clsSubmitButton" name="submit_faq" id="selSubmitFaq" value="<?php echo $LANG['langedit_update']; ?>" tabindex="1005" /></td>
			</tr>
			</table>
		</form>
	</div>
<?php
}
?>
	</div>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>
