<?php

   class blogStoryData extends Data {

      var $table = BLOG_STORY_TABLE;

      var $config = array (
  'table' => BLOG_STORY_TABLE,
  'idField' => 'id',
  'addedMsg' => 'Osdate Blog Story %s Added',
  'added_err' => 'Can\\\'t Add Osdate Blog Story',
  'editMsg' => 'Osdate Blog Story %s Updated',
  'editErr' => 'Can\\\'t Update Osdate Blog Story',
  'delErr' => 'Can\\\'t Delete Osdate Blog Story',
  'delMsg' => 'Osdate Blog Story %s Deleted',
  'blankErr' => 'Osdate Blog Story Empty',
  'fields' => 
  array (
    'userid' => 
    array (
      'name' => 'userid',
      'description' => 'Userid',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'adminid' => 
    array (
      'name' => 'adminid',
      'description' => 'Adminid',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'date_posted' => 
    array (
      'name' => 'date_posted',
      'description' => 'Date Posted',
      'type' => 'date',
      'min_len' => 0,
      'max_len' => 10,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'title' => 
    array (
      'name' => 'title',
      'description' => 'Title',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 65535,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'story' => 
    array (
      'name' => 'story',
      'description' => 'Story',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 65535,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'views' => 
    array (
      'name' => 'views',
      'description' => 'Views',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
  ),
);   

      function blogStoryData() {
      
         $this->Data($this->config);
      }
   }

?>
