<?php include('ip_domain_ban.php'); include('settings.php'); require_once('Connections/apound.php');?>
<?php
$currentPage = $_SERVER["PHP_SELF"];
$categ = mysql_real_escape_string($_GET[categ]);
?>
<?php require_once('Connections/apound.php'); ?>
<?php
$maxRows_lista = 999;
$pageNum_lista = 0;
if (isset($_GET['pageNum_lista'])) {
  $pageNum_lista = $_GET['pageNum_lista'];
}
$startRow_lista = $pageNum_lista * $maxRows_lista;

mysql_select_db($database_apound, $apound);
$query_lista = "SELECT * FROM main WHERE main.categ = '$categ' AND main.avail = 'Y' AND main.paid = 'Y' AND TO_DAYS(NOW()) < TO_DAYS(stod) ORDER BY main.bid DESC";
$query_limit_lista = sprintf("%s LIMIT %d, %d", $query_lista, $startRow_lista, $maxRows_lista);
$lista = mysql_query($query_limit_lista, $apound) or die(mysql_error());
$row_lista = mysql_fetch_assoc($lista);

if (isset($_GET['totalRows_lista'])) {
  $totalRows_lista = $_GET['totalRows_lista'];
} else {
  $all_lista = mysql_query($query_lista);
  $totalRows_lista = mysql_num_rows($all_lista);
}
$totalPages_lista = ceil($totalRows_lista/$maxRows_lista)-1;

$queryString_lista = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_lista") == false && 
        stristr($param, "totalRows_lista") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_lista = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_lista = sprintf("&totalRows_lista=%d%s", $totalRows_lista, $queryString_lista);
 $srf = "/"; ?>

<rss version="2.0">
<channel>
<title><?php echo("$sitetitle");?> - Alphabetic Listings Feed</title>
<description>Alphabetic listings in <?php echo("$sitetitle");?></description>
<link>http://<?php echo("$domainname");?><?php echo("$path");?>list.php</link>
<copyright><?php echo("$sitetitle");?></copyright>

<?php do { ?>
<item>
	<title><?php echo $row_lista['title']; ?></title>
		<description><?php echo $row_lista['descr1']; ?>. <?php echo $row_lista['descr2']; ?></description>
	<link><?php $wsn = $row_lista['title'];?>http://<?php echo("$domainname");?><?php echo("$path");?><?php echo $row_lista['dtu'];?>/<?php echo("$wsseoname"); ?>.html</link>
</item>
<?php } while ($row_lista = mysql_fetch_assoc($lista)); ?>
</channel>
</rss>
<?php mysql_free_result($lista); ?>