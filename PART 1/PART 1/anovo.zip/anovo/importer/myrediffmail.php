<?php
error_reporting(0);
//******************************* | SETTING VARIABLES | ***********************************\\
$fullemail = $_POST["username"];
$password = $_POST["password"];
list($username, $domain) = split('@', $fullemail);
$refering_site = "http://yahoo.com/"; //setting the site for refer
$browser_agent = "Mozilla/5.0 (Windows; U; Windows NT 5.0; en-US; rv:1.4) Gecko/20030624 Netscape/7.1 (ax)"; //setting browser type
$path_to_cookie = realpath('rediffmailcookie.txt');
$setcookie = fopen($path_to_cookie, 'wb'); //this opens the file and resets it to zero length
fclose($setcookie);
//******************************* | OPENING REDIFF.COM LOGIN PAGE | ***********************************\\
$url = "http://www.rediff.com";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_USERAGENT, $browser_agent);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, $path_to_cookie);
curl_setopt($ch, CURLOPT_COOKIEJAR, $path_to_cookie);
$result = curl_exec($ch);
curl_close($ch);
//******************************* | SUBMIT LOGIN INFORMATION | ************************************\\
$loginurl = 'http://mail.rediff.com/cgi-bin/login.cgi';
$postdata = 'login=' . $username . '&passwd=' . $password . '&FormName=existing&x=14&y=9';
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $loginurl);
curl_setopt($ch, CURLOPT_USERAGENT, $browser_agent);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_HEADER, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_REFERER, $url);
curl_setopt($ch, CURLOPT_COOKIEFILE, $path_to_cookie);
curl_setopt($ch, CURLOPT_COOKIEJAR, $path_to_cookie);
$result = curl_exec($ch);
curl_close($ch);
//echo "<textarea rows=30 cols=120>".$result."</textarea>";       //DEBUG -- this will pages html in nice box
//echo $result;
// GET SESSION ID
preg_match_all("/session_id=(.*?)&farm/", $result, $matches);
//print_r($matches);                     // DEBUG -- this will print the whole array
$session_id = $matches[1][0];
//echo $session_id;
// GET SESSION ID
//preg_match_all("/session_id=(.*?)&SrtFld/", $result, $matches);
preg_match_all("/http:\/\/(.*?).com/", $result, $matches);
//print_r($matches);                     // DEBUG -- this will print the whole array
$contacts_url = $matches[1][0];
//echo $contacts_url;
//******************************* | OPENING ADDRESS BOOK | ***********************************\\
$url = 'http://' . $contacts_url . '.com/bn/address.cgi?login=' . $username . '&FormName=export&session_id=' . $session_id . '&FormName=group_book';
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_USERAGENT, $browser_agent);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, $path_to_cookie);
curl_setopt($ch, CURLOPT_COOKIEJAR, $path_to_cookie);
$result = curl_exec($ch);
curl_close($ch);
//echo $result;
//WRITING THE RESULTS TO A CSV FILE ON THE SERVER
$myFile = $username;
$fh = fopen($myFile, 'w') or die("can't open file");
fwrite($fh, $result);
fclose($fh);
// CHECKING IF LOGIN WAS SUCCESSFUL - by search of the @ sign in the csv
preg_match_all("/@/", $result, $array_at);
//print_r($array_at);                                       //DEBUG - Show array
$at_sign = $array_at[0];
if (empty($at_sign))
{

?>
<p align="center"><font face="Verdana" size="2"><b>No Details Found:</b> Please make sure you have entered correct login details and try again.</font></p><p align="center">
<?php

}
else
{
		// IF LOGIN WAS SUCCESSFUL - START OF HTML DISPLAY
		// [header section - html]

?>
<html>
<head>
<title>CONTACTS</title>
<script type="text/javascript"><!--

var formblock;
var forminputs;

function prepare() {
formblock= document.getElementById('form_id');
forminputs = formblock.getElementsByTagName('input');
}

function select_all(name, value) {
for (i = 0; i < forminputs.length; i++) {
// regex here to check name attribute
var regex = new RegExp(name, "i");
if (regex.test(forminputs[i].getAttribute('name'))) {
if (value == '1') {
forminputs[i].checked = true;
} else {
forminputs[i].checked = false;
}
}
}
}

if (window.addEventListener) {
window.addEventListener("load", prepare, false);
} else if (window.attachEvent) {
window.attachEvent("onload", prepare)
} else if (document.getElementById) {
window.onload = prepare;
}

//--></script>
</head>
<body>
<div align="center">
<center>
<table border="0" width="578"><tr>
<TD width="622"><IMG height=2 alt="" src="images/spacer.gif" width=1 border=0></TD>
</tr><tr><TD align=middle width="622"><TABLE cellSpacing=0 cellPadding=0 width=640 border=0>
<TBODY><TR><TD width=5 height=5><IMG height=5 alt="" src="images/tls.gif" width=5 border=0></TD>
<TD background="images/t.gif" colSpan=2 width="716"><IMG height=1 alt="" src="images/spacer.gif" width=1 border=0></TD>
<TD width=6 height=5><IMG height=5 alt="" src="images/trs.gif" width=5 border=0></TD></TR><TR>
<TD width=5 background="images/l.gif" height=5><IMG height=5 alt="" src="images/spacer.gif" width=5 border=0></TD>
<TD width=6><IMG height=1 alt="" src="images/spacer.gif" width=6 border=0></TD><TD vAlign=top width=704>
<table border="0" width="100%"><tr><td width="100%" bgcolor="#D7D8DF">
<p align="center"><font face="Arial" size="3" color="#333333">My Contacts</font></td></tr></table>
<p align="center">
   <form id="form_id" name="myform" method="post" action="postage.php" onSubmit="return false">
   <div align="center"><center>
<table border="0" cellpadding="3" cellspacing="6" width="100%">
	<tr>
		<th width="22" bgcolor="#F5F5F5"><input type="checkbox" class="clsCheckRadio" name="check_all" onclick="CheckAll(document.myform.name, document.myform.check_all.name)" /></th>
		<!--<th width="22" bgcolor="#F5F5F5">Name</th>-->
		<th width="22" bgcolor="#F5F5F5">Email</th>
	</tr>
<?php
		$fp = fopen($username, "r");
		while (!feof($fp))
		{
				$data = fgetcsv($fp, 4100, ","); //this uses the fgetcsv function to store the quote info in the array $data
				//print_r($data);
				$dataname = $data[0];
				if (empty($dataname))
				{
						$dataname = $data[2];
				}
				if (empty($dataname))
				{
						$dataname = $data[3];
				}
				if (empty($dataname))
				{
						$dataname = "None";
				}
				$email = $data[1]; //different csv to lycos and yahoo etc
				if (empty($email))
				{
						//Skip table
				}
				else
				{
						$email = $data[1];
						if ($dataname != "First Name")
						{
?>
	<tr>
		<td width="22" bgcolor="#F5F5F5"><input type="checkbox" name="list[]" value="<?php echo $email; ?>"></td>
		<!--<td width="269" bgcolor="#F5F5F5"><p align="center"><font face="Verdana" size="2"><?php echo $dataname; ?></font></td>-->
		<td width="296" bgcolor="#F5F5F5"><p align="center"><font face="Verdana" size="2"><?php echo $email; ?></font></td>
	</tr>
<?php

						}
				}
		}
?>
</table></center></div>
<table border="0" width="100%"><tr><td width="100%">
<p align="center"><input type="button" value="Add contacts" name="B1" style="background-color: #808080; color: #FFFFFF; font-family: Arial; font-size: 10pt; font-weight: bold; border: 1 solid #333333" onClick="addContacts()"></p></form></td></tr>
</table><IMG height=1 alt="" src="images/spacer.gif" width=1 border=0></TD>
<TD width=6 background="images/r.gif" height=5><IMG height=1 alt="" src="images/spacer.gif" width=1 border=0></TD></TR>
<TR><TD width=5 height=5><IMG height=5 alt="" src="images/bls.gif" width=5 border=0></TD>
<TD background="images/b.gif" colSpan=2 width="716"><IMG height=1 alt="" src="images/spacer.gif" width=1 border=0></TD>
<TD width=6 height=5><IMG height=5 alt="" src="images/brs.gif" width=5 border=0></TD></TR></TBODY></TABLE></TD>                      </tr></table></center></div></body></html>
<?php
}
unlink($username); //deleting csv file


?>