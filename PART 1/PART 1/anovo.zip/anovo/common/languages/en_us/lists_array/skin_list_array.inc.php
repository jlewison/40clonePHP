<?php
$LANG_LIST_ARR['skin'] = array(
							'blue_skin' => 'Blue',
							'dark_blue_skin' => 'Dark Blue',
							'purple_skin' => 'Purple',
							'silver_skin' => 'Silver',
							'yellow_skin' => 'Yellow',
							'orange_skin' => 'Orange'
							);
?>