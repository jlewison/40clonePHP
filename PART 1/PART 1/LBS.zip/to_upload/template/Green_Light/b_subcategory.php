<?php
if($cat1 <> '' and $cat2 <> '' and $cat3 <> '' and $category <> '') { 

	mysql_select_db($database_apound, $apound);
	$query_SBC = "SELECT * FROM categorylisting WHERE catlistid = $categnum";
	$SBC = mysql_query($query_SBC, $apound) or die(mysql_error());
	$row_SBC = mysql_fetch_assoc($SBC);
	$totalRows_SBC = mysql_num_rows($SBC);
	$n_csn = $row_SBC['categoryname'];
	$n_csn2 = $row_SBC['categseoname'];

if($categnumB <> '') {
	mysql_select_db($database_apound, $apound);
	$query_SBCb = "SELECT * FROM categorylisting WHERE catlistid = $categnumB";
	$SBCb = mysql_query($query_SBCb, $apound) or die(mysql_error());
	$row_SBCb = mysql_fetch_assoc($SBCb);
	$totalRows_SBCb = mysql_num_rows($SBCb);
	$n_csnb = $row_SBCb['categoryname'];
	$n_csnb2 = $row_SBCb['categseoname'];
}
else {}
?>

<ul>
    <li>
		<?php if($categNA <> '' and $categNB <> '') { ?>
        <a href="<?php echo("$path$categNA/");?>"><?php echo("$categNA<br>"); ?></a>
        <a href="<?php echo("$path$categNA/$categNB/");?>"><?php echo("$categNB<br>"); ?></a>
        <a href="<?php echo("$path$categNA/$categNB/$categNC/");?>"><?php echo("$categNC<br>"); ?></a>
        <?php }
        elseif($categNA <> '' and $categNB == '') { echo("$categNA<br>"); } 
        else {}
        $egycat = $row_SBC['categoryname'];
        ?>
        <a href=""><?php echo("$egycat");?></a>
    </li>
</ul>


<?php }
else {}

$ifthis = $row_categSRL['categseoname'];

if($ifthis <> '') { 

	mysql_select_db($database_apound, $apound);
	$query_SBC = "SELECT * FROM categorylisting WHERE catlistid = $categnum";
	$SBC = mysql_query($query_SBC, $apound) or die(mysql_error());
	$row_SBC = mysql_fetch_assoc($SBC);
	$totalRows_SBC = mysql_num_rows($SBC);
	$n_csn = $row_SBC['categoryname'];
	$n_csn2 = $row_SBC['categseoname'];

if($categnumB <> '') {
	mysql_select_db($database_apound, $apound);
	$query_SBCb = "SELECT * FROM categorylisting WHERE catlistid = $categnumB";
	$SBCb = mysql_query($query_SBCb, $apound) or die(mysql_error());
	$row_SBCb = mysql_fetch_assoc($SBCb);
	$totalRows_SBCb = mysql_num_rows($SBCb);
	$n_csnb = $row_SBCb['categoryname'];
	$n_csnb2 = $row_SBCb['categseoname'];
}
else {}
?>

<ul>
		<?php if($cat1 == '' and $cat2 == '' and $cat3 == '' and $category <> '') { ?>
	<li><a href=""><?php echo $row_SBC['categseoname'];?></a></li>
		<?php } elseif($cat1 <> '' and $cat2 == '' and $cat3 == '' and $category <> '') { ?>
	<li><a href="<?php echo("$path$categNA/");?>"><?php echo("$categNA");?></a></li>
	<li><a href=""><?php echo $row_SBC['categseoname'];?></a></li>
		<?php } elseif($cat1 <> '' and $cat2 <> '' and $cat3 == '' and $category <> '') { ?>
	<li><a href="<?php echo("$path$categNA/");?>"><?php echo("$categNA");?></a></li>
	<li><a href="<?php echo("$path$categNA/$categNB/");?>"><?php echo("$categNB");?></a></li>
	<li><a href=""><?php echo $row_SBC['categseoname'];?></a></li>
		<?php } else { ?>
	<li><a href="#">#</a></li>
	<li><a href="#">#</a></li>
	<li><a href="#">#</a></li>
	<li><a href="#">#</a></li>
		<?php } ?>
</ul>

<?php mysql_free_result($SBC); if($categNA <> '') { $fcatut = "$categNA"; } else { $fcatut = $row_SBC['categseoname']; } ?>

<ul>
		<?php do { ?>
	<li><a href="<?php echo("$path");?><?php echo("$fcatut"); ?>/<?php if($categNA <> '' and $categNB <> '') { echo("$n_csnb/$n_csn/"); } elseif($categNA <> '' and $categNB == '') { echo("$n_csn2/"); } else { }?><?php echo $row_categSRL['categseoname']; ?>/"><?php echo $row_categSRL['categoryname']; ?></a></li>
		<?php $row_categSRL = mysql_fetch_assoc($categSRL); if (!isset($nested_categSRL)) { $nested_categSRL= 1; } } while ($row_categSRL); ?>
</ul>

<hr align="center" width="90%" /> 
<?php } else { } ?>