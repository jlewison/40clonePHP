<?php

/**
 * Network Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 12/18/2007
 */
class Network extends Controller
{
		//Constructor
		function Network()
		{
				parent::Controller();
				loginRequired();
				//Load the language file
				$this->lang->load('network', $this->config->item('language_code'));
				//Load the network model
				$this->load->model('networkmodel');
		}
		//Default function
		function index()
		{
				$this->browse();
		}
		function browse()
		{
				if ($this->uri->segment(3) == '' || ($this->uri->segment(3) != 'school' && $this->uri->segment(3) != 'college' && $this->uri->segment(3) != 'work' && $this->uri->segment(3) != 'region')) $networkType = 'region';
				else  $networkType = $this->uri->segment(3);
				$this->load->model('usermodel');
				$outputData['networkType'] = $networkType;
				$outputData['networks'] = $this->networkmodel->getNetwork($networkType);
				$outputData['networksCount'] = count($outputData['networks']);
				$outputData['country'] = $this->usermodel->getCountry(false);
				$this->smartyextended->view('networkbrowse', $outputData);
		}
		function view()
		{
				if ($this->networkmodel->isExist($this->uri->segment(3)))
				{
						//Load the discussion board model
						$this->load->model('discussionboardmodel');
						$this->load->model('wallmodel');
						$this->load->model('groupsmodel');
						$this->load->model('eventsmodel');
						$this->load->model('marketplacemodel');
						$networkId = $this->uri->segment(3);
						$outputData['networkDetails'] = $this->networkmodel->getNetworkDetails($networkId);
						$members = $outputData['members'] = $this->networkmodel->getMembers($networkId);
						$outputData['membersCount'] = count($outputData['members']);
						$outputData['totalMembersCount'] = $this->networkmodel->getMembersCount($networkId);
						//For discussion topic
						$outputData['discussionTopics'] = $this->discussionboardmodel->getDiscussionBoardTopic('network', $networkId, '', '', 'date_added', 0, 5);
						$outputData['discussionTopicsCount'] = count($outputData['discussionTopics']);
						$outputData['discussionTopicsTotal'] = $this->discussionboardmodel->getDiscussionBoardTopicCount('network', $networkId, '', '', 'date_added');
						//For wall
						$outputData['wall'] = $this->wallmodel->getWall('network', $networkId, 'wall_date desc', 0, 10);
						$outputData['wallCount'] = count($outputData['wall']);
						$outputData['wallTotal'] = $this->wallmodel->getWallCount('network', $networkId);
						if ($this->networkmodel->isUserExist($networkId, $this->session->userdata('user_id')))
						{
								$outputData['joined'] = 1;
								$start = 0;
								$limit = 5;
								$resultgroups = $this->groupsmodel->getNetworkGroups($networkId, $this->session->userdata('user_id'), $start, $limit);
								foreach ($resultgroups as $key => $detail)
								{
										$resultgroups[$key]['avatar'] = $this->groupsmodel->getGroupImage($detail['group_id'], true);
								}
								$outputData['resultgroups'] = $resultgroups;
								$outputData['resultscountgroup'] = count($resultgroups);
								$outputData['group_network'] = $networkId;
								$start = 0;
								$limit = 5;
								$resultevents = $this->eventsmodel->getNetworkEvents($networkId, $this->session->userdata('user_id'), $start, $limit);
								foreach ($resultevents as $key => $detail)
								{
										$resultevents[$key]['avatar'] = $this->eventsmodel->geteventImage($detail['event_id'], true);
								}
								$outputData['resultevents'] = $resultevents;
								$outputData['resultscountevent'] = count($resultevents);
								$outputData['event_network'] = $networkId;
								$start = 0;
								$limit = 5;
								$resultmarket = $this->marketplacemodel->getNetworkMarket($networkId, $start, $limit);
								foreach ($resultmarket as $key => $detailArr)
								{
										$resultmarket[$key]['avatar'] = $this->marketplacemodel->getMarketplaceImage($detailArr['list_id'], $detailArr['list_type'], true);
								}
								$outputData['resultmarket'] = $resultmarket;
								$outputData['resultscountmarket'] = count($resultmarket);
								$outputData['market_network'] = $networkId;
								$this->smartyextended->view('networkview', $outputData);
						}
						else
						{
								$outputData['joined'] = 0;
								if ($outputData['networkDetails']['network_type'] == 'region') $this->smartyextended->view('networkview', $outputData);
								else  $this->smartyextended->view('networkviewlimited', $outputData);
						}
				}
				else  redirect('network/browse');
		}
		function joinValidation()
		{
				$this->load->helper('validation');
				if (isValidEmail($this->input->post('join_email')))
				{
						//$networkDetails	= $this->networkmodel->getNetworkDetails($networkId);
						$emailArray = explode('@', $this->input->post('join_email'));
						$networkEmail = explode('@', $this->input->post('network_email'));
						$networkEmailChk = (count($networkEmail) > 0) ? $networkEmail[1] : $this->input->post('network_email');
						if ($emailArray[1] == $networkEmailChk) echo json_encode(array('error' => 'no'));
						else  echo json_encode(array('error' => 'yes', 'msg' => $this->lang->line('network_invalid_for_network')));
				}
				else  echo json_encode(array('error' => 'yes', 'msg' => $this->lang->line('network_email_invalid')));
		}
		function join()
		{
				$networkId = $this->uri->segment(3);
				if ($this->networkmodel->isExist($networkId))
				{
						if ($_POST && is_array($_POST) && count($_POST) > 0)
						{
								if (!$this->networkmodel->isUserExist($networkId, $this->session->userdata('user_id')))
								{
										$networkDetails = $this->networkmodel->getNetworkDetails($networkId);
										if ($networkDetails['network_type'] == 'region')
										{
												$joinConfig = array('network_id' => $networkId, 'user_status' => 'approved');
												$this->networkmodel->joinNetwork($joinConfig);
												$this->session->set_userdata('user_network_id', $networkId);
												$this->session->set_userdata('user_network', $networkDetails['network_name']);
												//Set the flash data
												$this->session->set_flashdata('flash_msg', $this->lang->line('network_join_success'));
												redirect('network/join/' . $networkId);
										}
										else
										{
												$this->load->helper('validation');
												if (isValidEmail($this->input->post('join_email')))
												{
														$emailArray = explode('@', $this->input->post('join_email'));
														$networkEmail = explode('@', $networkDetails['network_email']);
														$networkEmailChk = (count($networkEmail) > 0) ? $networkEmail[1] : $networkDetails['network_email'];
														if ($emailArray[1] == $networkEmailChk)
														{
																$this->load->library('encrypt');
																$confirmKey = $this->encrypt->sha1($this->input->post('join_email') . '/' . $networkId);
																$invitationId = $this->networkmodel->isInvitationSent($networkId);
																if ($invitationId == false)
																{
																		$joinConfig = array('network_id' => $networkId, 'user_email' => $this->input->post('join_email'), 'user_status' => 'pending', 'confirm_key' => $confirmKey);
																		$this->networkmodel->joinNetwork($joinConfig);
																}
																else
																{
																		$this->networkmodel->updateInvitation($invitationId, $this->input->post('join_email'));
																}
																//Send the confirm join email
																$this->_sendJoinConfirmEmail($this->input->post('join_email'), $networkId, $networkDetails['network_name'], $confirmKey);
																//Set the flash data
																$this->session->set_flashdata('flash_msg', $this->lang->line('network_request_confirm') . '(' . $this->input->post('join_email') . ').');
																redirect('network/join/' . $networkId);
														}
														else  $outputData['joinError'] = $this->lang->line('network_invalid_for_network');
												}
												else  $outputData['joinError'] = $this->lang->line('network_email_invalid');
										}
								}
						}
				}
				$outputData['userNetworks'] = $this->networkmodel->getUserNetwork();
				$outputData['userNetworksCount'] = count($outputData['userNetworks']);
				$this->smartyextended->view('networkjoin', $outputData);
		}
		function _sendJoinConfirmEmail($email, $networkId, $networkName, $confirmKey)
		{
				$this->load->model('emailTemplateModel');
				$this->load->library('email');
				$emailTemplate = $this->emailTemplateModel->readEmailTemplate('network_join_confirm');
				/* Send the Confirm E-Mail as the register is confirmed successfully */
				$settings = $this->settingsmodel->readSetting('admin_email, admin_name, site_name, site_title');
				$adminEmail = $settings['admin_email'];
				$adminName = $settings['admin_name'];
				$confirmText = base_url() . 'network/confirmjoin/' . $networkId . '/' . $confirmKey;
				$splVars = array("~~networkName~~" => $networkName, "~~attachUrl~~" => $confirmText, "~~adminName~~" => $adminName);
				$subject = strtr($emailTemplate['template_subject'], $splVars);
				$message = strtr($emailTemplate['template_content'], $splVars);
				$this->email->from($adminEmail, $adminName);
				$this->email->to($email);
				$this->email->subject($subject);
				$this->email->message(nl2br($message));
				$this->email->send();
		}
		function confirmjoin()
		{
				$networkId = $this->uri->segment(3);
				$confirmKey = $this->uri->segment(4);
				if ($this->networkmodel->isExist($networkId))
				{
						if (!$this->networkmodel->isUserExist($networkId, $this->session->userdata('user_id')))
						{
								$networkDetails = $this->networkmodel->getNetworkDetails($networkId);
								$this->networkmodel->activateUser($networkId, $confirmKey);
								$this->session->set_userdata('user_network_id', $networkId);
								$this->session->set_userdata('user_network', $networkDetails['network_name']);
						}
				}
				redirect('network/join');
		}
		function leave()
		{
				$networkId = $this->uri->segment(3);
				if ($this->networkmodel->isExist($networkId))
				{
						if ($this->networkmodel->isUserExist($networkId, $this->session->userdata('user_id'))) $this->networkmodel->leaveNetwork($networkId, $this->session->userdata('user_id'));
						if ($this->session->userdata('user_network_id') == $networkId)
						{
								$this->session->set_userdata('user_network_id', '');
								$this->session->set_userdata('user_network', '');
						}
						$networkName = $this->networkmodel->getName($networkId);
						$userFeedSettings = $this->usermodel->getUserFeedSetting();
						if (isset($userFeedSettings[11]) && $userFeedSettings[11] == 'yes')
						{
								//Load the minifeed model
								$this->load->model('minifeedmodel');
								$splVars = array('~~postedBy~~' => substr($this->usermodel->getName(), 0, 30), '~~networkName~~' => $networkName[$networkId]['network_name']);
								$this->minifeedmodel->postMiniFeed('LEAVE_NETWORK', $splVars, array(base_url() . 'network/view/' . $networkId));
						}
						//Set the flash data
						$this->session->set_flashdata('flash_msg', $this->lang->line('network_left_network') . $networkName[$networkId]['network_name'] . $this->lang->line('network_network'));
						redirect('network/join');
				}
				else  redirect('network/join');
		}
		function suggest()
		{
				$this->load->model('usermodel');
				$this->load->library('validation');
				//Set the form validation rules
				$this->_suggestFrmRules();
				//Do the validation
				if ($this->validation->run() == false)
				{
						//Oops! validation Error.
						$outputData['validationError'] = $this->validation->error_string;
						$outputData['country'] = $this->usermodel->getCountry(false);
						$countryId = ($this->input->post('network_country') != false) ? $this->input->post('network_country') : 1;
						$outputData['state'] = $this->usermodel->getStateList($outputData['country'][$countryId]['country_symbol']);
						$outputData['stateCnt'] = count($outputData['state']);
						$this->smartyextended->view('networksuggest', $outputData);
				}
				else
				{
						$networkType = $this->input->post('network_type');
						$newNetwork['network_type'] = $this->input->post('network_type');
						$newNetwork['network_status'] = 'suggested';
						$newNetwork['network_name'] = $this->input->post($networkType . '_network_name');
						$newNetwork['network_email'] = ($networkType == 'region') ? '' : $this->input->post($networkType . '_network_email');
						$newNetwork['network_country'] = $this->input->post('network_country');
						$newNetwork['network_city'] = $this->input->post('network_city');
						$newNetwork['network_state'] = ($this->input->post('network_state') == false) ? '' : $this->input->post('network_state');
						$newNetwork['network_website'] = ($networkType == 'work') ? $this->input->post('work_network_website') : '';
						$newNetwork['network_members'] = 0;
						$newNetwork['contact_email'] = $this->input->post('contact_email');
						if ($this->networkmodel->createNetwork($newNetwork))
						{
								//Set the flash data
								$this->session->set_flashdata('flash_msg', $this->lang->line('network_suggest'));
								redirect('network/browse');
						}
						else
						{
								//Oops! validation Error.
								$outputData['validationError'] = $this->lang->line('network_error_processing');
								$outputData['country'] = $this->usermodel->getCountry(false);
								$this->smartyextended->view('networksuggest', $outputData);
						}
				}
		}
		function _suggestFrmRules()
		{
				$networkType = ($this->input->post('network_type') == false) ? 'region' : $this->input->post('network_type');
				$rules[$networkType . '_network_name'] = 'trim|required|alpha_dash_space|min_length[4]';
				if ($networkType != 'region') $rules[$networkType . '_network_email'] = 'trim|required|valid_email';
				if ($networkType == 'work') $rules[$networkType . '_network_website'] = 'trim|required|prep_url|valid_url';
				$rules['network_city'] = 'trim|required|alpha_dash_space|min_length[3]';
				$rules['contact_email'] = 'trim|required|valid_email';
				$this->validation->set_rules($rules);
				$fields[$networkType . '_network_name'] = ($networkType == 'work') ? $this->lang->line('network_company_name') : $networkType . ' ' . $this->lang->line('network_name');
				$fields[$networkType . '_network_email'] = ($networkType != 'region' && $networkType == 'work') ? $this->lang->line('network_company_email') : $networkType . ' ' . $this->lang->line('network_email');
				if ($networkType == 'work') $fields[$networkType . '_network_website'] = $this->lang->line('network_company_website');
				$fields['network_city'] = $this->lang->line('network_city');
				$fields['contact_email'] = $this->lang->line('network_contact_email');
				$this->validation->set_fields($fields);
		}
		function getState()
		{
				$countrySymbol = $this->input->post('countrysymbol');
				echo json_encode($this->usermodel->getStateList($countrySymbol));
		}
		function confirmsuggest()
		{
				$networkId = $this->uri->segment(3);
				$confirmKey = $this->uri->segment(4);
				if ($this->networkmodel->isValidConfirmKey($networkId, $confirmKey))
				{
						$updateNetwork = array("network_status" => 'enabled');
						if ($this->networkmodel->updateNetworkByAdmin($networkId, $updateNetwork))
						{
								//Set the flash data
								$this->session->set_flashdata('flash_msg', $this->lang->line('network_suggest_confirm_success'));
								redirect('network/view/' . $networkId);
						}
						else
						{
								//Set the flash data
								$this->session->set_flashdata('flash_msg', $this->lang->line('network_confirm_link_invalid'));
								redirect('network');
						}
				}
				else
				{
						//Set the flash data
						$this->session->set_flashdata('flash_msg', $this->lang->line('network_confirm_link_invalid'));
						redirect('network');
				}
		}
}
?>
