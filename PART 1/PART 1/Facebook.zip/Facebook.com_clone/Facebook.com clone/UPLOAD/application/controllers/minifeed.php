<?php

/**
 * minifeed Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 2/5/2008
 */
class minifeed extends Controller
{
		//Constructor
		function minifeed()
		{
				parent::Controller();
				//check login
				loginRequired();
				//Load the language file
				$this->lang->load('minifeed', $this->config->item('language_code'));
				//Load the minifeed model
				$this->load->model('minifeedmodel');
		}
		//Default function
		function index()
		{
				$this->view();
		}
		function view()
		{
				$user_id = ($this->uri->segment(3) == false) ? $this->session->userdate('user_id') : $this->uri->segment(3);
				if ($this->uri->segment(4) == 'delete')
				{
						$this->minifeedmodel->deleteById($this->input->post('minifeed_id'));
						//Set the flash data
						$this->session->set_flashdata('flash_msg', $this->lang->line('minifeed_delete_success'));
						redirect('minifeed/view/' . $user_id . '/' . $this->uri->segment(5));
				}
				//Load the pagination model
				$this->load->model('paginationmodel');
				//Load the pagination language file
				$this->lang->load('pagination', $this->config->item('language_code'));
				$perPage = $this->paginationmodel->getPerPage('minifeed');
				$start = (trim($this->uri->segment(4)) != '' && is_numeric($this->uri->segment(4)) && $this->uri->segment(4) > 0) ? $this->uri->segment(4) : 1;
				$start = ($start - 1) * $perPage;
				//minifeed
				$outputData['currUserId'] = $user_id;
				$outputData['miniFeed'] = $this->minifeedmodel->getMiniFeed($user_id, 'datestamp desc', $start, $perPage);
				$outputData['miniFeedCount'] = count($outputData['miniFeed']);
				$outputData['miniFeedTotal'] = $this->minifeedmodel->getMiniFeedCount();
				$outputData['currentPage'] = (trim($this->uri->segment(4)) != '' && is_numeric($this->uri->segment(4))) ? $this->uri->segment(4) : 1;
				$outputData['totalPages'] = ($outputData['miniFeedTotal'] > $perPage) ? ceil(($outputData['miniFeedTotal'] / $perPage)) : 0;
				$outputData['pageUrl'] = base_url() . 'minifeed/view/' . $user_id . '/';
				$outputData['noResults'] = ($outputData['miniFeedTotal'] == 0) ? 1 : 0;
				$this->smartyextended->view('minifeed', $outputData);
		}
		function delete()
		{
				$this->minifeedmodel->deleteById($this->input->post('minifeed_id'));
				echo json_encode(array('msg' => 'DONE'));
		}
}

?>