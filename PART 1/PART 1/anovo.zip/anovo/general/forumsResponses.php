<?php

class forumsResponsesFormHandler extends ForumHandler
{
		public $forum_details_arr;
		public $forum_topic_details_arr;
		public function buildConditionQuery($condition = '')
		{
				$this->sql_condition = $condition;
		}
		public function checkSortQuery($field, $sort = 'asc')
		{
				if (!($this->sql_sort))
				{
						$this->sql_sort = $field . ' ' . $sort;
				}
		}
		public function deleteResponse($forum_id, $topic_id, $response_id)
		{
				$sql = 'DELETE FROM ' . $this->CFG['db']['tbl']['forum_response'] . ' ' . 'WHERE topic_id = ' . $this->dbObj->Param($topic_id) . ' ' . 'AND response_id = ' . $this->dbObj->Param($response_id) . ' ' . 'AND response_user_id = ' . $this->dbObj->Param($this->CFG['user']['user_id']);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($topic_id, $response_id, $this->CFG['user']['user_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$this->updateTotalResponse($topic_id);
				$this->updateTotalResponseForums($forum_id);
				return true;
		}
		public function updateTotalResponse($topic_id)
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['forum_topics'] . ' SET ' . 'total_response = total_response - 1 ' . 'WHERE topic_id = ' . $this->dbObj->Param($topic_id) . ' ' . 'AND total_response > 0 ';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($topic_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return true;
		}
		public function updateTotalResponseForums($forum_id)
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['forums'] . ' SET ' . 'total_response = total_response - 1 ' . 'WHERE forum_id = ' . $this->dbObj->Param($forum_id) . ' ' . 'AND total_response > 0 ';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($forum_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return true;
		}
		public function showForumResponse()
		{
				if ($this->forum_topic_details_arr)
				{
?>
				<tr>
				  <td colspan="2">
				    <p><?php echo $this->LANG['forumsresponses_forum_topic_by'] . ' '; ?>
					    <a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'myanswers.php?uid=' . $this->forum_topic_details_arr['user_id'], $this->CFG['site']['relative_url'] . 'my/answers/' . $this->forum_topic_details_arr['user_id'] . '/', false); ?>"><?php echo $this->forum_topic_details_arr['name']; ?></a>
					 <?php echo $this->LANG['forumsresponses_started_on'] . ' ' . $this->forum_topic_details_arr['date_added']; ?> </p></td>
				</tr>
				<?php
				}
				if (!$this->isResultsFound())
				{
?>
					<tr>
					  <td colspan="2">
					  	<div id="selMsgAlert">
							<p><?php echo $this->LANG['forumsresponses_no_responses']; ?></p>
							<p class="clsMsgAdditionalText"><a href="<?php echo getUrl($this->CFG['site']['url'] . 'members/forumsResponseCreate.php?forum_id=' . $this->fields_arr['forum_id'] . '&topic_id=' . $this->fields_arr['topic_id'], $this->CFG['site']['url'] . 'members/forumcreate/' . $this->fields_arr['forum_id'] . '/' . $this->fields_arr['topic_id'] . '/', false); ?>"><?php echo $this->LANG['forumsresponses_click_post_response']; ?></a></p>
						</div>
					  </td>
					</tr>
					<?php
						return;
				}
?>
<div class="clsPagingCollapse">
<?php if ($this->CFG['comments']['expand_collapse'])
				{ ?>
<span class="expand-all" onclick="toggleExpandResponses();"></span>
<script type="text/javascript" language="javascript">
	var commentsArray = new Array();
</script>
<?php } ?>
</div>
<?php
				$i = 0;
				while ($row = $this->fetchResultRecord())
				{
						$i++;
						$userDetails = $row;
						$userDetails['user_id'] = $row['response_user_id'];
						$responseId = $row['response_id'];
?>
<?php if ($this->CFG['comments']['expand_collapse'])
						{ ?>
<script type="text/javascript" language="javascript">
	commentsArray['<?php echo $i; ?>'] = '<?php echo $responseId; ?>';
</script>
<?php } ?>
					<tr>
					  	<td><div class="clsForumComment"> <!--rounded corners-->
 	<div class="lbprofile">
      <div class="rbprofile">
        <div class="bbprofile">
          <div class="blcprofile">
            <div class="brcprofile">
              <div class="tbprofile">
                <div class="tlcprofile">
                  <div class="trcprofile">
<?php if ($this->CFG['comments']['expand_collapse'])
						{ ?>
<span id="icon<?php echo $responseId; ?>" class="collapse expand" onclick="toggleResponse(this, '<?php echo $responseId; ?>');"></span>
<?php } ?>
					    	<div id="responsemore<?php echo $responseId; ?>" class="clsUserThumbDetails">
					    	<?php if (chkUserImageAllowed())
						{ ?>
							<div class="clsUserThumb"><p id="selImageBorder"><?php displayForumUserSmallImage($userDetails); ?></p></div>
							<?php } ?>
							<div class="clsUserDetails clsForumLargeImage">
						<p id="date"><?php echo $this->LANG['forumsresponses_posted_on'] . ' <span class="clsDate">' . $row['date_added'] . '</span> ' . $this->LANG['forumsresponses_by'] . ' '; ?><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'myanswers.php?uid=' . $userDetails['user_id'], $this->CFG['site']['relative_url'] . 'my/answers/' . $userDetails['user_id'] . '/', false); ?>"><?php echo stripString(ucwords($row['name']), $this->CFG['username']['short_length']); ?></a></p>
						    <p>
						    <?php
						$row['forum_response'] = str_replace('&lt;a href=&quot;', '&lt;a target=&quot;_blank&quot; href=&quot;', $row['forum_response']);
						echo nl2br(wordWrapManual($row['forum_response'], $this->CFG['admin']['forum']['line_length']));
?>
							<br /></p>
						<?php
						if ($row['response_user_id'] == $this->CFG['user']['user_id'])
						{
								$anchor = 'dAlt_' . $row['response_id'];
?>
	 						<p>[<a href="<?php echo getUrl('forumsResponseCreate.php?forum_id=' . $this->fields_arr['forum_id'] . '&topic_id=' . $this->fields_arr['topic_id'] . '&response_id=' . $row['response_id'], 'forumcreate/' . $this->fields_arr['forum_id'] . '/' . $this->fields_arr['topic_id'] . '/' . $row['response_id'] . '/'); ?>"><?php echo $this->LANG['forumsresponses_edit']; ?></a>]
	 						&nbsp;&nbsp;
	 						[<a href="#" id="<?php echo $anchor; ?>" onClick="return Confirmation('<?php echo $anchor; ?>', 'selMsgConfirm', 'msgConfirmform', Array('act','response_id', 'msgConfirmText'), Array('delete','<?php echo $row['response_id']; ?>', '<?php echo $this->LANG['forumsresponses_confirm_message']; ?>'), Array('value','value', 'innerHTML'), -100, -500);"><?php echo $this->LANG['forumsresponses_delete']; ?></a>]
	 						</p>
	 					<?php
						}
?></div> </div>
						<div id="responseless<?php echo $responseId; ?>" class="clsUserThumbDetails" style="display:none;">
							<div class="clsUserDetails">
								<p id="date"><?php echo $this->LANG['forumsresponses_posted_on'] . ' <span class="clsDate">' . $row['date_added'] . '</span> ' . $this->LANG['forumsresponses_by'] . ' '; ?><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'myanswers.php?uid=' . $userDetails['user_id'], $this->CFG['site']['relative_url'] . 'my/answers/' . $userDetails['user_id'] . '/', false); ?>"><?php echo stripString(ucwords($row['name']), $this->CFG['username']['short_length']); ?></a></p>
							</div>
						</div>
					 </div>
				   </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
<!--end of rounded corners-->
						</td>
					</tr>
					<?php
				}
		}
		public function updateTopicViews($topic_id)
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['forum_topics'] . ' SET total_views = total_views + 1' . ' WHERE topic_id = ' . $this->dbObj->Param($topic_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($topic_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return true;
		}
		public function updateQuestionAbuseCount()
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['forum_topics'] . ' SET abuse_count=abuse_count+1' . ' WHERE topic_id=' . $this->dbObj->Param('topic_id');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['topic_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function updateAbuseForum()
		{
				$sql = 'SELECT abuse_id FROM ' . $this->CFG['db']['tbl']['abuse_forum'] . ' WHERE topic_id=' . $this->dbObj->Param('topic_id') . ' AND reported_by=' . $this->dbObj->Param('reported_by');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['topic_id'], $this->CFG['user']['user_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if (!$rs->PO_RecordCount())
				{
						$sql = 'INSERT INTO ' . $this->CFG['db']['tbl']['abuse_forum'] . ' SET topic_id=' . $this->dbObj->Param('topic_id') . ', reported_by=' . $this->dbObj->Param('reported_by') . ', reason=' . $this->dbObj->Param('reason') . ', date_abused=NOW()';
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['topic_id'], $this->CFG['user']['user_id'], $this->fields_arr['reason']));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
						if ($this->dbObj->Affected_Rows())
						{
								$this->updateQuestionAbuseCount();
						}
				}
		}
}
$forumsResponses = new forumsResponsesFormHandler();
if (!chkAllowedModule(array('forums'))) Redirect2URL($CFG['redirect']['dsabled_module_url']);
$forumsResponses->setPageBlockNames(array('msg_form_error', 'msg_form_success', 'form_title', 'form_forum_title', 'form_show_responses', 'page_nav', 'form_confirm'));
$forumsResponses->setCSSAlternativeRowClasses($CFG['data_tbl']['css_alternative_row_classes']);
$forumsResponses->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$forumsResponses->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$forumsResponses->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$forumsResponses->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$forumsResponses->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$forumsResponses->setDBObject($db);
$forumsResponses->setCfgLangGlobal($CFG, $LANG);
$forumsResponses->setAllPageBlocksHide();
$forumsResponses->setFormField('id', '');
$forumsResponses->setFormField('forum_id', '');
$forumsResponses->setFormField('topic_id', '');
$forumsResponses->setFormField('msg', '');
$forumsResponses->setFormField('act', '');
$forumsResponses->setFormField('response_id', '');
$forumsResponses->setFormField('reason', '');
$forumsResponses->setFormField('numpg', 0);
$forumsResponses->setFormField('start', 0);
$condition = '';
$forumsResponses->numpg = $CFG['data_tbl']['numpg'];
$forumsResponses->setFormField('start', 0);
$forumsResponses->setFormField('numpg', $CFG['data_tbl']['numpg']);
$forumsResponses->setMinRecordSelectLimit($CFG['data_tbl']['min_record_select_limit']);
$forumsResponses->setMaxRecordSelectLimit($CFG['data_tbl']['max_record_select_limit']);
$forumsResponses->setNumPerPageListArr($CFG['data_tbl']['numperpage_list_arr']);
$forumsResponses->setTableNames(array());
$forumsResponses->setReturnColumns(array());
$forumsResponses->sanitizeFormInputs($_REQUEST);
if ($forumsResponses->isFormGETed($_GET, 'forum_id') && $forumsResponses->isFormGETed($_GET, 'topic_id'))
{
		$forumsResponses->chkIsNotEmpty('forum_id', $LANG['forumsresponses_err_tip_compulsory']) and $forumsResponses->chkIsNumeric('forum_id', $LANG['forumsresponses_err_tip_compulsory']) and $forumsResponses->isValidForumId($forumsResponses->getFormField('forum_id'), $LANG['forumsresponses_err_tip_invalid_forum_id']);
		$forumsResponses->chkIsNotEmpty('topic_id', $LANG['forumsresponses_err_tip_compulsory']) and $forumsResponses->chkIsNumeric('topic_id', $LANG['forumsresponses_err_tip_compulsory']) and $forumsResponses->isValidForumTopicId($forumsResponses->getFormField('forum_id'), $forumsResponses->getFormField('topic_id'), $LANG['forumsresponses_err_tip_invalid_forum_topic_id']);
		$forumsResponses->getFormField('response_id') and $forumsResponses->chkIsNotEmpty('response_id', $LANG['forumsresponses_err_tip_compulsory']) and $forumsResponses->chkIsNumeric('response_id', $LANG['forumsresponses_err_tip_compulsory']) and $forumsResponses->isValidForumResponseId($forumsResponses->getFormField('topic_id'), $forumsResponses->getFormField('response_id'), $LANG['forumsresponses_err_tip_invalid_forum_response_id']);
		if ($forumsResponses->getFormField('act') == 'delete')
		{
				$forumsResponses->setPageBlockShow('msg_form_success');
				$LANG['forumsresponses_success_message'] = 'Response deleted successfully';
		} elseif ($forumsResponses->isFormGETed($_GET, 'msg'))
		{
				$forumsResponses->setPageBlockShow('msg_form_success');
				if ($forumsResponses->getFormField('msg') == 'add') $LANG['forumsresponses_success_message'] = 'Response added successfully';
				else  $LANG['forumsresponses_success_message'] = 'Response updated successfully';
		}
		if (!$forumsResponses->isValidFormInputs())
		{
				Redirect2URL(getUrl('forums.php', 'forum/'));
		}
		if ($forumsResponses->isFormPOSTed($_POST, 'cancel'))
		{
				$forumsResponses->setFormField('response_id', '');
		}
		if ($forumsResponses->isFormPOSTed($_POST, 'confirm'))
		{
				$forumsResponses->deleteResponse($forumsResponses->getFormField('forum_id'), $forumsResponses->getFormField('topic_id'), $forumsResponses->getFormField('response_id'));
				$forumsResponses->setFormField('response_id', '');
		}
}
else
{
		Redirect2URL(getUrl('forums.php', 'forum/'));
}
if ($forumsResponses->isValidFormInputs())
{
		$forumsResponses->updateTopicViews($forumsResponses->getFormField('topic_id'));
		$forumsResponses->setTableNames(array($CFG['db']['tbl']['forum_response'] . ' as gr', $CFG['db']['tbl']['users'] . ' as u'));
		$forumsResponses->setReturnColumns(array('gr.response_id', 'gr.topic_id', 'gr.forum_response', 'gr.response_user_id', 'DATE_FORMAT(gr.date_added, \'' . $CFG['format']['date'] . '\') as date_added', 'u.' . $forumsResponses->getUserTableField('name') . ' AS name', 'u.' . $forumsResponses->getUserTableField('image_path') . ' AS image_path', 'u.' . $forumsResponses->getUserTableField('gender') . ' AS gender', 'u.' . $forumsResponses->getUserTableField('user_id') . ' AS img_user_id', 'u.' . $forumsResponses->getUserTableField('t_height') . ' AS t_height', 'u.' . $forumsResponses->getUserTableField('t_width') . ' AS t_width', 'u.' . $forumsResponses->getUserTableField('s_height') . ' AS s_height', 'u.' . $forumsResponses->getUserTableField('s_width') . ' AS s_width', 'u.' . $forumsResponses->getUserTableField('photo_server_url') . ' AS photo_server_url', 'u.' . $forumsResponses->getUserTableField('photo_ext') . ' AS photo_ext'));
		$condition = 'gr.response_user_id = u.' . $forumsResponses->getUserTableField('user_id') . ' AND gr.topic_id = \'' . $forumsResponses->getFormField('topic_id') . '\' AND gr.response_status =\'Yes\'';
		if ($CFG['admin']['ignore_user'])
		{
				$condition .= ' AND NOT EXISTS (SELECT 1 FROM ' . $CFG['db']['tbl']['user_ignored'] . ' AS ui WHERE ui.user_id=' . $CFG['user']['user_id'] . ' AND ui.ignored_id=gr.response_user_id)';
		}
		$forumsResponses->buildSelectQuery();
		$forumsResponses->buildConditionQuery($condition);
		$forumsResponses->buildSortQuery();
		$forumsResponses->checkSortQuery('gr.date_added', 'DESC');
		$forumsResponses->buildQuery();
		$forumsResponses->executeQuery();
		$forumsResponses->setPageBlockShow('form_forum_title');
		$forumsResponses->setPageBlockShow('form_show_responses');
		if ($forumsResponses->isResultsFound())
		{
				$forumsResponses->setPageBlockShow('page_nav');
				if ($CFG['url']['rewrite']) $paging_arr = array();
				else  $paging_arr = array('forum_id', 'topic_id');
		}
		if ($forumsResponses->getFormField('response_id'))
		{
				$forumsResponses->setPageBlockShow('form_confirm');
		}
		if ($forumsResponses->isFormPOSTed($_POST, 'confirm_action'))
		{
				$forumsResponses->chkIsNotEmpty('reason', $LANG['answers_err_tip_compulsory']);
				if ($forumsResponses->isValidFormInputs())
				{
						$forumsResponses->updateAbuseForum();
						$forumsResponses->setPageBlockShow('msg_form_success');
						$LANG['forumsresponses_success_message'] = $LANG['forum_abused_successfully'];
				}
				else
				{
						$forumsResponses->setCommonErrorMsg($LANG['err_msg_reason_empty']);
						$forumsResponses->setPageBlockShow('msg_form_error');
				}
		}
}
else
{
		$forumsResponses->setPageBlockShow('msg_form_error');
		Redirect2URL(getUrl('forums.php', 'forum/'));
}



?>
<script language="javascript" type="text/javascript">
	var replace_url = '<?php echo getUrl($CFG['site']['url'] . 'login.php', $CFG['site']['url'] . 'login/', false); ?>';
	var block_arr= new Array('selMsgConfirm', 'selMsgConfirmMulti', 'selEditPhotoComments','selMsgAbuseConfirm');
	var total_comments = 10;
	var minimum_counts = 10000;
</script>
<div id="selForumResponseListAll" class="clsForums">
  <h2 id="selForumTitle"><span>
		<a href="<?php echo getUrl('forums.php', 'forum/'); ?>"><?php echo $LANG['forumlistall_title_index']; ?></a>
		&nbsp;-&nbsp;
		<a href="<?php echo getUrl('forumsTopics.php?forum_id=' . $forumsResponses->getFormField('forum_id'), 'forum/' . $forumsResponses->getFormField('forum_id') . '/'); ?>">
			<?php echo $forumsResponses->forum_details_arr['forum_title']; ?></a>
		&nbsp;-&nbsp;
		<?php echo wordWrapManual($forumsResponses->forum_topic_details_arr['forum_topic'], 35); ?>
	</span></h2>
	<div id="selMsgConfirm" class="clsPopupConfirmation" style="display:none;position:absolute;">
		<p id="msgConfirmText"></p>
      	<form name="msgConfirmform" id="msgConfirmform" method="post" action="<?php echo $_SERVER['REQUEST_URI']; ?>">
        	<table summary="<?php echo $LANG['forumsresponses_confirm_tbl_summary']; ?>">
	          	<tr>
	            	<td>
					  	<input type="submit" class="clsSubmitButton" name="confirm" id="confirm" value="<?php echo $LANG['yes']; ?>" tabindex="<?php echo $forumsResponses->getTabIndex(); ?>" /> &nbsp;
		              	<input type="button" class="clsCancelButton" name="no" id="no" value="<?php echo $LANG['no']; ?>" tabindex="<?php echo $forumsResponses->getTabIndex(); ?>" onClick="return hideAllBlocks()" />
						<input type="hidden" name="act" id="act" />
		              	<input type="hidden" name="response_id" id="response_id" />
						<?php $forumsResponses->populateHidden(array('start', 'forum_id', 'topic_id')); ?>
					</td>
	          	</tr>
        	</table>
      	</form>
    </div>
<?php
if ($forumsResponses->isShowPageBlock('msg_form_error'))
{
?>
  <div id="selMsgError">
    <p><?php echo $LANG['msg_error_sorry']; ?> <?php echo $forumsResponses->getCommonErrorMsg(); ?></p>
  </div>
  <?php
}
if ($forumsResponses->isShowPageBlock('msg_form_success'))
{
?>
  <div id="selMsgSuccess">
    <p><?php echo $LANG['forumsresponses_success_message']; ?></p>
  </div>
  <?php
}
if ($forumsResponses->isShowPageBlock('form_forum_title'))
{ ?>
	<?php $forumsResponses->showForumDetails('responselist'); ?><div id="selForumQuickLinks"><ul class="clsForumLinks"><?php
		if ($CFG['admin']['subscribe']['forums'])
		{
?>
			<li id="selShowFavoriteText_Forum_<?php echo $forumsResponses->getFormField('topic_id'); ?>"><span class="clsForumLinkMiddle" >
				<?php if ($forumsResponses->isMember())
				{ ?>
					<?php if ($forumsResponses->isFavoriteContent($forumsResponses->getFormField('topic_id'), 'Forum'))
						{ ?>
						<a href="<?php echo $_SERVER['REQUEST_URI']; ?>" onClick="toggleFavorites('<?php echo $CFG['site']['relative_url']; ?>favoriteAnswers.php', 'cid=<?php echo $forumsResponses->getFormField('topic_id'); ?>&ctype=Forum', 'selShowFavoriteText_Forum_<?php echo $forumsResponses->getFormField('topic_id'); ?>'); return false;"><?php echo $LANG['forum_remove_favorites']; ?></a>
					<?php }
						else
						{ ?>
						<a href="<?php echo $_SERVER['REQUEST_URI']; ?>" onClick="toggleFavorites('<?php echo $CFG['site']['relative_url']; ?>favoriteAnswers.php', 'cid=<?php echo $forumsResponses->getFormField('topic_id'); ?>&ctype=Forum', 'selShowFavoriteText_Forum_<?php echo $forumsResponses->getFormField('topic_id'); ?>'); return false;"><?php echo $LANG['forum_add_to_favorites']; ?></a>
					<?php } ?>
				<?php }
				else
				{ ?>
				<a href="<?php echo getUrl($CFG['site']['url'] . 'members/forumsResponses.php?forum_id=' . $forumsResponses->getFormField('forum_id') . '&topic_id=' . $forumsResponses->getFormField('topic_id'), $CFG['site']['url'] . 'members/forum/' . $forumsResponses->getFormField('forum_id') . '/' . $forumsResponses->getFormField('topic_id') . '/', false); ?>"><?php echo $LANG['forum_add_to_favorites']; ?></a>
				<?php } ?>
			</span></li>
<?php
		}
		if ($CFG['admin']['email_to_friend']['allowed'])
		{
?>

<?php if ($CFG['user']['user_id'])
				{ ?>
			<li>
				<span><a id="emailToFriends" href="<?php echo getUrl($CFG['site']['relative_url'] . 'emailForums.php?tid=' . $forumsResponses->getFormField('topic_id'), $CFG['site']['relative_url'] . 'email-forums/' . $forumsResponses->getFormField('topic_id') . '/', false); ?>" class="lWOn" onClick="return false;"><?php echo $LANG['email_to_friends']; ?></a></span>
			</li>
		<?php }
				else
				{ ?>
			<li><span><a href="<?php echo getUrl($CFG['site']['url'] . 'members/forumsResponses.php?forum_id=' . $forumsResponses->getFormField('forum_id') . '&topic_id=' . $forumsResponses->getFormField('topic_id'), $CFG['site']['url'] . 'members/forum/' . $forumsResponses->getFormField('forum_id') . '/' . $forumsResponses->getFormField('topic_id') . '/', false); ?>"><?php echo $LANG['email_to_friends']; ?></a></span></li>
		<?php } ?>

<?php
		}
		if ($forumsResponses->isMember() and ($forumsResponses->forum_topic_details_arr['user_id'] != $CFG['user']['user_id']))
		{
				$anchor = 'abuseContent';
				if ($forumsResponses->chkIsForumAbusedAlready($forumsResponses->getFormField('topic_id')))
				{
?>
			<li><span><a href="<?php echo $_SERVER['REQUEST_URI']; ?>" onClick="return false;"><?php echo $LANG['forums_abused_already']; ?></a></span></li>


<?php
				}
				else
				{
?>

				<li><span><a href="<?php echo $_SERVER['REQUEST_URI']; ?>" onClick="abuseContent('abuseforum', '<?php echo $forumsResponses->getFormField('topic_id'); ?>', '<?php echo $anchor; ?>', '<?php echo $LANG['confirm_abuse_forum_message']; ?>'); return false;"><?php echo $LANG['forums_report_abuse']; ?></a></span></li>

			<?php
				}
		}
?>
            </ul> <?php
		if ($forumsResponses->isMember() and ($forumsResponses->forum_topic_details_arr['user_id'] != $CFG['user']['user_id']))
		{
?><a href="#" id="<?php echo $anchor; ?>"></a>
			<div id="selMsgAbuseConfirm" class="selMsgAbuseConfirm" style="display:none;position:absolute;">
				<form name="formAbuseConfirm" id="formAbuseConfirm" method="post" action="<?php echo URL($_SERVER['REQUEST_URI']); ?>">
				<p id="confirmAbuseMessage"></p>
				<table>
					<tr>
						<td>
							<p><?php echo $LANG['answers_reason']; ?></p>
							<p><textarea name="reason" id="reason" tabindex="<?php echo $forumsResponses->getTabIndex(); ?>"><?php echo $forumsResponses->getFormField('reason'); ?></textarea></p>
							<p id="validReason"></p>
						</td>
					</tr>
					<tr>
				      	<td>
						  	<input type="submit" class="clsSubmitButton" name="confirm_action" id="confirm_action" value="<?php echo $LANG['member_yes']; ?>" tabindex="<?php echo $forumsResponses->getTabIndex(); ?>" onClick="return chkIsAbuseReasonExists();" /> &nbsp;
				          	<input type="button" class="clsCancelButton" name="cancel" id="cancel" value="<?php echo $LANG['member_no']; ?>" tabindex="<?php echo $forumsResponses->getTabIndex(); ?>" onClick="removeReasonErrors(); return hideAllBlocks();" />
						</td>
			  		</tr>
				</table>
				<input type="hidden" name="content_id" id="content_id" value="" />
				</form>
			</div>

<?php
		} ?></div><?php
}
if ($forumsResponses->isShowPageBlock('page_nav') && $CFG['admin']['navigation']['top'])
{
		$forumsResponses->populatePageLinks($forumsResponses->getFormField('start'), $paging_arr);
}
if ($forumsResponses->isShowPageBlock('form_show_responses'))
{
?>
  <form name="selFormResponse" id="selFormResponse" method="post" action="<?php echo $_SERVER['REQUEST_URI']; ?>">
    <table border="0" cellspacing="0" summary="<?php echo $LANG['forumsresponses_tbl_summary']; ?>" class="clsDataTable">
      <?php $forumsResponses->showForumResponse(); ?>
    </table>
  </form>
  <?php
}
if ($forumsResponses->isShowPageBlock('page_nav') && $CFG['admin']['navigation']['bottom'])
{
		$forumsResponses->populatePageLinks($forumsResponses->getFormField('start'), $paging_arr);
}
if ($forumsResponses->isShowPageBlock('form_forum_title'))
{
?>	<div id="selGroupForumPost">
			<div class="clsForumPost"><p class="clsAlignRight" id="post">
				<a href="<?php echo getUrl($CFG['site']['url'] . 'members/forumsResponseCreate.php?forum_id=' . $forumsResponses->getFormField('forum_id') . '&topic_id=' . $forumsResponses->getFormField('topic_id'), $CFG['site']['url'] . 'members/forumcreate/' . $forumsResponses->getFormField('forum_id') . '/' . $forumsResponses->getFormField('topic_id') . '/', false); ?>"><?php echo $LANG['forumslinks_post_response']; ?></a>
			</div>
		</div>
	<?php
}
?>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>
<script language="javascript" type="text/javascript">
function toggleResponse(spanObj, responseID){
	var moreObj = 'responsemore'+responseID;
	var lessObj = 'responseless'+responseID;

	Effect.toggle(moreObj, 'slide');
	Effect.toggle(lessObj, 'slide');
}
var expand = true;
var clicked = true;
var toggleExpandResponses = function(){
	if (clicked){
			clicked = false;
	for (var i=1; i<=commentsArray.length; i++){
		moreObj = 'responsemore'+commentsArray[i];
		lessObj = 'responseless'+commentsArray[i];
		if ($(moreObj)){
			if (expand){
				Effect.SlideUp(moreObj);
				Effect.SlideDown(lessObj);
			}else{
				Effect.SlideDown(moreObj);
				Effect.SlideUp(lessObj);
			}
		}
	}
	expand = (expand)?false:true;
	setTimeout('changeClickedStatus()', 2000);
	}
}
var changeClickedStatus = function(){
		toggleNavBar();
		clicked = true;
	}
</script>
