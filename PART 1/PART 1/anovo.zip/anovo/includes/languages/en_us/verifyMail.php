<?php

$LANG['err_tip_verified'] = 'Already verified';
$LANG['err_tip_invalid'] = 'Invalid Email';
$LANG['err_tip_invalid_details'] = 'Invalid Details';
$LANG['verifymail_err_tip_invalid_email'] = 'Invalid email';
$LANG['verified_successfully'] = 'New Password Created sucessfully';
$LANG['err_tip_compulsory'] = 'Compulsory';
$LANG['verifymail_title'] = 'Mail Verification';
$LANG['verifymail_password_title'] = 'Change your password';
$LANG['verifymail_tbl_summary'] = 'form for mail Verification';
$LANG['verifymail_submit'] = 'Submit';
$LANG['verifymail_password'] = 'Password ({min_count} to {max_count} characters)';
$LANG['verifymail_confirm_password'] = 'Confirm Password';
$LANG['verifymail_email'] = 'Email';
$LANG['verifyUsername_submit'] = 'Submit';
$LANG['err_tip_pasword_equal'] = 'Password and confirm Password must be the same';
$LANG['verifymail_err_tip_invalid_size'] = 'Invalid Size';
$LANG['verifymail_err_tip_same_password'] = 'Passwords must be the same';
$LANG['password_user_name'] = 'Username and password should not be the same';

?>