<?php
/**
 * postedModel Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 12/17/2007
 */
class Postedmodel extends Model
{
		//Constructor
		function Postedmodel()
		{
				parent::Model();
				$this->load->model('usermodel');
				$this->load->model('groupsmodel');
				$this->load->model('eventsmodel');
				$this->load->model('photomodel');
				$this->load->model('friendsmodel');
				$this->load->model('notesmodel');
				$this->load->model('marketplacemodel');
				$this->load->model('videomodel');
		}
		#***************************************************************************
		#Method			: 	storePost()
		#Type			: 	Sub
		#Description	:	store the posted content to posted_items table
		#***************************************************************************
		function storePost($postValues)
		{
				$sql = 'INSERT INTO posted_items
							(posted_by,post_url,post_description,post_date,post_type, post_for_id)
							VALUES
							(	' . $this->session->userdata('user_id') . ',
								' . $this->db->escape($postValues['post_content']) . ',
								' . $this->db->escape($postValues['post_comment']) . ',
								' . 'NOW()' . ',
								' . $this->db->escape($postValues['post_type']) . ',
								' . $postValues['post_for_id'] . '
							)';
				$this->db->query($sql);
				if ($this->db->affected_rows() == 1) return $this->db->insert_id();
				else  return false;
		} //end storePost()
		#***************************************************************************
		#Method			: 	storeComment()
		#Type			: 	Sub
		#Description	:	store the comment for given post to posted_item_comments
		#					table
		#***************************************************************************
		function storeComment($commentValues)
		{
				$sql = 'INSERT INTO posted_item_comments
							(post_id, description, comment_by,comment_on)
							VALUES
							(	' . $commentValues['post_id'] . ',
								' . $this->db->escape($commentValues['comment']) . ',
								' . $this->session->userdata('user_id') . ',
								' . $this->db->escape(date($this->config->item('date_format_general'))) . '
							)';
				$this->db->query($sql);
				if ($this->db->affected_rows() == 1) return $this->db->insert_id();
				else  return false;
		} //end storePost()
		#***************************************************************************
		#Method			: 	deleteComment()
		#Type			: 	Sub
		#Description	:	delete a comment from posted_item_comments table, and
		#					returns the status
		#***************************************************************************
		function deleteComment($commentId)
		{
				$sql = 'DELETE FROM posted_item_comments WHERE comment_id=' . $commentId;
				$this->db->query($sql);
				if ($this->db->affected_rows() > 0) return true;
				else  return false;
		} //end deleteComment()
		#***************************************************************************
		#Type			: 	Sub
		#Method			: 	getPosts()
		#Description	: 	list all posted items for the given criteria
		#Arguments		: 	$postFor	=> list post items for(url, group, event,
		#					network, notes...)
		#				:	$postForId	=> groupId/eventId/notesId...
		#***************************************************************************
		function getPosts($postFor = '', $postForId = '', $action = 'all', $orderBy = 'post_date', $start = '0', $limit = '10')
		{
				$commentEndLimit = 3;
				$data = array();
				$condition = '';
				if (trim($action) == 'all') $friendsId = $this->friendsmodel->getFriends($this->session->userdata('user_id'));
				if (trim($action) == 'all' and empty($friendsId)) return $data;
				else
				{
						if (trim($action) == 'all') $condition[] = " posted_by IN(" . implode(",", $friendsId) . ")";
						if (trim($postFor) != '') $condition[] = " post_type='" . $postFor . "'";
						if (trim($postForId) > 0) $condition[] = " post_for_id=" . $postForId;
						if (trim($action) > 0) $condition[] = " posted_by=" . $action;
						if (!empty($condition)) $condition = " AND " . implode(" AND ", $condition);
						$query = "SELECT post_id, posted_by, post_url, post_description, post_date, post_type, post_status,post_for_id
						FROM posted_items WHERE post_status='active'" . $condition . " ORDER BY $orderBy DESC LIMIT $start, $limit";
						$res = $this->db->query($query);
						$totRec = $res->num_rows();
						if ($totRec > 0)
						{
								foreach ($res->result_array() as $rs)
								{
										$shareContent = array();
										$postContent = array();
										$totComments = $this->getTotComments($rs['post_id']);
										$postContent = $this->showPostDetails($rs['post_for_id'], $rs['post_type']);
										if ($rs['post_type'] == 'link') $shareContent = $this->getShareContent($rs['post_id'], $rs['post_type']);
										else  $shareContent = $this->getShareContent($rs['post_for_id'], $rs['post_type']);
										$data[$rs['post_id']] = $rs;
										$data[$rs['post_id']]['avatar'] = $this->userModel->getAvatar($rs['posted_by']);
										$data[$rs['post_id']]['name'] = $this->userModel->getName($rs['posted_by']);
										$data[$rs['post_id']]['post_name'] = $postContent['name'];
										$data[$rs['post_id']]['post_avatar'] = $postContent['photo'];
										$data[$rs['post_id']]['post_for_url'] = $postContent['url'];
										$data[$rs['post_id']]['post_time'] = date($this->config->item('date_format_full'), strtotime($rs['post_date']));
										$data[$rs['post_id']]['post_comments'] = $this->listComments($rs['post_id'], $commentEndLimit);
										$data[$rs['post_id']]['tot_comments'] = $totComments;
										$data[$rs['post_id']]['share_img'] = $shareContent['share_img'];
										$data[$rs['post_id']]['share_type'] = $shareContent['share_type'];
										$data[$rs['post_id']]['share_heading_lable'] = $shareContent['share_heading_lable'];
										$data[$rs['post_id']]['share_heading_caption'] = $shareContent['share_heading_caption'];
										$data[$rs['post_id']]['share_content_owner'] = $shareContent['share_content_owner'];
										$data[$rs['post_id']]['share_content_url'] = $shareContent['share_content_url'];
										$data[$rs['post_id']]['share_owner_url'] = $shareContent['share_owner_url'];
										$data[$rs['post_id']]['share_link'] = $shareContent['share_link'];
								}
						}
						return $data;
				}
		} //getPosts
		function getPostCount($postFor = '', $postForId = '', $action = 'all')
		{
				$condition = '';
				if (trim($action) == 'all') $friendsId = $this->friendsmodel->getFriends($this->session->userdata('user_id'));
				if (trim($action) == 'all' and empty($friendsId)) return false;
				else
				{
						if (trim($action) == 'all') $condition[] = " posted_by IN(" . implode(",", $friendsId) . ")";
						if (trim($postFor) != '') $condition[] = " post_type='" . $postFor . "'";
						if (trim($postForId) > 0) $condition[] = " post_for_id=" . $postForId;
						if (trim($action) > 0) $condition[] = " posted_by=" . $action;
						if (!empty($condition)) $condition = " AND " . implode(" AND ", $condition);
						$query = "SELECT count(post_id) as cnt
							FROM posted_items WHERE post_status='active'" . $condition;
						$postRes = $this->db->query($query);
						if ($postRes->num_rows() > 0)
						{
								$postRow = $postRes->result_array();
								return $postRow[0]['cnt'];
						}
						else  return false;
				}
		}
		#***************************************************************************
		#Method			: listComments
		#Description	: load all comments for the given post, and returns the array
		#***************************************************************************
		function listComments($postId, $limit = '')
		{
				if ($limit != '' and $limit > 0) $limit = " LIMIT 0, $limit";
				$data = array();
				$query = "SELECT comment_id, description, comment_by, comment_on
					FROM posted_item_comments WHERE post_id='$postId' ORDER BY comment_on DESC $limit";
				$res = $this->db->query($query);
				$totRec = $res->num_rows();
				if ($totRec > 0)
				{
						foreach ($res->result_array() as $rs)
						{
								$data[$rs['comment_id']] = $rs;
								$data[$rs['comment_id']]['avatar'] = $this->userModel->getAvatar($rs['comment_by']);
								$data[$rs['comment_id']]['name'] = $this->userModel->getName($rs['comment_by']);
								$data[$rs['comment_id']]['comment_time'] = date($this->config->item('date_format_full'), strtotime($rs['comment_on']));
						}
				}
				return $data;
		} //end listComments()
		#***************************************************************************
		#Method			: 	($actionId,$action)
		#Type			: 	sub
		#Description	:	return the user/group/... name and photo
		#***************************************************************************
		function showPostDetails($actionId, $action = "user")
		{
				$contentArray = array("name" => '', "photo" => '', "url" => '');
				switch ($action)
				{
						case "user":
								$contentArray['name'] = $this->userModel->getName($actionId);
								$contentArray['photo'] = $this->userModel->getAvatar($actionId);
								$contentArray['url'] = base_url() . "profile/" . $actionId;
								break;
						case "event":
								$contentArray['name'] = $this->eventsmodel->getName($actionId);
								$contentArray['photo'] = $this->eventsmodel->geteventImage($actionId);
								$contentArray['url'] = base_url() . "events/view/" . $actionId;
								break;
						case "group":
								//echo 'jjh' . $actionId . 'pppp';
								$contentArray['name'] = $this->groupsmodel->getName($actionId);
								$contentArray['photo'] = $this->groupsmodel->getGroupImage($actionId);
								$contentArray['url'] = base_url() . "groups/view/" . $actionId;
								break;
								/*case "network":
								$name	= $this->getNetworkName($actionId);
								$photo	= '';
								$content= $name;
								break;
								case "note":
								$rs		= getRow("notes","title,user_id","notes_id='$actionId'");
								$name	= $rs['title'];
								$photo	= '';
								$linkUrl= base_url().'notes/userNotes/'.$rs->user_id.'/'.$actionId;
								$content= '<a href="'.$linkUrl.'">'.$name.$photo.'</a>';
								break;*/
				}
				return $contentArray;
		} //end showPostDetails()
		#***************************************************************************
		#Method			: isPost
		#Description	: checks whether the given postId valid or not
		#***************************************************************************
		function isPost($postId)
		{
				$query = "SELECT post_id FROM posted_items WHERE post_id=$postId";
				$res = $this->db->query($query);
				$totRec = $res->num_rows();
				if ($totRec > 0) return true;
				else  return false;
		} //end isPost()
		#***************************************************************************
		#Method			: getPostedBy
		#Description	: returns the userId, who posted the given post
		#***************************************************************************
		function getPostedBy($postId)
		{
				$query = "SELECT posted_by FROM posted_items WHERE post_id=$postId";
				$res = $this->db->query($query);
				$totRec = $res->num_rows();
				if ($totRec > 0)
				{
						$rs = $res->row();
						return $rs->posted_by;
				}
				else  return false;
		} //end getPostedBy()
		#***************************************************************************
		#Method			: getSinglePost
		#Description	: returns the sigle post details for the given postID
		#***************************************************************************
		function getSinglePost($postId)
		{
				$query = "SELECT post_id,posted_by,post_url,post_description,post_date,post_type,post_for_id FROM posted_items WHERE post_id=$postId";
				$res = $this->db->query($query);
				$totRec = $res->num_rows();
				if ($totRec > 0)
				{
						$rs = $res->row_array();
						$postContent = $this->showPostDetails($rs['post_for_id'], $rs['post_type']);
						$data = $rs;
						$data['avatar'] = $this->userModel->getAvatar($rs['posted_by']);
						$data['name'] = $this->userModel->getName($rs['posted_by']);
						$data['post_name'] = $postContent['name'];
						$data['post_avatar'] = $postContent['photo'];
						$data['post_for_url'] = $postContent['url'];
						$data['post_time'] = date($this->config->item('date_format_full'), strtotime($rs['post_date']));
						$data['post_comments'] = $this->listComments($postId); // to list all comments
						$data['tot_comments'] = $this->getTotComments($postId);
						return $data;
				}
				else  return false;
		} //end getPostedBy()
		#***************************************************************************
		#Method			: getTotComments
		#Description	: returns the total comments for the given post
		#***************************************************************************
		function getTotComments($postId)
		{
				$query = "SELECT comment_id, description, comment_by, comment_on
					FROM posted_item_comments WHERE post_id=$postId";
				$res = $this->db->query($query);
				$totRec = $res->num_rows();
				if ($totRec > 0) return $totRec;
				else  return false;
		} //END getTotComments()
		#***************************************************************************
		#Method			: 	getShareContent($shareId,$shareType)
		#Type			: 	sub
		#Description	:	prepares share content
		#***************************************************************************
		function getShareContent($shareId, $shareType = 'link')
		{
				$contentArray = array("share_img" => '', "share_type" => '', "share_heading_lable" => '', "share_heading_caption" => '', "share_content_owner" => '', "share_link" => '', "share_content_url" => '', "share_owner_url" => '');
				switch ($shareType)
				{
						case "link":
								$postDetails = $this->getSinglePost($shareId);
								$contentArray['share_type'] = $shareType;
								$contentArray['share_link'] = $postDetails['post_url'];
								break;
						case "photo":
								$photoDetails = $this->photomodel->getPhotoDetails($shareId);
								$albumDetails = $this->photomodel->getAlbumDetails($photoDetails['album_id']);
								$contentArray['share_img'] = 'content/photos/album_' . $photoDetails['album_id'] . '/photo_' . $photoDetails['album_id'] . '_' . $shareId . '_thumb' . $photoDetails['photo_ext'];
								$contentArray['share_type'] = $shareType;
								$contentArray['share_heading_lable'] = "From the album";
								$contentArray['share_heading_caption'] = $albumDetails['name'];
								$contentArray['share_content_owner'] = $this->usermodel->getName($albumDetails['user_id']);
								$contentArray['share_content_url'] = base_url() . "photos/slideshow/" . $photoDetails['album_id'] . "/" . $shareId;
								$contentArray['share_owner_url'] = base_url() . "profile/" . $photoDetails['user_id'];
								break;
						case "note":
								$noteDetails = $this->notesmodel->listNotes($shareId);
								$contentArray['share_type'] = $shareType;
								$contentArray['share_heading_lable'] = "From the Note";
								$contentArray['share_heading_caption'] = $noteDetails['title'];
								$contentArray['share_content_owner'] = $noteDetails['username'];
								$contentArray['share_content_url'] = base_url() . 'notes/userNotes/' . $noteDetails['userId'] . '/' . $noteDetails['notes_id'];
								$contentArray['share_owner_url'] = base_url() . "profile/" . $noteDetails['userId'];
								break;
						case "group":
								$groupDetails = $this->groupsmodel->getInfo($shareId);
								$contentArray['share_img'] = $this->groupsmodel->getGroupImage($shareId, true, true);
								$contentArray['share_type'] = $shareType;
								$contentArray['share_heading_lable'] = "From the Group";
								$contentArray['share_heading_caption'] = $groupDetails['group_name'];
								$contentArray['share_content_owner'] = $groupDetails['username'];
								$contentArray['share_content_url'] = base_url() . 'groups/view/' . $groupDetails['group_id'] . '/';
								$contentArray['share_owner_url'] = base_url() . "profile/" . $groupDetails['user_id'];
								break;
						case "event":
								$eventDetails = $this->eventsmodel->getInfo($shareId);
								$contentArray['share_img'] = $this->eventsmodel->geteventImage($shareId, true, true);
								$contentArray['share_type'] = $shareType;
								$contentArray['share_heading_lable'] = "From the Event";
								$contentArray['share_heading_caption'] = $eventDetails['event_name'];
								$contentArray['share_content_owner'] = $eventDetails['username'];
								$contentArray['share_content_url'] = base_url() . 'events/view/' . $eventDetails['event_id'] . '/';
								$contentArray['share_owner_url'] = base_url() . "profile/" . $eventDetails['user_id'];
								break;
						case "marketplace_list":
								$mode = 'list';
								$marketDetails = $this->marketplacemodel->getListInfo($shareId, $mode);
								$contentArray['share_img'] = $this->marketplacemodel->getMarketplaceImage($shareId, $mode, true, true);
								$contentArray['share_type'] = $shareType;
								$contentArray['share_heading_lable'] = "From the Marketplace Listing";
								$contentArray['share_heading_caption'] = $marketDetails[0]['item_title'];
								$contentArray['share_content_owner'] = $this->usermodel->getName($marketDetails[0]['user_id']);
								$contentArray['share_content_url'] = base_url() . 'marketplace/show/' . $marketDetails[0]['list_id'] . '/' . $marketDetails[0]['tag_id'] . '/' . $mode . '/';
								$contentArray['share_owner_url'] = base_url() . "profile/" . $marketDetails[0]['user_id'];
								break;
						case "marketplace_want":
								$mode = 'want';
								$marketDetails = $this->marketplacemodel->getListInfo($shareId, $mode);
								$contentArray['share_img'] = $this->marketplacemodel->getMarketplaceImage($shareId, $mode, true, true);
								$contentArray['share_type'] = $shareType;
								$contentArray['share_heading_lable'] = "From the Marketplace Wanted";
								$contentArray['share_heading_caption'] = $marketDetails[0]['item_title'];
								$contentArray['share_content_owner'] = $this->usermodel->getName($marketDetails[0]['user_id']);
								$contentArray['share_content_url'] = base_url() . 'marketplace/show/' . $marketDetails[0]['list_id'] . '/' . $marketDetails[0]['tag_id'] . '/' . $mode . '/';
								$contentArray['share_owner_url'] = base_url() . "profile/" . $marketDetails[0]['user_id'];
								break;
						case "video":
								$videoDetails = $this->videomodel->getVideo($shareId);
								$contentArray['share_img'] = 'content/videos/user_' . $videoDetails['user_id'] . '/video_' . $videoDetails['video_id'] . '_thumb.jpg';
								$contentArray['share_type'] = $shareType;
								$contentArray['share_heading_lable'] = "From the video";
								$contentArray['share_heading_caption'] = $videoDetails['video_title'];
								$contentArray['share_content_owner'] = $this->usermodel->getName($videoDetails['user_id']);
								$contentArray['share_content_url'] = base_url() . 'videos/playvideo/' . $shareId;
								$contentArray['share_owner_url'] = base_url() . "profile/" . $videoDetails['user_id'];
								break;
				}
				return $contentArray;
		} //end getShareContent()
		#***************************************************************************
		#Method			: 	deletepost()
		#Type			: 	Sub
		#Description	:	delete a post from posted_items table, and
		#					returns the status
		#***************************************************************************
		function deletepost($postId)
		{
				$sql = 'DELETE FROM posted_items WHERE post_id=' . $postId;
				$this->db->query($sql);
				if ($this->db->affected_rows() > 0) return true;
				else  return false;
		} //end deleteComment()
		#***************************************************************************
		#Method			: 	deletePostByType($postFor,$postForId)
		#Type			: 	sub
		#Description	:	delete post by its type and its post_for_id(ex:delete by
		#					post by type 'group', and post_for_id group_id
		#***************************************************************************
		function deletePostByType($postFor, $postForId)
		{
				//echo 'DELETE FROM posted_items WHERE post_type=\''.$postFor.'\' AND post_for_id='.$postForId;
				$sql = 'DELETE FROM posted_items WHERE post_type=\'' . $postFor . '\' AND post_for_id=' . $postForId;
				$this->db->query($sql);
				if ($this->db->affected_rows() > 0) return true;
				else  return false;
		} //end deletePostByType()
		#***************************************************************************
		#Method			: updatePostedItemStatus
		#Description	: updates PostedItem status
		#Author
		#***************************************************************************
		function updatePostedItemStatus($block_id, $status)
		{
				$postedStatus = array('post_status' => $status);
				$this->db->where('post_id', $block_id);
				$this->db->update('posted_items', $postedStatus);
		}
}
?>