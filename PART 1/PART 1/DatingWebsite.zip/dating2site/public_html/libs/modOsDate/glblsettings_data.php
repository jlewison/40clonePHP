<?php

   class glblsettingsData extends Data {

      var $table = GLBLSETTINGS_TABLE;

      var $config = array (
  'table' => GLBLSETTINGS_TABLE,
  'idField' => 'osdate_glblsettings_id',
  'addedMsg' => 'Osdate Glblsettings %s Added',
  'added_err' => 'Can\\\'t Add Osdate Glblsettings',
  'editMsg' => 'Osdate Glblsettings %s Updated',
  'editErr' => 'Can\\\'t Update Osdate Glblsettings',
  'delErr' => 'Can\\\'t Delete Osdate Glblsettings',
  'delMsg' => 'Osdate Glblsettings %s Deleted',
  'blankErr' => 'Osdate Glblsettings Empty',
  'fields' => 
  array (
    'config_variable' => 
    array (
      'name' => 'config_variable',
      'description' => 'Config Variable',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 50,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'config_value' => 
    array (
      'name' => 'config_value',
      'description' => 'Config Value',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 255,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'description' => 
    array (
      'name' => 'description',
      'description' => 'Description',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 255,
      'blank_ok' => 1,
      'duplicate_ok' => 1,
    ),
    'groupid' => 
    array (
      'name' => 'groupid',
      'description' => 'Groupid',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 2,
      'blank_ok' => 1,
      'duplicate_ok' => 1,
    ),
  ),
);   

      function glblsettingsData() {
      
         $this->Data($this->config);
      }
   }

?>
