<?php
        include('config.php');
        include('libs/ts.php');
	ts_gfx($_GET['ts_random']);
?>