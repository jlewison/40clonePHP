<?php
function fgc($url, $variables=null) {
	$ch = curl_init();
	if ($variables) {
	   curl_setopt($ch, CURLOPT_POST, 1 );
	   curl_setopt($ch, CURLOPT_POSTFIELDS, $variables);
	}
	curl_setopt ($ch, CURLOPT_URL, $url);
	curl_setopt ($ch, CURLOPT_USERAGENT, "Mozilla/5.001 (windows; U; NT4.0; en-us) Gecko/25250101");
	curl_setopt ($ch, CURLOPT_HEADER, 0);
	curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
	$result = curl_exec ($ch);
	curl_close ($ch);
	return $result;
}
