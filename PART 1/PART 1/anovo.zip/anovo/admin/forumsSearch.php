<?php
require_once ('../common/config.inc.php');
$CFG['lang']['include_files'][] = 'admin/includes/languages/%s/forumsSearch.php';
$CFG['html']['header'] = 'admin/includes/languages/%s/html_header.php';
$CFG['html']['footer'] = 'admin/includes/languages/%s/html_footer.php';
$CFG['lang']['include_files'][] = 'common/configs/config_forums.inc.php';
$CFG['lang']['include_files'][] = 'common/languages/%s/lists_array/months_list_array.inc.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['db']['is_use_db'] = true;
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class ForumSearchFormHandler extends FormHandler
{
		public function generateQueryString($search_fields_arr)
		{
				$this->queryStr = '?';
				foreach ($search_fields_arr as $search_field)
				{
						if ($this->fields_arr[$search_field])
						{
								$this->queryStr .= '&' . $search_field . '=' . $this->fields_arr[$search_field];
								if ($search_field == 'srch_topic_cnt')
								{
										$this->queryStr .= '&topic_condition=' . $this->fields_arr['topic_condition'];
								} elseif ($search_field == 'srch_response_cnt')
								{
										$this->queryStr .= '&response_condition=' . $this->fields_arr['response_condition'];
								}
						}
				}
		}
		public function populateConditionOperators($highlight_operator)
		{
?>
				<option value="equalto" <?php if ($highlight_operator == 'equalto') echo 'SELECTED'; ?>><?php echo $this->LANG['forumsearch_equal_to'] ?></option>
				<option value="greaterthan" <?php if ($highlight_operator == 'greaterthan') echo 'SELECTED'; ?>><?php echo $this->LANG['forumsearch_greater_than'] ?></option>
				<option value="greaterthanequal" <?php if ($highlight_operator == 'greaterthanequal') echo 'SELECTED'; ?>><?php echo $this->LANG['forumsearch_greater_than_equal'] ?></option>
				<option value="lessthan" <?php if ($highlight_operator == 'lessthan') echo 'SELECTED'; ?>><?php echo $this->LANG['forumsearch_less_than'] ?></option>
				<option value="lessthanequal" <?php if ($highlight_operator == 'lessthanequal') echo 'SELECTED'; ?>><?php echo $this->LANG['forumsearch_less_than_equal'] ?></option>
				<option value="notequal" <?php if ($highlight_operator == 'notequal') echo 'SELECTED'; ?>><?php echo $this->LANG['forumsearch_not_equal'] ?></option>
			<?php
		}
}
$forums = new ForumSearchFormHandler();
$forums->setPageBlockNames(array('msg_form_error', 'msg_form_success', 'form_search'));
$forums->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$forums->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$forums->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$forums->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$forums->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$forums->setDBObject($db);
$forums->setCfgLangGlobal($CFG, $LANG);
$forums->setAllPageBlocksHide();
$forums->setFormField('srch', '');
$forums->setFormField('numpg', 0);
$forums->setFormField('start', 0);
$forums->setFormField('srch_title', '');
$forums->setFormField('srch_topic', '');
$forums->setFormField('srch_topic_cnt', '');
$forums->setFormField('topic_condition', '');
$forums->setFormField('srch_response', '');
$forums->setFormField('srch_response_cnt', '');
$forums->setFormField('response_condition', '');
$forums->setFormField('srch_uname', '');
$forums->setFormField('srch_status', '');
$forums->setFormField('status_active', '');
$forums->setFormField('status_inactive', '');
$forums->setFormField('srch_date_added', '');
$forums->setFormField('srch_date', '');
$forums->setFormField('srch_month', '');
$forums->setFormField('srch_year', '');
$forums->setMonthsListArr($LANG_LIST_ARR['months']);
if ($forums->isFormPOSTed($_POST, 'forumsearch_search'))
{
		$forums->sanitizeFormInputs($_POST);
		$forums->getFormField('srch_topic_cnt') and $forums->chkIsNumeric('srch_topic_cnt', $LANG['forumsearch_err_tip_enter_numbers']);
		$forums->getFormField('srch_response_cnt') and $forums->chkIsNumeric('srch_response_cnt', $LANG['forumsearch_err_tip_enter_numbers']);
		if ($forums->getFormField('srch_date') || $forums->getFormField('srch_month') || $forums->getFormField('srch_year'))
		{
				$forums->chkIsCorrectDate($forums->getFormField('srch_date'), $forums->getFormField('srch_month'), $forums->getFormField('srch_year'), 'srch_date_added', $LANG['forumsearch_err_tip_date_empty'], $LANG['forumsearch_err_tip_date_invalid']);
		}
		$forums->setAllPageBlocksHide();
		if ($forums->isValidFormInputs())
		{
				$forums->generateQueryString(array('srch_title', 'srch_topic', 'srch_topic_cnt', 'srch_response', 'srch_response_cnt', 'srch_uname', 'status_active', 'status_inactive', 'srch_date', 'srch_month', 'srch_year'));
				Redirect2URL('forums.php' . $forums->queryStr);
		}
		else
		{
				$forums->setPageBlockShow('msg_form_error');
		}
}
if ($forums->isFormGETed($_GET))
{
		$forums->sanitizeFormInputs($_GET);
		$forums->getFormField('srch_topic_cnt') and $forums->chkIsNumeric('srch_topic_cnt', $LANG['forumsearch_err_tip_enter_numbers']);
		$forums->getFormField('srch_response_cnt') and $forums->chkIsNumeric('srch_response_cnt', $LANG['forumsearch_err_tip_enter_numbers']);
		if ($forums->getFormField('srch_date') || $forums->getFormField('srch_month') || $forums->getFormField('srch_year'))
		{
				$forums->chkIsCorrectDate($forums->getFormField('srch_date'), $forums->getFormField('srch_month'), $forums->getFormField('srch_year'), 'date_added', $LANG['forumsearch_err_tip_date_empty'], $LANG['forumsearch_err_tip_date_invalid']);
		}
		$forums->setAllPageBlocksHide();
		if (!$forums->isValidFormInputs())
		{
				$forums->setPageBlockShow('msg_form_error');
		}
}
$forums->setPageBlockShow('form_search');




?>
<div id="selGroupListAll">
  <div>
    <h2><span><?php echo $LANG['forumsearch_title_index']; ?></span></h2>
    <div id="selRightNavigation">
		<h3><a href="forums.php"><?php echo $LANG['forumslinks_header']; ?></a></h3>
         <ul>
		   <li><a href="forums.php"><?php echo $LANG['forumslinks_list_forums']; ?></a></li>
           <li><a href="forumsAddTitle.php"><?php echo $LANG['forumslinks_add_title']; ?></a></li>
		   <li><a href="forums.php?srch=mosttopics"><?php echo $LANG['forumslinks_most_topics']; ?></a></li>
		   <li><a href="forums.php?srch=mostresponses"><?php echo $LANG['forumslinks_most_responses']; ?></a></li>
		   <li class="clsActivePhotoSubLink"><a href="forumsSearch.php"><?php echo $LANG['forumslinks_search_forums']; ?></a></li>
         </ul>
	</div>
    <div id="selLeftNavigation">
      <?php
if ($forums->isShowPageBlock('msg_form_error'))
{
?>
      <div id="selMsgError">
        <p><?php echo $LANG['msg_error_sorry']; ?> <?php echo $forums->getCommonErrorMsg(); ?></p>
      </div>
      <?php
}
if ($forums->isShowPageBlock('msg_form_success'))
{
?>
      <div id="selMsgSuccess">
        <p><?php echo $LANG['forumsearch_success_message']; ?></p>
      </div>
      <?php
}
?>
<form name="form_search" id="selFormSearch" method="post" action="<?php echo URL($_SERVER['PHP_SELF']); ?>" autocomplete="off">
<?php
if ($forums->isShowPageBlock('form_search'))
{
?>
		<div id="selShowSearchGroup">
			<table border="1" cellspacing="0" summary="<?php echo $LANG['forumsearch_tbl_summary']; ?>">
				<tr>
					<td class="<?php echo $forums->getCSSFormLabelCellClass('srch_title'); ?>"><label for="srch_title"><?php echo $LANG['forumsearch_search_title']; ?></label></td>
					<td class="<?php echo $forums->getCSSFormFieldCellClass('srch_title'); ?>"><?php echo $forums->getFormFieldErrorTip('srch_title'); ?><input type="text" class="clsTextBox" name="srch_title" id="srch_title" value="<?php echo $forums->getFormField('srch_title'); ?>" tabindex="<?php echo $forums->getTabIndex(); ?>"/></td>
				</tr>
				<tr>
					<td class="<?php echo $forums->getCSSFormLabelCellClass('srch_topic'); ?>"><label for="srch_topic"><?php echo $LANG['forumsearch_search_topics']; ?></label></td>
					<td class="<?php echo $forums->getCSSFormFieldCellClass('srch_topic'); ?>"><input type="text" class="clsTextBox" name="srch_topic" id="srch_topic" value="<?php echo $forums->getFormField('srch_topic'); ?>" tabindex="<?php echo $forums->getTabIndex(); ?>"/></td>
				</tr>
				<tr>
					<td class="<?php echo $forums->getCSSFormLabelCellClass('srch_topic_cnt'); ?>"><label for="srch_topic_cnt"><?php echo $LANG['forumsearch_search_topics_count']; ?></label></td>
					<td class="<?php echo $forums->getCSSFormFieldCellClass('srch_topic_cnt'); ?>">
						<select name="topic_condition" id="topic_condition" tabindex="<?php echo $forums->getTabIndex(); ?>" >
							<?php $forums->populateConditionOperators($forums->getFormField('topic_condition')); ?>
						</select>
						<input type="text" class="clsTextBox" name="srch_topic_cnt" id="srch_topic_cnt" value="<?php echo $forums->getFormField('srch_topic_cnt'); ?>" tabindex="<?php echo $forums->getTabIndex(); ?>"/>
					</td>
				</tr>
				<tr>
					<td class="<?php echo $forums->getCSSFormLabelCellClass('srch_response'); ?>"><label for="srch_response"><?php echo $LANG['forumsearch_search_response']; ?></label></td>
					<td class="<?php echo $forums->getCSSFormFieldCellClass('srch_response'); ?>"><input type="text" class="clsTextBox" name="srch_response" id="srch_response" value="<?php echo $forums->getFormField('srch_response'); ?>" tabindex="<?php echo $forums->getTabIndex(); ?>"/></td>
				</tr>
				<tr>
					<td class="<?php echo $forums->getCSSFormLabelCellClass('srch_response_cnt'); ?>"><label for="srch_response_cnt"><?php echo $LANG['forumsearch_search_response_count']; ?></label></td>
					<td class="<?php echo $forums->getCSSFormFieldCellClass('srch_response_cnt'); ?>">
						<select name="response_condition" id="response_condition" tabindex="<?php echo $forums->getTabIndex(); ?>" >
							<?php $forums->populateConditionOperators($forums->getFormField('response_condition')); ?>
						</select>
						<input type="text" class="clsTextBox" name="srch_response_cnt" id="srch_response_cnt" value="<?php echo $forums->getFormField('srch_response_cnt'); ?>" tabindex="<?php echo $forums->getTabIndex(); ?>"/>
					</td>
				</tr>
				<tr>
					<td class="<?php echo $forums->getCSSFormLabelCellClass('srch_uname'); ?>"><label for="srch_uname"><?php echo $LANG['forumsearch_search_uname']; ?></label></td>
					<td class="<?php echo $forums->getCSSFormFieldCellClass('srch_uname'); ?>"><input type="text" class="clsTextBox" name="srch_uname" id="srch_uname" value="<?php echo $forums->getFormField('srch_uname'); ?>" tabindex="<?php echo $forums->getTabIndex(); ?>"/></td>
				</tr>
				<tr>
					<td class="<?php echo $forums->getCSSFormLabelCellClass('srch_status'); ?>"><label for="status_active"><?php echo $LANG['forumsearch_search_status']; ?></label></td>
					<td class="<?php echo $forums->getCSSFormFieldCellClass('srch_status'); ?>">
						<input type="checkbox" class="clsCheckRadio" name="status_active" id="status_active" <?php if ($forums->getFormField('status_active')) echo 'CHECKED'; ?> value="Active" tabindex="<?php echo $forums->getTabIndex(); ?>" />
						<label for="status_active"><?php echo $LANG['forumsearch_search_active']; ?></label>&nbsp;&nbsp;&nbsp;
						<input type="checkbox" class="clsCheckRadio" name="status_inactive" id="status_inactive" <?php if ($forums->getFormField('status_inactive')) echo 'CHECKED'; ?> value="Inactive" tabindex="<?php echo $forums->getTabIndex(); ?>" />
						<label for="status_inactive"><?php echo $LANG['forumsearch_search_inactive']; ?></label>&nbsp;&nbsp;&nbsp;
					</td>
				</tr>
				<tr>
					<td class="<?php echo $forums->getCSSFormLabelCellClass('srch_date_added'); ?>"><label for="srch_date"><?php echo $LANG['forumsearch_search_date_created']; ?></label></td>
					<td class="<?php echo $forums->getCSSFormFieldCellClass('srch_date_added'); ?>"><?php echo $forums->getFormFieldErrorTip('srch_date_added'); ?>
						<select name="srch_date" id="srch_date" tabindex="<?php echo $forums->getTabIndex(); ?>">
							<option value=""><?php echo $LANG['forumsearch_search_date']; ?></option>
							<?php $forums->populateBWNumbers(1, 31, $forums->getFormField('srch_date')); ?>
						</select>
						<select name="srch_month" id="srch_month" tabindex="<?php echo $forums->getTabIndex(); ?>">
							<option value=""><?php echo $LANG['forumsearch_search_month']; ?></option>
							<?php $forums->populateMonthsList($forums->getFormField('srch_month')); ?>
						</select>
						<select name="srch_year" id="srch_year" tabindex="<?php echo $forums->getTabIndex(); ?>">
							<option value=""><?php echo $LANG['forumsearch_search_year']; ?></option>
							<?php $forums->populateBWNumbers(1920, date("Y"), $forums->getFormField('srch_year')); ?>
						</select>
					</td>
				</tr>
				<tr>
					<td class="<?php echo $forums->getCSSFormFieldCellClass('forumsearch_search'); ?>" colspan="2"><input type="submit" class="clsSubmitButton" value="<?php echo $LANG['forumsearch_search']; ?>" id="forumsearch_search" name="forumsearch_search" tabindex="<?php echo $forums->getTabIndex(); ?>"/></td>
				</tr>
			</table>
		</div>
      <?php
}
?>
	  </form>
    </div>
  </div>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>
