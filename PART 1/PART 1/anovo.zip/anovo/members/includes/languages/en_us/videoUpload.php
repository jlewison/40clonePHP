<?php
$LANG['videoupload_title'] = 'Video Capturing';
$LANG['success_uploaded'] = 'Success';
$LANG['error_uploaded'] = 'Error';
$LANG['close'] = 'Close';
?>