<?php

/**
 * Home Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 15-12-2007
 */
class Home extends Controller
{
		//Constructor
		function Home()
		{
				parent::Controller();
				loggedInTakeIn();
				//Load the language file
				$this->lang->load('login', $this->config->item('language_code'));
				$this->lang->load('home', $this->config->item('language_code'));
		}
		//Default function
		function index()
		{
				//Load the cookie helper
				$this->load->helper('cookie');
				//Get the e-mail from Cookie if set
				$outputData['user_email'] = get_cookie('kootali_email');
				$this->smartyextended->view('home', $outputData);
		}
}
?>