<?php
/**
 * posteditems Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 2007-12-14
 */
##################################################################
class posteditems extends Controller
{
		//Constructor
		var $userId;
		function posteditems()
		{
				parent::Controller();
				loginRequired();
				//Load the language file
				$this->lang->load('posted', $this->config->item('language_code'));
				$this->userId = $this->session->userdata('user_id');
		}
		#***************************************************************************
		#Method			: default
		#Description	: show posted items posted by all friends
		#***************************************************************************
		function index()
		{
				$this->load->model('friendsmodel');
				$this->load->model('usermodel');
				$this->load->model('postedmodel');
				$outputData = array();
				$commentEndLimit = 3;
				$userId = $this->userId;
				$friendsId = implode(",", $this->friendsmodel->getFriends($userId));
				if ($friendsId == '')
				{
						$outputData['friends_list'] = array();
				}
				else
				{
						$outputData['friends_list'] = $this->usermodel->getDetails($friendsId);
				}
				//Load the config file related to photo
				$this->config->load('photo');
				//Load the pagination model
				$this->load->model('paginationmodel');
				//Load the pagination language file
				$this->lang->load('pagination', $this->config->item('language_code'));
				$perPage = $this->paginationmodel->getPerPage('posteditems');
				$start = (trim($this->uri->segment(2)) != '' && is_numeric($this->uri->segment(2)) && $this->uri->segment(2) > 0) ? $this->uri->segment(2) : 1;
				$start = ($start - 1) * $perPage;
				$outputData['user_avatar'] = $this->usermodel->getAvatar($userId);
				$outputData['user_name'] = $this->usermodel->getName($userId);
				$outputData['user_id'] = $userId;
				$outputData['posted_content'] = $this->postedmodel->getPosts('', '', 'all', 'post_date', $start, $perPage);
				$outputData['comments_limit'] = $commentEndLimit;
				$outputData['postCount'] = $this->postedmodel->getPostCount('', '', 'all');
				$outputData['currentPage'] = (trim($this->uri->segment(2)) != '' && is_numeric($this->uri->segment(2))) ? $this->uri->segment(2) : 1;
				$outputData['totalPages'] = ($outputData['postCount'] > $perPage) ? ceil(($outputData['postCount'] / $perPage)) : 0;
				$outputData['pageUrl'] = base_url() . 'posteditems/';
				$outputData['endCount'] = $start + count($outputData['posted_content']);
				$outputData['startCount'] = $start + 1;
				#		echo '<pre>';
				#		print_r($outputData);
				#		echo '</pre>';
				$this->smartyextended->view('postedItems', $outputData);
		} //end index()
		#***************************************************************************
		#Method			: 	postToProfile()
		#Type			: 	Main
		#Description	:	store the posted content to posted_items table
		#					and redirect to my posted items page
		#***************************************************************************
		function postToProfile()
		{
				$this->load->model('usermodel');
				$this->load->model('postedmodel');
				$userId = $this->userId;
				if ($this->input->post('post2profile_submit') or $this->input->post('sharePost2profile_submit'))
				{
						$postTime = date($this->config->item('date_format_short'));
						$userName = $this->usermodel->getName($userId);
						$userAvatar = $this->usermodel->getAvatar($userId);
						if ($this->input->post('sharePost2profile_submit'))
						{
								$postValues['post_content'] = $this->input->post('hdn_share_post_content');
								$postValues['post_comment'] = $this->input->post('txt_share_post_comment');
								$postValues['post_type'] = $this->input->post('hdn_share_post_type');
								$postValues['post_for_id'] = $this->input->post('hdn_share_post_for_id');
						}
						else
						{
								$postValues['post_content'] = $this->input->post('txt_post_content');
								$postValues['post_comment'] = $this->input->post('txt_post_comment');
								$postValues['post_type'] = 'link';
								$postValues['post_for_id'] = 0;
						}
						if ($this->postedmodel->storePost($postValues)) $this->session->set_flashdata('flash_msg_success', $this->lang->line('posted_post_success_msg'));
						else  $this->session->set_flashdata('flash_msg_error', $this->lang->line('posted_post_error_msg'));
						redirect("posteditems/myposts");
				}
				else  redirect("posteditems");
		}
		#***************************************************************************
		#Method			: show
		#Description	: show posted items posted by given user id
		#***************************************************************************
		function show()
		{
				$this->load->model('usermodel');
				$this->load->model('postedmodel');
				$outputData = array();
				$commentEndLimit = 3;
				if ($this->input->post('lstFriends') or $this->uri->segment(3) > 0 or $this->session->userdata('postedListFriendId') != '')
				{
						if ($this->uri->segment(3) > 0) $this->session->set_userdata(array("postedListFriendId" => $this->uri->segment(3)));
						elseif ($this->input->post('lstFriends')) $this->session->set_userdata(array("postedListFriendId" => $this->input->post('lstFriends')));
						$userId = $this->session->userdata('postedListFriendId');
						$friendsArray = $this->usermodel->getFriends();
						if ($userId == $this->userId) //if the given user id is current user, then show my posted items
 										redirect("posteditems/myposts");
						elseif (array_key_exists($userId, $friendsArray))
						{
								//echo $this->uri->segment(3);
								//Load the config file related to photo
								$this->config->load('photo');
								//Load the pagination model
								$this->load->model('paginationmodel');
								//Load the pagination language file
								$this->lang->load('pagination', $this->config->item('language_code'));
								$perPage = $this->paginationmodel->getPerPage('posteditems');
								$start = (trim($this->uri->segment(4)) != '' && is_numeric($this->uri->segment(4)) && $this->uri->segment(4) > 0) ? $this->uri->segment(4) : 1;
								$start = ($start - 1) * $perPage;
								$outputData['user_avatar'] = $this->usermodel->getAvatar($userId);
								$outputData['user_name'] = $this->usermodel->getName($userId);
								$outputData['user_id'] = $userId;
								$outputData['posted_content'] = $this->postedmodel->getPosts('', '', $userId, 'post_date', $start, $perPage);
								$outputData['comments_limit'] = $commentEndLimit;
								$outputData['postCount'] = $this->postedmodel->getPostCount('', '', $userId);
								$outputData['currentPage'] = (trim($this->uri->segment(4)) != '' && is_numeric($this->uri->segment(4))) ? $this->uri->segment(4) : 1;
								$outputData['totalPages'] = ($outputData['postCount'] > $perPage) ? ceil(($outputData['postCount'] / $perPage)) : 0;
								$outputData['pageUrl'] = base_url() . 'posteditems/show/' . $userId . '/';
								$outputData['endCount'] = $start + count($outputData['posted_content']);
								$outputData['startCount'] = $start + 1;
								$this->smartyextended->view('postedFriends', $outputData);
						}
						else  redirect("posteditems");
				}
				else  redirect("posteditems");
		} //end show()
		#***************************************************************************
		#Method			: myposts
		#Description	: show current users posted items
		#***************************************************************************
		function myposts()
		{
				$this->load->model('usermodel');
				$this->load->model('postedmodel');
				$outputData = array();
				$userId = $this->userId;
				$commentEndLimit = 3;
				//Load the config file related to photo
				$this->config->load('photo');
				//Load the pagination model
				$this->load->model('paginationmodel');
				//Load the pagination language file
				$this->lang->load('pagination', $this->config->item('language_code'));
				$perPage = $this->paginationmodel->getPerPage('posteditems');
				$start = (trim($this->uri->segment(3)) != '' && is_numeric($this->uri->segment(3)) && $this->uri->segment(3) > 0) ? $this->uri->segment(3) : 1;
				$start = ($start - 1) * $perPage;
				$outputData['user_avatar'] = $this->usermodel->getAvatar($userId);
				$outputData['user_name'] = $this->usermodel->getName($userId);
				$outputData['user_id'] = $userId;
				$outputData['posted_content'] = $this->postedmodel->getPosts('', '', $userId, 'post_date', $start, $perPage);
				$outputData['comments_limit'] = $commentEndLimit;
				$outputData['userAvatar'] = $this->usermodel->getAvatar($userId);
				$outputData['postCount'] = $this->postedmodel->getPostCount('', '', $userId);
				$outputData['currentPage'] = (trim($this->uri->segment(3)) != '' && is_numeric($this->uri->segment(3))) ? $this->uri->segment(3) : 1;
				$outputData['totalPages'] = ($outputData['postCount'] > $perPage) ? ceil(($outputData['postCount'] / $perPage)) : 0;
				$outputData['pageUrl'] = base_url() . 'posteditems/myposts/';
				$outputData['endCount'] = $start + count($outputData['posted_content']);
				$outputData['startCount'] = $start + 1;
				//if($outputData['currentPage'] > $outputData['totalPages'])
				$this->smartyextended->view('postedMe', $outputData);
		} //end myposts()
		#***************************************************************************
		#Method			: addComment
		#Description	: add a comment to the particular post
		#***************************************************************************
		function addComment()
		{
				$this->load->model('postedmodel');
				$data['comment'] = $this->input->post('comment');
				$data['post_id'] = $this->input->post('postId');
				$commentId = $this->postedmodel->storeComment($data);
				if ($commentId)
				{
						$data['comment_result'] = $this->lang->line('posted_add_comment_success_msg');
						$data['comment_id'] = $commentId;
						$data['comment_on'] = date($this->config->item('date_format_full'), time());
				}
				else
				{
						$data['comment_result'] = $this->lang->line('posted_add_comment_error_msg');
						$data['comment_id'] = '';
				}
				$totRec = $this->postedmodel->getTotComments($this->input->post('postId'));
				echo json_encode(array('template' => $this->smartyextended->view('postedItemComments', $data, true), 'comment_id' => $commentId, 'tot_comments' => $totRec, 'post_id' => $this->input->post('postId')));
		} //end addComment()
		#***************************************************************************
		#Method			: deleteComment
		#Description	: delete a comment using comment id, for the particular post
		#***************************************************************************
		function processDeleteComment()
		{
				$this->load->model('postedmodel');
				$result = $this->postedmodel->deleteComment($this->input->post('commentId'));
				$totRec = $this->postedmodel->getTotComments($this->input->post('postId'));
				echo json_encode(array('success' => $result, 'tot_comments' => $totRec));
		} //end addComment()
		#***************************************************************************
		#Method			: viewPost
		#Description	: view signle post and its comments
		#Arguents		: $postId
		#***************************************************************************
		function viewPost($postId)
		{
				$this->load->model('usermodel');
				$this->load->model('postedmodel');
				$outputData = array();
				$isPost = $this->postedmodel->isPost($postId);
				if ($postId != '' and $postId > 0 and $isPost)
				{
						$postedBy = $this->postedmodel->getPostedBy($postId);
						$friendsArray = $this->usermodel->getFriends($postedBy);
						if ($postedBy == $this->userId or array_key_exists($this->userId, $friendsArray))
						{ //allow, if the current user posted this post or, he is the friend of posted person
								$outputData = array_merge($outputData, $this->postedmodel->getSinglePost($postId));
								$this->smartyextended->view('postedViewPost', $outputData);
						}
						else  redirect("posteditems");
				}
				else  redirect("posteditems");
		} //end viewPost()
		#***************************************************************************
		#Method			: 	showShareInterface()
		#Type			: 	Ajax
		#Description	:	prepare template for share interface, share content
		#***************************************************************************
		function showShareInterface()
		{
				$this->load->model('usermodel');
				$this->load->model('postedmodel');
				$shareType = $this->input->post('shareType');
				$shareId = $this->input->post('shareId');
				$data = $this->postedmodel->getShareContent($shareId, $shareType);
				echo json_encode(array('template' => $this->smartyextended->view('shareContent', $data, true), 'share_content_url' => $data['share_content_url']));
		} //end showShareInterface()
		#***************************************************************************
		#Method			: 	sharePost2Profile()
		#Type			: 	Main
		#Description	:	store the posted content to posted_items table
		#					and redirect to my posted items page
		#***************************************************************************
		function sharePost2Profile()
		{
				$this->load->model('usermodel');
				$this->load->model('postedmodel');
				$userId = $this->userId;
				$postTime = date($this->config->item('date_format_short'));
				$userName = $this->usermodel->getName($userId);
				$userAvatar = $this->usermodel->getAvatar($userId);
				if ($this->input->post('shareType') == 'link') $postValues['post_content'] = $this->input->post('shareLink');
				else  $postValues['post_content'] = '';
				$postValues['post_comment'] = $this->input->post('shareComment');
				$postValues['post_type'] = $this->input->post('shareType');
				$postValues['post_for_id'] = $this->input->post('shareId');
				if ($this->postedmodel->storePost($postValues))
				{
						$result = $this->lang->line('posted_post_success_msg');
				}
				else  $result = $this->lang->line('posted_post_error_msg');
				echo json_encode(array('result' => $result));
		}
		#***************************************************************************
		#Method			: deletepost
		#Description	: delete a post
		#***************************************************************************
		function deletepost()
		{
				if ($this->input->post('delete_post_submit'))
				{
						$this->load->model('postedmodel');
						if ($this->postedmodel->deletepost($this->input->post('hdn_del_post_id'))) $this->session->set_flashdata('flash_msg_success', $this->lang->line('posted_delete_post_success_msg'));
						else  $this->session->set_flashdata('flash_msg_error', $this->lang->line('posted_delete_post_error_msg'));
						redirect("posteditems/myposts");
				}
				else  redirect("posteditems");
		} //end addComment()
		#***************************************************************************
		#Method			: validateurl
		#Description	: validate given url is valid or or not, using ajax
		#***************************************************************************
		function validateurl()
		{
				$url = $this->input->post('url');
				$this->load->helper('validation');
				if (valid_url($url)) echo json_encode(array('msg' => 'success'));
				else  echo json_encode(array('msg' => 'error'));
		} //end addComment()
}
?>