<?php
// Le format de ce fichier est ---> $lang['message'] = 'text';
//
// Vous pouvez aussi choisir votre encodage de carract�res local. Cet encodage sera appliqu� � votre gabarit. Certains encodages locaux peuvent ne pas fonctionner, cela d�pend du syst�me d\'exploitation utilis�
// Choisissez-en un qui fonctionne en faisant des essais!
//


$lang['ENCODING'] = 'iso-8859-15';
$lang['DIRECTION'] = 'ltr';
$lang['LEFT'] = 'gauche';
$lang['RIGHT'] = 'droite';
$lang['DATE_FORMAT'] =  '%b %d, %Y'; // Ceci doit �tre chang� par le format de date par d�faut de votre langue, php date() format
$lang['DATE_TIME_FORMAT'] =  '%b %d, %Y %I:%M:%S %P'; // Ceci doit �tre chang� par le format de date par d�faut de votre langue, php date() format
$lang['DISPLAY_DATE_FORMAT'] =  'M d, Y';
$lang['DISPLAY_DATETIME_FORMAT'] = 'D M-d-Y H:i:s';
$lang['DB_ERROR'] = "Votre requ�te n\'a pu �tre ex�cut�e � cause d\'une erreur non-sp�cifi� de la base de donn�e...<br />Svp essayez encore.";

$lang['main_menu'] = 'Menu Principal';
$lang['homepage'] = 'Accueil';
$lang['rate_photos'] = 'Notez les Photos';
$lang['forum'] = 'Forum';
$lang['manageforum'] = 'Gestion du Forum';
$lang['chat'] = 'Tchat';
$lang['managechat'] = 'Gestion du Tchat';
$lang['member_login'] = 'Connexion Usagers';
$lang['featured_members'] = 'Usagers Distingu�s';
$lang['quick_search'] = 'Recherche Rapide';
$lang['my_searches'] = 'Mes Recherches';
$lang['affiliates'] = 'Affili�s';
$lang['already_affiliate'] = 'D�j� un affili�?';
$lang['referals'] = 'R�f�rants';
$lang['title_colon'] = 'Titre:';
$lang['comments_colon'] = 'Commentaires:';
$lang['feedback'] = 'Suggestions/Critiques';

$lang['profiles'] = 'Profils';
$lang['profile_s'] = 'Profil de USERNAME';
$lang['total_amt'] = 'Montant total';
$lang['banner_link'] = 'Banni�re/lien';
$lang['clicks'] = 'Cliques';
$lang['finance_calc'] = 'Calculateur de finances';
$lang['flash_chat_msg'] = 'FlashChat 4.1.0 et plus r�cents incluent une int�gration � osdate. Vous pouvez acheter FlashChat sur <a href="http://www.tufat.com/chat.php" target="_blank">http://www.tufat.com/chat.php</a> et copiez les fichiers dans ce dossier. Ensuite installez FlashChat et sp�cifiez osdate comme CMS pour votre installation.';
$lang['flash_chat_admin_msg'] = 'FlashChat 4.1.0 et plus r�cents incluent une int�gration � osdate. Vous pouvez acheter FlashChat sur <a href="http://www.tufat.com/chat.php" target="_blank">http://www.tufat.com/chat.php</a> et copiez les fichiers dans ce dossier. Ensuite installez FlashChat et sp�cifiez osdate comme CMS pour votre installation.';
$lang['affiliate_head_msg'] = 'Devenez un affili�';
$lang['affiliate_head_msg2'] = 'Nous offrons des commissions aux webmasters qui nous envoient des usagers.<br/>';
$lang['affiliate_success_msg1'] = 'Votre num�ro de compte affili� est:';
$lang['affiliate_success_msg2'] = 'Vous pouvez maintenant vous connecter sur votre compte affili�. ';
$lang['affiliate_login_title'] = "Connexion affili�s";
$lang['password_changed_successfully'] = 'Votre mot de passe a �t� chang� avec succ�s.';
$lang['affiliate_registration_success'] = 'Compte affili� enregistr� avec succ�s';
$lang['login_now'] = 'Connectez-vous ici';
$lang['must_be_valid'] = 'Doit �tre valide';
$lang['characters'] = 'caract�res';
$lang['email'] = 'E-mail:';
$lang['age'] = 'Age';
$lang['years'] = 'ann�es';

$lang['all_states'] = 'Tous Etats';
//
// Ces termes sont utilises sur la page d'inscription
//
$lang['welcome'] = 'Bienvenu';
$lang['admin_welcome'] = 'Bienvenue <br /> au Paneau d\'administration <br />de SITENAME<br />';
$lang['title'] = 'Bienvenu sur SITENAME';
$lang['site_links'] = array(
	'home' => 'Accueil',
	'signup_now' => 'S\'enregistrer',
	'chat' => 'Tchat',
	'forum' => 'Forum',
	'login' => 'Connexion',
	'search' => 'Rechercher',
	'aboutus' => 'A propos de nous',
	'forgot' => 'Mot de passe/pseudo oubli�?',
	'contactus' => 'Contactez Nous',
	'privacy' => 'Vie Priv�e',
	'terms_of_use' => 'Termes d\'Utilisation',
	'services' => 'Services',
	'faq' => 'FAQ',
	'articles' => 'Articles',
	'affliates' => 'Affili�s',
	'invite_a_friend' => 'Inviter un Ami',
	'feedback' => 'Suggestions/Critiques'
	);

$lang['success_stories'] = 'Histoires de succ�s';
$lang['members_login'] = 'Connexion Usagers';
$lang['poll'] = 'Sondage';
$lang['news'] = 'Nouvelles';
$lang['articles'] = 'Articles';
$lang['poll_result'] = 'R�sultat du sondage';
$lang['view_poll_archive'] = 'Sondages pr�c�dents';
$lang['member_panel'] = 'Section usagers';
$lang['poll_errmsg1'] = 'Vous avez d�j� r�pondu � ce sondage. Essayez un autre sondage un autre jour.';
$lang['close'] = 'Ferm�';
$lang['all_stories'] = 'Toutes les histoires';
$lang['all_news'] = 'Toutes les nouvelles';
$lang['more'] = 'plus';
$lang['by'] = 'par';

$lang['dont_stay_alone'] = 'Ne restez pas seul,';
$lang['join_now_for_free'] = 'Inscrivez-vous maintenant et gratuitement!';
$lang['special_offer'] = 'Offre Sp�ciale!';
$lang['welcome_to'] = 'Bienvenue sur';
$lang['welcome_to_site'] = 'Bienvenue sur SITENAME';

$lang['offer_text'] = 'D�couvrez pourquoi SITENAME est le site de rencontres qui a le plus haut taux de croissance sur le web. Cr�ez votre  profil sur SITENAME et commencez la recherche de l\'�me soeur.';

$lang['newest_profiles'] = 'Profils les plus r�cents';

$lang['edit_profile'] = 'Modifier Profil';
$lang['total_profiles'] = 'Totalit� des Profils';
$lang['forgot'] = 'Avez-vous oubli� vos identifiants?';
$lang['hide'] = 'Cacher';
$lang['show'] = 'Montrer';
$lang['sex'] = 'Sexe:';
$lang['sex_without_colon'] = 'Sexe';
$lang['pageno'] = 'Page ';
$lang['page'] = 'Page';
$lang['previous'] = 'Pr�c�dent';
$lang['next'] = 'Prochain';
$lang['time_col'] = 'L\'heure:';

$lang['save_search'] = 'Sauvegarder la recherche';
$lang['find_your_match'] = 'Trouvez votre �me soeur';

$lang['extended_search'] = 'Recherche �tendue';
$lang['matches_found'] = 'Les profils suivants correspondent � vos crit�res.';
$lang['timezone'] = 'Fuseau horraire:';
$lang['next_section'] = 'Prochaine section';
$lang['sign_in'] = 'Identification des Usagers';
$lang['member_panel'] = 'Paneau Usager';
$lang['aff_panel'] = 'Paneau Affili�';
$lang['login_title'] = 'Espace de connexion des usagers';
$lang['sign_out'] = 'D�connexion';
$lang['login_submit'] = 'Connexion';

$lang['change_password'] = 'Changer de mot de passe';
$lang['old_password'] = 'Ancien mot de passe:';
$lang['new_password'] = 'Nouveau mot de passe:';
$lang['confirm_password'] = 'Confirmer le mot de passe:';
$lang['password_change_msg'] = 'Votre mot de passe a �t� chang� avec succ�s.';

$lang['section_signup_title'] = 'Information d\'enregistrement';
$lang['signup'] = 'S\'enregistrer';
$lang['section_basic_title'] = 'Informations de base';
$lang['section_appearance_title'] = 'Physique';
$lang['section_interests_title'] = 'Int�r�ts';
$lang['section_lifestyle_title'] = 'Train de vie';

$lang['signup_subtitle_login'] = 'D�tails de connexion';
$lang['signup_subtitle_profile'] = 'Mon Profil';
$lang['signup_subtitle_address'] = 'Adresse';
$lang['signup_subtitle_appearacnce'] = 'Physique';
$lang['signup_subtitle_preference'] = 'Pr�f�rences de recherche';

$lang['signup_username'] = 'Pseudo:';
$lang['signup_password'] = 'Mot de passe:';
$lang['signup_confirm_password'] = 'Confirmer le mot de passe:';

$lang['signup_firstname'] = 'Pr�nom:';
$lang['signup_lastname'] = 'Nom:';
$lang['signup_email'] = 'E-Mail:';
$lang['section_mypicture'] = 'Mes photos';
$lang['upload'] = 'Envoyer';
$lang['upload_pictures'] = 'Organizer les Photos';
$lang['upload_format_msgs'] = 'Seulement les fichiers .jpg ou .gif ou .png sont accept�s.';
$lang['thumbnail'] = 'Vignettes';
$lang['picture'] = 'Photo';
$lang['signup_picture'] = 'Ma photo';
$lang['signup_picture2'] = 'Ma photo 2:';
$lang['signup_picture3'] = 'Ma photo 3:';
$lang['signup_picture4'] = 'Ma photo 4:';
$lang['signup_picture5'] = 'Ma photo 5:';

$lang['signup_gender'] = 'Je suis un/une';
$lang['signup_pref_age_range'] = 'Plage des �ges pr�f�r�e';
$lang['signup_year_old'] = 'ans';
$lang['signup_birthday'] = 'Anniversaire:';
$lang['signup_country'] = 'Pays:';
$lang['signup_state_province'] = '�tat / Province:';
$lang['signup_zip'] = 'Code postal:';
$lang['signup_city'] = 'Ville / Village:';
$lang['signup_address1'] = 'Adresse, ligne 1:';
$lang['signup_address2'] = 'Adresse, ligne 2:';
$lang['signup_height'] = 'Taille';
$lang['signup_feet'] = 'pieds';
$lang['signup_meter_inches'] = 'pouces [ m�tres si hors des EU ]';
$lang['signup_weight'] = 'Poids:';
$lang['signup_pounds'] = 'livres [ kg si hors des EU ]';
$lang['signup_where_should_we_look'] = 'O� devrait-on chercher?';
$lang['signup_view_online'] = "Authoriser les autres usagers � voir quand je suis en ligne?";

$lang['signup_gender_values'] = array(
	'M' => 'Homme',
	'F' => 'Femme',
	'C' => 'Couple',
	'G' => 'Groupe'
	);

$lang['signup_gender_look'] = array(
	'M' => 'Homme',
	'F' => 'Femme',
	'C' => 'Couple',
	'G' => 'Groupe',
	'B' => 'Homme ou Femme',
	'A' => 'Peu importe'
	);

$lang['seeking'] = 'recherche';
$lang['looking_for_a'] = 'recherche';
$lang['looking_for'] = 'Recherche';

$lang['of'] = ' de ';
$lang['to'] = ' � ';
$lang['from'] = ' de ';
$lang['for'] = ' pour ';
$lang['yes'] = 'Oui';
$lang['no'] = 'Non';
$lang['cancel'] = 'Annuler';

$lang['change'] = 'Modifier';
$lang['reset'] = 'R�initialiser';

//Mots courrants

$lang['required_info_indication'] = 'indique les champs requis';
$lang['required_info_indicator'] = '* ';
$lang['required_info_indicator_color'] = 'Red';
$lang['click_here'] = 'Cliquer ici';

$lang['datetime_dayval']['Sun'] = 'Dim';
$lang['datetime_dayval']['Mon'] = 'Lun';
$lang['datetime_dayval']['Tue'] = 'Mar';
$lang['datetime_dayval']['Wed'] = 'Mer';
$lang['datetime_dayval']['Thu'] = 'Jeu';
$lang['datetime_dayval']['Fri'] = 'Ven';
$lang['datetime_dayval']['Sat'] = 'Sam';

$lang['error_msg_color'] = 'Red';
$lang['success_message'] = "L\'information a �t� sauvegard�e avec succ�s.<br />Vous serez automatiquement redirrig� vers la prochaine section dans 5 secondes. Au case o� la redirection automatique n'a pas lieu, Veuillez clicker sur le lien ci-dessous.";
$lang['sendletter_success'] = 'La lettre a �t� envoy�e avec succ�s.';


/*****************Section  Admin labels********************/

//labels courrants
$lang['admin_login_title'] = 'SITENAME Paneau d\'Administration';
$lang['home_title'] = 'SITENAME Accueil';
$lang['admin_title_msg'] = 'Section Admin';
$lang['admin_login_msg'] = 'Connexion Admin';
$lang['admin_panel'] = 'Paneau Admin';
$lang['back'] = 'Retour';
$lang['insert_msg'] = 'Ins�rez nouveau ';
$lang['question_mark'] = '?';
$lang['id'] = 'Id:';
$lang['name'] = 'Nom: ';
$lang['name_col'] = 'Nom';
$lang['enabled'] = 'Activ�:';
$lang['action'] = 'Action';
$lang['edit'] = 'Modifier';
$lang['delete'] = 'Supprimer';
$lang['section'] = 'Section:';
$lang['insert_section'] = 'Ins�rer nouvelle section';
$lang['modify_section'] = 'Modifier section';
$lang['modify_sections'] = 'Modifier sections';
$lang['delete_section'] = 'Supprimmer section';
$lang['delete_sections'] = 'Suprimmer sections';
$lang['enable_selected'] = 'Activer';
$lang['disable_selected'] = 'D�sactiver';
$lang['change_selected'] = 'Changer';
$lang['delete_selected'] = 'Supprimer';
$lang['no_select_msg'] = "Vous n\'avez pas s�lectionn� d\'options. Svp cliquez sur le bouton PR�C�DENT de votre navigateur web pour s�lectionner une ou plusieurs options.";
$lang['delete_confirm_msg'] = 'Voulez-vous r�ellement supprimer cette section?';
$lang['delete_group_confirm_msg'] = 'Voulez-vous r�ellement supprimer ces sections? Cette action est d�finitive.';
$lang['enabled_values'] = array(
	'Y' => 'Oui',
	'N' => 'Non'
	);
$lang['display_control_type'] = array(
	'checkbox' => 'Case � cocher',
	'radio' => 'Bouton d\'option',
	'select' => 'Menu d�roulant',
	'textarea' => 'Bo�te texte'
	);
$lang['admin_error_color'] = 'Red';

$lang['col_head_srno'] = '#';
$lang['col_head_id'] = 'Id';
$lang['col_head_question'] = 'Question';
$lang['col_head_enabled'] = 'Activ�';
$lang['col_head_name'] = 'Nom';
$lang['col_head_username'] = 'Pseudo';
$lang['col_head_firstname'] = 'Pr�nom';
$lang['col_head_lastname'] = 'Nom';
$lang['col_head_fullname'] = 'Nom Complet';
$lang['col_head_status'] = 'Statut';
$lang['col_head_gender'] = 'Sexe';
$lang['col_head_email'] = 'E-mail';
$lang['col_head_country'] = 'Pays';
$lang['col_head_city'] = 'Ville';
$lang['col_head_zip'] = 'Code postal';
$lang['col_head_register_at'] = 'Enregistr� le';

$lang['section_title'] = 'Gestion des Sections';
$lang['total_sections'] = 'Total des Sections:';
$lang['profile_title'] = 'Gestion de Profil';
$lang['total_profiles_found'] = 'Total des Profils Trouv�s:';
$lang['modify_profile'] = 'Modifier Profil';

$lang['profile_signup_title'] = 'Information d\'enregistrement';
$lang['profile_basic_title'] = 'Information de base';
$lang['profile_appearance_title'] = 'Physique';
$lang['profile_interests_title'] = 'Int�r�ts';
$lang['profile_lifestyle_title'] = 'Train de vie';

$lang['profile_subtitle_login'] = 'D�tails de Connexion';
$lang['profile_subtitle_profile'] = 'Profil';
$lang['profile_subtitle_address'] = 'Adresse';
$lang['profile_subtitle_appearacnce'] = 'Physique';
$lang['profile_subtitle_preference'] = 'Preferences';
$lang['profile_delete_confirm_msg'] = 'Etes-vous certain de vouloir supprimer ce profil?';
$lang['delete_profile'] = 'Supprimer le profil';
$lang['profile_username'] = 'Pseudo:';
$lang['profile_firstname'] = 'Pr�nom:';
$lang['profile_lastname'] = 'Nom:';
$lang['profile_email'] = 'E-mail:';
$lang['profile_gender'] = 'Sexe:';
$lang['profile_birthday'] = 'Anniversaire:';
$lang['profile_country'] = 'Pays:';
$lang['profile_state_province'] = 'Etat / Province:';
$lang['profile_zip'] = 'Code postal:';
$lang['profile_city'] = 'Ville';
$lang['profile_address1'] = 'Address, ligne 1:';
$lang['profile_address2'] = 'Address, ligne 2:';
$lang['find'] = 'Trouver';
$lang['search'] = 'Rechercher';
$lang['AND'] = 'et';
$lang['OR'] = 'ou';
$lang['order_by'] = 'Classer par: ';
$lang['sort_by'] = 'Classer par';
$lang['sort_types'] = array(
	'asc' => 'Croissant',
	'desc' => 'D�croissant'
	);
$lang['search_results'] = 'R�sultats de la recherche';
$lang['no_record_found'] = 'Aucune entr�e correspondante n\'a �t� trouv�e.';
$lang['search_options'] = 'Options de recherche';
$lang['search_simple'] = 'Recherche simplifi�e';
$lang['search_advance'] = 'Recherche';
$lang['search_advance_results'] = 'R�sultats de la recherche';
$lang['search_country'] = 'Recherche par pays';
$lang['search_states'] = 'Recherche par �tats ou provinces';
$lang['search_zip'] = 'Recherche par code postal';
$lang['search_city'] = 'Recherche par ville';
$lang['search_wildcard_msg'] = 'Vous pouvez mettre une * dans la case de recherche pour avoir tous les r�sultats.';
$lang['search_location'] = '<b>Recherche par lieux de r�sidence:</b>';
$lang['select_state'] = 'Etat ou Province:';
$lang['enter_city'] = 'Ville:';
$lang['enter_zip'] = 'Code postal:';
$lang['enter_username'] = 'Pseudo:';
$lang['results_per_page'] = 'R�sultats par pages';
$lang['search_results_per_page'] = array( 2 => 2, 5 => 5 , 10 => 10, 20 => 20, 50 => 50, 100 => 100 );
$lang['order'] = 'Ordre';
$lang['up'] = 'Haut';
$lang['down'] = 'Bas';

$lang['question'] = 'Question:';

$lang['maxlength'] = 'Longeur maximum:';
$lang['description'] = 'Description:';
$lang['mandatory'] = 'Obligatoire:';
$lang['guideline'] = 'Directive:';
$lang['control_type'] = 'Contr�le d\'affichage:';
$lang['include_extsearch'] = 'Inclure dans la recherche �tendue:';
$lang['head_extsearch'] = 'Ent�te de la recherche �tendue:';

$lang['delete_question'] = 'Supprimer la Question';
$lang['modify_question'] = 'Modifier la Question';
$lang['questions_title'] = 'Gestion des Questions';
$lang['total_options'] = 'Total des Options:';
$lang['insert_question'] = 'Ins�rer nouvelles questions';
$lang['total_questions'] = 'Total des Questions:';
$lang['delete_questions'] = 'Supprimer les questions';
$lang['delete_group_questions_confirm_msg'] = 'Etes-vous certain de vouloir supprimer ces questions? Cette action est irr�versible';

$lang['option'] = 'Options';
$lang['answer'] = 'R�ponse';
$lang['options_title'] = 'Options de la question';
$lang['col_head_answer'] = 'R�ponse';
$lang['with_selected'] = 'Avec la s�lection';
$lang['ranging'] = 'D\'intervalle';

// Messagerie instantann�e
$lang['instant_messenger'] = 'Tchat';
$lang['instant_message'] = 'Message Tchat';
$lang['im_from'] = 'De:';
$lang['im_message'] = 'Message:';
$lang['im_reply'] = 'R�ponse';
$lang['close_window'] = 'Fermer la fen�tre';

// my matches
$lang['my_matches'] = 'Mes �mes soeurs';
$lang['i_am_a'] = 'Je suis un/une';
$lang['Between'] = 'entre';
$lang['who_is_from'] = 'Qui est de';
$lang['showing'] = 'Montrant';
$lang['your_search_preferences'] = 'Vos pr�f�rences de recherches:';
$lang['to_edit_search_preferences'] = 'pour modifier vos pr�f�rences de recherches';

$lang['unapproved_user'] = 'Profils � �tre approuv�s';
$lang['gbl_settings'] = 'Configuration G�n�rale du Site';
$lang['configurations'] = 'Configurations';
$lang['col_head_variable'] = 'Variable';
$lang['col_head_value'] = 'Valeur';

$lang['affiliate_title'] = 'Gestion des Affili�s';
$lang['col_head_counter'] = 'Conteur';
$lang['col_head_status'] = 'Statut';

$lang['tell_later'] = 'Je vous le dirai plus tard';
$lang['view_profile'] = 'Voir le profil';
$lang['view_profile_errmsg1']  = 'Vous n\'avez toujours pas sp�cifi� vos pr�f�rences.<br />Svp sp�cifiez les d�tails de votre profil en premier.<br />';
$lang['view_profile_errmsg2'] = '<br />Cliquez ici pour sp�cifier vos pr�f�rences maintenant.';
$lang['view_profile_errmsg3'] = 'Cet usager n\'a pas encore remplis les d�tails de son profil.';
$lang['view_profile_restricted'] = 'Ce profil est restreint, vous ne pouvez pas le voir.';
$lang['profile_notset'] = 'Pas de profil correspondant � cet usager.';
$lang['send_mail'] = 'Envoyer un message';
$lang['mail_messages'] = 'Messages';
$lang['col_head_subject'] = 'Sujet';
$lang['col_head_sendtime'] = 'Date';

$lang['inbox'] = 'Bo�te de r�ception';
$lang['sent'] = 'Envoy�';
$lang['trashcan'] = 'Poubelle';
$lang['reply'] = 'R�ponse';
$lang['read'] = 'Lu';
$lang['unread'] = 'Non lu';
$lang['restore'] = 'Restorer';
$lang['subject'] = 'Sujet';
$lang['subject_colon'] = 'Sujet:';
$lang['message'] = 'Message';
$lang['send'] = 'Envoyer';

$lang['send_letter'] = 'Envoyer une Lettre';
$lang['image_browser'] = 'Album Photos';
$lang['upload_image'] = 'Envoyer la Photo';
$lang['delete_image'] = 'Supprimer la Photo';
$lang['show_image'] = 'Montrer la Photo';
$lang['send_invite'] = 'Envoyer une Invitation';
$lang['letter_title'] = 'Nouvelle lettre';
$lang['from_email'] = 'Votre e-mail:';
$lang['from_name'] = 'Votre nom:';
$lang['send_to'] = 'Envoyer';
$lang['email_subject'] = 'Sujet:';
$lang['save_as'] = 'Enregistrer sous';

$lang['no_message'] = 'Pas de nouveaux messages dans votre bo�te de r�ception.';
$lang['descrip'] = 'Description';

//forgot password words
$lang['forgotpass_msg1'] = "Rappel d'identifiants";
$lang['forgotpass_msg2'] = "Veuillez nous fournir l'e-mail utilis� lors de la cr�ation de votre profil pour recevoir votre pseudo et un nouveau mot de passe. Apr�s la r�ception du nouveau mot de passe, vous �tes conseill� de changer celui-ci imm�diatement pour des raisons de s�curit�.";
$lang['retreieve_info'] = 'Envoyer';
$lang['forgotpass'] = 'Mot de passe oubli�';

//Tell a friend
$lang['tellafriend'] = 'Invitez un ami';
$lang['taf_msg1'] = 'Invitez un ami sur SITENAME';
$lang['taf_yourname'] = 'Votre nom:';
$lang['taf_youremail'] = 'Votre e-mail:';
$lang['taf_friendemail'] = "E-mail de votre ami:";

//Auto-mail
$lang['confirm_your_profile'] = 'Confirmez votre inscription';
$lang['letter_not_avail'] = 'Lettre gabarit  non disponnible';
$lang['confirm_letter_sent'] = 'Un e-mail de confirmation a �t� envoy� � l\'adresse fournie au moment de votre inscription. Veuillez clicker sur le lien de confirmation pour compl�ter votre enregistrement.';
$lang['letter_not_sent'] = 'Il y a eu un probl�me lors de l\'envoi de l\'e-mail. Veuillez contacter un administrateur.';
$lang['or'] = 'Ou';
$lang['enter_confirm_code'] = 'Entrez votre code de confirmation pour compl�ter le processus d\'enregistrement.';
// Affiliate auto-mail

$lang['aff_email_subject'] = 'Confirmez votre compte affili�';
$lang['aff_email_body'] = 'Merci d\'avoir cr�� votre compte affili� avec SITENAME. Veuillez entrer cet URL dans la barre d\'adresse de votre naviguateur web pour compl�ter votre inscription affili�:<br><br>#ConfirmationLink#';

//Page management

$lang['manage_pages'] = 'Gestion des Pages';
$lang['pagetitle'] = 'Titre:';
$lang['pagetext'] = 'Texte:';
$lang['pagekey'] = 'Clef:';
$lang['addpage'] = 'Ajouter la page';
$lang['page'] = 'Page:';
$lang['addnew'] = 'Ajouter Nouvelle';
$lang['modpage'] = 'Modifier la page';
$lang['pagekey_help'] = 'www.yourdomain.com/index.php?page=YOUR_KEY';

$lang['y_o'] = 'y/o';
$lang['lastlogged'] = 'Derni�re visite: ';
$lang['aff_stats'] = 'Statistiques des Affili�s';
$lang['total_referrals'] = 'Total des r�f�rences';
$lang['regis_referals'] = 'R�f�rences enregistr�es';
$lang['globalconfigurations'] = 'Configuration globale';

$lang['send_message_to'] = 'Envoyer un message �';
$lang['writing_message'] = 'Ecrire message pour ';
$lang['search_at'] = 'Chercher � ';

//Rating module
$lang['rate_profile'] = 'Notez le profil';
$lang['worst'] = 'Le Pire';
$lang['excellent'] = 'Excellent';
$lang['rating'] = 'Note';
$lang['submitrating'] = 'Soumettre la note';

//Payment Modules
$lang['mship_changed'] = 'Abonnement modifi�';
$lang['mship_changed_successfull'] = 'Votre abonnement a �t� chang� � Gratuit.';
$lang['no_payment'] = 'Aucun paiement requis (Gratuit)';
$lang['payment_modules'] = 'Modules de paiement';
$lang['payment_methods'] = 'M�thodes de paiement';
$lang['business'] = 'Entreprise:';
$lang['siteid'] = 'Num�ro:';
$lang['undefined_quantity'] = 'Quantit� ind�finie:';
$lang['no_shipping'] = 'Pas de transport:';
$lang['no_note'] = 'pas de Note:';
$lang['on_off_values'] = array( 1 => 'Oui', 0 => 'Non' );
$lang['edit_payment_modules'] = 'Modifier modules de paiement';
$lang['trans_key'] = 'Clef de transaction:';
$lang['trans_mode'] = 'Mode de transaction:';
$lang['trans_method'] = 'M�thode de transaction:';
$lang['username'] = 'Pseudo:';
$lang['username_without_colon'] = 'Pseudo';
$lang['country'] = 'Pays';
$lang['country_colon'] = 'Pays:';
$lang['state'] = 'Etat';
$lang['city'] = 'Ville';
$lang['location_col'] = 'R�gion:';
$lang['location_no_col'] = 'R�gion';
$lang['zip_code'] = 'Code Postal';
$lang['attached_files'] = 'Fichiers joints';
$lang['cc_owner'] = 'Propri�taire de la carte de cr�dit:';
$lang['cc_number'] = 'Num�ro de la carte de cr�dit:';
$lang['cc_type'] = 'Type de carte de cr�dit:';
$lang['cc_exp_date'] = 'Date d\'expiration de la carte de cr�dit:';
$lang['cc_cvv_number'] = 'Num�ro de v�rification de la carte de cr�dit (3 chiffres):';
$lang['cvv_help'] = '(localis� derri�re la carte de cr�dit)';
$lang['continue'] = 'Poursuivre';
$lang['trans_method_vals'] = array(
	'CC' => 'Carte de cr�dit',
	'ECHECK' => 'Cheque Electronique'
	);
$lang['trans_mode_vals'] = array(
	'AUTH_CAPTURE' => 'AUTH_CAPTURE',
	'AUTH_ONLY' => 'AUTH_ONLY',
	'CAPTURE_ONLY' => 'CAPTURE_ONLY',
	'CREDIT' => 'CREDIT',
	'VOID' => 'VOID',
	'PRIOR_AUTH_CAPTURE' => 'PRIOR_AUTH_CAPTURE'
 );
$lang['cc_unknown'] = 'Compagnie de carte de cr�dit inconnue. Veuillez essayer de nouveau avec une carte de cr�dit valide.';
$lang['cc_invalid_date'] = 'Expiration de la carte de cr�dit invalide. Veuillez essayer de nouveau avec une carte de cr�dit valide.';
$lang['cc_invalid_number'] = 'Num�ro de carte de cr�dit invalide. Veuillez essayer de nouveau avec une carte de cr�dit valide.';
$lang['amount'] = 'Montant: ';
$lang['confirmation'] = 'Confirmation';
$lang['confirm'] = 'Confirmez';
$lang['upgrade_membership'] = 'Surclasser abonnement';
$lang['changeto'] = 'Changer pour';
$lang['current_mship_level'] = 'Niveau actuel:';
$lang['membership_status'] = 'Statut d\'abonnement';
$lang['you_currently'] = 'Vous �tes actuellement ';
$lang['info_confirm'] = 'Les informations suivantes sont-elles correctes?';
$lang['change_mship_to'] = 'Changer l\'abonnement pour ';
//Membership
$lang['permitmsg_1'] = 'D�sol� votre abonnement n\'inclue pas';
$lang['permitmsg_2'] = 'Veuillez changer votre abonnement pour utiliser ';
$lang['permitmsg_3'] = 'Charte de comparaison des abonnements';
$lang['permitmsg_4'] = 'Cacher la charte des abonnements';
$lang['membership_packages'] = 'Abonnements offerts';
$lang['membership_packages_compare'] = 'Comparaison des abonnements offerts';
$lang['modify'] = 'Sauvegarder les changements';
$lang['manage_membership'] = 'Gestion des abonnements';
$lang['privileges_msg'] = 'Privil�ges';
$lang['price'] = 'Prix: ';
$lang['currency'] = 'Devise: ';
$lang['choose_membership'] = 'Choisir un abonnement:';
$lang['add_membership'] = 'Ajouter un nouvel abonnement';
$lang['membership_types'] = 'Types d\'abonnement';
$lang['member'] = 'usager';

$lang['select_letter'] = 'Choisir une lettre:';
$lang['body'] = 'Corps:';
$lang['module'] = 'Module';
$lang['uninstall'] = 'D�sinstaller';
$lang['install'] = 'Installer';
$lang['modify_option'] = 'Modifier option';

$lang['only_jpg'] = 'Seulement les formats JPG ou GIF ou PNG sont authoriz�s.';
$lang['upload_unsuccessful'] = 'Echec lors de l\'envoie des photos.';
$lang['upload_successful'] = 'Photos envoy�es avec succ�s.';
$lang['between1'] = 'Entre';
$lang['and'] = 'et';
$lang['profile_details'] = 'D�tails du profil';
$lang['personal_details'] = 'D�tails personnels';


//Banner Management
$lang['manage_banners'] = 'Gestion des Banni�res';
$lang['add_banners'] = 'Ajouter une banni�re';
$lang['edit_banners'] = 'Modifier banni�re';
$lang['size'] = 'Grandeur';
$lang['size_px'] = 'Grandeur (px)';
$lang['banner_linkurl'] = 'Banni�re / Lien URL';
$lang['banner_sizes'] = array(
	'468x60' => '468 x 60',
	'100X500'=>'100 x 500',
	'120x120'=>'120 x 120'
);
$lang['banner_sizes_name'] = array( 'horizontal', 'vertical', 'carr�' );
$lang['startdate'] = 'Date d�but:';
$lang['enddate'] = 'Date fin:';
$lang['tooltip'] = 'Outils:';
$lang['linkurl'] = 'Lien Url:';
$lang['banner'] = 'Banni�re:';
$lang['total_banner'] = 'Total des banni�res:';
$lang['online_users'] = 'Usagers en ligne: ';
$lang['site_statistics'] = 'Statistiques du site';
$lang['pending_profiles'] = 'Profils en attente';
$lang['active_profiles'] = 'Profils actifs';
$lang['online_profiles'] = 'Profils en ligne';
$lang['pending_aff'] = 'Affili�s en attente';
$lang['total_affiliates'] = 'Total des affili�s';
$lang['active_aff'] = 'Affili�s Actifs';
$lang['no_rating'] = 'Pas de note';

//SEO Words
$lang['seo'] = 'Param�tres SEO';
$lang['seo_head'] = 'Optimisation pour moteur de recherches';
$lang['sef_msg'] = 'URLs facilement indexable par les moteurs de recherches';
$lang['seo_enable'] = 'Activer la r��criture de l\'URL (en utilisant mod_rewrite):';
$lang['yes_msg'] ='L\'option r��criture de l\'URL n\'est que disponnible si vous utilisez un serveur Apache, Avec l\'extension mod_rewrite activ�. Veuillez vous assurez que votre serveur r�pond � ces crit�res. Aussi veuillez vous souvenir de renommer le fichier .htaccess.txt avec le nom .htaccess.';
$lang['keywords'] = 'Mots clefs:';
$lang['page_tags_msg'] = 'Titre de la page & balises Meta';
$lang['max_255'] = 'Maximum 255 characters';

//News / Story / Article Manangement
$lang['manage_news'] = 'Gestion des Nouvelles';
$lang['manage_story'] = 'Gestion des Histoires';
$lang['manage_article'] = 'Gestion des Articles';
$lang['news_header'] = 'Ent�te';
$lang['total_news'] = 'Total des Nouvelles:';
$lang['total_articles'] = 'Total des Articles:';
$lang['total_stories'] = 'Total des Histoires:';
$lang['article_title'] = 'Titre';
$lang['story_sender'] = 'Exp�diteur';
$lang['story_sender_msg'] = 'ID du Profil [Num�ro]';
$lang['modify_article'] = 'Modifier l\'article';
$lang['modify_news'] = 'Modifier la nouvelle';
$lang['modify_story'] = 'Modifier l\'histoire';
$lang['insert_article'] = 'Ajouter un Article';
$lang['insert_story'] = 'Ajouter une Histoire';
$lang['insert_news'] = 'Ajouter une Nouvelle';
$lang['dat'] = 'Date:';

//Poll Words
$lang['manage_polls'] = 'Gestion des Sondages';
$lang['modify_poll'] = 'Modifier le Sondage';
$lang['total_polls'] = 'Total des Sondages';
$lang['poll'] = 'Sondage';
$lang['add_polls'] = 'Ajouter un Sondage';
$lang['add_options'] = 'Ajouter des Choix';
$lang['active'] = 'Actif';
$lang['activate'] = 'Activer';
$lang['option'] = 'Choix';
$lang['modify_options'] = 'Modifier les Choix';
$lang['add_option_now'] = 'Ajouter un choix maintenant.';
$lang['poll_options'] = 'Choix du Sondage';
$lang['votes'] = 'Vote(s)';
$lang['first'] = 'Premier';
$lang['last'] = 'Dernier';
$lang['filter_records'] = 'Enregistrement des filtres';
$lang['search_at'] = 'Recherche';
$lang['criteria'] = 'Crit�res';

//Admin Management
$lang['manage_admins'] = 'Gestion des Admin';
$lang['total_admins'] = 'Total des Admins';
$lang['add_admin'] = 'Ajouter un Admin';
$lang['modify_admin'] = 'Modifier un Admin';
$lang['fullname'] = 'Nom Complet';
$lang['please_be_sure'] = 'Svp soyez certain de';
$lang['change_your_admin_pwd'] = 'Changer mot de passe Admin.';
$lang['superuser'] = 'Super Usager';
$lang['no_admin_user_msg1'] = 'Aucun admin non-Super Usager. Veuillez en cr�er un d\'abord.';
$lang['no_admin_user_msg2'] = 'Pour cr�er un nouvel usager Admin maintenant';
$lang['access_denied'] = 'Acc�s refus�';
$lang['not_authorize'] = 'Vous n\'�tes pas autoris� � cette page. Veuillez contacter votre Super Admin.';

//Admin Permissions Management
$lang['admin_permissions'] = 'Pouvoirs des Admins';
$lang['manage_admin_permissions'] = 'Gestion des permissions Admin';
$lang['admin_users'] = 'Usagers Admin';
$lang['permissions'] = 'Modules';
$lang['superuser_noteditable'] = 'Note: Les Super Usager ne sont pas modifiables.';
$lang['all'] = 'Tous';
$lang['selected'] = 'S�lectionn�';
$lang['selected_users'] = 'Usagers s�lectionn�s';
$lang['separate_users_by_coma'] = 'Entrez les pseudos s�par�s par des virgules';
$lang['admin_rights'] = array(
		'site_stats' 				=> 'Statistiques du Site',
		'profie_approval'		 	=> 'Profils � Approuver',
		'profile_mgt' 				=> 'Gestion des Profils',
		'section_mgt' 				=> 'Gestion des Sections',
		'affiliate_mgt' 			=> 'Gestion des Affili�s',
		'affiliate_stats'		 	=> 'Statistiques des Affili�s',
		'news_mgt' 					=> 'Gestion des Nouvelles',
		'article_mgt' 				=> 'Gestion des Articles',
		'story_mgt'					=> 'Gestion des Histoires',
		'poll_mgt'		 			=> 'Gestion des Sondages',
		'search' 					=> 'Recherche',
		'ext_search'				=> 'Recherche Etendue',
		'send_letter' 				=> 'Envoyer une Lettre',
		'pages_mgt' 				=> 'Gestion des Pages',
		'chat' 						=> 'Tchat',
		'chat_mgt' 					=> 'Gestion du Tchat',
		'forum_mgt' 				=> 'Gestion du Forum',
		'mship_mgt' 				=> 'Gestion des Abonnements',
		'payment_mgt' 				=> 'Modules de Paiements',
		'banner_mgt' 				=> 'Gestion des Banni�res',
		'seo_mgt' 					=> 'Param�tres SEO',
		'admin_mgt' 				=> 'Gestion des Admins',
		'admin_permit_mgt'			=> 'Permissions des Admins',
		'global_mgt' 				=> 'Configurations G�n�rales',
		'change_pwd'				=> 'Changer de Mot de passe',
		'cntry_mgt'					=> 'Gestion des Pays/Etats/Provinces/Villes',
		'snaps_require_approval'	=> 'Approuver les Photos',
		'featured_profiles_mgt'		=> 'Profils Distingu�s ',
		'calendar_mgt'				=> 'Calendrier',
		'event_mgt'					=> 'Approuver les Ev�nements',
		'import_mgt'				=> 'Importer',
	/* Added in 2.0 */
      	'plugin_mgt'            	=> 'Gestion des Plugins',
		'blog_mgt'					=> 'Gestion des Blogs',
		'profile_ratings'			=> 'Gestion des Notes pour les profils',
		);

$lang['cntry_mgt']	= 'Gestion des Pays / Etats /Provinces / Villes';
$lang['register_now'] = 'Enregistrez-vous maintenant pour rejoindre notre communaut�!';
$lang['addtobuddylist'] = 'Ajouter � ma liste d\'amis';
$lang['addtobanlist'] = 'Ajouter � ma liste des usagers bannis';
$lang['addtohotlist'] = 'Ajouter � ma Liste � Hot �';
$lang['buddylisthdr'] = 'Liste d\'amis';
$lang['banlisthdr'] = 'liste d\'usagers bannis';
$lang['hotlisthdr'] = 'Liste � Hot �';
$lang['username_hdr'] = 'Pseudo';
$lang['fullname_hdr'] = 'Nom Complet';
$lang['register'] = 'Inscrivez-vous';
$lang['featured_profiles'] = 'Profils Distingu�s';
$lang['bigger_pic_size'] = 'La taille du fichier photo d�passe la taille permise de '.$config['upload_snap_maxsize'].' KB.';
$lang['snaps_require_approval'] = 'Approuver les photos';
$lang['events_require_approval'] = 'Approuver les �v�nements';
$lang['upload_picture_caption'] = 'Image';
$lang['upload_thumbnail_caption'] = 'Miniature ';
$lang['Approve'] = 'Approuver';
$lang['Remove'] = 'Supprimer';
$lang['userdetails'] = 'Information usager';
$lang['pict'] = 'Photo';
$lang['tnail'] = 'Miniature';
$lang['reqact'] = 'Action d�sir�e';
$lang['newmemberlist'] = 'Usagers R�cents';
$lang['yearsold'] = 'ans';
$lang['Male'] = 'Homme';
$lang['Female'] = 'Femme';
$lang['showfulllist'] = 'Montrer la liste compl�te';
$lang['featuredprofiles'] = 'Profils Distingu�s';
$lang['featured_profiles_hdr'] = 'Profils des Usagers Distingu�s';
$lang['nonfeatured_profiles_hdr'] = 'Usagers Normaux';
$lang['level_hdr'] = 'Niveau';
$lang['date_from'] = 'Date de d�but';
$lang['date_upto'] = 'Date de fin';
$lang['must_show'] = 'Doit montrer';
$lang['reqd_exposures'] = 'Expositions requises';
$lang['total_exposures'] = 'Total des expositions';
$lang['add_featured'] = 'Ajouter le profil dans la liste distingu�e';
$lang['mod_featured'] = 'Modifier le profil dans la liste distingu�e';
$lang['member_since'] = 'Usager depuis';
$lang['invalid_username'] = 'Pseudo invalide';
$lang['weekcnt'] = 'Usagers connect�s la semaine derni�re:';
$lang['totalgents'] = 'Nombre d\'Hommes:';
$lang['totalfemales'] = 'Nombre de Femmes:';
$lang['weeksnaps'] = 'Nouvelles photos:';
$lang['since_last_login'] = 'depuis votre derni�re visite';
$lang['sincelastlogin_hdr'] ='Depuis votre derni�re visite';
$lang['newmessages'] = 'Nouveaux messages re�us:';
$lang['profileviewed'] = 'Personnes ayant lu mon profil:';
$lang['winks_received'] = 'Nombre de clin d\'oeils re�us:';
$lang['send_wink'] = 'Envoyer un clin d\'oeil';
$lang['listofviews'] = 'Liste des usagers qui ont lu votre profil';
$lang['listofwinks'] = 'Liste des usagers qui vous ont envoy� un clin d\'oeil';
$lang['winkslist'] = 'Liste des clin d\'oeils';
$lang['viewslist'] = 'Liste de ceux qui ont vu votre profil';
$lang['suggest_poll'] = 'Sugg�rer un sondage';
$lang['savepoll'] = 'Soumettre un sondage';
$lang['moreoptions'] = 'Plus de choix';
$lang['minimum_options'] = 'Minimum de deux choix n�cessaires';
$lang['pollsuggested'] = 'Merci! Votre suggestion de sondage a �t� envoy�e � un administrateur.';
$lang['suggested_by'] = 'Sugg�r� par:';
$lang['any_where'] = 'N\'importe o�';
$lang['memberpanel'] = "Page d\'accueil des usagers";
$lang['feedback_thanks'] = 'Merci de votre commentaire. Votre message a �t� transmit � un administrateur.';
$lang['cancel_hdr'] = 'Annuler votre abonnement';
$lang['cancel_txt01'] = 'Vous avez demand� d\'annuler votre abonnement sur <b>SITENAME</b>.<br /><br />En �tes vous certain? ';
$lang['cancel_opt01'] = 'Oui, Je suis certain';
$lang['cancel_opt02'] = 'Non, Je ne d�sire pas annuler maintenant';
$lang['cancel_domsg'] = 'Nous vous remercions d\'avoir utilis� SITENAME <br><br>Nous regrettons votre d�part, revenez nous voir quand bon vous semblera, et nous esp�rons que vous avez trouv� nos services utiles. ';
$lang['cancel_nomsg'] = 'Nous vous remercions d\'utilis� SITENAME.<br><br>Nous appr�cions votre pr�sence continu�e, et nous esp�rons que vous trouvez nos services utiles.';
$lang['reject'] = 'Rejeter';
$lang['unread'] = 'Non lu';
$lang['membership_hdr'] = 'Niveau d\'usager';
$lang['edit_pict'] = 'Modifier votre image principale';
$lang['edit_thmpnail'] = 'Modifier la miniature';
$lang['letter_options'] = 'Options des Lettres';
$lang['pic_gallery'] = 'Photos';
$lang['reactivate'] = 'R�activer Usagers';
$lang['cancel_list'] = 'Liste des usagers annul�s';
$lang['cancel_date'] = 'Date d\'annulation';
$lang['language_opt'] = 'Option de langue' ;
$lang['change_language'] = 'Changer la langue';
$lang['with_photo'] = 'avec photo';
$lang['logintime'] = 'Dur�e de connexion';
$lang['manage_country_states'] = 'Gestion des Pays/Etats';
$lang['manage_countries'] = 'Gestion des Pays';
$lang['countries_count'] = 'Nombre de Pays';
$lang['insert_country'] = 'Ajouter un nouveau Pays';
$lang['modify_country'] = 'Modifier un Pays';
$lang['country_code'] = 'Code du Pays';
$lang['country_name'] = 'Nom du Pays';
$lang['manage_states'] = 'Gestion des Etats';
$lang['states_count'] = 'Nombre des Etats';
$lang['insert_state'] = 'Ajouter un nouvel Etat';
$lang['modify_state'] = 'Modifier un Etat';
$lang['state_code'] = 'Code des Etats';
$lang['state_name'] = 'Nom des Etats';
$lang['totalcouples'] = 'Nombre de Couples:';
$lang['active_days'] = 'Valide pour combien de jours?';
$lang['activedays_array'] = array('1'=>'1','7'=>'7','30'=>'30','90'=>'90','180'=>'180','365'=>'365','999'=>'999' );
$lang['expired'] = 'Votre abonnement est expir�. <a href="payment.php" class="errors">Renouvellez votre abonnement</a> et continuez de profiter des avantages de SITENAME';
$lang['compose'] = 'Composer';

$lang['logout_login']='Pour v�rifier votre nouveau mot de passe, veuillez vous D�connect� et vous Reconnect�, merci.';
$lang['makefeatured'] = 'Cliquez sur l\'�toile pour ajouter ce profil � la liste des Profils Distingu�s';
$lang['col_head_gender_short'] = 'Sexe';
$lang['no_subject'] = 'Pas de sujet';
$lang['admin_col_head_fullname'] = $lang['col_head_fullname'];
$lang['select_from_list'] = '--Choisir--';

$lang['default_tz'] = '0.00';

$lang['manage_counties'] = 'R�gions';
$lang['counties_count'] = 'No. de R�gions';
$lang['insert_county'] = 'Ajouter nouvelle comt�/quartier ';
$lang['modify_county'] = 'Modifier comt�/quartier ';
$lang['county_code'] = 'Comt�/Quartier  Code';
$lang['county_name'] = 'Comt�/Quartier  Nom';
$lang['manage_cities'] = 'Villes/Villages';
$lang['cities_count'] = ' No. de Villes/Villages';
$lang['insert_city'] = 'Ajouter Ville/Village';
$lang['modify_city'] = 'Modifier Ville/Village';
$lang['city_code'] = 'Ville/Village Code';
$lang['city_name'] = 'Ville/Village Nom';
$lang['manage_zips'] = 'Codes Postals';
$lang['zips_count'] = 'No. de Codes postaux';
$lang['insert_zip'] = 'Ajouter code postal';
$lang['modify_zip'] = 'Modifier code postal';
$lang['zip_code'] = 'Code Postal';
$lang['show_form'] = 'Montrer le formulaire:';
$lang['change_album'] = 'Mettre � jour';


/* Following array is for Profile Window display heading conversion */
$lang['extsearchhead'] = array(
	'Marital Status'		=> 'Statut civil',
	'Ethnicity'				=> 'Ethnie',
	'Religion'				=> 'Religion',
	'Hobbies'				=> 'Passes temps',
	'Height'				=> 'Taille',
	'Body Type'				=> 'Type de corps',
	'Zodiac Sign'			=> 'Signe du zodiaque',
	'Eye color'				=> 'Couleur des yeux',
	'Hair color'			=> 'Couleur des cheveux',
	'Body art'				=> 'Art corporel',
	'Best feature'			=> 'Ce que vous trouvez le mieux chez vous (physiquement)',
	'Hot spots'				=> 'Endroits � hot �',
	'Sports'				=> 'Sports',
	'Favorite things'  		=> 'Choses Favoris',
	'Last reading'			=> 'Derni�re lecture',
	'Common interests'		=> 'Int�r�ts communs',
	'Sense of humor'		=> 'Humour',
	'Exercise'				=> 'Exercice',
	'Daily diet'			=> 'Di�te journali�re',
	'Smoking'				=> 'Cigarette',
	'Drinking'				=> 'Boisson',
	'Job schedule'			=> 'Horraire de travail',
	'Current annual income' => 'Salaire annuel',
	'Living situation'		=> 'Situation familiale',
	'Kids'					=> 'Enfants',
	'Want children'			=> 'Veux des enfants',
	'Weight'				=> 'Poids',
	'Employment status'		=> 'Statut d\'emploi',
	'Education'				=> 'Education',
	'Languages'				=> 'Langues',
	'Referred by'			=> 'R�f�r� par',
);

/* user_stats */

$lang['your_user_stats'] = 'Vos statistiques d\' usager';
$lang['other_user_stats'] = 'Autres statistiques d\'usager';

$lang['user_stats'] = 'Statistiques d\' usager';
$lang['users_match_your_search'] = 'Usagers correspondant � vos crit�res de recherche';
$lang['in_your_country'] = 'Usagers demeurant dans votre pays';
$lang['in_your_state'] = 'Usagers demeurant dans votre �tat/province';
$lang['in_your_county'] = 'Usagers demeurant dans votre comt�/quartier';
$lang['in_your_city'] = 'Usagers demeurant dans votre ville/village';
$lang['in_your_zip'] = 'Usagers demeurant dans votre code postal';
$lang['in_same_gender'] = 'Usagers qui sont de votre sexe';
$lang['in_same_age'] = 'Usagers qui ont votre �ge';
$lang['above_lookagestart'] = 'Usagers plus ag�s que ma limite maximum';
$lang['below_lookageend'] = 'Usagers moins ag�s que ma limite minimum';
$lang['your_lookgender'] = 'Usagers correspondant � vos pr�f�rences de sexe';
$lang['in_look_country'] = 'Usagers qui demeurent dans votre pays';
$lang['in_look_state'] = 'Usagers demeurant dans votre �tat/province';
$lang['in_look_county'] = 'Usagers demeurant dans votre comt�/quartier ';
$lang['in_look_city'] = 'Usagers demeurant dans votre ville/village';
$lang['in_look_zip'] = 'Usagers demeurant dans votre code postal';
$lang['in_same_timezone'] = 'Usagers demeurant dans votre fuseau horraire';
$lang['album_hdr'] = 'Album';
$lang['public'] = 'Publique';
$lang['calendar_admin'] = 'Calendrier Admin';

$lang['mysettings'] = 'Mes Param�tres';
$lang['user_lists'] = 'Dossiers';
$lang['login_settings'] = 'Param�tres de connexion';
$lang['no_pics'] = 'Aucune photo';
$lang['my_page'] = 'Ma page';
$lang['write_new_msg'] = 'Ecrire un nouveau message';
$lang['view_winkslist'] = 'Voir les clins d\'oeils';

// Import module
$lang['manage_import'] = 'Importer';
$lang['manage_import_datingpro'] = 'Importer de DatingPro';
$lang['manage_import_aedating'] = 'Importer de aeDating';
$lang['manage_import_section'] = 'Choisir Module d\'Import';
$lang['manage_import_select'] = 'Choisir quoi importer';
$lang['module'] = 'Module';
$lang['imported'] = 'Import�';
$lang['import'] = 'Importer';
$lang['empty'] = 'Vide';
$lang['select_section'] = 'Choisir la section';
$lang['import_db_configuration'] = 'Importer les configurations de la base de donn�e';
$lang['db_name'] = 'DB Nom:';
$lang['db_host'] = 'DB Host:';
$lang['db_user'] = 'DB usager:';
$lang['db_pass'] = 'DB Mot de passe:';
$lang['db_prefix'] = 'Tables Prefix:';


// Calendar
$lang['calendar_title'] = 'Gestion du Calendrier';
$lang['total_calendars'] = 'Total des calendriers:';
$lang['modify_calendar'] = 'Modifier le calendrier';
$lang['modify_calendars'] = 'Modifier les calendriers';
$lang['delete_calendar'] = 'Supprimer le calendrier';
$lang['delete_calendars'] = 'Supprimer les calendriers';

// Calendar Events
$lang['events_title'] = 'Gestion des �v�nements';
$lang['insert_event'] = 'Ajouter un �v�nement';
$lang['modify_event'] = 'Modifier un �v�nement';
$lang['total_events'] = 'Ev�nements s�lectionn�s';
$lang['event'] = 'Ev�nement:';
$lang['calendar_field'] = 'Calendrier:';
$lang['private_to'] = 'Priv� �:';
$lang['date_from'] = 'Date de:';
$lang['date_to'] = 'Date �:';
$lang['col_head_calendar'] = 'Calendrier';
$lang['col_head_username'] = 'Usager';
$lang['col_head_fullname'] = 'Nom complet';
$lang['col_head_event'] = 'Ev�nement';
$lang['col_head_datefrom'] = 'Date de';
$lang['col_head_dateto'] = 'Date �';
$lang['col_head_date'] = 'Date';
$lang['col_head_description'] = 'Description';

$lang['calendar_title'] = 'Calendrier';
$lang['calendar'] = 'Calendrier:';
$lang['event_title'] = 'Ev�nement';
$lang['add_event'] = 'Ajouter un �v�nement';
$lang['delete_calendar_group_confirm_msg'] = 'Etes-vous certain de vouloir supprimer ces calendriers? Cette action est d�finitive.';
$lang['private_only'] = 'Priv� seulement';
$lang['public_only'] = 'Publique seulement';
$lang['public_private'] = 'Publique et priv�';
$lang['total_events_found'] = 'Total des �v�nements trouv�s:';
$lang['start_date'] = 'Date de d�but';
$lang['start_time'] = 'Heure de d�but';
$lang['end_date'] = 'Date de fin';
$lang['end_time'] = 'Heure de fin';
$lang['event_description'] = 'Description de l\'�v�nement';

$lang['more_events'] = 'Plus d\'�v�nements >>';
$lang['daily_events_list'] = "Liste journali�re des �v�nements ";
$lang['add_to_private'] = "Ajouter � la Liste Priv�e";
$lang['close_window'] = "Fermer la fen�tre";
$lang['main_window_closed'] = "D�sol�, vous avez ferm� la fen�tre principale.";
$lang['user_added1'] = "Usager ";
$lang['user_added2'] = " ajout� � la Liste Priv�e";
$lang['next_month'] = 'Mois Suivant';
$lang['previous_month'] = 'Mois Pr�c�dent';
$lang['next_week'] = 'Semaine prochaine';
$lang['previous_week'] = 'Semaine pr�c�dente';
$lang['next_day'] = 'Jour suivant';
$lang['previous_day'] = 'Jour pr�c�dent';
$lang['view_day'] = 'Afficher Jour';
$lang['view_week'] = 'Afficher Semaine';
$lang['view_month'] = 'Afficher Mois';

$lang['watched_events'] = 'Ev�nements surveill�s';
$lang['event_notification'] = 'Notification d\'�v�nement';

$lang['jump_to'] = 'Aller �';
$lang['ok'] = 'Ok';

$lang['recurring'] = "R�p�titif:";
$lang['recur_every'] = "chaque";

$lang['recuring_labels'] = array(
	'0' => 'jamais',
	'1' => 'jours',
	'2' => 'semaines',
	'3' => 'mois',
	'4' => 'ann�es'
	);

$lang['calendat_filter_dates_range'] = "S�lection de la plage de dates";
$lang['calendat_filter_last_year'] = "Ann�e pr�c�dente";
$lang['calendat_filter_last_month'] = "Mois pr�c�dent";
$lang['calendat_filter_last_week'] = "Semaine pr�c�dente";
$lang['calendat_filter_yesterday'] = "Hier";


$lang['cannot_determine_membership'] = 'Votre niveau d\'abonnement est ind�termin�';
$lang['no_previous_polls'] = 'Aucun sondage pr�c�dent.';
$lang['no_event_for_the_day'] = "Aucun �v�nement pour cette date";
$lang['maxsize'] = 'Taille maximale permise (KB)';
$lang['views'] = 'Qui a lu mon profil';

/******************************************/
/* ALL ERROR MESSAGES ARE DEFINED BELOW.  */
/******************************************/

// Affiliates error
$lang['affiliates_error'] = array(
	18 =>'Les mots de passes ne correspondent pas',
	20 =>'Tous les champs sont requis.',
	21 =>'Tous les champs sont requis.',
	25 =>'Cette adresse e-mail est d�j� enregistr�e comme affili�e. Veuillez utilisez une autre adresse e-mail.'
);


// Javascript error messages
$lang['admin_js_error_msgs'] = array(
	'',
	'Veuillez cochez une case.',
	'Etes-vous certain de vouloir effectuer cette suppression?',
	'Etes-vous certain de vouloir supprimer cette banni�re?'
	);

$lang['admin_js__delete_error_msgs'] = array('',
	1=> 'Etes-vous certain de vouloir supprimer cette section? Cette action est irr�versible.',
	2=> 'Etes-vous certain de vouloir supprimer cette question de la section? Cette action est irr�versible.',
	3=> 'Etes-vous certain de vouloir supprimer cette option de question? Cette action est irr�versible.',
	4=> 'Etes-vous certain de vouloir supprimer ce profil? Cette action est irr�versible.',
	5=> 'Etes-vous certain de vouloir supprimer cette nouvelle? Cette action est irr�versible.',
	6=> 'Etes-vous certain de vouloir supprimer cette histoire? Cette action est irr�versible.',
	7=> 'Etes-vous certain de vouloir supprimer cet article? Cette action est irr�versible.',
	8=> 'Etes-vous certain de vouloir supprimer ce sondage? Cette action est irr�versible.',
	9=> 'Etes-vous certain de vouloir supprimer cette option de sondage? Cette action est irr�versible.',
	10=> 'Etes-vous certain de vouloir supprimer cette banni�re? Cette action est irr�versible.',
	11=> 'Etes-vous certain de vouloir supprimer cet admin? Cette action est irr�versible.',
/* Added in RC6 */
	12=>'Etes-vous certain de vouloir supprimer ce pays?',
	13=>'Etes-vous certain de vouloir supprimer cet �tat/province',
	14=>'Etes-vous certain de vouloir supprimer ces pays?',
	15=>'Etes-vous certain de vouloir supprimer ces �tats/provinces?',
	16=>'L\'ent�te de la recherche �tendue doit �tre fournie quand inclus dans la recherche �tendue.',
	17 => 'Les pseudos doivent �tre entr�s quand la plage des pseudos est s�lectionn�e.',
	18 => 'Etes-vous certain de vouloir supprimer ces profils? Cette action est irr�versible.',
/* Added Release 1.0 */
	19=>'Etes-vous certain de vouloir supprimer cette comt�/quartier  ?',
	20=>'Etes-vous certain de vouloir supprimer ces comt�s/quartiers?',
	21=>'Etes-vous certain de vouloir supprimer cette ville/village?',
	22=>'Etes-vous certain de vouloir supprimer ces villes/villages?',
	23=>'Etes-vous certain de vouloir supprimer ce code postal?',
	24=>'Etes-vous certain de vouloir supprimer ces codes postaux?',

	25 => 'Etes-vous certain de vouloir supprimer cet �v�nement? Cette action est irr�versible.',
	26 => 'Etes-vous certain de vouloir supprimer ce calendrier? Cette action est irr�versible.',
	27 => 'Etes-vous certain de vouloir supprimer cette page? Cette action est irr�versible.',
	);


// Don't use double qoutes(") in the item's text
$lang['signup_js_errors'] = array(
	'username_noblank' => 'Veuillez entrez votre pseudo.' ,
	'password_noblank' => 'Veuillez entrez votre mot de passe.',
	'old_password_noblank' => 'Votre ancien mot de passe doit �tre sp�cifi�.',
	'new_password_noblank' => 'Votre nouveau mot de passe doit �tre sp�cifi�.',
	'con_password_noblank' => 'Le mot de passe doit �tre confirm�.',
	'firstname_noblank' => 'Le pr�nom doit �tre sp�cifi�.',
	'name_noblank' => 'Veuillez entrez votre pr�nom.',
	'lastname_noblank' => 'Le nom doit �tre sp�cifi�.',
	'email_noblank' => 'L\'address e-mail doit �tre sp�cifi�.',
	'city_noblank' => 'Ville/Village doit �tre sp�cifi�.',
	'zip_noblank' => 'Code Postal doit �tre sp�cifi�.',
	'address1_noblank' => 'Au moins une adresse doit �tre sp�cifi�.',
	'sectionname_noblank' => 'Veuillez entrer un nom pour cette section.',
	'sendname_noblank' => 'Veuillez entrer le nom de l\'exp�diteur.',
	'calendarname_noblank' => 'Veuillez entrez un nom pour ce calendrier.',
	'comments_noblank' => 'Veuillez entrez les commentaires que vous d�sirez envoyer.',
	'question_noblank' => 'Veuillez entrez une question.',
	'extsearchhead_noblank' => 'Veuillez entrez une ent�te de recherche �tendue.',
	'username_charset' => 'Seulement des lettres, nombres et \'_\' sont permis dans le pseudo.',
	'password_charset' => 'Seulement des lettres, nombres et \'_\' sont permis dans le mot de passe.',
	'firstname_charset' => 'Seulement des lettres sont permises dans le pr�nom.',
	'lastname_charset' => 'Seulement des lettres sont permises dans le nom.',
	'city_charset' => 'Le nom de la ville/village ne doit contenir que des lettres.',
	'zip_charset' => 'Seulement des chiffres sont permis pour le code postal.',
	'address_charset' => 'Veuillez entrez une adresse valide.',
	'sectionname_charset' => 'Seulement des lettres sont permises pour le nom de la section.',
	'calendarname_charset' => 'Seulement des lettres sont permises pour le nom du calendrier.',
	'sendname_charset' => 'Seulement des lettres sont permises pour le nom de l\'exp�diteur.',
	'name_charset' => 'Veuillez n\'utiliser que des lettres pour le champ \'Nom\'.',
	'maxlength_charset' => 'Veuillez entrer un nombre entier pour la longeur maximum.',
	'email_notvalid' => 'E-mail invalide.',
	'password_nomatch' => 'Les mots de passes ne correspondent pas.',
	'password_outrange' => 'La longeur du mot de passe doit �tre comprise dans les valeurs sp�cifi�es.',
	'username_outrange' => 'Le nombre de carract�res du pseudo doit �tre compris dans les valeurs sp�cifi�es.',
	'username_start_alpha' => 'Le pseudo doit commencer par une lettre.',
	'ccowner_noblank' => 'Le nom du propri�taire de la carte de cr�dit doit �tre sp�cifi�.',
	'ccnumber_noblank' => 'Le num�ro de la carte de cr�dit doit �tre sp�cifi�.',
	'cvvnumber_noblank' => 'Le num�ro de v�rification de la carte de cr�dit doit �tre sp�cifi�.',
	'select_payment' => 'Veuillez s�lectionner une m�thode de paiement.',
	'stateprovince_noblank' => 'Etat/Province doit �tre sp�cifi�.',
	'subject_noblank'	=> 'Le sujet doit �tre sp�cifi�.',
	'county_noblank' => 'Comt�/Quartier  doit �tre sp�cifi�.',
	'county_charset' => 'Comt�/Quartier  doit �tre alphab�tic.',
	'timezone_noblank' => 'Votre fuseau horaire doit �tre s�lectionn�.',
/* Added in 2.0 */
	'ratingname_noblank' => 'Le nom de la note doit �tre sp�cifi�.',
	'ratingname_charset' => 'Carract�res invalides dans le nom de la note.',
	'about_me_noblank' 	=> 'Vous devez �crire du texte dans la section � propos de moi.',
	);

$lang['letter_errormsgs'] = array(
		0 => 'Votre mot de passe vous a �t� envoy�. Veuillez v�rifier votre courrier.',
		1 => 'Veuillez entrez l\'adresse e-mail utilis� lors de votre enregistrement.',
		2 => 'Aucun gabrit de lettre pour \'mot de passe oubli�\'. Veuillez contacter un administrateur.',
		4 => 'Il y a eu un probl�me lors de l\'envoie de l\' e-mail. Veuillez contacter un administrateur.',
		5 => 'Vous n\'�tes pas un usager enregistr� de SITENAME. Veuillez entrez l\' e-mail utilis� lors de votre enregistrement.'
	);

$lang['taf_errormsgs'] = array(
		0 => 'L\'invitation a �t� envoy�e.',
		'sendername_noblank' => 'Veuillez entrez votre nom.',
		'senderemail_noblank' => 'Veuillez entrez votre e-mail.',
		'recipientemail_noblank' => 'Veuillez entrez l\' e-mail de la personne � qui vous d�sirez envoyer le message.',
		'sendername_charset' => 'Veuillez entrez seulement des lettres pour le nom.',
		'senderemail_charset' => 'Veuillez entrez un e-mail valide.',
		'recipientemail_charset' => 'Veuillez entrez un e-mail valide pour la personne � qui vous d�sirez envoyer le message.',
		2 => 'Aucun gabrit de lettre pour \'inviter un ami\'. Veuillez contacter un administrateur.',
		3 => 'Il y a eu un probl�me lors de l\'envoie de l\'invitation. Veuillez contacter un administrateur.',
	);
$lang['pages_errormsgs'] = array( '',
	1 => 'Le titre de la page est manquant.',
	2 => 'La clef de la page est manquante.',
	3 => 'Le texte de la page est manquant.',
	4 => 'La clef de la page existe d�j�. Svp choisissez une autre clef.',
	5 => 'La page est supprim�e.',
	);

$lang['article_error'] = array(
	1 => 'Le titre de l\'article est un champ requis.',
	2 => 'Le texte de l\'article est un champ requis.',
	3 => 'La date de l\'article est un champ requis.'
);
$lang['story_error'] = array(
	1 => 'Le titre de cette histoire est un champ requis.',
	2 => 'Le texte de cette histoire est un champ requis.',
	3 => 'La date de cette histoire est un champ requis.',
	4 => 'Le nom de qui provient cette histoire est un champ requis.'
);
$lang['news_error'] = array(
	1 => 'Le titre de cette nouvelle est un champ requis.',
	2 => 'Le texte de cette nouvelle est un champ requis.',
	3 => 'La date de cette nouvelle est un champ requis.'
);

$lang['mship_errors'] = array (
	1 => 'Le nom est un champ requis.',
	2 => 'Le prix est un champ requis.',
	3 => 'La monaie est un champ requis.',
	4 => 'Aucune m�thode de paiement est seulement disponnible quand vous changez votre abonnement pour Gratuit.'
);
$lang['admin_error_msgs'] = array (
	'',
	'Section est un champ requis.',
	'Svp compl�tez tous les champs requis.'
	);
$lang['admin_error'] = array(
	'',
	1 => 'Pseudo Admin ne peut �tre vide.',
	2 => 'Mot de passe Admin ne peut �tre vide.',
	3 => 'Nom Complet Admin ne peut �tre vide.',
	4 => 'Ancien mot de passe ne peut �tre vide.',
	5 => 'Nouveau mot de passe ne peut �tre vide.',
	6 => 'Confirmation du mot de passe ne peut �tre vide.',
	7 => 'Nouveau mot de passe et confirmation du mot de passe doivent �tre identique.',
	8 => 'Votre ancien mot de passe est incorrect. Svp essayez de nouveau.',
	9 => 'Le pseudo choisi est d�j� utilis�. Veuillez en choisir un autre.',
	/* added in 1.1.0 */
	10 => 'Svp utilisez seulement du texte pour le nom de la section'
);

$lang['banner_error_msgs'] = array( '',
	1 => 'Banni�re ne peut �tre laiss� vide.',
	2 => 'Lien URL ne peut �tre laiss� vide.',
	3 => 'Outil ne peut �tre laiss� vide.',
	4 => 'Seulement les banni�res au format .jpg sont permises.',
	5 => 'Les dimensions de la banni�re d�passent les d�menssions permises.'
);
$lang['poll_error'] = array(
	1 => 'Sondage ne peut �tre vide.',
	2 => 'Date de sondage ne peut �tre vide.',
	3 => 'Option ne peut �tre vide.',
	'txtpoll_noblank'  => 'Sondage est un champs requis.',
	'txtpollopt_noblank'  => 'Option de sondage est un champ requis.'
	);

$lang['datetime_month'] = array(
	1=>'Janvier',
	2=>'F�vrier',
	3=>'Mars',
	4=>'Avril',
	5=>'Mai',
	6=>'Juin',
	7=>'Juillet',
	8=>'Ao�t',
	9=>'Septembre',
	10=>'Octobre',
	11=>'Novembre',
	12=>'D�cembre'
);
$lang['datetime_day'] = array(
	'sunday' => 'Dimanche',
	'monday' => 'Lundi',
	'tuesday' => 'Mardi',
	'wednesday' => 'Mercredi',
	'thursday' => 'Jeudi',
	'friday' => 'Vendredi',
	'saturday' => 'Samedi'
);

/* Release 1.0.2   */
$lang['settings_saved'] = 'Configuration sauvegard�e avec succ�s';
$lang['select_image_first'] = 'Veuillez s�lectionnez une image en premier';

/* Release 1.1.0 additions */
$lang['day_names'] = array(
	'Sun' => 'Dimanche',
	'Mon' => 'Lundi',
	'Tue' => 'Mardi',
	'Wed' => 'Mercredi',
	'Thu' => 'Jeudi',
	'Fri' => 'Vendredi',
	'Sat' => 'Samedi'
);
$lang['view_type'] =  'Type d\'affichage';
$lang['remember_me'] = 'Se rappeler de moi';
$lang['review'] = 'Revoir';
$lang['spammers'] = 'Spammers';
$lang['addquestion'] = 'Ajouter une question';
$lang['mainstats'] = 'Statistiques principales';
$lang['osdate_version'] = 'Version d\'Osdate';
$lang['signonstats'] = 'Statistiques de fr�quentation';
$lang['usersinpastminute'] = 'usagers dans la derni�re minute';
$lang['usersinpasthour'] = 'usagers dans la derni�re heure';
$lang['usersinpastday'] = 'usagers dans la derni�re journ�e';
$lang['usersinpastweek'] = 'usagers dans la derni�re semaine';
$lang['usersinpastmonth'] = 'usagers dans le dernier mois';
$lang['usersinpastyear'] = 'usagers dans la derni�re ann�e';
$lang['usersinpast2years'] = 'usagers dans les 2 derni�res ann�es';
$lang['usersinpast5years'] = 'usagers dans les 5 derni�res ann�es';
$lang['usersinpast10years'] = 'usagers dans les 10 derni�res ann�es';
$lang['userstats'] = 'Statistiques des usagers';
$lang['totalusers'] = 'Total des usagers';
$lang['totalactiveusers'] = 'Total des usagers actifs';
$lang['totalpendingusers'] = 'Total des usagers en attente';
$lang['totalsuspendedusers'] = 'Total des usagers suspendus';
$lang['totalpictureusers'] = 'Total des usagers qui ont une photo';
$lang['totalonlineusers'] = 'usagers en ligne';
$lang['visitorstats'] = 'Statistiques des visiteurs';
$lang['sitestats'] = 'Statistiques du site';
$lang['visitorstosite'] = 'Visiteurs sur le site';
$lang['mostactivepage'] = 'Page la plus active';
$lang['timesfeedback'] = 'Nombre de foi que le formulaire de Suggestions/Critiques a �t� utilis�';
$lang['timesim'] = 'Nombre de fois que le Tchat a �t� utilis�';
$lang['timeswink'] = 'Nombre de clin d\'oeils envoy�s';
$lang['timesmessage'] = 'Nombre de messages envoy�s';
$lang['timesinvitefriend'] = 'Nombre de foi que le formulaire d\'Invitation d\'un ami a �t� utilis�';
$lang['timeshowprofile'] = 'Nombre de visionnement de profils';
$lang['timesonlineusers'] = 'Nombre de cliques sur les usager en ligne';
$lang['timesbanner'] = 'Nombre de fois que les banni�res ont �t� cliqu�e';
$lang['timesnewmember'] = 'Nombre de foi que la liste des nouveaux usagers a �t� cliqu�e';
$lang['timespoll'] = 'Nombre de fois que les sondages ont �t� utilis�';
$lang['timesgallery'] = 'Nombre de foi que la gall�rie photo a �t� utilis�';
$lang['timesaffiliates'] = 'Nombre de fois que les affili�s ont �t� cliqu�';
$lang['timessignup'] = 'Nombre de foi que Inscrivez-vous a �t� cliqu�';
$lang['timesnews'] = 'Nombre de fois que nouvelles a �t� cliqu�';
$lang['timesstories'] = 'Nombre de fois que histoires a �t� cliqu�';
$lang['timessearchmatch'] = 'Nombre de foi que recherche d\'�me soeur  a �t� cliqu�e';
$lang['no_affiliates'] = 'Nombre des affili�s';
$lang['no_affiliate_refs'] = 'Nombre des usagers r�f�r�s par les affili�s';
$lang['no_pages_refs'] = 'Nombre de pages r�f�r�es';
$lang['no_polls'] = 'Nombre de sondages';
$lang['no_news'] = 'Nombre de nouvelles';
$lang['no_stories'] = 'Nombre des histoires';
$lang['no_langs'] = 'Nombre de langues disponnibles';
$lang['glblgroups'] = 'Groupe des configurations globales';
$lang['accept_tos'] = 'J\'ai lu et j\'accepte les <a href="javascript:popUpScrollWindow('."'tos.php','center',650,600);".'">Termes et Conditions</a>';
$lang['tos_must'] = 'Veuillez lire et accepter les Termes et Conditions avant de vous inscrire';
$lang['private_event'] = 'Les informations de cet �v�nement sont priv�es';
$lang['posted_by'] = 'Envoy� par';

$lang['countries01']='Pays';
$lang['states01'] = 'Etats';
$lang['latitude'] = 'Latitude';
$lang['longitude'] = 'Longitude';
$lang['search_within'] = 'Chercher dans';
$lang['miles'] = ' miles ';
$lang['kms'] = ' kilom�tres ';
$lang['no_search_results'] = '<font color=red><b>0 R�sultats trouv�s</b></font><br /><br />Aucun r�sultat ne correspond � vos crit�res de recherche. Vous devriez �tendre votre recherche. Essayez de diminuer la quantit� de crit�res, par exemple cherchez par taille et �ge, mais non par taille, age et type corporel. Ou, �tendre la plage de votre recherche. par example, au lieu de chercher des gens ag�s entre 40 - 50, cherchez des gens ag�s entre 30 - 60.<br /><br />';
$lang['expire_on'] = 'Expiration de votre abonnement';
$lang['expire_in'] = 'Jours avant la fin de votre abonnement';
$lang['lang_to_load'] = 'Langue � charger';
$lang['load_lang'] = 'Charger la langue';
$lang['manage_languages'] = 'Gestion des Langues';
$lang['manage_zips'] = 'Gestion des Codes Postaux';
$lang['file_not_found'] = 'Fichier non trouv� dans le syst�me';
/* Modified in 1.1.0 */
$lang['success_mship_change'] = 'Merci d\'avoir souscrit/renouveler votre abonnement. <br /><br />Votre abonnement a �t� chang� avec succ�s pour';
$lang['payment_cancel'] = 'Paiement annul�';
$lang['checkout_cancel'] = 'Tel que vous l\'lavez souhaiter, le processus de paiement a �t� annuler.';
$lang['useronlinetext'] = array(
	'online_now'		=> 	'En ligne actuellement',
	'active_24hours'	=> 	'Usager actif dans les derni�res 24 heures',
	'active_3days'		=>	'Usager actif dans les 3 derniers jours',
	'active_1week'		=>	'Usager actif dans la derni�re semaine',
	'active_1month'		=>	'Usager actif dans le dernier mois',
	'notactive'			=>	'Usager non actif'
);
$lang['useronlinecolor'] = array(
	'online_now'		=> 	'#FF0000',
	'active_24hours'	=> 	'#00AA00',
	'active_3days'		=>	'#AA00A0',
	'active_1week'		=>	'#0000AA',
	'active_1month'		=>	'#000000',
	'notactive'			=>	'#838383'
);

$lang['transactions_report'] = 'Rapport des transactions';
$lang['trans_count'] = 'Nombre de transactions';
$lang['pay_no'] = 'No. de Paiement.';
$lang['ref_no'] = 'No. de Ref�rence.';
$lang['paid_thru'] = 'Paiement par';
$lang['pay_status'] = 'Paiement Statut';
$lang['trans_rep'] = 'Rapports de paiements';
$lang['expiry_interval'] = array(
	'1'		=> '24 Heures',
	'3'		=>	'3 Jours',
	'7'		=>	'7 Jours',
	'15'	=>	'15 Jours',
	'30'	=>	'30 Jours',
	'0'		=>	'Expir�'
	);
$lang['expiry_hdr'] = 'Lettre de rappel de fin d\'abonnement';
$lang['expiry_ltr'] = 'Lettre de fin d\'abonnement';
$lang['expiry_select'] = 'Selectionner l\'interval d\'expiration';
$lang['expird'] = 'Expir�';
$lang['expiry_ltr_sent'] = 'Les lettres de \'rappel d\'expiration\' ont  �t� envoy�es';
$lang['searching_within'] = 'Chercher dans';
$lang['payment_failed'] = 'Processus de paiement int�rompu. Veuillez refaire le processus de paiement.';
$lang['payment_fail'] = 'Echec du paiement';
$lang['deactivate'] = 'D�sactiver';

$lang['open_search'] = 'Recherche globale';
$lang['replace'] = 'Remplacer';
$lang['new'] = 'Nouveau';
$lang['no_save'] = 'Ne pas sauvegarder';
$lang['modify_curr_search'] = 'Modifier vos crit�res de recherche';
$lang['perform_search'] = 'et effectuer une recherche.';
$lang['start_new_search'] = 'D�buter une nouvelle recherche';
$lang['use_empty_form'] = 'en utilisant un nouveau formulaire.';
$lang['of_zip_code'] = 'de ce code postal';

/* MOD START */

$lang['profile_ratings'] = 'Notes des Profils';
$lang['total_ratings'] = 'Note totale';
$lang['delete_ratings'] = 'Supprimer les notes';
$lang['delete_rating_group_confirm_msg'] = 'Etes-vous certain de vouloir supprimer ces notes? Cette action est irr�versible?';
$lang['delete_rating_confirm_msg'] = 'Etes-vous certain de vouloir supprimer cette note? Cette action est irr�versible?';
$lang['modify_rating'] = 'Modifier la note';
$lang['modify_ratings'] = 'Modifier les notes';

$lang['glblsettings_groups']['50'] = 'Notes des profils';
$lang['mod_lowtohigh']['Low to High'] = 'Ordre croissant';
$lang['mod_lowtohigh']['High to Low'] = 'Ordre d�croissant';
$lang['admin_rights']['profile_ratings'] = 'Notes des profils';

$lang['custom_message'] = 'Message personnalis�';
$lang['notify_me'] = 'Me pr�venir quand mon message sera lu.';
$lang['include_profile'] = 'Inclure mon profil dans ce message.';
$lang['message_templates'] = 'Gabarit de Message';
$lang['my_templates'] = 'Mes gabarits de messages';
$lang['template_select'] = 'Veuillez s�lectionnez un gabarit de message';
$lang['template_intro'] = 'Si vous envoyer souvent des messages similaires, vous pouvez cr�er un gabarit pour vous �conomiser du temps. En utilisant des variables tel que [username] et [firstname], votre message semblera plus personnalis� lors de sa r�ception.';

$lang['add_template'] = 'Ajouter gabarit de message';
$lang['return_message'] = 'Retourner au message';
$lang['delete_template_confirm_msg'] = 'Etes-vous certain de vouloir supprimer ce gabarit de message? Cette action est irr�versible.';
$lang['edit_template'] = 'Modifier le gabarit de message';

$lang['template_instructions'] = 'Les variables suivantes sont disponibles dans les gabarits de messages: <br />
[username], [firstname], [city], [state], [country], [age]<br /><br />Vous pouvez utiliser ces variables pour donner une impression personnalis�e � vos messages, par exemple:<br /><br />Bonjour [firstname]!<br /><br />J\'ai remarqu� que tu proviens de [city].... moi aussi! :) Je crois que nous avons des afinit�s communes... envoi moi un message si tu crois que je peux �tre dans tes crit�res recherch�s.<br /><br />Passe une belle journ�e,<br />[username]';

$lang['your_comment'] = 'Vos commentaires';
$lang['your_reply'] = 'Votre r�ponse';
$lang['comment_note'] = 'Les commentaires qui d�passent 255 carract�res seront coup�s';
$lang['chars_remaining'] = 'carract�res restants';

$lang['delete_comment_confirm_msg'] = 'Etes-vous certain de vouloir supprimer ce commentaire? Cette action est irr�versible.';
$lang['no_msg_templates'] = 'Aucun gabarit de message trouv�.';
/* MOD END */

$lang['select'] = '- Choisir -';
$lang['select_country'] = 'Choisir le Pays';
$lang['select_state'] = 'Choisir Etat/Province';
$lang['select_county'] = 'Choisir Comt�/Quartier ';
$lang['select_city'] = 'Choisir Ville/Village';
$lang['confirm_success'] = 'Entrez votre pseudo et mot de passe, pour joindre le site et profiter de ces nombreux avantages.';
$lang['signup_success_message'] = '<b>Merci!</b><br /><br />&nbsp;Vous �tes maintenant un usager enregistr� de SITENAME.';
$lang['noone_online'] = 'Aucun usager en ligne';
$lang['in_hot_list'] = 'Cet usager est dans la Liste � Hot �';
$lang['in_buddy_list'] = 'Cet usager est dans las Liste d\'Amis';
$lang['in_ban_list'] = 'Cet usager est dans la Liste Usagers Bannis';
$lang['delete_search'] = 'Effacer cette recherche';
$lang['select_user_to_send_message'] = 'Choisir un usager � qui envoyer un message';
$lang['no_im_msgs'] = 'Aucun message Tchat';
$lang['public_event'] = 'Cet �v�nement est visible du public';
$lang['no_event_description'] = 'Aucune description fournie';
$lang['signup_js_errors']['country_noblank'] = 'Le pays doit �tre s�lectionn�';
$lang['msg_sent'] = 'Votre message a �t� envoy�';
$lang['forgotpass_msg4'] = 'Avez-vous oubli� votre pseudo et mot de passe? Votre pseudo, avec un nouveau mot de passe temporaire, peuvent vous �tre envoy� automatiquement par e-mail. Veuillez entrez l\'e-mail utilis� lors de votre inscription.';

/* 	Additions for new email messaging interface
	Vijay Nair
*/
$lang['send_a_message'] = 'Envoyer un message';
$lang['flagged'] = 'D�marqu�';
$lang['un_flagged'] = '\'D�-d�marqu�\'';
$lang['unflagged_msg1'] = 'Message \'D�-d�marqu�\' de plus de ';
$lang['unflagged_msg2'] = ' jours seront automatiquement supprim�s.';
$lang['no_messages_in_box'] = 'Aucun messages dans cette bo�te de r�ception';
$lang['no_flagged_messages_in_box'] = 'Aucun messages d�marqu�s dans cette bo�te de r�ception';
$lang['no_unflagged_messages_in_box'] = 'Aucun messages \'D�-d�marqu�s\ dans cette bo�te de r�ception';
$lang['mark'] = 'Marquer';
$lang['flag'] = 'D�marquer';
$lang['unflag'] ='\'D�-d�marqu�\'';
$lang['msg_flagged'] = 'Le message a �t� d�marqu�';
$lang['msg_unflagged'] = 'Message n\'est plus d�marqu�';
$lang['msg_deleted'] = 'Le message est supprim�';
$lang['sel_msgs_flagged'] = 'Les messages s�lectionn�s sont d�marqu�s';
$lang['sel_msgs_unflagged'] = 'Les messages s�lectionn�s sont \'d�-d�marqu�\'';
$lang['sel_msgs_deleted'] = 'Les messages s�lectionn�s sont supprimer';
$lang['sel_msgs_undeleted'] = 'Les messages s�lectionn�s sont restor�s';
$lang['sel_msgs_read'] = 'Les messages s�lectionn�s sont marqu�s comme lus';
$lang['sel_msgs_unread'] = 'Les messages s�lectionn�s sont marqu�s comme nouveaux';
$lang['FROM1'] = 'De';
$lang['no_thanks'] = 'Dire \"Non Merci\"';
$lang['reply'] = 'R�pondre';
$lang['undelete'] = 'Restorer';
$lang['back_to_messages'] = 'Retourner aux messages';
$lang['replied'] = 'R�ponse envoy�e';
$lang['no_thanks_subject'] = 'Merci, mais non merci...';
$lang['total'] = 'Total';
$lang['max_allowed'] = 'Maximum permis';
$lang['im_msg_long'] = 'Le message Tchat est plus gros que le maximum permis ';
$lang['members'] = 'Usagers';
$lang['To1'] = 'pour';

/* Items which are modified in 1.1.0 */


$lang['change_email'] = 'Changer d\'e-mail';

/* Changes made for letters  */
$lang['no_watched_event'] = 'Vous ne surveillez aucun �v�nement pr�sentement.
<br /><br />Il y a #eventcount# �v�nements pr�vus dans les prochains 30 jours. <a "#calenderlink#">Ouvrir le calendrier</a> pour voir ces �v�nements.
<br /><br />Pour voir un �v�nement, cliquez cet �v�nement dans le calendrier, ensuite cliquez sur la loupe. #glassicon#
<br /><br />Chaque surveillance pour un �v�nement expire � la date de cet �v�nement.';

$lang['no_thanks_message']['text'] = 'Bonjour #recipient_username#,

Merci de votre int�r�t, mais je dois respectueusement le d�cliner. Je vous souhaite de belles rencontres sur #site_name#.

Cordialement,
#sender_username#';

$lang['message_read']['text'] = "Cher #FirstName#,

Le message que vous avez envoy� � '#RecipientName#' a �t� lu.

Bonne chance!
#AdminName#
SITENAME";


$lang['featured_profile_added']['text'] = "Cher #FirstName#,

Nous avons ajout� votre profil � la liste des Usagers Distingu�s de <a href=\"#link#\">#SiteName#</a>.

Votre profil sera visible de #FromDate# � #UptoDate#.

Ceci vous permettra une meilleure visibilit� et augmentara vos chances de rencontrer la personne id�ale pour vous.

Bonne chance!
#AdminName#
SITENAME";

$lang['wink_received']['text'] = "Cher #FirstName#,

Vous avez re�u un clin d\'oeil de #SiteName# provenant de '#SenderName#'.

Svp visitez <a href=\"#link#\">#SiteName#</a> pour envoyer � '#SenderName#' un message, ou lui retourner un clin d\'oeil.

Bonne chance!
#AdminName#
SITENAME";

$lang['invite_a_friend']['text'] = "Bonjour,

Je viens de d�couvrir ce site en surfant sur le web: #SiteUrl#.

Je crois que cela serait peut-�tre int�ressant pour toi.

Va voir #SiteUrl#.

#FromName#";

$lang['profile_confirmation_email']['text'] = "Cher #FirstName#,

Merci de vous �tre inscrit sur #siteName#! En tant que nouvel usager de notre communaut�, je vous invite � explorer nos nombreux services et avantages.

Pour confirmer votre profil, Veuillez cliquer sur ce lien. Ou, si le lien n\'est pas cliquable, copiez et collez le lien dans la barre d\'adresse de votre naviguateur web pour joindre le site.

#ConfirmationLink#=#ConfCode#

Si la page finale de votre inscription est encore ouverte, vous pouvez aussi y ins�rer votre code de confirmation.

Votre code de confirmation est: #ConfCode#

Nous avons enregistr� les informations suivantes vous concernant:

Pseudo: #StrID#
Mot de Passe: #Password#
E-Mail: #Email#

Svp conservez ces informations pr�cieusement pour joindre le site et profiter de nos nombreux avantages. Certaines options n�cessitent un abonnement pour �tre accessibles. Vous pouvez vous abonner en cliquant ce lien:

#SiteUrl#payment.php

Merci de votre participation � nos services et nous vous souhaitons de magnifiques rencontres avec nos nombreux usagers!

#AdminName#
#SiteName#";

/* Added in 1.1.1 */
$lang['loading'] = 'Chargement..';


/* Changes in 1.1.3 */
$lang['support_currency'] = array(
		'USD' 	=> '$',
		'EUR'	=>'�',
		'INR'	=>'Rs.',
		'AUD'	=> 'AU$',
		'CD'	=> 'CAN$',
		'UKP'	=> chr(163)
		);


$lang['ratings'] = 'Notes';
$lang['comment'] = 'Commentaire';
$lang['comments'] = 'Commentaires';
$lang['loadaction'] = 'S�lection n�cessaire';
$lang['loadintodb'] = 'Charger dans la base de donn�es';
$lang['createsql'] = 'Cr�er un script SQL';


/* Version 2.0 additions et modifications */
/* Modifications */
$lang['submit'] = 'Soumettre';
$lang['lang_ensure'] = 'Commencez par d�finir une nouvelle langue et nom de fichier dans config.php (voir $language_options et $language_files definitions). Ensuite charger le fichier de langue /language/lang_xxxx/ sous le nom de fichier lang_main.php avant de proc�der. (xxxx est le nom du fichier en lettres minuscules. Par exemple: french, dutch, etc.).<br /><br /><b>Pour modifier et/ou ajouter une nouvelle entr�e dans le fichier de langue existant, veuillez faire les changements n�cessaires et recharger le fichier de langue.</b><br /><br />Pour d�charger une langue cliquez sur le bouton "Supprimer la langue de la base de donn�e".';

/* $lang['rate_catefully'] is changed as below */
$lang['rate_carefully'] = 'Les op�rateurs de ce site ne sont pas responsables de l\'exactitude ou de la fiabilit� de ces notes.<br />Ces notes sont produites par les usagers, et ne sont pas v�rifi�es par les usagers.';


$lang['privileges'] = array (
	'chat' 				=> 'Participer au tchat.',
	'blog'				=> 'Participer au blog.',
	'poll'				=> 'Participer au sondages.',
	'forum'				=> 'Participer au forum.',
	'includeinsearch' 	=> 'Inclure dans les r�sultats de recherche.',
	'message'			=> 'Envoyer des messages.',
	/* Added in 1.1.0 */
	'message_keep_cnt'  => 'Nombre de messages � garder.',
	'message_keep_days' => 'Nombre de jours un message peut �tre gard�.',
	/* rel 2.0 */
	'messages_per_day' 	=> 'Nombre de messages pouvant �tre envoy�s par jours.',
	/* Rel 1.0 added  */
	'allowim'			=> 'Permettre le Tchat.',
	'uploadpicture'		=> 'Envoyer des photos.',
	'uploadpicturecnt'	=> 'Nombre de photos permises.',
	'allowalbum'		=> 'Permettre les albums priv�s.',
	'event_mgt'			=> 'Permettre la gestion des �v�nements.',
	/* Above is added in 1.0 */
	'seepictureprofile' => 'Voir les photos sur les profils.',
	'favouritelist'		=> 'Gestion des amis/bannis/hot liste.',
	'sendwinks'			=> 'Envoyer des clin d\'oeils.',
	/* rel 2.0 */
	'winks_per_day' 	=> 'Nombre de clin d\'oeils pouvant �tre envoy�s par jour.',
	'extsearch'			=> 'Faire une recherche �tendue.',
//	'fullsignup' 		=> 'Enregistrement complet.',
	/* RC6 Patch */
	'activedays'		=> 'Jours valides pour ce niveau.',
	/* added in 2.0 */
	'saveprofiles'		=> 'Permettre la sauvegarde du profil.',
	'saveprofilescnt'	=> 'Nombre de profils permis.',
	'allow_videos'		=> 'Permettre l\'envoie de vid�os.',
	'videoscnt'			=> 'Nombre d\'envoie de vid�os permis.',
	'allow_mysettings'	=> 'Permettre de r�gler les pr�f�rences de recherches.',
	'allow_php121'		=> 'Permettre Tchat php121.',

);

/* 	Signup Error Messages
	These are the signup error messages, Svp do not change the sequence.
*/

$lang['errormsgs']= array(
	00 => '',
	01 => 'Pseudo est un champ requis.',
	02 => 'Mot de passe est un champ requis.',
	03 => 'Confirmer le mot de passe est un champ requis.',
	04 => 'Pr�nom est un champ requis.',
	05 => 'Nom est un champ requis.',
	06 => 'Adresse e-mail est un champ requis.',
	07 => 'Ville/Village est un champ requis.',
	08 => 'Code postale est un champ requis.',
	09 => 'Adresse ligne 1 est un champ requis.',
	10 => 'La longeur maximum du pseudo est de 25 caract�res.',
	11 => 'La longeur maximum du pr�nom est de 50 caract�res.',
	12 => 'La longeur maximum du nom de famille de 50 caract�res.',
	13 => 'La longeur maximum du e-mail est de 255 caract�res.',
	14 => 'La longeur maximum de la ville est de 100 caract�res.',
	15 => 'La longeur maximum de votre adresse est de 255 caract�res.',
	16 => 'Pseudo doit commencer par une lettre.',
	17 => 'Mot de passe doit commencer par une lettre.',
	18 => 'Les champs Mot de passe et Confirmer le mot de passe doivent �tre identiques.',
	19 => 'Veuillez entrer une adresse e-mail valide',
	20 => 'Les informations requises doivent �tre entr�es.',
	21 => 'Les identifiants fournies ne sont pas reconnues par le syst�me. Veuillez-vous assurer de bien les entrer comme il faut et essayer � nouveau.',
	22 => 'Ce pseudo est d�j� utilis�, veuillez en choisir un autre.',
	23 => 'Votre ancien mot de passe est incorect. V�rifiez-le et essayez � nouveau.',
	25 => 'Cet adresse e-mail est d�j� utilis�.' ,
//	26 => "Votre status is 'Not Active'. Svp wait while activating or mail to administrator." ,
	27 => 'Impossible de trouver le message.',
	28 => 'Svp s�lectionnez un fichier en premier.',
	29 => 'Format de fichier non support�, Svp veuillez en choisir un autre',
	30 => 'La question est d�j� en haut.',
	31 => 'La question est d�j� en bas.',
	32 => 'Merci pour vos commentaires. Vos commentaires seront lus sous peu.',
	33 => 'Le code postale entr� ne correspond pas � cet �tat.',
	34 => 'Code postale non valide',
	36 => 'Votre compte a �t� suspendu. Veuillez contacter un administrateur pour plus de details.',
	37 => 'Votre soumission a �t� refus�e. Veuillez contacter un administrateur pour plus de d�tails.',
	38 => 'Vous avez sp�cifi�e une date invalide. Svp v�rifiez l� et essayez � nouveau.',
	39 => 'Votre ancien et nouveau mot de passe doivent �tre identique',
	40 => 'Age de d�part doit �tre �gale ou moins que celle du maximum',
	51 => 'Age de d�part doit �tre plus basse que celle de la fin',
	52 => 'Ce usager est d�j� sur la liste',
	53 => 'Date invalide',
	54 => 'Pseudo ou mot de passe invalide',
	55 => 'Vous devez �tre connect� pour envoyer un message',
	56 => $lang['bigger_pic_size'],
	57 => $lang['only_jpg'],
	58 => $lang['upload_unsuccessful'],
	59 => 'Ce profil est ajout� � la liste',
	60 => 'Les dimensions de la miniature exc�de les dimensions maximum permises ('.$config['upload_snap_tnsize'].' X '.$config['upload_snap_tnsize'].')',
	61 => 'Code d\'activation invalide',
	62 => 'L\'usager a �t� retir� de la liste',
	63 => 'Cet usager a �t� ajout� � votre liste d\'amis',
	64 => 'Cet usager a �t� ajout� � votre liste d\' usagers bannis',
	65 => 'Cet usager a �t� ajout� � votre liste � Hot �',
	66 => 'Votre clin d\'oeil a �t� envoy� � cet usager',
	67 => $lang['upload_successful'],
	68 => 'Votre photo a �t� approuv�e',
	69 => 'Votre photo a �t� rejett�e',
	70 => 'La liste de qui a vu ma fiche a �t� vid�e',
	71 => 'La liste de clin d\'oeils a �t� vid�e',
	/* Added in RC6  */
	72 => 'Le compte de l\'usager a �t� r�activ�',
	73 => 'Le pays a �t� ajout�',
	74 => 'Le pays a �t� supprim�',
	75 => 'Le nom du pays ou son code est d�j� utilis�',
	76 => 'Le pays a �t� modifi�',
	77 => 'Cet �tat/province a �t� ajout�',
	78 => 'Cet �tat/province a �t� supprim�',
	79 => 'Le nom ou le code de cet �tat/province est d�j� utilis�',
	80 => 'Cet �tat/province a �t� modifi�',
	81 => 'Etat/Province le nom doit �tre sp�cifi�',
	82 => 'Aucune photo envoy�e par cet usager. ',
	83 => 'Le profil a �t� supprim�',
	84 => 'Les profils s�lectionn�s sont supprim�s.',

	85 => 'Profil(s) activ�(s).',
	86 => 'Profil(s) rejet�(s).',
	87 => 'Profil(s) suspendus.',

	26 => 'Votre profil n\'est pas encore activ�. <a href=\'completereg.php\'>Activez votre compte</a> en entrant votre code de confirmation ou en cliquant le lien dans le message envoyer a l\'e-mail fourni au moment de votre inscription.',

//	26 => 'Votre compte affili� n\'est pas encore approuv� par un administrateur. Svp attendez cette activation avant de pouvoir utiliser votre compte affili�.',

	35 => 'Votre profil n\'est pas encore approuv�.<br /> Svp attendez son approbation ou contactez un administrateur',

/* Release 1.0 additions/modifications  */

	88 => 'La comt�/quartier a �t� ajout�',
	89 => 'Le comt�/quartier a �t� effac�',
	90 => 'comt�/quartier code ou nom d�j� utilis�',
	91 => 'La comt�/quartier a �t� modifi�',
	92 => 'La ville/village a �t� ajout�',
	93 => 'La ville/village a �t� supprim�',
	94 => 'Ville/village code ou nom d�j� utilis�',
	95 => 'La ville/village a �t� modifi�',
	96 => 'Le code postal a �t� ajout�',
	97 => 'Le code postal a �t� supprim�',
	98 => 'Code postal est d�j� utilis�',
	99 => 'Le code postal a �t� modifi�',
	100 => '\'Comt�/Quartier\' est un champ requis',
	101 => 'Mot de passe invalide',
	102 => 'Cet �v�nement a �t� approuv�.',
	103 => 'Cet �v�nement a �t� rejet�.',
	301 => 'Fuseau horraire invalide',
	302 => 'Album mis � jour',
/* 1.1.0 additions */
	104 => 'Ces identifiants sont inexistant. Svp v�rifiez vos donn�es et essayez encore, ou utilisez l\'option ci-dessous pour vous la faire rem�morer .',
	105 => 'usager dans la liste des usagers bannis',
	/* Added in 2.0 */
	111 => 'Cet usager est d�j� dans la liste des Usagers Distingu�s',
	120	=>	'Le code de s�curit� doit �tre entr�',
	121 => 'Code de s�curit� invalide ',
	122 => 'Vous avez d�j� envoy� le nombre de messages permis pour aujourd\'hui. Svp essayez demain.',
	123 => 'Vous avez d�j� envoy� le nombre de clin d\'oeils permis pour aujourd\'hui. Svp essayez demain.',
	124 => 'Le fichier vid�o est charg�',
	125 => 'Le fichier vid�o n\'est pas charg� parce que son transfert a �chou�.',
	126 => 'Vous devez entrer du texte vous d�crivant.',
	128 => 'Les pseudos de chaque usagers individuels du couple doivent �tre entr�s.',
	129 => 'Les pseudos doivent �tre d�j� disponnibles.',
	130 => 'Les fichiers vid�o ne peuvent pas �tre convertis. Svp utilisez des videos en format .flv ou .swf.',
    131 => 'Vous avez exc�der le nombre de messages permis pour votre niveau d\'abonnement',
	201 => 'Vous avez d�j� sauvegard� les profils � limite permise � la liste � surveiller',
	202 => 'Ce profil est ajout� � votre liste de profils � surveiller',
	203 => 'Ce profil est d�j� dans votre liste de profils � surveiller',
	);


$lang['alphanumeric'] = "0123456789.+-_#,/ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz��������� ()";
$lang['alphanum'] = "0123456789_- ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz��������� ";
$lang['text'] = "-_@ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz��������� ";
$lang['full_chars'] = "0123456789.+-_#,/ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz���������() $;:?'";
/* Additions  in Version 2.0 */

$lang['save'] = 'Sauvegarder';
$lang['delete_zips'] = 'Supprimmer code postaux';
$lang['zipcodes_sql_created'] = 'Fichier sql des codes postaux cr�� ';
$lang['zipcodes_loaded'] = 'Codes postaux charg�s de ';
$lang['delzips_msg'] = 'Tous les codes postaux pour ce pays seront supprim�s';
$lang['delzips_succ'] = 'Codes postaux pour #COUNTRY# supprim�s';
$lang['wrong_zipfile'] = 'Ce fichier n\'est pas pour le pays #COUNTRY#';
$lang['load_states'] = 'Charger le fichier des �tats';
$lang['state_ensure'] = 'Svp charger le fichier de codes pour les �tats dans le r�pertoire /states avant de proc�der. <br /><br />Le fichier doit contenir STATECODE et STATENAME s�par�s par des virgules.(Aucune ent�te)<br /><br /> Pour supprimer les codes d\'�tat pour un pays, choisir le pays et cliquez "Supprimer le bouton Codes �tats"';
$lang['statefile'] = 'Fichier codes �tats';
$lang['delete_states'] = 'Supprimer codes des �tats';
$lang['delstates_msg'] = 'Tous les codes des �tats pour ce pays seront supprim�s';
$lang['delstates_succ'] = 'Le code �tat pour #COUNTRY# est supprim�';
$lang['states_sql_created'] = 'Fichier sql des codes des �tat cr�� ';
$lang['states_loaded'] = 'Codes �tats charg�s de';
$lang['delete_lang'] = 'SUPPRIMER langue de la base de donn�e';
$lang['langfile_loaded'] = 'Les d�finitions de la langue #LANGUAGE# sont charg�es de ';
$lang['lang_deleted'] = 'Les d�finitions de la langue #LANGUAGE# sont supprim�es';
$lang['load_counties'] = 'Charger le fichier cont�';
$lang['countyfile'] = 'fichier codes comt�/quartier ';
$lang['county_ensure'] = 'Svp charger le fichier des codes de comt�/quartier   dans le r�pertoire /counties avant de proc�der. <br /><br />Le fichier doit contenir COUNTYCODE, COUNTYNAME et STATECODE s�par�s par des virgules.(dans le m�me ordre, aucune ent�te)<br /><br /> Pour supprimer les codes de comt�/quartier   pour un pays, s�lectionnez le pays et cliquez le bouton "Supprimer codes de cont�"';
$lang['delete_counties'] = 'Supprimer les codes de cont�';
$lang['delcounties_msg'] = 'Tous les codes de cont�s/district pour ce pays seront supprim�s';
$lang['delcounties_succ'] = 'Les codes de R�gion pour #COUNTRY# sont supprim�s';
$lang['counties_sql_created'] = 'R�gion codes sql fichier cr�� ';
$lang['counties_loaded'] = 'Codes de R�gion charg� de ';
$lang['load_cities'] = 'Modifier le fichier villes';
$lang['cityfile'] = 'fichier des codes de villes';
$lang['city_ensure'] = 'Svp charger le fichier des villes/villages dans le r�pertoire /cities avant de proc�der. <br /><br />Le fichier doit contenir CITYCODE, CITYNAME, COUNTYCODE et STATECODE s�par�s par des virgules.(dans le m�me ordre,aucune ent�te)<br /><br /> Pour supprimer les codes villes/villages pour un pays, s�lectionnez le pays et cliquez le bouton "Supprimer les codes de villes"';
$lang['delete_cities'] = 'Supprimer les codes de villes/villages';
$lang['delcities_msg'] = 'Tous les codes villes/villages pour ce pays seront supprim�s';
$lang['delcities_succ'] = 'Les codes villes/villages pour #COUNTRY# sont supprim�s';
$lang['cities_sql_created'] = 'Fichier sql des codes villes/villages cr�� ';
$lang['cities_loaded'] = 'Les codes villes/villages charg�s de ';
$lang['online'] = 'En ligne';
$lang['watchedprofiles_1'] = 'Ajouter aux profils surveill�s';
$lang['watchedprofiles'] = 'Profils surveill�s';


$lang['poll'] = 'Sondage';
$lang['section_poll_title'] = 'Sondage';
$lang['section_poll_list'] = 'Liste des sondages';
$lang['section_add_poll'] = 'Cr�er un sondage';
$lang['poll_subtitle_list'] = 'Liste des sondages';
$lang['poll_subtitle_add'] = 'Cr�er un sondage';
$lang['poll_subtitle_edit'] = 'Modifier un sondage';
$lang['poll_number'] = 'Nombre';
$lang['poll_active_hdr'] = 'Actif';
$lang['poll_question_hdr'] = 'Questions';
$lang['poll_responses_hdr'] = 'R�ponses';
$lang['no_poll_found'] = 'Aucun sondage trouv�';
$lang['poll_question'] = 'Question';
$lang['poll_options'] = 'Options';
$lang['poll_active'] = 'Actif';
$lang['poll_minimum_two'] = 'Au moins deux requis.';
$lang['results_poll_title'] = 'R�sultats';
$lang['poll_subtitle_results'] = 'R�sultats de sondages';
$lang['take_poll_title'] = 'Prenez un sondage';
$lang['poll_entries'] = 'Sondage';



$lang['plugin_access'] = 'Acc�s usager';
$lang['section_plugin_title'] = 'Plugins';
$lang['section_plugin_list'] = 'Liste des Plugin';
$lang['section_add_plugin'] = 'Charger un Plugin';
$lang['plugin_subtitle_list'] = 'Liste des Plugin';
$lang['plugin_number'] = 'Nombre';
$lang['plugin_name'] = 'Nom';
$lang['plugin_active'] = 'Actif';
$lang['plugin_installed'] = 'Install�';
$lang['plugin_install'] = 'Installer';
$lang['no_plugin_found'] = 'Aucun Plugins trouv�s';
$lang['plugin_file'] = 'Envoyez fichier zip de plugin';
$lang['plugin_subtitle_edit'] = 'Modifier le Plugin';
$lang['add_plugin_summary'] = 'La documentation sur comment cr�er un Plugin est inclue dans votre installation de osdate.';

$lang['blog']['hdr'] = 'Blog';
$lang['admin_blog'] = 'Blog du site';
$lang['blog_default_bad_words'] = 'xxx|levitra';
$lang['blog_bad_words'] = 'Censure';
$lang['blog_save_template'] = 'Sauvegarder comme gabarit';
$lang['blog_load_template'] = 'Charger le gabarit';
$lang['blog_bad_words_help'] = '(un mot par ligne)';
$lang['blog_search_results'] = 'R�sultat de recherche du blog';
$lang['section_blog_info'] = 'Configurations du blog';
$lang['section_blog_list'] = 'Blog entr�es';
$lang['section_blog_title'] = 'Blog';
$lang['blog_search_menu'] = 'Reserche de Blogs';
$lang['blog_search_username'] = 'Pseudo';
$lang['blog_search_title'] = 'Titre';
$lang['blog_search_body'] = 'Texte';
$lang['blog_search_Date'] = 'Date';

$lang['blog_subtitle_list'] = 'Liste des Blogs';
$lang['blog_name'] = 'Nom du Blog';
$lang['blog_description'] = 'Description du Blog';
$lang['blog_members_comment'] = 'Commentaires des usagers';
$lang['blog_buddies_comment'] = 'Commentaires des amis';
$lang['blog_members_vote'] = 'Vote des usagers';
$lang['blog_gui_editor'] = 'Editeur WYSIWYG';
$lang['blog_max_comments'] = 'Maximum de commentaires';
$lang['no_blog_found'] = 'Aucune entr�e trouv�e';
$lang['section_add_blog'] = 'Cr�er une entr�e de Blog';
$lang['blog_subtitle_add'] = 'Cr�er une entr�e de Blog';
$lang['blog_subtitle_edit'] = 'Modifier le Blog';
$lang['blog_title'] = 'Titre';
$lang['blog_story'] = 'Contenu';
$lang['blog_posted_date'] = 'Date de cr�ation';
$lang['blog_title_hdr'] = 'Titre';
$lang['blog_rating_list_hdr'] = 'Note';
$lang['blog_number'] = 'Nombre';
$lang['blog_date_posted_hdr'] = 'Date';
$lang['blog_views_hdr'] = 'Visionnements';
$lang['blog_votes_hdr'] = 'Votes';
$lang['blog_votes1'] = 'votes';
$lang['blog_rating_hdr'] = 'bas� sur';
$lang['blog_submit_vote'] = 'Vote';
$lang['blog_add_vote'] = 'Voter maintenant';
$lang['view_blog'] = 'Voir Blog';
$lang['blog_entries'] = 'Blog:';
$lang['blog_creator'] = 'Auteur';
$lang['blog_comments'] = 'Commentaires';
$lang['add_comment'] = 'Vos commentaires';
$lang['total_blogs_found'] = 'Total des entr�es de Blog trouv�es:';

$lang['blog_errors'] = array(
   'nosetup' => 'Les configuration initiales du Blog doivent �tre sp�cifi�es.' ,
   'name_noblank' => 'Le nom du Blog doit �tre sp�cifi�.' ,
   'description_noblank' => 'La description du Blog doit �tre sp�cifi�. ',
   'date_posted_noblank' => 'Une date de cr�ation doit �tre sp�cifi�.' ,
   'title_noblank' => 'Un titre doit �tre sp�cifi�.' ,
   'story_noblank' => 'Une histoire doit �tre sp�cifi�.' ,
   'max_stories_warning' => 'Le nombre maximum des histoires est atteint. Aucune autre histoire ne peut �tre ajout�e.' ,
   'comment_bad_word' => 'Votre commentaire contient le mot censur� %s' ,
);
$lang['spell_check'] = 'V�rification orthographe';

$lang['manage_import_webdate'] = 'Importer de Webdate';
$lang['import_config'] = 'Config';

$lang['forum_values'] = array(
   'None' => 'Aucun',
   'phpBB' => 'phpBB',
   'vBulletin' => 'vBulletin',
   'myBB' => 'myBB',
   'Phorum' => 'Phorum',
   );

$lang['photos_url'] = 'URL de la page d\'accueil:';
$lang['ftp_username'] = 'Pseudo FTP:';
$lang['ftp_password'] = 'Mot de passe FTP:';
$lang['ftp_hostname'] = 'Host FTP:';
$lang['ftp_path'] = 'Chemin FTP de aeDating:';
$lang['ftp_path_help'] = 'Chemin vers le r�pertoire aeDating quand vous le joignez par ftp.  Ex. public_html/aeDating';

$lang['nopicsloaded'] = 'Aucune photo';
$lang['loadedpicscnt'] = '#PICSCNT# photo(s)';
$lang['loadedpicscnt1'] = '#PICSCNT# photo';
$lang['picsloaded'] = 'Photos';
$lang['since'] = 'depuis';
$lang['unknown'] = 'Inconnu';

$lang['glblsettings_groups'] = array(
1	=>	'Information du site',
2	=> 	'Contr�le des utilisateurs',
3	=>	'Contr�le du Calendrier',
4	=>	'Configurations Messages',
5	=>	'Image et miniature du profil',
6	=>	'Disposition des Pages et des Tables',
);

$lang['who_is_online'] = 'Uniquement des usagers en ligne';
$lang['search_with_photo'] = 'usagers avec photo seulement';
$lang['search_with_video'] = 'usagers avec vid�o seulement';
$lang['expire_on_hdr'] = 'Expire le';
$lang['expird'] = 'Expir�';
$lang['pics'] = 'Photos';
$lang['pic_deleted'] = 'La photo s�lectionn�e est supprim�e';
$lang['entrycode_chars'] = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
$lang['enter_spamcode'] = 'Code de s�curit�';

/* Admin emails portion */


/* Modified in 2.0 */
$lang['payment_msg1'] = 'Le niveau FEATURE met votre profil avec photo directement sur la page principale:';

$lang['wrong_activationcode'] = 'Le code de confirmation sp�cifi� est incorrect ou le compte a d�j� �t� confirm�.';

$lang['security_code_txt'] = 'Veuillez lire le texte dans l\'image ci-dessous et tapper ce texte dans la bo�te juste � c�t�. Nous vous demandons de faire ceci pour v�rifier  que cet action n\'est pas execut�e par un processus automatis�.';
$lang['additional_pics'] = 'Photos additionnelles';
$lang['view_all_pics'] = 'Voir toutes les photos';
$lang['insufficientPrivileges'] = 'Vos privil�ges sont insuffisants pour cette option. Svp prenez un abonnement au niveau ad�quat.';
$lang['username_part_msg'] = "Si Vous �tes incertain du pseudo, entrez une partie du pseudo pour voir les possibilit�s les plus probables. Par exemple, entrez 'usager' va montrer 'usager123', 'untelusager', etc."
;
$lang['featured_profiles_msg01'] = "Doit montrer: 'Oui' va favoriser ce profil pour �tre affich� dans la liste des Usagers Distingu�s. 'Non' va r�duire les chances pour son affichage. ";

$lang['featured_profiles_msg02'] = "Expositions requises: Ceci est le nombre d\'expositions requises avant que ce profil peut �tre retir� de la liste des Usagers Distingu�s, au cas o� le nombre des expositions est atteint avant la date de fin.";
$lang['lookup'] = 'Obtenir';
/* for use in shoutbox */
$lang['sb_by'] = 'Provenant de:';
$lang['sb_hdr'] = 'Messagerie �clair';
$lang['sb_send'] = 'Envoyer';
$lang['sb_error'] = 'Le texte entr� d�passe la longeur maximum permise';
$lang['sb_msg_blank'] = 'Messagerie �clair vide?';
$lang['sb_show_all'] = 'Montrer tout';

$lang['upload_videos'] = 'Envoyer des vid�os';
$lang['videoupload_format_msgs'] = 'Seulement les fichiers .swf ou .flv sont permis.';
$lang['video'] = 'Vid�o';
$lang['upload_videos_ext'] = 'flv, swf';
$lang['upload_video_caption'] = 'Envoyer vid�o';
$lang['video_file'] = 'Le fichier vid�o';
$lang['vds'] = 'Vds';
$lang['manage_videos'] = 'Gestion des vid�os';
$lang['videos_loaded'] = 'Vid�os charg�s';
$lang['novideos_loaded'] = 'Aucune vid�o';
$lang['loadedvdocnt'] = '#PICSCNT# vid�o(s)';
$lang['loadedvdocnt1'] = '#PICSCNT# vid�o';
$lang['video_gallery'] = 'Gall�rie vid�o';
$lang['picture_gallery'] = 'Gall�rie photo';


/* New timezone display values Modified in 2.0 */
// These are displayed in the timezone select box
$lang['tz']['-25'] = '-- Choisir --';
$lang['tz']['-12.00'] = '(GMT -12:00) Eniwetok, Kwajalein';
$lang['tz']['-11.00'] = '(GMT -11:00) Midway Island, Samoa';
$lang['tz']['-10.00'] = '(GMT -10:00) Hawaii';
$lang['tz']['-9.00'] = '(GMT -9:00) Alaska';
$lang['tz']['-8.00'] = '(GMT -8:00) Pacific Time (US & Canada)';
$lang['tz']['-7.00'] = '(GMT -7:00) Mountain Time (US & Canada)';
$lang['tz']['-6.00'] = '(GMT -6:00) Central Time (US & Canada), Mexico City';
$lang['tz']['-5.00'] = '(GMT -5:00) Eastern Time (US & Canada), Bogota, Lima';
$lang['tz']['-4.00'] = '(GMT -4:00) Atlantic Time (Canada), Caracas, La Paz';
$lang['tz']['-3.5'] = '(GMT -3:30) Newfoundland';
$lang['tz']['-3.00'] = '(GMT -3:00) Brazil, Buenos Aires, Georgetown';
$lang['tz']['-2.00'] = '(GMT -2:00) Mid-Atlantic';
$lang['tz']['-1.00'] = '(GMT -1:00 hour) Azores, Cape Verde Islands';
$lang['tz']['0.00'] = '(GMT) Western Europe Time, London, Lisbon, Casablanca';
$lang['tz']['1.00'] = '(GMT +1:00 hour) Brussels, Copenhagen, Madrid, Paris';
$lang['tz']['2.00'] = '(GMT +2:00) Kaliningrad, South Africa';
$lang['tz']['3.00'] = '(GMT +3:00) Baghdad, Riyadh, Moscow, St. Petersburg';
$lang['tz']['3.5'] = '(GMT +3:30) Tehran';
$lang['tz']['4'] = '(GMT +4:00) Abu Dhabi, Muscat, Baku, Tbilisi';
$lang['tz']['4.5'] = '(GMT +4:30) Kabul';
$lang['tz']['5.00'] = '(GMT +5:00) Ekaterinburg, Islamabad, Karachi, Tashkent';
$lang['tz']['5.5'] = '(GMT +5:30) Bombay, Calcutta, Madras, New Delhi';
$lang['tz']['6.00'] = '(GMT +6:00) Almaty, Dhaka, Colombo';
$lang['tz']['6.5'] = 'GMT + 6.30) ';
$lang['tz']['7.00'] = '(GMT +7:00) Bangkok, Hanoi, Jakarta';
$lang['tz']['8.00'] = '(GMT +8:00) Beijing, Perth, Singapore, Hong Kong';
$lang['tz']['9'] = '(GMT +9:00) Tokyo, Seoul, Osaka, Sapporo, Yakutsk';
$lang['tz']['9.5'] = '(GMT +9:30) Adelaide, Darwin';
$lang['tz']['10.00'] = '(GMT +10:00) Eastern Australia, Guam, Vladivostok';
$lang['tz']['11.00'] = '(GMT +11:00) Magadan, Solomon Islands, New Caledonia';
$lang['tz']['12.00'] = '(GMT +12:00) Auckland, Wellington, Fiji, Kamchatka';
$lang['tz']['13.00'] = '(GMT + 13)';

$lang['myprofile'] = 'Mon profil';
$lang['myblog'] = 'Mon Blog';
$lang['profilesearch'] = 'Chercher un profil';
$lang['mylists'] = 'Mes listes';
$lang['bans'] = 'Bannis';
$lang['mybuddies'] = 'Mes amis';
$lang['hotprofiles'] = 'Profils � Hot �';
$lang['winks'] = 'Clin d\'oeils';
$lang['tools'] = 'Outils';
$lang['picturegallery'] = 'Ma Gall�rie photo';
$lang['videogallery'] = 'Ma Gall�rie vid�o';
$lang['membership'] = 'Mon niveau d\'abonnement';
$lang['adminhome'] = 'Accueil Admin';
$lang['membershdr'] = 'Usagers';
$lang['memberprofiles'] = 'Profils des Usagers';
$lang['membersearch'] = 'Recherche d\'Usagers';
$lang['blogs'] = 'Blogs';
$lang['blogsearch'] = 'Chercher des Blogs';
$lang['affiliateshdr'] = 'Affili�s';
$lang['localities'] = 'Environs';
$lang['contenthdr'] = 'Contenu';
$lang['financial'] = 'Financier';
$lang['plugins_hlp'] = 'Les Plugins administratifs sont disponnibles seulement pour les administrateurs et les mod�rateurs ayant les permissions suffisantes, elles apparaissent au bas de la colonne de gauche de la section admin, si ils sont activ�s. Les Plugins des usagers peuvent �tre acc�d�s dans la section usagers';

/* HTML et some text emails */
$lang['no_thanks_message']['html'] = 'Bonjour #recipient_username#,<br><br>Merci de votre int�r�t, mais je dois respectueusement d�cliner. J\'esp&egrave;re que vous trouverez �ventuellement la personne id�ale sur #site_name#.<br><br>Cordialement,<br><br>#sender_username#';
$lang['newpic']['html'] ='<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td class="module_head" width="100%" height="25"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25"><div class="module_head">#email_hdr_left#</div>
</td><td width="493" height="25"><div class="module_head">&nbsp;&nbsp;Nouvelle photo sur votre site! </div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" ><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="1"></td></tr><tr><td width="50%" valign="top" class="evenrow" >Cher administrateur du site,<br>
  <br>    <a href="#SiteUrl#admin/showprofile.php?username=#UserName#">#UserName#</a>a envoy� une nouvelle photo.<br>
    <br>
      Pseudo: #UserName#<br>
      Photo No.: #PicNo#<br>
      <br>#AdminName# <br>SITENAME<br></td><td valign="top" class="evenrow" align="cemter">#smallPic#
</td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table>';


$lang['newpic']['text'] = "Cher administrateur du site,

#UserName# a envoy� une nouvelle photo.

Pseudo: #UserName#
Photo No.: #PicNo#

#AdminName#
SITENAME";

$lang['newpic_sub'] = 'SITENAME Message: Nouvelle photo sur votre site ';

$lang['newvideo']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25"><div class="module_head">#email_hdr_left#</div>
</td><td width="493" height="25"><div class="module_head">&nbsp;&nbsp;Nouve vid�o sur votre site! </div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" ><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">Cher administrateur du site,<br><br>#UserName# a envoy� une nouvelle vid�o. <br><br>Pseudo: #UserName#<br>Video No.: #PicNo#<br><br>#AdminName#<br>SITENAME<br></td>
</tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['newvideo']['text'] = "Cher administrateur du site,

#UserName# a envoy� une nouvelle vid�o.

Pseudo: #UserName#
Video No.: #PicNo#

#AdminName#
SITENAME";

$lang['newvideo_sub'] = 'SITENAME Message: Nouvelle vid�o sur votre site ';


/* old format
$lang['wink_received']['html'] = "Cher #FirstName#,<br><br>Vous avez re�u un clin d\'oeil de #SiteName# provenant de '#SenderName#'.<br><br>Svp visitez <a href=\"#link#\">#SiteName#</a> pour envoyer � '#SenderName#' un message, ou lui retourner un clin d\'oeil<br><br>Bonne chance!<br>#AdminName#";
$lang['letter_winkreceived_sub'] = '#SITENAME# - Vous avez re�u un clin d\'oeil';

New format below
*/

$lang['mail']['hdr_text'] = '<font style="color:red; font-size: 9px;">Pour ne plus re�evoir ce type de message, <a href="#SiteUrlLogin#">connectez-vous</a> sur votre compte et changez vos pr�f�rences e-mail dans le menu usager.<br>Pour vous assurer de re�evoir ces messages, Svp ajoutez <a href="mailto:#AdminEmail#">#AdminEmail#</a> � votre carnet d\'adresse e-mail maintenant.</font><br><br>';
$lang['mail']['hdr_html'] = '<table border=0 cellspacing=0 cellpadding=5 width="570"><tr><td ><font style="color:red; font-size: 9px;">Pour ne plus re�evoir ce type de message, <a href="#SiteUrlLogin#">connectez-vous</a> sur votre compte et changez vos pr�f�rences e-mail dans le menu usager.<br>Pour vous assurer de re�evoir ces e-mails, Svp ajoutez <a href="mailto:#AdminEmail#">#AdminEmail#</a> � votre carnet d\'adresse e-mail maintenant.</font></td></tr><tr><td height="6"></td></tr></table>';

$lang['letter_winkreceived_sub'] = 'SITENAME Message: #SenderName# vous envoi un clin d\'oeil! ';
$lang['wink_received']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25px">#email_hdr_left#</td><td width="493" height="25" ><div class="module_head">&nbsp;&nbsp;#SenderName# viens de vous faire un clin d\'oeil!</div>
</td></tr></table></div></td></tr><tr><td width="570" class="evenrow" colspan="2" ><div class="evenrow" ><table border="0" cellspacing="2" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="50%" valign="top">#smallProfile#</td>
<td width="50%" valign="top"><p>Parmi tant d\'usagers, #SenderName# vous a choisi pour un clin d\'oeil! Vous pouvez continuer le jeu en retournant un clin d\'oeil, ou en lui envoyant un message.<br>
      <br>
      <a href="#SiteUrl#compose.php?recipient=#UserId#">Envoyer un message � #SenderName# maintenant</a><br>
      <br>
      <a href="#SiteUrl#sendwinks.php?ref_id=#UserId#&amp;rtnurl=showprofile.php">Retourner le clin d\'oeil</a><br>
        <br>
        <b>Pas int�ress�?</b><br>
        Donnez � #SenderName# la courtoisie de le savoir en envoyant un message "Non, merci"<br>
        <br>
        <a href="#SiteUrl#compose.php?recipient=#UserId#&amp;reply=11">Dire "Non, merci"</a><br>
        <br>
  </p>
  </td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

/* old format
$lang['profile_confirmation_email']['html'] = "Cher #FirstName#,<br><br>Merci de votre enregistrement sur  #SiteName#! � titre de nouvel usager de notre communaut�, je vous encourrage � explorer nos nombreux services et avantages.<br><br>Pour confirmer votre profil, Svp cliquez le lien ci-dessous. Ou, si le lien ne se clique pas, copiez et collez-le dans votre barre de recherche internet, pour y acc�der directement.<br><br><a href=\"#ConfirmationLink#=#ConfCode#\">#ConfirmationLink#=#ConfCode#</a><br><br>Si vous avez encore la page de votre enregistrement ouverte, vous pouvez y entrer votre code de confirmation.<br><br>Votre code de confirmation est: #ConfCode#<br><br>Les informations de votre enregistrement sont:<br><br>Pseudo: #StrID#<br>Mot de Passe: #Password#<br>E-Mail: #Email#<br><br>Conservez pr�cieusement ces informations pour acc�der � votre compte et profiter de nos nombreux avantages. Certains avantages n�cessitent un abonnement que vous pouvez obtenir en cliquant ce lien:<br><br>#SiteUrl#payment.php<br><br>Merci encore de faire partie de notre site, et nous vous souhaitons de magnifiques rencontres!<br><br>#AdminName#<br>#SiteName#";

New format below
*/
$lang['profile_confirmation_email_sub'] = 'SITENAME Message: Merci de votre enregistrement sur  SITENAME!';
$lang['profile_confirmation_email']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570">
<tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%">
<tr><td width="77" height="25" >#email_hdr_left#</td><td width="493"  height="25"><div class="module_head">&nbsp;&nbsp;#Welcome#!</div></td></tr></table></div></td></tr><tr><td width="570" class="evenrow" colspan="2" >
<div class="evenrow" ><table border=0 cellspacing=0 cellpadding=5 width="100%"><tr><td>Cher #FirstName#,<br><br>
Merci de votre enregistrement sur  #SiteName#! En tant que nouvel usager de notre communaut�, je vous encourrage � explorer nos nombreux services et avantages.<br>
<br>Pour confirmer votre profil, Svp cliquez le lien ci-dessous. Ou, si le lien n\'est pas cliquable, copiez et collez-le dans la barre de naviguation de votre naviguateur web, pour y acc�der directement.<br><br>
<a href=\"#ConfirmationLink#=#ConfCode#\">#ConfirmationLink#=#ConfCode#</a><br><br>Si vous avez encore la page de votre enregistrement ouverte, vous pouvez y entrer votre code de confirmation.<br><br>Votre code de confirmation est: <b>#ConfCode#</b><br><br>Les informations de votre enregistrement sont:<br>
<br>Pseudo: <b>#StrID#</b><br>Mot de Passe: <b>#Password#</b><br>E-Mail: <b>#Email#</b><br><br>Conservez pr�cieusement ces informations pour acc�der � votre compte et profiter de nos nombreux avantages. Certains avantages n�cessitent un abonnement que vous pouvez obtenir en cliquant ce lien:<br><br><a href="#SiteUrl#payment.php">#Upgrade#</a><br><br>
Merci encore de faire partie de notre site, et nous vous souhaitons de magnifiques rencontres! <br>
<br>
#AdminName#<br>#SiteName#</td></tr></table></div></td></tr>
<tr><td height="6" colspan="2" class="evenrow"></td></tr></table>';

/* old format
$lang['message_received']['text'] = "Cher #FirstName#,

Vous avez re��u un message sur SITENAME provenant de '#SenderName#'.

Svp visitez <a href=\"#link#\">SITENAME</a> pour r�pondre � ce message.

Bonne chance!
#AdminName#";

$lang['message_received']['html'] = "Cher #FirstName#,<br><br>Vous avez re�u un message de #SiteName# provenant de '#SenderName#'.<br><br>Svp visitez <a href=\"#link#\">#SiteName#</a> pour r�pondre � ce message.<br><br>Bonne chance!<br>#AdminName#";

New format below
*/
$lang['message_received_sub'] = 'SITENAME Message: Vous avez un nouveau message!';
$lang['message_received']['text'] = "Cher #FirstName#,

Vous avez re�u un message sur SITENAME provenant de '#SenderName#'.

Veuillez visiter <a href=\"#link#\">SITENAME</a> pour r�pondre � ce message.

Bonne chance!
#AdminName#
SITENAME";

$lang['message_received']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25"><div class="module_head">
#email_hdr_left#</div></td><td width="493" ><div class="module_head">&nbsp;&nbsp;Un nouveau message de #SenderName#! </div></td></tr></table></div></td></tr><tr><td width="570" class="evenrow" colspan="2" ><div class="evenrow" ><table border="0" cellspacing="2" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="50%" valign="top" class="evenrow">
<table width="100%" border=0 cellspacing=0 cellpadding=0><tr><td width="25%" ><div class="newshead">#From#:</div></td><td width="75%">#SenderName#</td></tr><tr><td><div class="newshead">#TO#:</div></td><td>#UserName#</td></tr><tr><td  ><div class="newshead">#Date#:</div></td><td>#MESSAGE_DATE# </td></tr><tr><td ><div class="newshead">#Subject#:</div></td><td>#MSG_SUBJECT#</td></tr><tr><td colspan="2" height="6">
</td></tr><tr><td colspan=2>Cher #FirstName#,<br><br>Vous avez re�u un message de #SenderName#.<br><br>
Veuillez visiter <a href=\"#link#\">SITENAME</a> pour r�pondre � ce message. <br>
<br>Bonne chance!<br>#AdminName#<br>SITENAME<br></td></tr></table></td><td width="50%" valign="top" class="oddrow"><div class="oddrow">#smallProfile#</div></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table>';

/* Old format
$lang['letter_featuredprofile_sub'] = '#SITENAME# - Liste des Usagers Distingu�s';
$lang['featured_profile_added']['html'] = "Cher #FirstName#,<br><br>Votre profil est maintenant dans la liste des Usagers Distingu�s de<a href=\"#link#\">#SiteName#</a>.<br><br>Votre profil sera affich� du #FromDate# au #UptoDate#.<br><br>Ceci augmentera votre popularit� sur notre site et vous apportera une meilleure visibilit�.<br><br>Bonne chance!<br>#AdminName#";

new format
*/
$lang['letter_featuredprofile_sub'] = 'SITENAME Message: Votre profil sera bient�t distingu�';
$lang['featured_profile_added']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr>
<td width="77" height="25" ><div class="module_head">#email_hdr_left#</div>
</td><td width="493" ><div class="module_head">&nbsp;&nbsp;Votre profil sera bient�t dans les profils des Usagers Distingu�s! </div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" ><div class="evenrow"><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">Cher #FirstName#,<br><br>
Il nous fait grand plaisir d\'inclure votre profil dans nos Profiles Distingu�s sur <a href=\"#link#\">SITENAME</a>.<br>
<br>Votre profil sera affich� du <b>#FromDate#</b> au <b>#UptoDate#</b>.<br>
<br>
Ceci augmentera la visibilit� de votre profil et pourra peut-�tre vous donner beacoup plus de visionements par des �mes soeurs prospectives.<br>
<br>Bonne chance!<br>#AdminName# <br>SITENAME<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

/* old format

$lang['profile_activated_sub'] = '#SITENAME# - Votre profil est activ�';
$lang['profile_activated']['html'] = "Cher #FirstName#,<br><br>Ceci est un message automatique pour vous informer que votre profil sur #SiteName# a �t� activ� au abonnement #MembershipLevel#. Vous pouvez maintenant vous rendre sur <a href=\"#link#\">#SiteName#</a>.<br><br>Bonne chance!<br>#AdminName#";

new format */

$lang['profile_activated_sub'] = 'SITENAME Message:  Votre profil a �t� activ�!';
$lang['profile_activated']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" ><div class="module_head">
#email_hdr_left#</div></td><td width="493"><div class="module_head">&nbsp;&nbsp;Votre profil a �t� activ�!</div></td></tr></table></div></td></tr><tr>
<td width="100%" class="evenrow" colspan="2"><div class="evenrow"><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">Cher #FirstName#,<br><br>          Il nous fait grand plaisir de vous accueillir sur SITENAME. <br>
          <br>Votre profil a �t� activ� avec l\' abonnement <b>#MembershipLevel#</b> valide jusqu\'au #ValidDate#.<br><br>
          Vous pouvez maintenant vous rendre sur <a href=\"#link#\">SITENAME</a>.<br>
<br>Bonne chance!<br>#AdminName# <br>SITENAME<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table>  ';
$lang['profile_activated']['text'] = "Cher #FirstName#,

Il nous fait grand plaisir de vous accueillir sur SITENAME.

Votre profil est activ� avec l\'abonnement <b>#MembershipLevel#</b> valide jusqu\'au <b>#ValidDate#</b>.

Vous pouvez maintenant vous rendre sur <a href=\"#link#\">SITENAME</a>.

Bonne chance!
#AdminName#
SITENAME";

/* old format
$lang['profile_reactivated_sub'] = '#SITENAME# - Votre profil est r�activ�';
$lang['profile_reactivated']['html'] = "Cher #FirstName#,<br><br>Ceci est un message automatique pour vous informer que votre profil sur #SiteName# a �t� reactiv� au abonnement #MembershipLevel#. Vous pouvez maintenant vous rendre sur <a href=\"#link#\">#SiteName#</a>.<br><br>Bonne chance!<br>#AdminName#";

New format
*/
$lang['profile_reactivated_sub'] = 'SITENAME Message: Votre profil est r�activ�!';
$lang['profile_reactivated']['text'] = "Cher #FirstName#,

Nous sommes heureux de vous informer que votre profil est r�activ� avec l\'abonnement <b>#MembershipLevel#</b> qui expirera le <b>#ValidDate#</b>.

Vous pouvez maintenant vous rendre sur <a href=\"#link#\">SITENAME</a>.

Bonne chance!
#AdminName#
SITENAME";

$lang['profile_reactivated']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head">
<div class="module_head">#email_hdr_left#</div></td><td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;Votre profil est r�activ�! </div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2">
<div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">Cher #FirstName#,<br><br>Nous sommes heureux de vous informer que votre profil est r�activ� avec l\'abonnement <b>#MembershipLevel#</b> qui expirera le <b>#ValidDate#</b>.<br>
<br>Vous pouvez maintenant vous rendre sur <a href=\"#link#\">SITENAME</a>.<br><br>Bonne chance!<br>#AdminName# <br>SITENAME<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

/* old format
$lang['added_banlist_sub'] = '#SITENAME# - Information';
$lang['added_buddylist_sub'] = '#SITENAME# - Information';
$lang['added_hotlist_sub'] = '#SITENAME# - Information';

$lang['added_buddylist']['html'] = "Cher #FirstName#,<br><br>Vous avez �t� ajout� � la liste des amis de #SenderName#'.<br><br>Pour voir son profil rendez-vous sur <a href=\"#link#\">#SiteName#</a>.<br><br>Bonne chance!<br>#AdminName#";

$lang['added_hotlist']['html'] = "Cher #FirstName#,<br><br>Vous avez �t� ajout� � la Hot Liste de #SenderName#'.<br><br>Pour voir son profil rendez-vous sur <a href=\"#link#\">#SiteName#</a>.<br><br>Bonne chance!<br>#AdminName#";

$lang['added_banlist']['html'] = "Cher #FirstName#,<br><br>Vous avez �t� ajout� � la Ban Liste de #SenderName#'.<br><br>Pour voir son profil rendez-vous sur <a href=\"#link#\">#SiteName#</a>.<br><br>#AdminName#";

$lang['added_buddylist']['text'] = "Cher #FirstName#,

Vous avez �t� ajout� � la liste des amis de #SenderName#'.

Pour voir son profil rendez-vous sur <a href=\"#link#\">#SiteName#</a>.

Bonne chance!
#AdminName#
SITENAME";

$lang['added_hotlist']['text'] = "Cher #FirstName#,

Vous avez �t� ajout� � la Hot Liste de #SenderName#'.

Pour voir son profil rendez-vous sur <a href=\"#link#\">#SiteName#</a>.

Bonne chance!
#AdminName#
SITENAME";

$lang['added_banlist']['text'] = "Cher #FirstName#,

Vous avez �t� ajout� � la Ban Liste de #SenderName#'.

Pour voir son profil rendez-vous sur <a href=\"#link#\">#SiteName#</a>.

#AdminName#";

New format
*/
$lang['added_list_sub'] = "SITENAME Message: Vous avez �t� ajout� � la #ListName# de #SenderName#'!";
$lang['added_list']['text'] = "Cher #FirstName#,

L\' usager #SenderName# vous a ajout� � sa #ListName# .

Pour voir le profil de cet usager, rendez-vous sur <a href=\"#link#\">SITENAME</a>.

Bonne chance!
#AdminName#
SITENAME";
$lang['added_list']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head">
 <table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25px" class="module_head">
<div class="module_head">#email_hdr_left#</div></td><td width="493" class="module_head" >
<div class="module_head">&nbsp;&nbsp;Vous avez �t� ajout� � la #ListName# de #SenderName#!</div>
</td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" >
<div class="evenrow"><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="50%" valign="top" class="evenrow">Cher #FirstName#,<br><br>
L\' usager <b>#SenderName#</b> vous a ajout� � sa <b>#ListName#</b>.<br>
<br>Pour voir le profil de cet usager, rendez-vous sur <a href=\"#link#\">SITENAME</a>.<br><br>Bonne chance!<br>#AdminName# <br>SITENAME<br></td><td valign="top">#smallProfile#</td>
</tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table>';

/* old format
$lang['invite_a_friend_sub'] = 'Invitez un ami';
$lang['invite_a_friend']['html'] = "Bonjour,<br><br>J\'ai d�couvert ce site en surfant sur le web: #Link#.<br>J\'ai pens� que �a pourrait t\'int�resser. Clique sur le nom<br><br>#FromName#";

New format
*/
$lang['invite_a_friend_sub'] = "SITENAME Message: Invitation de #FromName#! ";
$lang['invite_a_friend']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="27" class="module_head" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" valign="top" ><div class="module_head" >#email_hdr_left#</div>
</td>
<td width="493" valign="middle"><div class="module_head" >&nbsp;&nbsp;Invitation de #FromName#!</div></td></tr></table></div></td></tr><tr><td width="100%" colspan="2" ><div class="evenrow"><table border="0" cellspacing="0" cellpadding="5" width="100%"><tr><td height="2"></td></tr><tr>
  <td width="100%" valign="top" class="evenrow">Salut,<br>
    <br>
J\'ai d�couvert ce site de rencontres en surfant sur le web: <a href=\"#SiteUrl#\"><b>SITENAME</b></a><br>
J\'ai pens� que �a pourrait t\'int�resser.<br>
<br>Va voir <a href=\"#SiteUrl#\">SITENAME</a>.<br><br>Bonne chance!<br>#FromName# <br><br></td></tr></table></div>
</td></tr><tr><td height="12" class="evenrow" colspan="2" ></td></tr></table>';

/* old format
$lang['message_read_sub'] = '#SITENAME# - Information';
$lang['message_read']['html'] = "Cher #FirstName#,<br><br>Votre message envoy� � '#RecipientName#' a �t� lu.<br><br>Bonne chance!<br>#AdminName#";

New format */
$lang['message_read_sub'] = 'SITENAME Message: #RecipientName# a lu votre message!';
$lang['message_read']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25">
<div class="module_head">#email_hdr_left#</div></td><td width="493" ><div class="module_head">&nbsp;#RecipientName#&nbsp;a  lu votre message! </div></td></tr></table></div></td></tr>
<tr><td width="100%" class="evenrow" colspan="2" >
<div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="50%" valign="top" class="evenrow"><p>Cher #FirstName#,<br>
            <br>
    <b>#RecipientName#</b> a lu le message que vous lui aviez envoy�!<br>
                <br>
          Pour voir le profil de cet usager, rendez-vous sur <a href=\"#link#\">SITENAME</a>.<br>
          <br>
          Bonne chance!<br>
          #AdminName# <br>
          SITENAME<br>
              </p>
        </td>
<td valign="top">#smallProfile#</td></tr></table>
</div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table>';

/* old format
$lang['email_feedback_subject'] = 'Commentaire provenant de '.SITENAME;
$lang['feedback_email_to_admin']['text'] = 'Cher administrateur du site,

Vous avez re�u un commentaire,  en voici les d�tails:

Titre: #txttitle#
Nom: #txtname#
Email: #txtemail#
Pays: #txtcountry#
Commentaire: #txtcomments#

Merci,
#SITENAME# Daemon';

$lang['feedback_email_to_admin']['html'] = 'Cher administrateur du site,<br><br>Vous avez re�u un commentaire,  en voici les d�tails:<br><br>Titre: #txttitle#<br>Nom: #txtname#<br>Email: #txtemail#<br>Pays: #txtcountry#<br>Commentaire: #txtcomments#<br><br>Merci,<br>#SITENAME# Daemon';

New format */
$lang['email_feedback_subject'] = 'SITENAME Message: Commentaire de votre site ';
$lang['feedback_email_to_admin']['text'] = 'Cher administrateur du site,

Vous avez re�u un commentaire de votre site. En voici les d�tails:

Titre: #txttitle#
Nom: #txtname#
Email: #txtemail#
Pays: #txtcountry#
Commentaire: #txtcomments#

Merci,
#SiteName# Daemon';
$lang['feedback_email_to_admin']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25"><div class="module_head">
#email_hdr_left#</div></td><td width="493"><div class="module_head">&nbsp;&nbsp;Commentaire de votre site <div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" ><div class="evenrow" >
<table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr>
<tr><td width="100%" valign="top" class="evenrow">Cher administrateur du site,<br><br>Vous avez re�u un message d\'un visiteur de votre site. En voici les d�tails:<br><br><table cellspacing="4" cellpadding="2" border="0" width="100%"><tr><td width="20%"> Titre:</td><td width="80%">#txttitle# </td></tr><tr><td>Nom:</td> <td>#txtname#</td></tr>
<tr><td>Email:</td><td>#txtemail#</td></tr><tr><td>Pays:</td><td>#txtcountry#</td></tr><tr><td>Commentaire:</td><td>#txtcomments#</td></tr></table><br>Merci,<br>
#siteName# Daemon<br>
 <br></td></tr></table></div></td></tr></table> ';

/* old format
$lang['forgot_password_sub'] = 'Demande de Mot de Passe';
$lang['forgot_password']['text'] = "Cher #Name#,

Votre Num�ro de usager: #ID#
Votre Mot de Passe:  #Password#

Pour vous connecter cliquez ce lien: #LoginLink#.

Merci d\'utiliser nos services!

#SiteTitle# messagerie automatique
<Message automatique, ne pas r�pondre>";
$lang['forgot_password']['html'] = "Cher #Name#,<br><br>Votre Num�ro de usager: #ID#<br>Votre Mot de Passe: #Password#<br><br>Pour vous connecter cliquez ce lien: #LoginLink#.<br><br>Merci d\'utiliser nos services!<br><br>#SiteTitle# messagerie automatique<br><Message automatique, ne pas r�pondre>";



New format */
$lang['forgot_password_sub'] = 'SITENAME Message: Demande de changement de mot de passe';
$lang['forgot_password']['text'] = "Cher #Name#,

Ce message a �t� envoy� suite � votre demande de changement de mot de passe.

Votre num�ro d\' usager: #ID#
Votre nouveau mot de passe:  #Password#

Pour vous connecter cliquez ce lien: #LoginLink#.

Merci d\'utiliser nos services!

#AdminName#
SITENAME";
$lang['forgot_password']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head"><div class="module_head">#email_hdr_left#</div></td>
<td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;Demande de changement de Mot de Passe</div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" ><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">Cher #Name#,<br>
<br>Ce message a �t� envoy� suite � votre demande de changement de Mot de Passe.<br><br>
Votre num�ro d\' usager: <b>#ID#</b><br>
Votre nouveau mot de passe: <b>#Password#</b><br>
<br>Pour vous connecter cliquez ce lien: <a href=\"#LoginLink#\">SITENAME</a>.<br><br>Merci d\'utiliser nos services!<br><br>#AdminName#<br>SITENAME<br></td></tr> </table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

/* old format
$lang['expiry_ltr_sub'] = 'Rappel de fin d\'abonnement';
$lang['mship_expired_note']['text'] = "Cher #FirstName#,

Ceci est un message automatique pour vous informer que votre abonnement #MembershipLevel# sur #SiteName# a expir� le #ExpiryDate#.

Svp <a href=\"#link#\">connectez-vous sur #SiteName#</a> pour renouveller votre abonnement et continuer de profiter de nos services.

Bonne chance!
#AdminName#";
$lang['mship_expired_note']['html'] = "Cher #FirstName#,<br><br>Ceci est un message automatique pour vous informer que votre abonnement #MembershipLevel# sur #SiteName# a expir� le #ExpiryDate#.<br><br>Svp <a href=\"#link#\">connectez-vous sur  #SiteName#</a> pour renouveller votre abonnement et continuer de profiter de nos services.<br><br>Bonne chance!<br>#AdminName#";

New format */
$lang['expiry_ltr_sub'] = 'SITENAME Message: Rappel d\'expiration de l\'abonnement';

$lang['mship_expired_note']['text'] = "Cher #FirstName#,

Merci d\'utiliser SITENAME!

Ceci est pour vous informer que votre abonnement: #MembershipLevel# sur SITENAME a expir� le #ExpiryDate#.

Svp <a href=\"#link#\">connectez-vous sur SITENAME</a> pour renouveller votre abonnement et continuer de profiter de nos services.

Bonne chance!
#AdminName#
SITENAME";

$lang['mship_expired_note']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head"><div class="module_head">#email_hdr_left#</div></td>
<td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;Votre abonnement est expir�! </div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" ><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">Cher #FirstName#,<br>
<br>Merci d\'utiliser SITENAME!<br><br>Ceci est pour vous informer que votre abonnement: <b>#MembershipLevel#</b> sur <a href="\"#link#\"><b>SITENAME</b></a> a expir� le <b>#ExpiryDate#</b>.<br><br>Svp <a href=\"#link#\">connectez-vous sur SITENAME</a> pour renouveller votre abonnement et continuer de profiter de nos services.<br><br>Bonne chance!<br>#AdminName# <br>SITENAME<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

/* old format
$lang['mship_expiry_note']['text'] = 'Cher #FirstName#,

Ceci est un message automatique pour vous informer que votre abonnement sur #SiteName# expirera le #ExpiryDate#.

Svp <a href="#link#">connectez-vous sur #SiteName#</a> et renouvellez votre abonnement.

Bonne chance!
#AdminName#';

$lang['mship_expiry_note']['html'] = 'Cher #FirstName#,<br><br>Ceci est un message automatique pour vous informer que votre abonnement sur #SiteName# expirera le #ExpiryDate#.<br><br>Svp <a href="#link#">connectez-vous sur #SiteName#</a> et renouvellez votre abonnement.<br><br>Bonne chance!<br>#AdminName#';


New format */
$lang['mship_expiry_note']['text'] = 'Cher #FirstName#,

Merci d\'utiliser SITENAME!

Ceci est pour vous informer que votre abonnement: #MembershipLevel# sur SITENAME expirera le #ExpiryDate#.

Svp <a href="#link#">connectez-vous sur SITENAME</a> et renouvellez votre abonnement et continuez de profiter de nos services.

Bonne chance!
#AdminName#
SITENAME';

$lang['mship_expiry_note']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head">
<div class="module_head">#email_hdr_left#</div></td><td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;Votre abonnement expirera sous peu! </div></td></tr></table></div></td></tr>
<tr><td width="100%" class="evenrow" colspan="2" ><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">Cher #FirstName#,<br><br>Merci d\'utiliser SITENAME!<br><br>Ceci est pour vous informer que votre abonnement: <b>#MembershipLevel#</b> sur <a href="\"#link#\"><b>SITENAME</b></a> expirera le <b>#ExpiryDate#</b>.<br><br>Svp <a href=\"#link#\">connectez-vous sur SITENAME</a> pour renouveller votre abonnement et continuer de profiter de nos services.<br>
<br>Bonne chance!<br>#AdminName# <br>SITENAME<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

/* Newly added - mail to be sent to member quand admin changes membership level */

$lang['profile_membership_changed_sub'] = 'SITENAME Message:  Votre abonnement a �t� chang�!';
$lang['profile_membership_changed']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head">
<div class="module_head">#email_hdr_left#</div></td><td width="493" class="module_head" height="25"><div class="module_head">&nbsp;&nbsp;Votre abonnement a �t� chang�! </div></td></tr></table></div></td></tr>
<tr><td width="100%" class="evenrow" colspan="2"><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">Cher #FirstName#,<br><br>Votre abonnement <b>#CurrentLevel#</b> a �t� chang� pour <b>#NewLevel#</b> qui expirera le <b>#ValidDate#</b>.<br>
<br>Vous pouvez maintenant vous rendre sur <a href=\"#link#\">SITENAME</a>.<br><br>Bonne chance!<br>#AdminName# <br>SITENAME<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['profile_membership_changed']['text'] = "Cher #FirstName#,

Votre abonnement <b>#CurrentLevel#</b> a �t� chang� pour <b>#NewLevel#</b> qui expirera le <b>#ValidDate#</b>.

Vous pouvez maintenant vous rendre sur <a href=\"#link#\">SITENAME</a>.

Bonne chance!
#AdminName#
SITENAME
";

$lang['comment_received_sub'] = 'SITENAME Message: Un usager a mis un nouveau commentaire sur votre blog';
$lang['comment_received']['text'] = "Cher #FirstName#,

Vous avez re�u un commentaire sur SITENAME provenant de '<b>#SenderName#</b>'.

Svp visitez <a href=\"#link#\"><b>SITENAME</b></a> pour voir le commentaire de '<b>#SenderName#</b>'.

Bonne chance!
#AdminName#
SITENAME";

$lang['comment_received']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head"><div class="module_head">#email_hdr_left#</div></td><td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;Un usager a mis un commentaire sur votre Blog! </div></td></tr></table></div></td></tr>
<tr><td width="100%" class="evenrow" colspan="2"><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">Cher #FirstName#,<br><br>Vous avez re�u un commentaire sur SITENAME provenant de <b>#SenderName#</b>.<br><br>Svp visitez <a href=\"#link#\"><b>SITENAME</b></a> pour voir le commentaire de <b>#SenderName#</b>.<br>
<br>Bonne chance!<br>#AdminName# <br>SITENAME<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';
$lang['aff_added_sub'] = 'SITENAME Message: Vous �tes ajout� comme affili�!';
$lang['aff_added']['text'] = "Cher #Name#,

Nous sommes heureux de vous informer que vous avez �t� ajout� comme affili� de SITENAME.

Votre num�ro d\' usager: #Affid#
Votre Mot de Passe: #Password#

Svp visitez <a href=\"#SiteUrl#\"><b>SITENAME</b></a> et connectez-vous sur la section affili� et changez votre mot de passe le plus rapidement possible.

Bonne chance!
#AdminName#
SITENAME";

$lang['aff_added']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head"><div class="module_head">#email_hdr_left#</div></td><td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;Vous avez �t� ajout� comme affili�! </div></td></tr></table></div></td></tr>
<tr><td width="100%" class="evenrow" colspan="2"><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">Cher #Name#,<br><br>Nous sommes heureux de vous informer que vous avez �t� ajout� comme affili� de SITENAME.<br><br><b>Votre num�ro d\'affili�: #Affid#</b><br><b>Votre Mot de Passe: #Password#</b><br><br>Svp visitez <a href=\"#SiteUrl#\"><b>SITENAME</b></a> et connectez-vous sur la section affili� et changez votre mot de passe le plus rapidement possible.<br><br>Bonne chance!<br>#AdminName# <br>SITENAME<br></td>
</tr></table></div>
</td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['aff_newpwd_sub'] = 'SITENAME Message: Votre compte affili�!';
$lang['aff_newpwd']['text'] = "Cher #Name#,

Tel que vous l\'avez demand�, un nouveau mot de passe a �t� g�n�r� pour votre compte affili� sur SITENAME.

Votre nouveau Mot de Passe: #Password#

Svp visitez <a href=\"#SiteUrl#\"><b>SITENAME</b></a> et connectez-vous sur la section affili� et changez votre mot de passe le plus rapidement possible.

Bonne chance!
#AdminName#
SITENAME";

$lang['aff_newpwd']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head"><div class="module_head">#email_hdr_left#</div></td>
<td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;Votre compte affili�! </div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2"><div class="evenrow"><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">Cher #Name#,<br><br>
Tel que vous l\'avez demand�, un nouveau mot de passe a �t� g�n�r� pour votre compte affili� sur SITENAME.<br>
<br><b>Votre Mot de Passe: #Password#</b><br><br>Svp visitez <a href=\"#SiteUrl#\"><b>SITENAME</b></a> et connectez-vous sur la section affili� et changez votre mot de passe le plus rapidement possible.<br><br>Bonne chance!<br>#AdminName# <br>SITENAME<br></td></tr></table></div>
</td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['add_affiliate'] = 'Ajouter un affili�';
$lang['mod_affiliate'] = 'Modifier un affili�';
$lang['aff_modified'] = 'Information affili� modifi�e';

$lang['newuser']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head"><div class="module_head">#email_hdr_left#</div></td>
<td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;Nouvel usager enregistr�!</div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" ><div class="evenrow"><table width="55%" border="0" cellpadding="5" cellspacing="0">
  <tr><td width="100%" valign="top" class="evenrow">Cher administrateur du site,<br><br>
  Il y a un nouvel usager enregistr� sur #SiteName#.<br>
  <br>Pseudo: <a href="#SiteUrl#admin/showprofile.php?username=#UserName#">#UserName#</a><br><br>#AdminName# <br>#SiteName#<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['newuser']['text'] = "Cher administrateur du site,
ss
Il y a un nouvel usager enregistr� sur #SiteName#.

Pseudo: #UserName#

#AdminName#
#SiteName#";

$lang['newuser_sub'] = 'Nouvel usager enregistr�';

/* Following user options are managed. Svp modify only the description and not these keys */

$lang['user_choices'] = array(
	'email_message_received' 	=> "Recevoir un e-mail quand un nouveau message est re�u.",
	'email_wink_received'		=> "Recevoir un e-mail quand quelqu\'un vous envoi un clin d\'oeil.",
	'email_blog_commented'		=> "Recevoir un e-mail quand quelqu\'un ajoute un commentaire dans mon Blog.",
	'email_mship_expiry'		=> "Recevoir un e-mail de rappel de fin d\'abonnement.",
	'email_message_read'		=> "Recevoir un e-mail quand mes messages sont lus.",
	'email_buddy_list'			=> "Recevoir un e-mail quand quelqu\'un m\'ajoute � sa liste d\'amis.",
	'email_ban_list'			=> "Recevoir un e-mail quand quelqu\'un m\'ajoute � sa liste bannis.",
	'email_hot_list'			=> "Recevoir un e-mail quand quelqu\'un m\'ajoute � sa liste �  Hot �.",
	"allow_buddy_view_album"	=> "Permettre aux usagers de ma liste d\'amis de voir mes albums priv�s.",
	"allow_hotlist_view_album"	=> "Permettre aux usagers de ma liste �  Hot � de voir mes albums priv�s.",
	'email_match_mail_days'		=> "Fr�quence, en jours, des envois d\'e-mails \'mes �mes soeur\'. Entrez 0 si vous ne voulez pas re�evoir ces emails.",
	);
$lang['mysettings_updated'] = 'Vos pr�f�rences de r�ception de messages ont �t� mis � jour.';
$lang['resend_conflink_hdr'] = 'Envoyer de nouveau, l�e-mail de confirmation';
$lang['resend_conflink_hdr1'] = 'Perdu ou jamais re�u votre e-mail de confirmation? Inscrivez l\'e-mail utilis� lors de votre enregistrement et il vous sera envoy� si votre e-mail est valide.';
$lang['resend_conflink_msg'] = 'Votre e-mail de confirmation vous a �t� envoy�.';
$lang['resend_conflink_msg1'] = 'Veuillez entrez l\'e-mail que vous avez utilis� lors de votre inscription';
$lang['resend_conflink_err1'] = 'Vous avez d�j� confirm� votre profil. Svp utilisez <a href="forgotpass.php">le formulaire pour mot de passe oubli�</a> pour g�n�rer un nouveau mot de passe temporaire.';
$lang['about_me'] = '� propos de moi';
$lang['about_me_hlp'] = 'Entrez une petite description de vous, ce qui vous d�crit le mieux ou qui vous int�resse.';
$lang['aff_forgot_pass'] = 'Oubli� votre mot de passe? Entrez votre e-mail ici pour en re�evoir un nouveau mot de passe temporaire:';
$lang['send_new_password'] = 'Envoyer un nouveau mot de passe';
$lang['not_a_member'] = 'Pas encore usager?';
$lang['login_reminded'] = 'Obtenez un rappel de vos noms et mot de passe';
$lang['lost_confemail'] = 'Perdu l\'e-mail de confirmation?';
$lang['couple_usernames'] = 'Pseudos du Couple / Groupe';
$lang['couple_usernames_hlp'] = 'Un couple ou groupe comprend au moins deux pseudos. Veuillez entrez les pseudos du couple ou groupe dans la case texte ci-bas. Par exemple: usager_1,usager_2,usager_3. Ces usagers doivent d�j� avoir un profil personnel sur le site.';
$lang['blog']['del01'] = 'Voulez-vous r�ellement supprimer ce profil?';
$lang['blog']['del02'] = 'Voulez-vous r�ellement supprimer cette s�lection ';
$lang['blog']['del03'] = 'Voulez-vous r�ellement d�sinstaller ceci ';
$lang['feat_prof_del_msg'] = 'Voulez-vous r�ellement supprimer ce profil de la liste des Usagers Distingu�s?';
$lang['feat_prof_deleted'] = 'Les profils s�lectionn�s ont �t� supprim�s de la liste des Usagers Distingu�s.';

$lang['mymatches_sub'] = 'SITENAME Message: Liste des profils de vos �mes soeurs!';
$lang['mymatches_body']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25"><div class="module_head">#email_hdr_left#</div></td><td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;Votre e-mail des profils de vos �mes soeurs! </div></td></tr></table></div></td></tr>
<tr><td width="570" class="evenrow" colspan="2" ><div class="evenrow" ><table border="0" cellspacing="2" cellpadding="5"><tr><td height="2"></td></tr><tr><td class="evenrow">Cher #FirstName#,<br><br>Voici la liste des profils qui correspondent avec vos crit�res de recherche.</td></tr>
<tr><td height="10" class="evenrow"> </td></tr><tr><td valign="top" class="evenrow">#matchedProfiles#</td></tr><tr><td height="10" class="evenrow"> </td></tr><tr><td class="evenrow" colspan="2">Svp visitez <a href=\"#link#\">SITENAME</a> pour voir ces profils.<br><br>Bonne chance!<br>#AdminName#<br>SITENAME<br></td></tr></table></div> </td></tr></table>';

$lang['on'] = ' sur ';

$lang['use_seo_username'] = 'Utiliser le pseudo comme param�tre dans l\'URL. Activer cette option donnera aux URLs des profils le format de "domaine/pseudo". D�sactiver cette option donnera aux URLs des profils le format de "domaine/id.htm"';
$lang['leave_blank_no_change'] = '(Laisser vide si aucun changement)';

$lang['adminltr']['html']='<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head"><div class="module_head">#email_hdr_left#</div></td><td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;#Subject#</div></td></tr></table></div></td></tr>
<tr><td width="100%" class="evenrow" colspan="2"><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">#LetterContent#</td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['adminltr']['text'] = '#LetterContent#';

/* Following is the section headers in appropriate languages */

$lang['sections'] = array(
	'1'	=> 	'Informations de Base',
	'2'	=>	'Physique',
	'3'	=>	'Vie Professionnelle',
	'4'	=>	'Train de vie',
	'5'	=>	'Int�r�ts'	);

/* Following is for mail encoding */
$lang['mail_text_encoding'] = '7bit';
$lang['mail_html_encoding'] = '7bit';
$lang['mail_html_charset'] = 'ISO-8859-1';
$lang['mail_text_charset'] = 'ISO-8859-1';
$lang['mail_head_charset'] = 'ISO-8859-1';

$lang['split_file_names_hdr'] = 'Fichiers en cours de chargement';
$lang['worst1'] = '(pas terrible)';
$lang['best1'] = '(excellent)';
$lang['profile_auto_confirmed'] = 'Merci de vous �tre inscrit sur SITENAME.<br><br>A titre d\'exception, votre profil a �t� automatiquement confirm� par notre syst�me.<br><br>Svp <a href="index.php?page=login">Connectez-vous</a> pour profiter de nos services.<br><br>';
$lang['zipfile'] = 'Repertoire des codes postaux';
$lang['zip_ensure'] = 'Svp chargez les fichiers des code postaux dans le r�pertoire /zipcodes/nomdupays avant de proc�der. Les gros fichiers doivent �tre divis�s en petits fichiers en utilisant /admin/split_zipcodes_file.php. <br /><br />Le fichier doit contenir ZIPCODE, LATITUDE, LONGITUDE, STATECODE, COUNTYCODE, CITYCODE (dans cet ordre. STATECODE, COUNTYCODE et CITYCODE peuvent �tre omis et mis � jour plus tard) s�par�s par des virgules.<br /><br /><b>Avant de charger les codes postaux pour un pays, svp supprimer les codes postaux de ce pays AVANT pour vous assurer que les valeurs ne sont pas dupliqu�es dans la base de donn�e.</b><br /><br />Pour supprimer les codes postaux pour un pays, choisir le pays et cliquez Supprimer';
$lang['load_zips'] = 'Charger les codes postaux';
$lang['zip_loaded'] = 'Les codes postaux ont �t� charg�s du fichier ';
$lang['zip_load_over'] = 'Le chargement des codes postaux pour le pays #COUNTRY# est compl�t�.';

$lang['admin_login_title'] = 'SITENAME Section d\'Administration';
$lang['home_title'] = 'SITENAME Indexe';
$lang['admin_title_msg'] =  'Panneau Admin';

//Filter Records
$lang['filter_options'] = array(
	'id' => 'Id',
	'username' => 'Pseudo',
	'city' => 'Ville',
	'zip' => 'Zip',
	'status' => 'Statut',
	'email'	=> 'E-mail',
	'gender' => 'Sexe'
	);
$lang['loginagain'] = 'Svp d�connetez et reconnectez-vous pour valider votre nouveau statut d\'abonnement';

$lang['online_users_txt'] = 'Usagers en ligne';\
$lang['plugin'] = 'Outils Avanc�s';

$lang['status_disp'] = array(
	'approval' => 'En attente',
	'active' => 'Activ�',
	'rejected' => 'Rejett�',
	'suspended' => 'Suspendu',
	/* added in 1.1.0 */
	'cancel' => 'Annul�'
	);
$lang['status_enum'] = array(
	'approval' => 'En attente',
	'active' => 'Activ�',
	'rejected' => 'Rejett�',
	'suspended' => 'Suspendu',
	);


$lang['status_act'] = array(
	'approval' => 'En attente',
	'active' => 'Activer',
	'rejected' => 'Rejetter',
	'suspended' => 'Suspendre',
	/* added in 1.1.0 */
	'cancel' => 'Annuler'
	);

?>
