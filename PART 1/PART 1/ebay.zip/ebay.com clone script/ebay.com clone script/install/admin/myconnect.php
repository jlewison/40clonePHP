<?php
//NULLIFIED BY DEEKAY[WGT]
//SCRIPT IS SAFE TO USE!
//
// YOU NEED TO CHANGE THE CONTENTS OF THE values of variables given in single quotes

//CONFIGURATION SECTION STARTS ///


$servername='localhost' ;  // Replace this 'localhost' with your server name 
$database_username='db_username'; // Replace this  with your username 
$database_password='db_pass';  // Replace this  with your password
$database_name='db_name';//'bidmonster';  // Replace this 'db' with your database name
// CONFIGURATION SECTION ENDS ////



mysql_connect($servername,$database_username,$database_password);
mysql_select_db($database_name);

?>