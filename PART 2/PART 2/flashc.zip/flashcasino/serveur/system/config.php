<? include ("header.php"); ?>





<? include ("menugames.php"); ?>










          <TD class=fgi_flsh vAlign=top><SPAN class=fgi_gttl>PLAYING FOR 
            REAL</SPAN><BR>
            <TABLE class=fgi_chips cellSpacing=0 cellPadding=0 width="100%" 
            border=0>
              <TBODY>
              <TR>
                <TD class=t><IMG 
                  src="fgi/chips_tl.jpg"></TD>
                <TD class=t align=right><IMG 
                  src="fgi/chips_tr.jpg"></TD></TR>
              <TR>
                <TD class=l>Welcome <B><? echo $l; ?></B>&nbsp;&nbsp;&nbsp;&nbsp;your balance 
                  account : <? echo $rog1[3]; ?></TD>
                <TD class=r align=right><A 
                  href="cashier.php"><IMG hspace=10 
                  src="fgi/cashier.jpg"></A><A 
                  href="logout.php"><IMG 
                  src="fgi/logout.jpg"></A></TD></TR>
              <TR>
                <TD class=b><IMG 
                  src="fgi/chips_bl.jpg"></TD>
                <TD class=b align=right><IMG 
                  src="fgi/chips_br.jpg"></TD></TR></TBODY></TABLE>
            <TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
              <TBODY>
              







               <?
include ("setup.php");
$resultg=mysql_query("select * from seting ");
$rog=mysql_fetch_array($resultg);
?>



	
	

	
	

	
		

            





		
               
            <TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
              <TBODY>
              <TR>
                <TD width=10><IMG 
                  src="fgi/d_tl.jpg"></TD>
                <TD class=fgdt colSpan=3><IMG 
                  src="fgi/d_t.jpg"></TD>
                <TD width=10><IMG 
                  src="fgi/d_tr.jpg"></TD></TR>
              <TR>
                <TD class=fgdl><IMG 
                  src="fgi/d_l.jpg"></TD>
                <TD class=fgd colSpan=3>
                  <center><H3>PERSONAL DATA</H3>





<br>
<table border="0" align="center" cellpadding="0" cellspacing="0">
<FORM action=config.php method=post>
<TR><td class=fgd height=20 width=120><b>Num playeur :</b></td><TD class=fgd >ID <? echo $row[0] ?></TD></TR>
<TR><td class=fgd height=20><b>Login :</b></td><TD class=fgd ><? echo $row[1] ?></TD></TR>
<TR><td class=fgd height=20><b>Password :</b></td><TD><INPUT size=20 name=cpass style=" border: 1px solid rgb(60,100,255)" value=<? echo $row[2] ?> ></TD></TR>
<TR><td class=fgd height=20><b>E-mail</b></td><TD class=fgd ><? echo $row[6] ?></td></TR>
<TR><td class=fgd height=20><b>Affiliate</b></td><TD><INPUT size=20 name=cname style=" border: 1px solid rgb(0,0,0)" value=<? echo $row[7] ?>></TD></TR>
<TR><td class=fgd height=20><b>Code bonnus</b></td><TD><INPUT size=20 name=cfam style=" border: 1px solid rgb(0,0,0)" value=<? echo $row[8] ?>></TD></TR>

<TR><td class=fgd height=20><b>First name :</b></td><TD><INPUT size=20 name=prenom style=" border: 1px solid rgb(0,0,0)" value=<? echo $row[11] ?>></TD></TR>
<TR><td class=fgd height=20><b>Name :</b></td><TD><INPUT size=20 name=nom style=" border: 1px solid rgb(0,0,0)" value=<? echo $row[12] ?>></TD></TR>
<TR><td class=fgd height=20><b>address :</b></td><TD><INPUT size=20 name=adresse style=" border: 1px solid rgb(0,0,0)" value=<? echo $row[13] ?>></TD></TR>
<TR><td class=fgd height=20><b>Postal Code :</b></td><TD><INPUT size=20 name=codepostal style=" border: 1px solid rgb(0,0,0)" value=<? echo $row[14] ?>></TD></TR>
<TR><td class=fgd height=20><b>city :</b></td><TD><INPUT size=20 name=ville style=" border: 1px solid rgb(0,0,0)" value=<? echo $row[15] ?>></TD></TR>
<TR><td class=fgd height=20><b>country :</b></td><TD><INPUT size=20 name=pays style=" border: 1px solid rgb(0,0,0)" value=<? echo $row[16] ?>></TD></TR>




<TR><TD height=50><INPUT type=hidden value=1 name=send> <INPUT style="FONT-SIZE: 12px; BACKGROUND-COLOR: #FFFFFF" type=submit value="SUBMIT"></TD></TR>
</FORM>
</table>

<?
if ($send=="1"){
mysql_query("UPDATE users set pass='$cpass',name='$cname',fam='$cfam',prenom='$prenom',nom='$nom',adresse='$adresse',codepostal='$codepostal',ville='$ville',pays='$pays'                              where login='$l'");
echo "<script> alert('Informations enregistr�es'); document.location.href='config.php';</script>";
}
?>
                <TD class=fgdr><IMG 
                  src="fgi/d_r.jpg"></TD></TR>
              <TR>
                <TD class=fgdl><IMG 
                  src="fgi/d_l.jpg"></TD>
                <TD class=fgdb colSpan=3><IMG 
                  src="fgi/d_b.jpg"></TD>
                <TD class=fgdr><IMG 
                  src="fgi/d_r.jpg"></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></TD>
    <TD>&nbsp;</TD></TR>











  




<? include ("footer.php"); ?>





