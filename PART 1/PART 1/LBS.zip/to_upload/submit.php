<?php session_start(); include('ip_domain_ban.php'); include('settings.php'); if($onoff == 'N') { include('disabled.php'); exit; } else { } ?>

<?php 
$submit = $_POST[submit];
$number = $_POST['number'];
$mynumber = $_SESSION['image_value'];
if($submit == 'Next Step >>' and md5($number) == "$mynumber") {
$selectc = mysql_real_escape_string($_POST[selectc]);
$email = mysql_real_escape_string($_POST[email]);
$keyword = mysql_real_escape_string($_POST[keyword]);
$url = mysql_real_escape_string($_POST[url]);
$descr1 = mysql_real_escape_string($_POST[descr1]);
$descr2 = mysql_real_escape_string($_POST[descr2]);
$mdesc = mysql_real_escape_string($_POST[mdesc]);
$mword = mysql_real_escape_string($_POST[mword]);
$tag1 = mysql_real_escape_string($_POST[tag1]);
$tag2 = mysql_real_escape_string($_POST[tag2]);
$tag3 = mysql_real_escape_string($_POST[tag3]);
$tag4 = mysql_real_escape_string($_POST[tag4]);
$tag5 = mysql_real_escape_string($_POST[tag5]);
$tag6 = mysql_real_escape_string($_POST[tag6]);
$deeptf = mysql_real_escape_string($_POST[deeptf]);
$dfurl = mysql_real_escape_string($_POST[dfurl]);
$deepts = mysql_real_escape_string($_POST[deepts]);
$dsurl = mysql_real_escape_string($_POST[dsurl]);
$deeptt = mysql_real_escape_string($_POST[deeptt]);
$dturl = mysql_real_escape_string($_POST[dturl]);
$bid = mysql_real_escape_string($_POST[bid]);
$gm_str = mysql_real_escape_string($_POST[gm_str]);
$gm_str_nr = mysql_real_escape_string($_POST[gm_str_nr]);
$gm_city = mysql_real_escape_string($_POST[gm_city]);
$gm_county = mysql_real_escape_string($_POST[gm_county]);
$gm_country = mysql_real_escape_string($_POST[gm_country]);
$blinkurl = mysql_real_escape_string($_POST[blinkurl]);
//$categ = $_POST[categ];
include('processing_info_v.php');
$url = urlencode($url);
echo("<meta http-equiv='refresh' content='0;URL=processing.php?keyword=$keyword&email=$email&url=$url&bid=$bid&categ=$categ'>");
exit;}
//header("Location: contact_sent.php"); 
elseif($submit == 'Next Step >>' and md5($number) <> "$mynumber") {
echo '<div align="center" class="style19" id="wrong">Validation code is not correct! Please try again!</div>';
$selectc = mysql_real_escape_string($_POST[selectc]);
$email = mysql_real_escape_string($_POST[email]);
$keyword = mysql_real_escape_string($_POST[keyword]);
$url = mysql_real_escape_string($_POST[url]);
$descr1 = mysql_real_escape_string($_POST[descr1]);
$descr2 = mysql_real_escape_string($_POST[descr2]);
$mdesc = mysql_real_escape_string($_POST[mdesc]);
$mword = mysql_real_escape_string($_POST[mword]);
$tag1 = mysql_real_escape_string($_POST[tag1]);
$tag2 = mysql_real_escape_string($_POST[tag2]);
$tag3 = mysql_real_escape_string($_POST[tag3]);
$tag4 = mysql_real_escape_string($_POST[tag4]);
$tag5 = mysql_real_escape_string($_POST[tag5]);
$tag6 = mysql_real_escape_string($_POST[tag6]);
$deeptf = mysql_real_escape_string($_POST[deeptf]);
$dfurl = mysql_real_escape_string($_POST[dfurl]);
$deepts = mysql_real_escape_string($_POST[deepts]);
$dsurl = mysql_real_escape_string($_POST[dsurl]);
$deeptt = mysql_real_escape_string($_POST[deeptt]);
$dturl = mysql_real_escape_string($_POST[dturl]);
$bid = mysql_real_escape_string($_POST[bid]);
$gm_str = mysql_real_escape_string($_POST[gm_str]);
$gm_str_nr = mysql_real_escape_string($_POST[gm_str_nr]);
$gm_city = mysql_real_escape_string($_POST[gm_city]);
$gm_county = mysql_real_escape_string($_POST[gm_county]);
$gm_country = mysql_real_escape_string($_POST[gm_country]);
$blinkurl = mysql_real_escape_string($_POST[blinkurl]);
}
else {}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<?php echo("$lang_0");?>
<?php echo("$lang_01");?>
<title>Submit Listing - <?php echo("$sitetitle");?></title>
<link rel="shortcut icon" href="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/favicon.ico" />
<link href="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/style.css" rel="stylesheet" type="text/css" />
<meta name="description" content="<?php echo("$sitetitle");?>" />
<meta name="keywords" content="<?php echo("$sitetitle");?>" />

<script src="<?php echo("$path");?>SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<script src="<?php echo("$path");?>SpryAssets/SpryValidationTextarea.js" type="text/javascript"></script>
<script src="<?php echo("$path");?>SpryAssets/SpryValidationSelect.js" type="text/javascript"></script>
<link href="<?php echo("$path");?>SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<link href="<?php echo("$path");?>SpryAssets/SpryValidationTextarea.css" rel="stylesheet" type="text/css" />
<link href="<?php echo("$path");?>SpryAssets/SpryValidationSelect.css" rel="stylesheet" type="text/css" />


<SCRIPT language=javascript>
function gurl(l){ 
	document.location.href='/'+l+'/';
}

function dodiv() { 
	var frm = document.pgfrm; 
	var tt=frm.keyword.value; 
	var dd1=frm.descr1.value; 
	var dd2=frm.descr2.value; 
	var dd3=frm.url.value; 
	var bbd=frm.bid.value; 
	
	if (tt) { document.getElementById('kw').innerHTML=tt; } 
	else {  document.getElementById('kw').innerHTML="Example Title"; } 
	
	if (dd1) { document.getElementById('d1').innerHTML=dd1; } 
	else {  document.getElementById('d1').innerHTML="Description line 1 sample"; } 
	
	if (dd3) { document.getElementById('d3').innerHTML=dd3; } 
	
	else {  document.getElementById('d3').innerHTML="http://your_site.com/"; } 
	
	if (bbd) { document.getElementById('bidd').innerHTML=bbd; } 
	else {  document.getElementById('bidd').innerHTML="<?php echo("$minbid");?>"; }
} 
	
function chknum(evt) { 
	var charCode = (evt.which) ? evt.which : event.keyCode; 
	
	if (charCode > 31 && (charCode < 48 || charCode > 57)) return false; return true;
} 
	
function chkfrm() { 
	var frm = document.pgfrm; 
	
	if (!frm.selectc.value.replace(/^\s*|\s*$/g,"")) { alert("Please selest category for your listing"); frm.selectc.focus(); return false; } 
	
	if (!frm.email.value.replace(/^\s*|\s*$/g,"")) { alert("You must provide an e-mail address."); frm.email.focus(); return false; } 
	
	if (!frm.url.value.replace(/^\s*|\s*$/g,"") || frm.url.value.replace(/^\s*|\s*$/g,"") == "http://") { alert("You must provide a website URL."); frm.url.focus(); return false; } 
	
	if (!frm.keyword.value.replace(/^\s*|\s*$/g,"")) { alert("Please enter the title for your listing"); frm.keyword.focus(); return false; } 
	
	if (!frm.descr1.value.replace(/^\s*|\s*$/g,"")) { alert("You must provide a brief description."); frm.descr1.focus(); return false; } 
	
	if (!frm.descr2.value.replace(/^\s*|\s*$/g,"")) { alert("You must provide an extended description."); frm.descr2.focus(); return false; } 
	
    if (!frm.tag1.value.replace(/^\s*|\s*$/g,"")) { alert("You must provide a TAG."); frm.tag1.focus(); return false; } 
	if (!frm.tag2.value.replace(/^\s*|\s*$/g,"")) { alert("You must provide a TAG."); frm.tag2.focus(); return false; } 
	if (!frm.tag3.value.replace(/^\s*|\s*$/g,"")) { alert("You must provide a TAG."); frm.tag3.focus(); return false; } 
	if (!frm.tag4.value.replace(/^\s*|\s*$/g,"")) { alert("You must provide a TAG."); frm.tag4.focus(); return false; } 
	if (!frm.tag5.value.replace(/^\s*|\s*$/g,"")) { alert("You must provide a TAG."); frm.tag5.focus(); return false; } 
	if (!frm.tag6.value.replace(/^\s*|\s*$/g,"")) { alert("You must provide a TAG."); frm.tag6.focus(); return false; } 
	
	if (!frm.bid.value.replace(/^\s*|\s*$/g,"")) { alert("You must provide a bid amount."); frm.bid.focus(); return false; } 
	
	if (frm.bid.value.replace(/^\s*|\s*$/g,"") < <?php echo("$minbid");?>) { alert("Your initial contribution must be at least <?php echo("$currency");?><?php echo("$minbid");?>"); frm.bid.focus(); return false; }

<?php if($asubm == 'Y') { ?>	
	if (!frm.gm_str.value.replace(/^\s*|\s*$/g,"")) { alert("You must provide a street name."); frm.gm_str.focus(); return false; } 
	if (!frm.gm_str_nr.value.replace(/^\s*|\s*$/g,"")) { alert("You must provide a street number."); frm.gm_str_nr.focus(); return false; } 
	if (!frm.gm_city.value.replace(/^\s*|\s*$/g,"")) { alert("You must provide a city."); frm.gm_city.focus(); return false; } 
	if (!frm.gm_county.value.replace(/^\s*|\s*$/g,"")) { alert("You must provide a county."); frm.gm_county.focus(); return false; } 
	if (!frm.gm_country.value.replace(/^\s*|\s*$/g,"")) { alert("You must provide a country."); frm.gm_country.focus(); return false; } 
<?php } else {}?>
} 
</SCRIPT>
</head>

<body>

<?php include("template/$lbdtemplate/a_main_buylink.php"); ?>

</body>
</html>