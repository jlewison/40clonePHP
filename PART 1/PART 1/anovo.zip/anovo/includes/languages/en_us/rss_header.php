<?php
echo '<?xml version="1.0" encoding="utf-8"?>
'."\n"; ?>
<rss version="2.0" xmlns:media="http://search.yahoo.com/mrss">
<channel>
<copyright>Copyright (c) 2008 <?php echo $CFG['site']['name'];?>. All rights reserved.</copyright>
<link><?php echo $CFG['site']['url'];?></link>
<language>en-us</language>
<description>Enter a question and get answers from experts.</description>
<image>
	<url><?php echo $CFG['site']['url'];?>images/logo.jpg</url>
	<title><?php echo $CFG['site']['name'];?></title>
	<link><?php echo $CFG['site']['url'];?></link>
	<width>144</width>
	<height>17</height>
</image>