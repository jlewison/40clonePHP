<?php
function getEmailAddress($string)
{
		$string = trim($string);
		$str_arr = explode(' ', $string);
		foreach ($str_arr as $key => $value)
		{
				preg_match("/^\S+@\S+\.\S+$/i", $value, $email);
				if (isset($email[0]) and $email[0]) return $email[0];
		}
		return false;
}
?>