<?php
	//Include init.php
if ( !defined( 'SMARTY_DIR' ) ) {
	include_once( '../init.php' );
}

include ( 'sessioninc.php' );

define( 'PAGE_ID', 'profile_ratings' );
if ( !checkAdminPermission( PAGE_ID ) ) {
	header( 'location: not_authorize.php' );
	exit;
}

//Default Sorting
if( $_GET['sort'] == '' ) {
	$sort = 'displayorder asc ';
} else if( $_GET['sort'] == get_lang('col_head_name') ) {
		$sort = 'rating '. checkSortType ( $_GET['type'] );
} else {
	$sort = findSortBy();
}

//For Editing ratings
if ( $_GET['edit'] ) {
	$sqledit = 'SELECT id, rating, description, enabled from ! Where id = ?';
	$data = $db->getRow( $sqledit, array( RATINGS_TABLE, $_GET['edit'] ));
	$t->assign( 'lang', $lang );
	$t->assign( 'error', get_lang('admin_error_msgs', $_GET['errid'] ) );
	$t->assign( 'data', $data );
	$t->assign('rendered_page', $t->fetch('admin/ratingsedit.tpl'));
	$t->display( 'admin/index.tpl' );
	exit;
}

//For Deletion of ratings
if ( $_POST['frm'] == 'frmDelrating' && $_POST['delaction'] == 'Yes') {
	
	$id = $_POST['txtid'];
	
	// Deleting rating
	$sqldel = 'DELETE FROM ! WHERE id = ?';
	$db->query( $sqldel, array( RATINGS_TABLE, $id ) );
	header('location: manageratings.php');
	exit;
}

//Insert in ratings with max displayorder
if ( $_POST['frm'] == 'frmAddrating') {
	$rating = stripslashes(trim( $_POST['txtrating'] ));
	$enabled = trim( $_POST['txtenabled'] );
	$sql = 'SELECT MAX(displayorder)+1 as orderno FROM ! ' ;
	$row = $db->getRow( $sql, array( RATINGS_TABLE ) );
	$sqlins = 'INSERT INTO ! (rating, enabled , displayorder) VALUES (?, ?, ? )';
	$db->query( $sqlins, array( RATINGS_TABLE, $rating, $enabled,  (is_null($row['orderno'])?"0":$row['orderno']) ) );
	header('location: manageratings.php');
	exit;
}//End of if

if ( $_GET['moveup'] ) {
	$sql = 'SELECT displayorder FROM ! WHERE id = ?';
	$nrow = $db->getRow( $sql, array( RATINGS_TABLE, $_GET['moveup'] ) );
	//to check whether it is at the highest order
	//if not then move up
	if ( $nrow['displayorder'] != 0){
		$sql = 'SELECT id, displayorder FROM ! WHERE displayorder = ?';
		$prow = $db->getRow( $sql, array( RATINGS_TABLE, ($nrow['displayorder']-1) ) );
		$sqla = 'UPDATE ! SET displayorder = ? WHERE displayorder = ? AND id = ?';
		$db->query( $sqla, array( RATINGS_TABLE, $nrow['displayorder'], $prow['displayorder'], $prow['id'] ));
		$db->query( $sqla, array( RATINGS_TABLE, $nrow['displayorder']-1, $nrow['displayorder'], $_GET['moveup'] ));
		header('location: manageratings.php');
		exit;
	}
	header('location: manageratings.php?msg=rating is already at the top');
	exit;
}

if ( $_GET['movedown'] ) {
	$sql = 'SELECT displayorder FROM ! WHERE id = ?';
	$nrow = $db->getRow( $sql, array( RATINGS_TABLE,$_GET['movedown'] ) );
	//get maximum order of ratings
	$sql = 'SELECT MAX(displayorder) as maxorder FROM !';
	$maxorder = $db->getOne( $sql, array( RATINGS_TABLE ) );
	//to check whether it is at the lowest order
	//if not then move down
	if ( $nrow['displayorder'] !=  $maxorder['maxorder'] ){
		$sql = 'SELECT id, displayorder FROM ! WHERE displayorder = ?';
		$prow = $db->getRow( $sql, array( RATINGS_TABLE,($nrow['displayorder']+1) ) );
		$sqla = 'UPDATE ! SET displayorder = ? WHERE displayorder = ? AND
			id = ?';
		$db->query( $sqla , array( RATINGS_TABLE, ($nrow['displayorder']+1), $nrow['displayorder'], $_GET['movedown'] ));
		$db->query( $sqla , array( RATINGS_TABLE, $nrow['displayorder'], $prow['displayorder'], $prow['id'] ));
		header('location: manageratings.php');
		exit;
	}
	header('location: manageratings.php?msg=rating is already at the bottom');
	exit;
} 		

$sqlrating = 'SELECT id, rating, displayorder, enabled from ! order by ' . $sort;
$data = $db->getAll( $sqlrating, array(RATINGS_TABLE) );
$t->assign( 'lang', $lang );
$t->assign( 'sort_type', checkSortType( $_GET['type'] ) );
$t->assign( 'data', $data );
$t->assign('rendered_page', $t->fetch('admin/manageratings.tpl'));
$t->display( 'admin/index.tpl' );
?>
