<?php
class ViewAudio extends FormHandler
{
		public $audio_details;
		public function populateAudioDetails()
		{
				$param_arr = explode('_', $this->fields_arr['pg']);
				$this->fields_arr['audio_for'] = $param_arr[0];
				$this->fields_arr['aid'] = $param_arr[1];
				$sql = 'SELECT audio_id, content_id, user_id, audio_ext, audio_size,' . ' playing_time, date_added, audio_server_url' . ' FROM ' . $this->CFG['db']['tbl']['ans_audio'] . ' WHERE' . ' audio_id=' . $this->dbObj->Param('audio_id') . ' AND' . ' audio_status=\'Ok\' AND' . ' audio_encoded_status=\'Yes\' AND' . ' audio_for=' . $this->dbObj->Param('audio_for');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['aid'], $this->fields_arr['audio_for']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($this->audio_details = $rs->FetchRow()) return true;
				return false;
		}
		public function resetFieldsArray()
		{
				$this->setFormField('pg', '');
		}
}
$ViewAudio = new ViewAudio();
$ViewAudio->setDBObject($db);
$ViewAudio->makeGlobalize($CFG, $LANG);
if (!isAjax()) Redirect2URL($CFG['site']['url']);
$ViewAudio->setHeaderStart();
$ViewAudio->setPageBlockNames(array('msg_form_error', 'msg_form_success', 'audio_display'));
$ViewAudio->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$ViewAudio->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$ViewAudio->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$ViewAudio->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$ViewAudio->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$ViewAudio->resetFieldsArray();
$ViewAudio->setAllPageBlocksHide();
$ViewAudio->sanitizeFormInputs($_REQUEST);
if ($ViewAudio->isFormGETed($_REQUEST, 'pg'))
{
		if (!$ViewAudio->populateAudioDetails())
		{
				$ViewAudio->setAllPageBlocksHide();
				$ViewAudio->setCommonErrorMsg($LANG['error_audio']);
				$ViewAudio->setPageBlockShow('msg_form_error');
		}
		else
		{
				$ViewAudio->setPageBlockShow('audio_display');
		}
}



?>
<div id="selViewAudio" class="">
	<p class="clsPopupClose"><a href="#" onClick="return closLightWindow()"><?php echo $LANG['close']; ?></a></p>
	<div id="selLeftNavigation">
<?php
if ($ViewAudio->isShowPageBlock('msg_form_error'))
{
?>
		  <div id="selMsgError">
		    <p><?php echo $ViewAudio->getCommonErrorMsg(); ?></p>
		  </div>
<?php
}
if ($ViewAudio->isShowPageBlock('audio_display'))
{
		$player_url = $CFG['site']['url'] . 'files/flash/mp3_player/player.swf';
		$audios_folder = $CFG['admin']['ans_audios']['audio_folder'];
		$config_url = getUrl($CFG['site']['url'] . 'ansAudioConfigXmlCode.php?pg=music_' . $ViewAudio->getFormField('aid'), $CFG['site']['url'] . 'ansAudioConfigXmlCode.php?pg=music_' . $ViewAudio->getFormField('aid'), false);
		$playlist_url = getUrl($CFG['site']['url'] . 'ansAudioPlaylistXmlCode.php?pg=music_' . $ViewAudio->getFormField('aid'), $CFG['site']['url'] . 'ansAudioPlaylistXmlCode.php?pg=music_' . $ViewAudio->getFormField('aid'), false);
		echo '<div><object height="66" width="250"><param name="movie" value="' . $player_url . '?configXmlPath=' . $config_url . '&playListXmlPath=' . $playlist_url . '"></param><param name="wmode" value="' . $CFG['admin']['wmode_value'] . '" /><embed src="' . $player_url . '?configXmlPath=' . $config_url . '&playListXmlPath=' . $playlist_url . '" type="application/x-shockwave-flash" wmode="' . $CFG['admin']['wmode_value'] . '" height="66" width="250"></embed></object></div>';
}
?>
	</div>
</div>
<?php


$ViewAudio->setHeaderEnd();
?>