<?php
	//controller, videos.php
	$lang['page_title']					= 'Videos';
	$lang['video_info_title']			= 'Title';
	$lang['video_info_tags']			= 'Tags';
	$lang['video_info_description']		= 'Description';
	$lang['video_info_share_type']		= 'Share Type';
	$lang['video_label_terms']			= 'You must agree the terms and conditions.';
	$lang['video_upload_success_msg']	= 'Video has been successfully uploaded.';
	$lang['video_info_success_msg']		= 'Video information has been successfully saved.';
	$lang['video_info_error_msg']		= 'Video information has not been.';
	$lang['video_record_success_msg']	= 'Video has been successfully recorded.';
	$lang['video_record_error_msg']		= 'Video has not been recorded. Try Again !';
	$lang['video_new_entry_error_msg']	= 'Error in adding new video entry in videos table.';
	$lang['video_already_rated']		= 'Already rated.';
	$lang['video_rate_error_msg']		= 'Sorry ! Error in store rate value to database !';
	$lang['video_rate_success_msg']		= 'Thanks for the rating !';
	$lang['video_delete_error_msg']		= 'Video has not been deleted.';
	$lang['video_delete_success_msg']	= 'Video has been deleted.';

	//template, videos.tpl
	$lang['video_label_my_videos']						= 'My Videos';
	$lang['video_label_my_friends_videos']				= 'My Friends Videos';
	$lang['video_label_recently_uploaded_videos']		= 'Recently uploaded videos';
	$lang['video_no_videos_msg']						= 'No one has uploaded any videos yet!';
	$lang['video_label_welcome_to_videos']				= 'Welcome to videos';
	$lang['video_label_upload_video_hint']				= 'Upload and tag videos of you and your friends';
	$lang['video_label_record_video_hint']				= 'Use your webcam to record yourself in a video message.';
	$lang['video_label_upload_new_video']				= 'Upload a new video';
	$lang['video_label_record_new_video']				= 'Record a video message';

	//videoscreateinfo.tpl
	$lang['video_head_create_video_info']				= 'Add/Edit video information';
	$lang['video_label_common_save_info']				= 'After you finish editing your video data, click "Save" to continue';

	//videosfriends.tpl
	$lang['video_label_friends_have_no_videos']			= 'Your friends not yet uploaded any videos !';
	$lang['video_label_no_friends']						= 'You have no friends !';

	//videosmyvideos.tpl
	$lang['video_label_you_have_no_videos']				= 'You have not yet uploaded any videos !';

	//videosplay.tpl
	$lang['video_delete_confirm_msg']					= 'Do you really want to delete this video';
	$lang['video_label_total_view']						= 'Total View';
	$lang['video_label_edit']							= 'Edit video information';
	$lang['video_label_delete']							= 'Delete this Video';
	$lang['video_label_title']							= 'Video Title';
	$lang['video_label_about_video']					= 'About Video';
	$lang['video_label_updated_on']						= 'Updated On';
	$lang['video_label_see_all']						= 'See All';
	$lang['video_label_wrote']							= 'wrote';
	$lang['video_label_at']								= 'at';
	$lang['video_label_delete_post']					= 'Delete';
	$lang['video_label_displaying']						= 'Displaying';
	$lang['video_label_out_of']							= 'out of';
	$lang['video_label_posts']							= 'posts';
	$lang['video_label_write_on']						= 'Write on';
	$lang['video_label_my']								= 'my';
	$lang['video_label_wall']							= 'Wall';

	//videosrate.tpl
	$lang['video_label_rate_this']						= 'Rate this video';

	//videosrecorder.tpl
	$lang['video_label_record_video']					= 'Record Video';

	//videosupload.tpl
	$lang['video_label_upload_new_video']				= 'Upload New Videos';
	$lang['video_label_you_can_upload_a']				= 'You can upload a';
	$lang['video_upload_terms']							= 'I certify that I have the right to distribute this picture and that it does not violate the Terms of Use.';
	$lang['video_label_file_size_limit']				= 'File size limit';
	$lang['video_label_upload_does_not_work']			= 'If your upload does not work, try a smaller video.';

	$lang['video_label_by']								= 'By';
?>