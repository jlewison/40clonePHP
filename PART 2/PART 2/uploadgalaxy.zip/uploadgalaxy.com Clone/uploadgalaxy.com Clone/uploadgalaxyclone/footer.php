<table width="100%" border="0">
  <tr>
    <td><div align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="index.php">Home</a>        | <a href="mailto:admin@popscript.com">Contact</a> |
          <a href="http://mugen.33host.com/ffh">&copy; 2005
           kalekale upload scripts All Rights Reserved.</a></font></div></td>
  </tr>
</table>
