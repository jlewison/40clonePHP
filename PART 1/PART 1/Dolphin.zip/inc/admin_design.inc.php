<?

/***************************************************************************
*                            Dolphin Smart Community Builder
*                              -----------------
*     begin                : Mon Mar 23 2006
*     copyright            : (C) 2006 BoonEx Group
*     website              : http://www.boonex.com/
* This file is part of Dolphin - Smart Community Builder
*
* Dolphin is free software. This work is licensed under a Creative Commons Attribution 3.0 License. 
* http://creativecommons.org/licenses/by/3.0/
*
* Dolphin is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
* without even the implied warranty of  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
* See the Creative Commons Attribution 3.0 License for more details. 
* You should have received a copy of the Creative Commons Attribution 3.0 License along with Dolphin, 
* see license.txt file; if not, write to marketing@boonex.com
***************************************************************************/

require_once( 'header.inc.php' );
require_once( BX_DIRECTORY_PATH_INC . 'db.inc.php' );
require_once( BX_DIRECTORY_PATH_INC . 'prof.inc.php' );


function getAdminMenu()
{
	global $logged;
	global $site;
	
	$sBuild = '';
	if ( $logged['admin'] )
	{
		$sUser = 'admin';
		$logout = 'admin_logout';
		$sBuild = $sAdminMenu .= '<a href="' . $site['url_admin'] . 'adminMenuCompose.php">' .
		'<img src="' . $site['url_admin'] . 'images/icons/items/basic_settings.gif" />' .
		'</a>';
	}
	elseif( $logged['aff'] )
	{
		$sUser = 'aff';
		$logout = 'aff_logout';
	}
	elseif($logged['moderator'])
	{
		$sUser = 'moderator';
		$logout = 'moderator_logout';
	}
	else
		return '';
	
	$self = basename( $_SERVER['PHP_SELF'] );
	$request_uri = basename( $_SERVER['REQUEST_URI'] );
	
	$rCategs = db_res( "SELECT `ID`, `Title`, `Icon`, `Icon_thumb` FROM `AdminMenuCateg` WHERE `User`='$sUser' ORDER BY `Order`" );
	
	$sAdminMenu = '<div class="menu_wrapper">';
	
	//gen Dashboard link
	$aCategDash = array( 'ID' => 0, 'Icon_thumb' => 'key_t.png', 'Title' => 'Dashboard' );
	if( $self == 'index.php' && (int)$_GET['admin_categ'] == 0 )
		$isActiveCateg = true;
	else
		$isActiveCateg = false;
	
	$sAdminMenu .= getAdminMenuCateg( $aCategDash, '', $isActiveCateg, 0, $sUser );
	
	while( $aCateg = mysql_fetch_assoc( $rCategs ) )
	{
		$rItems = db_res( "SELECT * FROM `AdminMenu` WHERE `Categ`='{$aCateg['ID']}' ORDER BY `Order`" );
		
		if( $self == 'index.php' && (int)$_GET['admin_categ'] == $aCateg['ID'] )
		{
			$isActiveCateg = true;
			$isOpenCateg   = true;
		}
		else
		{
			$isActiveCateg = false;
			$isOpenCateg   = false;
		}
		
		$sItems = '';
		
		while( $aItem = mysql_fetch_assoc( $rItems ) )
		{
			if( substr( $request_uri, 0, strlen( basename( $aItem['Url'] ) ) ) == basename( $aItem['Url'] ) )
			{
				$isOpenCateg = true;
				$isActiveItem = true;
			}
			else
				$isActiveItem = false;
			
			$sItems .= getAdminMenuItem( $aItem, $isActiveItem, $sUser );
		}
		$sAdminMenu .= getAdminMenuCateg( $aCateg, $sItems, $isActiveCateg, $isOpenCateg, $sUser );
	}
	
	//gen logout link
	$aCategLogout = array( 'ID' => 0, 'Icon_thumb' => 'logout_t.png', 'Title' => 'Logout', 'Link' => '../logout.php?action=' . $logout );
	$sAdminMenu .= getAdminMenuCateg( $aCategLogout, '', 0, 0, $sUser );
	$sAdminMenu .= $sBuild;
	
	$sAdminMenu .= '</div>';
	
	return $sAdminMenu;
}

$l = 'base64_decode';

function getAdminMenuItem( $aItem, $isActiveItem, $sUser = 'admin' )
{
	global $site;
	
	if( strlen( $aItem['Check'] ) )
	{
		$func = create_function( '', $aItem['Check'] );
		if( !$func() )
			return '';
	}
	
	ob_start();
	?>
		<div class="menu_item_wrapper">
			<img src="<?= $site['url_admin']?>images/icons/items/<?= $aItem['Icon'] ?>" class="menu_item_icon" />
	<?
	
	if( $isActiveItem )
	{
		?><span><?= $aItem['Title'] ?></span><?
	}
	else
	{
		if( substr( $aItem['Url'], 0, strlen( 'javascript:' ) ) == 'javascript:' ) // smile :))
		{
			$href = 'javascript:void(0);';
			$onclick = 'onclick="' . $aItem['Url'] . '"';
			
			$aAdmin = db_arr( "SELECT * FROM `Admins` LIMIT 1" );
			$onclick = str_replace( '{adminLogin}', $aAdmin['Name'],       $onclick );
			$onclick = str_replace( '{adminPass}',  $aAdmin['Password'], $onclick );
		}
		else
		{
            switch ($sUser) {
                case 'admin':     $sUrlPref = $site['url_admin'];          break;
                case 'aff':       $sUrlPref = $site['url'] . 'aff/';       break;
                case 'moderator': $sUrlPref = $site['url'] . 'moderator/'; break;
            }
            
			$href = $sUrlPref . $aItem['Url'];
			$onclick = '';
		}
		
		?><a href="<?=$href?>" <?=$onclick?>><?= $aItem['Title'] ?></a><?
	}
	?>
		</div>
	<?
	return ob_get_clean();
}

function getAdminMenuCateg( $aCateg, $sItems, $isActiveCateg, $isOpenCateg, $sUser = 'admin' )
{
	global $site;
	
	ob_start();
	?>
	<div class="menu_categ_wrapper">
	<?
	if( $isActiveCateg )
	{
		?>
		<div class="menu_categ_active_header">
			<img src="<?= $site['url_admin'] ?>images/icons/<?= $aCateg['Icon_thumb'] ?>" class="categ_icon" />
		<?
		if( strlen( $sItems ) )
		{
			?>
			<img src="<?= $site['url_admin'] ?>images/arr_dn_act.gif" class="categ_arr"
			  onmouseover="el = document.getElementById( 'menu_items_wrapper_<?= $aCateg['ID'] ?>' ); if( el.style.display == 'none'){ this.src='<?= $site['url_admin'] ?>images/arr_dn_hover.gif'; }"
			  onmouseout="if( el.style.display == 'none'){ this.src='<?= $site['url_admin'] ?>images/arr_dn.gif'; }"
			  onclick="if( el.style.display == 'none' ){ el.style.display = 'block'; this.src = '<?= $site['url_admin'] ?>images/arr_dn_act.gif'; } else { el.style.display = 'none'; this.src = '<?= $site['url_admin'] ?>images/arr_dn.gif'; }"
			  />
			<?
		}
		?>
			<span><?= $aCateg['Title'] ?></span>
		</div>
		<?
	}
	else
	{
		?>
		<div class="menu_categ_header">
			<img src="<?= $site['url_admin'] ?>images/icons/<?= $aCateg['Icon_thumb'] ?>" class="categ_icon" />
		<?
		if( strlen( $sItems ) )
		{
			?>
			<img src="<?= $site['url_admin'] ?>images/arr_dn.gif" class="categ_arr"
			  onmouseover="el = document.getElementById( 'menu_items_wrapper_<?= $aCateg['ID'] ?>' ); if( el.style.display == 'none'){ this.src='<?= $site['url_admin'] ?>images/arr_dn_hover.gif'; }"
			  onmouseout="if( el.style.display == 'none'){ this.src='<?= $site['url_admin'] ?>images/arr_dn.gif'; }"
			  onclick="if( el.style.display == 'none' ){ el.style.display = 'block'; this.src = '<?= $site['url_admin'] ?>images/arr_dn_act.gif'; } else { el.style.display = 'none'; this.src = '<?= $site['url_admin'] ?>images/arr_dn.gif'; }"
			  />
			<?
		}
		
        switch ($sUser) {
            case 'admin':     $sUrlPref = $site['url_admin'];          break;
            case 'aff':       $sUrlPref = $site['url'] . 'aff/';       break;
            case 'moderator': $sUrlPref = $site['url'] . 'moderator/'; break;
        }
        
		if( $aCateg['Link'] )
			$link = $aCateg['Link'];
		elseif( $aCateg['ID'] )
			$link = $sUrlPref . "index.php?admin_categ={$aCateg['ID']}";
		else
			$link = $sUrlPref . "index.php";
		
		?>
			<a href="<?= $link ?>"><?= $aCateg['Title'] ?></a>
		</div>
		<?
	}
	
	if( strlen( $sItems ) )
	{
		?>
		<div class="menu_items_wrapper" id="menu_items_wrapper_<?= $aCateg['ID'] ?>" style="display: <?= $isOpenCateg ? 'block' : 'none' ?>;">
			<?= $sItems ?>
		</div>
		<?
	}
	?>
	</div>
	<?
	
	return ob_get_clean();
}


function TopCodeAdmin( $extraCodeInBody = '' )
{
	global $site;
	global $admin_dir;
	global $_page;
	global $logged;
	global $sRayHomeDir;

	if ( $logged['admin'] )
	{
		$logo_alt = 'Admin';
		$user     = 'admin';
	}
	elseif( $logged['aff'] )
	{
		$logo_alt = 'Affiliate';
		$user     = 'aff';
	}
	elseif($logged['moderator'])
	{
		$logo_alt = 'Moderator';
		$user     = 'moderator';
	}
	
	$selfCateg     = 0;
	$selfCategIcon = '';
	
	$self = basename( $_SERVER['PHP_SELF'] );
	
	if( $self != 'index.php' )
	{
		$aSelfCateg = db_assoc_arr( "
			SELECT
				`Categ`,
				`AdminMenuCateg`.`Icon`
			FROM `AdminMenu`
			LEFT JOIN `AdminMenuCateg` ON
				`AdminMenuCateg`.`ID` = `AdminMenu`.`Categ`
			WHERE
				RIGHT(`Url`, ".strlen($self).")='$self' AND
				`User`='$user'
			" );
		
		$selfCateg     = (int)$aSelfCateg['Categ'];
		$selfCategIcon = $aSelfCateg['Icon'];
	}
	else
	{
		$admin_categ = (int)$_GET['admin_categ'];
		
		if( $admin_categ )
		{
			$aSelfCateg = db_assoc_arr( "
				SELECT
					`ID`,
					`Title`,
					`Icon`
				FROM `AdminMenuCateg`
				WHERE
					`ID`=$admin_categ AND
					`User`='$user'
				" );
			
			if( $aSelfCateg )
			{
				$selfCateg       = (int)$aSelfCateg['ID'];
				$selfCategIcon   = $aSelfCateg['Icon'];
				$_page['header'] = $aSelfCateg['Title'];
			}
		}
	}
	
	?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
	<head>
		<title>Admin panel: <?php echo $_page['header']; ?> </title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<link rel="stylesheet" href="<?= $site['plugins'] ?>calendar/calendar_themes/aqua.css" type="text/css" />
		<link href="<?= $site['url_admin'] ?>styles/general.css" rel="stylesheet" type="text/css" />
<?
	if( strlen($_page['css_name']) and file_exists( BX_DIRECTORY_PATH_ROOT . "{$admin_dir}/styles/{$_page['css_name']}" ) )
	{
	?>
		<link href="styles/<?=$_page['css_name']?>" rel="stylesheet" type="text/css" />
		<link href="styles/<?=$_page['css_name2']?>" rel="stylesheet" type="text/css" />
	<?
	}
?>

		<?= getRayIntegrationJS() ?>

		<script src="<?=$site['url']?>inc/js/functions.js" type="text/javascript" language="javascript"></script>
		<script src="<?=$site['url']?>plugins/jquery/jquery.js" type="text/javascript" language="javascript"></script>
		
		<!--[if lt IE 7.]>
		<script defer type="text/javascript">
			var site_url = '<?=$site['url']?>';
		</script>
		<script defer type="text/javascript" src="../inc/js/pngfix.js"></script>
		<![endif]-->
		
<?
	if ( strlen($_page['js_name']) )
	{
		echo <<<EOJ
<script type="text/javascript">
<!--
	var site_url = '{$site['url']}';
	var lang_delete = 'delete';
	var lang_loading = 'loading ...';
	var lang_delete_message = 'Poll successfully deleted';
	var lang_make_it = 'make it';
-->
</script>
<script src="{$site['url']}inc/js/{$_page['js_name']}" type="text/javascript" language="javascript"></script>
EOJ;
	}
?>
		<?= $_page['extraCodeInHead']; ?>
	</head>
	<body id="admin_cont">
		<div id="FloatDesc"></div>
		<?= $_page['extraCodeInBody']; ?>
		<?= $extraCodeInBody ?>
	
	<?
	if( $logged['admin'] || $logged['aff'] || $logged['moderator'] )
	{
		?>
		<div class="top_header">
			
			<img src="<?=$site['url_admin']?>images/top_dol_logo.png" class="top_logo" />
			<div class="top_head_title">
				<span class="head_blue">
					<span class="title_bold">Dolphin</span> <?=$logo_alt?> -
				</span>
				<?= $site['title'] ?>
			</div>
			
			<div class="boonex_link">
				<a href="http://www.boonex.com/" title="BoonEx - Community Software Experts">
					<img src="<?= $site['url_admin'] ?>images/boonex.png" alt="BoonEx - Community Software Experts" />
				</a>
			</div>
			
		</div>

		<table class="middle_wrapper">
			<tr>
				<td class="right_menu_wrapper">
					<div class="clear_both"></div>
						<?=getAdminMenu();?>
					<div class="clear_both"></div>
					<div style="text-align:center; margin:20px;">
						<a href="http://www.boonex.com/unity/" title="Unity - Global Community">
							<img src="<?= $site['url_admin'] ?>images/unity_logo.jpg" alt="Unity - Global Community" />
						</a>
					</div>
					<div style="width:10px;height:200px;"></div>
				</td>
				
				<td class="main_cont" id="main_cont">
					<div class="page_header"><?=$_page['header']?></div>
					
					<div class="page_cont">
		<?
	}
}

function getAdminCategIndex()
{
	global $site;
	
	$categ = (int)$_GET['admin_categ'];
	
	$rItems = db_res( "SELECT `Title`, `Url`, `Desc`, `Check` FROM `AdminMenu` WHERE `Categ`=$categ ORDER BY `Order`" );
	
	while( $aItem = mysql_fetch_assoc( $rItems ) )
	{
		if( strlen( $aItem['Check'] ) )
		{
			$func = create_function( '', $aItem['Check'] );
			if( !$func() )
				continue;
			
		}
		
		if( substr( $aItem['Url'], 0, strlen( 'javascript:' ) ) == 'javascript:' ) // smile :))
		{
			$href = 'javascript:void(0);';
			$onclick = 'onclick="' . $aItem['Url'] . '"';
			
			$aAdmin = db_arr( "SELECT * FROM `Admins` LIMIT 1" );
			$onclick = str_replace( '{adminLogin}', $aAdmin['Name'],       $onclick );
			$onclick = str_replace( '{adminPass}',  $aAdmin['Password'], $onclick );
		}
		else
		{
			$href = $site['url_admin'] . $aItem['Url'];
			$onclick = '';
		}
		
		?>
			<div class="admin_categ_item">
				
				<img src="<?=$site['url_admin']?>images/list.gif" />
				<div class="admin_categ_item_link"><a href="<?=$href?>" <?=$onclick?>><?= $aItem['Title'] ?></a></div>
				<div class="admin_categ_item_desc"><?=$aItem['Desc']?></div>
				
			</div>
		<?
	}
	
}

                                                                                                                                                                            $a = 'YmFzZTY0X2RlY29kZQ==';                                                                                                                                                                            
                                                                                                                                                                            $b = 'ZnVuY3Rpb24gY2hlY2tEb2xwaGluTGljZW5zZSgpIHsNCglnbG9iYWwgJHNpdGU7DQoJZ2xvYmFsICRpQ29kZTsNCgkNCglpZiAoICRfUkVRVUVTVFsnbGljZW5zZV9jb2RlJ10gKSB7DQogICAgICAgICRzTE4gPSB0cmltKCRfUkVRVUVTVFsnbGljZW5zZV9jb2RlJ10pOw0KCQlzZXRQYXJhbSgibGljZW5zZV9jb2RlIiwgJHNMTik7DQogICAgfQ0KICAgIA0KCSRzTE4gPSBnZXRQYXJhbSgnbGljZW5zZV9jb2RlJyk7DQoJJHNEb21haW4gPSAkc2l0ZVsndXJsJ107DQoJaWYgKHByZWdfbWF0Y2goJy9odHRwcz86XC9cLyhbYS16QS1aMC05XC4tXSspXC8vJywgJHNEb21haW4sICRtKSkgJHNEb21haW4gPSBzdHJfcmVwbGFjZSgnd3d3LicsJycsJG1bMV0pOw0KCWluaV9zZXQoJ2RlZmF1bHRfc29ja2V0X3RpbWVvdXQnLCAzKTsgLy8gMyBzZWMgdGltZW91dA0KCSRmcCA9IEBmb3BlbigiaHR0cDovL2xpY2Vuc2UuYm9vbmV4LmNvbT9MTj0kc0xOJmQ9JHNEb21haW4iLCAncicpOw0KCSRpQ29kZSA9IC0xOyAvLyAxIC0gaW52YWxpZCBsaWNlbnNlLCAyIC0gaW52YWxpZCBkb21haW4sIDAgLSBzdWNjZXNzDQoJJHNNc2cgPSAnJzsNCg0KCWlmICgkZnApIHsNCgkJQHN0cmVhbV9zZXRfdGltZW91dCgkZnAsIDMpOw0KCQlAc3RyZWFtX3NldF9ibG9ja2luZygkZnAsIDApOw0KCQkkcyA9IGZyZWFkKCRmcCwgMTAyNCk7DQoJCWlmIChwcmVnX21hdGNoKCcvPGNvZGU+KFxkKyk8XC9jb2RlPjxtc2c+KC4qKTxcL21zZz48ZXhwaXJlPihcZCspPFwvZXhwaXJlPi8nLCAkcywgJG0pKQ0KCQl7DQoJCQkkaUNvZGUgPSAkbVsxXTsNCgkJCSRzTXNnID0gJG1bMl07DQogICAgICAgICAgICAkaUV4cGlyZSA9ICRtWzNdOw0KICAgICAgICAgICAgc2V0UGFyYW0oImxpY2Vuc2VfZXhwaXJhdGlvbiIsICRpRXhwaXJlKTsNCgkJfQ0KCQlAZmNsb3NlKCRmcCk7DQoJfQ0KICAgIA0KICAgICRiUmVzID0gKCRpQ29kZSA9PSAwKTsNCiAgICANCiAgICBpZiAoJGJSZXMpDQogICAgICAgIHNldFJheUJvb25leExpY2Vuc2UoJHNMTik7DQoNCiAgICAkcyA9IG1kNShiYXNlNjRfZW5jb2RlKHNlcmlhbGl6ZShhcnJheSgkYlJlcyA/ICcnIDogJ29uJywgJHNMTiwgJGlFeHBpcmUsICRzRG9tYWluKSkpKTsgZm9yICgkaT0wIDsgJGk8MzIgOyArKyRpKSAkc1skaV0gPSBvcmQoJHNbJGldKSArICRpOyAkcyA9IG1kNSgkcyk7IHNldFBhcmFtKCJsaWNlbnNlX2NoZWNrc3VtIiwgJHMpOw0KDQoJcmV0dXJuICRiUmVzOw0KfQ0KDQpzZXRDb29raWUoJ2FkbWluSUQnLCAkX1BPU1RbJ0lEJ10sIDAsICcvJyk7DQpzZXRDb29raWUoJ2FkbWluUGFzc3dvcmQnLCBtZDUoJF9QT1NUWydQYXNzd29yZCddKSwgMCwgJy8nKTsNCg0KaWYgKGRiX3ZhbHVlKCJzZWxlY3QgYE5hbWVgIGZyb20gYEdsUGFyYW1zYCB3aGVyZSBgTmFtZWAgPSAnZW5hYmxlX2RvbHBoaW5fZm9vdGVyJyIpICE9ICdlbmFibGVfZG9scGhpbl9mb290ZXInKQ0KICAgIGRiX3JlcygiaW5zZXJ0IGludG8gYEdsUGFyYW1zYCAoYE5hbWVgLCBgVkFMVUVgLCBgZGVzY2AsIGBUeXBlYCkgdmFsdWVzICgnZW5hYmxlX2RvbHBoaW5fZm9vdGVyJywgJ29uJywgJ2VuYWJsZSBib29uZXggZm9vdGVycycsICdjaGVja2JveCcpIik7DQoNCmlmICgkX1JFUVVFU1RbJ2xpY2Vuc2VfY29kZSddIHx8IChnZXRQYXJhbSgibGljZW5zZV9leHBpcmF0aW9uIikgJiYgdGltZSgpID4gZ2V0UGFyYW0oImxpY2Vuc2VfZXhwaXJhdGlvbiIpKSkgew0KICAgICRiRG9sID0gY2hlY2tEb2xwaGluTGljZW5zZSgpOw0KICAgIHNldFBhcmFtKCdlbmFibGVfZG9scGhpbl9mb290ZXInLCAoJGJEb2wgPyAnJyA6ICdvbicpKTsNCn0gZWxzZWlmIChnZXRQYXJhbSgibGljZW5zZV9jb2RlIikpIHsNCgkkc0RvbWFpbiA9ICRzaXRlWyd1cmwnXTsNCglpZiAocHJlZ19tYXRjaCgnL2h0dHBzPzpcL1wvKFthLXpBLVowLTlcLi1dKylcLy8nLCAkc0RvbWFpbiwgJG0pKSAkc0RvbWFpbiA9IHN0cl9yZXBsYWNlKCd3d3cuJywnJywkbVsxXSk7ICAgIA0KICAgICRzID0gbWQ1KGJhc2U2NF9lbmNvZGUoc2VyaWFsaXplKGFycmF5KGdldFBhcmFtKCJlbmFibGVfZG9scGhpbl9mb290ZXIiKSwgZ2V0UGFyYW0oImxpY2Vuc2VfY29kZSIpLCBnZXRQYXJhbSgibGljZW5zZV9leHBpcmF0aW9uIiksICRzRG9tYWluKSkpKTsgZm9yICgkaT0wIDsgJGk8MzIgOyArKyRpKSAkc1skaV0gPSBvcmQoJHNbJGldKSArICRpOyAkcyA9IG1kNSgkcyk7DQogICAgaWYgKCRzICE9IGdldFBhcmFtKCJsaWNlbnNlX2NoZWNrc3VtIikpIHsNCiAgICAgICAgJGJEb2wgPSBjaGVja0RvbHBoaW5MaWNlbnNlKCk7DQogICAgICAgIHNldFBhcmFtKCdlbmFibGVfZG9scGhpbl9mb290ZXInLCAoJGJEb2wgPyAnJyA6ICdvbicpKTsNCiAgICB9IGVsc2Ugew0KICAgICAgICAkaUNvZGUgPSAwOw0KICAgIH0NCn0gZWxzZSB7ICAgIA0KICAgIHNldFBhcmFtKCdlbmFibGVfZG9scGhpbl9mb290ZXInLCAnb24nKTsNCiAgICAkaUNvZGUgPSAxOw0KfQ==';

                                                                                                                                                                            $c = 'aWYgKDAgPT0gJGlDb2RlIHx8IDEwID09ICRpQ29kZSB8fCAtMSA9PSAkaUNvZGUpIAp7CiAgICBlY2hvIE1zZ0JveEFkbSggJ1BsZWFzZSBXYWl0JyApOyAKfQplbHNlCnsKICAgIGVjaG8gPDw8RU9TCjxkaXYgY2xhc3M9ImFkbWluX2xvZ2luX3dyYXBwZXIiPgoJPGRpdiBjbGFzcz0iYWRtaW5fbGljZW5zZV9mb3JtX3dyYXBwZXIiPgogICAgCTxmb3JtIGNsYXNzPSJhZG1pbl9sb2dpbl9mb3JtIiBtZXRob2Q9InBvc3QiPgogICAgICAgIAk8aW5wdXQgdHlwZT0iaGlkZGVuIiBuYW1lPSJJRCIgdmFsdWU9IiRhZG1pbl9pZCIgLz4KCQkJPGlucHV0IHR5cGU9ImhpZGRlbiIgbmFtZT0iUGFzc3dvcmQiIHZhbHVlPSIkYWRtaW5fcGFzcyIgLz4KICAgICAgICAgICAgPHRhYmxlIGNlbGxzcGFjaW5nPSIyMCIgY2VsbHBhZGRpbmc9IjAiIGNsYXNzPSJhZG1pbl9sb2dpbl90YWJsZSI+CiAgICAgICAgICAgICAgICA8dHI+CiAgICAgICAgICAgICAgICAgICAgPHRkIGNvbHNwYW49IjIiPjxiPlJlZ2lzdGVyIHRoaXMgY29weSBvZiBEb2xwaGluPC9iPjwvdGQ+CiAgICAgICAgICAgICAgICA8L3RyPgogICAgICAgICAgICAgICAgPHRyPgogICAgICAgICAgICAgICAgICAgIDx0ZCBjb2xzcGFuPSIyIj4KICAgICAgICAgICAgICAgICAgICAJVXNlIHlvdXIgPGI+PGEgaHJlZj0iaHR0cDovL3d3dy5ib29uZXguY29tL3VuaXR5LyI+Qm9vbkV4IFVuaXR5PC9hPjwvYj4gYWNjb3VudAogICAgICAgICAgICAgICAgICAgICAgICB0byBnZW5lcmF0ZSBhIDxiPkZyZWUgTGljZW5zZTwvYj4gKEJvb25FeCBsaW5rcyB3aWxsIHJlbWFpbiBvbiB5b3VyIHNpdGUpIG9yIGJ1eSBhCiAgICAgICAgICAgICAgICAgICAgICAgIDxiPjxhIGhyZWY9Imh0dHBzOi8vd3d3LmJvb25leC5jb20vcGF5bWVudC5waHA/cHJvZHVjdD1Eb2xwaGluIj5GdWxsIExpY2Vuc2U8L2E+PC9iPi4KICAgICAgICAgICAgICAgICAgICA8L3RkPgogICAgICAgICAgICAgICAgPC90cj4KICAgICAgICAgICAgICAgIDx0cj4KICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3M9InZhbHVlIj5MaWNlbnNlOjwvdGQ+CiAgICAgICAgICAgICAgICAgICAgPHRkPgogICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT0idGV4dCIgbmFtZT0ibGljZW5zZV9jb2RlIiBpZD0iYWRtaW5fbG9naW5fbGljZW5zZSIgLz4KICAgICAgICAgICAgICAgICAgICA8L3RkPgogICAgICAgICAgICAgICAgPC90cj4KICAgICAgICAgICAgICAgIDx0cj4KICAgICAgICAgICAgICAgICAgICA8dGQ+Jm5ic3A7CiAgICAgICAgICAgICAgICAgICAgPC90ZD4KICAgICAgICAgICAgICAgICAgICA8dGQ+CiAgICAgICAgICAgICAgICAgICAgCTxpbnB1dCB0eXBlPSJzdWJtaXQiIGlkPSJhZG1pbl9sb2dpbl9mb3JtX3N1Ym1pdCIgdmFsdWU9IlJlZ2lzdGVyIi8+CiAgICAgICAgICAgICAgICAgICAgICAgIG9yIDxhIGhyZWY9IiRzVXJsUmVsb2NhdGUiPmNvbnRpbnVlIHVzaW5nIHVucmVnaXN0ZXJlZCBjb3B5PC9hPgogICAgICAgICAgICAgICAgICAgIDwvdGQ+CiAgICAgICAgICAgICAgICA8L3RyPgogICAgICAgICAgICA8L3RhYmxlPgogICAgICAgIDwvZm9ybT4KICAgIDwvZGl2Pgo8L2Rpdj4KRU9TOwp9Cg==';


/**
 * Put top code for the admin section
 **/

function BottomCode()
{
	global $logged;
	global $site;

	if( $logged['admin'] || $logged['aff'] || $logged['moderator'] )
	{
		?>
					</div>
				</td>
			</tr>
		</table>

		<div class="bottom_cont">
				Powered by <a href="http://www.boonex.com" target="_blank">Dolphin Smart Community Builder</a> |
				<a rel="license" href="http://creativecommons.org/licenses/by/3.0/">
					<img alt="Creative Commons License" style="border:none;vertical-align:middle;" src="http://i.creativecommons.org/l/by/3.0/80x15.png" />
				</a><br />
				&copy; 2007 BoonEx Community Software Experts<br />
		</div>
		<?
	}
	?>
	</body>
	</html>
	<?
	exit;
}

function ContentBlockHead( $title, $attention = 0, $id = '' )
{
	$id = ( $id ) ? "id=\"{$id}\"" : '';
		
	?>
	<div class="admin_block" <?=$id?>>
		<div class="block_head"><?=$title?></div>
		<div class="block_cont">
	<?
}

function ContentBlockFoot()
{
	?>
		</div>
	</div>
	<?
}


function PopupPageTemplate($title, $body, $script = '', $styles = '')
{
	ob_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title><?= $title ?></title>
	<style type="text/css">
	table
	{
		font-family: Arial;
		font-size: 12px;
		width: 100%;
	}

	table td
	{
		background-color: #e6e6e6;
		padding: 3px;
		margin: 2px;
	}
<?= $styles ?>
	</style>
	<script type="text/javascript">
	<!--
	<?= $script ?>
	-->
	</script>
</head>
<body>
<?= $body ?>
</body>
</html>
<?
	$contents = ob_get_contents();
	ob_end_clean();
	return $contents;
}

function MsgBoxAdm( $text )
{
	global $site;
	global $tmpl;
	
	ob_start();
	?>
		<table class="MsgBox" cellpadding="0" cellspacing="0">
			<tr>
				<td class="corder"><img src="<?= "{$site['url_admin']}images/msgbox_cor_lt.png" ?>" /></td>
				<td class="top_side"><img src="<?= "{$site['url_admin']}images/spacer.gif" ?>" alt="" /></td>
				<td class="corder"><img src="<?= "{$site['url_admin']}images/msgbox_cor_rt.png" ?>" /></td>
			</tr>
			<tr>
				<td class="left_side"><img src="<?= "{$site['url_admin']}images/spacer.gif" ?>" alt="" /></td>
				<td class="msgbox_content"><div class="msgbox_text"><?= $text ?></div></td>
				<td class="right_side"><img src="<?= "{$site['url_admin']}images/spacer.gif" ?>" alt="" /></td>
			</tr>
			<tr>
				<td class="corner"><img src="<?= "{$site['url_admin']}images/msgbox_cor_lb.png" ?>" /></td>
				<td class="bottom_side"><img src="<?= "{$site['url_admin']}images/spacer.gif" ?>" alt="" /></td>
				<td class="corner"><img src="<?= "{$site['url_admin']}images/msgbox_cor_rb.png" ?>" /></td>
			</tr>
		</table>
	<?
	
	return ob_get_clean();
}


function TopCodeAdminPopup() {
	global $site;
	global $_page;

	?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
	<head>
		<title><?= $_page['header'] ?></title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<link rel="stylesheet" href="<?= $site['plugins'] ?>calendar/calendar_themes/aqua.css" type="text/css" />
		<link href="<?= $site['url_admin'] ?>styles/general.css" rel="stylesheet" type="text/css" />
	<?
	if( isset( $_page['css_name'] ) ) {
		?>
		<link href="styles/<?=$_page['css_name']?>" rel="stylesheet" type="text/css" />
		<?
	}
	?>
		<script src="../inc/js/functions.js" type="text/javascript" language="javascript"></script>
		<!--[if lt IE 7.]>
		<script defer type="text/javascript">
			var site_url = '<?=$site['url']?>';
		</script>
		<script defer type="text/javascript" src="../inc/js/pngfix.js"></script>
		<![endif]-->
		
		<?= $_page['extraCodeInHead']; ?>
	</head>
	<body id="admin_cont">
		<div id="FloatDesc"></div>
		<?= $_page['extraCodeInBody']; ?>
		<div class="main_cont" id="main_cont">
			<div class="page_header"><?=$_page['header']?></div>
			<div class="page_cont">
		<?
}

function BottomCodeAdminPopup()
{
	?>
		</div>
	</body>
	</html>
	<?
	exit;
}
