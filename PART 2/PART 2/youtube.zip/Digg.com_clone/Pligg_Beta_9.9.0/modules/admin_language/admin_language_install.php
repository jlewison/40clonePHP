<?php
	$module_info['name'] = 'Admin Modify Language';
	$module_info['desc'] = 'Allows the god users to modify the lang.conf file';
	$module_info['version'] = 0.11;
	$module_info['requires'][] = array('scriptaculous', 0.1);
	// this is where you set the modules "name" and "version" that is required
	// if more that one module is required then just make a copy of that line
?>
