<?php
require_once ('./common/config.inc.php');
$CFG['lang']['include_files'][] = 'includes/languages/%s/login.php';
$CFG['html']['header'] = 'members/includes/languages/%s/html_header.php';
$CFG['html']['footer'] = 'members/includes/languages/%s/html_footer.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['lang']['include_files'][] = 'common/languages/%s/help.inc.php';
$CFG['mods']['is_include_only']['non_html_header_files'] = true;
require ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class LoginFormHandler extends FormHandler
{
		private $user_details_arr = array();
		public function chkIsBrowserAcceptsCookies()
		{
				return count($_COOKIE);
		}
		public function chkIsLoginSessionError()
		{
				return isset($_SESSION['login_error']);
		}
		public function chkIsNoFormErrors()
		{
				return $this->isValidFormInputs();
		}
		public function chkIsValidLoginDetail($table_name, $name, $password, $err_tip = '')
		{
				$sql = 'SELECT ' . $this->getUserTableFields(array('user_id', 'name', 'user_access', 'last_logged', 'name', 'time_zone', 'pref_lang', 'num_visits')) . ' FROM ' . $table_name . ' WHERE ' . $this->getUserTableField('name') . ' =' . $this->dbObj->Param($name) . ' AND ' . 'password =' . $this->dbObj->Param($password) . ' AND ' . $this->getUserTableField('usr_status') . '=\'Ok\'';
				$condition_fields_value_arr = array($this->fields_arr[$name], md5($this->fields_arr[$password]));
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, $condition_fields_value_arr);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount())
				{
						$is_ok = true;
						$this->user_details_arr = $rs->FetchRow();
						$uid = $this->user_details_arr['user_id'];
				}
				else
				{
						$is_ok = false;
						$this->fields_err_tip_arr[$name] = $this->fields_err_tip_arr[$password] = $err_tip;
				}
				return $is_ok;
		}
		public function updateUserLog($table_name, $ip, $session_id)
		{
				$sql = 'UPDATE ' . $table_name . ' SET ' . $this->getUserTableField('last_logged') . '=NOW(), ' . $this->getUserTableField('num_visits') . '=' . $this->getUserTableField('num_visits') . '+1, ' . $this->getUserTableField('ip') . '=\'' . $ip . '\', ' . $this->getUserTableField('session') . '=\'' . $session_id . '\'' . ' WHERE ' . $this->getUserTableField('user_id') . '=' . $this->dbObj->Param('user_id');
				$stmt = $this->dbObj->Prepare($sql);
				$result = $this->dbObj->Execute($stmt, array($this->user_details_arr['user_id']));
				if (!$result) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function saveUserVarsInSession($ip)
		{
				$_SESSION = array();
				$_SESSION['user']['user_id'] = $this->user_details_arr['user_id'];
				$_SESSION['user']['name'] = $this->user_details_arr['name'];
				$_SESSION['user']['time_zone'] = $this->user_details_arr['time_zone'];
				$_SESSION['user']['pref_lang'] = $this->user_details_arr['pref_lang'];
				$_SESSION['user']['last_logged'] = $this->user_details_arr['last_logged'];
				$_SESSION['user']['num_visits'] = $this->user_details_arr['num_visits'];
				$_SESSION['user']['email'] = $this->user_details_arr['email'];
				$_SESSION['user']['is_logged_in'] = true;
				if ($this->user_details_arr['user_access'] == 'Admin') $_SESSION['user']['is_admin'] = true;
				$_SESSION['user']['useragent_hash'] = md5($_SERVER['HTTP_USER_AGENT']);
				$_SESSION['user']['ip'] = $ip;
				$_SESSION['url'] = $this->fields_arr['url'];
		}
		public function saveLoginCookie($remember)
		{
				if (!$remember) return;
				$expire = time() + 60 * 60 * 24 * 365;
				$cookie_str = $this->fields_arr['name'] . chr(31) . base64_encode($this->fields_arr['password']);
				setcookie($this->CFG['cookie']['name'] . '_login', $cookie_str, $expire, '/');
		}
		public function readCookieLogin($table_name, $name, $password, $err_tip = '')
		{
				$cookie_parts = explode(chr(31), $_COOKIE[$this->CFG['cookie']['name'] . '_login']);
				$Cname = $cookie_parts[0];
				$pass = base64_decode($cookie_parts[1]);
				$this->fields_arr['name'] = $Cname;
				$this->fields_arr['password'] = $pass;
				$sql = 'SELECT ' . $this->getUserTableFields(array('user_id', 'name', 'user_access', 'last_logged', 'email', 'time_zone', 'pref_lang', 'num_visits')) . ' FROM ' . $table_name . ' WHERE ' . $this->getUserTableField('name') . ' =' . $this->dbObj->Param($Cname) . ' AND ' . $this->getUserTableField('password') . ' =' . $this->dbObj->Param($pass) . ' AND ' . $this->getUserTableField('usr_status') . '=\'Ok\'';
				$condition_fields_value_arr = array($Cname, md5($pass));
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, $condition_fields_value_arr);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount())
				{
						$is_ok = true;
						$this->user_details_arr = $rs->FetchRow();
				}
				else
				{
						$is_ok = false;
						$this->fields_err_tip_arr[$name] = $this->fields_err_tip_arr[$password] = $err_tip;
				}
				return $is_ok;
		}
		public function redirectAjaxPages()
		{
				if (strpos($_SESSION['url'], 'avatars'))
				{
						$_SESSION['url'] = '';
						Redirect2URL(getUrl($this->CFG['site']['relative_url'] . 'manageSettings.php', $this->CFG['site']['relative_url'] . 'my/settings/', false));
				} elseif (strpos($_SESSION['url'], 'emailAnswers') || strpos($_SESSION['url'], 'email-answers') || strpos($_SESSION['url'], 'favoriteAnswers') || strpos($_SESSION['url'], 'ratingAnswer') || strpos($_SESSION['url'], 'audioupload') || strpos($_SESSION['url'], 'audioUpload') || strpos($_SESSION['url'], 'videoupload') || strpos($_SESSION['url'], 'videoUpload'))
				{
						$_SESSION['url'] = '';
						Redirect2URL(getUrl($this->CFG['site']['relative_url'] . 'questions.php', $this->CFG['site']['relative_url'] . 'answers/', false));
				} elseif (strpos($_SESSION['url'], 'emailBlogs') || strpos($_SESSION['url'], 'email-blogs') || strpos($_SESSION['url'], 'blogComment') || strpos($_SESSION['url'], 'blogcomment'))
				{
						$_SESSION['url'] = '';
						Redirect2URL(getUrl($this->CFG['site']['relative_url'] . 'blogs.php', $this->CFG['site']['relative_url'] . 'blog/', false));
				} elseif (strpos($_SESSION['url'], 'emailForums') || strpos($_SESSION['url'], 'email-forums'))
				{
						$_SESSION['url'] = '';
						Redirect2URL(getUrl($this->CFG['site']['relative_url'] . 'forums.php', $this->CFG['site']['relative_url'] . 'forum/', false));
				}
				else
				{
						Redirect2URL($this->CFG['auth']['members_url']);
				}
		}
}
$loginfrm = new LoginFormHandler();
$loginfrm->setCfgLangGlobal($CFG, $LANG);
$loginfrm->setPageBlockNames(array('msg_form_error', 'msg_session_error', 'form_login'));
$loginfrm->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$loginfrm->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$loginfrm->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$loginfrm->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$loginfrm->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$loginfrm->setFormField('name', '');
$loginfrm->setFormField('password', '');
$loginfrm->setFormField('remember', '');
$loginfrm->setFormField('rem', '');
$loginfrm->setFormField('url', (isset($_SESSION['url']) ? $_SESSION['url'] : ''));
$loginfrm->setAllPageBlocksHide();
$loginfrm->setPageBlockShow('form_login');
																																																																		/**
																																																																		 * 
																																																																		 * 	[iAG] NULLED
																																																																		 * 
																																																																		 **/
if (isset($_COOKIE[$CFG['cookie']['name'] . '_login']))
{
		$loginfrm->setDBObject($db);
		$loginfrm->readCookieLogin($CFG['db']['tbl']['users'], 'name', 'password', $LANG['login_err_tip_invalid']) or $loginfrm->setCommonErrorMsg($LANG['login_err_invalid_login']);
		if ($loginfrm->isValidFormInputs())
		{
				$loginfrm->updateUserLog($CFG['db']['tbl']['users'], $CFG['remote_client']['ip'], session_id());
				$loginfrm->saveUserVarsInSession($CFG['remote_client']['ip']);
				$loginfrm->redirectAjaxPages();
		}
		else
		{
				$loginfrm->setFormField('password', '');
				$loginfrm->setAllPageBlocksHide();
				$loginfrm->setPageBlockShow('msg_form_error');
				$loginfrm->setPageBlockShow('form_login');
		}
}
else
		if ($loginfrm->isFormPOSTed($_POST, 'login_submit'))
		{
				$loginfrm->sanitizeFormInputs($_POST);
				$loginfrm->setDBObject($db);
				$loginfrm->chkIsNotEmpty('name', $LANG['login_err_tip_compulsory']);
				$loginfrm->chkIsNotEmpty('password', $LANG['login_err_tip_compulsory']);
				$loginfrm->chkIsBrowserAcceptsCookies() or $loginfrm->setCommonErrorMsg($LANG['login_err_cookies_not_set']);
				$loginfrm->chkIsNoFormErrors() and ($loginfrm->chkIsValidLoginDetail($CFG['db']['tbl']['users'], 'name', 'password', $LANG['login_err_tip_invalid']) or $loginfrm->setCommonErrorMsg($LANG['login_err_invalid_login']));
				if ($loginfrm->isValidFormInputs())
				{
						$loginfrm->updateUserLog($CFG['db']['tbl']['users'], $CFG['remote_client']['ip'], session_id());
						$loginfrm->saveUserVarsInSession($CFG['remote_client']['ip']);
						$loginfrm->saveLoginCookie($loginfrm->getFormField('remember'));
						$loginfrm->redirectAjaxPages();
				}
				else
				{
						$loginfrm->setFormField('password', '');
						$loginfrm->setAllPageBlocksHide();
						$loginfrm->setPageBlockShow('msg_form_error');
						$loginfrm->setPageBlockShow('form_login');
				}
		} elseif ($loginfrm->chkIsLoginSessionError())
		{
				$loginfrm->setCommonErrorMsg($LANG[$_SESSION['login_error']]);
				unset($_SESSION['login_error']);
				$loginfrm->setPageBlockShow('msg_session_error');
		}
$CFG['mods']['is_include_only']['non_html_header_files'] = false;
$CFG['mods']['is_include_only']['html_header'] = true;
require ($CFG['site']['project_path'] . 'common/application_top.inc.php');


?>
<div id="selLogin">
	<h2><?php echo $LANG['login_title']; ?></h2>
<?php
if ($loginfrm->isShowPageBlock('msg_form_error'))
{
?>
		<div id="selMsgError">
			 <p><?php echo $LANG['msg_error_sorry']; ?> <?php echo $loginfrm->getCommonErrorMsg(); ?></p>
		</div>
<?php
}
if ($loginfrm->isShowPageBlock('msg_session_error'))
{
?>
		<div id="selMsgError">
			 <p><?php echo $loginfrm->getCommonErrorMsg(); ?></p>
		</div>
<?php
}
if ($loginfrm->isShowPageBlock('form_login'))
{
?>
		<form name="form_login" id="selFormLogin" method="post" action="<?php echo URL(getUrl($CFG['site']['relative_url'] . 'login.php', $CFG['site']['relative_url'] . 'login/', false)); ?>" autocomplete="off">
			<input type="hidden" name="url" id="url" value="<?php echo $loginfrm->getFormField('url'); ?>" />
			<table class="clsCommonTable" summary="<?php echo $LANG['login_tbl_summary']; ?>">
				<tr>
					<td class="<?php echo $loginfrm->getCSSFormLabelCellClass('name'); ?>"><?php ShowHelpTip('username'); ?><label for="name"><?php echo $LANG['login_user_name']; ?></label></td>
            <td class="<?php echo $loginfrm->getCSSFormFieldCellClass('name'); ?>"><?php echo $loginfrm->getFormFieldErrorTip('name'); ?>
              <span class="clsTextLeft"><span class="clsTextMiddle"><span class="clsTextRight"><input type="text" class="clsTextBox help" name="name" id="name" title="<?php ShowToolTip('username'); ?>" value="<?php echo $loginfrm->getFormField('name'); ?>" tabindex="<?php echo $loginfrm->getTabIndex(); ?>" /></span></span></span></td>
			    </tr>
				<tr>
					<td class="<?php echo $loginfrm->getCSSFormLabelCellClass('password'); ?>"><?php ShowHelpTip('password'); ?><label for="password"><?php echo $LANG['login_password']; ?></label></td>
            <td class="<?php echo $loginfrm->getCSSFormFieldCellClass('password'); ?>"><?php echo $loginfrm->getFormFieldErrorTip('password'); ?>
              <span class="clsTextLeft"><span class="clsTextMiddle"><span class="clsTextRight"><input type="password" class="clsTextBox help" name="password" id="password" title="<?php ShowToolTip('password'); ?>" value="<?php echo $loginfrm->getFormField('password'); ?>" tabindex="<?php echo $loginfrm->getTabIndex(); ?>" /></span></span></span></td>
			    </tr>
			    <tr>
					<td class="<?php echo $loginfrm->getCSSFormLabelCellClass('remember'); ?>"><?php ShowHelpTip('remember'); ?><label for="remember"><?php echo $LANG['login_remember']; ?></label></td>
            <td class="<?php echo $loginfrm->getCSSFormFieldCellClass('remember'); ?>"><?php echo $loginfrm->getFormFieldErrorTip('remember'); ?>
              <p class="clsBgCheckBox"><input type="checkbox" class="clsCheckBox" name="remember" id="remember" tabindex="<?php echo $loginfrm->getTabIndex(); ?>" /></p></td>
			    </tr>
			    <tr>
					<td class="clsFormFieldCellDefault">&nbsp;</td>
					<td class="<?php echo $loginfrm->getCSSFormFieldCellClass('submit'); ?>"><p class="clsSubmitTextBox clsLoginSubmitTextBox"><input type="submit" class="clsSubmitButton" name="login_submit" id="login_submit" tabindex="<?php echo $loginfrm->getTabIndex(); ?>" value="<?php echo $LANG['login_submit']; ?>" /></p></td>
		   	  	</tr>
  			</table>
		</form>
     <div class="clsLogin">   <p class="clsForgot"><a href="<?php echo getUrl($CFG['site']['relative_url'] . 'forgotPassword.php', $CFG['site']['relative_url'] . 'forgotpassword/', false); ?>"><?php echo $LANG['forget_password']; ?></a></p>
		<?php if (chkAllowedModule(array('registration')))
		{ ?>
		<p class="clsRegister"><a href="<?php echo getUrl($CFG['site']['relative_url'] . 'signup.php', $CFG['site']['relative_url'] . 'register/', false); ?>"><?php echo $LANG['new_user_signup_here']; ?></a></p>
		<?php } ?>
	</div>
<?php
}
?>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>
