<?php

if ( !defined( 'SMARTY_DIR' ) ) {
	include_once( 'init.php' );
}

include ( 'sessioninc.php' );

$mship = $_REQUEST['item_number'];

$mshipinfo = $db->getRow('select activedays, name from ! where roleid = ?', array( MEMBERSHIP_TABLE, $mship ) );

$activedays = $mshipinfo['activedays'];

$userrec = $db->getRow('select level, levelend from ! where id = ?', array(USER_TABLE, $_SESSION['UserId'] ) );

if ($userrec['levelend'] < time() or $userrec['level'] != $mship) { $userrec['levelend'] = time(); }

$levelend = strtotime("+$activedays day", $userrec['levelend']);

$sql = 'UPDATE ! SET level = ?, levelend = ?  WHERE id = ?';

$db->query( $sql, array( USER_TABLE, $mship, $levelend, $_SESSION['UserId'] ) );

$t->assign('level', $mshipinfo['name']);

$t->assign('rendered_page', $t->fetch('mshipchanged.tpl') );

$t->display( 'index.tpl' );

?>