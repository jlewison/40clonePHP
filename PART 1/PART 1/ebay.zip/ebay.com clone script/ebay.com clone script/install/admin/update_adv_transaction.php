<?php //00461
// Copyright Notice
// Web Site URL:  http://www.zeeways.com
// Script Owner eMail: mail@zeeways.com
// Date: April, 2007
// Script Name: Zeeways Auction Website PHP Script
// Copyright Details: This script is not free.  Do not Remove this Copy Right notice.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the site administrator.');exit(199);
?>
4+oV54C5WalwxtPibxCNQ66yrmxyAg20+wMUSE8Tnc5kE+MXZxEYzTr4M3tERW9sjLSAwioV8QN6
IM3I65C0aGjRbGev0xforW9xGAt51fQ5j1avcQnrJBzP8PYZS4ERl1WnG9BBJZ6OnSs//crHGrbJ
ABB83cnfGSqsnoqqIHgyLU4TYz8ljqAppICDaiiuRGxOUBpwXFReNnha4m/7hj4t3Czrlb8WH1dV
uHbrG1qRafTTs7dY+grRBSUMfZGCJ7FtBQv9VhQQS163Kbyos5joiAcj1HGdd2aA/tj/s16RO27V
Y2rPNAwFBFyBUbyPE0wqj5jR+0qgFerhqaALCq1hnUb+eEoNsIKSi/rbQFZaLD99AbOP7nSsNyN3
yWdazwlYrnuI9uqBKtOqwb5Bs0WtDYK7zzcL6vp/VxR761basM+Yk62ATWPR/wL8u0fBWT9sRVl6
BM/I1nCIovkgJsD8aotJIodHPN5HA8rnDrUeealP/AhigNCIm+BzyP1kFyiWO2WBTCCW0uiLp6ie
+G/MiPpFQLyDJlIeG6nw5NeJmG3MS+XNdpks8XmtC0nD6emOT1a2bO3crN5nVKTwai9tzn+F0saR
B0UioWuj20NDotUOo6wFJnMWK1nO2n+ZXCMdGCqZLZvKa+TleaT99bTTNuW+On6vPCy03S5dZKSq
bEEgd/Hxw8+XgfMwaHOJ96kNU7H/J6UkeRZuSAgy6D5bJS3jsYkMUWoHylV14DpfK9ytidTQXm3q
zksle/bYrfE7KgtFUqEbq867kjzwVv05orAN/tLnmH8uo6vQrdvIT/ff+I1qQ9gGrg4/c8TrnwdX
p6NbnB4o8DmOQL9u5w4/v8ngC2/X3cLxAstrBUlK8pwS4v8ecBTPNckVVp/h/T8Ibtm2M3Ks5BeO
aDGdQfNSW1zNCOHCNRQkZT4F9+xRjPLEiQ/YOyDN813kcE0Ph+MTiFGtvg/5FYM9L9WtS+W2I27Y
jzH2/o2MkPfTLHJyNV20n8yDZorSZmqh7gB1vtB0aX1fRSHsrFk5SX2uuLR0L8fWFlRdg97xCU3g
oQsFUkd3+OT6L+5v1SBis49bKe6movAwW2FRlG2HVJBaQL1H8PXLOl391NTupeYFYUlH1pC8aVZq
EbDPuwaUG4mUcMMDhLmlOgj0rIlRY+7ML9qrEsv6hf7w3vJKrOAYgyVFUlpLNRKxJ70cY38zgZa/
FZbQoYnH/FujBiyqE9Z29yNgxRjSvvjRzTqCT/BhIJX+rMEUPWTOB3lzeGHCFZ4IHJjhaisJ9Q5U
yxUqlkWe9V7iYP9VqLSjC8PA6Z4n8RJCW1ODdQDqVm+ihjpdRMuKONe/ciJQWErDYtjAAZgTCjmh
u2xB0dOKkkOCSm5RlzwSp0+LNoJN90Y19h0SN9uG5iEb0vSwV0zsCh1tQokl+N+VgPhDmylCrBAR
iYvvZgn4HfGBq6b5PMNg/ia/AO5LLu06zNYP4umNpqovM0NYiaofzERHD96P45zQMU6p26iCCfNn
v1VCgyo6BZggEPSsLA4XWT3uSY0CMTBOgQCqFLCcqsEv9ez8I5Auu0p8B7wisHa28Vjbddrv0QxD
aqJaq8DJ51jfLOImHPDdIqMxG303m6K4OM3yZWC+xW4dPkJc0tdAYw/uMTQhJ4YWDpMMAb6mompI
EZF3vylhXxDyVX8HttltmeDYS0XThF7nlZ/6V5P97X6XxxyHPi4IgeDUNBU6emXLjNBb9zF6gL7I
w/bB8oS0VMs4beVup5w/Ef4N9l/WJ4NoPzETpLTUXLZgMA8iLVt9YGucaqWMryhq5OC+yqKWOtoK
ee3my1D5ZimA0xdZWacfjcgnXsdHa9op50teW7YKU+dENrvdz8NSjSr7KNG=