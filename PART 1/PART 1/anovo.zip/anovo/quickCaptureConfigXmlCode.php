<?php
require_once ('common/config.inc.php');
require_once ('common/configs/config_encoder.inc.php');
require_once ('common/configs/config_ans_video.inc.php');
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['mods']['is_include_only']['non_html_header_files'] = true;
$CFG['auth']['is_authenticate'] = false;
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class XmlCode extends FormHandler
{
		public function setHeaderStart()
		{
				ob_start();
				header("Pragma: no-cache");
				header("Cache-Control: no-cache, must-revalidate");
				header("Expires: 0");
				header("Content-type: text/xml; charset=iso-8859-1");
		}
		public function getXmlCode()
		{
				$delete_path = $this->CFG['site']['url'] . 'deleteCapture.php?fname=' . $this->fields_arr['file_name'];
				$upload_path = getUrl($this->CFG['site']['url'] . 'members/videoUpload.php', $this->CFG['site']['url'] . 'members/videoupload/', false) . '?rid=' . $this->fields_arr['file_name'] . '&upload=true';
?>
<SETTINGS>
	<SERVER path="<?php echo $this->CFG['admin']['video']['red5_path']; ?>" />
	<PHP uploadpath="<?php echo $upload_path; ?>" deletepath="<?php echo $delete_path; ?>" jscall="true"/>
	<STREAM name="myvideo" seconds="<?php echo $this->CFG['admin']['ans_videos']['capture_second']; ?>" />
	<!-- Best Settings are quality="100" width="160" height="120" framerate="15" bandwidth="0"/-->
	<!-- If you change Any of these may or maynot Cause Frame Loss of Quality Loss. width and height will be selected Native modes of ur webcam / -->
	<VIDEO quality="100" width="160" height="120" framerate="15" bandwidth="0"/>
</SETTINGS>
<?php
		}
}
$XmlCode = new XmlCode();
$XmlCode->setHeaderStart();
$XmlCode->setDBObject($db);
$XmlCode->makeGlobalize($CFG, $LANG);
$XmlCode->setFormField('file_name', '');
$XmlCode->setPageBlockShow('get_code_form');
$XmlCode->sanitizeFormInputs($_REQUEST);
if ($XmlCode->isShowPageBlock('get_code_form'))
{
		$XmlCode->getXmlCode();
}
$XmlCode->setHeaderEnd();


?>