function toggleCalendar(objname){
	var DivDisplay = document.getElementById(objname).style;
	if (DivDisplay.display  == 'none') {
	  DivDisplay.display = 'block';
	}else{
	  DivDisplay.display = 'none';
	}
}

function setValue(objname, d){
	document.getElementById(objname).value = d;

	var dp = document.getElementById(objname+"_dp").value;
	if(dp == true){
		var date_array = d.split("-");
		document.getElementById(objname+"_day").selectedIndex = date_array[2];
		document.getElementById(objname+"_month").selectedIndex = date_array[1];
		document.getElementById(objname+"_year").value = date_array[0];
		
		toggleCalendar('div_'+objname);
	}
}

function tc_setDay(objname, dvalue){
	var obj = document.getElementById(objname);
	var date_array = obj.value.split("-");
	obj.value = date_array[0] + "-" + date_array[1] + "-" + dvalue;
}

function tc_setMonth(objname, mvalue){
	var obj = document.getElementById(objname);
	var date_array = obj.value.split("-");
	obj.value = date_array[0] + "-" + mvalue + "-" + date_array[2];
}

function tc_setYear(objname, yvalue){
	var obj = document.getElementById(objname);
	var date_array = obj.value.split("-");
	obj.value = yvalue + "-" + date_array[1] + "-" + date_array[2];
}