<?php

$lang['alpha_dash_space']		= "The %s field may only contain alpha-numeric characters, underscores, dashes and spaces.";
$lang['valid_url'] 				= "The %s field must contain a valid URL.";

?>