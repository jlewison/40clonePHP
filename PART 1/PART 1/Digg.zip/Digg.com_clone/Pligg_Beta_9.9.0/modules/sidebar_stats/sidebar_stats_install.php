<?php
	$module_info['name'] = 'Sidebar Stats';
	$module_info['desc'] = 'Sidebar Stats adds a module in your sidebar that displays various statistics corresponding to your Pligg site.';
	$module_info['version'] = 0.2;
	$module_info['requires'][] = array('PHP', 5);
?>