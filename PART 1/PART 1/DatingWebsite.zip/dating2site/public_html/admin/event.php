<?php
/* This is just a redirection program to add new event in admin.
	VIjay Nair

*/

if (isset($_GET['event_id']) && $_GET['event_id'] != ''){
	header("location: calendarevents.php?calendarid=".$_GET['calendarid']."&edit=".$_GET['event_id']);
} else {
	header("location: calendarevents.php?calendarid=".$_GET['calendarid']."&insert=event&timestamp=".$_GET['timestamp']);
}
exit;

?>