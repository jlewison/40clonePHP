<?
error_reporting(0);
if ($state == "") {
echo "<center><b>Installation</b><br><br>";
echo "supprimer ce fichier apres installation,<br> renseigner les champs ci-dessous</center>
<table border=\"0\" align=\"center\" cellpadding=\"0\" cellspacing=\"10\">
<FORM action=install.php method=post>
<TR><td>DB host</td><TD><INPUT size=20 name=host value=localhost></TD></TR>
<TR><td>DB username</td><TD><INPUT size=20 name=user></TD></TR>
<TR><td>DB password</td><TD><INPUT size=20 name=pass></TD></TR>
<TR><td>DB name</td><TD><INPUT size=20 name=name></TD></TR>
<TR><TD><INPUT type=hidden value=1 name=state> <INPUT type=submit value=\"Valider\"></TD></TR>
</FORM>
</table>
<table border=\"0\" align=\"center\" cellpadding=\"0\" cellspacing=\"10\">
<TR><td>
<h2>attention !!!</h2>
<b><i>setup.php</i> droit = (777)</b>
</TD></TR>
</table>
";
exit;
}


if ($state == "1") {

$fr=fopen("setup.php","w+");
fwrite($fr, '<'."?\n");
fwrite($fr, 'error_reporting(0);'."\n");
fwrite($fr, '$dbhost="'.$host.'";'."\n");
fwrite($fr, '$dbuname="'.$user.'";'."\n");
fwrite($fr, '$dbpass="'.$pass.'";'."\n");
fwrite($fr, '$dbname="'.$name.'";'."\n");
fwrite($fr, 'mysql_connect($dbhost, $dbuname, $dbpass) or die("<br><br><center><br><br><b>Impossible de se connecter</center></b>");'."\n");
fwrite($fr, 'mysql_select_db($dbname);'."\n");
fwrite($fr, '?'.'>');
fclose($fr);
echo"cr�ation fichier <br>";


$table1 = "CREATE TABLE `game_bank` (
  `name` varchar(10) NOT NULL default 'ttuz',
  `bank` decimal(12,2) NOT NULL default '0.00',
  `proc` decimal(3,0) NOT NULL default '0'
) TYPE=MyISAM;";

$table2 = "CREATE TABLE `news` (
  `id` int(11) NOT NULL auto_increment,
  `data` varchar(8) NOT NULL default '',
  `news` tinytext NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;";

$table3 = "CREATE TABLE `partner` (
  `pus` varchar(50) default NULL,
  `user` varchar(50) default NULL,
  `data` varchar(8) default NULL,
  `cash` varchar(10) default NULL
) TYPE=MyISAM;";

$table4 = "CREATE TABLE `seting` (
  `alog` varchar(10) NOT NULL default 'admin',
  `apas` varchar(10) NOT NULL default 'admin',
  `adm_email` varchar(200) NOT NULL default '',
  `cas_url` varchar(200) NOT NULL default 'http://',
  `cas_name` varchar(40) NOT NULL default '',
  `mrh_login` varchar(200) NOT NULL default '',
  `mrh_pass1` varchar(200) NOT NULL default '',
  `mrh_pass2` varchar(200) NOT NULL default '',
  `pcash` char(3) NOT NULL default '20',
  `paymail` char(3) NOT NULL default 'yes',
  `regmail` char(3) NOT NULL default 'yes',
  `zakmail` char(3) NOT NULL default 'yes',
  `icq` varchar(10) NOT NULL default '',
  `cas_bon` char(1) NOT NULL default '0'
) TYPE=MyISAM;";

$table5 = "CREATE TABLE `stat_game` (
  `id` int(11) NOT NULL auto_increment,
  `data` varchar(8) NOT NULL default '',
  `vrem` time NOT NULL default '00:00:00',
  `login` varchar(20) NOT NULL default '',
  `balans` varchar(10) NOT NULL default '',
  `stav` char(3) NOT NULL default '',
  `win` varchar(6) NOT NULL default '',
  `game` varchar(20) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;";

$table6 = "CREATE TABLE `stat_pay` (
  `user` varchar(20) NOT NULL default '',
  `data` varchar(8) NOT NULL default '',
  `vremya` time NOT NULL default '00:00:00',
  `inm` varchar(12) NOT NULL default '',
  `outm` varchar(12) NOT NULL default '',
  KEY `data` (`data`)
) TYPE=MyISAM;";

$table7 = "CREATE TABLE `users` (
  `id` int(11) NOT NULL auto_increment,
  `login` varchar(12) default NULL,
  `pass` varchar(12) default NULL,
  `cash` decimal(12,2) default '0.00',
  `cashin` decimal(12,2) default '0.00',
  `cashout` decimal(12,2) default '0.00',
  `email` varchar(50) default NULL,
  `name` varchar(50) default NULL,
  `fam` varchar(50) default NULL,
  `date` varchar(12) default NULL,
  `pcash` varchar(6) default '0.00',
  `prenom` varchar(100) default NULL,
  `nom` varchar(100) default NULL,
  `adresse` varchar(100) default NULL,
  `codepostal` varchar(100) default NULL,
  `ville` varchar(100) default NULL,
  `pays` varchar(100) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;";

$table8 = "CREATE TABLE `zakaz` (
  `id` int(11) NOT NULL auto_increment,
  `login` varchar(12) default NULL,
  `cash` varchar(30) default NULL,
  `rekvizit` varchar(20) default NULL,
  `sumout` varchar(10) default NULL,
  `flag` char(1) default '1',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;";

$table9 = "CREATE TABLE `categorie` (
  `id` int(11) NOT NULL auto_increment,
  `nom` varchar(25) default NULL,
  `description` varchar(90) default NULL,
  `image` varchar(20) default NULL,
   PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;";


$table10 = "CREATE TABLE `produit` (
  `id` int(11) NOT NULL auto_increment,
  `nomp` varchar(25) default NULL,
  `descriptionp` varchar(90) default NULL,
  `imagep` varchar(20) default NULL,
  `cat` varchar(30) default NULL,
  `valeur` varchar(20) default NULL,
   PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;";



$table11 = "CREATE TABLE `gagnants` (
  `id` int(11) NOT NULL auto_increment,
  `date` varchar(18) NOT NULL default '',
  `heure` varchar(18) NOT NULL default '',
  `nom` varchar(18) NOT NULL default '',
  `produit` tinytext NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;";



$table12 = "CREATE TABLE `game_bankd` (
  `name` varchar(10) NOT NULL default 'ttuz',
  `bank` decimal(12,2) NOT NULL default '0.00',
  `proc` decimal(3,0) NOT NULL default '0'
) TYPE=MyISAM;";








include ("setup.php");
mysql_connect($dbhost, $dbuname, $dbpass);
mysql_db_query($dbname, $table1);
echo"table  1.....ok <br>";
mysql_db_query($dbname, $table2);
echo"table  2.....ok  <br>";
mysql_db_query($dbname, $table3);
echo"table  3.....ok  <br>";
mysql_db_query($dbname, $table4);
echo"table  4.....ok <br>";
mysql_db_query($dbname, $table5);
echo"table  5.....ok <br>";
mysql_db_query($dbname, $table6);
echo"table  6.....ok <br>";
mysql_db_query($dbname, $table7);
echo"table  7.....ok <br>";
mysql_db_query($dbname, $table8);
echo"table  8.....ok <br>";
mysql_db_query($dbname, $table9);
echo"table  9.....ok <br>";
mysql_db_query($dbname, $table10);
echo"table  10.....ok <br>";
mysql_db_query($dbname, $table11);
echo"table  11.....ok <br>";
mysql_db_query($dbname, $table12);
echo"table  12.....ok <br>";





$sql1 = "INSERT INTO `seting` VALUES ('admin', 'admin', '', 'http://', '', '', '', '', '20', 'yes', 'yes', 'yes', '', '0');";
mysql_query($sql1);
$sql2 = "INSERT INTO `game_bank` VALUES ('ttuz', '0', '90');";
mysql_query($sql2);
$sql3 = "INSERT INTO `game_bankd` VALUES ('ttuz', '0', '300');";
mysql_query($sql3);

echo"insertion des donn�es ok ! <br><br><br>";

echo "<b>installation r�ussie !<br><br><br><br><br>

Administration :<br>http://yourdomain/master/<br><br>
Login : admin<br>
pass: admin<br>
</b>";
}

?>
