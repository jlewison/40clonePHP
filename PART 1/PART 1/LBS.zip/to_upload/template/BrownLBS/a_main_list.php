<?php include('template/BrownLBS/top_side.php');?>

<!--
###################################################################################
#######################                                     #######################
#######################   M A I N   S E C T I O N   Start   #######################
#######################                                     #######################
###################################################################################
-->

<h1><?php echo("$lang_24");?> <span style="text-transform:uppercase">"<?php echo("$categ");?>"</span></h1>

<div class="content">

<?php if($totalRows_lisPcatLN <> '') { ?>

<div id="stop"><a href="<?php echo("$path");?>listxml.php?categ=<?php echo("$categ");?>" target="_blank"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/xml.gif" alt="RSS Feed" border="0" /></a>
  <?php echo("$lang_25");?> <?php echo ($startRow_lisPcatLN + 1) ?> <?php echo("$lang_26");?> <?php echo min($startRow_lisPcatLN + $maxRows_lisPcatLN, $totalRows_lisPcatLN) ?> <?php echo("$lang_27");?> <?php echo $totalRows_lisPcatLN ?> <?php echo("$lang_28");?>
</div><br />


<table border="0" cellspacing="0" cellpadding="0">
		<?php do { ?>
        <tr><td>

			<?php $wsn = $row_lisPcatLN['title']; $step8 = str_replace(" ", "-", $wsn); $wsseoname = "$step8"; ?>

<div id="listing"><a href="<?php echo $row_lisPcatLN['site']; ?>" target="_blank"><?php echo $row_lisPcatLN['title']; ?></a><br />
              <?php echo $row_lisPcatLN['descr1']; ?>
</div>
<?php
$ABCcategory = $row_lisPcatLN['maincategory'];					
mysql_select_db($database_apound, $apound);
$query_LdetCAT = "SELECT * FROM categorylisting WHERE catlistid = '$ABCcategory'";
$LdetCAT = mysql_query($query_LdetCAT, $apound) or die(mysql_error());
$row_LdetCAT = mysql_fetch_assoc($LdetCAT);
$totalRows_LdetCAT = mysql_num_rows($LdetCAT); ?>
<div id="listingD"><?php echo $row_lisPcatLN['site']; ?> :: <?php echo("$lang_5");?> <?php echo $row_lisPcatLN['stad']; ?> <?php if($fremode == 'N') { ?> :: <?php echo $row_lisPcatLN['bid']; ?> <?php echo("$lang_29");?> <?php } else { } ?><br />
<?php echo("$lang_30");?> <a href="<?php echo("$path");?><?php echo $row_LdetCAT['categseoname']; ?>/"><?php echo $row_LdetCAT['categoryname'] ?></a>

<a href="<?php echo("$path");?><?php echo $row_lisPcatLN['dtu'];?>/<?php echo("$wsseoname"); ?>.html"><?php echo("$lang_7");?></a>
<?php if($fremode == 'N') { ?> <a href="<?php echo("$path");?>upgrade.php?ucat=<?php echo $row_lisPcatLN['dtu']; ?>"><?php echo("$lang_8");?></a> <?php } else { } ?>
</div>
            
<?php if($prenabled == 'Y' and $enb_list == 'Y') { ?>

	<?php include('pr_update_list.php');?>


<div id="stats">        
      <?php if($enb_google == 'Y') { ?>
      <img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/googleIcon.gif" /><?php echo $row_lisPcatLN['google']; ?>
          <?php } else {} ?>
      
          <?php if($enb_yahoo == 'Y') { ?>
      <img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/yahooIcon.gif" /><?php echo $row_lisPcatLN['yahoo']; ?>
          <?php } else {} ?>
      
          <?php if($enb_msn == 'Y') { ?>
      <img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/msnIcon.gif" /><?php echo $row_lisPcatLN['msn']; ?>
          <?php } else {} ?>
      
          <?php if($enb_alexa == 'Y') { ?>
      <img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/alexaIcon.gif" /><?php echo $row_lisPcatLN['alexa']; ?>
          <?php } else {} ?>
</div>

<?php } else {} ?>

		</td>
        </tr>
<?php } while ($row_lisPcatLN = mysql_fetch_assoc($lisPcatLN)); ?>
		</table>
        

<div id="sumitlink"><a href="<?php echo("$path");?>submit.php"><?php echo("$lang_31");?></a></div>

<?php } else { ?>


<div id="notlink"><?php echo("$lang_32");?> <a href="<?php echo("$path");?>submit.php"><strong><?php echo("$lang_33");?></strong></a> <?php echo("$lang_34");?> "<?php echo("$categ");?>"! </div>

<?php } ?>



<table  border="0" cellpadding="0" cellspacing="1">
  <tr>
    <td>
	
<?php if ($pageNum_lista > 0) { // Show if not first page ?>
<a href="<?php echo("$path");?><?php echo("0");?>/<?php echo("$totalRows_lista");?>/<?php echo("$categ");?>/">&lt;&lt; <?php echo("$lang_35");?></a>
<?php } // Show if not first page ?>

<?php if ($pageNum_lista > 0) { // Show if not first page ?>
<a href="<?php echo("$path");?><?php $mb = max(0, $pageNum_lista - 1); echo("$mb");?>/<?php echo("$totalRows_lista");?>/<?php echo("$categ");?>/">&lt; <?php echo("$lang_36");?></a>
<?php } // Show if not first page ?>

<?php if ($pageNum_lista < $totalPages_lista) { // Show if not last page ?>
<a href="<?php echo("$path");?><?php $mb = min($totalPages_lista, $pageNum_lista + 1); echo("$mb");?>/<?php echo("$totalRows_lista");?>/<?php echo("$categ");?>/"><?php echo("$lang_37");?> &gt;</a>
<?php } // Show if not last page ?>

<?php if ($pageNum_lista < $totalPages_lista) { // Show if not last page ?>
<a href="<?php echo("$path");?><?php $mb = min($totalPages_lista, $pageNum_lista + 1); echo("$totalPages_lista");?>/<?php echo("$totalRows_lista");?>/<?php echo("$categ");?>/"><?php echo("$lang_38");?> &gt;&gt;</a>
<?php } // Show if not last page ?>
    
    </td>
  </tr>
</table>
</div>
<!--
###################################################################################
#######################                                     #######################
#######################    M A I N   S E C T I O N   End    #######################
#######################                                     #######################
###################################################################################
-->


<?php include('template/BrownLBS/bottom_side.php');?>
<?php include('template/BrownLBS/footer.php'); ?>