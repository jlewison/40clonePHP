<?php
/**
*
*
*
* @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
* @license
* @version SVN:$Id
* @since 2007-06-18
*/
$lang['groupcategory_title'] 					= 'Manage Group Category';
$lang['groupcategory_category_name'] 			= 'Category Name';
$lang['groupcategory_description'] 				= 'Description';
$lang['groupcategory_status'] 					= 'Status';
$lang['groupcategory_sub_category_name'] 		= 'Sub Category Name';
$lang['groupcategory_sub_description'] 			= 'Sub Category Description';
$lang['groupcategory_sub_status'] 				= 'Sub Category Status';
$lang['groupcategory_category_note'] 			= '(Category name should not exceed 25 chars)';
$lang['groupcategory_description_note'] 		= '(Description should not exceed 50 chars)';
$lang['groupcategory_enabled'] 					= 'Enabled';
$lang['groupcategory_disabled'] 				= 'Disabled';
$lang['groupcategory_submit'] 					= 'Submit';
$lang['groupcategory_select_all'] 				= 'Select All';
$lang['groupcategory_delete_selected'] 			= 'Delete Selected';
$lang['groupcategory_category'] 				= 'Category';
$lang['groupcategory_sub_category'] 			= 'Sub Category';
$lang['groupcategory_description'] 				= 'Description';
$lang['groupcategory_status'] 					= 'Status';
$lang['groupcategory_date_added'] 				= 'Date Added';
$lang['groupcategory_action'] 					= 'Action';
$lang['groupcategory_delete'] 					= 'Delete';
$lang['groupcategory_edit'] 					= 'Edit';
$lang['groupcategory_base_category'] 			= 'Base Category';
$lang['groupcategory_no_records'] 				= 'No Group category found';
$lang['groupcategory_sub_no_records'] 			= 'No Group sub category found';
$lang['groupcategory_add_success_msg'] 			= 'Group category added successfully';
$lang['groupcategory_update_success_msg'] 		= 'Group category updated successfully';
$lang['groupcategory_sub_add_success_msg'] 		= 'Group sub category added successfully';
$lang['groupcategory_sub_update_success_msg'] 	= 'Group sub category updated successfully';
?>