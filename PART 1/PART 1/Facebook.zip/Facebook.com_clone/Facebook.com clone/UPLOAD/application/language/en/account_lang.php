<?php

	/**
	* Account Page Language
	*
	*
	* @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
	* @license
	* @since 2/8/2008
	*/

	$lang['page_title']	= 'Account';

	$lang['account_same_password']				= 'New password is same as the old password.';
	$lang['account_password_change_success']	= 'Password has been Changed successfully.';
	$lang['account_password_wrong']				= 'Old password is wrong.';

	$lang['account_question_change_success']		= 'Security Question Answer has been Changed successfully.';
	$lang['account_name_change_success']			= 'Your name has been changed successfully.';
	$lang['account_notification_change_success']	= 'Your notification settings has been changed successfully.';

	$lang['account_old_password']		= 'Old Password';
	$lang['account_new_password']		= 'New Password';
	$lang['account_confirm_password']	= 'Confirm Password';
	$lang['account_answer']				= 'Answer';
	$lang['account_name']				= 'Name';
	$lang['account_settings']			= 'Settings';
	$lang['account_notifications']		= 'Notifications';
	$lang['account_change']				= 'Change';
	$lang['account_hide']				= 'Hide';
	$lang['account_new_name']			= 'New Name';
	$lang['account_password']			= 'Password';
	$lang['account_your_password']		= 'Your password';
	$lang['account_security_question']	= 'Security question';
	$lang['account_question']			= 'Question';
	$lang['account_real_name']			= 'Your real name ';
	$lang['account_email_notify']		= 'Email Notifications';

	$lang['account_your_security_question']		= 'Your security question';

	$lang['account_msg_1']				= 'We confirm all name changes before they take effect. Sometimes this takes a little while, so please be patient.';
	$lang['account_msg_2']				= 'Make sure your CAPS-lock key isn\'t on';
	$lang['account_msg_3']				= 'It must be at least 6 characters long, but more is better';
	$lang['account_msg_4']				= 'Using both letters and numbers is even better';
	$lang['account_msg_5']				= '"PAssWoRd" isn\'t the same password as "password"';
	$lang['account_msg_6']				= 'Kootali notifies you by email whenever actions are taken on Kootali that involve you. You can control which email notifications you receive.';
	$lang['account_msg_7']				= 'Email me at';
	$lang['account_msg_8']				= 'when someone...';

?>