<?php

/**
 * invitations Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 1/30/2008
 */
class invitations extends Controller
{
		//Constructor
		function invitations()
		{
				parent::Controller();
				//check login
				loginRequired();
				//Load the language file
				$this->lang->load('invitations', $this->config->item('language_code'));
		}
		//Default function
		function index()
		{
				$this->friends();
		}
		function friends()
		{
				$this->load->model('friendsmodel');
				$outputData['currTab'] = 'friends';
				$displayMessage = '';
				if ($_POST && is_array($_POST) && count($_POST) > 0)
				{
						if ($this->input->post('invitation_reply') == 'confirm')
						{
								$this->friendsmodel->acceptRequest($this->input->post('invitation'));
								$displayMessage = $this->lang->line('invitations_friend_confirm');
								//Load the user model
								$this->load->model('usermodel');
								$userFeedSettings = $this->usermodel->getUserFeedSetting();
								if (isset($userFeedSettings[8]) && $userFeedSettings[8] == 'yes')
								{
										//Load the minifeed model
										$invitationDetails = $this->friendsmodel->getInvitation($this->input->post('invitation'));
										$this->load->model('minifeedmodel');
										$splVars = array('~~postedBy~~' => $this->session->userdata('username'), '~~friendName~~' => $this->usermodel->getName($invitationDetails['user_id']));
										$this->minifeedmodel->postMiniFeed('ADD_FRIEND', $splVars, array(base_url() . 'profile/' . $invitationDetails['user_id']));
								}
						} elseif ($this->input->post('invitation_reply') == 'reject')
						{
								$displayMessage = $this->lang->line('invitations_friend_reject');
								$this->friendsmodel->rejectRequest($this->input->post('invitation'));
						}
				}
				$outputData['requestCount'] = $this->friendsmodel->getRequestCount();
				if ($outputData['requestCount'] > 0)
				{
						$outputData['request'] = $this->friendsmodel->getRequest();
						$outputData['displayMessage'] = $displayMessage;
						$this->smartyextended->view('invitations', $outputData);
				}
				else
				{
						if ($displayMessage == '') $displayMessage = $this->lang->line('invitations_friends_note');
						//Set the flash data
						$this->session->set_flashdata('flash_msg', $displayMessage);
						redirect('welcome');
				}
		}
		function groups()
		{
				$this->load->model('groupsmodel');
				$this->load->model('usermodel');
				$outputData['currTab'] = 'groups';
				$displayMessage = '';
				$userId = $this->session->userdata('user_id');
				if ($_POST && is_array($_POST) && count($_POST) > 0)
				{
						if ($this->input->post('invitation_reply') == 'confirm')
						{
								$invId = $this->input->post('invitation');
								$invInfo = $this->groupsmodel->getInvitationInfo('', '', $invId);
								$sender = $invInfo['sender_id'];
								$groupId = $invInfo['group_id'];
								$groupInfo = $this->groupsmodel->getInfo($groupId);
								$receiver = $userId;
								$this->groupsmodel->joinGroup($groupId, $sender, $receiver);
								$this->groupsmodel->removeInvitation($userId, $groupId);
								$displayMessage = $this->lang->line('invitations_group_confirm');
						}
						else
						{
								$invId = $this->input->post('invitation');
								$invInfo = $this->groupsmodel->getInvitationInfo('', '', $invId);
								$sender = $invInfo['sender_id'];
								$groupId = $invInfo['group_id'];
								$receiver = $userId;
								$this->groupsmodel->removeInvitation($userId, $groupId, $invId);
								$displayMessage = $this->lang->line('invitations_group_reject');
						}
				}
				$outputData['requestCount'] = $this->groupsmodel->getRequestCount();
				if ($outputData['requestCount'] > 0)
				{
						$groupRequests = $this->groupsmodel->getRequestsForGroups($this->session->userdata('user_id'));
						foreach ($groupRequests as $key => $valArr)
						{
								$groupRequests[$key]['avatar'] = $this->usermodel->getAvatar($groupRequests[$key]['sender_id'], true);
								$groupRequests[$key]['admin_name'] = $this->usermodel->getName($groupRequests[$key]['group_owner'], true);
						}
						$outputData['request'] = $groupRequests;
						$outputData['displayMessage'] = $displayMessage;
						$this->smartyextended->view('invitations', $outputData);
				}
				else
				{
						if ($displayMessage == '') $displayMessage = $this->lang->line('invitations_events_note');
						//Set the flash data
						$this->session->set_flashdata('flash_msg', $displayMessage);
						redirect('welcome');
				}
		}
		function events()
		{
				$this->load->model('eventsmodel');
				$this->load->model('usermodel');
				$outputData['currTab'] = 'events';
				$displayMessage = '';
				$userId = $this->session->userdata('user_id');
				if ($_POST && is_array($_POST) && count($_POST) > 0)
				{
						if ($this->input->post('invitation_reply') == 'confirm')
						{
								$invId = $this->input->post('invitation');
								$invInfo = $this->eventsmodel->getInvitationInfo('', '', $invId);
								$sender = $invInfo['sender_id'];
								$eventId = $invInfo['event_id'];
								$receiver = $userId;
								$this->eventsmodel->joinevent($eventId, $sender, $receiver);
								$this->eventsmodel->removeInvitation($userId, $eventId);
								$displayMessage = $this->lang->line('invitations_event_confirm');
						}
						else
						{
								$invId = $this->input->post('invitation');
								$invInfo = $this->eventsmodel->getInvitationInfo('', '', $invId);
								$sender = $invInfo['sender_id'];
								$eventId = $invInfo['event_id'];
								$receiver = $userId;
								$this->eventsmodel->removeInvitation($userId, $eventId, $invId);
								$displayMessage = $this->lang->line('invitations_event_reject');
						}
				}
				$outputData['requestCount'] = $this->eventsmodel->getRequestCount();
				if ($outputData['requestCount'] > 0)
				{
						$eventRequests = $this->eventsmodel->getRequestsForevents($this->session->userdata('user_id'));
						foreach ($eventRequests as $key => $valArr)
						{
								$eventRequests[$key]['avatar'] = $this->usermodel->getAvatar($eventRequests[$key]['sender_id'], true);
								$eventRequests[$key]['admin_name'] = $this->usermodel->getName($eventRequests[$key]['event_owner'], true);
						}
						$outputData['request'] = $eventRequests;
						$outputData['displayMessage'] = $displayMessage;
						$this->smartyextended->view('invitations', $outputData);
				}
				else
				{
						if ($displayMessage == '') $displayMessage = $this->lang->line('invitations_events_note');
						//echo $displayMessage;
						//Set the flash data
						$this->session->set_flashdata('flash_msg', $displayMessage);
						redirect('welcome');
				}
		}
}

?>