<?php
/**
*
*
*
* @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
* @license
* @version SVN:$Id
* @since 2007-06-18
*/
$lang['managemembers_title'] 					= 'Member Management';
$lang['managemembers_add_member'] 				= 'Add Member';
$lang['managemembers_member_name'] 				= 'Member Name';
$lang['managemembers_email'] 					= 'Email';
$lang['managemembers_gender'] 					= 'Gender';
$lang['managemembers_doj'] 						= 'DOJ';
$lang['managemembers_country'] 					= 'Country';
$lang['managemembers_search'] 					= 'Search';
$lang['managemembers_account_info'] 			= 'Account Info';
$lang['managemembers_site_info'] 				= 'Site Info';
$lang['managemembers_status'] 					= 'Status';
$lang['managemembers_action'] 					= 'Action';
$lang['managemembers_age'] 						= 'Age';
$lang['managemembers_registered_on'] 			= 'Registered on';
$lang['managemembers_last_visit'] 				= 'Last Visit';
$lang['managemembers_email'] 					= 'Emai';
$lang['managemembers_city'] 					= 'City';
$lang['managemembers_country'] 					= 'Country';
$lang['managemembers_friends'] 					= 'Friends';
$lang['managemembers_groups'] 					= 'Groups';
$lang['managemembers_photos'] 					= 'Photos';
$lang['managemembers_events'] 					= 'Events';
$lang['managemembers_networks'] 				= 'Networks';
$lang['managemembers_view'] 					= 'View';
$lang['managemembers_edit'] 					= 'Edit';
$lang['managemembers_deactive'] 				= 'De-Activate';
$lang['managemembers_no_records'] 				= 'No records found';
?>