<?
include("include/config.php");
if(isset($_COOKIE['uname']))
{
$qry="select * from premium_package";
$rs=$conn->execute($qry);
STemplate::assign('pac',$rs->getarray());
$email=$_COOKIE['email'];
$uname=$_COOKIE['uname'];
$qry="select * from premium_user where uname='$uname'";
$rs=$conn->execute($qry);
$mv=$rs->fields['pac_time'];
if($mv==-1) $mv="0 days";
else if($mv==0) $mv="LifeTime";
else $mv=$mv." days";
STemplate::assign('mv',$mv);
$qry="select idkey,file_name,size,no_of_dwnld,recipient,expire_time from fileinfo where sender='$email' and link_status=1";
//echo $qry;
$rs=$conn->execute($qry);
//print_r($rs);
$mf=$rs->getarray();
for($i=0;$i<count($mf);$i++)
{
 $mf[$i]['expire_time']=date("m-d-Y",$mf[$i]['expire_time']);
}
STemplate::assign('myfile',$mf);
STemplate::display("welcome_premium.tpl");
}
else header("location: index.php");
?>
