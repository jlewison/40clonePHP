<?php /* Smarty version 2.6.18, created on 2007-11-21 12:06:24
         compiled from ../advertisements/bottom.tpl */ ?>
<a href="http://www.anrdoezrs.net/click-2720081-10448546" target="_top">
<img src="http://www.awltovhc.com/image-2720081-10448546" width="100%" alt="Great Movies" border="0"/></a>