<?
include "header.php";
// $date=date("d.m.Y");
?>
<center>
<h4><font color=#7C87C2>Liste des gagnants </font></h4>

<table border=0 cellspacing=0 cellpadding=0 width="40%">
<?
$result=mysql_query("select * from gagnants ORDER BY `id` DESC ");
while($row=mysql_fetch_array($result))
{
echo "
<tr>
<td width=\"300\"><b>$row[1]</b> - $row[2] - $row[3] - $row[4]<br><a href=\"?del=1&id=$row[0]\">Supprimer</a><br><br></td></tr>
";
}
?>
</table>

<h4><font color=#7C87C2>Ajouter un gagnant</font></h4>


<form name="form" method="post" action="" onSubmit="return formCheck(this)">


<table border="0" cellpadding="4" cellspacing="0">
<tr>
<td colspan="2"><table border="0" cellspacing="0" cellpadding="2">
<tr>
<td><b>Date:</b>&nbsp;</td>
<td><input name="datep" type="text" maxlength="16" value="" size="25"></td>
</tr>

</tr>
<tr>
<td><b>heure :</b>&nbsp;</td>
<td><input name="heure" type="text" maxlength="16" value="" size="25"></td>
</tr>

</tr>
<tr>
<td><b>Nom :</b>&nbsp;</td>
<td><input name="nom" type="text" maxlength="16" value="" size="25"></td>
</tr>
<tr>
<td><b>produit :</b>&nbsp;</td>
<td><input name="produit" type="text" maxlength="16" value="" size="25"></td>
</tr>



</table></td>
</tr>





<tr>
<td colspan="2">
<input type="hidden" name="send" value="1"><input type="submit" name="submit" value="Valider"></td>
</tr>
</table>
</form>
</center>
<?

if ($send=="1"){
$sqls="INSERT INTO gagnants VALUES(NULL,'$datep','$heure','$nom','$produit')";
mysql_query($sqls);
echo "<script> alert('OK!'); document.location.href='gagnants.php'; </script>";
}
if ($del=="1"){
mysql_query("DELETE FROM gagnants WHERE id = '$id'");
echo "<script> alert('OK!'); document.location.href='gagnants.php'; </script>";
}

include "footer.php"; ?>