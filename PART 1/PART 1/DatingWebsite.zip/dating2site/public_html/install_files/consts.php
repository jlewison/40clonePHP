<?php
/**
 ** Constants used for installation file.
 **/

define ( 'CONFIG_FILE', './config.inc.php');
define ( 'SQL_FILE',    'sql/tables.sql');
define ( 'SYSTEM_FILE', 'sql/system.sql' );
define ( 'SAMPLE_FILE', 'sql/sample_data.sql' );
// define ( 'PHPBB_FILE', 'sql/phpbb_tables.sql' );
define('OSDATE_VERSION','2.0.4');
define ('MAIL_FORMAT', 'html');

// defaults
$langType = 'lang_english';
$langtypeValues = array( 'lang_dutch', 'lang_french', 'lang_german','lang_greek', 'lang_portuguese', 'lang_russian',   'lang_romanian','lang_spanish', 'lang_turkish');
$langtypeNames  = array( 'Dutch', 'French' ,'German', 'Greek', 'Portuguese', 'Russian',  'Romanian','Spanish', 'Turkish');
$defaultLangNames  = array( 'Dutch', 'English', 'French' ,'German', 'Greek', 'Portuguese', 'Russian',  'Romanian','Spanish', 'Turkish');
$defaultLangValues = array( 'lang_dutch', 'lang_english', 'lang_french', 'lang_german','lang_greek', 'lang_portuguese', 'lang_russian',   'lang_romanian','lang_spanish', 'lang_turkish');
$countryType = 'US';

?>