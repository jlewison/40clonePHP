<?php

$LANG['page_title'] = 'Manage Blogs';
$LANG['back_to_blog'] = 'All Blogs';
$LANG['add_submit'] = 'Add';
$LANG['update_submit'] = 'Update';
$LANG['delete_submit'] = 'Delete';
$LANG['err_tip_compulsory'] = 'compulsory';
$LANG['msg_error'] = 'Sorry! Error found';
$LANG['update_canecl'] = 'Cancel';
$LANG['success_deleted'] = 'Selected blogs deleted successfully';
$LANG['tbl_summary'] = 'Table Summary';
$LANG['put_the_html_code'] = 'Write the html code';
$LANG['accept_comments'] = 'Accept Comments';
$LANG['label_yes'] = 'Yes';
$LANG['label_no'] = 'No';
$LANG['edit'] = 'Edit';
$LANG['chose_category'] = 'Choose';
$LANG['no_records_found'] = 'No records found';
$LANG['check_atleast_one'] = 'There are no records selected';
$LANG['delete_confirmation'] = 'Sure you want to delete the selected blogs?';
$LANG['subject'] = 'Subject';
$LANG['message'] = 'Message';
$LANG['msg_sorry_error'] = 'Sorry! error found';
$LANG['msg_success_added'] = 'Blogs added successfully!';
$LANG['msg_success_update'] = 'Blogs updated successfully!';
$LANG['th_subject'] = 'Subject';
$LANG['th_total_comments'] = 'Total comments';
$LANG['th_total_views'] = 'Total Views';
$LANG['th_accept_comments'] = 'Accept comments';
$LANG['th_date_added'] = 'Date Added';
$LANG['blogwriting_blog_category_id'] = 'Blog Category';
$LANG['select_a_category'] = 'Select a blog category';
$LANG['info_not_allowed_to_post'] = 'You are not allowed to add blog as you are abused by most of the users';
?>
