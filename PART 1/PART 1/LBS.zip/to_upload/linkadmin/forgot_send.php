<?php require_once('../Connections/apound.php');
$colname_fgpas = "-1";
if (isset($_POST['emadd'])) {
  $colname_fgpas = (get_magic_quotes_gpc()) ? $_POST['emadd'] : addslashes($_POST['emadd']);
}
mysql_select_db($database_apound, $apound);
$query_fgpas = sprintf("SELECT * FROM ig_admin WHERE email = '%s'", $colname_fgpas);
$fgpas = mysql_query($query_fgpas, $apound) or die(mysql_error());
$row_fgpas = mysql_fetch_assoc($fgpas);
$totalRows_fgpas = mysql_num_rows($fgpas);
$name = $row_fgpas['name'];
$pass = $row_fgpas['pass'];
$email = $row_fgpas['email'];
$kinek  = "$email";
$targy = "LBS Admin Password Recovery";
$uzenet = "
<html>
<head>
 <title>LBS Admin Password Recovery</title>
 </head>
<body>
<p>Password reminder</p>
<table>
 <tr>
  <th>Your Username</th>
  <th>Your Password</th>
  </tr>
 <tr>
  <td>$name</td><td colspan=5>$pass</td>
 </tr>
</table>
<p>LBS</p>
</body>
</html>
";
$fejlec  = "MIME-Version: 1.0\r\n";
$fejlec .= "Content-type: text/html; charset=iso-8859-2\r\n";
$fejlec .= "From: LBS <admin@biddirectory.linkbidscript.com>\r\n";
mail($kinek, $targy, $uzenet, $fejlec);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Forgot Password</title>
<link rel="shortcut icon" href="img/favicon.ico" />
<link rel="stylesheet" type="text/css" href="admin.css" />
<style type="text/css">
<!--
.style84 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	color: #333;
}
.style85 {color: #333}
-->
</style>
</head>
<body>
<?php
if($totalRows_fgpas <> '') { print"
<h4 align='center' class='style1 style84'>Your password have sent to the email address provided below.</h4>
<h4 align='center' class='style1 style84'><< <a href='index.php' class='style85'>back</a> to the login page </h4>"; }
else { print"<h4 align='center' class='style1'></h4>
<h4 align='center' class='style1 style84'>Sorry, the database does not contain the email address you provided, please use the contact form if you need more help.</h4>
<h4 align='center' class='style1 style84'><< <a href='index.php' class='style85'>back</a> to the login page </h4>"; }
?>
</body>
</html>
<?php mysql_free_result($fgpas); ?>
