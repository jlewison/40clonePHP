<?php

// the path to the module. the probably shouldn't be changed unless you rename the template_management folder(s)
define('template_management_path', my_pligg_base . '/modules/template_management/');

// the path to the module. the probably shouldn't be changed unless you rename the template_management folder(s)
define('template_management_lang_conf', '/modules/template_management/lang.conf');

// the path to the modules templates. the probably shouldn't be changed unless you rename the template_management folder(s)
define('template_management_tpl_path', '../modules/template_management/templates/');

// the path to the modules images. the probably shouldn't be changed unless you rename the template_management folder(s)
define('template_management_image_path', my_pligg_base . '/modules/template_management/images/');

define('URL_template_management', 'module.php?module=template_management');

// don't touch anything past this line.

if(isset($main_smarty) && is_object($main_smarty)){
	$main_smarty->assign('template_management_path', template_management_path);
	$main_smarty->assign('template_management_lang_conf', template_management_lang_conf);
	$main_smarty->assign('template_management_tpl_path', template_management_tpl_path);
	$main_smarty->assign('template_management_image_path', template_management_image_path);

	$main_smarty->assign('URL_template_management', URL_template_management);	
}

?>
