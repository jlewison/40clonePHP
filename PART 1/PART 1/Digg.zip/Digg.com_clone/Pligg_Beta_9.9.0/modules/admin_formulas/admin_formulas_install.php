<?php
	$module_info['name'] = 'Admin Modify Formulas';
	$module_info['desc'] = 'Allows GOD user to modify the formulas.';
	$module_info['version'] = 0.1;
	$module_info['requires'][] = array('scriptaculous', 0.1);
	// this is where you set the modules "name" and "version" that is required
	// if more that one module is required then just make a copy of that line
?>