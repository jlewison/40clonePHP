<? include ("header.php"); ?>
<H3>ttt</H3><br><br><br>
<center><b>yyyy</b></center>
<? include ("footer.php"); ?>