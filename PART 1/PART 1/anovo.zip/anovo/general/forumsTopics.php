<?php

class ForumsTopicsFormHandler extends ForumHandler
{
		public $forum_details_arr;
		public function storeSearchFields()
		{
				$allowed_fields_arr = array('forum_topic' => $this->fields_arr['forum_topic'], 'uname' => $this->fields_arr['uname'], 'date_added_from_day' => $this->fields_arr['date_added_from_day'], 'date_added_from_month' => $this->fields_arr['date_added_from_month'], 'date_added_from_year' => $this->fields_arr['date_added_from_year'], 'date_added_to_day' => $this->fields_arr['date_added_to_day'], 'date_added_to_month' => $this->fields_arr['date_added_to_month'], 'date_added_to_year' => $this->fields_arr['date_added_to_year']);
				$allowed_fields_arr = serialize($allowed_fields_arr);
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['advanced_search'] . ' SET' . ' forum = ' . $this->dbObj->Param('forum') . ' WHERE' . ' user_id = ' . $this->dbObj->Param('user_id');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($allowed_fields_arr, $this->CFG['user']['user_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function populateSearchFields()
		{
				if ($this->fields_arr['so'] == 'adv')
				{
						$sql = 'SELECT forum FROM ' . $this->CFG['db']['tbl']['advanced_search'] . ' WHERE user_id=' . $this->dbObj->Param('user_id');
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($this->CFG['user']['user_id']));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
						if ($row = $rs->FetchRow())
						{
								if ($row['forum'])
								{
										$search_fields_arr = unserialize($row['forum']);
										$this->fields_arr = array_merge($this->fields_arr, $search_fields_arr);
								}
						}
				}
		}
		public function buildConditionQuery($condition = '')
		{
				$this->sql_condition = $condition;
				if ($this->fields_arr['search_forum_topic'] && ($this->fields_arr['search_forum_topic'] != $this->LANG['search_for_forum_topics'])) $this->sql_condition .= ' AND ' . getSearchRegularExpressionQuery($this->fields_arr['search_forum_topic'], 'forum_topic');
				if ($this->fields_arr['forum_topic']) $this->sql_condition .= ' AND ' . getSearchRegularExpressionQuery($this->fields_arr['forum_topic'], 'forum_topic');
				if ($this->fields_arr['uname']) $this->sql_condition .= ' AND u.' . $this->getUserTableField('name') . ' LIKE \'' . addslashes($this->fields_arr['uname']) . '%\'';
				if ($this->fields_arr['date_added_from_day']) $this->sql_condition .= ' AND date_added>=\'' . addslashes($this->fields_arr['date_added_from_year'] . '-' . $this->fields_arr['date_added_from_month'] . '-' . $this->fields_arr['date_added_from_day']) . '\'';
				if ($this->fields_arr['date_added_to_day']) $this->sql_condition .= ' AND date_added<=\'' . addslashes($this->fields_arr['date_added_to_year'] . '-' . $this->fields_arr['date_added_to_month'] . '-' . $this->fields_arr['date_added_to_day']) . '\'';
		}
		public function checkSortQuery($field, $sort = 'asc')
		{
				if (!($this->sql_sort))
				{
						$this->sql_sort = $field . ' ' . $sort;
				}
		}
		public function populateRatingImages($rating = 0)
		{
				$rating_total = 10;
				for ($i = 1; $i <= $rating; $i++)
				{
?>
						<img src="<?php echo $this->CFG['site']['url']; ?>images/icon-ratehover.gif" />
					<?php
				}
				for ($i = $rating; $i < $rating_total; $i++)
				{
?>
						<img src="<?php echo $this->CFG['site']['url']; ?>images/icon-rate.gif" />
					<?php
				}
		}
		public function showForumTopics()
		{
				if (!$this->isResultsFound())
				{
?>
			  	<div id="selMsgAlert">
					<p><?php echo $this->LANG['forumstopics_no_topics']; ?></p>
					<p class="clsMsgAdditionalText"><a href="<?php echo getUrl($this->CFG['site']['url'] . 'members/forumsTopicCreate.php?forum_id=' . $this->forum_details_arr['forum_id'], $this->CFG['site']['url'] . 'members/forumcreate/' . $this->forum_details_arr['forum_id'] . '/', false); ?>"><?php echo $this->LANG['forumstopics_click_post_topic']; ?></a></p>
				</div>
				<?php
						return;
				}
?>
				<table summary="<?php echo $this->LANG['forumstopics_tbl_summary']; ?>">
			      <tr>
			        <th><?php echo $this->LANG['forumstopics_topic_created']; ?></th>
			        <th><?php echo $this->LANG['forumstopics_topic']; ?></th>
			        <th><?php echo $this->LANG['forumstopics_responses']; ?></th>
                     <th><?php echo $this->LANG['forumstopics_views']; ?></th>
			        <th><?php echo $this->LANG['forumstopics_last_responsed']; ?></th>
			      </tr>
				<?php

				while ($row = $this->fetchResultRecord())
				{
						$topicUserDetails['user_id'] = $row['topic_user_id'];
						$topicUserDetails['name'] = $row['topic_user_name'];
						$topicUserDetails['image_path'] = $row['topic_user_image_path'];
						$topicUserDetails['gender'] = $row['topic_user_gender'];
						$topicUserDetails['img_user_id'] = $row['topic_img_user_id'];
						$topicUserDetails['t_width'] = $row['topic_t_width'];
						$topicUserDetails['t_height'] = $row['topic_t_height'];
						$topicUserDetails['s_width'] = $row['topic_s_width'];
						$topicUserDetails['s_height'] = $row['topic_s_height'];
						$topicUserDetails['photo_server_url'] = $row['topic_photo_server_url'];
						$topicUserDetails['photo_ext'] = $row['topic_photo_ext'];
						$lastPostUserDetails['user_id'] = $row['last_user_id'];
						$lastPostUserDetails['name'] = $row['last_user_name'];
						$lastPostUserDetails['image_path'] = $row['last_user_image_path'];
						$lastPostUserDetails['gender'] = $row['last_user_gender'];
						$lastPostUserDetails['img_user_id'] = $row['last_img_user_id'];
						$lastPostUserDetails['t_width'] = $row['last_t_width'];
						$lastPostUserDetails['t_height'] = $row['last_t_height'];
						$lastPostUserDetails['s_width'] = $row['last_s_width'];
						$lastPostUserDetails['s_height'] = $row['last_s_height'];
						$lastPostUserDetails['photo_server_url'] = $row['last_photo_server_url'];
						$lastPostUserDetails['photo_ext'] = $row['last_photo_ext'];
?>
					<tr>
						<td>
							<?php if (chkUserImageAllowed())
						{ ?>
	      					<p id="selImageBorder"><?php displayForumUserSmallImage($topicUserDetails); ?></p>
	      					<?php } ?>
							<p><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'myanswers.php?uid=' . $topicUserDetails['user_id'], $this->CFG['site']['relative_url'] . 'my/answers/' . $topicUserDetails['user_id'] . '/', false); ?>"><?php echo stripString($topicUserDetails['name'], $this->CFG['username']['short_length']); ?></a></p>
	    				</td>
	  					<td>
							<p><a href="<?php echo getUrl('forumsResponses.php?forum_id=' . $this->forum_details_arr['forum_id'] . '&topic_id=' . $row['topic_id'], 'forum/' . $this->forum_details_arr['forum_id'] . '/' . $row['topic_id'] . '/'); ?>"> <?php echo wordWrapManual($row['forum_topic'], 15, $this->CFG['admin']['forum']['line_length']); ?> </a> </p>
	    					<p class="clsStartBy"><span class="clsBold">  <?php echo $this->LANG['forumstopics_started_by'] . ' '; ?> </span><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'myanswers.php?uid=' . $topicUserDetails['user_id'], $this->CFG['site']['relative_url'] . 'my/answers/' . $topicUserDetails['user_id'] . '/', false); ?>"><?php echo stripString($row['topic_user_name'], $this->CFG['username']['short_length']); ?></a> <?php echo ' ' . $this->LANG['forumstopics_on'] . ' ' . $row['date_add'] ?> </p>
							<p>
							<?php
						if ($row['rating_count'] && $row['rating_total'])
						{
								$average_rating = round($row['rating_total'] / $row['rating_count']);
								echo '<span class="clsBold"> ' . $this->LANG['forumstopics_average_rating'] . '</span>';
								$this->populateRatingImages($average_rating);
						}
?>
							</p>
	  					</td>
	  					<td class="clsCenter">
							<p><?php echo ($row['total_response']); ?></p>
                        </td>
                       <td class="clsCenter">
	    					<p><?php echo ($row['total_views']); ?></p>
						</td>
	  					<td>
	  						<?php if (chkUserImageAllowed())
						{ ?>
	      					<p id="selImageBorder"><?php displayForumUserSmallImage($lastPostUserDetails, true, true); ?></p>
	      					<?php } ?>
							<p><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'myanswers.php?uid=' . $lastPostUserDetails['user_id'], $this->CFG['site']['relative_url'] . 'my/answers/' . $lastPostUserDetails['user_id'] . '/', false); ?>"><?php echo stripString($lastPostUserDetails['name'], $this->CFG['username']['short_length']); ?></a></p>
	    				</td>
					</tr>
					<?php
				}
?>
				</table>
			<?php
		}
}
$forumstopics = new ForumsTopicsFormHandler();
if (!chkAllowedModule(array('forums'))) Redirect2URL($CFG['redirect']['dsabled_module_url']);
$forumstopics->setPageBlockNames(array('form_advanced_search', 'msg_form_error', 'msg_form_success', 'form_forum_title', 'form_show_topics', 'page_nav', 'form_confirm'));
$forumstopics->setCSSAlternativeRowClasses($CFG['data_tbl']['css_alternative_row_classes']);
$forumstopics->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$forumstopics->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$forumstopics->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$forumstopics->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$forumstopics->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$forumstopics->setDBObject($db);
$forumstopics->setCfgLangGlobal($CFG, $LANG);
$forumstopics->setAllPageBlocksHide();
$forumstopics->setFormField('forum_id', '');
$forumstopics->setFormField('search_forum_topic', '');
$forumstopics->setFormField('uname', '');
$forumstopics->setFormField('forum_topic', '');
$forumstopics->setFormField('date_added_from', '');
$forumstopics->setFormField('date_added_from_day', '');
$forumstopics->setFormField('date_added_from_month', '');
$forumstopics->setFormField('date_added_from_year', '');
$forumstopics->setFormField('date_added_to', '');
$forumstopics->setFormField('date_added_to_day', '');
$forumstopics->setFormField('date_added_to_month', '');
$forumstopics->setFormField('date_added_to_year', '');
$forumstopics->setFormField('adv_search', '');
$forumstopics->setFormField('so', 'min');
$forumstopics->setMonthsListArr($LANG_LIST_ARR['months']);
$forumstopics->setFormField('numpg', 0);
$forumstopics->setFormField('start', 0);
$forumstopics->setFormField('asc', 'ft.forum_topic');
$forumstopics->setFormField('dsc', '');
$condition = '';
$forumstopics->numpg = $CFG['data_tbl']['numpg'];
$forumstopics->setFormField('start', 0);
$forumstopics->setFormField('numpg', $CFG['data_tbl']['numpg']);
$forumstopics->setMinRecordSelectLimit($CFG['data_tbl']['min_record_select_limit']);
$forumstopics->setMaxRecordSelectLimit($CFG['data_tbl']['max_record_select_limit']);
$forumstopics->setNumPerPageListArr($CFG['data_tbl']['numperpage_list_arr']);
$forumstopics->setTableNames(array());
$forumstopics->setReturnColumns(array());
$forumstopics->sanitizeFormInputs($_REQUEST);
if ($forumstopics->isFormGETed($_GET, 'forum_id'))
{
		$forumstopics->chkIsNotEmpty('forum_id', $LANG['forumstopics_err_tip_compulsory']) and $forumstopics->chkIsNumeric('forum_id', $LANG['forumstopics_err_tip_compulsory']) and $forumstopics->isValidForumId($forumstopics->getFormField('forum_id'), $LANG['forumstopics_err_tip_invalid_forum_id']);
}
else
{
		Redirect2URL(getUrl('forums.php', 'forum/'));
}
$forumstopics->setPageBlockShow('form_show_topics');
if ($forumstopics->getFormField('so') == 'adv' and !$forumstopics->isFormPOSTed($_REQUEST, 'adv_search'))
{
		$forumstopics->populateSearchFields();
		$forumstopics->setPageBlockHide('form_show_topics');
		$forumstopics->setPageBlockHide('page_nav');
		$forumstopics->setPageBlockShow('form_advanced_search');
}
if ($forumstopics->isFormGETed($_GET, 'adv_search'))
{
		$forumstopics->populateSearchFields();
}
if ($forumstopics->isFormPOSTed($_POST, 'adv_search'))
{
		$forumstopics->checkIsValidDate('date_added_from_day', 'date_added_from_month', 'date_added_from_year', 'date_added_from', $LANG['invalid_date']);
		$forumstopics->checkIsValidDate('date_added_to_day', 'date_added_to_month', 'date_added_to_year', 'date_added_to', $LANG['invalid_date']);
		if ($forumstopics->isValidFormInputs())
		{
				$forumstopics->storeSearchFields();
		}
		else
		{
				$forumstopics->setPageBlockHide('form_show_topics');
				$forumstopics->setPageBlockShow('form_advanced_search');
				$forumstopics->setPageBlockShow('msg_form_error');
				$forumstopics->setCommonErrorMsg($LANG['err_msg_invalid_search_option']);
		}
}
if ($forumstopics->isValidFormInputs())
{
		if ($forumstopics->isShowPageBlock('form_show_topics'))
		{
				$forumstopics->setTableNames(array($CFG['db']['tbl']['forum_topics'] . ' as ft LEFT JOIN ' . $CFG['db']['tbl']['users'] . ' AS u1 ON ft.last_post_user_id = u1.' . $forumstopics->getUserTableField('user_id'), $CFG['db']['tbl']['users'] . ' as u'));
				$forumstopics->setReturnColumns(array('ft.forum_id', 'ft.topic_id', 'ft.forum_topic', 'ft.user_id', 'ft.total_response', 'ft.total_views', 'ft.last_post_user_id', 'ft.last_post_date', 'ft.rating_total', 'ft.rating_count', 'ft.topic_status', 'DATE_FORMAT(ft.date_added, \'' . $CFG['format']['date'] . '\') AS date_add', 'u.' . $forumstopics->getUserTableField('user_id') . ' AS topic_user_id', 'u.' . $forumstopics->getUserTableField('name') . ' AS topic_user_name', 'u.' . $forumstopics->getUserTableField('image_path') . ' AS topic_user_image_path', 'u.' . $forumstopics->getUserTableField('gender') . ' AS topic_user_gender', 'u.' . $forumstopics->getUserTableField('user_id') . ' AS topic_img_user_id', 'u.' . $forumstopics->getUserTableField('t_height') . ' AS topic_t_height', 'u.' . $forumstopics->getUserTableField('t_width') . ' AS topic_t_width', 'u.' . $forumstopics->getUserTableField('s_height') . ' AS topic_s_height', 'u.' . $forumstopics->getUserTableField('s_width') .
						' AS topic_s_width', 'u.' . $forumstopics->getUserTableField('photo_server_url') . ' AS topic_photo_server_url', 'u.' . $forumstopics->getUserTableField('photo_ext') . ' AS topic_photo_ext', 'u1.' . $forumstopics->getUserTableField('user_id') . ' AS last_user_id', 'u1.' . $forumstopics->getUserTableField('name') . ' AS last_user_name', 'u1.' . $forumstopics->getUserTableField('image_path') . ' AS last_user_image_path', 'u1.' . $forumstopics->getUserTableField('gender') . ' AS last_user_gender', 'u1.' . $forumstopics->getUserTableField('user_id') . ' AS last_img_user_id', 'u1.' . $forumstopics->getUserTableField('t_height') . ' AS last_t_height', 'u1.' . $forumstopics->getUserTableField('t_width') . ' AS last_t_width', 'u1.' . $forumstopics->getUserTableField('s_height') . ' AS last_s_height', 'u1.' . $forumstopics->getUserTableField('s_width') . ' AS last_s_width', 'u1.' . $forumstopics->getUserTableField('photo_server_url') . ' AS last_photo_server_url', 'u1.' . $forumstopics->
						getUserTableField('photo_ext') . ' AS last_photo_ext'));
				$condition = 'ft.user_id = u.' . $forumstopics->getUserTableField('user_id') . ' AND u.' . $forumstopics->getUserTableField('usr_status') . ' = \'Ok\' AND topic_status = \'Yes\' AND ft.forum_id = \'' . $forumstopics->getFormField('forum_id') . '\'';
				if ($CFG['admin']['ignore_user'])
				{
						$condition .= ' AND NOT EXISTS (SELECT 1 FROM ' . $CFG['db']['tbl']['user_ignored'] . ' AS ui WHERE ui.user_id=' . $CFG['user']['user_id'] . ' AND ui.ignored_id=ft.user_id)';
				}
				$forumstopics->buildSelectQuery();
				$forumstopics->buildConditionQuery($condition);
				$forumstopics->buildSortQuery();
				$forumstopics->checkSortQuery('ft.forum_topic', 'ASC');
				$forumstopics->buildQuery();
				$forumstopics->executeQuery();
				$forumstopics->setPageBlockShow('form_forum_title');
				$paging_arr = array();
				if ($forumstopics->isResultsFound())
				{
						$forumstopics->setPageBlockShow('page_nav');
						if ($CFG['url']['rewrite']) $paging_arr = array('so', 'adv_search', 'forum_topic', 'search_forum_topic');
						else  $paging_arr = array('forum_id', 'so', 'adv_search');
				}
		}
}
else
{
		$forumstopics->setPageBlockShow('msg_form_error');
		Redirect2URL(getUrl('forums.php', 'forum/'));
}



?>
<div id="selforumsTopics" class="clsForums">
  <h2 id="selForumTitle"><span>
  <a href="<?php echo getUrl('forums.php', 'forum/'); ?>"><?php echo $LANG['forumlistall_title_index']; ?></a>
  &nbsp;-&nbsp;
  <?php echo $forumstopics->forum_details_arr['forum_title']; ?>
  </span></h2>
  <?php
if ($forumstopics->isShowPageBlock('msg_form_error'))
{
?>
  <div id="selMsgError">
    <p><?php echo $LANG['msg_error_sorry']; ?> <?php echo $forumstopics->getCommonErrorMsg(); ?></p>
  </div>
  <?php
}
if ($forumstopics->isShowPageBlock('msg_form_success'))
{
?>
  <div id="selMsgSuccess">
    <p><?php echo $LANG['forumstopics_success_message']; ?></p>
  </div>
  <?php
}
if ($forumstopics->isShowPageBlock('form_forum_title'))
{
		$forumstopics->showForumDetails();
}
if ($forumstopics->isShowPageBlock('form_advanced_search'))
{
?>
<form name="formAdvanceSearch" id="formAdvanceSearch" method="post" action="<?php echo getUrl('forumsTopics.php?forum_id=' . $forumstopics->getFormField('forum_id') . '&so=adv', 'forum/' . $forumstopics->getFormField('forum_id') . '/?so=adv'); ?>">
	<div id="moreSearchOptions">
	<table summary="Displaying more search options">
		<tr>
			<td class="<?php echo $forumstopics->getCSSFormLabelCellClass('forum_topic'); ?>">
				<label for="forum_topic"><?php echo $LANG['search_forum_topic']; ?></label>
			</td>
			<td class="<?php echo $forumstopics->getCSSFormFieldCellClass('forum_topic'); ?>"><?php echo $forumstopics->getFormFieldErrorTip('forum_topic'); ?>
				<input type="text" class="clsCommonTextBox" name="forum_topic" id="forum_topic" value="<?php echo $forumstopics->getFormField('forum_topic'); ?>" tabindex="<?php echo $forumstopics->getTabIndex(); ?>" />
			</td>
		</tr>
		<tr>
			<td class="<?php echo $forumstopics->getCSSFormLabelCellClass('uname'); ?>">
				<label for="uname"><?php echo $LANG['search_username']; ?></label>
			</td>
			<td class="<?php echo $forumstopics->getCSSFormFieldCellClass('uname'); ?>"><?php echo $forumstopics->getFormFieldErrorTip('uname'); ?>
				<p><input type="text" class="clsCommonTextBox" name="uname" id="uname" value="<?php echo $forumstopics->getFormField('uname'); ?>" tabindex="<?php echo $forumstopics->getTabIndex(); ?>" /></p>
			</td>
		</tr>
		<tr>
			<td class="<?php echo $forumstopics->getCSSFormLabelCellClass('date_added_from'); ?>"><label for="srch_date"><?php echo $LANG['date_added_from_day']; ?></label></td>
			<td class="<?php echo $forumstopics->getCSSFormFieldCellClass('date_added_from'); ?>"><?php echo $forumstopics->getFormFieldErrorTip('date_added_from'); ?>
			<select name="date_added_from_day" id="date_added_from_day" tabindex="<?php echo $forumstopics->getTabIndex(); ?>">
					<option value=""><?php echo 'Date'; ?></option>
					<?php $forumstopics->populateBWNumbers(1, 31, $forumstopics->getFormField('date_added_from_day')); ?>
			</select>
			<select name="date_added_from_month" id="date_added_from_month" tabindex="<?php echo $forumstopics->getTabIndex(); ?>">
					<option value=""><?php echo 'Month'; ?></option>
					<?php $forumstopics->populateMonthsList($forumstopics->getFormField('date_added_from_month')); ?>
			</select>
			<select name="date_added_from_year" id="date_added_from_year" tabindex="<?php echo $forumstopics->getTabIndex(); ?>">
					<option value=""><?php echo 'Year'; ?></option>
					<?php $forumstopics->populateBWNumbers(1988, date("Y"), $forumstopics->getFormField('date_added_from_year')); ?>
			</select>
			<input type="hidden" name="date_added_from" id="date_added_from" value="<?php echo $forumstopics->getFormField('date_added_from'); ?>">
			<input type="hidden" name="date_added_to" id="date_added_to" value="<?php echo $forumstopics->getFormField('date_added_to'); ?>">
			<?php
?>
			</td>
		</tr>
		<tr>
			<td class="<?php echo $forumstopics->getCSSFormLabelCellClass('date_added_to'); ?>"><label for="srch_date"><?php echo $LANG['to']; ?></label></td>
			<td class="<?php echo $forumstopics->getCSSFormFieldCellClass('date_added_to'); ?>"><?php echo $forumstopics->getFormFieldErrorTip('date_added_to'); ?>
			<select name="date_added_to_day" id="date_added_to_day" tabindex="<?php echo $forumstopics->getTabIndex(); ?>">
					<option value=""><?php echo 'Date'; ?></option>
					<?php $forumstopics->populateBWNumbers(1, 31, $forumstopics->getFormField('date_added_to_day')); ?>
			</select>
			<select name="date_added_to_month" id="date_added_to_month" tabindex="<?php echo $forumstopics->getTabIndex(); ?>">
					<option value=""><?php echo 'Month'; ?></option>
					<?php $forumstopics->populateMonthsList($forumstopics->getFormField('date_added_to_month')); ?>
			</select>
			<select name="date_added_to_year" id="date_added_to_year" tabindex="<?php echo $forumstopics->getTabIndex(); ?>">
					<option value=""><?php echo 'Year'; ?></option>
					<?php $forumstopics->populateBWNumbers(2028, date("Y"), $forumstopics->getFormField('date_added_to_year')); ?>
			</select>
			<?php
?>
			</td>
		</tr>
		<tr>
			<td colspan="2" class="<?php echo $forumstopics->getCSSFormFieldCellClass('submitsearch'); ?>">
				<input type="submit" class="clsSubmitButton" name="adv_search" id="adv_search" value="<?php echo $LANG['search_submit'];
		; ?>" tabindex="<?php echo $forumstopics->getTabIndex(); ?>" />
			</td>
		</tr>
		</table>
	</div>
</form>
<?php
}
if ($forumstopics->isShowPageBlock('page_nav') && $CFG['admin']['navigation']['top'])
{
		$forumstopics->populatePageLinks($forumstopics->getFormField('start'), $paging_arr);
}
if ($forumstopics->isShowPageBlock('form_show_topics'))
{
?>
  <form name="selFormTopics" id="selFormTopics" method="post" action="<?php echo $_SERVER['REQUEST_URI']; ?>">
    <?php $forumstopics->showForumTopics(); ?>
  </form>
  <?php
}
if ($forumstopics->isShowPageBlock('page_nav') && $CFG['admin']['navigation']['bottom'])
{
		$forumstopics->populatePageLinks($forumstopics->getFormField('start'), $paging_arr);
}
if ($forumstopics->isShowPageBlock('form_forum_title'))
{
?>
		<div id="selGroupForumPost">
			<div class="clsForumPost"><p class="clsAlignRight" id="post">
				<a href="<?php echo getUrl($CFG['site']['url'] . 'members/forumsTopicCreate.php?forum_id=' . $forumstopics->getFormField('forum_id'), $CFG['site']['url'] . 'members/forumcreate/' . $forumstopics->getFormField('forum_id') . '/', false); ?>"><?php echo $LANG['forumslinks_post_topic']; ?></a>
			</div>
		</div>
	<?php
}
?>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>
