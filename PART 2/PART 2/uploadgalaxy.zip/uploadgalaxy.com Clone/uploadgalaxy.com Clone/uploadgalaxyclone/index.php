<?
include("include/config.php");
//include("include/function.php");
include("include/functions.php");
/////////////////////////////////////////////////////////////////
ChangeIni();
$err=array();
if(count($_POST)>0)
{
        $media=$_REQUEST["media"];
        $upfile=$_FILES['ufile']['name'];
        $upfile=trim($upfile);
        $emailto=trim($_REQUEST["reml"]);
        $emailfrom=trim($_REQUEST["yeml"]);
        $message=trim($_REQUEST["mdes"]);
        if(empty($emailto)) $err[]="Recipient's emailid is not specified.";
        if(empty($upfile)) $err[]="Browse a file to upload.";
        
        if(count($err)==0)
        {
                $qry="SELECT conf_value FROM configuration WHERE conf_name='MAX_SIZE'";
                $rs=$conn->execute($qry);
                $row=array();
                $row=$rs->fields;
                $sizelmt=((int)$row[0])*1000;
                if(isset($_COOKIE['uname']))
                {
                  $sizelmt=$config['PRE_MAX_SIZE'];
                }
                else $sizelmt=$config['MAX_SIZE'];
                
                $qry="SELECT conf_value FROM configuration WHERE conf_name='MIME_TYPES'";
                $rs=$conn->execute($qry);
                $row=array();
                $row=$rs->fields;
                if($row[0]=="") $mimearr="";
                else $mimearr=explode(",",$row[0]);
                
                require_once("include/uploader.php");                
                
                do
                {
                        $key=getRanID(20);
                        $qry="SELECT COUNT(*) FROM fileinfo WHERE idkey='$key'";
                        $rs=$conn->execute($qry);
                        $row=$rs->fields;                        
                        
                }while($row[0]);
                
                do
                {
                        $dirkey=getRanID(20);
                        $qry="SELECT COUNT(*) FROM fileinfo WHERE dir='$dirkey'";
                        $rs=$conn->execute($qry);
                        $row=array();
                        $row=$rs->fields;                        
                }while($row[0]);
                
                
                //mkdir($config['UP_DIR']."/$dirkey");
                //chmod($config['UP_DIR']."/$dirkey",0777);
                //print_r(headers_list());
                //ECHO "-----------------------------";
                $uploader = new MediaUploader($dirkey, $mimearr, $sizelmt);
                //$uploader->setTargetFileName($row[0].".jpg");
                if ($uploader->fetchMedia($media))
                {       $__serverid=$uploader->upload();
                        if($__serverid==false)
                        {
                                //rmdir($config['UP_DIR']."/$dirkey");
                                $err[] = $uploader->getErrors();
                        }        
                }
                else 
                {
                        //rmdir($config['UP_DIR']."/$dirkey");
                        $err[]=$uploader->getErrors();
                        $err[]=sprintf("Failed fetching file '%s'", $upfile);
                }
                
                if(count($err)==0)
                {        
                        $qry="SELECT conf_optional, conf_value FROM configuration WHERE conf_name='MAX_TIME'";
                        $rs=$conn->execute($qry);
                        $row=array();
                        $row=$rs->fields;
                        $maxtime=$row[0];
                        $maxtimeval=$row[1];
                
                
                        $qry="SELECT conf_optional, conf_value FROM configuration WHERE conf_name='MAX_COUNT'";
                        $rs=$conn->execute($qry);
                        $row=array();
                        $row=$rs->fields;
                        $maxcount=$row[0];
                        $maxcountval=$row[1];
                        
                        if(empty($emailfrom))
                        {
                                //$headers = "From: $email <$name>\nMIME-Version: 1.0\nContent-Type: text/html; charset=ISO-8859-1\nX-Mailer: PHP \n";
                                $headers = "From: Delivery@".SITE_NAME.".com <Delivery@".SITE_NAME.".com>\nMIME-Version: 1.0\nContent-Type: text/html; charset=ISO-8859-1\nX-Mailer: PHP\n";
                                $subject=SITE_NAME." Delivery Notification: ".$uploader->getSavedFileName();
                                $msg="Hello from ".SITE.",<br>
                                You've got a file called \"".$uploader->getSavedFileName()."\" (".sprintf("%.2f",($uploader->getMediaSize()/1024))." KB) 
                                waiting for download.<br>You can click on the following link to retrieve your file.
                                The link will expire in $maxtime and will be available for $maxcount 
                                downloads.<br>        Regular link (for all web browsers):
                                <a href=\"".HostURL()."download.php?id=$key\" target=\"_blank\">".HostURL()."download.php?id=$key</a><br>
                                This email was automatically generated, please do not reply to it. For 
                                any inquiries, feel free to email <a href=\"mailto: support@".SITE_NAME.".com\">support@".SITE_NAME.".com</a><br>
                                The ".SITE_NAME." Team";                
                                if(empty($message)) $msg.="<br>Additional Message:<br>$message";
                                @mail($emailto, $subject, "<font face=Tahoma size=2>".$msg."</font>", $headers);                
                        }
                        else
                        {
                                $headers = "From: $emailfrom <$emailfrom>\nMIME-Version: 1.0\nContent-Type: text/html; charset=ISO-8859-1\nX-Mailer: PHP\n";
                                $subject=SITE_NAME." Delivery Notification: ".$uploader->getSavedFileName();
                                $msg="Hello from ".SITE.",<br>
                                You've got a file called \"".$uploader->getSavedFileName()."\" (".sprintf("%.2f",($uploader->getMediaSize()/1024))." KB) 
                                from $emailfrom waiting for download.<br>You can click on the following link to retrieve your file.
                                The link will expire in $maxtime and will be available for $maxcount 
                                downloads.<br>        Regular link (for all web browsers):
                                <a href=\"".HostURL()."download.php?id=$key\" target=\"_blank\">".HostURL()."download.php?id=$key</a><br>
                                This email was automatically generated, please do not reply to it. For 
                                any inquiries, feel free to email <a href=\"mailto: support@".SITE_NAME.".com\">support@".SITE_NAME.".com</a><br>
                                The ".SITE_NAME." Team";                
                                if(empty($message)) $msg.="<br>Message from $emailfrom:<br>$message";
                                @mail($emailto, $subject, "<font face=Tahoma size=2>".$msg."</font>", $headers);
                                
                                
                                $headers = "From: Delivery@".SITE_NAME.".com<Delivery@".SITE_NAME.".com> \nMIME-Version: 1.0\nContent-Type: text/html; charset=ISO-8859-1\nX-Mailer: PHP\n";
                                $subject=SITE_NAME." Notification Sent: ".$uploader->getSavedFileName();
                                $msg="Hello from ".SITE.",<br>
                                Your file called \"".$uploader->getSavedFileName()."\" (".sprintf("%.2f",($uploader->getMediaSize()/1024))." KB) 
                                was sent to $emailto.<br>Please keep the following link for your records in case your recipient 
                                misplaces it. The link will expire in $maxtime and will be available for 
                                $maxcount downloads.<br>        Regular link (for all web browsers):
                                <a href=\"".HostURL()."download.php?id=$key\" target=\"_blank\">".HostURL()."download.php?id=$key</a><br>
                                This email was automatically generated, please do not reply to it. For 
                                any inquiries, feel free to email <a href=\"mailto: support@".SITE_NAME.".com\">support@".SITE_NAME.".com</a><br>
                                The ".SITE_NAME." Team";                
                                if(empty($message)) $msg.="<br>Additional Message:<br>$message";
                                @mail($emailfrom, $subject, "<font face=Tahoma size=2>".$msg."</font>", $headers);                                
                        }
                        /*
                        $server=$_SESSION['server'];
                        unset($_SESSION['server']);
                        if($server=="")
                        {
                         //header("location: error.php");
                        }
                        */
                        $server=$__serverid;
                        $qry="INSERT INTO fileinfo(idkey,dir,mime_type,file_name,size,upload_time,expire_time,max_dwnld,recipient,sender,server) VALUES('$key','$dirkey','".$uploader->getMediaType()."','".$uploader->getSavedFileName()."',".$uploader->getMediaSize().",".time().",".(time()+($maxtimeval*86400)).",".$maxcountval.",'$emailto','$emailfrom','$server')";
                        $conn->execute($qry);
                        $newid=$conn->insert_id();
                        
                        $qry="SELECT conf_optional FROM configuration WHERE conf_name='DAILY_TRANSFER'";
                        $rs=$conn->execute($qry);
                        $row=array();
                        $row=$rs->fields;
                        if($row[0]==date("d-m-Y"))
                                $qry="UPDATE configuration SET conf_value=conf_value+".$uploader->getMediaSize()." WHERE conf_name='DAILY_TRANSFER'";
                        else 
                                $qry="UPDATE configuration SET conf_value=".$uploader->getMediaSize().", conf_optional='".date("d-m-Y")."' WHERE conf_name='DAILY_TRANSFER'";        
                        $conn->execute($qry);
                        
                        //print date("Y-m-d H:i:s");
                        redirect("success.php?id=$newid");
                }
        }
}

$qry="SELECT conf_optional FROM configuration WHERE conf_name='MAX_SIZE'";
$rs=$conn->execute($qry);
$row=array();
$row=$rs->fields;
$maxsize=$row[0];
////////////////////////////////////////////////////////////////
//Ck_Auto_Del();
//print_r($_POST);
if(isset($_COOKIE['uname'])&&isset($_COOKIE['uid']))
{
STemplate::assign("premium","yes");
STemplate::assign("ALW_SIZE",$config['PRE_MAX_SIZE']);
}
else
{
STemplate::assign("ALW_SIZE",$config['MAX_SIZE']);
//post_max_size
}

$srvr=Select_Server();
STemplate::assign("server_id",$srvr);
STemplate::assign("err",$err);
STemplate::display("index.tpl");
?>
