<?php include('template/lbs/b_inside_top.php');?>

<!--
###################################################################################
#######################                                     #######################
#######################   M A I N   S E C T I O N   Start   #######################
#######################                                     #######################
###################################################################################
--> 
   <div id="welcome"><?php echo("$welcometext");?></div>

<?php if($htL == 'Y') { ?> 

<!-- HOME PAGE TOP LINKS - START -->
    
<div id="central">


<h1><?php echo("$lang_9");?> <?php echo("$lnbhome");?> <?php echo("$lang_10");?></h1>

<div id="stop">
<a href="<?php echo("$path");?>linkstopxml.php" target="_blank"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/xml.gif" alt="RSS Feed" border="0" /></a>
 <?php echo("$lang_3");?> <?php echo("$lnbhome");?> <?php echo("$lang_4");?>
</div>
<br />
<?php $currentPage = $_SERVER["PHP_SELF"];?>

<table border="0" cellpadding="0" cellspacing="1">
<?php do { ?>
<tr>
    <td>
<div id="listing">
	<?php $wsn = $row_lista['title']; 
    
		$step8 = str_replace(" ", "-", $wsn);
		$wsseoname = "$step8"; ?>
		
            <a href="<?php echo $row_lista['site']; ?>" target="_blank"><?php echo $row_lista['title']; ?></a><br />

            <?php echo $row_lista['descr1']; ?>
</div>

<div id="listingD">          
<?php echo $row_lista['site']; ?> :: <?php echo("$lang_5");?> <?php echo $row_lista['stad']; ?> :: <?php if($fremode == 'N') { ?> <?php echo $row_lista['bid']; ?> <?php //echo("$lang_6");?> <?php } else { } ?> 
<?php
$htf_category = $row_lista['maincategory'];
$query_LdetCAT = "SELECT * FROM categorylisting WHERE catlistid = '$htf_category'";
$LdetCAT = mysql_query($query_LdetCAT, $apound) or die(mysql_error());
$row_LdetCAT = mysql_fetch_assoc($LdetCAT);
$totalRows_LdetCAT = mysql_num_rows($LdetCAT);
?>
<!--<a href="<?php echo("$path");?><?php echo $row_LdetCAT['categseoname']; ?>/"><?php echo $row_LdetCAT['categoryname'] ?></a> -->

<a href="<?php echo("$path");?><?php echo $row_lista['dtu'];?>/<?php echo("$wsseoname"); ?>.html"><?php echo("$lang_7");?></a>
<?php if($fremode == 'N') { ?> <a href="<?php echo("$path");?>upgrade.php?ucat=<?php echo $row_lista['dtu']; ?>"><?php echo("$lang_8");?></a> <?php } else { } ?>
</div>              
<div id="stats">
          <?php if($prenabled == 'Y' and $enb_home == 'Y') { ?>

	<?php include('pr_update_home.php');?>
	
		<?php if($enb_google == 'Y') { ?>
			<img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/googleIcon.gif" /> <?php echo $row_lista['google']; ?>
		<?php } else {} ?>
		
		<?php if($enb_yahoo == 'Y') { ?>
			<img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/yahooIcon.gif" /> <?php echo $row_lista['yahoo']; ?>
		<?php } else {} ?>
		
		<?php if($enb_msn == 'Y') { ?>
			<img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/msnIcon.gif" /> <?php echo $row_lista['msn']; ?>
		<?php } else {} ?>
		
		<?php if($enb_alexa == 'Y') { ?>
			<img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/alexaIcon.gif" /> <?php echo $row_lista['alexa']; ?>
		<?php } else {} ?>

<?php } else {} ?>
</div>
<hr />
</td>
  </tr>
<?php } while ($row_lista = mysql_fetch_assoc($lista)); ?>
</table>

</div>

<!-- HOME PAGE TOP LINKS - END -->

<?php }
else { }
?>

<!--
###################################################################################
#######################                                     #######################
#######################    M A I N   S E C T I O N   End    #######################
#######################                                     #######################
###################################################################################
-->

<?php include('template/lbs/b_inside_bottom.php');?>
<?php include('template/lbs/b_footer_tpl.php'); ?>