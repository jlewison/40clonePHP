<?php

echo '</div>

			  </div>
		  </div>
			</div>
		</div>
	<div id="sidebar">

		<div class="sidebardiv">
		  <div class="sidebarbody links">
			<h3>Links</h3>
				<div class="sidebarin">
					<p>' . $lang['ThankYou'] . '</p>
				    <p>' . $lang['UsefulLinks'] . '</p>
				    <ul>
				      <li><a href="http://www.pligg.com" target="_blank">Pligg.com</a></li>
			          <li><a href="http://www.pligg.com/forum" target="_blank">Pligg Forum</a></li>
			          <li><a href="http://www.meneame.net" target="_blank">Meneame.net</a></li>
			          </ul>
				    <p>&nbsp;</p>
		    </div>
		</div>

	</div>
</div>
<div class="clearing">&nbsp;</div>
</div>
<div id="footer">
  <div id="credits"><a href="http://www.pligg.com" title="Pligg">Pligg</a><a href="http://jigsaw.w3.org/css-validator/check/referer"></a></div>
</div>
</body></html>';

?>
