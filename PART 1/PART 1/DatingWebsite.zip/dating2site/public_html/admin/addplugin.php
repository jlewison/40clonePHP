<?php
if ( !defined( 'SMARTY_DIR' ) ) {
	include_once( '../init.php' );
}

include( 'sessioninc.php' );

include(LIB_DIR . 'plugin_class.php');

$plugin = new Plugin();


// Load template if load template button pushed
// 
if ( $_POST['action'] == 'add_plugin' ) {

      $plugin->addplugin();

      if ( $plugin->getErrorMessage() ) {
    
          $t->assign ( 'error_message', $plugin->getErrorMessage() );
      }
      else {
    
          header( 'location: pluginlist.php' );
          exit;
      }
}
// Make the page
// 
$t->assign('rendered_page', $t->fetch('admin/addplugin.tpl') );


$t->display( 'admin/index.tpl' );

exit;

?>