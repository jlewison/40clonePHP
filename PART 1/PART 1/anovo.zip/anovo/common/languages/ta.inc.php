<?php
$LANG['msg_error_script'] = 'Script error occured.';
$LANG['msg_error_sorry'] = 'Sorry, errors found!';
$LANG['msg_retry_later'] = 'Please retry later.';
$LANG['msg_no_records'] = 'No records found';
$LANG['list_sort_ascending'] = 'Sort Ascending';
$LANG['list_sort_descending'] = 'Sort Descending';
$LANG['list_records'] = 'Records';
$LANG['list_of_about'] = 'of about';
$LANG['list_seconds'] = 'seconds';
$LANG['list_recpage'] = 'Records/Page';
$LANG['list_choosepage'] = 'Choose Page';
$LANG['confirm_delete_alert_msg'] = 'Are you sure to delete ?';
$LANG['success_delete_msg'] = 'Successfully deleted';
$LANG['invalid_credit_amount_msg'] = 'Credit amount less than the minimum amount';
?>