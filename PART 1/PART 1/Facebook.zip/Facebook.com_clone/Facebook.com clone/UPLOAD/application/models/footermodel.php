<?php
/**
 * Footer model
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 02/01/2008
 */
class Footermodel extends Model
{
		function Footermodel()
		{
				parent::Model();
		}
		#***************************************************************************
		#Method			: getFooter
		#Description	: fetches a footer
		#Author
		#***************************************************************************
		function getFooter($footer_id)
		{
				$footerQuery = $this->db->query('SELECT * FROM manage_static_page WHERE page_id=' . $this->db->escape($footer_id) . ' LIMIT 0,1');
				$footerRow = array();
				if ($footerQuery->num_rows() > 0)
				{
						$this->load->helper('file');
						$footerRow = $footerQuery->result_array();
						//echo APPPATH.'views/default/footer/'.$footerRow[0]['page_name'].'.tpl';
						$footerContent = read_file(APPPATH . 'views/default/footer/' . $footerRow[0]['page_name'] . '.tpl');
						$footerRow[0]['footer_content'] = $footerContent;
						return $footerRow[0];
				}
				else  return false;
		}
		#***************************************************************************
		#Method			: getFooters
		#Description	: fetches all footers
		#Author
		#***************************************************************************
		function getFooters()
		{
				$footerQuery = $this->db->query('SELECT * FROM manage_static_page');
				$footerRow = array();
				if ($footerQuery->num_rows() > 0)
				{
						$footerRow = $footerQuery->result_array();
						return $footerRow;
				}
				else  return false;
		}
		#***************************************************************************
		#Method			: updateFooter
		#Description	: updates footer
		#Author
		#***************************************************************************
		function updateFooter($data)
		{
				$footer = array('title' => ucwords($data['title']));
				$this->db->where('page_id', $data['page_id']);
				$this->db->update('manage_static_page', $footer);
		}
		#***************************************************************************
		#Method			: insertFooter
		#Description	: insert footer
		#Author
		#***************************************************************************
		function insertFooter($data)
		{
				$footer = array('page_name' => $data['page_name'], 'title' => $data['title']);
				$this->db->insert('manage_static_page', $footer);
				$this->db->query('UPDATE manage_static_page SET date_added=NOW()');
		}
		#***************************************************************************
		#Method			: deleteFooter
		#Description	: deletes footer
		#Author
		#***************************************************************************
		function deleteFooter($footer_id)
		{
				$this->db->where('page_id', $footer_id);
				$this->db->delete('manage_static_page');
		}
		function isTemplateExist($pageTpl, $pageId = '')
		{
				$this->db->select('page_id');
				$this->db->from('manage_static_page');
				$this->db->where('page_name', strtolower($pageTpl));
				if ($pageId != '') $this->db->where('page_id !=', $pageId);
				$resSQL = $this->db->get();
				if ($resSQL->num_rows() > 0) return true;
				else  return false;
		}
		function isPageExist($pageName, $pageId = '')
		{
				$this->db->select('page_id');
				$this->db->from('manage_static_page');
				$this->db->where('title', ucwords($pageName));
				if ($pageId != '') $this->db->where('page_id !=', $pageId);
				$resSQL = $this->db->get();
				if ($resSQL->num_rows() > 0) return true;
				else  return false;
		}
}

?>