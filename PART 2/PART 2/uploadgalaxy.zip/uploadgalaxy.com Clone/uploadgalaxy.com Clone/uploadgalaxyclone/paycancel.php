<?
include("include/config.php");
$item_name=$_REQUEST['item_name'];
STemplate::assign("item_name",$item_name);
STemplate::display("paycancel.tpl");
?>
