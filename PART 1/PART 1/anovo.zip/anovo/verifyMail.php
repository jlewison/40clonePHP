<?php
require_once ('./common/config.inc.php');
$CFG['lang']['include_files'][] = 'includes/languages/%s/verifyMail.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['lang']['include_files'][] = 'common/languages/%s/help.inc.php';
$CFG['html']['header'] = 'members/includes/languages/%s/html_header.php';
$CFG['html']['footer'] = 'members/includes/languages/%s/html_footer.php';
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class verifyMailHandler extends FormHandler
{
		public function chkCorrectEmail($err_tip)
		{
				$sql = 'SELECT user_id, name FROM ' . $this->CFG['db']['tbl']['users'] . ' WHERE email=\'' . addslashes($this->fields_arr['email']) . '\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($row = $rs->FetchRow())
				{
						if ($this->fields_arr['code'] == substr(md5($row['user_id']), 0, 8))
						{
								$this->fields_arr['user_id'] = $row['user_id'];
								$this->fields_arr['name'] = $row['name'];
								return true;
						}
				}
				$this->fields_err_tip_arr['email'] = $err_tip;
				return false;
		}
		public function updateNewPassword()
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['users'] . ' SET  password = \'' . md5($this->fields_arr['password']) . '\'
						 WHERE user_id = \'' . $this->fields_arr['user_id'] . '\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function chkIsPasswordAndUserNameAreSame($err_tip = '')
		{
				if ($this->fields_arr['name'] and $this->fields_arr['password'])
				{
						if (strtolower($this->fields_arr['name']) == strtolower($this->fields_arr['password']))
						{
								$this->fields_err_tip_arr['password'] = $err_tip;
								return false;
						}
				}
				return true;
		}
		public function chkIsSamePasswords($field_name1, $field_name2, $err_tip = '')
		{
				$is_ok = ($this->fields_arr[$field_name1] == $this->fields_arr[$field_name2]);
				if (!$is_ok) $this->fields_err_tip_arr[$field_name1] = $this->fields_err_tip_arr[$field_name2] = $err_tip;
				return $is_ok;
		}
		public function chkIsValidSize($field_name, $min, $max, $err_tip = '')
		{
				if ((strlen($this->fields_arr[$field_name]) < $min) or (strlen($this->fields_arr[$field_name]) > $max))
				{
						$this->fields_err_tip_arr[$field_name] = $err_tip;
						return false;
				}
				return true;
		}
}
$verifyfrm = new verifyMailHandler();
$verifyfrm->setDBObject($db);
$verifyfrm->makeGlobalize($CFG, $LANG);
$verifyfrm->setPageBlockNames(array('msg_form_error', 'msg_form_success', 'form_verifymail', 'form_email'));
$verifyfrm->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$verifyfrm->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$verifyfrm->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$verifyfrm->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$verifyfrm->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$verifyfrm->setFormField('code', '');
$verifyfrm->setFormField('user_id', '');
$verifyfrm->setFormField('password', '');
$verifyfrm->setFormField('confirm_password', '');
$verifyfrm->setFormField('password', '');
$verifyfrm->setFormField('email', '');
$verifyfrm->setFormField('name', '');
$verifyfrm->setAllPageBlocksHide();
$verifyfrm->setPageBlockShow('form_email');
$LANG['verifymail_password'] = str_replace('{min_count}', $CFG['admin']['password_min_size'], $LANG['verifymail_password']);
$LANG['verifymail_password'] = str_replace('{max_count}', $CFG['admin']['password_max_size'], $LANG['verifymail_password']);
$title = $LANG['verifymail_title'];
if ($verifyfrm->isFormGETed($_GET, 'code'))
{
		$verifyfrm->sanitizeFormInputs($_GET);
}
if ($verifyfrm->isFormPOSTed($_POST, 'verifyEmail'))
{
		$verifyfrm->sanitizeFormInputs($_POST);
		$verifyfrm->chkIsNotEmpty('email', $LANG['err_tip_compulsory']) and $verifyfrm->chkIsValidEmail('email', $LANG['verifymail_err_tip_invalid_email']);
		if ($verifyfrm->isValidFormInputs())
		{
				$verifyfrm->chkCorrectEmail($LANG['err_tip_invalid_details']);
				if ($verifyfrm->isValidFormInputs())
				{
						$verifyfrm->setAllPageBlocksHide();
						$verifyfrm->setPageBlockShow('form_verifymail');
						$title = $LANG['verifymail_password_title'];
				}
				else  $verifyfrm->setPageBlockShow('msg_form_error');
		}
		else  $verifyfrm->setPageBlockShow('msg_form_error');
}
if ($verifyfrm->isFormPOSTed($_POST, 'verifymail'))
{
		$verifyfrm->sanitizeFormInputs($_POST);
		$verifyfrm->chkIsNotEmpty('password', $LANG['err_tip_compulsory']) and $verifyfrm->chkIsValidSize('password', $CFG['admin']['password_min_size'], $CFG['admin']['password_max_size'], $LANG['verifymail_err_tip_invalid_size']);
		$verifyfrm->chkIsNotEmpty('confirm_password', $LANG['err_tip_compulsory']) and $verifyfrm->chkIsSamePasswords('password', 'confirm_password', $LANG['verifymail_err_tip_same_password']);
		$verifyfrm->chkIsPasswordAndUserNameAreSame($LANG['password_user_name']);
		$title = $LANG['verifymail_password_title'];
		if ($verifyfrm->isValidFormInputs())
		{
				$verifyfrm->updateNewPassword();
				$verifyfrm->setAllPageBlocksHide();
				$verifyfrm->setPageBlockShow('msg_form_success');
		}
		else
		{
				$verifyfrm->setFormField('password', '');
				$verifyfrm->setFormField('confirm_password', '');
				$verifyfrm->setAllPageBlocksHide();
				$verifyfrm->setPageBlockShow('form_verifymail');
				$verifyfrm->setPageBlockShow('msg_form_error');
		}
}



?>
<div id="selVerifyMail">
	<h2><?php echo $title; ?></h2>
<?php
if ($verifyfrm->isShowPageBlock('msg_form_error'))
{
?>
	<div id="selMsgError">
		 <p><?php echo $LANG['msg_error_sorry'] . ' ' . $verifyfrm->getCommonErrorMsg(); ?></p>
	</div>
<?php
}
if ($verifyfrm->isShowPageBlock('msg_form_success'))
{
?>
	<div id="selMsgSuccess">
		<p><?php echo $LANG['verified_successfully']; ?></p>
	</div>
<?php
}
if ($verifyfrm->isShowPageBlock('form_email'))
{
?>
	<div id="selEmail">
		<form name="form_verifymail" id="selFormVerifyMail" method="post" action="<?php echo URL($_SERVER['PHP_SELF']); ?>" autocomplete="off">
			<input type="hidden" name="code" id="code" value="<?php echo $verifyfrm->getFormField('code'); ?>" />
			<table summary="<?php echo $LANG['verifymail_tbl_summary']; ?>">
			   	<tr>
					<td class="<?php echo $verifyfrm->getCSSFormLabelCellClass('email'); ?>"><?php ShowHelpTip('email'); ?><label for="email"><?php echo $LANG['verifymail_email']; ?></label></td>
					<td class="<?php echo $verifyfrm->getCSSFormFieldCellClass('email'); ?>"><?php echo $verifyfrm->getFormFieldErrorTip('email'); ?><input type="text" name="email" id="email" tabindex="<?php echo $verifyfrm->getTabIndex(); ?>" value="<?php echo $verifyfrm->getFormField('email'); ?>" /></td>
			   	</tr>
				<tr>
					<td class="<?php echo $verifyfrm->getCSSFormFieldCellClass('submit'); ?>" colspan="2"><input type="submit" name="verifyEmail" id="verifyEmail" tabindex="<?php echo $verifyfrm->getTabIndex(); ?>" value="<?php echo $LANG['verifymail_submit']; ?>" /></td>
				</tr>
			</table>
		</form>
	</div>
<?php
}
if ($verifyfrm->isShowPageBlock('form_verifymail'))
{
?>
	<form name="form_verifymail" id="selFormVerifyMail" method="post" action="<?php echo URL($_SERVER['PHP_SELF']); ?>" autocomplete="off">
		<table summary="<?php echo $LANG['verifymail_tbl_summary']; ?>">
          <tr>
            <td class="<?php echo $verifyfrm->getCSSFormLabelCellClass('password'); ?>"><?php ShowHelpTip('password'); ?>
              <label for="password"><?php echo $LANG['verifymail_password']; ?></label>
              <span id="selCompulsoryField">*</span></td>
            <td class="<?php echo $verifyfrm->getCSSFormFieldCellClass('password'); ?>"><?php echo $verifyfrm->getFormFieldErrorTip('password'); ?>
              <input type="password" class="clsTextBox help" name="password" id="password" title="<?php ShowToolTip('password'); ?>" tabindex="<?php echo $verifyfrm->getTabIndex(); ?>" value="<?php echo $verifyfrm->getFormField('password'); ?>" /></td>
          </tr>
          <tr>
            <td class="<?php echo $verifyfrm->getCSSFormLabelCellClass('confirm_password'); ?>"><?php ShowHelpTip('confirmpassword'); ?>
              <label for="confirm_password"><?php echo $LANG['verifymail_confirm_password']; ?></label>
              <span id="selCompulsoryField">*</span></td>
            <td class="<?php echo $verifyfrm->getCSSFormFieldCellClass('confirm_password'); ?>"><?php echo $verifyfrm->getFormFieldErrorTip('confirm_password'); ?>
              <input type="password" class="clsTextBox help" name="confirm_password" id="confirm_password" title="<?php ShowToolTip('confirmpassword'); ?>" tabindex="<?php echo $verifyfrm->getTabIndex(); ?>" value="<?php echo $verifyfrm->getFormField('confirm_password'); ?>" /></td>
          </tr>
		    <tr>
				<td class="<?php echo $verifyfrm->getCSSFormFieldCellClass('submit'); ?>" colspan="2">
					<input type="hidden" name="user_id" id="user_id" value="<?php echo $verifyfrm->getFormField('user_id'); ?>" />
					<input type="hidden" name="email" value="<?php echo $verifyfrm->getFormField('email'); ?>" />
					<input type="hidden" name="name" value="<?php echo $verifyfrm->getFormField('name'); ?>" />
					<input type="submit" name="verifymail" id="verifymail" tabindex="<?php echo $verifyfrm->getTabIndex(); ?>" value="<?php echo $LANG['verifymail_submit']; ?>" />
				</td>
			</tr>
		</table>
	</form>
<?php
}
?>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>