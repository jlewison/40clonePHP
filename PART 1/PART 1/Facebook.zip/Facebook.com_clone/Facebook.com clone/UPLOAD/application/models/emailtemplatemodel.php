<?php

class Emailtemplatemodel extends Model
{
		//Constructor
		function Emailtemplatemodel()
		{
				parent::Model();
		}
		function readEmailTemplate($templateKey)
		{
				$templateQuery = $this->db->query('SELECT * FROM mail_templates WHERE template_key=' . $this->db->escape($templateKey) . ' AND template_language=' . $this->db->escape($this->config->item('language_code')) . ' LIMIT 0,1');
				$templateRow = array();
				if ($templateQuery->num_rows() > 0)
				{
						$templateRow = $templateQuery->result_array();
						return $templateRow[0];
				}
				else  return false;
		}
		#***************************************************************************
		#Method			: getEmailTemplate
		#Description	: fetches email templates
		#Author
		#***************************************************************************
		function getEmailTemplate()
		{
				$templateQuery = $this->db->query('SELECT * FROM mail_templates WHERE template_language=' . $this->db->escape($this->config->item('language_code')) . '');
				$templateRow = array();
				if ($templateQuery->num_rows() > 0)
				{
						$templateRow = $templateQuery->result_array();
						return $templateRow;
				}
				else  return false;
		}
		#***************************************************************************
		#Method			: updateEmailTemplate
		#Description	: updates email template
		#Author
		#***************************************************************************
		function updateEmailTemplate($data)
		{
				$emailTemplate = array('template_subject' => $data['template_subject'], 'template_content' => $data['template_content']);
				$this->db->where('template_key', $data['template_key']);
				$this->db->update('mail_templates', $emailTemplate);
		}
}

?>