<?php //00461
// Copyright Notice
// Web Site URL:  http://www.zeeways.com
// Script Owner eMail: mail@zeeways.com
// Date: April, 2007
// Script Name: Zeeways Auction Website PHP Script
// Copyright Details: This script is not free.  Do not Remove this Copy Right notice.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the site administrator.');exit(199);
?>
4+oV59QQSn8vVKWcq27cCSDru1eZb8B75JAhPjen3UQnbj8KvZkksHkfXdjy5QDk6eQtEg5U0G6o
g79NYTNNtQHYTguRHSwdUtUVb2zkzunwQQh+8bk0UUpXfpx5+8m3GoNYLssNVdtNHmAqxthdIlMa
ccoN6Wmv+sJaliixrCHJ6wZ/mqEFlCrqni/4nXzonwm86CvkmjH0MK+wpscevRPs6g2xw0F8mEgv
H4ukwt2bEEo8wsWn/42SlfQcD0nCS/Sjhab+jffm4OEAPvPVcAIn5YXsg/gSAMuGFfoix0GpXFxh
FRH6vHerq5heAUNL1dPQKhSiihGE9qZLRfZYsSD/+ML2duHCE5qKdyPJ6HbAJ+xuzsHYfHUqKsRj
3TVW6uB90dWd88a4ycctTYq5smcj1//dCp3COgKltCmbbXpTAROeR8UpWWm/PS7vQ2KrnxZ+yhzx
NYWBqo+/yOKxTJKKkEV9vuHvFMn8ajlVEvGebyL5rACMDZIUVH4hlMUSDUqFrVTKq6eGzIpmfkdn
X7htsskbaqS3yogNkToWXKIfHk5VEh7qgP5K8HPT+5O3/HnHvSB3FS/1D5GxfC4dc2GmWSOD7q+9
i56GfdvyTWHKJ3KuE0/PXLQ+S9KqeWRyOlNUdZb3pV/mYK/6NIqV8NRWFft1yojN5BQokELnQIFX
mCNpLyA0dj+C4vWUr3HKwUMHmPV7u8v1MsSKVGQpCgexH9H8duQyo1zsASbdDLI6ohtN88TrwfcG
j5kyskx8btV0h8fch0VpAFonc0qr09JVgscjBFt0SkKpE80urzi0UDRtSdrs7PjxDIi5JHxaDLP6
asfIYiPL7Z2gnWTpLWZdPBv/WIwaDfPnIQybE+pj0s4eISZvLh0CYSzvuy92IdOHfSulN7y45X48
/jb0g+eURtQ3bd4nkdrYrGLCZZ8VG7ZDUgYJfqpPJqtDh8DO+Md3hnQdh7sFRyzXTjDhSOMf2jle
b+FD4LiYaHYzD8kPaRTFiQi8+7MEPRyW4O66XZRJ0AqJqyxmIfbpKxNL5kon