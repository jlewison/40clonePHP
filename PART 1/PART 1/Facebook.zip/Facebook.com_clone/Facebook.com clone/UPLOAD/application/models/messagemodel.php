<?php

class Messagemodel extends Model
{
		//Constructor
		function Messagemodel()
		{
				parent::Model();
		}
		function getMessagesInInbox($orderBy = 'datestamp desc', $start = '', $limit = '')
		{
				return $this->getUserMessages('inbox', '', $orderBy, $start, $limit);
		}
		function getMessagesInInboxCount()
		{
				return $this->getUserMessagesCount('inbox');
		}
		function getMessagesInSent($orderBy = 'datestamp desc', $start = '', $limit = '')
		{
				return $this->getUserMessages('sent', '', $orderBy, $start, $limit);
		}
		function getMessagesInSentCount()
		{
				return $this->getUserMessagesCount('sent');
		}
		function getMessagesInTrash($orderBy = 'datestamp desc', $start = '', $limit = '')
		{
				return $this->getUserMessages('trash', '', $orderBy, $start, $limit);
		}
		function getMessagesInTrashCount()
		{
				return $this->getUserMessagesCount('trash');
		}
		function getMessage($message_id)
		{
				return $this->getUserMessages('message', $message_id);
		}
		function getUserMessages($in, $message_id = '', $orderBy = 'datestamp DESC', $start = '', $limit = '')
		{
				if ($in == 'inbox') $condition = 'msg.to_id= ' . $this->session->userdata('user_id') . ' AND msg.to_message_in=' . $this->db->escape($in) . ' AND usr.user_id = msg.from_id';
				else
						if ($in == 'sent') $condition = 'msg.from_id= ' . $this->session->userdata('user_id') . ' AND msg.from_message_in=' . $this->db->escape($in) . ' AND usr.user_id = msg.to_id';
						else
								if ($in == 'trash') $condition = '((msg.from_id= ' . $this->session->userdata('user_id') . ' AND msg.from_message_in=' . $this->db->escape($in) . ' AND usr.user_id = msg.to_id) OR (msg.to_id= ' . $this->session->userdata('user_id') . ' AND msg.to_message_in=' . $this->db->escape($in) . ' AND usr.user_id = msg.from_id))';
								else
										if ($in == 'message') $condition = 'msg.message_id = ' . $message_id . ' AND msg.from_id=usr.user_id ';
				$messageSql = 'SELECT usr.user_id, usr.username, usr.avatar_ext, msg.subject, msg.message, msg.message_id, msg.from_message_status, msg.to_message_status,
						msg.from_message_in, msg.to_message_in, DATE_FORMAT(msg.datestamp,\'%b %e,%Y at %k:%i %p \') AS datestamp
						FROM messages msg, users usr
						WHERE msg.message_parent_id=0 AND ' . $condition;
				if (trim($orderBy) != '') $messageSql .= ' ORDER BY msg.' . $orderBy;
				if (trim($limit) != '' && is_numeric($limit))
				{
						if (trim($start) != '' && is_numeric($start)) $messageSql .= ' LIMIT ' . $start . ', ' . $limit;
						else  $messageSql .= ' LIMIT ' . $limit;
				}
				//print $messageSql; exit();
				$messageQuery = $this->db->query($messageSql);
				$messages = array();
				if ($messageQuery->num_rows() > 0)
				{
						foreach ($messageQuery->result_array() as $messageRow)
						{
								$userAvatar = getAvatar($messageRow['user_id'], $messageRow['avatar_ext'], 'thumb');
								$messageRow['avatar'] = $userAvatar;
								$messages[] = $messageRow;
						}
						return $messages;
				}
				else  return false;
		}
		function getUserMessagesCount($in, $message_id = '', $specialCond = false)
		{
				if ($in == 'inbox') $condition = 'msg.to_id= ' . $this->session->userdata('user_id') . ' AND msg.to_message_in=' . $this->db->escape($in) . ' AND usr.user_id = msg.from_id';
				else
						if ($in == 'sent') $condition = 'msg.from_id= ' . $this->session->userdata('user_id') . ' AND msg.from_message_in=' . $this->db->escape($in) . ' AND usr.user_id = msg.to_id';
						else
								if ($in == 'trash') $condition = '((msg.from_id= ' . $this->session->userdata('user_id') . ' AND msg.from_message_in=' . $this->db->escape($in) . ' AND usr.user_id = msg.to_id) OR (msg.to_id= ' . $this->session->userdata('user_id') . ' AND msg.to_message_in=' . $this->db->escape($in) . ' AND usr.user_id = msg.from_id))';
								else
										if ($in == 'message') $condition = 'msg.message_id = ' . $message_id . ' AND msg.from_id=usr.user_id ';
				$secondCond = 1;
				if ($specialCond) $secondCond = 'msg.message_id = ' . $message_id;
				$countSql = 'SELECT count(msg.message_id) as cnt
						FROM messages msg, users usr
						WHERE msg.message_parent_id=0 AND ' . $condition . ' AND ' . $secondCond;
				$countQuery = $this->db->query($countSql);
				if ($countQuery->num_rows() > 0)
				{
						$countRow = $countQuery->result_array();
						return $countRow[0]['cnt'];
				}
				else  return 0;
		}
		function updateMessage($message_ids, $action_from)
		{
				if ($action_from == 'inbox') $condition = 'to_message_in = \'trash\'';
				else
						if ($action_from == 'sent') $condition = 'from_message_in = \'trash\'';
				$this->db->query('UPDATE messages SET ' . $condition . ' WHERE message_id IN(' . $message_ids . ')');
		}
		function updateMessageStatus($message_ids, $message_status_field, $message_status)
		{
				$this->db->query('UPDATE messages SET ' . $message_status_field . '=\'' . $message_status . '\' WHERE message_id IN(' . $message_ids . ')');
		}
		function messageTrash($message_ids)
		{
				$this->db->query('UPDATE messages SET message_in=\'trash\' WHERE message_id IN(' . $message_ids . ')');
		}
		function messageDelete($message_ids)
		{
				if (is_array($message_ids))
				{
						//
						//$message_arr = explode(',',$message_ids);
						foreach ($message_ids as $key => $val)
						{
								$query = $this->db->query('SELECT to_id,from_id,from_message_in,to_message_in FROM messages WHERE message_id=' . $val . '');
								if ($query->num_rows() > 0)
								{
										$messageRow = $query->row_array();
										if (($messageRow['from_message_in'] == 'delete') || ($messageRow['to_message_in'] == 'delete') || (($messageRow['to_id'] == $messageRow['from_id']) && (($messageRow['from_message_in'] == 'trash') || ($messageRow['to_message_in'] == 'trash') && ($messageRow['from_message_in'] != 'sent'))))
										{
												$this->db->query('DELETE FROM messages WHERE message_id =' . $val . '');
										}
										else
												if ($messageRow['to_id'] == $this->session->userdata('user_id'))
												{
														$this->db->query('UPDATE messages SET to_message_in=\'delete\' WHERE message_id =' . $val . '');
												}
												else
														if ($messageRow['from_id'] == $this->session->userdata('user_id'))
														{
																$this->db->query('UPDATE messages SET from_message_in=\'delete\' WHERE message_id =' . $val . '');
														}
								}
						}
				}
				else
				{
						$message_id = $message_ids;
						$query = $this->db->query('SELECT to_id,from_id,from_message_in,to_message_in FROM messages WHERE message_id=' . $message_id . '');
						if ($query->num_rows() > 0)
						{
								$messageRow = $query->row_array();
								if (($messageRow['from_message_in'] == 'delete') || ($messageRow['to_message_in'] == 'delete') || (($messageRow['to_id'] == $messageRow['from_id']) && (($messageRow['from_message_in'] == 'trash') || ($messageRow['to_message_in'] == 'trash') && ($messageRow['from_message_in'] != 'sent'))))
								{
										$this->db->query('DELETE FROM messages WHERE message_id =' . $message_id . '');
								}
								else
										if ($messageRow['to_id'] == $this->session->userdata('user_id'))
										{
												$this->db->query('UPDATE messages SET to_message_in=\'delete\' WHERE message_id =' . $message_id . '');
										}
										else
												if ($messageRow['from_id'] == $this->session->userdata('user_id'))
												{
														$this->db->query('UPDATE messages SET from_message_in=\'delete\' WHERE message_id =' . $message_id . '');
												}
						}
				}
		}
		function getFriendsAddress($suggest = '', $limit = 10)
		{
				$addressSql = 'SELECT username, user_id FROM users WHERE (user_id=' . $this->session->userdata('user_id') . ' AND username LIKE \'' . $suggest . '%\') OR (username LIKE \'' . $suggest . '%\' AND user_id IN(
							SELECT friend_id AS FriendId FROM friends_list WHERE user_id=' . $this->session->userdata('user_id') . ' AND approved_status=\'yes\'
							UNION
							SELECT user_id as FriendId FROM friends_list WHERE friend_id=' . $this->session->userdata('user_id') . ' AND approved_status=\'yes\')) LIMIT 0, ' . $this->db->escape($limit);
				$addressQuery = $this->db->query($addressSql);
				$address = array();
				if ($addressQuery->num_rows() > 0)
				{
						foreach ($addressQuery->result_array() as $addressRow)
						{
								$address[$addressRow['user_id']] = $addressRow['username'];
						}
				}
				return $address;
		}
		function sendMessage($msgConfig, $isAdmin = false)
		{
				if (isset($msgConfig['to_id']) && isset($msgConfig['subject']) && isset($msgConfig['message']))
				{
						$toIds = explode(',', $msgConfig['to_id']);
						$id = '';
						$user_id = $this->session->userdata('user_id');
						if (is_array($toIds))
						{
								foreach ($toIds as $toId)
								{
										if ($isAdmin) $newMessageSql = $this->db->query('INSERT INTO messages SET from_id=' . $this->db->escape($toId) . ',to_id=' . $this->db->escape($toId) . ',subject=' . $this->db->escape($msgConfig['subject']) . ',message=' . $this->db->escape($msgConfig['message']) . ',from_message_status=\'unread\',to_message_status=\'unread\',from_message_in=\'sent\',to_message_in=\'inbox\',datestamp=NOW()');
										else  $newMessageSql = $this->db->query('INSERT INTO messages SET from_id=' . $this->db->escape($user_id) . ',to_id=' . $this->db->escape($toId) . ',subject=' . $this->db->escape($msgConfig['subject']) . ',message=' . $this->db->escape($msgConfig['message']) . ',from_message_status=\'unread\',to_message_status=\'unread\',from_message_in=\'sent\',to_message_in=\'inbox\',datestamp=NOW()');
										$id = $this->db->insert_id();
								}
								return $id;
						}
						else  return false;
				}
				else  return false;
		}
}
?>