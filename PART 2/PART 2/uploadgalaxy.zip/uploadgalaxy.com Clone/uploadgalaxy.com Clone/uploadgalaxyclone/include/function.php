<?php

function Select_Server()
{
global $conn;
$qry="select * from server ORDER by used ASC LIMIT 1";
$rs=$conn->execute($qry);
return $rs->fields;
}
function Ck_Auto_Del()
{
global $conn;
$qry="SELECT conf_value FROM configuration WHERE conf_name='AUTO_FILE_DELETE'";
$rs=$conn->execute($qry);
$row=array();
$row=$rs->fields;
if($row[0]=="Yes")
{
        $now=time();
        $qry="SELECT dir, file_name FROM fileinfo WHERE expire_time<$now";
        $conn->execute($qry);
        while(!$rs->EOF)
        {
                $row=array();
                $row=$rs->fields;
                @unlink("uploads/".$row[1]."/".$row[2]);
                @rmdir("uploads/".$row[1]);
                $rs->movenext();
        }
        $qry="DELETE FROM fileinfo WHERE expire_time<$now";
        $conn->execute($qry);
}

}

//GET THE SUBJECT OF AN EMAIL TO BE SEND
function get_email_subject($sub)
{
        $subject="";
        global $conn;
        $sql="select * from email_subject where subject_id=$sub";
        $rs=$conn->execute($sql);
        $subject=$rs->fields['subject'];
        return $subject;

}


//CHECK HOTORNOT ADMINISTRATOR LOGIN
function chk_admin_login()
{
        global $config;
        if($_SESSION['ADMINUID']!=$config[admin_name] || $_SESSION['ADMINPASSWORD']!=$config[admin_pass])
        {
                header("Location:$config[baseurl]/admin/login.php");
                exit;
        }
}
function chk_moderator_login()
{
        global $config,$conn;

        $sql="select * from hotusers where uname='$_SESSION[MODUID]' and privilege='moderator' and status='yes'";
        $rs=$conn->execute($sql);
        if($_SESSION['MODUID']=="" || $_SESSION['MODPASSWORD']=="" || $rs->recordcount()==0)
        {

                header("Location:$config[baseurl]/moderator/login.php");
                exit;
        }
}
//CHECK HOTORNOT MEMBER LOGIN
function chk_member_login()
{
        global $config,$conn;

        $sql="select * from hotusers where uname='$_SESSION[USERNAME]'";
        $rs=$conn->execute($sql);
        if($_SESSION['USERNAME']=="" || $_SESSION['PASSWORD']=="" || $rs->recordcount()==0)
        {

                header("Location:$config[baseurl]/user/login.php");
                exit;
        }
}
//SOME YEARS CONSTRUCTION
function years($sel="")
{
        $year="";
        $init=date("Y");
        for($i=$init;$i<=$init+2;$i++)
        {
                if($i==$sel)
                        $year.="<option value='$i' selected>$i</option>";
                else
                        $year.="<option value='$i'>$i</option>";
        }
        return $year;
}
//SOME MONTHS CONSTRUCTION
function months($sel=""){
        $month="";
        //$months=array("January","February","March","April","May","June","July","August","September","October","November","December");
        for($i=1;$i<=12;$i++)
        {
                if($i==$sel)
                        $month.="<option value='$i' selected>$i</option>";
                else
                        $month.="<option value='$i'>$i</option>";
        }
        return $month;
}
//SOME DAYS CONSTRUCTION
function days($sel="")
{
        $day="";
        for($i=1;$i<=31;$i++)
        {
                if($i==$sel)
                        $day.="<option value='$i' selected>$i</option>";
                else
                        $day.="<option value='$i'>$i</option>";
        }
        return $day;
}
function delete_members($delid)
{
        global $conn;

        $sql="select uname from hotusers where id='$delid'";
        $rs=$conn->execute($sql);
        $uname=$rs->fields[uname];
        $sql="delete from hotusers where id='$delid' and uname='$uname'";
        $conn->execute($sql);

}
function age($sel="")
{
        for($i=18;$i<=110;$i++)
        {
        if($sel==$i)
                $age .="<option value='$i' selected>$i</option>";
        else
                $age .="<option value='$i'>$i</option>";
        }
return $age;
}
function member_rate_calc($username="")
{
        global $config,$conn;
        if($username=="")
        $sql="select count(*) as record,sum(rank) as total from userrate where touser='$_SESSION[USERNAME]'";
        else
        $sql="select count(*) as record,sum(rank) as total from userrate where touser='$username'";
        $res=$conn->execute($sql);
        if($res->fields[record]>5) $rate=round(($res->fields['total']/$res->fields[record]),1);
        else $rate="?";
        STemplate::assign('count',$res->fields[record]+0);
        if(isset($rate))return $rate;
}

function member_rate_howmany($uname)
{
        global $config,$conn;

        $sql="select count(*) as record,sum(rank) as total from userrate where touser='$uname'";
        $res=$conn->execute($sql);
        if($res->fields[record]>5) $rate=round(($res->fields['total']/$res->fields[record]),1); else $rate="No";
        $a  = array();
        $a['rate']=$rate;
        $a['count']=$res->fields[record];

        return $a;
}

function createThumb($srcname,$destname,$maxwidth,$maxheight)
{
        global $config;
        $oldimg = $srcname;//$config['basepath']."/photo/".$srcname;
        $newimg = $destname;//$config['basepath']."/photo/".$destname;

        $imagedata = GetImageSize($oldimg);
        $imagewidth = $imagedata[0];
        $imageheight = $imagedata[1];
        $imagetype = $imagedata[2];

        $shrinkage = 1;
        if ($imagewidth > $maxwidth)
        {
                $shrinkage = $maxwidth/$imagewidth;
        }
        if($shrinkage !=1)
        {
                $dest_height = $shrinkage * $imageheight;
                $dest_width = $maxwidth;
        }
        else
        {
                $dest_height=$imageheight;
                $dest_width=$imagewidth;
        }
        if($dest_height > $maxheight)
        {
                $shrinkage = $maxheight/$dest_height;
                $dest_width = $shrinkage * $dest_width;
                $dest_height = $maxheight;
        }
        if($imagetype==2)
        {
                $src_img = imagecreatefromjpeg($oldimg);
                $dst_img = imageCreateTrueColor($dest_width, $dest_height);
                ImageCopyResampled($dst_img, $src_img, 0, 0, 0, 0, $dest_width, $dest_height, $imagewidth, $imageheight);
                imagejpeg($dst_img, $newimg, 100);
                imagedestroy($src_img);
                imagedestroy($dst_img);
        }
        elseif ($imagetype == 3)
        {
                $src_img = imagecreatefrompng($oldimg);
                $dst_img = imageCreateTrueColor($dest_width, $dest_height);
                ImageCopyResampled($dst_img, $src_img, 0, 0, 0, 0, $dest_width, $dest_height, $imagewidth, $imageheight);
                imagepng($dst_img, $newimg, 100);
                imagedestroy($src_img);
                imagedestroy($dst_img);
        }
        else
        {
                $src_img = imagecreatefromgif($oldimg);
                $dst_img = imageCreateTrueColor($dest_width, $dest_height);
                ImageCopyResampled($dst_img, $src_img, 0, 0, 0, 0, $dest_width, $dest_height, $imagewidth, $imageheight);
                imagejpeg($dst_img, $newimg, 100);
                imagedestroy($src_img);
                imagedestroy($dst_img);
        }
}

//CHECK IF EMAIL ADDRESS IS VALID OR NOT
function check_email($email)
{
       $email_regexp = "^([-!#\$%&'*+./0-9=?A-Z^_`a-z{|}~])+@([-!#\$%&'*+/0-9=?A-Z^_`a-z{|}~]+\\.)+[a-zA-Z]{2,4}\$";
       return eregi($email_regexp, $email);
}
function check_email_exists($email,$table)
{
        global $conn;

        $sql="select count(*) as cnt from $table where email='$email'";
        $res=$conn->execute($sql);
        if($res->fields[cnt]>0) return 1; else return 0;
}
//CHECK MIN LENGTH OF A VALUE
function check_min_length($str,$length)
{
        if(strlen($str)<$length)
                return 0;
        else
                return 1;
}
//CHECK MAX LENGTH OF A VALUE
function check_max_length($str,$length)
{
        if(strlen($str)>$length)
                return 0;
        else
                return 1;
}
//Populate country
function country_box($sel=""){
$coun="";
$country=array("United States","Afghanistan","Albania","Algeria","American Samoa","Andorra","Angola","Anguilla","Antartica","Antigua and Barbuda","Argentina","Armenia","Aruba","Ascension Island","Australia","Austria","Azerbaijan","Bahamas","Bahrain","Bangladesh","Barbados","Belarus","Belgium","Belize","Benin","Bermuda","Bhutan","Bolivia","Botswana","Bouvet Island","Brazil","Brunei Darussalam","Bulgaria","Burkina Faso","Burundi","Cambodia","Cameroon","Canada","Cape Verde Islands","Cayman Islands","Chad","Chile","China","Christmas Island","Colombia","Comoros","Cook Islands","Costa Rica","Cote d Ivoire","Croatia/Hrvatska","Cyprus","Czech Republic","Denmark","Djibouti","Dominica","Dominican Republic","East Timor","Ecuador","Egypt","El Salvador","Equatorial Guinea","Eritrea","Estonia","Ethiopia","Falkland Islands","Faroe Islands","Fiji","Finland","France","French Guiana","French Polynesia","Gabon","Gambia","Georgia","Germany","Ghana","Gibraltar","Greece","Greenland","Grenada","Guadeloupe","Guam","Guatemala","Guernsey","Guinea","Guinea-Bissau","Guyana","Haiti","Honduras","Hong Kong","Hungary","Iceland","India","Indonesia","Iran","Ireland","Isle of Man","Israel","Italy", "Jamaica", "Japan", "Jersey", "Jordan", "Kazakhstan", "Kenya", "Kiribati", "Korea", "Kuwait", "Kyrgyzstan", "Laos", "Latvia", "Lebanon", "Lesotho", "Liberia", "Libya", "Liechtenstein", "Lithuania", "Luxembourg", "Macau", "Macedonia", "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", "Malta", "Marshall Islands", "Martinique", "Mauritania", "Mauritius", "Mayotte Island", "Mexico", "Micronesia", "Moldova", "Monaco", "Mongolia", "Montserrat", "Morocco", "Mozambique", "Myanmar", "Namibia", "Nauru", "Nepal", "Netherlands", "Netherlands Antilles", "New Caledonia", "New Zealand", "Nicaragua", "Niger", "Nigeria", "Niue", "Norfolk Island", "Norway", "Oman", "Pakistan", "Palau", "Panama", "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Pitcairn Island", "Poland", "Portugal", "Puerto Rico", "Qatar", "Reunion Island", "Romania", "Russian Federation", "Rwanda", "Saint Helena", "Saint Lucia", "San Marino", "Saudi Arabia", "Senegal", "Seychelles", "Sierra Leone", "Singapore", "Slovak Republic", "Slovenia", "Solomon Islands", "Somalia", "South Africa", "South Georgia", "Spain", "Sri Lanka", "Suriname", "Svalbard", "Swaziland", "Sweden", "Switzerland", "Syria", "Taiwan", "Tajikistan", "Tanzania", "Thailand", "Togo", "Tokelau", "Tonga Islands", "Tunisia", "Turkey", "Turkmenistan", "Tuvalu", "Uganda", "Ukraine", "United Kingdom", "Uruguay", "Uzbekistan", "Vanuatu", "Vatican City", "Venezuela", "Vietnam", "Western Sahara", "Western Samoa", "Yemen", "Yugoslavia", "Zambia","Zimbabwe");
for($i=0;$i<count($country);$i++)
{
        if($sel==$country[$i])
                $coun .="<option value='$country[$i]' selected>$country[$i]</option>";
        else
                $coun .="<option value='$country[$i]'>$country[$i]</option>";
}
return $coun;
}
//DROP STATE
function state_drop($sel="")
{
$coun="";
$state = array("Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado", "Connecticut", "Delaware", "District of Columbia", "Florida", "Georgia", "Hawaii", "Idaho", "Illinois", "Indiana", "Iowa", "Kansas", "Kentucky", "Louisiana", "Maine", "Maryland", "Massachusetts", "Michigan", "Minnesota", "Mississippi", "Missouri", "Montana", "Nebraska", "Nevada", "New Jersey", "New Mexico", "New York", "North Carolina", "North Dakota", "Ohio", "Oklahoma", "Oregon", "Pennsylvania", "Rhode Island", "South Carolina", "South Dakota", "Tennessee", "Texas", "Utah", "Vermont", "Virginia", "Washington", "West Virginia", "Wisconsin", "Wyoming", "Others");

for($i=0;$i<count($state);$i++)
{
        if($sel==$state[$i])
                $coun .="<option value='$state[$i]' selected>$state[$i]</option>";
        else
                $coun .="<option value='$state[$i]'>$state[$i]</option>";
}
return $coun;
}

function gender_box($selected)
{
        $a = "";
        $type=array("0"=>"men and women","1"=>"men only","2"=>"women only");
        while(list($k,$v)=each($type))
        {
                $sel="";
                if($selected==$k) $sel="selected";
                $a.="<option value='$k' $sel>$v</option>\n";
        }
        return $a;
}

function sexstyle_box($selected)
{
        $a = "";
        $type=array("1"=>"straight","2"=>"gay/lesbian");
        while(list($k,$v)=each($type))
        {
                $sel="";
                if($selected==$k) $sel="selected";
                $a.="<option value='$k' $sel>$v</option>\n";
        }
        return $a;
}


function age_box($selected)
{
        $a = "";
        $type=array("0"=>"ages 18-any","1"=>"ages 18-25","2"=>"ages 25-35","3"=>"ages 35 up");
        while(list($k,$v)=each($type))
        {
                $sel="";
                if($selected==$k) $sel="selected";
                $a.="<option value='$k' $sel>$v</option>\n";
        }
        return $a;
}
//REDIRECT PAGE USING JAVASCRIPT
function redirect($link)
{
        echo "<script language=Javascript>
                document.location.href='$link';
                </script>";
}
function time_range($uname)
{
        global $config,$conn;
        
        $present=time();
        $sql="select logintime from hotusers where uname='$uname'";
        $rs=$conn->execute($sql);
        $interval=$present-$rs->fields[logintime];
        if($interval>0){
        $day=$interval/(60*60*24);
        if($day>=1) {$range="<b>".floor($day)."</b> days ";$interval=$interval-(60*60*24*floor($day));}
        if($interval>0)
        {
        $hour=$interval/(60*60);
        if($hour>=1) {$range=$range."  <b>".floor($hour)."</b> hours ";$interval=$interval-(60*60*floor($hour));}
        }
        if($interval>0)
        {
        $min=$interval/(60);
        if($min>=1) {$range=$range."  <b>".floor($min)."</b> minutes ";$interval=$interval-(60*floor($min));}
        }
        if($range!="")$range=$range." ago"; else $range="just now";
        return $range;
        }
}
function email_verify_code($email)
{
        global $conn;

        $ran=date(time());
        $vcode=$ran.rand(99999,999999999);
        $sql="update verifications set
                email='$email',
                vID='$vcode'
                where uname='$_SESSION[USERNAME]'";
        $conn->execute($sql);
        //VERIFY MAIL
        $sql="select fname from hotusers where uname='$_SESSION[USERNAME]'";
        $res=$conn->execute($sql);
        STemplate::assign('fname',$rs->fields[fname]);
        STemplate::assign('vcode',$vcode);
        $to=$email;
        $subject=get_email_subject(2);
        $mailbody=STemplate::fetch('emails/verify_email.tpl');
        $additional="from: Admin<$config[admin_email]>";
        mail($to,$subject,$mailbody,$additional);
}
function notify_email_text($uname)
{
        global $conn;
        $fromuser=$_SESSION[USERNAME];
        $sql="select fname,email from hotusers where uname='$uname'";
        $rs=$conn->execute($sql);
        STemplate::assign('fname',$rs->fields[fname]);
        $to=$rs->fields[email];
        $sql="select id from hotusers where uname='$fromuser'";
        $res=$conn->execute($sql);
        STemplate::assign('profile',$res->getarray());
        $name="Someone ckicked yes";
        $subject=get_email_subject(3);
        $mailbody=STemplate::fetch('emails/notify_email_text.tpl');
        mailing($to,$name,$config[admin_email],$subject,$mailbody);
}
function notify_email_html($uname)
{
        global $conn,$config;
        $fromuser=$_SESSION[USERNAME];
        $sql="select fname,email from hotusers where uname='$uname'";
        $rs=$conn->execute($sql);
        STemplate::assign('fname',$rs->fields[fname]);
        $to=$rs->fields[email];
        $sql="select id,eimg,introduce from hotusers where uname='$fromuser'";
        $res=$conn->execute($sql);
        STemplate::assign('profile',$res->getarray());
        $name="One ckicked yes";
        $subject=get_email_subject(3);
        $mailbody=STemplate::fetch('emails/notify_email_html.tpl');
        mailing($to,$name,$config[admin_email],$subject,$mailbody);
}
function group_email_html_text($uname,$ishtm)
{
        global $conn,$config;
        $sql="select fname,email from hotusers where uname='$uname'";
        $rs=$conn->execute($sql);
        STemplate::assign('fname',$rs->fields[fname]);
        $to=$rs->fields[email];
        
        if($ishtm=="no")
        {$sql="SELECT distinct h.id,h.uname
        FROM hotusers as h,yes_notify as y
        WHERE h.uname=y.fromuser and h.status='yes' and h. ismailverified='yes' and y.status='no' and y.touser='$uname'";}
        if($ishtm=="yes")
        {$sql="SELECT distinct h.id,h.eimg,h.introduce,h.uname
        FROM hotusers as h,yes_notify as y
        WHERE h.uname=y.fromuser and h.status='yes' and h. ismailverified='yes' and y.status='no' and y.touser='$uname'";}
        $res=$conn->execute($sql);
        $temp=$res;

        STemplate::assign('profile',$res->getarray());
        $name="One ckicked yes";
        $subject=get_email_subject(10);
        if($ishtm=="no") $mailbody=STemplate::fetch('emails/notify_email_text.tpl');
        if($ishtm=="yes") $mailbody=STemplate::fetch('emails/notify_email_html.tpl');
        mailing($to,$name,$config[admin_email],$subject,$mailbody);
        while(!$temp->EOF)
        {
        $sql="update yes_notify set status='yes' where fromuser='".$temp->fields[uname]."' and touser='$uname'";
        $conn->execute($sql);
        $temp->movenext();
        }
}
//MAIL FUNCTIION
function mailing($to,$name,$from,$subj,$body,$bcc="") {
global $SERVER_NAME;
$subj=nl2br($subj);
$body=nl2br($body);
$recipient = $to;
if($bcc!="") $headers = "Bcc: " . $bcc."\n";
$headers .= "From: " . "$name" . "<" . "$from" . ">\n";
$headers .= "X-Sender: <" . "$to" . ">\n";
$headers .= "Return-Path: <" . "$to" . ">\n";
$headers .= "Error-To: <" . "$to" . ">\n";
$headers .= "Content-Type: text/html\n";
mail("$recipient","$subj","$body","$headers");
}
function country_list($sel="")
{
$coun="";
$country=array("anywhere","United States","Afghanistan","Albania","Algeria","American Samoa","Andorra","Angola","Anguilla","Antartica","Antigua and Barbuda","Argentina","Armenia","Aruba","Ascension Island","Australia","Austria","Azerbaijan","Bahamas","Bahrain","Bangladesh","Barbados","Belarus","Belgium","Belize","Benin","Bermuda","Bhutan","Bolivia","Botswana","Bouvet Island","Brazil","Brunei Darussalam","Bulgaria","Burkina Faso","Burundi","Cambodia","Cameroon","Canada","Cape Verde Islands","Cayman Islands","Chad","Chile","China","Christmas Island","Colombia","Comoros","Cook Islands","Costa Rica","Cote d Ivoire","Croatia/Hrvatska","Cyprus","Czech Republic","Denmark","Djibouti","Dominica","Dominican Republic","East Timor","Ecuador","Egypt","El Salvador","Equatorial Guinea","Eritrea","Estonia","Ethiopia","Falkland Islands","Faroe Islands","Fiji","Finland","France","French Guiana","French Polynesia","Gabon","Gambia","Georgia","Germany","Ghana","Gibraltar","Greece","Greenland","Grenada","Guadeloupe","Guam","Guatemala","Guernsey","Guinea","Guinea-Bissau","Guyana","Haiti","Honduras","Hong Kong","Hungary","Iceland","India","Indonesia","Iran","Ireland","Isle of Man","Israel","Italy", "Jamaica", "Japan", "Jersey", "Jordan", "Kazakhstan", "Kenya", "Kiribati", "Korea", "Kuwait", "Kyrgyzstan", "Laos", "Latvia", "Lebanon", "Lesotho", "Liberia", "Libya", "Liechtenstein", "Lithuania", "Luxembourg", "Macau", "Macedonia", "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", "Malta", "Marshall Islands", "Martinique", "Mauritania", "Mauritius", "Mayotte Island", "Mexico", "Micronesia", "Moldova", "Monaco", "Mongolia", "Montserrat", "Morocco", "Mozambique", "Myanmar", "Namibia", "Nauru", "Nepal", "Netherlands", "Netherlands Antilles", "New Caledonia", "New Zealand", "Nicaragua", "Niger", "Nigeria", "Niue", "Norfolk Island", "Norway", "Oman", "Pakistan", "Palau", "Panama", "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Pitcairn Island", "Poland", "Portugal", "Puerto Rico", "Qatar", "Reunion Island", "Romania", "Russian Federation", "Rwanda", "Saint Helena", "Saint Lucia", "San Marino", "Saudi Arabia", "Senegal", "Seychelles", "Sierra Leone", "Singapore", "Slovak Republic", "Slovenia", "Solomon Islands", "Somalia", "South Africa", "South Georgia", "Spain", "Sri Lanka", "Suriname", "Svalbard", "Swaziland", "Sweden", "Switzerland", "Syria", "Taiwan", "Tajikistan", "Tanzania", "Thailand", "Togo", "Tokelau", "Tonga Islands", "Tunisia", "Turkey", "Turkmenistan", "Tuvalu", "Uganda", "Ukraine", "United Kingdom", "Uruguay", "Uzbekistan", "Vanuatu", "Vatican City", "Venezuela", "Vietnam", "Western Sahara", "Western Samoa", "Yemen", "Yugoslavia", "Zambia","Zimbabwe");
for($i=0;$i<count($country);$i++)
{
        if($sel==$country[$i])
                $coun .="<option value='$country[$i]' selected>$country[$i]</option>";
        else
                $coun .="<option value='$country[$i]'>$country[$i]</option>";
}
return $coun;
}
function isMailVerified()
{
        global $conn;

        $sql="select h.ismailverified,v.email,v.vID from hotusers as h,verifications as v where h.uname=v.uname and h.uname='$_SESSION[USERNAME]'";
        $rs=$conn->execute($sql);
        if($rs->fields[ismailverified]=="no" && $rs->fields[email]!="" && $rs->fields[vID]!="") $isVerified="NO";
        return $isVerified;
}
function assign_db_toSESSION()
{
        global $config,$conn;
        
        $sql="select ismailverified,status,utype,privilege from hotusers where uname='$_SESSION[USERNAME]'";
        $res=$conn->execute($sql);
        $_SESSION[EMAILVERIFIED]=$res->fields['ismailverified'];
        $_SESSION[ACCSTATUS]=$res->fields['status'];
        $_SESSION[USERTYPE]=$res->fields['utype'];
        $_SESSION[MODSTATUS]=$res->fields['privilege'];
}
function insert_meet_keyword($a)
{
        global $conn;
        
        $sql="select * from keywords where uname='$a[uname]'";
        $rs=$conn->execute($sql);
        $temp=$rs->fields[keywords];
        $list=explode(",",$temp);
        return $list;
}
function insert_user_info($a)
{
        global $conn;

        $sql="select id,eimg,introduce,fname,country,state,utype from hotusers where uname='$a[uname]'";
        $rs=$conn->execute($sql);
        return $rs->getarray();
}
function insert_meet_link_gen($a)
{
        $eid = substr(base64_encode(md5($a[ID])),8,17);
        return $eid;
}
function insert_yes_also($a)
{
        global $conn;

        $sql="SELECT status FROM meet WHERE fromuser='$a[uname]' and touser='$_SESSION[USERNAME]'";
        $rsx=$conn->execute($sql);
        return $rsx->fields[status];
}
function insert_double_match_link($a)
{
        global $conn,$config;
        
        $type="";
        $eid=$a[UID];
        $key=substr(base64_encode(md5($eid)),8,17);
        $sql="SELECT utype from hotusers WHERE uname='$_SESSION[USERNAME]'";
        $rs=$conn->execute($sql);
        if($rs->fields[utype]!="BASIC" || $a[acctype]!="BASIC") $type="FREE"; else $type="";
        $matchlink="
        <table class='reg2table2' width='100%'>

        <tr><td>
        <table class='dmatch_link_table' width='100%'>
        <tr><td align='center'>
        <a class='dtab' href='$config[baseurl]/meetme/send_note.php?eid=$eid&key=$key'>Send note</a>
        <br><span class='linkfree'>FREE</span>
        </td></tr>
        </table>
        </td></tr>

        <tr><td>
        <table class='dmatch_link_table' width='100%'>
        <tr><td align='center'>
        <a class='dtab' href='$config[baseurl]/meetme/send_email.php?eid=$eid&key=$key'>Send email</a>
        <br><span class='linkfree'>$type</span>
        </td></tr>
        </table>
        </td></tr>

        <tr><td>
        <table class='dmatch_link_table' width='100%'>
        <tr><td align='center'>
        <a class='dtab' href='$config[baseurl]/meetme/send_flower.php'>Send flower</a>
        </td></tr>
        </table>
        </td></tr>
        </table>";
        
        return $matchlink;
        
}
function insert_starmember_expiration($a)
{
        global $conn;
        
        $sql="select paypal_end_date from hotusers where uname='$a[uname]'";
        $rs=$conn->execute($sql);
        $dd = explode("-",$rs->fields[paypal_end_date]);
        $endday=mktime(0,0,0,$dd[1],$dd[2],$dd[0]);
        $today=strtotime("now");
        $diff=$endday-$today;
        $limit=$diff/(3600*24);

        if($rs->fields[paypal_end_date]!="0000-00-00")return $limit;
        else return "?";
}
function insert_assign_star($a)
{
        global $config;

        $star="";
        if ($a[utype]=="H_MEM")
        $star="<img src='$config[baseurl]/images/star_b.gif'><br>";
        if ($a[utype]=="I_MEM")
        {
        $star="<img src='$config[baseurl]/images/star_b.gif'>
        <img src='$config[baseurl]/images/star_b.gif'>
        <img src='$config[baseurl]/images/star_b.gif'><br>";
        }
        if ($a[utype]=="J_MEM")
        {
        $star="<img src='$config[baseurl]/images/star_b.gif'>
        <img src='$config[baseurl]/images/star_b.gif'>
        <img src='$config[baseurl]/images/star_b.gif'>
        <img src='$config[baseurl]/images/star_b.gif'>
        <img src='$config[baseurl]/images/star_b.gif'><br>";
        }

        return $star;

}
function assign_bcc_email($table)
{
        global $conn;
        $sql="select email from $table";
        $rs=$conn->execute($sql);
        $list = array();
        while(!$rs->EOF)
        {
                $list[]= $rs->fields[email];
                $rs->movenext();
        }
        $bcc=implode(",",$list);
        return $bcc;
}
function banner_placement($sel="")
{
        $ban="";
        $place=array("0"=>"-- Select One --","headtop"=>"Header Top", "headbottom"=>"Header Bottom", "foottop"=>"Footer Top", "footbottom"=>"Footer Bottom", "leftside_1"=>"Left Side Top", "leftside_2"=>"Left Side Bottom", "rightside_1"=>"Right Side Top", "rightside_2"=>"Right Side Bottom");
        while(list($k,$v)=each($place))
        {
                if($sel==$k)
                        $ban .="<option value='$k' selected>$v</option>";
                else
                        $ban .="<option value='$k'>$v</option>";

        }
        return $ban;
}
function insert_load_banner($ban)
{
        global $conn;

        $sql="select * from banners where place='$ban[place]' order by rand() limit 1";
        $rs=$conn->execute($sql);
        return $rs->getarray();
}
//SET THE NEW DIMENSION OF AN IMAGE
function set_display_dimension($photopath, $maxwidth)
{
        $imginfo = getimagesize($photopath);
        $imagewidth = $imginfo[0];
        $imageheight = $imginfo[1];
        $shrinkage = 1;

        if ($imagewidth > $maxwidth)
        {
                $shrinkage = $maxwidth/$imagewidth;
        }
        if($shrinkage !=1)
        {
                $dest_height = $shrinkage * $imageheight;
                $dest_width = $maxwidth;
        }
        else
        {
                $dest_height=$imageheight;
                $dest_width=$imagewidth;
        }
        $dm = array();
        $dm['width']= $dest_width;
        $dm['height']= $dest_height;

        return $dm;
}
?>
