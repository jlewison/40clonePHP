<?
function left()
{

?> 
<table width="100" border="0" cellpadding="0" cellspacing="0" bordercolor="#000000" dwcopytype="CopyTableRow">
  <tr> 
    <td height="25"> <div align="center"><FONT color=#000000><strong><img src="images/member.gif" width="164" height="25"></strong></FONT></div></td>
  </tr>
  <tr> 
    <td height="25"><div align="center"> 
        <table width="144" border="0" cellspacing="0" cellpadding="4">
          <tr> 
            <td width="128"><a href="add_soft.php" class="sidelink">Add Your Software</a> 
            </td>
          </tr>
          <tr> 
            <td><a href="editmember.php" class="sidelink">Manage Your Profile</a></td>
          </tr>
          <tr> 
            <td><a href="viewstat.php" class="sidelink">Software</a> <a href="viewstat.php" class="sidelink">Stats 
              </a></td>
          </tr>
          <tr> 
            <td><a href="member_fb.php" class="sidelink">Contact Us</a></td>
          </tr>
          <tr> 
            <td><a href="logout.php" class="sidelink">&nbsp;Logout</a></td>
          </tr>
        </table>
      </div></td>
  </tr>
</table>
<br>
<br>
<?
}// end left
?>
