<?php

	$lang['page_title']	= 'Policy';

?>