<?php include('restrict.php'); include('../settings.php'); require_once('../Connections/apound.php'); ?>
<?php
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = (!get_magic_quotes_gpc()) ? addslashes($theValue) : $theValue;

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form1")) {
  $updateSQL = sprintf("UPDATE adsense SET adsensecode=%s WHERE adsenseid=%s",
                       GetSQLValueString($_POST['adsensecode'], "text"),
                       GetSQLValueString($_POST['adsenseid'], "int"));

  mysql_select_db($database_apound, $apound);
  $Result1 = mysql_query($updateSQL, $apound) or die(mysql_error());

  $updateGoTo = "adsense.php?upd=Y";
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $updateGoTo));
}

mysql_select_db($database_apound, $apound);
$query_GGaD = "SELECT * FROM adsense";
$GGaD = mysql_query($query_GGaD, $apound) or die(mysql_error());
$row_GGaD = mysql_fetch_assoc($GGaD);
$totalRows_GGaD = mysql_num_rows($GGaD);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Manage Adsense Code</title>
<link href="admin.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.style84 {color: #FF0000}
.style85 {font-size: 12px}
.style86 {color: #009900}
-->
</style>
</head>

<body>
<?php include('header_tpl.php'); ?>
<h2>Manage Google Adsense</h2>
<table width="770"  border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="770" bgcolor="#FFFFFF"><?php $x = getenv("HTTP_HOST").getenv("REQUEST_URI"); echo("<font color=white>$x</font>"); ?></td>
  </tr>
</table>
<table width="770"  border="0" align="center" cellpadding="3" cellspacing="1" bgcolor="#FFFFFF">
  <tr>
    <td width="772" valign="top" bgcolor="#FFFFFF">
    <form method="post" name="form1" action="<?php echo $editFormAction; ?>">
      <?php $upd = $_GET[upd]; if($upd == 'Y') { echo("<div align='center'><font color='red'><b>Update ... DONE</b></font></div>"); } else { } ?>
      <table align="center">
        <tr align="left" valign="baseline">
          <td nowrap class="style82 style67"><strong>Adsense Code</strong></td>
          </tr>
        <tr valign="baseline">
          <td><textarea name="adsensecode" cols="85" rows="20" class="edtab"><?php echo $row_GGaD['adsensecode']; ?></textarea>
          </td>
        </tr>
        <tr valign="baseline">
          <td><input type="submit" class="login-but" value="Update record"></td>
        </tr>
      </table>
      <input type="hidden" name="MM_update" value="form1">
      <input type="hidden" name="adsenseid" value="<?php echo $row_GGaD['adsenseid']; ?>">
    </form>
    <p>&nbsp;</p></td>
  </tr>
</table>
<?php include('footer_tpl.php'); ?>
</body>
</html>
<?php
mysql_free_result($GGaD);
?>
