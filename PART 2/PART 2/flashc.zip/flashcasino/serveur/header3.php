<?
Error_Reporting(E_ALL & ~E_NOTICE);
if ($pus<>""){
setcookie ("par", $pus,time()+60*60*24*30); 
}
$r_login = str_replace('..',"",$r_login);
$r_login = str_replace('.',"",$r_login);
$r_login = str_replace('/',"",$r_login);
$r_login = str_replace('>',"",$r_login);
$r_login = str_replace('<',"",$r_login);

include ("fun.php");

include ("setup.php");

require ("trace_ip.php");


?>








<html lang="en">

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Flash Casino</title>
<meta name="robots" content="all">
<META NAME="copyright" CONTENT="Copyright 2008">
<base >
<link href="fgi/style.css" rel="stylesheet" type="text/css">


</head>
<body>
<table cellpadding="0" cellspacing="0" border="0" width="100%">
	<tr class="top1">

<td>&nbsp;</td>
		<td width="778" align="left"><object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" width="778" height="109" id="logo" align="middle"><param name="movie" value="flash/logo1.swf" /><param name="quality" value="high" /><param name="wmode" value="transparent" /><param name="bgcolor" value="#ffffff" /><embed src="flash/logo1.swf" quality="high" wmode="transparent" bgcolor="#ffffff" width="778" height="109" name="rotator" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /></object></td>
<td>&nbsp;</td>	</tr>
</table>
<table cellpadding="0" cellspacing="0" border="0" width="100%">
	<tr class="top2">
		<td><img src="template/v3/i/b.gif" height="27" width="1" border="0"></td>
		<td class="top2" valign="top" align="center">
			<table cellpadding="0" cellspacing="0" border="0" align="center">
				<tr>
					<td class="top2_menu"><a href="index.php" class="sel" >Home</a>|<a href="promotions.php"  >Promotions</a>|<a href="preview.php"  >Preview</a>|<a href="cashier.php"  >Cashier</a>|<a href="support.php"  >24/7 Support</a>|<a href="fair_gaming.php"  >Fair Gaming</a>|<a href="indexuk.php"><img src="template/v3/i/flag_uk.jpg" border="0" align="absmiddle"></a><a href="index.php"><img src="template/v3/i/flag_ca.jpg" border="0" align="absmiddle"></a><a href="indexes.php"><img src="template/v3/i/flag_sp.jpg" border="0" align="absmiddle"></a><a href="indexit.php"><img src="template/v3/i/flag_it.jpg" border="0" align="absmiddle"></a><a href="indexfr.php"><img src="template/v3/i/flag_fr.jpg" border="0" align="absmiddle"></a><a href="indexde.php"><img src="template/v3/i/flag_de.jpg" border="0" align="absmiddle"></a><a href="indexpt.php"><img src="template/v3/i/flag_pt.jpg" border="0" align="absmiddle"></a><a href="indexgr.php"><img src="template/v3/i/flag_gr.jpg" border="0" align="absmiddle"></a></td>
					<td align="right" valign="bottom"></td>
				</tr>
			</table>
		</td>
	</tr>
</table>




