<?php

$LANG['page_title'] = 'Blog List';
$LANG['tbl_summary'] = 'Table Summary';
$LANG['no_records_found'] = 'No records found';
$LANG['th_subject'] = 'Subject';
$LANG['th_total_comments'] = 'Total comments';
$LANG['th_total_views'] = 'Total Views';
$LANG['th_accept_comments'] = 'Accept comments';
$LANG['th_date_added'] = 'Date Added';
$LANG['th_posted_by'] = 'Posted By';
$LANG['title_seperator'] = ':';
$LANG['part_seperator'] = '|';
$LANG['manage_blog'] = 'Manage Blog';
$LANG['search_for_blog_subject'] = 'Search for blogs';
$LANG['search_subject'] = 'Subject';
$LANG['err_msg_invalid_search_option'] = 'Invalid search';
$LANG['advanced_search'] = 'Advanced Search';
$LANG['search_username'] = 'User Name';
$LANG['date_added_from_day'] = 'Date added';
$LANG['search_date'] = '-';
$LANG['search_month'] = '-';
$LANG['search_year'] = '-';
$LANG['to'] = 'to';
$LANG['search_submit'] = 'Search';
$LANG['invalid_date'] = 'Invalid Date';
$LANG['search'] = 'Search';
?>
