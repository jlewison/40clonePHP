<?php
require_once ('../common/config.inc.php');
$CFG['lang']['include_files'][] = 'admin/includes/languages/%s/manageBlogCategory.php';
$CFG['html']['header'] = 'admin/includes/languages/%s/html_header.php';
$CFG['html']['footer'] = 'admin/includes/languages/%s/html_footer.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['mods']['include_files'][] = 'common/classes/class_ListRecordsHandler.lib.php';
$CFG['mods']['include_files'][] = 'common/classes/class_Image.lib.php';
$CFG['db']['is_use_db'] = true;
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class BlogCategoryFormHandler extends ListRecordsHandler
{
		public $category_details_arr;
		public $category_id;
		public function setIHObject($imObj)
		{
				$this->imageObj = $imObj;
		}
		public function buildConditionQuery($condition = '')
		{
				$this->sql_condition = $condition;
		}
		public function checkSortQuery($field, $sort = 'asc')
		{
				if (!($this->sql_sort))
				{
						$this->sql_sort = $field . ' ' . $sort;
				}
		}
		public function storeImagesTempServer($uploadUrl, $extern)
		{
				@chmod($uploadUrl . '.' . $extern, 0777);
				if ($this->CFG['admin']['blogs']['category_height'] or $this->CFG['admin']['blogs']['category_width'])
				{
						$this->imageObj->resize($this->CFG['admin']['blogs']['category_width'], $this->CFG['admin']['blogs']['category_height'], '-');
						$this->imageObj->output_resized($uploadUrl . '.' . $extern, strtoupper($extern));
				}
				else
				{
						$this->imageObj->output_original($uploadUrl . '.' . $extern, strtoupper($extern));
				}
		}
		public function isValidCategoryId($category_id, $err_tip = '')
		{
				$sql = 'SELECT blog_category_id, blog_category_description' . ', blog_category_name, blog_category_status, date_added' . ' FROM ' . $this->CFG['db']['tbl']['blog_category'] . ' WHERE blog_category_id = ' . $this->dbObj->Param($this->fields_arr[$category_id]);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr[$category_id]));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($this->category_details_arr = $rs->FetchRow())
				{
						return true;
				}
				$this->setCommonErrorMsg($err_tip);
				return false;
		}
		public function chkBlogExists($category_ids)
		{
				$sql = 'SELECT count( g.blog_id ) AS cat_count, blog_category_id' . ' FROM ' . $this->CFG['db']['tbl']['blogs'] . ' AS g' . ' WHERE blog_category_id IN ( ' . $category_ids . ' )' . ' AND status!=\'Deleted\'' . ' GROUP BY blog_category_id';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount()) return true;
				return false;
		}
		public function deleteSelectedCategories()
		{
				$category_ids = $this->fields_arr['category_ids'];
				if ($this->chkBlogExists($category_ids))
				{
						$this->setCommonErrorMsg($this->LANG['blogcategory_err_tip_have_blog']);
						return false;
				}
				$sql = 'DELETE FROM ' . $this->CFG['db']['tbl']['blog_category'] . ' WHERE blog_category_id IN (' . $category_ids . ') ';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return false;
		}
		public function chkCategoryExits($category, $err_tip = '')
		{
				$sql = 'SELECT COUNT(blog_category_id) AS cat_cnt FROM ' . $this->CFG['db']['tbl']['blog_category'] . ' WHERE blog_category_name = ' . $this->dbObj->Param($this->fields_arr[$category]);
				$fields_value_arr[] = $this->fields_arr[$category];
				if ($this->fields_arr['category_id'])
				{
						$sql .= ' AND blog_category_id != ' . $this->dbObj->Param($this->fields_arr['category_id']);
						$fields_value_arr[] = $this->fields_arr['category_id'];
				}
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($fields_value_arr));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = $rs->FetchRow();
				if (!$row['cat_cnt'])
				{
						return false;
				}
				$this->fields_err_tip_arr['category'] = $err_tip;
				$this->setCommonErrorMsg($err_tip);
				return false;
		}
		public function createCategory($category_table)
		{
				if ($this->fields_arr['category_id'])
				{
						$sql = 'UPDATE ' . $category_table . ' SET blog_category_name = ' . $this->dbObj->Param($this->fields_arr['category']) . ', blog_category_description = ' . $this->dbObj->Param($this->fields_arr['category_description']) . ', blog_category_status = ' . $this->dbObj->Param($this->fields_arr['status']) . ' WHERE blog_category_id = ' . $this->dbObj->Param($this->fields_arr['category_id']);
						$fields_value_arr = array($this->fields_arr['category'], $this->fields_arr['category_description'], $this->fields_arr['status'], $this->fields_arr['category_id']);
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, $fields_value_arr);
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
						$this->category_id = $this->fields_arr['category_id'];
						return true;
				}
				else
				{
						$sql = 'INSERT INTO ' . $category_table . ' SET blog_category_name = ' . $this->dbObj->Param($this->fields_arr['category']) . ', blog_category_description = ' . $this->dbObj->Param($this->fields_arr['category_description']) . ', blog_category_status = ' . $this->dbObj->Param($this->fields_arr['status']) . ', date_added = NOW()';
						$fields_value_arr = array($this->fields_arr['category'], $this->fields_arr['category_description'], $this->fields_arr['status']);
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, $fields_value_arr);
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
						$this->category_id = $this->dbObj->Insert_ID();
						return true;
				}
		}
		public function getBlogCount($category_id)
		{
				$sql = 'SELECT COUNT(g.blog_id) AS cat_count' . ' FROM ' . $this->CFG['db']['tbl']['blogs'] . ' AS g' . ' WHERE blog_category_id = ' . $this->dbObj->Param($category_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($category_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = $rs->FetchRow();
				return $row['cat_count'];
		}
		public function showCategories()
		{
				if (!$this->isResultsFound())
				{
?>
<tr>
	<td colspan="6"><?php echo $this->LANG['blogcategory_no_category']; ?></td>
</tr>
<?php
						return;
				}
?>
				<table summary="<?php echo $this->LANG['blogcategory_tbl_summary']; ?>">
					<tr>
						<th><input type="checkbox" class="clsCheckRadio" name="check_all" id="check_all" tabindex="<?php echo $this->getTabIndex(); ?>" onclick="CheckAll(document.selFormCategory.name, document.selFormCategory.check_all.name)"/></th>
						<th><?php echo $this->LANG['category']; ?></th>
						<th><?php echo $this->LANG['blog_count']; ?></th>
						<th><?php echo $this->LANG['status']; ?></th>
						<th><?php echo $this->LANG['date_added']; ?></th>
						<th>&nbsp;</th>
					</tr>
				<?php
				while ($row = $this->fetchResultRecord())
				{
?>
					<tr>
						<td class="clsAlignCenter"><input type="checkbox" class="clsCheckRadio" name="category_ids[]" value="<?php echo $row['blog_category_id']; ?>" tabindex="<?php echo $this->getTabIndex(); ?>" <?php if ((is_array($this->fields_arr['category_ids'])) && (in_array($row['blog_category_id'], $this->fields_arr['category_ids']))) echo "CHECKED"; ?>/></td>
						<td>
							<p id="categoryName"><?php echo $row['blog_category_name']; ?></p>
						</td>
						<td><?php echo $this->getBlogCount($row['blog_category_id']); ?></td>
						<td>
							<p><?php echo $row['blog_category_status']; ?></p>
						</td>
						<td>
							<p><?php echo $row['date_added']; ?></p>
						</td>
						<td>
							<p id="edit"><a href="manageBlogCategory.php?category_id=<?php echo $row['blog_category_id']; ?>&start=<?php echo $this->fields_arr['start']; ?>"><?php echo $this->LANG['blogcategory_edit']; ?></a></p>
						</td>
					</tr>
					<?php
				}
?>
				<tr>
					<td colspan="9" class="<?php echo $this->getCSSFormFieldCellClass('delete'); ?>">
						<a href="#" id="dAltMlti"></a>
						<select name="blog_options" id="blog_options" tabindex="<?php echo $this->getTabIndex(); ?>" >
							<option value="Enable"><?php echo $this->LANG['action_enable']; ?></option>
	  						<option value="Disable"><?php echo $this->LANG['action_disable']; ?></option>
	  						<option value="Delete"><?php echo $this->LANG['action_delete']; ?></option>
	  					</select>
						<input type="button" class="clsSubmitButton" name="action_submit" id="action_submit" tabindex="<?php echo $this->getTabIndex(); ?>" value="<?php echo $this->LANG['blogcategory_submit']; ?>" onClick="if(getMultiCheckBoxValue('selFormCategory', 'check_all', '<?php echo $this->LANG['blogcategory_err_tip_select_category']; ?>', 'dAltMlti', -25, -290)){Confirmation('dAltMlti', 'selMsgConfirm', 'msgConfirmform', Array('category_ids', 'action', 'confirmMessage'), Array(multiCheckValue, document.selFormCategory.blog_options.value, '<?php echo $this->LANG['blogcategory_confirm_message']; ?>'), Array('value', 'value', 'innerHTML'), -25, -290);}" />
					</td>
				</tr>
			</table>
			<?php
		}
		public function chkFileNmaeIsNotEmpty($field_name, $err_tip = '')
		{
				if (!$_FILES[$field_name]['name'])
				{
						$this->setFormFieldErrorTip($field_name, $err_tip);
						return false;
				}
				return true;
		}
		public function chkValidFileType($field_name, $err_tip = '')
		{
				$extern = strtolower(substr($_FILES[$field_name]['name'], strrpos($_FILES[$field_name]['name'], '.') + 1));
				if (!in_array($extern, $this->CFG['admin']['blogs']['category_image_format_arr']))
				{
						$this->fields_err_tip_arr[$field_name] = $err_tip;
						return false;
				}
				return true;
		}
		public function chkValideFileSize($field_name, $err_tip = '')
		{
				$max_size = $this->CFG['admin']['blogs']['category_image_max_size'] * 1024;
				if ($_FILES[$field_name]['size'] > $max_size)
				{
						$this->fields_err_tip_arr[$field_name] = $err_tip;
						return false;
				}
				return true;
		}
		public function chkErrorInFile($field_name, $err_tip = '')
		{
				if ($_FILES[$field_name]['error'])
				{
						$this->fields_err_tip_arr[$field_name] = $err_tip;
						return false;
				}
				return true;
		}
		public function resetFieldsArray()
		{
				$this->setFormField('category', '');
				$this->setFormField('category_image', '');
				$this->setFormField('category_id', '');
				$this->setFormField('category_description', '');
				$this->setFormField('category_image_ext', '');
				$this->setFormField('status', 'Yes');
				$this->setFormField('category_ids', array());
				$this->setFormField('action', '');
		}
		public function chkIsEditMode()
		{
				if ($this->fields_arr['category_id']) return true;
				return false;
		}
		public function changeStatus($status)
		{
				$category_ids = $this->fields_arr['category_ids'];
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['blog_category'] . ' SET' . ' blog_category_status=' . $this->dbObj->Param('blog_category_status') . ' WHERE blog_category_id IN(' . $category_ids . ')';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($status));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return true;
		}
}
$category = new BlogCategoryFormHandler();
$category->setPageBlockNames(array('msg_form_error', 'msg_form_success_edit', 'msg_form_success', 'msg_cannot_create', 'form_create_category', 'form_show_category', 'page_nav', 'form_confirm'));
$category->setCSSAlternativeRowClasses($CFG['data_tbl']['css_alternative_row_classes']);
$category->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$category->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$category->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$category->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$category->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$category->setDBObject($db);
$category->setCfgLangGlobal($CFG, $LANG);
$category->setAllPageBlocksHide();
$category->resetFieldsArray();
$category->setFormField('numpg', 0);
$category->setFormField('start', 0);
$category->setFormField('prev_numpg', 0);
$condition = '';
$category->numpg = $CFG['data_tbl']['numpg'];
$category->setFormField('start', 0);
$category->setFormField('numpg', $CFG['data_tbl']['numpg']);
$category->setMinRecordSelectLimit($CFG['data_tbl']['min_record_select_limit']);
$category->setMaxRecordSelectLimit($CFG['data_tbl']['max_record_select_limit']);
$category->setNumPerPageListArr($CFG['data_tbl']['numperpage_list_arr']);
$category->setTableNames(array());
$category->setReturnColumns(array());
$category->sanitizeFormInputs($_REQUEST);
if ($category->isFormGETed($_GET, 'category_id'))
{
		$category->chkIsNotEmpty('category_id', $LANG['blogcategory_err_tip_compulsory']) and $category->chkIsNumeric('category_id', $LANG['blogcategory_err_tip_invalid_category_id']) and $category->isValidCategoryId('category_id', $LANG['blogcategory_err_tip_invalid_category_id']);
		$category->getFormField('start') and $category->chkIsNumeric('start', $LANG['blogcategory_err_tip_compulsory']);
		if ($category->isValidFormInputs())
		{
				$category->setAllPageBlocksHide();
				$category->setFormField('category_id', $category->category_details_arr['blog_category_id']);
				$category->setFormField('category', stripslashes($category->category_details_arr['blog_category_name']));
				$category->setFormField('status', $category->category_details_arr['blog_category_status']);
		}
		else
		{
				$category->setAllPageBlocksHide();
				$category->setFormField('start', 0);
				$category->setPageBlockShow('msg_form_error');
		}
}
if ($category->isFormPOSTed($_POST, 'confirm_action'))
{
		$category->chkIsNotEmpty('category_ids', $LANG['blogcategory_err_tip_compulsory']) or $category->setCommonErrorMsg($LANG['blogcategory_err_tip_select_category']);
		if ($category->isValidFormInputs())
		{
				switch ($category->getFormField('action'))
				{
						case 'Delete':
								$category->deleteSelectedCategories();
								break;
						case 'Enable':
								$LANG['blogcategory_success_message'] = $LANG['success_enable_msg'];
								$category->changeStatus('Yes');
								break;
						case 'Disable':
								$LANG['blogcategory_success_message'] = $LANG['success_disable_msg'];
								$category->changeStatus('No');
								break;
				}
		}
		$category->setAllPageBlocksHide();
		if ($category->isValidFormInputs())
		{
				$category->setPageBlockShow('msg_form_success');
				$category->resetFieldsArray();
		}
		else
		{
				$category->setPageBlockShow('msg_form_error');
		}
}
if ($category->isFormPOSTed($_POST, 'category_submit'))
{
		$category->chkIsNotEmpty('category', $LANG['blogcategory_err_tip_compulsory']) and $category->chkCategoryExits('category', $LANG['blogcategory_err_tip_alreay_exists']);
		$category->chkIsNotEmpty('status', $LANG['blogcategory_err_tip_compulsory']);
		$category->getFormField('category_id') and $category->chkIsNotEmpty('category_id', $LANG['blogcategory_err_tip_compulsory']) and $category->chkIsNumeric('category_id', $LANG['blogcategory_err_tip_invalid_category_id']) and $category->isValidCategoryId('category_id', $LANG['blogcategory_err_tip_invalid_category_id']);
		$category->isValidFormInputs() and $category->createCategory($CFG['db']['tbl']['blog_category']);
		if ($category->isValidFormInputs())
		{
				$category->setPageBlockShow('msg_form_success_edit');
				$category->resetFieldsArray();
		}
		else
		{
				$category->setAllPageBlocksHide();
				$category->setPageBlockShow('msg_form_error');
				$category->setFormField('category_id', $category->category_details_arr['blog_category_id']);
		}
}
else
		if ($category->isFormPOSTed($_POST, 'category_cancel'))
		{
				$category->resetFieldsArray();
		}
$category->setTableNames(array($CFG['db']['tbl']['blog_category'] . ' AS gc'));
$category->setReturnColumns(array('gc.blog_category_id', 'gc.blog_category_description', 'gc.blog_category_name', 'gc.blog_category_status', 'DATE_FORMAT(gc.date_added, \'' . $CFG['format']['date'] . '\') as date_added'));
$condition = '';
$category->buildSelectQuery();
$category->buildConditionQuery($condition);
$category->buildSortQuery();
$category->checkSortQuery('gc.blog_category_name', 'asc');
$category->buildQuery();
$category->executeQuery();
if ($category->isResultsFound())
{
		$category->setPageBlockShow('page_nav');
}
$category->setPageBlockShow('form_create_category');
$category->setPageBlockShow('form_show_category');




?>
<script language="javascript">
	var block_arr= new Array('selMsgConfirm');
	var replace_url = '<?php echo $CFG['site']['url']; ?>login.php';
</script>
<div id="selBlogCategory" class="clsBlogCategory">
	<h2><span><?php echo $LANG['blogcategory_title']; ?></span></h2>
	<div id="selMsgConfirm" class="clsPopupConfirmation" style="display:none;position:absolute;">
		<p id="confirmMessage"></p>
		<form name="msgConfirmform" id="msgConfirmform" method="post" action="<?php echo URL($_SERVER['PHP_SELF']); ?>">
			<table summary="<?php echo $LANG['blogcategory_confirm_tbl_summary']; ?>">
				<tr>
					<td>
						<input type="submit" class="clsSubmitButton" name="confirm_action" id="confirm_action" tabindex="<?php echo $category->getTabIndex(); ?>" value="<?php echo $LANG['yes']; ?>" />&nbsp;
						<input type="button" class="clsCancelButton" name="cancel" id="cancel" tabindex="<?php echo $category->getTabIndex(); ?>" value="<?php echo $LANG['no']; ?>"  onClick="return hideAllBlocks();" />
						<input type="hidden" name="category_ids" id="category_ids" />
						<input type="hidden" name="action" id="action" />
						<?php $category->populateHidden(array('start')); ?>
					</td>
				</tr>
			</table>
		</form>
	</div>
	<div class="clsLeftNavigation" id="selLeftNavigation">
<?php
if ($category->isShowPageBlock('msg_form_error'))
{
?>
		<div id="selMsgError">
			 <p><?php echo $LANG['msg_error_sorry']; ?> <?php echo $category->getCommonErrorMsg(); ?></p>
		</div>
<?php
}
if ($category->isShowPageBlock('msg_form_success'))
{
?>
		<div id="selMsgSuccess">
			<p><?php echo $LANG['blogcategory_success_message']; ?></p>
		</div>
<?php
}
if ($category->isShowPageBlock('msg_form_success_edit'))
{
?>
		<div id="selMsgSuccess">
			<p><?php echo $LANG['blogcategory_success_edit_message']; ?></p>
		</div>
<?php
}
if ($category->isShowPageBlock('form_create_category'))
{
?>
	<div id="selCreateCategory">
		<form name="selCreateCategory" id="selCreateCategory" enctype="multipart/form-data" method="post" action="<?php echo URL($_SERVER['PHP_SELF']); ?>" autocomplete="off">
		<table border="0" summary="<?php echo $LANG['blogcategory_create_tbl_summary']; ?>">
		   	<tr>
				<td class="<?php echo $category->getCSSFormLabelCellClass('category'); ?>"><label for="category"><?php echo $LANG['blogcategory_blogcategory_name']; ?></label></td>
				<td class="<?php echo $category->getCSSFormFieldCellClass('category'); ?>"><?php echo $category->getFormFieldErrorTip('category'); ?>
					<input type="text" class="clsTextBox" name="category" id="category" value="<?php echo $category->getFormField('category'); ?>" tabindex="<?php echo $category->getTabIndex(); ?>" />
				</td>
			</tr>
			<tr>
				<td class="<?php echo $category->getCSSFormLabelCellClass('status'); ?>"><label for="status_yes"><?php echo $LANG['blogcategory_blogcategory_status']; ?></label></td>
				<td class="<?php echo $category->getCSSFormFieldCellClass('status'); ?>">
					<input type="radio" class="clsCheckRadio" name="status" id="status_yes" value="Yes" <?php if ($category->getFormField('status') == 'Yes') echo 'CHECKED'; ?> tabindex="<?php echo $category->getTabIndex(); ?>" />&nbsp;<label for="status_yes"><?php echo $LANG['blogcategory_status_yes']; ?></label>
					&nbsp;&nbsp;
					<input type="radio" class="clsCheckRadio" name="status" id="status_no" value="No" <?php if ($category->getFormField('status') == 'No') echo 'CHECKED'; ?> tabindex="<?php echo $category->getTabIndex(); ?>" />&nbsp;<label for="status_no"><?php echo $LANG['blogcategory_status_no']; ?></label>
				</td>
			</tr>
			<tr>
				<td colspan="2" class="<?php echo $category->getCSSFormFieldCellClass('category_submit'); ?>">
<?php
		if ($category->chkIsEditMode())
		{
?>
					<input type="submit" class="clsSubmitButton" name="category_submit" id="category_submit" tabindex="<?php echo $category->getTabIndex(); ?>" value="<?php echo $LANG['blogcategory_update_submit']; ?>" />
					<input type="submit" class="clsSubmitButton" name="category_cancel" id="category_cancel" tabindex="<?php echo $category->getTabIndex(); ?>" value="<?php echo $LANG['blogcategory_cancel_submit']; ?>" />
<?php
		}
		else
		{
?>
					<input type="submit" class="clsSubmitButton" name="category_submit" id="category_submit" tabindex="<?php echo $category->getTabIndex(); ?>" value="<?php echo $LANG['blogcategory_add_submit']; ?>" />
<?php
		}
?>
				</td>
			</tr>
		</table>
		<input type="hidden" name="category_id" value="<?php echo $category->getFormField('category_id'); ?>" />
		<input type="hidden" name="start" value="<?php echo $category->getFormField('start'); ?>" />
		</form>
	</div>
<?php
}
?>
<form name="selFormCategory" id="selFormCategory" method="post" action="<?php echo URL($_SERVER['PHP_SELF']); ?>">
<?php
if ($category->isShowPageBlock('page_nav') && $CFG['admin']['navigation']['top'])
{
		$category->populatePageLinksPOST($category->getFormField('start'), 'selFormCategory');
}
if ($category->isShowPageBlock('form_show_category'))
{
		$category->populateHidden(array('start'));
?>
		<div id="selShowCategories">
			<?php $category->showCategories(); ?>
		</div>
<?php
}
if ($category->isShowPageBlock('page_nav') && $CFG['admin']['navigation']['bottom'])
{
		$category->populatePageLinksPOST($category->getFormField('start'), 'selFormCategory');
}
?>
	</form>
	</div>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>