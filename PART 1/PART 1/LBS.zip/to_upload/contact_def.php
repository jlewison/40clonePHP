<div id="Layer1" style="position:absolute; left:0px; top:0px; width:100%; height:695px; z-index:1; background-color: #FFFFFF; layer-background-color: #FFFFFF; border: 1px none #000000;">

  <table width="100%"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td height="600" valign="top" background="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/bg_b.gif" bgcolor="#FFFFFF">

<?php include("template/$lbdtemplate/main_contact_def.php"); ?>
		
	  </td>
    </tr>
  </table>
</div>
