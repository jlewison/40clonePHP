<?php
class staticPageHandler extends FormHandler
{
		public function getStaticContent($title)
		{
				$sql = 'SELECT * FROM ' . $this->CFG['db']['tbl']['static_pages'] . ' WHERE page_title = ' . $this->dbObj->Param($title) . ' AND page_status=\'Yes\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($title));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$static_details = array('page_display_title' => '', 'page_content' => 'Add content from admin/manageStaticPages.php');
				if ($rs->PO_RecordCount())
				{
						$row = $rs->FetchRow();
						if (isset($row['page_display_title'])) $static_details['page_display_title'] = $row['page_display_title'];
						if (isset($row['page_content'])) $static_details['page_content'] = html_entity_decode($row['page_content']);
				}
				return $static_details;
		}
}

$static_page = new staticPageHandler();
$static_page->setDBObject($db);
$static_page->setCfgLangGlobal($CFG, $LANG);
$static_page->setFormField('pg', '');
$static_page->sanitizeFormInputs($_REQUEST);
$title = $static_page->getFormField('pg');
$staticPages = array('faq', 'privacy', 'terms');
$title = (in_array($title, $staticPages)) ? $title : 'terms';
?>
<div id="inner_container">
	<?php $static_details = $static_page->getStaticContent($title); ?>
	<?php
if ($static_details['page_display_title'])
{
		$topDivHeader = 'header';
?>
	<h2><?php echo $static_details['page_display_title']; ?></h2>
	<?php
}
if ($static_details['page_content'])
{
?>
		<?php echo nl2br($static_details['page_content']); ?>
	<?php
}
?>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>
