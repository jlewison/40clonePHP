<?php //00461
// Copyright Notice
// Web Site URL:  http://www.zeeways.com
// Script Owner eMail: mail@zeeways.com
// Date: April, 2007
// Script Name: Zeeways Auction Website PHP Script
// Copyright Details: This script is not free.  Do not Remove this Copy Right notice.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the site administrator.');exit(199);
?>
4+oV5Etgm2ekC3aD8rvL2Lg1NvcbV3P4K1d01f+ihek6s0ZBRugrfIxWi9dR0+KGAtq3ocQJp/Iw
MKlP/DJrd1i69bRVuvPhUm4NAVcdNPlRqXkcxpWs6SHcfTPcU4c+3yhHa9rNIvSmjOTbmEONandR
mEdcvvSIof7dhgM9+yZBK9bfNCCo3TUhAL5ll/0CuaaevLN1sxTT9yKlITJj5hosBZj1qx6ZCjLw
BedLwmVRrAOm5Wz2Qr2sbgOq34npzoskINwscd0HWnHa8v5zHENFmP6+Ksms6e5v/x+7T/Y92jyN
zosB29aVXawzI0haBjhqYngxicskHKU3wITvUcrLu7xxir1SzWrqANF+0tZiXBfndjXehWB03+Cz
NZ8793FM9+6TOi0JeoG92g+AmD6P3SZRQtkW+ggBl78sOd+YlAeHf2ax0q+HPixstg+eAy/17y2Y
K04umBQlDF5MOJM8x9eIPpxOesbFqvt5WwHOX7j0nlRUpGQS0bci2JqXCPppjnRu4yQ0cghGtc6D
WzcCzMDBDR9t1c6eC46PfSDt0r487WG+qXTDk34V5hKP8OpUN3idUST4KWHb2nKRHcr7mn5Fs0oQ
SfV6hZc4Pax2O6j/S0V3pJTMutcAl+xzkqxpEtvf3I++asZCSZcRSupwiO4UvHFj7eyrzZg4DXVZ
IYmKsXVNWXsyH2E0DI7W5sumj4yL0sQPAuWVop39C+4XDXsxubUFWLzi6DTTWk35qVdm7czImG37
RrZJ8PuQ5o1L53envJ475/xTD5qGzm/nZ8fKmE5rfCTaciDGbHu+B8qqtCq2cMK2T6+hx/M4Ts3t
H7MV+bLzSXBymMtz/HplXL8fztOAOzeKH9ZLvWjZyPZqnX3Cj73ArQvNIdU491evb5WZMn/HQou5
LO2UisdaRANjtdMoo//s8lHaWYYwUbsem+cVO7dmBB34HlAGVRbcSBnxq5go//bHzdlKBO/evAdK
3LiZknL4edFPqLbG7MrrdrUphLxEnnlRvpqJVnpvbHUq5BVvFvY/Exl30SrkZ45FChxmpv8FYJUV
TpMzYayqgpzbC4zn7Iu4wEvHTzhds0JYJ/Ofxypm08hCtlzshmkiOeNJ1DXAOAmum0vVz2x0OAyQ
kaLW4hPfT9WsWQ6Oj1Cx2ZlDWAdWEtxcqOrf8X4K9KNmCqtQVqq5TcUW/mTbARvEJGD5