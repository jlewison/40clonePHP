<?php
$CFG['admin']['mails']['inbox'] = true;
$CFG['admin']['mails']['sent'] = true;
$CFG['admin']['mails']['compose'] = true;
$CFG['admin']['mails']['reply'] = true;
$CFG['admin']['mails']['forward'] = false;
$CFG['admin']['mails']['delete'] = false;
$CFG['admin']['mails']['redirect'] = true;
?>