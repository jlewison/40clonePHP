<?php
require_once ('../common/config.inc.php');
$CFG['lang']['include_files'][] = 'admin/includes/languages/%s/forumsAddTitle.php';
$CFG['html']['header'] = 'admin/includes/languages/%s/html_header.php';
$CFG['html']['footer'] = 'admin/includes/languages/%s/html_footer.php';
$CFG['lang']['include_files'][] = 'common/languages/%s/help.inc.php';
$CFG['lang']['include_files'][] = 'common/configs/config_forums.inc.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['db']['is_use_db'] = true;
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class ForumFormHandler extends FormHandler
{
		public $forum_details_arr;
		public function chkLength($field_name, $err_tip = '')
		{
				$url_len = strlen($this->fields_arr[$field_name]);
				if ($url_len < 3 || $url_len > 20)
				{
						$this->fields_err_tip_arr[$field_name] = $err_tip;
						return false;
				}
				return true;
		}
		public function isValidForumId($forum_table, $forum_id, $err_tip = '')
		{
				$sql = 'SELECT forum_id, forum_title, forum_description, forum_status ' . 'FROM ' . $forum_table . ' ' . 'WHERE forum_id = ' . $this->dbObj->Param($forum_id) . ' ';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($forum_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($this->forum_details_arr = $rs->FetchRow())
				{
						$this->setFormField('forum_title', stripslashes($this->forum_details_arr['forum_title']));
						$this->setFormField('forum_status', $this->forum_details_arr['forum_status']);
						$this->setFormField('forum_description', stripslashes($this->forum_details_arr['forum_description']));
						return true;
				}
				$this->setCommonErrorMsg($err_tip);
				return false;
		}
		public function chkIsNotExists($forum_title, $forum_id, $forum_table, $err_tip = '')
		{
				$sql = 'SELECT COUNT(forum_id) AS count ' . 'FROM ' . $forum_table . ' ' . 'WHERE forum_title = ' . $this->dbObj->Param($forum_title) . ' ';
				$fields_value_arr[] = $forum_title;
				if ($forum_id)
				{
						$sql .= ' AND forum_id != ' . $this->dbObj->Param($forum_id) . ' ';
						$fields_value_arr[] = $forum_id;
				}
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, $fields_value_arr);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = $rs->FetchRow();
				if ($row['count'])
				{
						$this->fields_err_tip_arr['forum_title'] = $err_tip;
						return false;
				}
				return true;
		}
		public function createForumTitle($forum_id)
		{
				if ($forum_id)
				{
						$sql = 'UPDATE ' . $this->CFG['db']['tbl']['forums'] . ' SET ' . 'forum_title = ' . $this->dbObj->Param($this->fields_arr['forum_title']) . ', ' . 'forum_description = ' . $this->dbObj->Param($this->fields_arr['forum_description']) . ', ' . 'forum_status = ' . $this->dbObj->Param($this->fields_arr['forum_status']) . ' ' . 'WHERE forum_id = ' . $this->dbObj->Param($forum_id) . '';
						$fields_value_arr = array($this->fields_arr['forum_title'], $this->fields_arr['forum_description'], $this->fields_arr['forum_status'], $forum_id);
				}
				else
				{
						$sql = 'INSERT INTO ' . $this->CFG['db']['tbl']['forums'] . ' SET ' . 'forum_title = ' . $this->dbObj->Param($this->fields_arr['forum_title']) . ', ' . 'forum_description = ' . $this->dbObj->Param($this->fields_arr['forum_description']) . ', ' . 'forum_status = ' . $this->dbObj->Param($this->fields_arr['forum_status']) . ', ' . 'date_added = now()';
						$fields_value_arr = array($this->fields_arr['forum_title'], $this->fields_arr['forum_description'], $this->fields_arr['forum_status']);
				}
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, $fields_value_arr);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return true;
		}
		public function setError($field_name, $err_tip = '')
		{
				$this->fields_err_tip_arr[$field_name] = $err_tip;
		}
}
$forum = new ForumFormHandler();
$forum->setPageBlockNames(array('msg_form_error', 'msg_form_success', 'form_create_forum'));
$forum->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$forum->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$forum->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$forum->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$forum->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$forum->setDBObject($db);
$forum->setCfgLangGlobal($CFG, $LANG);
$forum->setFormField('forum_id', '');
$forum->setFormField('forum_title', '');
$forum->setFormField('forum_status', '');
$forum->setFormField('forum_description', '');
$forum->setAllPageBlocksHide();
if ($forum->isFormGETed($_GET, 'forum_id'))
{
		$forum->sanitizeFormInputs($_GET);
		$forum->chkIsNotEmpty('forum_id', $LANG['forum_err_tip_compulsory']) and $forum->chkIsNumeric('forum_id', $LANG['forum_err_tip_compulsory']) and $forum->isValidForumId($CFG['db']['tbl']['forums'], $forum->getFormField('forum_id'), $LANG['forum_err_tip_invalid_forum_id']);
		if ($forum->isValidFormInputs())
		{
		}
		else
		{
				$forum->setPageBlockShow('msg_form_error');
		}
} elseif ($forum->isFormPOSTed($_POST, 'forum_submit'))
{
		$forum->sanitizeFormInputs($_POST);
		$forum->chkIsNotEmpty('forum_title', $LANG['forum_err_tip_compulsory']) and $forum->chkIsNotExists($forum->getFormField('forum_title'), $forum->getFormField('forum_id'), $CFG['db']['tbl']['forums'], $LANG['forum_err_tip_forum_title_exists']);
		$forum->chkIsNotEmpty('forum_status', $LANG['forum_err_tip_compulsory']);
		$forum->chkIsNotEmpty('forum_description', $LANG['forum_err_tip_compulsory']);
		$forum->getFormField('forum_id') and $forum->chkIsNotEmpty('forum_id', $LANG['forum_err_tip_compulsory']) and $forum->chkIsNumeric('forum_id', $LANG['forum_err_tip_compulsory']);
		$forum->isValidFormInputs() and $forum->createForumTitle($forum->getFormField('forum_id'));
		$forum->setAllPageBlocksHide();
		if ($forum->isValidFormInputs())
		{
				$forum->setPageBlockShow('msg_form_success');
				Redirect2URL('forums.php');
		}
		else
		{
				$forum->setPageBlockShow('msg_form_error');
		}
} elseif ($forum->isFormPOSTed($_POST, 'forum_cancel'))
{
		Redirect2URL('forums.php');
}
$forum->setPageBlockShow('form_create_forum');





?>
<div id="selSignUp">
	<h2 class="clsForumLinkTitle"><?php echo $LANG['forumslinks_add_title']; ?></h2>
    <div id="selLeftNavigation">
<?php
if ($forum->isShowPageBlock('msg_form_error'))
{
?>
<div id="selMsgError">
	 <p><?php echo $LANG['msg_error_sorry'] . ' ' . $forum->getCommonErrorMsg(); ?></p>
</div>
<?php
}
if ($forum->isShowPageBlock('msg_form_success'))
{
?>
<div id="selMsgSuccess">
 	<p><?php echo $LANG['forum_success']; ?></p>
</div>
<?php
}
if ($forum->isShowPageBlock('form_create_forum'))
{
?>
<div id="selShowCreateForum">
	<h3>
		<a href="forums.php">
			<?php echo $LANG['forum_back_index']; ?>
		</a>
	</h3>
	<form name="form_create_forum" id="selFormSignup" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" autocomplete="off">
		<table summary="<?php echo $LANG['forum_tbl_summary']; ?>">
		   	<tr>
				<td class="<?php echo $forum->getCSSFormLabelCellClass('forum_title'); ?>"><?php ShowHelpTip('forum_title'); ?><label for="forum_title"><?php echo $LANG['forum_title_add']; ?></label></td>
				<td class="<?php echo $forum->getCSSFormFieldCellClass('forum_title'); ?>"><?php echo $forum->getFormFieldErrorTip('forum_title'); ?>
					<input type="text" class="clsTextBox" name="forum_title" id="forum_title" maxlength="200" tabindex="<?php echo $forum->getTabIndex(); ?>" value="<?php echo $forum->getFormField('forum_title'); ?>" />
				</td>
		   	</tr>
		    <tr>
				<td class="<?php echo $forum->getCSSFormLabelCellClass('forum_status'); ?>"><?php ShowHelpTip('forum_title_status'); ?><label for="forum_status"><?php echo $LANG['forum_status']; ?></label></td>
				<td class="<?php echo $forum->getCSSFormFieldCellClass('forum_status'); ?>"><?php echo $forum->getFormFieldErrorTip('forum_status'); ?>
					<select class="clsCommonListBox" name="forum_status" id="forum_status" tabindex="<?php echo $forum->getTabIndex(); ?>"  >
						<option value="Yes" <?php if ($forum->getFormField('forum_status') == 'Yes') echo 'SELECTED' ?>><?php echo $LANG['forum_active']; ?></option>
						<option value="No" <?php if ($forum->getFormField('forum_status') == 'No') echo 'SELECTED' ?>><?php echo $LANG['forum_inactive']; ?></option>
					</select>
				</td>
		   	</tr>
		    <tr>
				<td class="<?php echo $forum->getCSSFormLabelCellClass('forum_description'); ?>"><?php ShowHelpTip('forum_title_description'); ?><label for="forum_description"><?php echo $LANG['forum_description']; ?></label></td>
				<td class="<?php echo $forum->getCSSFormFieldCellClass('forum_description'); ?>"><?php echo $forum->getFormFieldErrorTip('forum_description'); ?>
					<textarea name="forum_description" id="forum_description" rows="5" cols="50" tabindex="<?php echo $forum->getTabIndex(); ?>"><?php echo $forum->getFormField('forum_description'); ?></textarea>
				</td>
		    </tr>
			</tr>
		    <tr>
            <td>&nbsp;</td>
				<td class="<?php echo $forum->getCSSFormFieldCellClass('submit'); ?>">
					<?php
		$button_value = $LANG['forum_create_title'];
		if ($forum->getFormField('forum_id'))
		{
				$button_value = $LANG['forum_edit_title'];
		}
?>
					<input type="submit" class="clsSubmitButton clsMediumSubmitButton" name="forum_submit" id="forum_submit" tabindex="<?php echo $forum->getTabIndex(); ?>" value="<?php echo $button_value; ?>" />
					&nbsp;&nbsp;
					<input type="submit" class="clsCancelButton" name="forum_cancel" id="forum_cancel" tabindex="<?php echo $forum->getTabIndex(); ?>" value="<?php echo $LANG['forum_cancel']; ?>" />
				</td>
			</tr>
		</table>
		<input type="hidden" name="forum_id" id="forum_id" value="<?php echo $forum->getFormField('forum_id'); ?>" />
	</form>
</div>
<?php
}
?>
	</div>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>
