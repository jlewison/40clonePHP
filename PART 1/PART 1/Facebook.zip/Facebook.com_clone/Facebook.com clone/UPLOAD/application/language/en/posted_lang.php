<?php

/**
* Language File for posted items
*
*
* @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
* @license
* @since 12/18/2007
*/
	$lang['page_title']							= 'Posted Items';
	$lang['posted_post_success_msg']			= 'Your data has been posted successfully.';
	$lang['posted_post_error_msg']				= 'Your data has not been posted.';
	$lang['posted_add_comment_success_msg']		= 'Your comment has been added successfully.';
	$lang['posted_add_comment_error_msg']		= 'Your comment has not been added.';
	$lang['posted_head_my_posted_items']		= 'My Posted Items';
	$lang['posted_head_posted_items']			= 'Posted Items.';
	$lang['posted_label_recently_posted_by']	= 'Recently posted Items by';
	$lang['posted_label_displaying']			= 'Displaying';
	$lang['posted_label_out_of']				= 'out of';//example: Displaying 2 out of 10
	$lang['posted_label_all_friends']			= 'all friends';
	$lang['posted_label_recently_posted_items']	= 'recently posted item(s)';
	$lang['posted_label_posted_a_content_for']	= 'posted a content for';
	$lang['posted_label_view']					= 'View';
	$lang['posted_label_posted_items']			= 'Posted Items';
	$lang['posted_label_posted_at']				= 'posted at';
	$lang['posted_label_more']					= 'More';
	$lang['posted_label_comments']				= 'Comment(s)';
	$lang['posted_label_add_a_comment']			= 'Add a comment';
	$lang['posted_label_no_comments']			= 'No Comments';
	$lang['posted_label_report_item']			= 'Report Item';
	$lang['posted_label_no_post_friends']		= 'Your friend(s) have not posted anything!';
	$lang['posted_label_post_link']				= 'Post Link!';
	$lang['posted_label_example']				= 'example';
	$lang['posted_label_example_link1']			= 'http://www.domain.tld';
	$lang['posted_label_example_link2']			= 'http://www.domain.tld';
	$lang['posted_invalid_url_error_msg']		= 'Invalid Url!';
	$lang['posted_comment_validation_msg']		= 'Please give the comment to add.';
	$lang['posted_label_no_post_me']			= 'You are not yet posted anything!';
	$lang['posted_delete_post_confirm_msg']		= 'Dou you really want to delete this post';
	$lang['posted_label_posted_content_for']	= 'posted a content for';
	$lang['posted_label_post_content']			= 'Post Content';
	$lang['posted_label_comment']				= 'Comment';
	$lang['posted_label_optional']				= 'optional';
	$lang['posted_label_share']					= 'Share';
	$lang['posted_label_share_send_message']	= 'Send Message';
	$lang['posted_label_post_to_profile']		= 'Post to Profile';
	$lang['posted_label_send_to']				= 'To';
	$lang['posted_label_send_to_hint']			= 'Type friends name';
	$lang['posted_label_send_message']			= 'Message';
	$lang['posted_delete_confirm_message']		= 'Do you really want to delete this';
	$lang['posted_delete_post_success_msg']		= 'Post has been deleted successfully';
	$lang['posted_delete_post_error_msg']		= 'Post has not been deleted';


?>