<?
include("include/config.php");
$item_name=$_REQUEST['item_name'];
$item_number=$_REQUEST['item_number'];

$payment_date=$_REQUEST['payment_date'];
$payment_status=$_REQUEST['payment_status'];
if($payment_status=="Completed"||$payment_status=="Pending")
{
 $qry="select pactime from premium_package where pid=$item_number";
 $rs=$conn->execute($qry);
 $pt=$rs->fields['pactime'];
 $uname=$_COOKIE['uname'];
 $tm=time();
 $qry="update premium_user set pac_time=$pt,buy_time=$tm where uname='$uname'";
 $conn->execute($qry);
 setcookie("item_name",$item_name);
 setcookie("date",$pt);
 header("location: paydone.php");
}
else header("location: payerr.php");
?>
