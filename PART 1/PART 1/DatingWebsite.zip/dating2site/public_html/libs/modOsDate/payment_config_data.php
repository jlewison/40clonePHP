<?php

   class payment_configData extends Data {

      var $table = PAYMENT_CONFIG_TABLE;

      var $config = array (
  'table' => PAYMENT_CONFIG_TABLE,
  'idField' => 'osdate_payment_config_id',
  'addedMsg' => 'Osdate Payment Config %s Added',
  'added_err' => 'Can\\\'t Add Osdate Payment Config',
  'editMsg' => 'Osdate Payment Config %s Updated',
  'editErr' => 'Can\\\'t Update Osdate Payment Config',
  'delErr' => 'Can\\\'t Delete Osdate Payment Config',
  'delMsg' => 'Osdate Payment Config %s Deleted',
  'blankErr' => 'Osdate Payment Config Empty',
  'fields' => 
  array (
    'configuration_id' => 
    array (
      'name' => 'configuration_id',
      'description' => 'Configuration Id',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'configuration_title' => 
    array (
      'name' => 'configuration_title',
      'description' => 'Configuration Title',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 64,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'configuration_key' => 
    array (
      'name' => 'configuration_key',
      'description' => 'Configuration Key',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 64,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'configuration_value' => 
    array (
      'name' => 'configuration_value',
      'description' => 'Configuration Value',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 255,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'configuration_description' => 
    array (
      'name' => 'configuration_description',
      'description' => 'Configuration Description',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 255,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'configuration_group_id' => 
    array (
      'name' => 'configuration_group_id',
      'description' => 'Configuration Group Id',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'sort_order' => 
    array (
      'name' => 'sort_order',
      'description' => 'Sort Order',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 5,
      'blank_ok' => 1,
      'duplicate_ok' => 1,
    ),
    'last_modified' => 
    array (
      'name' => 'last_modified',
      'description' => 'Last Modified',
      'type' => 'datetime',
      'min_len' => 0,
      'max_len' => 19,
      'blank_ok' => 1,
      'duplicate_ok' => 1,
    ),
    'date_added' => 
    array (
      'name' => 'date_added',
      'description' => 'Date Added',
      'type' => 'datetime',
      'min_len' => 0,
      'max_len' => 19,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'use_function' => 
    array (
      'name' => 'use_function',
      'description' => 'Use Function',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 255,
      'blank_ok' => 1,
      'duplicate_ok' => 1,
    ),
    'set_function' => 
    array (
      'name' => 'set_function',
      'description' => 'Set Function',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 255,
      'blank_ok' => 1,
      'duplicate_ok' => 1,
    ),
    'module_key' => 
    array (
      'name' => 'module_key',
      'description' => 'Module Key',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 255,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
  ),
);   

      function payment_configData() {
      
         $this->Data($this->config);
      }
   }

?>
