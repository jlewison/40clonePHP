<?php
class UserDetailHandler extends FormHandler
{
		public function displayUserDetails()
		{
				$uid = $this->fields_arr['uid'];
				if ($userDetails = $this->chkIsValidUser($uid))
				{
						$uid = $userDetails['user_id'];
						$uname = $userDetails['name'];
						$userLog = $this->getUserLog($uid);
?>

<div class="clsUserPopUpTop">
  <div class="clsUserPopUpMiddle">
    <div class="clsUserPopUpBottom">
      <div class="clsUserPopUpDetails">
        <div class="clsInline">
          <p class="clsUserName clsOtherInfo"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'myanswers.php?uid=' . $uid, $this->CFG['site']['relative_url'] . 'my/answers/' . $uid . '/', false); ?>"><?php echo stripString($uname, $this->CFG['username']['medium_length']); ?></a></p>
          <P class="clsSendMessage clsOtherInfi"><a href="<?php echo getUrl($this->CFG['site']['url'] . 'members/' . $this->CFG['admin']['mail_urls']['compose']['normal'] . '?mcomp=' . $uname, $this->CFG['site']['url'] . 'members/' . $this->CFG['admin']['mail_urls']['compose']['htaccess'] . '?mcomp=' . $uname, false); ?>"><?php echo $this->LANG['send_message']; ?></a></P>
        </div>
        <div class="clsInline">
          <p class="clsOtherInfo"><?php echo $this->LANG['total_points']; ?> <span class="clsNumbers"><?php echo $userLog['total_points']; ?></span></p>
          <p class="clsOtherInfo"><?php echo $this->LANG['total_answers']; ?> <a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'questions.php?view=search&uname=' . $uname . '&opt=ans', $this->CFG['site']['relative_url'] . 'answers/search/?uname=' . $uname . '&opt=ans', false); ?>"><span class="clsTotalNumbers"><?php echo $userLog['total_ans']; ?></span></a></p>
        </div>
     <div class="clsInline">   <p class="clsOtherInfo"><?php echo $this->LANG['question_asked']; ?> <a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'questions.php?view=search&uname=' . $uname . '&opt=ques', $this->CFG['site']['relative_url'] . 'answers/search/?uname=' . $uname . '&opt=ques', false); ?>"><span class="clsTotalNumbers"><?php echo $userLog['total_ques']; ?></span></a></p>
        <p class="clsOtherInfo"><?php echo $this->LANG['resolved_questions']; ?>: <a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'questions.php?view=search&uname=' . $uname . '&opt=resolve', $this->CFG['site']['relative_url'] . 'answers/search/?uname=' . $uname . '&opt=resolve', false); ?>"><span class="clsTotalNumbers"><?php echo $this->getResolvedQuestions($uid); ?></span></a></p></div>
      </div>
    </div>
  </div>
</div>
<?php
				}
		}
		public function chkIsValidUser($uid)
		{
				if (!$uid) return false;
				$sql = 'SELECT ' . $this->getUserTableFields(array('user_id', 'name', 'image_path', 't_height', 't_width', 'photo_server_url', 'photo_ext')) . ', u.' . $this->getUserTableField('user_id') . ' AS img_user_id' . ' FROM ' . $this->CFG['db']['tbl']['users'] . ' AS u' . ' WHERE u.' . $this->getUserTableField('user_id') . '=' . $this->dbObj->Param($uid) . ' AND u.' . $this->getUserTableField('usr_status') . '=\'Ok\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($uid));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if (!$rs->PO_RecordCount())
				{
						return false;
				}
				$row = $rs->FetchRow();
				return $row;
		}
		public function getResolvedQuestions($uid)
		{
				$sql = 'SELECT COUNT(ques_id) AS resolved FROM ' . $this->CFG['db']['tbl']['questions'] . ' WHERE user_id=' . $this->dbObj->Param($uid) . ' AND status=\'Resolved\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($uid));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = $rs->FetchRow();
				return $row['resolved'];
		}
}
$userdetails = new UserDetailHandler();
$userdetails->setDBObject($db);
$userdetails->makeGlobalize($CFG, $LANG);
$userdetails->setFormField('uid', '');
$userdetails->sanitizeFormInputs($_REQUEST);
if ($userdetails->isFormGETed($_REQUEST, 'uid'))
{
		ob_start();
		$userdetails->displayUserDetails();
}
?>