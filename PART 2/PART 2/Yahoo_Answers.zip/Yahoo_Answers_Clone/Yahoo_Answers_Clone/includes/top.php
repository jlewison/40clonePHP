<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<title><? echo $configuration['title'] ?></title>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<meta name="description" content="<? echo $configuration['description'] ?>" />
	<meta name="keywords" content="<? echo $configuration['keywords'] ?>" />
	<LINK media="screen" href="css/<? echo $configuration['style'] ?>" type="text/css" rel="stylesheet">
</head>

<body>
<div class=o80 id=error-log></div>
<div class=rollover-profile-info id=></div>
<a name=top></a>
<div id=whole-page>
<div id=header align=center>
  <div id=ygma style="WIDTH: 100%">
    <div id=>
      <div id=>
      </div>
      <h1><p><a href="http://www.<? echo $configuration['title'] ?>">
		<img border="0" src="images/ga_ans_uh_logo.gif" width="264" height="33" align="left"></a>
		<?php include('google_search.php'); ?>
  		</p></h1></A></div>
    </div>
  </div>
  <div id=banner align=center>
    <div id=header-container>
      <TABLE cellSpacing=9 cellPadding=0 width=750 border=0>
        <TBODY>
          <TR>
			<td>
 			<a href="postquestion.php">
			<img border="0" src="images/mhask.gif" width="238" height="40"></a>&nbsp;
			<a href="answerthisquestion.php">
			<img border="0" src="images/mhanswer.gif" width="238" height="40"></a>&nbsp;
			<a href="index.php">
			<img border="0" src="images/mhdiscover.gif" width="238" height="40"></a></td>
          </TR>
        </TBODY>
      </TABLE>
    </div>
  </div>