<?php

   class buddyBanListData extends Data {

      var $table = BUDDY_BAN_TABLE;

      var $config = array (
  'table' => BUDDY_BAN_TABLE,
  'idField' => 'id',
  'addedMsg' => 'Osdate Buddy Ban List %s Added',
  'added_err' => 'Can\\\'t Add Osdate Buddy Ban List',
  'editMsg' => 'Osdate Buddy Ban List %s Updated',
  'editErr' => 'Can\\\'t Update Osdate Buddy Ban List',
  'delErr' => 'Can\\\'t Delete Osdate Buddy Ban List',
  'delMsg' => 'Osdate Buddy Ban List %s Deleted',
  'blankErr' => 'Osdate Buddy Ban List Empty',
  'fields' => 
  array (
    'username' => 
    array (
      'name' => 'username',
      'description' => 'Username',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 25,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'act' => 
    array (
      'name' => 'act',
      'description' => 'Act',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 1,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'ref_username' => 
    array (
      'name' => 'ref_username',
      'description' => 'Ref Username',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 25,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'act_date' => 
    array (
      'name' => 'act_date',
      'description' => 'Act Date',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
  ),
);   

      function buddyBanListData() {
      
         $this->Data($this->config);
      }
   }

?>
