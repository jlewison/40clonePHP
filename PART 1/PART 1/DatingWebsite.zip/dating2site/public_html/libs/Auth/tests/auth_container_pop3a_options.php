<?php

$options = 'mail.netsmart.com.cy:110';

$extra_options['username'] = 'test_user';
$extra_options['passwd'] = 'test_user';

?>