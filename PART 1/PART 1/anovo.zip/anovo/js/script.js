var block_arr = new Array();
var enabled_edit_fields_time = new Array();
var enabled_edit_fields_comment = new Array();
var commentsArray = new Array();
var ajaxWindowLink;
var ajaxWindowYPos = 0;
var ajaxWindowXPos = 0;

// ARRAY EXTENSIONS

if (!Array.prototype.push) Array.prototype.push = function() {
    for (var i=0; i<arguments.length; i++) this[this.length] = arguments[i];
    return this.length;
}

Array.prototype.find = function(value, start) {
    start = start || 0;
    for (var i=start; i<this.length; i++)
        if (this[i]==value)
            return i;
    return -1;
}

Array.prototype.has = function(value) {
    return this.find(value)!==-1;
}

// FUNCTIONAL

function map(list, func) {
    var result = [];
    func = func || function(v) {return v};
    for (var i=0; i < list.length; i++) result.push(func(list[i], i, list));
    return result;
}

function filter(list, func) {
    var result = [];
    func = func || function(v) {return v};
    map(list, function(v) { if (func(v)) result.push(v) } );
    return result;
}


// DOM

function getElem(elem) {
    if (document.getElementById) {
        if (typeof elem == "string") {
            elem = document.getElementById(elem);
            if (elem===null) throw 'cannot get element: element does not exist';
        } else if (typeof elem != "object") {
            throw 'cannot get element: invalid datatype';
        }
    } else throw 'cannot get element: unsupported DOM';
    return elem;
}

function hasClass(elem, className) {
    return getElem(elem).className.split(' ').has(className);
}

function getElementsByClass(className, tagName, parentNode) {
    parentNode = !isUndefined(parentNode)? getElem(parentNode) : document;
    if (isUndefined(tagName)) tagName = '*';
    return filter(parentNode.getElementsByTagName(tagName),
        function(elem) { return hasClass(elem, className) });
}


// DOM EVENTS

function listen(event, elem, func) {
    elem = getElem(elem);
    if (elem.addEventListener)  // W3C DOM
        elem.addEventListener(event,func,false);
    else if (elem.attachEvent)  // IE DOM
        elem.attachEvent('on'+event, function(){ func(new W3CDOM_Event(elem)) } );
        // for IE we use a wrapper function that passes in a simplified faux Event object.
    else throw 'cannot add event listener';
}

function mlisten(event, elem_list, func) {
    map(elem_list, function(elem) { listen(event, elem, func) } );
}

function W3CDOM_Event(currentTarget) {
    this.currentTarget  = currentTarget;
    this.preventDefault = function() { window.event.returnValue = false }
    return this;
}

// MISC CLEANING-AFTER-MICROSOFT STUFF
function isUndefined(v) {
    var undef;
    return v===undef;
}

//<--lib ends

//Our functions starts....

//Open popup. Can be called directly
function Popup(url, target, features)
{
	var theWindow = window.open(url, target, features);
	theWindow.focus();
	return theWindow;
}
//Holder for Popup(). As it's to be registered with event listener
function PopupHolder(e)
{
	Popup(e.currentTarget.getAttribute('href'), e.currentTarget.getAttribute('target') || J_POPUP_TARGET, J_POPUP_FEATURES);
	e.preventDefault();
}
//show balloon. Can be called directly
function ShowBalloon(objA, x, y)
{
	gTmp_ATitle = objA.title; //preserve the title in global var
	objA.title = ''; //empty it, so that it won't popup
	var tmp_title = 'Help', tmp_desc = gTmp_ATitle, pos_colon; //safe init
	//e.g., gTmp_ATitle = 'Help: Help is a help...'
	if ((pos_colon=gTmp_ATitle.indexOf(':')) !=-1 )
		{
			tmp_title = gTmp_ATitle.substring(0, pos_colon);
			tmp_desc = gTmp_ATitle.substring(pos_colon+1);
		}
	var balloon = document.getElementById(J_BALLOON);
	balloon.className = J_CLSBALLOON;
	balloon.style.display = 'inline';
	balloon.style.width = J_BALLOONWIDTH + 'px';
	balloon.style.top = y + 'px';
	balloon.style.left = x + 'px';
	balloon.innerHTML = '<span class="' + J_CLSBALLOONTITTLE + '">'+ tmp_title +'<\/span><div class="' + J_CLSBALLOONDESC + '">'+ tmp_desc + '<\/div>';
	return true;
}
//For the links in myPhotos.php
function ShowPhotoBalloon(objA, x, y)
{
	gTmp_ATitle = objA.title; //preserve the title in global var
	objA.title = ''; //empty it, so that it won't popup
	var tmp_title = 'Help', tmp_desc = gTmp_ATitle, pos_colon; //safe init
	//e.g., gTmp_ATitle = 'Help: Help is a help...'
	if ((pos_colon=gTmp_ATitle.indexOf(':')) !=-1 )
		{
			tmp_title = gTmp_ATitle.substring(0, pos_colon);
			tmp_desc = gTmp_ATitle.substring(pos_colon+1);
		}
	var balloon = document.getElementById(J_BALLOON);
	balloon.className = J_CLSPHOTOLINKBALLOON;
	balloon.style.display = 'inline';
	balloon.style.width = J_PHOTOBALLOONWIDTH + 'px';
	balloon.style.top = y + 'px';
	balloon.style.left = x + 'px';
	balloon.innerHTML = '<div class="' + J_CLSPHOTOBALLOONTEXT + '">'+ tmp_desc + '<\/div>';
	return true;
}
//Holder for ShowBalloon(). As it's to be registered with event listener
function ShowPhotoLinkBalloonHolder(e)
{
	var posx = 0, posy = 0;
	if (e.pageX || e.pageY) //Moz
		{
			posx = e.pageX;
			posy = e.pageY;
		}
	 else if (event.clientX || event.clientY) //IE. Note: event.x not working fine
		{
			posx = event.clientX + document.body.scrollLeft;
			posy = event.clientY + document.body.scrollTop;
		}
	//Note: using the x, y as it is cause the div to flicker in certain border points in FF (IE, Opera works find).
	ShowPhotoBalloon(e.currentTarget, posx+J_BALLOONPOSADJX, posy+J_BALLOONPOSADJY);
	e.preventDefault();
}
function ShowBalloonHolder(e)
{
	var posx = 0, posy = 0;
	if (e.pageX || e.pageY) //Moz
		{
			posx = e.pageX;
			posy = e.pageY;
		}
	 else if (event.clientX || event.clientY) //IE. Note: event.x not working fine
		{
			if(document.body.scrollTop==0){
				var targetText = e.currentTarget;
				targetText = targetText + "";
				targetText = targetText.substring(targetText.indexOf('#')+1);
				targetText = 'Help_'+targetText;
				targetText = document.getElementById(targetText);
				var posy = getAbsoluteOffsetTopConfirmation(targetText);
				var posx = getAbsoluteOffsetLeftConfirmation(targetText);
				//alert(posx+'--'+posy+J_BALLOONPOSADJX);
			}
			else{
				posx = event.clientX + document.body.scrollLeft;
				posy = event.clientY + document.body.scrollTop;
			}
		}
	//Note: using the x, y as it is cause the div to flicker in certain border points in FF (IE, Opera works find).
	ShowBalloon(e.currentTarget, posx+J_BALLOONPOSADJX, posy+J_BALLOONPOSADJY);
	e.preventDefault();
}
//Hides balloon.
function HideBalloon(objA)
{
	var balloon = document.getElementById(J_BALLOON);
	balloon.style.display = 'none';
	objA.title = gTmp_ATitle; //re-assign
}
//Holder for HideBaloon. As it's to be registered with event listener
function HideBalloonHolder(e)
{
	HideBalloon(e.currentTarget);
	e.preventDefault();
}

//global vars
var gTmp_ATitle; //temp variable to hold and swap title attributes
//global constants. Used to change behaviors quickly
//presumably IE doesn't support const on strings
var J_BALLOON = 'balloon'; //balloon id
var J_CLSHELP = 'clsHelp';
var J_CLSBALLOON = 'clsBalloon';
var J_CLSBALLOONTITTLE = 'clsBalloonTittle';
var J_CLSBALLOONDESC = 'clsBalloonDesc';
var J_BALLOONPOSADJX = 10;
var J_BALLOONPOSADJY = 10;
var J_POPUP_FEATURES = 'location=0,statusbar=0,menubar=0,scrollbars=1';
var J_POPUP_TARGET = 'help';
var J_BALLOONWIDTH = 200;
var J_CLSPHOTOLINKCLASS = 'clsPhotoVideoEditLinks';
var J_CLSPHOTOLINKBALLOON = 'clsPhotoBalloon';
var J_CLSPHOTOBALLOONTEXT = 'clsPhotoBalloonText';
var J_PHOTOBALLOONWIDTH = '90';

listen('load',
		window,
		function()
		{
			//create balloon div...
			var balloon = document.createElement('div');
			balloon.id = J_BALLOON;
			document.body.appendChild(balloon);
			//listen...
			mlisten('mouseover', getElementsByClass(J_CLSHELP,'a'), ShowBalloonHolder);
			mlisten('mouseout', getElementsByClass(J_CLSHELP,'a'), HideBalloonHolder);
			mlisten('click', getElementsByClass(J_CLSHELP,'a'), PopupHolder);
			mlisten('mouseover', getElementsByClass(J_CLSPHOTOLINKCLASS,'a'), ShowPhotoLinkBalloonHolder);
			mlisten('mouseout', getElementsByClass(J_CLSPHOTOLINKCLASS,'a'), HideBalloonHolder);
		}
	);

function Popup(url, target, features)
{
	var theWindow = window.open(url, target, features);
	//http://developer.mozilla.org/en/docs/DOM:window.open
	//window.open will return null on popup blocker and sort of
	if (theWindow==null)
			location.href = url;
		else if (window.focus)
			theWindow.focus();
	return theWindow;
}

function LTrim(str)
{
  var whitespace = new String(" \t\n\r");

  var s = new String(str);

  if (whitespace.indexOf(s.charAt(0)) != -1) {
    // We have a string with leading blank(s)...

    var j=0, i = s.length;

    // Iterate from the far left of string until we
    // don't have any more whitespace...
    while (j < i && whitespace.indexOf(s.charAt(j)) != -1)
    j++;


    // Get the substring from the first non-whitespace
    // character to the end of the string...
    s = s.substring(j, i);
  }

  return s;
}

function RTrim(str)
{
  // We don't want to trip JUST spaces, but also tabs,
  // line feeds, etc.  Add anything else you want to
  // "trim" here in Whitespace
  var whitespace = new String(" \t\n\r");

  var s = new String(str);

  if (whitespace.indexOf(s.charAt(s.length-1)) != -1) {
    // We have a string with trailing blank(s)...

    var i = s.length - 1;       // Get length of string

    // Iterate from the far right of string until we
    // don't have any more whitespace...
    while (i >= 0 && whitespace.indexOf(s.charAt(i)) != -1)
      i--;


    // Get the substring from the front of the string to
    // where the last non-whitespace character is...
    s = s.substring(0, i+1);
  }

  return s;
}

function Trim(str)
{
  return RTrim(LTrim(str));
}

function selectAll(thisForm)
	{
		for (var i=0; i<thisForm.elements.length; i++)
			{
				if (thisForm.elements[i].type == "checkbox")
					{
						if(thisForm.checkall.checked)
							{
								thisForm.elements[i].checked=true;
							}
							else
								{
									thisForm.elements[i].checked=false;
								}
					}
			}
	}

//function for check box manage
function CheckAll(form_name,check_all,isO,noHL)
	{
		var trk=0;
		var frm = eval('document.'+form_name);
		var check_frm = eval('document.'+form_name+'.'+check_all);

		for (var i=0;i<frm.elements.length;i++)
		{
			var e=frm.elements[i];
			if ((e.name != check_all) && (e.type=='checkbox'))
			{
				if (isO != 1)
				{
					trk++;
					if(e.disabled!=true)
						e.checked=check_frm.checked;
				}
			}
		}
	}

//function for disable the select all checkbox column
function disableHeading(frmname)
{
		var targetForm = document.getElementById(frmname);

		for (var i=1; i<targetForm.elements.length; i++)
			{
				if (targetForm.elements[i].type == "checkbox")
				{	//alert(i);
					if (targetForm.elements[i].checked)
					{	//alert('chekall');
						targetForm.elements[0].checked=true;
					}
					else
					{
						targetForm.elements[0].checked=false;
						break;
					}
				}
			}
}

function disableAll(isEnable,frmname)
	{
		//alert('inside disable');
		var make = isEnable;
		var targetForm = document.getElementById(frmname);

		if(frmname == '')
		return false;

		for (var i=0; i<targetForm.elements.length; i++)
			{
				if (targetForm.elements[i].type == "checkbox")
					{
						if(make == '0')
						targetForm.elements[i].disabled=true;
						else
						targetForm.elements[i].disabled=false;

					}
			}
	}

function setSubjectFocus(thisForm)
{
	thisForm.subject.focus();
}

var myGlobalHandlers = {
		onCreate: function(){
			Element.show('systemWorking');
			Element.hide('content');
		},

		onComplete: function() {
			if(Ajax.activeRequestCount == 0){
				Element.hide('systemWorking');
				Element.show('content');

			}
		}
	};

var divToChange = '';
function getRatingDetails(url, pars, divname)
	{
		Ajax.Responders.unregister(myGlobalHandlers);
		divToChange = divname;
		var myAjax = new Ajax.Request(
								url,
								{
								method: 'get',
								parameters: pars,
								onComplete: changeDivInnerHtml
								});
	}

function getQuestionRatingDetails(url, pars, divname)
	{
		Ajax.Responders.unregister(myGlobalHandlers);
		divToChange = divname;
		var myAjax = new Ajax.Request(
								url,
								{
								method: 'get',
								parameters: pars,
								onComplete: changeDivInnerHtml
								});
	}

function call_ajax_populate_sub_categories(url, add_pars,divname)
	{
		a = document.selFormAskQuestion.category;
		divToChange = divname;
		cat = a.value;
		pars = 'cid='+cat+'&'+add_pars;
		var myAjax = new Ajax.Request(
							url,
							{
							method: 'get',
							parameters: pars,
							onComplete: changeDivInnerHtml
							});

	}
function changeDivInnerHtml(originalRequest){
		var data = originalRequest.responseText;
		$(divToChange).innerHTML = data;
	}
function toggleFavorites(url, pars, divname){
		Ajax.Responders.unregister(myGlobalHandlers);
		divToChange = divname;
		$(divToChange).innerHTML = loadingSrc;
		var myAjax = new Ajax.Request(
								url,
								{
								method: 'get',
								parameters: pars,
								onComplete: changeDivInnerHtml
								});
	}
function updatelength(obj)
{
	var mlength=obj.getAttribute? parseInt(obj.getAttribute("maxlength")) : "";
	if (obj.getAttribute && obj.value.length>mlength)
		{
			obj.value=obj.value.substring(0,mlength);
			alert_manual("Description limit exceeded", obj.id);
		}

	var a;
	a=obj.value.length + '   (Limit '+mlength+')';
	Element.update('ss', a);
}

/**
 *
 * @access public
 * @return void
 **/
var img_src = new Array();
function mouseOver(rating, rate_img_mouse_over, rate_img_mouse_out)
{
	for(var i=1; i<=rating; i++)
		{
			var obj = document.getElementById('rate'+i);
			img_src[i] = obj.src;
			obj.src = rate_img_mouse_over;
		}
	for(; i<=4; i++)
		{
			var obj = document.getElementById('rate'+i);
			img_src[i] = obj.src;
			obj.src = rate_img_mouse_out;
		}
}

function mouseOut()
	{
		for(var i=1; i<=4; i++)
			{
				var obj = document.getElementById('rate'+i);
				obj.src = img_src[i];
			}
	}

/**
 *
 * @access public
 * @return void
 **/
function mouseOverAnswers(rating, start, rate_img_mouse_over, rate_img_mouse_out)
{
	for(var i=1+start; i<=rating; i++)
		{
			var obj = document.getElementById('rate'+i);
			img_src[i] = obj.src;
			obj.src = rate_img_mouse_over;
		}
	for(; i<=4+start; i++)
		{
			var obj = document.getElementById('rate'+i);
			img_src[i] = obj.src;
			obj.src = rate_img_mouse_out;
		}
}

function mouseOutAnswers(start)
	{
		for(var i=1+start; i<=4+start; i++)
			{
				var obj = document.getElementById('rate'+i);
				obj.src = img_src[i];
			}
	}

/**
 *
 * @access public
 * @return void
 **/
function hide_element()
{
    for (var i = 0; i < arguments.length; i++)
	{
      var element = $(arguments[i]);
      if (element)
      	element.style.display = 'none';
    }

}

function show_element()
{
    for (var i = 0; i < arguments.length; i++)
	{
      var element = $(arguments[i]);
      if (element)
      	element.style.display = '';
    }

}
//**************** Regular Expression functions*******************/
function RegularExpressionReplace(expression, subject, replaced)
	{
	  var re = new RegExp(expression, "g");
	  return subject.replace(re, replaced);
	}
function StringReplcae(find_string, replace_string, subject)
	{
		return RegularExpressionReplace(find_string, subject, replace_string);
	}
function replace_string(str, search_str, replace_str)
	{
			var condition = true;
			var inc= 1;
			while(condition)
				{
					str = str.replace(search_str,replace_str);
					if(str.indexOf(search_str)<0)
						condition = false;
					inc++;
				}
			return str;
	}

//**************** confirmation box related functions Start *******************/
//Change position of the confirmation block
function getAbsoluteOffsetTopConfirmation(obj){
	    var top = obj.offsetTop;
	    var parent = obj.offsetParent;
	    while (parent != document.body)
			{
		        top += parent.offsetTop;
		        parent = parent.offsetParent;
		    }
	    return top;
	}

function getAbsoluteOffsetLeftConfirmation(obj){
	    var left = obj.offsetLeft;
	    var parent = obj.offsetParent;
	    while (parent != document.body)
			{
		        left += parent.offsetLeft;
		        parent = parent.offsetParent;
		    }
	    return left;
	}

//Hide all confirmation blocks
function hideAllBlocks(){
		var obj;
		var enable_frm = '';
		if(arguments.length == 1)
			var enable_frm = arguments[0];
		if(obj = $('selAlertbox'))
			obj.style.display = 'none';
		for(var i=0;i<block_arr.length;i++){
				if(obj = $(block_arr[i]))
					{	obj.style.display = 'none';
						disableAll('1', enable_frm);
					}
			}
		if(obj = $('hideScreen'))
			obj.style.display='none';

		if(obj = $('selAjaxWindow'))
			obj.style.display='none';

		if(obj = $('selAjaxWindowInnerDiv'))
			obj.innerHTML='';

		if ((catObj = $('category')) || (sub_catObj = $('sub_category'))){
			br=getBrowser();
			if (br[0] == 'msie' && getMajorVersion(br[1]) == '6'){
				if (catObj = $('category'))
					catObj.style.display = '';

				if (sub_catObj = $('sub_category'))
					sub_catObj.style.display = '';
			}
		}

		return false;
	}

//Get multible check box value with comma seperator
var multiCheckValue='';
var minimum_top = 20;
var minimum_left = 20;
var zIndexValue = 200;
// form_name, check_all_name, alert_value, place
var getMultiCheckBoxValue = function(){
	multiCheckValue = '';
	var form_name = arguments[0];
	var check_all_name = arguments[1];
	var alert_value = arguments[2];
	var place = 0;
	var add_left_position = 0
	var add_top_position = 0;
	if(arguments.length>=4)
		place = arguments[3];
	if(arguments.length>=5)
		add_top_position = arguments[4];
	if(arguments.length>=6)
		add_left_position = arguments[5];

	var frm = eval('document.'+form_name);
	var ids = '';
	for(var i=0;i<frm.elements.length;i++){
		var e=frm.elements[i];
		if ((e.name != check_all_name) && (e.type=='checkbox') && e.checked)
			ids += e.value+',';
	}
	if(ids){
		multiCheckValue =ids.substring(0,ids.length-1);
		return true;
	}
	if(place)
		alert_manual(alert_value, place, add_top_position, add_left_position);
	else
		alert(alert_value);
	return false;
}
var alert_manual = function()
	{
		var obj;
		var alert_value = arguments[0];
		var place = arguments[1];
		var add_left_position = 0
		var add_top_position = 0;
		if(arguments.length>=3)
			add_top_position = arguments[2];
		if(arguments.length>=4)
			add_left_position = arguments[3];
		if(obj = $('selAlertMessage'))
			obj.innerHTML = alert_value;
		if(fromObj = $('selAlertbox'))
			changePosition(fromObj, $(place), add_top_position, add_left_position);
		if(obj = $('selAlertOkButton'))
			obj.focus();
		return false;
	}
function changePosition(fromObj, toObj, add_top_position, add_left_position){
	fromObj.style.zIndex = zIndexValue;
	var top = getAbsoluteOffsetTopConfirmation(toObj)+ add_top_position;
	var left = getAbsoluteOffsetLeftConfirmation(toObj)+ add_left_position;
	if(top<minimum_top)
		top = minimum_top;
	if(left<minimum_left)
		left = minimum_left;
	fromObj.style.top = top + 'px';
	fromObj.style.left = left + 'px';
	fromObj.style.display = 'block';
	if(obj = $('hideScreen')){
		var ss = getPageSizeWithScroll();
		obj.style.width=ss[0]+"px";
		obj.style.height=ss[1]+"px";
		obj.style.display='block';
	}
}
function showHideScreen(divElm){
	var fromObj = $(divElm);
	fromObj.style.zIndex = zIndexValue;
	fromObj.style.display = 'block';
	if(obj = $('hideScreen')){
		var ss = getPageSizeWithScroll();
		obj.style.width=ss[0]+"px";
		obj.style.height=ss[1]+"px";
		obj.style.display='block';
		return false;
	}
}
function makeQueryAsFormFieldValues(form_name)
	{
		var query = '';
		var frm = eval('document.'+form_name);
		for(var i=0;i<frm.elements.length;i++){
				var e=frm.elements[i];
				if (e.type!='button' && e.type!='checkbox'){
						query += e.name+'='+e.value+'&';
					}
			}
		query =query.substring(0,query.length-1);
		return query;
	}

//Display confirmation Block
//place, block, form_name, id_array, value_array, property_array, add_top_position, add_left_position
//property_array, add_top_position, add_left_position --- optional
var Confirmation = function(){
	//alert('here');
	var obj, inc, form_field;
	hideAllBlocks();

	var place = arguments[0];
	var block = arguments[1];
	var form_name = arguments[2];
	var id_array = arguments[3];
	var value_array = arguments[4];
	var add_top_position = 0;
	var add_left_position = 0;
	var disable_form = '';
	var property_array = new Array();
	multiCheckValue ='';

	if(arguments.length==9)
		{
		var disable_form = arguments[8];
		disableAll('0',disable_form);
		}
	if(arguments.length>=8)
		var add_left_position = arguments[7];
	if(arguments.length>=7)
		var add_top_position = arguments[6];
	if(arguments.length>=6)
		property_array = arguments[5];

	for(inc=0; inc<value_array.length;inc++){
		if(!property_array[inc])
			property_array[inc] = 'value';
		form_field = eval('document.'+form_name+'.'+id_array[inc]);
		if(form_field && form_field[property_array[inc]]!=null)
			form_field[property_array[inc]] = value_array[inc];
		else if(obj = $(id_array[inc]))
			obj[property_array[inc]] = value_array[inc];
	}
	if(fromObj = $(block))
		changePosition(fromObj, $(place), add_top_position, add_left_position);
	return false;
}
function getPageSizeWithScroll(){
	if (window.innerHeight && window.scrollMaxY) {// Firefox
		yWithScroll = window.innerHeight + window.scrollMaxY;
		xWithScroll = window.innerWidth + window.scrollMaxX;
	} else if (document.body.scrollHeight > document.body.offsetHeight){ // all but Explorer Mac
		yWithScroll = document.body.scrollHeight;
		xWithScroll = document.body.scrollWidth;
	} else { // works in Explorer 6 Strict, Mozilla (not FF) and Safari
		yWithScroll = document.body.offsetHeight;
		xWithScroll = document.body.offsetWidth;
  	}
	arrayPageSizeWithScroll = new Array(xWithScroll,yWithScroll);
	//alert( 'The height is ' + yWithScroll + ' and the width is ' + xWithScroll );
	return arrayPageSizeWithScroll;
}
//**************** confirmation box related functions End *******************/

var getCheckBoxValue = function(){
	var form_name = arguments[0];
	var check_all_name = arguments[1];
	var frm = eval('document.'+form_name);
	var ids = '';
	for(var i=0;i<frm.elements.length;i++){
		var e=frm.elements[i];
		if ((e.name != check_all_name) && (e.type=='checkbox') && e.checked)
			ids += e.value+', ';
	}
	if(ids){
		multiCheckValue =ids.substring(0,ids.length-1);
		return true;
	}
	return false;
}

var doActionOnQuestion = function(){
	var act_value = arguments[0];
	var anchorLink = arguments[1];
	var msg_confirm = arguments[2];

	var confirm_message = msg_confirm;

	$('confirmMessage').innerHTML = confirm_message;
	document.formConfirm.action.value = act_value;
	Confirmation(anchorLink, 'selMsgConfirm', 'formConfirm', Array(), Array(), Array(), -25, -500);

	return false;
}

var doActionOnAnswer = function(){
	var act_value = arguments[0];
	var anchorLink = arguments[1];
	var msg_confirm = arguments[2];
	var ansId = arguments[3];

	var confirm_message = msg_confirm;

	$('confirmMessage').innerHTML = confirm_message;
	document.formConfirm.action.value = act_value;
	document.formConfirm.aid.value = ansId;
	Confirmation(anchorLink, 'selMsgConfirm', 'formConfirm', Array(), Array(), Array(), -25, -500);

	return false;
}

function openAjaxWindow(linkid, xPos, yPos){
	ajaxWindowLink = linkid;
	ajaxWindowYPos = yPos;
	ajaxWindowXPos = xPos;
	linkobj = document.getElementById(linkid);
	url = linkobj.href;
	pars = '';
	var myAjax = new Ajax.Request(
								url,
								{
								method: 'get',
								parameters: pars,
								onComplete: ajaxResultOpenAjaxWindow
								});
								return false;
}

function ajaxResultOpenAjaxWindow(originalRequest){
	data = originalRequest.responseText;
	Confirmation(ajaxWindowLink, 'selAjaxWindow', 'frmAjaxWindow', Array('selAjaxWindowInnerDiv'), Array(data), Array('innerHTML'), ajaxWindowYPos, ajaxWindowXPos);
	if ((catObj = $('category')) || (sub_catObj = $('sub_category'))){
		br=getBrowser();
		if (br[0] == 'msie' && getMajorVersion(br[1]) == '6'){
			if (catObj = $('category'))
				catObj.style.display = 'none';

			if (sub_catObj = $('sub_category'))
				sub_catObj.style.display = 'none';
		}
	}
}

var abuseContent = function(){
	var act_value = arguments[0];
	var content_id = arguments[1];
	var anchorLink = arguments[2];
	var msg_confirm = arguments[3];

	var confirm_message = msg_confirm;

	$('confirmAbuseMessage').innerHTML = confirm_message;
	document.formAbuseConfirm.action.value = act_value;
	document.formAbuseConfirm.content_id.value = content_id;
	Confirmation(anchorLink, 'selMsgAbuseConfirm', 'formAbuseConfirm', Array(), Array(), Array(), -25, -500);

	return false;
}

var chkIsAbuseReasonExists = function(){
	var abuseReason = $('reason').value;
	if (!Trim(abuseReason))
		{
			$('validReason').innerHTML = 'Enter valid reason for abusing!';
			return false;
		}
	$('validReason').innerHTML = '';
}

var removeReasonErrors = function(){
	$('validReason').innerHTML = '';
	$('reason').value = '';
}

var closLightWindow = function(){
	hideAllBlocks();
	return false;
}

function show(element){
	if(obj = document.getElementById(element))
		obj.style.display = '';
}

function hide(element){
	if(obj = document.getElementById(element))
		obj.style.display = 'none';
}
/************ edit comments end ********/

/*******for ediit comment functions started***********/
function callAjaxEdit(url, pars, comment_id)
	{
		pars = pars+'&type=edit&comment_id='+comment_id;
		var myAjax = new Ajax.Request(
								url,
								{
								method: 'get',
								parameters: pars,
								onComplete: ajaxResultEdit
								});
		return false;
	}

function ajaxResultEdit(originalRequest)
	{
		var obj;
		data = originalRequest.responseText;

		data = data.split('***--***!!!');

		if(obj = document.getElementById('selEditCommentTxt_'+data[0]))
			obj.style.display = 'none';

		obj = document.getElementById('selEditComments_'+data[0]);
		obj.style.display = 'block';
		var txt = replace_string(data['1'], '<br>', '\n');
		txt = replace_string(txt, '<br />', '\n');
		txt = trim(txt);
		obj.innerHTML = txt;

		obj = document.getElementById('selViewEditComment_'+data[0]);
		obj.style.display = 'none';
		return true;
	}

function discardEdit(comment_id)
	{
		var obj;

		if(obj = document.getElementById('selEditCommentTxt_'+comment_id))
			obj.style.display = '';

		if(obj = document.getElementById('selEditComments_'+comment_id))
			obj.style.display = 'none';

		if(obj = document.getElementById('selViewEditComment_'+comment_id))
			obj.style.display = '';
	}

var addToEdit = function()
	{
		comment_id = arguments[0];

		if(arguments[1])
			addCommentsUrl = arguments[1];

		var f = '';

		var frm = eval("document.addEdit_"+comment_id);
		for (var i=0;i<frm.elements.length;i++)
			{
				var e=frm.elements[i];
				if (e.type!='button')
					{
						var ovalue = Trim(e.value);
						if(ovalue)
							{
								ovalue = replace_string(ovalue, '\n', '<br />');
								f += ovalue;
							}
						else
							{
								e.value = '';
								e.focus();
								return false;
							}
					}
			}
		f = escape(f);
		var currpath = addCommentsUrl+'&comment_id='+comment_id+'&type=edit&f='+escape(f);
		callAjaxUpdate(currpath,'selCommentBlock');
		return false
	}

function callAjaxUpdate(path, block)
	{

		path = path;
		new AG_ajax(path,'callAjaxUpdateResponse');
		return false;
	}

function callAjaxUpdateResponse(data)
	{
		data = unescape(data);
		if(data.indexOf(session_check)>=1)
			{
				data = data.replace(session_check_replace,'');
			}
		else
			{
				return;
			}
		data = data.split('***--***!!!');

		if(obj = document.getElementById('selEditCommentTxt_'+data['0']))
			obj.innerHTML = data['1'];

		discardEdit(data['0']);
		return;
	}
//For sorting
function changeOrderbyElements(form_name,field_name){
	 	var obj = eval("document."+form_name+".orderby_field");
	 	obj.value = field_name;
	 	obj = eval("document."+form_name+".orderby");
	 	if(obj.value=="asc")
	 		obj.value="desc";
	 	else
	 		obj.value="asc";
	 	eval("document."+form_name+".submit()");
	 	return false;
	}

//for postmethod to paging
function pagingSubmit(formname, start){
	var obj = eval("document."+formname);
	obj.start.value = start;
	obj.submit();
	return false;
}

function addComment(url, first_par, form_name, divname)
	{
		Ajax.Responders.unregister(myGlobalHandlers);
		commet_str = $F('comment')
		commet_str = commet_str.replace( /^\s+/g, "" );
  		commet_str =  commet_str.replace( /\s+$/g, "" );
		if (commet_str.length == 0)
			{
				alert_manual("Enter comment", divname);
				return false;
			}

		pars = Form.serialize(form_name);
		pars = first_par + pars;
		var myAjax = new Ajax.Updater(
								{success: divname},
								url,
								{
									method: 'post',
									parameters: pars
								});
		form_name.reset();
	}
function CheckAll(form_name,check_all,isO,noHL)
	{
		var trk=0;
		var frm = eval('document.'+form_name);
		var check_frm = eval('document.'+form_name+'.'+check_all);

		for (var i=0;i<frm.elements.length;i++)
		{
			var e=frm.elements[i];
			if ((e.name != check_all) && (e.type=='checkbox'))
			{
				if (isO != 1)
				{
					trk++;
					if(e.disabled!=true)
						e.checked=check_frm.checked;
				}
			}
		}
	}
//timer for delete blogs start
function changeTimer(){
	if(enabled_edit_fields_comment.length){
		doTimerFunction();
	}
	setTimeout('changeTimer()',1000);
}

function setEditTimerValue(comment_id){
	enabled_edit_fields_comment[enabled_edit_fields_comment.length] = comment_id;
	enabled_edit_fields_time[comment_id] = max_timer;
}

function doTimerFunction(){
	var val;
	var comment_id;
	for(var i in enabled_edit_fields_comment){
		comment_id = enabled_edit_fields_comment[i];
		if(i!='undefined' && i!='has' && i!='find'){
		val = enabled_edit_fields_time[comment_id];
		if(val<=1)
			hideDeleteEditLinks(comment_id);
		else if(val!=null)
			decrementTime(comment_id);
		}
	}
}

function decrementTime(comment_id){
	var obj;
	var val = enabled_edit_fields_time[comment_id];
	if(obj = document.getElementById('selViewTimerComment_'+comment_id)){
		obj.innerHTML = val-1;
		obj.innerHTML = obj.innerHTML+' Sec';
	}
	enabled_edit_fields_time[comment_id] = val-1;
}
function hideDeleteEditLinks(comment_id){
	var obj;
	var val = enabled_edit_fields_time[comment_id];
	if(obj = document.getElementById('selViewDeleteComment_'+comment_id))
		obj.style.display = 'none';
	if(obj = document.getElementById('selViewEditComment_'+comment_id))
		obj.style.display = 'none';
	if(obj = document.getElementById('selViewTimerComment_'+comment_id))
		obj.style.display = 'none';
	if(obj = document.getElementById('cmd'+comment_id))
		obj.className = 'clsNotEditable';
	enabled_edit_fields_time[comment_id] = null;
}
//timer for delete blogs End
function popupWindow(url){
	 window.open (url, "","status=0,toolbar=0,resizable=0,scrollbars=1");
	 return false;
}
function showUserInfoPopup(url, pars, divname){
	// reset timer
	resetUserInfoTimer();

	// close old layer
	if(divObj) divObj.style.display = 'none';

	// get new layer and show it
	divObj = document.getElementById(divname);
	if(divObj)
		divObj.style.display = '';

	// if content exists
	if ($(divname).innerHTML){
		return;
	}

	//if there is no content
	$(divname).innerHTML = processingSrc;
	ajaxUpdateDiv(url, pars, divname);
}
function hideUserInfoPopup(divname){
	closeUserPopupAndTimer();
	//if ($(divname))
		//hide(divname);
}
function ajaxFormSubmit(frmName, divname){
	var pars = $(frmName).serialize();
	var url = $(frmName).action;
	var myAjax = new Ajax.Updater(
									{success: divname},
									url,
									{
										method: 'post',
										parameters: pars
									});
}
function ajaxUpdateDiv(url, pars, divname){
	var myAjax = new Ajax.Updater(
									{success: divname},
									url,
									{
										method: 'post',
										parameters: pars
									});
}

function openUploadPage(url, pars){
	var myAjax = new Ajax.Request(
								url,
								{
								method: 'get',
								parameters: pars,
								onComplete: ajaxResultOpenUploadPage
								});
								return false;
}

function ajaxResultOpenUploadPage(originalRequest){
	data = originalRequest.responseText;
	Confirmation('video_add', 'selMsgConfirm', 'msgConfirmform', Array('selConfirmText'), Array(data), Array('innerHTML'), -25, -600);
	//alert(data);
}
function toggleElement(myDiv){
	var divObj = $(myDiv);
	if (divObj.style.display=='none')
		divObj.show();
	else
		divObj.hide();
}

function showAvatars(url, pars, divname){
	if ($('loadingAvatars1'))
		$('loadingAvatars1').innerHTML = processingSrc;
	if ($('loadingAvatars2'))
		$('loadingAvatars2').innerHTML = processingSrc;
	ajaxUpdateDiv(url, pars, divname);
}

var originalImageSrc = '';
function selectAvatar(avatarUrl){
	if (originalImageSrc == '')
		originalImageSrc = $('selUserImage').innerHTML;
	if (avatarUrl==0){
		$('selUserImage').innerHTML = originalImageSrc;
		document.form_edit_settings.avatar.value = '';
	}else{
		var posF = avatarUrl.indexOf('avatars/') + 8;
		avatarName = avatarUrl.substring(posF);

		$('selUserImage').innerHTML = '<p id="selImageBorder"><img src="'+avatarUrl+'" /></p>';
		document.form_edit_settings.avatar.value = avatarName;
	}
	document.form_edit_settings.photo.value = '';
}
function changeSheets(url, activeTitle, inactiveTitle, activeSheet){
  if(document.styleSheets){
    var c = document.styleSheets.length;
    for(var i=0;i<c;i++){
      if(document.styleSheets[i].title==inactiveTitle){
        document.styleSheets[i].disabled=true;
      }
	  if(document.styleSheets[i].title==activeTitle){
        document.styleSheets[i].disabled=false;

        Ajax.Responders.unregister(myGlobalHandlers);
		var pars = 'style='+activeSheet;
        var myAjax = new Ajax.Request(
									url,
									{
									method: 'get',
									parameters: pars
									});
      }
    }
  }
}
function changePopupDivPosition(popupDivId){
	var imgObjName = 'img'+popupDivId;
	var imgObj = $(imgObjName);
	var popupObj = $(popupDivId);
	var left = getAbsoluteOffsetLeftConfirmation(imgObj)-parseInt(popupPosition);
	popupObj.style.left = left + 'px';
}
