<?php
if ( !defined( 'SMARTY_DIR' ) ) {

	include_once( '../init.php' );
}
/* THis shuld be called as
	/cronjobs/speeddater_email.php?number=x
	x = the number of mail to be sent at each cron job run
	x is by default 100
*/

$installed = $db->getOne('select name from ! where name=? and active=?',array(PLUGIN_TABLE, 'speedDater','1') );
if (isset($installed) && $installed == 'speedDater') {

	$table=DB_PREFIX."_speeddater";
	$number=$_GET['number'];
	if(!$number) $number=100;

	$data=$db->getAll("SELECT * FROM ! WHERE sent=? ORDER BY id ASC LIMIT 0,!",array($table,0,$number));
	foreach ($data as $item)
	{
			$file=TEMP_DIR."speeddater/sd_{$item['ts']}_{$item['owner']}_{$item['friend']}.txt";
			$handle=fopen($file,"r");
			$content=fread($handle,filesize($file));
			fclose($handle);
			$mail=unserialize($content);
			unlink($file);

			$From= $mail['from'];

			$To = $mail['to'];

			$message = $mail['message'];

			$message = str_replace('#FirstName#', $user['firstname'] ,$message);

			$message = str_replace('#matchedProfiles#', $profs, $message);

			mailSender($From, $To, $To, $mail['subject'], $message);

			/* Don't bombard the mailer program */
			sleep(2);
			$db->query("UPDATE ! SET sent=? WHERE id=?",array($table,1,$item['id']));

	}
}
exit;
?>