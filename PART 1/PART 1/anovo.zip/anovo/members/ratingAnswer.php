<?php
require_once ('../common/config.inc.php');
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['db']['is_use_db'] = true;
$CFG['html']['is_use_header'] = false;
$CFG['html']['is_use_footer'] = false;
$CFG['http_headers']['is_cache'] = false;
$CFG['http_headers']['is_use_if_modified_since'] = false;
$CFG['is']['ajax_page'] = true;
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class AnswerRatingHandler extends FormHandler
{
		public function addQuestionRating($users_stared_question_table, $question_table, $users_ans_log_table, $ques_id, $user_id, $session_user_id, $cfg_project_path_relative, $relative_path)
		{
				$sql = 'SELECT rating FROM ' . $users_stared_question_table . ' WHERE ques_id = ' . $this->dbObj->Param($this->fields_arr['ques_id']) . ' AND user_id = ' . $this->dbObj->Param('user_id');
				$stmt = $this->dbObj->Prepare($sql);
				$result = $this->dbObj->Execute($stmt, array($this->fields_arr['qid'], $session_user_id));
				if (!$result) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$old_points = 0;
				$old_ratings = 0;
				$rating = 0;
				if ($result->PO_RecordCount())
				{
						$sql = 'UPDATE ' . $users_stared_question_table . ' SET rating=' . $this->dbObj->Param('rating') . ' WHERE ques_id=' . $this->dbObj->Param('qid') . ' AND user_id=' . $this->dbObj->Param('user_id');
						$field_values_arr[] = $this->fields_arr['rating'];
						$field_values_arr[] = $this->fields_arr['qid'];
						$field_values_arr[] = $session_user_id;
						$row = $result->FetchRow();
						$old_ratings = $row['rating'];
				}
				else
				{
						$sql = 'INSERT INTO ' . $users_stared_question_table . ' SET rating=' . $this->dbObj->Param('rating') . ', ques_id=' . $this->dbObj->Param('qid') . ', user_id=' . $this->dbObj->Param('user_id');
						$field_values_arr[] = $this->fields_arr['rating'];
						$field_values_arr[] = $this->fields_arr['qid'];
						$field_values_arr[] = $session_user_id;
				}
				$stmt = $this->dbObj->Prepare($sql);
				$result = $this->dbObj->Execute($stmt, $field_values_arr);
				if (!$result) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$sql = 'SELECT RPAD(AVG(rating),4,\'0\') as avg_rating FROM ' . $users_stared_question_table . ' WHERE ques_id = ' . $this->dbObj->Param('qid');
				$stmt = $this->dbObj->Prepare($sql);
				$result = $this->dbObj->Execute($stmt, array($this->fields_arr['qid']));
				if (!$result) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = $result->FetchRow();
				$avg_rating = $row['avg_rating'];
				$sql = 'UPDATE ' . $question_table . ' set total_stars = ' . $this->dbObj->Param($avg_rating) . ' WHERE ques_id = ' . $this->dbObj->Param('qid');
				$stmt = $this->dbObj->Prepare($sql);
				$result = $this->dbObj->Execute($stmt, array($avg_rating, $this->fields_arr['qid']));
				if (!$result) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$rating = $this->fields_arr['rating'];
				$increase_rating = $this->getPointsFromStars($rating);
				if ($old_ratings > 0)
				{
						$old_points = $this->getPointsFromStars($old_ratings);
				}
				$increase_rating = $increase_rating - $old_points;
				$sql = 'UPDATE ' . $users_ans_log_table . ' set total_points=total_points+' . $this->dbObj->Param('points') . ', date_updated=NOW() WHERE user_id = ' . $this->dbObj->Param('uid');
				$stmt = $this->dbObj->Prepare($sql);
				$result = $this->dbObj->Execute($stmt, array($increase_rating, $this->fields_arr['uid']));
				if (!$result) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$sql = 'SELECT COUNT(star_id) as cnt FROM ' . $users_stared_question_table . ' WHERE ques_id = ' . $this->dbObj->Param('qid');
				$stmt = $this->dbObj->Prepare($sql);
				$result = $this->dbObj->Execute($stmt, array($this->fields_arr['qid']));
				if (!$result) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = $result->FetchRow();
				$rating_count = $row['cnt'];
				$start = 1000;
				$end = 1000 + 4;
?>
<div class="blctitle">
	<div class="brctitle">
	<div class="tlctitle">
	<div class="trctitle">
		<p class="clsRatingImg">
		<span class="clsRateStars"><?php echo $this->LANG['your_rating']; ?>
<?php
				$pointer = 1;
				for ($i = $start; $i < $rating + $start; $i++)
				{
?>
						<img id="rate<?php echo ($i + 1); ?>" src="<?php echo $cfg_project_path_relative; ?>images/icon-ratehover.gif" alt="<?php echo ($i + 1); ?>" onMouseOver="mouseOverAnswers(<?php echo ($i + 1); ?>, <?php echo $start; ?>, '<?php echo $cfg_project_path_relative; ?>images/icon-ratehover.gif', '<?php echo $cfg_project_path_relative; ?>images/icon-rate.gif');" onMouseOut="mouseOutAnswers(<?php echo $start; ?>);" onClick="getQuestionRatingDetails('<?php echo $relative_path; ?>ratingAnswer.php', 'action=question&qid=<?php echo $ques_id; ?>&uid=<?php echo $user_id; ?>&rating=<?php echo ($pointer); ?>', 'selQuestionRatingContent');" />
<?php
						$pointer++;
				}
				for ($j = $i; $j < $end; $j++)
				{
?>
						<img id="rate<?php echo ($j + 1); ?>" src="<?php echo $cfg_project_path_relative; ?>images/icon-rate.gif" alt="<?php echo ($j + 1); ?>" onMouseOver="mouseOverAnswers(<?php echo ($i + 1); ?>, <?php echo $start; ?>, '<?php echo $cfg_project_path_relative; ?>images/icon-ratehover.gif', '<?php echo $cfg_project_path_relative; ?>images/icon-rate.gif');" onMouseOut="mouseOutAnswers(<?php echo $start; ?>);" onClick="getQuestionRatingDetails('<?php echo $relative_path; ?>ratingAnswer.php', 'action=question&qid=<?php echo $ques_id; ?>&uid=<?php echo $user_id; ?>&rating=<?php echo ($pointer); ?>', 'selQuestionRatingContent');" />
<?php
						$pointer++;
				}
?></span>
		<span class="clsRateScores"><?php echo $this->LANG['average_rating']; ?>
<?php
?><span class="clsScore"><?php echo $avg_rating; ?> / <?php echo $rating_count; ?></span>
		 <?php echo $this->LANG['ratings']; ?>
</span>
	</p>
	</div>
	</div>
          </div>
        </div>
<?php
		}
		public function addAnswerRating($users_stared_answer_table, $answers_table, $users_ans_log_table, $ans_id, $user_id, $session_user_id, $cfg_project_path_relative, $relative_path, $id_cnt)
		{
				$sql = 'SELECT rating FROM ' . $users_stared_answer_table . ' WHERE ans_id = ' . $this->dbObj->Param($this->fields_arr['ans_id']) . ' AND user_id = ' . $this->dbObj->Param('user_id');
				$stmt = $this->dbObj->Prepare($sql);
				$result = $this->dbObj->Execute($stmt, array($this->fields_arr['aid'], $session_user_id));
				if (!$result) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$old_points = 0;
				$old_ratings = 0;
				$rating = 0;
				if ($result->PO_RecordCount())
				{
						$sql = 'UPDATE ' . $users_stared_answer_table . ' SET rating=' . $this->dbObj->Param('rating') . ' WHERE ans_id=' . $this->dbObj->Param('aid') . ' AND user_id=' . $this->dbObj->Param('user_id');
						$field_values_arr[] = $this->fields_arr['rating'];
						$field_values_arr[] = $this->fields_arr['aid'];
						$field_values_arr[] = $session_user_id;
						$row = $result->FetchRow();
						$old_ratings = $row['rating'];
				}
				else
				{
						$sql = 'INSERT INTO ' . $users_stared_answer_table . ' SET rating=' . $this->dbObj->Param('rating') . ', ans_id=' . $this->dbObj->Param('aid') . ', user_id=' . $this->dbObj->Param('user_id');
						$field_values_arr[] = $this->fields_arr['rating'];
						$field_values_arr[] = $this->fields_arr['aid'];
						$field_values_arr[] = $session_user_id;
				}
				$stmt = $this->dbObj->Prepare($sql);
				$result = $this->dbObj->Execute($stmt, $field_values_arr);
				if (!$result) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$sql = 'SELECT RPAD(AVG(rating),4,\'0\') as avg_rating FROM ' . $users_stared_answer_table . ' WHERE ans_id = ' . $this->dbObj->Param('aid');
				$stmt = $this->dbObj->Prepare($sql);
				$result = $this->dbObj->Execute($stmt, array($this->fields_arr['aid']));
				if (!$result) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = $result->FetchRow();
				$avg_rating = $row['avg_rating'];
				$sql = 'UPDATE ' . $answers_table . ' set total_stars = ' . $this->dbObj->Param($avg_rating) . ' WHERE ans_id = ' . $this->dbObj->Param('aid');
				$stmt = $this->dbObj->Prepare($sql);
				$result = $this->dbObj->Execute($stmt, array($avg_rating, $this->fields_arr['aid']));
				if (!$result) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$rating = $this->fields_arr['rating'];
				$increase_rating = $this->getPointsFromStars($rating);
				if ($old_ratings > 0)
				{
						$old_points = $this->getPointsFromStars($old_ratings);
				}
				$increase_rating = $increase_rating - $old_points;
				$sql = 'UPDATE ' . $users_ans_log_table . ' set total_points=total_points+' . $this->dbObj->Param('points') . ', date_updated=NOW() WHERE user_id = ' . $this->dbObj->Param('uid');
				$stmt = $this->dbObj->Prepare($sql);
				$result = $this->dbObj->Execute($stmt, array($increase_rating, $this->fields_arr['uid']));
				if (!$result) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$sql = 'SELECT COUNT(star_id) as cnt FROM ' . $users_stared_answer_table . ' WHERE ans_id = ' . $this->dbObj->Param('aid');
				$stmt = $this->dbObj->Prepare($sql);
				$result = $this->dbObj->Execute($stmt, array($this->fields_arr['aid']));
				if (!$result) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = $result->FetchRow();
				$rating_count = $row['cnt'];
				$start = $id_cnt;
				$end = $id_cnt + 4;
?>
<div class="blctitle">
	<div class="brctitle">
	<div class="tlctitle">
	<div class="trctitle">
		<p class="clsRatingImg">
		<span class="clsRateStars"><?php echo $this->LANG['your_rating']; ?>
<?php
				$pointer = 1;
				for ($i = $start; $i < $rating + $start; $i++)
				{
?>
						<img id="rate<?php echo ($i + 1); ?>" src="<?php echo $cfg_project_path_relative; ?>images/icon-ratehover.gif" alt="<?php echo ($i + 1); ?>" onMouseOver="mouseOverAnswers(<?php echo ($i + 1); ?>, <?php echo $start; ?>, '<?php echo $cfg_project_path_relative; ?>images/icon-ratehover.gif', '<?php echo $cfg_project_path_relative; ?>images/icon-rate.gif');" onMouseOut="mouseOutAnswers(<?php echo $start; ?>);" onClick="getRatingDetails('<?php echo $relative_path; ?>ratingAnswer.php', 'action=answers&aid=<?php echo $ans_id; ?>&uid=<?php echo $user_id; ?>&rating=<?php echo ($pointer); ?>&id_cnt=<?php echo ($id_cnt); ?>', 'selAnswersRatingContent<?php echo $id_cnt; ?>');" />
<?php
						$pointer++;
				}
				for ($j = $i; $j < $end; $j++)
				{
?>
						<img id="rate<?php echo ($j + 1); ?>" src="<?php echo $cfg_project_path_relative; ?>images/icon-rate.gif" alt="<?php echo ($j + 1); ?>" onMouseOver="mouseOverAnswers(<?php echo ($i + 1); ?>, <?php echo $start; ?>, '<?php echo $cfg_project_path_relative; ?>images/icon-ratehover.gif', '<?php echo $cfg_project_path_relative; ?>images/icon-rate.gif');" onMouseOut="mouseOutAnswers(<?php echo $start; ?>);" onClick="getRatingDetails('<?php echo $relative_path; ?>ratingAnswer.php', 'action=answers&aid=<?php echo $ans_id; ?>&uid=<?php echo $user_id; ?>&rating=<?php echo ($pointer); ?>&id_cnt=<?php echo ($id_cnt); ?>', 'selAnswersRatingContent<?php echo $id_cnt; ?>');" />
<?php
						$pointer++;
				}
?></span>
		<span class="clsRateScores"><?php echo $this->LANG['average_rating']; ?>
<?php
?><span class="clsScore"><?php echo $avg_rating; ?> / <?php echo $rating_count; ?></span>
		 <?php echo $this->LANG['ratings']; ?>
</span>
	</p>
	</div>
	</div>
          </div>
        </div>
<?php
		}
		public function addBlogRating($users_stared_blog_table, $blog_table, $blog_id, $user_id, $session_user_id, $cfg_project_path_relative, $relative_path)
		{
				$sql = 'SELECT rating FROM ' . $users_stared_blog_table . ' WHERE blog_id = ' . $this->dbObj->Param($this->fields_arr['blog_id']) . ' AND user_id = ' . $this->dbObj->Param('user_id');
				$stmt = $this->dbObj->Prepare($sql);
				$result = $this->dbObj->Execute($stmt, array($this->fields_arr['blog_id'], $session_user_id));
				if (!$result) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$rating = 0;
				if ($result->PO_RecordCount())
				{
						$sql = 'UPDATE ' . $users_stared_blog_table . ' SET rating=' . $this->dbObj->Param('rating') . ' WHERE blog_id=' . $this->dbObj->Param('blog_id') . ' AND user_id=' . $this->dbObj->Param('user_id');
						$field_values_arr[] = $this->fields_arr['rating'];
						$field_values_arr[] = $this->fields_arr['blog_id'];
						$field_values_arr[] = $session_user_id;
				}
				else
				{
						$sql = 'INSERT INTO ' . $users_stared_blog_table . ' SET rating=' . $this->dbObj->Param('rating') . ', blog_id=' . $this->dbObj->Param('blog_id') . ', user_id=' . $this->dbObj->Param('user_id');
						$field_values_arr[] = $this->fields_arr['rating'];
						$field_values_arr[] = $this->fields_arr['blog_id'];
						$field_values_arr[] = $session_user_id;
				}
				$stmt = $this->dbObj->Prepare($sql);
				$result = $this->dbObj->Execute($stmt, $field_values_arr);
				if (!$result) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$sql = 'SELECT RPAD(AVG(rating),4,\'0\') as avg_rating FROM ' . $users_stared_blog_table . ' WHERE blog_id = ' . $this->dbObj->Param('blog_id');
				$stmt = $this->dbObj->Prepare($sql);
				$result = $this->dbObj->Execute($stmt, array($this->fields_arr['blog_id']));
				if (!$result) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = $result->FetchRow();
				$avg_rating = $row['avg_rating'];
				$sql = 'UPDATE ' . $blog_table . ' set total_stars = ' . $this->dbObj->Param($avg_rating) . ' WHERE blog_id = ' . $this->dbObj->Param('blog_id');
				$stmt = $this->dbObj->Prepare($sql);
				$result = $this->dbObj->Execute($stmt, array($avg_rating, $this->fields_arr['blog_id']));
				if (!$result) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$rating = $this->fields_arr['rating'];
				$sql = 'SELECT COUNT(star_id) as cnt FROM ' . $users_stared_blog_table . ' WHERE blog_id = ' . $this->dbObj->Param('blog_id');
				$stmt = $this->dbObj->Prepare($sql);
				$result = $this->dbObj->Execute($stmt, array($this->fields_arr['blog_id']));
				if (!$result) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = $result->FetchRow();
				$rating_count = $row['cnt'];
				$start = 1000;
				$end = 1000 + 4;
?>
<div class="blctitle">
	<div class="brctitle">
	<div class="tlctitle">
	<div class="trctitle">
		<p class="clsRatingImg">
		<span class="clsRateStars"><?php echo $this->LANG['your_rating']; ?>
<?php
				$pointer = 1;
				for ($i = $start; $i < $rating + $start; $i++)
				{
?>
						<img id="rate<?php echo ($i + 1); ?>" src="<?php echo $cfg_project_path_relative; ?>images/icon-ratehover.gif" alt="<?php echo ($i + 1); ?>" onMouseOver="mouseOverAnswers(<?php echo ($i + 1); ?>, <?php echo $start; ?>, '<?php echo $cfg_project_path_relative; ?>images/icon-ratehover.gif', '<?php echo $cfg_project_path_relative; ?>images/icon-rate.gif');" onMouseOut="mouseOutAnswers(<?php echo $start; ?>);" onClick="getQuestionRatingDetails('<?php echo $relative_path; ?>ratingAnswer.php', 'action=blogs&blog_id=<?php echo $blog_id; ?>&uid=<?php echo $user_id; ?>&rating=<?php echo ($pointer); ?>', 'selBlogRatingContent');" />
<?php
						$pointer++;
				}
				for ($j = $i; $j < $end; $j++)
				{
?>
						<img id="rate<?php echo ($j + 1); ?>" src="<?php echo $cfg_project_path_relative; ?>images/icon-rate.gif" alt="<?php echo ($j + 1); ?>" onMouseOver="mouseOverAnswers(<?php echo ($i + 1); ?>, <?php echo $start; ?>, '<?php echo $cfg_project_path_relative; ?>images/icon-ratehover.gif', '<?php echo $cfg_project_path_relative; ?>images/icon-rate.gif');" onMouseOut="mouseOutAnswers(<?php echo $start; ?>);" onClick="getQuestionRatingDetails('<?php echo $relative_path; ?>ratingAnswer.php', 'action=blogs&blog_id=<?php echo $blog_id; ?>&uid=<?php echo $user_id; ?>&rating=<?php echo ($pointer); ?>', 'selBlogRatingContent');" />
<?php
						$pointer++;
				}
?></span>
		<span class="clsRateScores"><?php echo $this->LANG['average_rating']; ?>
<?php
?><span class="clsScore"><?php echo $avg_rating; ?> / <?php echo $rating_count; ?></span>
		 <?php echo $this->LANG['ratings']; ?>
</span>
	</p>
	</div>
	</div>
          </div>
        </div>
<?php
		}
		public function getPointsFromStars($ratings)
		{
				$points_for_stars = 0;
				switch ($ratings)
				{
						case 1:
								$points_for_stars = $this->CFG['admin']['single_star']['points'];
								break;
						case 2:
								$points_for_stars = $this->CFG['admin']['two_stars']['points'];
								break;
						case 3:
								$points_for_stars = $this->CFG['admin']['three_stars']['points'];
								break;
						case 4:
								$points_for_stars = $this->CFG['admin']['four_stars']['points'];
								break;
				}
				return $points_for_stars;
		}
}
$answerRating = new AnswerRatingHandler();
$answerRating->setDBObject($db);
$answerRating->makeGlobalize($CFG, $LANG);
$answerRating->setFormField('action', '');
$answerRating->setFormField('aid', '');
$answerRating->setFormField('qid', '');
$answerRating->setFormField('blog_id', '');
$answerRating->setFormField('uid', '');
$answerRating->setFormField('rating', '');
$answerRating->setFormField('id_cnt', '');
if ($answerRating->isFormGETed($_GET, 'action'))
{
		$answerRating->sanitizeFormInputs($_GET);
		switch ($answerRating->getFormField('action'))
		{
				case 'answers':
						if ($answerRating->getFormField('aid') and $answerRating->getFormField('uid') and $answerRating->getFormField('rating'))
						{
								$answerRating->setFormField('ans_id', $answerRating->getFormField('aid'));
								$answerRating->setFormField('user_id', $answerRating->getFormField('uid'));
								$answerRating->addAnswerRating($CFG['db']['tbl']['users_stared_answer'], $CFG['db']['tbl']['answers'], $CFG['db']['tbl']['users_ans_log'], $answerRating->getFormField('aid'), $answerRating->getFormField('uid'), $CFG['user']['user_id'], $CFG['site']['project_path_relative'], $CFG['site']['relative_url'], $answerRating->getFormField('id_cnt'));
						}
						break;
				case 'question':
						if ($answerRating->getFormField('qid') and $answerRating->getFormField('uid') and $answerRating->getFormField('rating'))
						{
								$answerRating->setFormField('ques_id', $answerRating->getFormField('qid'));
								$answerRating->setFormField('user_id', $answerRating->getFormField('uid'));
								$answerRating->addQuestionRating($CFG['db']['tbl']['users_stared_question'], $CFG['db']['tbl']['questions'], $CFG['db']['tbl']['users_ans_log'], $answerRating->getFormField('qid'), $answerRating->getFormField('uid'), $CFG['user']['user_id'], $CFG['site']['project_path_relative'], $CFG['site']['relative_url']);
						}
						break;
				case 'blogs':
						if ($answerRating->getFormField('blog_id') and $answerRating->getFormField('uid') and $answerRating->getFormField('rating'))
						{
								$answerRating->setFormField('blog_id', $answerRating->getFormField('blog_id'));
								$answerRating->setFormField('user_id', $answerRating->getFormField('uid'));
								$answerRating->addBlogRating($CFG['db']['tbl']['users_stared_blogs'], $CFG['db']['tbl']['blogs'], $answerRating->getFormField('blog_id'), $answerRating->getFormField('uid'), $CFG['user']['user_id'], $CFG['site']['project_path_relative'], $CFG['site']['relative_url']);
						}
						break;
		}
}
die();
require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>
