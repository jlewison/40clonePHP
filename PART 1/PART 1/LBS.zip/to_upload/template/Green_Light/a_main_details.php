<?php include('template/Green_Light/b_inside_top.php');?>

<td valign="top">

<script type="text/javascript">
<!--
function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}
//-->
</script>

<!--TITLE START -->
<div class="page-header"><h1><?php echo("$lang_101");?></h1></div>
<!--TITLE END -->

<!--MIDDLE BOX START -->

<div class="box" style="margin-left:10px">
	<div class="dbox_top"></div>
	<div class="dbox_middle1">

<table border="0" cellpadding="4" cellspacing="4">
  <tr>
    <td colspan="2"><a href="<?php echo $row_UPBID['site']; ?>" target="_blank">
    <!--<img src="http://services.velnetweb.co.uk/screenshot/screenshot.php?domainname=<?php echo("$domainname");?>&domain=<?php echo $row_UPBID['site']; ?>" alt="<?php echo $row_UPBID['title']; ?>" border="0" /> -->
    <img src="http://open.thumbshots.org/image.aspx?url=<?php echo $row_UPBID['site']; ?>" border="1" alt="<?php echo $row_UPBID['title']; ?>" /> 
    
    </a></td>
  </tr>
<?php if($fremode == 'N') { ?> 
  <tr>
    <td colspan="2"><?php echo $row_UPBID['bid']; ?> <?php echo("$lang_29");?></td>
  </tr>
  <tr>
    <td colspan="2"><?php echo("$lang_8");?><a href="<?php echo("$path");?>upgrade.php?ucat=<?php echo $row_UPBID['dtu']; ?>" title="Upgrade Listing!"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/upgrade.gif" alt="Upgrade Listing!" border="0" /></a></td>
  </tr>
<?php } else { } ?>
  <tr>
    <td colspan="2" class="bid-title"><a href="<?php echo $row_UPBID['site']; ?>" target="_blank"><?php echo $row_UPBID['title']; ?></a><br /> <?php echo $row_UPBID['descr2']; ?> <br />
      <br />URL: <a href="<?php echo $row_UPBID['site']; ?>" target="_blank"><?php echo $row_UPBID['site']; ?></a><br />
      <br />
<?php 
if($google_m == 'Y') { ?>
[<a href="#" onclick="MM_openBrWindow('<?php echo("$path");?>google_map.php?dtu=<?php echo $row_UPBID['dtu']; ?>','googlemap','width=500,height=300')"><?php echo("$lang_94");?></a>] <br />
<?php }
else {}
?>      </td>
  </tr>
  <tr>
    <td colspan="2"><strong><?php echo("$lang_95");?>: </strong><a href="<?php echo("$path");?><?php echo $row_LdetCAT['categseoname']; ?>/"><?php echo $row_LdetCAT['categoryname'] ?></a></td>
  </tr>
  <?php if($prenabled == 'Y') { ?>
  <tr>
    <td colspan="2"><strong><?php echo("$lang_100");?>:</strong>
      <?php
			$sitewww = $row_UPBID['site'];
			$sitewwwA = str_replace("http://", "", $sitewww);
			$googlepagerankA = "$sitewwwA";
			$sitewwwB = str_replace("/", "", $googlepagerankA);
			$googlepagerankB = "$sitewwwB";
			?>
    <img src="http://services.velnetweb.co.uk/gpr/gpr.php?sitepr=<?php echo("$sitewww");?>" border="0"></td>
  </tr>
  <?php } else {} ?>
  <tr>
    <td colspan="2"><strong><?php echo("$lang_96");?>:</strong> <?php echo $row_UPBID['stad']; ?></td>
  </tr>
<?php if($fremode == 'N') { ?>
  <tr>
    <td colspan="2"><strong><?php echo("$lang_97");?>:</strong> <?php echo $row_UPBID['stup']; ?></td>
  </tr>
<?php } else { } ?>
  <tr>
    <td colspan="2"><?php echo("$lang_98");?> <?php echo $row_UPBID['title']; ?>: <strong> <a href="<?php echo $row_UPBID['dfurl']; ?>" target="_blank"><?php echo $row_UPBID['deeptf']; ?></a> <a href="<?php echo $row_UPBID['dsurl']; ?>" target="_blank"><?php echo $row_UPBID['deepts']; ?></a> <a href="<?php echo $row_UPBID['dturl']; ?>" target="_blank"><?php echo $row_UPBID['deeptt']; ?></a></strong></td>
  </tr>
  <?php if(($deepenable == 'Y') && ($row_UPBID['deeptf'] != '')) { ?>
  
  <?php } else {} ?>



  <tr>
    <td colspan="2"><hr /></td>
    </tr>
  <tr>
    <td>
	
<?php if($prenabled == 'Y' and $enb_details == 'Y') { ?>
<?php include('pr_update_details.php');?>


    <strong><?php echo("$lang_99");?>:</strong><br />
    <br />

    <?php if($enb_google == 'Y') { ?>
	    <img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/googleIcon.gif" /> <?php echo $row_UPBID['google']; ?>
    <?php } else {} ?><br />


    <?php if($enb_yahoo == 'Y') { ?>
	    <img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/yahooIcon.gif" /> <?php echo $row_UPBID['yahoo']; ?>
    <?php } else {} ?><br />


    <?php if($enb_msn == 'Y') { ?>
	    <img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/msnIcon.gif" /> <?php echo $row_UPBID['msn']; ?>
    <?php } else {} ?><br />


    <?php if($enb_alexa == 'Y') { ?>
	    <img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/alexaIcon.gif" /> <?php echo $row_UPBID['alexa']; ?>
    <?php } else {} ?><br />



<?php } else {} ?>	</td>
    <td><img src="http://traffic.alexa.com/graph?a=1&w=280&h=160&r=1m&u=<?php echo $row_UPBID['site']; ?>" alt="" name="alexa" border="0" /></td>
  </tr>
</table>








	</div>
	<div class="dbox_bottom">
		<div style="padding:8px 100px 0 0">
			<?php if($fremode == 'N') { ?><a href="<?php echo("$path");?>upgrade.php?ucat=<?php echo $row_UPBID['dtu']; ?>" title="Upgrade Listing!">Upgrade</a><?php } else { } ?>
		</div>
	</div>
</div>

<!--MIDDLE BOX END -->























<div class="bks-right" style="margin-left:10px">
<div class="bks-left">
<div class="bookmarks"><div class="lbl">Bookmark this site: </div>
	<ul>
		<li><a target="_blank" rel="nofollow" href="http://digg.com/submit?phase=2&url=<?php echo $row_UPBID['site']; ?>&title=<?php echo $row_UPBID['title']; ?>&bodytext=<?php echo $row_UPBID['descr1']; ?> <?php echo $row_UPBID['descr2']; ?>" title="Digg It!"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/diggIcon.gif" alt="Digg It!" border="0" /></a></li>
		<li><a target="_blank" rel="nofollow" href="http://del.icio.us/post?url=<?php echo $row_UPBID['site']; ?>&title=<?php echo $row_UPBID['title']; ?>&notes=<?php echo $row_UPBID['descr1']; ?> <?php echo $row_UPBID['descr2']; ?>"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/deliciousIcon.gif" alt="Del.icio.us" border="0" /></a></li>
		<li><a target="_blank" rel="nofollow" href="http://www.stumbleupon.com/submit?url=<?php echo $row_UPBID['site']; ?>&title=<?php echo $row_UPBID['title']; ?>"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/stumbleuponIcon.gif" alt="StumbleUpon" border="0" /></a></li>
		<li><a target="_blank" rel="nofollow" href="http://www.google.com/bookmarks/mark?op=edit&bkmk=<?php echo $row_UPBID['site']; ?>&title=<?php echo $row_UPBID['title']; ?>"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/googleIcon.gif" alt="Google Bookmarks" border="0" /></a></li>
		<li><a target="_blank" rel="nofollow" href="http://myweb2.search.yahoo.com/myresults/bookmarklet?u=<?php echo $row_UPBID['site']; ?>&t=<?php echo $row_UPBID['title']; ?>"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/yahooIcon.gif" alt="Yahoo! Bookmarklet" border="0" /></a></li>
		<li><a target="_blank" rel="nofollow" href="http://myweb2.search.yahoo.com/myresults/bookmarklet?u=<?php echo $row_UPBID['site']; ?>&t=<?php echo $row_UPBID['title']; ?>"></a></li>
		<li><a target="_blank" rel="nofollow" href="http://www.furl.net/storeIt.jsp?u=<?php echo $row_UPBID['site']; ?>&t=<?php echo $row_UPBID['title']; ?>"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/furlIcon.gif" alt="Furl" border="0" /></a></li>
		<li><a target="_blank" rel="nofollow" href="http://reddit.com/submit?url=<?php echo $row_UPBID['site']; ?>&title=<?php echo $row_UPBID['title']; ?>"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/redditIcon.gif" alt="reddit" border="0" /></a></li>
		<li><a target="_blank" rel="nofollow" href="http://technorati.com/cosmos/search.html?url=<?php echo $row_UPBID['site']; ?>"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/technoratiIcon.gif" alt="Technorati" border="0" /></a></li>
		<li><a target="_blank" rel="nofollow" href="http://www.blinklist.com/index.php?Action=Blink/addblink.php&Description=&Url=<?php echo $row_UPBID['site']; ?>&Title=<?php echo $row_UPBID['title']; ?>" title="Blink It!"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/blinklistIcon.gif" alt="Blink It!" border="0" /></a></li>
		<li><a target="_blank" rel="nofollow" href="http://www.plugim.com/submit?url=<?php echo $row_UPBID['site']; ?>&title=<?php echo $row_UPBID['title']; ?>&trackback=" title="PlugIm!"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/plugimIcon.gif" alt="PlugIm!" border="0" /></a></li>
		<li><a target="_blank" rel="nofollow" href="http://co.mments.com/track?url=<?php echo $row_UPBID['site']; ?>&title=<?php echo $row_UPBID['title']; ?>"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/commentsIcon.gif" alt="co.mments" border="0" /></a></li>
		<li><a target="_blank" rel="nofollow" href="http://www.newsvine.com/_tools/seed&save?u=<?php echo $row_UPBID['site']; ?>&h=<?php echo $row_UPBID['title']; ?>"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/newsvineIcon.gif" alt="Newsvine" border="0" /></a></li>
		<li><a target="_blank" rel="nofollow" href="http://www.netscape.com/submit/?U=<?php echo $row_UPBID['site']; ?>&T=<?php echo $row_UPBID['title']; ?>"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/netscapeIcon.gif" alt="Netscape" border="0" /></a></li>
		<li><a target="_blank" rel="nofollow" href="http://ma.gnolia.com/bookmarklet/add?url=<?php echo $row_UPBID['site']; ?>&title=<?php echo $row_UPBID['title']; ?>"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/magnoliaIcon.gif" alt="Ma.gnolia.com" border="0" /></a></li>
		<li><a target="_blank" rel="nofollow" href="http://www.simpy.com/simpy/LinkAdd.do?href=<?php echo $row_UPBID['site']; ?>&title=<?php echo $row_UPBID['title']; ?>" title="Simpify!"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/simpyIcon.gif" alt="Simpify!" border="0" /></a></li>
		<li><a target="_blank" rel="nofollow" href="http://www.spurl.net/spurl.php?url=<?php echo $row_UPBID['site']; ?>&title=<?php echo $row_UPBID['title']; ?>"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/spurlIcon.gif" alt="Spurl.net" border="0" /></a></li>
	</ul>
</div>
</div>
</div>

<!--
###################################################################################
#######################                                     #######################
#######################    M A I N   S E C T I O N   End    #######################
#######################                                     #######################
###################################################################################
-->


<?php include('template/Green_Light/b_footer_tpl.php'); ?>