
JP1   = "100000&100000&200000&4&5&6&7&8&9&10&11&12&13&14&15&16&".split("&");
Inc1  = "5&1&1&1&1&5&1&1&1&6&1&1&1&1&10&4&15&6&".split("&");
LastUpdate="1&2&3&4&5&6&7&8&9&10&11&12&13&14&15&16&17&18&".split("&");
NumberOfProgr = 18;
JP  = new Array(18);
Inc = new Array(18);

for (i = 18-1; i>=0; i--) { // shift
	JP[i+1] = parseInt(JP1[i])+parseInt(Inc1[i])*(100-LastUpdate[i]);
	Inc[i+1] = Inc1[i];
}
for (i=1;i <= 18;i++){
	JP[i]=parseInt(JP[i]);
	Inc[i]=parseInt(Inc[i]);
	if (Inc[i] < 0) Inc[i] = 0;
}

/////////////////////////////////////////////////////////////

function num2dollar(field){
   var tmp1 = cents = dollars = "";
   var dec = -1;
   var num,i;

   num = "" + (Math.round(field * 100)/100);
   dec = num.indexOf(".");

   cents = ((dec > 0) ? num.substring(dec,num.length) : ".00");
   if (cents.length == 2) cents += "0";

   dollars = "" + parseInt(num);
   tmp1 = insComma(dollars);
   num = String.fromCharCode("36");
   for (i = tmp1.length-1; i >= 0; i--)
   num += tmp1.charAt(i);;
   num +=  cents + "";

   return num;
}

function insComma(data){
   var count = i = 0;
   var tmpStr = "";
   var comma = ",";

   for (i = data.length-1; i >= 0; i--)
   {
      if (count == 3)
      {
         tmpStr += comma;
         count = 1;
      }
      else  count ++;
      tmpStr += data.charAt(i);
   }
   return(tmpStr);
}

/////////////////////////////////////////////////////////////

function J_jumpMenu(selObj,restore){ //Jacob version of MM_jumpMenu

    if(selObj.selectedIndex) window.open(selObj.options[selObj.selectedIndex].value,"casino");

 	if (restore) selObj.selectedIndex=0;

}

function ScrollProgressiveCounters(prId){

	//var objstr = "document.forms['jpform"+prId+"'].elements['progressive"+prId+"']";
// var objstr = "document.all('progressive"+prId+"')";
 var objstr = "document.getElementById('progressive"+prId+"')";

	var obj = eval(objstr);

	if (obj) {

		JP[prId] += (Inc[prId]);	

		obj.value = num2dollar(JP[prId]/100);

	}

	window.setTimeout( "ScrollProgressiveCounters("+prId+")",1000); 

}