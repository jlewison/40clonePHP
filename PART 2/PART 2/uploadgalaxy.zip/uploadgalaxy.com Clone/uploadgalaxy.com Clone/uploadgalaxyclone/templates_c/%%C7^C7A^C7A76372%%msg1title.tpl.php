<?php /* Smarty version 2.6.6, created on 2006-02-01 09:53:09
         compiled from msg1title.tpl */ ?>
Megaupload becomes fairer, faster and introduces Uploader Rewards.