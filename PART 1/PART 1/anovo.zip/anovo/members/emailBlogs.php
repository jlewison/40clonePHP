<?php
require_once ('../common/config.inc.php');
$CFG['lang']['include_files'][] = 'members/includes/languages/%s/emailBlogs.php';
$CFG['html']['header'] = 'members/includes/languages/%s/html_header.php';
$CFG['html']['footer'] = 'members/includes/languages/%s/html_footer.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['lang']['include_files'][] = 'common/email_templates/languages/%s/email_notify.inc.php';
$CFG['lang']['include_files'][] = 'common/languages/%s/help.inc.php';
$CFG['lang']['include_files'][] = 'common/configs/config_article.inc.php';
$CFG['html']['is_use_header'] = false;
$CFG['html']['is_use_footer'] = false;
$CFG['is']['ajax_page'] = true;
if ($_POST) $CFG['mods']['include_files'][] = 'common/classes/phpmailer/class_PHPMailer.lib.php';
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
require ('../general/emailBlogs.php');
?>