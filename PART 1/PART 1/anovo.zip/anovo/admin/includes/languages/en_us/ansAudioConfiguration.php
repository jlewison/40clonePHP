<?php
$LANG['Serial NumberToolTip'] = 'Track';
$LANG['Album NameToolTip'] = 'Title';
$LANG['StopToolTip'] = 'Stop';
$LANG['PlayToolTip'] = 'Play';
$LANG['PauseToolTip'] = 'Pause';
$LANG['Tack sequenceToolTip'] = 'Tack sequence';
$LANG['VolToolTip'] = 'Volume';
$LANG['Drag playerToolTip'] = 'Drag player';
$LANG['LastToolTip'] = 'Last';
$LANG['FirstToolTip'] = 'First';
$LANG['OpenToolTip'] = 'Open';
$LANG['CloseToolTip'] = 'Close';
$LANG['NextToolTip'] = 'Next';
$LANG['PreviousToolTip'] = 'Previous';
$LANG['MuteToolTip'] = 'Mute';
$LANG['UnMuteToolTip'] = 'Un Mute';
$LANG['Open Play ListToolTip'] = 'Open Play List';
$LANG['Close Play ListToolTip'] = 'Close Play List';
$LANG['MinimizeToolTip'] = 'Minimize';
$LANG['HelpToolTip'] = 'Help';
$LANG['RepeatToolTip'] = 'Repeat';
$LANG['ShuffleToolTip'] = 'Shuffle';
$LANG['UpToolTip'] = 'Up';
$LANG['DownToolTip'] = 'Down';
$LANG['IjiggToolTip'] = 'goto ijigg';
$LANG['IikeIjiggToolTip'] = 'Ijigg It if you like it!';
?>