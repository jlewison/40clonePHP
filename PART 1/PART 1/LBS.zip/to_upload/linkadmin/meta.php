<?php include('restrict.php'); include('../settings.php'); require_once('../Connections/apound.php'); ?>
<?php
mysql_select_db($database_apound, $apound);
$query_MET = "SELECT * FROM meta";
$MET = mysql_query($query_MET, $apound) or die(mysql_error());
$row_MET = mysql_fetch_assoc($MET);
$totalRows_MET = mysql_num_rows($MET);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>Meta Tags Management - Link Bid Script Admin Panel</title>
<link rel="shortcut icon" href="img/favicon.ico" />
<link rel="stylesheet" type="text/css" href="admin.css" />
<style type="text/css">
<!--
.style84 {color: #FF0000}
.style85 {font-size: 12px}
#admnav li {
	padding-top: 0px;
	padding-bottom: 0px;
	margin-top: 0px;
	margin-bottom: 0px;
}
#admnav ul {
	padding-top: 0px;
	padding-bottom: 0px;
	margin-top: 0px;
	margin-bottom: 0px;
}
.style86 {
	color: #CC0000;
	text-decoration: none;
}
-->
</style>
</head>

<body>
<?php $x = getenv("HTTP_HOST").getenv("REQUEST_URI"); ?>
<?php include('header_tpl.php'); ?>

<h2>Meta Tags Management</h2>
<?php $upd = $_GET[upd]; if($upd == 'Y') { echo("<div align='center'><font color='red'><b>Update ... DONE</b></font></div>"); } else { } ?>
<table width="770"  border="0" align="center" cellpadding="3" cellspacing="1" bgcolor="#FFFFFF">
  <tr>
    <td width="760" valign="top"><table width="100%" border="0" cellpadding="3" cellspacing="3">
        <tr bgcolor="#FFFF00" class="style80">
          <td width="5%" align="center">ID</td>
          <td width="15%">Page Name</td>
          <td width="20%">Page Title</td>
          <td width="20%" align="center">Page Keywords</td>
          <td width="25%" align="center">Page Description</td>
          <td width="10%" align="center">Edit</td>
          </tr>
  <?php do { ?>
        <tr class="style70">
          <td align="center" style="border-right:1px solid #999999;"><?php echo $row_MET['m_id']; ?></td>
          <td style="border-right:1px solid #999999;"><?php echo $row_MET['m_page']; ?></td>
          <td style="border-right:1px solid #999999;"><?php echo $row_MET['m_title']; ?></td>
          <td style="border-right:1px solid #999999;"><?php echo $row_MET['m_keyword']; ?></td>
          <td style="border-right:1px solid #999999;"><?php echo $row_MET['m_description']; ?></td>
          <td align="center"><a href="meta_edit.php?m_id=<?php echo $row_MET['m_id']; ?>&page=<?php echo $row_MET['m_page']; ?>" title="Edit"><img src="img/ico-edit.gif" alt="Edit" /></a></td>
        </tr>
        <tr bgcolor="#CCCCCC" class="style70">
          <td height="1" colspan="6"></td>
        </tr>
  <?php } while ($row_MET = mysql_fetch_assoc($MET)); ?>
</table>
</td></tr></table>

<?php include('footer_tpl.php'); ?>
</body>
</html>
<?php
mysql_free_result($MET);
?>
