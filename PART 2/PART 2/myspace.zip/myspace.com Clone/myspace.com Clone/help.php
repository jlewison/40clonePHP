<?
show_header();
?>
<table width=100% class=body>
<tr><td class='lined padded-6'><p><span class="title"><b>Our</b></span><b><span class='title'> Help</span>
  	Page:</b><p><b>Edit this file by opening up the file help.php and put in 
	your own text, then save the changes and upload this file again to your 
	server to see your changes immediately.</b></td></table>
<? show_footer(); ?>