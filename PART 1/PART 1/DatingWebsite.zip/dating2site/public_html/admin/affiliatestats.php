<?php

if ( !defined( 'SMARTY_DIR' ) ) {
	include_once( '../init.php' );
}

include ( 'sessioninc.php' );

define( 'PAGE_ID', 'affiliate_stats' );

if ( !checkAdminPermission( PAGE_ID ) ) {

	header( 'location: not_authorize.php' );
	exit;
}
if ( isset( $_GET['results_per_page'] ) && $_GET['results_per_page'] ) {

	$psize = $_GET['results_per_page'];

	$config['search_results_per_page'] = $_GET['results_per_page'] ;

	$_SESSION['ResultsPerPage'] = $_GET['results_per_page'];

} elseif( $_SESSION['ResultsPerPage'] != '' ) {

	$psize = $_SESSION['ResultsPerPage'];

	$config['search_results_per_page'] = $_SESSION['ResultsPerPage'] ;

} else {

	$psize = $config['page_size'];

	$_SESSION['ResultsPerPage'] = $config['page_size'];

}

if (!isset($_REQUEST['sortby']) && $_SESSION['sortby'] != '') {

	$sortby = $_SESSION['sortby'];

} else {

//Default Sorting
	if ($_REQUEST['sortby'] == 'refcnt') {
		$sortby = ' refcnt ';
	} elseif ($_REQUEST['sortby'] == 'refcnt') {
		$sortby = ' usercnt ';
	} else {
		$sortby = ' a.name ';
	}
}

if (!isset($sortby) or $sortby == '') $sortby = ' a.name ';

$_SESSION['sortby'] = trim($sortby);

if (!isset($_REQUEST['sortorder']) && $_SESSION['sortorder'] != '') {

	$sortorder = $_SESSION['sortorder'];

} else {

	$sortorder = checkSortType($_REQUEST['sortorder']);
}

$page_size = $psize;

$_SESSION['sortorder'] = $sortorder;

//Paging View style

$page = (int)$_GET['offset'];

if( $page == 0 ) $page = 1;

$upr = ($page)*$page_size - $page_size;

$lwr = ($page)*$page_size ;

$sql = 'SELECT a. * , count( b.id )  AS refcnt, sum( if(b.userid>0,1,0) )  AS usercnt
FROM  !  AS a LEFT  JOIN ! AS b ON b.affid = a.id where a.status in (?, ?) GROUP  BY a.id ';

$rs = $db->getAll( $sql, array( AFFILIATE_TABLE, AFFILIATE_REFERALS_TABLE, 'active', get_lang('status_act','active') ) );

$totalrecs = count($rs);

$pages = ceil($totalrecs / $page_size);

$sql .= ' order by '.$sortby. ' ' . $sortorder;

$sql .= " limit $upr, $page_size ";
$rs = $db->getAll( $sql, array( AFFILIATE_TABLE, AFFILIATE_REFERALS_TABLE, 'active', get_lang('status_act','active') ) );

$t->assign('psize', $psize);

$t->assign( 'upr', $upr );

$t->assign('pages', $pages);

$t->assign( 'sortorder', trim($sortorder) );

$t->assign( 'data', $rs );

$t->assign('lang',$lang);

$t->assign('rendered_page', $t->fetch('admin/affiliatestats.tpl'));

$t->display( 'admin/index.tpl' );


?>