<?php
$db['host']     = '127.0.0.1';   //Your database host, I.E. localhost
$db['username'] = '';        //Your database username
$db['password'] = '';            //Your database password
$db['db']       = '';  //Your database name
$db['prefix']   = '';            //Your table prefix, can be left blank
?>
