
/*
Theme Name: GreenFlower
Description: WP Theme <a href="http://wpthemes.info/green-flower/" title="WordPress Theme GreenFlower" target="_blank">GreenFlower</a> by Sadish
Version: 1.1
Author: Sadish Bala
Author URI: http://wpthemepark.com
*/

Ported to CPG  by: Billy Bullock
Porter URI: http://www.billygbullock.com
Coppermine Theme Version: 1.0.0
Tested on CPG v1.4.10

License -
The CSS, XHTML and design is released under GPL:
http://www.opensource.org/licenses/gpl-license.php

This program is free software; you can redistribute it and/or modify it under 

The terms of the GNU General Public License as published by the Free Software 
Foundation, version 2 of the License.

This program is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 

PARTICULAR PURPOSE. See the GNU General Public License for more details.
*/

Thank you for downloading Green Flower, a  theme for Coppermine Photo Gallery v1.4.x and WordPress v2.+. This is a fixed width theme and is fully compatible with most of the major browsers (I tested it in FF 1.5, IE 6 & 7 and Safari at various monitor resolutions). The width will accomodate monitor sizes from 800x600 on up.

I've overwritten some of the configuration settings by using variables in the theme.php file. The reason for this is to prevent the standard settings in the Configuration tables set by you from "breaking" the theme. These changes are:

$CONFIG['max_film_strip_items'] = 4; //overrides the number of thumbnails.
$CONFIG['thumbcols'] = 4; //overrides the number of columns for thumbnails.
$CONFIG['main_table_width'] = '100%'; //overrides the Width of the main table (pixels or %).
$CONFIG['picture_table_width'] = '100%'; //overrides the Width of the table for file display (pixels or %).
$CONFIG['album_list_cols'] = 4; // sets "Number of columns for the album list = 3"
$CONFIG['first_level'] = 0; //sets "Show first level album thumbnails in categories = no".

This theme has the first level of album thumbnails turned off to make large galleries look move attractive. This will prevent the main page from being cluttered with thumbnails and easier to chose a particular category. Also, this theme is geared towards intermediate photos sizes of 400 pixels or less but the theme will reduce the size automatically for intermediate images larger than this. The popup size can be any size though.

Please enjoy the theme and all I ask is that you keep the credit line in the template.html to help support my efforts to develop and port themes for Coppermine.

Cheers,

Billy
http://www.billygbullock.com