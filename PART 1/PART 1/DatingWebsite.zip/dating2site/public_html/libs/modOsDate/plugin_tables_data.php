<?php

   class pluginTablesData extends Data {

      var $table = PLUGIN_TABLES_TABLE;

      var $config = array (
  'table' => PLUGIN_TABLES_TABLE,
  'idField' => 'id',
  );   

      function pluginTablesData() {
      
         $this->Data($this->config);
      }
   }

?>
