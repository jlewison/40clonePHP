<?php
class CategoryHandler extends FormHandler
{
		public function displayCategory()
		{
				$sql = 'SELECT cat_id, cat_name, has_child, total_questions' . ' FROM ' . $this->CFG['db']['tbl']['questions_category'] . ' WHERE status=\'1\' AND parent_id=0 ';
				$orderSql = ' ORDER BY cat_name ASC';
				if ($this->fields_arr['s'] == 'f') $orderSql = ' ORDER BY total_questions DESC, cat_name ASC';
				$sql .= $orderSql;
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount())
				{
						$alphabetLI = $questionsLI = '';
						$alphabetSPAN = $questionsSPAN = '';
						$alphabetA = $questionsA = '';
						$clsActiveForumLinksLeft = 'clsActiveForumLinksLeft';
						$clsActiveForumLinksRight = 'clsActiveForumLinksRight';
						$clsActiveForumLinksMiddle = 'clsActiveForumLinksMiddle';
						$alphaClass = $freqClass = '';
						if ($this->fields_arr['s'] == 'a')
						{
								$alphabetLI = $clsActiveForumLinksLeft;
								$alphabetSPAN = $clsActiveForumLinksRight;
								$alphabetA = $clsActiveForumLinksMiddle;
						}
						if ($this->fields_arr['s'] == 'f')
						{
								$questionsLI = $clsActiveForumLinksLeft;
								$questionsSPAN = $clsActiveForumLinksRight;
								$questionsA = $clsActiveForumLinksMiddle;
						}
?>
<ul class="clsForumLinks">
<li class="<?php echo $alphabetLI; ?>"><span class="<?php echo $alphabetSPAN; ?>"><a class="<?php echo $alphabetA; ?>" href="<?php echo getUrl('categories.php?s=a', 'category/?s=a'); ?>"><?php echo $this->LANG['category_alphabetically'] ?></a></span></li>

<li class="<?php echo $questionsLI; ?>"><span class="<?php echo $questionsSPAN; ?>"><a class="<?php echo $questionsA; ?>" href="<?php echo getUrl('categories.php?s=f', 'category/?s=f'); ?>"><?php echo $this->LANG['category_frequency'] ?></a>
</span></li>
</ul>
<script type="text/javascript" language="javascript">
	var subCat = new Array();
</script>
<div class="clsCategoryList" id="selMainCategory">
<div class="clsCommonCategory">
<div class="clsCategoryListLeft">

<?php
						while ($row = $rs->FetchRow())
						{
?>
<p>
	<a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'questions.php?cid=' . $row['cat_id'], $this->CFG['site']['relative_url'] . 'answers/dir/' . $row['cat_id'] . '/', false); ?>"><?php echo $row['cat_name']; ?><?php if ($row['total_questions']) echo '(' . $row['total_questions'] . ')'; ?></a>
	<?php if ($row['has_child'])
								{ ?>
		<a class="clsSubCategory" id="<?php echo $row['cat_id']; ?>" href="<?php echo $_SERVER['REQUEST_URI']; ?>" onclick="Effect.toggle('subcat_<?php echo $row['cat_id']; ?>', 'BLIND'); return false;"><img src="<?php echo $this->CFG['site']['url'] . 'images/screen_white/icon-dropdown.gif'; ?>" alt="<?php echo $this->LANG['category_click_for_subcategory']; ?>" title="<?php echo $this->LANG['category_click_for_subcategory']; ?>" /></a>
		<?php $this->displaySubCategoy($row['cat_id']); ?>
	<?php } ?>
</p>
<?php
						}
?>

</div></div>
<div id="selSubCategory" class="clsSubCategoryListRight"></div>
</div>
<?php
				}
				else
				{
						echo $this->LANG['no_category_found'];
				}
		}
		public function displaySubCategoy($parent_id)
		{
				$sql = 'SELECT cat_id, cat_name, total_questions' . ' FROM ' . $this->CFG['db']['tbl']['questions_category'] . ' WHERE status=\'1\' AND parent_id=' . $this->dbObj->Param($parent_id);
				$orderSql = ' ORDER BY cat_name ASC';
				if ($this->fields_arr['s'] == 'f') $orderSql = ' ORDER BY total_questions DESC, cat_name ASC';
				$sql .= $orderSql;
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($parent_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$ok = false;
				if ($rs->PO_RecordCount())
				{
						$ok = true;
						$i = 1;
?>
<div style="display:none;" id="subcat_<?php echo $parent_id; ?>">
	<ul id="selCategoryList">
<?php
						while ($row = $rs->FetchRow())
						{
?>
		<li><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'questions.php?cid=' . $row['cat_id'], $this->CFG['site']['relative_url'] . 'answers/dir/' . $row['cat_id'] . '/', false); ?>"><?php echo $row['cat_name']; ?><?php if ($row['total_questions']) echo '(' . $row['total_questions'] . ')'; ?></a></li>
<?php
								$i++;
						}
?>
	</ul>
</div>
<?php
				}
				return $ok;
		}
}
$category = new CategoryHandler();
$category->setDBObject($db);
$category->makeGlobalize($CFG, $LANG);
$category->setPageBlockNames(array('form_question_category'));
$category->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$category->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$category->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$category->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$category->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$category->setFormField('s', 'a');
$category->setAllPageBlocksHide();
$category->setPageBlockShow('form_question_category');
$category->sanitizeFormInputs($_REQUEST);



?>
<div id="selCategory">
	<h2><span><?php echo $LANG['page_title']; ?></span></h2>
<?php
if ($category->isShowPageBlock('form_question_category'))
{
		$category->displayCategory();
}
?>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>