						<br><br><br><br>
						</span></td>
					</tr>
					</table>
				</div>
			</td>
		</tr>
		</table>
		<table cellpadding="0" cellspacing="0" width="100%">
		<tr>
			<td colspan=2 width="100%" height="25" class="BodyHeader1" style="background-color:#000000;padding-left:20px;" align=center>
				<span class="SideHeading"><span class=small>
					<?=$sitename?> Copyright � 2000-2006 <a href="<?=$siteurl?>" style="text-decoration:none;color:#ffffff;"><span class=small><?=$sitename?></a>. Powered by SaveFile Clone</span>
			</td>
		</tr>
		</table>
	</div>
</div>
</body>
</html>