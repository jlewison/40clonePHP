<?PHP
/*
	This program will convert current questions and answers in the format defined
	in the profile_questions.php file in the language directory for language specific
	conversions.

*/
if ( !defined( 'SMARTY_DIR' ) ){
	include_once( '../init.php' );
}

include ( 'sessioninc.php' );

$questions = $db->getAll('select id, question, description, guideline, control_type, extsearchhead from ! ', array(QUESTIONS_TABLE));
$file = TEMP_DIR . '/profile_questions.php';
$fp = @fopen($file,'wb');
fwrite($fp,'<?php '.'\n\r');
foreach ($questions as $x => $rec) {
	fwrite($fp, "\$profile_questions['".$rec['id']."']['question'] = '".addslashes($rec['question'])."';\n\r");
	fwrite($fp, "\$profile_questions['".$rec['id']."']['description'] = '".addslashes($rec['description'])."';\n\r");
	fwrite($fp, "\$profile_questions['".$rec['id']."']['guideline'] = '".addslashes($rec['guideline'])."';\n\r");
	fwrite($fp, "\$profile_questions['".$rec['id']."']['extsearchhead'] = '".addslashes($rec['extsearchhead'])."';\n\r");
	if ($rec['control_type'] != 'textarea') {
		$options = $db->getAll('select id, answer from ! where questionid = ? order by questionid, id', array(OPTIONS_TABLE, $rec['id']) );
		foreach ($options as $x => $ans) {
			fwrite($fp, "\$profile_questions['".$rec['id']."']['".$ans['id']."'] = '".addslashes($ans['answer'])."';\n\r");
		}
	}
}
fwrite($fp,'?>');
fclose($fp);

echo("Profile questions are added in the file ".$file."<br /><p>Please copy this to /language/lang_english/ as profile_questions.php. Also copy this to other language directories as profile_questions.php which you want to use and modify the text for that language.");

?>