<?php
////////////////////////////////////////////////////////////// 
// Rapidsendit Clone V.1.1  Purchased from Rapidsendit.com ///
// flatFileHost lives on! Credits To Jim For The Foundtion ///
//////////////////////////////////////////////////////////////

extract ($_REQUEST);
extract($_POST);
extract($_GET);

include("./config.php");
include("./header.php");

$bans=file("./bans.txt");
foreach($bans as $line)
{
  if ($line==$_SERVER['REMOTE_ADDR']){
    echo "You are not allowed to download files.";
    include("./footer.php");
    die();
  }
}

if(isset($_GET['file'])) {
  $rand2 = $_GET['file'];
} else {
  echo "Invalid download link.<br />";
  include("./footer.php");
  die();
}

//$checkfiles=file("./files.txt");
//$foundfile=0;
//foreach($checkfiles as $line)
//{
//  $thisline = explode('|', $line);
//  if ($thisline[0]==$rand2){
//    $foundfile=$thisline;
//  }
//}

// begin separate file mod
$foundfile=0;
if (file_exists("./storagedata/".$rand2.".txt")) {
	$fh1=fopen("./storagedata/".$rand2.".txt",r);
	$foundfile= explode('|', fgets($fh1));
	fclose($fh1);
}
// end separate file mod

//if(isset($_GET['del'])) {
//
//$fc=file("./files.txt");
//$f=fopen("./files.txt","w");
//$deleted=0;
//foreach($fc as $line)
//{
//  $thisline = explode('|', $line);
//  if ($thisline[0] == $_GET['file']){
//    if($thisline[2] == $_GET['del']){
//	$deleted=1;
//    } else {
//    fputs($f,$line);
//    }
//  } else {
//    fputs($f,$line);
//  }
//}
//fclose($f);

// begin separate file mod
if(isset($_GET['del'])) {
$deleted=0;
$rand2 = $_GET['file'];
$rand2txt = $rand2 . ".txt";
$passcode = $_GET['del'];
if (file_exists("./storagedata/".$rand2txt)) {
	$fh2=fopen ("./storagedata/".$rand2txt,r);
	$filedata= explode('|', fgets($fh2));
	if($filedata[1] == $passcode){
		$deleted=1;
		unlink("./storagedata/".$rand2txt);
	}

}
// end separate file mod

if($deleted==1){
unlink("./storage/".$_GET['file']);
echo "Your file was deleted.<br />";
} else {
echo "Invalid delete link.<br />";
}
include("./footer.php");
die();

}

$filesize = filesize("./storage/".$file);
$filesize = $filesize / 1048576;

if($filesize > $nolimitsize) {

$userip=$_SERVER['REMOTE_ADDR'];
$time=time();
$downloaders = fopen("./downloaders.txt","r+");
flock($downloaders,2);

while (!feof($downloaders)) { 
  $user[] = chop(fgets($downloaders));
}

fseek($downloaders,0,SEEK_SET);
ftruncate($downloaders,0);

foreach ($user as $line) {
  list($savedip,$savedtime) = explode("|",$line);
  if ($savedip == $userip) {
    if ($time < $savedtime + ($downloadtimelimit*60)) {
		$toosoon = true;
		$waittime = (($savedtime + ($downloadtimelimit*60))-$time) ;
		if ($waittime < 60) {
			$waittime .= " seconds.";
		} else {
			$waittime = round(($waittime/60),0) . " minutes.";
		}
    }
  }

  if ($time < $savedtime + ($downloadtimelimit*60)) {
    fputs($downloaders,"$savedip|$savedtime\n");
  }
}

}


$fsize = 0;
$fsizetxt = "";
  if ($filesize < 1)
  {
     $fsize = round($filesize*1024,2);
     $fsizetxt = "".$fsize." KB";

  }
  else
    {
     $fsize = round($filesize,2);
     $fsizetxt = "".$fsize." MB";
  }

$fh3 = fopen("./storagedata/".$file.".txt" ,r);
$filedata= explode('|', fgets($fh3));

echo "<font face='Verdana' size='2'><b>".$filedata[0]." <br>".$fsizetxt."</b></font><br>";

if ($toosoon) {
		echo "You're trying to download again too soon!  ";
		echo "Wait " . $waittime . "<BR>";
		echo "<span style=font-size:9px;font-family:arial>Note: Files over " . ($nolimitsize * 1000) . " KB require a " . $downloadtimelimit . " minute wait time.</span><BR><BR>";
		include("./footer.php");
		die();
}

echo "<font face='Verdana' size='2'><b>This file has been downloaded ".$filedata[4]." times.</b></font>";

$randcounter = rand(100,999);
?>

<div id="dl" align="center">
<?php 
if($downloadtimer == 0) {
echo "<a href=\"" .$scripturl . "download2.php?a=" . $rand2 . "&b=" . md5($foundfile[1].$_SERVER['REMOTE_ADDR']) . "\">Download</a>";
} else { ?>
If you're seeing this message, you need to enable JavaScript
<?php } ?>
</div>
<script language="Javascript">
x<?php echo $randcounter; ?>=<?php echo $downloadtimer; ?>;
function countdown() 
{
 if ((0 <= 100) || (0 > 0))
 {
  x<?php echo $randcounter; ?>--;
  if(x<?php echo $randcounter; ?> == 0)
  {
   document.getElementById("dl").innerHTML = '<input type="submit" value="Download File Now" onClick="window.location=\'<?php echo $scripturl . "download2.php?a=" . $rand2 . "&b=" . md5($foundfile[1].$_SERVER['REMOTE_ADDR']) ?>\'">';
  }
  if(x<?php echo $randcounter; ?> > 0)
  {
document.getElementById("dl").innerHTML = '<input type=submit value=\"Please wait '+x<?php echo $randcounter; ?>+' seconds..\">';
   setTimeout('countdown()',1000);
  }
 }
}
countdown();
</script>
<br /><p>
<a href="report.php?file=<?php echo $rand2;?>">Click here to report this file for breaking the rules</a></p>
<?php
include("./footer.php");
?>