<?php
function isLoggedIn()
{
		$CI = &get_instance();
		//check login
		if ($CI->session->userdata('logged_in') == 1 && $CI->session->userdata('user_id') != '') return true;
		else  return false;
}
function loginRequired($page = '')
{
		$CI = &get_instance();
		//check login
		if ($CI->session->userdata('logged_in') != 1 && $CI->session->userdata('user_id') == '')
		{
				$CI->session->set_userdata(array('redirectURL' => $CI->uri->uri_string()));
				redirect((trim($page) == '') ? 'home' : trim($page));
		}
}
function doLogin($page = '')
{
		$CI = &get_instance();
		//Login success
		if ($CI->session->userdata('redirectURL') != '') redirect($CI->session->userdata('redirectURL'));
		else  redirect((trim($page) == '') ? 'welcome' : trim($page));
}
function loggedInTakeIn($page = '')
{
		$CI = &get_instance();
		//check login
		if ($CI->session->userdata('logged_in') == 1 && $CI->session->userdata('user_id') != '')
		{
				redirect((trim($page) == '') ? 'welcome' : trim($page));
		}
}
function getAvatar($userId, $ext, $size = 'thumb')
{
		$size = (trim($size) != '') ? '_' . $size : '';
		$userAvatar = base_url() . 'application/content/profiles/' . $userId . $size . $ext;
		$filename = APPPATH . 'content/profiles/' . $userId . $size . $ext;
		if (!file_exists($filename)) $userAvatar = base_url() . 'application/images/default_avatar_thumb.jpg';
		return $userAvatar;
}
?>