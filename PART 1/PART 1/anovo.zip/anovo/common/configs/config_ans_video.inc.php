<?php

$CFG['admin']['ans_videos']['folder'] = 'ans_videos';
$CFG['admin']['ans_videos']['video_folder'] = 'files/ans_videos/';
$CFG['admin']['ans_videos']['thumbnail_folder'] = 'files/ans_videos/ans_thumbnails/';
$CFG['admin']['ans_videos']['temp_folder'] = 'files/temp_files/ans_temp_videos/';
$CFG['admin']['ans_videos']['thumb_width'] = 90;
$CFG['admin']['ans_videos']['thumb_height'] = 90;
$CFG['admin']['ans_videos']['video_auto_encode'] = true;
$CFG['admin']['ans_videos']['logo_format_arr'] = array('jpg', 'swf');
$CFG['admin']['ans_videos']['mini_logo_format_arr'] = array('jpg', 'swf');
$CFG['admin']['ans_videos']['logo_max_size'] = 500;
$CFG['admin']['ans_videos']['mini_logo_max_size'] = 500;
$CFG['admin']['ans_videos']['logo_folder'] = 'files/video_logo/';
$CFG['admin']['ans_videos']['logo_name'] = 'logo';
$CFG['admin']['ans_videos']['mini_logo_name'] = 'mini_logo';
$CFG['admin']['ans_videos']['advertisement_format_arr'] = array('jpg', 'swf', 'flv');
$CFG['admin']['ans_videos']['advertisement_max_size'] = 500;
$CFG['admin']['ans_videos']['advertisement_folder'] = 'files/video_advertisement/';
$CFG['admin']['video']['vbitrate'] = 500;
$CFG['admin']['ans_videos']['format_arr'] = array('mpeg', 'dat', 'wmv', 'avi', 'mov', 'mpg', 'flv');
$CFG['admin']['ans_videos']['max_size'] = 32;
?>