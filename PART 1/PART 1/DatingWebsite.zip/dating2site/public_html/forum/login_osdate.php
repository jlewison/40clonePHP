<?PHP
include_once( '../init.php');
/**
 * Fetch the IP address of the current user.
 *
 * @return string The IP address.
 */
function get_ip()
{
	if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
	{
		if(preg_match_all("#[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}#s", $_SERVER['HTTP_X_FORWARDED_FOR'], $addresses))
		{
			foreach($addresses[0] as $key => $val)
			{
				if(!preg_match("#^(10|172\.16|192\.168)\.#", $val))
				{
					$ip = $val;
					break;
				}
			}
		}
	}
	if(!isset($ip))
	{
		if(isset($_SERVER['HTTP_CLIENT_IP']))
		{
			$ip = $_SERVER['HTTP_CLIENT_IP'];
		}
		else
		{
			$ip = $_SERVER['REMOTE_ADDR'];
		}
	}
	return $ip;
}

/**
 * Escape a string according to the MySQL escape format.
 *
 * @param string The string to be escaped.
 * @return string The escaped string.
 */
function escape_string($string)
{
	if(function_exists("mysql_real_escape_string"))
	{
		$string = mysql_real_escape_string($string);
	}
	else
	{
		$string = addslashes($string);
	}
	return $string;
}

if ($_SESSION['AdminId'] > 0) {
	include (FORUM_DIR.'adminLogin.php');
}elseif ($_SESSION['UserId'] > 0) {
	include (FORUM_DIR.'userLogin.php');
}

?>