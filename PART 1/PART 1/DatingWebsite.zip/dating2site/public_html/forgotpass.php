<?php
if ( !defined( 'SMARTY_DIR' ) ) {
	include_once( 'init.php' );
}

if ($_GET['errid'] != '') {

	$t->assign( 'errmsg', str_replace('SITENAME', $config['site_name'], get_lang('letter_errormsgs',$_GET['errid']) ) );

}

$t->assign('rendered_page', $t->fetch('forgotpass.tpl') );

$t->display( 'index.tpl' );
?>