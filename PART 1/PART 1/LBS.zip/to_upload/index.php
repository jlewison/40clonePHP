<?php include('ip_domain_ban.php'); include('settings.php'); if($onoff == 'N') { include('disabled.php'); exit; } else { } if($prenabled == 'Y' and $enb_home == 'Y') { include('pr.php'); } else { } ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<?php echo("$lang_0");?>
<?php echo("$lang_01");?>

<title><?php echo("$index_title");?> - <?php echo("$sitetitle");?></title>
<link rel="shortcut icon" href="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/favicon.ico" />
<link href="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/style.css" rel="stylesheet" type="text/css" />
<meta name="description" content="<?php echo("$index_description");?>">
<meta name="keywords" content="<?php echo("$index_keyword");?>">
</head>

<body>

<?php if($screenshot == 'Y') { ?> <SCRIPT language=javascript src="<?php echo("$path");?>screenshots.htm" type=text/javascript></SCRIPT> <?php } else { } ?>
<?php include("template/$lbdtemplate/a_main_homepage.php"); ?>

</body>
</html>