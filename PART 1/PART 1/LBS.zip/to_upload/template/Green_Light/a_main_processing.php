<?php include('template/Green_Light/b_inside_top.php');?>
<td valign="top">

<?php
if($fremode == 'Y') { ?>



<div class="page-header"><h1><?php echo("$lang_102");?></h1></div>

<div style="margin-left:30px; margin-right:30px;">
<div class="box" style="margin-bottom:10px;">
<div class="box-cap-left">
		<div class="box-cap-right">
			<div class="box-cap"></div>
		</div>
	</div>
<div class="box2-left"><div class="box2-right" style="min-height:70px;"><?php echo("$lang_103");?></div></div>
<div class="box-bottom-left">
		<div class="box-bottom-right">
		</div>
	</div></div>
</div>


<?php } else { ?> 

<div class="page-header"><h1><?php echo("$lang_104");?></h1></div>
<div style="margin-left:30px; margin-right:30px;">
<div class="box" style="margin-bottom:10px;">
	<div class="box-cap-left">
		<div class="box-cap-right">
			<div class="box-cap"></div>
		</div>
	</div>
	<div class="box2-left">
		<div class="box2-right" style="min-height:70px;">
		<div class="rate" id="bidd"><?php echo("$currency");?><?php echo("$bid");?></div>
			<div class="listing-descr">
				<div class="bid-title"><a href="http://<?php echo("$url");?>" target="_blank" class="style1"><?php echo("$keyword");?></a></div>
				<div class="bid-descr"><?php echo("$descr1");?></div>
				<div class="bid-url"><span style="color:#3a6e2f; font-style:italic;"><?php echo("$url");?></span></div>
				<div class="bid-descr">Submitted: <?php $today = date("F j, Y, g:i a"); echo("$today");?></div>
				<div class="bid-descr">Last Upgrade: never</div>
			</div>
		</div>
	</div>
	<div class="box-bottom-left">
		<div class="box-bottom-right">
		</div>
	</div>
</div>

<table border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><div id="TabbedPanels1" class="TabbedPanels">
  <ul class="TabbedPanelsTabGroup">
    <li class="TabbedPanelsTabB" tabindex="0">Terms of Submission</li>
    <li class="TabbedPanelsTab" tabindex="0">Agree</li>
    <li class="TabbedPanelsTabA" tabindex="0">Disagree</li>
  </ul>
  <div class="TabbedPanelsContentGroup">
    <div class="style30"><?php echo("$termsdetails");?></div>
    <div class="TabbedPanelsContent">
      <div align="center"><span class="style30">Click on the PayPal image to proceed with the payment.</span><br />  
          <br />
<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
    <input type="hidden" name="cmd" value="_xclick">
    <input type="hidden" name="business" value="<?php echo("$paypal");?>">
    <input type="hidden" name="item_name" value="Payment for Bid ID <?php echo("$linkid");?> for link <?php echo("$url");?>">
    <input type="hidden" name="item_number" value="<?php echo("$linkid");?>">
    <input type="hidden" name="amount" value="<?php echo("$bid");?>">
    <input type="hidden" name="no_shipping" value="2">
    <input type="hidden" name="no_note" value="1">
    <input type="hidden" name="currency_code" value="<?php echo("$paypalcurrency");?>">
	<input type="hidden" name="return" value="http://<?php echo("$domainname");?><?php echo("$pathmail");?>/thankyou.php">
	<input type="hidden" name="cancel_return" value="http://<?php echo("$domainname");?><?php echo("$pathmail");?>/sorry.php">
    <input type="hidden" name="bn" value="PP-BuyNowBF">
    <input name="submit" type="image" src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/PP-6.gif" alt="Make payments with PayPal - it's fast, free and secure!" width="150" height="140" border="0">
</form>
        </div>
    </div>
    <div class="style26">We are sorry to learn you disagree with our terms of service, its important that   you choose agreed to proceed with your order. 
    Please <a href="/" class="style26">click here</a> to return to our homepage.</div>
  </div>
</div></td>
  </tr>
</table>


<script type="text/javascript">
<!--
var TabbedPanels1 = new Spry.Widget.TabbedPanels("TabbedPanels1");
//-->
</script>

</div>
<?php } ?>

<?php include('template/Green_Light/b_footer_tpl.php'); ?>