<!-- Footer begins -->
</div>
<!-- Footer -->

<div id="footer">
  <div id="subFooter">
    <h2>Miscellaneous Navigational Links</h2>
    <ul>
      <li class="faq"><a href="<? echo $CFG['site']['relative_url'] . 'staticPage.php?pg=faq'; ?>">Faq</a></li>
      <li class="privacy"><a href="<? echo $CFG['site']['relative_url'] . 'staticPage.php?pg=privacy'; ?>">Privacy</a></li>
      <li class="terms"><a href="<? echo $CFG['site']['relative_url'] . 'staticPage.php?pg=terms'; ?>">Terms</a></li>
    </ul>
  </div>
  <p>&copy; 2008 <?php echo $CFG['site']['name']; ?>. All rights reserved.</p>
  <p><?php echo $CFG['dev']['product_name'] . ' ' . $CFG['dev']['version']; ?></p>
</div>
</div>
</div>
</body>
<?php
if (chkToolTipAllowed())
{
?>
<script language="javascript" type="text/javascript">
/*-------------------Top tip ---------------------------*/
	$$("form input.help").each( function(input) {
		new Tooltip(input, {backgroundColor: "#FC9", borderColor: "#C96",
		textColor: "#000", textShadowColor: "#FFF"});
	});
</script>
<?php
}
?>
</html>