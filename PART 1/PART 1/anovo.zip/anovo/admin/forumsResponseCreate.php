<?php
require_once ('../common/config.inc.php');
$CFG['lang']['include_files'][] = 'admin/includes/languages/%s/forumsResponseCreate.php';
$CFG['html']['header'] = 'admin/includes/languages/%s/html_header.php';
$CFG['html']['footer'] = 'admin/includes/languages/%s/html_footer.php';
$CFG['lang']['include_files'][] = 'common/languages/%s/help.inc.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['mods']['include_files'][] = 'common/classes/class_inputfilter_clean.php';
$CFG['db']['is_use_db'] = true;
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class ForumResponseFormHandler extends FormHandler
{
		public $forum_details_arr;
		public $forum_topic_details_arr;
		public function chkLength($field_name, $err_tip = '')
		{
				$url_len = strlen($this->fields_arr[$field_name]);
				if ($url_len < 3 || $url_len > 20)
				{
						$this->fields_err_tip_arr[$field_name] = $err_tip;
						return false;
				}
				return true;
		}
		public function isValidForumId($forum_id, $err_tip = '')
		{
				$sql = 'SELECT forum_id, forum_title, forum_description, forum_status' . ' FROM ' . $this->CFG['db']['tbl']['forums'] . ' WHERE forum_id = ' . $this->dbObj->Param($forum_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($forum_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($this->forum_details_arr = $rs->FetchRow())
				{
						return true;
				}
				$this->setCommonErrorMsg($err_tip);
				return false;
		}
		public function isValidForumTopicId($forum_id, $topic_id, $err_tip = '')
		{
				$sql = 'SELECT g.topic_id, g.forum_id, g.forum_topic, g.user_id, DATE_FORMAT(g.date_added, \'' . $this->CFG['format']['date'] . '\') as date_added' . ', u.' . $this->getUserTableField('name') . ' AS name, u.' . $this->getUserTableField('image_path') . ' AS image_path, u.' . $this->getUserTableField('gender') . ' AS gender' . ' FROM ' . $this->CFG['db']['tbl']['forum_topics'] . ' AS g, ' . $this->CFG['db']['tbl']['users'] . ' AS u ' . ' WHERE g.user_id = u.' . $this->getUserTableField('user_id') . ' AND topic_id = ' . $this->dbObj->Param($topic_id) . ' ' . ' AND forum_id = ' . $this->dbObj->Param($forum_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($topic_id, $forum_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($this->forum_topic_details_arr = $rs->FetchRow())
				{
						return true;
				}
				$this->setCommonErrorMsg($err_tip);
				return false;
		}
		public function isValidForumResponseId($topic_id, $response_id, $err_tip = '')
		{
				$sql = 'SELECT response_id, topic_id, forum_response, response_user_id, response_status' . ' FROM ' . $this->CFG['db']['tbl']['forum_response'] . ' WHERE topic_id = ' . $this->dbObj->Param($topic_id) . ' AND response_id = ' . $this->dbObj->Param($response_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($topic_id, $response_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($row = $rs->FetchRow())
				{
						$this->setFormField('forum_response', $row['forum_response']);
						$this->setFormField('response_status', $row['response_status']);
						return true;
				}
				$this->setCommonErrorMsg($err_tip);
				return false;
		}
		public function createForumResponse()
		{
				if ($this->fields_arr['response_id'])
				{
						$this->updateForumResponse($this->fields_arr['topic_id'], $this->fields_arr['response_id']);
				}
				else
				{
						$this->insertForumResponse($this->fields_arr['topic_id']);
						$this->updateUsers();
				}
				$this->updateForumTopic($this->fields_arr['topic_id']);
				$this->updateForumsTable();
		}
		public function updateForumsTable()
		{
				$sql = 'SELECT COUNT(topic_id) AS total_topic FROM ' . $this->CFG['db']['tbl']['forum_topics'] . ' WHERE forum_id = ' . $this->dbObj->Param($this->fields_arr['forum_id']) . ' AND topic_status = \'Yes\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['forum_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = $rs->FetchRow();
				$total_topic = $row['total_topic'];
				$sql = 'SELECT COUNT(response_id) AS total_response FROM ' . $this->CFG['db']['tbl']['forum_response'] . ' AS fr' . ', ' . $this->CFG['db']['tbl']['forum_topics'] . ' AS ft' . ' WHERE fr.topic_id = ft.topic_id AND forum_id = ' . $this->dbObj->Param($this->fields_arr['forum_id']) . ' AND topic_status = \'Yes\' AND fr.response_status = \'Yes\' ';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['forum_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = $rs->FetchRow();
				$total_response = $row['total_response'];
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['forums'] . ' SET total_topics = ' . $this->dbObj->Param($total_topic) . ', total_response = ' . $this->dbObj->Param($total_response) . ' WHERE forum_id = ' . $this->dbObj->Param($this->fields_arr['forum_id']);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($total_topic, $total_response, $this->fields_arr['forum_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return true;
		}
		public function updateUsers()
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['users_ans_log'] . ' SET total_posts = total_posts + 1';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return true;
		}
		public function updateForums($forum_id)
		{
				$sql = 'SELECT 1 FROM ' . $this->CFG['db']['tbl']['forum_topics'] . ' WHERE topic_id = ' . $this->dbObj->Param($this->fields_arr['topic_id']) . ' AND topic_status = \'Ok\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['topic_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount())
				{
						$sql = 'UPDATE ' . $this->CFG['db']['tbl']['forums'] . ' SET last_post_user_id = \'' . $this->CFG['user']['user_id'] . '\'' . ', last_post_date = now()' . ', total_response = total_response + 1' . ' WHERE forum_id = ' . $this->dbObj->Param($forum_id);
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($forum_id));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				}
				return true;
		}
		public function insertForumResponse($topic_id)
		{
				$sql = 'INSERT INTO ' . $this->CFG['db']['tbl']['forum_response'] . ' SET topic_id = ' . $this->dbObj->Param($topic_id) . ', forum_response = ' . $this->dbObj->Param($this->fields_arr['forum_response']) . ', response_user_id = ' . $this->dbObj->Param($this->CFG['user']['user_id']) . ', response_status = ' . $this->dbObj->Param($this->fields_arr['response_status']) . ', date_added = NOW()';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($topic_id, html_entity_decode($this->fields_arr['forum_response'], ENT_QUOTES, $this->CFG['site']['charset']), $this->CFG['user']['user_id'], $this->fields_arr['response_status']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return true;
		}
		public function updateForumResponse($topic_id, $response_id)
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['forum_response'] . ' SET forum_response = ' . $this->dbObj->Param($this->fields_arr['forum_response']) . ', response_status = ' . $this->dbObj->Param($this->fields_arr['response_status']) . ' WHERE topic_id = ' . $this->dbObj->Param($topic_id) . ' AND response_id = ' . $this->dbObj->Param($response_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array(html_entity_decode($this->fields_arr['forum_response'], ENT_QUOTES, $this->CFG['site']['charset']), $this->fields_arr['response_status'], $topic_id, $response_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return true;
		}
		public function updateForumTopic($topic_id)
		{
				$sql = 'SELECT COUNT(response_id) AS total_response FROM ' . $this->CFG['db']['tbl']['forum_response'] . ' AS fr' . ' WHERE topic_id = ' . $this->dbObj->Param($this->fields_arr['topic_id']) . ' AND fr.response_status = \'Yes\' ';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['topic_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = $rs->FetchRow();
				$total_response = $row['total_response'];
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['forum_topics'] . ' SET total_response = ' . $this->dbObj->Param($total_response) . ', total_views = total_views + 1' . ', last_post_user_id = ' . $this->dbObj->Param($this->CFG['user']['user_id']) . ', last_post_date = NOW()';
				$fields_value_arr = array($total_response, $this->CFG['user']['user_id']);
				if ($this->fields_arr['forum_ratings'])
				{
						$sql .= ', rating_total = rating_total + ' . $this->dbObj->Param($this->fields_arr['forum_ratings']) . ', rating_count = rating_count + 1 ';
						$fields_value_arr[] = $this->fields_arr['forum_ratings'];
				}
				$sql .= ' WHERE topic_id = ' . $this->dbObj->Param($topic_id);
				$fields_value_arr[] = $topic_id;
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, $fields_value_arr);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return true;
		}
		public function updateForumTopicViews($topic_id)
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['forum_topics'] . ' SET total_views = total_views + 1';
				if ($this->fields_arr['forum_ratings'])
				{
						$sql .= ', rating_total = rating_total + ' . $this->dbObj->Param($this->fields_arr['forum_ratings']) . ', rating_count = rating_count + 1 ';
						$fields_value_arr[] = $this->fields_arr['forum_ratings'];
				}
				$sql .= ' WHERE topic_id = ' . $this->dbObj->Param($topic_id);
				$fields_value_arr[] = $topic_id;
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, $fields_value_arr);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return true;
		}
		public function populateRatings($ratings_value)
		{
				for ($i = 1; $i <= 10; $i++)
				{
?>
	<input type="radio" class="clsCheckRadio" name="forum_ratings" id="forum_ratings<?php echo $i; ?>" tabindex="<?php $this->getTabIndex(); ?>" value="<?php echo $i; ?>"<?php echo ($ratings_value == $i) ? 'CHECKED' : ''; ?> /><?php echo $i; ?>&nbsp;&nbsp;
<?php
				}
		}
		public function setError($field_name, $err_tip = '')
		{
				$this->fields_err_tip_arr[$field_name] = $err_tip;
		}
}
$forumsresponse = new ForumResponseFormHandler();
$forumsresponse->setPageBlockNames(array('msg_form_error', 'msg_form_success', 'form_create_response'));
$forumsresponse->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$forumsresponse->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$forumsresponse->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$forumsresponse->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$forumsresponse->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$forumsresponse->setDBObject($db);
$forumsresponse->setCfgLangGlobal($CFG, $LANG);
$forumsresponse->setFormField('forum_id', '');
$forumsresponse->setFormField('topic_id', '');
$forumsresponse->setFormField('response_id', '');
$forumsresponse->setFormField('forum_response', '');
$forumsresponse->setFormField('forum_ratings', '');
$forumsresponse->setFormField('response_status', 'Yes');
$forumsresponse->setAllPageBlocksHide();
if ($forumsresponse->isFormGETed($_GET, 'forum_id') && $forumsresponse->isFormGETed($_GET, 'topic_id'))
{
		$forumsresponse->sanitizeFormInputs($_GET);
		$forumsresponse->chkIsNotEmpty('forum_id', $LANG['forumsresponse_err_tip_compulsory']) and $forumsresponse->chkIsNumeric('forum_id', $LANG['forumsresponse_err_tip_compulsory']) and $forumsresponse->isValidForumId($forumsresponse->getFormField('forum_id'), $LANG['forumsresponse_err_tip_invalid_forum_id']);
		$forumsresponse->chkIsNotEmpty('topic_id', $LANG['forumsresponse_err_tip_compulsory']) and $forumsresponse->chkIsNumeric('topic_id', $LANG['forumsresponse_err_tip_compulsory']) and $forumsresponse->isValidForumTopicId($forumsresponse->getFormField('forum_id'), $forumsresponse->getFormField('topic_id'), $LANG['forumsresponse_err_tip_invalid_forum_topic_id']);
		$forumsresponse->getFormField('response_id') and $forumsresponse->chkIsNotEmpty('response_id', $LANG['forumsresponse_err_tip_compulsory']) and $forumsresponse->chkIsNumeric('response_id', $LANG['forumsresponse_err_tip_compulsory']) and $forumsresponse->isValidForumResponseId($forumsresponse->getFormField('topic_id'), $forumsresponse->getFormField('response_id'), $LANG['forumsresponse_err_tip_invalid_forum_response_id']);
		if ($forumsresponse->isValidFormInputs())
		{
				$forumsresponse->setPageBlockShow('form_create_response');
		}
		else
		{
				$forumsresponse->setPageBlockShow('msg_form_error');
		}
} elseif ($forumsresponse->isFormPOSTed($_POST, 'forumsresponse_submit'))
{
		$forumsresponse->sanitizeFormInputs($_POST);
		$forumsresponse->chkIsNotEmpty('forum_id', $LANG['forumsresponse_err_tip_compulsory']) and $forumsresponse->chkIsNumeric('forum_id', $LANG['forumsresponse_err_tip_compulsory']) and $forumsresponse->isValidForumId($forumsresponse->getFormField('forum_id'), $LANG['forumsresponse_err_tip_invalid_forum_id']);
		$forumsresponse->chkIsNotEmpty('topic_id', $LANG['forumsresponse_err_tip_compulsory']) and $forumsresponse->chkIsNumeric('topic_id', $LANG['forumsresponse_err_tip_compulsory']) and $forumsresponse->isValidForumTopicId($forumsresponse->getFormField('forum_id'), $forumsresponse->getFormField('topic_id'), $LANG['forumsresponse_err_tip_invalid_forum_topic_id']);
		$forumsresponse->getFormField('response_id') and $forumsresponse->chkIsNotEmpty('response_id', $LANG['forumsresponse_err_tip_compulsory']) and $forumsresponse->chkIsNumeric('response_id', $LANG['forumsresponse_err_tip_compulsory']);
		$filter = new InputFilter($CFG['fckeditor']['allowed_tags'], $CFG['fckeditor']['allowed_attr']);
		$forumsresponse->setFormfield('forum_response', $filter->process($forumsresponse->getFormfield('forum_response')));
		$forumsresponse->chkIsNotEmpty('forum_response', $LANG['forumsresponse_err_tip_compulsory']);
		$forumsresponse->chkIsNotEmpty('response_status', $LANG['forumsresponse_err_tip_compulsory']);
		$forumsresponse->isValidFormInputs() and $forumsresponse->createForumResponse();
		if ($forumsresponse->isValidFormInputs())
		{
				$forumsresponse->setAllPageBlocksHide();
				$forumsresponse->setPageBlockShow('form_create_response');
				Redirect2URL('forumsResponses.php?forum_id=' . $forumsresponse->getFormField('forum_id') . '&topic_id=' . $forumsresponse->getFormField('topic_id'));
		}
		else
		{
				$forumsresponse->setAllPageBlocksHide();
				$forumsresponse->setPageBlockShow('msg_form_error');
				$forumsresponse->setPageBlockShow('form_create_response');
		}
} elseif ($forumsresponse->isFormPOSTed($_POST, 'forumsresponse_cancel'))
{
		$forumsresponse->sanitizeFormInputs($_POST);
		Redirect2URL('forumsResponses.php?forum_id=' . $forumsresponse->getFormField('forum_id') . '&topic_id=' . $forumsresponse->getFormField('topic_id'));
}
else
{
		$forumsresponse->setAllPageBlocksHide();
		$forumsresponse->setPageBlockShow('msg_form_error');
}




?>
<script type="text/javascript" language="javascript">
	var palette_url = '<?php echo $CFG['site']['url'] . 'admin/palette.htm'; ?>';
	var block_arr= new Array('selMsgConfirm');
</script>
<div id="selForumResponseCreate">
	 <h2 class="clsForumResponseCreateTitle"><span>
		<a href="forums.php"><?php echo $LANG['forumlistall_title_index']; ?></a>
		&nbsp;-&nbsp;
		<a href="forumsTopics.php?forum_id=<?php echo $forumsresponse->getFormField('forum_id'); ?>">
			<?php echo $forumsresponse->forum_details_arr['forum_title']; ?></a>
		&nbsp;-&nbsp;
		<a href="forumsResponses.php?forum_id=<?php echo $forumsresponse->getFormField('forum_id'); ?>&topic_id=<?php echo $forumsresponse->getFormField('topic_id'); ?>">
			<?php echo $forumsresponse->forum_topic_details_arr['forum_topic']; ?></a>
		&nbsp;-&nbsp;
		<?php echo $LANG['forumsresponse_post_response']; ?>
	</span></h2>
    <div id="selLeftNavigation">
<?php

if ($forumsresponse->isShowPageBlock('msg_form_error'))
{
?>
<div id="selMsgError">
	 <p><?php echo $LANG['msg_error_sorry'] . ' ' . $forumsresponse->getCommonErrorMsg(); ?></p>
</div>
<?php
}
if ($forumsresponse->isShowPageBlock('msg_form_success'))
{
?>
<div id="selMsgSuccess">
 	<p><?php echo $LANG['forumsresponse_success']; ?></p>
</div>
<?php
}
if ($forumsresponse->isShowPageBlock('form_create_response'))
{
?>
<div id="selShowCreateResponse">
	<form name="selFormCreateForum" id="selFormCreateForum" method="post" action="<?php echo URL($_SERVER['PHP_SELF']); ?>" autocomplete="off" onsubmit="return getHTMLSource('rte1', 'selFormCreateForum', 'forum_response');">
		<table summary="<?php echo $LANG['forumsresponse_tbl_summary']; ?>" class="clsRichTextTable">
		   	<?php if (strchr(strtolower($_SERVER['HTTP_USER_AGENT']), "opera") == '')
		{ ?>
			<tr>
				<td class="<?php echo $forumsresponse->getCSSFormLabelCellClass('forum_response'); ?>"><?php ShowHelpTip('forum_topic_response'); ?><label for="response"><?php echo $LANG['forumsresponse_response']; ?></label></td>
				<td class="<?php echo $forumsresponse->getCSSFormFieldCellClass('forum_response'); ?>"><?php echo $forumsresponse->getFormFieldErrorTip('forum_response'); ?>
					<?php populateRichTextEdit('forum_response', $forumsresponse->getFormField('forum_response'), $forumsresponse->isValidFormInputs()); ?>
				</td>
		    </tr>
			<?php }
		else
		{ ?>
			<tr>
				<td class="<?php echo $forumsresponse->getCSSFormFieldCellClass('forum_response'); ?>">
					<p><label for="response"><?php echo $LANG['forumsresponse_response']; ?></label><?php ShowHelpTip('forum_topic_response'); ?></p></td>
				<td>	<p>
						<?php echo $forumsresponse->getFormFieldErrorTip('forum_response'); ?>
						<textarea class="clsCommonTextArea" name="forum_response" id="forum_response" cols="100" rows="7"><?php echo $forumsresponse->getFormField('forum_response'); ?></textarea>
					</p>
				</td>
		    </tr>
			<?php } ?>
		    <tr>
				<td colspan="2" class="<?php echo $forumsresponse->getCSSFormFieldCellClass('response_status'); ?>">
					<input type="radio" class="clsCheckRadio" name="response_status" id="status_yes" value="Yes" <?php if ($forumsresponse->getFormField('response_status') == 'Yes') echo 'CHECKED'; ?> tabindex="<?php echo $forumsresponse->getTabIndex(); ?>"  />
					<label for="status_yes"><?php echo $LANG['forumsresponse_active']; ?></label>
					<input type="radio" class="clsCheckRadio" name="response_status" id="status_no" value="No" <?php if ($forumsresponse->getFormField('response_status') == 'No') echo 'CHECKED'; ?> tabindex="<?php echo $forumsresponse->getTabIndex(); ?>"  />
					<label for="status_no"><?php echo $LANG['forumsresponse_inactive']; ?></label>
				</td>
			</tr>
		    <tr>
				<td class="<?php echo $forumsresponse->getCSSFormFieldCellClass('submit'); ?>" colspan="2">
					<input type="submit" class="clsSubmitButton" name="forumsresponse_submit" id="forumsresponse_submit" tabindex="<?php echo $forumsresponse->getTabIndex(); ?>" value="<?php echo $LANG['forumsresponse_submit']; ?>" />
					&nbsp;&nbsp;
					<input type="submit" class="clsCancelButton" name="forumsresponse_cancel" id="forumsresponse_cancel" tabindex="<?php echo $forumsresponse->getTabIndex(); ?>" value="<?php echo $LANG['forumsresponse_cancel']; ?>" />
				</td>
			</tr>
		</table>
		<input type="hidden" name="forum_id" id="forum_id" value="<?php echo $forumsresponse->getFormField('forum_id'); ?>" />
		<input type="hidden" name="topic_id" id="topic_id" value="<?php echo $forumsresponse->getFormField('topic_id'); ?>" />
		<input type="hidden" name="response_id" id="response_id" value="<?php echo $forumsresponse->getFormField('response_id'); ?>" />
	</form>
</div>
<?php
}

?>
	</div>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>
