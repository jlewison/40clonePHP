<?php

   class aff_referalsData extends Data {

      var $table = AFF_REFERALS_TABLE;

      var $config = array (
  'table' => AFF_REFERALS_TABLE,
  'idField' => 'osdate_aff_referals_id',
  'addedMsg' => 'Osdate Aff Referals %s Added',
  'added_err' => 'Can\\\'t Add Osdate Aff Referals',
  'editMsg' => 'Osdate Aff Referals %s Updated',
  'editErr' => 'Can\\\'t Update Osdate Aff Referals',
  'delErr' => 'Can\\\'t Delete Osdate Aff Referals',
  'delMsg' => 'Osdate Aff Referals %s Deleted',
  'blankErr' => 'Osdate Aff Referals Empty',
  'fields' => 
  array (
    'id' => 
    array (
      'name' => 'id',
      'description' => 'Id',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'affid' => 
    array (
      'name' => 'affid',
      'description' => 'Affid',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'userid' => 
    array (
      'name' => 'userid',
      'description' => 'Userid',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'ip' => 
    array (
      'name' => 'ip',
      'description' => 'Ip',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 255,
      'blank_ok' => 1,
      'duplicate_ok' => 1,
    ),
  ),
);   

      function aff_referalsData() {
      
         $this->Data($this->config);
      }
   }

?>
