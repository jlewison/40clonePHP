<?php
/**
*
*
*
* @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
* @license
* @version SVN:$Id
* @since 2007-06-18
*/
$lang['changepassword_title'] 				= 'Change Password';
$lang['changepassword_old_password'] 		= 'Old Password';
$lang['changepassword_new_password'] 		= 'New Password';
$lang['changepassword_confirm_password'] 	= 'Confirm Password';
$lang['changepassword_submit'] 				= 'Change Password';
$lang['changepassword_success_msg'] 		= 'Password updated successfully!';
$lang['changepassword_error_msg'] 			= 'Sorry,invalid old Password';
?>