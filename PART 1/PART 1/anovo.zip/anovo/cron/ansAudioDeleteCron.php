<?php
require_once ('../common/config.inc.php');
require_once ('../common/configs/config_ans_audio.inc.php');
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['mods']['include_files'][] = 'common/classes/class_ftp.lib.php';
$CFG['mods']['is_include_only']['non_html_header_files'] = true;
$CFG['auth']['is_authenticate'] = false;
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
set_time_limit(0);
class ManageDeleted extends FormHandler
{
		public function deleteAudiosTable()
		{
				$audio_id = $this->audio_details['audio_id'];
				if ($audio_id)
				{
						$tablename_arr = array('ans_audio');
						for ($i = 0; $i < sizeof($tablename_arr); $i++)
						{
								$sql = 'DELETE FROM ' . $this->CFG['db']['tbl'][$tablename_arr[$i]] . ' WHERE audio_id =' . $this->dbObj->Param('audio_id');
								$stmt = $this->dbObj->Prepare($sql);
								$rs = $this->dbObj->Execute($stmt, array($audio_id));
								if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
						}
				}
		}
		public function chkIsLocalServer()
		{
				$server_url = $this->audio_details['audio_server_url'];
				if (strstr($server_url, $this->CFG['site']['url']))
				{
						$server_url = str_replace($this->CFG['site']['url'], '', $server_url);
						if (trim($server_url) == '')
						{
								return true;
						}
				}
				return false;
		}
		public function getServerDetails()
		{
				$server_url = str_replace($this->CFG['admin']['ans_audios']['audio_folder'], '', $this->audio_details['audio_server_url']);
				$sql = 'SELECT ftp_server, ftp_folder, ftp_usrename, ftp_password, category FROM' . ' ' . $this->CFG['db']['tbl']['server_settings'] . ' WHERE server_for=\'Ans_audio\' AND server_url=' . $this->dbObj->Param('server_url') . ' LIMIT 0,1';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($server_url));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if (!$rs->PO_RecordCount()) return false;
				while ($row = $rs->FetchRow())
				{
						$this->fields_arr['ftp_server'] = $row['ftp_server'];
						$this->fields_arr['ftp_folder'] = $row['ftp_folder'];
						$this->fields_arr['ftp_usrename'] = $row['ftp_usrename'];
						$this->fields_arr['ftp_password'] = $row['ftp_password'];
						return true;
				}
				return false;
		}
		public function removeFiles($file)
		{
				if (is_file($file))
				{
						unlink($file);
						return true;
				}
				return false;
		}
		public function deleteDeletedAudio()
		{
				$flv_folder = '../' . $this->CFG['admin']['ans_audios']['audio_folder'];
				if ($this->chkIsLocalServer())
				{
						$flv_filename = $flv_folder . getImageName($this->audio_details['audio_id']);
						$this->removeFiles($flv_filename . '.' . $this->audio_details['audio_ext']);
				}
				else
				{
						if ($this->getServerDetails())
						{
								if ($FtpObj = new FtpHandler($this->fields_arr['ftp_server'], $this->fields_arr['ftp_usrename'], $this->fields_arr['ftp_password']))
								{
										if ($this->fields_arr['ftp_folder']) $FtpObj->changeDirectory($this->fields_arr['ftp_folder']);
										$filename = getImageName($this->audio_details['audio_id']);
										$dir_audio = $this->CFG['admin']['ans_audios']['audio_folder'];
										$FtpObj->deleteFile($dir_audio . $filename . '.' . $this->audio_details['audio_ext']);
										$FtpObj->ftpClose();
								}
						}
				}
				$this->deleteAudiosTable();
				return true;
		}
		public function deleteAudios()
		{
				$sql = 'SELECT audio_id, audio_ext, user_id, audio_for, content_id, audio_server_url' . ' FROM ' . $this->CFG['db']['tbl']['ans_audio'] . ' WHERE' . ' audio_status=\'Deleted\' OR (audio_encoded_status!=\'Yes\' AND' . ' date_added<=DATE_SUB(NOW(),INTERVAL 48 HOUR))';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount())
				{
						$this->audio_details = array();
						while ($row = $rs->FetchRow())
						{
								$this->audio_details = $row;
								echo $row['audio_id'], '<br>';
								$this->deleteDeletedAudio();
						}
				}
		}
}
$ManageDeleted = new ManageDeleted();
$ManageDeleted->setDBObject($db);
$ManageDeleted->makeGlobalize($CFG, $LANG);
$ManageDeleted->deleteAudios();


?>