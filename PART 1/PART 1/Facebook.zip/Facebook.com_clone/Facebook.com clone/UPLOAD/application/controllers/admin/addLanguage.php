<?php
/**
 * Language management Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 02/01/2008
 */
class AddLanguage extends controller
{
		function AddLanguage()
		{
				parent::controller();
				//check login
				if ($this->session->userdata('admin_logged_in') != 1 && $this->session->userdata('admin_id') == '') redirect('admin/login');
				//Load the language file
				$this->lang->load('admin/addLanguage', $this->config->item('language_code'));
				$this->load->model('settingsmodel');
		}
		function index()
		{
				$this->load->library('validation');
				$this->_languageFrm();
				$outputData['languageList'] = $this->settingsmodel->getLanguages();
				if ($this->validation->run() == false) $outputData['validationError'] = $this->validation->error_string;
				else
				{
						if (isset($_POST['add_language']))
						{
								$this->settingsmodel->insertLanguage($_POST);
								//Load the filesystem helper
								$this->load->helper('filesystem');
								//create the new language CSS dir
								copyDir(APPPATH . 'css/en', APPPATH . 'css/' . $this->input->post('lang_code'));
								$fileContents1 = file_get_contents(APPPATH . 'css/' . $this->input->post('lang_code') . '/screen_white.css');
								if ($fileContents1)
								{
										//echo $fileContents1;
										$fileContents1 = str_ireplace('/en/', '/' . $this->input->post('lang_code') . '/', $fileContents1);
										file_put_contents(APPPATH . 'css/' . $this->input->post('lang_code') . '/screen_white.css', $fileContents1);
								}
								$fileContents2 = file_get_contents(APPPATH . 'css/' . $this->input->post('lang_code') . '/style.css');
								if ($fileContents2)
								{
										$fileContents2 = str_ireplace('/en/', '/' . $this->input->post('lang_code') . '/', $fileContents2);
										file_put_contents(APPPATH . 'css/' . $this->input->post('lang_code') . '/style.css', $fileContents2);
								}
								//create the new language images dir
								copyDir(APPPATH . 'images/en', APPPATH . 'images/' . $this->input->post('lang_code'));
								//create the new language language dir
								copyDir(APPPATH . 'language/en', APPPATH . 'language/' . $this->input->post('lang_code'));
								//Set the flash data
								$this->session->set_flashdata('successMsg', $this->lang->line('addlanguage_add_success_msg'));
								redirect('admin/addLanguage');
						}
				}
				$this->smartyextended->view('../admin/addLanguage', $outputData);
		}
		function _languageFrm()
		{
				$rules['lang_code'] = 'trim|required|alphanumeric';
				$rules['lang_name'] = 'trim|required|alphanumeric';
				$fields['lang_code'] = $this->lang->line('addlanguage_lang_code');
				$fields['lang_name'] = $this->lang->line('addlanguage_lang_name');
				$this->validation->set_rules($rules);
				$this->validation->set_fields($fields);
		}
		#***************************************************************************
		#Method			: deleteLanguage
		#Description	: deleted language
		#Author			
		#***************************************************************************
		function deleteLanguage()
		{
				if ($this->uri->segment(4))
				{
						$languageDetails = $this->settingsmodel->getLanguageDetails($this->uri->segment(4));
						//Load the filesystem helper
						$this->load->helper('filesystem');
						//delete the CSS dir
						@deleteDir(APPPATH . 'css/' . $languageDetails['lang_code'] . '/');
						//delete the images dir
						@deleteDir(APPPATH . 'images/' . $languageDetails['lang_code'] . '/');
						//delete the language dir
						@deleteDir(APPPATH . 'language/' . $languageDetails['lang_code'] . '/');
						$this->settingsmodel->deleteLanguage($this->uri->segment(4));
						//Set the flash data
						$this->session->set_flashdata('successMsg', $this->lang->line('addlanguage_delete_success_msg'));
						redirect('admin/addLanguage');
				}
				else
				{
						$outputData['languageList'] = $this->lang->line('addlanguage_error');
						$this->smartyextended->view('../admin/eventCategory', $outputData);
				}
		}
}
?>