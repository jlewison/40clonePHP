<?php
echo '<?xml version="1.0"?>
' . "\n"; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html lang="en-US" dir="ltr" xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="application/xhtml+xml; charset=UTF-8" />
<meta http-equiv="content-Language" content="en-US" />
<meta name="keywords" content="<?php echo $CFG['html']['meta']['keywords']; ?>" />
<meta name="description" content="<?php echo $CFG['html']['meta']['description']; ?>" />
<?php
if ($CFG['html']['meta']['MSSmartTagsPreventParsing'])
{
?>
<!-- Disable MSSmartTags -->
<meta name="MSSmartTagsPreventParsing" content="true" />
<?php
}
if (!$CFG['html']['meta']['imagetoolbar'])
{
?>
<!-- Disable IE6 image toolbar -->
<meta http-equiv="imagetoolbar" content="no" />
<?php
}
$default_style_name = $CFG['html']['stylesheet']['screen']['default'];
$default_style_title = $CFG['html']['stylesheet']['screen']['available_stylesheets'][$default_style_name];
$style_titles = array_values($CFG['html']['stylesheet']['screen']['available_stylesheets']);
$onLoadFunction = '';
if ($CFG['html']['stylesheet']['screen']['is_style_support'])
{
		$selected_style_title = '';
		if (!empty($_GET['style']))
		{
				$selected_style_title = $_GET['style'];
		}
		else
				if (!empty($_POST['style']))
				{
						$selected_style_title = $_POST['style'];
				}
				else
						if (!empty($_COOKIE['style']))
						{
								$selected_style_title = $_COOKIE['style'];
						}
						else
								if (!empty($_SESSION['user']['pref_style']))
								{
										$selected_style_title = $_SESSION['user']['pref_style'];
								}
		if (in_array($selected_style_title, $style_titles)) $default_style_title = $selected_style_title;
		if ($default_style_title == 'White') $default_style_name = 'screen_white';
}
$Default = $White = '';
if ($default_style_title)
{
		$_SESSION['user']['pref_style'] = $default_style_title;
		setcookie('style', $default_style_title, time() + 4320000, '/');
		$$default_style_title = 'clsActiveTheme';
?>
<link rel="stylesheet" type="text/css" href="<?php echo $CFG['site']['url']; ?>members/css/<?php echo $default_style_name; ?>.css" media="screen" title="<?php echo $default_style_title; ?>" />
<?php
}
if ($CFG['html']['stylesheet']['screen']['is_style_support'])
{
		foreach ($CFG['html']['stylesheet']['screen']['available_stylesheets'] as $style_name => $style_title)
		{
				if ($default_style_title != $style_title)
				{
?>
<link rel="alternate stylesheet" type="text/css" href="<?php echo $CFG['site']['url']; ?>members/css/<?php echo $style_name; ?>.css" media="screen" title="<?php echo $style_title; ?>" />
<?php
				}
		}
}


?>
<link rel="stylesheet" type="text/css" href="<?php echo $CFG['site']['url']; ?>css/print.css" media="print" />
<link rel="shortcut icon" href="<?php echo $CFG['site']['url']; ?>favicon.ico" type="image/x-icon" />
<?php






?>
<!-- for link bar -->
<link rel="Home"     href="<?php echo URL($CFG['site']['url']); ?>" title="Home page" />
<link rel="Index"    href="<?php echo URL($CFG['site']['url']); ?>" title="Index" />
<link rel="search"   href="<?php echo '#'; ?>" title="Search this site" />
<link rel="contents" href="<?php echo '#'; ?>" title="Site map" />
<script type="text/javascript"	src="<?php echo $CFG['site']['url']; ?>js/script.js"></script>
<title><?php echo $CFG['site']['title']; ?></title>
</head>
<body>
<div id="<?php echo $CFG['html']['page_id']; ?>" class="clsBodyContent clsPopupHeader">
<!-- Accessibility Links -->
<div id="top">
  <ul>
    <li><a href="#main">Skip to main content</a></li>
    <li><a href="#selSubHeader">Skip to Navigation Links</a></li>
    <li><a href="#footer">Skip to Footer</a></li>
  </ul>
</div>
<!-- Header -->
<div id="header" href="<? echo $CFG['site']['relative_url']; ?>">
  <h1><a href="<?php echo $CFG['site']['relative_url']; ?>home/" title="Browse to homepage"><?php echo $CFG['site']['name']; ?></a></h1>
</div>

<!-- Main -->
<div id="main">
<!-- Header ends -->
