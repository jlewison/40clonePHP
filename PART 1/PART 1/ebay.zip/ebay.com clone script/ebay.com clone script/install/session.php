<?php //00461
// Copyright Notice
// Web Site URL:  http://www.zeeways.com
// Script Owner eMail: mail@zeeways.com
// Date: April, 2007
// Script Name: Zeeways Auction Website PHP Script
// Copyright Details: This script is not free.  Do not Remove this Copy Right notice.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the site administrator.');exit(199);
?>
4+oV5FyLSdbE8Tf1OYZ8x6swwhyKUV7IZK0mRgsiCpFykGMhnERtren3GzKGlup7XalCMNIwdopw
Bxnqz75czagxtjCntfpqXmnGLkmm2sNvllAZTgAq1mXxKr8DWFHh1PO/9IneOATtXaCzbPGbwQms
H6U9O+zY1VtqvmWPPSEBICvkKCDHTYaPqAov/FfFPwkjUZ6YLrvgJTJceXP6wNmNjtcz9zhGYVTC
ol638BLSbrD+SMH2dT+fbgOq34npzoskINwscd0HWx5booT97g6ABPPAsfpvWmXmMEIjnAw0Z0VA
G7q8CMDkcF66NQbuy4pemMML293ZAW6E0DIJrHEPXx3YAmK+Ns4kUdI+bSX3d+79sURycpBbEgCw
EI1dOCeMuj/jMInCDLSVSGFbwtPiPZEGPZv6fcWsQyRSWfXGEdZbYDpo6cUoNnBdnKE5BUOuPpQr
fiiYyUt16UN6vAPl6Ndtn9vR+1N10lndl8luQdlo4zvyVX48Q6VWhASYL2MT