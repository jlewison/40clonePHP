<?php include('ip_domain_ban.php'); include('settings.php'); ?>

<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_GMQ = "-1";
if (isset($_GET['dtu'])) {
  $colname_GMQ = $_GET['dtu'];
}
mysql_select_db($database_apound, $apound);
$query_GMQ = sprintf("SELECT dtu, gm_str, gm_str_nr, gm_city, gm_county, gm_country FROM main WHERE dtu = %s", GetSQLValueString($colname_GMQ, "int"));
$GMQ = mysql_query($query_GMQ, $apound) or die(mysql_error());
$row_GMQ = mysql_fetch_assoc($GMQ);
$totalRows_GMQ = mysql_num_rows($GMQ);
?>

<?php
$gm_str_nr = $row_GMQ['gm_str_nr'];
$gm_str = $row_GMQ['gm_str'];
$gm_city = $row_GMQ['gm_city'];
$gm_county = $row_GMQ['gm_county'];
$gm_country = $row_GMQ['gm_country'];
?>

<?php $address = "$gm_str_nr, $gm_str, $gm_city, $gm_county, $gm_country";?>

<?php mysql_free_result($GMQ); ?>

<?php //$address = "1600 Amphitheatre Pky, Mountain View, CA"; ?>


    <script src="http://maps.google.com/maps?file=api&amp;v=2.x&amp;key=<?php echo("$google_m_k");?>" type="text/javascript"></script>
    <script type="text/javascript">

    var map = null;
    var geocoder = null;
	var address = '<?php echo("$address");?>';

    function initialize() {
      if (GBrowserIsCompatible()) {
        map = new GMap2(document.getElementById("map_canvas"));
        geocoder = new GClientGeocoder();
      }
    }

    function showAddress(address) {
      if (geocoder) {
        geocoder.getLatLng(
          address,
          function(point) {
            if (!point) {
              alert(address + " not found");
            } else {
              map.setCenter(point, 13);
              var marker = new GMarker(point);
              map.addOverlay(marker);
              marker.openInfoWindowHtml(address);
            }
          }
        );
      }
    }
    </script>

  <style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
-->
</style>
<body onLoad="initialize(); showAddress(address)">
      <div id="map_canvas" style="width: 500px; height: 300px"></div>
  </body>

