<?php
$lang['page_title']	= 'Profile';
$lang['profile_basic_networks']				= 'Networks';

$lang['profile_basic_sex']					= 'Sex';
$lang['profile_basic_birthday']				= 'Birthday';
$lang['profile_basic_hometown']				= 'Hometown';
$lang['profile_basic_relegiousview']		= 'Religious Views';
$lang['profile_contact_title']				= 'Contact';

$lang['profile_contact_email']				= 'Email';
$lang['profile_contact_address']			= 'Address';
$lang['profile_contact_city']				= 'City';
$lang['profile_contact_country']			= 'Country';
$lang['profile_contact_state']				= 'State';
$lang['profile_contact_zipcode']			= 'Zip code';
$lang['profile_contact_website']			= 'Website';
$lang['profile_contact_mobile']				= 'Mobile';
$lang['profile_contact_land_line']			= 'Land Phone';

$lang['profile_personal_title']				= 'Personal';
$lang['profile_personal_activities']		= 'Activities';
$lang['profile_personal_interests']			= 'Interests';
$lang['profile_personal_favorite_music']	= 'Favorite Music';
$lang['profile_personal_favorite_tvshows']	= 'Favorite TV Shows';
$lang['profile_personal_favorite_movies']	= 'Favorite Movies';
$lang['profile_personal_favorite_books']	= 'Favorite Books';
$lang['profile_personal_favorite_quotes']	= 'Favorite Quotes';
$lang['profile_personal_about_me']			= 'About Me';

$lang['profile_work_title']					= 'Work';
$lang['profile_work_employer']				= 'Employer';
$lang['profile_work_position']				= 'Position';
$lang['profile_work_description']			= 'Description';
$lang['profile_work_time_period']			= 'Time Period';
$lang['profile_work_location']				= 'Location';

$lang['profile_education_work_title']		= 'Education and Work';
$lang['profile_education_title']			= 'Education';
$lang['profile_education_college']			= 'College';
$lang['profile_education_high_school']		= 'High School';


$lang['profile_restricted']		= 'The user\'s profile you trying to view is not availabe as the user does not allow it';

$lang['profile_jan']		= 'January';
$lang['profile_feb']		= 'February';
$lang['profile_mar']		= 'March';
$lang['profile_apr']		= 'April';
$lang['profile_may']		= 'May';
$lang['profile_jun']		= 'June';
$lang['profile_jul']		= 'July';
$lang['profile_aug']		= 'August';
$lang['profile_sep']		= 'September';
$lang['profile_oct']		= 'October';
$lang['profile_nov']		= 'November';
$lang['profile_dec']		= 'December';


$lang['profile_welcome']		= 'Welcome';
$lang['profile_update_status']	= 'Update your status';
$lang['profile_cancel']			= 'Cancel';
$lang['profile_update_photo']	= 'Update profile picture';
$lang['profile_send_im']		= 'Send IM';
$lang['profile_online_now']		= 'I am online now';
$lang['profile_compose']		= 'compose';
$lang['profile_group']			= 'group';
$lang['profile_video']			= 'video';
$lang['profile_friends']		= 'Friends';
$lang['profile_see_all']		= 'See all';
$lang['profile_no_friends']		= 'You have no friends';
$lang['profile_groups']			= 'Groups';
$lang['profile_marketplace']	= 'Marketplace'; 
$lang['profile_market_nothing']	= 'Nothing here'; 
$lang['profile_market_listed']	= 'Listed by'; 
$lang['profile_market_listed_on']= 'Listed on';
$lang['profile_market_add_listing']= 'Add Listing'; 
 
$lang['profile_none']			= 'None';
$lang['profile_info']			= 'Information';
$lang['profile_edit']			= 'edit';
$lang['profile_email']			= 'Email';
$lang['profile_contact_info']	= 'Contact info';
$lang['profile_wall_title']		= 'The Wall';
$lang['profile_displaying']		= 'Displaying';
$lang['profile_of']				= 'of';
$lang['profile_posts']			= 'posts';
$lang['profile_wrote']			= 'wrote';
$lang['profile_at']				= 'at';
$lang['profile_write_on']		= 'Write on';
$lang['profile_my']				= 'my';
$lang['profile_wall']			= 'Wall';
$lang['profile_delete']			= 'Delete';
$lang['profile_minifeed']		= 'Mini-Feeds';
$lang['profile_stories']		= 'stories';
$lang['profile_delete_confirm']	= 'Delete Minifeed confirmation';
$lang['profile_delete_question']= 'Are you sure, you want to delete this minifeed';

$lang['profile_blocked']		= 'The user whose profile you are trying to view has blocked you, so you cannot view his profile.';
$lang['profile_posted_items']	= 'Posted Items';

$lang['profile_status']			= 'Status';

?>