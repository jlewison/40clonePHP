<?php include('template/BrownLBS/top_side.php');?>

<!--
###################################################################################
#######################                                     #######################
#######################   M A I N   S E C T I O N   Start   #######################
#######################                                     #######################
###################################################################################
-->

<h1><?php echo("$lang_41");?></h1>

<div class="content">

<?php if($totalRows_SEARlista <> '') { ?>

	<div id="stop"><?php echo("$lang_25");?> <?php echo ($startRow_SEARlista + 1) ?> <?php echo("$lang_26");?> <?php echo min($startRow_SEARlista + $maxRows_SEARlista, $totalRows_SEARlista) ?> <?php echo("$lang_27");?> <?php echo $totalRows_SEARlista ?> <?php echo("$lang_28");?></div><br>


		<table border="0" cellspacing="0" cellpadding="0">
		<?php do { ?>
        <tr><td>

			<?php $wsn = $row_SEARlista['title']; $step8 = str_replace(" ", "-", $wsn); $wsseoname = "$step8"; ?>

            <div class="listing">
		<img class="listingPrev" src="http://open.thumbshots.org/image.aspx?url=<?php echo $row_SEARlista['site']; ?>" alt="<?php echo $row_top_BID['title']; ?>" height="68" width="84" />
		<h3><a href="<?php echo $row_SEARlista['site']; ?>" target="_blank"><?php echo $row_SEARlista['title']; ?></a></h3>
                <?php echo $row_SEARlista['descr1']; ?>
                
          
            
          <div class="listingD">
		  <?php echo $row_SEARlista['site']; ?> :: <?php echo("$lang_5");?> <?php echo $row_SEARlista['stad']; ?> <?php if($fremode == 'N') { ?> :: <?php echo $row_SEARlista['bid']; ?> <?php echo("$lang_29");?> <?php } else { } ?>
            <a href="<?php echo("$path");?><?php echo $row_SEARlista['dtu'];?>/<?php echo("$wsseoname"); ?>.html"><?php echo("$lang_7");?></a>
            <?php if($fremode == 'N') { ?> <a href="<?php echo("$path");?>upgrade.php?ucat=<?php echo $row_SEARlista['dtu']; ?>"><?php echo("$lang_8");?></a> <?php } else { } ?>
          </div>

<?php if($prenabled == 'Y' and $enb_search == 'Y') { ?>

	<?php include('pr_update_search.php');?>
    
    <div id="stats">		

<a target="_blank" rel="nofollow" href="http://digg.com/submit?phase=2&url=<?php echo $row_lista['site']; ?>&title=Air Tickets&bodytext= "><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/diggIcon.gif" alt="Digg It!" border="0px" /></a> 
<a target="_blank" rel="nofollow" href="http://www.google.com/bookmarks/mark?op=edit&bkmk=<?php echo $row_lista['site']; ?>&title=Air Tickets"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/googleIcon.gif" alt="Google Bookmarks" border="0px" /></a> 
<a target="_blank" rel="nofollow" href="http://co.mments.com/track?url=<?php echo $row_lista['site']; ?>&title=Air Tickets"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/commentsIcon.gif" alt="co.mments" border="0px" /></a>                
<a target="_blank" rel="nofollow" href="http://ma.gnolia.com/bookmarklet/add?url=<?php echo $row_lista['site']; ?>&title=Air Tickets"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/magnoliaIcon.gif" alt="Ma.gnolia.com" border="0px" /></a>                
<a target="_blank" rel="nofollow" href="http://www.spurl.net/spurl.php?url=<?php echo $row_lista['site']; ?>&title=Air Tickets"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/spurlIcon.gif" alt="Spurl.net" border="0px" /></a>                
<a target="_blank" rel="nofollow" href="http://technorati.com/cosmos/search.html?url=<?php echo $row_lista['site']; ?>"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/technoratiIcon.gif" alt="Technorati" border="0px" /></a> 
<a target="_blank" rel="nofollow" href="http://reddit.com/submit?url=<?php echo $row_lista['site']; ?>&title=Air Tickets"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/redditIcon.gif" alt="reddit" border="0px" /></a> 
<a target="_blank" rel="nofollow" href="http://www.stumbleupon.com/submit?url=<?php echo $row_lista['site']; ?>&title=Air Tickets"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/stumbleuponIcon.gif" alt="StumbleUpon" border="0px" /></a> 
<a target="_blank" rel="nofollow" href="http://www.furl.net/storeIt.jsp?u=<?php echo $row_lista['site']; ?>&t=Air Tickets"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/furlIcon.gif" alt="Furl" border="0px" /></a> 
<a target="_blank" rel="nofollow" href="http://del.icio.us/post?url=<?php echo $row_lista['site']; ?>&title=Air Tickets&notes= "><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/deliciousIcon.gif" alt="Del.icio.us" border="0px" /></a>
<a target="_blank" rel="nofollow" href="http://www.netscape.com/submit/?U=<?php echo $row_lista['site']; ?>&T=Air Tickets"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/netscapeIcon.gif" alt="Netscape" border="0px" /></a> 
<a target="_blank" rel="nofollow" href="http://myweb2.search.yahoo.com/myresults/bookmarklet?u=<?php echo $row_lista['site']; ?>&t=Air Tickets"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/yahooIcon.gif" alt="Yahoo! Bookmarklet" border="0px" /></a>

    </div>

<div class="line"></div>

<?php } else {} ?>

</div>
		</td></tr>
		<?php } while ($row_SEARlista = mysql_fetch_assoc($SEARlista)); ?>
		</table>

	    <div id="sumitlink"><a href="<?php echo("$path");?>submit.php"><?php echo("$lang_31");?></a></div>

<?php } else { ?>
	<div id="notlink"><?php echo("$lang_42");?></div>
<?php } ?>
<table  border="0" cellpadding="0" cellspacing="1">
  <tr>
    <td>
	
<?php if ($pageNum_SEARlista > 0) { // Show if not first page ?>
<a href="<?php echo("$path");?><?php echo("0");?>/<?php echo("$totalRows_SEARlista");?>/<?php echo("$categ");?>/">&lt;&lt; <?php echo("$lang_35");?></a>
<?php } // Show if not first page ?>

<?php if ($pageNum_SEARlista > 0) { // Show if not first page ?>
<a href="<?php echo("$path");?><?php $mb = max(0, $pageNum_SEARlista - 1); echo("$mb");?>/<?php echo("$totalRows_SEARlista");?>/<?php echo("$categ");?>/">&lt; <?php echo("$lang_36");?></a>
<?php } // Show if not first page ?>

<?php if ($pageNum_SEARlista < $totalPages_SEARlista) { // Show if not last page ?>
<a href="<?php echo("$path");?><?php $mb = min($totalPages_SEARlista, $pageNum_SEARlista + 1); echo("$mb");?>/<?php echo("$totalRows_SEARlista");?>/<?php echo("$categ");?>/"><?php echo("$lang_37");?> &gt;</a>
<?php } // Show if not last page ?>

<?php if ($pageNum_SEARlista < $totalPages_SEARlista) { // Show if not last page ?>
<a href="<?php echo("$path");?><?php $mb = min($totalPages_SEARlista, $pageNum_SEARlista + 1); echo("$totalPages_SEARlista");?>/<?php echo("$totalRows_SEARlista");?>/<?php echo("$categ");?>/"><?php echo("$lang_38");?> &gt;&gt;</a>
<?php } // Show if not last page ?>
    
    </td>
  </tr>
</table>

</div>
<!--
###################################################################################
#######################                                     #######################
#######################    M A I N   S E C T I O N   End    #######################
#######################                                     #######################
###################################################################################
-->

<?php include('template/BrownLBS/bottom_side.php');?>
<?php include('template/BrownLBS/footer.php'); ?>