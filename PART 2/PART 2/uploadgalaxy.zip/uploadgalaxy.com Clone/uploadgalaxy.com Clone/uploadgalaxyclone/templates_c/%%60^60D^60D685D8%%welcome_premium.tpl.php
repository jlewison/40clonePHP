<?php /* Smarty version 2.6.6, created on 2006-03-11 11:17:14
         compiled from welcome_premium.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'cycle', 'welcome_premium.tpl', 90, false),)), $this); ?>
<html>

<head>
<title>Welcome Mr. <?php echo $_COOKIE['uname']; ?>
</title>
<!--<?php echo '-->
<link href="templates/style.css" rel="stylesheet" type="text/css">
<!--'; ?>
-->

</head>

<body>
<p align=center>
<table border="0" width="600" height="129" cellspacing="0" cellpadding="0">
  <tr>
    <td width="600" height="250" valign="top">
      <table border="0" width="100%" cellspacing="0" cellpadding="0" height="314">
        <tr>
          <td width="100%" height="29" colspan="2">
<!---------------------------------------------------------------->          
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "header.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<!---------------------------------------------------------------->
          </td>
        </tr>
        <tr>
          <td width="100%" height="29" colspan="2">
          <p align="left">
          <font face="Verdana" size="2" color="#7777D2"><b>Premium Members Area</b></font>
          </p>
          </td>
        </tr>
        <tr>
          <td width="84%" height="49" bgcolor="#F2F2FF">
            &nbsp;
          </td>
          <td width="16%" height="49" bgcolor="#F2F2FF">
            <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%">
                  <tr>
                    <td width="179%" align=right>
                    <p>
                    <a class="link" href="index.php">Upload</a></p></td>
                  </tr>
                  <tr>
                    <td width="179%" align=right>
                    <p>
                    <a class="link" title="Go to my  file manager..." href="welcome_premium.php">
                    File Manager</a></p></td>
                  </tr>
                  <tr>
                    <td width="179%" align=right>
                    <a class="link1" title="Log out" href="logout.php">Logout</a></td>
                  </tr>
                  </table>
          </td>
        </tr>
        
        
        <tr>
          <td width="100%" height="18" align="center" colspan="2">
          <p align="left">Your membership is valid for <?php echo $this->_tpl_vars['mv']; ?>

          </td>
        </tr>
        
        
        <tr>
          <td width="100%" height="127" valign="top" colspan="2">          
            <table border="0" width="100%" cellspacing="0" cellpadding="0" height="202">
              <tr>
                <td width="44%" align="right" height="175" valign="top">
                  <table border="0" width="100%" height="30" bgcolor="#C0C0C0" cellspacing="0" cellpadding="0">
                    <tr>
                      <th width="22%" height="24" valign="middle" align="left" bgcolor="#EBF1F1">
                        <p align="left"><b><font color="#000000">&nbsp;&nbsp;</font>Name</b></th>
                      <th width="10%" height="24" valign="middle" align="left" bgcolor="#EBF1F1">
                        <p align="left"><b>Size</b></th>
                      <th width="22%" height="24" valign="middle" align="left" bgcolor="#EBF1F1">
                        <b><p align=left> Recipient</b></th>
                      <th width="7%" height="24" valign="middle" align="left" bgcolor="#EBF1F1">
                        <p align="left"><b># D/L</b></th>
                      <th width="13%" height="24" valign="middle" align="left" bgcolor="#EBF1F1">
                        <p align="left"><b>Expired</b></th>
                      <th width="6%" height="24" valign="middle" align="left" bgcolor="#EBF1F1">
                        <b>Action</b></th>
                    </tr>
                    <tr>
                      <td width="100%" height="1" valign="middle" align="left" colspan="6" bgcolor="#FFFFFF"></td>
                    </tr>
<!----------------------------------------------------------------------------------------------->                    
				   <?php if ($this->_tpl_vars['mv'] != '0 days'): ?>
                   <?php unset($this->_sections['i']);
$this->_sections['i']['name'] = 'i';
$this->_sections['i']['loop'] = is_array($_loop=$this->_tpl_vars['myfile']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['i']['show'] = true;
$this->_sections['i']['max'] = $this->_sections['i']['loop'];
$this->_sections['i']['step'] = 1;
$this->_sections['i']['start'] = $this->_sections['i']['step'] > 0 ? 0 : $this->_sections['i']['loop']-1;
if ($this->_sections['i']['show']) {
    $this->_sections['i']['total'] = $this->_sections['i']['loop'];
    if ($this->_sections['i']['total'] == 0)
        $this->_sections['i']['show'] = false;
} else
    $this->_sections['i']['total'] = 0;
if ($this->_sections['i']['show']):

            for ($this->_sections['i']['index'] = $this->_sections['i']['start'], $this->_sections['i']['iteration'] = 1;
                 $this->_sections['i']['iteration'] <= $this->_sections['i']['total'];
                 $this->_sections['i']['index'] += $this->_sections['i']['step'], $this->_sections['i']['iteration']++):
$this->_sections['i']['rownum'] = $this->_sections['i']['iteration'];
$this->_sections['i']['index_prev'] = $this->_sections['i']['index'] - $this->_sections['i']['step'];
$this->_sections['i']['index_next'] = $this->_sections['i']['index'] + $this->_sections['i']['step'];
$this->_sections['i']['first']      = ($this->_sections['i']['iteration'] == 1);
$this->_sections['i']['last']       = ($this->_sections['i']['iteration'] == $this->_sections['i']['total']);
?>                     
                    <tr bgcolor=<?php echo smarty_function_cycle(array('values' => "#EFEFEF,#DFDFDF"), $this);?>
>
                      <td height="24" valign="middle" align="left"><p align=left>&nbsp;<?php echo $this->_tpl_vars['myfile'][$this->_sections['i']['index']]['file_name']; ?>
</td>
                      <td height="24" valign="middle" align="left"><p align=left><?php echo $this->_tpl_vars['myfile'][$this->_sections['i']['index']]['size']; ?>
 B</td>
                      <td height="24" valign="middle" align="left"><p align=left><?php echo $this->_tpl_vars['myfile'][$this->_sections['i']['index']]['recipient']; ?>
</td>
                      <td height="24" valign="middle" align="left"><p align=left><?php echo $this->_tpl_vars['myfile'][$this->_sections['i']['index']]['no_of_dwnld']; ?>
</td>
                      <td height="24" valign="middle" align="left"><p align=left><?php echo $this->_tpl_vars['myfile'][$this->_sections['i']['index']]['expire_time']; ?>
</td>
                      <td height="24" valign="middle" align="left">
                      <p align=center>&nbsp;<a href="remove.php?key=<?php echo $this->_tpl_vars['myfile'][$this->_sections['i']['index']]['idkey']; ?>
">Delete</a></td>
                    </tr>
<!----------------------------------------------------------------------------------------------->                    
                    <tr>
                      <td width="100%" height="1" valign="middle" align="left" colspan="6" bgcolor="#FFFFFF"></td>
                    </tr>
                   <?php endfor; endif; ?> 
                   <?php else: ?>
                   <tr><td colspan=6><font color=red>This option is frozen. Buy a memdership package to activate.</font></td></tr>
                   <?php endif; ?>
                  </table>
                  <p align="right">
                  <p align="left">
                  <p align="left"></td>
              </tr>
              <tr>
                <td width="44%" align="right" height="27">
                  <p align="center">
<!--------------------------------------------------------------------------------------------------------->                         
                  <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "premium_packages.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<!--------------------------------------------------------------------------------------------------------->                          
                  <p align="left"></td>
              </tr>
            </table>
          </td>
        </tr>
        <tr>
          <td width="100%" height="18" colspan="2">
          
          
          </td>
        </tr>
        <tr>
          <td width="100%" height="48" bgcolor="#F7F3FF" colspan="2"></td>
        </tr>
        <tr>
<!--------------------------------------------------------------------------------------------------------->        
   <td width="100%" height="25" colspan="2">
<p align="center"><?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "bottom_link.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
          
          </td>
<!--------------------------------------------------------------------------------------------------------->                  
        </tr>
      </table>
    </td>
  </tr>
  <tr>
    <td width="600" height="25"><img border="0" src="images/bottomLine.gif" width="600" height="18">      
    </td>
  </tr>
  <tr>
    <td width="600" height="109" valign="top" align="center">
 <p>&nbsp;</p>
<!--------------------------------------------------------------------------------------------------------->             
      <p><b><font color="#FF0000">Important Service Announcement:</font><br>      
      <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "msg1title.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
      </b></p>
      <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "msg1.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>      
<!--------------------------------------------------------------------------------------------------------->              
      </td>
  </tr>
  <tr>
    <td width="600" height="15" valign="top">
    <p align="center"><?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>      
      </td>
  </tr>
</table>
</body>

</html>