<?php
updateAdvertisementCount();
if ($CFG['html']['is_use_footer'])
{
		require_once ($CFG['site']['project_path'] . sprintf($CFG['html']['footer'], $CFG['lang']['default']));
}
if ($CFG['debug']['is_debug_mode'])
{
		if ($DEBUG_TRACE)
		{
				echo "\n\n" . '<!--' . "\n";
				echo '<debugtrace>' . "\n";
				echo $DEBUG_TRACE;
				echo '</debugtrace>' . "\n\n";
				echo '-->';
		}
}
if ($CFG['db']['abodb_lite'])
{
		if ($CFG['debug']['is_db_debug_mode'] && $CFG['db']['is_use_db'])
		{
				if ($CFG['db']['explain_query'])
				{
?>
<style type="text/css">
	table.tableQueryExplained{
		width:auto;
	}
	table.tableQueryExplained td{
		text-align:left;
	}
	table.tableQueryExplained tr.trFileSort td{
		color:red;
	}
</style>
<?php
						$queries = $db->query_list;
						if ($queries)
						{
								$dbCon = mysql_connect($CFG['db']['hostname'], $CFG['db']['username'], $CFG['db']['password']);
								mysql_select_db($CFG['db']['name'], $dbCon);
								$queryExplained = array();
								$indexCount = 0;
								foreach ($queries as $query)
								{
										$query = trim($query);
										if (empty($query)) continue;
										$query = str_replace('&gt;', '>', $query);
										$query = str_replace('&lt;', '<', $query);
										$explainQuery = 'EXPLAIN ' . $query;
										$res = @mysql_query($explainQuery, $dbCon);
										if ($res and @mysql_num_rows($res) > 0)
										{
												$row = mysql_fetch_array($res, MYSQL_ASSOC);
												mysql_free_result($res);
												$queryExplained[$indexCount] = $row;
												$queryExplained[$indexCount]['sql_query'] = $query;
												$indexCount++;
										}
								}
						}
						if ($queryExplained)
						{
								$listingIndex = array('sql_query', 'select_type', 'table', 'Extra', 'rows', 'key', 'key_len');
								$queryTable = '';
								$queryTable .= '<table class="tableQueryExplained">';
								$queryTable .= '<tr>';
								foreach ($listingIndex as $field)
								{
										$queryTable .= '<th>' . $field . '</th>';
								}
								$queryTable .= '</tr>';
								foreach ($queryExplained as $queryDetails)
								{
										$extra = $queryDetails['Extra'];
										$isFileSort = stristr($extra, 'filesort');
										$trStyle = $isFileSort ? 'class="trFileSort"' : '';
										$queryTable .= '<tr ' . $trStyle . '>';
										foreach ($listingIndex as $field)
										{
												$queryTable .= '<td>' . $queryDetails[$field] . '</td>';
										}
										$queryTable .= '</tr>';
								}
								$queryTable .= '</table>';
								print $queryTable;
						}
				}
				echo "\n\n" . '<!--' . "\n";
				echo '<benchmark>' . "\n";
				for ($i = 0; $i < count($db->query_list); $i++)
				{
						echo '(' . round($db->query_list_time[$i], 5) . ') : ' . $db->query_list[$i] . "\n\n";
				}
				echo '</benchmark>' . "\n";
				echo '-->';
		}
}
else
{
		if ($CFG['debug']['is_db_debug_mode'] && $CFG['db']['is_use_db'])
		{
				if ($CFG['db']['explain_query'])
				{
?>
<style type="text/css">
	table.tableQueryExplained{
		width:auto;
	}
	table.tableQueryExplained td{
		text-align:left;
	}
	table.tableQueryExplained tr.trFileSort td{
		color:red;
	}
</style>
<?php
						$queries = $SQL_QUERIES;
						$queries = str_replace('<hr />', '', $queries);
						$queries = str_replace('(mysqli): ', '', $queries);
						$queries = str_replace('&nbsp;', '', $queries);
						$queries = explode("\n", $queries);
						$queries = array_unique($queries);
						if ($queries)
						{
								$dbCon = mysql_connect($CFG['db']['hostname'], $CFG['db']['username'], $CFG['db']['password']);
								mysql_select_db($CFG['db']['name'], $dbCon);
								$queryExplained = array();
								$indexCount = 0;
								foreach ($queries as $query)
								{
										$query = trim($query);
										if (empty($query)) continue;
										$query = str_replace('&gt;', '>', $query);
										$query = str_replace('&lt;', '<', $query);
										$explainQuery = 'EXPLAIN ' . $query;
										$res = @mysql_query($explainQuery, $dbCon);
										if ($res and @mysql_num_rows($res) > 0)
										{
												$row = mysql_fetch_array($res, MYSQL_ASSOC);
												mysql_free_result($res);
												$queryExplained[$indexCount] = $row;
												$queryExplained[$indexCount]['sql_query'] = $query;
												$indexCount++;
										}
								}
						}
						if ($queryExplained)
						{
								$listingIndex = array('sql_query', 'select_type', 'table', 'Extra', 'rows', 'key', 'key_len');
								$queryTable = '';
								$queryTable .= '<table class="tableQueryExplained">';
								$queryTable .= '<tr>';
								foreach ($listingIndex as $field)
								{
										$queryTable .= '<th>' . $field . '</th>';
								}
								$queryTable .= '</tr>';
								foreach ($queryExplained as $queryDetails)
								{
										$extra = $queryDetails['Extra'];
										$isFileSort = stristr($extra, 'filesort');
										$trStyle = $isFileSort ? 'class="trFileSort"' : '';
										$queryTable .= '<tr ' . $trStyle . '>';
										foreach ($listingIndex as $field)
										{
												$queryTable .= '<td>' . $queryDetails[$field] . '</td>';
										}
										$queryTable .= '</tr>';
								}
								$queryTable .= '</table>';
								print $queryTable;
						}
				}
				echo "\n\n" . '<!--' . "\n";
				echo '<benchmark>' . "\n";
				echo $SQL_QUERIES;
				echo '</benchmark>' . "\n";
				echo '-->';
		}
		if ($CFG['benchmark']['query_time']['is_expose'] && $CFG['db']['is_use_db'])
		{
				echo "\n\n" . '<!--' . "\n";
				echo '<benchmark>' . "\n";
				echo '  <querytime>' . "\n";
				$query_timings_arr = $db->getQueryTimings();
				foreach ($query_timings_arr as $key => $query_and_time_arr)
				{
						foreach ($query_and_time_arr as $query => $query_time)
						{
								$query = ($CFG['benchmark']['query_time']['is_expose_query']) ? htmlspecialchars($query) : md5($query);
								echo '   <sec>' . $query_time . '</sec><sql>' . $query . '</sql>' . "\n";
						}
				}
				echo '  </querytime>' . "\n";
				echo '</benchmark>' . "\n";
				echo '-->';
		}
}
if ($CFG['benchmark']['is_expose_parse_time'])
{
		$CFG['parse_time']['end'] = explode(' ', microtime());
		$CFG['parse_time']['total'] = number_format(($CFG['parse_time']['end'][1] + $CFG['parse_time']['end'][0] - ($CFG['parse_time']['start'][1] + $CFG['parse_time']['start'][0])), 5);
		echo "\n\n" . '<!--' . "\n";
		echo '<benchmark>' . "\n";
		echo '  <parsetime>' . "\n";
		echo '    <sec>' . $CFG['parse_time']['total'] . '</sec>' . "\n";
		echo '  </parsetime>' . "\n";
		echo '</benchmark>' . "\n";
		echo '-->';
}
if ($CFG['debug']['is_custom_handler'])
{
		echo $errHandler->processTrappedErrors();
}


?>