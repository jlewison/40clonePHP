<?php //00461
// Copyright Notice
// Web Site URL:  http://www.zeeways.com
// Script Owner eMail: mail@zeeways.com
// Date: April, 2007
// Script Name: Zeeways Auction Website PHP Script
// Copyright Details: This script is not free.  Do not Remove this Copy Right notice.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the site administrator.');exit(199);
?>
4+oV5DEoX/D0ctp42GSIq5pQIIhi7KVXC+bmxeIiq62T0vRvKnt7JDJz3MrAJvVGUeyNWgthB7ys
1J8CSUw27jVsrsK6i3kuNebCmzt+/VCrKUXqEJ1nlsO0kt2Pq93dA9LKZ7fZNJA90CPzKWGa6o90
rX9JxvCrepSPM0xrKH58noH3HAoMgMeDkSOHJ9+2H5WjuKdh3pITZMg5/jGTrkLEyIcrTNFY6LU5
nHRatABytgZghxJQtsUJbgOq34npzoskINwscd0HWxXXZRotaRyMh3CI/fn1s/jYnjqlIErwzGun
R37/goz1L8TZgwk2FzHSBnQlLlhmYpE0V0RZUzTS8gccUAhtGa0EfUn04U/QvQgWB3yfGXY1WEgN
xhZtLm6W9FjbaYh2UoJTJuxqEYKUb+7z39dGydm4xujzS4ceb4egWz6p9rdKhqw6NvHVb8mkPkK0
0uVU7/fwYK7nAdshLvavoQfA79NCA28/oxg6EzWrb83pH6B4bwd8rZkRXlvdgYeJKx8VD9FS+3kV
qrDVhx1Ku96xrBGoOUFXU/aHUO9XNZXDI8F1ogOPchuqeBJ2nOOm60cALkQjhb7dnwklChlodXg0
0cwDnSOrzh1b7MdIDJeONPSaW7xAo3t/9ou84jVwRYjAIwDfCbGkFTMd2ZLkdHQnaaiv1gRIyn3s
5eHfIUGzFJRtb257lgKTbQruaSAYytjYdrncJlNdWMOVM8Z4udd3sj6pCEE3w8oc1H4DcDjhAsYk
7hBd15Y7rAMEe3JE+PmnJCvt5k6X3CzHQsDrxxdP2wAPI2PK4Eims9tsddXG/2Oqwwa26JBjbKcs
RN+/yHEXOCeGMJ41M1LcEolZFNgoblQNwckamnLHJ6Z1y1lUS2vL63M93pJ02sL/bkvkX2auOuBS
MTtrT1MfN8vgg3qrdkjupb3yn9VUbPqnnZq/UZ86pIFhSO5crA2ZexV12N8WB5Hc3MCz6NeCcpMX
s/b/BfQ4nb4eT/ID5iOhJt0v+oCMD9XK7PuixQsdHtu+xJWJeywMw9yKvdt/rAAOObIl0tIGGd3t
I8cMehDqHMHrxjeXM7CMlhh1WcHjXEz4O7/wCOu5jOH9UzeMOWnVhgFYh19pyUPgIab5alcJT6yR
M4FLivaOReIM9S81KBKVIl20N0mEMkoncZyO/5m8wiIyy2LJVZc6iplps2vJmDBC93rTjdhFZseH
alc7+0udjIIyxIpuOkxz7J3M3E8Dtui9qC6mg/+oBAPWZcQARjyUcbEqFOWL/y2vSY7thG/fXk1s
fFP2IAo0nKPhfpdgSmvRiXUwsrSog2hV1OGC4cXYjBd78/4Z3rJuTpXwk5vDMupZQnzBHQKd871m
i7iTOLRUwFDO/1+plNhQgMmWnfGM17rLYp0LMn917zBdnHT8QdkIJ31L/TgrMXpUibFa/dhw80uR
2t87f/W1C8tJ9OVKB8QMVgyswbQTPxXjUwGgQ0vM0uFo+SEDsT4jllz0mFtWto1W9uppice6OFvV
EtWcOxAtICho7G==