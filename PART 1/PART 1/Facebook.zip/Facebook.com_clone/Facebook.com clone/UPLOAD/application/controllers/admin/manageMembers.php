<?php
/**
 * Manage members Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 02/01/2008
 */
class ManageMembers extends controller
{
		function ManageMembers()
		{
				parent::controller();
				//check login
				if ($this->session->userdata('admin_logged_in') != 1 && $this->session->userdata('admin_id') == '') redirect('admin/login');
				//Load the language file
				$this->lang->load('admin/manageMembers', $this->config->item('language_code'));
				$this->load->model('usermodel');
		}
		function index()
		{
				$this->members();
		}
		function members($userId = '', $action = '')
		{
				if ($userId != '')
				{
						if (!ereg('^[0-9]+$', $userId))
						{
								$userId = '';
						}
				}
				if ($action != '')
				{
						if ($action != 'active' && $action != 'deactive')
						{
								$action = '';
						}
				}
				if ($userId != '' && $action != '')
				{
						$res = $this->usermodel->updateUserStatusAdmin($userId, $action);
						if ($res > 0)
						{
								$outputData['validationError'] = 'Status Updated Successfully...';
						}
				}
				$data = isset($_POST['searchBtn_x']) ? $_POST : '';
				$this->load->model('friendsmodel');
				$this->load->model('networkmodel');
				$this->load->model('groupsmodel');
				$this->load->model('eventsmodel');
				$this->load->model('photomodel');
				$criteriaArray = array();
				if ($this->input->post('searchBtn_x') != false)
				{
						$searchName = ($this->input->post('member_name') != false) ? $this->input->post('member_name') : '';
						$searchEmail = ($this->input->post('member_email') != false) ? $this->input->post('member_email') : '';
						$startday = $this->input->post('Start_Year') . '-' . $this->input->post('Start_Month') . '-' . $this->input->post('Start_Day');
						$endday = $this->input->post('End_Year') . '-' . $this->input->post('End_Month') . '-' . $this->input->post('End_Day');
						$country = ($this->input->post('country') != false) ? $this->input->post('country') : '';
						$status = ($this->input->post('member_status') != false) ? $this->input->post('member_status') : '';
						$criteriaArray = array('username' => $searchName, 'email' => $searchEmail, 'startday' => $startday, 'endday' => $endday, 'country' => $country, 'status' => $status);
				}
				$membersList = $this->usermodel->getMembers($criteriaArray);
				foreach ($membersList as $userId => $userDetail)
				{
						$membersList[$userId]['friends'] = count($this->friendsmodel->getFriends($userDetail['user_id']));
						$membersList[$userId]['networks'] = count($this->networkmodel->getUserNetwork($userDetail['user_id']));
						$membersList[$userId]['groups'] = count($this->groupsmodel->getUserGroupsCount($userDetail['user_id'], '', 'Y'));
						$membersList[$userId]['events'] = count($this->eventsmodel->getOwnEvents($userDetail['user_id']));
						$membersList[$userId]['photos'] = count($this->photomodel->getUserPhotosCount($userDetail['user_id']));
				}
				//$members[$row['user_id']]['friendscount']	=	count($this->friendsmodel->getFriends($row['user_id']));
				$country = $this->usermodel->getCountry(true);
				$outputData['country'] = $country;
				$outputData['memberList'] = $membersList;
				$outputData['resultscount'] = count($membersList);
				//print_r($outputData['memberList']); exit();
				$this->smartyextended->view('../admin/manageMembers', $outputData);
		}
		function edit($action = 'add', $userId = '')
		{
				$this->load->library('validation');
				$this->_FormRules();
				if ($userId != '' && $action == 'edit')
				{
						if (!ereg('^[0-9]+$', $userId))
						{
								redirect('admin/');
						}
				}
				if ($action != 'add' && $action != 'edit')
				{
						redirect('admin/');
				}
				$this->load->model('usermodel');
				if ($this->validation->run() == false)
				{
						$outputData['validationError'] = $this->validation->error_string;
				}
				else
				{
						if ($this->input->post('saveinfo_x') != false)
						{
								$action = $this->input->post('action');
								$birthday = $this->input->post('Birth_Year') . '-' . $this->input->post('Birth_Month') . '-' . $this->input->post('Birth_Day');
								$valuesArray = array('username' => $this->input->post('member_name'), 'birthday' => $birthday, 'city' => $this->input->post('member_city'), 'email' => $this->input->post('member_email'), 'pwd' => $this->input->post('member_pwd'), 'country' => $this->input->post('country'));
								if ($action == 'edit')
								{
										$res = $this->usermodel->saveUserInfoAdmin($userId, $valuesArray);
										if ($res == true)
										{
												$this->session->set_flashdata('successMsg', 'Member information updated successfully...');
										}
										else
										{
												$this->session->set_flashdata('successMsg', 'Failed to update the member information....');
										}
								}
								else
								{
										if (!$this->usermodel->checkUserExists($valuesArray['email']))
										{
												$userId = $this->usermodel->addUserInfoAdmin($valuesArray);
												if ($userId > 0)
												{
														$this->_sendConfirmEmail($valuesArray['username'], $valuesArray['email']);
														$this->session->set_flashdata('successMsg', 'Member added successfully...');
												}
												else
												{
														$this->session->set_flashdata('successMsg', 'Failed to add the member....');
												}
										}
										else
										{
												$this->session->set_flashdata('successMsg', 'Email you are given is already registered...');
										}
								}
								redirect('admin/manageMembers/edit/edit/' . $userId . '/');
						}
				}
				$userDetail = array();
				if ($action == 'edit')
				{
						$userDetail = $this->usermodel->getUserDetailAdmin($userId);
						if (count($userDetail) == 0) redirect('admin/');
				}
				$country = $this->usermodel->getCountry(true);
				$outputData['action'] = $action;
				$outputData['userdetail'] = $userDetail;
				$outputData['country'] = $country;
				$outputData['member_id'] = $userId;
				$this->smartyextended->view('../admin/editmember', $outputData);
		}
		function _sendConfirmEmail($username, $email)
		{
				$this->load->model('emailTemplateModel');
				$this->load->library('email');
				$emailTemplate = $this->emailTemplateModel->readEmailTemplate('register_confirm');
				/* Send the Confirm E-Mail as the register is confirmed successfully */
				$settings = $this->settingsmodel->readSetting('admin_email, admin_name, site_name, site_title');
				$adminEmail = $settings['admin_email'];
				$adminName = $settings['admin_name'];
				$confirmKey = md5(time());
				$confirmText = base_url() . 'register/confirm/' . $confirmKey;
				//Set the user activation key
				$this->usermodel->setUserActivationKey($email, $confirmKey);
				$splVars = array("~~receiverName~~" => $username, "~~siteName~~" => $settings['site_name'], "~~siteTitle~~" => $settings['site_title'], "~~attachUrl~~" => $confirmText, "~~adminEmail~~" => $adminEmail, "~~adminName~~" => $adminName);
				$subject = strtr($emailTemplate['template_subject'], $splVars);
				$message = strtr($emailTemplate['template_content'], $splVars);
				$this->email->from($adminEmail, $adminName);
				$this->email->to($email);
				$this->email->subject($subject);
				$this->email->message($message);
				$this->email->send();
		}
		function viewmember($userId)
		{
				if (!ereg('^[0-9]+$', $userId))
				{
						redirect('admin/');
				}
				$this->load->model('usermodel');
				$userViewDetails = $this->usermodel->getUserViewInfoAdmin($userId);
				if (count($userViewDetails) == 0)
				{
						redirect('admin/');
				}
				$userViewDetails['avatar'] = $this->usermodel->getAvatar($userId);
				$userViewDetails['workinfo'] = $this->usermodel->getUserWorkInfoAdmin($userId);
				$userViewDetails['workcount'] = count($userViewDetails['workinfo']);
				$userViewDetails['collegeinfo'] = $this->usermodel->getUserCollegesAdmin($userId);
				$userViewDetails['collegecount'] = count($userViewDetails['collegeinfo']);
				$userViewDetails['lookingfor'] = $this->usermodel->getUserLookingForAdmin($userId);
				$userViewDetails['lookingcount'] = count($userViewDetails['lookingfor']);
				$data['userViewInfo'] = $userViewDetails;
				$this->smartyextended->view('../admin/viewmember', $data);
		}
		function _FormRules()
		{
				$rules['member_name'] = 'trim|required|min_length[5]';
				$rules['member_email'] = 'required|callback__isMail';
				$rules['member_pwd'] = 'trim|required|min_length[6]';
				$this->validation->set_rules($rules);
				$fields['member_name'] = 'user name';
				$fields['member_email'] = 'email';
				$fields['member_pwd'] = 'password';
				$this->validation->set_fields($fields);
		}
		function _isMail($member_email)
		{
				$pattern = "^[a-zA-Z0-9]([a-zA-Z0-9]*\_[a-zA-Z0-9]+)*([a-zA-Z0-9\-]*\.[a-zA-Z0-9\-]+)*[a-zA-Z0-9]*@[a-zA-Z0-9]{2,}\.[a-zA-Z0-9]{2,}(\.[a-zA-Z0-9]{2,})?$";
				if (trim($member_email) != '')
				{
						if (!ereg($pattern, $member_email))
						{
								$this->validation->set_message('_isMail', 'The %s Entered is Not valid ');
								return false;
						}
						else
						{
								return true;
						}
				}
				else
				{
						$this->validation->set_message('_isMail', 'The %s is required ');
						return false;
				}
		}
}
?>