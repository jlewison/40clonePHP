<?php

/**
 * Logout
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 2007-12-14
 */
class Logout extends Controller
{
		//Constructor
		function Login()
		{
				parent::Controller();
		}
		//Default function
		function index()
		{
				//Load the user model
				$this->load->model('usermodel');
				//logout the user. set in DB
				$this->usermodel->logout($this->session->userdata('email'));
				//Clear the session
				$logout = array('logged_in' => 0, 'user_id' => '', 'redirectURL' => '');
				$this->session->set_userdata($logout);
				//Go to the login page
				redirect('home');
		}
}

?>