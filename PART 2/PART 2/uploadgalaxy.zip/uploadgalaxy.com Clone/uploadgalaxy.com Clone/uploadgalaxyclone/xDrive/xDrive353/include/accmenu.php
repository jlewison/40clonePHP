<?
	echo "$table1<tr><td valign=top align=center>";
?>
		&nbsp; <a class="hmenu" href="editp.php">Edit Account Info</a>
		&nbsp;|&nbsp; <a class="hmenu" href="upload.php">New Upload</a>
		&nbsp;|&nbsp; <a class="hmenu" href="editimg.php">Manage Your Uploads</a>
		&nbsp;|&nbsp; <a class="hmenu" href="delacc.php">Delete Account </a>
		&nbsp;|&nbsp; <a class="hmenu" href="logout.php">Logout</a>
		&nbsp; 
<?
	echo "</td></tr></table><br>"; 
?>