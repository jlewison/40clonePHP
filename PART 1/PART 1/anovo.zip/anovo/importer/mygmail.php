<?php
error_reporting(0);
//******************************* | SETTING VARIABLES | ***********************************\\
include_once ('functions.php');
$username = $_POST["username"];
$password = $_POST["password"];
#Script to import the names and emails from gmail contact list
#Globals Section, $location and $cookiearr should be used in any script that uses
$location = "";
$cookiearr = array();
#function get_contacts, accepts as arguments $login (the username) and $password
#returns array of: array of the names and array of the emails if login successful
#otherwise returns 1 if login is invalid and 2 if username or password was not specified
function get_contacts($login, $password)
{
		#the globals will be updated/used in the read_header function
		global $location;
		global $cookiearr;
		global $ch;
		#check if username and password was given:
		if ((isset($login) && trim($login) == "") || (isset($password) && trim($password) == ""))
		{
				#return error code if they weren't
				return 2;
		}
		#initialize the curl session
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, "http://mail.google.com/mail/");
		curl_setopt($ch, CURLOPT_REFERER, "");
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
		curl_setopt($ch, CURLOPT_HEADERFUNCTION, 'read_header');
		#get the html from gmail.com
		$html = curl_exec($ch);
		$matches = array();
		$actionarr = array();
		$action = "https://www.google.com/accounts/ServiceLoginAuth?service=mail";
		#parse the login form:
		#parse all the hidden elements of the form
		preg_match_all('/<input type\="hidden" name\="([^"]+)".*?value\="([^"]*)"[^>]*>/si', $html, $matches);
		$values = $matches[2];
		$params = "";
		$i = 0;
		foreach ($matches[1] as $name)
		{
				$params .= "$name=" . urlencode($values[$i]) . "&";
				++$i;
		}
		$login = urlencode($login);
		$password = urlencode($password);
		#submit the login form:
		curl_setopt($ch, CURLOPT_URL, $action);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $params . "Email=$login&Passwd=$password&PersistentCookie=");
		$html = curl_exec($ch);
		#test if login was successful:
		if (!isset($cookiearr['GX']) && (!isset($cookiearr['LSID']) || $cookiearr['LSID'] == "EXPIRED"))
		{
				return 1;
		}
		#this is the new csv url:
		curl_setopt($ch, CURLOPT_URL, "http://mail.google.com/mail/contacts/data/export?exportType=ALL&groupToExport=&out=OUTLOOK_CSV");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		$html = curl_exec($ch);
		$csvrows = explode("\n", $html);
		array_shift($csvrows);
		$names = array();
		$emails = array();
		foreach ($csvrows as $row)
		{
				$values = explode(",", $row);
				if (eregi("@", $values[1]))
				{
						$names[] = (trim($values[0]) == "") ? $values[1] : $values[0];
						$emails[] = $values[1];
				}
		}
		return $emails;
}
$emails_arr = get_contacts($username, $password);
#read_header is essential as it processes all cookies and keeps track of the current location url
#leave unchanged, include it with get_contacts
function read_header($ch, $string)
{
		global $location;
		global $cookiearr;
		global $ch;
		$length = strlen($string);
		if (!strncmp($string, "Location:", 9))
		{
				$location = trim(substr($string, 9, -1));
		}
		if (!strncmp($string, "Set-Cookie:", 11))
		{
				$cookiestr = trim(substr($string, 11, -1));
				$cookie = explode(';', $cookiestr);
				$cookie = explode('=', $cookie[0]);
				$cookiename = trim(array_shift($cookie));
				$cookiearr[$cookiename] = trim(implode('=', $cookie));
		}
		$cookie = "";
		if (trim($string) == "")
		{
				foreach ($cookiearr as $key => $value)
				{
						$cookie .= "$key=$value; ";
				}
				curl_setopt($ch, CURLOPT_COOKIE, $cookie);
		}
		return $length;
}
if (sizeof($emails_arr) < 1)
{
?>
<p align="center"><font face="Verdana" size="2"><b>No Details Found:</b> Please make sure you have entered correct login details and try again.</font></p><p align="center">
<?php
}
else
{
		//***************** | LOGGING ONTO GMAIL STEP 8 [html display] | ********************\\
		//
		//
		//
		//
		//
		//***********************************************************************************\\
		// [header section - html]

?>
<html>
<head>
<title>CONTACTS</title>
<script type="text/javascript"><!--

var formblock;
var forminputs;

function prepare() {
formblock= document.getElementById('form_id');
forminputs = formblock.getElementsByTagName('input');
}

function select_all(name, value) {
for (i = 0; i < forminputs.length; i++) {
// regex here to check name attribute
var regex = new RegExp(name, "i");
if (regex.test(forminputs[i].getAttribute('name'))) {
if (value == '1') {
forminputs[i].checked = true;
} else {
forminputs[i].checked = false;
}
}
}
}

if (window.addEventListener) {
window.addEventListener("load", prepare, false);
} else if (window.attachEvent) {
window.attachEvent("onload", prepare)
} else if (document.getElementById) {
window.onload = prepare;
}

//--></script>
</head>
<body>
<div align="center">
<center>
<table border="0" width="578" bgcolor="#FFFFFF"><tr>
<TD width="622"><IMG height=2 alt="" src="images/spacer.gif" width=1 border=0></TD>
</tr><tr><TD align=middle width="622"><TABLE cellSpacing=0 cellPadding=0 width=640 border=0>
<TBODY><TR><TD width=5 height=5><IMG height=5 alt="" src="images/tls.gif" width=5 border=0></TD>
<TD background="images/t.gif" colSpan=2 width="716"><IMG height=1 alt="" src="images/spacer.gif" width=1 border=0></TD>
<TD width=6 height=5><IMG height=5 alt="" src="images/trs.gif" width=5 border=0></TD></TR><TR>
<TD width=5 background="images/l.gif" height=5><IMG height=5 alt="" src="images/spacer.gif" width=5 border=0></TD>
<TD width=6><IMG height=1 alt="" src="images/spacer.gif" width=6 border=0></TD><TD vAlign=top width=704>
<table border="0" width="100%"><tr><td width="100%" bgcolor="#D7D8DF">
<p align="center"><font face="Arial" size="3" color="#333333">My Contacts</font></td></tr></table>
<p align="center">
<form id="form_id" name="myform" method="post" action="postage.php" onsubmit="return false;">
<div align="center"><center>
<table border="0" cellpadding="3" cellspacing="6" width="100%">
	<tr>
		<th width="22" bgcolor="#F5F5F5"><input type="checkbox" class="clsCheckRadio" name="check_all" onclick="CheckAll(document.myform.name, document.myform.check_all.name)" /></th>
		<!--<th width="22" bgcolor="#F5F5F5">Name</th>-->
		<th width="22" bgcolor="#F5F5F5">Email</th>
	</tr>
<?php
		foreach ($emails_arr as $email)
		{
?>
<tr>
	<td width="22" bgcolor="#F5F5F5"><input type="checkbox" name="list[]" value="<?php echo $email; ?>"></td>
	<!--<td width="269" bgcolor="#F5F5F5"><p align="center"><font face="Verdana" size="2">'.$name.'</font></td>-->
	<td width="296" bgcolor="#F5F5F5"><p align="center"><font face="Verdana" size="2"><?php echo $email; ?></font></td>
</tr>
<?php
		}
		//  [RESULTS - START OF FOOTER]

?>
</table></center></div>
<table border="0" width="100%"><tr><td width="100%">
<p align="center"><font face="Arial" size="2"><br></font><br>
<p></p><p align="center"><input type="button" value="Add contacts" name="B1" style="background-color: #808080; color: #FFFFFF; font-family: Arial; font-size: 10pt; font-weight: bold; border: 1 solid #333333" onClick="addContacts()"></p></form></td></tr>
</table><IMG height=1 alt="" src="images/spacer.gif" width=1 border=0></TD>
<TD width=6 background="images/r.gif" height=5><IMG height=1 alt="" src="images/spacer.gif" width=1 border=0></TD></TR>
<TR><TD width=5 height=5><IMG height=5 alt="" src="images/bls.gif" width=5 border=0></TD>
<TD background="images/b.gif" colSpan=2 width="716"><IMG height=1 alt="" src="images/spacer.gif" width=1 border=0></TD>
<TD width=6 height=5><IMG height=5 alt="" src="images/brs.gif" width=5 border=0></TD></TR></TBODY></TABLE></TD>                      </tr></table></center></div>
<?php
		//*********************** | END OF SCRIPT | ***********************************\\
}
?>

















