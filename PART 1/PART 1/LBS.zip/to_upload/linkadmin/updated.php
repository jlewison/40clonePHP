<?php include('restrict.php'); include('../settings.php'); require_once('../Connections/apound.php'); ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Info</title>
<link rel="shortcut icon" href="img/favicon.ico" />
<link rel="stylesheet" type="text/css" href="admin.css" />
<style type="text/css">
<!--
.style75 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	color: #009933;
}
-->
</style>
</head>

<body>
<?php include('header_tpl.php'); ?>
<table width="770"  border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
  <tr>
    <td width="770">&nbsp;</td>
  </tr>
</table>
<table width="770"  border="0" align="center" cellpadding="3" cellspacing="1" bgcolor="#FFFFFF">
  <tr>
    <td width="772" valign="top"><table width="100%"  border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="248" align="center"><span class="style75">Your changes were saved</span></td>
      </tr>
    </table></td>
  </tr>
</table>
<?php include('footer_tpl.php'); ?>
</body>
</html>
