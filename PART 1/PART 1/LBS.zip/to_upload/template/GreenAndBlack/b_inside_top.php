<link href="<?php echo("$path");?>stat.css" rel="stylesheet" type="text/css" /> 

<div id="header">
	<h1><a href="<?php echo("$path");?>" title="Welcome to <?php echo("$sitetitle");?>!"><?php echo("$sitetitle");?></a></h1>
	<ul class="primary">
		<li><a href="<?php echo("$path");?>"><?php echo("$lang_11");?></a></li>
		<li><a href="<?php echo("$path");?>new-links.php"><?php echo("$lang_12");?></a></li>
		<?php if($p_top == 'Y') { ?><li><a href="<?php echo("$path");?>links.php"><?php echo("$lang_13");?></a></li><?php } else {} ?>
		<li><a href="<?php echo("$path");?>submit.php?su_categ=<?php echo("$su_categ");?>"><?php echo("$lang_14");?></a></li>
        <li><a href="<?php echo("$path");?>tags/"><?php echo("$lang_181");?></a></li>
	</ul>
	<ul class="secondary">
		<?php if($p_terms == 'Y') { ?><li><a href="<?php echo("$path");?>terms.php"><?php echo("$lang_16");?></a> | </li><?php } else {} ?>
		<?php if($p_about == 'Y') { ?><li><a href="<?php echo("$path");?>about.php"><?php echo("$lang_80");?></a> | </li><?php } else {} ?>
		<li><a href="<?php echo("$path");?>contact.php"><?php echo("$lang_15");?></a></li>
	</ul>
</div>

<div id="panel">
	<?php if($alphacat != 'N') { ?>
	<ul>
		<li><a href="<?php echo("$path");?>0-9.html">#</a></li>
		<li><a href="<?php echo("$path");?>A.html">A</a></li>
		<li><a href="<?php echo("$path");?>B.html">B</a></li>
		<li><a href="<?php echo("$path");?>C.html">C</a></li>
		<li><a href="<?php echo("$path");?>D.html">D</a></li>
		<li><a href="<?php echo("$path");?>E.html">E</a></li>
		<li><a href="<?php echo("$path");?>F.html">F</a></li>
		<li><a href="<?php echo("$path");?>G.html">G</a></li>
		<li><a href="<?php echo("$path");?>H.html">H</a></li>
		<li><a href="<?php echo("$path");?>I.html">I</a></li>
		<li><a href="<?php echo("$path");?>J.html">J</a></li>
		<li><a href="<?php echo("$path");?>K.html">K</a></li>
		<li><a href="<?php echo("$path");?>L.html">L</a></li>
		<li><a href="<?php echo("$path");?>M.html">M</a></li>
		<li><a href="<?php echo("$path");?>N.html">N</a></li>
		<li><a href="<?php echo("$path");?>O.html">O</a></li>
		<li><a href="<?php echo("$path");?>P.html">P</a></li>
		<li><a href="<?php echo("$path");?>Q.html">Q</a></li>
		<li><a href="<?php echo("$path");?>R.html">R</a></li>
		<li><a href="<?php echo("$path");?>S.html">S</a></li>
		<li><a href="<?php echo("$path");?>T.html">T</a></li>
		<li><a href="<?php echo("$path");?>U.html">U</a></li>
		<li><a href="<?php echo("$path");?>V.html">V</a></li>
		<li><a href="<?php echo("$path");?>W.html">W</a></li>
		<li><a href="<?php echo("$path");?>X.html">X</a></li>
		<li><a href="<?php echo("$path");?>Y.html">Y</a></li>
		<li><a href="<?php echo("$path");?>Z.html">Z</a></li>
	</ul>
	<?php } ?>
	<form name="form1sea" method="post" action="<?php echo("$path");?>search.php">
		<input type="text" class="text" name="q" onfocus="this.value='';" value="<?php echo("$lang_19");?>" />
		<input type="submit" class="btn" name="button" value="<?php echo("$lang_20");?>" />
	</form>
</div>

<div id="container">
	<div id="contentcontainer"><div id="content">