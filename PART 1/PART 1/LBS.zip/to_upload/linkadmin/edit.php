<?php include('restrict.php');
require_once('../Connections/apound.php');
mysql_select_db($database_apound, $apound);
$query_CSE = "SELECT * FROM categorylisting";
$CSE = mysql_query($query_CSE, $apound) or die(mysql_error());
$row_CSE = mysql_fetch_assoc($CSE);
$totalRows_CSE = mysql_num_rows($CSE);
mysql_select_db($database_apound, $apound);
$query_CON = "SELECT * FROM country";
$CON = mysql_query($query_CON, $apound) or die(mysql_error());
$row_CON = mysql_fetch_assoc($CON);
$totalRows_CON = mysql_num_rows($CON);
$x = $_GET[x];
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = (!get_magic_quotes_gpc()) ? addslashes($theValue) : $theValue;

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;   
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form1")) {
  $updateSQL = sprintf("UPDATE main SET categ=%s, maincategory=%s, email=%s, site=%s, title=%s, descr1=%s, descr2=%s, mdesc=%s, mword=%s, deeptf=%s, dfurl=%s, deepts=%s, dsurl=%s, deeptt=%s, dturl=%s, bid=%s, stad=%s, stup=%s, stod=%s, avail=%s, paid=%s, gm_str=%s, gm_str_nr=%s, gm_city=%s, gm_county=%s, gm_country=%s, tag1=%s, tag2=%s, tag3=%s, tag4=%s, tag5=%s, tag6=%s WHERE dtu=%s",
                       GetSQLValueString($_POST['categ'], "text"),
					   GetSQLValueString($_POST['maincategory'], "text"),
					   GetSQLValueString($_POST['email'], "text"),
                       GetSQLValueString($_POST['site'], "text"),
                       GetSQLValueString($_POST['title'], "text"),
                       GetSQLValueString($_POST['descr1'], "text"),
                       GetSQLValueString($_POST['descr2'], "text"),
                       GetSQLValueString($_POST['mdesc'], "text"),
                       GetSQLValueString($_POST['mword'], "text"),					   
                       GetSQLValueString($_POST['deeptf'], "text"),					   
                       GetSQLValueString($_POST['dfurl'], "text"),					   
                       GetSQLValueString($_POST['deepts'], "text"),	
                       GetSQLValueString($_POST['dsurl'], "text"),
                       GetSQLValueString($_POST['deeptt'], "text"),
                       GetSQLValueString($_POST['dturl'], "text"),
                       GetSQLValueString($_POST['bid'], "int"),
                       GetSQLValueString($_POST['stad'], "date"),
                       GetSQLValueString($_POST['stup'], "date"),
                       GetSQLValueString($_POST['stod'], "date"),
                       GetSQLValueString($_POST['avail'], "text"),
                       GetSQLValueString($_POST['paid'], "text"),
					   GetSQLValueString($_POST['gm_str'], "text"),
					   GetSQLValueString($_POST['gm_str_nr'], "text"),
					   GetSQLValueString($_POST['gm_city'], "text"),
					   GetSQLValueString($_POST['gm_county'], "text"),
					   GetSQLValueString($_POST['gm_country'], "text"),
					   GetSQLValueString($_POST['tag1'], "text"),
					   GetSQLValueString($_POST['tag2'], "text"),
					   GetSQLValueString($_POST['tag3'], "text"),
					   GetSQLValueString($_POST['tag4'], "text"),
					   GetSQLValueString($_POST['tag5'], "text"),
					   GetSQLValueString($_POST['tag6'], "text"),
                       GetSQLValueString($_POST['dtu'], "int"));

  mysql_select_db($database_apound, $apound);
  $Result1 = mysql_query($updateSQL, $apound) or die(mysql_error());
  $updated = "Y";
  // TAG Section
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}
// TAG1

$tag1 = mysql_real_escape_string($_POST[tag1]);
$tag2 = mysql_real_escape_string($_POST[tag2]);
$tag3 = mysql_real_escape_string($_POST[tag3]);
$tag4 = mysql_real_escape_string($_POST[tag4]);
$tag5 = mysql_real_escape_string($_POST[tag5]);
$tag6 = mysql_real_escape_string($_POST[tag6]);

mysql_select_db($database_apound, $apound);
$query_tagA = "SELECT * FROM tags WHERE tag = '$tag1'";
$tagA = mysql_query($query_tagA, $apound) or die(mysql_error());
$row_tagA = mysql_fetch_assoc($tagA);
$totalRows_tagA = mysql_num_rows($tagA);

if($totalRows_tagA == '' and $tag1 <> '') {

$count = "1";
mysql_select_db($database_apound, $apound);
$result = mysql_query ("INSERT INTO tags (tag, count) VALUES('$tag1', '$count')");

}

else {

$id = $row_tagA['id'];
$tag = $row_tagA['tag'];
$count_old = $row_tagA['count'];
$count_new = "1";
$count = $count_old + $count_new;

mysql_select_db($database_apound);
mysql_query("UPDATE tags SET count='$count' WHERE id='$id'");
}

mysql_free_result($tagA);

// TAG2
mysql_select_db($database_apound, $apound);
$query_tagB = "SELECT * FROM tags WHERE tag = '$tag2'";
$tagB = mysql_query($query_tagB, $apound) or die(mysql_error());
$row_tagB = mysql_fetch_assoc($tagB);
$totalRows_tagB = mysql_num_rows($tagB);

if($totalRows_tagB == '' and $tag2 <> '') {

$count = "1";
mysql_select_db($database_apound, $apound);
$result = mysql_query ("INSERT INTO tags (tag, count) VALUES('$tag2', '$count')");

}

else {

$id = $row_tagB['id'];
$tag = $row_tagB['tag'];
$count_old = $row_tagB['count'];
$count_new = "1";
$count = $count_old + $count_new;

mysql_select_db($database_apound);
mysql_query("UPDATE tags SET count='$count' WHERE id='$id'");
}

mysql_free_result($tagB);

// TAG3
mysql_select_db($database_apound, $apound);
$query_tagC = "SELECT * FROM tags WHERE tag = '$tag3'";
$tagC = mysql_query($query_tagC, $apound) or die(mysql_error());
$row_tagC = mysql_fetch_assoc($tagC);
$totalRows_tagC = mysql_num_rows($tagC);

if($totalRows_tagC == '' and $tag3 <> '') {

$count = "1";
mysql_select_db($database_apound, $apound);
$result = mysql_query ("INSERT INTO tags (tag, count) VALUES('$tag3', '$count')");

}

else {

$id = $row_tagC['id'];
$tag = $row_tagC['tag'];
$count_old = $row_tagC['count'];
$count_new = "1";
$count = $count_old + $count_new;

mysql_select_db($database_apound);
mysql_query("UPDATE tags SET count='$count' WHERE id='$id'");
}

mysql_free_result($tagC);

// TAG4
mysql_select_db($database_apound, $apound);
$query_tagD = "SELECT * FROM tags WHERE tag = '$tag4'";
$tagD = mysql_query($query_tagD, $apound) or die(mysql_error());
$row_tagD = mysql_fetch_assoc($tagD);
$totalRows_tagD = mysql_num_rows($tagD);

if($totalRows_tagD == '' and $tag4 <> '') {

$count = "1";
mysql_select_db($database_apound, $apound);
$result = mysql_query ("INSERT INTO tags (tag, count) VALUES('$tag4', '$count')");

}

else {

$id = $row_tagD['id'];
$tag = $row_tagD['tag'];
$count_old = $row_tagD['count'];
$count_new = "1";
$count = $count_old + $count_new;

mysql_select_db($database_apound);
mysql_query("UPDATE tags SET count='$count' WHERE id='$id'");
}

mysql_free_result($tagD);

// TAG5
mysql_select_db($database_apound, $apound);
$query_tagE = "SELECT * FROM tags WHERE tag = '$tag5'";
$tagE = mysql_query($query_tagE, $apound) or die(mysql_error());
$row_tagE = mysql_fetch_assoc($tagE);
$totalRows_tagE = mysql_num_rows($tagE);

if($totalRows_tagE == '' and $tag5 <> '') {

$count = "1";
mysql_select_db($database_apound, $apound);
$result = mysql_query ("INSERT INTO tags (tag, count) VALUES('$tag5', '$count')");

}

else {

$id = $row_tagE['id'];
$tag = $row_tagE['tag'];
$count_old = $row_tagE['count'];
$count_new = "1";
$count = $count_old + $count_new;

mysql_select_db($database_apound);
mysql_query("UPDATE tags SET count='$count' WHERE id='$id'");
}

mysql_free_result($tagE);

// TAG6
mysql_select_db($database_apound, $apound);
$query_tagF = "SELECT * FROM tags WHERE tag = '$tag6'";
$tagF = mysql_query($query_tagF, $apound) or die(mysql_error());
$row_tagF = mysql_fetch_assoc($tagF);
$totalRows_tagF = mysql_num_rows($tagF);

if($totalRows_tagF == '' and $tag6 <> '') {

$count = "1";
mysql_select_db($database_apound, $apound);
$result = mysql_query ("INSERT INTO tags (tag, count) VALUES('$tag6', '$count')");

}

else {

$id = $row_tagF['id'];
$tag = $row_tagF['tag'];
$count_old = $row_tagF['count'];
$count_new = "1";
$count = $count_old + $count_new;

mysql_select_db($database_apound);
mysql_query("UPDATE tags SET count='$count' WHERE id='$id'");
}

mysql_free_result($tagF);

/*   $updateGoTo = "http://$x?upd=Y";
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $updateGoTo)); */
}

$colname_Recordset1 = "1";
if (isset($_GET['id'])) {
  $colname_Recordset1 = (get_magic_quotes_gpc()) ? $_GET['id'] : addslashes($_GET['id']);
}
mysql_select_db($database_apound, $apound);
$query_Recordset1 = sprintf("SELECT * FROM main WHERE dtu = %s", $colname_Recordset1);
$Recordset1 = mysql_query($query_Recordset1, $apound) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Edit Listing Details - Link Bid Script Admin Panel</title>
<link rel="shortcut icon" href="img/favicon.ico" />
<link rel="stylesheet" type="text/css" href="admin.css" />
<style type="text/css">
<!--
.style84 {color: #006600}
.style85 {
	color: #006600;
	font-size: 12px;
	font-weight: bold;
}
-->
</style>
</head>

<body>
<?php include('header_tpl.php'); ?>
<h2>Edit Listing Details</h2>
<table width="770"  border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
  <tr>
    <td width="770" height="23" align="center">
<?php if($updated == 'Y') { ?><span class="shame style84">Listing updated ...</span> <A HREF="javascript:javascript:history.go(-2)" class="style85">Click here to go back to previous page</A><?php } else {} ?></td>
  </tr>
</table>
<table width="770"  border="0" align="center" cellpadding="3" cellspacing="1" bgcolor="#FFFFFF">
  <tr>
    <td width="760" valign="top"><form method="post" name="form1" action="<?php echo $editFormAction; ?>">
      <table border="0" align="center" cellpadding="6" cellspacing="1">
        <tr valign="baseline">
          <td align="right" nowrap class="style67 style82">Letter:</td>
          <td bgcolor="#FFFFFF"><input name="categ" type="text" class="edtab1" value="<?php echo $row_Recordset1['categ']; ?>" size="32"></td>
        </tr>
        <tr valign="baseline">
          <td align="right" nowrap class="style67 style82">Category:</td>
          <td bgcolor="#FFFFFF"><select name="maincategory" id="maincategory">
            <?php do { ?>
            <option value="<?php echo $row_CSE['catlistid']?>"<?php if (!(strcmp($row_CSE['catlistid'], $row_Recordset1['maincategory']))) {echo "selected=\"selected\"";} ?>><?php echo $row_CSE['categoryname']?></option>
            <?php
} while ($row_CSE = mysql_fetch_assoc($CSE));
  $rows = mysql_num_rows($CSE);
  if($rows > 0) {
      mysql_data_seek($CSE, 0);
	  $row_CSE = mysql_fetch_assoc($CSE);
}
?>
          </select>          </td>
        </tr>
        <tr valign="baseline">
          <td align="right" nowrap class="style67 style82">Email:</td>
          <td bgcolor="#FFFFFF"><input name="email" type="text" class="edtab1" value="<?php echo $row_Recordset1['email']; ?>" size="32"></td>
        </tr>
        <tr valign="baseline">
          <td align="right" nowrap class="style67 style82">Site:</td>
          <td bgcolor="#FFFFFF"><input name="site" type="text" class="edtab1" value="<?php echo $row_Recordset1['site']; ?>" size="32"></td>
        </tr>
        <tr valign="baseline">
          <td align="right" nowrap class="style67 style82">Title:</td>
          <td bgcolor="#FFFFFF"><input name="title" type="text" class="edtab1" value="<?php echo $row_Recordset1['title']; ?>" size="32"></td>
        </tr>
        <tr valign="baseline">
          <td align="right" valign="top" nowrap class="style67 style82">Brief Description :</td>
          <td bgcolor="#FFFFFF"><textarea name="descr1" class="edtab2"><?php echo $row_Recordset1['descr1']; ?></textarea></td>
        </tr>
        <tr valign="baseline">
          <td align="right" valign="top" nowrap class="style67 style82">Extended Description :</td>
          <td bgcolor="#FFFFFF"><textarea  name="descr2" class="edtab22"><?php echo $row_Recordset1['descr2']; ?></textarea></td>
        </tr>
        <tr valign="baseline">
          <td align="right" valign="top" nowrap class="style67 style82">Meta Description :</td>
          <td bgcolor="#FFFFFF"><textarea name="mdesc" class="edtab2"><?php echo $row_Recordset1['mdesc']; ?></textarea></td>
        </tr>
        <tr valign="baseline">
          <td align="right" nowrap class="style67 style82">Meta Keywords :</td>
          <td bgcolor="#FFFFFF"><input name="mword" type="text" class="edtab1" value="<?php echo $row_Recordset1['mword']; ?>" size="32"></td>
        </tr>
        <tr valign="baseline">
          <td align="right" nowrap class="style67 style82">Deep Title 1:</td>
          <td bgcolor="#FFFFFF"><input name="deeptf" type="text" class="edtab1" value="<?php echo $row_Recordset1['deeptf']; ?>" size="32"></td>
        </tr>
        <tr valign="baseline">
          <td align="right" nowrap class="style67 style82">Deep URL 1:</td>
          <td bgcolor="#FFFFFF"><input name="dfurl" type="text" class="edtab1" value="<?php echo $row_Recordset1['dfurl']; ?>" size="32"></td>
        </tr>
        <tr valign="baseline">
          <td align="right" nowrap class="style67 style82">Deep Title 2:</td>
          <td bgcolor="#FFFFFF"><input name="deepts" type="text" class="edtab1" value="<?php echo $row_Recordset1['deepts']; ?>" size="32"></td>
        </tr>
        <tr valign="baseline">
          <td align="right" nowrap class="style67 style82">Deep URL 2:</td>
          <td bgcolor="#FFFFFF"><input name="dsurl" type="text" class="edtab1" value="<?php echo $row_Recordset1['dsurl']; ?>" size="32"></td>
        </tr>
        <tr valign="baseline">
          <td align="right" nowrap class="style67 style82">Deep Title 3:</td>
          <td bgcolor="#FFFFFF"><input name="deeptt" type="text" class="edtab1" value="<?php echo $row_Recordset1['deeptt']; ?>" size="32"></td>
        </tr>
        <tr valign="baseline">
          <td align="right" nowrap class="style67 style82">Deep URL 3:</td>
          <td bgcolor="#FFFFFF"><input name="dturl" type="text" class="edtab1" value="<?php echo $row_Recordset1['dturl']; ?>" size="32"></td>
        </tr>
        <tr valign="baseline">
          <td align="right" nowrap class="style67 style82">Bid:</td>
          <td bgcolor="#FFFFFF"><input name="bid" type="text" class="edtab1" value="<?php echo $row_Recordset1['bid']; ?>" size="32"></td>
        </tr>
        <tr valign="baseline">
          <td align="right" nowrap class="style67 style82">Start Date :</td>
          <td bgcolor="#FFFFFF"><input name="stad" type="text" class="edtab1" value="<?php echo $row_Recordset1['stad']; ?>" size="32"></td>
        </tr>
        <tr valign="baseline">
          <td align="right" nowrap class="style67 style82">Last Upgrade :</td>
          <td bgcolor="#FFFFFF"><input name="stup" type="text" class="edtab1" value="<?php echo $row_Recordset1['stup']; ?>" size="32"></td>
        </tr>
        <tr valign="baseline">
          <td align="right" nowrap class="style67 style82">End Date :</td>
          <td bgcolor="#FFFFFF"><input name="stod" type="text" class="edtab1" value="<?php echo $row_Recordset1['stod']; ?>" size="32"></td>
        </tr>
        <tr valign="baseline">
          <td align="right" valign="middle" nowrap class="style67 style82">Available:</td>
          <td valign="baseline" bgcolor="#FFFFFF"><table>
            <tr>
              <td class="edtab"><input type="radio" name="avail" value="Y"  <?php if (!(strcmp($row_Recordset1['avail'],"Y"))) {echo "CHECKED";} ?>>
                Yes</td>
              <td>            </tr>
            <tr>
              <td class="edtab"><input type="radio" name="avail" value="N"  <?php if (!(strcmp($row_Recordset1['avail'],"N"))) {echo "CHECKED";} ?>>
                No</td>
              <td>            </tr>
          </table>          </tr>
        <tr valign="baseline">
          <td align="right" valign="middle" nowrap class="style67 style82">Paid:</td>
          <td valign="baseline" bgcolor="#FFFFFF"><table>
            <tr>
              <td class="edtab"><input type="radio" name="paid" value="Y"  <?php if (!(strcmp($row_Recordset1['paid'],"Y"))) {echo "CHECKED";} ?>>
                Yes</td>
              <td>            </tr>
            <tr>
              <td class="edtab"><input type="radio" name="paid" value="N"  <?php if (!(strcmp($row_Recordset1['paid'],"N"))) {echo "CHECKED";} ?>>
                No</td>
              <td>            </tr>
          </table>          </tr>
        <tr valign="baseline">
          <td align="right" valign="middle" nowrap class="style67 style82">Street:</td>
          <td><label>
            <input name="gm_str" type="text" id="gm_str" value="<?php echo $row_Recordset1['gm_str']; ?>" size="51" />
          </label></td>
        </tr>
        <tr valign="baseline">
          <td align="right" valign="middle" nowrap class="style67 style82">Strret Nr:</td>
          <td><input name="gm_str_nr" type="text" id="gm_str_nr" value="<?php echo $row_Recordset1['gm_str_nr']; ?>" size="10" /></td>
        </tr>
        <tr valign="baseline">
          <td align="right" valign="middle" nowrap class="style67 style82">City:</td>
          <td><input name="gm_city" type="text" id="gm_city" value="<?php echo $row_Recordset1['gm_city']; ?>" size="51" /></td>
        </tr>
        <tr valign="baseline">
          <td align="right" valign="middle" nowrap class="style67 style82">County:</td>
          <td><input name="gm_county" type="text" id="gm_county" value="<?php echo $row_Recordset1['gm_county']; ?>" size="51" /></td>
        </tr>
        <tr valign="baseline">
          <td align="right" valign="middle" nowrap class="style67 style82">Country:</td>
          <td>
<select name="gm_country" id="gm_country">
    <?php
do {  
?>
<option value="<?php echo $row_CON['iso']?>"<?php if (!(strcmp($row_CON['iso'], $row_Recordset1['gm_country']))) {echo "selected=\"selected\"";} ?>><?php echo $row_CON['printable_name']?></option>
    <?php
} while ($row_CON = mysql_fetch_assoc($CON));
  $rows = mysql_num_rows($CON);
  if($rows > 0) {
      mysql_data_seek($CON, 0);
	  $row_CON = mysql_fetch_assoc($CON);
  }
?>
</select>          </td>
        </tr>
        <tr valign="baseline">
          <td align="right" valign="middle" nowrap class="style67 style82">Tags:</td>
          <td>
            <input name="tag1" type="text" id="tag1" value="<?php echo $row_Recordset1['tag1']; ?>" size="15">
            <input name="tag2" type="text" id="tag2" value="<?php echo $row_Recordset1['tag2']; ?>" size="15">
            <input name="tag3" type="text" id="tag3" value="<?php echo $row_Recordset1['tag3']; ?>" size="15">
          </td>
        </tr>
        <tr valign="baseline">
          <td align="right" valign="middle" nowrap class="style67 style82">&nbsp;</td>
          <td><input name="tag4" type="text" id="tag4" value="<?php echo $row_Recordset1['tag4']; ?>" size="15">
            <input name="tag5" type="text" id="tag5" value="<?php echo $row_Recordset1['tag5']; ?>" size="15">
            <input name="tag6" type="text" id="tag6" value="<?php echo $row_Recordset1['tag6']; ?>" size="15"></td>
        </tr>
        <tr valign="baseline" bgcolor="#FFFFFF">
          <td align="right" nowrap>&nbsp;</td>
          <td align="right" nowrap bgcolor="#FFFFFF"><input type="submit" class="login-but" value="Update record"></td>
        </tr>
      </table>
      <div align="center"><?php if($updated == '') { ?><a href="javascript:javascript:history.go(-1)">Click here to go back to previous page</a><?php } else {} ?>
          <input type="hidden" name="MM_update" value="form1">
          <input type="hidden" name="dtu" value="<?php echo $row_Recordset1['dtu']; ?>">
        </div>
    </form></td>
  </tr>
</table>
<?php include('footer_tpl.php'); ?>
</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
