<?
include("include/config.php");
if(isset($_COOKIE['uname'])){
STemplate::assign('premium','yes');
STemplate::assign("ALW_SIZE",$config['PRE_MAX_SIZE']);
STemplate::display("index.tpl");}
else
{
 header("location: index.php");
}
?>
