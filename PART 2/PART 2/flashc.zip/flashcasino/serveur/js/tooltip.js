// Detect if the browser is IE or not.
// If it is not IE, we assume that the browser is NS.
var IE = navigator.appName.indexOf('Explorer')!=-1?true:false;
var NS = document.layers?true:false;

// If NS -- that is, !IE -- then set up for mouse capture
if (!IE)
	document.captureEvents(Event.MOUSEMOVE)

// Set-up to use getMouseXY function onMouseMove
document.onmousemove = overhere;



// Temporary variables to hold mouse x-y pos.s
var tempX = 0;
var tempY = 0;
var initialize=0;

function MoveToolTip(FromTop, FromLeft){
	document.getElementById('ToolTip').style.top=FromTop+'px';
	document.getElementById('ToolTip').style.left=FromLeft+'px';
}

function ReplaceContent(layerName){
	if(NS){
		with(document.layers[layerName].document){
			open();
			write(ContentInfo);
			close();
		}
		return;
	}
	document.getElementById(layerName).innerHTML=ContentInfo;
}



function Activate(){initialize=1;}
function deActivate(){initialize=0;}


function overhere(e){
	if (IE) { // grab the x-y pos.s if browser is IE
		tempX = event.clientX + document.body.scrollLeft;
		tempY = event.clientY + document.body.scrollTop;
	}
	else {  // grab the x-y pos.s if browser is NS
		tempX = e.pageX;
		tempY = e.pageY;
	}
	// catch possible negative values in NS4
	if (tempX < 0){tempX = 0;}
	if (tempY < 0){tempY = 0;}

	if(initialize){
		// must be +2, because on mouse move, onMouseOut event might trigger
		MoveToolTip(tempY+2, tempX+2);
		document.getElementById('ToolTip').style.visibility='visible';
	}
	else{
		MoveToolTip(0, 0);
		document.getElementById('ToolTip').style.visibility='hidden';
	}
	return true;
}


function EnterContent(layerName, TTitle, TContent){
	if(TContent==''){
		ContentInfo='';
	}
	else{
		ContentInfo = '<table border="0" cellpadding="0" cellspacing="0"><tr><td>&nbsp;&nbsp;&nbsp;</td></tr>';
		ContentInfo+= '<tr><td bgcolor="white" class="tooltip">';
		if (TTitle!='notitle' && TTitle!='')
			ContentInfo+='<h1>'+TTitle+'</h1>';
		ContentInfo+=TContent+'</td></tr></table>';
	}
	ReplaceContent(layerName);

}

function check_mouse_tooltip () {
	overhere(window.event);
	setTimeout("check_mouse_tooltip()", 300);
}
//check_mouse_tooltip();