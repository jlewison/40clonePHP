<?php
$lang['page_title']	= 'Login';
$lang['login_kootali']		= 'Kootali';
$lang['login_member_login']	= 'Member Login';
$lang['login_remember_me']	= 'Remember Me';
$lang['login_already_user']	= 'Already a Member';
$lang['login_kootali_is_a']	= 'Kootali is a';
$lang['login_that']			= 'that';
$lang['login_connects']		= 'connects';
$lang['login_you']			= 'you';
$lang['login_with_people']	= 'with the people around you';
$lang['login_upload_photos']= 'upload photos';
$lang['login_or']			= 'or';
$lang['login_publish_notes']= 'publish notes';
$lang['login_get_the']		= 'get the';
$lang['login_latest_news']	= 'latest news';
$lang['login_frm_friends']	= 'from your friends';
$lang['login_post_videos']	= 'post videos on your profile';
$lang['login_tag_friends']	= 'tag your friends';
$lang['login_use']			= 'use';
$lang['login_to_control']	= 'to control who sees your info';
$lang['login_join_network'] = 'join a network';
$lang['login_to_see']		= 'to see people who live, study, or work around you';
$lang['login_find_friends'] = 'Find your friends';
$lang['login_search_name']	= 'Search by name';
$lang['login_more_search']	= 'More Search options';

$lang['login_social_utility']	= 'Social utility';
$lang['login_everone_kootali']	= 'Every one can use Kootali';
$lang['login_privacy_settings']	= 'privacy settings';

$lang['login_email']		= 'E-Mail';
$lang['login_username']		= 'Username';
$lang['login_password']		= 'Password';
$lang['login_login']		= 'Login';
$lang['login_signup']		= 'signup';
$lang['login_forgot_pass']	= 'Forgot Password';

//Error Messages
$lang['login_error_inactive']	= 'Login error. You have not yet activated your account.';
$lang['login_error_password']	= 'Login error. Invalid Password.';
$lang['login_error_username']	= 'Login error. Invalid username.';

?>