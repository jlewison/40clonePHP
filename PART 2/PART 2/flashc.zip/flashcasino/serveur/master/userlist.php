<? include "header.php"; ?>

<center><h4><font color=#7C87C2>List playeurs</font></h4></center>
<table border style="BORDER-COLLAPSE: collapse" cellspacing=0 cellpadding=3><tr><td class=text1><b>ID</b></td><td class=text1><b>Login</b></td><td class=text1><b>password</b></td><td class=text1><b>credit</b></td><td class=text1><b>NB a</b></td><td class=text1><b>special</b></td><td class=text1><b>sp</b></td><td class=text1><b>E-mail</b></td><td class=text1><b>Date register</b></td><td class=text1><b>first name</b></td><td class=text1><b>Last name</b></td><td class=text1><b>Adress</b></td><td class=text1><b>zip postal</b></td><td class=text1><b>Town</b></td><td class=text1><b>country</b></td><td class=text1><b>Action</b></td></tr>
<?
$result=mysql_query("select * from users ORDER BY `id`");
while($row=mysql_fetch_array($result))
{
echo "
<tr><td class=text1>$row[0]</td><td class=text1><a href=stat.php?user=$row[1]>$row[1]</a></td><td class=text1>$row[2]</td><td class=text1><a href=userpay.php?logi=$row[1]>$row[3]</a></td><td class=text1>$row[4]</td><td class=text1>$row[5]</td><td class=text1>$row[7] $row[8]</td><td class=text1><a href=mailto:$row[6]>$row[6]</a></td><td class=text1>$row[9]</td><td class=text1>$row[11]</td><td class=text1>$row[12]</td><td class=text1>$row[13]</td><td class=text1>$row[14]</td><td class=text1>$row[15]</td><td class=text1>$row[16]</td><td class=text1><a href=del.php?user=$row[1]>Supprimer</a><br><a href=stat.php?user=$row[1]>Editer</a></td></tr>
";
}
?>
</table>

<? include "footer.php"; ?>

