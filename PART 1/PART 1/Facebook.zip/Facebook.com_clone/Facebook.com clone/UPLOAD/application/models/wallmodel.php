<?php
/**
 * Wall Model
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 12/24/2007
 * 
 * Tables: wall
 * 
 */
class Wallmodel extends Model
{
		//Constructor
		function Wallmodel()
		{
				parent::Model();
		}
		function isExist($wallFor, $wallForId)
		{
				$this->db->select('wall_id');
				$this->db->from('wall');
				$this->db->where('wall_for', $wallFor);
				$this->db->where('wall_for_id', $wallForId);
				$this->db->limit(1);
				$wallQuery = $this->db->get();
				if ($wallQuery->num_rows() > 0) return true;
				else  return false;
		}
		function getWall($wallFor, $wallForId, $orderBy = 'wall_date desc', $start = '', $limit = '')
		{
				$this->db->select('wall_id, wall_for, wall_for_id, wall.user_id, username, avatar_ext, wall_content, wall_date');
				$this->db->from('wall');
				$this->db->join('users', 'wall.user_id = users.user_id');
				$this->db->where('wall_for', $wallFor);
				$this->db->where('wall_for_id', $wallForId);
				if (trim($orderBy) != '') $this->db->order_by($orderBy);
				if (trim($limit) != '' && is_numeric($limit))
				{
						if (trim($start) != '' && is_numeric($start)) $this->db->limit($limit, $start);
						else  $this->db->limit($limit);
				}
				$wallQuery = $this->db->get();
				$wall = array();
				if ($wallQuery->num_rows() > 0)
				{
						foreach ($wallQuery->result_array() as $wallRow)
						{
								$wallRow['avatar'] = getAvatar($wallRow['user_id'], $wallRow['avatar_ext']);
								$wall[$wallRow['wall_id']] = $wallRow;
						}
				}
				return $wall;
		}
		function getWallById($wallId)
		{
				$this->db->select('wall_id, wall_for, wall_for_id, wall.user_id, username, avatar_ext, wall_content, wall_date');
				$this->db->from('wall');
				$this->db->join('users', 'wall.user_id = users.user_id');
				$this->db->where('wall_id', $wallId);
				$wallQuery = $this->db->get();
				$wall = array();
				if ($wallQuery->num_rows() > 0)
				{
						$wallRow = $wallQuery->result_array();
						$wallRow[0]['avatar'] = getAvatar($wallRow[0]['user_id'], $wallRow[0]['avatar_ext']);
						return $wallRow[0];
				}
				else  return $wall;
		}
		function getWallCount($wallFor, $wallForId)
		{
				$this->db->from('wall');
				$this->db->where('wall_for', $wallFor);
				$this->db->where('wall_for_id', $wallForId);
				return $this->db->count_all_results();
		}
		function createWall($newWall)
		{
				if ((isset($newWall['user_id']) && trim($newWall['user_id']) == '') || !isset($newWall['user_id'])) $newWall['user_id'] = $this->session->userdata('user_id');
				$this->db->set($newWall);
				$this->db->set('wall_date', 'NOW()', false);
				$this->db->insert('wall');
				return $this->db->insert_id();
		}
		function deleteWall($wallId)
		{
				$this->db->delete('wall', array('wall_id' => $wallId));
		}
}

?>