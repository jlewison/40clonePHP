<?php

	$lang['page_title']	= 'Welcome to Kootali - Home Page [x-MoBiLe] Nulled';
?>