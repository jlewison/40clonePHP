<?php
require_once ('../common/config.inc.php');
$CFG['lang']['include_files'][] = 'admin/includes/languages/%s/index.php';
$CFG['html']['header'] = 'admin/includes/languages/%s/html_header.php';
$CFG['html']['footer'] = 'admin/includes/languages/%s/html_footer.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class IndexFormHandler extends FormHandler
{
}
$indexfrm = new IndexFormHandler();
$indexfrm->setDBObject($db);
$indexfrm->makeGlobalize($CFG, $LANG);
$indexfrm->setPageBlockNames(array('form_index'));
$indexfrm->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$indexfrm->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$indexfrm->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$indexfrm->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$indexfrm->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$indexfrm->setAllPageBlocksHide();
$indexfrm->setPageBlockShow('form_index');




?>
<div id="selEditForum">
	<h2><?php echo $LANG['index_title']; ?></h2>

<?php
if ($indexfrm->isShowPageBlock('form_index'))
{
?>
	<table class="clsIndexTable" summary="<?php echo $LANG['index_tbl_summary']; ?>">
	    <tr>
			<td>
				<p><a href="editConfig.php"><img src="<?php echo $CFG['site']['url'] . 'admin/images/icon-setting.jpg'; ?>" /></a></p>
				<p><a href="editConfig.php"><?php echo $LANG['settings']; ?></a></p>
			</td>
			<td>
				<p><a href="ansVideoPlayerSettings.php"><img src="<?php echo $CFG['site']['url'] . 'admin/images/icon-videoplayer.jpg'; ?>" /></a></p>
				<p><a href="ansVideoPlayerSettings.php"><?php echo $LANG['video_player']; ?></a></p>
			</td>
			<td>
				<p><a href="manageAnswers.php"><img src="<?php echo $CFG['site']['url'] . 'admin/images/icon-answer.jpg'; ?>" /></a></p>
				<p><a href="manageAnswers.php"><?php echo $LANG['answers']; ?></a></p>
			</td>
	   	</tr>
		<tr>
			<td>
				<p><a href="forums.php"><img src="<?php echo $CFG['site']['url'] . 'admin/images/icon-forums.jpg'; ?>" /></a></p>
				<p><a href="forums.php"><?php echo $LANG['forums']; ?></a></p>
			</td>
			<td>
				<p><a href="manageBlogs.php"><img src="<?php echo $CFG['site']['url'] . 'admin/images/icon-blogs.jpg'; ?>" /></a></p>
				<p><a href="manageBlogs.php"><?php echo $LANG['blogs']; ?></a></p>
			</td>
			<td>
				<p><a href="manageAnswersMembers.php"><img src="<?php echo $CFG['site']['url'] . 'admin/images/icon-member.jpg'; ?>" /></a></p>
				<p><a href="manageAnswersMembers.php"><?php echo $LANG['members']; ?></a></p>
			</td>
	   	</tr>
		<tr>
			<td>
				<p><a href="manageBanner.php"><img src="<?php echo $CFG['site']['url'] . 'admin/images/icon-banner.jpg'; ?>" /></a></p>
				<p><a href="manageBanner.php"><?php echo $LANG['banners']; ?></a></p>
			</td>
			<td>
				<p><a href="addNewsLetter.php"><img src="<?php echo $CFG['site']['url'] . 'admin/images/icon-newsletter.jpg'; ?>" /></a></p>
				<p><a href="addNewsLetter.php"><?php echo $LANG['news_letter']; ?></a></p>
			</td>
			<td>
				<p><a href="<?php echo $CFG['site']['url'] . 'members/'; ?>"><img src="<?php echo $CFG['site']['url'] . 'admin/images/icon-memberlogin.jpg'; ?>" /></a></p>
				<p><a href="<?php echo $CFG['site']['url'] . 'members/'; ?>"><?php echo $LANG['member_login']; ?></a></p>
			</td>
	   	</tr>
		<tr>
			<td>
				<p><a href="manageAvatars.php"><img src="<?php echo $CFG['site']['url'] . 'admin/images/icon-avatar.jpg'; ?>" /></a></p>
				<p><a href="manageAvatars.php"><?php echo $LANG['manage_avatars']; ?></a></p>
			</td>
			<td>
				<p><a href="manageStaticPages.php"><img src="<?php echo $CFG['site']['url'] . 'admin/images/icon-static.jpg'; ?>" /></a></p>
				<p><a href="manageStaticPages.php"><?php echo $LANG['manage_static_pages']; ?></a></p>
			</td>
			<td>
				<p><a href="<?php echo $CFG['site']['url']; ?>logout.php"><img src="<?php echo $CFG['site']['url'] . 'admin/images/logout.jpg'; ?>" /></a></p>
				<p><a href="<?php echo $CFG['site']['url']; ?>logout.php">Logout</a></p>
			</td>
		</tr>
	</table>
<?php
}
?>
</div>

<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>