<?php
require_once ('../common/config.inc.php');
$CFG['lang']['include_files'][] = 'admin/includes/languages/%s/manageBanner.php';
$CFG['html']['header'] = 'admin/includes/languages/%s/html_header.php';
$CFG['html']['footer'] = 'admin/includes/languages/%s/html_footer.php';
$CFG['mods']['include_files'][] = 'common/languages/%s/lists_array/banner_list_array.inc.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['mods']['include_files'][] = 'common/classes/class_ListRecordsHandler.lib.php';
$CFG['lang']['include_files'][] = 'common/languages/%s/help.inc.php';
require ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class Add extends ListRecordsHandler
{
		public function chkIsValidDate($field, $date_arr, $err_tip = '')
		{
				if (!checkdate($this->fields_arr[$date_arr['1']], $this->fields_arr[$date_arr['0']], $this->fields_arr[$date_arr['2']]))
				{
						$this->setFormFieldErrorTip($field, $err_tip);
						return false;
				}
		}
		public function getUserId($user_name)
		{
				$sql = 'SELECT ' . $this->getUserTableField('user_id') . ' as user_id FROM ' . $this->CFG['db']['tbl']['users'] . ' WHERE ' . $this->getUserTableField('name') . '=' . $this->dbObj->Param('user_name');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($user_name));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($row = $rs->FetchRow()) return $row['user_id'];
				return 0;
		}
		public function buildConditionQuery()
		{
				$this->sql_condition = '';
				if ($this->fields_arr['user_name'])
				{
						$this->sql_condition .= 'user_id=\'' . addslashes($this->getUserId($this->fields_arr['user_name'])) . '\' AND ';
				}
				if ($this->fields_arr['block_search']) $this->sql_condition .= 'block=\'' . addslashes($this->fields_arr['block_search']) . '\' AND ';
				$this->sql_condition = substr($this->sql_condition, 0, strrpos($this->sql_condition, 'AND'));
		}
		public function buildSortQuery()
		{
				$this->sql_sort = $this->fields_arr['orderby_field'] . ' ' . $this->fields_arr['orderby'];
		}
		public function insertAdvertisementTable()
		{
				$start_date = $this->fields_arr['start_year'] . '-' . str_pad($this->fields_arr['start_month'], 2, "0", STR_PAD_LEFT) . '-' . str_pad($this->fields_arr['start_day'], 2, "0", STR_PAD_LEFT) . ' 00:00:00';
				$end_date = $this->fields_arr['end_year'] . '-' . str_pad($this->fields_arr['end_month'], 2, "0", STR_PAD_LEFT) . '-' . str_pad($this->fields_arr['end_day'], 2, "0", STR_PAD_LEFT) . ' 00:00:00';
				$this->fields_arr['allowed_impressions'] = $this->fields_arr['allowed_impressions'] ? $this->fields_arr['allowed_impressions'] : 0;
				$sql = 'INSERT INTO ' . $this->CFG['db']['tbl']['advertisement'] . ' SET' . ' user_id=' . $this->CFG['user']['user_id'] . ',' . ' block=' . $this->dbObj->Param('block') . ',' . ' post_from=\'Admin\',' . ' about=' . $this->dbObj->Param('about') . ',' . ' source=' . $this->dbObj->Param('source') . ',' . ' start_date=' . $this->dbObj->Param('start_date') . ',' . ' end_date=' . $this->dbObj->Param('end_date') . ',' . ' status=' . $this->dbObj->Param('status') . ',' . ' add_type=' . $this->dbObj->Param('add_type') . ',' . ' allowed_impressions=' . $this->dbObj->Param('allowed_impressions') . ',' . ' date_added=NOW()';
				$array = array($this->fields_arr['block'], $this->fields_arr['about'], $this->fields_arr['source'], $start_date, $end_date, $this->fields_arr['status'], $this->fields_arr['add_type'], $this->fields_arr['allowed_impressions']);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, $array);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$this->setDefaultValue();
		}
		function updateAdvertisementTable()
		{
				$start_date = $this->fields_arr['start_year'] . '-' . str_pad($this->fields_arr['start_month'], 2, "0", STR_PAD_LEFT) . '-' . str_pad($this->fields_arr['start_day'], 2, "0", STR_PAD_LEFT) . ' 00:00:00';
				$end_date = $this->fields_arr['end_year'] . '-' . str_pad($this->fields_arr['end_month'], 2, "0", STR_PAD_LEFT) . '-' . str_pad($this->fields_arr['end_day'], 2, "0", STR_PAD_LEFT) . ' 00:00:00';
				$this->fields_arr['allowed_impressions'] = $this->fields_arr['allowed_impressions'] ? $this->fields_arr['allowed_impressions'] : 0;
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['advertisement'] . ' SET' . ' block=' . $this->dbObj->Param('block') . ',' . ' about=' . $this->dbObj->Param('about') . ',' . ' source=' . $this->dbObj->Param('source') . ',' . ' start_date=' . $this->dbObj->Param('start_date') . ',' . ' end_date=' . $this->dbObj->Param('end_date') . ',' . ' status=' . $this->dbObj->Param('status') . ',' . ' add_type=' . $this->dbObj->Param('add_type') . ',' . ' allowed_impressions=' . $this->dbObj->Param('allowed_impressions') . ' WHERE add_id=' . $this->dbObj->Param('add_id');
				$array = array($this->fields_arr['block'], $this->fields_arr['about'], $this->fields_arr['source'], $start_date, $end_date, $this->fields_arr['status'], $this->fields_arr['add_type'], $this->fields_arr['allowed_impressions'], $this->fields_arr['aid']);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, $array);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$this->setDefaultValue();
				if ($this->dbObj->Affected_Rows()) return true;
				return false;
		}
		public function deleteAdvertisementTable()
		{
				$sql = 'DELETE FROM ' . $this->CFG['db']['tbl']['advertisement'] . ' WHERE' . ' add_id IN(' . $this->fields_arr['aid'] . ')';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($this->dbObj->Affected_Rows())
				{
						return true;
				}
				return false;
		}
		public function updateStatusInAdvertisementTable($status)
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['advertisement'] . ' SET' . ' status=' . $this->dbObj->Param('status') . ' WHERE' . ' add_id IN(' . $this->fields_arr['aid'] . ')';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($status));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($this->dbObj->Affected_Rows())
				{
						return true;
				}
				return false;
		}
		public function setDefaultValue()
		{
				$this->setFormField('block', '');
				$this->setFormField('about', '');
				$this->setFormField('source', '');
				$this->setFormField('start_date', '');
				$this->setFormField('start_day', date('d'));
				$this->setFormField('start_month', date('m'));
				$this->setFormField('start_year', date('Y'));
				$this->setFormField('end_date', '');
				$this->setFormField('end_day', date('d'));
				$this->setFormField('end_month', date('m'));
				$this->setFormField('end_year', date('Y'));
				$this->setFormField('status', 'toactivate');
				$this->setFormField('add_type', 'General');
		}
		public function populateAdvertisementValues()
		{
				$sql = 'SELECT block, about, source, start_date, end_date, status, add_type,' . ' allowed_impressions FROM ' . $this->CFG['db']['tbl']['advertisement'] . ' WHERE' . ' add_id=' . $this->dbObj->Param('add_id');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['aid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($row = $rs->FetchRow())
				{
						$this->fields_arr['block'] = $row['block'];
						$this->fields_arr['about'] = $row['about'];
						$this->fields_arr['source'] = $row['source'];
						$this->fields_arr['start_date'] = $row['start_date'];
						$this->fields_arr['end_date'] = $row['end_date'];
						$this->fields_arr['status'] = $row['status'];
						$this->fields_arr['add_type'] = $row['add_type'];
						$start_date = explode(' ', $row['start_date']);
						$start_date = explode('-', $start_date[0]);
						$this->fields_arr['start_year'] = $start_date['0'];
						$this->fields_arr['start_month'] = $start_date['1'];
						$this->fields_arr['start_day'] = $start_date['2'];
						$end_date = explode(' ', $row['end_date']);
						$end_date = explode('-', $end_date[0]);
						$this->fields_arr['end_year'] = $end_date['0'];
						$this->fields_arr['end_month'] = $end_date['1'];
						$this->fields_arr['end_day'] = $end_date['2'];
						$this->fields_arr['allowed_impressions'] = $row['allowed_impressions'];
						return true;
				}
				return false;
		}
		public function showAdd()
		{
				$fields_list = array('name as user_name');
				while ($row = $this->fetchResultRecord())
				{
						if (!isset($this->UserDetails[$row['user_id']])) $this->getUserDetails($row['user_id'], $fields_list);
						if (!isset($this->UserDetails[$row['user_id']]['user_name'])) $this->UserDetails[$row['user_id']]['user_name'] = 'Admin';
?>
					<tr class="<?php echo $this->getCSSRowClass(); ?>">
						<td><input type="checkbox" class="clsCheckRadio" name="aid[]" onclick="disableHeading('selListAdvertisementForm');" value="<?php echo $row['add_id']; ?>" tabindex="<?php echo $this->getTabIndex(); ?>" /></td>
						<td><?php echo $row['block']; ?></td>
						<td class="clsBannerDescription"><?php echo $row['about']; ?></td>
<?php
						if ($this->CFG['admin']['banner']['impressions_date'])
						{
?>
						<td><?php echo $row['start_date']; ?></td>
						<td><?php echo $row['end_date']; ?></td>
						<td><?php echo $row['allowed_impressions']; ?></td>
						<td><?php echo $row['completed_impressions']; ?></td>
<?php
						}
?>
						<td><?php echo $this->UserDetails[$row['user_id']]['user_name']; ?></td>
						<td><?php echo $row['add_type']; ?></td>
						<td><?php echo $row['status']; ?></td>
						<td><?php echo $row['date_added']; ?></td>
						<td>
							<a href="<?php echo $this->CFG['site']['url']; ?>admin/manageBanner.php?act=edt&amp;aid=<?php echo $row['add_id']; ?>&amp;start=<?php echo $this->fields_arr['start']; ?>&amp;block_search=<?php echo $this->fields_arr['block_search']; ?>&amp;user_name=<?php echo $this->fields_arr['user_name']; ?>"><?php echo $this->LANG['edit']; ?></a>
							<div class="clsDownPreviewBanner" id="selPreview<?php echo $row['add_id']; ?>" style="display:none;position:absolute"><?php echo html_entity_decode($row['source']); ?></div>
							<a href="#" onMouseOver="Element.show('selPreview<?php echo $row['add_id']; ?>');return false;" onMouseOut="Element.hide('selPreview<?php echo $row['add_id']; ?>');"><?php echo $this->LANG['preview']; ?></a>
							<a id="code_<?php echo $row['add_id']; ?>" href="#" onClick="return populateCode('<?php echo $row['block']; ?>', 'code_<?php echo $row['add_id']; ?>')"><?php echo $this->LANG['code']; ?></a>
						</td>
					</tr>
<?php
				}
		}
		public function populatePosition($banner_position = array())
		{
				$banner_key = array_keys($banner_position);
				return implode(', ', $banner_key);
		}
}
$Add = new Add();
$Add->setDBObject($db);
$Add->makeGlobalize($CFG, $LANG);
$Add->setPageBlockNames(array('msg_form_error', 'msg_form_success', 'addAdvertisementBlock', 'listAdvertisementBlock', 'editAdvertisementBlock', 'searchBlock'));
$Add->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$Add->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$Add->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$Add->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$Add->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$Add->setFormField('aid', '');
$Add->setFormField('act', '');
$Add->setFormField('block', '');
$Add->setFormField('about', '');
$Add->setFormField('source', '');
$Add->setFormField('start_date', '');
$Add->setFormField('start_day', date('d'));
$Add->setFormField('start_month', date('m'));
$Add->setFormField('start_year', date('Y'));
$Add->setFormField('end_date', '');
$Add->setFormField('end_day', date('d'));
$Add->setFormField('end_month', date('m'));
$Add->setFormField('end_year', date('Y'));
$Add->setFormField('add_type', 'General');
$Add->setFormField('status', 'toactivate');
$Add->setFormField('allowed_impressions', '0');
$Add->setFormField('user_name', '');
$Add->setFormField('block_search', '');
$Add->setFormField('orderby_field', 'add_id');
$Add->setFormField('orderby', 'DESC');
$Add->setFormField('start', '0');
$Add->setFormField('numpg', $CFG['data_tbl']['numpg']);
$Add->setCSSColumnHeaderCellAscSortClasses(array('clsColumnHeaderCellAscSort1', 'clsColumnHeaderCellAscSort2', 'clsColumnHeaderCellAscSort3', 'clsColumnHeaderCellAscSort4', 'clsColumnHeaderCellAscSort5'));
$Add->setCSSColumnHeaderCellDefaultClass('clsColumnHeaderCellDefault');
$Add->setCSSColumnHeaderCellDescSortClasses(array('clsColumnHeaderCellDscSort1', 'clsColumnHeaderCellDscSort2', 'clsColumnHeaderCellDscSort3', 'clsColumnHeaderCellDscSort4', 'clsColumnHeaderCellDscSort5'));
$Add->setMinRecordSelectLimit(2);
$Add->setMaxRecordSelectLimit($CFG['data_tbl']['max_record_select_limit']);
$Add->setNumPerPageListArr($CFG['data_tbl']['numperpage_list_arr']);
$Add->setTableNames(array($CFG['db']['tbl']['advertisement']));
$Add->setReturnColumns(array('add_id', 'block', 'about', 'source', 'start_date', 'end_date', 'IF (status=\'activate\', \'Active\', \'Inactive\') AS status', 'add_type', 'date_added', 'allowed_impressions', 'completed_impressions', 'user_id'));
$Add->setPageBlockShow('addAdvertisementBlock');
$Add->setPageBlockShow('listAdvertisementBlock');
$Add->setPageBlockShow('searchBlock');
$Add->sanitizeFormInputs($_REQUEST);
if ($Add->isFormPOSTed($_POST, 'add_submit'))
{
		$Add->chkIsNotEmpty('block', $LANG['err_tip_compulsory']);
		$Add->chkIsNotEmpty('source', $LANG['err_tip_compulsory']);
		$Add->chkIsNotEmpty('about', $LANG['err_tip_compulsory']);
		$Add->chkIsValidDate('start_date', array('start_day', 'start_month', 'start_year'), $LANG['err_tip_compulsory']);
		$Add->chkIsValidDate('end_date', array('end_day', 'end_month', 'end_year'), $LANG['err_tip_compulsory']);
		$Add->getFormField('allowed_impressions') and $Add->chkIsNumeric('allowed_impressions', $LANG['err_tip_numeric']);
		if ($Add->isValidFormInputs())
		{
				$Add->insertAdvertisementTable();
				$Add->setPageBlockShow('msg_form_success');
				$Add->setCommonErrorMsg($LANG['success_added']);
		}
		else
		{
				$Add->setPageBlockShow('msg_form_error');
		}
}
if ($Add->isFormPOSTed($_POST, 'update_submit'))
{
		$Add->chkIsNotEmpty('source', $LANG['err_tip_compulsory']);
		$Add->chkIsNotEmpty('about', $LANG['err_tip_compulsory']);
		$Add->chkIsValidDate('start_date', array('start_day', 'start_month', 'start_year'), $LANG['err_tip_compulsory']);
		$Add->chkIsValidDate('end_date', array('end_day', 'end_month', 'end_year'), $LANG['err_tip_compulsory']);
		if ($Add->isValidFormInputs())
		{
				if ($Add->updateAdvertisementTable())
				{
						$Add->setPageBlockShow('msg_form_success');
						$Add->setCommonErrorMsg($LANG['success_updated']);
				}
				else
				{
						$Add->setPageBlockShow('msg_form_success');
						$Add->setCommonErrorMsg($LANG['no_changes']);
				}
		}
		else
		{
				$Add->setPageBlockShow('msg_form_error');
				$Add->setPageBlockShow('editAdvertisementBlock');
		}
}
else
		if ($Add->isFormPOSTed($_POST, 'cancel_submit'))
		{
				$Add->setDefaultValue();
		}
if ($Add->isFormGETed($_GET, 'act'))
{
		if ($Add->getFormField('act') == 'edt')
		{
				if ($Add->populateAdvertisementValues()) $Add->setPageBlockShow('editAdvertisementBlock');
		}
}
if ($Add->isFormPOSTed($_POST, 'act'))
{
		if ($Add->getFormField('act') == 'delete')
		{
				if ($Add->deleteAdvertisementTable())
				{
						$Add->setPageBlockShow('msg_form_success');
						$Add->setCommonErrorMsg($LANG['success_deleted']);
				}
				else
				{
						$Add->setPageBlockShow('msg_form_success');
						$Add->setCommonErrorMsg($LANG['no_changes']);
				}
		}
		else
				if ($Add->getFormField('act') == 'activate')
				{
						if ($Add->updateStatusInAdvertisementTable('activate'))
						{
								$Add->setPageBlockShow('msg_form_success');
								$Add->setCommonErrorMsg($LANG['success_activated']);
						}
						else
						{
								$Add->setPageBlockShow('msg_form_success');
								$Add->setCommonErrorMsg($LANG['no_changes']);
						}
				}
		if ($Add->getFormField('act') == 'toactivate')
		{
				if ($Add->updateStatusInAdvertisementTable('toactivate'))
				{
						$Add->setPageBlockShow('msg_form_success');
						$Add->setCommonErrorMsg($LANG['success_toactivated']);
				}
				else
				{
						$Add->setPageBlockShow('msg_form_success');
						$Add->setCommonErrorMsg($LANG['no_changes']);
				}
		}
}




?>
<script type="text/javascript" language="javascript">
	var block_arr= new Array('selMsgConfirm', 'selCodeForm');
	function $(elmt){
		return document.getElementById(elmt);
	}
	function populateCode(block, pos){
		var codeDetail = "<div><?php echo '<?php echo getAdvertisement(\'{block}\');?>'; ?></div>";//"
		var codeTitle = "<?php echo $LANG['code_title']; ?>";
		var cd = codeDetail.replace('{block}', block);
		var ct = codeTitle.replace('{block}', block);
		Confirmation(pos, 'selCodeForm', 'codeForm', Array('codeTitle', 'addCode'), Array(ct, cd), Array('innerHTML', 'value'), -100, -500);
		return false;
	}
	var popupWindow = function(){
		var additional = '';
		if(arguments[1])
			additional += ',width='+arguments[1];

		if(arguments[2])
			additional += ',height='+arguments[2];

		window.open (arguments[0], "","status=0,toolbar=0,resizable=0,scrollbars=1"+additional);
		return false;
	}
   var showBannerSource = function(){

		if($('source').value == '')
		return false;
		$('selPreview').innerHTML=$('source').value;
		Element.show('selPreview');
		document.getElementById('source').blur();
		return false;
   }
   var hideBannerSource = function(){
		document.getElementById('source').focus();
		Element.hide('selPreview');

   }

</script>
<div id="selAdvertisement">
  	<h2 class="clsBannerTitle"><span><?php echo $LANG['page_title']; ?></h2>
<?php
if ($Add->isShowPageBlock('msg_form_error'))
{
?>
	<div id="selMsgError">
		<p><?php echo $LANG['msg_err_sorry']; ?></p>
		<p><?php echo $Add->getCommonErrorMsg(); ?></p>
	</div>
<?php
}
if ($Add->isShowPageBlock('msg_form_success'))
{
?>
	  <div id="selMsgSuccess">
	   	<p><?php echo $Add->getCommonErrorMsg(); ?></p>
	  </div>
<?php
}
if ($Add->isShowPageBlock('addAdvertisementBlock'))
{
?>
	  <div id="selAddAdvertisementBlock">
	   		<form name="selAddAdvertisementForm" id="selAddAdvertisementForm" method="post" action="<?php echo 'manageBanner.php'; ?>" autocomplete="off">
				<table summary="<?php echo $LANG['tbl_summary']; ?>">
					<tr>
						<td class="<?php echo $Add->getCSSFormLabelCellClass('block'); ?>">
							<?php ShowHelpTip('managebanners_block'); ?>
							<label for="block"><?php echo $LANG['label_block']; ?></label>
						</td>
						<td class="<?php echo $Add->getCSSFormFieldCellClass('block'); ?>">
							<?php echo $Add->getFormFieldErrorTip('block'); ?>
							<input type="text" class="clsTextBox" name="block" id="block" tabindex="<?php echo $Add->getTabIndex(); ?>" value="<?php echo $Add->getFormField('block'); ?>" />
							<!-- <p class="clsHelpBanner"><a href="#" onClick="return popupWindow('<?php echo $CFG['site']['url']; ?>members/bannerPosition.php', '552', '467')"><?php echo $LANG['banner_position']; ?></a></p> -->
							<p><?php echo $LANG['default_postion']; ?>&nbsp;<?php echo $Add->populatePosition($LANG_LIST_ARR['banner_list']); ?></p>
						</td>
				   	</tr>
					<tr>
						<td class="<?php echo $Add->getCSSFormLabelCellClass('source'); ?>">
							<?php ShowHelpTip('managebanners_source'); ?>
							<label for="source"><?php echo $LANG['label_source']; ?></label>
						</td>
						<td class="<?php echo $Add->getCSSFormFieldCellClass('source'); ?>">
							<?php echo $Add->getFormFieldErrorTip('source'); ?>
							<textarea name="source" id="source" tabindex="<?php echo $Add->getTabIndex(); ?>"><?php echo $Add->getFormField('source'); ?></textarea>
							<div id="selPreview" style="display:none;position:absolute" class="clsPreviewBanner" onMouseOver="showBannerSource();" onMouseOut="hideBannerSource();"></div>
							<p><a href="#" onMouseOver="showBannerSource();" onMouseOut="hideBannerSource();"><?php echo $LANG['preview']; ?></a></p>
						</td>
				   	</tr>
					<tr>
						<td class="<?php echo $Add->getCSSFormLabelCellClass('about'); ?>">
							<?php ShowHelpTip('managebanners_about'); ?>
							<label for="about"><?php echo $LANG['label_about']; ?></label>
						</td>
						<td class="<?php echo $Add->getCSSFormFieldCellClass('about'); ?>">
							<?php echo $Add->getFormFieldErrorTip('about'); ?>
							<textarea name="about" id="about" tabindex="<?php echo $Add->getTabIndex(); ?>"><?php echo $Add->getFormField('about'); ?></textarea>
						</td>
				   	</tr>
<?php
		if ($CFG['admin']['banner']['impressions_date'])
		{
?>
					<tr>
						<td class="<?php echo $Add->getCSSFormLabelCellClass('start_date'); ?>"><?php ShowHelpTip('managebanners_start_date'); ?>
							<label for="start_day"><?php echo $LANG['label_start_date']; ?></label>
						</td>
						<td class="<?php echo $Add->getCSSFormFieldCellClass('start_date'); ?>"><?php echo $Add->getFormFieldErrorTip('start_date'); ?>
							<select name="start_day" id="start_day" tabindex="<?php echo $Add->getTabIndex(); ?>">
								<option value="0"><?php echo $LANG['activate_dd']; ?></option>
								<?php $Add->populateBWNumbers(1, 31, $Add->getFormField('start_day')); ?>
							</select>
							<select name="start_month" id="start_month" tabindex="<?php echo $Add->getTabIndex(); ?>">
								<option value="0"><?php echo $LANG['activate_mm']; ?></option>
								<?php $Add->populateBWNumbers(1, 12, $Add->getFormField('start_month')); ?>
							</select>
							<select name="start_year" id="start_year" tabindex="<?php echo $Add->getTabIndex(); ?>">
								<option value="0"><?php echo $LANG['activate_yy']; ?></option>
								<?php $Add->populateBWNumbers(date('Y'), date('Y') + 30, $Add->getFormField('start_year')); ?>
							</select>
						</td>
					</tr>
					<tr>
						<td class="<?php echo $Add->getCSSFormLabelCellClass('end_date'); ?>"><?php ShowHelpTip('managebanners_end_date'); ?>
							<label for="end_day"><?php echo $LANG['label_end_date']; ?></label>
						</td>
						<td class="<?php echo $Add->getCSSFormFieldCellClass('end_date'); ?>"><?php echo $Add->getFormFieldErrorTip('end_date'); ?>
							<select name="end_day" id="end_day" tabindex="<?php echo $Add->getTabIndex(); ?>">
								<option value="0"><?php echo $LANG['activate_dd']; ?></option>
								<?php $Add->populateBWNumbers(1, 31, $Add->getFormField('end_day')); ?>
							</select>
							<select name="end_month" id="end_month" tabindex="<?php echo $Add->getTabIndex(); ?>">
								<option value="0"><?php echo $LANG['activate_mm']; ?></option>
								<?php $Add->populateBWNumbers(1, 12, $Add->getFormField('end_month')); ?>
							</select>
							<select name="end_year" id="end_year" tabindex="<?php echo $Add->getTabIndex(); ?>">
								<option value="0"><?php echo $LANG['activate_yy']; ?></option>
								<?php $Add->populateBWNumbers(date('Y'), date('Y') + 30, $Add->getFormField('end_year')); ?>
							</select>
						</td>
					</tr>
					<tr>
						<td class="<?php echo $Add->getCSSFormLabelCellClass('allowed_impressions'); ?>">
							<?php ShowHelpTip('managebanners_allowed_impressions'); ?>
							<label for="allowed_impressions"><?php echo $LANG['label_allowed_impressions']; ?></label>
						</td>
						<td class="<?php echo $Add->getCSSFormFieldCellClass('allowed_impressions'); ?>">
							<?php echo $Add->getFormFieldErrorTip('allowed_impressions'); ?>
							<input type="text" class="clsTextBox" name="allowed_impressions" id="allowed_impressions" tabindex="<?php echo $Add->getTabIndex(); ?>" value="<?php echo $Add->getFormField('allowed_impressions'); ?>" />
						</td>
				   	</tr>
<?php
		}
		if (chkAllowedModule(array('content_filter')))
		{
?>
					<tr>
						<td class="<?php echo $Add->getCSSFormLabelCellClass('add_type'); ?>">
							<?php ShowHelpTip('managebanners_add_type'); ?>
							<label for="add_type1"><?php echo $LANG['label_add_type']; ?></label>
						</td>
						<td class="<?php echo $Add->getCSSFormFieldCellClass('add_type'); ?>">
							<?php echo $Add->getFormFieldErrorTip('add_type'); ?>
							<input type="radio" class="clsCheckRadio" name="add_type" id="add_type1" tabindex="<?php echo $Add->getTabIndex(); ?>" value="General"<?php echo $Add->isCheckedRadio('add_type', 'General'); ?> />
							<label for="add_type1"><?php echo $LANG['add_type_general']; ?></label>
							<input type="radio" class="clsCheckRadio" name="add_type" id="add_type2" tabindex="<?php echo $Add->getTabIndex(); ?>" value="Porn"<?php echo $Add->isCheckedRadio('add_type', 'Porn'); ?> />
							<label for="add_type2"><?php echo $LANG['add_type_porn']; ?></label>
						</td>
				   	</tr>
<?php
		}
?>
					<tr>
						<td class="<?php echo $Add->getCSSFormLabelCellClass('status'); ?>">
							<?php ShowHelpTip('managebanners_status'); ?>
							<label for="status1"><?php echo $LANG['label_status']; ?></label>
						</td>
						<td class="<?php echo $Add->getCSSFormFieldCellClass('status'); ?>">
							<?php echo $Add->getFormFieldErrorTip('status'); ?>
							<input type="radio" class="clsCheckRadio" name="status" id="status1" tabindex="<?php echo $Add->getTabIndex(); ?>" value="activate"<?php echo $Add->isCheckedRadio('status', 'activate'); ?> />
							<label for="status1"><?php echo $LANG['status_activate']; ?></label>
							<input type="radio" class="clsCheckRadio" name="status" id="status2" tabindex="<?php echo $Add->getTabIndex(); ?>" value="toactivate"<?php echo $Add->isCheckedRadio('status', 'toactivate'); ?> />
							<label for="status2"><?php echo $LANG['status_toactivate']; ?></label>
						</td>
				   	</tr>
					<tr>
                    <td>&nbsp;</td>
						<td class="<?php echo $Add->getCSSFormFieldCellClass('submit'); ?>">
<?php
		$Add->populateHidden(array('start'));
		if ($Add->isShowPageBlock('editAdvertisementBlock'))
		{
				$Add->populateHidden(array('aid', 'user_name', 'block_search'));
?>
							<input type="submit" class="clsSubmitButton" name="update_submit" id="update_submit" tabindex="<?php echo $Add->getTabIndex(); ?>" value="<?php echo $LANG['update_submit']; ?>" />
							<input type="submit" class="clsCancelButton" name="cancel_submit" id="cancel_submit" tabindex="<?php echo $Add->getTabIndex(); ?>" value="<?php echo $LANG['cancel_submit']; ?>" />
<?php
		}
		else
		{
?>
							<input type="submit" class="clsSubmitButton" name="add_submit" id="add_submit" tabindex="<?php echo $Add->getTabIndex(); ?>" value="<?php echo $LANG['add_submit']; ?>" />
<?php
		}
?>
						</td>
					</tr>
				</table>
			</form>
	  </div>
<?php
}
if ($Add->isShowPageBlock('searchBlock'))
{
?>
	  <div id="selSearchBlock">
	   		<form name="selSearchForm" id="selSearchForm" method="post" action="<?php echo $_SERVER['REQUEST_URI']; ?>" autocomplete="off">
				<table summary="<?php echo $LANG['tbl_summary']; ?>">
					<tr>
						<td class="<?php echo $Add->getCSSFormLabelCellClass('user_name'); ?>">
							<label for="user_name"><?php echo $LANG['label_user_name']; ?></label>
						</td>
						<td class="<?php echo $Add->getCSSFormFieldCellClass('user_name'); ?>">
							<?php echo $Add->getFormFieldErrorTip('user_name'); ?>
							<input type="text" class="clsTextBox" name="user_name" id="user_name" tabindex="<?php echo $Add->getTabIndex(); ?>" value="<?php echo $Add->getFormField('user_name'); ?>" />
						</td>
						<td class="<?php echo $Add->getCSSFormLabelCellClass('block_search'); ?>">
							<label for="block_search"><?php echo $LANG['label_block']; ?></label>
						</td>
						<td class="<?php echo $Add->getCSSFormFieldCellClass('block_search'); ?>">
							<?php echo $Add->getFormFieldErrorTip('block_search'); ?>
							<input type="text" class="clsTextBox" name="block_search" id="block_search" tabindex="<?php echo $Add->getTabIndex(); ?>" value="<?php echo $Add->getFormField('block_search'); ?>" />
						</td>
						<td>
							<input type="submit" class="clsSubmitButton" name="search_submit" id="search_submit" tabindex="<?php echo $Add->getTabIndex(); ?>" value="<?php echo $LANG['search_submit']; ?>" />
						</td>
				   	</tr>
				</table>
			</form>
	  </div>
<?php
}
if ($Add->isShowPageBlock('listAdvertisementBlock'))
{
		$Add->buildSelectQuery();
		$Add->buildConditionQuery();
		$Add->buildSortQuery();
		$Add->buildQuery();
		$Add->executeQuery();
		if ($Add->isResultsFound())
		{
				$anchor = 'dAltMlti';
?>
			<div id="selMsgConfirm" class="selMsgConfirm" style="display:none;position:absolute;">
	    		<h3 id="confirmation_msg"></h3>
		      	<form name="deleteForm" id="deleteForm" method="post" action="<?php echo $_SERVER['REQUEST_URI']; ?>" autocomplete="off">
		        	<table summary="<?php echo $LANG['tbl_summary']; ?>">
					  	<tr>
			            	<td>
							  	<input type="submit" class="clsSubmitButton" name="delete_add" id="delete_add" value="<?php echo $LANG['act_yes']; ?>" tabindex="<?php echo $Add->getTabIndex(); ?>" /> &nbsp;
				              	<input type="button" class="clsCancelButton" name="cancel" id="cancel" value="<?php echo $LANG['act_no']; ?>" tabindex="<?php echo $Add->getTabIndex(); ?>" onClick="return hideAllBlocks('selListAdvertisementForm');" />
				              	<input type="hidden" name="aid" id="aid" />
								<input type="hidden" name="act" id="act" />
								<?php $Add->populateHidden(array('start')); ?>
							</td>
			          	</tr>
		        	</table>
		      	</form>
		    </div>
			<div id="selCodeForm" class="clsPopupConfirmation" style="display:none;position:absolute;">
	    		<h2 id="codeTitle"></h2>
				<span id="cancel"><a href="<?php echo $_SERVER['REQUEST_URI']; ?>" onClick="return hideAllBlocks();"><?php echo $LANG['close']; ?></a></span>
		      	<form name="codeForm" id="codeForm" method="post" action="<?php echo $_SERVER['REQUEST_URI']; ?>" autocomplete="off">
		        	<table summary="<?php echo $LANG['tbl_summary']; ?>">
					  	<tr>
			            	<td>
								<textarea name="addCode" id="addCode" rows="2" cols="50"  onfocus="this.select()" onclick="this.select()" readonly></textarea>
								<p><?php echo $LANG['code_instruction']; ?></p>
							</td>
			          	</tr>
		        	</table>
		      	</form>
		    </div>
<?php
				if ($CFG['admin']['navigation']['top']) $Add->populatePageLinks($Add->getFormField('start'), array('user_name', 'block_search'));
?>
			<form name="selListAdvertisementForm" id="selListAdvertisementForm" method="post" action="<?php echo $_SERVER['REQUEST_URI']; ?>" autocomplete="off">
				<table summary="<?php echo $LANG['tbl_summary']; ?>" class="clsBannerTbl">
					<tr>
						<th><input type="checkbox" class="clsCheckRadio" name="check_all" onclick = "CheckAll(document.selListAdvertisementForm.name, document.selListAdvertisementForm.check_all.name)" tabindex="<?php echo $Add->getTabIndex(); ?>" /></th>
						<th><?php echo $LANG['th_block']; ?></th>
						<th class="clsBannerDescription"><?php echo $LANG['th_about']; ?></th>
<?php
				if ($CFG['admin']['banner']['impressions_date'])
				{
?>
						<th><?php echo $LANG['th_start_date']; ?></th>
						<th><?php echo $LANG['th_end_date']; ?></th>
						<th><?php echo $LANG['allowed_impressions']; ?></th>
						<th><?php echo $LANG['completed_impressions']; ?></th>
<?php
				}
?>
						<th><?php echo $LANG['th_added_by']; ?></th>
						<th><?php echo $LANG['th_add_type']; ?></th>
						<th><?php echo $LANG['th_status']; ?></th>
						<th><?php echo $LANG['th_date_added']; ?></th>
						<th>&nbsp;</th>
					</tr>
			  		<?php $Add->showAdd(); ?>
					<tr>
						<td class="<?php echo $Add->getCSSFormFieldCellClass('add_delete'); ?>" colspan="11">
							<a href="#" id="<?php echo $anchor; ?>"></a>
							<input type="button" class="clsSubmitButton" name="delete_submit" id="delete_submit" tabindex="<?php echo $Add->getTabIndex(); ?>" value="<?php echo $LANG['add_delete']; ?>" onClick="if(getMultiCheckBoxValue('selListAdvertisementForm', 'check_all', '<?php echo $LANG['check_atleast_one']; ?>', '<?php echo $anchor; ?>', -100, -500)){Confirmation('<?php echo $anchor; ?>', 'selMsgConfirm', 'deleteForm', Array('aid', 'act', 'confirmation_msg'), Array(multiCheckValue, 'delete', '<?php echo nl2br($LANG['delete_confirmation']); ?>'), Array('value', 'value', 'innerHTML'), -100, -500, 'selListAdvertisementForm');}" />
							<input type="button" class="clsSubmitButton" name="activate_submit" id="activate_submit" tabindex="<?php echo $Add->getTabIndex(); ?>" value="<?php echo $LANG['add_activate']; ?>" onClick="if(getMultiCheckBoxValue('selListAdvertisementForm', 'check_all', '<?php echo $LANG['check_atleast_one']; ?>', '<?php echo $anchor; ?>', -100, -500)){Confirmation('<?php echo $anchor; ?>', 'selMsgConfirm', 'deleteForm', Array('aid', 'act', 'confirmation_msg'), Array(multiCheckValue, 'activate', '<?php echo nl2br($LANG['activate_confirmation']); ?>'), Array('value', 'value', 'innerHTML'), -100, -500, 'selListAdvertisementForm');}" />
							<input type="button" class="clsSubmitButton" name="toactivate_submit" id="toactivate_submit" tabindex="<?php echo $Add->getTabIndex(); ?>" value="<?php echo $LANG['add_toactivate']; ?>" onClick="if(getMultiCheckBoxValue('selListAdvertisementForm', 'check_all', '<?php echo $LANG['check_atleast_one']; ?>', '<?php echo $anchor; ?>', -100, -500)){Confirmation('<?php echo $anchor; ?>', 'selMsgConfirm', 'deleteForm', Array('aid', 'act', 'confirmation_msg'), Array(multiCheckValue, 'toactivate', '<?php echo nl2br($LANG['toactivate_confirmation']); ?>'), Array('value', 'value', 'innerHTML'), -100, -500, 'selListAdvertisementForm');}" />
						</td>
				   	</tr>
				</table>
			</form>
<?php
				if ($CFG['admin']['navigation']['bottom']) $Add->populatePageLinks($Add->getFormField('start'), array('user_name', 'block_search'));
		}
		else
		{
?>
			<div id="selMsgAlert">
				<p><?php echo $LANG['no_records_found']; ?></p>
			</div>
<?php
		}
?>
		</div>
<?php
}
?>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>