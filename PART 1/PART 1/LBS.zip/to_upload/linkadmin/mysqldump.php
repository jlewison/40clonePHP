<?php
require_once('../Connections/apound.php'); include('restrict.php'); include('../settings.php');
set_time_limit(0);

$print_form=1;
$output_messages=array();


//test mysql connection
if( isset($_REQUEST['action']) )
{
	$mysql_host= "$hostname_apound";
	$mysql_database= "$database_apound";
	$mysql_username= "$username_apound";
	$mysql_password= "$password_apound";

	if( 'Test Connection' == $_REQUEST['action'])
	{
		_mysql_test($mysql_host,$mysql_database, $mysql_username, $mysql_password);
	}
	else if( 'Export' == $_REQUEST['action'])
	{
		_mysql_test($mysql_host,$mysql_database, $mysql_username, $mysql_password);
		if( 'SQL' == $_REQUEST['output_format'] )
		{
			$print_form=0;

			//ob_start("ob_gzhandler");
			header('Content-type: text/plain');
			header('Content-Disposition: attachment; filename="'.$mysql_host."_".$mysql_database."_".date('YmdHis').'.sql"');
			echo "/*LBS v.1.02 mysqldump */\n";
			_mysqldump($mysql_database);

			//header("Content-Length: ".ob_get_length());

			//ob_end_flush();
		}
		else if( 'CSV' == $_REQUEST['output_format'] && isset($_REQUEST['mysql_table']))
		{
			$print_form=0;

			ob_start("ob_gzhandler");

			header('Content-type: text/comma-separated-values');
			header('Content-Disposition: attachment; filename="'.$mysql_host."_".$mysql_database."_".$mysql_table."_".date('YmdHis').'.csv"');
			//header('Content-type: text/plain');
			_mysqldump_csv($_REQUEST['mysql_table']);
			header("Content-Length: ".ob_get_length());
			ob_end_flush();
		}
	}

}

function _mysqldump_csv($table)
{
	$delimiter= ",";
	if( isset($_REQUEST['csv_delimiter']))
		$delimiter= $_REQUEST['csv_delimiter'];

	if( 'Tab' == $delimiter)
		$delimiter="\t";


	$sql="select * from `$table`;";
	$result=mysql_query($sql);
	if( $result)
	{
		$num_rows= mysql_num_rows($result);
		$num_fields= mysql_num_fields($result);

		$i=0;
		while( $i < $num_fields)
		{
			$meta= mysql_fetch_field($result, $i);
			echo($meta->name);
			if( $i < $num_fields-1)
				echo "$delimiter";
			$i++;
		}
		echo "\n";

		if( $num_rows > 0)
		{
			while( $row= mysql_fetch_row($result))
			{
				for( $i=0; $i < $num_fields; $i++)
				{
					echo mysql_real_escape_string($row[$i]);
					if( $i < $num_fields-1)
							echo "$delimiter";
				}
				echo "\n";
			}

		}
	}
	mysql_free_result($result);

}


function _mysqldump($mysql_database)
{
	$sql="show tables;";
	$result= mysql_query($sql);
	if( $result)
	{
		while( $row= mysql_fetch_row($result))
		{
			_mysqldump_table_structure($row[0]);

			if( isset($_REQUEST['sql_table_data']))
			{
				_mysqldump_table_data($row[0]);
			}
		}
	}
	else
	{
		echo "/* no tables in $mysql_database */\n";
	}
	mysql_free_result($result);
}

function _mysqldump_table_structure($table)
{
	echo "/* Table structure for table `$table` */\n";
	if( isset($_REQUEST['sql_drop_table']))
	{
		echo "DROP TABLE IF EXISTS `$table`;\n\n";
	}
	if( isset($_REQUEST['sql_create_table']))
	{

		$sql="show create table `$table`; ";
		$result=mysql_query($sql);
		if( $result)
		{
			if($row= mysql_fetch_assoc($result))
			{
				echo $row['Create Table'].";\n\n";
			}
		}
		mysql_free_result($result);
	}
}

function _mysqldump_table_data($table)
{

	$sql="select * from `$table`;";
	$result=mysql_query($sql);
	if( $result)
	{
		$num_rows= mysql_num_rows($result);
		$num_fields= mysql_num_fields($result);

		if( $num_rows > 0)
		{
			echo "/* dumping data for table `$table` */\n";

			$field_type=array();
			$i=0;
			while( $i < $num_fields)
			{
				$meta= mysql_fetch_field($result, $i);
				array_push($field_type, $meta->type);
				$i++;
			}

			//print_r( $field_type);
			echo "insert into `$table` values\n";
			$index=0;
			while( $row= mysql_fetch_row($result))
			{
				echo "(";
				for( $i=0; $i < $num_fields; $i++)
				{
					if( is_null( $row[$i]))
						echo "null";
					else
					{
						switch( $field_type[$i])
						{
							case 'int':
								echo $row[$i];
								break;
							case 'string':
							case 'blob' :
							default:
								echo "'".mysql_real_escape_string($row[$i])."'";

						}
					}
					if( $i < $num_fields-1)
						echo ",";
				}
				echo ")";

				if( $index < $num_rows-1)
					echo ",";
				else
					echo ";";
				echo "\n";

				$index++;
			}
		}
	}
	mysql_free_result($result);
	echo "\n";
}

function _mysql_test($mysql_host,$mysql_database, $mysql_username, $mysql_password)
{
	global $output_messages;
	$link = mysql_connect($mysql_host, $mysql_username, $mysql_password);
	if (!$link)
	{
	   array_push($output_messages, 'Could not connect: ' . mysql_error());
	}
	else
	{
		array_push ($output_messages,"Connected with MySQL server:$mysql_username@$mysql_host successfully");

		$db_selected = mysql_select_db($mysql_database, $link);
		if (!$db_selected)
		{
			array_push ($output_messages,'Can\'t use $mysql_database : ' . mysql_error());
		}
		else
			array_push ($output_messages,"Connected with MySQL database:$mysql_database successfully");
	}

}

if( $print_form >0 )
{
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
<title>MySQL Database Management - Link Bid Script Admin Panel</title>
<link rel="shortcut icon" href="img/favicon.ico" />
<link rel="stylesheet" type="text/css" href="admin.css" />
<style type="text/css">
<!--
.style84 {color: #FF0000}
#admnav li {
	padding-top: 0px;
	padding-bottom: 0px;
	margin-top: 0px;
	margin-bottom: 0px;
}
#admnav ul {
	padding-top: 0px;
	padding-bottom: 0px;
	margin-top: 0px;
	margin-bottom: 0px;
}
.style86 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
	font-weight: bold;
}
.style87 {color: #009900}
-->
</style>
</head>

<body>
<?php include('header_tpl.php'); ?>
<h2>Manage MySQL Database</h2>
<?php if($output_messages)
{ ?>
<div class="messages">
	<?php foreach ($output_messages as $message)
	{?>
    	<li><?php echo $message; ?></li>
	<?php }
	?>
</div>
<?php } else {} ?>
<table width="770"  border="0" align="center" cellpadding="3" cellspacing="1" bgcolor="#FFFFFF">
  <tr>
    <td width="760" valign="top" bgcolor="#FFFFFF">
<form action="" method="post">
<table border="0" align="center">
  <tr>
    <td nowrap class="style82 style67" style="padding-bottom:7px;" colspan="2"><strong>MySQL connection parameters:</strong></td>
    </tr>
  <tr>
    <td><span class="style80">Host:</span></td>
    <td><input  name="mysql_host" class="edtab" value="<?php echo("$hostname_apound");?>"  /></td>
  </tr>
  <tr>
    <td><span class="style80">Database:</span></td>
    <td><input  name="mysql_database" class="edtab" value="<?php echo("$database_apound");?>"  /></td>
  </tr>
  <tr>
    <td><span class="style80">Username:</span></td>
    <td><input  name="mysql_username" class="edtab" value="<?php echo("$username_apound");?>"  /></td>
  </tr>
  <tr>
    <td><span class="style80">Password:</span></td>
    <td><input  type="password" name="mysql_password" class="edtab" value="<?php echo("$password_apound");?>"  />
      <input name="output_format" type="hidden" value="SQL"></td>
  </tr>
  <tr>
    <td colspan="2" align="left" style="padding-top:7px;"><input type="submit" name="action" class="login-but"  value="Test Connection"></td>
  </tr>
</table></td>
  </tr>
</table>
<table width="770"  border="0" align="center" cellpadding="3" cellspacing="1" bgcolor="#FFFFFF">
  <tr>
    <td width="760" valign="top" bgcolor="#FFFFFF">
  <table width="250px"  border="0" align="center" cellspacing="3" cellpadding="3">
    <tr>
      <td nowrap class="style82 style67" style="padding-bottom:7px;" colspan="2"><strong>Dump options(SQL):</strong></td>
    </tr>
    <tr>
      <td><span class="style80">Drop table statement: </span></td>
      <td><input type="checkbox" name="sql_drop_table" <?php if(isset($_REQUEST['action']) && ! isset($_REQUEST['sql_drop_table'])) ; else echo 'checked' ?> /></td>
    </tr>
    <tr>
      <td><span class="style80">Create table statement: </span></td>
      <td><input type="checkbox" name="sql_create_table" <?php if(isset($_REQUEST['action']) && ! isset($_REQUEST['sql_create_table'])) ; else echo 'checked' ?> /></td>
    </tr>
    <tr>
      <td><span class="style80">Table data: </span></td>
      <td><input type="checkbox" name="sql_table_data"  <?php if(isset($_REQUEST['action']) && ! isset($_REQUEST['sql_table_data'])) ; else echo 'checked' ?>/></td>
  </tr>
  <tr>
    <td colspan="2" align="left" style="padding-top:7px;"><input type="submit" name="action" class="login-but"  value="Export">
</form></td>
  </tr>
</table></td>
  </tr>
</table>

<?php include('footer_tpl.php'); ?>
</body>
</html>

<?php
}
?>
