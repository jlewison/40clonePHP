<?php
$CFG['db']['hostname'] = 'localhost';
$CFG['db']['name'] = 'anova';
$CFG['db']['username'] = 'dbuser';
$CFG['db']['password'] = 'dbpass';
?>