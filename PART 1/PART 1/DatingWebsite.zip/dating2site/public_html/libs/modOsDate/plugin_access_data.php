<?php

   class pluginAccessData extends Data {

      var $table = PLUGIN_ACCESS_TABLE;

      var $config = array (
  'table' => PLUGIN_ACCESS_TABLE,
  'idField' => 'id',
  );   

      function pluginAccessData() {
      
         $this->Data($this->config);
      }
   }

?>
