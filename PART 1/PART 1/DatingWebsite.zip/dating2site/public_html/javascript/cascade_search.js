function cascadeCountry(value) {
    http.open('get', 'cascade_search.php?a=country&v=' + value );
    document.getElementById('srchlookstate_province').innerHTML="&nbsp;&nbsp;"+loadingTag;
    http.onreadystatechange = handleResponse;
    http.send(null);
}

function cascadeState(value,v1) {
    http.open('get', 'cascade_search.php?a=state&v=' + value  + '&v1=' + v1);
	document.getElementById('srchlookcounty').innerHTML="&nbsp;&nbsp;"+loadingTag;

    http.onreadystatechange = handleResponse;
    http.send(null);
}

function cascadeCounty(value,v1,v2) {
    http.open('get', 'cascade_search.php?a=county&v=' + value
					+ '&v1=' + v1 + '&v2=' + v2);
	document.getElementById('srchlookcity').innerHTML="&nbsp;&nbsp;"+loadingTag;

    http.onreadystatechange = handleResponse;
    http.send(null);
}

function cascadeCity(value,v1,v2,v3) {
    http.open('get', 'cascade_search.php?a=city&v=' + value
					+ '&v1=' + v1 + '&v2=' + v2 + '&v3=' + v3);
	document.getElementById('srchlookzip').innerHTML="&nbsp;&nbsp;"+loadingTag;

    http.onreadystatechange = handleResponse;
    http.send(null);
}
