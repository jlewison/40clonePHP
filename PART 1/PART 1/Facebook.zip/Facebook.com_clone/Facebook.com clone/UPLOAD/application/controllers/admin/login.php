<?php

/**
 * Login Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 2007-12-13
 */
class Login extends Controller
{
		//Constructor
		function Login()
		{
				parent::Controller();
				if ($this->session->userdata('admin_logged_in') == 1 && $this->session->userdata('admin_id') != '') redirect('admin/siteInfo');
				//Load the language file
				$this->lang->load('admin/login', $this->config->item('language_code'));
		}
		function index()
		{
				//Load the required model, libraries, plugins.
				$this->load->model('registerModel');
				$this->load->library('validation');
				$this->load->helper('cookie');
				//Set the validation rules
				$this->_loginFrmRules();
				//Do the validation
				if ($this->validation->run() == false)
				{
						//Oops! validation Error.
						$outputData['validationError'] = $this->validation->error_string;
						//Get the e-mail from Cookie if set
						$outputData['admin_name'] = get_cookie('admin_name');
						$this->smartyextended->view('../admin/login', $outputData);
				}
				else
				{
						//Load the user model
						$this->load->model('usermodel');
						$loginStatus = $this->usermodel->adminLogin($this->input->post('admin_name'), $this->input->post('admin_password'));
						if (!is_array($loginStatus))
						{
								//Login failed
								$outputData['validationError'] = $this->lang->line($loginStatus);
								//Get the e-mail from Cookie if set
								$outputData['admin_name'] = get_cookie('admin_name');
								$this->smartyextended->view('../admin/login', $outputData);
						}
						else
						{
								//Set the logged in user details in the session
								$this->session->set_userdata($loginStatus);
								//Set the e-mail in cookie
								if ($this->input->post('rememberme') == 'yes')
								{
										set_cookie('admin_name', $this->input->post('admin_name'), 3600 * 24 * 30); // set the cookie for 1 month
								}
								redirect('admin/siteInfo');
						}
				}
		}
		function _loginFrmRules()
		{
				$rules['admin_name'] = 'trim|required';
				$rules['admin_password'] = 'trim|required';
				$this->validation->set_rules($rules);
				$fields['admin_name'] = $this->lang->line('login_username');
				$fields['admin_password'] = $this->lang->line('login_password');
				$this->validation->set_fields($fields);
		}
}
?>