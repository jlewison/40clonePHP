<?php /* Smarty version 2.6.6, created on 2006-03-11 11:25:35
         compiled from admin/adminheader.tpl */ ?>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" height="18">
          <tr>
            <td width="100%" align="center" colspan="13" height="23">
            <hr color="#3366FF" size="1">
            <font face="Verdana" size="2" color="#333399"><b>Do Changes</b></font></td>
          </tr>
          <tr>
            <td width="100%" align="center" height="1" bgcolor="#003366" colspan="13">
            <img border="0" src="<?php echo $this->_tpl_vars['imgurl']; ?>
/line.JPG" width="650" height="1"></td>
          </tr>
          <tr>
            <td width="2%" align="center" height="14" bgcolor="#003366">
            &nbsp;</td>

            <td width="10%" align="center" height="14" bgcolor="<?php if ($_REQUEST['change'] == 'Personal'): ?>#E5E5E5<?php else: ?>#003366<?php endif; ?>">
            <font size="1" face="Verdana">
            <a style="text-decoration: none" class="link" href="admin_index.php?change=Personal">
            <font color="<?php if ($_REQUEST['change'] == 'Personal'): ?>#003366<?php else: ?>#FFFFF<?php endif; ?>">Personal</font></a></font></td>
            <td width="2%" align="center" height="14" bgcolor="#003366">
            &nbsp;</td>

            <td width="10%" align="center" height="14" bgcolor="<?php if ($_REQUEST['change'] == 'Config'): ?>#E5E5E5<?php else: ?>#003366<?php endif; ?>">
            <font face="Verdana" size="1">
            <a style="text-decoration: none; hover:#00FF00" class="link" href="admin_index.php?change=Config">
            <font color="<?php if ($_REQUEST['change'] == 'Config'): ?>#003366<?php else: ?>#FFFFF<?php endif; ?>">Configuration</font></a></font></td>
            <td width="2%" align="center" height="14" bgcolor="#003366">
            &nbsp;</td>

            <td width="10%" align="center" height="14" bgcolor="<?php if ($_REQUEST['change'] == 'Packages'): ?>#E5E5E5<?php else: ?>#003366<?php endif; ?>">
            <font size="1" face="Verdana">
            <a style="text-decoration: none" class="link" href="admin_index.php?change=Packages">
            <font color="<?php if ($_REQUEST['change'] == 'Packages'): ?>#003366<?php else: ?>#FFFFF<?php endif; ?>">Packages</font></a></font></td>
            <td width="2%" align="center" height="14" bgcolor="#003366">&nbsp;</td>

            <td width="10%" align="center" height="14" bgcolor="<?php if ($_REQUEST['change'] == 'Server'): ?>#E5E5E5<?php else: ?>#003366<?php endif; ?>">
            <font size="1" face="Verdana">
            <a style="text-decoration: none" class="link" href="admin_index.php?change=Server">
            <font color="<?php if ($_REQUEST['change'] == 'Server'): ?>#003366<?php else: ?>#FFFFF<?php endif; ?>">Server</font></a></font></td>
            <td width="2%" align="center" height="14" bgcolor="#003366">&nbsp;</td>

            <td width="10%" align="center" height="14" bgcolor="<?php if ($_REQUEST['change'] == 'FInfo'): ?>#E5E5E5<?php else: ?>#003366<?php endif; ?>">
            <a href="admin_index.php?change=FInfo" style="font-family: Verdana; font-size: 8pt;text-decoration: none">
            <font color="<?php if ($_REQUEST['change'] == 'FInfo'): ?>#003366<?php else: ?>#FFFFFF<?php endif; ?>">File Info</font></a></td>
            <td width="2%" align="center" height="14" bgcolor="#003366">
            &nbsp;</td>

            <td width="10%" align="center" height="14" bgcolor="#003366" style="color: #000000" bordercolor="#003366">
            <font face="Verdana" size="1" color="#FFFFFF">
            <a style="text-decoration: none" href="admin_logout.php">
            <font color="#ffffff">Log<?php if ($_COOKIE['admin_uid']): ?>out<?php else: ?>in<?php endif; ?></font></a></font></td>
            <td width="2%" align="center" height="14" bgcolor="#003366">
            &nbsp;</td>
          </tr>
        </table>