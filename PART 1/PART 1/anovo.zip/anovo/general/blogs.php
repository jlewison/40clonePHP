<?php
class blogList extends ListRecordsHandler
{
		public function storeSearchFields()
		{
				$allowed_fields_arr = array('subject' => $this->fields_arr['subject'], 'uname' => $this->fields_arr['uname'], 'date_added_from_day' => $this->fields_arr['date_added_from_day'], 'date_added_from_month' => $this->fields_arr['date_added_from_month'], 'date_added_from_year' => $this->fields_arr['date_added_from_year'], 'date_added_to_day' => $this->fields_arr['date_added_to_day'], 'date_added_to_month' => $this->fields_arr['date_added_to_month'], 'date_added_to_year' => $this->fields_arr['date_added_to_year']);
				$allowed_fields_arr = serialize($allowed_fields_arr);
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['advanced_search'] . ' SET' . ' blog = ' . $this->dbObj->Param('blog') . ' WHERE' . ' user_id = ' . $this->dbObj->Param('user_id');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($allowed_fields_arr, $this->CFG['user']['user_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function populateSearchFields()
		{
				if ($this->fields_arr['so'] == 'adv')
				{
						$sql = 'SELECT blog FROM ' . $this->CFG['db']['tbl']['advanced_search'] . ' WHERE user_id=' . $this->dbObj->Param('user_id');
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($this->CFG['user']['user_id']));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
						if ($row = $rs->FetchRow())
						{
								if ($row['blog'])
								{
										$search_fields_arr = unserialize($row['blog']);
										$this->fields_arr = array_merge($this->fields_arr, $search_fields_arr);
								}
						}
				}
		}
		public function buildSortQuery()
		{
				$this->sql_sort = $this->fields_arr['orderby_field'] . ' ' . $this->fields_arr['orderby'];
		}
		public function buildConditionQuery()
		{
				$this->sql_condition = 'status=\'Active\'';
				if ($this->getFormField('pg'))
				{
						if ($this->getFormField('pg') == 'newblog')
						{
								$this->setFormField('orderby_field', 'date_added');
								$this->setFormField('orderby', 'DESC');
						}
						if ($this->getFormField('pg') == 'mostviewblog')
						{
								$this->sql_condition .= ' AND total_views > 0';
								$this->setFormField('orderby_field', 'total_views');
								$this->setFormField('orderby', 'DESC');
						}
				}
				if ($this->getFormField('cid'))
				{
						$this->sql_condition .= ' AND blog_category_id = \'' . addslashes($this->getFormField('cid')) . '\'';
				}
				if ($this->CFG['admin']['ignore_user'])
				{
						$this->sql_condition .= ' AND NOT EXISTS (SELECT 1 FROM ' . $this->CFG['db']['tbl']['user_ignored'] . ' AS ui WHERE ui.user_id=' . $this->CFG['user']['user_id'] . ' AND ui.ignored_id=b.user_id)';
				}
				if ($this->fields_arr['search_blog_subject'] && ($this->fields_arr['search_blog_subject'] != $this->LANG['search_for_blog_subject'])) $this->sql_condition .= ' AND ' . getSearchRegularExpressionQuery($this->fields_arr['search_blog_subject'], 'subject');
				if ($this->fields_arr['subject']) $this->sql_condition .= ' AND ' . getSearchRegularExpressionQuery($this->fields_arr['subject'], 'subject');
				if ($this->fields_arr['uname']) $this->sql_condition .= ' AND u.' . $this->getUserTableField('name') . ' LIKE \'' . addslashes($this->fields_arr['uname']) . '%\'';
				if ($this->fields_arr['date_added_from_day']) $this->sql_condition .= ' AND date_added>=\'' . addslashes($this->fields_arr['date_added_from_year'] . '-' . $this->fields_arr['date_added_from_month'] . '-' . $this->fields_arr['date_added_from_day']) . '\'';
				if ($this->fields_arr['date_added_to_day']) $this->sql_condition .= ' AND date_added<=\'' . addslashes($this->fields_arr['date_added_to_year'] . '-' . $this->fields_arr['date_added_to_month'] . '-' . $this->fields_arr['date_added_to_day']) . '\'';
		}
		public function showBlogsList()
		{
				$i = 0;
				while ($row = $this->fetchResultRecord())
				{
						$i++;
						$clsOddOrEvenQuestion = 'clsEvenQuestion';
						if ($i % 2) $clsOddOrEvenQuestion = 'clsOddQuestion';
						$row['date_added'] = ($row['date_added'] != '') ? getTimeDiffernceFormat($row['date_added']) : '';
						$name = $row['name'];
						$message = strip_tags($row['message']);
						$message = (strlen($message) > $this->CFG['admin']['short_description_size']) ? (substr($message, 0, $this->CFG['admin']['short_description_size'] - 1) . ' ..') : ($message);
?>
<div class="<?php echo $clsOddOrEvenQuestion; ?> clsBlogDisplay"><h3><a href="<?php echo getUrl('blogComment.php', 'blogcomment/'); ?>?blog_id=<?php echo $row['blog_id']; ?>"><?php echo wordWrapManual($row['subject'], $this->CFG['admin']['blog']['line_length'], $this->CFG['admin']['blog']['total_length']); ?></a></h3>
<div class="clsUserBlogDetails">
	<?php if (chkUserImageAllowed())
						{ ?>
	<div class="clsBlogUserThumb"><p id="selImageBorder"><?php displayBlogUserSmallImage($row); ?></p></div>
	<?php } ?>
   <div class="clsBlogDetails"> <p> <?php echo wordWrapManual($message, $this->CFG['admin']['blog']['line_length'], $this->CFG['admin']['blog']['total_length']); ?></p></div></div>
	<ul class="clsBlogDisplayLinks">
		<li class="clsLastBlogInfo"><span class="clsBlogInfoTitle"><?php echo $this->LANG['th_posted_by']; ?><?php echo $this->LANG['title_seperator']; ?></span>&nbsp;<a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'myanswers.php?uid=' . $row['user_id'], $this->CFG['site']['relative_url'] . 'my/answers/' . $row['user_id'] . '/', false); ?>"><?php echo stripString($name, $this->CFG['username']['short_length']); ?></a></li>
		<li><span class="clsBlogInfoTitle"><?php echo $this->LANG['th_date_added']; ?><?php echo $this->LANG['title_seperator']; ?></span>&nbsp;<?php echo $row['date_added']; ?></li>
		<li><span class="clsBlogInfoTitle"><?php echo $this->LANG['th_total_views']; ?><?php echo $this->LANG['title_seperator']; ?></span>&nbsp;<?php echo $row['total_views']; ?></li></ul>
        <ul class="clsBlogDisplayLinks">
		<li class="clsLastBlogInfo"><span class="clsBlogInfoTitle"><?php echo $this->LANG['th_total_comments']; ?><?php echo $this->LANG['title_seperator']; ?></span>&nbsp;<?php echo $row['total_comments']; ?></li>
		<li><span class="clsBlogInfoTitle"><?php echo $this->LANG['th_accept_comments']; ?><?php echo $this->LANG['title_seperator']; ?></span>&nbsp;<?php echo $row['accept_comments']; ?></li>
	</ul></div>
<?php
				}
		}
}
$blogList = new blogList();
$blogList->setDBObject($db);
$blogList->makeGlobalize($CFG, $LANG);
if (!chkAllowedModule(array('blog'))) Redirect2URL($CFG['redirect']['dsabled_module_url']);
$blogList->setPageBlockNames(array('form_advanced_search', 'msg_form_success', 'msg_form_error', 'selBlogsListBlock'));
$blogList->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$blogList->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$blogList->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$blogList->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$blogList->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$blogList->setFormField('orderby_field', 'blog_id');
$blogList->setFormField('orderby', 'DESC');
$blogList->setFormField('start', '0');
$blogList->setFormField('pg', '');
$blogList->setFormField('cid', '');
$blogList->setFormField('search_blog_subject', '');
$blogList->setFormField('uname', '');
$blogList->setFormField('subject', '');
$blogList->setFormField('date_added_from', '');
$blogList->setFormField('date_added_from_day', '');
$blogList->setFormField('date_added_from_month', '');
$blogList->setFormField('date_added_from_year', '');
$blogList->setFormField('date_added_to', '');
$blogList->setFormField('date_added_to_day', '');
$blogList->setFormField('date_added_to_month', '');
$blogList->setFormField('date_added_to_year', '');
$blogList->setFormField('adv_search', '');
$blogList->setFormField('so', 'min');
$blogList->setMonthsListArr($LANG_LIST_ARR['months']);
$search_title = $LANG['page_title'];
$blogList->setCSSColumnHeaderCellAscSortClasses(array('clsColumnHeaderCellAscSort1', 'clsColumnHeaderCellAscSort2', 'clsColumnHeaderCellAscSort3', 'clsColumnHeaderCellAscSort4', 'clsColumnHeaderCellAscSort5'));
$blogList->setCSSColumnHeaderCellDefaultClass('clsColumnHeaderCellDefault');
$blogList->setCSSColumnHeaderCellDescSortClasses(array('clsColumnHeaderCellDscSort1', 'clsColumnHeaderCellDscSort2', 'clsColumnHeaderCellDscSort3', 'clsColumnHeaderCellDscSort4', 'clsColumnHeaderCellDscSort5'));
$blogList->setMinRecordSelectLimit(2);
$blogList->setMaxRecordSelectLimit($CFG['data_tbl']['max_record_select_limit']);
$blogList->setNumPerPageListArr($CFG['data_tbl']['numperpage_list_arr']);
$blogList->setTableNames(array($CFG['db']['tbl']['blogs'] . ' AS b LEFT JOIN ' . $CFG['db']['tbl']['users'] . ' AS u ON b.user_id=u.' . $CFG['users']['user_id']));
$blogList->setReturnColumns(array('blog_id', 'subject', 'message', 'accept_comments', 'total_comments', 'total_views', 'b.user_id', 'status', 'TIMEDIFF(NOW(), date_added) as date_added', $blogList->getUserTableFields(array('name')), $blogList->getUserTableField('email'), $blogList->getUserTableField('image_path') . ' AS image_path', $blogList->getUserTableField('gender') . ' AS gender', $blogList->getUserTableField('usr_status'), $blogList->getUserTableField('user_access'), 'u.' . $blogList->getUserTableField('user_id') . ' AS img_user_id', 'u.' . $blogList->getUserTableField('t_height') . ' AS t_height', 'u.' . $blogList->getUserTableField('t_width') . ' AS t_width', 'u.' . $blogList->getUserTableField('s_height') . ' AS s_height', 'u.' . $blogList->getUserTableField('s_width') . ' AS s_width', 'u.' . $blogList->getUserTableField('photo_server_url') . ' AS photo_server_url', 'u.' . $blogList->getUserTableField('photo_ext') . ' AS photo_ext'));
$blogList->setFormField('numpg', $CFG['data_tbl']['numpg']);
$blogList->setPageBlockShow('selBlogsListBlock');
$blogList->sanitizeFormInputs($_REQUEST);
if ($blogList->getFormField('subject') or $blogList->getFormField('search_blog_subject'))
{
		$search_title = '<a href="' . getUrl($CFG['site']['url'] . 'blogs.php', $CFG['site']['url'] . 'blog/', false) . '">Home</a> > ' . $LANG['page_title'];
}
if ($blogList->getFormField('so') == 'adv' and !$blogList->isFormPOSTed($_REQUEST, 'adv_search'))
{
		$blogList->populateSearchFields();
		$blogList->setPageBlockHide('selBlogsListBlock');
		$blogList->setPageBlockShow('form_advanced_search');
}
if ($blogList->isFormGETed($_GET, 'adv_search'))
{
		$blogList->populateSearchFields();
}
if ($blogList->isFormPOSTed($_POST, 'adv_search'))
{
		$blogList->checkIsValidDate('date_added_from_day', 'date_added_from_month', 'date_added_from_year', 'date_added_from', $LANG['invalid_date']);
		$blogList->checkIsValidDate('date_added_to_day', 'date_added_to_month', 'date_added_to_year', 'date_added_to', $LANG['invalid_date']);
		if ($blogList->isValidFormInputs())
		{
				$blogList->storeSearchFields();
		}
		else
		{
				$blogList->setPageBlockHide('selBlogsListBlock');
				$blogList->setPageBlockShow('form_advanced_search');
				$blogList->setPageBlockShow('msg_form_error');
				$blogList->setCommonErrorMsg($LANG['err_msg_invalid_search_option']);
		}
}



?>
<div id="selblogList">
	<div class="clsManageBlogHeading">
		<div class="clsBlogHeading"><h2><?php echo $search_title; ?></h2></div>
		<?php if ($blogList->isMember())
{ ?>
		<div class="clsManageBlog"><span><a href="<?php echo getUrl($CFG['site']['relative_url'] . 'manageBlog.php', $CFG['site']['relative_url'] . 'manageblog/', false) ?>"><?php echo $LANG['manage_blog']; ?></a></span></div>
		<?php } ?>
	</div>
<?php
if ($blogList->isShowPageBlock('msg_form_error'))
{
?>
  	<div id="selMsgError">
   		<p><?php echo $blogList->getCommonErrorMsg(); ?></p>
  	</div>
<?php
}
if ($blogList->isShowPageBlock('msg_form_success'))
{
?>
	<div id="selMsgSuccess">
		<p><?php echo $blogList->getCommonErrorMsg(); ?></p>
	</div>
<?php
}
if ($blogList->isShowPageBlock('form_advanced_search'))
{
?>
<form name="formAdvanceSearch" id="formAdvanceSearch" method="post" action="<?php echo getUrl('blogs.php?so=adv', 'blog/?so=adv'); ?>">
	<div id="moreSearchOptions">
	<table summary="Displaying more search options">
		<tr>
			<td class="<?php echo $blogList->getCSSFormLabelCellClass('subject'); ?>">
				<label for="subject"><?php echo $LANG['search_subject']; ?></label>
			</td>
			<td class="<?php echo $blogList->getCSSFormFieldCellClass('subject'); ?>"><?php echo $blogList->getFormFieldErrorTip('subject'); ?>
				<input type="text" class="clsCommonTextBox" name="subject" id="subject" value="<?php echo $blogList->getFormField('subject'); ?>" tabindex="<?php echo $blogList->getTabIndex(); ?>" />
			</td>
		</tr>
		<tr>
			<td class="<?php echo $blogList->getCSSFormLabelCellClass('uname'); ?>">
				<label for="uname"><?php echo $LANG['search_username']; ?></label>
			</td>
			<td class="<?php echo $blogList->getCSSFormFieldCellClass('uname'); ?>"><?php echo $blogList->getFormFieldErrorTip('uname'); ?>
				<p><input type="text" class="clsCommonTextBox" name="uname" id="uname" value="<?php echo $blogList->getFormField('uname'); ?>" tabindex="<?php echo $blogList->getTabIndex(); ?>" /></p>
			</td>
		</tr>
		<tr>
			<td class="<?php echo $blogList->getCSSFormLabelCellClass('date_added_from'); ?>"><label for="srch_date"><?php echo $LANG['date_added_from_day']; ?></label></td>
			<td class="<?php echo $blogList->getCSSFormFieldCellClass('date_added_from'); ?>"><?php echo $blogList->getFormFieldErrorTip('date_added_from'); ?>
			<select name="date_added_from_day" id="date_added_from_day" tabindex="<?php echo $blogList->getTabIndex(); ?>">
					<option value=""><?php echo 'Date'; ?></option>
					<?php $blogList->populateBWNumbers(1, 31, $blogList->getFormField('date_added_from_day')); ?>
			</select>
			<select name="date_added_from_month" id="date_added_from_month" tabindex="<?php echo $blogList->getTabIndex(); ?>">
					<option value=""><?php echo 'Month'; ?></option>
					<?php $blogList->populateMonthsList($blogList->getFormField('date_added_from_month')); ?>
			</select>
			<select name="date_added_from_year" id="date_added_from_year" tabindex="<?php echo $blogList->getTabIndex(); ?>">
					<option value=""><?php echo 'Year'; ?></option>
					<?php $blogList->populateBWNumbers(1988, date("Y"), $blogList->getFormField('date_added_from_year')); ?>
			</select>
			<input type="hidden" name="date_added_from" id="date_added_from" value="<?php echo $blogList->getFormField('date_added_from'); ?>">
			<input type="hidden" name="date_added_to" id="date_added_to" value="<?php echo $blogList->getFormField('date_added_to'); ?>">
			</td>
		</tr>
		<tr>
			<td class="<?php echo $blogList->getCSSFormLabelCellClass('date_added_to'); ?>"><label for="srch_date"><?php echo $LANG['to']; ?></label></td>
			<td class="<?php echo $blogList->getCSSFormFieldCellClass('date_added_to'); ?>"><?php echo $blogList->getFormFieldErrorTip('date_added_to'); ?>
			<select name="date_added_to_day" id="date_added_to_day" tabindex="<?php echo $blogList->getTabIndex(); ?>">
					<option value=""><?php echo 'Date'; ?></option>
					<?php $blogList->populateBWNumbers(1, 31, $blogList->getFormField('date_added_to_day')); ?>
			</select>
			<select name="date_added_to_month" id="date_added_to_month" tabindex="<?php echo $blogList->getTabIndex(); ?>">
					<option value=""><?php echo 'Month'; ?></option>
					<?php $blogList->populateMonthsList($blogList->getFormField('date_added_to_month')); ?>
			</select>
			<select name="date_added_to_year" id="date_added_to_year" tabindex="<?php echo $blogList->getTabIndex(); ?>">
					<option value=""><?php echo 'Year'; ?></option>
					<?php $blogList->populateBWNumbers(2028, date("Y"), $blogList->getFormField('date_added_to_year')); ?>
			</select>
			</td>
		</tr>
		<tr>
			<td colspan="2" class="<?php echo $blogList->getCSSFormFieldCellClass('submitsearch'); ?>">
				<input type="submit" class="clsSubmitButton" name="adv_search" id="adv_search" value="<?php echo $LANG['search_submit'];
		; ?>" tabindex="<?php echo $blogList->getTabIndex(); ?>" />
			</td>
		</tr>
		</table>
	</div>
</form>
<?php
}
if ($blogList->isShowPageBlock('selBlogsListBlock'))
{
		$blogList->buildSelectQuery();
		$blogList->buildConditionQuery();
		$blogList->buildSortQuery();
		$blogList->buildQuery();
		$blogList->executeQuery();
		if ($blogList->isResultsFound())
		{
?>
			<form name="blogsListForm" id="blogsListForm" method="post" action="<?php echo getUrl('blogs.php', 'blogList/'); ?>" autocomplete="off">
<?php
				$paging_arr = array('pg', 'cid', 'so', 'adv_search');
				if ($blogList->getFormField('search_blog_subject')) $paging_arr[] = 'search_blog_subject';
				if ($blogList->getFormField('subject')) $paging_arr[] = 'subject';
				if ($CFG['admin']['navigation']['top']) $blogList->populatePageLinks($blogList->getFormField('start'), $paging_arr);
?>
			  		<?php $blogList->showBlogsList(); ?>
<?php
				if ($CFG['admin']['navigation']['bottom']) $blogList->populatePageLinks($blogList->getFormField('start'), $paging_arr);
?>
			</form>
<?php
		}
		else
		{
?>
			<div id="selMsgAlert">
				<p><?php echo $LANG['no_records_found']; ?></p>
			</div>
<?php
		}
?>

<?php
}
?>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>