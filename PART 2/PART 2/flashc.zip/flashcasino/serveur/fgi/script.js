function deleteCookie (name, path, domain)
{
	if (getCookie(name))
	{
		document.cookie = name + "=" +
			((path) ? "; path=" + path : "") +
			((domain) ? "; domain=" + domain : "") +
			"; expires=Thu, 01-Jan-70 00:00:01 GMT";
	}
}

function getCookie (name)
{
	var dc = document.cookie;
	var prefix = name + "=";
	var begin = dc.indexOf("; " + prefix);
	if (begin == -1)
	{
		begin = dc.indexOf(prefix);
		if (begin != 0) return null;
	}
	else
		begin += 2;
	var end = document.cookie.indexOf(";", begin);
	if (end == -1)
		end = dc.length;
	return unescape(dc.substring(begin + prefix.length, end));
}

function setCookie (name, value, expires, path, domain, secure)
{
	var curCookie = name + "=" + escape(value) +
		((expires) ? "; expires=" + expires.toGMTString() : "") +
		((path) ? "; path=" + path : "") +
		((domain) ? "; domain=" + domain : "") +
		((secure) ? "; secure" : "");
	document.cookie = curCookie;
}

function loginConvertPassword()
{
	var LoginForm = document.forms['LoginForm'];
	var nonhashed = LoginForm.elements['password'].value
	var hashed = hex_sha1(nonhashed);
	setCookie("hashpassword", hashed);
	//setCookie("unhashedpassword", nonhashed, new Date("January 1, 3000"));
}

function createConvertPassword()
{
	var CreateForm = document.forms['CreateForm'];
	var nonhashed = CreateForm.elements['unhashedpassword'].value
	var hashed = hex_sha1(nonhashed);
	//setCookie("hashpassword", hashed, new Date("January 1, 3000"));
	//setCookie("unhashedpassword", nonhashed, new Date("January 1, 3000"));
}

var flashgood = false;
var plugin = (navigator.mimeTypes && navigator.mimeTypes["application/x-shockwave-flash"]) ? navigator.mimeTypes["application/x-shockwave-flash"].enabledPlugin : 0;
if (plugin)
{
    var versionstring = navigator.plugins["Shockwave Flash"].description.split(" ");
    for (var x = 0; x < versionstring.length; ++x)
    {
        if (isNaN(parseInt(versionstring[x]))) continue;
        flashgood = versionstring[x] >= 8;
    }
}
else if (navigator.userAgent && navigator.userAgent.indexOf("MSIE") >= 0 && (navigator.appVersion.indexOf("Win") != -1))
{
    document.write("<scr" + "ipt language=\"VBScript\">\n");
    document.write("On Error Resume Next\n");
    document.write("flashgood = IsObject(CreateObject(\"ShockwaveFlash.ShockwaveFlash.8\"))\n");
    document.write("</scr" + "ipt>\n");
}
if (!flashgood)
{
    document.write("<h3>Warnings</h3>\n<ul><li>Your computer does not have the minimum required version of Flash installed. Please <a href=\"http://www.macromedia.com/go/getflashplayer\" target=\"_blank\">go here</a> to get the latest version of Flash.</li></ul>");
}