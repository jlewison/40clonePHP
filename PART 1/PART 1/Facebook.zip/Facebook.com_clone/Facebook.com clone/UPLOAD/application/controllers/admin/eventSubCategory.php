<?php
/**
 * Event sub category Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 02/01/2008
 */
class EventSubCategory extends controller
{
		function EventSubCategory()
		{
				parent::controller();
				//check login
				if ($this->session->userdata('admin_logged_in') != 1 && $this->session->userdata('admin_id') == '') redirect('admin/login');
				//Load the language file
				$this->lang->load('admin/eventCategory', $this->config->item('language_code'));
				$this->load->model('eventsmodel');
		}
		function index()
		{
				$this->load->library('validation');
				$this->_eventCategoryFrm();
				$outputData['addEventCategory'] = true;
				$outputData['editEventCategory'] = false;
				$outputData['event_category_id'] = $this->uri->segment(3);
				$outputData['eventsList'] = $this->eventsmodel->getEventMainSubCategory($outputData['event_category_id'], $status = '');
				$outputData['mainEventCategoryName'] = $this->eventsmodel->getEventCategoryName($outputData['event_category_id']);
				if (!empty($outputData['eventsList'])) $outputData['eventsListArr'] = $outputData['eventsList'];
				else  $outputData['eventsListArr'] = false;
				if ($this->validation->run() == false) $outputData['validationError'] = $this->validation->error_string;
				else
				{
						if (isset($_POST['add_event_sub_category']))
						{
								$this->eventsmodel->insertEventSubCategory($_POST, $outputData['event_category_id']);
								//Set the flash data
								$this->session->set_flashdata('successMsg', $this->lang->line('eventcategory_sub_add_success_msg'));
								redirect('admin/eventSubCategory/' . $outputData['event_category_id']);
						}
				}
				$this->smartyextended->view('../admin/eventSubCategory', $outputData);
		}
		function _eventCategoryFrm()
		{
				$rules['event_sub_category_name'] = 'trim|required|alphanumeric';
				$rules['event_sub_category_description'] = 'trim|required|alphanumeric';
				$fields['event_sub_category_name'] = $this->lang->line('eventcategory_sub_category_name');
				$fields['event_sub_category_description'] = $this->lang->line('eventcategory_sub_description');
				$this->validation->set_rules($rules);
				$this->validation->set_fields($fields);
		}
		#***************************************************************************
		#Method			: editEventCategory
		#Description	: updates Event Category
		#Author			
		#***************************************************************************
		function editEventSubCategory()
		{
				$this->load->library('validation');
				$outputData['event_sub_category_id'] = $this->uri->segment(5);
				$outputData['event_category_id'] = $this->uri->segment(4);
				$outputData['addEventCategory'] = false;
				$outputData['editEventCategory'] = true;
				$outputData['eventsList'] = $this->eventsmodel->getEventMainSubCategory($outputData['event_category_id'], $status = '');
				if (!empty($outputData['eventsList'])) $outputData['eventsListArr'] = $outputData['eventsList'];
				else  $outputData['eventsListArr'] = false;
				//echo '<pre>';
				//print_r($outputData['eventsListArr'][$outputData['event_sub_category_id']]);
				//echo '<pre>';
				//print_r($outputData['eventsListArr']); exit();
				//$outputData['events'] = $this->eventsmodel->geteventCategory($status='');
				//echo '<pre>';
				//print_r($outputData['eventsList']); exit();
				$this->_eventCategoryFrm();
				if ($this->validation->run() == false) $outputData['validationError'] = $this->validation->error_string;
				else
				{
						if (isset($_POST['update_event_sub_category']))
						{
								$this->eventsmodel->updateEventSubCategory($_POST);
								//Set the flash data
								$this->session->set_flashdata('successMsg', $this->lang->line('eventcategory_sub_update_success_msg'));
								redirect('admin/eventSubCategory/' . $_POST['event_category_id'] . '');
						}
				}
				$this->smartyextended->view('../admin/eventSubCategory', $outputData);
		}
}
?>