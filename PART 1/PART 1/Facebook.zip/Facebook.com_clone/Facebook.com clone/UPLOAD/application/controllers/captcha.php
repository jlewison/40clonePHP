<?php

/**
 * Generates a new captcha image
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 2007-12-13
 */
class Captcha extends Controller
{
		//Constructor
		function Captcha()
		{
				parent::Controller();
		}
		function index()
		{
				//Load the captcha plugin
				$this->load->plugin('captcha');
				//Create the captcha image
				$randKey = rand();
				$vals = array('word' => $this->_randomPassword(5, $randKey), 'img_path' => BASEPATH . '../application/images/captcha/', 'img_url' => base_url() . 'application/images/captcha/', 'font_path' => BASEPATH . '../application/fonts/verdana.ttf', 'font_size' => 25, 'img_width' => 150, 'img_height' => 30, 'expiration' => 7200);
				$cap = create_captcha($vals);
				echo $cap['word'] . '|' . $cap['time'] . '|' . $randKey;
		}
		function _randomPassword($length = 8, $seed = '')
		{
				$password = "";
				$possible = "0123456789";
				$i = 0;
				mt_srand(($seed == '') ? rand() : $seed);
				while ($i < $length)
				{
						$char = substr($possible, mt_rand(0, strlen($possible) - 1), 1);
						if (!strstr($password, $char))
						{
								$password .= $char;
								$i++;
						}
				}
				return $password;
		}
}
?>