<TD class=fgi_flsh vAlign=top><SPAN class=fgi_gttl>PLAYING FOR 
            FUN</SPAN><BR>
            <TABLE class=fgi_chips cellSpacing=0 cellPadding=0 width="100%" 
            border=0>
              <TBODY>
              <TR>
                <TD class=t><IMG 
                  src="fgi/chips_tl.jpg"></TD>
                <TD class=t align=right><IMG 
                  src="fgi/chips_tr.jpg"></TD></TR>
              
              <TR>
                <TD class=b><IMG 
                  src="fgi/chips_bl.jpg"></TD>
                <TD class=b align=right><IMG 
                  src="fgi/chips_br.jpg"></TD></TR></TBODY></TABLE>