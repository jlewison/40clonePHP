<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); 

/**
* Validation Class that extends the codeIgniter Core Validation Class.
*
*
* @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
* @license
* @since 1/25/2008
*/

class AI_Validation extends CI_Validation
{
	/**
	 * Constructor
	 *
	 */	
	function AI_Validation()
	{	
		parent::CI_Validation();
				
		//Load the language file
		$this->CI->lang->load('libraries/validation', $this->CI->config->item('language_code'));
		
		log_message('debug', "Validation Class Initialized");
	}
	
	/**
	 * Alpha-numeric with underscores, dashes and space
	 *
	 * @access	public
	 * @param	string
	 * @return	bool
	 */	
	function alpha_dash_space($str)
	{
		return ( ! preg_match("/^([-a-z0-9_.-\s])+$/i", $str)) ? FALSE : TRUE;
	}
	
	function valid_url($str)
	{
		// SCHEME
		$urlregex = "^(https?|ftp)\:\/\/";
		
		// USER AND PASS (optional)
		$urlregex .= "([a-z0-9+!*(),;?&=\$_.-]+(\:[a-z0-9+!*(),;?&=\$_.-]+)?@)?";
		
		// HOSTNAME OR IP
		$urlregex .= "[a-z0-9+\$_-]+(\.[a-z0-9+\$_-]+)*";  // http://x = allowed (ex. http://localhost, http://routerlogin)
		//$urlregex .= "[a-z0-9+\$_-]+(\.[a-z0-9+\$_-]+)+";  // http://x.x = minimum
		//$urlregex .= "([a-z0-9+\$_-]+\.)*[a-z0-9+\$_-]{2,3}";  // http://x.xx(x) = minimum
		//use only one of the above
		
		// PORT (optional)
		$urlregex .= "(\:[0-9]{2,5})?";
		
		// PATH  (optional)
		$urlregex .= "(\/([a-z0-9+\$_-]\.?)+)*\/?";
		
		// GET Query (optional)
		$urlregex .= "(\?[a-z+&\$_.-][a-z0-9;:@/&%=+\$_.-]*)?";
		
		// ANCHOR (optional)
		$urlregex .= "(#[a-z_.-][a-z0-9+\$_.-]*)?\$";
		
		// check
		return (eregi($urlregex, $str)) ? TRUE : FALSE;
	}	
}

?>