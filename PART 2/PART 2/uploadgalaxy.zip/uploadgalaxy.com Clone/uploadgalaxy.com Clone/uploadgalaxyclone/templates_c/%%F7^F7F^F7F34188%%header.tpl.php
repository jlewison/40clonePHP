<?php /* Smarty version 2.6.6, created on 2006-07-26 23:20:52
         compiled from header.tpl */ ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<meta http-equiv="Content-Language" content="en-us">
	<title><?php echo '<?='; ?>
$sitename<?php echo '?>'; ?>
</title>
	<meta http-equiv='Content-Type' content='text/html; charset=windows-1252'/>
	<link href='style.css' type='text/css' rel='stylesheet'/>
</head>
<body bgcolor="F2F2F2">














<table border="0" width="600" cellspacing="0" cellpadding="0" height="77">
  <tr>

<center>

    <a href="index.php"><IMG SRC="images/final2.gif" WIDTH=690 HEIGHT=139 ALT="" border="0"></a></TD> 
  </tr>
  <tr>
    <td width="20%" align="center" height="27" valign="bottom">
      <p>
      <a class="link" title="Allow free upload...No registration required." href="index.php">Reward</a></td>
    <td width="20%" align="center" height="27" valign="bottom">
    <a class="link" title="Be registered...Be speedy..." href="premium.php">Premium</a></td>
    <td width="20%" align="center" height="27" valign="bottom">
    <a class="link" href="privacy.php">Privacy Policy</a></td>
    <td width="20%" align="center" height="27" valign="bottom">
    <a class="link" href="terms.php">Terms of Services</a></td>
    <td width="20%" align="center" height="27" valign="bottom">
      <p><a class="link" href="mailto:<?php echo $this->_tpl_vars['ADMIN_MAIL']; ?>
">Contact Us</a></td>
  </tr>
  <tr>
    <td width="100%" align="center" height="21" colspan="5">
            <img border="0" src="images/bottomLine.gif" width="600" height="18">      
    </td>
  </tr>
</table>