<?php

   class instant_messageData extends Data {

      var $table = INSTANT_MESSAGE_TABLE;

      var $config = array (
  'table' => INSTANT_MESSAGE_TABLE,
  'idField' => 'osdate_instant_message_id',
  'addedMsg' => 'Osdate Instant Message %s Added',
  'added_err' => 'Can\\\'t Add Osdate Instant Message',
  'editMsg' => 'Osdate Instant Message %s Updated',
  'editErr' => 'Can\\\'t Update Osdate Instant Message',
  'delErr' => 'Can\\\'t Delete Osdate Instant Message',
  'delMsg' => 'Osdate Instant Message %s Deleted',
  'blankErr' => 'Osdate Instant Message Empty',
  'fields' => 
  array (
    'id' => 
    array (
      'name' => 'id',
      'description' => 'Id',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'senderid' => 
    array (
      'name' => 'senderid',
      'description' => 'Senderid',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 1,
      'duplicate_ok' => 1,
    ),
    'recipientid' => 
    array (
      'name' => 'recipientid',
      'description' => 'Recipientid',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 1,
      'duplicate_ok' => 1,
    ),
    'message' => 
    array (
      'name' => 'message',
      'description' => 'Message',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 65535,
      'blank_ok' => 1,
      'duplicate_ok' => 1,
    ),
    'pingflag' => 
    array (
      'name' => 'pingflag',
      'description' => 'Pingflag',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 1,
      'blank_ok' => 1,
      'duplicate_ok' => 1,
    ),
    'sendtime' => 
    array (
      'name' => 'sendtime',
      'description' => 'Sendtime',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
  ),
);   

      function instant_messageData() {
      
         $this->Data($this->config);
      }
   }

?>
