-- phpMyAdmin SQL Dump
-- version 2.10.0.2
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Aug 19, 2007 at 12:01 AM
-- Server version: 5.0.27
-- PHP Version: 4.4.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `zeeaucti_main`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `zeeauctions_admin`
-- 

CREATE TABLE `zeeauctions_admin` (
  `id` bigint(20) NOT NULL auto_increment,
  `admin_name` varchar(255) default NULL,
  `pwd` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `zeeauctions_admin`
-- 

INSERT INTO `zeeauctions_admin` VALUES (1, 'admin', 'admin');

-- --------------------------------------------------------

-- 
-- Table structure for table `zeeauctions_ads`
-- 

CREATE TABLE `zeeauctions_ads` (
  `id` bigint(20) NOT NULL auto_increment,
  `url` varchar(255) NOT NULL default '',
  `bannerurl` varchar(255) NOT NULL default '',
  `adv_id` bigint(20) NOT NULL default '0',
  `credits` bigint(20) NOT NULL default '0',
  `displays` bigint(20) NOT NULL default '0',
  `paid` varchar(255) NOT NULL default '',
  `approved` varchar(255) NOT NULL default '',
  `clicks` bigint(20) default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `zeeauctions_ads`
-- 

INSERT INTO `zeeauctions_ads` VALUES (1, 'http://www.zeescripts.com', 'http://www.zeescripts.com/images/banner_468x60.gif', 0, 10000000, 100000000000, 'yes', 'yes', 0);
INSERT INTO `zeeauctions_ads` VALUES (2, 'http://www.zeescripts.com/main/home.php', 'http://www.zeescripts.com/images/banner_468x60.gif', 1, 10000000, 10001, 'yes', 'yes', 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `zeeauctions_advertisers`
-- 

CREATE TABLE `zeeauctions_advertisers` (
  `id` bigint(20) NOT NULL auto_increment,
  `uname` varchar(255) default NULL,
  `email` varchar(255) default NULL,
  `pwd` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `zeeauctions_advertisers`
-- 

INSERT INTO `zeeauctions_advertisers` VALUES (1, 'syed', 'zeescripts@gmail.com', 'tiger786');

-- --------------------------------------------------------

-- 
-- Table structure for table `zeeauctions_adv_transactions`
-- 

CREATE TABLE `zeeauctions_adv_transactions` (
  `id` bigint(20) NOT NULL auto_increment,
  `description` varchar(255) default NULL,
  `amount` decimal(10,2) default NULL,
  `adv_id` bigint(20) default NULL,
  `date_submitted` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `zeeauctions_adv_transactions`
-- 

INSERT INTO `zeeauctions_adv_transactions` VALUES (1, 'bonus', '10000000.00', 1, '2007-08-18 11:58:55');
INSERT INTO `zeeauctions_adv_transactions` VALUES (2, 'Banner Posting Charges', '-36.00', 1, '2007-08-18 11:59:32');

-- --------------------------------------------------------

-- 
-- Table structure for table `zeeauctions_auction_types`
-- 

CREATE TABLE `zeeauctions_auction_types` (
  `id` bigint(20) NOT NULL auto_increment,
  `auction_name` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

-- 
-- Dumping data for table `zeeauctions_auction_types`
-- 

INSERT INTO `zeeauctions_auction_types` VALUES (3, 'fixed');
INSERT INTO `zeeauctions_auction_types` VALUES (2, 'dutch');
INSERT INTO `zeeauctions_auction_types` VALUES (1, 'auction');
INSERT INTO `zeeauctions_auction_types` VALUES (4, 'classified');

-- --------------------------------------------------------

-- 
-- Table structure for table `zeeauctions_banners`
-- 

CREATE TABLE `zeeauctions_banners` (
  `id` bigint(20) NOT NULL auto_increment,
  `img_url` varchar(255) default NULL,
  `banner_link` varchar(255) default NULL,
  `width` int(11) default NULL,
  `height` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `zeeauctions_banners`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `zeeauctions_bids`
-- 

CREATE TABLE `zeeauctions_bids` (
  `id` bigint(20) NOT NULL auto_increment,
  `pid` bigint(20) default NULL,
  `amount` decimal(10,2) default NULL,
  `uid` bigint(20) default NULL,
  `date_submitted` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `notify_me` varchar(255) default 'no',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `zeeauctions_bids`
-- 

INSERT INTO `zeeauctions_bids` VALUES (1, 3, '199.00', 2, '2007-08-18 23:45:33', 'no');

-- --------------------------------------------------------

-- 
-- Table structure for table `zeeauctions_blocked`
-- 

CREATE TABLE `zeeauctions_blocked` (
  `id` bigint(20) NOT NULL auto_increment,
  `uid` bigint(20) default NULL,
  `blocked_user` bigint(20) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `zeeauctions_blocked`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `zeeauctions_categories`
-- 

CREATE TABLE `zeeauctions_categories` (
  `id` bigint(20) NOT NULL auto_increment,
  `cat_name` varchar(255) default NULL,
  `pid` bigint(20) default NULL,
  `clicks` bigint(20) default NULL,
  `order_index` bigint(20) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=589 ;

-- 
-- Dumping data for table `zeeauctions_categories`
-- 

INSERT INTO `zeeauctions_categories` VALUES (30, 'Maps, Atlases, Globes', 22, NULL, 12);
INSERT INTO `zeeauctions_categories` VALUES (28, 'Ethnographic', 22, NULL, 10);
INSERT INTO `zeeauctions_categories` VALUES (29, 'Furniture', 22, NULL, 11);
INSERT INTO `zeeauctions_categories` VALUES (25, 'Asian Antiques', 22, NULL, 7);
INSERT INTO `zeeauctions_categories` VALUES (26, 'Books, Manuscripts', 22, NULL, 8);
INSERT INTO `zeeauctions_categories` VALUES (27, 'Decorative Arts', 22, NULL, 9);
INSERT INTO `zeeauctions_categories` VALUES (23, 'Antiquities (Classical, Amer.)', 22, NULL, 5);
INSERT INTO `zeeauctions_categories` VALUES (22, 'Antiques', 0, NULL, 4);
INSERT INTO `zeeauctions_categories` VALUES (24, 'Architectural & Garden', 22, NULL, 6);
INSERT INTO `zeeauctions_categories` VALUES (31, 'Maritime', 22, NULL, 13);
INSERT INTO `zeeauctions_categories` VALUES (32, 'Musical Instruments', 22, NULL, 14);
INSERT INTO `zeeauctions_categories` VALUES (33, 'Periods, Styles', 22, NULL, 15);
INSERT INTO `zeeauctions_categories` VALUES (34, 'Primitives', 22, NULL, 16);
INSERT INTO `zeeauctions_categories` VALUES (35, 'Reproduction Antiques', 22, NULL, 17);
INSERT INTO `zeeauctions_categories` VALUES (36, 'Rugs, Carpets', 22, NULL, 18);
INSERT INTO `zeeauctions_categories` VALUES (37, 'Silver', 22, NULL, 19);
INSERT INTO `zeeauctions_categories` VALUES (38, 'Science & Medicine', 22, NULL, 20);
INSERT INTO `zeeauctions_categories` VALUES (39, 'Textiles, Linens', 22, NULL, 21);
INSERT INTO `zeeauctions_categories` VALUES (40, 'Other Antiques', 22, NULL, 22);
INSERT INTO `zeeauctions_categories` VALUES (41, 'Art', 0, NULL, 23);
INSERT INTO `zeeauctions_categories` VALUES (42, 'Digital Art', 41, NULL, 24);
INSERT INTO `zeeauctions_categories` VALUES (43, 'Drawings', 41, NULL, 25);
INSERT INTO `zeeauctions_categories` VALUES (44, 'Folk Art', 41, NULL, 26);
INSERT INTO `zeeauctions_categories` VALUES (45, 'Mixed Media', 41, NULL, 27);
INSERT INTO `zeeauctions_categories` VALUES (46, 'Paintings', 41, NULL, 28);
INSERT INTO `zeeauctions_categories` VALUES (47, 'Photographic Images', 41, NULL, 29);
INSERT INTO `zeeauctions_categories` VALUES (48, 'Posters', 41, NULL, 30);
INSERT INTO `zeeauctions_categories` VALUES (49, 'Prints', 41, NULL, 31);
INSERT INTO `zeeauctions_categories` VALUES (50, 'Sculpture, Carvings', 41, NULL, 32);
INSERT INTO `zeeauctions_categories` VALUES (51, 'Self-Representing Artists', 41, NULL, 33);
INSERT INTO `zeeauctions_categories` VALUES (52, 'Self-Representing ACEOs', 41, NULL, 34);
INSERT INTO `zeeauctions_categories` VALUES (53, 'Other Art', 41, NULL, 35);
INSERT INTO `zeeauctions_categories` VALUES (54, 'Wholesale Lots', 41, NULL, 36);
INSERT INTO `zeeauctions_categories` VALUES (55, 'Paintings', 54, NULL, 37);
INSERT INTO `zeeauctions_categories` VALUES (56, 'Photographic Images', 54, NULL, 38);
INSERT INTO `zeeauctions_categories` VALUES (57, 'Prints', 54, NULL, 39);
INSERT INTO `zeeauctions_categories` VALUES (58, 'Posters', 54, NULL, 40);
INSERT INTO `zeeauctions_categories` VALUES (59, 'Other', 54, NULL, 41);
INSERT INTO `zeeauctions_categories` VALUES (60, 'Baby', 0, NULL, 42);
INSERT INTO `zeeauctions_categories` VALUES (61, 'Baby Gear', 60, NULL, 43);
INSERT INTO `zeeauctions_categories` VALUES (62, 'Baby Safety & Health', 60, NULL, 44);
INSERT INTO `zeeauctions_categories` VALUES (63, 'Bathing & Grooming', 60, NULL, 45);
INSERT INTO `zeeauctions_categories` VALUES (64, 'Car Safety Seats', 60, NULL, 46);
INSERT INTO `zeeauctions_categories` VALUES (65, 'Diapering', 60, NULL, 47);
INSERT INTO `zeeauctions_categories` VALUES (66, 'Feeding', 60, NULL, 48);
INSERT INTO `zeeauctions_categories` VALUES (67, 'Keepsakes & Baby Announcements', 60, NULL, 49);
INSERT INTO `zeeauctions_categories` VALUES (68, 'Nursery Bedding', 60, NULL, 50);
INSERT INTO `zeeauctions_categories` VALUES (69, 'Nursery Décor', 60, NULL, 51);
INSERT INTO `zeeauctions_categories` VALUES (70, 'Nursery Furniture', 60, NULL, 52);
INSERT INTO `zeeauctions_categories` VALUES (71, 'Potty Training', 60, NULL, 53);
INSERT INTO `zeeauctions_categories` VALUES (72, 'Strollers', 60, NULL, 54);
INSERT INTO `zeeauctions_categories` VALUES (73, 'Toys', 60, NULL, 55);
INSERT INTO `zeeauctions_categories` VALUES (74, 'Other Baby Items', 60, NULL, 56);
INSERT INTO `zeeauctions_categories` VALUES (75, 'Baby Wholesale Lots', 60, NULL, 57);
INSERT INTO `zeeauctions_categories` VALUES (76, 'Books', 0, NULL, 58);
INSERT INTO `zeeauctions_categories` VALUES (78, 'Accessories', 76, NULL, 59);
INSERT INTO `zeeauctions_categories` VALUES (79, 'Antiquarian & Collectible', 76, NULL, 60);
INSERT INTO `zeeauctions_categories` VALUES (80, 'Audiobooks', 76, NULL, 61);
INSERT INTO `zeeauctions_categories` VALUES (81, 'Catalogs', 76, NULL, 62);
INSERT INTO `zeeauctions_categories` VALUES (82, 'Children''s Books', 76, NULL, 63);
INSERT INTO `zeeauctions_categories` VALUES (83, 'Comics', 76, NULL, 64);
INSERT INTO `zeeauctions_categories` VALUES (84, 'Cookbooks', 76, NULL, 65);
INSERT INTO `zeeauctions_categories` VALUES (85, 'Fiction Books', 76, NULL, 66);
INSERT INTO `zeeauctions_categories` VALUES (86, 'Magazine Back Issues', 76, NULL, 67);
INSERT INTO `zeeauctions_categories` VALUES (87, 'Magazine Subscriptions', 76, NULL, 68);
INSERT INTO `zeeauctions_categories` VALUES (88, 'Nonfiction Books', 76, NULL, 69);
INSERT INTO `zeeauctions_categories` VALUES (89, 'Textbooks, Education', 76, NULL, 70);
INSERT INTO `zeeauctions_categories` VALUES (90, 'Wholesale, Bulk Lots', 76, NULL, 71);
INSERT INTO `zeeauctions_categories` VALUES (91, 'Other', 76, NULL, 72);
INSERT INTO `zeeauctions_categories` VALUES (92, 'Business & Industrial', 0, NULL, 73);
INSERT INTO `zeeauctions_categories` VALUES (93, 'Agriculture & Forestry', 92, NULL, 74);
INSERT INTO `zeeauctions_categories` VALUES (94, 'Construction', 92, NULL, 75);
INSERT INTO `zeeauctions_categories` VALUES (95, 'Food Service & Retail', 92, NULL, 76);
INSERT INTO `zeeauctions_categories` VALUES (96, 'Healthcare, Lab & Life Science', 92, NULL, 77);
INSERT INTO `zeeauctions_categories` VALUES (97, 'Industrial Electrical & Test', 92, NULL, 78);
INSERT INTO `zeeauctions_categories` VALUES (98, 'Industrial Supply, MRO', 92, NULL, 79);
INSERT INTO `zeeauctions_categories` VALUES (99, 'Manufacturing & Metalworking', 92, NULL, 80);
INSERT INTO `zeeauctions_categories` VALUES (100, 'Office, Printing & Shipping', 92, NULL, 81);
INSERT INTO `zeeauctions_categories` VALUES (101, 'Other Industries', 92, NULL, 82);
INSERT INTO `zeeauctions_categories` VALUES (102, 'Cameras & Photo', 0, NULL, 83);
INSERT INTO `zeeauctions_categories` VALUES (103, 'Bags, Cases & Straps', 102, NULL, 84);
INSERT INTO `zeeauctions_categories` VALUES (104, 'Binoculars & Telescopes', 102, NULL, 85);
INSERT INTO `zeeauctions_categories` VALUES (105, 'Camcorder Accessories', 102, NULL, 86);
INSERT INTO `zeeauctions_categories` VALUES (106, 'Camcorders', 102, NULL, 87);
INSERT INTO `zeeauctions_categories` VALUES (107, 'Digital Camera Accessories', 102, NULL, 88);
INSERT INTO `zeeauctions_categories` VALUES (108, 'Digital Cameras', 102, NULL, 89);
INSERT INTO `zeeauctions_categories` VALUES (109, 'Film', 102, NULL, 90);
INSERT INTO `zeeauctions_categories` VALUES (110, 'Film Camera Accessories', 102, NULL, 91);
INSERT INTO `zeeauctions_categories` VALUES (111, 'Film Cameras', 102, NULL, 92);
INSERT INTO `zeeauctions_categories` VALUES (112, 'Film Processing & Darkroom', 102, NULL, 93);
INSERT INTO `zeeauctions_categories` VALUES (113, 'Flashes & Accessories', 102, NULL, 94);
INSERT INTO `zeeauctions_categories` VALUES (114, 'Lenses & Filters', 102, NULL, 95);
INSERT INTO `zeeauctions_categories` VALUES (115, 'Lighting & Studio Equipment', 102, NULL, 96);
INSERT INTO `zeeauctions_categories` VALUES (116, 'Manuals, Guides & Books', 102, NULL, 97);
INSERT INTO `zeeauctions_categories` VALUES (117, 'Photo Albums & Archive Items', 102, NULL, 98);
INSERT INTO `zeeauctions_categories` VALUES (118, 'Printers, Scanners & Supplies', 102, NULL, 99);
INSERT INTO `zeeauctions_categories` VALUES (119, 'Professional Video Equipment', 102, NULL, 100);
INSERT INTO `zeeauctions_categories` VALUES (120, 'Projection Equipment', 102, NULL, 101);
INSERT INTO `zeeauctions_categories` VALUES (121, 'Stock Photography & Footage', 102, NULL, 102);
INSERT INTO `zeeauctions_categories` VALUES (122, 'Tripods, Monopods', 102, NULL, 103);
INSERT INTO `zeeauctions_categories` VALUES (123, 'Vintage', 102, NULL, 104);
INSERT INTO `zeeauctions_categories` VALUES (124, 'Wholesale Lots', 102, NULL, 105);
INSERT INTO `zeeauctions_categories` VALUES (125, 'Cars, Vehicles & Parts', 0, NULL, 106);
INSERT INTO `zeeauctions_categories` VALUES (126, 'Cars & Trucks', 125, NULL, 107);
INSERT INTO `zeeauctions_categories` VALUES (127, 'Parts & Accessories', 125, NULL, 108);
INSERT INTO `zeeauctions_categories` VALUES (128, 'Motorcycles', 125, NULL, 109);
INSERT INTO `zeeauctions_categories` VALUES (129, 'Powersports', 125, NULL, 110);
INSERT INTO `zeeauctions_categories` VALUES (130, 'Boats', 125, NULL, 111);
INSERT INTO `zeeauctions_categories` VALUES (131, 'Other Vehicles', 125, NULL, 112);
INSERT INTO `zeeauctions_categories` VALUES (132, 'Cell Phones & PDAs', 0, NULL, 113);
INSERT INTO `zeeauctions_categories` VALUES (133, 'Accessories, Parts', 132, NULL, 114);
INSERT INTO `zeeauctions_categories` VALUES (134, 'Bluetooth Wireless Accessories', 132, NULL, 115);
INSERT INTO `zeeauctions_categories` VALUES (135, 'Cell Phones', 132, NULL, 116);
INSERT INTO `zeeauctions_categories` VALUES (136, 'Headsets - Wireless', 132, NULL, 117);
INSERT INTO `zeeauctions_categories` VALUES (137, 'PDAs & Pocket PCs', 132, NULL, 118);
INSERT INTO `zeeauctions_categories` VALUES (138, 'Phone & SIM Cards', 132, NULL, 119);
INSERT INTO `zeeauctions_categories` VALUES (139, 'Wholesale & Large Lots', 132, NULL, 120);
INSERT INTO `zeeauctions_categories` VALUES (141, 'Clothing, Shoes & All', 0, NULL, 121);
INSERT INTO `zeeauctions_categories` VALUES (142, 'Dancewear & Dance Shoes', 141, NULL, 122);
INSERT INTO `zeeauctions_categories` VALUES (143, 'Infants & Toddlers', 141, NULL, 123);
INSERT INTO `zeeauctions_categories` VALUES (144, 'Boys', 141, NULL, 124);
INSERT INTO `zeeauctions_categories` VALUES (145, 'Girls', 141, NULL, 125);
INSERT INTO `zeeauctions_categories` VALUES (146, 'Men''s Accessories', 141, NULL, 126);
INSERT INTO `zeeauctions_categories` VALUES (147, 'Men''s Accessories', 141, NULL, 127);
INSERT INTO `zeeauctions_categories` VALUES (148, 'Men''s Clothing', 141, NULL, 128);
INSERT INTO `zeeauctions_categories` VALUES (149, 'Men''s Shoes', 141, NULL, 129);
INSERT INTO `zeeauctions_categories` VALUES (150, 'Uniforms', 141, NULL, 130);
INSERT INTO `zeeauctions_categories` VALUES (151, 'Wedding Apparel', 141, NULL, 131);
INSERT INTO `zeeauctions_categories` VALUES (152, 'Women''s Accessories, Handbags', 141, NULL, 132);
INSERT INTO `zeeauctions_categories` VALUES (153, 'Women''s Clothing', 141, NULL, 133);
INSERT INTO `zeeauctions_categories` VALUES (154, 'Women''s Shoes', 141, NULL, 134);
INSERT INTO `zeeauctions_categories` VALUES (155, 'Vintage', 141, NULL, 135);
INSERT INTO `zeeauctions_categories` VALUES (156, 'Wholesale, Large & Small Lots', 141, NULL, 136);
INSERT INTO `zeeauctions_categories` VALUES (157, 'Coins & Paper Money', 0, NULL, 137);
INSERT INTO `zeeauctions_categories` VALUES (158, 'Coins: World', 157, NULL, 138);
INSERT INTO `zeeauctions_categories` VALUES (159, 'Bullion', 157, NULL, 139);
INSERT INTO `zeeauctions_categories` VALUES (160, 'Coins: Ancient', 157, NULL, 140);
INSERT INTO `zeeauctions_categories` VALUES (161, 'Exonumia', 157, NULL, 141);
INSERT INTO `zeeauctions_categories` VALUES (162, 'Paper Money: World', 157, NULL, 142);
INSERT INTO `zeeauctions_categories` VALUES (163, 'Publications & Supplies', 157, NULL, 143);
INSERT INTO `zeeauctions_categories` VALUES (164, 'Scripophily', 157, NULL, 144);
INSERT INTO `zeeauctions_categories` VALUES (165, 'Collectibles', 0, NULL, 145);
INSERT INTO `zeeauctions_categories` VALUES (166, 'Advertising', 165, NULL, 146);
INSERT INTO `zeeauctions_categories` VALUES (167, 'Animals', 165, NULL, 147);
INSERT INTO `zeeauctions_categories` VALUES (168, 'Animation Art, Characters', 165, NULL, 148);
INSERT INTO `zeeauctions_categories` VALUES (169, 'Arcade, Jukeboxes & Pinball', 165, NULL, 149);
INSERT INTO `zeeauctions_categories` VALUES (170, 'Autographs', 165, NULL, 150);
INSERT INTO `zeeauctions_categories` VALUES (171, 'Banks, Registers & Vending', 165, NULL, 151);
INSERT INTO `zeeauctions_categories` VALUES (172, 'Barware', 165, NULL, 152);
INSERT INTO `zeeauctions_categories` VALUES (173, 'Bottles & Insulators', 165, NULL, 153);
INSERT INTO `zeeauctions_categories` VALUES (174, 'Breweriana, Beer', 165, NULL, 154);
INSERT INTO `zeeauctions_categories` VALUES (175, 'Casino', 165, NULL, 155);
INSERT INTO `zeeauctions_categories` VALUES (176, 'Clocks', 165, NULL, 156);
INSERT INTO `zeeauctions_categories` VALUES (177, 'Comics', 165, NULL, 157);
INSERT INTO `zeeauctions_categories` VALUES (178, 'Cultures, Ethnicities', 165, NULL, 158);
INSERT INTO `zeeauctions_categories` VALUES (179, 'Decorative Collectibles', 165, NULL, 159);
INSERT INTO `zeeauctions_categories` VALUES (180, 'Fantasy, Mythical & Magic', 165, NULL, 160);
INSERT INTO `zeeauctions_categories` VALUES (181, 'Historical Memorabilia', 165, NULL, 161);
INSERT INTO `zeeauctions_categories` VALUES (182, 'Holiday, Seasonal', 165, NULL, 162);
INSERT INTO `zeeauctions_categories` VALUES (183, 'Housewares & Kitchenware', 165, NULL, 163);
INSERT INTO `zeeauctions_categories` VALUES (184, 'Knives, Swords & Blades', 165, NULL, 164);
INSERT INTO `zeeauctions_categories` VALUES (185, 'Lamps, Lighting', 165, NULL, 165);
INSERT INTO `zeeauctions_categories` VALUES (186, 'Linens, Fabric & Textiles', 165, NULL, 166);
INSERT INTO `zeeauctions_categories` VALUES (187, 'Metalware', 165, NULL, 167);
INSERT INTO `zeeauctions_categories` VALUES (188, 'Militaria', 165, NULL, 168);
INSERT INTO `zeeauctions_categories` VALUES (189, 'Pens & Writing Instruments', 165, NULL, 169);
INSERT INTO `zeeauctions_categories` VALUES (190, 'Pez, Keychains, Promo Glasses', 165, NULL, 170);
INSERT INTO `zeeauctions_categories` VALUES (191, 'Photographic Images', 165, NULL, 171);
INSERT INTO `zeeauctions_categories` VALUES (192, 'Pinbacks, Nodders, Lunchboxes', 165, NULL, 172);
INSERT INTO `zeeauctions_categories` VALUES (193, 'Postcards & Paper', 165, NULL, 173);
INSERT INTO `zeeauctions_categories` VALUES (194, 'Radio, Phonograph, TV, Phone', 165, NULL, 174);
INSERT INTO `zeeauctions_categories` VALUES (195, 'Religions, Spirituality', 165, NULL, 175);
INSERT INTO `zeeauctions_categories` VALUES (196, 'Rocks, Fossils, Minerals', 165, NULL, 176);
INSERT INTO `zeeauctions_categories` VALUES (197, 'Science Fiction', 165, NULL, 177);
INSERT INTO `zeeauctions_categories` VALUES (198, 'Science, Medical', 165, NULL, 178);
INSERT INTO `zeeauctions_categories` VALUES (199, 'Tobacciana', 165, NULL, 179);
INSERT INTO `zeeauctions_categories` VALUES (200, 'Tools, Hardware & Locks', 165, NULL, 180);
INSERT INTO `zeeauctions_categories` VALUES (201, 'Trading Cards', 165, NULL, 181);
INSERT INTO `zeeauctions_categories` VALUES (202, 'Transportation', 165, NULL, 182);
INSERT INTO `zeeauctions_categories` VALUES (203, 'Vanity, Perfume & Shaving', 165, NULL, 183);
INSERT INTO `zeeauctions_categories` VALUES (204, 'Vintage Sewing', 165, NULL, 184);
INSERT INTO `zeeauctions_categories` VALUES (205, 'Wholesale Lots', 165, NULL, 185);
INSERT INTO `zeeauctions_categories` VALUES (206, 'Computers & Networking', 0, NULL, 186);
INSERT INTO `zeeauctions_categories` VALUES (207, 'Apple, Macintosh Computers', 206, NULL, 187);
INSERT INTO `zeeauctions_categories` VALUES (208, 'Desktop PCs', 206, NULL, 188);
INSERT INTO `zeeauctions_categories` VALUES (209, 'Laptops, Notebooks', 206, NULL, 189);
INSERT INTO `zeeauctions_categories` VALUES (210, 'Monitors & Projectors', 206, NULL, 190);
INSERT INTO `zeeauctions_categories` VALUES (211, 'Desktop & Laptop Components', 206, NULL, 191);
INSERT INTO `zeeauctions_categories` VALUES (212, 'Drives, Controllers & Storage', 206, NULL, 192);
INSERT INTO `zeeauctions_categories` VALUES (213, 'Networking', 206, NULL, 193);
INSERT INTO `zeeauctions_categories` VALUES (214, 'Printers', 206, NULL, 194);
INSERT INTO `zeeauctions_categories` VALUES (215, 'Printer Supplies & Accessories', 206, NULL, 195);
INSERT INTO `zeeauctions_categories` VALUES (216, 'Scanners', 206, NULL, 196);
INSERT INTO `zeeauctions_categories` VALUES (217, 'Servers', 206, NULL, 197);
INSERT INTO `zeeauctions_categories` VALUES (218, 'Technology Books', 206, NULL, 198);
INSERT INTO `zeeauctions_categories` VALUES (219, 'Vintage Computing Products', 206, NULL, 199);
INSERT INTO `zeeauctions_categories` VALUES (220, 'Other Hardware & Services', 206, NULL, 200);
INSERT INTO `zeeauctions_categories` VALUES (221, 'Consumer Electronics', 0, NULL, 201);
INSERT INTO `zeeauctions_categories` VALUES (222, 'Apple iPod, MP3 Players', 221, NULL, 202);
INSERT INTO `zeeauctions_categories` VALUES (223, 'A/V Accessories & Cables', 221, NULL, 203);
INSERT INTO `zeeauctions_categories` VALUES (224, 'Batteries & Chargers', 221, NULL, 204);
INSERT INTO `zeeauctions_categories` VALUES (225, 'Car Electronics', 221, NULL, 205);
INSERT INTO `zeeauctions_categories` VALUES (226, 'DVD & Home Theater', 221, NULL, 206);
INSERT INTO `zeeauctions_categories` VALUES (227, 'Gadgets & Other Electronics', 221, NULL, 207);
INSERT INTO `zeeauctions_categories` VALUES (228, 'GPS Devices', 221, NULL, 208);
INSERT INTO `zeeauctions_categories` VALUES (229, 'Home Audio', 221, NULL, 209);
INSERT INTO `zeeauctions_categories` VALUES (230, 'MP3 Accessories', 221, NULL, 210);
INSERT INTO `zeeauctions_categories` VALUES (231, 'Portable Audio/Video', 221, NULL, 211);
INSERT INTO `zeeauctions_categories` VALUES (232, 'Radios: CB, Ham & Shortwave', 221, NULL, 212);
INSERT INTO `zeeauctions_categories` VALUES (233, 'Satellite Radio', 221, NULL, 213);
INSERT INTO `zeeauctions_categories` VALUES (234, 'Satellite, Cable TV', 221, NULL, 214);
INSERT INTO `zeeauctions_categories` VALUES (235, 'Telephones & Pagers', 221, NULL, 215);
INSERT INTO `zeeauctions_categories` VALUES (236, 'Televisions', 221, NULL, 216);
INSERT INTO `zeeauctions_categories` VALUES (237, 'Vintage Electronics', 221, NULL, 217);
INSERT INTO `zeeauctions_categories` VALUES (238, 'Wholesale Lots', 221, NULL, 218);
INSERT INTO `zeeauctions_categories` VALUES (239, 'Crafts', 0, NULL, 219);
INSERT INTO `zeeauctions_categories` VALUES (240, 'Bead Art', 239, NULL, 220);
INSERT INTO `zeeauctions_categories` VALUES (241, 'Candle & Soap Making', 239, NULL, 221);
INSERT INTO `zeeauctions_categories` VALUES (242, 'Ceramics, Pottery', 239, NULL, 222);
INSERT INTO `zeeauctions_categories` VALUES (243, 'Crocheting', 239, NULL, 223);
INSERT INTO `zeeauctions_categories` VALUES (244, 'Cross Stitch', 239, NULL, 224);
INSERT INTO `zeeauctions_categories` VALUES (245, 'Decorative, Tole Painting', 239, NULL, 225);
INSERT INTO `zeeauctions_categories` VALUES (246, 'Drawing', 239, NULL, 226);
INSERT INTO `zeeauctions_categories` VALUES (247, 'Embroidery', 239, NULL, 227);
INSERT INTO `zeeauctions_categories` VALUES (248, 'Fabric', 239, NULL, 228);
INSERT INTO `zeeauctions_categories` VALUES (249, 'Fabric Embellishments', 239, NULL, 229);
INSERT INTO `zeeauctions_categories` VALUES (250, 'Floral Crafts', 239, NULL, 230);
INSERT INTO `zeeauctions_categories` VALUES (251, 'Framing & Matting', 239, NULL, 231);
INSERT INTO `zeeauctions_categories` VALUES (252, 'General Art & Craft Supplies', 239, NULL, 232);
INSERT INTO `zeeauctions_categories` VALUES (253, 'Glass Art Crafts', 239, NULL, 233);
INSERT INTO `zeeauctions_categories` VALUES (254, 'Handcrafted Items', 239, NULL, 234);
INSERT INTO `zeeauctions_categories` VALUES (255, 'Kids Crafts', 239, NULL, 235);
INSERT INTO `zeeauctions_categories` VALUES (256, 'Knitting', 239, NULL, 236);
INSERT INTO `zeeauctions_categories` VALUES (257, 'Latch Rug Hooking', 239, NULL, 237);
INSERT INTO `zeeauctions_categories` VALUES (258, 'Leathercraft', 239, NULL, 238);
INSERT INTO `zeeauctions_categories` VALUES (259, 'Macramé', 239, NULL, 239);
INSERT INTO `zeeauctions_categories` VALUES (260, 'Metalworking', 239, NULL, 240);
INSERT INTO `zeeauctions_categories` VALUES (261, 'Needlepoint', 239, NULL, 241);
INSERT INTO `zeeauctions_categories` VALUES (262, 'Painting', 239, NULL, 242);
INSERT INTO `zeeauctions_categories` VALUES (263, 'Quilting', 239, NULL, 243);
INSERT INTO `zeeauctions_categories` VALUES (264, 'Ribbon', 239, NULL, 244);
INSERT INTO `zeeauctions_categories` VALUES (265, 'Rubber Stamping & Embossing', 239, NULL, 245);
INSERT INTO `zeeauctions_categories` VALUES (266, 'Scrapbooking', 239, NULL, 246);
INSERT INTO `zeeauctions_categories` VALUES (267, 'Sewing', 239, NULL, 247);
INSERT INTO `zeeauctions_categories` VALUES (268, 'Shellcraft', 239, NULL, 248);
INSERT INTO `zeeauctions_categories` VALUES (269, 'Spinning', 239, NULL, 249);
INSERT INTO `zeeauctions_categories` VALUES (270, 'Upholstery', 239, NULL, 250);
INSERT INTO `zeeauctions_categories` VALUES (271, 'Weaving', 239, NULL, 251);
INSERT INTO `zeeauctions_categories` VALUES (272, 'Woodworking', 239, NULL, 252);
INSERT INTO `zeeauctions_categories` VALUES (273, 'Yarn', 239, NULL, 253);
INSERT INTO `zeeauctions_categories` VALUES (274, 'Wall Décor, Tatouage', 239, NULL, 254);
INSERT INTO `zeeauctions_categories` VALUES (275, 'Other Arts & Crafts', 239, NULL, 255);
INSERT INTO `zeeauctions_categories` VALUES (276, 'Wholesale Lots', 239, NULL, 256);
INSERT INTO `zeeauctions_categories` VALUES (277, 'Dolls & Bears', 0, NULL, 257);
INSERT INTO `zeeauctions_categories` VALUES (278, 'Bear Making Supplies', 277, NULL, 258);
INSERT INTO `zeeauctions_categories` VALUES (279, 'Bears', 277, NULL, 259);
INSERT INTO `zeeauctions_categories` VALUES (280, 'Dolls', 277, NULL, 260);
INSERT INTO `zeeauctions_categories` VALUES (281, 'Dollhouse Miniatures', 277, NULL, 261);
INSERT INTO `zeeauctions_categories` VALUES (282, 'Paper Dolls', 277, NULL, 262);
INSERT INTO `zeeauctions_categories` VALUES (283, 'Wholesale Lots', 277, NULL, 263);
INSERT INTO `zeeauctions_categories` VALUES (285, 'Domain names', 0, NULL, 264);
INSERT INTO `zeeauctions_categories` VALUES (286, '2 Letter / Character', 285, NULL, 265);
INSERT INTO `zeeauctions_categories` VALUES (287, '.com', 286, NULL, 266);
INSERT INTO `zeeauctions_categories` VALUES (288, '.net', 286, NULL, 267);
INSERT INTO `zeeauctions_categories` VALUES (289, '.org', 286, NULL, 268);
INSERT INTO `zeeauctions_categories` VALUES (290, '.biz', 286, NULL, 269);
INSERT INTO `zeeauctions_categories` VALUES (291, '.us', 286, NULL, 270);
INSERT INTO `zeeauctions_categories` VALUES (292, '.cc', 286, NULL, 271);
INSERT INTO `zeeauctions_categories` VALUES (293, 'other', 286, NULL, 272);
INSERT INTO `zeeauctions_categories` VALUES (294, '3 Letter / Character', 285, NULL, 273);
INSERT INTO `zeeauctions_categories` VALUES (295, '.com', 294, NULL, 274);
INSERT INTO `zeeauctions_categories` VALUES (296, '.net', 294, NULL, 275);
INSERT INTO `zeeauctions_categories` VALUES (297, '.org', 294, NULL, 276);
INSERT INTO `zeeauctions_categories` VALUES (298, '.biz', 294, NULL, 277);
INSERT INTO `zeeauctions_categories` VALUES (299, '.us', 294, NULL, 278);
INSERT INTO `zeeauctions_categories` VALUES (300, 'other', 294, NULL, 279);
INSERT INTO `zeeauctions_categories` VALUES (301, '.cc', 294, NULL, 280);
INSERT INTO `zeeauctions_categories` VALUES (302, '4 Letter / Character', 285, NULL, 281);
INSERT INTO `zeeauctions_categories` VALUES (303, '.com', 302, NULL, 282);
INSERT INTO `zeeauctions_categories` VALUES (304, '.net', 302, NULL, 283);
INSERT INTO `zeeauctions_categories` VALUES (305, '.org', 302, NULL, 284);
INSERT INTO `zeeauctions_categories` VALUES (306, 'other', 302, NULL, 285);
INSERT INTO `zeeauctions_categories` VALUES (307, 'One Word', 285, NULL, 286);
INSERT INTO `zeeauctions_categories` VALUES (308, 'Dictionary', 285, NULL, 287);
INSERT INTO `zeeauctions_categories` VALUES (309, 'Other', 285, NULL, 288);
INSERT INTO `zeeauctions_categories` VALUES (310, 'Ebooks', 0, NULL, 289);
INSERT INTO `zeeauctions_categories` VALUES (311, 'Architecture & Design', 310, NULL, 290);
INSERT INTO `zeeauctions_categories` VALUES (312, 'Art & Photography', 310, NULL, 291);
INSERT INTO `zeeauctions_categories` VALUES (313, 'Biography & Memoir', 310, NULL, 292);
INSERT INTO `zeeauctions_categories` VALUES (314, 'Books on Collecting', 310, NULL, 293);
INSERT INTO `zeeauctions_categories` VALUES (315, 'Business & Economy', 310, NULL, 294);
INSERT INTO `zeeauctions_categories` VALUES (316, 'Computers & Internet', 310, NULL, 295);
INSERT INTO `zeeauctions_categories` VALUES (317, 'Cooking, Food, Wine', 310, NULL, 296);
INSERT INTO `zeeauctions_categories` VALUES (318, 'Family, Relationship', 310, NULL, 297);
INSERT INTO `zeeauctions_categories` VALUES (319, 'Health & Fitness', 310, NULL, 298);
INSERT INTO `zeeauctions_categories` VALUES (320, 'History', 310, NULL, 299);
INSERT INTO `zeeauctions_categories` VALUES (321, 'Hobbies & Crafts', 310, NULL, 300);
INSERT INTO `zeeauctions_categories` VALUES (322, 'Home & Garden', 310, NULL, 301);
INSERT INTO `zeeauctions_categories` VALUES (323, 'Humor', 310, NULL, 302);
INSERT INTO `zeeauctions_categories` VALUES (324, 'Law & Government', 310, NULL, 303);
INSERT INTO `zeeauctions_categories` VALUES (325, 'Medical', 310, NULL, 304);
INSERT INTO `zeeauctions_categories` VALUES (326, 'Anatomy', 325, NULL, 305);
INSERT INTO `zeeauctions_categories` VALUES (327, 'Physiology', 325, NULL, 306);
INSERT INTO `zeeauctions_categories` VALUES (328, 'Biochemistry', 325, NULL, 307);
INSERT INTO `zeeauctions_categories` VALUES (329, 'Microbiology', 325, NULL, 308);
INSERT INTO `zeeauctions_categories` VALUES (330, 'Pathology', 325, NULL, 309);
INSERT INTO `zeeauctions_categories` VALUES (331, 'Forensic', 325, NULL, 310);
INSERT INTO `zeeauctions_categories` VALUES (332, 'Preventive Medicine', 325, NULL, 311);
INSERT INTO `zeeauctions_categories` VALUES (333, 'Ophthalmology', 325, NULL, 312);
INSERT INTO `zeeauctions_categories` VALUES (334, 'ENT', 325, NULL, 313);
INSERT INTO `zeeauctions_categories` VALUES (335, 'Orthopaedics', 325, NULL, 314);
INSERT INTO `zeeauctions_categories` VALUES (336, 'Paediatrics', 325, NULL, 315);
INSERT INTO `zeeauctions_categories` VALUES (337, 'General Medicine', 325, NULL, 316);
INSERT INTO `zeeauctions_categories` VALUES (338, 'General Surgery', 325, NULL, 317);
INSERT INTO `zeeauctions_categories` VALUES (339, 'Obstetrics & Gynaecology', 325, NULL, 318);
INSERT INTO `zeeauctions_categories` VALUES (340, 'Cardiology', 325, NULL, 319);
INSERT INTO `zeeauctions_categories` VALUES (341, 'Oncology', 325, NULL, 320);
INSERT INTO `zeeauctions_categories` VALUES (342, 'Gastroenterology', 325, NULL, 321);
INSERT INTO `zeeauctions_categories` VALUES (343, 'Nephrology', 325, NULL, 322);
INSERT INTO `zeeauctions_categories` VALUES (344, 'Other', 325, NULL, 323);
INSERT INTO `zeeauctions_categories` VALUES (345, 'Military & War', 310, NULL, 324);
INSERT INTO `zeeauctions_categories` VALUES (346, 'Outdoor, Nature', 310, NULL, 325);
INSERT INTO `zeeauctions_categories` VALUES (347, 'Paranormal, Meta.', 310, NULL, 326);
INSERT INTO `zeeauctions_categories` VALUES (348, 'Performing Arts', 310, NULL, 327);
INSERT INTO `zeeauctions_categories` VALUES (349, 'Pet, Animal Care', 310, NULL, 328);
INSERT INTO `zeeauctions_categories` VALUES (350, 'Philosophy', 310, NULL, 329);
INSERT INTO `zeeauctions_categories` VALUES (351, 'Psychology', 310, NULL, 330);
INSERT INTO `zeeauctions_categories` VALUES (352, 'Psychiatry', 325, NULL, 331);
INSERT INTO `zeeauctions_categories` VALUES (353, 'Reference', 310, NULL, 332);
INSERT INTO `zeeauctions_categories` VALUES (354, 'Religion', 310, NULL, 333);
INSERT INTO `zeeauctions_categories` VALUES (355, 'Science & Tech', 310, NULL, 334);
INSERT INTO `zeeauctions_categories` VALUES (356, 'Self-Help', 310, NULL, 335);
INSERT INTO `zeeauctions_categories` VALUES (357, 'Social Sciences', 310, NULL, 336);
INSERT INTO `zeeauctions_categories` VALUES (358, 'Sports, Recreation', 310, NULL, 337);
INSERT INTO `zeeauctions_categories` VALUES (359, 'Tutorials, Lessons, Guides', 310, NULL, 338);
INSERT INTO `zeeauctions_categories` VALUES (360, 'Transportation', 310, NULL, 339);
INSERT INTO `zeeauctions_categories` VALUES (361, 'Travel, Geography, Exploration', 310, NULL, 340);
INSERT INTO `zeeauctions_categories` VALUES (362, 'True Crime', 310, NULL, 341);
INSERT INTO `zeeauctions_categories` VALUES (363, 'Other', 310, NULL, 342);
INSERT INTO `zeeauctions_categories` VALUES (364, 'Radiology', 325, NULL, 343);
INSERT INTO `zeeauctions_categories` VALUES (365, 'Engineering', 310, NULL, 344);
INSERT INTO `zeeauctions_categories` VALUES (366, 'English, Grammar', 310, NULL, 345);
INSERT INTO `zeeauctions_categories` VALUES (367, 'Geography', 310, NULL, 346);
INSERT INTO `zeeauctions_categories` VALUES (368, 'Language Study', 310, NULL, 347);
INSERT INTO `zeeauctions_categories` VALUES (369, 'Mathematics', 310, NULL, 348);
INSERT INTO `zeeauctions_categories` VALUES (370, 'Test Prep, Study Aid', 310, NULL, 349);
INSERT INTO `zeeauctions_categories` VALUES (371, 'Pharmacology', 325, NULL, 350);
INSERT INTO `zeeauctions_categories` VALUES (372, 'Entertainment Memorabilia', 0, NULL, 351);
INSERT INTO `zeeauctions_categories` VALUES (373, 'Autographs-Original', 372, NULL, 352);
INSERT INTO `zeeauctions_categories` VALUES (374, 'Autographs-Reprints', 372, NULL, 353);
INSERT INTO `zeeauctions_categories` VALUES (375, 'Movie Memorabilia', 372, NULL, 354);
INSERT INTO `zeeauctions_categories` VALUES (376, 'Music Memorabilia', 372, NULL, 355);
INSERT INTO `zeeauctions_categories` VALUES (377, 'Television Memorabilia', 372, NULL, 356);
INSERT INTO `zeeauctions_categories` VALUES (378, 'Theater Memorabilia', 372, NULL, 357);
INSERT INTO `zeeauctions_categories` VALUES (379, 'Video Game Memorabilia', 372, NULL, 358);
INSERT INTO `zeeauctions_categories` VALUES (380, 'Other Memorabilia', 372, NULL, 359);
INSERT INTO `zeeauctions_categories` VALUES (382, 'Gift Certificates, Coupons', 0, NULL, 360);
INSERT INTO `zeeauctions_categories` VALUES (383, 'Health & Beauty', 0, NULL, 361);
INSERT INTO `zeeauctions_categories` VALUES (384, 'Bath & Body', 383, NULL, 362);
INSERT INTO `zeeauctions_categories` VALUES (385, 'Dietary Supplements, Nutrition', 383, NULL, 363);
INSERT INTO `zeeauctions_categories` VALUES (386, 'Fragrances', 383, NULL, 364);
INSERT INTO `zeeauctions_categories` VALUES (387, 'Hair Care', 383, NULL, 365);
INSERT INTO `zeeauctions_categories` VALUES (388, 'Hair Removal', 383, NULL, 366);
INSERT INTO `zeeauctions_categories` VALUES (389, 'Health Care', 383, NULL, 367);
INSERT INTO `zeeauctions_categories` VALUES (390, 'Makeup', 383, NULL, 368);
INSERT INTO `zeeauctions_categories` VALUES (391, 'Nail', 383, NULL, 369);
INSERT INTO `zeeauctions_categories` VALUES (392, 'Massage', 383, NULL, 370);
INSERT INTO `zeeauctions_categories` VALUES (393, 'Medical, Special Needs', 383, NULL, 371);
INSERT INTO `zeeauctions_categories` VALUES (394, 'Natural Therapies', 383, NULL, 372);
INSERT INTO `zeeauctions_categories` VALUES (395, 'Oral Care', 383, NULL, 373);
INSERT INTO `zeeauctions_categories` VALUES (396, 'Over-the-Counter Medicine', 383, NULL, 374);
INSERT INTO `zeeauctions_categories` VALUES (397, 'Skin Care', 383, NULL, 375);
INSERT INTO `zeeauctions_categories` VALUES (398, 'Tanning Beds, Lamps', 383, NULL, 376);
INSERT INTO `zeeauctions_categories` VALUES (399, 'Tattoos, Body Art', 383, NULL, 377);
INSERT INTO `zeeauctions_categories` VALUES (400, 'Eye Care', 383, NULL, 378);
INSERT INTO `zeeauctions_categories` VALUES (401, 'Weight Management', 383, NULL, 379);
INSERT INTO `zeeauctions_categories` VALUES (402, 'Wholesale Lots', 383, NULL, 380);
INSERT INTO `zeeauctions_categories` VALUES (403, 'Other', 383, NULL, 381);
INSERT INTO `zeeauctions_categories` VALUES (404, 'Home & Garden', 0, NULL, 382);
INSERT INTO `zeeauctions_categories` VALUES (405, 'Bath', 404, NULL, 383);
INSERT INTO `zeeauctions_categories` VALUES (406, 'Bedding', 404, NULL, 384);
INSERT INTO `zeeauctions_categories` VALUES (407, 'Building & Hardware', 404, NULL, 385);
INSERT INTO `zeeauctions_categories` VALUES (408, 'Dining & Bar', 404, NULL, 386);
INSERT INTO `zeeauctions_categories` VALUES (409, 'Electrical & Solar', 404, NULL, 387);
INSERT INTO `zeeauctions_categories` VALUES (410, 'Food & Wine', 404, NULL, 388);
INSERT INTO `zeeauctions_categories` VALUES (411, 'Furniture', 404, NULL, 389);
INSERT INTO `zeeauctions_categories` VALUES (412, 'Gardening & Plants', 404, NULL, 390);
INSERT INTO `zeeauctions_categories` VALUES (413, 'Heating, Cooling & Air', 404, NULL, 391);
INSERT INTO `zeeauctions_categories` VALUES (414, 'Home Décor', 404, NULL, 392);
INSERT INTO `zeeauctions_categories` VALUES (415, 'Home Security', 404, NULL, 393);
INSERT INTO `zeeauctions_categories` VALUES (416, 'Kitchen', 404, NULL, 394);
INSERT INTO `zeeauctions_categories` VALUES (417, 'Lamps, Lighting, Ceiling Fans', 404, NULL, 395);
INSERT INTO `zeeauctions_categories` VALUES (418, 'Major Appliances', 404, NULL, 396);
INSERT INTO `zeeauctions_categories` VALUES (419, 'Outdoor Power Equipment', 404, NULL, 397);
INSERT INTO `zeeauctions_categories` VALUES (420, 'Patio & Grilling', 404, NULL, 398);
INSERT INTO `zeeauctions_categories` VALUES (421, 'Pet Supplies', 404, NULL, 399);
INSERT INTO `zeeauctions_categories` VALUES (422, 'Plumbing & Fixtures', 404, NULL, 400);
INSERT INTO `zeeauctions_categories` VALUES (423, 'Pools & Spas', 404, NULL, 401);
INSERT INTO `zeeauctions_categories` VALUES (424, 'Rugs & Carpets', 404, NULL, 402);
INSERT INTO `zeeauctions_categories` VALUES (425, 'Tools', 404, NULL, 403);
INSERT INTO `zeeauctions_categories` VALUES (426, 'Vacuum Cleaners & Housekeeping', 404, NULL, 404);
INSERT INTO `zeeauctions_categories` VALUES (427, 'Window Treatments', 404, NULL, 405);
INSERT INTO `zeeauctions_categories` VALUES (428, 'Wholesale Lots', 404, NULL, 406);
INSERT INTO `zeeauctions_categories` VALUES (429, 'Jewelry & Watches', 0, NULL, 407);
INSERT INTO `zeeauctions_categories` VALUES (430, 'Body Jewelry', 429, NULL, 408);
INSERT INTO `zeeauctions_categories` VALUES (431, 'Bracelets', 429, NULL, 409);
INSERT INTO `zeeauctions_categories` VALUES (432, 'Children''s Jewelry', 429, NULL, 410);
INSERT INTO `zeeauctions_categories` VALUES (433, 'Earrings', 429, NULL, 411);
INSERT INTO `zeeauctions_categories` VALUES (434, 'Ethnic, Tribal ', 429, NULL, 412);
INSERT INTO `zeeauctions_categories` VALUES (435, 'Hair Jewelry', 429, NULL, 413);
INSERT INTO `zeeauctions_categories` VALUES (436, 'Handcrafted, Artisan', 429, NULL, 414);
INSERT INTO `zeeauctions_categories` VALUES (437, 'Jewelry Boxes & Supplies', 429, NULL, 415);
INSERT INTO `zeeauctions_categories` VALUES (438, 'Jewellery Sets', 429, NULL, 416);
INSERT INTO `zeeauctions_categories` VALUES (439, 'Loose Beads', 429, NULL, 417);
INSERT INTO `zeeauctions_categories` VALUES (440, 'Loose Diamonds & Gemstones', 429, NULL, 418);
INSERT INTO `zeeauctions_categories` VALUES (441, 'Men''s Jewelry', 429, NULL, 419);
INSERT INTO `zeeauctions_categories` VALUES (442, 'Necklaces & Pendants', 429, NULL, 420);
INSERT INTO `zeeauctions_categories` VALUES (443, 'Pins, Brooches', 429, NULL, 421);
INSERT INTO `zeeauctions_categories` VALUES (444, 'Rings', 429, NULL, 422);
INSERT INTO `zeeauctions_categories` VALUES (445, 'Watches', 429, NULL, 423);
INSERT INTO `zeeauctions_categories` VALUES (446, 'Wholesale Lots', 429, NULL, 424);
INSERT INTO `zeeauctions_categories` VALUES (447, 'Other Items', 429, NULL, 425);
INSERT INTO `zeeauctions_categories` VALUES (448, 'Movies, DVD, VCD, VHS', 0, NULL, 426);
INSERT INTO `zeeauctions_categories` VALUES (449, 'International', 448, NULL, 427);
INSERT INTO `zeeauctions_categories` VALUES (450, 'Indian', 448, NULL, 428);
INSERT INTO `zeeauctions_categories` VALUES (451, 'Others', 448, NULL, 429);
INSERT INTO `zeeauctions_categories` VALUES (452, 'Wholesale Lots', 448, NULL, 430);
INSERT INTO `zeeauctions_categories` VALUES (453, 'Action, Adventure', 449, NULL, 431);
INSERT INTO `zeeauctions_categories` VALUES (454, 'Animation', 449, NULL, 432);
INSERT INTO `zeeauctions_categories` VALUES (455, 'Anime & Manga', 449, NULL, 433);
INSERT INTO `zeeauctions_categories` VALUES (456, 'Children & Family', 449, NULL, 434);
INSERT INTO `zeeauctions_categories` VALUES (457, 'Comedy', 449, NULL, 435);
INSERT INTO `zeeauctions_categories` VALUES (458, 'Concert & Music', 449, NULL, 436);
INSERT INTO `zeeauctions_categories` VALUES (459, 'Documentary', 449, NULL, 437);
INSERT INTO `zeeauctions_categories` VALUES (460, 'Drama', 449, NULL, 438);
INSERT INTO `zeeauctions_categories` VALUES (461, 'Educational', 449, NULL, 439);
INSERT INTO `zeeauctions_categories` VALUES (462, 'Exercise & Fitness', 449, NULL, 440);
INSERT INTO `zeeauctions_categories` VALUES (463, 'Foreign', 449, NULL, 441);
INSERT INTO `zeeauctions_categories` VALUES (464, 'Horror', 449, NULL, 442);
INSERT INTO `zeeauctions_categories` VALUES (465, 'Musicals', 449, NULL, 443);
INSERT INTO `zeeauctions_categories` VALUES (466, 'Sci-Fi, Fantasy', 449, NULL, 444);
INSERT INTO `zeeauctions_categories` VALUES (467, 'Sports', 449, NULL, 445);
INSERT INTO `zeeauctions_categories` VALUES (468, 'TV Shows', 449, NULL, 446);
INSERT INTO `zeeauctions_categories` VALUES (469, 'Other', 449, NULL, 447);
INSERT INTO `zeeauctions_categories` VALUES (470, 'Action, Adventure', 450, NULL, 448);
INSERT INTO `zeeauctions_categories` VALUES (471, 'Animation', 450, NULL, 449);
INSERT INTO `zeeauctions_categories` VALUES (472, 'Children & Family', 450, NULL, 450);
INSERT INTO `zeeauctions_categories` VALUES (473, 'Comedy', 450, NULL, 451);
INSERT INTO `zeeauctions_categories` VALUES (474, 'Concert & Music', 450, NULL, 452);
INSERT INTO `zeeauctions_categories` VALUES (475, 'Documentary', 450, NULL, 453);
INSERT INTO `zeeauctions_categories` VALUES (476, 'Drama', 450, NULL, 454);
INSERT INTO `zeeauctions_categories` VALUES (477, 'Educational', 450, NULL, 455);
INSERT INTO `zeeauctions_categories` VALUES (478, 'Family', 450, NULL, 456);
INSERT INTO `zeeauctions_categories` VALUES (479, 'Horror', 450, NULL, 457);
INSERT INTO `zeeauctions_categories` VALUES (480, 'Musicals', 450, NULL, 458);
INSERT INTO `zeeauctions_categories` VALUES (481, 'Mythology', 450, NULL, 459);
INSERT INTO `zeeauctions_categories` VALUES (482, 'Romantic', 450, NULL, 460);
INSERT INTO `zeeauctions_categories` VALUES (483, 'TV Shows', 450, NULL, 461);
INSERT INTO `zeeauctions_categories` VALUES (484, 'Other', 450, NULL, 462);
INSERT INTO `zeeauctions_categories` VALUES (485, 'Romantic', 449, NULL, 463);
INSERT INTO `zeeauctions_categories` VALUES (486, 'Music', 0, NULL, 464);
INSERT INTO `zeeauctions_categories` VALUES (487, 'Accessories', 486, NULL, 465);
INSERT INTO `zeeauctions_categories` VALUES (488, 'Cassettes', 486, NULL, 466);
INSERT INTO `zeeauctions_categories` VALUES (489, 'CDs', 486, NULL, 467);
INSERT INTO `zeeauctions_categories` VALUES (490, 'Digital Music Downloads', 486, NULL, 468);
INSERT INTO `zeeauctions_categories` VALUES (491, 'DVD Audio', 486, NULL, 469);
INSERT INTO `zeeauctions_categories` VALUES (492, 'Records', 486, NULL, 470);
INSERT INTO `zeeauctions_categories` VALUES (493, 'MP3 CDs', 486, NULL, 471);
INSERT INTO `zeeauctions_categories` VALUES (494, 'Super Audio CDs', 486, NULL, 472);
INSERT INTO `zeeauctions_categories` VALUES (495, 'Other Formats', 486, NULL, 473);
INSERT INTO `zeeauctions_categories` VALUES (496, 'Wholesale Lots', 486, NULL, 474);
INSERT INTO `zeeauctions_categories` VALUES (497, 'Musical Instruments', 0, NULL, 475);
INSERT INTO `zeeauctions_categories` VALUES (498, 'Brass', 497, NULL, 476);
INSERT INTO `zeeauctions_categories` VALUES (499, 'DJ Gear & Lighting', 497, NULL, 477);
INSERT INTO `zeeauctions_categories` VALUES (500, 'Electronic', 497, NULL, 478);
INSERT INTO `zeeauctions_categories` VALUES (501, 'Equipment', 497, NULL, 479);
INSERT INTO `zeeauctions_categories` VALUES (502, 'Guitar', 497, NULL, 480);
INSERT INTO `zeeauctions_categories` VALUES (503, 'Harmonica', 497, NULL, 481);
INSERT INTO `zeeauctions_categories` VALUES (504, 'Instruction Books, CDs, Videos', 497, NULL, 482);
INSERT INTO `zeeauctions_categories` VALUES (505, 'Keyboard, Piano', 497, NULL, 483);
INSERT INTO `zeeauctions_categories` VALUES (506, 'Percussion', 497, NULL, 484);
INSERT INTO `zeeauctions_categories` VALUES (507, 'Pro Audio', 497, NULL, 485);
INSERT INTO `zeeauctions_categories` VALUES (508, 'Sheet Music, Song Books', 497, NULL, 486);
INSERT INTO `zeeauctions_categories` VALUES (509, 'String', 497, NULL, 487);
INSERT INTO `zeeauctions_categories` VALUES (510, 'Woodwind', 497, NULL, 488);
INSERT INTO `zeeauctions_categories` VALUES (511, 'Wholesale Lots', 497, NULL, 489);
INSERT INTO `zeeauctions_categories` VALUES (512, 'Other Instruments', 497, NULL, 490);
INSERT INTO `zeeauctions_categories` VALUES (513, 'Pottery & Glass', 0, NULL, 491);
INSERT INTO `zeeauctions_categories` VALUES (514, 'Real Estate', 0, NULL, 492);
INSERT INTO `zeeauctions_categories` VALUES (515, 'Software', 0, NULL, 493);
INSERT INTO `zeeauctions_categories` VALUES (516, 'Antivirus, Security, Utilities', 515, NULL, 494);
INSERT INTO `zeeauctions_categories` VALUES (517, 'Apple, Macintosh Software', 515, NULL, 495);
INSERT INTO `zeeauctions_categories` VALUES (518, 'Business & Productivity', 515, NULL, 496);
INSERT INTO `zeeauctions_categories` VALUES (519, 'Database & Development Tools', 515, NULL, 497);
INSERT INTO `zeeauctions_categories` VALUES (520, 'Digital Music & Video Software', 515, NULL, 498);
INSERT INTO `zeeauctions_categories` VALUES (521, 'Downloadable Software', 515, NULL, 499);
INSERT INTO `zeeauctions_categories` VALUES (522, 'Education & Reference', 515, NULL, 500);
INSERT INTO `zeeauctions_categories` VALUES (523, 'Games & Entertainment', 515, NULL, 501);
INSERT INTO `zeeauctions_categories` VALUES (524, 'Graphics, Photo & Publishing', 515, NULL, 502);
INSERT INTO `zeeauctions_categories` VALUES (525, 'Handheld Software', 515, NULL, 503);
INSERT INTO `zeeauctions_categories` VALUES (526, 'Internet  Utilities', 515, NULL, 504);
INSERT INTO `zeeauctions_categories` VALUES (527, 'Kids'' Software', 515, NULL, 505);
INSERT INTO `zeeauctions_categories` VALUES (528, 'Networking', 515, NULL, 506);
INSERT INTO `zeeauctions_categories` VALUES (529, 'Operating Systems', 515, NULL, 507);
INSERT INTO `zeeauctions_categories` VALUES (530, 'Other Software', 515, NULL, 508);
INSERT INTO `zeeauctions_categories` VALUES (531, 'Wholesale Lots', 515, NULL, 509);
INSERT INTO `zeeauctions_categories` VALUES (532, 'Work At Home', 310, NULL, 510);
INSERT INTO `zeeauctions_categories` VALUES (533, 'Websites & Templates', 515, NULL, 511);
INSERT INTO `zeeauctions_categories` VALUES (534, 'Web Design', 515, NULL, 512);
INSERT INTO `zeeauctions_categories` VALUES (535, 'Web Hosting', 515, NULL, 513);
INSERT INTO `zeeauctions_categories` VALUES (536, 'Sporting Goods', 0, NULL, 514);
INSERT INTO `zeeauctions_categories` VALUES (537, 'Apparel', 536, NULL, 515);
INSERT INTO `zeeauctions_categories` VALUES (538, 'Footwear', 536, NULL, 516);
INSERT INTO `zeeauctions_categories` VALUES (539, 'Cycling', 536, NULL, 517);
INSERT INTO `zeeauctions_categories` VALUES (540, 'Equestrian', 536, NULL, 518);
INSERT INTO `zeeauctions_categories` VALUES (541, 'Exercise & Fitness', 536, NULL, 519);
INSERT INTO `zeeauctions_categories` VALUES (542, 'Wholesale Lots', 536, NULL, 520);
INSERT INTO `zeeauctions_categories` VALUES (543, 'Others', 536, NULL, 521);
INSERT INTO `zeeauctions_categories` VALUES (544, 'Stamps', 165, NULL, 522);
INSERT INTO `zeeauctions_categories` VALUES (545, 'Toys & Hobbies', 0, NULL, 523);
INSERT INTO `zeeauctions_categories` VALUES (546, 'Action Figures', 545, NULL, 524);
INSERT INTO `zeeauctions_categories` VALUES (547, 'Beanbag Plush, Beanie Babies', 545, NULL, 525);
INSERT INTO `zeeauctions_categories` VALUES (548, 'Building Toys', 545, NULL, 526);
INSERT INTO `zeeauctions_categories` VALUES (549, 'Toy Vehicles', 545, NULL, 527);
INSERT INTO `zeeauctions_categories` VALUES (550, 'Educational', 545, NULL, 528);
INSERT INTO `zeeauctions_categories` VALUES (551, 'Electronic, Battery, Wind-Up', 545, NULL, 529);
INSERT INTO `zeeauctions_categories` VALUES (552, 'Games', 545, NULL, 530);
INSERT INTO `zeeauctions_categories` VALUES (553, 'Outdoor Toys, Structures', 545, NULL, 531);
INSERT INTO `zeeauctions_categories` VALUES (554, 'Puzzles', 545, NULL, 532);
INSERT INTO `zeeauctions_categories` VALUES (555, 'Radio Control', 545, NULL, 533);
INSERT INTO `zeeauctions_categories` VALUES (556, 'Robots, Monsters, Space Toys', 545, NULL, 534);
INSERT INTO `zeeauctions_categories` VALUES (557, 'Other', 545, NULL, 535);
INSERT INTO `zeeauctions_categories` VALUES (558, 'Wholesale Lots', 545, NULL, 536);
INSERT INTO `zeeauctions_categories` VALUES (559, 'Travel', 0, NULL, 537);
INSERT INTO `zeeauctions_categories` VALUES (560, 'Airline', 559, NULL, 538);
INSERT INTO `zeeauctions_categories` VALUES (561, 'Car Rental', 559, NULL, 539);
INSERT INTO `zeeauctions_categories` VALUES (562, 'Lodging', 559, NULL, 540);
INSERT INTO `zeeauctions_categories` VALUES (563, 'Luggage', 559, NULL, 541);
INSERT INTO `zeeauctions_categories` VALUES (564, 'Vacation Packages', 559, NULL, 542);
INSERT INTO `zeeauctions_categories` VALUES (565, 'Other ', 559, NULL, 543);
INSERT INTO `zeeauctions_categories` VALUES (566, 'Video Games', 0, NULL, 544);
INSERT INTO `zeeauctions_categories` VALUES (567, 'Accessories', 566, NULL, 545);
INSERT INTO `zeeauctions_categories` VALUES (568, 'Games', 566, NULL, 546);
INSERT INTO `zeeauctions_categories` VALUES (569, 'Internet Games', 566, NULL, 547);
INSERT INTO `zeeauctions_categories` VALUES (570, 'Systems', 566, NULL, 548);
INSERT INTO `zeeauctions_categories` VALUES (571, 'Others', 566, NULL, 549);
INSERT INTO `zeeauctions_categories` VALUES (572, 'Wholesale Lots', 566, NULL, 550);
INSERT INTO `zeeauctions_categories` VALUES (573, 'Everything Else', 0, NULL, 551);
INSERT INTO `zeeauctions_categories` VALUES (574, 'Advertising Opportunities', 573, NULL, 552);
INSERT INTO `zeeauctions_categories` VALUES (575, 'eBay User Tools', 573, NULL, 553);
INSERT INTO `zeeauctions_categories` VALUES (576, 'Education & Learning', 573, NULL, 554);
INSERT INTO `zeeauctions_categories` VALUES (577, 'Funeral & Cemetery', 573, NULL, 555);
INSERT INTO `zeeauctions_categories` VALUES (578, 'Genealogy', 573, NULL, 556);
INSERT INTO `zeeauctions_categories` VALUES (579, 'Gifts & Occasions', 573, NULL, 557);
INSERT INTO `zeeauctions_categories` VALUES (580, 'Information Products', 573, NULL, 558);
INSERT INTO `zeeauctions_categories` VALUES (581, 'Memberships', 573, NULL, 559);
INSERT INTO `zeeauctions_categories` VALUES (582, 'Metaphysical', 573, NULL, 560);
INSERT INTO `zeeauctions_categories` VALUES (583, 'Mystery Auctions', 573, NULL, 561);
INSERT INTO `zeeauctions_categories` VALUES (584, 'Personal Security', 573, NULL, 562);
INSERT INTO `zeeauctions_categories` VALUES (585, 'Religious Products & Supplies', 573, NULL, 563);
INSERT INTO `zeeauctions_categories` VALUES (586, 'Reward Pts, Incentive Progs', 573, NULL, 564);
INSERT INTO `zeeauctions_categories` VALUES (587, 'Weird Stuff', 573, NULL, 565);
INSERT INTO `zeeauctions_categories` VALUES (588, 'Other', 573, NULL, 566);

-- --------------------------------------------------------

-- 
-- Table structure for table `zeeauctions_config`
-- 

CREATE TABLE `zeeauctions_config` (
  `id` bigint(20) NOT NULL auto_increment,
  `admin_email` varchar(255) default NULL,
  `site_name` varchar(255) default NULL,
  `recperpage` int(11) default NULL,
  `pay_pal` varchar(255) default NULL,
  `no_of_images` int(11) default NULL,
  `agreement` longtext,
  `recinpanel` int(11) default NULL,
  `null_char` varchar(255) default NULL,
  `privacy` longtext,
  `legal` longtext,
  `terms` longtext,
  `username_len` int(11) default NULL,
  `pwd_len` int(11) default NULL,
  `site_root` varchar(255) default NULL,
  `featured_items` int(11) default NULL,
  `fp_images` int(11) default '0',
  `bonus` decimal(10,2) default NULL,
  `bold_rate` decimal(10,2) default NULL,
  `featured_rate` decimal(10,2) default NULL,
  `highlight_rate` decimal(10,2) default NULL,
  `free_images` int(10) default NULL,
  `image_rate` decimal(10,2) default NULL,
  `buy_images` int(10) default NULL,
  `welcome_msg` longtext,
  `max_period` int(10) default NULL,
  `fp_featured_rate` decimal(10,2) default NULL,
  `gallery_featured_rate` decimal(10,2) default NULL,
  `auction_item_fees` decimal(10,2) default '0.00',
  `fixed_item_fees` decimal(10,2) default '0.00',
  `classified_item_fees` decimal(10,2) default '0.00',
  `dutch_item_fees` decimal(10,2) default '0.00',
  `cur_id` bigint(20) default '1',
  `max_ext_period` int(11) default '0',
  `ext_cost` decimal(10,2) NOT NULL default '0.00',
  `image_size` bigint(20) default '0',
  `buy_now` decimal(10,2) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `zeeauctions_config`
-- 

INSERT INTO `zeeauctions_config` VALUES (1, 'admin@zeeauctions.com', 'ZeeAuctions.com :: List Anything Old or New For Free', 10, 'admin@zeescripts.com', 10, 'Your Agreement Here\r\n', 6, '- -', '<font type=''arial'' size=4><b>Privacy Policy</b></font>\r\n<font type=''arial'' size=2><br>Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. <p>\r\nAdmin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. <p>Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. <p>\r\n</font>', '<font type=''arial'' size=4><b>Legal Policy</b></font>\r\n<font type=''arial'' size=2><br>Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.<p>Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.<p>Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.<p>Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.<p>Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.<p>', '<font type=''arial'' size=4><b>Terms and Conditions</b></font>\r\n<font type=''arial'' size=2><br>Terms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions here<p>Terms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions here<p>Terms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions here<p>Terms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions here<p>Terms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions here<p>Terms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions here<p>Terms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions here<p>Terms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions here<p>', 4, 4, 'http://www.zeeauctions.com', 5, 5, '100.00', '2.00', '1.00', '7.00', 3, '5.00', 3, 'Welcome to ZeeAuctions', 15, '1.00', '1.80', '0.50', '0.75', '1.50', '2.00', 1, 15, '0.05', 500000, '1.00');

-- --------------------------------------------------------

-- 
-- Table structure for table `zeeauctions_contacts`
-- 

CREATE TABLE `zeeauctions_contacts` (
  `id` bigint(20) NOT NULL auto_increment,
  `uid` bigint(20) default NULL,
  `contact_user` bigint(20) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `zeeauctions_contacts`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `zeeauctions_counters`
-- 

CREATE TABLE `zeeauctions_counters` (
  `id` bigint(20) NOT NULL auto_increment,
  `zero` varchar(255) default NULL,
  `one` varchar(255) default NULL,
  `two` varchar(255) default NULL,
  `three` varchar(255) default NULL,
  `four` varchar(255) default NULL,
  `five` varchar(255) default NULL,
  `six` varchar(255) default NULL,
  `seven` varchar(255) default NULL,
  `eight` varchar(255) default NULL,
  `nine` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `zeeauctions_counters`
-- 

INSERT INTO `zeeauctions_counters` VALUES (1, '0.gif', '1.gif', '2.gif', '3.gif', '4.gif', '5.gif', '6.gif', '7.gif', '8.gif', '9.gif');
INSERT INTO `zeeauctions_counters` VALUES (2, 'a0.gif', 'a1.gif', 'a2.gif', 'a3.gif', 'a4.gif', 'a5.gif', 'a6.gif', 'a7.gif', 'a8.gif', 'a9.gif');

-- --------------------------------------------------------

-- 
-- Table structure for table `zeeauctions_country`
-- 

CREATE TABLE `zeeauctions_country` (
  `country` varchar(255) NOT NULL default '',
  `id` bigint(20) NOT NULL auto_increment,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=222 ;

-- 
-- Dumping data for table `zeeauctions_country`
-- 

INSERT INTO `zeeauctions_country` VALUES ('Afghanistan', 1);
INSERT INTO `zeeauctions_country` VALUES ('Albania', 2);
INSERT INTO `zeeauctions_country` VALUES ('Algeria', 3);
INSERT INTO `zeeauctions_country` VALUES ('Andorra', 4);
INSERT INTO `zeeauctions_country` VALUES ('Angola', 5);
INSERT INTO `zeeauctions_country` VALUES ('Anguilla', 6);
INSERT INTO `zeeauctions_country` VALUES ('Antigua & Barbuda', 7);
INSERT INTO `zeeauctions_country` VALUES ('Argentina', 8);
INSERT INTO `zeeauctions_country` VALUES ('Armenia', 9);
INSERT INTO `zeeauctions_country` VALUES ('Austria', 10);
INSERT INTO `zeeauctions_country` VALUES ('Azerbaijan', 11);
INSERT INTO `zeeauctions_country` VALUES ('Bahamas', 12);
INSERT INTO `zeeauctions_country` VALUES ('Bahrain', 13);
INSERT INTO `zeeauctions_country` VALUES ('Bangladesh', 14);
INSERT INTO `zeeauctions_country` VALUES ('Barbados', 15);
INSERT INTO `zeeauctions_country` VALUES ('Belarus', 16);
INSERT INTO `zeeauctions_country` VALUES ('Belgium', 17);
INSERT INTO `zeeauctions_country` VALUES ('Belize', 18);
INSERT INTO `zeeauctions_country` VALUES ('Belize', 19);
INSERT INTO `zeeauctions_country` VALUES ('Bermuda', 20);
INSERT INTO `zeeauctions_country` VALUES ('Bhutan', 21);
INSERT INTO `zeeauctions_country` VALUES ('Bolivia', 22);
INSERT INTO `zeeauctions_country` VALUES ('Bosnia and Herzegovina', 23);
INSERT INTO `zeeauctions_country` VALUES ('Botswana', 24);
INSERT INTO `zeeauctions_country` VALUES ('Brazil', 25);
INSERT INTO `zeeauctions_country` VALUES ('Brunei', 26);
INSERT INTO `zeeauctions_country` VALUES ('Bulgaria', 27);
INSERT INTO `zeeauctions_country` VALUES ('Burkina Faso', 28);
INSERT INTO `zeeauctions_country` VALUES ('Burundi', 29);
INSERT INTO `zeeauctions_country` VALUES ('Cambodia', 30);
INSERT INTO `zeeauctions_country` VALUES ('Cameroon', 31);
INSERT INTO `zeeauctions_country` VALUES ('Canada', 32);
INSERT INTO `zeeauctions_country` VALUES ('Cape Verde', 33);
INSERT INTO `zeeauctions_country` VALUES ('Cayman Islands', 34);
INSERT INTO `zeeauctions_country` VALUES ('Central African Republic', 35);
INSERT INTO `zeeauctions_country` VALUES ('Chad', 36);
INSERT INTO `zeeauctions_country` VALUES ('Chile', 37);
INSERT INTO `zeeauctions_country` VALUES ('China', 38);
INSERT INTO `zeeauctions_country` VALUES ('Colombia', 39);
INSERT INTO `zeeauctions_country` VALUES ('Comoros', 40);
INSERT INTO `zeeauctions_country` VALUES ('Congo', 41);
INSERT INTO `zeeauctions_country` VALUES ('Congo (DRC)', 42);
INSERT INTO `zeeauctions_country` VALUES ('Cook Islands', 43);
INSERT INTO `zeeauctions_country` VALUES ('Costa Rica', 44);
INSERT INTO `zeeauctions_country` VALUES ('Cote d''Ivoire', 45);
INSERT INTO `zeeauctions_country` VALUES ('Croatia (Hrvatska)', 46);
INSERT INTO `zeeauctions_country` VALUES ('Cuba', 47);
INSERT INTO `zeeauctions_country` VALUES ('Cyprus', 48);
INSERT INTO `zeeauctions_country` VALUES ('Czech Republic', 49);
INSERT INTO `zeeauctions_country` VALUES ('Denmark', 50);
INSERT INTO `zeeauctions_country` VALUES ('Djibouti', 51);
INSERT INTO `zeeauctions_country` VALUES ('Dominica', 52);
INSERT INTO `zeeauctions_country` VALUES ('Dominican Republic', 53);
INSERT INTO `zeeauctions_country` VALUES ('East Timor', 54);
INSERT INTO `zeeauctions_country` VALUES ('Ecuador', 55);
INSERT INTO `zeeauctions_country` VALUES ('Egypt', 56);
INSERT INTO `zeeauctions_country` VALUES ('El Salvador', 57);
INSERT INTO `zeeauctions_country` VALUES ('Equatorial Guinea', 58);
INSERT INTO `zeeauctions_country` VALUES ('Eritrea', 59);
INSERT INTO `zeeauctions_country` VALUES ('Estonia', 60);
INSERT INTO `zeeauctions_country` VALUES ('Ethiopia', 61);
INSERT INTO `zeeauctions_country` VALUES ('Falkland Islands', 62);
INSERT INTO `zeeauctions_country` VALUES ('Faroe Islands', 63);
INSERT INTO `zeeauctions_country` VALUES ('Fiji Islands', 64);
INSERT INTO `zeeauctions_country` VALUES ('Finland', 65);
INSERT INTO `zeeauctions_country` VALUES ('France', 66);
INSERT INTO `zeeauctions_country` VALUES ('French Guiana', 67);
INSERT INTO `zeeauctions_country` VALUES ('French Polynesia', 68);
INSERT INTO `zeeauctions_country` VALUES ('Gabon', 69);
INSERT INTO `zeeauctions_country` VALUES ('Gambia', 70);
INSERT INTO `zeeauctions_country` VALUES ('Georgia', 71);
INSERT INTO `zeeauctions_country` VALUES ('Germany', 72);
INSERT INTO `zeeauctions_country` VALUES ('Ghana', 73);
INSERT INTO `zeeauctions_country` VALUES ('Gibraltar', 74);
INSERT INTO `zeeauctions_country` VALUES ('Greece', 75);
INSERT INTO `zeeauctions_country` VALUES ('Greenland', 76);
INSERT INTO `zeeauctions_country` VALUES ('Grenada', 77);
INSERT INTO `zeeauctions_country` VALUES ('Guadeloupe', 78);
INSERT INTO `zeeauctions_country` VALUES ('Guam', 79);
INSERT INTO `zeeauctions_country` VALUES ('Guatemala', 80);
INSERT INTO `zeeauctions_country` VALUES ('Guinea', 81);
INSERT INTO `zeeauctions_country` VALUES ('Guinea-Bissau', 82);
INSERT INTO `zeeauctions_country` VALUES ('Guyana', 83);
INSERT INTO `zeeauctions_country` VALUES ('Haiti', 84);
INSERT INTO `zeeauctions_country` VALUES ('Honduras', 85);
INSERT INTO `zeeauctions_country` VALUES ('Hong Kong SAR', 86);
INSERT INTO `zeeauctions_country` VALUES ('Hungary', 87);
INSERT INTO `zeeauctions_country` VALUES ('Iceland', 88);
INSERT INTO `zeeauctions_country` VALUES ('India', 89);
INSERT INTO `zeeauctions_country` VALUES ('Indonesia', 90);
INSERT INTO `zeeauctions_country` VALUES ('Iran', 91);
INSERT INTO `zeeauctions_country` VALUES ('Iraq', 92);
INSERT INTO `zeeauctions_country` VALUES ('Ireland', 93);
INSERT INTO `zeeauctions_country` VALUES ('Israel', 94);
INSERT INTO `zeeauctions_country` VALUES ('Italy', 95);
INSERT INTO `zeeauctions_country` VALUES ('Jamaica', 96);
INSERT INTO `zeeauctions_country` VALUES ('Japan', 97);
INSERT INTO `zeeauctions_country` VALUES ('Jordan', 98);
INSERT INTO `zeeauctions_country` VALUES ('Kazakhstan', 99);
INSERT INTO `zeeauctions_country` VALUES ('Kenya', 100);
INSERT INTO `zeeauctions_country` VALUES ('Kiribati', 101);
INSERT INTO `zeeauctions_country` VALUES ('Korea', 102);
INSERT INTO `zeeauctions_country` VALUES ('Kuwait', 103);
INSERT INTO `zeeauctions_country` VALUES ('Kyrgyzstan', 104);
INSERT INTO `zeeauctions_country` VALUES ('Laos', 105);
INSERT INTO `zeeauctions_country` VALUES ('Latvia', 106);
INSERT INTO `zeeauctions_country` VALUES ('Lebanon', 107);
INSERT INTO `zeeauctions_country` VALUES ('Lesotho', 108);
INSERT INTO `zeeauctions_country` VALUES ('Liberia', 109);
INSERT INTO `zeeauctions_country` VALUES ('Libya', 110);
INSERT INTO `zeeauctions_country` VALUES ('Liechtenstein', 111);
INSERT INTO `zeeauctions_country` VALUES ('Lithuania', 112);
INSERT INTO `zeeauctions_country` VALUES ('Luxembourg', 113);
INSERT INTO `zeeauctions_country` VALUES ('Macao SAR', 114);
INSERT INTO `zeeauctions_country` VALUES ('Macedonia', 115);
INSERT INTO `zeeauctions_country` VALUES ('Madagascar', 116);
INSERT INTO `zeeauctions_country` VALUES ('Malawi', 117);
INSERT INTO `zeeauctions_country` VALUES ('Malaysia', 118);
INSERT INTO `zeeauctions_country` VALUES ('Maldives', 119);
INSERT INTO `zeeauctions_country` VALUES ('Mali', 120);
INSERT INTO `zeeauctions_country` VALUES ('Malta', 121);
INSERT INTO `zeeauctions_country` VALUES ('Martinique', 122);
INSERT INTO `zeeauctions_country` VALUES ('Mauritania', 123);
INSERT INTO `zeeauctions_country` VALUES ('Mauritius', 124);
INSERT INTO `zeeauctions_country` VALUES ('Mayotte', 125);
INSERT INTO `zeeauctions_country` VALUES ('Mexico', 126);
INSERT INTO `zeeauctions_country` VALUES ('Micronesia', 127);
INSERT INTO `zeeauctions_country` VALUES ('Moldova', 128);
INSERT INTO `zeeauctions_country` VALUES ('Monaco', 129);
INSERT INTO `zeeauctions_country` VALUES ('Mongolia', 130);
INSERT INTO `zeeauctions_country` VALUES ('Montserrat', 131);
INSERT INTO `zeeauctions_country` VALUES ('Morocco', 132);
INSERT INTO `zeeauctions_country` VALUES ('Mozambique', 133);
INSERT INTO `zeeauctions_country` VALUES ('Myanmar', 134);
INSERT INTO `zeeauctions_country` VALUES ('Namibia', 135);
INSERT INTO `zeeauctions_country` VALUES ('Nauru', 136);
INSERT INTO `zeeauctions_country` VALUES ('Nepal', 137);
INSERT INTO `zeeauctions_country` VALUES ('Netherlands', 138);
INSERT INTO `zeeauctions_country` VALUES ('Netherlands Antilles', 139);
INSERT INTO `zeeauctions_country` VALUES ('New Caledonia', 140);
INSERT INTO `zeeauctions_country` VALUES ('New Zealand', 141);
INSERT INTO `zeeauctions_country` VALUES ('Nicaragua', 142);
INSERT INTO `zeeauctions_country` VALUES ('Niger', 143);
INSERT INTO `zeeauctions_country` VALUES ('Nigeria', 144);
INSERT INTO `zeeauctions_country` VALUES ('Niue', 145);
INSERT INTO `zeeauctions_country` VALUES ('Norfolk Island', 146);
INSERT INTO `zeeauctions_country` VALUES ('North Korea', 147);
INSERT INTO `zeeauctions_country` VALUES ('Norway', 148);
INSERT INTO `zeeauctions_country` VALUES ('Oman', 149);
INSERT INTO `zeeauctions_country` VALUES ('Pakistan', 150);
INSERT INTO `zeeauctions_country` VALUES ('Panama', 151);
INSERT INTO `zeeauctions_country` VALUES ('Papua New Guinea', 152);
INSERT INTO `zeeauctions_country` VALUES ('Paraguay', 153);
INSERT INTO `zeeauctions_country` VALUES ('Peru', 154);
INSERT INTO `zeeauctions_country` VALUES ('Philippines', 155);
INSERT INTO `zeeauctions_country` VALUES ('Pitcairn Islands', 156);
INSERT INTO `zeeauctions_country` VALUES ('Poland', 157);
INSERT INTO `zeeauctions_country` VALUES ('Portugal', 158);
INSERT INTO `zeeauctions_country` VALUES ('Puerto Rico', 159);
INSERT INTO `zeeauctions_country` VALUES ('Qatar', 160);
INSERT INTO `zeeauctions_country` VALUES ('Reunion', 161);
INSERT INTO `zeeauctions_country` VALUES ('Romania', 162);
INSERT INTO `zeeauctions_country` VALUES ('Russia', 163);
INSERT INTO `zeeauctions_country` VALUES ('Rwanda', 164);
INSERT INTO `zeeauctions_country` VALUES ('Samoa', 165);
INSERT INTO `zeeauctions_country` VALUES ('San Marino', 166);
INSERT INTO `zeeauctions_country` VALUES ('Sao Tome and Principe', 167);
INSERT INTO `zeeauctions_country` VALUES ('Saudi Arabia', 168);
INSERT INTO `zeeauctions_country` VALUES ('Senegal', 169);
INSERT INTO `zeeauctions_country` VALUES ('Serbia and Montenegro', 170);
INSERT INTO `zeeauctions_country` VALUES ('Seychelles', 171);
INSERT INTO `zeeauctions_country` VALUES ('Sierra Leone', 172);
INSERT INTO `zeeauctions_country` VALUES ('Singapore', 173);
INSERT INTO `zeeauctions_country` VALUES ('Slovakia', 174);
INSERT INTO `zeeauctions_country` VALUES ('Slovenia', 175);
INSERT INTO `zeeauctions_country` VALUES ('Solomon Islands', 176);
INSERT INTO `zeeauctions_country` VALUES ('Somalia', 177);
INSERT INTO `zeeauctions_country` VALUES ('South Africa', 178);
INSERT INTO `zeeauctions_country` VALUES ('Spain', 179);
INSERT INTO `zeeauctions_country` VALUES ('Sri Lanka', 180);
INSERT INTO `zeeauctions_country` VALUES ('St. Helena', 181);
INSERT INTO `zeeauctions_country` VALUES ('St. Kitts and Nevis', 182);
INSERT INTO `zeeauctions_country` VALUES ('St. Lucia', 183);
INSERT INTO `zeeauctions_country` VALUES ('St. Pierre and Miquelon', 184);
INSERT INTO `zeeauctions_country` VALUES ('St. Vincent & Grenadines', 185);
INSERT INTO `zeeauctions_country` VALUES ('Sudan', 186);
INSERT INTO `zeeauctions_country` VALUES ('Suriname', 187);
INSERT INTO `zeeauctions_country` VALUES ('Swaziland', 188);
INSERT INTO `zeeauctions_country` VALUES ('Sweden', 189);
INSERT INTO `zeeauctions_country` VALUES ('Switzerland', 190);
INSERT INTO `zeeauctions_country` VALUES ('Syria', 191);
INSERT INTO `zeeauctions_country` VALUES ('Taiwan', 192);
INSERT INTO `zeeauctions_country` VALUES ('Tajikistan', 193);
INSERT INTO `zeeauctions_country` VALUES ('Tanzania', 194);
INSERT INTO `zeeauctions_country` VALUES ('Thailand', 195);
INSERT INTO `zeeauctions_country` VALUES ('Togo', 196);
INSERT INTO `zeeauctions_country` VALUES ('Tokelau', 197);
INSERT INTO `zeeauctions_country` VALUES ('Tonga', 198);
INSERT INTO `zeeauctions_country` VALUES ('Trinidad and Tobago', 199);
INSERT INTO `zeeauctions_country` VALUES ('Tunisia', 200);
INSERT INTO `zeeauctions_country` VALUES ('Turkey', 201);
INSERT INTO `zeeauctions_country` VALUES ('Turkmenistan', 202);
INSERT INTO `zeeauctions_country` VALUES ('Turks and Caicos Islands', 203);
INSERT INTO `zeeauctions_country` VALUES ('Tuvalu', 204);
INSERT INTO `zeeauctions_country` VALUES ('Uganda', 205);
INSERT INTO `zeeauctions_country` VALUES ('Ukraine', 206);
INSERT INTO `zeeauctions_country` VALUES ('United Arab Emirates', 207);
INSERT INTO `zeeauctions_country` VALUES ('United Kingdom', 208);
INSERT INTO `zeeauctions_country` VALUES ('Uruguay', 209);
INSERT INTO `zeeauctions_country` VALUES ('USA', 210);
INSERT INTO `zeeauctions_country` VALUES ('Uzbekistan', 211);
INSERT INTO `zeeauctions_country` VALUES ('Vanuatu', 212);
INSERT INTO `zeeauctions_country` VALUES ('Venezuela', 213);
INSERT INTO `zeeauctions_country` VALUES ('Vietnam', 214);
INSERT INTO `zeeauctions_country` VALUES ('Virgin Islands', 215);
INSERT INTO `zeeauctions_country` VALUES ('Virgin Islands (British)', 216);
INSERT INTO `zeeauctions_country` VALUES ('Wallis and Futuna', 217);
INSERT INTO `zeeauctions_country` VALUES ('Yemen', 218);
INSERT INTO `zeeauctions_country` VALUES ('Yugoslavia', 219);
INSERT INTO `zeeauctions_country` VALUES ('Zambia', 220);
INSERT INTO `zeeauctions_country` VALUES ('Zimbabwe', 221);

-- --------------------------------------------------------

-- 
-- Table structure for table `zeeauctions_currency`
-- 

CREATE TABLE `zeeauctions_currency` (
  `id` bigint(20) NOT NULL auto_increment,
  `cur_name` varchar(255) default NULL,
  `paypal_code` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `zeeauctions_currency`
-- 

INSERT INTO `zeeauctions_currency` VALUES (1, '$', 'USD');

-- --------------------------------------------------------

-- 
-- Table structure for table `zeeauctions_desc`
-- 

CREATE TABLE `zeeauctions_desc` (
  `id` bigint(20) NOT NULL auto_increment,
  `pid` bigint(20) default NULL,
  `add_desc` longtext,
  `date_submitted` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `zeeauctions_desc`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `zeeauctions_email_id`
-- 

CREATE TABLE `zeeauctions_email_id` (
  `id` bigint(20) NOT NULL auto_increment,
  `fname` varchar(255) default NULL,
  `lname` varchar(255) default NULL,
  `useremail` varchar(255) default NULL,
  `friend_email` longtext,
  `no_of_friends` int(11) default NULL,
  `sid` bigint(20) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `zeeauctions_email_id`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `zeeauctions_favourites`
-- 

CREATE TABLE `zeeauctions_favourites` (
  `id` bigint(20) NOT NULL auto_increment,
  `pid` bigint(20) default NULL,
  `uid` bigint(20) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `zeeauctions_favourites`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `zeeauctions_feedback`
-- 

CREATE TABLE `zeeauctions_feedback` (
  `id` bigint(20) NOT NULL auto_increment,
  `username` varchar(255) default NULL,
  `rating` varchar(50) default NULL,
  `comment` longtext,
  `by_id` varchar(255) default NULL,
  `pid` bigint(20) default '0',
  `date_submitted` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `zeeauctions_feedback`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `zeeauctions_forum_ans`
-- 

CREATE TABLE `zeeauctions_forum_ans` (
  `id` bigint(20) NOT NULL auto_increment,
  `ques_id` bigint(20) default NULL,
  `ans` longtext,
  `uid` bigint(20) default NULL,
  `postedon` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `zeeauctions_forum_ans`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `zeeauctions_forum_ques`
-- 

CREATE TABLE `zeeauctions_forum_ques` (
  `id` bigint(20) NOT NULL auto_increment,
  `uid` bigint(20) default NULL,
  `ques` longtext,
  `can_comment` longtext,
  `postedon` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `zeeauctions_forum_ques`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `zeeauctions_images`
-- 

CREATE TABLE `zeeauctions_images` (
  `id` bigint(20) NOT NULL auto_increment,
  `pid` bigint(20) default NULL,
  `url` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

-- 
-- Dumping data for table `zeeauctions_images`
-- 

INSERT INTO `zeeauctions_images` VALUES (2, 2, '877950V2Boxthumb.jpg');
INSERT INTO `zeeauctions_images` VALUES (3, 3, '945255UQ7.jpg');
INSERT INTO `zeeauctions_images` VALUES (4, 4, '43795boxthumb.jpg');

-- --------------------------------------------------------

-- 
-- Table structure for table `zeeauctions_mails`
-- 

CREATE TABLE `zeeauctions_mails` (
  `id` bigint(20) NOT NULL auto_increment,
  `mailid` bigint(20) NOT NULL default '0',
  `fromid` varchar(255) NOT NULL default '',
  `subject` varchar(255) NOT NULL default '',
  `mail` longtext NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

-- 
-- Dumping data for table `zeeauctions_mails`
-- 

INSERT INTO `zeeauctions_mails` VALUES (2, 2, 'approval@zeeauctions.com', 'Your product has been Approved', 'Hi <fname> <lname>,\r\n\r\nYour product <productname> has been Approved for inclusion on the site.\r\nYou can view this product on <producturl>\r\n\r\nRegards,\r\nAdmin');
INSERT INTO `zeeauctions_mails` VALUES (3, 3, 'disapproval@zeeauctions.com', 'Your product has been disapproved', 'Hi <fname> <lname>,\r\n\r\nYour product <productname> has been disapproved from inclusion on the site.\r\n\r\n\r\nRegards,\r\nAdmin\r\n');
INSERT INTO `zeeauctions_mails` VALUES (4, 4, 'password@zeeauctions.com', 'Your password', 'Hi <fname> <lname>,\r\n\r\nHere is your login information:\r\n\r\nUsername:        <username>\r\nPassword:        <password>\r\nEmail:           <email>\r\n\r\n\r\nThanks for being part of our website.\r\n\r\nRegards,\r\nAdmin\r\nFor login click <loginurl>');
INSERT INTO `zeeauctions_mails` VALUES (1, 1, 'welcome@zeeauctions.com', 'Welcome to zeeauctions.com', 'Hi <fname> <lname>,\r\n\r\nWelcome to zeeauctions.com.\r\n\r\nYour registration information is as follows:\r\n\r\nUsername:        <username>\r\nPassword:        <password>\r\nEmail:           <email>\r\n\r\nThanks for being part of our website.\r\n\r\nRegards,\r\nAdmin\r\nFor login click <loginurl>\r\n');
INSERT INTO `zeeauctions_mails` VALUES (5, 5, 'admin@zeeauctions.com', 'Your product has been Posted', 'Hi <fname> <lname>,\r\n\r\nYour product <productname> has been Posted to our site.You can view this product at <producturl>.\r\n\r\n\r\nRegards,\r\nAdmin');
INSERT INTO `zeeauctions_mails` VALUES (6, 6, 'admin@zeeauctions.com', 'A bid has been placed against your product', 'Hi <fname> <lname>,\r\n\r\nA bid of amount <currentbid> has been placed against your product <productname> from member <bidder_username>.\r\nTotal no of bids <noofbids> \r\n\r\n\r\nRegards,\r\nAdmin');
INSERT INTO `zeeauctions_mails` VALUES (7, 7, 'admin@zeeauctions.com', 'Auction End', 'Hi <fname> <lname>,\r\nYour auction for product <productname> has been expired on <expired_date>.\r\n\r\n\r\nRegards,\r\nAdmin');
INSERT INTO `zeeauctions_mails` VALUES (8, 8, 'admin@zeeauctions.com', 'Message from user.', 'Hi <fname> <lname>,\r\n\r\nYou have been recieved a message\r\nFrom ::  <sender_username>\r\nTitle :: <message_title>\r\nMessage :: <message_text>\r\nTime :: <message_time>\r\nDate :: <message_date>\r\n\r\n\r\nRegards,\r\nAdmin');
INSERT INTO `zeeauctions_mails` VALUES (9, 9, 'admin@zeeauctions.com', 'Auction Winner', 'Hi <fname> <lname>,\r\n\r\nYou have been won the auction for the product <productname>.\r\nYou can order the product through email <seller_email>\r\n\r\nRegards,\r\nAdmin');
INSERT INTO `zeeauctions_mails` VALUES (10, 10, 'admin@zeeauctions.com', 'Auction Closed', 'Hi <fname> <lname>,\r\n\r\nYou have closed the auction for the product <productname>.\r\nYou can contact buyer(s) contact information is as follows:\r\n <contact_information>\r\n\r\nRegards,\r\nAdmin');
INSERT INTO `zeeauctions_mails` VALUES (11, 11, 'admin@zeeauctions.com', 'Auction Looser', 'Hi <fname> <lname>,\r\n\r\nUnfortunately your bid for product <productname> has not been choosed.\r\n\r\nRegards,\r\nAdmin');
INSERT INTO `zeeauctions_mails` VALUES (12, 12, 'admin@zeeauctions.com', 'Purchase Request', 'Hi <fname> <lname>,\r\n\r\nAn order for your product <productname> of quantity <quantity> items @ <amount>  has been placed by <buyer_username>.\r\nYou can contact him/her at <contact_information>.\r\n\r\nRegards,\r\nAdmin');
INSERT INTO `zeeauctions_mails` VALUES (13, 13, 'admin@zeeauctions.com', 'Order Placed', 'Hi <fname> <lname>,\r\n\r\nYour order of quantity <quantity> items @ <amount> of product <productname> has been placed.\r\nYou can contact seller at <seller_email>.\r\n\r\nRegards,\r\nAdmin');
INSERT INTO `zeeauctions_mails` VALUES (14, 14, 'admin@zeeauctions.com', 'outbid mail', 'Hi <fname> <lname>,\r\n\r\nA bid more than your bid for the product <productname> has been placed.\r\n\r\nRegards,\r\nAdmin\r\n');
INSERT INTO `zeeauctions_mails` VALUES (15, 15, 'admin@zeeauctions.com', 'Send Stat Mail', 'Hi \r\n\r\nThere are statistics information regarding your banner display on our site::\r\nBanner ::<bannerurl>\r\nDisplays::<displays>\r\ncredits ::<credits>\r\nbalance ::<balance>\r\n\r\nRegards,\r\nAdmin');

-- --------------------------------------------------------

-- 
-- Table structure for table `zeeauctions_members`
-- 

CREATE TABLE `zeeauctions_members` (
  `id` bigint(20) NOT NULL auto_increment,
  `c_name` varchar(255) default NULL,
  `add1` varchar(255) default NULL,
  `add2` varchar(255) default NULL,
  `city` varchar(255) default NULL,
  `state` varchar(255) default NULL,
  `zip` varchar(50) default NULL,
  `country` varchar(255) default NULL,
  `home_phone` varchar(50) default NULL,
  `email` varchar(255) default NULL,
  `username` varchar(255) default NULL,
  `pwd` varchar(255) default NULL,
  `fname` varchar(255) default NULL,
  `lname` varchar(255) default NULL,
  `work_phone` varchar(50) default NULL,
  `logo_url` varchar(255) default NULL,
  `store_title` varchar(255) default NULL,
  `store_desc` longtext,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `zeeauctions_members`
-- 

INSERT INTO `zeeauctions_members` VALUES (1, 'zeescripts', '#1 C B Colony', '', 'Karnataka', 'Bangalore', '560045', '89', '25464057', 'admin@zeescripts.com', 'zeescripts', 'tiger786', 'Syed', 'Nazir', '', '228930logoscripts.jpg', 'Zeescripts', '<FONT face="Arial, Helvetica, sans-serif" color=#660000 size=2><STRONG>Welcome to My Store Zeescripts</STRONG></FONT> ');
INSERT INTO `zeeauctions_members` VALUES (2, 'Zeeways', 'C B C, Smpr rod', '', 'Bangalore', 'Ka', '560045', '89', '111111111', 'mail@zeeways.com', 'websiteslogic', 'Arrazikhu', 'syed', 'Farooq', '', '', '', '');

-- --------------------------------------------------------

-- 
-- Table structure for table `zeeauctions_member_feedback`
-- 

CREATE TABLE `zeeauctions_member_feedback` (
  `id` bigint(20) NOT NULL auto_increment,
  `fname` varchar(255) default NULL,
  `lname` varchar(255) default NULL,
  `email` varchar(255) default NULL,
  `url` varchar(255) default NULL,
  `title` varchar(255) default NULL,
  `comment` longtext,
  `uid` bigint(20) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `zeeauctions_member_feedback`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `zeeauctions_messages`
-- 

CREATE TABLE `zeeauctions_messages` (
  `id` bigint(20) NOT NULL auto_increment,
  `fid` bigint(20) NOT NULL default '0',
  `tid` bigint(20) NOT NULL default '0',
  `subject` mediumtext NOT NULL,
  `message` longtext NOT NULL,
  `tempdate` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `onstamp` timestamp NOT NULL default '0000-00-00 00:00:00',
  `msg_read` varchar(10) NOT NULL default '',
  `f_del` varchar(10) NOT NULL default '',
  `t_del` varchar(10) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `zeeauctions_messages`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `zeeauctions_plans`
-- 

CREATE TABLE `zeeauctions_plans` (
  `id` bigint(20) NOT NULL auto_increment,
  `credits` bigint(20) NOT NULL default '0',
  `price` bigint(20) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

-- 
-- Dumping data for table `zeeauctions_plans`
-- 

INSERT INTO `zeeauctions_plans` VALUES (8, 1000, 7);
INSERT INTO `zeeauctions_plans` VALUES (7, 10000, 36);
INSERT INTO `zeeauctions_plans` VALUES (6, 5000, 20);

-- --------------------------------------------------------

-- 
-- Table structure for table `zeeauctions_products`
-- 

CREATE TABLE `zeeauctions_products` (
  `id` bigint(20) NOT NULL auto_increment,
  `uid` bigint(20) NOT NULL default '0',
  `product_name` varchar(255) default NULL,
  `cid` bigint(20) default NULL,
  `aucid` bigint(20) default NULL,
  `auction_period` varchar(255) default NULL,
  `featured` varchar(10) default NULL,
  `approved` varchar(10) default NULL,
  `tmpdate` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `date_submitted` timestamp NOT NULL default '0000-00-00 00:00:00',
  `date_closed` timestamp NOT NULL default '0000-00-00 00:00:00',
  `product_desc` longtext,
  `quantity` bigint(20) default NULL,
  `location` varchar(255) default NULL,
  `bid_inc` decimal(10,2) default NULL,
  `min_bid` decimal(10,2) default NULL,
  `no_of_views` bigint(20) default NULL,
  `ship_cost` decimal(10,2) default NULL,
  `who_pay_sc` varchar(255) default NULL,
  `status` varchar(255) default NULL,
  `winner` varchar(255) default NULL,
  `bold` varchar(10) default NULL,
  `highlight` varchar(10) default NULL,
  `purchased_images` int(10) default '0',
  `fp_featured` varchar(10) default NULL,
  `gallery_featured` varchar(10) default NULL,
  `auto_list` int(11) default '0',
  `done` int(11) default '0',
  `paypal_id` varchar(255) default NULL,
  `counter_id` bigint(20) default '0',
  `reserve_price` decimal(10,2) default '0.00',
  `buy_price` decimal(10,2) default '0.00',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

-- 
-- Dumping data for table `zeeauctions_products`
-- 

INSERT INTO `zeeauctions_products` VALUES (2, 2, 'EXIT POP-UP POPUP + PEEL AWAY ADS SOFTWARE -RESELL', 534, 3, '1', 'yes', 'yes', '2007-08-18 23:29:45', '2007-08-18 11:29:45', '0000-00-00 00:00:00', '<DIV align=center><SPAN style="COLOR: #000080; FONT-FAMILY: Arial"><STRONG>EXIT POP-UP &amp; PEEL AWAY ADS SOFTWARE - RESELL </STRONG></SPAN></DIV>\r\n<DIV align=center><SPAN style="COLOR: #000080; FONT-FAMILY: Arial"></SPAN>&nbsp;</DIV>\r\n<DIV align=center><SPAN style="COLOR: #000080; FONT-FAMILY: Arial"><IMG alt="" src="http://www.zeescripts.com/salespages/youcantblockthis/images/V2Box.jpg" border=0></SPAN></DIV>\r\n<DIV align=center><SPAN style="FONT-SIZE: 10pt; COLOR: #000080; FONT-FAMILY: Arial"></SPAN>&nbsp;</DIV>\r\n<DIV align=center><SPAN style="FONT-SIZE: 10pt; COLOR: #000080; FONT-FAMILY: Arial"></SPAN>&nbsp;</DIV>\r\n<DIV><SPAN style="FONT-SIZE: 10pt; FONT-FAMILY: Arial">This is yet another new pop up software. This one has combined all the features of Peel Away Ads and Exit Grabber into one “unblockable” piece of software. I already purchased the peel aways and would have bought exit grabber as well but they are asking $80 and I thought I would wait and see if the price goes down. I am glad I waited because You Can’t Block This is only $17 and it does what both of the above do and more. Not only are they unblockable but they can be used in different configurations with timers and fade in/outs. The coolest thing about them is that the program loads the code on your website for you. Absolutely no html or java required </SPAN></DIV>\r\n<DIV><SPAN style="FONT-SIZE: 10pt; FONT-FAMILY: Arial"></SPAN>&nbsp;</DIV>\r\n<DIV align=center><SPAN style="FONT-SIZE: 10pt; COLOR: #000080; FONT-FAMILY: Arial; TEXT-DECORATION: underline"><STRONG><A href="http://www.zeescripts.com/salespages/youcantblockthis/" target=_blank>CLICK HERE FOR FULL DETAILS</A></STRONG></SPAN></DIV>', 100, 'India', '0.00', '17.00', 0, '0.00', 'seller', 'open', '0', 'no', 'no', 0, 'yes', 'yes', 3, 0, '', 2, '0.00', '0.00');
INSERT INTO `zeeauctions_products` VALUES (3, 1, 'uq7.com 3 LETTER CHARACTER .COM DOMAIN', 295, 1, '1', 'yes', 'yes', '2007-08-18 23:45:34', '2007-08-18 11:34:33', '0000-00-00 00:00:00', '<P align=center><FONT face=Arial color=#006535 size=4><FONT size=5><STRONG>UQ7.COM&nbsp; TOP&nbsp;3&nbsp; LETTER / &nbsp;CHARACTER&nbsp;.COM DOMAIN NAME</STRONG></FONT>&nbsp;</FONT></P>\r\n<P align=center><FONT face=Arial color=#006535 size=4>Appraised for <STRONG><FONT color=#000000>$ 5,600 ~ 8,000</FONT></STRONG></FONT></P>\r\n<P align=center><FONT face=Arial color=#00429a size=4>DOMAIN NAME FOR FREE PUSH</FONT></P>\r\n<P align=center><FONT color=#202020><FONT face=Courier size=5><STRONG>DONT MISS THIS CHANCE TO GRAB THE .COM DOMAIN NAME!</STRONG></FONT> </FONT></P>\r\n<P align=center><FONT face=Verdana color=#00665e size=4><STRONG>GREAT INVESTMENT FOR FUTURE - MORE SAFER THAN STOCK MARKET !</STRONG></FONT></P>\r\n<BLOCKQUOTE>\r\n<BLOCKQUOTE>\r\n<UL>\r\n<UL>\r\n<LI>\r\n<P align=left><FONT face=Arial size=4>In the internet marketplace your domain name is everything.</FONT> </P>\r\n<LI>\r\n<P align=left><FONT face=Arial size=4>Without a domain name that is easy to remember you cannot succeed. </FONT></P>\r\n<LI>\r\n<P align=left><FONT face=Arial size=4>A domain name like&nbsp;<FONT color=#ff0010>UQ7</FONT></FONT><B><FONT face=Verdana color=#ff0000 size=2>.com </FONT></B><FONT face=Arial size=4>sticks in your mind and your customers will remember it later. </FONT></P>\r\n<LI>\r\n<P align=left><FONT face=Arial size=4>Word of Mouth advertising is always the best advertising you can have, since this domain name is so perfect anyone can easily remember it if told about it in passing, at the office, on the golf course, etc. </FONT></P></LI></UL></UL>\r\n<BLOCKQUOTE dir=ltr style="MARGIN-RIGHT: 0px">\r\n<BLOCKQUOTE dir=ltr style="MARGIN-RIGHT: 0px">\r\n<P align=left><FONT face=Verdana>- The Domain is at <STRONG><FONT color=#ff0000>Godaddy</FONT></STRONG>.<BR>- Shipping Charge Worldwide </FONT><FONT face=Verdana><FONT color=#ff0000><STRONG>Free<BR></STRONG><FONT color=#000000>-&nbsp;Domain transfer to Godaddy Account </FONT><STRONG>Free</STRONG></FONT><BR>- Domain ownership transfer within 24 hours upon receipt of payment.<BR>- Payment Accept via <STRONG><FONT color=#ff0000>Paypal</FONT> </STRONG>only.</FONT></P></BLOCKQUOTE></BLOCKQUOTE></BLOCKQUOTE></BLOCKQUOTE>', 1, 'iNDIA', '1.00', '0.99', 5, '0.00', 'seller', 'open', '0', 'no', 'no', 0, 'yes', 'yes', 3, 0, '', 2, '0.00', '0.00');
INSERT INTO `zeeauctions_products` VALUES (4, 1, 'RIBBON ADS GENERATOR - LATEST BANNER AD TECHNOLOGY - RESELL ', 526, 3, '1', 'yes', 'yes', '2007-08-19 00:00:38', '2007-08-18 11:39:39', '0000-00-00 00:00:00', '<P align=center><SPAN style="FONT-SIZE: 10pt; FONT-FAMILY: Arial"><SPAN style="FONT-WEIGHT: 700; FONT-SIZE: 10pt; FONT-FAMILY: Arial">"Grab Your Visitors Attention, Explode Your Profits, And Practically Force Your Prospects To See Your Message With The Latest Eye Grabbing "Ribbon Ad" Technology ... Shown To Increase Click-Through Rates By Up To 817% Over Conventional Banner Ads"</SPAN></SPAN></P>\r\n<DIV>\r\n<TABLE width=520>\r\n<TBODY>\r\n<TR>\r\n<TD align=middle>\r\n<H2><SPAN style="FONT-SIZE: 12pt">You''ll learn exactly how to do it in just a few simple steps - even<BR>if you don''t know a single line of HTML code!</SPAN></H2></TD></TR></TBODY></TABLE></DIV>\r\n<DIV>\r\n<TABLE style="BORDER-RIGHT: black 2px dashed; BORDER-TOP: black 2px dashed; BORDER-LEFT: black 2px dashed; WIDTH: 346px; BORDER-BOTTOM: black 2px dashed; BORDER-COLLAPSE: collapse; HEIGHT: 58px" cellPadding=5 width=346 align=center bgColor=#ffffbc>\r\n<TBODY>\r\n<TR bgColor=#c0c0c0>\r\n<TD align=middle background=../WebCashMachine.com/Impact/images/order-bg.jpg bgColor=#ffffbc>\r\n<H1><SPAN style="FONT-SIZE: 10pt; COLOR: #dd0000; FONT-FAMILY: Arial">Order Now &amp; Get an Instant Upgrade to Master<BR>Resale Rights... Included For A Limited Time!</SPAN></H1></TD></TR></TBODY></TABLE></DIV>\r\n<P class=body><SPAN style="FONT-SIZE: 10pt; FONT-FAMILY: Arial">When somebody visits your website, you have about 3 seconds to grab their attention or they''re gone, and in all likelihood, they''ll never return again.</SPAN></P>\r\n<DIV class=body><SPAN style="FONT-SIZE: 10pt; FONT-FAMILY: Arial">You need something that instantly grabs their attention.&nbsp; In the wild west days of the internet, this was easy to do using popups.&nbsp; But according to a recent study, at least <B>86% of the visitors to your website have at least one pop-up blocker installed</B>.</SPAN></DIV>\r\n<DIV class=body>&nbsp;</DIV>\r\n<DIV class=body align=center><SPAN style="FONT-SIZE: 12pt; COLOR: #2f4f4f; FONT-FAMILY: Arial"><STRONG>"Ribbon Ads" Enter Thru The Back Door And Instantly Grab Attention Before Your Prospects Even Know About It!</STRONG></SPAN></DIV>\r\n<P align=center><SPAN style="FONT-SIZE: 14pt; COLOR: #0000cd; FONT-FAMILY: Arial"><STRONG><A title="Ribbon Ad Generator By Zeescripts.com" href="http://www.zeescripts.com/salespages/ribbonads/" target=_blank>Click Here For Full Details<BR></A></STRONG></SPAN></P>', 1111, 'India', '0.00', '7.00', 3, '0.00', 'seller', 'open', '0', 'no', 'no', 0, 'yes', 'yes', 3, 0, '', 2, '0.00', '0.00');

-- --------------------------------------------------------

-- 
-- Table structure for table `zeeauctions_purchased`
-- 

CREATE TABLE `zeeauctions_purchased` (
  `id` bigint(20) NOT NULL auto_increment,
  `pid` bigint(20) default NULL,
  `uid` bigint(20) default NULL,
  `quantity` bigint(20) default NULL,
  `date_submitted` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `email` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `zeeauctions_purchased`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `zeeauctions_ratings`
-- 

CREATE TABLE `zeeauctions_ratings` (
  `id` bigint(20) NOT NULL auto_increment,
  `sid` bigint(20) default NULL,
  `rating` int(11) default NULL,
  `ip` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `zeeauctions_ratings`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `zeeauctions_transactions`
-- 

CREATE TABLE `zeeauctions_transactions` (
  `id` bigint(20) NOT NULL auto_increment,
  `uid` bigint(20) default NULL,
  `amount` decimal(10,2) default NULL,
  `date_submitted` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `description` longtext,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

-- 
-- Dumping data for table `zeeauctions_transactions`
-- 

INSERT INTO `zeeauctions_transactions` VALUES (1, 1, '1.00', '2007-08-13 08:33:42', 'Sign Up Bonus');
INSERT INTO `zeeauctions_transactions` VALUES (2, 1, '100.00', '2007-08-13 08:43:01', 'Credit');
INSERT INTO `zeeauctions_transactions` VALUES (3, 1, '100.00', '2007-08-13 08:43:24', 'bonus');
INSERT INTO `zeeauctions_transactions` VALUES (4, 1, '-0.75', '2007-08-13 08:47:07', 'Uploaded product ''Test Auction''');
INSERT INTO `zeeauctions_transactions` VALUES (5, 1, '-1.00', '2007-08-13 08:47:07', 'Made Your Product ''Test Auction'' to be Appeared  as   Featured on Front Page');
INSERT INTO `zeeauctions_transactions` VALUES (6, 2, '100.00', '2007-08-18 11:26:47', 'Sign Up Bonus');
INSERT INTO `zeeauctions_transactions` VALUES (7, 2, '-0.75', '2007-08-18 11:29:45', 'Uploaded product ''EXIT POP-UP POPUP + PEEL AWAY ADS SOFTWARE -RESELL''');
INSERT INTO `zeeauctions_transactions` VALUES (8, 2, '-1.00', '2007-08-18 11:29:45', 'Made Your Product ''EXIT POP-UP POPUP + PEEL AWAY ADS SOFTWARE -RESELL'' to be Appeared as Featured');
INSERT INTO `zeeauctions_transactions` VALUES (9, 2, '-1.00', '2007-08-18 11:29:45', 'Made Your Product ''EXIT POP-UP POPUP + PEEL AWAY ADS SOFTWARE -RESELL'' to be Appeared  as   Featured on Front Page');
INSERT INTO `zeeauctions_transactions` VALUES (10, 2, '-1.80', '2007-08-18 11:29:45', 'Made Your Product ''EXIT POP-UP POPUP + PEEL AWAY ADS SOFTWARE -RESELL'' to be Appeared as Featured in Gallery ');
INSERT INTO `zeeauctions_transactions` VALUES (11, 1, '-0.50', '2007-08-18 11:34:33', 'Uploaded product ''uq7.com 3 LETTER CHARACTER .COM DOMAIN''');
INSERT INTO `zeeauctions_transactions` VALUES (12, 1, '-1.00', '2007-08-18 11:34:33', 'Made Your Product ''uq7.com 3 LETTER CHARACTER .COM DOMAIN'' to be Appeared as Featured');
INSERT INTO `zeeauctions_transactions` VALUES (13, 1, '-1.00', '2007-08-18 11:34:33', 'Made Your Product ''uq7.com 3 LETTER CHARACTER .COM DOMAIN'' to be Appeared  as   Featured on Front Page');
INSERT INTO `zeeauctions_transactions` VALUES (14, 1, '-1.80', '2007-08-18 11:34:33', 'Made Your Product ''uq7.com 3 LETTER CHARACTER .COM DOMAIN'' to be Appeared as Featured in Gallery ');
INSERT INTO `zeeauctions_transactions` VALUES (15, 1, '-0.75', '2007-08-18 11:39:39', 'Uploaded product ''RIBBON ADS GENERATOR - LATEST BANNER AD TECHNOLOGY - RESELL ''');
INSERT INTO `zeeauctions_transactions` VALUES (16, 1, '-1.00', '2007-08-18 11:39:39', 'Made Your Product ''RIBBON ADS GENERATOR - LATEST BANNER AD TECHNOLOGY - RESELL '' to be Appeared as Featured');
INSERT INTO `zeeauctions_transactions` VALUES (17, 1, '-1.00', '2007-08-18 11:39:39', 'Made Your Product ''RIBBON ADS GENERATOR - LATEST BANNER AD TECHNOLOGY - RESELL '' to be Appeared  as   Featured on Front Page');
INSERT INTO `zeeauctions_transactions` VALUES (18, 1, '-1.80', '2007-08-18 11:39:39', 'Made Your Product ''RIBBON ADS GENERATOR - LATEST BANNER AD TECHNOLOGY - RESELL '' to be Appeared as Featured in Gallery ');
