<?php
if ( !defined( 'SMARTY_DIR' ) ) {
	include_once( '../init.php' );
}
  
include( 'sessioninc.php' );

define( 'PAGE_ID', 'plugin_mgt' );

if ( ! checkAdminPermission( PAGE_ID ) ) {

	header( 'location: not_authorize.php' );
	exit;
}

// If a plugin is provided, time to process and display it's panel
// 
if ( isset($_REQUEST['plugin']) ) {

    $param['plugin'] = $_REQUEST['plugin'];
    
    $mod->modDisplayPluginAdminPage($param);

}


$t->display( 'admin/index.tpl' );

exit;

?>