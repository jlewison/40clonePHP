<?php
/**
 * Event category Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 02/01/2008
 */
class EventCategory extends controller
{
		function EventCategory()
		{
				parent::controller();
				//check login
				if ($this->session->userdata('admin_logged_in') != 1 && $this->session->userdata('admin_id') == '') redirect('admin/login');
				//Load the language file
				$this->lang->load('admin/eventCategory', $this->config->item('language_code'));
				$this->load->model('eventsmodel');
		}
		function index()
		{
				$this->load->library('validation');
				$this->_eventCategoryFrm();
				$outputData['addEventCategory'] = true;
				$outputData['editEventCategory'] = false;
				$outputData['eventsList'] = $this->eventsmodel->getEventMainCategory($status = '');
				if (!empty($outputData['eventsList'])) $outputData['eventsListArr'] = $outputData['eventsList'];
				else  $outputData['eventsListArr'] = false;
				if ($this->validation->run() == false) $outputData['validationError'] = $this->validation->error_string;
				else
				{
						if (isset($_POST['add_event_category']))
						{
								$this->eventsmodel->insertEventCategory($_POST);
								//Set the flash data
								$this->session->set_flashdata('successMsg', $this->lang->line('eventcategory_add_success_msg'));
								redirect('admin/eventCategory');
						}
				}
				$this->smartyextended->view('../admin/eventCategory', $outputData);
		}
		function _eventCategoryFrm()
		{
				$rules['event_category_name'] = 'trim|required|alphanumeric';
				$rules['event_category_description'] = 'trim|required|alphanumeric';
				$fields['event_category_name'] = $this->lang->line('eventcategory_category_name');
				$fields['event_category_description'] = $this->lang->line('eventcategory_description');
				$this->validation->set_rules($rules);
				$this->validation->set_fields($fields);
		}
		#***************************************************************************
		#Method			: editEventCategory
		#Description	: updates Event Category
		#Author			
		#***************************************************************************
		function editEventCategory()
		{
				$this->load->library('validation');
				$outputData['event_category_id'] = $this->uri->segment(4);
				$outputData['addEventCategory'] = false;
				$outputData['editEventCategory'] = true;
				$outputData['eventsList'] = $this->eventsmodel->getEventMainCategory($status = '');
				if (!empty($outputData['eventsList'])) $outputData['eventsListArr'] = $outputData['eventsList'];
				else  $outputData['eventsListArr'] = false;
				//$outputData['events'] = $this->eventsmodel->geteventCategory($status='');
				//echo '<pre>';
				//print_r($outputData['eventsList']); exit();
				$this->_eventCategoryFrm();
				if ($this->validation->run() == false) $outputData['validationError'] = $this->validation->error_string;
				else
				{
						if (isset($_POST['update_event_category']))
						{
								$this->eventsmodel->updateEventCategory($_POST);
								//Set the flash data
								$this->session->set_flashdata('successMsg', $this->lang->line('eventcategory_update_success_msg'));
								redirect('admin/eventCategory');
						}
				}
				$this->smartyextended->view('../admin/eventCategory', $outputData);
		}
}
?>