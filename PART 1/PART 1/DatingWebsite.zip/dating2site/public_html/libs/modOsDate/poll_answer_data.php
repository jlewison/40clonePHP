<?php

   class poll_answerData extends Data {

      var $table = POLL_ANSWER_TABLE;

      var $config = array (
  'table' => POLL_ANSWER_TABLE,
  'idField' => 'osdate_poll_answer_id',
  'addedMsg' => 'Osdate Poll Answer %s Added',
  'added_err' => 'Can\\\'t Add Osdate Poll Answer',
  'editMsg' => 'Osdate Poll Answer %s Updated',
  'editErr' => 'Can\\\'t Update Osdate Poll Answer',
  'delErr' => 'Can\\\'t Delete Osdate Poll Answer',
  'delMsg' => 'Osdate Poll Answer %s Deleted',
  'blankErr' => 'Osdate Poll Answer Empty',
  'fields' => 
  array (
    'id' => 
    array (
      'name' => 'id',
      'description' => 'Id',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'questionid' => 
    array (
      'name' => 'questionid',
      'description' => 'Questionid',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'userid' => 
    array (
      'name' => 'userid',
      'description' => 'Userid',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'optionid' => 
    array (
      'name' => 'optionid',
      'description' => 'Optionid',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
  ),
);   

      function poll_answerData() {
      
         $this->Data($this->config);
      }
   }

?>
