<?php

/**
 * Searchm Model
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 1/9/2008
 */
class Searchmodel extends Model
{
		//Constructor
		function Searchmodel()
		{
				parent::Model();
				//Load the user model
				$this->load->model('usermodel');
				//Load the user model
				$this->load->model('friendsmodel');
				$this->load->model('networkmodel');
		}
		function searchNetworks($suggest = '', $searchOnly = 'region', $orderBy = '', $start = '', $limit = '')
		{
				$this->db->from('networks');
				$this->db->join('country', 'networks.network_country = country.country_id', 'inner');
				$this->db->join('state_province', 'networks.network_state = state_province.state_id', 'left');
				$this->db->where('network_status', 'enabled');
				$this->db->where('(network_name LIKE \'%' . addslashes($suggest) . '%\' OR `network_city` LIKE \'%' . addslashes($suggest) . '%\' OR `country_name` LIKE \'%' . addslashes($suggest) . '%\' OR `state_name` LIKE \'%' . addslashes($suggest) . '%\')');
				//$this->db->like('network_name', $suggest);
				//		$this->db->or_like('network_city', $suggest);
				//		$this->db->or_like('country_name', $suggest);
				//		$this->db->or_like('state_name', $suggest);
				//		$this->db->where(')');
				if (trim($orderBy) != '') $this->db->order_by($orderBy);
				if (trim($limit) != '' && is_numeric($limit))
				{
						if (trim($start) != '' && is_numeric($start)) $this->db->limit($limit, $start);
						else  $this->db->limit($limit);
				}
				$resultQuery = $this->db->get();
				//echo $this->db->last_query();
				$result = array();
				if ($resultQuery->num_rows() > 0)
				{
						foreach ($resultQuery->result_array() as $resultRow)
						{
								$result[$resultRow['network_id']] = $resultRow;
								$isNetworkMember = $this->networkmodel->isUserExist($resultRow['network_id'], $this->session->userdata('user_id'));
								$result[$resultRow['network_id']]['is_joined'] = $isNetworkMember;
						}
				}
				return $result;
		}
		function searchNetworksCount($suggest = '')
		{
				$this->db->from('networks');
				$this->db->join('country', 'networks.network_country = country.country_id', 'inner');
				$this->db->join('state_province', 'networks.network_state = state_province.state_id', 'left');
				$this->db->where('network_status', 'enabled');
				$this->db->where('(network_name LIKE \'%' . addslashes($suggest) . '%\' OR `network_city` LIKE \'%' . addslashes($suggest) . '%\' OR `country_name` LIKE \'%' . addslashes($suggest) . '%\' OR `state_name` LIKE \'%' . addslashes($suggest) . '%\')');
				//		$this->db->like('network_name', $suggest);
				//		$this->db->or_like('network_city', $suggest);
				//		$this->db->or_like('country_name', $suggest);
				//		$this->db->or_like('state_name', $suggest);
				return $this->db->count_all_results();
		}
		function searchPeoples($suggest = '', $orderBy = '', $start = '', $limit = '', $includeMe = false, $includeBlocked = false, $friendsOnTop = false, $networkId = '')
		{
				$networkQuery = '';
				if (trim($networkId) != '') $networkQuery = ' users.user_id IN (SELECT user_id FROM network_users WHERE network_id IN (' . $networkId . ')) ';
				$blockedUserIds = '';
				if ($includeBlocked == false) $blockedUsers = array_keys($this->usermodel->getBlockedUsers());
				//dont include me in the search results
				if ($includeMe == false) $blockedUsers[] = $this->session->userdata('user_id');
				if (is_array($blockedUsers) && count($blockedUsers) > 0) $blockedUserIds = '\'' . implode('\',\'', $blockedUsers) . '\'';
				$profileIds = '';
				$friends = $this->usermodel->getFriends('', false);
				if (count($friends) > 0) $friends = array_keys($friends);
				if (is_array($friends) && count($friends) > 0) $profileIds = '\'' . implode('\',\'', $friends) . '\'';
				$networkIds = '';
				$userNetworks = $this->usermodel->getUserNetworks();
				if (count($userNetworks) > 0) $userNetworks = array_keys($userNetworks);
				if (is_array($userNetworks) && count($userNetworks) > 0) $networkIds = '\'' . implode('\',\'', $userNetworks) . '\'';
				$profileSQL = ($profileIds != '') ? ' OR search_profile.search_profile IN (' . $profileIds . ')' : '';
				$networkSQL = ($networkIds != '') ? ' OR search_profile.search_network IN (' . $networkIds . ')' : '';
				$isUserInRegionNetwork = ($this->usermodel->isUserInNetwork('region')) ? ' OR search_profile.regional_network=1 ' : '';
				$isUserInWorkNetwork = ($this->usermodel->isUserInNetwork('work')) ? ' OR search_profile.company_network=1 ' : '';
				$isUserInCollegeNetwork = ($this->usermodel->isUserInNetwork('college')) ? ' OR search_profile.college_network=1 ' : '';
				$isUserInSchoolNetwork = ($this->usermodel->isUserInNetwork('school')) ? ' OR search_profile.school_network=1 ' : '';
				$isUserInNonetwork = ($isUserInRegionNetwork == false && $isUserInWorkNetwork == false && $isUserInCollegeNetwork == false && $isUserInSchoolNetwork == false) ? ' OR search_profile.no_network=1 ' : '';
				$userSearchSetting = $this->usermodel->getUserSearchSetting();
				$this->db->select('users.user_id, users.username, users.avatar_ext');
				$this->db->from('users');
				if (trim($networkId) != '') $this->db->join('network_users', 'users.user_id = network_users.user_id AND network_users.network_id IN (' . $networkId . ')', 'INNER');
				$this->db->join('search_profile', 'users.user_id = search_profile.user_id', 'LEFT');
				$this->db->where('users.user_status', 'active');
				if (trim($networkId) != '') $this->db->where($networkQuery);
				$this->db->like('users.username', $suggest);
				$this->db->where_not_in('users.user_id', $blockedUsers);
				$this->db->where('(
						search_profile.search_profile IS NULL ' . $profileSQL . ' OR
						search_profile.search_network IS NULL ' . $networkSQL . $isUserInRegionNetwork . $isUserInWorkNetwork . $isUserInCollegeNetwork . $isUserInSchoolNetwork . $isUserInNonetwork . '
					)');
				if (trim($orderBy) != '') $this->db->order_by('users.' . $orderBy);
				if (trim($limit) != '' && is_numeric($limit))
				{
						if (trim($start) != '' && is_numeric($start)) $this->db->limit($limit, $start);
						else  $this->db->limit($limit);
				}
				//Get the rows
				$friendsQuery = $this->db->get();
				$friends = array();
				$userNetworks = $this->usermodel->getUserNetworks();
				if ($friendsQuery->num_rows() > 0)
				{
						foreach ($friendsQuery->result_array() as $friendsRow)
						{
								$friendsRow['searchSetting'] = $this->usermodel->getUserSearchSetting($friendsRow['user_id']);
								$userAvatar = getAvatar($friendsRow['user_id'], $friendsRow['avatar_ext'], 'thumb');
								$friendsRow['avatar'] = $userAvatar;
								//get the user network
								$userNetworks = $this->usermodel->getUserNetworks($friendsRow['user_id'], 'datestamp', '', 0, 1);
								$network = array_pop($userNetworks);
								$friendsRow['network'] = $network;
								$friendsRow['isFriend'] = $this->usermodel->isFriend($friendsRow['user_id']);
								$friends[$friendsRow['user_id']] = $friendsRow;
						}
				}
				return $friends;
		}
		function searchPeoplesCount($suggest = '', $includeMe = false, $includeBlocked = false, $friendsOnTop = true, $networkId = '')
		{
				$networkQuery = '';
				if (trim($networkId) != '') $networkQuery = ' users.user_id IN (SELECT user_id FROM network_users WHERE network_id IN (' . $networkId . ')) ';
				$blockedUserIds = '';
				if ($includeBlocked == false) $blockedUsers = array_keys($this->usermodel->getBlockedUsers());
				//dont include me in the search results
				if ($includeMe == false) $blockedUsers[] = $this->session->userdata('user_id');
				if (is_array($blockedUsers) && count($blockedUsers) > 0) $blockedUserIds = '\'' . implode('\',\'', $blockedUsers) . '\'';
				$profileIds = '';
				$friends = $this->usermodel->getFriends('', false);
				if (count($friends) > 0) $friends = array_keys($friends);
				if (is_array($friends) && count($friends) > 0) $profileIds = '\'' . implode('\',\'', $friends) . '\'';
				$networkIds = '';
				$userNetworks = $this->usermodel->getUserNetworks();
				if (count($userNetworks) > 0) $userNetworks = array_keys($userNetworks);
				if (is_array($userNetworks) && count($userNetworks) > 0) $networkIds = '\'' . implode('\',\'', $userNetworks) . '\'';
				$profileSQL = ($profileIds != '') ? ' OR search_profile.search_profile IN (' . $profileIds . ')' : '';
				$networkSQL = ($networkIds != '') ? ' OR search_profile.search_network IN (' . $networkIds . ')' : '';
				$isUserInRegionNetwork = ($this->usermodel->isUserInNetwork('region')) ? ' OR search_profile.regional_network=1 ' : '';
				$isUserInWorkNetwork = ($this->usermodel->isUserInNetwork('work')) ? ' OR search_profile.company_network=1 ' : '';
				$isUserInCollegeNetwork = ($this->usermodel->isUserInNetwork('college')) ? ' OR search_profile.college_network=1 ' : '';
				$isUserInSchoolNetwork = ($this->usermodel->isUserInNetwork('school')) ? ' OR search_profile.school_network=1 ' : '';
				$isUserInNonetwork = ($isUserInRegionNetwork == false && $isUserInWorkNetwork == false && $isUserInCollegeNetwork == false && $isUserInSchoolNetwork == false) ? ' OR search_profile.no_network=1 ' : '';
				$this->db->select('count(users.user_id) as cnt');
				$this->db->from('users');
				if (trim($networkId) != '') $this->db->join('network_users', 'users.user_id = network_users.user_id AND network_users.network_id IN (' . $networkId . ')', 'INNER');
				$this->db->join('search_profile', 'users.user_id = search_profile.user_id', 'LEFT');
				$this->db->where('users.user_status', 'active');
				if (trim($networkId) != '') $this->db->where($networkQuery);
				$this->db->like('users.username', $suggest);
				$this->db->where_not_in('users.user_id', $blockedUsers);
				$this->db->where('(
						search_profile.search_profile IS NULL ' . $profileSQL . ' OR
						search_profile.search_network IS NULL ' . $networkSQL . $isUserInRegionNetwork . $isUserInWorkNetwork . $isUserInCollegeNetwork . $isUserInSchoolNetwork . $isUserInNonetwork . '
					)');
				$friendsQuery = $this->db->get();
				if ($friendsQuery->num_rows() > 0)
				{
						$friendsRow = $friendsQuery->result_array();
						return $friendsRow[0]['cnt'];
				}
				else  return 0;
		}
		function searchEvents($suggest = '', $orderBy = '', $start = '', $limit = '')
		{
				$this->db->from('events');
				$this->db->where('event_status', 'ok');
				$this->db->where('((event_type != \'SECRET\' AND event_publicize = \'yes\') OR user_id=' . $this->session->userdata('user_id') . ')');
				$this->db->like('event_name', $suggest);
				$this->db->or_like('event_description', $suggest);
				if (trim($orderBy) != '') $this->db->order_by($orderBy);
				if (trim($limit) != '' && is_numeric($limit))
				{
						if (trim($start) != '' && is_numeric($start)) $this->db->limit($limit, $start);
						else  $this->db->limit($limit);
				}
				$eventsQuery = $this->db->get();
				$events = array();
				if ($eventsQuery->num_rows() > 0)
				{
						foreach ($eventsQuery->result_array() as $eventsRow)
						{
								$eventAvatar = base_url() . 'application/content/events/' . $eventsRow['event_id'] . '_thumb' . '.' . $eventsRow['event_photo_path'];
								if (!file_exists(APPPATH . 'content/events/' . $eventsRow['event_id'] . '_thumb.' . $eventsRow['event_photo_path'])) $eventAvatar = base_url() . 'application/images/default_avatar.jpg';
								$eventsRow['avatar'] = $eventAvatar;
								$events[$eventsRow['event_id']] = $eventsRow;
						}
				}
				return $events;
		}
		function searchEventsCount($suggest = '')
		{
				$this->db->from('events');
				$this->db->where('event_status', 'ok');
				$this->db->where('((event_type != \'SECRET\' AND event_publicize = \'yes\') OR user_id=' . $this->session->userdata('user_id') . ')');
				$this->db->like('event_name', $suggest);
				$this->db->or_like('event_description', $suggest);
				return $this->db->count_all_results();
		}
		function searchGroups($suggest = '', $orderBy = '', $start = '', $limit = '')
		{
				$this->db->from('groups');
				$this->db->where('group_status', 'ok');
				$this->db->where('((group_type != \'SECRET\' AND group_publicize = \'yes\') OR user_id=' . $this->session->userdata('user_id') . ')');
				$this->db->like('group_name', $suggest);
				$this->db->or_like('group_description', $suggest);
				if (trim($orderBy) != '') $this->db->order_by($orderBy);
				if (trim($limit) != '' && is_numeric($limit))
				{
						if (trim($start) != '' && is_numeric($start)) $this->db->limit($limit, $start);
						else  $this->db->limit($limit);
				}
				$groupsQuery = $this->db->get();
				$groups = array();
				if ($groupsQuery->num_rows() > 0)
				{
						foreach ($groupsQuery->result_array() as $groupsRow)
						{
								$groupAvatar = base_url() . 'application/content/groups/' . $groupsRow['group_id'] . '_thumb' . '.' . $groupsRow['group_photo_path'];
								if (!file_exists(APPPATH . 'content/groups/' . $groupsRow['group_id'] . '_thumb.' . $groupsRow['group_photo_path'])) $groupAvatar = base_url() . 'application/images/default_avatar.jpg';
								$groupsRow['avatar'] = $groupAvatar;
								$groups[$groupsRow['group_id']] = $groupsRow;
						}
				}
				return $groups;
		}
		function searchgroupsCount($suggest = '')
		{
				$this->db->from('groups');
				$this->db->where('group_status', 'ok');
				$this->db->where('((group_type != \'SECRET\' AND group_publicize = \'yes\') OR user_id=' . $this->session->userdata('user_id') . ')');
				$this->db->like('group_name', $suggest);
				$this->db->or_like('group_description', $suggest);
				return $this->db->count_all_results();
		}
		#***************************************************************************
		#Method			: searchContactProfile
		#Description	: fetches user ids for the maching search from contact profile
		#Author
		#***************************************************************************
		function searchContactProfile($user_ids, $data)
		{
				$orArray = array('city' => $data['search_city'], 'state_province' => $data['search_contact_state'], 'country' => $data['search_contact_country'], 'zip_code' => $data['search_zip']);
				$this->db->select('user_id');
				$this->db->from('profile_contact');
				$this->db->where('user_id IN (' . $user_ids . ')');
				$this->db->or_like($orArray);
				$searchContactProfileQuery = $this->db->get();
				if ($searchContactProfileQuery->num_rows() > 0)
				{
						foreach ($searchContactProfileQuery->result_array() as $row)
						{
								$contactProfile[] = $row['user_id'];
						}
						return $contactProfile;
				}
				else  return false;
		}
		#***************************************************************************
		#Method			: searchPersonalProfile
		#Description	: fetches user ids for the maching search from personal profile
		#Author
		#***************************************************************************
		function searchPersonalProfile($user_ids, $data)
		{
				$orArray = array('activities' => $data['search_activities'], 'favorite_tv_shows' => $data['search_tv_show'], 'interests' => $data['search_interest'], 'favorite_movies' => $data['search_movie'], 'favorite_music' => $data['search_music'], 'favorite_books' => $data['search_book']);
				$this->db->select('user_id');
				$this->db->from('profile_personal');
				$this->db->where('user_id IN (' . $user_ids . ')');
				$this->db->or_like($orArray);
				$searchPersonalProfileQuery = $this->db->get();
				if ($searchPersonalProfileQuery->num_rows() > 0)
				{
						foreach ($searchPersonalProfileQuery->result_array() as $row)
						{
								$personalProfile[] = $row['user_id'];
						}
						return $personalProfile;
				}
				else  return false;
		}
		#***************************************************************************
		#Method			: searchHighSchoolProfile
		#Description	: fetches user ids for the maching search from education profile
		#Author
		#***************************************************************************
		function searchHighSchoollProfile($user_ids, $data)
		{
				$this->db->select('user_id');
				$this->db->from('profile_education');
				$this->db->where('user_id IN (' . $user_ids . ')');
				$this->db->like('high_school', $data['search_school']);
				$searchSchoolProfileQuery = $this->db->get();
				if ($searchSchoolProfileQuery->num_rows() > 0)
				{
						foreach ($searchSchoolProfileQuery->result_array() as $row)
						{
								$schoolProfile[] = $row['user_id'];
						}
						return $schoolProfile;
				}
				else  return false;
		}
		#***************************************************************************
		#Method			: searchCollegeProfile
		#Description	: fetches user ids for the maching search from college profile
		#Author
		#***************************************************************************
		function searchCollegeProfile($user_ids, $data)
		{
				$orArray = array('college_name' => $data['search_college'], 'concentration1' => $data['search_concentration'], 'concentration2' => $data['search_concentration'], 'concentration3' => $data['search_concentration'], 'class_year' => $data['search_college_Year']);
				$this->db->select('user_id');
				$this->db->from('school_education');
				$this->db->where('user_id IN (' . $user_ids . ')');
				$this->db->or_like($orArray);
				$searchCollegeProfileQuery = $this->db->get();
				if ($searchCollegeProfileQuery->num_rows() > 0)
				{
						foreach ($searchCollegeProfileQuery->result_array() as $row)
						{
								$collegeProfile[] = $row['user_id'];
						}
						return $collegeProfile;
				}
				else  return false;
		}
		#***************************************************************************
		#Method			: searchWorkProfile
		#Description	: fetches user ids for the maching search from work profile
		#Author
		#***************************************************************************
		function searchWorkProfile($user_ids, $data)
		{
				$orArray = array('employer' => $data['search_company'], 'position' => $data['search_position']);
				$this->db->select('user_id');
				$this->db->from('profile_work');
				$this->db->where('user_id IN (' . $user_ids . ')');
				$this->db->or_like($orArray);
				$searchWorkProfileQuery = $this->db->get();
				if ($searchWorkProfileQuery->num_rows() > 0)
				{
						foreach ($searchWorkProfileQuery->result_array() as $row)
						{
								$workProfile[] = $row['user_id'];
						}
						return $workProfile;
				}
				else  return false;
		}
		#***************************************************************************
		#Method			: searchProfile
		#Description	: fetches users for the maching search from all profile
		#Author
		#***************************************************************************
		function searchProfile($data, $orderBy = '', $start = '', $limit = '')
		{
				$suggest = '';
				$includeMe = false;
				$includeBlocked = false;
				$blockedUserIds = '';
				if ($includeBlocked == false) $blockedUsers = array_keys($this->usermodel->getBlockedUsers());
				//dont include me in the search results
				if ($includeMe == false) $blockedUsers[] = $this->session->userdata('user_id');
				if (is_array($blockedUsers) && count($blockedUsers) > 0) $blockedUserIds = '\'' . implode('\',\'', $blockedUsers) . '\'';
				if ($data['searchIn'] == 0)
				{
						// friends
						$profileIds = '';
						$friends = $this->usermodel->getFriends('', false);
						if (count($friends) > 0) $friends = array_keys($friends);
						//networks
						$networkIds = '';
						$networkUserIds = '';
						$networkUsers = array();
						$userNetworks = $this->usermodel->getUserNetworks();
						if (count($userNetworks) > 0) $userNetworks = array_keys($userNetworks);
						if (is_array($userNetworks) && count($userNetworks) > 0) $networkIds = '\'' . implode('\',\'', $userNetworks) . '\'';
						//$networkUsers	= $this->usermodel->getUsersInNetworks($networkIds);
						$profileUsers = array_unique(array_merge($friends, $userNetworks));
						if (is_array($profileUsers) && count($profileUsers) > 0)
						{
								$profileIds = '\'' . implode('\',\'', $profileUsers) . '\'';
						}
						//if (!empty($networkIds))
						//$networkUserIds = '\'' . implode('\',\'', array_unique($networkUsers)) . '\'';
						$profileSQL = ($profileIds != '') ? ' OR (search_profile.search_profile IN (' . $profileIds . ')  AND users.user_id IN (' . $profileIds . ')) ' : '';
						//$networkSQL	= ($networkIds != '') ? ' OR search_profile.search_network IN (' . $networkIds . ')' : '';
				}
				else
				{
						//$profileSQL	= '';
						$profileIds = '';
						$networkIds = $data['searchIn'];
						//$networkSQL	= ($networkIds != '') ? ' OR search_profile.search_network IN (' . $networkIds . ')' : '';
						$networkUsers = $this->usermodel->getUsersInNetworks($networkIds);
						if (!empty($networkUsers))
						{
								$profileUsers = array_unique($networkUsers);
								$profileIds = '\'' . implode('\',\'', $profileUsers) . '\'';
						}
						$profileSQL = ($profileIds != '') ? ' OR (search_profile.search_profile IN (' . $profileIds . ')  AND users.user_id IN (' . $profileIds . ')) ' : '';
				}
				$this->db->select('users.user_id, users.username, users.avatar_ext');
				$this->db->from('users');
				$this->db->join('search_profile', 'users.user_id = search_profile.user_id', 'left');
				$this->db->where('users.user_status=\'active\'');
				if ($profileSQL != '') $this->db->where('users.user_id IN (' . $profileIds . ')');
				//$this->db->like('users.username',$suggest);
				$this->db->where('users.user_id NOT IN (' . $blockedUserIds . ')');
				$this->db->where('search_profile.search_profile IS NULL ' . $profileSQL . '');
				if (!empty($data['looking_for_id']))
				{
						$looking_for_id = implode(',', array_keys($data['looking_for_id']));
						$this->db->join('looking_for_map', 'users.user_id = looking_for_map.basic_profile_id', 'left');
						$this->db->where('looking_for_map.looking_id IN (' . $looking_for_id . ')');
				}
				// search for username
				if ($data['search_name']) $this->db->like('users.username', $data['search_name']);
				// search for user email
				if ($data['search_email']) $this->db->like('users.email', $data['search_email']);
				// search for screen name
				if ($data['search_screen_name'])
				{
						$this->db->join('screens', 'users.user_id = screens.user_id', 'left');
						$this->db->like('screens.screen_name', $data['search_screen_name']);
				}
				// basic profile search condition
				if ($data['search_interest'] || $data['search_sex'] || $data['search_relationship_status'] || $data['search_home_town'] || $data['search_political_views'] || $data['name_religious_view'])
				{
						$this->db->join('profile_basic', 'users.user_id = profile_basic.user_id', 'left');
						if ($data['search_interest']) $this->db->or_like('profile_basic.interested_in', $data['search_interest']);
						if ($data['search_sex']) $this->db->or_like('profile_basic.sex', $data['search_sex']);
						if ($data['search_relationship_status']) $this->db->or_like('profile_basic.relation_id', $data['search_relationship_status']);
						if ($data['search_home_town']) $this->db->or_like('profile_basic.hometown', $data['search_home_town']);
						if ($data['search_political_views']) $this->db->or_like('profile_basic.political_id', $data['search_political_views']);
						if ($data['name_religious_view']) $this->db->or_like('profile_basic.religious_view', $data['name_religious_view']);
				}
				// contact profile search condition
				if ($data['search_city'] || $data['search_contact_state'] || $data['search_mobile'] || $data['search_contact_country'] || $data['search_land_phone'] || $data['search_zip'])
				{
						$this->db->join('profile_contact', 'users.user_id = profile_contact.user_id', 'left');
						if ($data['search_city']) $this->db->or_like('profile_contact.city', $data['search_city']);
						if ($data['search_contact_state']) $this->db->or_like('profile_contact.state_province', $data['search_contact_state']);
						if ($data['search_mobile']) $this->db->or_like('profile_contact.mobile', $data['search_mobile']);
						if ($data['search_contact_country']) $this->db->or_like('profile_contact.country', $data['search_contact_country']);
						if ($data['search_land_phone']) $this->db->or_like('profile_contact.land_line', $data['search_land_phone']);
						if ($data['search_zip']) $this->db->or_like('profile_contact.zip_code', $data['search_zip']);
				}
				// personal profile search condition
				if ($data['search_activities'] || $data['search_tv_show'] || $data['search_interest'] || $data['search_movie'] || $data['search_music'] || $data['search_book'])
				{
						$this->db->join('profile_personal', 'users.user_id = profile_personal.user_id', 'left');
						if ($data['search_activities']) $this->db->or_like('profile_personal.activities', $data['search_activities']);
						if ($data['search_tv_show']) $this->db->or_like('profile_personal.favorite_tv_shows', $data['search_tv_show']);
						if ($data['search_interest']) $this->db->or_like('profile_personal.interests', $data['search_interest']);
						if ($data['search_movie']) $this->db->or_like('profile_personal.favorite_movies', $data['search_movie']);
						if ($data['search_music']) $this->db->or_like('profile_personal.favorite_music', $data['search_music']);
						if ($data['search_book']) $this->db->or_like('profile_personal.favorite_books', $data['search_book']);
				}
				// high school profile search condition
				if ($data['search_school'])
				{
						$this->db->join('profile_education', 'users.user_id = profile_education.user_id', 'left');
						if ($data['search_city']) $this->db->or_like('profile_education.high_school', $data['search_school']);
				}
				// education search condition
				if ($data['search_concentration'] || $data['search_college_Year'] || $data['search_college'])
				{
						$this->db->join('school_education', 'users.user_id = school_education.user_id', 'left');
						if ($data['search_concentration'])
						{
								$concentrations = array('school_education.concentration1' => $data['search_concentration'], 'school_education.concentration2' => $data['search_concentration'], 'school_education.concentration3' => $data['search_concentration']);
								$this->db->or_like($concentrations);
						}
						if ($data['search_college_Year']) $this->db->where('school_education.class_year', $data['search_college_Year']);
						if ($data['search_college']) $this->db->or_like('school_education.college_name', $data['search_college']);
				}
				// work search condition
				if ($data['search_company'] || $data['search_position'])
				{
						$this->db->join('profile_work', 'users.user_id = profile_work.user_id', 'left');
						if ($data['search_company']) $this->db->or_like('profile_work.employer', $data['search_company']);
						if ($data['search_position']) $this->db->or_like('profile_work.position', $data['search_position']);
				}
				if (trim($orderBy) != '') $this->db->orderby('users.' . $orderBy, "desc");
				if (trim($limit) != '' && is_numeric($limit))
				{
						if (trim($start) != '' && is_numeric($start)) $this->db->limit($limit, $start);
						else  $this->db->limit($limit);
				}
				$searchProfileQuery = $this->db->get();
				if ($searchProfileQuery->num_rows() > 0)
				{
						foreach ($searchProfileQuery->result_array() as $userrow)
						{
								$userrow['searchSetting'] = $this->usermodel->getUserSearchSetting($userrow['user_id']);
								$userAvatar = getAvatar($userrow['user_id'], $userrow['avatar_ext'], 'thumb');
								$userrow['avatar'] = $userAvatar;
								//get the user network
								$userNetworks = $this->usermodel->getUserNetworks($userrow['user_id'], 'datestamp', '', 0, 1);
								$network = array_pop($userNetworks);
								$userrow['network'] = $network;
								$userrow['isFriend'] = $this->usermodel->isFriend($userrow['user_id']);
								$users[$userrow['user_id']] = $userrow;
						}
						return $users;
				}
				else  return false;
		}
		#***************************************************************************
		#Method			: searchProfileCount
		#Description	: fetches users count for the maching search from all profile
		#Author
		#***************************************************************************
		function searchProfileCount($data, $orderBy = '', $start = 0, $limit = 0)
		{
				$suggest = '';
				$includeMe = false;
				$includeBlocked = false;
				$blockedUserIds = '';
				if ($includeBlocked == false) $blockedUsers = array_keys($this->usermodel->getBlockedUsers());
				//dont include me in the search results
				if ($includeMe == false) $blockedUsers[] = $this->session->userdata('user_id');
				if (is_array($blockedUsers) && count($blockedUsers) > 0) $blockedUserIds = '\'' . implode('\',\'', $blockedUsers) . '\'';
				if ($data['searchIn'] == 0)
				{
						// friends
						$profileIds = '';
						$friends = $this->usermodel->getFriends('', false);
						if (count($friends) > 0) $friends = array_keys($friends);
						//networks
						$networkIds = '';
						$networkUserIds = '';
						$networkUsers = array();
						$userNetworks = $this->usermodel->getUserNetworks();
						if (count($userNetworks) > 0) $userNetworks = array_keys($userNetworks);
						if (is_array($userNetworks) && count($userNetworks) > 0) $networkIds = '\'' . implode('\',\'', $userNetworks) . '\'';
						//$networkUsers	= $this->usermodel->getUsersInNetworks($networkIds);
						$profileUsers = array_unique(array_merge($friends, $userNetworks));
						if (is_array($profileUsers) && count($profileUsers) > 0)
						{
								$profileIds = '\'' . implode('\',\'', $profileUsers) . '\'';
						}
						//if (!empty($networkIds))
						//$networkUserIds = '\'' . implode('\',\'', array_unique($networkUsers)) . '\'';
						$profileSQL = ($profileIds != '') ? ' OR (search_profile.search_profile IN (' . $profileIds . ')  AND users.user_id IN (' . $profileIds . ')) ' : '';
						//$networkSQL	= ($networkIds != '') ? ' OR search_profile.search_network IN (' . $networkIds . ')' : '';
				}
				else
				{
						//$profileSQL	= '';
						$profileIds = '';
						$networkIds = $data['searchIn'];
						//$networkSQL	= ($networkIds != '') ? ' OR search_profile.search_network IN (' . $networkIds . ')' : '';
						$networkUsers = $this->usermodel->getUsersInNetworks($networkIds);
						if (!empty($networkUsers))
						{
								$profileUsers = array_unique($networkUsers);
								$profileIds = '\'' . implode('\',\'', $profileUsers) . '\'';
						}
						$profileSQL = ($profileIds != '') ? ' OR (search_profile.search_profile IN (' . $profileIds . ')  AND users.user_id IN (' . $profileIds . ')) ' : '';
				}
				$this->db->select('users.user_id, users.username, users.avatar_ext');
				$this->db->from('users');
				$this->db->join('search_profile', 'users.user_id = search_profile.user_id', 'left');
				$this->db->where('users.user_status=\'active\'');
				if ($profileSQL != '') $this->db->where('users.user_id IN (' . $profileIds . ')');
				$this->db->where('users.user_id NOT IN (' . $blockedUserIds . ')');
				$this->db->where('search_profile.search_profile IS NULL ' . $profileSQL . ' ');
				if (!empty($data['looking_for_id']))
				{
						$looking_for_id = implode(',', array_keys($data['looking_for_id']));
						$this->db->join('looking_for_map', 'users.user_id = looking_for_map.basic_profile_id', 'left');
						$this->db->where('looking_for_map.looking_id IN (' . $looking_for_id . ')');
				}
				// search for username
				if ($data['search_name']) $this->db->like('users.username', $data['search_name']);
				// search for user email
				if ($data['search_email']) $this->db->like('users.email', $data['search_email']);
				// search for screen name
				if ($data['search_screen_name'])
				{
						$this->db->join('screens', 'users.user_id = screens.user_id', 'left');
						$this->db->like('screens.screen_name', $data['search_screen_name']);
				}
				// basic profile search condition
				if ($data['search_interest'] || $data['search_sex'] || $data['search_relationship_status'] || $data['search_home_town'] || $data['search_political_views'] || $data['name_religious_view'])
				{
						$this->db->join('profile_basic', 'users.user_id = profile_basic.user_id', 'left');
						if ($data['search_interest']) $this->db->or_like('profile_basic.interested_in', $data['search_interest']);
						if ($data['search_sex']) $this->db->or_like('profile_basic.sex', $data['search_sex']);
						if ($data['search_relationship_status']) $this->db->or_like('profile_basic.relation_id', $data['search_relationship_status']);
						if ($data['search_home_town']) $this->db->or_like('profile_basic.hometown', $data['search_home_town']);
						if ($data['search_political_views']) $this->db->or_like('profile_basic.political_id', $data['search_political_views']);
						if ($data['name_religious_view']) $this->db->or_like('profile_basic.religious_view', $data['name_religious_view']);
				}
				// contact profile search condition
				if ($data['search_city'] || $data['search_contact_state'] || $data['search_mobile'] || $data['search_contact_country'] || $data['search_land_phone'] || $data['search_zip'])
				{
						$this->db->join('profile_contact', 'users.user_id = profile_contact.user_id', 'left');
						if ($data['search_city']) $this->db->or_like('profile_contact.city', $data['search_city']);
						if ($data['search_contact_state']) $this->db->or_like('profile_contact.state_province', $data['search_contact_state']);
						if ($data['search_mobile']) $this->db->or_like('profile_contact.mobile', $data['search_mobile']);
						if ($data['search_contact_country']) $this->db->or_like('profile_contact.country', $data['search_contact_country']);
						if ($data['search_land_phone']) $this->db->or_like('profile_contact.land_line', $data['search_land_phone']);
						if ($data['search_zip']) $this->db->or_like('profile_contact.zip_code', $data['search_zip']);
				}
				// personal profile search condition
				if ($data['search_activities'] || $data['search_tv_show'] || $data['search_interest'] || $data['search_movie'] || $data['search_music'] || $data['search_book'])
				{
						$this->db->join('profile_personal', 'users.user_id = profile_personal.user_id', 'left');
						if ($data['search_activities']) $this->db->or_like('profile_personal.activities', $data['search_activities']);
						if ($data['search_tv_show']) $this->db->or_like('profile_personal.favorite_tv_shows', $data['search_tv_show']);
						if ($data['search_interest']) $this->db->or_like('profile_personal.interests', $data['search_interest']);
						if ($data['search_movie']) $this->db->or_like('profile_personal.favorite_movies', $data['search_movie']);
						if ($data['search_music']) $this->db->or_like('profile_personal.favorite_music', $data['search_music']);
						if ($data['search_book']) $this->db->or_like('profile_personal.favorite_books', $data['search_book']);
				}
				// high school profile search condition
				if ($data['search_school'])
				{
						$this->db->join('profile_education', 'users.user_id = profile_education.user_id', 'left');
						if ($data['search_city']) $this->db->or_like('profile_education.high_school', $data['search_school']);
				}
				// education search condition
				if ($data['search_concentration'] || $data['search_college_Year'] || $data['search_college'])
				{
						$this->db->join('school_education', 'users.user_id = school_education.user_id', 'left');
						if ($data['search_concentration'])
						{
								$concentrations = array('school_education.concentration1' => $data['search_concentration'], 'school_education.concentration2' => $data['search_concentration'], 'school_education.concentration3' => $data['search_concentration']);
								$this->db->or_like($concentrations);
						}
						if ($data['search_college_Year']) $this->db->where('school_education.class_year', $data['search_college_Year']);
						if ($data['search_college']) $this->db->or_like('school_education.college_name', $data['search_college']);
				}
				// work search condition
				if ($data['search_company'] || $data['search_position'])
				{
						$this->db->join('profile_work', 'users.user_id = profile_work.user_id', 'left');
						if ($data['search_company']) $this->db->or_like('profile_work.employer', $data['search_company']);
						if ($data['search_position']) $this->db->or_like('profile_work.position', $data['search_position']);
				}
				//$searchProfileQuery = $this->db->get();
				return $this->db->count_all_results();
				//return $searchProfileQuery->num_rows();
		}
		function searchFriends($suggest = '', $orderBy = 'last_modified desc', $start = '', $limit = '')
		{
				$friendsList = array();
				$friends = $this->friendsmodel->getFriends($this->session->userdata('user_id'));
				if (is_array($friends) && count($friends) > 0)
				{
						$this->db->from('users');
						$this->db->where_in('user_id', $friends);
						if (trim($suggest) != '') $this->db->like('username', $suggest);
						if (trim($orderBy) != '') $this->db->order_by($orderBy);
						if (trim($limit) != '' && is_numeric($limit))
						{
								if (trim($start) != '' && is_numeric($start)) $this->db->limit($limit, $start);
								else  $this->db->limit($limit);
						}
						$friendsQuery = $this->db->get();
						//echo $this->db->last_query();
						if ($friendsQuery->num_rows() > 0)
						{
								foreach ($friendsQuery->result_array() as $friendsRow)
								{
										$friendsRow['searchSetting'] = $this->usermodel->getUserSearchSetting($friendsRow['user_id']);
										$userAvatar = getAvatar($friendsRow['user_id'], $friendsRow['avatar_ext'], 'thumb');
										$friendsRow['avatar'] = $userAvatar;
										//get the user network
										$userNetworks = $this->usermodel->getUserNetworks($friendsRow['user_id'], 'datestamp', '', 0, 1);
										$network = array_pop($userNetworks);
										$friendsRow['network'] = $network;
										$friendsRow['isFriend'] = $this->usermodel->isFriend($friendsRow['user_id']);
										$friendsList[$friendsRow['user_id']] = $friendsRow;
								}
						}
				}
				return $friendsList;
		}
		function searchFriendsCount($suggest = '')
		{
				$friends = $this->friendsmodel->getFriends($this->session->userdata('user_id'));
				if (is_array($friends) && count($friends) > 0)
				{
						$this->db->from('users');
						$this->db->where_in('user_id', $friends);
						$this->db->like('username', $suggest);
						return $this->db->count_all_results();
				}
				else  return 0;
		}
}
?>