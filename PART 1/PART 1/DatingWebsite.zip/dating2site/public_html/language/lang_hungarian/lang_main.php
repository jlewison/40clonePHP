<?php
// The format of this file is ---> $lang['message'] = 'text';
//
// You should also try to set a locale and a character encoding (plus direction). The encoding and direction
// will be sent to the template. The locale may or may not work, it's dependent on OS support and the syntax
// varies ... give it your best guess!
//

$lang['ENCODING'] = 'iso-8859-2';
$lang['DIRECTION'] = 'ltr';
$lang['LEFT'] = 'bal';
$lang['RIGHT'] = 'jobb';
$lang['DATE_FORMAT'] =  '%Y.%m. %d'; // This should be changed to the default date format for your language, php date() format
$lang['DATE_TIME_FORMAT'] =  '%Y. %m. %d %I:%M:%S %P'; // This should be changed to the default date format for your language, php date() format
$lang['DISPLAY_DATE_FORMAT'] =  'Y. m. d';
$lang['DISPLAY_DATETIME_FORMAT'] = 'Y. M. d H:i:s';
$lang['DB_ERROR'] = "Az �n k�r�se nem hajthat� v�gre egy meghat�rozatlan adatb�zis hiba miatt.<br />K�rem pr�b�lja �jra.";
$lang['main_menu'] = 'F�men�';
$lang['homepage'] = 'Kezd�lap';
$lang['rate_photos'] = 'K�pek �rt�kel�se';
$lang['forum'] = 'F�rum';
$lang['manageforum'] = 'F�rum kezel�s';
$lang['chat'] = 'Chat';
$lang['managechat'] = 'Chat kezel�s';
$lang['member_login'] = 'Bel�p�s tagoknak';
$lang['featured_members'] = 'K�l�nleges tagok';
$lang['quick_search'] = 'Gyorskeres�s';
$lang['my_searches'] = 'Keres�seim';
$lang['affiliates'] = 'T�rshirdet�k';
$lang['already_affiliate'] = '�n is t�rshirdet�?';
$lang['referals'] = 'Hivatkoz�sok';
$lang['title_colon'] = 'C�m:';
$lang['comments_colon'] = 'Hozz�sz�l�sok:';
$lang['feedback'] = 'Visszajelz�s';

$lang['profiles'] = 'Profilok';
$lang['profile_s'] = 'Az �n profilja';
$lang['total_amt'] = 'Teljes �sszeg';
$lang['banner_link'] = 'Banner/link';
$lang['clicks'] = 'Klikkek';
$lang['finance_calc'] = 'P�nz sz�ml�l�';
$lang['flash_chat_msg'] = 'A FlashChat 4.1.0 �s az �jabb verzi�k tartalmaznak egy oszt�lyilleszt�st az osDate-nek. A FlashChat megv�s�rolhat� a <a href="www.tufat.com/chat.php" target="_blank">www.tufat.com/chat.php</a> c�men �s ebbe a k�nyvt�rba m�soland�. Ezut�n ind�tsa el a FlashChat telep�t�t �s adja meg az osDate-et mint a kezel�fel�letet a beilleszt�shez.';
$lang['flash_chat_admin_msg'] = 'A FlashChat 4.1.0 �s az �jabb verzi�k tartalmaznak egy ozt�lyilleszt�st  az osDate-nek. A FlashChat megv�s�rolhat� a <a href="www.tufat.com/chat.php" target="_blank">www.tufat.com/chat.php</a> c�mr�l �s ebbe a k�nyvt�rba m�soland�. Ezut�n ind�tsa a FlashChat telep�t�t �s adja meg az osDate-et mint kezel�fel�letet a beilleszt�shez.';
$lang['affiliate_head_msg'] = 'Legyen t�rshirdet�';
$lang['affiliate_head_msg2'] = 'R�szesed�st aj�nlunk azoknak az �zemeltet�knek akik l�togat�kat szereznek weboldalunknak.<br/>';
$lang['affiliate_success_msg1'] = 'Az �n t�rshirdet�i fi�kj�nak felhaszn�l�neve:';
$lang['affiliate_success_msg2'] = 'Most m�r bel�phet az �n t�rshirdet�i fi�kj�ba. ';
$lang['affiliate_login_title'] = "T�rshirdet�i bel�p�";
$lang['password_changed_successfully'] = 'A jelszav�t sikeresen megv�ltoztattuk.';
$lang['affiliate_registration_success'] = 'A t�rshirdet�i regisztr�l�s sikeres volt.';
$lang['login_now'] = 'Bel�p�s';
$lang['must_be_valid'] = '�rv�nyesnek kell lennie.';
$lang['characters'] = 'bet�';
$lang['email'] = 'Email:';
$lang['age'] = '�letkor';
$lang['years'] =  '�v';

$lang['all_states'] = 'Minden �llam';
//
// These terms are used at Signup page
//
$lang['welcome'] = '�dv�z�lj�k';
$lang['admin_welcome'] = '�dv�z�lj�k <br /> az <br />' . 'SITENAME' . ' <br /> kezel�i fel�leten.';
$lang['title'] = '�dv�z�lj�k az ' . 'SITENAME'. 'oldalon';
$lang['site_links'] = array(
	'home' => 'F�oldal',
	'signup_now' => 'Regisztr�ljon!',
	'chat' => 'Chat',
	'forum' => 'F�rum',
	'login' => 'Bel�p�s',
	'search' => 'Keres�s',
	'aboutus' => 'R�lunk',
	'forgot' => 'Elfelejtett jelsz�/felhaszn�l�n�v?',
	'contactus' => 'Irjon nek�nk',
	'privacy' => 'Szab�lyzat',
	'terms_of_use' => 'Felt�telek',
	'services' => 'Szolg�ltat�sok',
	'faq' => 'GYIK',
	'articles' => 'Cikkek',
	'affliates' => 'T�rshirdet�k',
	'invite_a_friend' => 'H�vjon meg egy bar�tot',
	'feedback' => 'Visszajelz�s'
	);

$lang['success_stories'] = 'Sikert�rt�netek';
$lang['members_login'] = 'Bel�p�s tagoknak';
$lang['poll'] = 'Szavaz�s';
$lang['news'] = 'H�rek';
$lang['articles'] = 'Cikkek';
$lang['poll_result'] = 'Szavaz�s eredm�nyek';
$lang['view_poll_archive'] = 'El�z� szavaz�sek';
$lang['member_panel'] = 'Tagok fel�lete';
$lang['poll_errmsg1'] = '�n m�r szavazott ezen a szavaz�son. V�lasszon m�s szavaz�st egy m�sik napon.';
$lang['close'] = 'Bez�r';
$lang['all_stories'] = '�sszes t�rt�net';
$lang['all_news'] = '�sszes h�r';
$lang['more'] = 'tov�bb';
$lang['by'] = '�rta';

$lang['dont_stay_alone'] = 'Ne maradjon egyed�l.';
$lang['join_now_for_free'] = 'L�pjen be most ingyen!';
$lang['special_offer'] = 'K�l�nleges aj�nlat!';
$lang['welcome_to'] = '�dv�z�li az ';
$lang['welcome_to_site'] = '�dv�z�li az '.'SITENAME';

$lang['offer_text'] = 'N�zze meg, hogy az ' . 'SITENAME' . ' mi�rt a leggyorsabb online kapcsolatteremt� weboldal. K�sz�tse el az �n ' . 'SITENAME' . ' profilj�t hogy elkezdhesse t�rs�nak  keres�s�t.';

$lang['newest_profiles'] = '�j profilok';

$lang['edit_profile'] = 'Profil m�dos�t�sa';
$lang['total_profiles'] = '�sszes profil';
$lang['forgot'] = 'Elfelejtette felhaszn�l�nev�t?';
$lang['hide'] = 'Elrejt';
$lang['show'] = 'Megjelen�t';
$lang['sex'] = 'Nem:';
$lang['sex_without_colon'] = 'Nem';
$lang['pageno'] = 'Oldal ';
$lang['page'] = 'Oldal';
$lang['previous'] = 'El�z�';
$lang['next'] = 'K�vetkez�';
$lang['time_col'] = 'Id�:';

$lang['save_search'] = 'Keres�st ment';
$lang['find_your_match'] = 'T�rskeres�';

$lang['extended_search'] = 'R�szletes keres�';
$lang['matches_found'] = 'A k�vetkez� profilok egyeznek meg a megadott krit�riumokkal.';
$lang['timezone'] = 'Id�z�na:';
$lang['next_section'] = 'K�vetkez� r�sz';
$lang['sign_in'] = 'Regisztr�ci�';
$lang['member_panel'] = 'Tagok fel�lete';
$lang['aff_panel'] = 'T�rshirdet�k fel�lete';
$lang['login_title'] = 'Bel�p�s tagoknak';
$lang['sign_out'] = 'Kil�p�s';
$lang['login_submit'] = 'Bel�p�s';

$lang['change_password'] = 'Jelsz� v�ltoztat�s';
$lang['old_password'] = 'R�gi jelsz�:';
$lang['new_password'] = '�j jelsz�:';
$lang['confirm_password'] = 'Jelsz� meger�s�t�se :';
$lang['password_change_msg'] = 'Az �n jelszav�t sikeresen megv�ltoztattuk.';

$lang['section_signup_title'] = 'Regisztr�l�si inform�ci�k';
$lang['signup'] = 'Regisztr�ci�';
$lang['section_basic_title'] = 'Alap inform�ci�k';
$lang['section_appearance_title'] = 'Fizikai Megjelen�s';
$lang['section_interests_title'] = '�rdekl�d�s';
$lang['section_lifestyle_title'] = '�letst�lus';

$lang['signup_subtitle_login'] = 'Bel�p�si r�szletek';
$lang['signup_subtitle_profile'] = 'Az �n profilom';
$lang['signup_subtitle_address'] = 'C�m';
$lang['signup_subtitle_appearacnce'] = 'Fizikai megjelen�s';
$lang['signup_subtitle_preference'] = 'Keres�si be�ll�t�sok';

$lang['signup_username'] = 'Felhaszn�l�n�v:';
$lang['signup_password'] = 'Jelsz�:';
$lang['signup_confirm_password'] = 'Jelsz� meger�s�t�se:';

$lang['signup_firstname'] = 'Csal�dn�v:';
$lang['signup_lastname'] = 'Keresztn�v:';
$lang['signup_email'] = 'Email c�m:';
$lang['section_mypicture'] = 'K�peim';
$lang['upload'] = 'Felt�lt';
$lang['upload_pictures'] = 'K�peket rendszerez';
$lang['upload_format_msgs'] = 'Csak .jpg, .gif,.bmp vagy .png f�jlok megengedettek.';
$lang['thumbnail'] = 'Kisk�p';
$lang['picture'] = 'K�p';
$lang['signup_picture'] = 'K�pem';
$lang['signup_picture2'] = 'K�pem 2:';
$lang['signup_picture3'] = 'K�pem 3:';
$lang['signup_picture4'] = 'K�pem 4:';
$lang['signup_picture5'] = 'K�pem 5:';

$lang['signup_gender'] = '�n';
$lang['signup_pref_age_range'] = 'Kedvelt koroszt�ly';
$lang['signup_year_old'] = '�ves';
$lang['signup_birthday'] = 'Sz�let�snap:';
$lang['signup_country'] = 'Orsz�g:';
$lang['signup_state_province'] = '�llam / Megye:';
$lang['signup_zip'] = 'Ir�ny�t�sz�m:';
$lang['signup_city'] = 'V�ros / Helys�g:';
$lang['signup_address1'] = 'C�m, 1. sor:';
$lang['signup_address2'] = 'C�m, 2. sor:';
$lang['signup_height'] = 'Magass�g: ';
$lang['signup_feet'] = 'l�b';
$lang['signup_meter_inches'] = 'm�ter';
$lang['signup_weight'] = 'S�ly:';
$lang['signup_pounds'] = 'kg';
$lang['signup_where_should_we_look'] = 'Merre kellene sz�tn�zz�nk?';
$lang['signup_view_online'] = "M�s tag l�that ha online vagyok?";

$lang['signup_gender_values'] = array(
	'M' => 'F�rfi',
	'F' => 'N�',
	'C' => 'P�r',
	'G' => 'Csoport'
	);

$lang['signup_gender_look'] = array(
	'M' => 'F�rfi',
	'F' => 'N�',
	'C' => 'P�r',
	'G' => 'Csoport',
	'B' => 'F�rfi vagy N�',
	'A' => 'B�rmelyik ezek k�z�l'
	);

$lang['seeking'] = 'keres';
$lang['looking_for_a'] = 'keres';
$lang['looking_for'] = 'keres';

$lang['of'] = ' ';
$lang['to'] = '-';
$lang['from'] = '';
$lang['for'] = '';
$lang['yes'] = 'Igen';
$lang['no'] = 'Nem';
$lang['cancel'] = 'M�gsem';

$lang['change'] = 'V�ltoztat';
$lang['reset'] = 'M�gsem';

//Commonly used words

$lang['required_info_indication'] = 'a -al jel�lt mez�k kit�lt�se k�telez�';
$lang['required_info_indicator'] = '* ';
$lang['required_info_indicator_color'] = 'Red';
$lang['click_here'] = 'Kattintson ide';

$lang['datetime_dayval']['Sun'] = 'Vas';
$lang['datetime_dayval']['Mon'] = 'H�t';
$lang['datetime_dayval']['Tue'] = 'Ked';
$lang['datetime_dayval']['Wed'] = 'Sze';
$lang['datetime_dayval']['Thu'] = 'Cs�';
$lang['datetime_dayval']['Fri'] = 'P�n';
$lang['datetime_dayval']['Sat'] = 'Szo';

$lang['error_msg_color'] = 'Piros';
$lang['success_message'] = "A be�rt inform�ci�kat sikeresen elmentett�k.<br />5 m�sodperc m�lva �tir�ny�tjuk a k�vetkez� r�szhez. Abban az esetben, ha az �tir�ny�t�s nem m�k�dne, k�rj�k, haszn�lja az al�bbi linket.";
$lang['sendletter_success'] = 'A level�t sikeresen elk�ldt�k.';


/*****************Admin Section Labels********************/

//Commonly used labels
$lang['admin_login_title'] = 'SITENAME' . 'Admin fel�let';
$lang['home_title'] = 'SITENAME' . ' kezd�oldal';
$lang['admin_login_msg'] = 'Admin bel�p�s';
$lang['admin_title_msg'] = 'SITENAME' . ' Admin fel�let';
$lang['admin_panel'] = 'Admin fel�let';
$lang['back'] = 'Vissza';
$lang['insert_msg'] = '�jat hozz�ad ';
$lang['question_mark'] = '?';
$lang['id'] = 'Azonos�t�:';
$lang['name'] = 'N�v: ';
$lang['name_col'] = 'N�v';
$lang['enabled'] = 'Bekapcsolva:';
$lang['action'] = 'Esem�ny';
$lang['edit'] = 'M�dos�t';
$lang['delete'] = 'T�r�l';
$lang['section'] = 'R�sz:';
$lang['insert_section'] = '�j r�sz hozz�ad�sa';
$lang['modify_section'] = 'R�szt m�dos�t';
$lang['modify_sections'] = 'R�szeket m�dos�t';
$lang['delete_section'] = 'R�szt t�r�l';
$lang['delete_sections'] = 'R�szeket m�dos�t';
$lang['enable_selected'] = 'Bekapcsol';
$lang['disable_selected'] = 'Kikapcsol';
$lang['change_selected'] = 'V�ltoztat';
$lang['delete_selected'] = 'T�r�l';
$lang['no_select_msg'] = "Nem v�lasztott egyet az opci�k k�z�l. K�rem haszn�lja a VISSZA gombot �s v�lasszon ki egy vagy t�bb opci�t.";
$lang['delete_confirm_msg'] = 'Biztos benne hogy t�rli ezt a r�szt?';
$lang['delete_group_confirm_msg'] = 'Biztos benne hogy t�rli ezeket a r�szeket? A t�rl�s nem vonhat� vissza.';
$lang['enabled_values'] = array(
	'Y' => 'Igen',
	'N' => 'Nem'
	);
$lang['display_control_type'] = array(
	'checkbox' => 'Kijel�l�doboz',
	'radio' => 'Opci�doboz',
	'select' => 'Lista',
	'textarea' => 'Sz�veg'
	);
$lang['admin_error_color'] = 'Piros';

$lang['col_head_srno'] = '#';
$lang['col_head_id'] = 'Azonos�t�';
$lang['col_head_question'] = 'K�rd�s';
$lang['col_head_enabled'] = 'Bekapcsolva';
$lang['col_head_name'] = 'N�v';
$lang['col_head_username'] = 'Felhaszn�l�n�v';
$lang['col_head_firstname'] = 'Csal�dn�v';
$lang['col_head_lastname'] = 'Keresztn�v';
$lang['col_head_fullname'] = 'Teljes N�v';
$lang['col_head_status'] = 'St�tusz';
$lang['col_head_gender'] = 'Nem';
$lang['col_head_email'] = 'Email';
$lang['col_head_country'] = 'Orsz�g';
$lang['col_head_city'] = 'V�ros';
$lang['col_head_zip'] = 'Ir�ny�t�sz�m';
$lang['col_head_zip'] = 'Ir�ny�t�sz�m';
$lang['col_head_register_at'] = 'Feliratkozva';

$lang['section_title'] = 'R�sz szerkeszt�se';
$lang['total_sections'] = '�sszes r�sz:';
$lang['profile_title'] = 'Profil szerkeszt�s';
$lang['total_profiles_found'] = '�sszes tal�lt profil:';
$lang['modify_profile'] = 'Profilt m�dos�t';

$lang['profile_signup_title'] = 'Bel�p�si inform�ci�k';
$lang['profile_basic_title'] = 'Alap inform�ci�k';
$lang['profile_appearance_title'] = 'Fizikai megjelen�s';
$lang['profile_interests_title'] = '�rdekl�d�s';
$lang['profile_lifestyle_title'] = '�letst�lus';

$lang['profile_subtitle_login'] = 'Bel�p�si r�szletek';
$lang['profile_subtitle_profile'] = 'Profil';
$lang['profile_subtitle_address'] = 'C�m';
$lang['profile_subtitle_appearacnce'] = 'Fizikai megjelen�s';
$lang['profile_subtitle_preference'] = 'Be�ll�t�sok';
$lang['profile_delete_confirm_msg'] = 'Biztos benne hogy t�rli ezt a profilt?';
$lang['delete_profile'] = 'Profilt t�r�l';
$lang['profile_username'] = 'Felhaszn�l�n�v:';
$lang['profile_firstname'] = 'Csal�dn�v:';
$lang['profile_lastname'] = 'Keresztn�v:';
$lang['profile_email'] = 'Email c�m:';
$lang['profile_gender'] = 'Nem:';
$lang['profile_birthday'] = 'Sz�let�snap:';
$lang['profile_country'] = 'Orsz�g:';
$lang['profile_state_province'] = '�llam / Megye:';
$lang['profile_zip'] = 'Ir�ny�t�sz�m';
$lang['profile_city'] = 'V�ros / Helys�g';
$lang['profile_address1'] = 'C�m, 1. sor:';
$lang['profile_address2'] = 'C�m, 2. sor:';
$lang['find'] = 'Tal�l';
$lang['search'] = 'Keres';
$lang['AND'] = '�s';
$lang['OR'] = 'vagy';
$lang['order_by'] = 'Sorba�ll�t�s: ';
$lang['sort_by'] = 'sorrendben';
$lang['sort_types'] = array(
	'asc' => 'N�vekv�',
	'desc' => 'Cs�kken�'
	);
$lang['search_results'] = 'Tal�latok';
$lang['no_record_found'] = 'Nincs tal�lat.';
$lang['search_options'] = 'Keres�si opci�k';
$lang['search_simple'] = 'Egyszer� keres�s';
$lang['search_advance'] = 'Keres�s';
$lang['search_advance_results'] = 'Tal�latok';
$lang['search_country'] = 'Keres�s orsz�g szerint';
$lang['search_states'] = 'Keres�s �llam szerint';
$lang['search_zip'] = 'Keres�s ir�ny�t�sz�m szerint';
$lang['search_city'] = 'Keres�s v�ros szerint';
$lang['search_wildcard_msg'] = 'Be�rhat egy *-ot hogy az �sszes krit�rium szerint keressen.';
$lang['search_location'] = '<b>Keres�s helys�g szerint:</b>';
$lang['select_state'] = '�llam:';
$lang['enter_city'] = 'V�ros:';
$lang['enter_zip'] = 'Ir�ny�t�sz�m:';
$lang['enter_username'] = 'Felhaszn�l�n�v:';
$lang['results_per_page'] = 'Tal�latok';
$lang['search_results_per_page'] = array( 2 => 2, 5 => 5 , 10 => 10, 20 => 20, 50 => 50, 100 => 100 );
$lang['order'] = 'Felsorol';
$lang['up'] = 'Fel';
$lang['down'] = 'Le';

$lang['question'] = 'K�rd�s:';

$lang['maxlength'] = 'Maxim�lis hosszus�g:';
$lang['description'] = 'Le�r�s:';
$lang['mandatory'] = 'K�telez�ek:';
$lang['guideline'] = 'Utmutat�s:';
$lang['control_type'] = 'Kezel�s megjelen�t�se :';
$lang['include_extsearch'] = 'Hozz�ad a r�szletes keres�shez:';
$lang['head_extsearch'] = 'R�szletes keres�s fejl�c:';

$lang['delete_question'] = 'K�rd�st t�r�l';
$lang['modify_question'] = 'K�rd�st m�dos�t';
$lang['questions_title'] = 'K�rd�sek szerkeszt�se';
$lang['total_options'] = '�sszes opci�:';
$lang['insert_question'] = '�j k�rd�st hozz�ad';
$lang['total_questions'] = '�sszes K�rd�s:';
$lang['delete_questions'] = 'K�rd�st T�r�l';
$lang['delete_group_questions_confirm_msg'] = 'Biztos benne hogy t�rli ezt a k�rd�st? A t�rl�s nem vonhat� vissza.';

$lang['option'] = 'Opci�k';
$lang['answer'] = 'V�lasz';
$lang['options_title'] = 'V�lasz Opci�k';
$lang['col_head_answer'] = 'V�lasz';
$lang['with_selected'] = 'Kijel�lt';
$lang['ranging'] = 'Rang';

// Instant messenger
$lang['instant_messenger'] = 'Messenger';
$lang['instant_message'] = '�zenet';
$lang['im_from'] = 'K�ld�:';
$lang['im_message'] = '�zenet:';
$lang['im_reply'] = 'V�lasz';
$lang['close_window'] = 'Ablakot bez�r';

// my matches
$lang['my_matches'] = 'Tal�lataim';
$lang['i_am_a'] = '�n';
$lang['Between'] = 'k�z�tt';
$lang['who_is_from'] = 'aki';
$lang['showing'] = 'Megjelen�t';
$lang['your_search_preferences'] = 'Jelenlegi keres�si be�ll�t�sok:';
$lang['to_edit_search_preferences'] = 'keres�si be�ll�t�sok szerkeszt�se';

$lang['unapproved_user'] = 'Elfogad�sra v�r� profilok';
$lang['gbl_settings'] = 'Weboldal glob�lis be�ll�t�sai';
$lang['configurations'] = 'Konfigur�ci�k';
$lang['col_head_variable'] = 'V�ltoz�';
$lang['col_head_value'] = '�rt�k';

$lang['affiliate_title'] = 'T�rshirdet�i szerkeszt�s';
$lang['col_head_counter'] = 'Sz�ml�l�';
$lang['col_head_status'] = 'St�tusz';

$lang['tell_later'] = 'K�s�bb elmondom';
$lang['view_profile'] = 'Profilt Megn�z';
$lang['view_profile_errmsg1']  = 'M�g mindig nem hat�rozta meg a be�ll�t�sait.<br />K�rem hat�rozza meg el�sz�r a profilja r�szleteit.<br />';
$lang['view_profile_errmsg2'] = '<br />Kattintson ide a be�ll�t�sok�rt.';
$lang['view_profile_errmsg3'] = 'A felhaszn�l� m�g nem hat�rozta meg a profilja r�szleteit.';
$lang['view_profile_restricted'] = 'Ez egy titkos profil. �n nem n�zheti meg.';
$lang['profile_notset'] = 'Nincs tal�lat a felhaszn�l�n�vre.';
$lang['send_mail'] = '�zenetet k�ld';
$lang['mail_messages'] = '�zenetek';
$lang['col_head_subject'] = 'T�ma';
$lang['col_head_sendtime'] = 'D�tum';

$lang['inbox'] = 'Be�rkezett �zenetek';
$lang['sent'] = 'Elk�ld�tt �zenetek';
$lang['trashcan'] = 'Kuka';
$lang['reply'] = 'V�laszol';
$lang['read'] = 'Olvas';
$lang['unread'] = 'Olvasatlan';
$lang['restore'] = 'Vissza�ll�t';
$lang['subject'] = 'T�ma';
$lang['subject_colon'] = 'T�ma:';
$lang['message'] = '�zenet';
$lang['send'] = 'Elk�ld';

$lang['send_letter'] = 'Levelet k�ld';
$lang['image_browser'] = 'K�pb�ng�sz�';
$lang['upload_image'] = 'K�pet felt�lt';
$lang['delete_image'] = 'K�pet t�r�l';
$lang['show_image'] = 'K�pet megjelen�t';
$lang['send_invite'] = 'Megh�v� K�ld�se';
$lang['letter_title'] = '�j lev�l';
$lang['from_email'] = 'Email:';
$lang['from_name'] = 'N�v:';
$lang['send_to'] = 'K�ld';
$lang['email_subject'] = 'T�ma:';
$lang['save_as'] = 'Ment�s m�sk�pp';

$lang['no_message'] = 'Nincs t�bb �j �zenet.';
$lang['descrip'] = 'Le�r�s';

//forgot password words
$lang['forgotpass_msg1'] = "Eml�keztet�";
$lang['forgotpass_msg2'] = "Haszn�lja azt az email c�met amivel regisztr�lt, hogy egy �j jelszav�t eltudjuk k�ldeni �nnek. Ezut�n azonnal meg kell v�ltoztatnia jelszav�t.";
$lang['retreieve_info'] = 'K�ld';
$lang['forgotpass'] = 'Elefelejtettem a jelszavam';

//Tell a friend
$lang['tellafriend'] = 'Bar�tot megh�v';
$lang['taf_msg1'] = 'Bar�tot megh�v ' . 'SITENAME';
$lang['taf_yourname'] = 'Az �n Neve:';
$lang['taf_youremail'] = 'Email c�me:';
$lang['taf_friendemail'] = "Egy bar�tja email c�me:";

//Auto-mail
$lang['confirm_your_profile'] = 'Regisztr�l�s �rv�nyes�t�se';
$lang['letter_not_avail'] = 'Lev�l sablon nem l�tezik';
$lang['confirm_letter_sent'] = 'Egy �rv�nyes�t�si lev�l volt elk�ldve arra az email c�mre, amelyiket a regisztr�ci�nal megadott. Nyissa meg az �zenetet, hogy befejezhesse a regisztr�ci�t.';
$lang['letter_not_sent'] = 'Az emailt nem siker�lt elk�ldeni. K�s�bb pr�b�lja �jra.';
$lang['or'] = 'Vagy';
$lang['enter_confirm_code'] = 'Irja be a regisztr�ci�s k�dot hogy a m�velet befejez�dhessen.';
// Affiliate auto-mail

$lang['aff_email_subject'] = '�rv�nyes�tse az �n t�rshirdet�i fi�kj�t';
$lang['aff_email_body'] = 'K�sz�nj�k, hogy regisztr�lt mint t�rshirdet� a ' . 'SITENAME' . ' weboldalra. Haszn�lja a k�vetkez� linket, hogy a regisztr�ci� befejez�dhessen:<br><br>#ConfirmationLink#';

//Page management

$lang['manage_pages'] = 'Oldal szerkeszt�s';
$lang['pagetitle'] = 'C�m:';
$lang['pagetext'] = 'Sz�veg:';
$lang['pagekey'] = 'Kulcs:';
$lang['addpage'] = 'Oldalt Hozz�ad';
$lang['page'] = 'Oldal:';
$lang['addnew'] = '�j hozz�ad�sa';
$lang['modpage'] = 'Oldalt M�dos�t';
$lang['pagekey_help'] = 'www.sajatcim.com/index.php?page=ON_KULCS';

$lang['y_o'] = 'y/o';
$lang['lastlogged'] = 'Utols� bel�p�s: ';
$lang['aff_stats'] = 'T�rshirdet�i statisztik�k';
$lang['total_referrals'] = '�sszes hivatkoz�s';
$lang['regis_referals'] = 'Regisztr�lt hivatkoz�k';
$lang['globalconfigurations'] = 'Glob�lis be�ll�t�sok';

$lang['send_message_to'] = '�zenet c�mzettje';
$lang['writing_message'] = '�zenet �r�sa ';
$lang['search_at'] = 'Keres ';

//Rating module
$lang['rate_profile'] = '�rt�keljen profilt';
$lang['worst'] = 'Legrosszabb';
$lang['excellent'] = 'Legjobb';
$lang['rating'] = '�rt�kel�s';
$lang['submitrating'] = '�rt�keljen:';

//Payment Modules
$lang['mship_changed'] = 'Tags�gi fel�let m�dos�t�sa';
$lang['mship_changed_successfull'] = 'Tags�god  ingyeness� v�lt.';
$lang['no_payment'] = 'Ingyenes';
$lang['payment_modules'] = 'Fizet�s modulok';
$lang['payment_methods'] = 'Fizet�si m�dszerek';
$lang['business'] = '�zlet:';
$lang['siteid'] = 'Oldal azonos�t�:';
$lang['undefined_quantity'] = 'Meghat�rozatlan mennyis�g:';
$lang['no_shipping'] = 'Nincs sz�ll�t�s:';
$lang['no_note'] = 'Nincs megjegyz�s:';
$lang['on_off_values'] = array( 1 => 'Igen', 0 => 'Nem' );
$lang['edit_payment_modules'] = 'Fizet�s modulok szerkeszt�se';
$lang['trans_key'] = 'Tranzakci� kulcs:';
$lang['trans_mode'] = 'Tranzakci� m�dja:';
$lang['trans_method'] = 'Tranzakci� m�dszere:';
$lang['username'] = ' Felhaszn�l�n�v:';
$lang['username_without_colon'] = ' Felhaszn�l�n�v ';
$lang['country'] = 'Orsz�g';
$lang['country_colon'] = ' Orsz�g:';
$lang['state'] = 'St�tusz';
$lang['city'] = 'V�ros';
$lang['location_col'] = 'Helys�g:';
$lang['location_no_col'] = 'Helys�g';
$lang['zip_code'] = 'Ir�ny�t�sz�m ';
$lang['attached_files'] = 'Csatolt �llom�nyok';
$lang['cc_owner'] = 'Hitelk�rtya tulajdonos:';
$lang['cc_number'] = 'Hitelk�rtya sz�m:';
$lang['cc_type'] = 'Hitelk�rtya t�pus:';
$lang['cc_exp_date'] = 'Hitelk�rtya lej�rati ideje:';
$lang['cc_cvv_number'] = 'Hitelk�rtya sz�mlasz�m:';
$lang['cvv_help'] = '(A hitelk�rtya h�toldal�n tal�lhat�)';
$lang['continue'] = 'Tov�bb';
$lang['trans_method_vals'] = array(
	'CC' => 'Hitelk�rtya',
	'ECHECK' => 'Elektronikus Sz�mla'
	);
$lang['trans_mode_vals'] = array(
	'AUTH_CAPTURE' => 'AUTH_CAPTURE',
	'AUTH_ONLY' => 'AUTH_ONLY',
	'CAPTURE_ONLY' => 'CAPTURE_ONLY',
	'CREDIT' => 'CREDIT',
	'VOID' => 'VOID',
	'PRIOR_AUTH_CAPTURE' => 'PRIOR_AUTH_CAPTURE'
 );
$lang['cc_unknown'] = 'A hitelk�rtya kibocs�jt�ja nem ismert. Pr�b�lja �jra egy �rv�nyes bankk�rty�val.';
$lang['cc_invalid_date'] = 'A hitelk�rtya lej�rati ideje nem val�s. Pr�b�lja �jra egy �rv�nyes bankk�rty�val.';
$lang['cc_invalid_number'] = 'A hitelk�rtya sz�ma nem val�s. Pr�b�lja �jra egy �rv�nyes bankk�rty�val.';
$lang['amount'] = '�sszeg: ';
$lang['confirmation'] = '�rv�nyes�t�s';
$lang['confirm'] = '�rv�nyes�t';
$lang['upgrade_membership'] = 'Tags�got jav�t';
$lang['changeto'] = 'V�lt�s';
$lang['current_mship_level'] = 'Jelenlegi tags�gi szint:';
$lang['membership_status'] = 'Tags�gi st�tusz';
$lang['you_currently'] = 'Jelenlegi �llapot: ';
$lang['info_confirm'] = 'Igaz-e a k�vetkez� inform�ci�?';
$lang['change_mship_to'] = 'Tags�gi szintet v�ltoztat ';
//Membership
$lang['permitmsg_1'] = 'Sajn�lom, az �n tags�gi szintje nem el�gs�ges ehhez a m�velethez';
$lang['permitmsg_2'] = 'Emelje tags�gi szintj�t hogy haszn�lni tudja ';
$lang['permitmsg_3'] = 'Tags�gi szintek �sszehasonl�t�sa';
$lang['permitmsg_4'] = 'Tags�gi Szintek �sszehasonl�t�s�t elt�ntet';
$lang['membership_packages'] = 'Tags�gi Csomagok';
$lang['membership_packages_compare'] = 'Tags�gi Csomagok �sszehasonl�t�sa';
$lang['modify'] = 'V�toztat�sokat elment';
$lang['manage_membership'] = 'Tags�g szerkeszt�se';
$lang['privileges_msg'] = 'Kiv�lts�gok';
$lang['price'] = '�r: ';
$lang['currency'] = 'P�nznem: ';
$lang['choose_membership'] = 'V�lasszon egy tags�gi szintet:';
$lang['add_membership'] = '�j Tags�gi t�pust hozz�ad';
$lang['membership_types'] = 'Tags�gi t�pusok';
$lang['member'] = 'tag';

$lang['select_letter'] = 'Levelet v�laszt:';
$lang['body'] = 'Tartalom:';
$lang['module'] = 'Modul';
$lang['uninstall'] = 'Let�r�l';
$lang['install'] = 'Telep�t';
$lang['modify_option'] = 'Opci�t m�dos�t';

$lang['only_jpg'] = 'Csak JPG,GIF,PNG,BMP f�jlok megengedettek.';
$lang['upload_unsuccessful'] = 'A k�pet nem siker�lt felt�lteni.';
$lang['upload_successful'] = 'A k�peket sikeresen felt�lt�tt�k.';
$lang['between1'] = 'k�z�tt';
$lang['and'] = '�s';
$lang['profile_details'] = 'Profil r�szletek';
$lang['personal_details'] = 'Szem�lyes r�szletek';


//Banner Management
$lang['manage_banners'] = 'Banner szerkeszt�s';
$lang['add_banners'] = 'Bannert Hozz�ad�s';
$lang['edit_banners'] = 'Bannert M�dos�t';
$lang['size'] = 'M�ret';
$lang['size_px'] = 'M�ret (px)';
$lang['banner_linkurl'] = 'Banner / Link URL';
$lang['banner_sizes'] = array(
	'468X60' => '468 x 60',
	'100X500'=>'100 x 500',
	'120X120'=>'120 x 120'
);
$lang['banner_sizes_name'] = array( 'v�zszintes', 'f�gg�leges', 'n�gsz�gletes' );
$lang['startdate'] = 'Kezdeti d�tum:';
$lang['enddate'] = 'V�gs� d�tum:';
$lang['tooltip'] = 'Tipp:';
$lang['linkurl'] = 'Link Url:';
$lang['banner'] = 'Banner:';
$lang['total_banner'] = '�sszes Banner:';
$lang['online_users'] = 'Online tagok: ';
$lang['site_statistics'] = 'Oldal statisztik�k';
$lang['pending_profiles'] = 'F�gg�ben lev� profilok';
$lang['active_profiles'] = 'Akt�v profilok';
$lang['online_profiles'] = 'Online profilok';
$lang['pending_aff'] = 'F�gg�ben lev� t�rshirdet�k';
$lang['total_affiliates'] = '�sszes t�rshirdet�';
$lang['active_aff'] = 'Akt�v t�rshirdet�k';
$lang['no_rating'] = 'Nincs �rt�kelve';

//SEO Words
$lang['seo'] = 'SEO be�ll�t�sok';
$lang['seo_head'] = 'Keres� Motor optimiz�l�s';
$lang['sef_msg'] = 'Keres� Motor bar�ti URL-k';
$lang['seo_enable'] = 'URL �jra�r� m�dot bekapcsol:';
$lang['yes_msg'] ='Az URL �jra�r�s csak Apache szerveren lehets�ges, ha a mod_rewrite kiterjeszt�s be van kapcsolva. K�rem ellen�rizze, hogy az �n szervere megfelel�en van-e be�ll�tva. Ugyanakkor k�rem nevezze �t a .htaccess.txt f�jlt .htaccess-re.';
$lang['keywords'] = 'Kulcsszavak:';
$lang['page_tags_msg'] = 'Oldal c�me �s meta elemek';
$lang['max_255'] = 'Maximum 255 karakter';

//News / Story / Article Manangement
$lang['manage_news'] = 'H�r szerkeszt�s';
$lang['manage_story'] = 'T�rt�net szerkeszt�s';
$lang['manage_article'] = 'Cikk szerkeszt�s';
$lang['news_header'] = 'Fed�lap';
$lang['total_news'] = '�sszes h�r:';
$lang['total_articles'] = '�sszes cikk:';
$lang['total_stories'] = '�sszes t�rt�net:';
$lang['article_title'] = 'C�m';
$lang['story_sender'] = 'K�ld�';
$lang['story_sender_msg'] = 'Profil azonos�t� [Digit]';
$lang['modify_article'] = 'Cikket m�dos�t';
$lang['modify_news'] = 'H�rt m�dos�t';
$lang['modify_story'] = 'T�rt�netet m�dos�t';
$lang['insert_article'] = 'Cikket hozz�ad';
$lang['insert_story'] = 'T�rt�netet hozz�ad';
$lang['insert_news'] = 'H�rt hozz�ad';
$lang['dat'] = 'D�tum:';

//Poll Words
$lang['manage_polls'] = 'Szavaz�s szerkeszt�s';
$lang['modify_poll'] = 'Szavaz�st s�dos�t';
$lang['total_polls'] = '�sszes szavaz�s';
$lang['poll'] = 'Szavaz�s';
$lang['add_polls'] = 'Szavaz�st hozz�ad';
$lang['add_options'] = 'Opci�k hozz�ad�sa';
$lang['active'] = 'Akt�v';
$lang['activate'] = 'Aktiv�l';
$lang['option'] = 'Opci�';
$lang['modify_options'] = 'Opci�t m�dos�t';
$lang['add_option_now'] = 'Opci�t hozz�ad.';
$lang['poll_options'] = 'Szavaz�si opci�';
$lang['votes'] = 'Szavazat(ok)';
//Filter Records
$lang['filter_options'] = array(
	'id' => 'Id',
	'username' => 'Felhaszn�l�n�v',
	'city' => 'V�ros',
	'zip' => 'Ir�ny�t�sz�m',
	'status' => 'St�tusz'
	);
$lang['first'] = 'Els�';
$lang['last'] = 'Utols�';
$lang['filter_records'] = 'Feljegyz�sek sz�r�';
$lang['search_at'] = 'Keres';
$lang['criteria'] = 'Krit�rium';

//Admin Management
$lang['manage_admins'] = 'Adminisztr�ci�s R�sz';
$lang['total_admins'] = '�sszes adminisztr�tor';
$lang['add_admin'] = 'Adminisztr�tort hozz�ad';
$lang['modify_admin'] = 'Adminisztr�tort m�dos�t';
$lang['fullname'] = 'Teljes n�v';
$lang['please_be_sure'] = 'Legyen biztos benne, hogy';
$lang['change_your_admin_pwd'] = 'megv�ltoztatja az admin jelszav�t.';
$lang['superuser'] = 'Szuper felhaszn�l�';
$lang['no_admin_user_msg1'] = 'Nincsenek nem-szuper felhaszn�l� adminok. Adja meg az els�t.';
$lang['no_admin_user_msg2'] = '�j Adminisztr�tor hozz�ad�s';
$lang['access_denied'] = 'Hozz�f�r�s megtiltva';
$lang['not_authorize'] = 'Nincs felhatalmazva ezen oldal b�ng�sz�s�re. Vegye fel a kapcsolatot egy Adminisztr�torral.';

//Admin Permissions Management
$lang['admin_permissions'] = 'Admin enged�lyek';
$lang['manage_admin_permissions'] = 'Admin enged�lyek szerkeszt�s';
$lang['admin_users'] = 'Admin felhaszn�l�k';
$lang['permissions'] = 'Enged�lyek';
$lang['superuser_noteditable'] = 'Megjegyz�s: Szuper Felhaszn�l�(k) nem m�dos�that�(ak).';
$lang['all'] = '�sszes';
$lang['selected'] = 'Kijel�lt';
$lang['selected_users'] = 'Kijel�lt felhaszn�l�k';
$lang['separate_users_by_coma'] = 'Felhaszn�l�neveket be�r vessz�vel elv�lasztva';
$lang['admin_rights'] = array(
		'site_stats' 				=> 'Site statisztik�k',
		'profie_approval'		 	=> 'Profil elfogad�s',
		'profile_mgt' 				=> 'Profil szerkeszt�s',
		'section_mgt' 				=> 'R�sz szerkeszt�s',
		'affiliate_mgt' 			=> 'T�rshirdet� szerkeszt�s',
		'affiliate_stats'		 	=> 'T�rshirdet�i statisztik�k',
		'news_mgt' 					=> 'H�r szerkeszt�s',
		'article_mgt' 				=> 'Cikk szerkeszt�s',
		'story_mgt'					=> 'T�rt�net szerkeszt�s',
		'poll_mgt'		 			=> 'Szavaz�s szerkeszt�s',
		'search' 					=> 'Keres�s',
		'ext_search'				=> 'R�szletes keres�s',
		'send_letter' 				=> 'Levelet k�ld',
		'pages_mgt' 				=> 'Oldal szerkeszt�s',
		'chat' 						=> 'Chat',
		'chat_mgt' 					=> 'Chat szerkeszt�s',
		'forum_mgt' 				=> 'F�rum szerkeszt�s',
		'mship_mgt' 				=> 'Tags�g szerkeszt�s',
		'payment_mgt' 				=> 'Fizet�si modulok',
		'banner_mgt' 				=> 'Banner szerkeszt�s',
		'seo_mgt' 					=> 'SEO szerkeszt�s',
		'admin_mgt' 				=> 'Admin szerkeszt�s',
		'admin_permit_mgt'			=> 'Admin enged�lyek',
		'global_mgt' 				=> 'Glob�lis be�ll�t�sok',
		'change_pwd'				=> 'Jelsz� v�ltoztat�s',
		'cntry_mgt'					=> 'Szerkeszt Orsz�g/�llam/V�ros',
		'snaps_require_approval'	=> 'K�peket elfogad',
		'featured_profiles_mgt'		=> 'K�l�nleges profilok',
		'calendar_mgt'				=> 'Napt�rak',
		'event_mgt'					=> 'Esem�nyeket elfogad',
		'import_mgt'				=> 'Import�l',
	/* Added in 2.0 */
      	'plugin_mgt'            	=> 'Plugin szerkeszt�s',
		'blog_mgt'					=> 'Blog szerkeszt�s',
		'profile_ratings'			=> 'Profil �rt�kel�sek',
		);

$lang['cntry_mgt']	= 'Szerkeszt Orsz�gok / �llamok / V�rosok';
$lang['register_now'] = 'Regisztr�ljon!';
$lang['addtobuddylist'] = 'Bar�tok list�j�hoz hozz�ad';
$lang['addtobanlist'] = 'Letiltottak list�j�hoz hozz�ad';
$lang['addtohotlist'] = 'Kedvencek list�hoz hozz�ad';
$lang['buddylisthdr'] = 'Bar�tok list�ja';
$lang['banlisthdr'] = 'Letiltottak list�ja';
$lang['hotlisthdr'] = 'Kedvencek lista';
$lang['username_hdr'] = 'Felhaszn�l�n�v';
$lang['fullname_hdr'] = 'Teljes N�v';
$lang['register'] = 'Regisztr�ljon!';
$lang['featured_profiles'] = 'K�l�nleges profilok';
$lang['bigger_pic_size'] = 'A k�p m�rete nagyobb a megengedettn�l, ami '.$config['upload_snap_maxsize'].' KB.';
$lang['snaps_require_approval'] = 'K�peket elfogad';
$lang['events_require_approval'] = 'Esem�nyeket elfogad';
$lang['upload_picture_caption'] = 'Alap�rtelmezett k�p ';
$lang['upload_thumbnail_caption'] = 'Kisk�p ';
$lang['Approve'] = 'Elfogad';
$lang['Remove'] = 'T�r�l';
$lang['userdetails'] = 'Felhaszn�l�i inform�ci�';
$lang['pict'] = 'K�p';
$lang['tnail'] = 'Kisk�p';
$lang['reqact'] = 'K�v�nt esem�ny';
$lang['newmemberlist'] = '�j tagok';
$lang['yearsold'] = '�v';
$lang['Male'] = 'F�rfi';
$lang['Female'] = 'N�';
$lang['showfulllist'] = 'Teljes list�t megmegjelen�t';
$lang['featuredprofiles'] = 'K�l�nleges profilok';
$lang['featured_profiles_hdr'] = 'K�l�nleges tagok profiljai';
$lang['nonfeatured_profiles_hdr'] = '�tlag tagok';
$lang['level_hdr'] = 'Szint';
$lang['date_from'] = 'Kezdeti D�tum';
$lang['date_upto'] = 'D�tumig';
$lang['must_show'] = 'Megjelen�teni';
$lang['reqd_exposures'] = 'Sz�ks�ges megvil�g�t�sok';
$lang['total_exposures'] = '�sszes megvil�g�t�s';
$lang['add_featured'] = 'Profil hozz�ad�s a k�l�nleges list�hoz';
$lang['mod_featured'] = 'Profil m�dos�t�sa a k�l�nleges list�n';
$lang['member_since'] = 'Tag';
$lang['invalid_username'] = '�rv�nytelen felhaszn�l�n�v';
$lang['weekcnt'] = 'M�ltheti bel�p�sek sz�ma:';
$lang['totalgents'] = '�sszes f�rfi tag:';
$lang['totalfemales'] = '�sszes n�i tag:';
$lang['weeksnaps'] = 'M�ltheti k�pek:';
$lang['since_last_login'] = 'utols� bel�p�s';
$lang['sincelastlogin_hdr'] ='Utols� bel�p�s';
$lang['newmessages'] = '�j �zenetek �rkeztek:';
$lang['profileviewed'] = 'Profil megtekint�s�nek sz�ma:';
$lang['winks_received'] = 'Kaccsint�sok sz�ma:';
$lang['send_wink'] = 'Kaccsint�st k�ld';
$lang['listofviews'] = 'Tagok list�ja akik az �n profilj�t megn�zt�k';
$lang['listofwinks'] = 'Tagok list�ja akik kaccsint�st k�ldtek �nnek';
$lang['winkslist'] = 'Kaccsint�s lista';
$lang['viewslist'] = 'Profill�togat�k lista';
$lang['suggest_poll'] = 'Szavaz�st aj�nl';
$lang['savepoll'] = 'Szavaz�st elk�ld';
$lang['moreoptions'] = 'T�bb opci�';
$lang['minimum_options'] = 'Legal�bb k�t opci� kell';
$lang['pollsuggested'] = 'K�sz�nj�k! Az �n szavaz�s �tlet�t elk�ldt�k egy oldalkezel�h�z.';
$lang['suggested_by'] = 'Javasolta:';
$lang['any_where'] = 'B�rhol';
$lang['memberpanel'] = "Tagok kezd�oldala";
$lang['feedback_thanks'] = 'K�sz�nj�k a v�lem�ny�t. Az �n v�lem�ny�t egy oldalkezel�h�z k�ldt�k.';
$lang['cancel_hdr'] = 'Tags�got megsz�ntet';
$lang['cancel_txt01'] = '�n azt k�rte, hogy a tags�g�t sz�ntess�k meg a <b>'.'SITENAME'.'</b> odalon.<br /><br />Biztos �n benne, hogy ezt akarja? ';
$lang['cancel_opt01'] = 'Igen, biztos vagyok benne';
$lang['cancel_opt02'] = 'Nem, m�g nem akarom megsz�ntetni a tags�gomat';
$lang['cancel_domsg'] = 'K�sz�nj�k hogy az '.'SITENAME'.' oldalt haszn�lta.<br><br>Rem�lj�k hogy �lvezte a szolg�ltat�sainkat �s b�rmikor sz�vesen l�tjuk a j�v�ben is.';
$lang['cancel_nomsg'] = 'K�sz�nj�k hogy az '.'SITENAME'.' szitot haszn�lta.<br><br>Nagyra �rt�kelj�k a l�togat�s�t �s rem�lj�k hasznosnak v�lte a szolg�ltat�sainkat.';
$lang['reject'] = 'Elutas�t';
$lang['unread'] = 'Olvasatlan';
$lang['membership_hdr'] = 'Tags�gi Szint';
$lang['edit_pict'] = 'Els�dleges k�pet m�dos�t';
$lang['edit_thmpnail'] = 'Kisk�pet m�dos�t';
$lang['letter_options'] = 'Lev�l opci�k';
$lang['pic_gallery'] = 'K�pek';
$lang['reactivate'] = 'Felhaszn�l�t �jraaktiv�l';
$lang['cancel_list'] = 'El nem fogadott tagok list�ja';
$lang['cancel_date'] = 'Visszautas�t�s d�tuma';
$lang['language_opt'] = 'Nyelv opci�' ;
$lang['change_language'] = 'Nyelvet m�dos�t';
$lang['with_photo'] = 'Csak k�pekkel';
$lang['logintime'] = 'Bel�p�si id�';
$lang['manage_country_states'] = 'Orsz�g/�llam szerkeszt�s';
$lang['manage_countries'] = 'Orsz�g szerkeszt�s';
$lang['countries_count'] = 'Orsz�g szerkeszt�s';
$lang['insert_country'] = '�j orsz�g';
$lang['modify_country'] = 'Orsz�g m�dos�t�s';
$lang['country_code'] = 'Orsz�g k�d';
$lang['country_name'] = 'Orsz�g n�v';
$lang['manage_states'] = '�llamok szerkeszt�s';
$lang['states_count'] = 'Orsz�gok sz�ma';
$lang['insert_state'] = '�j �llam';
$lang['modify_state'] = '�llam szerkeszt�s';
$lang['state_code'] = '�llam k�d';
$lang['state_name'] = '�llam n�v';
$lang['totalcouples'] = '�sszes tag akik p�rok:';
$lang['active_days'] = 'H�ny napig �rv�nyes?';
$lang['activedays_array'] = array('1'=>'1','7'=>'7','30'=>'30','90'=>'90','180'=>'180','365'=>'365');
$lang['expired'] = 'Az �n tags�ga lej�rt. <a href="payment.php" class="errors">�j�tsa meg tags�g�t</a> �s �lvezze szolg�ltat�sainkat '. 'SITENAME';
$lang['compose'] = 'Fogalmaz';

$lang['logout_login']='Jelsz� tesztel�s: L�pjen ki majd l�pjen be �jra az �j jelsz�val.';
$lang['makefeatured'] = 'Kattintson ide, hogy ezt a profilt a k�l�nleges profilokhoz adja.';
$lang['col_head_gender_short'] = 'Nem';
$lang['no_subject'] = 'Nincs t�rgy';
$lang['admin_col_head_fullname'] = $lang['col_head_fullname'];
$lang['select_from_list'] = '--Kiv�laszt--';

$lang['default_tz'] = '0.00';

$lang['manage_counties'] = 'Megye';
$lang['counties_count'] = 'Megy�k sz�ma';
$lang['insert_county'] = '�j megye';
$lang['modify_county'] = 'Megy�t m�dos�t';
$lang['county_code'] = 'Megye k�d';
$lang['county_name'] = 'Megye neve';
$lang['manage_cities'] = 'V�rosok';
$lang['cities_count'] = 'V�rosok sz�ma';
$lang['insert_city'] = '�j v�ros';
$lang['modify_city'] = 'V�rost m�dos�t';
$lang['city_code'] = 'V�ros k�d';
$lang['city_name'] = 'V�ros neve';
$lang['manage_zips'] = 'Ir�ny�t�sz�m';
$lang['zips_count'] = 'Ir�ny�t�sz�mok sz�ma';
$lang['insert_zip'] = '�j ir�ny�t�sz�m';
$lang['modify_zip'] = 'Ir�ny�t�sz�mot m�dos�t';
$lang['zip_code'] = 'Ir�ny�t�sz�m/Postai k�d';
$lang['show_form'] = 'Szelv�nyt megjelen�t:';
$lang['change_album'] = '�j�t';
$lang['in_your_country'] = 'Felhaszn�l�k akik az orsz�gomban �lnek';
$lang['in_your_state'] = 'Felhaszn�l�k akik az �llamomban �lnek';
$lang['in_your_county'] = 'Felhaszn�l�k akik a megy�mben �lnek';
$lang['in_your_city'] = 'Felhaszn�l�k akik a v�rosomban laknak';
$lang['in_your_zip'] = 'Felhaszn�l�k akiknek ugyanaz az ir�ny�t�sz�muk';
$lang['in_same_gender'] = 'Felhaszn�l�k akiknek ugyanaz a neme';
$lang['in_same_age'] = 'Felhaszn�l�k akik velem egyid�sek';
$lang['above_lookagestart'] = 'Felhaszn�l�k akik id�sebbek n�lam';
$lang['below_lookageend'] = 'Felhaszn�l�k akik fiatalabbak n�lam';
$lang['your_lookgender'] = 'Felhaszn�l�k akik ugyanazt a nemet r�szes�tik el�nyben mint �n';
$lang['in_look_country'] = 'Felhaszn�l�k akik a keresend� orsz�gban �lnek';
$lang['in_look_state'] = 'Felhaszn�l�k akik a keresend� �llamban �lnek';
$lang['in_look_county'] = 'Felhaszn�l�k akik a keresend� megy�ben �lnek';
$lang['in_look_city'] = 'Felhaszn�l�k akik a keresend� v�rosban laknak';
$lang['in_look_zip'] = 'Felhaszn�l�k akik a keresend� ir�ny�t�sz�mn�l laknak';
$lang['in_same_timezone'] = 'Felhaszn�l�k akik az �n id�z�n�mban laknak';


/* Following array is for Profile Window display heading conversion */
$lang['extsearchhead'] = array(
	'Marital Status'		=> 'Csal�di �llapot',
	'Ethnicity'				=> 'Nemzetis�g',
	'Religion'				=> 'Vall�s',
	'Hobbies'				=> 'Hobby',
	'Height'				=> 'Magass�g',
	'Body Type'				=> 'Testfel�p�t�s',
	'Zodiac Sign'			=> 'Csillagjegy',
	'Eye color'				=> 'Szemek sz�ne',
	'Hair color'			=> 'Hajsz�n',
	'Body art'				=> 'Testd�szek',
	'Best feature'			=> 'Legjobb tulajdons�g',
	'Hot spots'				=> 'Kedvenc helyek',
	'Sports'				=> 'Sportok',
	'Favorite things'  		=> 'Kedvenc dolgok',
	'Last reading'			=> 'Utols� olvasm�ny',
	'Common interests'		=> 'K�z�s �rdekelts�g',
	'Sense of humor'		=> 'Humor�rz�k',
	'Exercise'				=> 'Gyakorlatok',
	'Daily diet'			=> 'Napi �trend',
	'Smoking'				=> 'Doh�nyz�s',
	'Drinking'				=> 'Iv�s',
	'Job schedule'			=> 'Munka',
	'Current annual income' => '�vi j�vedelem',
	'Living situation'		=> 'Lakhely',
	'Kids'					=> 'Gyerekek',
	'Want children'			=> 'Gyerekeket szeretne',
	'Weight'				=> 'S�ly',
	'Employment status'		=> 'Foglalkoz�s',
	'Education'				=> 'V�gzetts�g',
	'Languages'				=> 'Nyelvek',
	'Referred by'			=> 'Aj�nlotta',
);

/* user_stats */

$lang['your_user_stats'] = 'Az �n statisztik�i';
$lang['other_user_stats'] = 'M�s felhaszn�l�k statisztik�i';

$lang['user_stats'] = 'Felhaszn�l�i statisztik�k';
$lang['users_match_your_search'] = 'Felhaszn�l�k akik megegyeznek a keres�si krit�riumokkal';

$lang['album_hdr'] = 'Album';
$lang['public'] = 'Publikus';
$lang['calendar_admin'] = 'Napt�r szerkeszt�s';

$lang['mysettings'] = 'Be�l�t�saim';
$lang['user_lists'] = 'Mapp�im';
$lang['login_settings'] = 'Bel�p�si be�l�t�sok';
$lang['no_pics'] = 'Nincs k�p';
$lang['my_page'] = 'Saj�t oldal';
$lang['write_new_msg'] = '�j �zenet';
$lang['view_winkslist'] = 'Kacsint�sokat megn�z';

// Import module
$lang['manage_import'] = 'Import�l';
$lang['manage_import_datingpro'] = 'Import�l�s DatingPro';
$lang['manage_import_aedating'] = 'Import�l�s aeDating';
$lang['manage_import_section'] = 'Import�l� modult kiv�laszt';
$lang['manage_import_select'] = 'Import�lnival�t kiv�laszt';
$lang['module'] = 'Modul';
$lang['imported'] = 'Import�lva';
$lang['import'] = 'Import�l';
$lang['empty'] = '�res';
$lang['select_section'] = 'K�rd�sek kiv�laszt�sa';
$lang['import_db_configuration'] = 'Adatb�zis be�ll�t�s';
$lang['db_name'] = 'DB N�v:';
$lang['db_host'] = 'DB Szerver:';
$lang['db_user'] = 'DB Felhaszn�l�:';
$lang['db_pass'] = 'DB Jelsz�:';
$lang['db_prefix'] = 'DB Prefix:';


// Calendar
$lang['calendar_title'] = 'Napt�r szerkeszt�s';
$lang['total_calendars'] = '�sszes napt�r:';
$lang['modify_calendar'] = 'Napt�rt m�dos�t';
$lang['modify_calendars'] = 'Napt�rakat m�dos�t';
$lang['delete_calendar'] = 'Napt�rt t�r�l';
$lang['delete_calendars'] = 'Napt�rakat t�r�l';

// Calendar Events
$lang['events_title'] = 'Esem�ny szerkeszt�s';
$lang['insert_event'] = '�j esem�ny';
$lang['modify_event'] = 'Esem�nyt m�dos�t';
$lang['total_events'] = 'Kiv�lasztott esem�ny';
$lang['event'] = 'Esem�ny:';
$lang['calendar_field'] = 'Napt�r:';
$lang['private_to'] = 'Priv�t:';
$lang['date_from'] = 'D�tumt�l:';
$lang['date_to'] = 'D�tumig:';
$lang['col_head_calendar'] = 'Napt�r';
$lang['col_head_username'] = 'Felhaszn�l�n�v';
$lang['col_head_fullname'] = 'Teljes N�v';
$lang['col_head_event'] = 'Esem�ny';
$lang['col_head_datefrom'] = 'D�tumt�l';
$lang['col_head_dateto'] = 'D�tumig';
$lang['col_head_date'] = 'D�tum';
$lang['col_head_description'] = 'Le�r�s';

$lang['calendar_title'] = 'Napt�r';
$lang['calendar'] = 'Napt�r:';
$lang['event_title'] = 'Esem�ny';
$lang['add_event'] = '�j esem�ny';
$lang['delete_calendar_group_confirm_msg'] = 'Biztos benne hogy le akarja t�r�lni ezeket a napt�rakat? Az t�rl�s nem vonhat� vissza.';
$lang['private_only'] = 'Csak priv�t';
$lang['public_only'] = 'Csak publikus';
$lang['public_private'] = 'Publikus �s priv�t';
$lang['total_events_found'] = '�sszes esem�ny:';
$lang['start_date'] = 'Kezd� d�tum';
$lang['start_time'] = 'Kezd� id�';
$lang['end_date'] = 'V�gs� d�tum';
$lang['end_time'] = 'V�gs� id�';
$lang['event_description'] = 'Esem�ny le�r�s';

$lang['more_events'] = 'Tov�bbi esem�nyek >>';
$lang['daily_events_list'] = "Esem�nyek list�ja ";
$lang['add_to_private'] = "Priv�t list�hoz hozz�ad";
$lang['close_window'] = "Ablakot bez�r";
$lang['main_window_closed'] = "Sajn�lom, a f�ablakot bez�rta.";
$lang['user_added1'] = "Felhaszn�l� ";
$lang['user_added2'] = " Priv�t list�hoz volt hozz�adva";
$lang['next_month'] = 'K�vetkez� h�nap';
$lang['previous_month'] = 'El�z� h�nap';
$lang['next_week'] = 'K�vetkez� h�t';
$lang['previous_week'] = 'El�z� h�t';
$lang['next_day'] = 'K�vetkez� Nap';
$lang['previous_day'] = 'El�z� Nap';
$lang['view_day'] = 'Nap megtekint�s';
$lang['view_week'] = 'H�t megtekint�s';
$lang['view_month'] = 'H�nap megtekint�s';

$lang['watched_events'] = 'Megfigyelend� esem�nyek';
$lang['event_notification'] = 'Esem�nyekr�l val� �rtes�t�s';

$lang['jump_to'] = 'Ugr�s';
$lang['ok'] = 'OK';

$lang['recurring'] = "Ism�tl�s:";
$lang['recur_every'] = "minden";

$lang['recuring_labels'] = array(
	'0' => 'soha',
	'1' => 'napok',
	'2' => 'hetek',
	'3' => 'h�napok',
	'4' => '�vek'
	);

$lang['calendat_filter_dates_range'] = "Kiv�lasztott d�tum terjedelem";
$lang['calendat_filter_last_year'] = "El�z� �v";
$lang['calendat_filter_last_month'] = "El�z� h�nap";
$lang['calendat_filter_last_week'] = "El�z� h�t";
$lang['calendat_filter_yesterday'] = "Tegnap";


$lang['cannot_determine_membership'] = 'A tags�gi szintje meg nem hat�rozhat�';
$lang['no_previous_polls'] = 'Nincs el�z� szavaz�s.';
$lang['no_event_for_the_day'] = "Nincs esem�y ezen a d�tumon.";
$lang['maxsize'] = 'Maxim�lis m�ret (KB)';
$lang['views'] = 'N�zet';

/******************************************/
/* ALL ERROR MESSAGES ARE DEFINED BELOW.  */
/******************************************/

// Affiliates error
$lang['affiliates_error'] = array(
	18 =>'Jelszavak nem egyeznek meg.',
	20 =>'Minden k�telez� mez�.',
	21 =>'Minden mez� k�telez�.',
	25 =>'A be�rt email-c�m m�r megtal�lhat� adatb�zisunkba mint t�rshirdet�. V�lasszon m�sik email c�met.'
);


// Javascript error messages
$lang['admin_js_error_msgs'] = array(
	'',
	'El�sz�r v�lasszon ki egy dobozt.',
	'Biztos benne, hogy le akarja t�r�lni?',
	'Biztos benne, hogy t�r�lni akarja ezt a bannert?'
	);

$lang['admin_js__delete_error_msgs'] = array('',
	1=> 'Biztos benne hogy t�r�lni akarja ezt a r�szt? A folyamat nem vonhat� vissza.',
	2=> 'Biztos benne hogy t�r�lni akarja ezt a szekci�t ebb�l a r�szb�l? A folyamat nem vonhat� vissza.',
	3=> 'Biztos benne hogy t�r�lni akarja ezt a k�rd�s szekci�t? A folyamat nem vonhat� vissza.',
	4=> 'Biztos benne hogy t�r�lni akarja ezt a profilt? A folyamat nem vonhat� vissza.',
	5=> 'Biztos benne hogy t�r�lni akarja ezt a h�rt? A folyamat nem vonhat� vissza.',
	6=> 'Biztos benne hogy t�r�lni akarja ezt a sztoryt? A folyamat vissza nem �ll�that�.',
	7=> 'Biztos benne hogy t�r�lni akarja ezt a cikket? A folyamat vissza nem �ll�that�.',
	8=> 'Biztos benne hogy t�r�lni akarja ezt a szavaz�st? A folyamat nem vonhat� vissza.',
	9=> 'Biztos benne hogy t�r�lni akarja ezt a szavaz�si opci�t? A folyamat nem vonhat� vissza.',
	10=> 'Biztos benne hogy t�r�lni akarja ezt a bannert? A folyamat nem vonhat� vissza.',
	11=> 'Biztos benne hogy t�r�lni akarja ezt az admint? A folyamat nem vonhat� vissza.',
/* Added in RC6 */
	12=>'Biztos benne hogy t�r�lni akarja ezt az orsz�got?',
	13=>'Biztos benne hogy t�r�lni akarja ezt az �llamot?',
	14=>'Biztos benne hogy t�r�lni akarja ezeket az orsz�gokat?',
	15=>'Biztos benne hogy t�r�lni akarja ezeket az �llamokat?',
	16=>'R�szletes fejl�c sz�ks�ges a keres�shez.',
	17 => 'Felhaszn�l�n�v be�r�sa sz�ks�ges a kiv�laszt�shoz.',
	18 => 'Biztos benne hogy t�r�lni akarja ezt a profilt? A folyamat nem vonhat� vissza.',
/* Added Release 1.0 */
	19=>'Biztos benne hogy t�r�lni akarja ezt a megy�t?',
	20=>'Biztos benne hogy t�r�lni akarja ezeket a megy�ket?',
	21=>'Biztos benne hogy t�r�lni akarja ezt a v�rost?',
	22=>'Biztos benne hogy t�r�lni akarja ezeket a v�rosokat?',
	23=>'Biztos benne hogy t�r�lni akarja ezt az ir�ny�t�sz�mot?',
	24=>'Biztos benne hogy t�r�lni akarja ezeket az ir�ny�t�sz�mokat?',

	25 => 'Biztos benne hogy t�r�lni akarja ezt az esem�nyt? A folyamat nem vonhat� vissza.',
	26 => 'Biztos benne hogy t�r�lni akarja ezt a napt�rt? A folyamat nem vonhat� vissza.',
	27 => 'Biztos benne hogy t�r�lni akarja ezt az oldalt? A folyamat nem vonhat� vissza.',
	);


// Don't use double qoutes(") in the item's text
$lang['signup_js_errors'] = array(
	'username_noblank' => '�rjon be egy felhaszn�l�nevet.' ,
	'password_noblank' => '�rjon be egy jelsz�t.',
	'old_password_noblank' => 'R�gi jelsz� sz�ks�ges.',
	'new_password_noblank' => '�j jelsz� sz�ks�ges.',
	'con_password_noblank' => '�rv�nyes�t� jelsz� sz�ks�ges.',
	'firstname_noblank' => 'Csal�dn�v sz�ks�ges.',
	'name_noblank' => 'Irja be a csal�dnev�t.',
	'lastname_noblank' => 'Keresztn�v sz�ks�ges.',
	'email_noblank' => 'Email-c�m sz�s�ges.',
	'city_noblank' => 'V�rosn�v sz�ks�ges.',
	'zip_noblank' => 'Ir�ny�t�sz�m sz�ks�ges.',
	'address1_noblank' => 'Legal�bb egy c�m sz�ks�ges.',
	'sectionname_noblank' => 'N�v sz�ks�ges.',
	'sendname_noblank' => 'K�ld� neve sz�ks�ges.',
	'calendarname_noblank' => 'Napt�r n�v sz�ks�ges.',
	'comments_noblank' => 'Hozz�sz�l�s sz�ks�ges.',
	'question_noblank' => 'K�rd�s sz�ks�ges.',
	'extsearchhead_noblank' => 'R�szletes keres� fejl�c sz�ks�ges.',
	'username_charset' => 'Csak sz�mok �s bet�k haszn�lhat�ak a felhaszn�l�n�vben.',
	'password_charset' => 'Csak sz�mok �s bet�k haszn�lhat�ak a jelsz�ban.',
	'firstname_charset' => 'Csak bet�k haszn�lhat�ak a csal�dn�vben.',
	'lastname_charset' => 'Csak bet�k haszn�lhat�ak a keresztn�v.',
	'city_charset' => 'Csak bet�k haszn�lhat�ak a v�ros nev�ben.',
	'zip_charset' => 'Csak sz�mok haszn�lhat�ak az ir�ny�t�sz�mban.',
	'address_charset' => '�rv�nyes c�m sz�ks�ges.',
	'sectionname_charset' => 'Csak bet�k haszn�lhat�ak egy r�sz nev�ben.',
	'calendarname_charset' => 'Csak bet�k haszn�lhat�ak egy napt�r nev�ben.',
	'sendname_charset' => 'Csak bet�k haszn�lhat�ak a k�ld� nev�ben.',
	'name_charset' => 'Csak bet�k haszn�lhat�ak a n�v mez�ben.',
	'maxlength_charset' => '�rjon be egy maxim�lis �rt�ket a hossz�s�gnak.',
	'email_notvalid' => 'Email-c�m nem �rv�nyes.',
	'password_nomatch' => 'A jelszavak nem egyeznek meg.',
	'password_outrange' => 'A jelsz� hossz�s�ga a megadott tartom�nyban kell legyen.',
	'username_outrange' => 'A felhaszn�l�n�v hossz�s�ga a megadott tartom�nyban kell legyen.',
	'username_start_alpha' => 'A felhaszn�l�n�v bet�vel kell kezd�dj�n.',
	'ccowner_noblank' => 'Hitelk�rtya tulajdonos�nak a nev�t meg kell adni.',
	'ccnumber_noblank' => 'Meg kell adni a hitelk�rtya sz�m�t.',
	'cvvnumber_noblank' => 'Meg kell adni a hitelk�rtya ellen�rz�si sz�m�t.',
	'select_payment' => 'El�sz�r v�lasszon fizet�si m�dot.',
	'stateprovince_noblank' => 'L�tez� �llamot/r�gi�t kell megadni.',
	'subject_noblank'	=> 'A lev�l t�rgy�t meg kell adni.',
	'county_noblank' => 'Az orsz�got meg kell adni.',
	'county_charset' => 'Az orsz�g neve csak bet�kb�l �llhat.',
	'timezone_noblank' => 'V�lassza ki az id�z�n�t.',
/* Added in 2.0 */
	'ratingname_noblank' => 'Meg kell adni az �rt�kel�s nev�t.',
	'ratingname_charset' => '�rv�nytelen karakterek az �rt�kel�s nev�ben.',
	'about_me_noblank' 	=> 'Meg kell adnia inform�ci�kat mag�r�l.',
	);
$lang['signup_js_errors']['zip_noblank'] = 'Ir�ny�t�sz�mot/ Postai k�dot meg kell adni.';
$lang['signup_js_errors']['zip_charset'] = 'Az ir�ny�t�sz�mban csak sz�mok megengedettek';

$lang['letter_errormsgs'] = array(
		0 => 'A jelszav�t elk�ldt�k emailben, ellen�rizze leveleit.',
		1 => 'Adja meg a regisztr�ci�kor haszn�lt email-c�met.',
		2 => 'Nem tal�lhat� az elfelejtett jelsz� sablon. K�rj�k, sz�ljon egy adminisztr�tornak!',
		4 => 'Probl�ma l�pett fel az email k�ld�sekor. K�rj�k, sz�ljon egy adminisztr�tornak!',
		5 => '�n nem az SITENAME regisztr�lt tagja. Azt az email cimet adja meg, amit regisztr�ci�n�l haszn�lt.'
	);

$lang['taf_errormsgs'] = array(
		0 => 'A meghiv�t elk�ldt�k.',
		'sendername_noblank' => 'Adja meg a nev�t.',
		'senderemail_noblank' => 'Adja meg email-c�m�t.',
		'recipientemail_noblank' => 'Adja meg a c�mzett email-c�m�t.',
		'sendername_charset' => 'Csak bet�ket haszn�lhat a n�vben.',
		'senderemail_charset' => 'Val�s email c�met kell megadnia.',
		'recipientemail_charset' => 'Adjon meg egy val�s email-c�met a cimzettnek.',
		2 => 'Nem tal�lhat� a meghiv� sablon. K�rj�k, sz�ljon egy adminisztr�tornak!',
		3 => 'Hiba a meghiv� k�ld�sekor. K�rj�k, sz�ljon egy adminisztr�tornak!',
	);
$lang['pages_errormsgs'] = array( '',
	1 => 'Az oldal c�me hi�nyzik.',
	2 => 'Az oldal kulcsa hi�nyzik.',
	3 => 'Az oldal sz�vege hi�nyzik.',
	4 => 'Az oldalkulcs m�r l�tezik, v�lasszon m�sikat.',
	5 => 'Az oldal t�r�lve.',
	);

$lang['artile_error'] = array(
	1 => 'Sz�ks�g van a cikk cim�re.',
	2 => 'Sz�ks�g van a cikk sz�veg�re.',
	3 => 'Sz�ks�g van a cikk d�tum�ra.'
);
$lang['story_error'] = array(
	1 => 'Sz�ks�g van a t�rt�net fejl�c�re.',
	2 => 'Sz�ks�g van a t�rt�net cim�re.',
	3 => 'Sz�ks�g van a t�rt�net d�tum�ra.',
	4 => 'Meg kell adni a t�rt�net k�ld�j�t.'
);
$lang['news_error'] = array(
	1 => 'Meg kell adni a h�r fejl�c�t.',
	2 => 'Meg kell adni a h�r sz�veg�t.',
	3 => 'Meg kell adni a h�r d�tum�t.'
);

$lang['mship_errors'] = array (
	1 => 'Meg kell adnia a nev�t.',
	2 => 'Meg kell adnia az �rat.',
	3 => 'Meg kell adnia a p�nznemet.',
	4 => 'Fizet�s n�lk�l csak az ingyenes tags�got lehet v�lasztani.'
);
$lang['admin_error_msgs'] = array (
	'',
	'Meg kell adnia a ter�letet.',
	'T�lts�n ki minden k�rt mez�t.'
	);
$lang['admin_error'] = array(
	'',
	1 => 'Az admin felhaszn�l� nem lehet �res.',
	2 => 'Az admin jelsz� nem lehet �res.',
	3 => 'Az admin neve nem lehet �res.',
	4 => 'A r�gi jelsz� nem lehet �res.',
	5 => 'Az �j jelsz� nem lehet �res.',
	6 => 'A meger�s�tett jelsz� nem lehet �res.',
	7 => 'A jelsz� �s a meger�s�t�s nem egyezik meg.',
	8 => 'Hib�s a r�gi jelsz�.',
	9 => 'A felhaszn�l�i n�v m�r haszn�latban van.',
	/* added in 1.1.0 */
	10 => 'Csak sz�veget haszn�lhat a szekci� megad�s�n�l'
);

$lang['banner_error_msgs'] = array( '',
	1 => 'A banner nem maradhat �resen.',
	2 => 'A link c�me (URL) nem maradhat �resen.',
	3 => 'A megjegyz�s nem lehet �res.',
	4 => 'Csak .jpg bannerok enged�lyezettek.'
);
$lang['poll_error'] = array(
	1 => 'A szavaz�s nem lehet �res.',
	2 => 'A szavaz�s d�tuma nem lehet �res.',
	3 => 'Az opci� nem lehet �res.',
	'txtpoll_noblank'  => 'A szavaz�s egy k�telez� mez�.',
	'txtpollopt_noblank'  => 'Az opci� egy k�telez� mez�.'
	);

$lang['datetime_month'] = array(
	1=>'Janu�r',
	2=>'Febru�r',
	3=>'M�rcius',
	4=>'�prilis',
	5=>'M�jus',
	6=>'J�nius',
	7=>'J�lius',
	8=>'Augusztus',
	9=>'Szeptember',
	10=>'Okt�ber',
	11=>'November',
	12=>'December'
);
$lang['datetime_day'] = array(
	'sunday' => 'Vas�rnap',
	'monday' => 'H�tf�',
	'tuesday' => 'Kedd',
	'wednesday' => 'Szerda',
	'thursday' => 'Cs�t�rt�k',
	'friday' => 'P�ntek',
	'saturday' => 'Szombat'
);


/* Release 1.0.2   */
$lang['settings_saved'] = 'A be�ll�t�sokat sikeresen elmentett�k.';
$lang['select_image_first'] = 'V�lassza ki el�sz�r a k�pet';

/* Release 1.1.0 additions */
$lang['day_names'] = array(
	'Sun' => 'Vas�rnap',
	'Mon' => 'H�tf�',
	'Tue' => 'Kedd',
	'Wed' => 'Szerda',
	'Thu' => 'Cs�t�rt�k',
	'Fri' => 'P�ntek',
	'Sat' => 'Szombat'
);
$lang['view_type'] = 'T�pust megn�z';
$lang['remember_me'] = 'Eml�keztess';
$lang['review'] = 'N�zet';
$lang['spammers'] = 'Spammerek';
$lang['addquestion'] = '�j k�rd�s';
$lang['mainstats'] = 'F� statisztik�k';
$lang['osdate_version'] = 'osDate verzi�';
$lang['signonstats'] = 'Bel�p�si statisztik�k';
$lang['usersinpastminute'] = 'Felhaszn�l�k az elm�lt percben';
$lang['usersinpasthour'] = 'Felhaszn�l�k az elm�lt �r�ban';
$lang['usersinpastday'] = 'Felhaszn�l�k az elm�lt napon';
$lang['usersinpastweek'] = 'Felhaszn�l�k az elm�lt h�ten';
$lang['usersinpastmonth'] = 'Felhaszn�l�k az elm�lt h�napban';
$lang['usersinpastyear'] = 'Felhaszn�l�k az elm�lt �vben';
$lang['usersinpast2years'] = 'Felhaszn�l�k az elm�lt 2 �vben';
$lang['usersinpast5years'] = 'Felhaszn�l�k az elm�lt 5 �vben';
$lang['usersinpast10years'] = 'Felhaszn�l�k az elm�lt 10 �vben';
$lang['userstats'] = 'Felhaszn�l�i statisztik�k';
$lang['totalusers'] = '�sszes felhaszn�l�';
$lang['totalactiveusers'] = '�sszes akt�v felhaszn�l�';
$lang['totalpendingusers'] = '�sszes v�rakoz� felhaszn�l�';
$lang['totalsuspendedusers'] = '�sszes letiltott felhaszn�l�';
$lang['totalpictureusers'] = '�sszes fot�val rendelkez� felhaszn�l�';
$lang['totalonlineusers'] = 'Online felhaszn�l�k';
$lang['visitorstats'] = 'L�togat�i statisztika';
$lang['sitestats'] = 'Oldal sztatisztik�k';
$lang['visitorstosite'] = 'L�togat�k sz�ma';
$lang['mostactivepage'] = 'Legakt�vabb oldal';
$lang['timesfeedback'] = 'Ennyi �rlap volt haszn�lva';
$lang['timesim'] = 'Ennyi IM volt haszn�lva';
$lang['timeswink'] = 'Ennyi kacsint�s volt elk�ldve';
$lang['timesmessage'] = 'Ennyi �zenet volt elk�ldve';
$lang['timesinvitefriend'] = 'Ennyi megh�v� volt elk�ldve';
$lang['timeshowprofile'] = 'Ennyiszer volt megtekintve a profil';
$lang['timesonlineusers'] = 'Ennyiszer klikkeltek az online felhaszn�l�k';
$lang['timesbanner'] = 'Ennyi banner klikk volt';
$lang['timesnewmember'] = 'Ennyi �j tag klikk volt';
$lang['timespoll'] = 'Ennyi szavaz�s volt';
$lang['timesgallery'] = 'Ennyiszer volt haszn�lva a fot�gal�ria';
$lang['timesaffiliates'] = 'Ennyi klikk volt az t�rshirdet�kre';
$lang['timessignup'] = 'Ennyi regisztr�ci�s klikk volt';
$lang['timesnews'] = 'Ennyi h�r klikk volt';
$lang['timesstories'] = 'Ennyi t�rt�net klikk volt';
$lang['timessearchmatch'] = 'Ennyiszer volt haszn�lva a keres�';
$lang['no_affiliates'] = 'T�rshirdet�k sz�ma';
$lang['no_affiliate_refs'] = 'T�rshirdet�k hivatkoz�sainak sz�ma';
$lang['no_pages_refs'] = 'Oldal hivatkoz�sok sz�ma';
$lang['no_polls'] = 'Szavazatok sz�ma';
$lang['no_news'] = 'H�rekk sz�ma';
$lang['no_stories'] = 'T�rt�netek sz�ma';
$lang['no_langs'] = '�sszes nyelv';
$lang['glblgroups'] = 'Glob�lis be�ll�t�sok a csoportra';
$lang['accept_tos'] = 'Elolvastam �s elfogadtam a <a href="javascript:popUpScrollWindow('."'tos.php','center',650,600);".'"> felt�teleket.</a>';
$lang['tos_must'] = 'K�rj�k, olvassa el �s fogadja el a Felt�teles Szolg�ltat�sok oldalt miel�tt beregisztr�lna.';
$lang['private_event'] = 'Ez az esem�ny inform�ci� priv�t';
$lang['posted_by'] = '�rta';

$lang['countries01']='Orsz�gok';
$lang['states01'] = '�llamok';
$lang['latitude'] = 'Sz�less�g';
$lang['longitude'] = 'Hossz�s�g';
$lang['search_within'] = 'Keres�s k�z�tt';
$lang['miles'] = ' m�rf�ld ';
$lang['kms'] = ' kil�m�ter ';
$lang['no_search_results'] = '<font color=red><b>Nincs tal�lat</b></font><br /><br />Nincs tal�lat a megadott krit�riumokra. Pr�b�lja cs�kkenteni a krit�riumokat, vagy n�velje a keres�si tartom�nyokat.<br /><br />';
$lang['expire_on'] = 'Tags�g lej�rati ideje';
$lang['expire_in'] = 'H�tral�v� napok a tags�g lej�rt�ig';
$lang['lang_to_load'] = 'Bet�ltend� nyelv';
$lang['load_lang'] = 'Nyelv bet�lt�se';
$lang['manage_languages'] = 'Nyelvek kezel�se';
$lang['manage_zips'] = 'Ir�ny�t�sz�mok kezel�se';
$lang['zipfile'] = 'Ir�ny�t�sz�m f�jl';
$lang['zip_loaded'] = 'A ir�ny�t�sz�mok ebb�l a f�jlbol vannak bet�ltve: ';
$lang['file_not_found'] = 'A megadott f�jl nem tal�lhat�';
/* Modified in 1.1.0 */
$lang['success_mship_change'] = 'K�sz�nj�k a tags�g frissit�s�t/�jit�s�t. <br /><br />Tags�gi szintje megv�ltozott erre: ';
$lang['payment_cancel'] = 'Fizet�s visszavonva';
$lang['checkout_cancel'] = 'Amint k�rte, fizet�si k�r�s�t visszovontuk.';
$lang['useronlinetext'] = array(
	'online_now'		=> 	'Most Online',
	'active_24hours'	=> 	'Akt�v az elm�lt 24 �r�ban',
	'active_3days'		=>	'Akt�v az elm�lt 3 napon',
	'active_1week'		=>	'Akt�v az elm�lt 1 h�tben',
	'active_1month'		=>	'Akt�v az elm�lt 1 h�napban',
	'notactive'			=>	'R�g�ta nem akt�v'
);
$lang['useronlinecolor'] = array(
	'online_now'		=> 	'#FF0000',
	'active_24hours'	=> 	'#00AA00',
	'active_3days'		=>	'#AA00A0',
	'active_1week'		=>	'#0000AA',
	'active_1month'		=>	'#000000',
	'notactive'			=>	'#838383'
);

$lang['transactions_report'] = '�tutal�si jelent�sek';
$lang['trans_count'] = '�tutal�sok sz�ma';
$lang['pay_no'] = 'Fizet�s sz�m';
$lang['ref_no'] = 'Hivatkoz�si sz�m';
$lang['paid_thru'] = 'Ezen kereszt�l val� fizet�s';
$lang['pay_status'] = 'St�tusz';
$lang['trans_rep'] = '�tutal�si jelent�s';
$lang['expiry_interval'] = array(
	'1'		=> '24 Ora',
	'3'		=>	'3 Nap',
	'7'		=>	'7 Nap',
	'15'	=>	'15 Nap',
	'30'	=>	'30 Nap',
	'0'		=>	'Lej�rt'
	);
$lang['expiry_hdr'] = 'Tags�g lej�rt�ra eml�keztet� lev�l';
$lang['expiry_ltr'] = 'Tags�g lej�rt�ra figyelmeztet� lev�l';
$lang['expiry_select'] = 'V�lassz  id�k�zt';
$lang['expird'] = 'Lej�rt';
$lang['expiry_ltr_sent'] = 'Lej�rati id�re eml�keztet�k elk�ldve';
$lang['searching_within'] = 'Keres�s ezek k�z�tt';
$lang['payment_failed'] = 'Nem siker�lt a fizet�s feldolgoz�sa, pr�b�lja �jra';
$lang['payment_fail'] = 'Nem siker�lt a fizet�s';
$lang['deactivate'] = 'Kikapcsol';

$lang['open_search'] = 'Nyitott Keres�s';
$lang['replace'] = 'Helyettes�t';
$lang['new'] = '�j';
$lang['no_save'] = 'Nem ker�l elment�sre';
$lang['modify_curr_search'] = 'M�dositsa a keres�si krit�riumokat';
$lang['perform_search'] = '�s keressen.';
$lang['start_new_search'] = '�j keres�s';
$lang['use_empty_form'] = '�res �rlappal.';
$lang['of_zip_code'] = 'ennek az ir�ny�t�sz�mnak';

/* MOD START */

$lang['profile_ratings'] = 'Profil �rt�kel�s';
$lang['total_ratings'] = '�sszes �rt�kel�s';
$lang['delete_ratings'] = '�rt�kel�st t�r�l';
$lang['delete_rating_group_confirm_msg'] = 'Biztosan t�r�lni akarod? A folyamat nem vonhat� vissza.';
$lang['delete_rating_confirm_msg'] = 'Biztosan t�r�lni akarod? A folyamat nem vonhat� vissza.';
$lang['modify_rating'] = '�rt�kel�st m�dos�t';
$lang['modify_ratings'] = '�rt�kel�seket m�dos�t';

$lang['glblsettings_groups']['50'] = 'Profil �rt�kel�sel';
$lang['mod_lowtohigh']['Low to High'] = 'Alacsonyr�l magasra';
$lang['mod_lowtohigh']['High to Low'] = 'Magasr�l alacsonyra';
$lang['admin_rights']['profile_ratings'] = 'Profil �rt�kel�sek';

$lang['custom_message'] = 'Szem�lyes �zenet';
$lang['notify_me'] = '�rtes�tsen az elolvas�skor.';
$lang['include_profile'] = 'Profilom hozz�f�z�se.';
$lang['message_templates'] = '�zenet sablonok';
$lang['my_templates'] = 'Saj�t sablonok';
$lang['template_select'] = 'V�lasszon egy sablont';
$lang['template_intro'] = 'Ha sokszor k�ldi el ugyanazokat az �zeneteket, akkor l�trehozhat sablonokat. Sablonv�ltoz�kat haszn�lva, mint [felhaszn�l�n�v] �s [keresztn�v], szem�lyre szabhatja a sablonokat.';

$lang['add_template'] = 'Sablon hozz�ad�sa';
$lang['return_message'] = 'Visszat�r�s az �zenethez';
$lang['delete_template_confirm_msg'] = 'Biztosan t�rl�d a sablont? A folyamat nem vonhat� vissza.';
$lang['edit_template'] = 'Sablon szerkeszt�se';

$lang['template_instructions'] = 'A k�vetkez� sablonv�ltoz�k el�rhet�ek: <br />
[felhaszn�l�n�v], [keresztn�v], [v�ros], [�llam], [orsz�g], [�letkor]<br /><br />Ezekkel szem�lyre szabhatja az �zeneteit, pl.:<br /><br />hello [firstname]!<br /><br />�szrevettem, hogy mindketten [v�rosn�v]-b�l vagyunk :) �gy gondolom tal�lunk, dobj meg egy emaillel<br /><br />�dv,<br />neved';

$lang['your_comment'] = 'Megjegyz�seidKomment�rjaid';
$lang['your_reply'] = 'V�laszaid';
$lang['comment_note'] = 'A 255 karaktern�l hosszabb megjegyz�seket csonk�tjuk.';
$lang['chars_remaining'] = 'karakter maradt';

$lang['delete_comment_confirm_msg'] = 'Biztosan t�rl�d a megjegyz�st? A folyamat nem vonhat� vissza.';
$lang['no_msg_templates'] = 'Nincs �zenetsablon.';
/* MOD END */

$lang['select'] = '- Kiv�laszt -';
$lang['select_country'] = 'Orsz�g';
$lang['select_state'] = '�llam';
$lang['select_county'] = 'Megye';
$lang['select_city'] = 'V�ros';
$lang['confirm_success'] = 'L�pj be, hogy haszn�lhasd tags�godat.';
$lang['signup_success_message'] = '<b>K�sz�nj�k!</b><br /><br />&nbsp;Mostm�r az SITENAME regisztr�lt tagja vagy.';
$lang['noone_online'] = 'Nincs Online Tag';
$lang['in_hot_list'] = 'Felhaszn�l� a kedvencek list�n';
$lang['in_buddy_list'] = 'Felhaszn�l� a partner list�n';
$lang['in_ban_list'] = 'Felhaszn�l� a letiltottak list�n';
$lang['delete_search'] = 'Keres�s t�rl�se';
$lang['select_user_to_send_message'] = 'V�lassz cimzett felhaszn�l�t';
$lang['no_im_msgs'] = 'Nincs �zenet';
$lang['public_event'] = 'Ez az esem�ny nyilv�nosan megtekinthet�';
$lang['no_event_description'] = 'Nincs le�r�s';
$lang['signup_js_errors']['country_noblank'] = 'Nincs megadva orsz�g';
$lang['msg_sent'] = '�zenet�t elk�ldt�k.';
$lang['forgotpass_msg4'] = 'Elfelejtetted a bejelentkez�si adataid? A felhaszn�l�neved �s egy �j jelsz�t k�ldhet�nk a regisztr�ci�kor megadott email c�medre.';

/* 	Additions for new email messaging interface
	Vijay Nair
*/
$lang['send_a_message'] = '�zenetet k�ld';
$lang['flagged'] = 'Megjel�lt';
$lang['un_flagged'] = 'Nem megjel�lt';
$lang['unflagged_msg1'] = 'A t�bb, mint ';
$lang['unflagged_msg2'] = ' napos nem megjel�lt �zenetek automatikusan t�rl�dnek.';
$lang['no_messages_in_box'] = 'Nincsenek �zenetek ebben a mapp�ban';
$lang['no_flagged_messages_in_box'] = 'Nincsenek megjel�lt �zenetek ebben a mapp�ban';
$lang['no_unflagged_messages_in_box'] = 'Nincsenek nem-megjel�lt �zenetek ebben a mapp�ban';
$lang['mark'] = 'Kijel�l';
$lang['flag'] = 'Megjel�l';
$lang['unflag'] = 'Lez�szl�z';
$lang['msg_flagged'] = '�zenet megjel�lt';
$lang['msg_unflagged'] = '�zenet nem megjel�lt';
$lang['msg_deleted'] = '�zenet t�r�lve';
$lang['sel_msgs_flagged'] = 'Kiv�lasztott �zenetek megjel�lve';
$lang['sel_msgs_unflagged'] = 'Kiv�lasztott �zenetek megjel�l�s�t megsz�nteti';
$lang['sel_msgs_deleted'] = 'Kijel�lt �zenetek t�r�lve';
$lang['sel_msgs_undeleted'] = 'Kijel�lt t�r�lt �zenetek �zenetek visszahozva';
$lang['sel_msgs_read'] = 'Kijel�lt �zenetek olvasottnak jel�lve';
$lang['sel_msgs_unread'] = 'Kijel�lt �zenetek �jnak jel�lve';
$lang['FROM1'] = 'K�ld�';
$lang['no_thanks'] = 'Mondja \"Nem, k�sz�n�m\"';
$lang['reply'] = 'V�lasz';
$lang['undelete'] = 'T�rl�st visszavon';
$lang['back_to_messages'] = 'Vissza az �zenetekhez';
$lang['replied'] = 'V�lasz elk�ldve';
$lang['no_thanks_subject'] = 'K�sz�n�m, de nem kell...';
$lang['total'] = '�sszes';
$lang['max_allowed'] = '�sszes megengedett';
$lang['im_msg_long'] = '�zenet hosszabb, mint a megengedett m�ret ';
$lang['members'] = 'Tagok';
$lang['To1'] = 'C�mzett';

/* Items which are modified in 1.1.0 */


$lang['change_email'] = 'Emailt v�ltoztat';

/* Changes made for letters  */
$lang['no_watched_event'] = 'Nem figyelt semmilyen esem�nyt.
<br /><br />�sszesen #eventcount# esem�ny lesz a k�vetkez� 30 napban. <a "#calenderlink#">Nyissa meg a napt�rt</a> az esem�nyek megtekint�s�hez.
<br /><br />Egy esem�ny figyel�s�hez kattintson az esem�nyre a napt�rban majd kattintson a nagyit� ikonra #glassicon#
<br /><br />Minden megfigyel�s lej�r az esem�ny bek�vetkez�se ut�n.';

$lang['no_thanks_message']['text'] = 'Szia #recipient_username#,

K�sz�n�m az �rdekl�d�sed, de tisztelettel visszautas�tom. Rem�lem megtal�lod a p�rod.

�dv�zlettel,
#sender_username#';

$lang['message_read']['text'] = "Kedves #FirstName#,

A '#RecipientName#'-nak/nek k�ld�tt �zenet el lett olvasva.

Sok Szerencs�t!
#AdminName#
SITENAME";


$lang['featured_profile_added']['text'] = "Kedves #FirstName#,

�r�mmel jelen�tj�k meg profilodat a k�l�nleges profilok list�j�n a(z) <a href=\"#link#\">#siteName#</a> oldalon.
A profilod #FromDate# �s #UptoDate# k�z�tt fog megjelenni.

�gy l�that�bb� v�lik a profilod �s val�szin�leg t�bb �rdekelt fogja megtekinteni.

Sok Szerencs�t!
#AdminName#
SITENAME";

$lang['wink_received']['text'] = "Kedves #FirstName#,

'#SenderName#' r�d kaccsintott a(z) #siteName# oldalon.

L�togasd meg a <a href=\"#link#\">#siteName#</a> weboldalt, hogy v�laszt k�ldhess.


Sok Szerencs�t!
#AdminName#
SITENAME";

$lang['invite_a_friend']['text'] = "Hello,

Tal�ltam egy j� t�rskeres� oldalt: #SiteUrl#
�gy gondolom ez t�ged is �rdekelhet.

L�togasd meg itt: #SiteUrl#.

#FromName#";

$lang['profile_confirmation_email']['text'] = "Kedves #FirstName#,

K�sz�nj�k, hogy regisztr�lt a #SiteName# oldalon. Mint a k�z�ss�g leg�jabb tagj�t, k�r�nk n�zze v�gig
a szolg�ltat�sainkait �s a lehet�s�geket.

A regisztr�ci� �rv�nyes�t�s�hez kattintson az al�bbi linkre, vagy m�solja be a b�ng�sz�je ablak�ba.

#ConfirmationLink#=#ConfCode#

Ha m�g nyitva van a b�ng�sz�je a regisztr�ci� utols� l�p�sek�nt megadhatja a k�dot:
#ConfCode#

Felhaszn�l�i adatai

Felhaszn�l�i n�v: #StrID#
Jelsz�: #Password#
E-Mail: #Email#

Egyes szolg�ltat�sok magasabb tags�gi rangot k�vetelhetnek, a v�lt�shoz kattintson az al�bbi c�mre

#SiteUrl#payment.php

K�sz�nj�k a regisztr�ci�t, �s rem�lj�k megtal�lja p�rj�t!

#AdminName#
#SiteName#";

/* Added in 1.1.1 */
$lang['loading'] = 'Bet�lt�s..';


/* Changes in 1.1.3 */
$lang['support_currency'] = array(
		'USD' 	=> '$',
		'EUR'	=>'EUR',
		'INR'	=>'Rs.',
		'AUD'	=> 'AU$',
		'CD'	=> 'CAN$',
		'UKP'	=> chr(163)
		);


$lang['ratings'] = '�rt�kel�s';
$lang['comment'] = 'Hozz�sz�l�s';
$lang['comments'] = 'Hozz�sz�l�s';
$lang['loadaction'] = 'Akci� kiv�laszt�sa sz�ks�ges';
$lang['loadintodb'] = 'Adatb�zisba bet�lt';
$lang['createsql'] = 'SQL Szkriptet k�pez';

$lang['load_zips'] = 'Ir�ny�t�sz�m/Ir�ny�t�sz�mok f�jl bet�lt�se';



/* Version 2.0 additions and modifications */
/* Modifications */
$lang['submit'] = 'Elk�ld';
$lang['lang_ensure'] = 'El�bb adjon meg egy �j nyelvet �s f�jlnevet a config.php-ben. Ut�na t�ltse fel a nyelv f�jlt a /language/lang_xxxx/ k�nyvt�rba lang_main.php n�ven.';

/* $lang['rate_catefully'] is changed as below */
$lang['rate_carefully'] = 'Az oldal �zemeltet�i nem felelnek az �rt�kel�sek pontoss�g��rt �s megbizhat�s�g��rt. Ezek a felhaszn�l�k �ltal vannak bek�ldve �s nincsenek az �zemeltet�k �ltal ellen�rizve.';


$lang['privileges'] = array (
	'chat' 				=> 'Chaten val� r�szv�tel.',
	'blog'				=> 'Blogol�sban val� r�szv�tel.',
	'poll'				=> 'Szavaz�s.',
	'forum'				=> 'F�rumban val� r�szv�tel.',
	'includeinsearch' 	=> 'Megjelen�t a keres�si eredm�nyekben.',
	'message'			=> '�zenet k�ld�se a levelez�l�d�ba.',
	/* Added in 1.1.0 */
	'message_keep_cnt'  => 'Megtartott �zenetek sz�ma.',
	'message_keep_days' => 'Napok sz�ma, am�g meg�rz�sre ker�lnek.',
	/* rel 2.0 */
	'messages_per_day' 	=> 'Napi �zenetek sz�ma.',
	/* Rel 1.0 added  */
	'allowim'			=> '�zenetk�ld�s enged�lyezve.',
	'uploadpicture'		=> 'K�pek felt�lt�se.',
	'uploadpicturecnt'	=> 'Felt�lt�tt k�pek sz�ma.',
	'allowalbum'		=> 'Priv�t albumok enged�lyez�se.',
	'event_mgt'			=> 'Esem�nyek kezel�s�nek enged�lyez�se.',
	/* Above is added in 1.0 */
	'seepictureprofile' => 'Profil k�pek megtekint�se.',
	'favouritelist'		=> 'Partner/tilt�/kedvenc lista kezel�se.',
	'sendwinks'			=> 'Kaccsint�sok k�ld�se.',
	/* rel 2.0 */
	'winks_per_day' 	=> 'Naponta k�ldhet� kaccsint�sok sz�ma.',
	'extsearch'			=> 'Kiterjesztett keres�s.',
	//'fullsignup' 		=> 'Teljes feliratkoz�s.',
	/* RC6 Patch */
	'activedays'		=> 'Szint �rv�nyess�ge.',
	/* added in 2.0 */
	'saveprofiles'		=> 'Profil elment�s�nek enged�lyez�se.',
	'saveprofilescnt'	=> 'Elmenthet� profilok sz�ma.',
	'allow_videos'		=> 'Vide� felt�lt�sek enged�lyez�se.',
	'videoscnt'			=> 'Felt�lthet� vide�k sz�ma.',
	'allow_mysettings'	=> 'Felhaszn�l�i be�ll�t�sok enged�lyez�se.',
	'allow_php121'		=> 'php121 �zenetk�ld�s�nek enged�lyez�se.',

);

/* 	Signup Error Messages
	These are the signup error messages, Please do not change the sequence.
*/

$lang['errormsgs']= array(
	00 => '',
	01 => 'Meg kell adnia egy felhaszn�l�i nevet.',
	02 => 'Meg kell adnia a jelsz�t.',
	03 => 'Meg kell er�sitenie a jelsz�t.',
	04 => 'Meg kell adnia a nevet.',
	05 => 'Meg kell adnia a csal�dnevet.',
	06 => 'Meg kell adnia az email cimet.',
	07 => 'Meg kell adnia a v�rost.',
	08 => 'Meg kell adnia a ir�ny�t�sz�mot.',
	09 => 'Az els� c�msor k�telez�.',
	10 => 'A felhaszn�l�i n�v maximum 25 karakter lehet.',
	11 => 'A n�v maximum 50 karakter lehet.',
	12 => 'A csal�dn�v maximum 50 karakter lehet.',
	13 => 'Az email c�m maximum 255 karakter lehet.',
	14 => 'A v�ros maximum 100 karakter lehet.',
	15 => 'Az els� c�msor maximum 255 karakter lehet.',
	16 => 'A felhaszn�l�n�v bet�vel kell kezd�dj�n.',
	17 => 'A jelsz� bet�vel kell kezd�dj�n.',
	18 => 'Nem egyezik meg a jelsz� �s a meger�sitett jelsz�.',
	19 => '�rv�nytelen email cim',
	20 => 'A sz�ks�ges inform�ci�kat meg kell adnia.',
	21 => 'A bejelentkez�si adatok hib�sak, pr�b�lja �jra.',
	22 => 'A felhaszn�l�i n�v m�r haszn�latban van, v�lasszon m�sikat.',
	23 => 'A megadott r�gi jelsz� nem helyes.',
	25 => 'Az email cim m�r regisztr�lva van.' ,
//	26 => "Your status is 'Not Active'. Please wait while activating or mail to administrator." ,
	27 => '�zenet nem tal�lhat�.',
	28 => 'El�bb v�lassz egy f�jlt.',
	29 => '�rv�nytelen f�jlform�tum',
	30 => 'A k�rd�s m�r az elej�n van.',
	31 => 'A k�rd�s m�r a v�g�n van.',
	32 => 'K�sz�nj�k az �zenetet, nemsok�ra �tn�zz�k.',
	33 => 'A ir�ny�t�sz�m nem tal�l a kiv�lasztott �llammal.',
	34 => '�rv�nytelen ir�ny�t�sz�m',
	36 => 'Hozz�f�r�se felf�ggesztve, forduljon egy adminisztr�torhoz.',
	37 => 'Feliratkoz�sa visszautas�tva, forduljon egy adminisztr�torhoz.',
	38 => '�rv�nytelen sz�let�si d�tum.',
	39 => 'A r�gi �s az �j jelsz� nem lehet ugyanaz',
	40 => 'A kezd� �v kisebb kell legyen',
	51 => 'A kezd� d�tumot a v�gs� el�tt kell megadnia',
	52 => 'Ez a tag m�r szerepel a list�n',
	53 => '�rv�nytelen d�tum',
	54 => '�rv�nytelen felhaszn�l�n�v vagy jelsz�',
	55 => 'Be kell jelentkeznie az �zenet k�ld�s�hez',
	56 => $lang['bigger_pic_size'],
	57 => $lang['only_jpg'],
	58 => $lang['upload_unsuccessful'],
	59 => 'Profil hozz�adva a list�hoz',
	60 => 'Az ikon m�rete nagyobb a megengedettn�l ('.$config['upload_snap_tnsize'].' X '.$config['upload_snap_tnsize'].')',
	61 => '�rv�nytelen aktiv�l� k�d',
	62 => 'Felhaszn�l�n�v t�r�lve a list�r�l',
	63 => 'Felhaszn�l� hozz�adva a partnerlist�hoz',
	64 => 'Felhaszn�l� hozz�adva a tiltottak list�hoz',
	65 => 'Felhaszn�l� hozz�adva a kedvencek list�hoz',
	66 => 'Kaccsint�s elk�ldve a felhaszn�l�nak',
	67 => $lang['upload_successful'],
	68 => 'K�p elfogadva',
	69 => 'K�p visszautas�tva',
	70 => 'A megtekint�s napl� t�r�lve',
	71 => 'A kaccsint�s napl� t�r�lve',
	/* Added in RC6  */
	72 => 'Hozz�f�r�s �jraaktiv�lva',
	73 => 'Orsz�g hozz�adva',
	74 => 'Orsz�g t�r�lve',
	75 => 'Orsz�gk�d vagy n�v m�r haszn�latban',
	76 => 'Orsz�g m�dositva',
	77 => '�llam hozz�adva',
	78 => '�llam t�r�lve',
	79 => '�llamk�d vagy n�v m�r haszn�latban',
	80 => '�llam m�dos�tva',
	81 => '�llam nev�t meg kell adnia',
	82 => 'Nincsenek felt�lt�tt k�pei. ',
	83 => 'Profil t�r�lve',
	84 => 'Kiv�lasztott profilok t�r�lve.',

	85 => 'Kiv�lasztott profil(ok) aktiv�lva.',
	86 => 'Kiv�lasztott profil(ok) visszautas�tva.',
	87 => 'Kiv�lasztott profil(ok) felf�ggesztve.',

	26 => 'A profilja m�g nincs aktiv�lva. <a href=\'completereg.php\'>Aktiv�lja hozz�f�r�s�t</a> az aktiv�l� k�d megad�s�val, vagy az emailben kapott linkre kattint�ssal.',

//	26 => 'Your affiliate account hasn\'t yet been activated by an administrator. Please wait for this activation before using your affiliate account.',

	35 => 'Profilja m�g nincs elfogadva.<br /> V�rja meg az elfogad�st vagy sz�ljon egy adminisztr�tornak',

/* Release 1.0 additions/modifications  */

	88 => 'Orsz�g/r�gi� hozz�adva',
	89 => 'Orsz�g/r�gi� t�r�lve',
	90 => 'Orsz�g/r�gi� neve m�r haszn�latban',
	91 => 'Osz�g/r�gi� m�dos�tva',
	92 => 'V�ros hozz�adva',
	93 => 'V�ros t�r�lve',
	94 => 'V�ros k�d vagy n�v m�r haszn�latban',
	95 => 'V�ros n�v m�dos�tva',
	96 => 'Ir�ny�t�sz�m hozz�adva',
	97 => 'Ir�ny�t�sz�m t�r�lve',
	98 => 'Ir�ny�t�sz�m m�r haszn�latban',
	99 => 'Ir�ny�t�sz�m m�dos�tva',
	100 => 'Meg kell adni az orsz�g�t/r�gi�t',
	101 => '�rv�nytelen jelsz�',
	102 => 'Esem�ny elfogadva.',
	103 => 'Esem�ny visszautas�tva.',
	301 => '�rv�nytelen id�z�na',
	302 => 'Album friss�tve',
/* 1.1.0 additions */
	104 => 'Nem megfelel� bejelentkez�s.Pr�b�lja �jra.',
	105 => 'Felhaszn�l� a tiltottak list�n',
	/* Added in 2.0 */
	120	=>	'Meg kell adni a biztons�gi k�dot.',
	121 => '�rv�nytelen biztons�gi k�d. ',
	122 => 'M�r elk�ldte a megengedett napi �zeneteket, pr�b�lkozzon holnap.',
	123 => 'M�r elk�ldte a napi megengedett kaccsint�sokat, pr�b�lkozzon holnap.',
	124 => 'Vide� bet�ltve',
	125 => 'Vide� nincs bet�ltve, mert a felt�lt�s nem siker�lt.',
	126 => 'Meg kell adnia saj�t inform�ci�kat.',
	128 => 'Egy�ni felhaszn�l�neveket kell megadni, akik p�rt alkotnak.',
	129 => '�rv�nyes felhaszn�l�i nevet kell megadni.',
	201 => 'M�r elmentett megengedett sz�m� profilt',
	202 => 'Profil hozz�adva a megfigyeltek k�z�',
	203 => 'A profil m�r megtal�lhat� a figyelt profilok k�z�tt',
	);


$lang['alphanumeric'] = "0123456789.+-_#,/ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz ()_";
$lang['alphanum'] = "0123456789_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz ";
$lang['text'] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz '";
$lang['full_chars'] = "0123456789.+-_#,/ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz() _$+=;:?'";
/* Additions  in Version 2.0 */

$lang['save'] = 'Ment�s';
$lang['delete_zips'] = 'Ir�ny�t�sz�mokat T�r�l';
$lang['zipcodes_sql_created'] = 'Ir�ny�t�sz�m/ir�ny�t�sz�mok SQL f�jl l�trehozva ';
$lang['zipcodes_loaded'] = 'Ir�ny�t�sz�mok  bet�ltve innen ';
$lang['delzips_msg'] = 'Ennek az orsz�gnak az �sszes Ir�ny�t�sz�ma t�rl�dik';
$lang['delzips_succ'] = '#COUNTRY# Ir�ny�t�sz�mai t�r�lve';
$lang['wrong_zipfile'] = 'Ez a f�jl nem ennek az orsz�gnak van: #COUNTRY#';
$lang['load_states'] = '�llamok f�jl feldolgoz�sa';
$lang['state_ensure'] = 'T�ltse fel a f�jlt a /states k�nyvt�rba a folytat�s el�tt. <br /><br />A f�jlnak tartalmaznia kell az �LLAMK�D �s �LLAMN�V �rt�keket vessz�vel elv�lasztva';
$lang['statefile'] = '�llamok f�jl';
$lang['delete_states'] = '�llamk�dok t�rl�se';
$lang['delstates_msg'] = 'Az orsz�ghoz tartoz� �llamk�dok t�rl�dnek';
$lang['delstates_succ'] = '#COUNTRY# �llamk�djai t�rl�dtek';
$lang['states_sql_created'] = '�llamok SQL f�jl l�trehozva ';
$lang['states_loaded'] = '�llamk�dok bet�ltve innen ';
$lang['delete_lang'] = 'Nyelv t�rl�se az adatb�zisb�l';
$lang['langfile_loaded'] = "#LANGUAGE# nyelv definic�i bet�ltve innen ";
$lang['lang_deleted'] = '#LANGUAGE# definici�i t�r�lve';
$lang['load_counties'] = 'Orsz�gok f�jl feldolgoz�sa';
$lang['countyfile'] = 'Megy�k f�jl';
$lang['county_ensure'] = 'T�ltse fel az megye/r�gi� k�dokat a /counties k�nyvt�rba. A f�jl kell tartalmazza a MEGYEK�D, MEGYEN�V, �s �LLAMK�D �rt�keket vessz�vel elv�lasztva';
$lang['delete_counties'] = 'Megyek�dok t�rl�se';
$lang['delcounties_msg'] = 'Az �sszes megye �s r�gi� t�rl�dik a kiv�lasztott orsz�gb�l';
$lang['delcounties_succ'] = '#COUNTRY# megy�i t�rl�dtek';
$lang['counties_sql_created'] = 'Megy�k/r�gi�k SQL f�jl l�trehozva ';
$lang['counties_loaded'] = 'Megyek�dok bet�ltve innen ';
$lang['load_cities'] = 'V�rosok f�jl feldolgoz�sa';
$lang['cityfile'] = 'V�ros k�dok f�jl';
$lang['city_ensure'] = 'T�ltse fel a v�ros k�dokat a /cities k�nyvt�rba. A f�jlnak tartalmaznia kell a V�ROSK�D, V�ROSN�V, MEGYEK�D, �LLAMK�D �rt�keket vessz�vel elv�lasztva';
$lang['delete_cities'] = 'V�ros k�dok t�rl�se';
$lang['delcities_msg'] = 'A kiv�lasztott orsz�g v�rosai t�rl�dnek';
$lang['delcities_succ'] = '#COUNTRY# v�rosk�djai t�r�lve';
$lang['cities_sql_created'] = 'V�rosk�dok SQL l�trehozva ';
$lang['cities_loaded'] = 'V�rosk�dok bet�ltve innen ';
$lang['online'] = 'Online';
$lang['watchedprofiles_1'] = 'Hozz�ad�s a megfigyelt profilokhoz';
$lang['watchedprofiles'] = 'Megfigyelt profilok';


$lang['poll'] = 'Szavaz�s';
$lang['section_poll_title'] = 'Szavaz�s';
$lang['section_poll_list'] = 'Szavaz�s lista';
$lang['section_add_poll'] = '�j szavaz�s';
$lang['poll_subtitle_list'] = 'Szavaz�s lista';
$lang['poll_subtitle_add'] = '�j szavaz�s';
$lang['poll_subtitle_edit'] = 'Szavaz�s szerkeszt�se';
$lang['poll_number'] = 'Sz�m';
$lang['poll_active_hdr'] = 'Aktiv';
$lang['poll_question_hdr'] = 'K�rd�sek';
$lang['poll_responses_hdr'] = 'V�laszok';
$lang['no_poll_found'] = 'Nincsenek szavaz�sok';
$lang['poll_question'] = 'K�rd�s';
$lang['poll_options'] = 'Opci�k';
$lang['poll_active'] = 'Aktiv';
$lang['poll_minimum_two'] = 'Legal�bb 2 kell.';
$lang['results_poll_title'] = 'Eredm�nyek';
$lang['poll_subtitle_results'] = 'Szavaz�seredm�nyek';
$lang['take_poll_title'] = 'Szavaz�s';
$lang['poll_entries'] = 'Szavaz�s';


$lang['plugin'] = 'Pluginok';
$lang['plugin_access'] = 'Tagok hozz�f�r�se';
$lang['section_plugin_title'] = 'Pluginok';
$lang['section_plugin_list'] = 'Plugin Lista';
$lang['section_add_plugin'] = 'Plugin bet�lt�se';
$lang['plugin_subtitle_list'] = 'Plugin Lista';
$lang['plugin_number'] = 'Sz�m';
$lang['plugin_name'] = 'N�v';
$lang['plugin_active'] = 'Aktiv';
$lang['plugin_installed'] = 'Telep�tve';
$lang['plugin_install'] = 'Telep�t�se';
$lang['no_plugin_found'] = 'Nincsenek pluginok';
$lang['plugin_file'] = 'Plugin ir�ny�t�sz�m f�jl felt�lt�se';
$lang['plugin_subtitle_edit'] = 'Plugin szerkeszt�se';
$lang['add_plugin_summary'] = 'Plugin l�trehoz�s�ra dokument�ci� a telepit�si k�nyvt�rban.';

$lang['blog']['hdr'] = 'Blog';
$lang['admin_blog'] = 'Site Blog';
$lang['blog_default_bad_words'] = 'xxx|levitra';
$lang['blog_bad_words'] = 'Cs�nya szavak';
$lang['blog_save_template'] = 'Ment�s sablonk�nt';
$lang['blog_load_template'] = 'Sablon bet�lt�se';
$lang['blog_bad_words_help'] = '(egy sz� per sor)';
$lang['blog_search_results'] = 'Blog keres�s eredm�nyei';
$lang['section_blog_info'] = 'Blog be�ll�t�sok';
$lang['section_blog_list'] = 'Blog bejegyz�s';
$lang['section_blog_title'] = 'Blog';
$lang['blog_search_menu'] = 'Blog keres�s';
$lang['blog_search_username'] = 'Felhaszn�l�n�v';
$lang['blog_search_title'] = 'C�m';
$lang['blog_search_body'] = 'Sz�veg';
$lang['blog_search_Date'] = 'D�tum';

$lang['blog_subtitle_list'] = 'Blog lista';
$lang['blog_name'] = 'Blog n�v';
$lang['blog_description'] = 'Blog le�r�s';
$lang['blog_members_comment'] = 'Tagok megjegyz�sei';
$lang['blog_buddies_comment'] = 'Partnerek megjegyz�sei';
$lang['blog_members_vote'] = 'Tagok szavazatai';
$lang['blog_gui_editor'] = 'WYSIWYG szerkeszt�';
$lang['blog_max_comments'] = 'Max megjegyz�sek';
$lang['no_blog_found'] = 'Nincsenek bejegyz�sek';
$lang['section_add_blog'] = 'Blog bejegyz�s';
$lang['blog_subtitle_add'] = '�j Blog bejegyz�s';
$lang['blog_subtitle_edit'] = 'Blog szerkeszt�se';
$lang['blog_title'] = 'C�m';
$lang['blog_story'] = 'Tartalom';
$lang['blog_posted_date'] = 'Bek�ld�si d�tum';
$lang['blog_title_hdr'] = 'C�m';
$lang['blog_rating_list_hdr'] = '�rt�kel�s';
$lang['blog_number'] = 'Sz�m';
$lang['blog_date_posted_hdr'] = 'D�tum';
$lang['blog_views_hdr'] = 'Megtekint�sek';
$lang['blog_votes_hdr'] = 'Szavazatok';
$lang['blog_votes1'] = 'Szavazat';
$lang['blog_rating_hdr'] = 'erre alapozva ';
$lang['blog_submit_vote'] = 'Szavaz�s';
$lang['blog_add_vote'] = 'Szavaz�s most';
$lang['view_blog'] = 'Blog megtekint�se';
$lang['blog_entries'] = 'Blog:';
$lang['blog_creator'] = 'Szerz�';
$lang['blog_comments'] = 'Megjegyz�sek';
$lang['add_comment'] = 'Saj�t megjegyz�sek';
$lang['total_blogs_found'] = '�sszes tal�lt blog bejegyz�s:';

$lang['blog_errors'] = array(
   'nosetup' => 'Kezd� blog be�ll�t�sokat meg kell adni.' ,
   'name_noblank' => 'Blog nevet meg kell adni' ,
   'description_noblank' => 'Blog le�r�st meg kell adni. ',
   'date_posted_noblank' => 'A bevitel d�tum�t meg kell adni.' ,
   'title_noblank' => 'A c�met meg kell adni.' ,
   'story_noblank' => 'A t�rt�netet meg kell adni.' ,
   'max_stories_warning' => 'El�rte a maxim�lis t�rt�netek sz�m�t. Nem adhat hozz� �j t�rt�netet.' ,
   'comment_bad_word' => 'A megjegyz�s a k�vetkez� tiltott sz�t tartalmazza: %s' ,
);
$lang['spell_check'] = 'Helyesir�s ellen�rz�s';

$lang['manage_import_webdate'] = 'Import�l�s Webdateb�l';
$lang['import_config'] = 'Config';

$lang['forum_values'] = array(
   'None' => 'semmi',
   'phpBB' => 'phpBB',
   'vBulletin' => 'vBulletin',
   'myBB' => 'myBB',
   'Phorum' => 'Phorum',
   );

$lang['photos_url'] = 'Honlap URL:';
$lang['ftp_username'] = 'FTP Felhaszn�l�:';
$lang['ftp_password'] = 'FTP Jelsz�:';
$lang['ftp_hostname'] = 'FTP Host:';
$lang['ftp_path'] = 'FTP aeDating �tvonal:';
$lang['ftp_path_help'] = 'Az aeDating k�nyvt�r �tvonala.  Pl. public_html/aeDating';

$lang['nopicsloaded'] = 'Nincsenek k�pek';
$lang['loadedpicscnt'] = '#PICSCNT# k�p';
$lang['loadedpicscnt1'] = '#PICSCNT# k�p';
$lang['picsloaded'] = 'K�pek bet�ltve';
$lang['since'] = 'a k�v. d�tum �ta:';
$lang['unknown'] = 'Ismeretlen';

$lang['glblsettings_groups'] = array(
1	=>	'Site inform�ci�',
2	=> 	'Felhaszn�l�i vez�rl�k',
3	=>	'Napt�r vez�rl�k',
4	=>	'Levelez�si be�ll�t�sok',
5	=>	'Profil k�pek �s ikonok',
6	=>	'Oldal �s t�bl�zat elrendez�s',
);

$lang['who_is_online'] = 'Csak online felhaszn�l�k';
$lang['search_with_photo'] = 'Csak k�ppel rendelkez� tagok';
$lang['search_with_video'] = 'Csak vide�val rendelkez� tagok';
$lang['expire_on_hdr'] = 'Lej�rat';
$lang['expird'] = 'Lej�rt';
$lang['pics'] = 'K�pek';
$lang['pic_deleted'] = 'Kiv�lasztott k�p t�r�lve';
$lang['entrycode_chars'] = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
$lang['enter_spamcode'] = 'Biztons�gi k�d';

/* Admin emails portion */

$lang['newpic']['html'] ='<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td class="module_head" width="100%" height="25"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25"><div class="module_head">#email_hdr_left#</div>
</td><td width="493" height="25"><div class="module_head">&nbsp;&nbsp;Felhaszn�l� �j k�pet t�lt�tt fel</div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" ><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="1"></td></tr><tr><td width="50%" valign="top" class="evenrow" >Kedves oldal Adminisztr�tor,
<br><br><a href="#SiteUrl#admin/showprofile.php?username=#UserName#">#UserName#</a> felhaszn�l� �j k�pet t�lt�tt fel. <br><br>Felhaszn�l�n�v: #UserName#<br>K�p sz�ma: #PicNo#<br><br>#AdminName# <br>SITENAME<br></td><td valign="top" class="evenrow" align="cemter">#smallPic#
</td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';


$lang['newpic']['text'] = "Kedves Admin,

A #UserName# felhaszn�l� �j k�pet t�lt�tt fel.

Felh. n�v: #UserName#
K�p sz�ma: #PicNo#

#AdminName#
SITENAME";

$lang['newpic_sub'] = 'SITENAME �zenet: �j k�p felt�ltve ';
$lang['newvideo']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25"><div class="module_head">#email_hdr_left#</div>
</td><td width="493" height="25"><div class="module_head">&nbsp;&nbsp;Felhaszn�l� �j vide�t t�lt�tt fel! </div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" ><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">Kedves oldal Adminisztr�tor,<br><br><a href="#SiteUrl#admin/showprofile.php?username=#UserName#">#UserName#</a> egy �j vide�t t�lt�tt fel. <br><br>Felhaszn�l�n�v: #UserName#<br>Vide� sz�ma: #PicNo#<br><br>#AdminName#<br>SITENAME<br></td>
</tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';


$lang['newvideo']['text'] = "Kedves Admin,

A #UserName# felhaszn�l� �j vide�t t�lt�tt fel.

Felh. n�v: #UserName#
Vide� sz�ma: #PicNo#

#AdminName#
SITENAME";

$lang['newvideo_sub'] = 'SITENAME �zenet: �j vide� felt�ltve ';

/* Modified in 2.0 */
$lang['payment_msg1'] = 'El�rhet� fizet�si m�dok:';

$lang['wrong_activationcode'] = 'A megadott aktiv�ci�s k�d �rv�nytelen vagy az azonosit� m�r aktiv�lva van.';

$lang['security_code_txt'] = 'Olvassa el a k�pen tal�lhat� sz�veget �s irja be a mellete lev� mez�be.';
$lang['additional_pics'] = 'Tov�bbi k�pek';
$lang['view_all_pics'] = 'Minden k�p';
$lang['insufficientPrivileges'] = 'Nincs joga a m�velethez, n�velje meg a tags�gi szintj�t.';
$lang['username_part_msg'] = "Ha nem tudja a pontos felhaszn�l�i nevet, irja be egy r�sz�t a lehets�ges nevek megjelen�t�s�hez."
;
$lang['featured_profiles_msg01'] = "Meg kell jelen�teni: 'Igen' eset�n ez a profil kiv�laszthat� a k�l�nleges profilok list�j�n, 'Nem' eset�n nem jelenhet meg a k�l�nleges profilok k�z�tt";

$lang['featured_profiles_msg02'] = "K�rt megjelentet�sek: ez adja meg a k�l�nleges profilok list�j�n val� megjelen�sek sz�m�t, ha ezt a sz�mot el�ri a lej�rati d�tum el�tt.";
$lang['lookup'] = 'Lek�r';
/* for use in shoutbox */
$lang['sb_by'] = 'Bek�ldte:';
$lang['sb_hdr'] = 'Shoutbox';
$lang['sb_send'] = 'K�ld�s';
$lang['sb_error'] = 'A megadott sz�veg t�l hossz�';
$lang['sb_msg_blank'] = '�res �zenet?';
$lang['sb_show_all'] = 'Megjelen�t mindent';

$lang['upload_videos'] = 'Vide�k felt�lt�se';
$lang['videoupload_format_msgs'] = 'Csak .swf vagy .flv f�jlok megengedettek.';
$lang['video'] = 'Vide�';
$lang['upload_videos_ext'] = 'flv, swf';
$lang['upload_video_caption'] = 'Vide� felt�lt�se';
$lang['video_file'] = 'Vide� f�jl';
$lang['vds'] = 'Vide�k';
$lang['manage_videos'] = 'Vide�k kezel�se';
$lang['videos_loaded'] = 'Bet�lt�tt vide�k';
$lang['novideos_loaded'] = 'Nincsenek vide�k';
$lang['loadedvdocnt'] = '#PICSCNT# vide�';
$lang['loadedvdocnt1'] = '#PICSCNT# vide�';
$lang['video_gallery'] = 'Vide�t�r';
$lang['picture_gallery'] = 'K�pt�r';


/* New timezone display values Modified in 2.0 */
// These are displayed in the timezone select box
$lang['tz']['-25'] = '-- Kiv�laszt --';
$lang['tz']['-12.00'] = '(GMT -12:00) Eniwetok, Kwajalein';
$lang['tz']['-11.00'] = '(GMT -11:00) Midway Island, Samoa';
$lang['tz']['-10.00'] = '(GMT -10:00) Hawaii';
$lang['tz']['-9.00'] = '(GMT -9:00) Alaska';
$lang['tz']['-8.00'] = '(GMT -8:00) Pacific Time (US & Canada)';
$lang['tz']['-7.00'] = '(GMT -7:00) Mountain Time (US & Canada)';
$lang['tz']['-6.00'] = '(GMT -6:00) Central Time (US & Canada), Mexico City';
$lang['tz']['-5.00'] = '(GMT -5:00) Eastern Time (US & Canada), Bogota, Lima';
$lang['tz']['-4.00'] = '(GMT -4:00) Atlantic Time (Canada), Caracas, La Paz';
$lang['tz']['-3.5'] = '(GMT -3:30) Newfoundland';
$lang['tz']['-3.00'] = '(GMT -3:00) Brazil, Buenos Aires, Georgetown';
$lang['tz']['-2.00'] = '(GMT -2:00) Mid-Atlantic';
$lang['tz']['-1.00'] = '(GMT -1:00 hour) Azores, Cape Verde Islands';
$lang['tz']['0.00'] = '(GMT) Western Europe Time, London, Lisbon, Casablanca';
$lang['tz']['1.00'] = '(GMT +1:00 hour) Brussels, Copenhagen, Madrid, Paris';
$lang['tz']['2.00'] = '(GMT +2:00) Kaliningrad, South Africa';
$lang['tz']['3.00'] = '(GMT +3:00) Baghdad, Riyadh, Moscow, St. Petersburg';
$lang['tz']['3.5'] = '(GMT +3:30) Tehran';
$lang['tz']['4'] = '(GMT +4:00) Abu Dhabi, Muscat, Baku, Tbilisi';
$lang['tz']['4.5'] = '(GMT +4:30) Kabul';
$lang['tz']['5.00'] = '(GMT +5:00) Ekaterinburg, Islamabad, Karachi, Tashkent';
$lang['tz']['5.5'] = '(GMT +5:30) Bombay, Calcutta, Madras, New Delhi';
$lang['tz']['6.00'] = '(GMT +6:00) Almaty, Dhaka, Colombo';
$lang['tz']['6.5'] = 'GMT + 6.30) ';
$lang['tz']['7.00'] = '(GMT +7:00) Bangkok, Hanoi, Jakarta';
$lang['tz']['8.00'] = '(GMT +8:00) Beijing, Perth, Singapore, Hong Kong';
$lang['tz']['9'] = '(GMT +9:00) Tokyo, Seoul, Osaka, Sapporo, Yakutsk';
$lang['tz']['9.5'] = '(GMT +9:30) Adelaide, Darwin';
$lang['tz']['10.00'] = '(GMT +10:00) Eastern Australia, Guam, Vladivostok';
$lang['tz']['11.00'] = '(GMT +11:00) Magadan, Solomon Islands, New Caledonia';
$lang['tz']['12.00'] = '(GMT +12:00) Auckland, Wellington, Fiji, Kamchatka';
$lang['tz']['13.00'] = '(GMT + 13)';

$lang['myprofile'] = 'Profilom';
$lang['myblog'] = 'Blogom';
$lang['profilesearch'] = 'Profil keres�s';
$lang['mylists'] = 'List�m';
$lang['bans'] = 'Letiltottjaim';
$lang['mybuddies'] = 'Haverok';
$lang['hotprofiles'] = 'Kedvelt profilok';
$lang['winks'] = 'Kacsint�sok';
$lang['tools'] = 'Eszk�z�k';
$lang['picturegallery'] = 'Fot� gal�ria';
$lang['videogallery'] = 'Vide� gal�ria';
$lang['membership'] = 'Tags�g';
$lang['adminhome'] = 'Admin kezd�oldal';
$lang['membershdr'] = 'Tagok';
$lang['memberprofiles'] = 'Tagok profiljai';
$lang['membersearch'] = 'Tagok keres�se';
$lang['blogs'] = 'Blogok';
$lang['blogsearch'] = 'Blogokat Keres';
$lang['affiliateshdr'] = 'T�rshirdet�k';
$lang['localities'] = 'Helys�gek';
$lang['contenthdr'] = 'Tartalom';
$lang['financial'] = 'P�nz�gyi';
$lang['plugins_hlp'] = 'Az adminisztrat�v pluginok csak adminok �s megfelel� jogokkal rendelkez� moder�torok �ltal haszn�lhat�ak �s automatikusan megjelennek a bal oldali admin men� alatt. A tagok pluginjai a tagok fel�let�r�l �rhet�ek el';

/* additions */

//$lang['banner_sizes']['100x500'] = '100 x 500';
$lang['activedays_array'][999] = '999';
$lang['banner_error_msgs'][5] = 'A banner m�rete nagyobb a megengedettn�l.';
$lang['errormsgs'][111] = 'Ez a tag m�r a k�l�nlegesek list�j�n van.';
$lang['errormsgs'][130] = 'Vide�t f�jlt nem siker�lt �talak�tani. K�rj�k, .flv form�tum� vide�t haszn�ljon.';
$lang['errormsgs'][131] = '�n el�rte a tags�gi szintje �ltal megengedett �zenetek sz�m�t';


/* HTML and some text emails */
$lang['no_thanks_message']['html'] = 'Szia #recipient_username#,<BR><BR>

K�sz�n�m az �rdekl�d�sed, de tisztelettel visszautas�tom. Rem�lem megtal�lod a p�rod.<BR><BR>

�dv�zlettel,
#sender_username#';




$lang['mail']['hdr_text'] = '<font style="color:red; font-size: 9px;"> Ha nem szeretne t�bb ilyen emailt kapni, <a href="#SiteUrlLogin#">jelentkezzen be</a> �s v�ltoztassa meg az �rtes�t�si be�ll�t�sait.<br>Hogy biztos legyen benne, hogy megkapja ezeket az emaileket, k�rj�k, adja hozz� a k�vetkez� email c�met a c�mlist�j�hoz: <a href="mailto:#AdminEmail#">#AdminEmail#</a>.</font><br><br>';
$lang['mail']['hdr_html'] = '<table border=0 cellspacing=0 cellpadding=5 width="570"><tr><td ><font style="color:red; font-size: 9px;">Ha nem szeretne t�bb ilyen emailt kapni, <a href="#SiteUrlLogin#">jelentkezzen be</a> �s v�ltoztassa meg az �rtesit�si be�ll�t�sait.<br>Hogy biztos legyen benne, hogy megkapja ezeket az emaileket, k�rj�k, adja hozz� a k�vetkez� email c�met a c�mlist�j�hoz: <a href="mailto:#AdminEmail#">#AdminEmail#</a>.</font></td></tr><tr><td height="6"></td></tr></table>';

$lang['letter_winkreceived_sub'] = 'SITENAME �zenet: #SenderName# �pp r�d kacsinott! ';
$lang['wink_received']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25px">#email_hdr_left#</td><td width="493" height="25" ><div class="module_head">&nbsp;&nbsp;#SenderName# �pp �nre kacsintott!</div>
</td></tr></table></div></td></tr><tr><td width="570" class="evenrow" colspan="2" ><div class="evenrow" ><table border="0" cellspacing="2" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="50%" valign="top">#smallProfile#</td><td width="50%" valign="top">A sok tag k�z�l #SenderName# �nt v�lasztotta ki �s �nre kaccsintott! Tov�bb fl�rt�lhet visszakaccsintva, vagy emailt k�ldve<br><br> <a href="#SiteUrl#compose.php?recipient=#UserId#">E-mail k�ld�se #SenderName#-nek: </a><br><br> <a href="#SiteUrl#sendwinks.php?ref_id=#UserId#&amp;rtnurl=showprofile.php">Visszakaccsint�s</a><br>
<br><b>Nem �rdekel?</b><br #SenderName#-nak/nek egy "Nem, k�sz�n�m" �zenetet><br><br> <a href="#SiteUrl#compose.php?recipient=#UserId#&amp;reply=11">"Nem, k�sz�n�m" k�ld�se</a><br><br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';




$lang['profile_confirmation_email_sub'] = 'SITENAME �zenet: K�sz�nj�k, hogy regisztr�lt!';
$lang['profile_confirmation_email']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570">
<tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%">
<tr><td width="77" height="25" >#email_hdr_left#</td><td width="493"  height="25"><div class="module_head">&nbsp;&nbsp;#Welcome#!</div></td></tr></table></div></td></tr><tr><td width="570" class="evenrow" colspan="2" >
<div class="evenrow" ><table border=0 cellspacing=0 cellpadding=5 width="100%"><tr><td>Kedves #FirstName#,<br><br>K�sz�nj�k, hogy regisztr�lt a #SiteName# weboldalon! Mint az oldal leg�jabb tagja, megk�rj�k, n�zzen k�r�l az oldalon.<br><br>A regisztr�ci�t �rv�nyes�tenie kell a k�vetkez� c�mre kattintva<br><br><a href=\"#ConfirmationLink#=#ConfCode#\">#ConfirmationLink#=#ConfCode#</a><br><br>Ha m�g nyitva van a regisztr�ci�s ablak, be�rhatja oda is az aktiv�l� k�dot.<br><br>Az �n aktiv�l� k�dja:<b>#ConfCode#</b><br><br>Felhaszn�l�i adatai:<br>
<br>Felhaszn�l�n�v: <b>#StrID#</b><br>Jelsz�: <b>#Password#</b><br>Email: <b>#Email#</b><br><br>K�rj�k, tartsa biztons�gban ezen adataid, mert csak ezek �ltal �rhet�ek el szolg�ltat�saink az �n sz�m�ra. Egyes szolg�ltat�sok magasabb tags�gi szintet k�rnek, amit itt n�velhet: <br><br><a href="#SiteUrl#payment.php">#Upgrade#</a><br><br>K�sz�nj�k, hogy szolg�ltat�sainkat haszn�lja �s rem�lj�k megtal�lja a p�rj�t!<br><br>
#AdminName#<br>#siteName#</td></tr></table></div></td></tr>
<tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['message_received_sub'] = 'SITENAME �zenet: RE: �zenet...';
$lang['message_received']['text'] = "Kedves #FirstName#,

�zenetet kapott a SITENAME '#SenderName#' nev� felhaszn�l�j�t�l.

L�togassa meg a(z) <a href=\"#link#\">SITENAME</a> oldalt, hogy v�laszoljon.

Sok szerencs�t!
#AdminName#
SITENAME";

$lang['message_received']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25"><div class="module_head">
#email_hdr_left#</div></td><td width="493" ><div class="module_head">&nbsp;&nbsp;#SenderName# �zenetet k�ld�tt! </div></td></tr></table></div></td></tr><tr><td width="570" class="evenrow" colspan="2" ><div class="evenrow" ><table border="0" cellspacing="2" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="50%" valign="top" class="evenrow">
<table width="100%" border=0 cellspacing=0 cellpadding=0><tr><td width="25%" ><div class="newshead">#From#:</div></td><td width="75%">#SenderName#</td></tr><tr><td><div class="newshead">#TO#:</div></td><td>#UserName#</td></tr><tr><td  >
<div class="newshead">#Date#:</div></td><td>#MESSAGE_DATE# </td></tr><tr><td ><div class="newshead">#Subject#:</div></td><td>#MSG_SUBJECT#</td></tr><tr><td colspan="2" height="6">
</td></tr><tr><td colspan=2>Kedves #FirstName#,<br><br>#SenderName# �zenetet k�ld�tt �nnek.<br><br>K�rj�k, l�togasson el a k�vetkez� c�mre, hogy v�laszolhasson az �zenetre: <a href=\"#link#\">SITENAME</a><br><br>Sok szerencs�t!<br>#AdminName#<br>SITENAME<br></td></tr></table>
</td><td width="50%" valign="top" class="oddrow"><div class="oddrow">#smallProfile#</div></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';


$lang['letter_featuredprofile_sub'] = 'SITENAME �zenet: Profilja meg fog jelenni a k�l�nleges profilok list�j�n!';
$lang['featured_profile_added']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr>
<td width="77" height="25" ><div class="module_head">#email_hdr_left#</div>
</td><td width="493" ><div class="module_head">&nbsp;&nbsp;Profilja meg fog jelenni a k�l�nleges profilok list�j�n!</div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" >
<div class="evenrow"><table border="0" cellspacing="0" cellpadding="5"><tr><td width="100%" valign="top" class="evenrow">Kedves #FirstName#,<br><br>�r�mmel jelen�tj�k meg a k�l�nleges profilok list�j�n a k�vetkez� c�men: <a href=\"#link#\">SITENAME</a>.<br><br>A megjelen�s <b>#FromDate#</b> �s <b>#UptoDate#</b> k�z�tt lesz.<br>
<br>Ez megn�veli a profilja l�togatotts�g�t, �s t�bb tal�latot hoz majd.<br><br>Sok szerencs�t!<br>#AdminName# <br>SITENAME<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['profile_activated_sub'] = 'SITENAME �zenet: Profilja aktiv�lva!';
$lang['profile_activated']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" ><div class="module_head">
#email_hdr_left#</div></td><td width="493"><div class="module_head">&nbsp;&nbsp;Profilja aktiv�lva!</div></td></tr></table></div></td></tr><tr>
<td width="100%" class="evenrow" colspan="2"><div class="evenrow"><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr>
<tr><td width="100%" valign="top" class="evenrow">Kedves #FirstName#,<br><br>�dv�z�lj�k az SITENAME oldalon. <br><br>Profilja aktiv�lva van a k�vetkez� tags�gi szinten: <b>#MembershipLevel#</b>, �s �rv�nyes #ValidDate#-ig.<br><br>L�togasson meg a k�vetkez� c�men <a href=\"#link#\">SITENAME</a>.<br>
<br>Sok szerencs�t!<br>#AdminName# <br>SITENAME<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';
$lang['profile_activated']['text'] = "Kedves #FirstName#,

�dv�z�lj�k a SITENAME weboldalon.

Profilja aktiv�lva van a k�vetkez� tags�gi szinten: <b>#MembershipLevel#</b>, �s �rv�nyes: <b>#ValidDate#</b>.

L�togasson meg a <a href=\"#link#\">SITENAME</a> c�men.

Sok szerencs�t!
#AdminName#
SITENAME";

$lang['profile_reactivated_sub'] = 'SITENAME �zenet: Profilod �jra akt�v!';
$lang['profile_reactivated']['text'] = "Kedves #FirstName#,

�r�mmel �rtes�tj�k, hogy profilja �jra akt�v a k�vetkez� tags�gi szinten: <b>#MembershipLevel#</b>, �s �rv�nyes: <b>#ValidDate#</b>.

Sok szerencs�t!
#AdminName#
SITENAME";

$lang['profile_reactivated']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head">
<div class="module_head">#email_hdr_left#</div></td><td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;Profilja �jra akt�v!</div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2">
<div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">Kedves #FirstName#,<br><br>�r�mmel �rtes�tj�k, hogy profilj�t �jraaktiv�ltuk a k�vetkez� tags�gi szinten: <b>#MembershipLevel#</b>, amely <b>#ValidDate#</b>-ig �rv�nyes.<br>
<br>K�rj�k, l�togasson meg a k�vetkez� c�men: <a href=\"#link#\">SITENAME</a>.<br><br>Sok szerencs�t!<br>#AdminName# <br>SITENAME<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['added_list_sub'] = "SITENAME �zenet: Felker�lt #SenderName# #ListName# list�j�ra!";
$lang['added_list']['text'] = "Kedves #FirstName#,

#SenderName# hozz�adta a(z) #ListName# list�j�hoz.

L�togassa meg a tag profilj�t a <a href=\"#link#\">SITENAME</a> c�men.

Sok szerencs�t!
#AdminName#
SITENAME";

$lang['added_list']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25px" class="module_head">
<div class="module_head">#email_hdr_left#</div></td><td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;Felker�lt #SenderName# #ListName# list�j�ra!</div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" >
<div class="evenrow"><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="50%" valign="top" class="evenrow">Kedves #FirstName#,<br><br><b>#SenderName#</b> hozz�adott a(z) <b>#ListName#</b> list�j�hoz.<br><br>L�togassa meg a tag profilj�t a k�vetkez� c�men: <a href=\"#link#\">SITENAME</a>.<br><br>Sok szerencs�t!<br>#AdminName# <br>SITENAME<br></td><td valign="top">#smallProfile#</td>
</tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['invite_a_friend_sub'] = "SITENAME �zenet: #FromName# meghiv�t k�ld�tt! ";
$lang['invite_a_friend']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="27" class="module_head" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" valign="top" ><div class="module_head" >#email_hdr_left#</div>
</td>
<td width="493" ><div class="module_head" >&nbsp;&nbsp;#FromName# meghiv�t k�ld�tt!</div></td></tr></table></div></td></tr><tr><td width="100%" colspan="2" ><div class="evenrow"><table border="0" cellspacing="0" cellpadding="5" width="100%"><tr><td height="1"></td></tr><tr><td width="100%" valign="top" class="evenrow">Szia,<br><br>Tal�ltam egy j� t�rskeres� weboldalt: <a href=\"#SiteUrl#\"><b>SITENAME</b></a>.<br>�gy gondoltam �rdekelhet.<br>
<br><br>Sok sikert!<br>#FromName# <br><br></td></tr></table></div>
</td></tr><tr><td height="6" class="evenrow" colspan="2" ></td></tr></table>';

$lang['message_read_sub'] = 'SITENAME �zenet: #RecipientName# elolvasta az �zenet�t!';
$lang['message_read']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25">
<div class="module_head">#email_hdr_left#</div></td><td width="493" ><div class="module_head">&nbsp;&nbsp;#RecipientName# elolvasta az �zenet�t!</div></td></tr></table></div></td></tr>
<tr><td width="100%" class="evenrow" colspan="2" >
<div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="50%" valign="top" class="evenrow">Kedves #FirstName#,<br><br><b>#RecipientName#</b> elolvasta az �zenet�t.<br><br>L�togassa meg a tag profilj�t a k�vetkez� c�men: <a href=\"#link#\">SITENAME</a>.<br><br>Sok szerencs�t!<br>#AdminName# <br>SITENAME<br></td>
<td valign="top">#smallProfile#</td></tr></table>
</div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['email_feedback_subject'] = 'SITENAME �zenet: Felhaszn�l�i visszajelz�s ';
$lang['feedback_email_to_admin']['text'] = 'Kedves Admin,

Egy l�togat� a k�vetkez�ket k�ldi:

C�m: #txttitle#
N�v: #txtname#
Email: #txtemail#
Orsz�g: #txtcountry#
Megjegyz�sek: #txtcomments#
';

$lang['feedback_email_to_admin']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25"><div class="module_head">
#email_hdr_left#</div></td><td width="493"><div class="module_head">&nbsp;&nbsp;Felhaszn�l�i visszajelz�s <div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" ><div class="evenrow" >
<table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr>
<tr><td width="100%" valign="top" class="evenrow">Kedves Oldal Adminisztr�tor,<br><br>Egy l�togat� a k�vetkez�ket k�ldi:<br><br><table cellspacing="4" cellpadding="2" border="0" width="100%"><tr><td width="20%"> C�m: </td><td width="80%">#txttitle# </td></tr><tr><td>N�v: </td> <td>#txtname#</td></tr>
<tr><td>Email: </td><td>#txtemail#</td></tr><tr><td>Orsz�g: </td><td>#txtcountry#</td></tr><tr><td>Megjegyz�sek: </td><td>#txtcomments#</td></tr></table><br>K�sz�nettel,<br>#siteName# Daemon<br><br></td></tr></table></div></td></tr></table> ';


$lang['forgot_password_sub'] = 'SITENAME �zenet: �j jelsz� k�r�s';
$lang['forgot_password']['text'] = "Kedves #Name#,

Ebben a lev�lben tal�lja meg �j adataid.

Felhaszn�l�: #ID#
�j jelsz�:  #Password#

Bejelentkez�s: #LoginLink#.

K�sz�nj�k, hogy szolg�ltat�sainkat haszn�lja.

#AdminName#
SITENAME";

$lang['forgot_password']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head"><div class="module_head">#email_hdr_left#</div></td>
<td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;�j jelsz� k�r�s</div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" ><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">Kedves #Name#,<br>
<br>Ezt az �zenetet az�rt k�ldt�k, mert �j jelsz�t k�rt.<br><br>A tags�gi azonos�t�ja: <b>#ID#</b><br>Az �j jelszava: <b>#Password#</b><br><br>A bel�p�shez, kattintson ide: <a href=\"#LoginLink#\">SITENAME</a>.<br><br>K�sz�nj�k, hogy szolg�ltat�sainkat haszn�lja.<br><br>#AdminName#<br>SITENAME<br></td></tr> </table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['expiry_ltr_sub'] = 'SITENAME �zenet: Eml�keztet� tags�ga lej�rt�r�l';

$lang['mship_expired_note']['text'] = "Kedves #FirstName#,

K�sz�nj�k, hogy a SITENAME weboldalt haszn�lja!

Eml�keztetj�k, hogy #MembershipLevel# tags�gi szintje #ExpiryDate# d�tumon lej�r.

K�rj�k, <a href=\"#link#\">jelentkezzen be</a> a tags�ga meg�j�t�s�hoz.

Sok szerencs�t!
#AdminName#
SITENAME";

$lang['mship_expired_note']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head"><div class="module_head">#email_hdr_left#</div></td>
<td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;Tags�ga lej�rt! </div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" ><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">Kedves #FirstName#,<br>
<br>K�sz�nj�k, hogy az SITENAME-et haszn�lja!<br><br>Eml�keztetj�k, hogy <B>#MembershipLevel#</B> tags�gi szintje <B>#ExpiryDate#</B> d�tumon lej�r.<br><br>K�rj�k, <a href=\"#link#\">l�pjen be az SITENAME</a> oldalra, hogy meg�j�tsa tags�g�t �s tov�bbra is �lvezhesse szolg�ltat�sainkat.<br><br>Sok szerencs�t!<br>#AdminName# <br>SITENAME<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['mship_expiry_note']['text'] = 'Kedves #FirstName#,

K�sz�nj�k, hogy a SITENAME weboldalt haszn�lja!

Eml�keztetj�k, hogy #MembershipLevel# tags�gi szintje #ExpiryDate# d�tumon lej�r.

K�rj�k, <a href=\"#link#\">jelentkezzen be</a> a tags�ga meg�j�t�s�hoz.

Sok szerencs�t!
#AdminName#
SITENAME"';
$lang['mship_expiry_note']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head">
<div class="module_head">#email_hdr_left#</div></td><td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;Tags�ga hamarosan lej�r!</div></td></tr></table></div></td></tr>
<tr><td width="100%" class="evenrow" colspan="2" ><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">Kedves #FirstName#,<br><br>K�sz�nj�k, hogy az SITENAME-et haszn�lja.<br><br>Eml�keztetj�k, hogy <B>#MembershipLevel#</B> tags�gi szintje <B>#ExpiryDate#</B> d�tumon lej�r.<br><br>K�rj�k, <a href=\"#link#\">jelentkezzen be</a> a tags�ga meg�jit�s�hoz.<br><br>
<br>Sok szerencs�t!<br>#AdminName# <br>SITENAME<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';



/* Newly added - mail to be sent to member when admin changes membership level */

$lang['profile_membership_changed_sub'] = 'SITENAME �zenet:  Tags�gi szintje megv�ltozott!';
$lang['profile_membership_changed']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head">
<div class="module_head">#email_hdr_left#</div></td><td width="493" class="module_head" height="25"><div class="module_head">&nbsp;&nbsp;Tags�gi szintje megv�ltozott! </div></td></tr></table></div></td></tr>
<tr><td width="100%" class="evenrow" colspan="2"><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">Kedves #FirstName#,<br><br>Jelenlegi <b>#CurrentLevel#</b> tags�gi szintje  <b>#NewLevel#</b>-ra v�ltozott, �s  <b>#ValidDate#</b> d�tumon lefog j�rni.<br>
<br>K�rj�k, l�togassa meg a k�vetkez� c�met: <a href=\"#link#\">SITENAME</a>.<br><br>Sok szerencs�t!<br>#AdminName# <br>SITENAME<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['profile_membership_changed']['text'] = "Kedves #FirstName#,

Jelenlegi <b>#CurrentLevel#</b> tags�ga erre v�ltozott: <b>#NewLevel#</b>, ami eddig �rv�nyes: <b>#ValidDate#</b>

L�togasson meg minket a(z) <a href=\"#link#\">SITENAME</a> c�men.

Sok szerencs�t!
#AdminName#
SITENAME
";

$lang['comment_received_sub'] = 'SITENAME �zenet: �j megjegyz�s a blogj�ban';
$lang['comment_received']['text'] = "Kedves #FirstName#,

'<b>#SenderName#</b>', a SITENAME tagja �j megjegyz�st �rt az �n blogj�ba.

L�togassa meg a <a href=\"#link#\"><b>SITENAME</b></a> weboldalt a '<b>#SenderName#</b>' �ltal �rt megjegyz�s megtekint�s�hez.

Sok szerencs�t!
#AdminName#
SITENAME";
$lang['comment_received']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head"><div class="module_head">#email_hdr_left#</div></td><td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;Egy felhaszn�l� �ppen �j megjegyz�st �rt a blogj�ba! </div></td></tr></table></div></td></tr>
<tr><td width="100%" class="evenrow" colspan="2"><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">Kedves #FirstName#,<br><br><b>#SenderName#</b>, a SITENAME tagja, �j megjegyz�st �rt a blogj�ba.<br><br>K�rj�k, l�togasson el a <a href=\"#link#\"><b>SITENAME</b></a> c�mre, hogy megtekinthesse a megjegyz�st <b>#SenderName#</b>-t�(�)l.<br>
<br>Sok szerencs�t!<br>#AdminName# <br>SITENAME<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';
$lang['aff_added_sub'] = 'SITENAME �zenet: T�rshirdet� tag lett!';
$lang['aff_added']['text'] = "Kedves #Name#,

�r�mmel �rtesitj�k, hogy a SITENAME weboldal t�rshirdet�je lett!

Felhaszn�l�: #Affid#
Jelsz�: #Password#

L�togassa meg a <a href=\"#SiteUrl#\"><b>SITENAME</b></a> weboldalt, jelentkezzen be a t�rshirdet�k r�szbe �s v�ltoztassa meg jelszav�t min�l hamarabb.

Sok szerencs�t!
#AdminName#
SITENAME";

$lang['aff_added']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head"><div class="module_head">#email_hdr_left#</div></td><td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;T�rshirdet�i tag lett!</div></td></tr></table></div></td></tr>
<tr><td width="100%" class="evenrow" colspan="2"><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">Dear #Name#,<br><br>�r�mmel �rtesitj�k, hogy a SITENAME weboldal t�rshirdet�je lett!<br><br><b>Azonos�t�ja: #Affid#</b><br><b>Jelszava: #Password#</b><br><br>K�rj�k, l�togasson el a k�vetkez� c�mre: <a href=\"#SiteUrl#\"><b>SITENAME</b></a>, jelentkezzen be az t�rshirdet�i r�szbe �s cser�lje meg a jelszav�t min�l hamarabb.<br><br>Sok szerencs�t!<br>#AdminName# <br>SITENAME<br></td>
</tr></table></div>
</td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';
$lang['aff_newpwd_sub'] = 'SITENAME �zenet: T�rshirdet�i hozz�f�r�seir"ol...';
$lang['aff_newpwd']['text'] = "Kedves #Name#,

A t�rshirdet�i hozz�f�r�s�hez egy �j jelsz�t gener�ltunk.

Az �j jelsz�: #Password#

L�togassa meg a(z) <a href=\"#SiteUrl#\"><b>SITENAME</b></a> oldalt, jelentkezzen be a t�rshirdet�k r�szbe �s v�ltoztassa meg jelszav�t min�l hamarabb.

Sok szerencs�t!
#AdminName#
SITENAME";

$lang['aff_newpwd']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head"><div class="module_head">#email_hdr_left#</div></td>
<td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;T�rshirdet�i hozz�f�r�seir�l... </div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2"><div class="evenrow"><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">Kedves #Name#,<br><br>A t�rshirdet�i hozz�f�r�s�hez egy �j jelsz�t gener�ltunk.<br>
<br>Jelszava: #Password#</b><br><br>K�rj�k, l�togasson el a k�vetkez� c�mre <a href=\"#SiteUrl#\"><b>SITENAME</b></a>, jelentkezzen be a t�rshirdet�k r�szbe �s cser�lje meg a jelszav�t min�l hamarabb. <br><br>Sok szerencs�t!<br>#AdminName# <br>SITENAME<br></td></tr></table></div>
</td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';
$lang['add_affiliate'] = 'Hozz�ad egy t�rshirdet�t';
$lang['mod_affiliate'] = 'M�dos�t egy t�rshirdet�t';
$lang['aff_modified'] = 'T�rshirdet�k informaci�i megv�ltoztatva';


$lang['newuser']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head"><div class="module_head">#email_hdr_left#</div></td><td width="493" class="module_head" ><div class="module_head"><font color=white>&Uacute;j felhaszn&aacute;l&oacute iratkozott fel!</font></div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" ><div class="evenrow"><table border="0" cellspacing="0" cellpadding="5"><tr><td width="100%" valign="top" class="evenrow">Kedves oldal Adminisztr&aacute;tor,<br><br>&Uacute;j felhaszn&aacute;l&oacute; regisztr&aacute;lt az #SiteName# oldalra.<br> <br> Felhaszn&aacute;l&oacute;n&eacute;v: <a href="#SiteUrl#admin/showprofile.php?username=#UserName#">#UserName#</a><br><br> #AdminName# <br> SITENAME<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';



$lang['newuser']['text'] = "Kedves oldal Adminisztr�tor,

�j felhaszn�l� regisztr�lt az #SiteName# oldalra.

Felhaszn�l�n�v: #UserName#

#AdminName#
SITENAME";

$lang['newuser_sub'] = '�j felhaszn�l� regisztr�lt';

/* Following user options are managed. Please modify only the description and not these keys */

$lang['user_choices'] = array(
	'email_message_received' 	=> "Email k�ld�se az �rkezett �zenetekr�l.",
	'email_wink_received'		=> "Email k�ld�se kaccsint�sokkor.",
	'email_blog_commented'		=> "Email k�ld�se blog komment�r hozz�ad�sakor.",
	'email_mship_expiry'		=> "Tags�g lej�rt�ra figyelmeztet� emailek k�ld�se.",
	'email_message_read'		=> "Email k�ld�se az �ltalam k�ld�tt �zenetekr�l, amikor a cimzett elolvasta.",
	'email_buddy_list'			=> "Email k�ld�se, amikor valaki felvesz a partnerlist�j�ra.",
	'email_ban_list'			=> "Email k�ld�se, amikor valaki felvesz a tilt�list�j�ra.",
	'email_hot_list'			=> "Email k�ld�se, amikor valaki felvesz a hot list�j�ra.",
	"allow_buddy_view_album"	=> "Partnereim megtekinthetik a priv�t albumaimat.",
	"allow_hotlist_view_album"	=> "Hot list�s tagok megtekinthetik a priv�t albumaimat.",
	'email_match_mail_days'		=> "H�ny naponta kapjak emailt a tal�lataimr�l? 0 - kikapcsol.",
	);
$lang['mysettings_updated'] = 'Email fogad�si be�ll�t�sok friss�tve.';
$lang['resend_conflink_hdr'] = '�rv�nyes�t� email �jrak�ld�se';
$lang['resend_conflink_hdr1'] = 'Elvesztette vagy nem kapta meg az �rv�nyes�t� emailt regisztr�ci� ut�n? Adja meg az email c�m�t az �jrak�ld�shez.';
$lang['resend_conflink_msg'] = '�rv�nyes�t� email �jrak�ldve.';
$lang['resend_conflink_msg1'] = 'Adja meg a regisztr�ci�kor haszn�lt email c�met.';
$lang['resend_conflink_err1'] = 'M�r �rv�nyes�tette a feliratkoz�s�t. Haszn�lja az <a href="forgotpass.php">elfelejtett jelsz�</a> opci�t egy �j jelsz� k�ld�s�hez.';
$lang['about_me'] = 'Magamr�l';
$lang['about_me_hlp'] = 'Adjon meg egy r�vid le�r�st, ami m�sokat �rdekelhet.';
$lang['aff_forgot_pass'] = 'Adja meg az email c�met egy �j jelsz� k�ld�s�hez:';
$lang['send_new_password'] = '�j jelsz� k�ld�se';
$lang['not_a_member'] = 'M�g nem tag?';
$lang['login_reminded'] = 'Felhaszn�l�i n�v �s jelsz� eml�keztet�se.';
$lang['lost_confemail'] = 'Elvesztett �rv�nyes�t� email?';
$lang['couple_usernames'] = 'P�rok / csoportok felhaszn�l�nevei';
$lang['couple_usernames_hlp'] = 'Egy p�r vagy csoport t�bb tagb�l �ll. Adja meg a felhaszn�l�neveit a p�r vagy csoport tagjainak az al�bbi mez�ben. P�ld�ul: felh_1, felh_2, felh_3.';
$lang['blog']['del01'] = 'Biztosan t�rl�d a megjegyz�st?';
$lang['blog']['del02'] = 'Biztosan t�rl�d a kiv�lasztott ';
$lang['blog']['del03'] = 'T�nyleg le akarja t�r�lni ';
$lang['feat_prof_del_msg'] = 'T�rl�d a profilt a k�l�nleges profilok list�j�b�l?';
$lang['feat_prof_deleted'] = 'A kiv�lasztott profil t�r�lve a list�b�l.';

$lang['mymatches_sub'] = 'SITENAME �zenet: A profil keres�s�nek tal�latair�l sz�l� email!';

$lang['mymatches_body']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td width="77" height="25">#email_hdr_left#</td><td width="493" class="module_head" >&nbsp;&nbsp; A profil keres�s�nek tal�latair�l sz�l� email! </td></tr><tr><td width="570" class="evenrow" colspan="2" style="padding: 5px;"><table border="0" cellspacing="2" cellpadding="2"><tr><td height="6"></td></tr><tr><td class="evenrow">Kedves #FirstName#,<br><br>A k�vetkez�kben egy list�t tal�l azokr�l a profilokr�l, amelyek megfeleltek a keres�si krit�riumainak. </td></tr><tr><td height="10" class="evenrow"> </td></tr><tr><td valign="top" class="evenrow">#matchedProfiles#</td></tr><tr><td height="10" class="evenrow"> </td></tr><tr><td class="evenrow">K�rj�k, l�tog�sson el a <a href=\"#link#\">SITENAME</a> c�mre, hogy megtekinthesse ezeket a profilokat. <br><br>Sok szerencs�t!<br>#AdminName#<br>SITENAME<br></td></tr></table> </td></tr></table>';

$lang['on'] = '';

$lang['use_seo_username'] = 'Felhaszn�l�n�v haszn�lata az URL-ben. Ezt bekapcsolva a profil URL-eknek a k�vetkez� form�t adja: domain/felhaszn�l�n�v. Kikapcsolva az URL form�tuma: domain/id.htm"';
$lang['leave_blank_no_change'] = '(hagyja �resen ha nem szeretn� megcser�lni)';

$lang['adminltr']['html']='<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td width="77" height="25" class="module_head">#email_hdr_left#</td><td width="493" class="module_head" >&nbsp;&nbsp;#Subject#</td></tr><tr><td width="100%" class="evenrow" colspan="2" style="padding: 5px;"><table border="0" cellspacing="0" cellpadding="6"><tr><td height="6"></td></tr><tr><td width="100%" valign="top" class="evenrow">#LetterContent#</td></tr></table></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['adminltr']['text'] = '#LetterContent#';

/* Following is the section headers in appropriate languages */

$lang['sections'] = array(
	'1'	=> 	'Alapinform�ci�k',
	'2'	=>	'Fizikai megjelen�s',
	'3'	=>	'Hivat�s',
	'4'	=>	'�letst�lus',
	'5'	=>	'�rdeklod�si k�r'	);

/* Following is for mail encoding */
$lang['mail_text_encoding'] = '7bit';
$lang['mail_html_encoding'] = '7bit';
$lang['mail_html_charset'] = 'ISO-8859-2';
$lang['mail_text_charset'] = 'ISO-8859-2';
$lang['mail_head_charset'] = 'ISO-8859-2';

$lang['split_file_names_hdr'] = 'F�jlok amelyek most t�lt�dnek';
$lang['worst1'] = '(legrosszabb)';
$lang['best1'] = '(legjobb)';
$lang['profile_auto_confirmed'] = 'K�sz�nj�k, hogy  SITENAME tagja lett.<br><br>Hogy a kedv�re legy�nk, rendszer�nk automatikusan �rv�nyes�tette az �n profilj�t.<br><br>K�rj�k, <a href="index.php?page=login">l�pjen be</a>, hogy �lvezhesse szolg�latainkat.<br><br>';
$lang['zipfile'] = 'Ir�ny�t�sz�m k�nyvt�r';
$lang['zip_ensure'] = 'K�rj�k, t�ltse fel az ir�ny�t�sz�mokat a /zipcodes/countryname  k�nyvt�rba. A nagy m�ret� f�jlokat ossza fel kisebbekre az /admin/split_zipcodes_file.php -t haszn�lva. <br /><br />A f�jlnak tartalmaznia kell IR�NY�T�SZ�MOT, F�LDRAJZI HOSSZ�S�GOT, F�LDRAJZI SZ�LESS�GET, �LLAMK�DOT, MEGYEK�DOT, V�ROSK�DOT (ebben a sorrendben. Az �LLAMK�D,MEGYEK�D �s V�ROSK�D elhagyhat� �s k�sobb p�tolhat�) vesszovel elv�lasztva.<br /><br /><b>Miel�tt bet�lten� az ir�ny�t�sz�mok f�jlt egy orsz�gnak, k�rj�k, EL�SZ�R t�r�lje az adott orsz�gra vonatkoz� k�dokat, ez�ltal kiz�rva a lehetos�g�t, hogy k�tszer legyenek felt�ltve.</b><br /><br />Egy orsz�g ir�ny�t�sz�mainak t�rl�s�hez v�lassza ki az orsz�got �s nyomja meg a T�r�l gombot.';
$lang['load_zips'] = 'Ir�ny�t�sz�mokat bet�lt';
$lang['zip_loaded'] = 'Ir�ny�t�sz�mokat bet�lt�tt�k a f�jlb�l ';
$lang['zip_load_over'] = ' #COUNTRY# ir�ny�t�sz�mainak bet�lt�se befejezod�tt.';
$lang['filter_options']['email'] = 'Email';
$lang['filter_options']['gender'] = 'Nem';
$lang['loginagain'] = 'L�pjen ki �s l�pjen be, hogy t�gs�g�t haszn�lni tudja';
$lang['online_users_txt'] = 'Online tagok';

$lang['status_disp'] = array(
	'approval' => 'V�rakoz�',
	'active' => 'Akt�v',
	'rejected' => 'Elutas�tva',
	'suspended' => 'Letiltva',
	/* added in 1.1.0 */
	'cancel' => 'T�r�lve'
	);
$lang['status_enum'] = array(
	'approval' => 'Lappang',
	'active' => 'Akt�v',
	'rejected' => 'Elutas�tva',
	'suspended' => 'Letiltva',
	);

$lang['status_act'] = array(
	'approval' => 'V�rakoz�',
	'active' => 'Akt�v',
	'rejected' => 'Elutas�tva',
	'suspended' => 'Letiltva',
	/* added in 1.1.0 */
	'cancel' => 'T�r�lve'
	);



?>
