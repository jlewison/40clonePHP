<?php

/**
 * search Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 1/8/2008
 */
class search extends Controller
{
		var $start, $limit, $outputData;
		// Constructor
		function search()
		{
				parent::Controller();
				loginRequired();
				// Load the language file
				$this->lang->load('network', $this->config->item('language_code'));
				$this->lang->load('search', $this->config->item('language_code'));
				//Load the search model
				$this->load->model('searchmodel');
				//Initialize
				$this->outputData = array();
		}
		// Default function
		function index()
		{
				redirect('search/all');
		}
		function _prepareSearch($default)
		{
				$searchFor = (trim($this->uri->segment(3)) == '') ? $default : $this->uri->segment(3);
				$this->outputData['searchArea'] = strtolower($this->uri->segment(2));
				$this->outputData['searchFor'] = $searchFor;
				$this->outputData['keyword'] = $this->input->post('searchKeyword');
				$this->start = ($this->input->post('pageNo')) ? $this->input->post('pageNo') : 0;
				//Load the pagination model
				$this->load->model('paginationmodel');
				$this->limit = $this->paginationmodel->getPerPage('search_results');
		}
		function _preparePagination($currentPageSegment)
		{
				//For pagination
				$this->outputData['currentPage'] = ($this->input->post('pageNo')) ? $this->input->post('pageNo') : 0;
				$this->outputData['totalPages'] = ($this->outputData['resultsTotal'] > 0) ? round($this->outputData['resultsTotal'] / $this->outputData['resultsCount']) : 0;
				$this->outputData['pageUrl'] = base_url() . 'search/' . $this->uri->segment(2) . '/' . $this->outputData['searchFor'] . '/';
		}
		function profile()
		{
				$this->load->model('usermodel');
				$current_year = date('Y');
				$year_range = range($current_year - 80, $current_year);
				foreach ($year_range as $key => $val) $years[$val] = $val;
				$this->outputData['years'] = $years;
				if (isset($_POST) && is_array($_POST) && count($_POST) > 0)
				{
						$this->start = ($this->input->post('pageNo')) ? $this->input->post('pageNo') : 0;
						//Load the pagination model
						$this->load->model('paginationmodel');
						$this->limit = $this->paginationmodel->getPerPage('search_results');
						$this->outputData['searchArea'] = (strtolower($this->uri->segment(3)) != '') ? strtolower($this->uri->segment(3)) : 'peoples';
						$this->outputData['results'] = $this->searchmodel->searchProfile($_POST, 'last_login', $this->start, $this->limit);
						$this->outputData['searchFor'] = 'peoples';
						$this->outputData['resultsCount'] = count($this->outputData['results']);
						$this->outputData['resultsTotal'] = $this->searchmodel->searchProfileCount($_POST);
						$this->outputData['random_no'] = rand(100, 10000);
						//For pagination
						$this->_preparePagination(4);
						$this->smartyextended->view('searchresults', $this->outputData);
				}
				else
				{
						$this->outputData['userNetworks'] = $this->usermodel->getNetworks();
						$this->outputData['relationStatus'] = $this->usermodel->getRelationStatus();
						$this->outputData['lookingFor'] = $this->usermodel->getLookingFor();
						$this->outputData['politicalViews'] = $this->usermodel->getPoliticalViews();
						$this->outputData['religiousViews'] = $this->usermodel->getReligiousViews();
						$this->outputData['stateList'] = $this->usermodel->getStateList();
						$this->outputData['countryList'] = $this->usermodel->getCountry();
						$this->smartyextended->view('searchprofile', $this->outputData);
				}
		}
		function networks()
		{
				$this->_prepareSearch('join');
				$this->outputData['results'] = $this->searchmodel->searchNetworks($this->outputData['keyword'], '', 'datestamp desc', $this->start, $this->limit);
				$this->outputData['resultsCount'] = count($this->outputData['results']);
				$this->outputData['resultsTotal'] = $this->searchmodel->searchNetworksCount($this->outputData['keyword']);
				$this->_preparePagination(4);
				$this->smartyextended->view('searchresults', $this->outputData);
		}
		function peoples()
		{
				$this->_prepareSearch('block');
				$this->outputData['results'] = $this->searchmodel->searchPeoples($this->outputData['keyword'], 'last_login', $this->start, $this->limit);
				$this->outputData['resultsCount'] = count($this->outputData['results']);
				$this->outputData['resultsTotal'] = $this->searchmodel->searchPeoplesCount($this->outputData['keyword']);
				$this->_preparePagination(4);
				$this->smartyextended->view('searchresults', $this->outputData);
		}
		function friends()
		{
				$this->_prepareSearch('');
				$this->outputData['results'] = $this->searchmodel->searchFriends($this->outputData['keyword'], 'last_login desc', $this->start, $this->limit);
				$this->outputData['resultsCount'] = count($this->outputData['results']);
				$this->outputData['resultsTotal'] = $this->searchmodel->searchFriendsCount($this->outputData['keyword']);
				$this->_preparePagination(4);
				$this->smartyextended->view('searchresults', $this->outputData);
		}
		function all()
		{
				$this->outputData['searchArea'] = (strtolower($this->uri->segment(3)) != '') ? strtolower($this->uri->segment(3)) : 'peoples';
				$this->outputData['keyword'] = $this->input->post('searchKeyword');
				$this->outputData['networkId'] = $this->input->post('networkId');
				$this->start = ($this->input->post('pageNo')) ? $this->input->post('pageNo') : 0;
				//Load the pagination model
				$this->load->model('paginationmodel');
				$this->limit = $this->paginationmodel->getPerPage('search_results');
				if ($this->outputData['searchArea'] == 'peoples')
				{
						$this->outputData['results'] = $this->searchmodel->searchPeoples($this->outputData['keyword'], 'last_login', $this->start, $this->limit, false, false, true, $this->outputData['networkId']);
						$this->outputData['resultsCount'] = count($this->outputData['results']);
						$this->outputData['resultsTotal'] = $this->searchmodel->searchPeoplesCount($this->outputData['keyword'], false, false, true, $this->outputData['networkId']);
				} elseif ($this->outputData['searchArea'] == 'events')
				{
						$this->outputData['results'] = $this->searchmodel->searchEvents($this->outputData['keyword'], '', $this->start, $this->limit);
						$this->outputData['resultsCount'] = count($this->outputData['results']);
						$this->outputData['resultsTotal'] = $this->searchmodel->searchEventsCount($this->outputData['keyword']);
				} elseif ($this->outputData['searchArea'] == 'groups')
				{
						$this->outputData['results'] = $this->searchmodel->searchGroups($this->outputData['keyword'], '', $this->start, $this->limit);
						$this->outputData['resultsCount'] = count($this->outputData['results']);
						$this->outputData['resultsTotal'] = $this->searchmodel->searchgroupsCount($this->outputData['keyword']);
				} elseif ($this->outputData['searchArea'] == 'networks')
				{
						$this->outputData['results'] = $this->searchmodel->searchNetworks($this->outputData['keyword'], '', 'datestamp desc', $this->start, $this->limit);
						$this->outputData['resultsCount'] = count($this->outputData['results']);
						$this->outputData['resultsTotal'] = $this->searchmodel->searchNetworksCount($this->outputData['keyword']);
				}
				//For pagination
				$this->outputData['currentPage'] = ($this->input->post('pageNo')) ? $this->input->post('pageNo') : 0;
				$this->outputData['totalPages'] = ($this->outputData['resultsTotal'] > 0) ? round($this->outputData['resultsTotal'] / $this->limit) : 0;
				$this->outputData['pageUrl'] = base_url() . 'search/all/' . $this->outputData['searchArea'] . '/';
				$this->smartyextended->view('searchallresults', $this->outputData);
		}
}

?>