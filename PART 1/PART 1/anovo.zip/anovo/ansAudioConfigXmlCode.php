<?php
require_once ('common/config.inc.php');
require_once ('common/configs/config_ans_audio.inc.php');
$CFG['lang']['include_files'][] = 'admin/includes/languages/%s/ansAudioConfiguration.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['mods']['is_include_only']['non_html_header_files'] = true;
$CFG['auth']['is_authenticate'] = false;
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class XmlCode extends FormHandler
{
		public function setHeaderStart()
		{
				ob_start();
				header("Pragma: no-cache");
				header("Cache-Control: no-cache, must-revalidate");
				header("Expires: 0");
				header("Content-type: text/xml; charset=iso-8859-1");
		}
		public function changeConfigBooleanValues()
		{
				$array = array('AutoPlay', 'ToolTip');
				foreach ($array as $key => $value)
				{
						if ($this->CFG['admin']['ans_audios'][$value]) $this->CFG['admin']['ans_audios'][$value] = 'true';
						else  $this->CFG['admin']['ans_audios'][$value] = 'false';
				}
		}
		public function getXmlCode()
		{
				$fields = explode('_', $this->fields_arr['pg']);
				$this->fields_arr['pg'] = $fields[0];
				$this->fields_arr['aid'] = $fields[1];
				if (!($this->fields_arr['pg'] and $this->fields_arr['aid']))
				{
						return;
				}
				$sharing_url = '';
				switch ($this->fields_arr['pg'])
				{
						case 'music':
								break;
						case 'previewmusic':
								break;
						case 'smallmusic':
								$this->CFG['admin']['musics']['SelectedSkin'] = 'mini_' . $this->CFG['admin']['musics']['SelectedSkin'];
								break;
						case 'musicactivate':
								$this->CFG['admin']['musics']['SelectedSkin'] = 'mini_' . $this->CFG['admin']['musics']['SelectedSkin'];
								break;
				}
				$this->changeConfigBooleanValues();
?>
<CONFIG>
	<SETTINGS>
		<PLAYER autoplay="false" />
		<PLAYER toolTip="false" />
	</SETTINGS>
	<SKINS>
		<SKIN Name="newskin " recorderPath="<?php echo $this->CFG['site']['url'] . 'files/flash/mp3_player/skins/' . $this->CFG['admin']['ans_audios']['SelectedSkin']; ?>.swf"  enabled="true"/>
	</SKINS>
	<GOTO Name="goto" URL="http://www.ijigg.com/songs/" Target="_blank" />
	<CMT Name="cmt" URL="http://www.yahoo.com/" Target="_blank" />
	<SHARE Name="share" URL="<?php echo $sharing_url; ?>" Target="_blank" />
	<LOGIN Name="login" URL="http://www.domain.tld/" Target="_blank" />
	<INTERFACE>
		<TEXT  Tooltip="Serial Number"  Label="<?php echo $this->LANG['Serial NumberToolTip']; ?>" />
		<TEXT  Tooltip="Album Name"  Label="<?php echo $this->LANG['Album NameToolTip']; ?>" />
		<TEXT  Tooltip="Stop"  Label="<?php echo $this->LANG['StopToolTip']; ?>" />
		<TEXT  Tooltip="Play"  Label="<?php echo $this->LANG['PlayToolTip']; ?>" />
		<TEXT  Tooltip="Pause"  Label="<?php echo $this->LANG['PauseToolTip']; ?>" />
		<TEXT  Tooltip="Tack sequence"  Label="<?php echo $this->LANG['Tack sequenceToolTip']; ?>" />
		<TEXT  Tooltip="Vol"  Label="<?php echo $this->LANG['VolToolTip']; ?>" />
		<TEXT  Tooltip="Drag player"  Label="<?php echo $this->LANG['Drag playerToolTip']; ?>" />
		<TEXT  Tooltip="Last"  Label="<?php echo $this->LANG['LastToolTip']; ?>" />
		<TEXT  Tooltip="First"  Label="<?php echo $this->LANG['FirstToolTip']; ?>" />
		<TEXT  Tooltip="Open"  Label="<?php echo $this->LANG['OpenToolTip']; ?>" />
		<TEXT  Tooltip="Close"  Label="<?php echo $this->LANG['CloseToolTip']; ?>" />

		<TEXT  Tooltip="Next"  Label="<?php echo $this->LANG['NextToolTip']; ?>" />
		<TEXT  Tooltip="Previous"  Label="<?php echo $this->LANG['PreviousToolTip']; ?>" />
		<TEXT  Tooltip="Mute"  Label="<?php echo $this->LANG['MuteToolTip']; ?>" />
		<TEXT  Tooltip="UnMute"  Label="<?php echo $this->LANG['UnMuteToolTip']; ?>" />
		<TEXT  Tooltip="Open Play List"  Label="<?php echo $this->LANG['Open Play ListToolTip']; ?>" />
		<TEXT  Tooltip="Close Play List"  Label="<?php echo $this->LANG['Close Play ListToolTip']; ?>" />
		<TEXT  Tooltip="Minimize"  Label="<?php echo $this->LANG['MinimizeToolTip']; ?>" />
		<TEXT  Tooltip="Help"  Label="<?php echo $this->LANG['HelpToolTip']; ?>" />
		<TEXT  Tooltip="Repeat"  Label="<?php echo $this->LANG['RepeatToolTip']; ?>" />
		<TEXT  Tooltip="Shuffle"  Label="<?php echo $this->LANG['ShuffleToolTip']; ?>" />
		<TEXT  Tooltip="Up"  Label="<?php echo $this->LANG['UpToolTip']; ?>" />
		<TEXT  Tooltip="Down"  Label="<?php echo $this->LANG['DownToolTip']; ?>" />
		<TEXT  Tooltip="Ijigg"  Label="<?php echo $this->LANG['IjiggToolTip']; ?>" />
		<TEXT  Tooltip="IikeIjigg"  Label="<?php echo $this->LANG['IikeIjiggToolTip']; ?>" />
	</INTERFACE>
</CONFIG>
<?php
		}
}
$XmlCode = new XmlCode();
$XmlCode->setHeaderStart();
$XmlCode->setDBObject($db);
$CFG['user']['user_id'] = isset($_SESSION['user']['user_id']) ? $_SESSION['user']['user_id'] : '0';
$XmlCode->makeGlobalize($CFG, $LANG);
$XmlCode->setPageBlockNames(array('get_code_form'));
$XmlCode->setFormField('aid', '');
$XmlCode->setFormField('pg', '');
$XmlCode->setFormField('gurl', '');
$XmlCode->setFormField('full', false);
$XmlCode->setPageBlockShow('get_code_form');
$XmlCode->sanitizeFormInputs($_GET);
if ($XmlCode->isShowPageBlock('get_code_form'))
{
		$XmlCode->getXmlCode();
}
$XmlCode->setHeaderEnd();


?>