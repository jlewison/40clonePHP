<?php
require_once ('../common/config.inc.php');
$CFG['lang']['include_files'][] = 'members/includes/languages/%s/forumsResponseCreate.php';
$CFG['lang']['include_files'][] = 'members/includes/languages/%s/forumsRightLinks.php';
$CFG['html']['header'] = 'members/includes/languages/%s/html_header.php';
$CFG['html']['footer'] = 'members/includes/languages/%s/html_footer.php';
$CFG['lang']['include_files'][] = 'common/languages/%s/help.inc.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['mods']['include_files'][] = 'common/classes/class_ForumHandler.lib.php';
$CFG['mods']['include_files'][] = 'common/classes/class_inputfilter_clean.php';
$CFG['db']['is_use_db'] = true;
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class ForumResponseFormHandler extends ForumHandler
{
		public $forum_details_arr;
		public $forum_topic_details_arr;
		public function chkLength($field_name, $err_tip = '')
		{
				$url_len = strlen($this->fields_arr[$field_name]);
				if ($url_len < 3 || $url_len > 20)
				{
						$this->fields_err_tip_arr[$field_name] = $err_tip;
						return false;
				}
				return true;
		}
		public function createForumResponse()
		{
				if ($this->fields_arr['response_id'])
				{
						$this->updateForumResponse($this->fields_arr['topic_id'], $this->fields_arr['response_id']);
						$this->updateForumTopicViews($this->fields_arr['topic_id']);
				}
				else
				{
						$this->insertForumResponse($this->fields_arr['topic_id']);
						$this->updateForumTopic($this->fields_arr['topic_id']);
						$this->updateForums($this->fields_arr['forum_id']);
						$this->updateUsersAnsLog();
				}
		}
		public function updateForums($forum_id)
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['forums'] . ' SET ' . 'last_post_user_id = ' . $this->dbObj->Param($this->CFG['user']['user_id']) . ', ' . 'last_post_date = now(), ' . 'total_response = total_response + 1 ' . 'WHERE forum_id = ' . $this->dbObj->Param($forum_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->CFG['user']['user_id'], $forum_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return true;
		}
		public function updateForumResponse($topic_id, $response_id)
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['forum_response'] . ' SET ' . 'forum_response = ' . $this->dbObj->Param($this->fields_arr['forum_response']) . ' ' . 'WHERE response_user_id = ' . $this->dbObj->Param($this->CFG['user']['user_id']) . ' ' . 'AND topic_id = ' . $this->dbObj->Param($topic_id) . ' ' . 'AND response_id = ' . $this->dbObj->Param($response_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array(html_entity_decode($this->fields_arr['forum_response'], ENT_QUOTES, $this->CFG['site']['charset']), $this->CFG['user']['user_id'], $topic_id, $response_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return true;
		}
		public function updateForumTopic($topic_id)
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['forum_topics'] . ' SET ' . 'total_response = total_response + 1, ' . 'total_views = total_views + 1, ' . 'last_post_user_id = ' . $this->dbObj->Param($this->CFG['user']['user_id']) . ', ' . 'last_post_date = now() ';
				$fields_value_arr[] = $this->CFG['user']['user_id'];
				if ($this->fields_arr['forum_ratings'])
				{
						$sql .= ', rating_total = rating_total + ' . $this->dbObj->Param($this->fields_arr['forum_ratings']) . ', ' . ' rating_count = rating_count + 1 ';
						$fields_value_arr[] = $this->fields_arr['forum_ratings'];
				}
				$sql .= 'WHERE topic_id = ' . $this->dbObj->Param($topic_id);
				$fields_value_arr[] = $topic_id;
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, $fields_value_arr);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return true;
		}
		public function updateForumTopicViews($topic_id)
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['forum_topics'] . ' SET ' . 'total_views = total_views + 1 ';
				if ($this->fields_arr['forum_ratings'])
				{
						$sql .= ', rating_total = rating_total + ' . $this->dbObj->Param($this->fields_arr['forum_ratings']) . ', ' . ' rating_count = rating_count + 1 ';
						$fields_value_arr[] = $this->fields_arr['forum_ratings'];
				}
				$sql .= 'WHERE topic_id = ' . $this->dbObj->Param($topic_id) . ' ' . 'AND last_post_user_id = ' . $this->dbObj->Param($this->CFG['user']['user_id']);
				$fields_value_arr[] = $topic_id;
				$fields_value_arr[] = $this->CFG['user']['user_id'];
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, $fields_value_arr);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return true;
		}
		public function populateRatings($ratings_value)
		{
				for ($i = 1; $i <= 10; $i++)
				{
?>
<input type="radio" class="clsCheckRadio" name="forum_ratings" id="forum_ratings<?php echo $i; ?>" tabindex="<?php $this->getTabIndex(); ?>" value="<?php echo $i; ?>"<?php echo ($ratings_value == $i) ? 'CHECKED' : ''; ?> /><?php echo $i; ?>&nbsp;&nbsp;
<?php
				}
		}
		public function setError($field_name, $err_tip = '')
		{
				$this->fields_err_tip_arr[$field_name] = $err_tip;
		}
}
$forumsresponse = new ForumResponseFormHandler();
if (!chkAllowedModule(array('forums'))) Redirect2URL($CFG['redirect']['dsabled_module_url']);
$forumsresponse->setPageBlockNames(array('msg_form_error', 'msg_form_success', 'form_create_response'));
$forumsresponse->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$forumsresponse->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$forumsresponse->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$forumsresponse->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$forumsresponse->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$forumsresponse->setDBObject($db);
$forumsresponse->setCfgLangGlobal($CFG, $LANG);
$forumsresponse->setFormField('forum_id', '');
$forumsresponse->setFormField('topic_id', '');
$forumsresponse->setFormField('response_id', '');
$forumsresponse->setFormField('forum_response', '');
$forumsresponse->setFormField('forum_ratings', '');
$msg = 'add';
$forumsresponse->setAllPageBlocksHide();
if ($forumsresponse->isFormGETed($_GET, 'forum_id') && $forumsresponse->isFormGETed($_GET, 'topic_id'))
{
		$forumsresponse->sanitizeFormInputs($_GET);
		$forumsresponse->chkIsNotEmpty('forum_id', $LANG['forumsresponse_err_tip_compulsory']) and $forumsresponse->chkIsNumeric('forum_id', $LANG['forumsresponse_err_tip_compulsory']) and $forumsresponse->isValidForumId($forumsresponse->getFormField('forum_id'), $LANG['forumsresponse_err_tip_invalid_forum_id']);
		$forumsresponse->chkIsNotEmpty('topic_id', $LANG['forumsresponse_err_tip_compulsory']) and $forumsresponse->chkIsNumeric('topic_id', $LANG['forumsresponse_err_tip_compulsory']) and $forumsresponse->isValidForumTopicId($forumsresponse->getFormField('forum_id'), $forumsresponse->getFormField('topic_id'), $LANG['forumsresponse_err_tip_invalid_forum_topic_id']);
		$forumsresponse->getFormField('response_id') and $forumsresponse->chkIsNotEmpty('response_id', $LANG['forumsresponse_err_tip_compulsory']) and $forumsresponse->chkIsNumeric('response_id', $LANG['forumsresponse_err_tip_compulsory']) and $forumsresponse->isValidForumResponseId($forumsresponse->getFormField('topic_id'), $forumsresponse->getFormField('response_id'), $LANG['forumsresponse_err_tip_invalid_forum_response_id']);
		if (!$forumsresponse->isAllowedToAsk())
		{
				$forumsresponse->setCommonErrorMsg($LANG['info_not_allowed_to_post']);
		}
		if ($forumsresponse->isValidFormInputs())
		{
				$forumsresponse->setPageBlockShow('form_create_response');
		}
		else
		{
				$forumsresponse->setPageBlockShow('msg_form_error');
		}
		if ($forumsresponse->isFormPOSTed($_POST, 'forumsresponse_submit'))
		{
				$forumsresponse->sanitizeFormInputs($_POST);
				$filter = new InputFilter($CFG['fckeditor']['allowed_tags'], $CFG['fckeditor']['allowed_attr']);
				$forumsresponse->setFormfield('forum_response', $filter->process($forumsresponse->getFormfield('forum_response')));
				$forumsresponse->chkIsNotEmpty('forum_response', $LANG['forumsresponse_err_tip_compulsory']);
				if ($forumsresponse->getFormField('response_id')) $msg = 'edit';
				if ($forumsresponse->isValidFormInputs())
				{
						$forumsresponse->createForumResponse();
						$forumsresponse->setAllPageBlocksHide();
						$forumsresponse->setPageBlockShow('form_create_response');
						Redirect2URL(getUrl('forumsResponses.php?forum_id=' . $forumsresponse->getFormField('forum_id') . '&topic_id=' . $forumsresponse->getFormField('topic_id') . '&msg=' . $msg, 'forum/' . $forumsresponse->getFormField('forum_id') . '/' . $forumsresponse->getFormField('topic_id') . '/?msg=' . $msg));
				}
				else
				{
						$forumsresponse->setAllPageBlocksHide();
						$forumsresponse->setPageBlockShow('msg_form_error');
						$forumsresponse->setPageBlockShow('form_create_response');
				}
		}
		if ($forumsresponse->isFormPOSTed($_POST, 'forumsresponse_cancel'))
		{
				$forumsresponse->sanitizeFormInputs($_POST);
				Redirect2URL(getUrl('forumsResponses.php?forum_id=' . $forumsresponse->getFormField('forum_id') . '&topic_id=' . $forumsresponse->getFormField('topic_id'), 'forum/' . $forumsresponse->getFormField('forum_id') . '/' . $forumsresponse->getFormField('topic_id') . '/'));
		}
}
else
{
		$forumsresponse->setAllPageBlocksHide();
		$forumsresponse->setPageBlockShow('msg_form_error');
}



?>
<script type="text/javascript" language="javascript">
	var palette_url = '<?php echo $CFG['site']['url'] . 'admin/palette.htm'; ?>';
	var block_arr= new Array('selMsgConfirm');
</script>
<div id="selForumResponseCreate">
	 <h2 id="selForumTitle"><span>
		<a href="<?php echo getUrl('forums.php', 'forum/'); ?>"><?php echo $LANG['forumlistall_title_index']; ?></a>
		&nbsp;-&nbsp;
		<a href="<?php echo getUrl('forumsTopics.php?forum_id=' . $forumsresponse->getFormField('forum_id'), 'forum/' . $forumsresponse->getFormField('forum_id') . '/'); ?>">
			<?php echo $forumsresponse->forum_details_arr['forum_title']; ?></a>
		&nbsp;-&nbsp;
		<a href="<?php echo getUrl('forumsResponses.php?forum_id=' . $forumsresponse->getFormField('forum_id') . '&topic_id=' . $forumsresponse->getFormField('topic_id'), 'forum/' . $forumsresponse->getFormField('forum_id') . '/' . $forumsresponse->getFormField('topic_id') . '/'); ?>">
			<?php echo wordWrapManual($forumsresponse->forum_topic_details_arr['forum_topic'], 35); ?></a>
		&nbsp;-&nbsp;
		<?php echo $LANG['forumsresponse_post_response']; ?>
	</span></h2>
<?php
if ($forumsresponse->isShowPageBlock('msg_form_error'))
{
?>
<div id="selMsgError">
	 <p><?php echo $LANG['msg_error_sorry'] . ' ' . $forumsresponse->getCommonErrorMsg(); ?></p>
</div>
<?php
}
if ($forumsresponse->isShowPageBlock('msg_form_success'))
{
?>
<div id="selMsgSuccess">
 	<p><?php echo $LANG['forumsresponse_success']; ?></p>
</div>
<?php
}
if ($forumsresponse->isShowPageBlock('form_create_response'))
{
?>
<div id="selShowCreateForum">
<div id="selGroupForumPost">
	<h3 id="selBackToForum">
		<a href="<?php echo getUrl('forumsResponses.php?forum_id=' . $forumsresponse->getFormField('forum_id') . '&topic_id=' . $forumsresponse->getFormField('topic_id'), 'forum/' . $forumsresponse->getFormField('forum_id') . '/' . $forumsresponse->getFormField('topic_id') . '/'); ?>">
			<?php echo $LANG['forumlistall_back_responses']; ?>
		</a>
	</h3>
</div>
	<form name="selFormCreateForum" id="selFormCreateForum" method="post" action="<?php echo $_SERVER['REQUEST_URI']; ?>" autocomplete="off" onsubmit="return getHTMLSource('rte1', 'selFormCreateForum', 'forum_response');">
		<table summary="<?php echo $LANG['forumsresponse_tbl_summary']; ?>" class="clsRichTextTable">
			<?php if (strchr(strtolower($_SERVER['HTTP_USER_AGENT']), "opera") == '')
		{ ?>
			<tr>
				<td class="<?php echo $forumsresponse->getCSSFormFieldCellClass('forum_response'); ?>">
					<p><?php ShowHelpTip('forum_topic_response'); ?><label for="response"><?php echo $LANG['forumsresponse_response']; ?></label></p></td></tr>
			<tr>	<td>	<p>
						<?php echo $forumsresponse->getFormFieldErrorTip('forum_response'); ?>
						<?php populateRichTextEdit('forum_response', $forumsresponse->getFormField('forum_response'), $forumsresponse->isValidFormInputs()); ?>
					</p>
				</td>
		    </tr>
			<?php }
		else
		{ ?>
			<tr>
				<td class="<?php echo $forumsresponse->getCSSFormFieldCellClass('forum_response'); ?>">
					<p><label for="response"><?php echo $LANG['forumsresponse_response']; ?></label><?php ShowHelpTip('forum_topic_response'); ?></p></td></tr>
				<td>	<p>
						<?php echo $forumsresponse->getFormFieldErrorTip('forum_response'); ?>
						<textarea class="clsCommonTextArea" name="forum_response" id="forum_response" cols="100" rows="7"><?php echo $forumsresponse->getFormField('forum_response'); ?></textarea>
					</p>
				</td>
		    </tr>
			<?php } ?>
		    <?php if ($forumsresponse->getFormField('forum_response')) $LANG['forumsresponse_submit'] = 'Update'; ?>
			<tr>
				<td class="<?php echo $forumsresponse->getCSSFormFieldCellClass('submit'); ?>">
					<input type="submit" class="clsSubmitButton" name="forumsresponse_submit" id="forumsresponse_submit" tabindex="<?php echo $forumsresponse->getTabIndex(); ?>" value="<?php echo $LANG['forumsresponse_submit']; ?>" />
					&nbsp;&nbsp;
					<input type="submit" class="clsCancelButton" name="forumsresponse_cancel" id="forumsresponse_cancel" tabindex="<?php echo $forumsresponse->getTabIndex(); ?>" value="<?php echo $LANG['forumsresponse_cancel']; ?>" />
				</td>
			</tr>
		</table>
		<input type="hidden" name="forum_id" id="forum_id" value="<?php echo $forumsresponse->getFormField('forum_id'); ?>" />
		<input type="hidden" name="topic_id" id="topic_id" value="<?php echo $forumsresponse->getFormField('topic_id'); ?>" />
		<input type="hidden" name="response_id" id="response_id" value="<?php echo $forumsresponse->getFormField('response_id'); ?>" />
	</form>
</div>
<?php
}
?>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>
