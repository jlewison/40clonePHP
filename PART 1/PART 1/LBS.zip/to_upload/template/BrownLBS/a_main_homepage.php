<?php include('template/BrownLBS/top_side.php');?>

<!--
###################################################################################
#######################                                     #######################
#######################   M A I N   S E C T I O N   Start   #######################
#######################                                     #######################
###################################################################################
--> 

<?php if($htL == 'Y') { ?> 

<!-- HOME PAGE TOP LINKS - START -->
    



<h1><?php echo("$lang_9");?> <?php echo("$lnbhome");?> <?php echo("$lang_10");?></h1>

<div class="content">

<div id="stop">
<a href="<?php echo("$path");?>linkstopxml.php" target="_blank"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/xml.gif" alt="RSS Feed" border="0" /></a>
 <?php echo("$lang_3");?> <?php echo("$lnbhome");?> <?php echo("$lang_4");?>
</div>
<br />
<?php $currentPage = $_SERVER["PHP_SELF"];?>

<?php do { ?>

<div class="listing">
	<img class="listingPrev" src="http://open.thumbshots.org/image.aspx?url=<?php echo $row_lista['site']; ?>" alt="<?php echo $row_top_BID['title']; ?>" height="68" width="84" />
	<?php $wsn = $row_lista['title']; 
    
		$step8 = str_replace(" ", "-", $wsn);
		$wsseoname = "$step8"; ?>
		
            <h3><a href="<?php echo $row_lista['site']; ?>" target="_blank"><?php echo $row_lista['title']; ?></a></h3>

            <?php echo $row_lista['descr1']; ?>

<div class="listingD">          
<!--
<?php echo $row_lista['site']; ?> :: <?php echo("$lang_5");?> <?php echo $row_lista['stad']; ?> :: <?php if($fremode == 'N') { ?> <?php echo $row_lista['bid']; ?> <?php //echo("$lang_6");?> <?php } else { } ?> 
-->

<span>Current Contribution</span> <span style="font-weight:bold;font-size:12px;">$<?php echo $row_lista['bid']; ?></span>

<!--
<?php
$htf_category = $row_lista['maincategory'];
$query_LdetCAT = "SELECT * FROM categorylisting WHERE catlistid = '$htf_category'";
$LdetCAT = mysql_query($query_LdetCAT, $apound) or die(mysql_error());
$row_LdetCAT = mysql_fetch_assoc($LdetCAT);
$totalRows_LdetCAT = mysql_num_rows($LdetCAT);
?>
<a href="<?php echo("$path");?><?php echo $row_LdetCAT['categseoname']; ?>/"><?php echo $row_LdetCAT['categoryname'] ?></a>

<a href="<?php echo("$path");?><?php echo $row_lista['dtu'];?>/<?php echo("$wsseoname"); ?>.html"><?php echo("$lang_7");?></a>
-->

<?php if($fremode == 'N') { ?> &nbsp;&nbsp;<a href="<?php echo("$path");?>upgrade.php?ucat=<?php echo $row_lista['dtu']; ?>"><?php echo("$lang_8");?></a> <img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/increaseBid.gif" alt="increase Bid" /><?php } else { } ?>

</div>              
<div class="linkStats">
          <?php if($prenabled == 'Y' and $enb_home == 'Y') { ?>

	<?php include('pr_update_home.php');?>
	
<div>
<a target="_blank" rel="nofollow" href="http://digg.com/submit?phase=2&url=<?php echo $row_lista['site']; ?>&title=Air Tickets&bodytext= "><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/diggIcon.gif" alt="Digg It!" border="0px" /></a> 
<a target="_blank" rel="nofollow" href="http://www.google.com/bookmarks/mark?op=edit&bkmk=<?php echo $row_lista['site']; ?>&title=Air Tickets"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/googleIcon.gif" alt="Google Bookmarks" border="0px" /></a> 
<a target="_blank" rel="nofollow" href="http://co.mments.com/track?url=<?php echo $row_lista['site']; ?>&title=Air Tickets"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/commentsIcon.gif" alt="co.mments" border="0px" /></a>                
<a target="_blank" rel="nofollow" href="http://ma.gnolia.com/bookmarklet/add?url=<?php echo $row_lista['site']; ?>&title=Air Tickets"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/magnoliaIcon.gif" alt="Ma.gnolia.com" border="0px" /></a>                
<a target="_blank" rel="nofollow" href="http://www.spurl.net/spurl.php?url=<?php echo $row_lista['site']; ?>&title=Air Tickets"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/spurlIcon.gif" alt="Spurl.net" border="0px" /></a>                
<a target="_blank" rel="nofollow" href="http://technorati.com/cosmos/search.html?url=<?php echo $row_lista['site']; ?>"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/technoratiIcon.gif" alt="Technorati" border="0px" /></a> 
<a target="_blank" rel="nofollow" href="http://reddit.com/submit?url=<?php echo $row_lista['site']; ?>&title=Air Tickets"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/redditIcon.gif" alt="reddit" border="0px" /></a> 
<a target="_blank" rel="nofollow" href="http://www.stumbleupon.com/submit?url=<?php echo $row_lista['site']; ?>&title=Air Tickets"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/stumbleuponIcon.gif" alt="StumbleUpon" border="0px" /></a> 
<a target="_blank" rel="nofollow" href="http://www.furl.net/storeIt.jsp?u=<?php echo $row_lista['site']; ?>&t=Air Tickets"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/furlIcon.gif" alt="Furl" border="0px" /></a> 
<a target="_blank" rel="nofollow" href="http://del.icio.us/post?url=<?php echo $row_lista['site']; ?>&title=Air Tickets&notes= "><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/deliciousIcon.gif" alt="Del.icio.us" border="0px" /></a>
<a target="_blank" rel="nofollow" href="http://www.netscape.com/submit/?U=<?php echo $row_lista['site']; ?>&T=Air Tickets"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/netscapeIcon.gif" alt="Netscape" border="0px" /></a> 
<a target="_blank" rel="nofollow" href="http://myweb2.search.yahoo.com/myresults/bookmarklet?u=<?php echo $row_lista['site']; ?>&t=Air Tickets"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/yahooIcon.gif" alt="Yahoo! Bookmarklet" border="0px" /></a>
</div>

<div class="line"></div>

<?php } else {} ?>
</div>

</div>

<?php } while ($row_lista = mysql_fetch_assoc($lista)); ?>

<!-- HOME PAGE TOP LINKS - END -->

<?php }
else { }
?>
</div>
<!--
###################################################################################
#######################                                     #######################
#######################    M A I N   S E C T I O N   End    #######################
#######################                                     #######################
###################################################################################
-->

<?php include('template/BrownLBS/bottom_side.php');?>
<?php include('template/BrownLBS/footer.php'); ?>