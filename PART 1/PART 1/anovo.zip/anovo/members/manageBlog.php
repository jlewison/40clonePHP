<?php
require_once ('../common/config.inc.php');
$CFG['lang']['include_files'][] = 'members/includes/languages/%s/manageBlog.php';
$CFG['html']['header'] = 'members/includes/languages/%s/html_header.php';
$CFG['html']['footer'] = 'members/includes/languages/%s/html_footer.php';
$CFG['lang']['include_files'][] = 'common/languages/%s/help.inc.php';
$CFG['lang']['include_files'][] = 'common/configs/config_article.inc.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['mods']['include_files'][] = 'common/classes/class_ListRecordsHandler.lib.php';
require ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class manageBlog extends ListRecordsHandler
{
		public function buildSortQuery()
		{
				$this->sql_sort = $this->fields_arr['orderby_field'] . ' ' . $this->fields_arr['orderby'];
		}
		public function buildConditionQuery()
		{
				$this->sql_condition = 'user_id=\'' . $this->CFG['user']['user_id'] . '\'';
		}
		public function updateBlog()
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['blogs'] . ' SET subject=' . $this->dbObj->Param('subject_new') . ', message=' . $this->dbObj->Param('message') . ', blog_category_id=' . $this->dbObj->Param('blog_category_id') . ', accept_comments=' . $this->dbObj->Param('accept_comments') . ' WHERE blog_id=' . $this->dbObj->Param('blog_id') . ' AND user_id=' . $this->dbObj->Param('user_id');
				$param_arr = array($this->fields_arr['subject_new'], $this->fields_arr['message'], $this->fields_arr['blog_category_id'], $this->fields_arr['accept_comments'], $this->fields_arr['blog_id'], $this->CFG['user']['user_id']);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, $param_arr);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function insertBlog()
		{
				$sql = 'INSERT ' . $this->CFG['db']['tbl']['blogs'] . ' SET subject=' . $this->dbObj->Param('subject_new') . ', message=' . $this->dbObj->Param('message') . ', blog_category_id=' . $this->dbObj->Param('blog_category_id') . ', accept_comments=' . $this->dbObj->Param('accept_comments') . ', user_id=' . $this->dbObj->Param('user_id') . ', date_added=NOW(), status=\'Active\'';
				$param_arr = array($this->fields_arr['subject_new'], $this->fields_arr['message'], $this->fields_arr['blog_category_id'], $this->fields_arr['accept_comments'], $this->CFG['user']['user_id']);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, $param_arr);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function populateBlogsValue()
		{
				$sql = 'SELECT blog_id, subject, message, accept_comments, user_id, blog_category_id, status, date_added' . ' FROM ' . $this->CFG['db']['tbl']['blogs'] . ' WHERE blog_id=' . $this->dbObj->Param('blog_id') . ' AND user_id=' . $this->dbObj->Param('user_id');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['blog_id'], $this->CFG['user']['user_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($row = $rs->FetchRow())
				{
						$this->fields_arr['subject_new'] = $row['subject'];
						$this->fields_arr['message'] = $row['message'];
						$this->fields_arr['blog_category_id'] = $row['blog_category_id'];
						$this->fields_arr['accept_comments'] = $row['accept_comments'];
						return true;
				}
				return false;
		}
		public function showBlogsList()
		{
				while ($row = $this->fetchResultRecord())
				{
						$anchor = 'anchor_' . $row['blog_id'];
?>
				<tr>
					<td><input type="checkbox" class="clsCheckRadio" name="blog_id[]" onclick="disableHeading('blogsListForm');" value="<?php echo $row['blog_id']; ?>" tabindex="<?php echo $this->getTabIndex(); ?>" /></td>
					<td><a href="<?php echo getUrl('blogComment.php', 'blogcomment/'); ?>?blog_id=<?php echo $row['blog_id']; ?>"><?php echo stripString($row['subject'], 35); ?></a></td>
					<td><?php echo $row['total_comments']; ?></td>
					<td><?php echo $row['total_views']; ?></td>
					<td><?php echo $row['accept_comments']; ?></td>
					<td><?php echo $row['date_added']; ?></td>
					<td>
						<a id="<?php echo $anchor; ?>" href="<?php getUrl('manageBlog.php', 'manageblog/'); ?>?act=edt&amp;blog_id=<?php echo $row['blog_id']; ?>&amp;start=<?php echo $this->fields_arr['start']; ?>"><?php echo $this->LANG['edit']; ?></a>
					</td>
				</tr>
<?php
				}
		}
		public function deleteSelectedBlogs()
		{
				$blog_ids = addslashes($this->fields_arr['blog_id']);
				$blog_ids = explode(',', $blog_ids);
				$blog_ids = '\'' . implode('\',\'', $blog_ids) . '\'';
				$sql = 'DELETE FROM ' . $this->CFG['db']['tbl']['blogs'] . ' WHERE blog_id IN(' . $blog_ids . ')';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$sql = 'DELETE FROM ' . $this->CFG['db']['tbl']['blog_comment'] . ' WHERE blog_id IN(' . $blog_ids . ')';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function resetFieldsArray()
		{
				$this->setFormField('subject_new', '');
				$this->setFormField('message', '');
				$this->setFormField('accept_comments', 'Yes');
				$this->setFormField('blog_category_id', '');
				$this->setFormField('act', '');
				$this->setFormField('blog_id', '');
		}
		public function doDefaultValidation()
		{
				$this->chkIsNotEmpty('subject_new', $this->LANG['err_tip_compulsory']);
				$this->chkIsNotEmpty('message', $this->LANG['err_tip_compulsory']);
				$this->chkIsNotEmpty('blog_category_id', $this->LANG['err_tip_compulsory']);
		}
		public function populateBlogCatagory($err_tip = '')
		{
				$sql = 'SELECT blog_category_id, blog_category_name FROM ' . $this->CFG['db']['tbl']['blog_category'] . ' WHERE blog_category_status=\'Yes\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if (!$rs->PO_RecordCount()) return;
				$names = array('blog_category_name');
				$value = 'blog_category_id';
				$highlight_value = $this->fields_arr['blog_category_id'];
?>
				<ul>
<?php
				$inc = 1;
				while ($row = $rs->FetchRow())
				{
						$out = '';
						$selected = $highlight_value == $row[$value] ? ' checked' : '';
?>
						<li>
							<input type="radio" class="clsCheckRadio" name="blog_category_id" id="blog_category_id<?php echo $row[$value]; ?>" tabindex="<?php echo $this->getTabIndex(); ?>" value="<?php echo $row[$value]; ?>"<?php echo $selected; ?> />
<?php
						foreach ($names as $name) $out .= $row[$name] . ' ';
?>
						<label for="blog_category_id<?php echo $row[$value]; ?>"><?php echo $out; ?></label>
						</li>

<?php
						$inc++;
				}
?>
				</ul>
				<p class="clsSelectNote"><?php echo $this->LANG['select_a_category']; ?></p>
<?php
		}
		public function populateCategories($highlight_category)
		{
				$sql = 'SELECT blog_category_id, blog_category_name FROM ' . $this->CFG['db']['tbl']['blog_category'] . ' WHERE blog_category_status=\'Yes\' ORDER BY blog_category_name';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount())
				{
						while ($row = $rs->FetchRow())
						{
?>
<option value="<?php echo $row['blog_category_id']; ?>" <?php echo ($row['blog_category_id'] == $highlight_category) ? 'selected' : ''; ?>><?php echo $row['blog_category_name']; ?></option>
<?php
						}
				}
		}
}
$manageBlog = new manageBlog();
$manageBlog->setDBObject($db);
$manageBlog->makeGlobalize($CFG, $LANG);
if (!chkAllowedModule(array('blog'))) Redirect2URL($CFG['redirect']['dsabled_module_url']);
$manageBlog->setPageBlockNames(array('msg_form_success', 'msg_form_error', 'blogsEditor', 'blogsEditBlock', 'selBlogsListBlock'));
$manageBlog->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$manageBlog->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$manageBlog->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$manageBlog->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$manageBlog->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$manageBlog->setFormField('orderby_field', 'blog_id');
$manageBlog->setFormField('orderby', 'DESC');
$manageBlog->setFormField('start', '0');
$manageBlog->setFormField('numpg', $CFG['data_tbl']['numpg']);
$manageBlog->setCSSColumnHeaderCellAscSortClasses(array('clsColumnHeaderCellAscSort1', 'clsColumnHeaderCellAscSort2', 'clsColumnHeaderCellAscSort3', 'clsColumnHeaderCellAscSort4', 'clsColumnHeaderCellAscSort5'));
$manageBlog->setCSSColumnHeaderCellDefaultClass('clsColumnHeaderCellDefault');
$manageBlog->setCSSColumnHeaderCellDescSortClasses(array('clsColumnHeaderCellDscSort1', 'clsColumnHeaderCellDscSort2', 'clsColumnHeaderCellDscSort3', 'clsColumnHeaderCellDscSort4', 'clsColumnHeaderCellDscSort5'));
$manageBlog->setMinRecordSelectLimit(2);
$manageBlog->setMaxRecordSelectLimit($CFG['data_tbl']['max_record_select_limit']);
$manageBlog->setNumPerPageListArr($CFG['data_tbl']['numperpage_list_arr']);
$manageBlog->setTableNames(array($CFG['db']['tbl']['blogs']));
$manageBlog->setReturnColumns(array('blog_id', 'subject', 'message', 'accept_comments', 'total_comments', 'total_views', 'user_id', 'status', 'date_added'));
$manageBlog->resetFieldsArray();
$manageBlog->setAllPageBlocksHide();
$manageBlog->setPageBlockShow('blogsEditor');
$manageBlog->setPageBlockShow('selBlogsListBlock');
$manageBlog->sanitizeFormInputs($_REQUEST);
if (!$manageBlog->isAllowedToAsk())
{
		$manageBlog->setAllPageBlocksHide();
		$manageBlog->setPageBlockShow('msg_form_error');
		$manageBlog->setCommonErrorMsg($LANG['info_not_allowed_to_post']);
}
else
		if ($manageBlog->isFormPOSTed($_POST, 'add_submit'))
		{
				$manageBlog->doDefaultValidation();
				if ($manageBlog->isValidFormInputs())
				{
						$manageBlog->setFormField('message', html_entity_decode($manageBlog->getFormField('message'), ENT_QUOTES, $CFG['site']['charset']));
						$manageBlog->insertBlog();
						$manageBlog->setCommonErrorMsg($LANG['msg_success_added']);
						$manageBlog->setPageBlockShow('msg_form_success');
						Redirect2Url(getUrl($CFG['site']['relative_url'] . 'manageBlog.php?added', $CFG['site']['relative_url'] . 'manageblog/?added', false));
				}
				else
				{
						$manageBlog->setCommonErrorMsg($LANG['msg_sorry_error']);
						$manageBlog->setPageBlockShow('msg_form_error');
				}
		}
		else
				if ($manageBlog->isFormPOSTed($_POST, 'update_submit'))
				{
						$manageBlog->doDefaultValidation();
						if ($manageBlog->isValidFormInputs())
						{
								$manageBlog->setFormField('message', html_entity_decode($manageBlog->getFormField('message'), ENT_QUOTES, $CFG['site']['charset']));
								$manageBlog->updateBlog();
								$manageBlog->setCommonErrorMsg($LANG['msg_success_update']);
								$manageBlog->setPageBlockShow('msg_form_success');
								$manageBlog->resetFieldsArray();
								Redirect2Url(getUrl($CFG['site']['relative_url'] . 'manageBlog.php?update', $CFG['site']['relative_url'] . 'manageblog/?update', false));
						}
						else
						{
								$manageBlog->setCommonErrorMsg($LANG['msg_sorry_error']);
								$manageBlog->setPageBlockShow('msg_form_error');
								$manageBlog->setPageBlockShow('blogsEditBlock');
						}
				}
				else
						if ($manageBlog->isFormGETed($_GET, 'act'))
						{
								if ($manageBlog->getFormField('act') == 'edt')
								{
										if ($manageBlog->populateBlogsValue()) $manageBlog->setPageBlockShow('blogsEditBlock');
								}
						}
						else
								if ($manageBlog->isFormPOSTed($_POST, 'action_blog'))
								{
										if ($manageBlog->getFormField('act') == 'delete')
										{
												$manageBlog->deleteSelectedBlogs();
												$manageBlog->setCommonErrorMsg($LANG['success_deleted']);
										}
										$manageBlog->setPageBlockShow('msg_form_success');
										$manageBlog->resetFieldsArray();
								}
								else
										if ($manageBlog->isFormPOSTed($_POST, 'update_canecl'))
										{
												$manageBlog->resetFieldsArray();
										}
if ($manageBlog->isFormPOSTed($_GET, 'added'))
{
		$manageBlog->setCommonErrorMsg($LANG['msg_success_added']);
		$manageBlog->setPageBlockShow('msg_form_success');
}
if ($manageBlog->isFormPOSTed($_GET, 'update'))
{
		$manageBlog->setCommonErrorMsg($LANG['msg_success_update']);
		$manageBlog->setPageBlockShow('msg_form_success');
}



?>
<script language="javascript">
	var block_arr= new Array('selMsgConfirm');
</script>
<div id="selManageBlog">
	<div class="clsManageBlogHeading"><div class="clsBlogHeading"><h2><?php echo $LANG['page_title']; ?></h2></div>
	<div class="clsManageBlog"><span class=""><a href="<?php echo getUrl($CFG['site']['relative_url'] . 'blogs.php', $CFG['site']['relative_url'] . 'blog/', false); ?>"><?php echo $LANG['back_to_blog']; ?></a></span></div></div>
<?php
if ($manageBlog->isShowPageBlock('msg_form_error'))
{
?>
  	<div id="selMsgError">
   		<p><?php echo $manageBlog->getCommonErrorMsg(); ?></p>
  	</div>
<?php
}
if ($manageBlog->isShowPageBlock('msg_form_success'))
{
?>
	<div id="selMsgSuccess">
		<p><?php echo $manageBlog->getCommonErrorMsg(); ?></p>
	</div>
<?php
}
if ($manageBlog->isShowPageBlock('blogsEditor'))
{
?>
		<div id="selBlogsEditor">
<?php
		if ($CFG['admin']['blogs_editor'])
		{
?>
			<form name="frmBlogsEditor" action="<?php echo getUrl('manageBlog.php', 'manageblog/'); ?>" method="post" onSubmit="return getHTMLSource('rte1', 'frmBlogsEditor', 'message');" autocomplete="off">
<?php
		}
		else
		{
?>
			<form name="frmBlogsEditor" action="<?php echo getUrl('manageBlog.php', 'manageblog/'); ?>" method="post" autocomplete="off">
<?php
		}
?>
				<table summary="<?php echo $LANG['tbl_summary']; ?>" class="clsRichTextTable">
					<tr>
						<td class="<?php echo $manageBlog->getCSSFormLabelCellClass('subject'); ?>"><label for="subject"><?php echo $LANG['subject']; ?></label></td>
						<td class="<?php echo $manageBlog->getCSSFormFieldCellClass('subject'); ?>"><?php echo $manageBlog->getFormFieldErrorTip('subject'); ?>
							<input type="text" class="clsTextBox" name="subject_new" id="subject_new" tabindex="<?php echo $manageBlog->getTabIndex(); ?>" value="<?php echo $manageBlog->getFormField('subject_new'); ?>" />
						</td>
				   	</tr>
					<tr>
						<td class="<?php echo $manageBlog->getCSSFormFieldCellClass('message'); ?>" colspan="2"><?php echo $manageBlog->getFormFieldErrorTip('message'); ?>
<?php
		if ($CFG['admin']['blogs_editor'])
		{
				if (strchr(strtolower($_SERVER['HTTP_USER_AGENT']), "opera") == '')
				{
						populateRichTextEdit('message', $manageBlog->getFormField('message'), $manageBlog->isValidFormInputs());
				}
				else
				{

?>							<textarea class="clsCommonTextArea" name="message" id="message" tabindex="<?php echo $manageBlog->getTabIndex(); ?>" cols="50" rows="5"><?php echo $manageBlog->getFormField('message'); ?></textarea>
<?php
				}
		}
		else
		{
?>
							<textarea name="message" id="message" tabindex="<?php echo $manageBlog->getTabIndex(); ?>" cols="100" rows="15"><?php echo $manageBlog->getFormField('message'); ?></textarea>
							<p><?php echo $LANG['put_the_html_code']; ?></p>
<?php
		}
?>
						</td>
				   	</tr>
					<tr>
						<td class="<?php echo $manageBlog->getCSSFormLabelCellClass('accept_comments'); ?>"><label for="accept_comments"><?php echo $LANG['accept_comments']; ?></label></td>
						<td class="<?php echo $manageBlog->getCSSFormFieldCellClass('accept_comments'); ?>"><?php echo $manageBlog->getFormFieldErrorTip('accept_comments'); ?>
							<input type="radio" class="clsCheckRadio" name="accept_comments" id="accept_comments2" tabindex="<?php echo $manageBlog->getTabIndex(); ?>" value="Yes"<?php echo $manageBlog->isCheckedRadio('accept_comments', 'Yes'); ?> /><label for="accept_comments2"><?php echo $LANG['label_yes']; ?></label>&nbsp;
							<input type="radio" class="clsCheckRadio" name="accept_comments" id="accept_comments3" tabindex="<?php echo $manageBlog->getTabIndex(); ?>" value="No"<?php echo $manageBlog->isCheckedRadio('accept_comments', 'No'); ?> /><label for="accept_comments3"><?php echo $LANG['label_no']; ?></label>
						</td>
				   	</tr>
					<tr id="selCategoryBlock">
			         		<td class="<?php echo $manageBlog->getCSSFormLabelCellClass('blog_category_id'); ?>">
								<label for="blog_category_id"><?php echo $LANG['blogwriting_blog_category_id']; ?></label>&nbsp;*&nbsp;
							</td>
			          		<td class="<?php echo $manageBlog->getCSSFormFieldCellClass('blog_category_id'); ?>"><?php echo $manageBlog->getFormFieldErrorTip('blog_category_id'); ?>
								<div id="selGeneralCategory">
									<select name="blog_category_id" id="blog_category_id" tabindex="<?php echo $manageBlog->getTabIndex(); ?>"><option value=""><?php echo $LANG['chose_category']; ?></option><?php $manageBlog->populateCategories($manageBlog->getFormField('blog_category_id')); ?></select>
								</div>
							</td>
			        	</tr>

<?php
		if ($manageBlog->isShowPageBlock('blogsEditBlock'))
		{
				$manageBlog->populateHidden(array('start', 'blog_id'));
?>
					<tr>
						<td class="<?php echo $manageBlog->getCSSFormFieldCellClass('update_submit'); ?>" colspan="2">
							<input type="submit" class="clsSubmitButton" name="update_submit" id="update_submit" tabindex="<?php echo $manageBlog->getTabIndex(); ?>" value="<?php echo $LANG['update_submit']; ?>" />
							<input type="submit" class="clsCancelButton" name="update_canecl" id="update_canecl" tabindex="<?php echo $manageBlog->getTabIndex(); ?>" value="<?php echo $LANG['update_canecl']; ?>" />
						</td>
					</tr>
<?php
		}
		else
		{
?>
					<tr>
						<td class="<?php echo $manageBlog->getCSSFormFieldCellClass('add_submit'); ?>" colspan="2">
							<input type="submit" class="clsSubmitButton" name="add_submit" id="add_submit" tabindex="<?php echo $manageBlog->getTabIndex(); ?>" value="<?php echo $LANG['add_submit']; ?>" />
						</td>
					</tr>
<?php
		}
?>
				</table>
			</form>
		</div>
<?php
}
if ($manageBlog->isShowPageBlock('selBlogsListBlock'))
{
		$manageBlog->buildSelectQuery();
		$manageBlog->buildConditionQuery();
		$manageBlog->buildSortQuery();
		$manageBlog->buildQuery();
		$manageBlog->executeQuery();
		if ($manageBlog->isResultsFound())
		{
				$anchor = 'dAltMlti';
?>
			<div id="selMsgConfirm" class="clsMsgAlert" style="display:none;position:absolute;">
	    		<p id="confirmation_msg"></p>
		      	<form name="deleteForm" id="deleteForm" method="post" action="<?php echo getUrl('manageBlog.php', 'manageblog/'); ?>" autocomplete="off">
		        	<table summary="<?php echo $LANG['tbl_summary']; ?>">
					  	<tr>
			            	<td>
							  	<input type="submit" class="clsSubmitButton" name="action_blog" id="action_blog" value="<?php echo $LANG['yes']; ?>" tabindex="<?php echo $manageBlog->getTabIndex(); ?>" /> &nbsp;
				              	<input type="button" class="clsCancelButton" name="cancel" id="cancel" value="<?php echo $LANG['no']; ?>" tabindex="<?php echo $manageBlog->getTabIndex(); ?>"  onClick="return hideAllBlocks('blogsListForm');"/>
				              	<input type="hidden" name="blog_id" id="blog_id" />
								<input type="hidden" name="act" id="act" />
								<?php $manageBlog->populateHidden(array('start')); ?>
							</td>
			          	</tr>
		        	</table>
		      	</form>
		    </div>
			<form name="blogsListForm" id="blogsListForm" method="post" action="<?php echo getUrl('manageBlog.php', 'manageblog/'); ?>" autocomplete="off">
<?php
				$paging_arr = array();
				if ($CFG['admin']['navigation']['top']) $manageBlog->populatePageLinks($manageBlog->getFormField('start'), $paging_arr);
?>
				<table summary="<?php echo $LANG['tbl_summary']; ?>">
					<tr>
						<th><input type="checkbox" class="clsCheckRadio" name="check_all" onclick = "CheckAll(document.blogsListForm.name, document.blogsListForm.check_all.name)" tabindex="<?php echo $manageBlog->getTabIndex(); ?>" /></th>
						<th><?php echo $LANG['th_subject']; ?></th>
						<th><?php echo $LANG['th_total_comments']; ?></th>
						<th><?php echo $LANG['th_total_views']; ?></th>
						<th><?php echo $LANG['th_accept_comments']; ?></th>
						<th><?php echo $LANG['th_date_added']; ?></th>
						<th>&nbsp;</th>
					</tr>
			  		<?php $manageBlog->showBlogsList(); ?>
					<tr>
						<td class="<?php echo $manageBlog->getCSSFormFieldCellClass('add_delete'); ?>" colspan="9">
							<?php $manageBlog->populateHidden(array('start')); ?>
							<a href="#" id="<?php echo $anchor; ?>"></a>
							<input type="button" class="clsSubmitButton" name="delete_submit" id="delete_submit" tabindex="<?php echo $manageBlog->getTabIndex(); ?>" value="<?php echo $LANG['delete_submit']; ?>" onClick="if(getMultiCheckBoxValue('blogsListForm', 'check_all', '<?php echo $LANG['check_atleast_one']; ?>', '<?php echo $anchor; ?>', -200, -500)){Confirmation('<?php echo $anchor; ?>', 'selMsgConfirm', 'deleteForm', Array('blog_id', 'act', 'confirmation_msg'), Array(multiCheckValue, 'delete', '<?php echo nl2br($LANG['delete_confirmation']); ?>'), Array('value', 'value', 'innerHTML'), -200, -500, 'blogsListForm');}" />
						</td>
				   	</tr>
				</table>
<?php
				if ($CFG['admin']['navigation']['bottom']) $manageBlog->populatePageLinks($manageBlog->getFormField('start'), $paging_arr);
?>
			</form>
<?php
		}
		else
		{
?>
			<div id="selMsgAlert">
				<p><?php echo $LANG['no_records_found']; ?></p>
			</div>
<?php
		}
?>

<?php
}
?>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>
