<?php

class verifyMailHandler extends FormHandler
{
		public function chkIsValidCode($code)
		{
				$sql = 'SELECT user_id, name, usr_status, password, email FROM ' . $this->CFG['db']['tbl']['users'] . ' WHERE substring(md5(name), 1, 8) = ' . $this->dbObj->Param('field_name') . ' AND usr_status!=\'Deleted\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($code));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($row = $rs->FetchRow())
				{
						return $row['user_id'];
				}
				else
				{
						$this->setCommonErrorMsg($this->LANG['err_tip_invalid_link']);
						return false;
				}
		}
		public function chkIsNotDuplicateEmail($table_name, $field_name, $err_tip = '')
		{
				$sql = 'SELECT ' . $this->getUserTableField('user_id') . ' FROM ' . $table_name . ' WHERE ' . $this->getUserTableField('email') . ' =' . $this->dbObj->Param($field_name);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr[$field_name]));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$numrows = $rs->PO_RecordCount();
				$is_ok = ($numrows == 0);
				if (!$is_ok) $this->fields_err_tip_arr[$field_name] = $err_tip;
				return $is_ok;
		}
		private function _sendMail($to_email, $subject, $body, $sender_name, $sender_email)
		{
				$mail = new PHPMailer();
				$mail->AddAddress($to_email);
				$mail->FromName = $sender_name;
				$mail->From = $mail->Sender = $sender_email;
				$mail->Subject = $subject;
				$mail->Body = $body;
				$mail->IsMail();
				$mail->IsHTML(true);
				return ($mail->Send());
		}
		public function updateMail()
		{
				$mail = $this->fields_arr['new_mail'];
				$id = $this->fields_arr['user_id'];
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['users'] . ' SET ' . $this->getUserTableField('email') . '=\'' . $mail . '\' WHERE ' . $this->getUserTableField('user_id') . '=' . $id;
				$stmt = $this->dbObj->Prepare($sql);
				$result = $this->dbObj->Execute($stmt);
				if (!$result) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
}
$verifyfrm = new verifyMailHandler();
$verifyfrm->setDBObject($db);
$verifyfrm->makeGlobalize($CFG, $LANG);
$verifyfrm->setPageBlockNames(array('msg_form_error', 'msg_form_success', 'form_verifymail'));
$verifyfrm->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$verifyfrm->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$verifyfrm->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$verifyfrm->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$verifyfrm->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$verifyfrm->setFormField('code', '');
$verifyfrm->setFormField('mail_code', '');
$verifyfrm->setFormField('new_mail', '');
$verifyfrm->setFormField('user_id', '');
$verifyfrm->setAllPageBlocksHide();
$verifyfrm->setPageBlockShow('form_verifymail');
$verifyfrm->sanitizeFormInputs($_REQUEST);
$activated_account = false;
if ($verifyfrm->isFormPOSTed($_POST, 'new_mail'))
{
		$verifyfrm->sanitizeFormInputs($_POST);
		$verifyfrm->chkIsNotEmpty('new_mail', $LANG['err_tip_compulsory']) and $verifyfrm->chkIsValidEmail('new_mail', $LANG['err_tip_invalid_mail']) and ($verifyfrm->chkIsNotDuplicateEmail($CFG['db']['tbl']['users'], 'new_mail', $LANG['err_tip_already']) or $verifyfrm->setCommonErrorMsg($LANG['err_tip_already']));
		if ($verifyfrm->isValidFormInputs())
		{
				$newMail = substr(md5($verifyfrm->getFormField('new_mail')), 0, 8);
				$mailCode = $verifyfrm->getFormField('mail_code');
				if ($newMail == $mailCode)
				{
						$verifyfrm->updateMail();
						$verifyfrm->setFormField('new_mail', '');
						$verifyfrm->setAllPageBlocksHide();
						$verifyfrm->setPageBlockShow('msg_form_success');
				}
				else
				{
						$verifyfrm->setAllPageBlocksHide();
						$verifyfrm->setCommonErrorMsg($LANG['err_tip_invalid_mail']);
						$verifyfrm->setPageBlockShow('msg_form_error');
						$verifyfrm->setIndirectFormField('new_mail', '');
						$verifyfrm->setPageBlockShow('form_verifymail');
				}
		}
		else
		{
				$verifyfrm->setAllPageBlocksHide();
				$verifyfrm->setCommonErrorMsg($LANG['err_tip_invalid_mail']);
				$verifyfrm->setPageBlockShow('msg_form_error');
				$verifyfrm->setIndirectFormField('new_mail', '');
				$verifyfrm->setPageBlockShow('form_verifymail');
		}
} elseif ($verifyfrm->isFormGETed($_GET, 'code'))
{
		$code = substr($verifyfrm->getFormField('code'), 0, 8);
		$mailcode = substr($verifyfrm->getFormField('code'), 8, 8);
		$verifyfrm->setFormField('mail_code', $mailcode);
		if ($verifyfrm->chkIsValidCode($code) !== false)
		{
				$verifyfrm->setFormField('user_id', $verifyfrm->chkIsValidCode($code));
				$verifyfrm->setAllPageBlocksHide();
				$verifyfrm->setPageBlockShow('form_verifymail');
		}
		else
		{
				$verifyfrm->setAllPageBlocksHide();
				$verifyfrm->setPageBlockShow('msg_form_error');
		}
}



?>
<div id="selVerifyMail">
	<h2><span><?php echo $LANG['verifymail_title']; ?></span></h2>
<?php
if ($verifyfrm->isShowPageBlock('msg_form_error'))
{
?>
	<div id="selMsgError">
		 <p><?php echo $LANG['msg_error_sorry'] . ' ' . $verifyfrm->getCommonErrorMsg(); ?></p>
	</div>
<?php
}
if ($verifyfrm->isShowPageBlock('msg_form_success'))
{
?>
	<div id="selMsgSuccess">
		<p><?php echo $LANG['email_successfully']; ?></p>
	</div>
<?php
}
if ($verifyfrm->isShowPageBlock('form_verifymail'))
{
?>
	<form name="form_verifymail" id="selFormVerifyMail" method="post" action="<?php echo URL($_SERVER['REQUEST_URI']); ?>" autocomplete="off">
		<input type="hidden" name="mail_code" id="mail_code" value="<?php echo $verifyfrm->getFormField('mail_code'); ?>" />
		<input type="hidden" name="user_id" id="user_id" value="<?php echo $verifyfrm->getFormField('user_id'); ?>" />
		<table summary="<?php echo $LANG['verifymail_tbl_summary']; ?>" class="clsTwoColumnTbl">
			<tr>
				<td class="<?php echo $verifyfrm->getCSSFormLabelCellClass('new_mail'); ?>"><?php ShowHelpTip('new_mail'); ?><label for="new_mail"><?php echo $LANG['verifymail_new_mail']; ?></label></td>
				<td class="<?php echo $verifyfrm->getCSSFormFieldCellClass('new_mail'); ?>"><?php echo $verifyfrm->getFormFieldErrorTip('new_mail'); ?><input type="text" class="clsTextBox" name="new_mail" id="new_mail" tabindex="1" value="<?php echo $verifyfrm->getFormField('new_mail'); ?>" /></td>
		    </tr>
		    <tr>
				<td class="<?php echo $verifyfrm->getCSSFormFieldCellClass('submit'); ?>" colspan="2"><input type="submit" class="clsSubmitButton" name="verifymail" id="verifymail" tabindex="2" value="<?php echo $LANG['verifymail_submit']; ?>" /></td>
			</tr>
		</table>
	</form>
<?php
}
?>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>
