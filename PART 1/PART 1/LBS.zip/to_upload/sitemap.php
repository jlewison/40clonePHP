<?php include('ip_domain_ban.php'); include('settings.php');
$currentPage = $_SERVER["PHP_SELF"];
require_once('Connections/apound.php');
$maxRows_TLlista = "9999";
$pageNum_TLlista = 0;
if (isset($_GET['pageNum_TLlista'])) {
  $pageNum_TLlista = $_GET['pageNum_TLlista'];
}
$startRow_TLlista = $pageNum_TLlista * $maxRows_TLlista;
mysql_select_db($database_apound, $apound);
if($lexv == 'LIMITED') {
$query_TLlista = "SELECT * FROM main WHERE main.avail = 'Y' AND main.paid = 'Y' AND TO_DAYS(NOW()) < TO_DAYS(stod) ORDER BY main.$TL_ordby_F $TL_ordby_O";
}
else {
$query_TLlista = "SELECT * FROM main WHERE main.avail = 'Y' AND main.paid = 'Y' ORDER BY main.$TL_ordby_F $TL_ordby_O";
}
$query_limit_TLlista = sprintf("%s LIMIT %d, %d", $query_TLlista, $startRow_TLlista, $maxRows_TLlista);
$TLlista = mysql_query($query_limit_TLlista, $apound) or die(mysql_error());
$row_TLlista = mysql_fetch_assoc($TLlista);
if (isset($_GET['totalRows_TLlista'])) {
  $totalRows_TLlista = $_GET['totalRows_TLlista'];
} else {
  $all_TLlista = mysql_query($query_TLlista);
  $totalRows_TLlista = mysql_num_rows($all_TLlista);
}
$totalPages_TLlista = ceil($totalRows_TLlista/$maxRows_TLlista)-1;
$queryString_TLlista = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_TLlista") == false && 
        stristr($param, "totalRows_TLlista") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_TLlista = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_TLlista = sprintf("&totalRows_TLlista=%d%s", $totalRows_TLlista, $queryString_TLlista);
$srf = "/"; ?>
<?php print'<?xml version="1.0" encoding="UTF-8"?>'; ?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
   <url>
      <loc>http://<?php echo("$domainname$path");?></loc>
   </url>
<?php do {
$wsn = $row_TLlista['title']; $step8 = str_replace(" ", "-", $wsn); $wsseoname = "$step8";
$LDcategory = $row_TLlista['maincategory'];
mysql_select_db($database_apound, $apound);
$query_LdetCAT = "SELECT * FROM categorylisting WHERE catlistid = '$LDcategory'";
$LdetCAT = mysql_query($query_LdetCAT, $apound) or die(mysql_error());
$row_LdetCAT = mysql_fetch_assoc($LdetCAT);
$totalRows_LdetCAT = mysql_num_rows($LdetCAT);?>
   <url>
      <loc>http://<?php echo("$domainname$path");?><?php echo $row_TLlista['dtu'];?>/<?php echo("$wsseoname"); ?>.html</loc>
   </url>
<?php } while ($row_TLlista = mysql_fetch_assoc($TLlista)); ?>
</urlset>