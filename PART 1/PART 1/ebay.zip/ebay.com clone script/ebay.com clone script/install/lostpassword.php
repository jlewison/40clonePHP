<?php //00461
// Copyright Notice
// Web Site URL:  http://www.zeeways.com
// Script Owner eMail: mail@zeeways.com
// Date: April, 2007
// Script Name: Zeeways Auction Website PHP Script
// Copyright Details: This script is not free.  Do not Remove this Copy Right notice.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the site administrator.');exit(199);
?>
4+oV53jpwwzRsE+0DiP+Z8jC1xvircJ3ll10Q+OZUzCmGPHWOghWi9x35rE+fhItWVsX/3hAjJkS
Qj99oWe5Ev7iEtIRSMY/imvjme1MkmzVJS1SNH1GV0s5WVvxg8wRq0ewUCNOmquVfB6g70IimLy9
lozV9FYHThyGAniCc4mI5AT6ldblf+T8MZ1WBRZMGNo7+tLfWasJOEWRKAHibpy2ovP4Gn4WAfxA
XjyIzt5I6gFzn5If1dprMH+MfZGCJ7FtBQv9VhQQS163O634VNd/xAZRBW/1dCcV01+IaEBlXNQx
+nuBsOkvTL5riOxgtVjwxvQpKb9IyB69H9gzsLE1nhs8pt/BKxZ5ByAnVaxYIydQh1YTg4IXmvmi
z9wnowy/FIoRm3cZRNP8OmOuWxF133zWVntapjV8RuL0s2mH/urSlaPJBt01X8kLnqd+V3ixfOvN
0GDWkE9nLR6oXY2LiCbAKqjwOEMsI7idczwVnbj2WJqqMNXnIBLgNyicVcgy1SrO66sUnMezVVsD
lRhZg2rS69kArH9FHVIuU8iYA7odsaBNji+Q/UEDhptGJBeH7a9QcqTwAJGDeL8BsSn5i3ylwvR+
3GTb6GIC0YUns4sPI7W6/darXXeIlvEZVKGG6/ynCTyqT4R3eyJiSgamjEA8AyZN1EkZ3lTDe/2m
wR0NJ+eaMMthzleeEhLSywzyr7yTTuL9L8A79iDsm9HFzCztNuHmlV9cSafHAXfHrrvWQjBoZ6Qk
1+UNKsVtVFGtvkVryQ8EWuFbLSY7wHGgKSrmgZBECAMJOjJbYMMSS0JIV+zUhGaKWMDr3v2ZC0NQ
6IDw3DNJjzBLmIXpXciW3ZY3rXLOGyqKye7iZsOQIqSQRYjR7fAuQWicz3FHlzIqQO/sNTNHcoD/
Y7g9gNQ0ASRJTkdU04UCX8cDSyrjvi26SV4M8wmv+M9uho5r7rnO8nJ3HiIjQMSeyGIyGtrA1rfw
/yxAcJ9hxxi/nSMhFwKCtX6R/ga1Fskvivt7fzaX9h0R02f3wVLxQRDQwhWtH4Qz7MzAGdeQnr08
qVw49bVNjBTaEmwnTrNPp37yePHXgy+Fy8KPvcn/Ng2m1y0vNNuw6QFci7ZPpDeJB/A/US2GeXyp
1er+nK7F3FDubIcGTr69HYFvQXPIYugj4joF2T1DgydTX8ltlYUs1N1GbAlfnZqtJYAipF84Hupa
VrCu1NN89EI/hc1+8FO53i6d78KJpka+v+FackUDIblgiRPp/WqRrdcr6ty+4EDvfpgkYeFpf/sP
CTAAljG65spfEgSZ7FgncFOGVKUgiJOPFvgg0nYzVaRRYvgmNu4PrzLBoWnTV0maiQ6pNfzMGcuW
MD8SjQDVbAl5figOnTzQXb64wy0cBvvYsgKLJTky4zBIKQyT/+pSeypRVIjstLormCppJrU+B8jw
np+jMi+cJem3VzUYp2fN75yZ9jZ4Y9d2q6kn7JSfzWnp9uycfbCC7Q/UTa47KKdiKoHUqRnlMfL2
9MaNnEvtq5eAodtKO+2fVAc1GGkWlMYYq+qBo5E5QijvMuq1usjd6kpihUPUmnYXcEHnGOQ4N/q6
eZv34wmz+9TpsArBgESbIYC5Lt4lQ179rvbkRN7OSo+Qzzi/SicRqYfcq2FOBWSe/VQJ6X/J3qFY
IuFg3btTzLibWqpiLhZAIHik/QOgCYBPN6mJS04LrrVCvzShYsJswsErY9a2H+jXZpS3Xao+zdq0
PggAZ7rI53/abuv06A2/kB7QAAVvsyDhQ1lPYkKg62bg8raB9z1Py3sql3T3r0==