<?php
require_once ('../common/config.inc.php');
require_once ('../common/configs/config_encoder.inc.php');
require_once ('../common/configs/config_ans_audio.inc.php');
$CFG['lang']['include_files'][] = 'members/includes/languages/%s/videoUpload.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['mods']['is_include_only']['non_html_header_files'] = true;
$CFG['is']['ajax_page'] = true;
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
set_time_limit(0);
class AudioUpload extends FormHandler
{
		public function chkIsValidCaptureFile()
		{
				$file_name = $this->CFG['admin']['video']['red5_flv_path'] . $this->fields_arr['rid'] . '.mp3';
				if (1 or is_file($file_name)) return true;
				return false;
		}
		public function resetFieldsArray()
		{
				$this->setFormField('rid', '');
		}
}
$AudioUpload = new AudioUpload();
$AudioUpload->setDBObject($db);
$AudioUpload->makeGlobalize($CFG, $LANG);
$AudioUpload->setPageBlockNames(array('msg_form_error', 'msg_form_success', 'audio_upload_form_capture'));
$AudioUpload->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$AudioUpload->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$AudioUpload->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$AudioUpload->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$AudioUpload->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$AudioUpload->resetFieldsArray();
$AudioUpload->setAllPageBlocksHide();
$AudioUpload->setPageBlockShow('audio_upload_form_capture');
$AudioUpload->sanitizeFormInputs($_REQUEST);
if ($AudioUpload->isFormGETed($_GET, 'upload'))
{
		if ($AudioUpload->chkIsValidCaptureFile())
		{
				$AudioUpload->setAllPageBlocksHide();
				$AudioUpload->setCommonSuccessMsg($LANG['success_uploaded']);
				$AudioUpload->setPageBlockShow('msg_form_success');
		}
		else
		{
				$AudioUpload->setCommonSuccessMsg($LANG['error_uploaded']);
				$AudioUpload->setPageBlockShow('msg_form_error');
		}
}



?>
<div id="selAudioUpload" class="">
	<p class="clsPopupClose"><a href="#" onClick="return closLightWindow()"><?php echo $LANG['close']; ?></a></p>
	<div id="selLeftNavigation">
<?php
if ($AudioUpload->isShowPageBlock('msg_form_error'))
{
?>
		  <div id="selMsgError">
		    <p><?php echo $AudioUpload->getCommonErrorMsg(); ?></p>
		  </div>
<?php
}
if ($AudioUpload->isShowPageBlock('msg_form_success'))
{
?>
		  <div id="selMsgSuccess">
		   	<p><?php echo $AudioUpload->getCommonSuccessMsg(); ?></p>
		  </div>
<?php
}
if ($AudioUpload->isShowPageBlock('audio_upload_form_capture'))
{
		$settingspath = $CFG['site']['url'] . 'quickCaptureConfigXmlCode.php?file_name=' . $AudioUpload->getFormField('rid');
		$skinpath = $CFG['site']['url'] . 'files/flash/audio_capture/skins/skin.xml';
		$quick_recorder_path = $CFG['site']['url'] . 'files/flash/audio_capture/VoiceRecorder.swf?filename=' . $AudioUpload->getFormField('rid') . '&settingspath=' . $settingspath . '&skinpath=' . $skinpath;
?>
		<div class="clsUploadSection">
			<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" width="400" height="340" id="QuickRecorder" align="middle">
				<param name="allowScriptAccess" value="sameDomain" />
				<param name="movie" value="<?php echo $quick_recorder_path; ?>" />
				<param name="quality" value="high" />
				<param name="wmode" value="<?php echo $CFG['admin']['wmode_value']; ?>" />
				<param name="bgcolor" value="#ffffff" />
				<embed src="<?php echo $quick_recorder_path; ?>" quality="high" bgcolor="#ffffff" width="400" height="340" name="QuickRecorder" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />
			</object>
		</div>
<?php
}
?>
	</div>
</div>
<?php


$AudioUpload->setHeaderEnd();
?>