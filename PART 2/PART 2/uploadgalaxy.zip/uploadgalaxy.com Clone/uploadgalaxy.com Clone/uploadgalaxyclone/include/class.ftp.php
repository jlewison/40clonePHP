<?
class ahm_FTP
{
private $server;
private $port=21;
private $timeout=90;
private $filename;
private $user;
private $password;
private $conn;

function ahm_FTP($server="",$port=0,$user="",$password="")
         {
           if($server!="")$this->server=$server;
           if($port!=0) $this->port=$port;
           if($user!="") $this->user=$user;
           if($password!="") $this->password=$password;
         }

function Connect($server="",$port=0)
         {
           if($server!="")$this->server=$server;
           if($port!=0) $this->port=$port;
           $this->conn=ftp_connect($this->server,$this->port,$this->timeout) or die("Connection Failed");
         }

function LogIn($user="",$password="")
         {
          if(!$this->conn) die("Connect First");
          if($user!="") $this->user=$user;
          if($password!="") $this->password=$password;
          if($this->user==""||$this->password=="") die("<h1 align=center><font  color=red>Error: Username/Password Not Supplied<h1>");
          $login_result = ftp_login($this->conn, $this->user, $this->password);
         }

function ChangeDir($dirpath)
         {
           return ftp_chdir($this->conn,$dirpath);
         }
 
function Receive($source,$dest)
         {
           if(!ftp_get($this->conn,$dest,$source,FTP_BINARY)) {echo "Error";};
         }

function Remove($filename)
         {
           if(!@ftp_delete($this->conn,$filename)) {return false;};
         }

function Send($dir,$udir,$filename,$newname="")
         {
           if($newname=="") $newname=$filename;
           @ftp_chdir($this->conn,$dir);
           @ftp_mkdir($this->conn,$udir);
           @ftp_chmod($this->conn,0777,$udir);
           @ftp_chdir($this->conn,$udir);
           if(ftp_put($this->conn,$newname,$filename,FTP_BINARY)) {return true;}
           //exit;
           return false;
         }
function Delete($dir="",$filename="")
         {
           if(!$this->conn) die("Connect First");
           if($dir==""&&$filename=="") die("No dir/file selected...");
           if($filename=="")
           ftp_rmdir($this->conn,$dir);
           else if($dir=="") ftp_delete($this->conn,$filename);
           else ftp_delete($this->conn,$dir."/".$filename);
         }

function LogOut()
         {
           ftp_close($this->conn);
         }
}
?>
