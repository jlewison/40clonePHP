<?
include("include/config.php");
if(isset($_COOKIE['error']))
STemplate::assign('error',$_COOKIE['error']);
setcookie('error','');
if($_COOKIE['uid'])
{
 header("location: welcome_premium.php");
 exit();
}
STemplate::display("premium.tpl");
?>
