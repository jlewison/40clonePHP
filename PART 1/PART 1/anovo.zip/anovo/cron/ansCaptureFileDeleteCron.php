<?php
require_once ('../common/config.inc.php');
require_once ('../common/configs/config_encoder.inc.php');
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['mods']['is_include_only']['non_html_header_files'] = true;
$CFG['auth']['is_authenticate'] = false;
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
set_time_limit(0);
class ManageDeleted extends FormHandler
{
		public function removeFiles($file)
		{
				if (is_file($file))
				{
						unlink($file);
						return true;
				}
				return false;
		}
		public function deleteNotUsedFiles()
		{
				$dir = '../test/removed_file/';
				if (!is_dir($dir))
				{
						echo 'Directory does not exist';
						return;
				}
				if ($handle = opendir($dir))
				{
						while (false !== ($file = readdir($handle)))
						{
								if ($file != "." && $file != "..")
								{
										echo "$file was last changed: " . date("F d Y H:i:s.", filectime($file)) . '<br>';
								}
						}
						closedir($handle);
				}
		}
}
$ManageDeleted = new ManageDeleted();
$ManageDeleted->setDBObject($db);
$ManageDeleted->makeGlobalize($CFG, $LANG);
$ManageDeleted->deleteNotUsedFiles();


?>