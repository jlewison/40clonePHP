<table cellpadding="0" cellspacing="0" border="0">
	<tr>
	
	</tr>
</table>

<table cellpadding="0" cellspacing="0" border="0" width="173">
	<tr>
		<td colspan="2" align="right" height="29" background="template/v3/i/box_support1.jpg" class="white" style="padding-right: 7px;"><b>24/7 CUSTOMER<br>SUPPORT</b></td>
	</tr>
	<tr>
		<td width="63"><img src="template/v3/i/box_support21.jpg" border="0"></td>
		<td rowspan="2" valign="top" background="template/v3/i/box_support22.jpg" class="white" style="padding: 3px 0px 0px 5px;">Canada Free:<br><b>1 (800) 761-1303</b><br><br>
			UK Free:<br><b>0 (808) 238-0020</b><br><br>
			International:<br><b>+ (800) 761-1303</b>
		</td>
	</tr>
	<tr>
		<td width="63"><img src="template/v3/i/box_support31.jpg" border="0"></td>
	</tr>
</table><table cellpadding="0" cellspacing="0" border="0">
	<tr>
		<td background="template/v3/i/instant_games.jpg" width="173" height="67" align="right" class="white2" valign="top"><div style="margin: 8px"><a href="system/login_procdemo.php"><b>INSTANT GAMES</b><br>NO DOWNLOAD</a></div><<img src="template/v3/i/b.gif" border="0" width="73" height="20" hspace="7"></a></td>
	</tr>
</table><table cellpadding="0" cellspacing="0" border="0" width="173">
	<tr>
		<td><img src="template/v3/i/box_games.jpg" border="0"></a></td>
	</tr>
</table><table cellpadding="0" cellspacing="0" border="0" width="173" class="bodytext12"><tr><td align="center"></td></tr></table>					</td>
				</tr>
				
