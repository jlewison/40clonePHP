<tr class="top5">
		<td>&nbsp;</td>
		<td class="menu_bottom" height="32"><a href="about_us.php" >About Us</a>&nbsp;|&nbsp;<a href="terms_and_conditions.php" >Terms and Conditions</a>&nbsp;|&nbsp;<a href="http://www.earnunited.com/" target="_blank">Casino Affiliate Program</a>		</td>
		<td>&nbsp;</td>
	</tr>	<tr class="top6">
	
	</tr>
	<tr>
		<td>&nbsp;</td>
		<td class="certified"><a href="http://www.kahnawake.com/gamingcommission/" target="_blank"><img src="template/v3/i/certified1.jpg" border="0" vspace="10"></a><img src="template/v3/i/certified2.jpg" border="0" vspace="10"><br>flash Casino - All Rights Reserved. Copyright &copy; 2008</td>
		<td>&nbsp;</td>
	</tr>
</table>
<br><br><br>
body>

</html>
