<?php
/**
 * Manage reports Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 02/01/2008
 */
class ManageReports extends controller
{
		function ManageReports()
		{
				parent::controller();
				//check login
				if ($this->session->userdata('admin_logged_in') != 1 && $this->session->userdata('admin_id') == '') redirect('admin/login');
				//Load the language file
				$this->lang->load('admin/manageReports', $this->config->item('language_code'));
				$this->load->model('reportmodel');
		}
		function index()
		{
				$outputData['reportTypes'] = array('group' => $this->lang->line('managereports_groups'), 'event' => $this->lang->line('managereports_event'), 'photo' => $this->lang->line('managereports_photo'), 'network' => $this->lang->line('managereports_network'), 'posted_item' => $this->lang->line('managereports_posted_item'), 'profile' => $this->lang->line('managereports_profile'));
				if (isset($_POST['searchReport'])) $outputData['report_for'] = $_POST['reportType'];
				else  $outputData['report_for'] = 'group';
				$outputData['reportsList'] = $this->reportmodel->getReportList($outputData['report_for']);
				//print_r($outputData['reportsList']); exit();
				$this->smartyextended->view('../admin/manageReports', $outputData);
		}
		#***************************************************************************
		#Method			: deleteReport
		#Description	: deletes report
		#Author			
		#***************************************************************************
		function deleteReport()
		{
				if ($this->uri->segment(4)) $report_id = $this->uri->segment(4);
				else
						if ($_POST['deleteReport'])
						{
								if (!empty($_POST['report_id'])) $report_id = implode(',', array_keys($_POST['report_id']));
						}
				$this->reportmodel->deleteReport($report_id);
				//Set the flash data
				$this->session->set_flashdata('successMsg', $this->lang->line('managereports_report_delete_success'));
				redirect('admin/manageReports');
		}
}
?>