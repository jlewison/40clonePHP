<?php
function smarty_function_getdates($params, &$smarty) {
	$params['dates'];
	$today = date('Y-m-d');
	$tomorrow = date('Y-m-d', strtotime('+1 day'));
	foreach ($params['dates'] as $date => $time) {
		
		echo "<option value=\"{$date}\" ";
		if ($date == $params['selected']) echo 'selected';
		echo '>';
		if ($date == $today) {
			echo date('\T\o\d\a\y, M j', $time);
		} else if ($date == $tomorrow) {
			echo date('\T\o\m\o\r\r\o\w, M j', $time);
		} else {
			echo date('l, M j', $time);
		}
		echo '</option>';
	}
}