<?
include("../include/config.php");
if(!isset($_COOKIE['admin_uid'])) header("location: admin_index.php");
$action=$_REQUEST['action'];
switch($action)
{
case "del":
$srvrid=$_REQUEST['srvrid'];
$qry="delete from server where id=$srvrid";
$conn->execute($qry);
break;
case "Update":
$srvrid=$_REQUEST['srvrid'];
$ss=$_REQUEST['s']*1048576;
$sp=$_REQUEST['p'];
$pp=number_format($_REQUEST['p'],2,'.','');
$qry="update server set size=$ss,priority=$sp where id=$srvrid";
//echo $qry;
$conn->execute($qry);
break;
case "Include":
$srvrid=$_REQUEST['srvrid'];
$sn=$_REQUEST['n'];
$ss=$_REQUEST['s']*1048576;
$sp=$_REQUEST['p'];
$qry="insert into server set name='$sn',size=$ss,priority=$sp";
$conn->execute($qry);
break;
default:
break;
}
if($_REQUEST['sort']!="") {header("location: admin_index.php?change=Server&sort=".$_REQUEST['sort']);exit;}
header("location: admin_index.php?change=Server");
?>
