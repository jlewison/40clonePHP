<?php
$LANG['help_text'] = 'Help';

//A
$LANG['help']['address']['text'] = 'Address';
$LANG['help']['address']['desc'] = 'Address of the users when registered';
$LANG['help']['abuse_mail']['text'] = 'Abuse mail';
$LANG['help']['abuse_mail']['desc'] = 'Did you like to receive email while your questions are abused?';
$LANG['help']['all_news_letter']['text'] = 'All Newsletter';
$LANG['help']['all_news_letter']['desc'] = 'Did you like to allow all email from '.$CFG['site']['name'].'?';
$LANG['help']['answers']['text'] = 'Answer';
$LANG['help']['answers']['desc'] = 'Your Answer';
$LANG['help']['answers_audio']['text'] = 'Audio';
$LANG['help']['answers_audio']['desc'] = 'Add Your Audio';
$LANG['help']['answers_video']['text'] = 'Video';
$LANG['help']['answers_video']['desc'] = 'Add Your Video';
$LANG['help']['answers_source']['text'] = 'Source';
$LANG['help']['answers_source']['desc'] = 'Enter your source here';

//B
$LANG['help']['bio']['text'] = 'Bio';
$LANG['help']['bio']['desc'] = 'Biodata of the users';
$LANG['help']['best_ans_mail']['text'] = 'Best Answer';
$LANG['help']['best_ans_mail']['desc'] = 'Did you like to receive email while you answer selected as best?';

//C
$LANG['help']['confirmpassword']['text'] = 'Confirm password';
$LANG['help']['confirmpassword']['desc'] = 'The confirmation of the password.The password and the confirmation of the password must be same';
$LANG['help']['country']['text'] = 'Country';
$LANG['help']['country']['desc'] = 'The country which users belongs';
$LANG['help']['city']['text'] = 'City';
$LANG['help']['city']['desc'] = 'The city which users belongs';
$LANG['help']['captcha']['text'] = 'Captcha';
$LANG['help']['captcha']['desc'] = 'Turing number';
$LANG['help']['contact_us_useremail']['text'] = 'E-mail';
$LANG['help']['contact_us_useremail']['desc'] = 'E-mail to contact';
$LANG['help']['contact_us_subject']['text'] = 'Subject';
$LANG['help']['contact_us_subject']['desc'] = 'Subject message of the mail';
$LANG['help']['contact_us_message']['text'] = 'Message';
$LANG['help']['contact_us_message']['desc'] = 'Content of the mail';

//D

//E
$LANG['help']['email']['text'] = 'E-mail';
$LANG['help']['email']['desc'] = 'E-mail of the users';

//F
$LANG['help']['fax']['text'] = 'Fax';
$LANG['help']['fax']['desc'] = 'Fax number of the users';
$LANG['help']['forum_ratings']['text'] = 'Ratings';
$LANG['help']['forum_ratings']['desc'] = 'Rate this topic. ( 1 = lowest   and 10 = highest )';
$LANG['help']['forum_title']['text'] = 'Forum Title';
$LANG['help']['forum_title']['desc'] = 'Forum Title';
$LANG['help']['forum_title_status']['text'] = 'Forum Status';
$LANG['help']['forum_title_status']['desc'] = 'Forum Status';
$LANG['help']['forum_title_description']['text'] = 'Forum Description';
$LANG['help']['forum_title_description']['desc'] = 'Forum Description';
$LANG['help']['forum_topic_subject']['text'] = 'Topic';
$LANG['help']['forum_topic_subject']['desc'] = 'Topic name';
$LANG['help']['forum_topic_response']['text'] = 'Topic response';
$LANG['help']['forum_topic_response']['desc'] = 'Topic response';
$LANG['help']['favorite_mail']['text'] = 'Favorite Questions';
$LANG['help']['favorite_mail']['desc'] = 'Did you like to receive email while replying your favorite questions?';
$LANG['help']['forward_friend_name']['text'] = 'Name';
$LANG['help']['forward_friend_name']['desc'] = 'Your Name';
$LANG['help']['forward_friend_email']['text'] = 'Email';
$LANG['help']['forward_friend_email']['desc'] = 'Your Email';
$LANG['help']['forward_friend_emails']['text'] = 'Friend\'s Email';
$LANG['help']['forward_friend_emails']['desc'] = 'Your Friend\'s Email IDs';

//G
$LANG['help']['gender']['text'] = 'Gender';
$LANG['help']['gender']['desc'] = 'Your gender';

//H

//I
$LANG['help']['image_path']['text'] = 'Image Path';
$LANG['help']['image_path']['desc'] = 'Image path url';
$LANG['help']['internal_mail']['text'] = 'Internal mail';
$LANG['help']['internal_mail']['desc'] = 'Did you like to receive internal mail?';

//J

//K
$LANG['help']['keyword_mail']['text'] = 'Keyword related mail';
$LANG['help']['keyword_mail']['desc'] = 'Did you like to receive email while adding questions related to your keywords?';

//L

//M
$LANG['help']['messages_include_original_message']['text'] = 'Include original message';
$LANG['help']['messages_include_original_message']['desc'] = 'Click Yes to send original message along with your message';
$LANG['help']['messages_message']['text'] = 'Message';
$LANG['help']['messages_message']['desc'] = 'Message you like to send';
$LANG['help']['messages_subject']['text'] = 'Subject';
$LANG['help']['messages_subject']['desc'] = 'Subject of the message';
$LANG['help']['messages_to']['text'] = 'To';
$LANG['help']['messages_to']['desc'] = 'Enter username to send message';
$LANG['help']['managebanners_source']['text'] = 'Html Source';
$LANG['help']['managebanners_source']['desc'] = 'Html source';
$LANG['help']['managebanners_about']['text'] = 'About';
$LANG['help']['managebanners_about']['desc'] = 'More details about the advertisement';
$LANG['help']['managebanners_block']['text'] = 'Block';
$LANG['help']['managebanners_block']['desc'] = 'Select advertisment block';
$LANG['help']['managebanners_status']['text'] = 'Status';
$LANG['help']['managebanners_status']['desc'] = 'Select status';
$LANG['help']['managebanners_start_date']['text'] = 'Start Date';
$LANG['help']['managebanners_start_date']['desc'] = 'Advertisement start date';
$LANG['help']['managebanners_end_date']['text'] = 'End Date';
$LANG['help']['managebanners_end_date']['desc'] = 'Advertisement end date';
$LANG['help']['managebanners_allowed_impressions']['text'] = 'Impressions';
$LANG['help']['managebanners_allowed_impressions']['desc'] = 'Allowed Impressions';

//N
$LANG['help']['name']['text'] = 'Name';
$LANG['help']['name']['desc'] = 'Name of the users';
$LANG['help']['new_mail']['text'] = 'New Email';
$LANG['help']['new_mail']['desc'] = 'Enter your new email Id';

//0

//P
$LANG['help']['password']['text'] = 'Password';
$LANG['help']['password']['desc'] = 'The password of the users when registered';
$LANG['help']['phone']['text'] = 'Phone';
$LANG['help']['phone']['desc'] = 'Phone number of the users';

//Q
$LANG['help']['question']['text'] = 'Question';
$LANG['help']['question']['desc'] = 'Enter your question';
$LANG['help']['question_details']['text'] = 'Details';
$LANG['help']['question_details']['desc'] = 'Details about the question';
$LANG['help']['question_category']['text'] = 'Question Category';
$LANG['help']['question_category']['desc'] = 'Select Your Question Category';
$LANG['help']['question_subcategory']['text'] = 'Question SubCategory';
$LANG['help']['question_subcategory']['desc'] = 'Select Your Question SubCategory';
$LANG['help']['question_tag']['text'] = 'Tag';
$LANG['help']['question_tag']['desc'] = 'Enter your Tags';
$LANG['help']['question_audio']['text'] = 'Audio';
$LANG['help']['question_audio']['desc'] = 'Add Your Audio';
$LANG['help']['question_video']['text'] = 'Video';
$LANG['help']['question_video']['desc'] = 'Add Your Video';

//R
$LANG['help']['reply_mail']['text'] = 'Reply to the questions';
$LANG['help']['reply_mail']['desc'] = 'Did you like to receive email while replying for questions you have asked?';
$LANG['help']['remember']['text'] = 'Remember login';
$LANG['help']['remember']['desc'] = 'Remembers your login details';

//S
$LANG['help']['state']['text'] = 'State';
$LANG['help']['state']['desc'] = 'The state which users belongs';
$LANG['help']['subscribe_keywords']['text'] = 'Subscribe Keywords';
$LANG['help']['subscribe_keywords']['desc'] = 'Enter keywords you like, email will come if question related to the keyword added';
$LANG['help']['select_avatar_image']['text'] = 'Select Avatar';
$LANG['help']['select_avatar_image']['desc'] = 'Select image for avatar';

//T

//U
$LANG['help']['user_id']['text'] = 'User id';
$LANG['help']['user_id']['desc'] = 'The user id of the users which is unique';
$LANG['help']['username']['text'] = 'Username';
$LANG['help']['username']['desc'] = 'The username of the users which is unique';
$LANG['help']['upload_avatar_image']['text'] = 'Upload Image';
$LANG['help']['upload_avatar_image']['desc'] = 'Upload image for avatar';
$LANG['help']['user_access']['text'] = 'User access';
$LANG['help']['user_access']['desc'] = 'User access';

//Y
$LANG['help']['your_name']['text'] = 'Your Name';
$LANG['help']['your_name']['desc'] = 'Your Name';
$LANG['help']['your_email']['text'] = 'Your Email';
$LANG['help']['your_email']['desc'] = 'Your Email Id';
$LANG['help']['your_friends_email']['text'] = 'Your Friends MailID';
$LANG['help']['your_friends_email']['desc'] = 'Enter Your Friend\'s Email IDs';

//Home page settings
$LANG['help']['recent_questions']['text'] = 'Recent Questions';
$LANG['help']['recent_questions']['desc'] = 'Do you want to display this block in home page?';
$LANG['help']['popular_questions']['text'] = 'Popular questions';
$LANG['help']['popular_questions']['desc'] = 'Do you want to display this block in home page?';
$LANG['help']['questions_with_videos']['text'] = 'Questions with videos';
$LANG['help']['questions_with_videos']['desc'] = 'Do you want to display this block in home page?';
$LANG['help']['questions_with_audios']['text'] = 'Questions with audios';
$LANG['help']['questions_with_audios']['desc'] = 'Do you want to display this block in home page?';
$LANG['help']['best_of_answer']['text'] = 'Best of Answers';
$LANG['help']['best_of_answer']['desc'] = 'Do you want to display this block in home page?';
$LANG['help']['recent_forums']['text'] = 'Recent forums';
$LANG['help']['recent_forums']['desc'] = 'Do you want to display this block in home page?';
$LANG['help']['forums_with_most_replies']['text'] = 'Forums with most replies';
$LANG['help']['forums_with_most_replies']['desc'] = 'Do you want to display this block in home page?';
$LANG['help']['recent_blogs']['text'] = 'Recent Blogs';
$LANG['help']['recent_blogs']['desc'] = 'Do you want to display this block in home page?';
$LANG['help']['blogs_with_most_comment']['text'] = 'Blogs with most comment';
$LANG['help']['blogs_with_most_comment']['desc'] = 'Do you want to display this block in home page?';
$LANG['help']['top_analyst']['text'] = 'Top Analyst';
$LANG['help']['top_analyst']['desc'] = 'Do you want to display this block in home page?';
$LANG['help']['featured_analyst']['text'] = 'Featured Analyst';
$LANG['help']['featured_analyst']['desc'] = 'Do you want to display this block in home page?';

?>