<?php
/**
 * MyBB 1.4 English Language Pack
 * Copyright © 2008 MyBB Group, All Rights Reserved
 * 
 * $Id: syndication.lang.php 4304 2009-01-02 01:11:56Z chris $
 */

$l['all_forums'] = "All Forums";
$l['forum'] = "Forum:";
$l['posted_by'] = "Posted By:";
$l['on'] = "on";

?>