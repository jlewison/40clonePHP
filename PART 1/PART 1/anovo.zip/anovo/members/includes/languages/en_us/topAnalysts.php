<?php
$LANG['analysts_err_sorry'] = 'Sorry, errors detected!';
$LANG['analysts_err_tip_compulsory'] = 'Compulsory!';
$LANG['analysts_err_exists_already'] = 'Question exists already!. Try another question';
$LANG['analysts_name'] = 'Analysts';
$LANG['analysts_points'] = 'Total points';
$LANG['analysts_questions'] = 'Questions Asked';
$LANG['analysts_answers'] = 'Total Answers';
$LANG['analysts_no_records'] = 'No analysts found';
$LANG['display_all_analysts'] = 'display all analysts';
?>