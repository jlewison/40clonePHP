<?php
/**
*
*
*
* @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
* @license
* @version SVN:$Id
* @since 2007-06-18
*/
$lang['emailtemplates_title'] 					= 'Email Templates';
$lang['emailtemplates_template_title'] 			= 'Template Title';
$lang['emailtemplates_action'] 					= 'Action';
$lang['emailtemplates_edit'] 					= 'Edit';
$lang['emailtemplates_mail_subject'] 			= 'Mail Subject';
$lang['emailtemplates_mail_content'] 			= 'Mail Content';
$lang['emailtemplates_special_variables'] 		= 'Special Variables';
$lang['emailtemplates_submit'] 					= 'Save changes';
$lang['emailtemplates_back'] 					= 'Back to email templates';
$lang['emailtemplates_success_msg'] 			= 'Email template updated successfully!';
?>