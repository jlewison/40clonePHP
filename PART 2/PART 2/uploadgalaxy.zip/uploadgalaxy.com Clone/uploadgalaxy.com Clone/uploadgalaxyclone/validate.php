<?
include("include/config.php");
$uname=$_REQUEST['name'];
$upass=$_REQUEST['pass'];
$sql="select * from premium_user where uname='$uname' and pass='$upass'";
$rs=$conn->execute($sql);
$n=$rs->recordcount();
if($n>0) 
        {
         setcookie('uname',$uname);
         setcookie('uid',$rs->fields['uid']);
         setcookie('email',$rs->fields['email']);
         header("location: welcome_premium.php");
        }

else 
        {
         setcookie('error',"Incorrect Username/Password");
         header("location: premium.php");
        }
?>
