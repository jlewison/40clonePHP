<?php
class subscribedUser extends FormHandler
{
		public $user_details = array();
		public function populateUserDetails($user_id)
		{
				$fields_arr = array('user_id', 'name', 'email', 'image_path', 'gender', 'usr_status', 'user_access', 't_height', 't_width', 'photo_server_url', 'photo_ext');
				$sql = 'SELECT ' . $this->getUserTableFields($fields_arr) . ' ,' . $this->getUserTableField('user_id') . ' as img_user_id FROM ' . $this->CFG['db']['tbl']['users'] . ' WHERE user_id = ' . $this->dbObj->Param('user_id');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($user_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($row = $rs->FetchRow()) return $row;
				return false;
		}
		public function populateUserList()
		{
				$sql = 'SELECT content_id FROM ' . $this->CFG['db']['tbl']['user_bookmarked'] . ' WHERE content_type = \'User\' AND user_id = ' . $this->dbObj->Param('user_id');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['uid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if (!$rs->PO_RecordCount())
				{
?>
					<div class="clsNoRecords">
						<p><?php echo $this->LANG['no_tags_subscribed']; ?></p>
					</div>
					<?php
						return;
				}
				$photosPerRow = 3;
				$count = 0;
				$found = false;
?>
<div class="clsSideBarContents">
<table summary="display subscribed users" class="clsSubscribeTbl">
<?php
				while ($row = $rs->FetchRow())
				{
						$user_details = $this->populateUserDetails($row['content_id']);
						$found = true;
						if ($count % $photosPerRow == 0)
						{
?>
							<tr>
<?php
						}
?>
<td>
<div class="clsMysubscribeUser">
<?php if (chkUserImageAllowed())
						{ ?>
<p id="selImageBorder"><?php displayUserImage($user_details, 'thumb', false); ?></p>
<?php } ?>
<p class="clsSubscribeName"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'myanswers.php?uid=' . $user_details['user_id'], $this->CFG['site']['relative_url'] . 'my/answers/' . $user_details['user_id'] . '/', false); ?>"><?php echo stripString($user_details['name'], $this->CFG['username']['short_length']); ?></a></p>
</div>
</td>
<?php
						$count++;
						if ($count % $photosPerRow == 0)
						{
								$count = 0;
?>
							</tr>
<?php
						}
				}
?>
</table>
</div>
<?php
		}
		public function populateUserDetailsArr()
		{
				$sql = 'SELECT ' . $this->getUserTableFields(array('name')) . ' FROM' . ' ' . $this->CFG['db']['tbl']['users'] . ' WHERE' . ' user_id = ' . $this->dbObj->Param('user_id') . ' AND' . ' ' . $this->getUserTableField('usr_status') . '=\'OK\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['uid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($row = $rs->FetchRow())
				{
						$this->user_details = $row;
						return true;
				}
				return false;
		}
}
$subscribedUser = new subscribedUser();
$subscribedUser->setDBObject($db);
$subscribedUser->makeGlobalize($CFG, $LANG);
$subscribedUser->setPageBlockNames(array('msg_form_success', 'msg_form_error', 'user_list_block'));
$subscribedUser->setFormField('uid', '');
$subscribedUser->sanitizeFormInputs($_REQUEST);
if (!$subscribedUser->getFormField('uid')) $subscribedUser->setFormField('uid', $CFG['user']['user_id']);
if ($subscribedUser->populateUserDetailsArr())
{
		$subscribedUser->setPageBlockShow('user_list_block');
		$LANG['back_to_user_profile_user'] = str_replace('{user_name}', $subscribedUser->user_details['name'], $LANG['back_to_user_profile_user']);
		$LANG['back_to_user_profile'] = ($CFG['user']['user_id'] == $subscribedUser->getFormField('uid')) ? $LANG['back_to_user_profile'] : $LANG['back_to_user_profile_user'];
		$LANG['page_title_user_name'] = str_replace('{user_name}', $subscribedUser->user_details['name'], $LANG['page_title_user_name']);
		$LANG['page_title'] = ($subscribedUser->getFormField('uid') == $CFG['user']['user_id']) ? $LANG['page_title'] : $LANG['page_title_user_name'];
		$back_link = '<a href="' . getUrl($CFG['site']['relative_url'] . 'myanswers.php?uid=' . $subscribedUser->getFormField('uid'), $CFG['site']['relative_url'] . 'my/answers/' . $subscribedUser->getFormField('uid') . '/', false) . '">' . $LANG['back_to_user_profile'] . '</a>';
}
else
{
		$subscribedUser->setPageBlockShow('msg_form_error');
		$subscribedUser->setCommonErrorMsg($LANG['invalid_user']);
}



?>
<script language="javascript">
	var block_arr= new Array('selMsgConfirm');
</script>
<div id="selManageBlog">
<?php
if ($subscribedUser->isShowPageBlock('user_list_block'))
{
		$display_username = $LANG['myanswers_subscribed'];
		$uid = $subscribedUser->getFormField('uid');
		$uname = $subscribedUser->user_details['name'];
		if ($CFG['user']['user_id'] != $uid)
		{
				$display_username = str_replace('{user_name}', $uname, $LANG['myanswers_subscribed_others']);
		}
?>
	<div class="clsQuestionsLink">
		<ul>
        <li class="clsSubscribe"><?php echo $display_username; ?></li>
			<li class="clsLeftInActiveQuestionsLink"><span class="clsRightInActiveQuestionsLink"><a class="clsMiddleInActiveQuestionsLink" href="<?php echo getUrl($CFG['site']['relative_url'] . 'mySubscribedTag.php?uid=' . $uid, $CFG['site']['relative_url'] . 'mysubscribedtag/' . $uid . '/', false); ?>"><?php echo $LANG['myanswers_subscribed_tag']; ?></a></span></li>
			<li class="clsLeftActiveQuestionsLink"><span class="clsRightActiveQuestionsLink"><a class="clsMiddleActiveQuestionsLink" href="<?php echo getUrl($CFG['site']['relative_url'] . 'mySubscribedUser.php?uid=' . $uid, $CFG['site']['relative_url'] . 'mysubscribeduser/' . $uid . '/', false); ?>"><?php echo $LANG['myanswers_subscribed_user']; ?></a></span></li>
			<li class="clsLeftInActiveQuestionsLink"><span class="clsRightInActiveQuestionsLink"><a class="clsMiddleInActiveQuestionsLink" href="<?php echo getUrl($CFG['site']['relative_url'] . 'mySubscribedForum.php?uid=' . $uid, $CFG['site']['relative_url'] . 'mysubscribedforum/' . $uid . '/', false); ?>"><?php echo $LANG['myanswers_subscribed_forum']; ?></a></span></li>
		</ul>
	</div>
<?php
}
if ($subscribedUser->isShowPageBlock('msg_form_error'))
{
?>
  	<div id="selMsgError">
   		<p><?php echo $subscribedUser->getCommonErrorMsg(); ?></p>
  	</div>
<?php
}
if ($subscribedUser->isShowPageBlock('msg_form_success'))
{
?>
	<div id="selMsgSuccess">
		<p><?php echo $subscribedUser->getCommonErrorMsg(); ?></p>
	</div>
<?php
}
if ($subscribedUser->isShowPageBlock('user_list_block'))
{
?>
	<div id="selSubscribedTags" class="clsCommonIndexSection">
		<div id="selWidgetRecentQuestions" class="clsSideBarSections">
			<?php $subscribedUser->populateUserList(); ?>
		</div>
	</div>
<?php
}
?>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>
