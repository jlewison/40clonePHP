<?php include('template/BrownLBS/top_side.php');?>
<!--
###################################################################################
#######################                                     #######################
#######################   M A I N   S E C T I O N   Start   #######################
#######################                                     #######################
###################################################################################
-->

<h1><?php echo("$categoryname");?></h1>

<div class="content">

<?php if($totalRows_catPcatLN <> '') { ?>
<div id="stop">	<a href="<?php echo("$path");?>categxml.php?categ=<?php echo("$categnum");?>" target="_blank"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/xml.gif" alt="RSS Feed" border="0" /></a>
	<?php echo("$lang_25");?> <?php echo ($startRow_catPcatLN + 1) ?> <?php echo("$lang_26");?> <?php echo min($startRow_catPcatLN + $maxRows_catPcatLN, $totalRows_catPcatLN) ?> <?php echo("$lang_27");?> <?php echo $totalRows_catPcatLN ?> <?php echo("$lang_25");?>
<br>
<br>
</div>
  <table border="0" cellpadding="0" cellspacing="1" width="100%">
	<?php do { ?>
    	<tr><td>

			<?php $wsn = $row_catPcatLN['title']; $step8 = str_replace(" ", "-", $wsn); $wsseoname = "$step8";?>
            <div id="listing"><a href="<?php echo $row_catPcatLN['site']; ?>" target="_blank"><?php echo $row_catPcatLN['title']; ?></a><br />
			  <?php echo $row_catPcatLN['descr1']; ?>
			</div>
		  <div id="listingD">
			  	<?php echo $row_catPcatLN['site']; ?> :: <?php echo("$lang_5");?> <?php echo $row_catPcatLN['stad']; ?> <?php if($fremode == 'N') { ?> :: <?php echo $row_catPcatLN['bid']; ?> <?php echo("$lang_29");?> <?php } else { } ?> 
		    <a href="<?php echo("$path");?><?php echo $row_catPcatLN['dtu'];?>/<?php echo("$wsseoname"); ?>.html"><?php echo("$lang_7");?></a>
		    <?php if($fremode == 'N') { ?> <a href="<?php echo("$path");?>upgrade.php?ucat=<?php echo $row_catPcatLN['dtu']; ?>"><?php echo("$lang_8");?></a> <?php } else { } ?>
            </div>
          
<?php if($prenabled == 'Y' and $enb_category == 'Y') { ?>

	<?php include('pr_update_category.php');?>

    <div id="stats">	    
      <?php if($enb_google == 'Y') { ?>
      <img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/googleIcon.gif" /> <?php echo $row_catPcatLN['google']; ?>
          <?php } else {} ?>
      
          <?php if($enb_yahoo == 'Y') { ?>
      <img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/yahooIcon.gif" /> <?php echo $row_catPcatLN['yahoo']; ?>
          <?php } else {} ?>
      
          <?php if($enb_msn == 'Y') { ?>
      <img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/msnIcon.gif" /> <?php echo $row_catPcatLN['msn']; ?>
          <?php } else {} ?>
      
          <?php if($enb_alexa == 'Y') { ?>
      <img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/alexaIcon.gif" /> <?php echo $row_catPcatLN['alexa']; ?>
          <?php } else {} ?>
    </div>
<?php } else {} ?>


<hr />
		</td>
    	</tr>
	<?php } while ($row_catPcatLN = mysql_fetch_assoc($catPcatLN));?>
  </table>



			<div id="sumitlink"><a href="<?php echo("$path");?>submit.php?su_categ=<?php echo("$su_categ");?>"><?php echo("$lang_31");?></a></div>

<?php } else { ?>

  <div id="notlink"><?php echo("$lang_32");?> <a href="<?php echo("$path");?>submit.php?su_categ=<?php echo("$su_categ");?>"><?php echo("$lang_33");?></a> <?php echo("$lang_34");?></div>

<?php } ?>
<table  border="0" cellpadding="0" cellspacing="1">
  <tr>
    <td>


<?php if ($pageNum_catPcatLN > 0) { // Show if not first page ?>
<a href="<?php echo("$path");?>next/<?php echo("0");?>/<?php echo("$totalRows_catPcatLN");?>/<?php echo("$categseoname");?>.html"> <?php echo("$lang_35");?> </a>
<?php } // Show if not first page ?>

<?php if ($pageNum_catPcatLN > 0) { // Show if not first page ?>
<a href="<?php echo("$path");?>next/<?php $mb = max(0, $pageNum_catPcatLN - 1); echo("$mb");?>/<?php echo("$totalRows_catPcatLN");?>/<?php echo("$categseoname");?>.html"> <?php echo("$lang_36");?> </a>
<?php } // Show if not first page ?>

<?php if ($pageNum_catPcatLN < $totalPages_catPcatLN) { // Show if not last page ?>
<a href="<?php echo("$path");?>next/<?php $mb = min($totalPages_catPcatLN, $pageNum_catPcatLN + 1); echo("$mb");?>/<?php echo("$totalRows_catPcatLN");?>/<?php echo("$categseoname");?>.html"><?php echo("$lang_37");?> > </a>
<?php } // Show if not last page ?>

<?php if ($pageNum_catPcatLN < $totalPages_catPcatLN) { // Show if not last page ?>
<a href="<?php echo("$path");?>next/<?php $mb = min($totalPages_catPcatLN, $pageNum_catPcatLN + 1); echo("$totalPages_catPcatLN");?>/<?php echo("$totalRows_catPcatLN");?>/<?php echo("$categseoname");?>.html"><?php echo("$lang_38");?> &gt;</a>
<?php } // Show if not last page ?>


    </td>
  </tr>
</table>

</div>

<!--
###################################################################################
#######################                                     #######################
#######################    M A I N   S E C T I O N   End    #######################
#######################                                     #######################
###################################################################################
-->

<?php include('template/BrownLBS/bottom_side.php');?>
<?php include('template/BrownLBS/footer.php'); ?>