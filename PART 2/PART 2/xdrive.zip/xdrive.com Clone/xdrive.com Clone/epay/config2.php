<?
$currency = "$";
$ex_rate = 1.00;
$signup_bonus = 5.00;
$signup_fee = 5.00;

// $
$referral_payout = 2.5;
$minimal_transfer = 0.05;
$transfer_percent = 2.9;
$transfer_fee = 0.39;
$sales_tax = "0";
$send_i = 1;
$send_r = 1;

// DEPOSIT
$dep_notify = 1;
$dep_pp_percent = 3.5;
$dep_pp_fee = 0.30;
$dep_sp_percent = 3.5;
$dep_sp_fee = 0.30;
$dep_cc_percent = 5.5;
$dep_cc_fee = 0.50;
$dep_anet_percent = 0;
$dep_anet_fee = 0.00;
$dep_eg_percent = 2.5;
$dep_eg_fee = 0.50;
$dep_np_percent = 2.5;
$dep_np_fee = 0.50;
$dep_check_fee = 1.00;
$minimal_deposit = 0.10;

// WITHDRAW
$wdr_notify = 1;
$wdr_pp_fee = 1.00;
$wdr_check_fee = 2.00;
$wdr_wire_fee = 21.00;
$minimal_withdrawal = 0.50;

// STORMPAY
$paypal_use = 0;
$paypal_id = "Yourname@Yoursite.com";
$paypal_auto_deposit = 1;
$stormpay_use = 0;
$stormpay_id = "Yourname@Yoursite.com";
$stormpay_auto_deposit = 1;

// NETPAY
$tocheckout_sid = "";
$anet_sid = "";
$anet_pwd = "";
$eg_use = 0;
$egold_sid = "";
$np_use = 0;
$netpay_sid = "";

// CHECK
$check_use = 0;
$dep_check = "";

?>