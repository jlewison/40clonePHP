<?php
/**
 * Message Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 12/17/2007
 */
class Message extends Controller
{
		//Constructor
		function Message()
		{
				parent::Controller();
				loginRequired();
				//Load the language file
				$this->lang->load('message', $this->config->item('language_code'));
				//Load the message model
				$this->load->model('messagemodel');
		}
		//Default function
		function index()
		{
				$this->inbox();
		}
		function inbox()
		{
				//Load the pagination model
				$this->load->model('paginationmodel');
				//Load the pagination language file
				$this->lang->load('pagination', $this->config->item('language_code'));
				if ($this->uri->segment(4) == 'deleted') $outputData['successMsg'] = $this->lang->line('message_delete_success');
				$perPage = $this->paginationmodel->getPerPage('message');
				$start = (trim($this->uri->segment(3)) != '' && is_numeric($this->uri->segment(3)) && $this->uri->segment(3) > 0) ? $this->uri->segment(3) : 1;
				$start = ($start - 1) * $perPage;
				$messages = $this->messagemodel->getMessagesInInbox('datestamp desc', $start, $perPage);
				$messagesTotal = $this->messagemodel->getMessagesInInboxCount();
				$outputData['inbox'] = true;
				$outputData['sent'] = false;
				$outputData['trash'] = false;
				$outputData['view_message'] = false;
				$outputData['selectOptions'] = array('' => '--', 'none' => $this->lang->line('message_none'), 'read' => $this->lang->line('message_read'), 'unread' => $this->lang->line('message_unread'), 'all' => $this->lang->line('message_all'));
				$outputData['total_messages'] = 0;
				if (!empty($messages))
				{
						$outputData['is_messages'] = true;
						$outputData['message_arr'] = $messages;
						$outputData['total_messages'] = count($messages);
				}
				else  $outputData['is_messages'] = false;
				$outputData['currentPage'] = (trim($this->uri->segment(3)) != '' && is_numeric($this->uri->segment(3))) ? $this->uri->segment(3) : 1;
				$outputData['totalPages'] = ($messagesTotal > $perPage) ? ceil(($messagesTotal / $perPage)) : 0;
				$outputData['pageUrl'] = base_url() . 'message/inbox/';
				$this->smartyextended->view('messageinbox', $outputData);
		}
		function sent()
		{
				//Load the pagination model
				$this->load->model('paginationmodel');
				//Load the pagination language file
				$this->lang->load('pagination', $this->config->item('language_code'));
				if ($this->uri->segment(4) == 'deleted') $outputData['successMsg'] = $this->lang->line('message_delete_success');
				$perPage = $this->paginationmodel->getPerPage('message');
				$start = (trim($this->uri->segment(3)) != '' && is_numeric($this->uri->segment(3)) && $this->uri->segment(3) > 0) ? $this->uri->segment(3) : 1;
				$start = ($start - 1) * $perPage;
				$messages = $this->messagemodel->getMessagesInSent('datestamp desc', $start, $perPage);
				$messagesTotal = $this->messagemodel->getMessagesInSentCount();
				$outputData['inbox'] = false;
				$outputData['sent'] = true;
				$outputData['trash'] = false;
				$outputData['view_message'] = false;
				$outputData['selectOptions'] = array('' => '--', 'none' => $this->lang->line('message_none'), 'read' => $this->lang->line('message_read'), 'unread' => $this->lang->line('message_unread'), 'all' => $this->lang->line('message_all'));
				$outputData['total_messages'] = 0;
				if (!empty($messages))
				{
						$outputData['is_messages'] = true;
						$outputData['message_arr'] = $messages;
						$outputData['total_messages'] = count($messages);
				}
				else  $outputData['is_messages'] = false;
				$outputData['currentPage'] = (trim($this->uri->segment(3)) != '' && is_numeric($this->uri->segment(3))) ? $this->uri->segment(3) : 1;
				$outputData['totalPages'] = ($messagesTotal > $perPage) ? ceil(($messagesTotal / $perPage)) : 0;
				$outputData['pageUrl'] = base_url() . 'message/sent/';
				$this->smartyextended->view('messageinbox', $outputData);
		}
		function trash()
		{
				//Load the pagination model
				$this->load->model('paginationmodel');
				//Load the pagination language file
				$this->lang->load('pagination', $this->config->item('language_code'));
				if ($this->uri->segment(4) == 'deleted') $outputData['successMsg'] = $this->lang->line('message_delete_success');
				$perPage = $this->paginationmodel->getPerPage('message');
				$start = (trim($this->uri->segment(3)) != '' && is_numeric($this->uri->segment(3)) && $this->uri->segment(3) > 0) ? $this->uri->segment(3) : 1;
				$start = ($start - 1) * $perPage;
				$messages = $this->messagemodel->getMessagesInTrash('datestamp desc', $start, $perPage);
				$messagesTotal = $this->messagemodel->getMessagesInTrashCount();
				$outputData['inbox'] = false;
				$outputData['sent'] = false;
				$outputData['trash'] = true;
				$outputData['view_message'] = false;
				$outputData['selectOptions'] = array('' => '--', 'none' => $this->lang->line('message_none'), 'all' => $this->lang->line('message_all'));
				$outputData['total_messages'] = 0;
				if (!empty($messages))
				{
						$outputData['is_messages'] = true;
						$outputData['message_arr'] = $messages;
						$outputData['total_messages'] = count($messages);
				}
				else  $outputData['is_messages'] = false;
				$outputData['currentPage'] = (trim($this->uri->segment(3)) != '' && is_numeric($this->uri->segment(3))) ? $this->uri->segment(3) : 1;
				$outputData['totalPages'] = ($messagesTotal > $perPage) ? ceil(($messagesTotal / $perPage)) : 0;
				$outputData['pageUrl'] = base_url() . 'message/trash/';
				$this->smartyextended->view('messageinbox', $outputData);
		}
		function compose()
		{
				$this->send();
		}
		function send()
		{
				$this->load->model('usermodel');
				$outputData['inbox'] = false;
				$outputData['sent'] = false;
				$outputData['trash'] = false;
				$outputData['view_message'] = false;
				$outputData['user_exists'] = 0;
				if ($this->uri->segment(3) && is_numeric($this->uri->segment(3)))
				{
						$outputData['user_id'] = $this->uri->segment(3);
						$userDetails = $this->usermodel->getDetails($outputData['user_id']);
						if (!empty($userDetails))
						{
								$outputData['user_name'] = $userDetails[$outputData['user_id']]['username'];
								$outputData['user_exists'] = $outputData['user_id'];
						}
				}
				if (isset($_POST) && is_array($_POST) && count($_POST) > 0)
				{
						if (trim($this->input->post('to_id')) == '' && trim($this->input->post('to_name') == '')) $outputData['validationError'] = $this->lang->line('message_select_person_err');
						else
								if (trim($this->input->post('to_id')) == '') $outputData['validationError'] = $this->lang->line('message_invalid_person_err');
								elseif (trim($this->input->post('subject')) == '') $outputData['validationError'] = $this->lang->line('message_subject_err');
								elseif (trim($this->input->post('message')) == '') $outputData['validationError'] = $this->lang->line('message_message_err');
								else
								{
										$msgConfig = array('to_id' => $this->input->post('to_id'), 'subject' => $this->input->post('subject'), 'message' => $this->input->post('message'));
										$user_details = $this->usermodel->getUserDetails($this->input->post('to_id'));
										$user_status = $this->usermodel->getUserNotifications();
										$id = $this->messagemodel->sendMessage($msgConfig);
										if (isset($user_status[2]) && $user_status[2] == 1)
										{
												$this->load->library('email');
												/* Send the Confirm E-Mail as the register is confirmed successfully */
												$settings = $this->settingsmodel->readSetting('admin_email, admin_name, site_name, site_title');
												$adminEmail = $settings['admin_email'];
												$adminName = $settings['admin_name'];
												$this->email->from($adminEmail, $adminName);
												$this->email->to($user_details[$this->input->post('to_id')]['email']);
												$this->email->subject($this->input->post('subject'));
												$this->email->message(nl2br($this->input->post('message')));
												$this->email->send();
										}
										redirect('message/viewMessage/s_' . $id . '');
								}
								$this->smartyextended->view('messagecompose', $outputData);
				}
				else  $this->smartyextended->view('messagecompose', $outputData);
		}
		function share()
		{
				$outputData['validationError'] = '';
				if (isset($_POST) && is_array($_POST) && count($_POST) > 0)
				{
						if (trim($this->input->post('to_id')) == '') $outputData['validationError'] = $this->lang->line('message_select_friend_err');
						elseif (trim($this->input->post('subject')) == '') $outputData['validationError'] = $this->lang->line('message_subject_err');
						elseif (trim($this->input->post('message')) == '') $outputData['validationError'] = $this->lang->line('message_message_err');
						else
						{
								$this->load->model('emailTemplateModel');
								$this->load->model('settingsModel');
								//reads common site settings
								$settings = $this->settingsmodel->readSetting('admin_email, admin_name, site_name, site_title');
								$adminEmail = $settings['admin_email'];
								$adminName = $settings['admin_name'];
								$siteName = $settings['site_title'];
								//reads mail templates
								$emailTemplate = $this->emailTemplateModel->readEmailTemplate('share_content');
								//send external mail
								$splVars = array("~~senderName~~" => ucfirst($this->session->userdata('username')), "~~attachUrl~~" => $this->input->post('content_url'), "~~privateMessage~~" => $this->input->post('message'), "~~adminName~~" => $adminName);
								$subject = strtr($emailTemplate['template_subject'], $splVars);
								$message = strtr($emailTemplate['template_content'], $splVars);
								$msgConfig = array('to_id' => $this->input->post('to_id'), 'subject' => $subject, 'message' => $message);
								$this->messagemodel->sendMessage($msgConfig);
						}
				}
				if ($outputData['validationError'] != '') echo json_encode(array('error' => 'yes', 'msg' => $outputData['validationError']));
				else  echo json_encode(array('error' => 'no', 'msg' => $this->lang->line('message_share_link_success')));
		}
		function getToNames()
		{
				echo json_encode($this->messagemodel->getFriendsAddress($this->input->post('q')));
		}
		function unreadMessage()
		{
				if ($this->uri->segment(3) == 'inbox') $message_status_field = 'to_message_status';
				else
						if ($this->uri->segment(3) == 'sent') $message_status_field = 'from_message_status';
				if ($this->input->post('checked_id'))
				{
						$message_ids = $this->input->post('checked_id');
						$messages = $this->messagemodel->updateMessageStatus($message_ids, $message_status_field, 'unread');
						echo 'done';
				}
				else
						if ($this->uri->segment(4) && is_numeric($this->uri->segment(4)))
						{
								$message_ids = $this->uri->segment(4);
								$messages = $this->messagemodel->updateMessageStatus($message_ids, $message_status_field, 'unread');
								if ($message_status_field == 'to_message_status') echo 'unreadinbox';
								else
										if ($message_status_field == 'from_message_status') echo 'unreadsent';
						}
		}
		function readMessage()
		{
				if ($this->uri->segment(3) == 'inbox') $message_status_field = 'to_message_status';
				else
						if ($this->uri->segment(3) == 'sent') $message_status_field = 'from_message_status';
				if ($this->input->post('checked_id'))
				{
						$message_ids = $this->input->post('checked_id');
						$messages = $this->messagemodel->updateMessageStatus($message_ids, $message_status_field, 'read');
						echo 'done';
				}
		}
		function inboxToTrash()
		{
				if ($this->input->post('checked_id') || ($this->uri->segment(3) && is_numeric($this->uri->segment(3))))
				{
						if (($this->uri->segment(3)) && is_numeric($this->uri->segment(3)))
						{
								$message_ids = $this->uri->segment(3);
								$messages = $this->messagemodel->updateMessage($message_ids, 'inbox');
								echo 'inbox';
						} elseif ($this->input->post('checked_id'))
						{
								$message_ids = $this->input->post('checked_id');
								$messages = $this->messagemodel->updateMessage($message_ids, 'inbox');
								echo 'done';
						}
				}
		}
		function sentToTrash()
		{
				if ($this->input->post('checked_id') || ($this->uri->segment(3) && is_numeric($this->uri->segment(3))))
				{
						if (($this->uri->segment(3)) && (is_numeric($this->uri->segment(3))))
						{
								$message_ids = $this->uri->segment(3);
								$messages = $this->messagemodel->updateMessage($message_ids, 'sent');
								echo 'sent';
						} elseif ($this->input->post('checked_id'))
						{
								$message_ids = $this->input->post('checked_id');
								$messages = $this->messagemodel->updateMessage($message_ids, 'sent');
								echo 'done';
						}
				}
		}
		function trashDelete()
		{
				if ($this->input->post('checked_id') || ($this->uri->segment(3) && is_numeric($this->uri->segment(3))))
				{
						if (($this->uri->segment(3)) && (is_numeric($this->uri->segment(3))))
						{
								$message_ids = $this->uri->segment(3);
								$messages = $this->messagemodel->messageDelete($message_ids);
								echo 'trash';
						} elseif ($this->input->post('checked_id'))
						{
								$message_ids = explode(',', $this->input->post('checked_id'));
								$messages = $this->messagemodel->messageDelete($message_ids);
								echo 'done';
						}
				}
		}
		function deleteMessage()
		{
				if ($this->input->post('checked_id') || $this->uri->segment(3))
				{
						if ($this->uri->segment(3))
						{
								$message_ids = $this->uri->segment(3);
								$messages = $this->messagemodel->messageDelete($message_ids);
						} elseif ($this->input->post('checked_id'))
						{
								$message_ids = $this->input->post('checked_id');
								$messages = $this->messagemodel->messageDelete($message_ids);
						}
						echo 'done';
				}
		}
		function viewMessage()
		{
				$outputData['is_message'] = false;
				if ($this->uri->segment(3))
				{
						$messageid = explode('_', $this->uri->segment(3));
						$message_id = $messageid[1];
						if ($messageid[0] == 'i') $type = 'inbox';
						else
								if ($messageid[0] == 's') $type = 'sent';
								else
										if ($messageid[0] == 't') $type = 'trash';
						$validMessage = $this->messagemodel->getUserMessagesCount($type, $message_id, true);
						if ($validMessage)
						{
								$messages = $this->messagemodel->getMessage($message_id);
								if (!empty($messages))
								{
										$outputData = $messages[0];
										$messageArray = spliti('<a|</a>', $outputData['message']);
										$newMessage = '';
										foreach ($messageArray as $messageText)
										{
												if (strtolower(substr(trim($messageText), 0, 4)) == 'href') $newMessage = $newMessage . '<a ' . $messageText . '</a><BR />';
												else  $newMessage = $newMessage . wordwrap(nl2br(htmlspecialchars($messageText)), 50, '<br />', 1);
										}
										$outputData['message'] = $newMessage;
										if (($messageid[0] == 'i') && ($messages[0]['to_message_status'] == 'unread')) $this->messagemodel->updateMessageStatus($message_id, 'to_message_status', 'read');
										else
												if (($messageid[0] == 's') && ($messages[0]['from_message_status'] == 'unread')) $this->messagemodel->updateMessageStatus($message_id, 'from_message_status', 'read');
										$outputData['is_message'] = true;
										$outputData['message_type'] = $messageid[0];
										$outputData['inbox'] = false;
										$outputData['sent'] = false;
										$outputData['trash'] = false;
										$outputData['view_message'] = true;
										$this->smartyextended->view('messageinbox', $outputData);
								}
								else  redirect('message/inbox');
						}
						else
						{
								$this->session->set_flashdata('validationError', $this->lang->line('message_invalid_message_err'));
								redirect('message/' . $type);
						}
				}
				else  redirect('message');
		}
}
?>