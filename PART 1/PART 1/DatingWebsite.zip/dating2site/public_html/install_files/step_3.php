<?php

if ($config_opt == 'U' or $config_opt == 'F') {
	/* Let us get the database connectivity details using the config.php file */
//	include_once('config.php');
	$dbversion = VERSION;
	$dbname = DB_NAME;
	$dbuser = DB_USER;
	$dbpasswd = DB_PASS;
	$dbhost = DB_HOST;
	$prefix = DB_PREFIX;
	$dbtype = DB_TYPE;
	$errorcode='';
	/* Check if database can be connected */

	$dsn = $dbtype . '://' . $dbuser . ':' . $dbpasswd . '@' . $dbhost . '/';
	$db = @DB::connect( $dsn );
	if ( DB::isError($db) ) {
		$errorcode = 1;
		$t->assign( 'errorLogin', 1 );

	} else {

		if ($dbtype == 'mysql') {

			$result = $db->getAll( "show databases;" );

			// check if we have rights

			if ( !DB::isError( $result ) ) {

				foreach ( $result as $index => $dbarray ) {

					$name = $dbarray[0];

					if ( $name == $dbname ) {
						$db_valid = true;
						break;
					}
				}
			}
		} else {
			// if no rights - assume user entered valid db name
			// if not - this will be found in the next lines
			$db_valid = true;
		}

		$db->disconnect();

	}
	if ($errorcode == '') {
		/* Now see if tables are available */
		$dsn = $dbtype . '://' . $dbuser . ':' . $dbpasswd . '@' . $dbhost . '/' .$dbname;

		$db = @DB::connect( $dsn );

		if ($dbtype == 'mysql') {

			$result = $db->getAll( "show tables" );
			$tablesexist=0;
			foreach (array_values($result) as $table_exist) {
				foreach ($table_exist as $k => $tablename) {
					if (strpos($tablename,$prefix) !== false && strpos($tablename,$prefix.'_fc_') === false) $tablesexist++;
				}
			}

		}
		$db->disconnect();
	}

} else {

	$dbhost='localhost';
	$prefix = 'osdate';
}

$t->assign('tablesexist', $tablesexist);
$t->assign('dbversion',$dbversion);
$t->assign('dbname', $dbname);
$t->assign('dbuser', $dbuser);
$t->assign('dbpasswd', $dbpasswd);
$t->assign('dbhost', $dbhost);
$t->assign('prefix', $prefix);
$t->assign('db_valid', $db_valid);
$t->assign('dbtype', $dbtype);

$t->assign('dispstep', $dispstep+1);
$t->assign('config_opt',$config_opt);

$t->display('install/install_step3.tpl');
include('footer.tpl');
exit;
?>
