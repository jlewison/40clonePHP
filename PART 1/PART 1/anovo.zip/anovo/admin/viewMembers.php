<?php
require_once ('../common/config.inc.php');
require_once ('../common/configs/config_index.inc.php');
$CFG['lang']['include_files'][] = 'admin/includes/languages/%s/editMembers.php';
$CFG['html']['header'] = 'admin/includes/languages/%s/html_header.php';
$CFG['html']['footer'] = 'admin/includes/languages/%s/html_footer.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['db']['is_use_db'] = true;
$CFG['mods']['is_include_only']['non_html_header_files'] = true;
require ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class ViewMembersHandler extends FormHandler
{
		public function getUserDetailsArrFromDB($table_name, $fields_arr = array(), $user_id)
		{
				$sql = 'SELECT ';
				foreach ($fields_arr as $field_name) $sql .= $field_name . ', ';
				$sql = substr($sql, 0, strrpos($sql, ','));
				$sql .= ' FROM ' . $table_name . ' WHERE user_id=' . $this->dbObj->Param($user_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($user_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = array();
				if ($rs->PO_RecordCount()) $row = $rs->FetchRow();
				$ret_fields_arr = array();
				foreach ($fields_arr as $field_name) $ret_fields_arr[$field_name] = isset($row[$field_name]) ? $row[$field_name] : '';
				return $ret_fields_arr;
		}
		public function setIndexBlockFormField($index_block_arr)
		{
				foreach ($index_block_arr as $value)
				{
						$this->setFormField($value, $this->CFG['admin']['index'][$value]);
				}
		}
		public function populateIndexBlockValues($index_block_value)
		{
				$index_block_value_arr = unserialize($index_block_value);
				if (!is_array($index_block_value_arr)) return;
				foreach ($index_block_value_arr as $key => $value)
				{
						if (!($this->fields_arr[$key] == 'compulsory' or $value == 'compulsory')) $this->fields_arr[$key] = $value;
						else  $this->fields_arr[$key] = $this->CFG['admin']['index'][$key];
				}
		}
		public function populateIndexPageFields($index_block_arr)
		{
				foreach ($index_block_arr as $value)
				{
						$label = $this->LANG[$value];
						if (!$this->isShowIndexBlock($this->CFG['admin']['index'][$value])) continue;
?>
<tr>
	<th><?php echo $label; ?></td>
	<td><?php echo $this->getFormField($value); ?></td>
</tr>
<?php
				}
		}
		public function chkIsValidUser()
		{
				$uid = $this->fields_arr['uid'];
				$sql = 'SELECT 1 FROM ' . $this->CFG['db']['tbl']['users'] . ' WHERE ' . $this->getUserTableField('user_id') . '=' . $this->dbObj->Param($uid);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($uid));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount()) return true;
				return false;
		}
}
$viewmember = new ViewMembersHandler();
$viewmember->makeGlobalize($CFG, $LANG);
$index_block_arr = array('recent_questions', 'popular_questions', 'questions_with_videos', 'questions_with_audios', 'best_of_answer', 'recent_forums', 'forums_with_most_replies', 'recent_blogs', 'blogs_with_most_comment', 'top_analyst', 'featured_analyst');
$viewmember->setPageBlockNames(array('form_search', 'form_settings', 'msg_form_error', 'msg_form_success'));
$viewmember->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$viewmember->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$viewmember->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$viewmember->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$viewmember->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$viewmember->setDBObject($db);
$viewmember->setFormField('subscribe_keywords', '');
$viewmember->setFormField('keyword_mail', '');
$viewmember->setFormField('reply_mail', '');
$viewmember->setFormField('favorite_mail', '');
$viewmember->setFormField('best_ans_mail', '');
$viewmember->setFormField('abuse_mail', '');
$viewmember->setFormField('internal_mail', '');
$viewmember->setFormField('all_email_notification', '');
$viewmember->setFormField('search_question', '');
$viewmember->setFormField('image_path', '');
$viewmember->setFormField('msg', '');
$viewmember->setFormField('uid', '');
$viewmember->setFormField('name', '');
$viewmember->setFormField('password', '');
$viewmember->setFormField('confirm_password', '');
$viewmember->setFormField('email', '');
$viewmember->setFormField('gender', 'Female');
$viewmember->setFormField('bio', '');
$viewmember->setFormField('user_access', '');
$viewmember->setFormField('photo', '');
$viewmember->setFormField('photo_ext', '');
$viewmember->setFormField('photo_server_url', '');
$viewmember->setFormField('index_block', '');
$viewmember->setFormField('avatar', '');
$viewmember->setIndexBlockFormField($index_block_arr);
$viewmember->setDBObject($db);
$viewmember->sanitizeFormInputs($_REQUEST);
$viewmember->setAllPageBlocksHide();
$title = $LANG['viewmembers_title'];
if ($viewmember->chkIsValidUser())
{
		$viewmember->setPageBlockShow('form_settings');
		$user_settings_arr = $viewmember->getUserDetailsArrFromDB($CFG['db']['tbl']['users_ans_log'], array('subscribe_keywords', 'keyword_mail', 'reply_mail', 'favorite_mail', 'best_ans_mail', 'abuse_mail', 'internal_mail', 'index_block'), $viewmember->getFormField('uid'));
		$viewmember->populateIndexBlockValues($user_settings_arr['index_block']);
		$viewmember->setFormField('subscribe_keywords', $user_settings_arr['subscribe_keywords']);
		$viewmember->setFormField('keyword_mail', $user_settings_arr['keyword_mail']);
		$viewmember->setFormField('reply_mail', $user_settings_arr['reply_mail']);
		$viewmember->setFormField('favorite_mail', $user_settings_arr['favorite_mail']);
		$viewmember->setFormField('best_ans_mail', $user_settings_arr['best_ans_mail']);
		$viewmember->setFormField('abuse_mail', $user_settings_arr['abuse_mail']);
		$viewmember->setFormField('internal_mail', $user_settings_arr['internal_mail']);
		$user_details_arr = $viewmember->getUserDetailsFromUsersTable($CFG['db']['tbl']['users'], $viewmember->getFormField('uid'));
		$viewmember->setFormField('image_path', $user_details_arr['image_path']);
		$viewmember->setFormField('name', $user_details_arr['name']);
		$viewmember->setFormField('email', $user_details_arr['email']);
		$viewmember->setFormField('bio', $user_details_arr['bio']);
		$viewmember->setFormField('gender', $user_details_arr['gender']);
		$viewmember->setFormField('user_access', $user_details_arr['user_access']);
}
else
{
		$viewmember->setPageBlockShow('msg_form_error');
		$viewmember->setCommonErrorMsg($LANG['err_tip_invalid_user']);
}
$CFG['mods']['is_include_only']['non_html_header_files'] = false;
$CFG['mods']['is_include_only']['html_header'] = true;
require ($CFG['site']['project_path'] . 'common/application_top.inc.php');
?>
<div id="selListAll">
	<h2 class="clsManageAnswers"><?php echo $title; ?></h2>
<?php
if ($viewmember->isShowPageBlock('form_settings'))
{
?>
	<p><a href="editMembers.php?uid=<?php echo $viewmember->getFormField('uid'); ?>"><?php echo $LANG['edit_this_member']; ?></a></p>
<?php
}
if ($viewmember->isShowPageBlock('msg_form_error'))
{
?>
    	<div id="selMsgError">
      		<p>
<?php
		echo $LANG['editmembers_err_sorry'] . ' ' . $viewmember->getCommonErrorMsg();
?>
      		</p>
    	</div>
<?php
}
if ($viewmember->isShowPageBlock('msg_form_success'))
{
?>
	    <div id="selMsgSuccess">
	      	<p>
<?php
		echo $viewmember->getCommonSuccessMsg();
?>
	      	</p>
	    </div>
    <?php
}
if ($viewmember->isShowPageBlock('form_settings'))
{
?>
	<form name="form_view_settings" id="form_view_settings" method="post" action="<?php echo URL($_SERVER['REQUEST_URI']); ?>">
		<table summary="<?php echo $LANG['editmembers_tbl_summary']; ?>" class="clsManageSettings">
          <tr>
            <th colspan="2"><?php echo $LANG['signup_personal']; ?></th>
          </tr>
<?php
		if (chkUserImageAllowed())
		{
?>
			<tr>
				<th>&nbsp;</th>
				<td class="clsFormFieldCellDefault">
					<div id="selUserImage">
					<?php
				if (($user_details_arr['photo_server_url'] and $user_details_arr['photo_ext']) or $user_details_arr['image_path'])
				{
?>
						<p id="selImageBorder"><?php displayUserImage($user_details_arr, 'thumb', false); ?></p>
					<?php
				}
?>
					</div>
				</td>
			</tr>
<?php
		}
?>
          <tr>
            <th><?php echo $LANG['signup_email']; ?></th>
            <td><?php echo $viewmember->getFormField('email'); ?></td>
          </tr>
          <tr>
            <th><?php echo $LANG['view_username']; ?></th>
            <td><?php echo $viewmember->getFormField('name'); ?></td>
          </tr>
          <tr>
            <th><?php echo $LANG['view_password']; ?></th>
            <td>*********</td>
          </tr>
          <tr>
            <th><?php echo $LANG['signup_sex']; ?></th>
            <td><?php echo $viewmember->getFormField('gender'); ?></td>
          </tr>
          <tr>
            <th><?php echo $LANG['signup_user_access']; ?></th>
            <td><?php echo $viewmember->getFormField('user_access'); ?></td>
          </tr>
          <tr>
            <th><?php echo $LANG['signup_bio']; ?></th>
            <td><?php echo nl2br($viewmember->getFormField('bio')); ?></td>
          </tr>
		  <tr>
			<th><?php echo $LANG['editmembers_subscribe_keywords']; ?></th>
			<td><?php echo $viewmember->getFormField('subscribe_keywords'); ?></td>
		   </tr>

		   <tr><td colspan="2"></td></tr>
		   <tr>
		   		<th colspan="2"><?php echo $LANG['editmembers_all_email_notification']; ?></td>
		   </tr>
		   <tr>
				<th><?php echo $LANG['editmembers_keyword_mail']; ?></th>
				<td><?php echo $viewmember->getFormField('keyword_mail'); ?></td>
		   </tr>
		   <tr>
				<th><?php echo $LANG['editmembers_reply_mail']; ?></th>
				<td><?php echo $viewmember->getFormField('reply_mail'); ?></td>
		   </tr>
		   <tr>
				<th><?php echo $LANG['editmembers_favorite_mail']; ?></th>
				<td><?php echo $viewmember->getFormField('favorite_mail'); ?></td>
		   </tr>
		   <tr>
				<th><?php echo $LANG['editmembers_best_answer_mail']; ?></th>
				<td><?php echo $viewmember->getFormField('best_ans_mail'); ?></td>
		   </tr>
		   <tr>
				<th><?php echo $LANG['editmembers_abuse_mail']; ?></th>
				<td><?php echo $viewmember->getFormField('abuse_mail'); ?></td>
		   </tr>
		   <tr>
				<th><?php echo $LANG['editmembers_internal_mail']; ?></th>
				<td><?php echo $viewmember->getFormField('internal_mail'); ?></td>
		   </tr>

			<tr><td colspan="2"></td></tr>
		   <tr>
		   		<th colspan="2"><?php echo $LANG['index_block_settings']; ?></td>
		   </tr>
		   <?php $viewmember->populateIndexPageFields($index_block_arr); ?>
		</table>
	</form>
<?php
}
?>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>