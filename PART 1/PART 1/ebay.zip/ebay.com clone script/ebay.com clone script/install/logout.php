<?php //00461
// Copyright Notice
// Web Site URL:  http://www.zeeways.com
// Script Owner eMail: mail@zeeways.com
// Date: April, 2007
// Script Name: Zeeways Auction Website PHP Script
// Copyright Details: This script is not free.  Do not Remove this Copy Right notice.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the site administrator.');exit(199);
?>
4+oV54pCxhAjADE5l7PxaQ/1CZDv8o87nCbm6UzAVdNH4b6lTyugGqeaL+JL1ufX7tQZfejQO9Il
z0A2++ZCpg9pEEa03ZqmppqkrAr6Y/GMB0NmTmffyn2cwU0dNj837B03XlvmuQZl0qF7LBzTqzMI
CsoUScTwtolPWFi4y0JHyQUxa95V3Djge8KFIR3VtZztUHpb9DjMcPI2cQq6727QzAXyLkVZRV0x
nt9m+9/v2uycoCC6CTAR94IMfZGCJ7FtBQv9VhQQS163P6HpGXNjE82ysW90d0aU3q35IEX+amK9
Zsux7z3lRLcikRsQpZDtqSrm6UOwdY3lqvvAOGSEqDmPbhh5xHyYGorKg9M+7ig3cUpbD8y1m49v
cQI3q19m9jQy+hBPKUagHk2B2eJLzBg1p6kKxasYiWqm0pFj4ylTSGW0aFIrT2Krs5wta733LLRl
FsejoNdmCNBVV8MH0S5d4yiQg66JXkLEa8YUd/AJwFobLTV51VNPYaGFYwGRHf+VDX6d99V9Fvug
IsmS2hEPSq+1nJ7KFZaDV8NUZQcmHMGCg0==