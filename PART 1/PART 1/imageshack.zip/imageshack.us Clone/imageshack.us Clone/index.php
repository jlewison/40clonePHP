<?
include "config.php";
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html><head><title>ImageShack� - Hosting</title>




<link rel="stylesheet" href="ImageShack%AE%20-%20Hosting_elemei/style-def.css" type="text/css">

<link rel="shortcut icon" href="http://imageshack.modthisname.spiderhost.hu/favicon.ico" type="image/x-icon">
</head><body bgcolor="#f7f7f7"><table align="center" border="0" cellpadding="0" cellspacing="0" width="760"><tbody><tr><td><a href="http://imageshack.modthisname.spiderhost.hu"><img alt="ImageShack� Logo" src="ImageShack%AE%20-%20Hosting_elemei/imageshack.png" title=""></a></td>
<td align="left" valign="bottom">
<b><a href="#">ImageShack Clone &reg;</a>
 | <a href="#">Link</a> | <a href="#">Link</a>
 | <a href="#">Link</a>
 | <a href="#">Link</a>
 | <a href="#">LINK</a> | <a href="#">Link</a> </b></td>
</tr></tbody></table>
<table class="table_decoration" align="center" border="1" bordercolor="#cccccc" cellpadding="5" width="760"><tbody><tr><td valign="top"><!-- BEGIN STANDARD TAG - 300 x 250 - imageshack: Medium Rectangle - DO NOT MODIFY -->
<script type="text/javascript" src="ImageShack%AE%20-%20Hosting_elemei/rmtag3.js"></script>
<script language="JavaScript">
var rm_host = "http://ad.yieldmanager.com";
var rm_section_id = 62324;
var rm_iframe_tags = 1;

rmShowAd("300x250");
</script>
<!-- END TAG -->

</td><td valign="top"><p>ImageShack's mission is to provide an easy-to-use image hosting service.</p><p>Read the <a href="http://reg.imageshack.us/content.php?page=rules"><b>Terms of Service</b></a> and Bookmark <a rel="sidebar" title="ImageShack� - Sidebar" href="http://imageshack.modthisname.spiderhost.hu/index4.php" onClick="window.external.AddFavorite(location.href,document.title);window.sidebar.addPanel(document.title,location.href,'');"><b>ImageShack's Sidebar</b></a>.</p><p><b><a href="http://reg.imageshack.us/content.php?page=faq">New to ImageShack</a></b>? Start an <a href="http://imageshack.modthisname.spiderhost.hu/slideshow/"><b>Image Slideshow</b></a>, or upload now:</p><br>
  <form method="post" enctype="multipart/form-data" action="basic.php">
    <div align="center"> <br>
    upload: file
    <label>
    <input name="radiobutton" type="radio" value="radiobutton" checked>
&nbsp;&nbsp;&nbsp;&nbsp;    &nbsp;&nbsp;    </label>
    <INPUT NAME="userfile" TYPE="file" class="asd" size="27">
    <br>
        <br>
        <input name="upload" type="submit" class="asd" value="Host It !">
        &nbsp;
        </p>
  </div></form>
  <p>
    <input name="MAX_FILE_SIZE" value="3145728" type="hidden">
    <input name="refer" value="" type="hidden">
    <input name="brand" value="" type="hidden">
    </p>
  <div id="filetypeerror" style="display: none;"> <b style="color: red;">Please select only one of the supported file types:</b><br></div>
<p>allowed: <b>jpg jpeg png gif bmp tif tiff swf</b> &lt; <b><? print("$max_size"); ?> kilobytes</b><em> (a.k.a <? print("$max_size_mb"); ?> megabytes)</em> </p>
<p>Learn about the <b><a href="http://toolbar.imageshack.us/">ImageShack Toolbar</a></b> now!
  </form>
</td>
</tr></tbody></table>
<div class="links" align="center">
<a href="http://reg.imageshack.us/content.php?page=rules">Copyright</a> &copy; 2003-2006 <a href="http://reg.imageshack.us/content.php?page=aboutus">ImageShack Corp</a>. All
rights reserved. <a href="http://reg.imageshack.us/content.php?page=linkto">Link to ImageShack</a>
<br>
<a href="http://reg.imageshack.us/content.php?page=email&amp;q=marketing">Marketing Opportunities</a> |
<a href="http://reg.imageshack.us/content.php?page=email&amp;q=abuse">Report Abuse or Request Deletion</a> |
<a href="http://reg.imageshack.us/content.php?page=email&amp;q=customer">Customer Service</a>
<br>
<a href="http://reg.imageshack.us/content.php?page=email">Contact ImageShack</a>

</div>

<table class="table_decoration" align="center" border="0" cellpadding="3" cellspacing="0" width="385"><tbody><tr><td>
<p>Learn more about the <b><a href="http://toolbar.imageshack.us/">ImageShack Toolbar</a></b> now!</p>
<p><a href="http://toolbar.imageshack.us/"><img src="ImageShack%AE%20-%20Hosting_elemei/toolbar_img.png"></a></p>

</td></tr></tbody></table> <br>

<table class="table_decoration" align="center" border="0" cellpadding="5" cellspacing="0" width="300"><tbody><tr><td>



</td></tr></tbody></table>
<div class="don" style="color: rgb(204, 204, 204);">
	<div align="right">
		img301 at 38.99.76.172<br>
		<div style="color: rgb(247, 247, 247);">
			yieldmanager<br>yieldmanager
		</div>
	</div>
</div>
</body></html>