<?php
if ( !defined( 'SMARTY_DIR' ) ) {
	include_once( '../init.php' );
}

include ( 'sessioninc.php' );

define( 'PAGE_ID', 'snaps_require_approval' );

if ( !checkAdminPermission( PAGE_ID ) ) {

	header( 'location: not_authorize.php' );
	exit;
}

if ($_REQUEST['action'] == get_lang('Delete')) {
/* delete picture */

	$sql = 'select * from ! where id=?';

	$row=$db->getRow( $sql, array( USER_SNAP_TABLE, $_REQUEST['picid'] ) );

	if (substr_count($row['picture'],'file:') > 0) {
		/* The picture is in file system */
		$imgfile = ltrim(rtrim(str_replace('file:',USER_IMAGE_DIR,$row['picture']) ) );
		unlink($imgfile);
	}
	if (substr_count($row['tnpicture'],'file:') > 0) {
		/* The picture is in file system */
		$imgfile = ltrim(rtrim(str_replace('file:',USER_IMAGE_DIR,$row['tnpicture']) ) );
		unlink($imgfile);
	}

	$db->query('delete from ! where id=?',array(USER_SNAP_TABLE, $_REQUEST['picid'] ) );

	$t->assign('errormsg',get_lang('pic_deleted'));
}


/* Now select the pictures for the requested user */
$sql = 'select id, username, firstname, lastname from ! where id = ?';

$user = $db->getRow( $sql, array( USER_TABLE, $_REQUEST['userid'] ) );

$sql = 'select id, userid, picno, album_id from ! where userid = ? order by picno';

$pics = $db->getAll( $sql, array( USER_SNAP_TABLE, $_REQUEST['userid'] ) );

$albs = $db->getAll('select id, name from ! order by name', array( USERALBUMS_TABLE ) );

$albums = array();

$albums['0'] = 'Public';

foreach ($albs as $albm) {
	$albums[$albm['id']] = $albm['name'];
}

$t->assign('albums', $albums);

$user_pics = array();

foreach ( $pics as $row ) {

	$row['username'] = $user['username'];

	$row['fullname'] = $user['firstname'] . ' '. $user['lastname'];

	if ($row['album_id']=='') $row['album_id'] = '0';

	$user_pics[] = $row;
}

//print_r($user_pics);
$t->assign('user_pics', $user_pics);

$t->assign('userrec',$user);

$t->assign('rendered_page', $t->fetch('admin/showpics.tpl'));

$t->display('admin/index.tpl');

?>