<?

require_once( 'Thing.php' );

class BxDolMistake extends Thing
{

// private variables
	
	var $_error;							// current error string

// public functions

	/**
	 * constructor
	 */
	function BxDolMistake()
	{
	}


	/**
	 *	set error string for the object
	 */
	
	function log ()
	{
		
	}	


	function displayError ()
	{
		
	}
	


	/**
	 * returns page XML
	 */
	/*
	function getErrorPageXML ()
	{
		
	}
	*/

// private functions


}

?>