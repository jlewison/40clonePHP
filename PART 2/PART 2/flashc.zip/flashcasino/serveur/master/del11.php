<? include ("header.php");
mysql_query("DELETE FROM produit WHERE nomp='$nomp'");

echo "<script>document.location.href='boutique.php'; </script>";

include ("footer.php"); 
?>