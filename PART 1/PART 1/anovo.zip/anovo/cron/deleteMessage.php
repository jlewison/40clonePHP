<?php
require_once ('../common/config.inc.php');
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['auth']['is_authenticate'] = false;
$CFG['html']['is_use_footer'] = false;
$CFG['mods']['is_include_only']['non_html_header_files'] = true;
ini_set('max_execution_time', 0);
require ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class DeleteMessageFormHandler extends FormHandler
{
		public function getCronMasterDetails($table_name, $cron_for)
		{
				$sql = 'SELECT upto_id FROM ' . $table_name . ' WHERE cron_for = ' . $this->dbObj->Param($cron_for) . ' AND status = \'Started\' limit 0,1';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($cron_for));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount())
				{
						$row = $rs->FetchRow();
						return $row;
				}
				return false;
		}
		public function updateCronMaster($table_name, $cron_for, $status, $new_old, $upto = 0, $total = 0)
		{
				$val_arr = array();
				$val_arr[] = $status;
				$sql = 'UPDATE ' . $table_name . ' SET ' . 'status=' . $this->dbObj->Param($status);
				$sql .= ', upto_id = ' . $this->dbObj->Param($upto);
				$val_arr[] = $upto;
				if ($total == 0) $sql .= ', total = ' . $this->dbObj->Param($total);
				else  $sql .= ', total = total + ' . $this->dbObj->Param($total);
				$val_arr[] = $total;
				if ($new_old == 'new')
				{
						$sql .= ', start_time = ' . $this->dbObj->SQLDate('Y-m-d H:i:s');
						$sql .= ', tot_finished_crons = tot_finished_crons + 1';
				}
				$sql .= ' WHERE cron_for = ' . $this->dbObj->Param($cron_for);
				$val_arr[] = $cron_for;
				$stmt = $this->dbObj->Prepare($sql);
				$result = $this->dbObj->Execute($stmt, $val_arr);
				if (!$result) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function deleteMessages($upto_id, $check_count)
		{
				$sql = 'SELECT info_id, message_id' . ' FROM ' . $this->CFG['db']['tbl']['messages_info'] . ' WHERE info_id > ' . $this->dbObj->Param($upto_id) . ' AND to_delete=\'Yes\' AND from_delete=\'Yes\'' . ' ORDER BY info_id limit 0,' . $this->dbObj->Param($check_count);
				$stmt = $this->dbObj->Prepare($sql);
				$rsques = $this->dbObj->Execute($stmt, array($upto_id, $check_count));
				if (!$rsques) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($count = $rsques->PO_RecordCount())
				{
						while ($rowques = $rsques->FetchRow())
						{
								$ret_arr = array('info_id' => $rowques['info_id'], 'count' => $count);
								$this->deleteFromMessagesInfoTable($rowques['info_id']);
								$this->deleteFromMessagesTable($rowques['message_id']);
						}
						return $ret_arr;
				}
				return false;
		}
		public function deleteFromMessagesInfoTable($info_id)
		{
				$sql = 'DELETE FROM ' . $this->CFG['db']['tbl']['messages_info'] . ' WHERE info_id=' . $this->dbObj->Param($info_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($info_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function deleteFromMessagesTable($message_id)
		{
				$sql = 'DELETE FROM ' . $this->CFG['db']['tbl']['messages'] . ' WHERE message_id=' . $this->dbObj->Param($message_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($message_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
}
$reminder = new DeleteMessageFormHandler();
$reminder->setDBObject($db);
$reminder->setCfgLangGlobal($CFG, $LANG);
$reminder->member_url = $CFG['site']['url'] . $CFG['redirect']['member'] . '/';
if ($cron_arr = $reminder->getCronMasterDetails($CFG['db']['tbl']['cron_master'], 'Message'))
{
		if ($autoindex_arr = $reminder->deleteMessages($cron_arr['upto_id'], $CFG['messages']['send_count'])) $reminder->updateCronMaster($CFG['db']['tbl']['cron_master'], 'Message', 'Started', 'old', $autoindex_arr['info_id'], $autoindex_arr['count']);
		else  $reminder->updateCronMaster($CFG['db']['tbl']['cron_master'], 'Message', 'Started', 'new');
}
else  $reminder->updateCronMaster($CFG['db']['tbl']['cron_master'], 'Message', 'Started', 'new');
require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>
