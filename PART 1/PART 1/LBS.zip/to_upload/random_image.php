<?php include('settings.php');
session_start();
//this function is called recursivelly 
$len = "$chp_leng";

if($chp_typ == 'A') {
function random_string($len, $str='')
{
  for($i=1; $i<=$len; $i++)
   {
    //generates a random number that will be the ASCII code of the character. We only want numbers (ascii code from 48 to 57) and caps letters. 
    $ord=rand(65, 90);
    if((($ord >= 65) && ($ord <= 90)))
        $str.=chr($ord);
    //If the number is not good we generate another one
    else
        $str.=random_string(1);
  }
  return $str; 
}
}
elseif($chp_typ == 'N') {
function random_string($len, $str='')
{
  for($i=1; $i<=$len; $i++)
   {
    //generates a random number that will be the ASCII code of the character. We only want numbers (ascii code from 48 to 57) and caps letters. 
    $ord=rand(48, 57);
    if((($ord >= 48) && ($ord <= 57)))
        $str.=chr($ord);
    //If the number is not good we generate another one
    else
        $str.=random_string(1); 
  }
  return $str;
}
}
else {
function random_string($len, $str='')
{
  for($i=1; $i<=$len; $i++)
   {
    //generates a random number that will be the ASCII code of the character. We only want numbers (ascii code from 48 to 57) and caps letters. 
    $ord=rand(48, 90);
    if((($ord >= 48) && ($ord <= 57)) || (($ord >= 65) && ($ord <= 90)))
        $str.=chr($ord);
    //If the number is not good we generate another one
    else
        $str.=random_string(1); 
  }
  return $str;
}
}

//create the random string using the upper function (if you want more than 5 characters just modify the parameter)
$rand_str=random_string($chp_leng);

//We memorize the md5 sum of the string into a session variable
$_SESSION['image_value'] = md5($rand_str);

//Get each letter in one valiable, we will format all letters different
$letter1=substr($rand_str,0,1);
$letter2=substr($rand_str,1,1);
$letter3=substr($rand_str,2,1);
$letter4=substr($rand_str,3,1);
$letter5=substr($rand_str,4,1);
$letter6=substr($rand_str,5,1);
$letter7=substr($rand_str,6,1);

//Creates an image from a png file. If you want to use gif or jpg images, just use the coresponding functions: imagecreatefromjpeg and imagecreatefromgif.

if($chp_distors == '1') {
$image=imagecreatefrompng("img/noise1.png");
}
elseif($chp_distors == '2') {
$image=imagecreatefrompng("img/noise2.png");
}
elseif($chp_distors == '3') {
$image=imagecreatefrompng("img/noise3.png");
}
elseif($chp_distors == '4') {
$image=imagecreatefrompng("img/noise4.png");
}
elseif($chp_distors == '5') {
$image=imagecreatefrompng("img/noise5.png");
}
elseif($chp_distors == '6') {
$image=imagecreatefrompng("img/noise6.png");
}
else{
$image=imagecreatefrompng("img/noise7.png");
}

//Get a random angle for each letter to be rotated with.
$angle1 = rand(-$chp_simp, $chp_simp);
$angle2 = rand(-$chp_simp, $chp_simp);
$angle3 = rand(-$chp_simp, $chp_simp);
$angle4 = rand(-$chp_simp, $chp_simp);
$angle5 = rand(-$chp_simp, $chp_simp);
$angle6 = rand(-$chp_simp, $chp_simp);
$angle7 = rand(-$chp_simp, $chp_simp);

//Get a random font. (In this examples, the fonts are located in "fonts" directory and named from 1.ttf to 10.ttf)
$font1 = "fonts/".rand(1, 6).".ttf";
$font2 = "fonts/".rand(1, 6).".ttf";
$font3 = "fonts/".rand(1, 6).".ttf";
$font4 = "fonts/".rand(1, 6).".ttf";
$font5 = "fonts/".rand(1, 6).".ttf";
$font6 = "fonts/".rand(1, 6).".ttf";
$font7 = "fonts/".rand(1, 6).".ttf";

//Define a table with colors (the values are the RGB components for each color).
$colors[0]=array(255,0,0);
$colors[1]=array(255,153,204);
$colors[2]=array(0,255,0);
$colors[3]=array(255,255,0);
$colors[4]=array(255,102,0);
$colors[5]=array(0,255,255);
$colors[6]=array(0,0,0);
$colors[7]=array(102,51,153);

//Get a random color for each letter.
$color1=rand(0, 5);
$color2=rand(0, 5);
$color3=rand(0, 5);
$color4=rand(0, 5);
$color5=rand(0, 5);
$color6=rand(0, 5);
$color7=rand(0, 5);

//Allocate colors for letters.
$textColor1 = imagecolorallocate ($image, $colors[$color1][0],$colors[$color1][1], $colors[$color1][2]);
$textColor2 = imagecolorallocate ($image, $colors[$color2][0],$colors[$color2][1], $colors[$color2][2]);
$textColor3 = imagecolorallocate ($image, $colors[$color3][0],$colors[$color3][1], $colors[$color3][2]);
$textColor4 = imagecolorallocate ($image, $colors[$color4][0],$colors[$color4][1], $colors[$color4][2]);
$textColor5 = imagecolorallocate ($image, $colors[$color5][0],$colors[$color5][1], $colors[$color5][2]);
$textColor6 = imagecolorallocate ($image, $colors[$color6][0],$colors[$color6][1], $colors[$color6][2]);
$textColor7 = imagecolorallocate ($image, $colors[$color7][0],$colors[$color7][1], $colors[$color7][2]);

if($chp_distors == '3') {
	$x = 216;
	$y = 100;
	$gd = imagecreatetruecolor($x, $y);
	
	$size = 30;
	imagettftext($gd, $size, $angle1, 10, $size+30, $textColor1, $font1, $letter1);
	imagettftext($gd, $size, $angle2, 40, $size+30, $textColor2, $font2, $letter2);
	imagettftext($gd, $size, $angle3, 70, $size+30, $textColor3, $font3, $letter3);
	imagettftext($gd, $size, $angle4, 90, $size+30, $textColor4, $font4, $letter4);
	imagettftext($gd, $size, $angle5, 120, $size+30, $textColor5, $font5, $letter5);
	imagettftext($gd, $size, $angle6, 150, $size+30, $textColor6, $font6, $letter6);
	imagettftext($gd, $size, $angle7, 180, $size+30, $textColor7, $font7, $letter7);
		for ($i = 0; $i < 216 * 100 / 20; $i++)
		{
		 $white = imagecolorallocate ($gd, 255, 255, 255);
		 imagesetpixel ($gd, mt_rand (0, 216), mt_rand (0, 100), $white);
		}
	header('Content-Type: image/png');
	imagepng($gd);
}
elseif($chp_distors == '4') {
	$x = 216;
	$y = 100;
	$gd = imagecreatetruecolor($x, $y);
	$size = 30;
	imagettftext($gd, $size, $angle1, 10, $size+30, $textColor1, $font1, $letter1);
	imagettftext($gd, $size, $angle2, 40, $size+30, $textColor2, $font2, $letter2);
	imagettftext($gd, $size, $angle3, 70, $size+30, $textColor3, $font3, $letter3);
	imagettftext($gd, $size, $angle4, 90, $size+30, $textColor4, $font4, $letter4);
	imagettftext($gd, $size, $angle5, 120, $size+30, $textColor5, $font5, $letter5);
	imagettftext($gd, $size, $angle6, 150, $size+30, $textColor6, $font6, $letter6);
	imagettftext($gd, $size, $angle7, 180, $size+30, $textColor7, $font7, $letter7);

		for ($i = 0; $i < 216 * 100 / 20; $i++)
		{
		 $white = imagecolorallocate ($gd, 255, 255, 255);
		 imagesetpixel ($gd, mt_rand (0, 216), mt_rand (0, 100), $white);
		}

			$wavenum = 4;
			$wavemultiplier = ($wavenum * 360) / 216 ;
			$curX = 0;
			$curY = 0;
				for ($pt = 0; $pt < 216 ; $pt++)
				{
					$newX = $curX + 1;
					$newY = (100 /2) + (sin (deg2rad ($newX * $wavemultiplier - 90)) * (100 / 2));
					$white = imagecolorallocate ($gd, 255, 255, 255);
					imageline ($gd, $curX, $curY, $newX, $newY, $white);
					$curX = $newX;
					$curY = $newY;
				}
				
			$wavenum = 4;
			$wavemultiplier = ($wavenum * 360) / 216 ;
			$curX = 0;
			$curY = 100 ;
				for ($pt = 0; $pt < 216 ; $pt++)
				{
					$newX = $curX + 1;
					$newY = (195 / 2) + (cos (deg2rad ($newX * $wavemultiplier)) * (100 /2));
					$white = imagecolorallocate ($gd, 255, 255, 255);
					imageline ($gd, $curX, $curY, $newX, $newY, $white);
					$curX = $newX;
					$curY = $newY;
				}
				
	header('Content-Type: image/png');
	imagepng($gd);
}
elseif($chp_distors == '5') {
	$x = 216;
	$y = 100;
	$gd = imagecreatetruecolor($x, $y);
	$size = 30;
	imagettftext($gd, $size, $angle1, 10, $size+30, $textColor1, $font1, $letter1);
	imagettftext($gd, $size, $angle2, 40, $size+30, $textColor2, $font2, $letter2);
	imagettftext($gd, $size, $angle3, 70, $size+30, $textColor3, $font3, $letter3);
	imagettftext($gd, $size, $angle4, 90, $size+30, $textColor4, $font4, $letter4);
	imagettftext($gd, $size, $angle5, 120, $size+30, $textColor5, $font5, $letter5);
	imagettftext($gd, $size, $angle6, 150, $size+30, $textColor6, $font6, $letter6);
	imagettftext($gd, $size, $angle7, 180, $size+30, $textColor7, $font7, $letter7);

		for ($i = 0; $i < 216 * 100 / 20; $i++)
		{
		 $white = imagecolorallocate ($gd, 255, 255, 255);
		 imagesetpixel ($gd, mt_rand (0, 216), mt_rand (0, 100), $white);
		}

			$wavenum = 4;
			$wavemultiplier = ($wavenum * 360) / 216 ;
			$curX = 0;
			$curY = 0;
				for ($pt = 0; $pt < 216 ; $pt++)
				{
					$newX = $curX + 1;
					$newY = (100 /2) + (sin (deg2rad ($newX * $wavemultiplier - 90)) * (100 / 2));
					$white = imagecolorallocate ($gd, 255, 255, 255);
					imageline ($gd, $curX, $curY, $newX, $newY, $white);
					$curX = $newX;
					$curY = $newY;
				}
				
			$wavenum = 4;
			$wavemultiplier = ($wavenum * 360) / 216 ;
			$curX = 0;
			$curY = 100 ;
				for ($pt = 0; $pt < 216 ; $pt++)
				{
					$newX = $curX + 1;
					$newY = (195 / 2) + (cos (deg2rad ($newX * $wavemultiplier)) * (100 /2));
					$white = imagecolorallocate ($gd, 255, 255, 255);
					imageline ($gd, $curX, $curY, $newX, $newY, $white);
					$curX = $newX;
					$curY = $newY;
				}


for ($i = 0; $i <= 100 ; $i += 10)
{
	$white = imagecolorallocate ($gd, 255, 255, 255);
	imageline ($gd, 0, $i, 216 , $i, $white);
}
	header('Content-Type: image/png');
	imagepng($gd);
}
else {
	//Write text to the image using TrueType fonts.
	$size = 30;
	imagettftext($image, $size, $angle1, 10, $size+30, $textColor1, $font1, $letter1);
	imagettftext($image, $size, $angle2, 40, $size+30, $textColor2, $font2, $letter2);
	imagettftext($image, $size, $angle3, 70, $size+30, $textColor3, $font3, $letter3);
	imagettftext($image, $size, $angle4, 90, $size+30, $textColor4, $font4, $letter4);
	imagettftext($image, $size, $angle5, 120, $size+30, $textColor5, $font5, $letter5);
	imagettftext($image, $size, $angle6, 150, $size+30, $textColor6, $font6, $letter6);
	imagettftext($image, $size, $angle7, 180, $size+30, $textColor7, $font7, $letter7);
	header('Content-type: image/jpeg');
	//Output image to browser
	imagejpeg($image, '', 100);
	//Destroys the image
	imagedestroy($image);
}
?>