<?
include("config.php");
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<head><title>ImageShack� - Linkto</title>



<meta name="Author" content="ImageShack� Corp">
<meta name="Copyright" content="� 2003-2006 ImageShack Corp">
<meta name="Language" content="en">
<link rel="stylesheet" title="User Defined Style" href="content_elemei/imageshack.css" type="text/css">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon"></head><body><table align="center" border="0" cellpadding="0" cellspacing="0" width="760"><tbody><tr><td>
<? include("header.php"); ?>

</tr></td></table>
<div id="container"><b>:: linkto :: </b><br><br><p>Use this code to link to ImageShack on your forum signature or website!</p>


<img src="content_elemei/iss1.png">&nbsp;<img src="content_elemei/iss2.png">&nbsp;<img src="content_elemei/iss3.png">&nbsp;<img src="content_elemei/iss4.png"><p>Small Button Code for websites. Replace the iss1.png with numbers up to iss4.png for various buttons.</p>
<p><input style="width: 700px;" size="70" value="&lt;a href=&quot;<? echo $domain; ?>&quot;&gt;&lt;img src=&quot;<? echo $domain; ?>/img/iss1.png&quot; border=&quot;0&quot; /&gt;&lt;/a&gt;" type="text">
</p><p>Small Button Code for signatures. Replace the iss1.png with numbers up to iss4.png for various buttons.</p>
<p><input style="width: 700px;" size="70" value="[URL=<? echo $domain; ?>][IMG]<? echo $domain; ?>/img/iss1.png[/IMG][/URL]" type="text">
</p>

<img src="content_elemei/is1.gif">&nbsp;<img src="content_elemei/is2.gif">&nbsp;<img src="content_elemei/is3.gif">&nbsp;<img src="content_elemei/is4.gif">&nbsp;<img src="content_elemei/is5.gif">&nbsp;<img src="content_elemei/is6.gif">&nbsp;<img src="content_elemei/is7.gif">&nbsp;<img src="content_elemei/is8.gif">
<p>Button Code for websites. Replace the is1.gif with numbers up to is8.gif for various buttons.</p>
<p><input style="width: 700px;" size="70" value="&lt;a href=&quot;<? echo $domain; ?>&quot;&gt;&lt;img src=&quot;<? echo $domain; ?>/img/is1.gif&quot; border=&quot;0&quot; /&gt;&lt;/a&gt;" type="text">
</p>
<p>Button Code for signatures. Replace the is1.gif with numbers up to is8.gif for various buttons.</p>
<p><input style="width: 700px;" size="70" value="[URL=<? echo $domain; ?>][IMG]<? echo $domain; ?>/img/is1.gif[/IMG][/URL]" type="text">
</p>
<p><img src="content_elemei/imageshackbanner.gif"></p>
<p>Banner Code for websites.</p>
<p><input style="width: 700px;" size="70" value="&lt;a href=&quot;<? echo $domain; ?>&quot;&gt;&lt;img src=&quot;<? echo $domain; ?>/img/imageshackbanner.gif&quot; border=&quot;0&quot; /&gt;&lt;/a&gt;" type="text">
</p>
<p>Banner code for signatures.</p>
<p><input style="width: 700px;" size="70" value="[URL=<? echo $domain; ?>][IMG]<? echo $domain; ?>/img/imageshackbanner.gif[/IMG][/URL]" type="text">
</p>
<p><img src="content_elemei/imageshack.png"></p>
<p>Frog Code for websites.</p>
<p><input style="width: 700px;" size="70" value="&lt;a href=&quot;<? echo $domain; ?>&quot;&gt;&lt;img src=&quot;<? echo $domain; ?>/img/imageshack.png&quot; border=&quot;0&quot; /&gt;&lt;/a&gt;" type="text">
</p>
<p>Frog Code for signatures.</p>
<p><input style="width: 700px;" size="70" value="[URL=<? echo $domain; ?>][IMG]<? echo $domain; ?>/img/imageshack.png[/IMG][/URL]" type="text">
</p>

</div><div class="links" align="center">
<? include("footer.php"); ?>
</div>
<div class="don" style="color: rgb(204, 204, 204);">
	<div align="right">
		 at <br>
		<div style="color: rgb(247, 247, 247);">
			
		</div>
	</div>
      </div>

</body></html>