<?
error_reporting(0);
include ("../setup.php");
$resultg=mysql_query("select * from seting ");
$rog=mysql_fetch_array($resultg);
$Users = array($rog[0] => $rog[1]);
session_start();
session_register("SESSION");
if (! isset($SESSION)) {
$SESSION = array();
}
if($event=='exit') {
unset ($SESSION["password"]);
unset ($SESSION["username"]);
}
if($enter) {
$SESSION["username"] = $user;
$SESSION["password"] = $passw;
}
$username = $SESSION["username"];
$password = $SESSION["password"];
$dd = array_search($password, $Users);
?>

<style type=text/css>
input { FONT-FAMILY: MS Sans Serif; FONT-SIZE: 10px; }
select { FONT-FAMILY: MS Sans Serif; FONT-SIZE: 10px; }
a:hover { color: #86869B }
a:visited { color: navy }
a { color: navy }
a:active { color: #ff0000 }
body { FONT-FAMILY: Times New Roman; FONT-SIZE: 13pt; COLOR: #1F1F1F; }
</style>

<? if (empty($password) or $dd !== $username) { ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html><head>
<meta http-equiv="content-type" content="text/html; charset=windows-1251" />
<title>admin</title>
<link href="images/default.css" rel="stylesheet" type="text/css" media="screen">
</head>

<body>
<table border="0" align="center" cellpadding="2" cellspacing="0">
<tr>
<td class="bborder">
<table border="0" cellpadding="0" cellspacing="0" width="700">
<tr>
<td align="center" height="24" class="main">
<table border="0" cellspacing="0" cellpadding="5">
<tr>
<td>
</table>
<tr>
<td height="19">
<table border="0" cellpading="0"cellspacing="15" width="100%" height="100%">
<tr>
<td><div class="header"><img border="0" src="images/user.gif" align="absmiddle">�jeuxgagnants</div>
<tr>
<td width="100%" height="100%">
<table border="0" cellspacing="0" cellpadding="1">
 <form action="<?=$PHP_SELF?>" method="post">
  <tr>
   <td width="80">Login  <td><input type="text" name="user" style="width:134">
  <tr>
   <td>Mot de passe   <td><input type="password" name="passw" style="width:134">
  <tr>
   <td>
   <td><input type="submit" name="enter" style="width:134;" value="   Valider   ">
  <tr>
   <td align="center" colspan="3"></td>
  </tr>
 </form>
</table>

</table>
<tr>
<td height="24" align="center" class="copyrights"><div style="font-size: 9px;">Powered by <a style="font-size: 9px" href="http://www.jeuxgagnants.com" target=_blank>xxxxxxxxx</a></div></td>
</table>
</table>

</body>
</html>
<?
die();
}
?>