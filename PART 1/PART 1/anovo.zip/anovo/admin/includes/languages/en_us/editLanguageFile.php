<?php
$LANG['langedit_directory'] = 'Directory';
$LANG['langedit_directory_table'] = 'Directory list Table';
$LANG['langedit_lang_editing'] = 'Language File Editing';
$LANG['langedit_select'] = 'Choose';
$LANG['langedit_err_tip_compulsory'] = 'Compulsory';
$LANG['langedit_file'] = 'File';
$LANG['langedit_files_table'] = 'File list form container';
$LANG['langedit_submit'] = 'Submit';
$LANG['langedit_language'] = 'Language';
$LANG['langedit_edit_table'] = 'Edit language phrases container table';
$LANG['langedit_variable_name'] = 'Variable names';
$LANG['langedit_new_value'] = 'Phrase';
$LANG['langedit_msg_success'] = '%s language phrases updated successfully.';
$LANG['langedit_update'] = 'Update';
$LANG['langedit_err_tip_invalid'] = 'Invalid file';
$LANG['langedit_write_err_tip_invalid'] = 'File do not have write permission';
$LANG['langedit_read_err_tip_invalid'] = 'File do not have read permission';
$LANG['langedit_root'] = 'Root';
$LANG['langedit_members'] = 'Members';
$LANG['langedit_faq'] = 'FAQ';
$LANG['langedit_question'] = 'Questions';
$LANG['langedit_answer'] = 'Answers';
$LANG['langedit_faq_edit_success'] = 'FAQ edited successfully';
$LANG['langedit_faq_delete_note'] = 'You can delete a Q&A by clearing it.';
$LANG['langedit_'] = 'You can delete a Q&A by clearing it.';
$LANG['langedit_add_faq'] = 'Add new Q&A';
?>
