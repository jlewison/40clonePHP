<?php
/**
 * groups Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 12/26/2007
 */
class groupsModel extends Model
{
		//Constructor
		function groupsModel()
		{
				parent::Model();
				$this->userId = $this->session->userdata('user_id');
		}
		function storePhotos($groupId, $newFileName)
		{
				$strSQL = 'UPDATE groups SET group_photo_path = ' . $this->db->escape($newFileName) . ' WHERE group_id =' . $this->db->escape($groupId);
				$this->db->query($strSQL);
		}
		function addMembers($groupId, $receiver, $sender, $memberStatus = 'not sent', $member = true, $receiverMail = '')
		{
				$strSQL = 'SELECT gi.group_id FROM groups_invitation AS gi WHERE gi.sender_id = ' . $sender . ' AND gi.group_id =' . $this->db->escape($groupId) . ' AND gi.receiver_id = ' . $this->db->escape($receiver);
				$condSQL = '';
				if (!$member)
				{
						$condSQL = ' AND receiver_email = ' . $this->db->escape($receiverMail);
				}
				$strSQL .= $condSQL;
				$checkResult = $this->db->query($strSQL);
				if ($checkResult->num_rows() == 0)
				{
						$condSQL = '';
						if (!$member)
						{
								//$condSQL = ', receiver_email =  '. $this->db->escape($receiverMail) . ', invitation_status = "requested"';
								$condSQL = ', receiver_email =  ' . $this->db->escape($receiverMail) . ', invitation_status = "not sent"';
						}
						else
						{
								$condSQL = ', invitation_status = ' . $this->db->escape($memberStatus);
						}
						$strSQL = 'INSERT INTO groups_invitation SET group_id = ' . $this->db->escape($groupId) . ', receiver_id = ' . $this->db->escape($receiver) . ', sender_id = ' . $this->db->escape($sender);
						$strSQL .= $condSQL;
						$this->db->query($strSQL);
						return 1;
				}
				else
				{
						return 0;
				}
		}
		function isGroupMember($groupId, $receiver)
		{
				$strSQL = 'SELECT group_id FROM group_members WHERE group_id = ' . $this->db->escape($groupId) . ' AND receiver_id =' . $this->db->escape($receiver);
				$resSQL = $this->db->query($strSQL);
				$res = ($resSQL->num_rows == 0) ? 0 : 1;
				return $res;
		}
		function getFriendsInvitees($groupId, $userId)
		{
				$strSQL = " SELECT results.friendId,
					IFNULL((SELECT gm.group_member_id FROM group_members as gm WHERE  gm.group_id = '" . $groupId . "' AND gm.receiver_id = results.friendId ),'0') as ismember ,
					IFNULL((SELECT gi.group_invitation_id FROM groups_invitation as gi WHERE gi.sender_id = " . $this->userId . " AND gi.group_id = " . $this->db->escape($groupId) . " AND gi.receiver_id = results.friendId ),'0') as memberstaus,(SELECT username FROM users WHERE user_id = results.friendId limit 0,1) as username
					FROM
					(
					SELECT friend_id AS FriendId FROM `friends_list` WHERE user_id=" . $this->db->escape($userId) . " and approved_status='yes'
					UNION
					SELECT user_id as FriendId FROM `friends_list` WHERE friend_id=" . $this->db->escape($userId) . " and approved_status='yes'
					) as results   ";
				$resSQL = $this->db->query($strSQL);
				$resArray = array();
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[$resRow['friendId']] = $resRow;
						}
				}
				return $resArray;
		}
		function getMembers($groupId, $status = 'not sent')
		{
				$strSQL = 'SELECT gi.group_invitation_id, gi.group_id, gi.sender_id, gi.invitation_status, gi.receiver_id,u.username FROM groups_invitation as gi
						INNER JOIN users as u ON u.user_id = gi.receiver_id AND gi.invitation_status = ' . $this->db->escape($status) . ' AND gi.sender_id = ' . $this->userId . ' AND gi.group_id = ' . $groupId . '
						 UNION
						SELECT gi.group_invitation_id, gi.group_id, gi.sender_id, gi.invitation_status, gi.receiver_id, gi.receiver_email AS username
						FROM groups_invitation AS gi
						WHERE (gi.invitation_status != "sent" OR gi.invitation_status = ' . $this->db->escape($status) . ' )  AND gi.sender_id = ' . $this->userId . '  AND gi.group_id = ' . $groupId . ' AND gi.receiver_email != "" AND gi.receiver_id = "0"';
				$strSQL = 'SELECT gi.group_invitation_id, gi.group_id, gi.sender_id, gi.invitation_status, gi.receiver_id,u.username FROM groups_invitation as gi
						INNER JOIN users as u ON u.user_id = gi.receiver_id AND (gi.invitation_status = ' . $this->db->escape($status) . ' OR gi.invitation_status != "sent" )AND gi.sender_id = ' . $this->userId . ' AND gi.group_id = ' . $groupId . '
						 UNION
						SELECT gi.group_invitation_id, gi.group_id, gi.sender_id, gi.invitation_status, gi.receiver_id, gi.receiver_email AS username
						FROM groups_invitation AS gi
						WHERE (gi.invitation_status != "sent" OR gi.invitation_status = ' . $this->db->escape($status) . ' )  AND gi.sender_id = ' . $this->userId . '  AND gi.group_id = ' . $groupId . ' AND gi.receiver_email != "" AND gi.receiver_id = "0"';
				$resSQL = $this->db->query($strSQL);
				$resArray = array();
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[$resRow['group_invitation_id']] = $resRow;
						}
				}
				return $resArray;
		}
		function getRequests($groupId, $status = 'requested', $start = '', $limit = '')
		{
				/*
				$strSQL 	= 	'SELECT gi.group_invitation_id, gi.group_id, gi.sender_id, gi.invitation_status, gi.receiver_id,u.username FROM groups_invitation as gi
				INNER JOIN users as u ON u.user_id = gi.receiver_id AND  (gi.invitation_status = "requested" OR  gi.invitation_status = "sent") AND gi.group_id = '.$groupId .'
				UNION
				SELECT gi.group_invitation_id, gi.group_id, gi.sender_id, gi.invitation_status, gi.receiver_id, gi.receiver_email AS username
				FROM groups_invitation AS gi
				WHERE (gi.invitation_status = "requested" OR  gi.invitation_status = "sent")  AND gi.group_id = '.$groupId .' AND gi.receiver_email != "" AND gi.receiver_id = "0"';
				*/
				$strSQL = 'SELECT results.group_id , results.receiver_id,results.username
						FROM
						(
						SELECT gi.group_invitation_id, gi.group_id, gi.sender_id, gi.invitation_status, gi.receiver_id,u.username
						FROM groups_invitation as gi
						INNER JOIN users as u ON u.user_id = gi.receiver_id AND (gi.invitation_status = "requested" OR gi.invitation_status = "sent") AND gi.group_id = ' . $this->db->escape($groupId) . '
						UNION
						SELECT gi.group_invitation_id, gi.group_id, gi.sender_id, gi.invitation_status, gi.receiver_id, gi.receiver_email AS username
						FROM groups_invitation AS gi
						WHERE (gi.invitation_status = "requested" OR gi.invitation_status = "sent") AND gi.group_id = ' . $this->db->escape($groupId) . ' AND gi.receiver_email != "" AND gi.receiver_id = "0"
						) as results
						GROUP BY results.group_id , results.receiver_id,results.username  ';
				$strSQL = 'SELECT results.group_id , results.receiver_id,results.username
						FROM
						(
						SELECT gi.group_invitation_id, gi.group_id, gi.sender_id, gi.invitation_status, gi.receiver_id,u.username
						FROM groups_invitation as gi
						INNER JOIN users as u ON u.user_id = gi.receiver_id AND (gi.invitation_status = "requested") AND gi.group_id = ' . $this->db->escape($groupId) . '
						UNION
						SELECT gi.group_invitation_id, gi.group_id, gi.sender_id, gi.invitation_status, gi.receiver_id, gi.receiver_email AS username
						FROM groups_invitation AS gi
						WHERE (gi.invitation_status = "requested") AND gi.group_id = ' . $this->db->escape($groupId) . ' AND gi.receiver_email != "" AND gi.receiver_id = "0"
						) as results
						GROUP BY results.group_id , results.receiver_id,results.username  ';
				//echo $strSQL;
				if (ereg('^[0-9]+$', $start) && ereg('^[0-9]+$', $limit))
				{
						$strSQL .= ' LIMIT ' . $start . ', ' . $limit;
				}
				$resSQL = $this->db->query($strSQL);
				$resArray = array();
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[] = $resRow;
						}
				}
				return $resArray;
		}
		function getRequestsCount($groupId, $status = 'requested')
		{
				/*
				$strSQL 	= 	'SELECT gi.group_invitation_id, gi.group_id, gi.sender_id, gi.invitation_status, gi.receiver_id,u.username FROM groups_invitation as gi
				INNER JOIN users as u ON u.user_id = gi.receiver_id AND  (gi.invitation_status = "requested" OR  gi.invitation_status = "sent") AND gi.group_id = '.$groupId .'
				UNION
				SELECT gi.group_invitation_id, gi.group_id, gi.sender_id, gi.invitation_status, gi.receiver_id, gi.receiver_email AS username
				FROM groups_invitation AS gi
				WHERE (gi.invitation_status = "requested" OR  gi.invitation_status = "sent")  AND gi.group_id = '.$groupId .' AND gi.receiver_email != "" AND gi.receiver_id = "0"';
				*/
				$strSQL = 'SELECT results.group_id , results.receiver_id,results.username
						FROM
						(
						SELECT gi.group_invitation_id, gi.group_id, gi.sender_id, gi.invitation_status, gi.receiver_id,u.username
						FROM groups_invitation as gi
						INNER JOIN users as u ON u.user_id = gi.receiver_id AND (gi.invitation_status = "requested" OR gi.invitation_status = "sent") AND gi.group_id = ' . $this->db->escape($groupId) . '
						UNION
						SELECT gi.group_invitation_id, gi.group_id, gi.sender_id, gi.invitation_status, gi.receiver_id, gi.receiver_email AS username
						FROM groups_invitation AS gi
						WHERE (gi.invitation_status = "requested" OR gi.invitation_status = "sent") AND gi.group_id = ' . $this->db->escape($groupId) . ' AND gi.receiver_email != "" AND gi.receiver_id = "0"
						) as results
						GROUP BY results.group_id , results.receiver_id,results.username  ';
				$resSQL = $this->db->query($strSQL);
				return $resSQL->num_rows();
		}
		function isAdmin($groupId, $userId)
		{
				$strSQL = 'SELECT result.group_id, result.user_id
						FROM
						(
						SELECT group_id,user_id FROM groups WHERE group_id = ' . $this->db->escape($groupId) . '
						UNION
						SELECT group_id,receiver_id FROM group_members WHERE group_id = ' . $this->db->escape($groupId) . ' AND is_admin = "Y" AND member_status = "accepted"
						) AS result WHERE result.user_id = ' . $this->db->escape($userId);
				$resSQL = $this->db->query($strSQL);
				$rows = ($resSQL->num_rows() == 0) ? 0 : 1;
				return $rows;
		}
		function removeGroupMember($userId, $groupId)
		{
				$strSQL = 'DELETE FROM group_members WHERE group_id = ' . $this->db->escape($groupId) . ' AND receiver_id = ' . $this->db->escape($userId);
				$this->db->query($strSQL);
		}
		function blockGroupMember($userId, $groupId)
		{
				$strSQL = 'UPDATE group_members SET member_status = "blocked", date_modified = CURRENT_TIMESTAMP WHERE group_id = ' . $this->db->escape($groupId) . ' AND receiver_id = ' . $this->db->escape($userId);
				$this->db->query($strSQL);
		}
		function unblockGroupMember($userId, $groupId)
		{
				$strSQL = 'UPDATE group_members SET member_status = "accepted", date_modified = CURRENT_TIMESTAMP WHERE group_id = ' . $this->db->escape($groupId) . ' AND receiver_id = ' . $this->db->escape($userId);
				$this->db->query($strSQL);
		}
		function getGroupMembers($groupId, $status = 'accepted', $adminFlag = '', $start = '', $limit = '')
		{
				$strSQL = 'SELECT gm.group_member_id, gm.group_id, gm.sender_id, gm.member_status as invitation_status, gm.receiver_id,u.username,gm.is_admin FROM group_members as gm INNER JOIN users as u ON u.user_id = gm.receiver_id AND gm.member_status = ' . $this->db->escape($status) . ' AND gm.group_id = ' . $groupId;
				if ($adminFlag == 'Y')
				{
						$strSQL .= ' AND gm.is_admin = "Y"';
				}
				if (ereg('^[0-9]+$', $start) && ereg('^[0-9]+$', $limit))
				{
						$strSQL .= ' LIMIT ' . $start . ', ' . $limit;
				}
				$resSQL = $this->db->query($strSQL);
				$resArray = array();
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[$resRow['group_member_id']] = $resRow;
						}
				}
				return $resArray;
		}
		function getGroupMembersCount($groupId, $status = 'accepted', $adminFlag = '')
		{
				$strSQL = 'SELECT gm.group_member_id, gm.group_id, gm.sender_id, gm.member_status as invitation_status, gm.receiver_id,u.username,gm.is_admin FROM group_members as gm INNER JOIN users as u ON u.user_id = gm.receiver_id AND gm.member_status = ' . $this->db->escape($status) . ' AND gm.group_id = ' . $groupId;
				if ($adminFlag == 'Y')
				{
						$strSQL .= ' AND gm.is_admin = "Y"';
				}
				$resSQL = $this->db->query($strSQL);
				return $resSQL->num_rows();
		}
		function getReceiverDetails($invids)
		{
				//$strSQL 	= 	'SELECT u.username,u.user_id,u.email FROM users AS u INNER JOIN groups_invitation AS gi ON gi.receiver_id = u.user_id AND gi.group_invitation_id in ('. $invids .')';
				$strSQL = 'SELECT gi.group_invitation_id ,IFNULL(u.username,"") AS username, gi.receiver_id as user_id,IFNULL(u.email,"") AS email, gi.receiver_email FROM groups_invitation AS gi  LEFT JOIN users AS u ON gi.receiver_id = u.user_id WHERE gi.group_invitation_id in (' . $invids . ')';
				/*
				$fp = fopen('receiver_qry22.txt','ab+');
				fwrite($fp,$strSQL);
				fclose($fp);
				*/
				$resSQL = $this->db->query($strSQL);
				$resArray = array();
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[] = $resRow;
						}
				}
				return $resArray;
		}
		function updateInvitations($ids, $groupId, $status, $message = '')
		{
				//$strSQL = 'UPDATE groups_invitation SET invitation_message = '.$this->db->escape($message).', invitation_status = '.$this->db->escape($status).' WHERE group_invitation_id in ('.$ids.') AND sender_id = '.$this->userId;
				$strSQL = 'UPDATE groups_invitation SET invitation_message = ' . $this->db->escape($message) . ', invitation_status = ' . $this->db->escape($status) . ' WHERE group_invitation_id in (' . $ids . ')';
				$this->db->query($strSQL);
				if ($this->db->affected_rows() == 1) return 1;
				else  return 0;
		}
		function leaveGroup($groupId, $receiver)
		{
				$strSQL = 'DELETE FROM group_members WHERE group_id =' . $this->db->escape($groupId) . ' AND receiver_id =' . $this->db->escape($receiver);
				$this->db->query($strSQL);
		}
		function joinGroup($groupId, $sender, $receiver)
		{
				$strSQL = 'INSERT INTO group_members SET group_id =' . $this->db->escape($groupId) . ', receiver_id =' . $this->db->escape($receiver) . ', sender_id =' . $this->db->escape($sender);
				$this->db->query($strSQL);
		}
		function removeGroup($groupId)
		{
				$strSQL = 'UPDATE groups SET group_status = "deleted" WHERE group_id = ' . $this->db->escape($groupId) . ' AND user_id =' . $this->db->escape($this->userId);
				$this->db->query($strSQL);
				$postType = 'group';
				$postId = $groupId;
				$this->deletePostByType($postType, $postId);
		}
		function getAdminSettingsGroupCount()
		{
				$strSQL = 'SELECT total_groups_user_create,total_events_user_create FROM admin_settings';
				$resSQL = $this->db->query($strSQL);
				$count = 0;
				if ($resSQL->num_rows() > 0)
				{
						$resRow = $resSQL->result_array();
						$count = $resRow[0]['total_groups_user_create'];
				}
				return $count;
		}
		function getUserGroupCount($userId = '')
		{
				if (TRIM($userId) == '')
				{
						$userId = $this->userId;
				}
				else
				{
						if (!ereg('^[0-9]+$', $userId))
						{
								$userId = $this->userId;
						}
				}
				$count = 0;
				$strSQL = 'SELECT user_id,count(group_id) AS group_count FROM groups WHERE user_id = ' . $this->db->escape($userId) . ' AND UPPER(TRIM(group_status)) = "OK" GROUP BY user_id';
				$resSQL = $this->db->query($strSQL);
				if ($resSQL->num_rows() > 0)
				{
						$resRow = $resSQL->result_array();
						$count = $resRow[0]['group_count'];
				}
				return $count;
		}
		function deletePostByType($postFor, $postForId)
		{
				//echo 'DELETE FROM posted_items WHERE post_type=\''.$postFor.'\' AND post_for_id='.$postForId;
				$sql = 'DELETE FROM posted_items WHERE post_type=\'' . $postFor . '\' AND post_for_id=' . $postForId;
				$this->db->query($sql);
				if ($this->db->affected_rows() > 0) return true;
				else  return false;
		} //end deletePostByType()
		function removeInvitation($userId, $groupId, $invitationId = '')
		{
				$condSQL = '';
				if ($invitationId != '') $condSQL = ' AND group_invitation_id =' . $this->db->escape($invitationId);
				$strSQL = 'DELETE FROM groups_invitation WHERE group_id =' . $this->db->escape($groupId) . ' AND receiver_id =' . $this->db->escape($userId) . $condSQL;
				$this->db->query($strSQL);
		}
		function removeAllInvitations($groupId)
		{
				$strSQL = 'DELETE FROM groups_invitation WHERE group_id =' . $this->db->escape($groupId);
				$this->db->query($strSQL);
		}
		function getGroupInfo($groupId)
		{
				$strSQL = '	SELECT group_id, group_type, group_name, group_description, group_category_id, group_sub_category_id
							,group_recentnews,group_office,group_url,group_email,group_street,group_city,group_state,group_country
							,group_related, group_discussionboard, group_wall, group_photos, group_upload_permission
							, group_videos, group_videos_permission, group_posted, group_posted_permission, group_type
							,group_publicize, network_id,group_photo_path
							FROM groups WHERE group_id = ' . $this->db->escape($groupId) . ' AND trim(upper(group_status)) = "OK" ';
				$resSQL = $this->db->query($strSQL);
				$resRow = array();
				if ($resSQL->num_rows() > 0)
				{
						$resArray = $resSQL->result_array();
						$resRow = $resArray[0];
				}
				return $resRow;
		}
		function getName($groupId)
		{
				$sql = ' SELECT group_name FROM groups WHERE group_id ="' . trim($groupId) . '"';
				$res = $this->db->query($sql);
				$rs = $res->row();
				if ($res->num_rows() > 0)
				{
						return $rs->group_name;
				}
				else
				{
						return false;
				}
		}
		function getInfo($groupId)
		{
				$strSQL = 'SELECT g.user_id,u.username, u.email, g.group_id,IFNULL(IF(TRIM(n.network_name) = "", n.network_city, n.network_name),"") AS network_name,
					g.group_type, g.group_name, g.group_description, g.group_category_id, g.group_sub_category_id ,g.group_recentnews,g.group_office,g.group_url,
					g.group_email,g.group_street,g.group_city,g.group_state,g.group_country ,g.group_related, g.group_discussionboard, g.group_wall, g.group_photos,
					g.group_upload_permission , g.group_videos, g.group_videos_permission, g.group_posted, g.group_posted_permission, g.group_type ,g.group_publicize,
					g.network_id, gc.group_category_name,gsc.group_sub_category_name,IFNULL(c.country_name,"") AS country_name
					FROM groups AS g
					INNER JOIN groups_category AS gc ON gc.group_category_id = g.group_category_id
					INNER JOIN groups_sub_category AS gsc ON gsc.group_sub_category_id = g.group_sub_category_id
					INNER JOIN users AS u ON g.user_id = u.user_id
					LEFT JOIN country AS c ON g.group_country = c.country_symbol
					LEFT JOIN networks AS n ON n.network_id = g.network_id AND g.network_id != 0
					WHERE group_id = ' . $this->db->escape($groupId) . ' AND trim(upper(group_status)) = "OK"';
				$resSQL = $this->db->query($strSQL);
				$resRow = array();
				if ($resSQL->num_rows() > 0)
				{
						$resArray = $resSQL->result_array();
						$resRow = $resArray[0];
				}
				return $resRow;
		}
		function saveGroupInfo($groupValues, $groupId = '', $action = 'new')
		{
				$dataSQL = '';
				$condSQL = '';
				if ($action == 'new')
				{
						$strSQL = 'INSERT INTO groups SET  ';
						foreach ($groupValues as $key => $val)
						{
								if ($dataSQL == '')
								{
										$dataSQL .= $key . ' = ' . $val;
								}
								else
								{
										$dataSQL .= ',' . $key . ' = ' . $val;
								}
						}
						$dataSQL .= ', date_modified = CURRENT_TIMESTAMP  ';
				}
				else
				{
						$strSQL = 'UPDATE groups SET  ';
						foreach ($groupValues as $key => $val)
						{
								if ($dataSQL == '')
								{
										$dataSQL .= $key . ' = ' . $val;
								}
								else
								{
										$dataSQL .= ',' . $key . ' = ' . $val;
								}
						}
						$dataSQL .= ', date_modified = CURRENT_TIMESTAMP  ';
						$condSQL = '  WHERE group_id = ' . $this->db->escape($groupId);
				}
				$strSQL = $strSQL . $dataSQL . $condSQL;
				$this->db->query($strSQL);
				if ($action == 'new')
				{
						if ($this->db->affected_rows() == 1)
						{
								$groupId = $this->db->insert_id();
								$strSQL = "INSERT INTO group_members SET group_id = " . $groupId . ", sender_id = " . $this->userId . ", receiver_id = " . $this->userId . ", is_admin = 'Y', member_status = 'accepted'";
								$this->db->query($strSQL);
								return $groupId;
						}
						else  return 0;
				}
				else
				{
						return $groupId;
				}
		}
		//Default function
		// This Function is used for groups browse page
		function getGroups($userId, $networkId = '', $catId = '', $subCatId = '', $start = '', $limit = '')
		{
				$networkCondSQL = '';
				if (ereg('^[0-9]+$', $networkId))
				{
						if ($networkId > 0)
						{
								$networkCondSQL = ' AND g.network_id = ' . $this->db->escape($networkId);
						}
				}
				$categoryCondSQL = '';
				if (ereg('^[0-9]+$', $catId))
				{
						if ($catId > 0) $categoryCondSQL = ' AND g.group_category_id = ' . $this->db->escape($catId);
				}
				$subCategoryCondSQL = '';
				if (ereg('^[0-9]+$', $subCatId))
				{
						if ($subCatId > 0)
						{
								$subCategoryCondSQL = ' AND g.group_sub_category_id = ' . $this->db->escape($subCatId);
						}
				}
				$limitSQL = '';
				if (ereg('^[0-9]+$', $start) && ereg('^[0-9]+$', $limit))
				{
						$limitSQL = ' LIMIT ' . $start . ' , ' . $limit;
				}
				$strSQL = 'SELECT	g.group_id,g.network_id, g.group_type, g.user_id,g.date_added, g.group_name, gc.group_category_id, gc.group_category_name, gsc.group_sub_category_id,
						gsc.group_sub_category_name, dt.posted_for_id, w.wall_for_id, IFNULL(IF(n.network_name = "", n.network_city,n.network_name),"Global") AS network_name,count(distinct gi.receiver_id) AS new_member,
						count(distinct gm.receiver_id) AS members, count(distinct w.wall_id) AS wall_posts,
						count(distinct dt.discussion_topic_id) AS topics,COUNT(distinct dp.discussion_post_id) AS topic_posts
					FROM 	groups AS g
					INNER JOIN
						group_members AS gm ON gm.group_id = g.group_id AND gm.member_status != "blocked"
					INNER JOIN
						groups_category AS gc ON gc.group_category_id = g.group_category_id
					INNER JOIN
						groups_sub_category AS gsc ON gsc.group_sub_category_id = g.group_sub_category_id
					LEFT JOIN
						groups_invitation AS gi ON gi.group_id = g.group_id
					LEFT JOIN
						wall AS w ON w.wall_for_id = g.group_id AND wall_for = "group"
					LEFT JOIN
						discussion_topic AS dt ON g.group_id = dt.posted_for_id AND dt.posted_for = "group"
					LEFT JOIN
						discussion_post AS dp ON dt.discussion_topic_id = dp.discussion_topic_id
					LEFT JOIN
						networks AS n ON g.network_id = n.network_id
					WHERE
						UPPER(TRIM(g.group_status)) = "OK" AND ((UPPER(TRIM(g.group_type)) != "SECRET" AND g.group_publicize = "yes") OR gm.receiver_id = ' . $userId . ' OR g.user_id = ' . $userId . ')' . $networkCondSQL . $categoryCondSQL . $subCategoryCondSQL . '
					GROUP BY
						g.group_id,g.network_id, g.group_type, g.user_id,g.date_added,g.group_name, gc.group_category_id, gc.group_category_name, gsc.group_sub_category_id,
						gsc.group_sub_category_name,dt.posted_for_id,w.wall_for_id
					ORDER BY g.group_id DESC' . $limitSQL;
				$resSQL = $this->db->query($strSQL);
				$resArray = array();
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[$resRow['group_id']] = $resRow;
						}
				}
				return $resArray;
		}
		function getGroupsCount($userId, $networkId = '', $catId = '', $subCatId = '')
		{
				$networkCondSQL = '';
				if (ereg('^[0-9]+$', $networkId))
				{
						if ($networkId > 0)
						{
								$networkCondSQL = ' AND g.network_id = ' . $this->db->escape($networkId);
						}
				}
				$categoryCondSQL = '';
				if (ereg('^[0-9]+$', $catId))
				{
						if ($catId > 0) $categoryCondSQL = ' AND g.group_category_id = ' . $this->db->escape($catId);
				}
				$subCategoryCondSQL = '';
				if (ereg('^[0-9]+$', $subCatId))
				{
						if ($subCatId > 0)
						{
								$subCategoryCondSQL = ' AND g.group_sub_category_id = ' . $this->db->escape($subCatId);
						}
				}
				$strSQL = 'SELECT	g.group_id,g.network_id, g.group_type, g.user_id,g.date_added, g.group_name, gc.group_category_id, gc.group_category_name, gsc.group_sub_category_id,
						gsc.group_sub_category_name, dt.posted_for_id, w.wall_for_id, IFNULL(IF(n.network_name = "", n.network_city,n.network_name),"Global") AS network_name,count(distinct gi.receiver_id) AS new_member,
						count(distinct gm.receiver_id) AS members, count(distinct w.wall_id) AS wall_posts,
						count(distinct dt.discussion_topic_id) AS topics,COUNT(distinct dp.discussion_post_id) AS topic_posts
					FROM 	groups AS g
					INNER JOIN
						group_members AS gm ON gm.group_id = g.group_id AND gm.member_status != "blocked"
					INNER JOIN
						groups_category AS gc ON gc.group_category_id = g.group_category_id
					INNER JOIN
						groups_sub_category AS gsc ON gsc.group_sub_category_id = g.group_sub_category_id
					LEFT JOIN
						groups_invitation AS gi ON gi.group_id = g.group_id
					LEFT JOIN
						wall AS w ON w.wall_for_id = g.group_id AND wall_for = "group"
					LEFT JOIN
						discussion_topic AS dt ON g.group_id = dt.posted_for_id AND dt.posted_for = "group"
					LEFT JOIN
						discussion_post AS dp ON dt.discussion_topic_id = dp.discussion_topic_id
					LEFT JOIN
						networks AS n ON g.network_id = n.network_id
					WHERE
						UPPER(TRIM(g.group_status)) = "OK" AND ((UPPER(TRIM(g.group_type)) != "SECRET" AND g.group_publicize = "yes") OR gm.receiver_id = ' . $userId . '  OR g.user_id = ' . $userId . ')' . $networkCondSQL . $categoryCondSQL . $subCategoryCondSQL . '
					GROUP BY
						g.group_id,g.network_id, g.group_type, g.user_id,g.date_added,g.group_name, gc.group_category_id, gc.group_category_name, gsc.group_sub_category_id,
						gsc.group_sub_category_name,dt.posted_for_id,w.wall_for_id
					ORDER BY g.group_id DESC';
				$resSQL = $this->db->query($strSQL);
				return $resSQL->num_rows();
		}
		function getGroupImage($groupId, $thumbnail = false, $relativeURL = false)
		{
				$thumb = ($thumbnail == true) ? '_thumb' : '_view';
				$strSql = 'SELECT group_photo_path FROM groups WHERE group_id =' . $this->db->escape($groupId);
				$resQuery = $this->db->query($strSql);
				if ($resQuery->num_rows() > 0)
				{
						$rowAvatar = $resQuery->result_array();
						if (!$relativeURL) $userAvatar = base_url() . 'application/content/groups/' . $groupId . $thumb . '.' . $rowAvatar[0]['group_photo_path'];
						else  $userAvatar = 'content/groups/' . $groupId . $thumb . '.' . $rowAvatar[0]['group_photo_path'];
						if (!file_exists(APPPATH . 'content/groups/' . $groupId . $thumb . '.' . $rowAvatar[0]['group_photo_path']))
						{
								$thumb = '';
								if ($thumbnail == true)
								{
										$thumb = '_thumb';
								}
								if (!$relativeURL) $userAvatar = base_url() . 'application/images/default_avatar' . $thumb . '.jpg';
								else  $userAvatar = 'images/default_avatar' . $thumb . '.jpg';
						}
				}
				else
				{
						$thumb = '';
						if ($thumbnail == true)
						{
								$thumb = '_thumb';
						}
						if (!$relativeURL) $userAvatar = base_url() . 'application/images/default_avatar' . $thumb . '.jpg';
						else  $userAvatar = 'images/default_avatar' . $thumb . '.jpg';
				}
				return $userAvatar;
		}
		function getInvitationInfo($groupId = '', $receiver = '', $invid = '')
		{
				$condSQL = '';
				$recSQL = '';
				if ($receiver != '') $recSQL = ' AND receiver_id = ' . $this->db->escape($receiver);
				$groupSQL = '';
				if ($groupId != '') $groupSQL = ' AND group_id = ' . $this->db->escape($groupId);
				if ($invid != '') $condSQL = ' AND group_invitation_id = ' . $this->db->escape($invid);
				$strSQL = 'SELECT group_invitation_id, sender_id, receiver_id, group_id, invitation_status, receiver_email, is_admin FROM groups_invitation WHERE 1=1 ' . $groupSQL . $recSQL . $condSQL;
				$resSQL = $this->db->query($strSQL);
				if ($resSQL->num_rows() > 0)
				{
						$row = $resSQL->result_array();
						return $row[0];
				}
				else  return false;
		}
		function getAdmin($groupId)
		{
				$strSQL = 'SELECT   receiver_id  FROM group_members  WHERE member_status = "accepted" AND is_admin = "Y" AND group_id = ' . $this->db->escape($groupId);
				$resSQL = $this->db->query($strSQL);
				if ($resSQL->num_rows() > 0)
				{
						$row = $resSQL->result_array();
						return $row[0]['receiver_id'];
				}
				else  return false;
		}
		function getGroupCategory($status = 'YES')
		{
				$cond1 = '';
				$cond2 = '';
				if ($status != '')
				{
						$cond1 = ' WHERE UPPER(TRIM(ec.group_category_status)) = ' . $this->db->escape(STRTOUPPER(TRIM($status)));
						$cond2 = ' AND UPPER(TRIM(esc.group_sub_category_status)) = ' . $this->db->escape(STRTOUPPER(TRIM($status)));
				}
				$strSQL = "SELECT ec.group_category_id,ec.group_category_name FROM groups_category AS ec
					INNER JOIN groups_sub_category AS esc ON ec.group_category_id = esc.group_category_id " . $cond1 . $cond2 . "
					GROUP BY ec.group_category_id,ec.group_category_name";
				$resArray = array();
				$resSQL = $this->db->query($strSQL);
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[$resRow['group_category_id']] = $resRow;
						}
				}
				return $resArray;
		}
		function getSubcategories($mainCatId, $status = 'YES')
		{
				$cond = '';
				if (TRIM($status) != '') $cond = ' group_sub_category_status = ' . STRTOUPPER(TRIM($this->db->escape($status))) . ' AND ';
				$strSQL = 'SELECT group_sub_category_id, group_sub_category_name FROM groups_sub_category WHERE ' . $cond . '  group_category_id = "' . $mainCatId . '" ORDER BY group_sub_category_name';
				$resArray = array();
				$resSQL = $this->db->query($strSQL);
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[] = $resRow;
						}
				}
				return $resArray;
		}
		function getCountry()
		{
				$strSQL = 'SELECT country_symbol, country_name FROM country';
				$resArray = array();
				$resSQL = $this->db->query($strSQL);
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[] = $resRow;
						}
				}
				return $resArray;
		}
		function getFriendsGroups($friendsIds, $user, $search = '', $start = '', $limit = '')
		{
				$condSQL = '';
				if ($search != '')
				{
						$search = '%' . $search . '%';
						$condSQL = ' AND g.group_name like ' . $this->db->escape($search);
				}
				$strSQL = 'SELECT   	g.user_id as group_owner,gm.receiver_id AS friend_id,gm.group_id, g.group_name,u.username AS friend_name,u.email,gm.is_admin,gm.date_created as join_date,
									gsc.group_sub_category_name,gc.group_category_name,g.group_category_id,g.group_sub_category_id,g.group_publicize,g.group_photo_path
						FROM 		group_members AS gm
						INNER JOIN 	groups AS g ON g.group_id = gm.group_id AND g.group_status = "ok" AND ((g.group_type != "secret" AND g.group_publicize = "yes") OR g.user_id = ' . $this->db->escape($user) . ')
						INNER JOIN	groups_category AS gc ON gc.group_category_id = g.group_category_id
						INNER JOIN	groups_sub_category AS gsc ON gsc.group_sub_category_id = g.group_sub_category_id AND gsc.group_category_id = g.group_category_id
						INNER JOIN 	users As u ON gm.receiver_id = u.user_id
						WHERE 		gm.receiver_id in (' . $friendsIds . ') AND gm.member_status = "accepted" ' . $condSQL . '
						ORDER BY 	g.date_modified DESC,g.date_added DESC,gm.date_created DESC ,g.group_name ASC ';
				$limitSQL = '';
				if (trim($start) != '' && trim($limit) != '')
				{
						if (ereg('^[0-9]+$', $start) && ereg('^[0-9]+$', $limit))
						{
								$limitSQL = '  LIMIT ' . $start . ',' . $limit;
						}
				}
				$strSQL .= $limitSQL;
				$resSQL = $this->db->query($strSQL);
				$resArray = array();
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[] = $resRow;
						}
				}
				return $resArray;
		}
		function getFriendsGroupsCount($friendsIds, $user, $search = '')
		{
				$condSQL = '';
				if ($search != '')
				{
						$search = '%' . $search . '%';
						$condSQL = ' AND g.group_name like ' . $this->db->escape($search);
				}
				$strSQL = 'SELECT   	g.user_id as group_owner,gm.receiver_id AS friend_id,gm.group_id, g.group_name,u.username AS friend_name,u.email,gm.is_admin,gm.date_created as join_date,
									gsc.group_sub_category_name,gc.group_category_name,g.group_category_id,g.group_sub_category_id,g.group_publicize,g.group_photo_path
						FROM 		group_members AS gm
						INNER JOIN 	groups AS g ON g.group_id = gm.group_id AND g.group_status = "ok" AND ((g.group_type != "secret" AND g.group_publicize = "yes") OR g.user_id = ' . $this->db->escape($user) . ')
						INNER JOIN	groups_category AS gc ON gc.group_category_id = g.group_category_id
						INNER JOIN	groups_sub_category AS gsc ON gsc.group_sub_category_id = g.group_sub_category_id AND gsc.group_category_id = g.group_category_id
						INNER JOIN 	users As u ON gm.receiver_id = u.user_id
						WHERE 		gm.receiver_id in (' . $friendsIds . ') AND gm.member_status = "accepted" ' . $condSQL . '
						ORDER BY 	gm.date_created DESC ,g.group_name ASC ';
				$resSQL = $this->db->query($strSQL);
				return $resSQL->num_rows();
		}
		function getNetworkGroups($networkId, $user, $start = '', $limit = '')
		{
				$strSQL = 'SELECT   	g.group_id,g.user_id as group_owner, g.group_name,u.username AS owner_name, n.network_id, IF(TRIM(n.network_name) = "", n.network_city , n.network_name) AS network_name,
									gsc.group_sub_category_name,gc.group_category_name,g.group_category_id,g.group_sub_category_id,g.group_publicize,g.group_photo_path, DATE_FORMAT(g.date_added,"%M %d %Y %H:%i") AS date_added
						FROM 		groups AS g
						INNER JOIN	groups_category AS gc ON gc.group_category_id = g.group_category_id
						INNER JOIN	groups_sub_category AS gsc ON gsc.group_sub_category_id = g.group_sub_category_id AND gsc.group_category_id = g.group_category_id
						INNER JOIN 	users As u ON g.user_id = u.user_id
						INNER JOIN 	networks AS n ON n.network_id = g.network_id AND n.network_id = ' . $this->db->escape($networkId) . '
						WHERE 		g.network_id = ' . $this->db->escape($networkId) . ' AND UPPER(TRIM(g.group_status)) = "OK" AND ((g.group_type != "secret" AND g.group_publicize = "yes") OR g.user_id = ' . $this->db->escape($user) . ')
						ORDER BY 	g.date_added DESC ,g.group_name ASC ';
				$limitSQL = '';
				if (trim($start) != '' && trim($limit) != '')
				{
						if (ereg('^[0-9]+$', $start) && ereg('^[0-9]+$', $limit))
						{
								$limitSQL = '  LIMIT ' . $start . ',' . $limit;
						}
				}
				$strSQL .= $limitSQL;
				$resSQL = $this->db->query($strSQL);
				$resArray = array();
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[] = $resRow;
						}
				}
				return $resArray;
		}
		function getUserGroups($user, $search = '', $ownerFlag = '', $start = '', $limit = '')
		{
				$condSQL = '';
				if ($search != '')
				{
						$search = '%' . $search . '%';
						$condSQL = ' AND g.group_name like ' . $this->db->escape($search);
				}
				$ownerSQL = '';
				if (strtoupper($ownerFlag) == 'Y')
				{
						$ownerSQL = ' AND UPPER(TRIM(gm.is_admin)) = "Y"';
				}
				$userSQL = '';
				if ($this->userId == $user)
				{
						$userSQL = ' AND ((g.group_type != "secret" AND g.group_publicize = "yes") OR gm.receiver_id = ' . $this->db->escape($user) . ' OR g.user_id = ' . $this->db->escape($user) . ')';
				}
				else
				{
						$userSQL = ' AND (g.group_type != "secret" AND g.group_publicize = "yes")';
				}
				$strSQL = 'SELECT   	g.user_id as group_owner,gm.receiver_id AS friend_id,gm.group_id, g.group_name,u.username AS friend_name,u.email,gm.is_admin,gm.date_created as join_date,
									gsc.group_sub_category_name,gc.group_category_name,g.group_category_id,g.group_sub_category_id,g.group_publicize,g.group_photo_path, DATE_FORMAT(g.date_modified,"%M %d %Y %H:%i") AS date_modified
						FROM 		group_members AS gm
						INNER JOIN 	groups AS g ON g.group_id = gm.group_id AND g.group_status = "ok" ' . $userSQL . '
						INNER JOIN	groups_category AS gc ON gc.group_category_id = g.group_category_id
						INNER JOIN	groups_sub_category AS gsc ON gsc.group_sub_category_id = g.group_sub_category_id AND gsc.group_category_id = g.group_category_id
						INNER JOIN 	users As u ON gm.receiver_id = u.user_id
						WHERE 		gm.receiver_id = ' . $user . ' AND gm.member_status = "accepted" ' . $condSQL . $ownerSQL . '
						ORDER BY 	g.date_modified DESC,g.date_added DESC,gm.date_created DESC ,g.group_name ASC ';
				$limitSQL = '';
				if (trim($start) != '' && trim($limit) != '')
				{
						if (ereg('^[0-9]+$', $start) && ereg('^[0-9]+$', $limit))
						{
								$limitSQL = '  LIMIT ' . $start . ',' . $limit;
						}
				}
				$strSQL .= $limitSQL;
				$resSQL = $this->db->query($strSQL);
				$resArray = array();
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[] = $resRow;
						}
				}
				return $resArray;
		}
		function getUserGroupsCount($user, $search = '', $ownerFlag = '')
		{
				/*
				$condSQL = '';
				if($search != '')
				{
				$search = '%'.$search.'%';
				$condSQL = ' AND g.group_name like '. $this->db->escape($search) ;
				}

				$ownerSQL = '';
				if( strtoupper($ownerFlag) == 'Y')
				{
				$ownerSQL = ' AND UPPER(TRIM(gm.is_admin)) = "Y"';
				}
				*/
				$condSQL = '';
				if ($search != '')
				{
						$search = '%' . $search . '%';
						$condSQL = ' AND g.group_name like ' . $this->db->escape($search);
				}
				$ownerSQL = '';
				if (strtoupper($ownerFlag) == 'Y')
				{
						$ownerSQL = ' AND UPPER(TRIM(gm.is_admin)) = "Y"';
				}
				$userSQL = '';
				if ($this->userId == $user)
				{
						$userSQL = ' AND ((g.group_type != "secret" AND g.group_publicize = "yes") OR gm.receiver_id = ' . $this->db->escape($user) . ' OR g.user_id = ' . $this->db->escape($user) . ')';
				}
				else
				{
						$userSQL = ' AND (g.group_type != "secret" AND g.group_publicize = "yes")';
				}
				$strSQL = 'SELECT   	g.user_id as group_owner,gm.receiver_id AS friend_id,gm.group_id, g.group_name,u.username AS friend_name,u.email,gm.is_admin,gm.date_created as join_date,
									gsc.group_sub_category_name,gc.group_category_name,g.group_category_id,g.group_sub_category_id,g.group_publicize,g.group_photo_path, DATE_FORMAT(g.date_modified,"%M %d %Y %H:%i") AS date_modified
						FROM 		group_members AS gm
						INNER JOIN 	groups AS g ON g.group_id = gm.group_id AND g.group_status = "ok" AND ((g.group_type != "secret" AND g.group_publicize = "yes") OR g.user_id = ' . $this->db->escape($user) . ')
						INNER JOIN	groups_category AS gc ON gc.group_category_id = g.group_category_id
						INNER JOIN	groups_sub_category AS gsc ON gsc.group_sub_category_id = g.group_sub_category_id AND gsc.group_category_id = g.group_category_id
						INNER JOIN 	users As u ON gm.receiver_id = u.user_id
						WHERE 		gm.receiver_id = ' . $user . ' AND gm.member_status = "accepted" ' . $condSQL . $ownerSQL . '
						ORDER BY 	gm.date_created DESC ,g.group_name ASC ';
				//echo $strSQL;
				$resSQL = $this->db->query($strSQL);
				return $resSQL->num_rows();
		}
		function getGroupApplicants($groupId)
		{
				$strSQL = 'SELECT group_id,receiver_id,receiver_email FROM groups_invitation WHERE group_id = ' . $groupId . ' GROUP BY group_id,receiver_id,receiver_email  ';
				$resSQL = $this->db->query($strSQL);
				$resArray = array();
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[] = $resRow;
						}
				}
				return $resArray;
		}
		#***************************************************************************
		#Method			: getRequestCount
		#Description	: returns group request count for the user
		#Author
		#***************************************************************************
		function getRequestCount()
		{
				$userId = $this->session->userdata('user_id');
				//$requestCountQuery = $this->db->query('SELECT group_invitation_id FROM groups_invitation WHERE receiver_id = '.$userId.' GROUP BY group_invitation_id');
				$requestCountQuery = $this->db->query('SELECT group_invitation_id FROM groups_invitation WHERE receiver_id = ' . $userId . ' AND sender_id != ' . $userId . ' AND ( invitation_status = "sent" )');
				return $requestCountQuery->num_rows();
		}
		function getRequestsForGroups($userId)
		{
				$strSQL = "SELECT 	gi.group_invitation_id,gi.group_id, g.group_name, g.group_type, g.user_id AS group_owner, gi.sender_id,
						u.username AS sendername,gi.invitation_status,gi.receiver_id
					FROM 	groups_invitation AS gi
					INNER JOIN users AS u ON u.user_id = gi.sender_id
					INNER JOIN groups AS g ON g.group_id = gi.group_id
					WHERE gi.receiver_id = " . $userId . " AND gi.sender_id != " . $userId . " AND (gi.invitation_status = 'sent' OR gi.invitation_status = 'requested')";
				$strSQL = "SELECT 	gi.group_invitation_id,gi.group_id, g.group_name, g.group_type, g.user_id AS group_owner, gi.sender_id,
						u.username AS sendername,gi.invitation_status,gi.receiver_id
					FROM 	groups_invitation AS gi
					INNER JOIN users AS u ON u.user_id = gi.sender_id
					INNER JOIN groups AS g ON g.group_id = gi.group_id
					WHERE gi.receiver_id = " . $userId . " AND gi.sender_id != " . $userId . " AND (gi.invitation_status = 'sent')";
				//	echo $strSQL;
				$resSQL = $this->db->query($strSQL);
				$resArray = array();
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[] = $resRow;
						}
				}
				return $resArray;
		}
		#***************************************************************************
		#Method			: getGroupCount
		#Description	: returns group count
		#Author
		#***************************************************************************
		function getGroupCount($status = 'ok')
		{
				$this->db->select('group_id');
				$this->db->from('groups');
				$this->db->where('group_status', $status);
				return $this->db->count_all_results();
		}
		#***************************************************************************
		#Method			: insertGroupCategory
		#Description	: insert group category
		#Author
		#***************************************************************************
		function insertGroupCategory($data)
		{
				$groupCategory = array('group_category_name' => $data['group_category_name'], 'group_category_description' => $data['group_category_description'], 'group_category_status' => $data['group_category_status']);
				$this->db->insert('groups_category', $groupCategory);
				$this->db->query('UPDATE groups_category SET date_added=NOW()');
		}
		#***************************************************************************
		#Method			: updateGroupCategory
		#Description	: updates Group Category
		#Author
		#***************************************************************************
		function updateGroupCategory($data)
		{
				$groupCategory = array('group_category_name' => $data['group_category_name'], 'group_category_description' => $data['group_category_description'], 'group_category_status' => $data['group_category_status']);
				$this->db->where('group_category_id', $data['group_category_id']);
				$this->db->update('groups_category', $groupCategory);
		}
		#***************************************************************************
		#Method			: insertGroupSubCategory
		#Description	: insert Group sub category
		#Author
		#***************************************************************************
		function insertGroupSubCategory($data, $group_category_id)
		{
				$groupSubCategory = array('group_sub_category_name' => $data['group_sub_category_name'], 'group_sub_category_description' => $data['group_sub_category_description'], 'group_sub_category_status' => $data['group_sub_category_status'], 'group_category_id' => $group_category_id);
				$this->db->insert('groups_sub_category', $groupSubCategory);
				$this->db->query('UPDATE groups_sub_category SET date_added=NOW()');
		}
		#***************************************************************************
		#Method			: updateGroupSubCategory
		#Description	: updates Group Sub Category
		#Author
		#***************************************************************************
		function updateGroupSubCategory($data)
		{
				$groupSubCategory = array('group_sub_category_name' => $data['group_sub_category_name'], 'group_sub_category_description' => $data['group_sub_category_description'], 'group_sub_category_status' => $data['group_sub_category_status']);
				$this->db->where('group_sub_category_id', $data['group_sub_category_id']);
				$this->db->update('groups_sub_category', $groupSubCategory);
		}
		#***************************************************************************
		#Method			: getGroupsMainCategory
		#Description	: fetches group category
		#Author
		#***************************************************************************
		function getGroupsMainCategory($status = 'Yes')
		{
				$cond = '';
				if ($status != '') $cond = 'WHERE group_category_status = \'' . $status . '\'';
				$strSQL = 'SELECT group_category_id, group_category_name,group_category_description,group_category_status,date_added FROM groups_category ' . $cond . ' ORDER BY group_category_name';
				$resArray = array();
				$resSQL = $this->db->query($strSQL);
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[$resRow['group_category_id']] = $resRow;
						}
				}
				return $resArray;
		}
		#***************************************************************************
		#Method			: getGroupsMainSubCategory
		#Description	: fetches group sub category
		#Author
		#***************************************************************************
		function getGroupsMainSubCategory($mainCatId, $status = 'Yes')
		{
				$cond = '';
				if ($status != '') $cond = 'WHERE group_sub_category_status = \'' . $status . '\' AND ';
				$strSQL = 'SELECT group_sub_category_id, group_sub_category_name,group_sub_category_description,group_sub_category_status,date_added FROM groups_sub_category WHERE  ' . $cond . '  group_category_id = "' . $mainCatId . '" ORDER BY group_sub_category_name';
				$resArray = array();
				$resSQL = $this->db->query($strSQL);
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[$resRow['group_sub_category_id']] = $resRow;
						}
				}
				return $resArray;
		}
		#***************************************************************************
		#Method			: updateGroupStatus
		#Description	: updates Group status
		#Author
		#***************************************************************************
		function updateGroupStatus($block_id, $status)
		{
				$groupStatus = array('group_status' => $status);
				$this->db->where('group_id', $block_id);
				$this->db->update('groups', $groupStatus);
		}
		#***************************************************************************
		#Method			: getGroupCategoryName
		#Description	: fetches group category name
		#Author
		#***************************************************************************
		function getGroupCategoryName($id)
		{
				$this->db->select('group_category_name');
				$this->db->from('groups_category');
				$this->db->where('group_category_id', $id);
				$query = $this->db->get();
				if ($query->num_rows() > 0)
				{
						foreach ($query->result() as $row)
						{
								$categoryName = $row->group_category_name;
						}
						return $categoryName;
				}
				else  return false;
		}
		//to check whether the group category exist or not
		//added by ilayaraja_22ag06
		function isCategoryExist($categoryName, $categoryId = '')
		{
				$cond = '';
				if (trim($categoryId) != '') $cond = ' AND group_category_id!=' . $this->db->escape($categoryId);
				$strSQL = 'SELECT group_category_id FROM groups_category WHERE group_category_name = ' . $this->db->escape($categoryName) . $cond;
				$resSQL = $this->db->query($strSQL);
				$res = ($resSQL->num_rows == 0) ? 0 : 1;
				return $res;
		}
		//to check whether the group category category exist or not
		//added by ilayaraja_22ag06
		function isSubCategoryExist($subCategoryName, $categoryId, $subCategoryId = '')
		{
				$cond = '';
				if (trim($subCategoryId) != '') $cond = ' AND group_sub_category_id!=' . $this->db->escape($subCategoryId);
				//echo 'SELECT group_sub_category_id FROM groups_sub_category WHERE group_sub_category_name = '. $this->db->escape($subCategoryName) .' AND group_category_id='. $this->db->escape($categoryId) .$cond;
				$strSQL = 'SELECT group_sub_category_id FROM groups_sub_category WHERE group_sub_category_name = ' . $this->db->escape($subCategoryName) . ' AND group_category_id=' . $this->db->escape($categoryId) . $cond;
				$resSQL = $this->db->query($strSQL);
				$res = ($resSQL->num_rows == 0) ? 0 : 1;
				return $res;
		}
}
?>