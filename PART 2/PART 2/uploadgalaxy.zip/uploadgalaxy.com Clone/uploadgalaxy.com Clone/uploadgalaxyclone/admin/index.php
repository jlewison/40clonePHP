<?php
include("../include/config.php");
Stemplate::assign("err",$_COOKIE['err']);
setcookie("err","");
STemplate::display("admin/admin_login.tpl");
?>
