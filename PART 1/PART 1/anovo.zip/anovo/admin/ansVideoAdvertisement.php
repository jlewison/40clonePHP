<?php
require_once ('../common/config.inc.php');
require_once ('../common/configs/config_ans_video.inc.php');
$CFG['lang']['include_files'][] = 'admin/includes/languages/%s/ansVideoAdvertisement.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['mods']['include_files'][] = 'common/classes/class_ListRecordsHandler.lib.php';
$CFG['lang']['include_files'][] = 'common/languages/%s/help.inc.php';
$CFG['html']['header'] = 'admin/includes/languages/%s/html_header.php';
$CFG['html']['footer'] = 'admin/includes/languages/%s/html_footer.php';
if ($_POST) $CFG['mods']['include_files'][] = 'common/classes/phpmailer/class_PHPMailer.lib.php';
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class advertisement extends ListRecordsHandler
{
		public function buildSortQuery()
		{
				$this->sql_sort = $this->fields_arr['orderby_field'] . ' ' . $this->fields_arr['orderby'];
		}
		public function chkFileNameIsNotEmpty($field_name, $err_tip = '')
		{
				if (!$_FILES[$field_name]['name'])
				{
						$this->setFormFieldErrorTip($field_name, $err_tip);
						return false;
				}
				return true;
		}
		public function chkFileNameIsNotEmptyEdit($field_name, $err_tip = '')
		{
				if (!$_FILES[$field_name]['name'])
				{
						return false;
				}
				return true;
		}
		public function chkValidFileType($field_name, $err_tip = '')
		{
				$extern = strtolower(substr($_FILES[$field_name]['name'], strrpos($_FILES[$field_name]['name'], '.') + 1));
				if (!in_array(strtolower($extern), $this->CFG['admin']['ans_videos']['advertisement_format_arr']))
				{
						$this->fields_err_tip_arr[$field_name] = $err_tip;
						return false;
				}
				return true;
		}
		public function chkValideFileSize($field_name, $err_tip = '')
		{
				$max_size = $this->CFG['admin']['ans_videos']['advertisement_max_size'] * 1024;
				if ($_FILES[$field_name]['size'] > $max_size)
				{
						$this->fields_err_tip_arr[$field_name] = $err_tip;
						return false;
				}
				return true;
		}
		public function chkErrorInFile($field_name, $err_tip = '')
		{
				if ($_FILES[$field_name]['error'])
				{
						$this->fields_err_tip_arr[$field_name] = $err_tip;
						return false;
				}
				return true;
		}
		public function resetFieldsArray()
		{
				$this->setFormField('aid', '');
				$this->setFormField('advertisement_name', '');
				$this->setFormField('advertisement_file', '');
				$this->setFormField('advertisement_description', '');
				$this->setFormField('advertisement_url', '');
				$this->setFormField('advertisement_duration', '0');
				$this->setFormField('advertisement_expiry_date', '');
				$this->setFormField('advertisement_impressions', '0');
				$this->setFormField('advertisement_channel', array());
				$this->setFormField('advertisement_image', '');
				$this->setFormField('advertisement_ext', '');
				$this->setFormField('advertisement_show_at', 'Begining');
				$this->setFormField('add_type', 'General');
				$this->setFormField('advertisement_status', '');
				$this->setFormField('date_added', '');
				$this->setFormField('month', '');
				$this->setFormField('day', '');
				$this->setFormField('year', '');
				$this->setFormField('act', '');
				$this->setFormField('views_revenue', '');
				$this->setFormField('clicks_revenue', '');
		}
		public function populateadvertisementDetails()
		{
				$sql = 'SELECT advertisement_id, advertisement_name, advertisement_description, advertisement_url,' . ' advertisement_duration, advertisement_expiry_date,' . ' advertisement_impressions, advertisement_channel, advertisement_image,' . ' advertisement_ext, advertisement_show_at, add_type, advertisement_status,' . ' views_revenue, clicks_revenue' . ' FROM ' . $this->CFG['db']['tbl']['ans_video_advertisement'] . ' WHERE' . ' advertisement_id=' . $this->dbObj->Param('advertisement_id');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['aid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($row = $rs->FetchRow())
				{
						$this->fields_arr['advertisement_name'] = $row['advertisement_name'];
						$this->fields_arr['advertisement_description'] = $row['advertisement_description'];
						$this->fields_arr['advertisement_url'] = $row['advertisement_url'];
						$this->fields_arr['advertisement_duration'] = $row['advertisement_duration'];
						$this->fields_arr['advertisement_expiry_date'] = $row['advertisement_expiry_date'];
						$this->fields_arr['advertisement_impressions'] = $row['advertisement_impressions'];
						$this->fields_arr['advertisement_channel'] = $row['advertisement_channel'];
						$this->fields_arr['advertisement_image'] = $row['advertisement_image'];
						$this->fields_arr['advertisement_ext'] = $row['advertisement_ext'];
						$this->fields_arr['advertisement_show_at'] = $row['advertisement_show_at'];
						$this->fields_arr['add_type'] = $row['add_type'];
						$this->fields_arr['advertisement_status'] = $row['advertisement_status'];
						$this->fields_arr['views_revenue'] = $row['views_revenue'];
						$this->fields_arr['clicks_revenue'] = $row['clicks_revenue'];
						$advertisement_expiry_date = explode(' ', $row['advertisement_expiry_date']);
						$advertisement_expiry_date = explode('-', $advertisement_expiry_date[0]);
						$this->fields_arr['year'] = $advertisement_expiry_date[0];
						$this->fields_arr['month'] = $advertisement_expiry_date[1];
						$this->fields_arr['day'] = $advertisement_expiry_date[2];
						$this->fields_arr['advertisement_channel'] = explode(',', $row['advertisement_channel']);
						return true;
				}
				return false;
		}
		public function getadvertisementImage()
		{
				switch ($this->fields_arr['advertisement_ext'])
				{
						case 'jpg':
								$image_path = $this->CFG['site']['url'] . $this->CFG['admin']['ans_videos']['advertisement_folder'] . $this->fields_arr['advertisement_image'] . '.' . $this->fields_arr['advertisement_ext'];
								break;
						case 'swf':
								$image_path = $this->CFG['site']['url'] . 'images/swflogo.jpg';
								break;
						case 'flv':
								$image_path = $this->CFG['site']['url'] . 'images/flvlogo.jpg';
								break;
						default:
								$image_path = $this->CFG['site']['url'] . 'images/nologo.jpg';
								break;
				}
?>
	<img src="<?php echo $image_path; ?>" alt="<?php echo $this->LANG['advertisement']; ?>" width="66px" height="66px" />
<?php
		}
		public function removeFiles($file)
		{
				if (is_file($file))
				{
						unlink($file);
						return true;
				}
				return false;
		}
		public function deleteFiles($image_name)
		{
				$this->removeFiles($image_name . '.flv');
				$this->removeFiles($image_name . '.jpg');
				$this->removeFiles($image_name . '.swf');
		}
		public function updateAdvertisementTable()
		{
				$add_arr = array();
				$add_field = '';
				$expiry_date = $this->getFormField('year') . '-' . $this->getFormField('month') . '-' . $this->getFormField('day');
				$channel = implode(',', $this->fields_arr['advertisement_channel']);
				if ($this->advertisement)
				{
						$extern = strtolower(substr($_FILES['advertisement_file']['name'], strrpos($_FILES['advertisement_file']['name'], '.') + 1));
						$image_name = getImageName($this->fields_arr['aid']);
						$dir = '../' . $this->CFG['admin']['ans_videos']['advertisement_folder'];
						$this->chkAndCreateFolder($dir);
						$this->deleteFiles($dir . $image_name);
						move_uploaded_file($_FILES['advertisement_file']['tmp_name'], $dir . $image_name . '.' . strtolower($extern));
						$add_arr = array($image_name, $extern);
						$add_field = ', advertisement_image=' . $this->dbObj->Param('advertisement_image') . ',' . ' advertisement_ext=' . $this->dbObj->Param('advertisement_ext');
				}
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['ans_video_advertisement'] . ' SET' . ' advertisement_name=' . $this->dbObj->Param('advertisement_name') . ',' . ' advertisement_description=' . $this->dbObj->Param('advertisement_description') . ',' . ' advertisement_url=' . $this->dbObj->Param('advertisement_url') . ',' . ' advertisement_duration=' . $this->dbObj->Param('advertisement_duration') . ',' . ' advertisement_expiry_date=' . $this->dbObj->Param('advertisement_expiry_date') . ',' . ' advertisement_impressions=' . $this->dbObj->Param('advertisement_impressions') . ',' . ' advertisement_channel=' . $this->dbObj->Param('advertisement_channel') . ',' . ' advertisement_show_at=' . $this->dbObj->Param('advertisement_show_at') . ',' . ' add_type=' . $this->dbObj->Param('add_type') . ',' . ' advertisement_status=' . $this->dbObj->Param('advertisement_status') . ',' . ' views_revenue=' . $this->dbObj->Param('views_revenue') . ',' . ' clicks_revenue=' . $this->dbObj->Param('clicks_revenue') .
						$add_field . ' WHERE advertisement_id=\'' . addslashes($this->fields_arr['aid']) . '\'';
				$array = array($this->fields_arr['advertisement_name'], $this->fields_arr['advertisement_description'], $this->fields_arr['advertisement_url'], $this->fields_arr['advertisement_duration'], $expiry_date, $this->fields_arr['advertisement_impressions'], $channel, $this->fields_arr['advertisement_show_at'], $this->fields_arr['add_type'], $this->fields_arr['advertisement_status'], $this->fields_arr['views_revenue'], $this->fields_arr['clicks_revenue']);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array_merge($array, $add_arr));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function insertAdvertisementTable()
		{
				$expiry_date = $this->getFormField('year') . '-' . $this->getFormField('month') . '-' . $this->getFormField('day');
				$channel = implode(',', $this->fields_arr['advertisement_channel']);
				$sql = 'INSERT INTO ' . $this->CFG['db']['tbl']['ans_video_advertisement'] . ' SET' . ' advertisement_name=' . $this->dbObj->Param('advertisement_name') . ',' . ' user_id=' . $this->dbObj->Param('user_id') . ',' . ' advertisement_description=' . $this->dbObj->Param('advertisement_description') . ',' . ' advertisement_url=' . $this->dbObj->Param('advertisement_url') . ',' . ' advertisement_duration=' . $this->dbObj->Param('advertisement_duration') . ',' . ' advertisement_expiry_date=' . $this->dbObj->Param('advertisement_expiry_date') . ',' . ' advertisement_impressions=' . $this->dbObj->Param('advertisement_impressions') . ',' . ' advertisement_channel=' . $this->dbObj->Param('advertisement_channel') . ',' . ' advertisement_show_at=' . $this->dbObj->Param('advertisement_show_at') . ',' . ' add_type=' . $this->dbObj->Param('add_type') . ',' . ' advertisement_status=' . $this->dbObj->Param('advertisement_status') . ',' . ' views_revenue=' . $this->dbObj->Param('views_revenue') . ',' .
						' clicks_revenue=' . $this->dbObj->Param('clicks_revenue') . ',' . ' date_added=NOW()';
				$array = array($this->fields_arr['advertisement_name'], $this->CFG['user']['user_id'], $this->fields_arr['advertisement_description'], $this->fields_arr['advertisement_url'], $this->fields_arr['advertisement_duration'], $expiry_date, $this->fields_arr['advertisement_impressions'], $channel, $this->fields_arr['advertisement_show_at'], $this->fields_arr['add_type'], $this->fields_arr['advertisement_status'], $this->fields_arr['views_revenue'], $this->fields_arr['clicks_revenue']);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, $array);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($advertisement_id = $this->dbObj->Insert_ID())
				{
						$extern = strtolower(substr($_FILES['advertisement_file']['name'], strrpos($_FILES['advertisement_file']['name'], '.') + 1));
						$image_name = getImageName($advertisement_id);
						$dir = '../' . $this->CFG['admin']['ans_videos']['advertisement_folder'];
						$this->chkAndCreateFolder($dir);
						$this->deleteFiles($dir . $image_name);
						move_uploaded_file($_FILES['advertisement_file']['tmp_name'], $dir . $image_name . '.' . strtolower($extern));
						$sql = 'UPDATE ' . $this->CFG['db']['tbl']['ans_video_advertisement'] . ' SET' . ' advertisement_image=' . $this->dbObj->Param('advertisement_image') . ',' . ' advertisement_ext=' . $this->dbObj->Param('advertisement_ext') . ' WHERE' . ' advertisement_id=' . $this->dbObj->Param('advertisement_id');
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($image_name, $extern, $advertisement_id));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				}
		}
		public function checkValidDate($err_tip)
		{
				if (!$this->fields_arr['month'] and !$this->fields_arr['day'] and !$this->fields_arr['year']) return true;
				if ($this->fields_arr['month'] and $this->fields_arr['day'] and $this->fields_arr['year'])
				{
						if (checkdate($this->fields_arr['month'], $this->fields_arr['day'], $this->fields_arr['year'])) return true;
				}
				$this->fields_err_tip_arr['month'] = $err_tip;
				return false;
		}
		public function chkIsEditMode()
		{
				if ($this->fields_arr['aid'] and $this->fields_arr['act'] == 'edit') return true;
				return false;
		}
		public function populateAdvertisementList()
		{
				while ($row = $this->fetchResultRecord())
				{
?>
	<tr>
		<td><input type="checkbox" class="clsCheckRadio" name="aid[]"  value="<?php echo $row['advertisement_id']; ?>" tabindex="<?php echo $this->getTabIndex(); ?>" /></td>
		<td><?php echo $row['advertisement_name']; ?></td>
		<td><?php echo $row['advertisement_show_at']; ?></td>
		<td><?php echo $row['advertisement_duration']; ?></td>
<?php
						if ($this->CFG['admin']['ans_video_advertisement_impressions'])
						{
?>
		<td><?php echo $row['advertisement_impressions']; ?></td>
		<td><?php echo $row['advertisement_current_impressions']; ?></td>
		<td><?php echo $row['advertisement_expiry_date']; ?></td>
<?php
						}
?>
		<td><?php echo $row['add_type']; ?></td>
		<td><?php echo $row['advertisement_status']; ?></td>
		<td><a href="ansVideoAdvertisement.php?act=edit&aid=<?php echo $row['advertisement_id']; ?>&start=<?php echo $this->fields_arr['start']; ?>"><?php echo $this->LANG['edit']; ?></a></td>
	</tr>
<?php
				}
		}
		public function deleteAdvertisement()
		{
				$sql = 'DELETE FROM ' . $this->CFG['db']['tbl']['ans_video_advertisement'] . ' WHERE' . ' advertisement_id IN(' . $this->fields_arr['aid'] . ')';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$dir = '../' . $this->CFG['admin']['ans_videos']['advertisement_folder'];
				$array = explode(',', $this->fields_arr['aid']);
				foreach ($array as $key => $value)
				{
						$image_name = getImageName($value);
						$this->deleteFiles($dir . $image_name);
				}
		}
		public function changeStatusAdvertisement($status)
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['ans_video_advertisement'] . ' SET' . ' advertisement_status=' . $this->dbObj->Param('advertisement_status') . ' WHERE' . ' advertisement_id IN(' . $this->fields_arr['aid'] . ')';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($status));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function defaultValidation()
		{
				$this->checkValidDate($this->LANG['err_tip_invalid_date']);
				$this->getFormField('advertisement_impressions') and $this->chkIsNumeric('advertisement_impressions', $this->LANG['err_tip_numeric']);
				$this->getFormField('advertisement_duration') and $this->chkIsNumeric('advertisement_duration', $this->LANG['err_tip_numeric']);
		}
}
$advertisement = new advertisement();
$advertisement->setDBObject($db);
$advertisement->makeGlobalize($CFG, $LANG);
$advertisement_status_array = array('Activate' => $LANG['activate'], 'Inactive' => $LANG['inactivate']);
$advertisement->setPageBlockNames(array('msg_form_error', 'msg_form_success', 'advertisement_list', 'advertisement_upload_form'));
$advertisement->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$advertisement->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$advertisement->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$advertisement->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$advertisement->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$advertisement->resetFieldsArray();
$advertisement->setFormField('start', '0');
$advertisement->setFormField('orderby', 'DESC');
$advertisement->setFormField('orderby_field', 'advertisement_id');
$advertisement->setFormField('numpg', $CFG['data_tbl']['numpg']);
$advertisement->setCSSColumnHeaderCellAscSortClasses(array('clsColumnHeaderCellAscSort1', 'clsColumnHeaderCellAscSort2', 'clsColumnHeaderCellAscSort3', 'clsColumnHeaderCellAscSort4', 'clsColumnHeaderCellAscSort5'));
$advertisement->setCSSColumnHeaderCellDefaultClass('clsColumnHeaderCellDefault');
$advertisement->setCSSColumnHeaderCellDescSortClasses(array('clsColumnHeaderCellDscSort1', 'clsColumnHeaderCellDscSort2', 'clsColumnHeaderCellDscSort3', 'clsColumnHeaderCellDscSort4', 'clsColumnHeaderCellDscSort5'));
$advertisement->setMinRecordSelectLimit(2);
$advertisement->setMaxRecordSelectLimit($CFG['data_tbl']['max_record_select_limit']);
$advertisement->setNumPerPageListArr($CFG['data_tbl']['numperpage_list_arr']);
$advertisement->setTableNames(array($CFG['db']['tbl']['ans_video_advertisement']));
$advertisement->setReturnColumns(array('advertisement_id', 'user_id', 'advertisement_name', 'advertisement_description', 'advertisement_url', 'advertisement_duration', 'DATE_FORMAT(advertisement_expiry_date,\'' . $CFG['format']['date'] . '\') AS advertisement_expiry_date', 'advertisement_impressions', 'advertisement_channel', 'advertisement_image', 'advertisement_ext', 'advertisement_show_at', 'add_type', 'advertisement_status', 'DATE_FORMAT(date_added,\'' . $CFG['format']['date'] . '\') AS date_added', 'advertisement_current_impressions', 'views_revenue', 'clicks_revenue', 'site_earnings', 'members_earnings'));
$advertisement->setAllPageBlocksHide();
$advertisement->sanitizeFormInputs($_REQUEST);
$advertisement->setPageBlockShow('advertisement_list');
if ($advertisement->isFormPOSTed($_POST, 'add'))
{
		$advertisement->chkFileNameIsNotEmpty('advertisement_file', $LANG['err_tip_compulsory']) and $advertisement->chkValidFileType('advertisement_file', $LANG['err_tip_invalid_file_type']) and $advertisement->chkValideFileSize('advertisement_file', $LANG['err_tip_invalid_file_size']) and $advertisement->chkErrorInFile('advertisement_file', $LANG['err_tip_invalid_file']);
		$advertisement->defaultValidation();
		if ($advertisement->isValidFormInputs())
		{
				$advertisement->insertAdvertisementTable();
				$advertisement->setCommonErrorMsg($LANG['msg_success_added']);
				$advertisement->setPageBlockShow('msg_form_success');
		}
		else
		{
				$advertisement->setCommonErrorMsg($LANG['msg_error_sorry']);
				$advertisement->setAllPageBlocksHide();
				$advertisement->setPageBlockShow('msg_form_error');
				$advertisement->setPageBlockShow('advertisement_upload_form');
		}
}
else
		if ($advertisement->isFormPOSTed($_POST, 'update'))
		{
				$advertisement->advertisement = $advertisement->chkFileNameIsNotEmptyEdit('advertisement_file', $LANG['err_tip_compulsory']) and $advertisement->chkValidFileType('advertisement_file', $LANG['err_tip_invalid_file_type']) and $advertisement->chkValideFileSize('advertisement_file', $LANG['err_tip_invalid_file_size']) and $advertisement->chkErrorInFile('advertisement_file', $LANG['err_tip_invalid_file']);
				$advertisement->defaultValidation();
				if ($advertisement->isValidFormInputs())
				{
						$advertisement->updateAdvertisementTable();
						$advertisement->setCommonErrorMsg($LANG['msg_success_updated']);
						$advertisement->setPageBlockShow('msg_form_success');
				}
				else
				{
						$advertisement->setCommonErrorMsg($LANG['msg_error_sorry']);
						$advertisement->setAllPageBlocksHide();
						$advertisement->setPageBlockShow('msg_form_error');
						$advertisement->setPageBlockShow('advertisement_upload_form');
				}
		}
		else
				if ($advertisement->isFormPOSTed($_POST, 'yes'))
				{
						switch ($advertisement->getFormField('act'))
						{
								case 'Delete':
										$advertisement->deleteAdvertisement();
										$advertisement->setCommonErrorMsg($LANG['msg_success_deleted']);
										$advertisement->setPageBlockShow('msg_form_success');
										break;
								case 'Activate':
										$advertisement->changeStatusAdvertisement('Activate');
										$advertisement->setCommonErrorMsg($LANG['msg_success_activated']);
										$advertisement->setPageBlockShow('msg_form_success');
										break;
								case 'Inactivate':
										$advertisement->changeStatusAdvertisement('Inactive');
										$advertisement->setCommonErrorMsg($LANG['msg_success_inactivated']);
										$advertisement->setPageBlockShow('msg_form_success');
										break;
						}
				}
				else
						if ($advertisement->isFormPOSTed($_GET, 'act'))
						{
								switch ($advertisement->getFormField('act'))
								{
										case 'add':
												$LANG['page_title'] = $LANG['page_add_title'];
												$advertisement->setAllPageBlocksHide();
												$advertisement->setPageBlockShow('advertisement_upload_form');
												break;
										case 'edit':
												if ($advertisement->chkIsEditMode())
												{
														if ($advertisement->populateadvertisementDetails())
														{
																$LANG['page_title'] = $LANG['page_edit_title'];
																$advertisement->setAllPageBlocksHide();
																$advertisement->setPageBlockShow('advertisement_upload_form');
														}
														else
														{
																$advertisement->setCommonErrorMsg($LANG['msg_error_sorry']);
																$advertisement->setPageBlockShow('msg_form_error');
														}
												}
												break;
								}
						}



?>
<script type="text/javascript" language="javascript">
	var block_arr= new Array('selMsgConfirm');
</script>
<div id="seladvertisement">
  <h2 class="clsVideoAdvertisement"><span><?php echo $LANG['page_title']; ?></span></h2>
<?php
if ($advertisement->getFormField('act') != 'add')
{
?>
  <p class="clsAdvertisement"><a href="ansVideoAdvertisement.php?act=add"><?php echo $LANG['add_new_advertisement']; ?></a></p>
<?php
}
?>
  <div id="selLeftNavigation">
<?php
if ($advertisement->isShowPageBlock('msg_form_error'))
{
?>
    <div id="selMsgError">
      <p><?php echo $advertisement->getCommonErrorMsg(); ?></p>
    </div>
<?php
}
if ($advertisement->isShowPageBlock('msg_form_success'))
{
?>
    <div id="selMsgSuccess">
      <p><?php echo $advertisement->getCommonErrorMsg(); ?></p>
    </div>
<?php
}
if ($advertisement->isShowPageBlock('advertisement_upload_form'))
{
?>
    <div id="selUpload">
	  <form name="advertisement_upload_form" id="advertisement_upload_form" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" autocomplete="off" enctype="multipart/form-data">
		<div id="selUploadBlock">
          <table summary="<?php echo $LANG['advertisement_tbl_summary']; ?>" id="selUploadTbl" class="clsCommonTable clsUploadBlock">
		  	<tr>
              <td class="<?php echo $advertisement->getCSSFormLabelCellClass('advertisement_name'); ?>">
                <label for="advertisement_name"><?php echo $LANG['advertisement_name']; ?></label> </td>
              <td class="<?php echo $advertisement->getCSSFormFieldCellClass('advertisement_name'); ?>"><?php echo $advertisement->getFormFieldErrorTip('advertisement_name'); ?>
                <input type="text" class="clsTextBox" name="advertisement_name" id="advertisement_name" tabindex="<?php echo $advertisement->getTabIndex(); ?>" value="<?php echo $advertisement->getFormField('advertisement_name'); ?>" /></td>
            </tr>
			<tr>
              <td class="<?php echo $advertisement->getCSSFormLabelCellClass('advertisement_description'); ?>">
                <label for="advertisement_description"><?php echo $LANG['advertisement_description']; ?></label> </td>
              <td class="<?php echo $advertisement->getCSSFormFieldCellClass('advertisement_description'); ?>"><?php echo $advertisement->getFormFieldErrorTip('advertisement_description'); ?>
                <textarea name="advertisement_description" id="advertisement_description" tabindex="<?php echo $advertisement->getTabIndex(); ?>"><?php echo $advertisement->getFormField('advertisement_description'); ?></textarea></td>
            </tr>
			<tr>
              <td class="<?php echo $advertisement->getCSSFormLabelCellClass('advertisement_url'); ?>">
                <label for="advertisement_url"><?php echo $LANG['advertisement_url']; ?></label> </td>
              <td class="<?php echo $advertisement->getCSSFormFieldCellClass('advertisement_url'); ?>"><?php echo $advertisement->getFormFieldErrorTip('advertisement_url'); ?>
                <input type="text" class="clsTextBox" name="advertisement_url" id="advertisement_url" tabindex="<?php echo $advertisement->getTabIndex(); ?>" value="<?php echo $advertisement->getFormField('advertisement_url'); ?>" /></td>
            </tr>
			<tr>
              <td class="<?php echo $advertisement->getCSSFormLabelCellClass('advertisement_duration'); ?>">
                <label for="advertisement_duration"><?php echo $LANG['advertisement_duration']; ?></label> </td>
              <td class="<?php echo $advertisement->getCSSFormFieldCellClass('advertisement_duration'); ?>"><?php echo $advertisement->getFormFieldErrorTip('advertisement_duration'); ?>
                <input type="text" class="clsTextBox" name="advertisement_duration" id="advertisement_duration" tabindex="<?php echo $advertisement->getTabIndex(); ?>" value="<?php echo $advertisement->getFormField('advertisement_duration'); ?>" />&nbsp;<?php echo $LANG['seconds']; ?></td>
            </tr>
<?php
		if ($CFG['admin']['ans_video_advertisement_impressions'])
		{
?>
			<tr>
              <td class="<?php echo $advertisement->getCSSFormLabelCellClass('month'); ?>">
                <label for="month"><?php echo $LANG['advertisement_expiry_date']; ?></label> </td>
              <td class="<?php echo $advertisement->getCSSFormFieldCellClass('advertisement_expiry_date'); ?>"><?php echo $advertisement->getFormFieldErrorTip('month'); ?>
                <!--<input type="text" class="clsTextBox" name="advertisement_expiry_date" id="advertisement_expiry_date" tabindex="<?php echo $advertisement->getTabIndex(); ?>" value="<?php echo $advertisement->getFormField('advertisement_expiry_date'); ?>" />&nbsp;(YYYY-MM-DD HH:MM:SS)-->
				<select name="month" id="month" tabindex="<?php echo $advertisement->getTabIndex(); ?>">
                  <option value=""><?php echo $LANG['select_month']; ?></option>
                  <?php $advertisement->populateBWNumbers(1, 12, $advertisement->getFormField('month')); ?>
                </select>
                <select name="day" id="day" tabindex="<?php echo $advertisement->getTabIndex(); ?>">
                  <option value=""><?php echo $LANG['select_day']; ?></option>
                  <?php $advertisement->populateBWNumbers(1, 31, $advertisement->getFormField('day')); ?>
                </select>
                <select name="year" id="year" tabindex="<?php echo $advertisement->getTabIndex(); ?>">
                  <option value=""><?php echo $LANG['select_year']; ?></option>
                  <?php $advertisement->populateBWNumbers(date('Y') - 20, date('Y') + 20, $advertisement->getFormField('year')); ?>
                </select>
			  </td>
            </tr>
			<tr>
              <td class="<?php echo $advertisement->getCSSFormLabelCellClass('advertisement_impressions'); ?>">
                <label for="advertisement_impressions"><?php echo $LANG['advertisement_impressions']; ?></label> </td>
              <td class="<?php echo $advertisement->getCSSFormFieldCellClass('advertisement_impressions'); ?>"><?php echo $advertisement->getFormFieldErrorTip('advertisement_impressions'); ?>
                <input type="text" class="clsTextBox" name="advertisement_impressions" id="advertisement_impressions" tabindex="<?php echo $advertisement->getTabIndex(); ?>" value="<?php echo $advertisement->getFormField('advertisement_impressions'); ?>" /></td>
            </tr>
<?php
		}
?>
			<tr>
              <td class="<?php echo $advertisement->getCSSFormLabelCellClass('advertisement_show_at'); ?>">
                <label for="advertisement_show_at"><?php echo $LANG['advertisement_show_at']; ?></label> </td>
              <td class="<?php echo $advertisement->getCSSFormFieldCellClass('advertisement_show_at'); ?>"><?php echo $advertisement->getFormFieldErrorTip('advertisement_show_at'); ?>
                <input type="radio" class="clsCheckRadio" name="advertisement_show_at" id="advertisement_show_at1" tabindex="<?php echo $advertisement->getTabIndex(); ?>" value="Begining" <?php echo $advertisement->isCheckedRadio('advertisement_show_at', 'Begining'); ?> />&nbsp;<label for="advertisement_show_at1"><?php echo $LANG['begining']; ?></label>
				<input type="radio" class="clsCheckRadio" name="advertisement_show_at" id="advertisement_show_at2" tabindex="<?php echo $advertisement->getTabIndex(); ?>" value="Ending" <?php echo $advertisement->isCheckedRadio('advertisement_show_at', 'Ending'); ?> />&nbsp;<label for="advertisement_show_at2"><?php echo $LANG['ending']; ?></label>
				<input type="radio" class="clsCheckRadio" name="advertisement_show_at" id="advertisement_show_at3" tabindex="<?php echo $advertisement->getTabIndex(); ?>" value="Both" <?php echo $advertisement->isCheckedRadio('advertisement_show_at', 'Both'); ?> />&nbsp;<label for="advertisement_show_at3"><?php echo $LANG['both']; ?></label>
			  </td>
            </tr>
			<tr>
              <td class="<?php echo $advertisement->getCSSFormLabelCellClass('advertisement_file'); ?>">
                <label for="advertisement_file"><?php echo $LANG['advertisement_file']; ?></label> </td>
              <td class="<?php echo $advertisement->getCSSFormFieldCellClass('advertisement_file'); ?>"><?php echo $advertisement->getFormFieldErrorTip('advertisement_file'); ?>
              <?php if ($advertisement->chkIsEditMode())
		{ ?>
			   <div id="selLeftPlainImage">
					<p id="selImageBorder"><span id="selPlainCenterImage"><?php $advertisement->getadvertisementImage(); ?></span></p>
			   </div>
			   <?php } ?>
			   <input type="file" class="clsFileBox" accept="image/<?php echo implode(', ', $CFG['admin']['ans_videos']['advertisement_format_arr']); ?>" name="advertisement_file" id="advertisement_file" tabindex="<?php echo $advertisement->getTabIndex(); ?>" />
                (<?php echo $CFG['admin']['ans_videos']['advertisement_max_size']; ?>&nbsp;KB)</td>
            </tr>
			<tr>
              <td class="<?php echo $advertisement->getCSSFormLabelCellClass('advertisement_status'); ?>">
                <label for="advertisement_status"><?php echo $LANG['advertisement_status']; ?></label> </td>
              <td class="<?php echo $advertisement->getCSSFormFieldCellClass('advertisement_status'); ?>"><?php echo $advertisement->getFormFieldErrorTip('advertisement_status'); ?>
                <select name="advertisement_status" id="advertisement_status" tabindex="<?php echo $advertisement->getTabIndex(); ?>">
					<?php $advertisement->generalPopulateArray($advertisement_status_array, $advertisement->getFormField('advertisement_status')); ?>
				</select></td>
            </tr>
            <tr>
            <td>&nbsp;</td>
              <td class="clsFormFieldCellDefault">
<?php
		if ($advertisement->chkIsEditMode())
		{
				$advertisement->populateHidden(array('advertisement_image', 'advertisement_ext', 'aid', 'start', 'act'));
?>
				<input type="submit" class="clsSubmitButton" name="update" id="update" tabindex="<?php echo $advertisement->getTabIndex(); ?>" value="<?php echo $LANG['update']; ?>" />
<?php
		}
		else
		{
?>
              	<input type="submit" class="clsSubmitButton" name="add" id="add" tabindex="<?php echo $advertisement->getTabIndex(); ?>" value="<?php echo $LANG['add']; ?>" />
<?php
		}
?>
			  	<input type="submit" class="clsCancelButton" name="cancel" id="cancel" tabindex="<?php echo $advertisement->getTabIndex(); ?>" value="<?php echo $LANG['cancel']; ?>" />
			  </td>
            </tr>
          </table>
        </div>
      </form>
    </div>
<?php
}
if ($advertisement->isShowPageBlock('advertisement_list'))
{
		$advertisement->buildSelectQuery();
		$advertisement->buildConditionQuery();
		$advertisement->buildSortQuery();
		$advertisement->buildQuery();
		$advertisement->executeQuery();
		if ($advertisement->isResultsFound())
		{
				$anchor = 'dAltMlti';
?>
		<div id="selMsgConfirm" class="clsMsgConfirm" style="display:none;position:absolute;">
    		<p id="selMsgText"></p>
	      	<form name="actionForm" id="actionForm" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" autocomplete="off">
	        	<table summary="<?php echo $LANG['advertisement_tbl_summary']; ?>">
				  	<tr>
		            	<td>
						  	<input type="submit" class="clsSubmitButton" name="yes" id="yes" value="<?php echo $LANG['yes']; ?>" tabindex="<?php echo $advertisement->getTabIndex(); ?>" /> &nbsp;
			              	<input type="button" class="clsCancelButton" name="no" id="no" value="<?php echo $LANG['no']; ?>" tabindex="<?php echo $advertisement->getTabIndex(); ?>" onClick="return hideAllBlocks();" />
			              	<input type="hidden" name="aid" id="aid" />
							<input type="hidden" name="act" id="act" />
							<?php $advertisement->populateHidden(array('orderby', 'orderby_field', 'start')); ?>
						</td>
		          	</tr>
	        	</table>
	      	</form>
	    </div>
		<div id="advertisementListBlock">
			<form name="listAddForm" id="listAddForm" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" autocomplete="off">
<?php
				if ($CFG['admin']['navigation']['top']) $advertisement->populatePageLinksPOST($advertisement->getFormField('start'), 'listAddForm');
?>
				<table summary="<?php echo $LANG['advertisement_tbl_summary']; ?>">
					<tr>
						<th class="clsSelectAllItems"><input type="checkbox" class="clsCheckRadio" name="check_all" tabindex="<?php echo $advertisement->getTabIndex(); ?>" onclick="CheckAll(document.listAddForm.name, document.listAddForm.check_all.name)" /></th>
						<th><p<?php echo $advertisement->getOrderCss('advertisement_name'); ?>><a href="#" onClick="return changeOrderbyElements('listAddForm','advertisement_name')"><?php echo $LANG['advertisement_name']; ?></a></p></th>
						<th><p<?php echo $advertisement->getOrderCss('advertisement_show_at'); ?>><a href="#" onClick="return changeOrderbyElements('listAddForm','advertisement_show_at')"><?php echo $LANG['advertisement_show_at']; ?></a></p></th>
						<th><p<?php echo $advertisement->getOrderCss('advertisement_duration'); ?>><a href="#" onClick="return changeOrderbyElements('listAddForm','advertisement_duration')"><?php echo $LANG['advertisement_duration']; ?></a></p></th>
<?php
				if ($CFG['admin']['ans_video_advertisement_impressions'])
				{
?>
						<th><p<?php echo $advertisement->getOrderCss('advertisement_impressions'); ?>><a href="#" onClick="return changeOrderbyElements('listAddForm','advertisement_impressions')"><?php echo $LANG['advertisement_impressions']; ?></a></p></th>
						<th><p<?php echo $advertisement->getOrderCss('advertisement_current_impressions'); ?>><a href="#" onClick="return changeOrderbyElements('listAddForm','advertisement_current_impressions')"><?php echo $LANG['advertisement_current_impressions']; ?></a></p></th>
						<th><p<?php echo $advertisement->getOrderCss('advertisement_expiry_date'); ?>><a href="#" onClick="return changeOrderbyElements('listAddForm','advertisement_expiry_date')"><?php echo $LANG['advertisement_expiry_date']; ?></a></p></th>
<?php
				}
?>
						<th><p<?php echo $advertisement->getOrderCss('add_type'); ?>><a href="#" onClick="return changeOrderbyElements('listAddForm','add_type')"><?php echo $LANG['add_type']; ?></a></p></th>
						<th><p<?php echo $advertisement->getOrderCss('advertisement_status'); ?>><a href="#" onClick="return changeOrderbyElements('listAddForm','advertisement_status')"><?php echo $LANG['advertisement_status']; ?></a></p></th>
						<th>&nbsp;</th>
					</tr>
					<?php $advertisement->populateAdvertisementList(); ?>
					<tr>
						<td class="<?php echo $advertisement->getCSSFormFieldCellClass('privacy_status'); ?>" colspan="15">
							<?php $advertisement->populateHidden(array('orderby', 'orderby_field', 'start')); ?>
							<a href="#" id="<?php echo $anchor; ?>"></a>
							<input type="button" class="clsSubmitButton" name="delete_submit" id="delete_submit" tabindex="<?php echo $advertisement->getTabIndex(); ?>" value="<?php echo $LANG['delete']; ?>" onClick="if(getMultiCheckBoxValue('listAddForm', 'check_all', '<?php echo $LANG['check_atleast_one']; ?>', '<?php echo $anchor; ?>', -100, -500)){Confirmation('<?php echo $anchor; ?>', 'selMsgConfirm', 'actionForm', Array('aid', 'act', 'selMsgText'), Array(multiCheckValue, 'Delete', '<?php echo $LANG['delete_confirmation']; ?>'), Array('value', 'value', 'innerHTML'), -100, -500);}" />
							<input type="button" class="clsSubmitButton" name="activate_submit" id="activate_submit" tabindex="<?php echo $advertisement->getTabIndex(); ?>" value="<?php echo $LANG['activate']; ?>" onClick="if(getMultiCheckBoxValue('listAddForm', 'check_all', '<?php echo $LANG['check_atleast_one']; ?>', '<?php echo $anchor; ?>', -100, -500)){Confirmation('<?php echo $anchor; ?>', 'selMsgConfirm', 'actionForm', Array('aid', 'act', 'selMsgText'), Array(multiCheckValue, 'Activate', '<?php echo $LANG['activate_confirmation']; ?>'), Array('value', 'value', 'innerHTML'), -100, -500);}" />
							<input type="button" class="clsSubmitButton" name="inactivate_submit" id="inactivate_submit" tabindex="<?php echo $advertisement->getTabIndex(); ?>" value="<?php echo $LANG['inactivate']; ?>" onClick="if(getMultiCheckBoxValue('listAddForm', 'check_all', '<?php echo $LANG['check_atleast_one']; ?>', '<?php echo $anchor; ?>', -100, -500)){Confirmation('<?php echo $anchor; ?>', 'selMsgConfirm', 'actionForm', Array('aid', 'act', 'selMsgText'), Array(multiCheckValue, 'Inactivate', '<?php echo $LANG['inactivate_confirmation']; ?>'), Array('value', 'value', 'innerHTML'), -100, -500);}" />
						</td>
				   	</tr>
				</table>
<?php
				if ($CFG['admin']['navigation']['bottom']) $advertisement->populatePageLinksPOST($advertisement->getFormField('start'), 'listAddForm');
?>
			</form>
		</div>
<?php
		}
		else
		{
?>
		<div id="selMsgAlert">
			<p><?php echo $LANG['no_records_found']; ?></p>
		</div>
<?php
		}
}
?>
  </div>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>
