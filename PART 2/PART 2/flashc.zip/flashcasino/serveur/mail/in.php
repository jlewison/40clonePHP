<?
$reg_reg_mail_subject="Compte credit� ";

$reg_reg_mail="Compte cr�diter de :$l de $rog[12]";
?>