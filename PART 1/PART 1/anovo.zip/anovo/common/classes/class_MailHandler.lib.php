<?php
if (class_exists('ListRecordsHandler'))
{
		class Handler extends ListRecordsHandler
		{
		}
}
else
{
		class Handler extends FormHandler
		{
		}
}
class MailHandler extends Handler
{
		public $allowed_folder = array('inbox', 'sent');
		public $updateNewMailInFolder = array('inbox');
		public $mail_title = '';
		public function chkIsValidFolder()
		{
				$ok = true;
				if (!in_array($this->fields_arr['folder'], $this->allowed_folder)) $ok = false;
				return $ok;
		}
		public function getMailReadNormalUrl()
		{
				switch ($this->fields_arr['folder'])
				{
						case 'inbox':
								$normalUrl = $this->CFG['admin']['mail_urls']['read_inbox']['normal'];
								break;
						case 'sent':
								$normalUrl = $this->CFG['admin']['mail_urls']['read_sent']['normal'];
								break;
						default:
								$normalUrl = $this->CFG['admin']['mail_urls']['read_inbox']['normal'];
								break;
				}
				return $normalUrl;
		}
		public function getMailReadHtaccessUrl()
		{
				switch ($this->fields_arr['folder'])
				{
						case 'inbox':
								$htaccessUrl = $this->CFG['admin']['mail_urls']['read_inbox']['htaccess'];
								break;
						case 'sent':
								$htaccessUrl = $this->CFG['admin']['mail_urls']['read_sent']['htaccess'];
								break;
						default:
								$htaccessUrl = $this->CFG['admin']['mail_urls']['read_inbox']['htaccess'];
								break;
				}
				return $htaccessUrl;
		}
		public function getMailListNormalUrl()
		{
				switch ($this->fields_arr['folder'])
				{
						case 'inbox':
								$normalUrl = $this->CFG['admin']['mail_urls']['inbox']['normal'];
								break;
						case 'sent':
								$normalUrl = $this->CFG['admin']['mail_urls']['sent']['normal'];
								break;
						default:
								$normalUrl = $this->CFG['admin']['mail_urls']['inbox']['normal'];
								break;
				}
				return $normalUrl;
		}
		public function getMailListHtaccessUrl()
		{
				switch ($this->fields_arr['folder'])
				{
						case 'inbox':
								$htaccessUrl = $this->CFG['admin']['mail_urls']['inbox']['htaccess'];
								break;
						case 'sent':
								$htaccessUrl = $this->CFG['admin']['mail_urls']['sent']['htaccess'];
								break;
						default:
								$htaccessUrl = $this->CFG['admin']['mail_urls']['inbox']['htaccess'];
								break;
				}
				return $htaccessUrl;
		}
		public function updateMessageStatusDelete($column_name, $message_ids)
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['messages_info'] . ' SET ' . $column_name . ' = \'Yes\' WHERE info_id IN (' . $message_ids . ')';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return true;
		}
		public function updateMessageStatusTrash($column_name, $message_ids)
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['messages_info'] . ' SET ' . $column_name . ' = \'Trash\' WHERE info_id IN (' . $message_ids . ') ';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return true;
		}
		public function countUnReadMail()
		{
				$sql = 'SELECT COUNT( mi.info_id ) AS mail_count' . ' FROM ' . $this->CFG['db']['tbl']['users'] . ' AS u, ' . $this->CFG['db']['tbl']['messages'] . ' AS ms, ' . $this->CFG['db']['tbl']['messages_info'] . ' AS mi' . ' WHERE mi.to_id = ' . $this->dbObj->Param($this->CFG['user']['user_id']) . ' AND mi.from_id = u.' . $this->getUserTableField('user_id') . ' AND mi.message_id = ms.message_id' . ' AND mi.to_viewed = \'No\'' . ' AND mi.to_delete = \'No\'' . ' AND mi.to_stored = \'No\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->CFG['user']['user_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = $rs->FetchRow();
				return $row['mail_count'];
		}
		public function sendInternalMail($from_id, $to_id, $subject, $message)
		{
				$message_id = $this->insertMessages($subject, $message);
				$this->insertMessagesInfo($from_id, $to_id, $message_id);
				return true;
		}
		public function insertMessages($subject, $message)
		{
				$sql = 'INSERT INTO ' . $this->CFG['db']['tbl']['messages'] . ' SET subject = ' . $this->dbObj->Param($subject) . ', message = ' . $this->dbObj->Param($message) . ', mess_date = NOW()';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($subject, $message));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return $this->dbObj->Insert_ID();
		}
		public function insertMessagesInfo($from_id, $to_id, $message_id)
		{
				$sql = 'INSERT INTO ' . $this->CFG['db']['tbl']['messages_info'] . ' SET message_id = ' . $this->dbObj->Param($message_id) . ', from_id = ' . $this->dbObj->Param($from_id) . ', to_id = ' . $this->dbObj->Param($to_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($message_id, $from_id, $to_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return true;
		}
		public function messageContentReplace($message, $keywords_arr)
		{
				foreach ($keywords_arr as $key => $value)
				{
						$message = str_replace('{' . $key . '}', $value, $message);
				}
				return $message;
		}
}
?>
