<?php include('restrict.php'); include('../settings.php'); require_once('../Connections/apound.php'); ?>
<?php
mysql_select_db($database_apound, $apound);
$query_Recordset1 = "SELECT * FROM categorylisting WHERE categorylisting.parentid = '0'";
$Recordset1 = mysql_query($query_Recordset1, $apound) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Manage Main Categories - Link Bid Script Admin Panel</title>
<link rel="shortcut icon" href="img/favicon.ico" />
<link rel="stylesheet" type="text/css" href="admin.css" />
</head>

<body>
<?php include('header_tpl.php'); ?>
<h2>Manage Main Categories</h2>
<table width="770"  border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
  <tr>
    <td width="770"><?php $x = getenv("HTTP_HOST").getenv("REQUEST_URI"); echo("<font color=white>$x</font>"); ?></td>
  </tr>
</table>
<?php $upd = $_GET[upd]; if($upd == 'Y') { echo("<div align='center'><font color='red'><b>Update ... DONE</b></font></div>"); } else { } ?>
<table width="770"  border="0" align="center" cellpadding="3" cellspacing="1" bgcolor="#FFFFFF">
  <tr>
    <td width="760" valign="top">      <table width="100%" border="0" cellpadding="3" cellspacing="3">
        <tr bgcolor="#FFFFFF" class="style80">
          <td colspan="8"><a href="category_add.php" class="style82">add new category</a> </td>
        </tr>
        <tr bgcolor="#FFFF00" class="style80">
          <td width="16%">ID</td>
          <td width="21%">category name</td>
          <td width="21%">SEO name</td>
          <td width="9%" align="center">Active?</td>
          <td width="8%" align="center">Edit</td>
          <td width="8%" align="center">Enable</td>
          <td width="8%" align="center">Disable</td>
          <td width="9%" align="center">Delete</td>
          </tr>
        <?php do { ?>
        <tr class="style70">
          <td><?php echo $row_Recordset1['catlistid']; ?></td>
          <td><?php echo $row_Recordset1['categoryname']; ?></td>
          <td><?php echo $row_Recordset1['categseoname']; ?></td>
          <td align="center"><?php $enabled = $row_Recordset1['categenable']; if($enabled == 'Y') { print'<img src="img/ico-live.gif" alt="Active" />'; } else { print'<img src="img/ico-pending.gif" alt="Pending" />'; }?></td>
          <td align="center"><a href="categedit.php?id=<?php echo $row_Recordset1['catlistid'];?>"><img src="img/ico-edit.gif" alt="Edit" /></a></td>
          <td align="center"><a href="categenable.php?id=<?php echo $row_Recordset1['catlistid'];?>"><?php if($enabled == 'Y') { print''; } else { print'<img src="img/ico-activate.png" alt="Activate" />'; }?></a></td>
          <td align="center"><a href="categdisable.php?id=<?php echo $row_Recordset1['catlistid'];?>"><?php if($enabled == 'Y') { print'<img src="img/ico-suspend.gif" alt="Suspend" />'; } else { print''; }?></a></td>
          <td align="center"><a href="categdelete.php?id=<?php echo $row_Recordset1['catlistid'];?>"><img src="img/ico-delete.gif" alt="Delete" /></a></td>
          </tr>
        <tr bgcolor="#CCCCCC" class="style70">
          <td height="1" colspan="8"></td>
        </tr>
        <?php } while ($row_Recordset1 = mysql_fetch_assoc($Recordset1)); ?>
    </table></td>
  </tr>
</table>
<?php include('footer_tpl.php'); ?>
</body>
</html>
<?php
mysql_free_result($Recordset1);
?>