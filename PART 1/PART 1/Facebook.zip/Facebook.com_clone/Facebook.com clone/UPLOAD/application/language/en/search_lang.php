<?php

$lang['page_title']						= 'Search';

$lang['search_title']					= 'Search';
$lang['search_advanced_title']			= 'Advanced Search';
$lang['search_question']				= 'What is Advanced Search?';
$lang['search_note']					= 'Advanced search will only search within your friends and people from India.';
$lang['search_within']					= 'Search within';
$lang['search_basic_info']				= 'Basic Info';
$lang['search_name']					= 'Name';
$lang['search_interested_in']			= 'Interested In';
$lang['search_sex']						= 'Sex';
$lang['search_relationship_status']		= 'Relationship Status';
$lang['search_home_town']				= 'Home Town';
$lang['search_looking_for']				= 'Looking For';
$lang['search_political_views']			= 'Political Views';
$lang['search_relegious_views']			= 'Religious Views';
$lang['search_contact_info']			= 'Contact Info';
$lang['search_email']					= 'Email';
$lang['search_city']					= 'City';
$lang['search_screen_name']				= 'Screen Name';
$lang['search_state']					= 'State';
$lang['search_mobile']					= 'Mobile';
$lang['search_country']					= 'Country';
$lang['search_land_phone']				= 'Land Phone';
$lang['search_zip']						= 'Zip';
$lang['search_personal_info']			= 'Person Info';
$lang['search_activities']				= 'Activities';
$lang['search_tv_show']					= 'TV Show';
$lang['search_interest']				= 'Interest';
$lang['search_movie']					= 'Movie';
$lang['search_music']					= 'Music';
$lang['search_book']					= 'Book';
$lang['search_education_info']			= 'Education Info';
$lang['search_school']					= 'School';
$lang['search_concentration']			= 'Concentration';
$lang['search_college']					= 'College';
$lang['search_class_year']				= 'Class Year';
$lang['search_work_info']				= 'Work Info';
$lang['search_company']					= 'Company';
$lang['search_position']				= 'Position';

$lang['search_network']					= 'Network';
$lang['search_block_person']			= 'Block Person';
$lang['search_add_friend']				= 'Add as Friend';
$lang['search_send_msg']				= 'Send Message';
$lang['search_view_friends']			= 'View Friends';
$lang['search_remove_friends']			= 'Remove Friend';
$lang['search_msg']						= 'Message';
$lang['search_question_1']				= 'Are you sure in removing';
$lang['search_question_2']				= 'from your friends list';

$lang['search_my_networks']				= 'My Networks';
$lang['search_friends']					= 'Friends';
$lang['search_women']					= 'Women';
$lang['search_men']						= 'Men';
$lang['search_both']					= 'Both';

$lang['search_type']					= 'Type';
$lang['search_country']					= 'Country';
$lang['search_members']					= 'Members';
$lang['search_join_network']			= 'Join Network';

$lang['search_peoples']			= 'Peoples';
$lang['search_events']			= 'Events';
$lang['search_groups']			= 'Groups';
$lang['search_networks']		= 'Networks';
$lang['search_start_date']		= 'Start Date';
$lang['search_view_event']		= 'View Event';
$lang['search_group_type']		= 'Group Type';
$lang['search_view_group']		= 'View Group';
$lang['search_view_network']	= 'View Network';
$lang['search_no_yields']		= 'Your search yields no results';

$lang['search_no_results']		= 'No matching results.';


?>