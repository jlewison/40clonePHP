<? include ("header.php"); ?>






<table cellpadding="0" cellspacing="0" border="0" width="100%">
	<tr class="top3">
		<td colspan="3"><img src="template/v3/i/b.gif" border="0" height="15" width="1"></td>
	</tr>
	<tr class="top4">
		<td>&nbsp;</td>
		<td align="center">
			<table cellpadding="0" cellspacing="0" border="0" width="778">
				<tr>
					<td valign="top" height="109"><object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" width="257" height="109" id="logo" align="middle"><param name="movie" value="flash/logo.swf" /><param name="quality" value="high" /><param name="wmode" value="transparent" /><param name="bgcolor" value="#ffffff" /><embed src="flash/logo.swf" quality="high" wmode="transparent" bgcolor="#ffffff" width="257" height="109" name="rotator" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /></object></td>
					<td valign="top" height="109"><img src="template/v3/i/content12.jpg" border="0"></td>
					<td rowspan="3" valign="top" class="box_right"><object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" width="204" height="128" id="innerstar" align="middle"><param name="allowScriptAccess" value="sameDomain" /><param name="movie" value="flash/innerstar.swf" /><param name="quality" value="high" /><param name="wmode" value="transparent" /><param name="bgcolor" value="#ffffff" /><embed src="flash/innerstar.swf" quality="high" wmode="transparent" bgcolor="#ffffff" width="204" height="128" name="innerstar" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /></object><a href="promotions.php"><img src="template/v3/i/innerstar-1b2.gif" border="0"></a>
						





<? include ("mg.php"); ?>
				<tr>
					<td class="subtitle_path" colspan="2" valign="top" height="35"><div><a href="index.php"><img src="template/v3/i/home_ico.jpg" border="0" vspace="0" style="margin-left: 36px;margin-right: 27px" align="left"></a></div>Promotions</td>
				</tr>
				<tr>
					<td colspan="2" class="content" valign="top"><img src="template/v3/i/b.gif" width="1" height="500" border="0" align="left"><h2>We are delighted to welcome you to PlayCasino!</h2>
<br>
<img src="template/v3/i/promotions_1234.jpg" align="right" border="0">
We want our regular players to enjoy the best promotions and comps on the net. <br>
Come back regularly to see our latest offers! <br>
<br>
<b>* Note: </b><br>
If you are an existing player and have not been receiving operational, payout related or promotional email from the Casino Network, it is possible that you have not added us to your address book or safe list. For instructions on how to do this, please contact our <a href="support.html">support staff</a>.<br>
<br>
<h2>Amazing Bonuses: <b>$ 750</b> <span>FREE Bonus</span></h2><br>
Not only will <b>Casino</b> give you <b>$150</b> for free on your first deposit, but we will continue to give you amazing bonuses on your following 3 deposits.<br>
We will give you <b>$750</b> for FREE!<br>
<br>
Just follow these 4 easy steps and collect your <b>FREE MONEY!</b><br>
<br>
<b>Please be sure to enter the bonus code claim  BEFORE you deposit and wager with the casino.</b><br>
<br>
<table cellpadding="0" cellspacing="0" border="0">
	<tr>
		<td>&nbsp;</td>
		<td rowspan="3"><img src="template/v3/i/b.gif" width="10" border="0"></td>
		<td class="coupon1">On Your First Deposit: <b>$ 150 FREE Bonus</b></td>
	</tr>
	<tr>
		<td rowspan="2" class="coupon2" valign="top"><img src="template/v3/i/coupon1.jpg" border="0"><br><img src="template/v3/i/coupon_bj.jpg" border="0"><br>COUPON CODE<br><b>JYVNK</b></td>
		<td class="coupon3" valign="top"><h3>Get a <b>100% Match Bonus</b> on your 1st Deposit</h3><br>
			With Casino's Welcome Bonus, we will match your first deposit dollar-for-dollar <b>up to $150</b>.<br>
			Deposit only $150 - <b>play with $300</b>!</td>
	</tr>
	<tr>
		<td class="coupon3" align="right" valign="top"><a href="javascript: popup('new_player_terms.html');">Terms and Conditions</a></td>
	</tr>
	<tr>
		<td colspan="3" height="30">&nbsp;</td>
	</tr>
	<tr>
		<td>&nbsp;</td>
		<td rowspan="3"><img src="template/v3/i/b.gif" width="10" border="0"></td>
		<td class="coupon1">On Your Second Deposit: <b>$ 150 FREE Bonus</b></td>
	</tr>
	<tr>
		<td rowspan="2" class="coupon2" valign="top"><img src="template/v3/i/coupon2.jpg" border="0"><br>COUPON CODE<br><b>DXURV</b></td>
		<td class="coupon3" valign="top"><h3>Then get <b>25 % More</b> on your 2nd Deposit</h3><br>
			When you are ready to make your 2nd deposit, contact us and we'll give you another <b>25% bonus</b>!</td>
	</tr>
	<tr>
		<td class="coupon3" align="right" valign="top"><a href="javascript: popup('new_player_terms.html');">Terms and Conditions</a></td>
	</tr>
	<tr>
		<td colspan="3" height="30">&nbsp;</td>
	</tr>
	<tr>
		<td>&nbsp;</td>
		<td rowspan="3"><img src="template/v3/i/b.gif" width="10" border="0"></td>
		<td class="coupon1">On Your Third Deposit: <b>$ 250 FREE Bonus</b></td>
	</tr>
	<tr>
		<td rowspan="2" class="coupon2" valign="top"><img src="template/v3/i/coupon3.jpg" border="0"><br>COUPON CODE<br><b>KDBDW</b></td>
		<td class="coupon3" valign="top"><h3>Then get <b>50% More</b> on your 3rd Deposit</h3><br>
			When it's time for your 3rd deposit, contact us once more and we'll give you a <b>50% bonus</b>!</td>
	</tr>
	<tr>
		<td class="coupon3" align="right" valign="top"><a href="javascript: popup('new_player_terms.html');">Terms and Conditions</a></td>
	</tr>
	<tr>
		<td colspan="3" height="30">&nbsp;</td>
	</tr>
	<tr>
		<td>&nbsp;</td>
		<td rowspan="3"><img src="template/v3/i/b.gif" width="10" border="0"></td>
		<td class="coupon1">On Your Fourth Deposit: <b>$ 200 FREE Bonus</b></td>
	</tr>
	<tr>
		<td rowspan="2" class="coupon2" valign="top"><img src="template/v3/i/coupon4.jpg" border="0"><br>COUPON CODE<br><b>EFW9J</b></td>
		<td class="coupon3" valign="top"><h3>Finally get <b>100%</b> again on your 4th Deposit</h3><br>
			Finally, make you 4th deposit, contact customer service, and we'll give you another <b>100% bonus</b>.</td>
	</tr>
	<tr>
		<td class="coupon3" align="right" valign="top"><a href="javascript: popup('new_player_terms.html');">Terms and Conditions</a></td>
	</tr>
	<tr>
		<td colspan="3" height="30">&nbsp;</td>
	</tr>
	<tr>
		<td>&nbsp;</td>
		<td rowspan="3"><img src="template/v3/i/b.gif" width="10" border="0"></td>
		<td class="coupon1">HIGH ROLLER BONUS: <b>$1000 FREE BONUS</b></td>
	</tr>
	<tr>
		<td rowspan="2" class="coupon2" valign="top"><img src="images/promotions/high1.gif"><br>COUPON CODE<br><b>WHALE</b></td>
		<td class="coupon3" valign="top"><h3>50% HIGH-ROLLER BONUS</h3><br>
		Receive a 50% bonus up to <b>$1,000.00</b>. Minimum deposit is $1,500.00. You must wager 18 times your deposit and bonus on selected games before requesting a cash-out.<br><br>
					<center><a href="download.html" onclick="popUpGood(this.href,'http://200.122.168.229/dl//TrackDownload.dll?DID=1013896&amp;RTGURL=http%3A%2F%2F200%2E122%2E168%2E229%2Fdl%2F%2FTrackDownload%2Edll%3FDID%3D1013896',10,10);return false;" target="newWin"><img src="template/v3/i/promoredeem.jpg" border="0" align="center"></a></center></td>
	</tr>
	<tr>
		<td class="coupon3" align="right" valign="top"><a href="javascript: popup('new_player_terms.html');">Terms and Conditions</a></td>
	</tr>
	<tr>
		<td colspan="3" height="30">&nbsp;</td>
	</tr>
	<tr>
		<td>&nbsp;</td>
		<td rowspan="3"><img src="template/v3/i/b.gif" width="10" border="0"></td>
		<td class="coupon1">Complimentary <b>CASINO Credits</b></td>
	</tr>
	<tr>
		<td rowspan="2" class="coupon2" valign="top"><img src="template/v3/i/couponvip.jpg" border="0"></td>
		<td class="coupon3" valign="top"><h3>Complimentary <b>CASINO Credits</b></h3><br>
			brings you our best ever loyalty program. You will automatically be enrolled when you register and will start collecting as soon as you start playing. The more you play, the more you collect, and the easier it is to earn points as you move up through our VIP classes !</td>
	</tr>
</table>
<br>
Wagering on some games gives you more points than on others and every 100 points you earn can be redeemed for $1 casino credit. To redeem your points visit the "Cashier" section in the casino and click "Redeem Comps".<br>
<br>
<table border="0" align="right" class="bet_range" cellspacing="0" cellpadding="0">
	<tr>
		<td class="br1"></td>
		<td colspan="2" class="br1" align="left">Game &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Bet Range For 1 Point</td>
	</tr>
	<tr>
		<td class="br2"><img src="template/v3/i/br_arr.jpg" border="0" hspace="7"></td>
		<td class="br2">Roulette</td>
		<td class="br3">$5 - $10 </td>
	</tr>
	<tr>
		<td class="br2"><img src="template/v3/i/br_arr.jpg" border="0" hspace="7"></td>
		<td class="br2">Slots</td>
		<td class="br3">$5 - $10</td>
	</tr>
	<tr>
		<td class="br2"><img src="template/v3/i/br_arr.jpg" border="0" hspace="7"></td>
		<td class="br2">Craps</td>
		<td class="br3">$5 - $10</td>
	</tr>
	<tr>
		<td class="br2"><img src="template/v3/i/br_arr.jpg" border="0" hspace="7"></td>
		<td class="br2">Red Dog </td>
		<td class="br3">$5 - $10</td>
	</tr>
	<tr>
		<td class="br2"><img src="template/v3/i/br_arr.jpg" border="0" hspace="7"></td>
		<td class="br2">Keno</td>
		<td class="br3">$5 - $10</td>
	</tr>
	<tr>
		<td class="br2"><img src="template/v3/i/br_arr.jpg" border="0" hspace="7"></td>
		<td class="br2">Baccarat</td>
		<td class="br3">$5 - $10</td>
	</tr>
	<tr>
		<td class="br2"><img src="template/v3/i/br_arr.jpg" border="0" hspace="7"></td>
		<td class="br2">Black Jack </td>
		<td class="br3">$5 - $10</td>
	</tr>
	<tr>
		<td class="br2"><img src="template/v3/i/br_arr.jpg" border="0" hspace="7"></td>
		<td class="br2">Pai Gow Poker </td>
		<td class="br3">$5 - $10</td>
	</tr>
	<tr>
		<td class="br2"><img src="template/v3/i/br_arr.jpg" border="0" hspace="7"></td>
		<td class="br2">Video Poker </td>
		<td class="br3">$5 - $10</td>
	</tr>
	<tr>
		<td class="br2"><img src="template/v3/i/br_arr.jpg" border="0" hspace="7"></td>
		<td class="br2">Let-Em-Ride Poker </td>
		<td class="br3">$5 - $10</td>
	</tr>
</table>
<b>You can redeem your points and change them into casino credits via the cashier whenever you like!</b><br>
Your loyalty points will be displayed as "Comp Balance" in the cashier section. When you wish to convert your points to casino credits, simply hit "Spend" and follow the on-screen instructions. For more information please <a href="support.html">Contact Customer Support</a>.<br>
<br>
<b>*Loyalty Terms and Conditions:</b><br>
Point proceeds cannot be used on <b>Baccarat</b>, <b>Craps</b>, and <b>Roulette</b> until bonus requirements are met.<br />
<a name="reload" id="reload"><br></a><br />
<h2>MONTHLY RELOAD BONUS: <span>$100 FREE!</span></h2><br>
Each month, slots lovers are eligible for a 100% bonus for between $20-$100.<br />
<p class="coupon3">
<b>September Coupon Code: SEPRELOAD</b>
<!--<<b>October Coupon Code: OCTRELOAD</b>
<b>November Coupon Code: NOVRELOAD</b>
<b>December Coupon Code: DECRELOAD</b> --></p>
Just follow these fast and easy steps and collect your <b>FREE MONEY!</b><br>
<br><strong>TERMS</strong><br />
<ul>
<li>SEPRELOAD Offer valid for 01-31 September 2008</li>
<!--<li>OCTRELOAD Offer valid for 01-31 October 2008</li>
<li>NOVRELOAD Offer valid for 01-31 November 2008</li>
<li>DECRELOAD Offer valid for 01-31 December 2008</li> -->
<li>Wagering of 30 times (Purchase + Bonus Amount) wagering applies to all.</li>
<li>Max cashout for any winnings made in conjunction with any of these coupons is $5000.</li>
<li>Playthrough has to be completed on the game which the coupon has been<br />
claimed, prior to playing any other games & prior to claiming the next code.</li>
<li>Only one bonus is allowed per deposit. Limited to one per household, address, IP address, person, account, or computer. Under the terms of membership as a player with Play United, you are permitted to have a single account to use within the entire Network of Casinos. No payments will be made in the case of multiple accounts or promotions.</li>
<li>You must meet the specified play-through requirements in full before requesting any payout.</li>
<li>Utilization of a coupon code when making a deposit shall be deemed to represent acceptance of all stated terms and conditions associated with the coupon.</li>
<li>Players from the UK are not eligible to any new players bonus offers. Players from Sweden, Australia, Germany, Denmark, and Israel must wager 2x play through requirements on all coupons. Players are not required to use coupons when depositing and should not do so without a complete understanding and acceptance of the terms and conditions.</li>
</ul></td>
				</tr>
				<tr>
					<td colspan="2" valign="bottom" class="content_bot"><img src="template/v3/i/content_bot.jpg" border="0"></td>
					<td class="box_right" valign="bottom"><img src="template/v3/i/box_right_bot.jpg" border="0"></td>
				</tr>
			</table>
		</td>
		<td>&nbsp;</td>
	</tr>
		<?		include ("footer.php") ?>	
