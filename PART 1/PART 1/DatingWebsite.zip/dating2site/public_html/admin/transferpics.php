<?php

if ( !defined( 'SMARTY_DIR' ) ) {
	include_once( '../init.php' );
}

include ( 'sessioninc.php' );

$action = $_REQUEST['action'];

if ($action != 'FS2DB' && $action != 'DB2FS') { exit;}

if ($action == 'FS2DB') {
	/* File system to DB transfer */
	$sql = 'SELECT * FROM ! WHERE picture like ? or tnpicture like ?';
} else {
	$sql = 'SELECT * FROM ! WHERE picture not like ? or tnpicture not like ?';
}

$rows = $db->getAll( $sql, array( USER_SNAP_TABLE, 'file:%', 'file:%' ) );

foreach($rows as $row) {
	/* Now process each record */
	if ($action == 'FS2DB') {
		/* Filesystem to DB transfer */
		if (substr_count($row['picture'], 'file:' )>0) {
			$imgfile = ltrim(rtrim(str_replace('file:','',$row['picture'] ) ) );
			$img = base64_encode(file_get_contents(USER_IMAGE_DIR.$imgfile));
			$db->query('update ! set picture=? where id=?', array(USER_SNAP_TABLE, $img, $row['id']) );
		}
		if (substr_count($row['tnpicture'], 'file:' )>0) {
			$imgfile = ltrim(rtrim(str_replace('file:','',$row['tnpicture'] ) ) );
			$img = base64_encode(file_get_contents(USER_IMAGE_DIR.$imgfile));
			$db->query('update ! set tnpicture=? where id=?', array(USER_SNAP_TABLE, $img, $row['id']) );
		}
	} else {
		/* DB to FileSystem */
		if (substr_count($row['picture'], 'file:' )<= 0 ) {
			$img = base64_decode ( $row['picture']  );
			$imgfile = writeImageToFile($img, $row['userid'], '1'.$row['picno']);
			$img = 'file:'.$imgfile;
			$db->query('update ! set picture=? where id=?', array(USER_SNAP_TABLE, $img, $row['id']) );
		}
		if (substr_count($row['tnpicture'], 'file:' )<= 0 ) {
			$img = base64_decode ( $row['tnpicture']  );
			$imgfile = writeImageToFile($img, $row['userid'], '1'.$row['picno']);
			$img = 'file:'.$imgfile;
			$db->query('update ! set tnpicture=? where id=?', array(USER_SNAP_TABLE, $img, $row['id']) );
		}
	}
}

function writeImageToFile($img, $userid, $picno, $file="") {
/* This routine will create an image file */
	if ($file == '') {
		$filename= time().$userid.$picno.'.jpg';
	} else {
		$filename = $file;
	}

	$img = imagecreatefromstring( $img );
	imagejpeg($img, USER_IMAGE_DIR.$filename);

	return ($filename);
}

if ($action == 'FS2DB') {
	echo(" Pictures are transferred to DB");
} else {
	echo(" Pictures are transferred from DB");
}
exit;
?>