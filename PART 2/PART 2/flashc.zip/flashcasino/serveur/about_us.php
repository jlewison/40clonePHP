<? include ("header2.php"); ?>
<table cellpadding="0" cellspacing="0" border="0" width="100%">
	<tr class="top3">
		<td colspan="3"><img src="template/v3/i/b.gif" border="0" height="15" width="1"></td>
	</tr>
	<tr class="top4">
		<td>&nbsp;</td>
		<td align="center">
			<table cellpadding="0" cellspacing="0" border="0" width="778">
				<tr>
					<td valign="top" height="109"><object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" width="257" height="109" id="logo" align="middle"><param name="movie" value="flash/logo.swf" /><param name="quality" value="high" /><param name="wmode" value="transparent" /><param name="bgcolor" value="#ffffff" /><embed src="flash/logo.swf" quality="high" wmode="transparent" bgcolor="#ffffff" width="257" height="109" name="rotator" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /></object></td>
					<td valign="top" height="109"><img src="template/v3/i/content12.jpg" border="0"></td>
					<td rowspan="3" valign="top" class="box_right"><object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" width="204" height="128" id="innerstar" align="middle"><param name="allowScriptAccess" value="sameDomain" /><param name="movie" value="flash/innerstar.swf" /><param name="quality" value="high" /><param name="wmode" value="transparent" /><param name="bgcolor" value="#ffffff" /><embed src="flash/innerstar.swf" quality="high" wmode="transparent" bgcolor="#ffffff" width="204" height="128" name="innerstar" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /></object><a href="promotions.php"><img src="template/v3/i/innerstar-1b2.gif" border="0"></a>
						
<? include ("mg.php"); ?>
				<tr>
					<td class="subtitle_path" colspan="2" valign="top" height="35"><div><a href="index.php"><img src="template/v3/i/home_ico.jpg" border="0" vspace="0" style="margin-left: 36px;margin-right: 27px" align="left"></a></div>About us</td>
				</tr>
				<tr>
					<td colspan="2" class="content" valign="top"><img src="template/v3/i/b.gif" width="1" height="500" border="0" align="left"><p>Legally licensed and fully insured, Online Casino is committed to making your gaming experience as exciting and rewarding as possible. We combine cutting-edge software, 24 hour live support, and the most advanced security measures available to provide the thrill of Las Vegas from the comfort and safety of your own home. All of Casino's transactions are facilitated by AquaGaming (Aquapay).<br>
<br> Casino maintains a truly fair, transparent, and secure gaming environment to build long-term relationships with our players. We respect your privacy and therefore will never rent, sell or distribute any information about you. Your personal information will be safeguarded by and will never be sold to mailing lists.<br>
<br> Casino offers the most prominent Casino games including Blackjack, Baccarat, Poker, Craps, Video Poker, Roulette, Slots and many more. Our team of developers strives to introduce exciting new games every month to ensure our customers are playing the most advanced online casino games in the world. Casino's software was developed and is maintained by RealTime Gaming, one of the leading online gaming software companies in the world. RealTime Gaming's Random Number Generator (RNG) has been tested and approved by software engineers from Princeton University, guaranteeing you absolute fairness in every game. The RNG algorithms are based on real-world dynamics to truly simulate the motion of real dice, wheels &amp; reels to provide you with casino odds and payouts that are identical or better than land based casinos.<br>
<br> Finally, Casino proactively encourages responsible gaming through our zero tolerance age check verification process and providing assistance to those with gambling problems. If you have any questions or concerns, please do not hesitate to Contact Us. We encourage you to download our casino software to experience the best in online gaming.</p></td>
				</tr>
				<tr>
					<td colspan="2" valign="bottom" class="content_bot"><img src="template/v3/i/content_bot.jpg" border="0"></td>
					<td class="box_right" valign="bottom"><img src="template/v3/i/box_right_bot.jpg" border="0"></td>
				</tr>
			</table>
		</td>
		<td>&nbsp;</td>
	</tr>
		<?		include ("footer.php") ?>	
