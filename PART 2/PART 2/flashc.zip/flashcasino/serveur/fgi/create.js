function deleteCookie (name, path, domain){
	if(getCookie(name)){
		document.cookie = name + "=" + ((path) ? "; path=" + path : "") + ((domain) ? "; domain=" + domain : "") + ";expires=Thu, 01-Jan-70 00:00:01 GMT";
	}
}

function getCookie(name){
	var dc = document.cookie;
	var prefix = name + "=";
	var begin = dc.indexOf("; " + prefix);
	if(begin == -1){
		begin = dc.indexOf(prefix);
		if(begin != 0)
			return null;
	}
	else
		begin += 2;
	var end = document.cookie.indexOf(";", begin);
	if(end == -1)
		end = dc.length;
		return unescape(dc.substring(begin + prefix.length, end));
}

function setCookie(name, value, expires, path, domain, secure){
	var curCookie = name + "=" + escape(value) + ((expires) ? "; expires=" + expires.toGMTString() : "") + ((path) ? "; path=" + path : "") + ((domain) ? "; domain=" + domain : "") + ((secure) ? "; secure" : "");
	document.cookie = curCookie;
}

function createConvertPassword(){
	var CreateForm = document.forms['CreateForm'];
	var nonhashed = CreateForm.elements['unhashedpassword'].value;
	var hashed = hex_sha1(nonhashed);
	setCookie("hashpassword", hashed);
	//alert(getCookie("hashpassword"));
	//setCookie("unhashedpassword", nonhashed, new Date("January 1, 3000"));
}

function CheckForm(){
	if(document.CreateForm.pid.value.length==0){
		alert("You must enter a Username");
		document.CreateForm.pid.focus();
		document.CreateForm.pid.select();
		return false;
	}
	if(document.CreateForm.unhashedpassword.value.length==0){
		alert("You must enter a Password");
		document.CreateForm.unhashedpassword.focus();
		document.CreateForm.unhashedpassword.select();
		return false;
	}
	if(document.CreateForm.unhashedpasswordconfirm.value.length==0){
		alert("You must Confirm your password");
		document.CreateForm.unhashedpasswordconfirm.focus();
		document.CreateForm.unhashedpasswordconfirm.select();
		return false;
	}
	if(document.CreateForm.unhashedpassword.value!=document.CreateForm.unhashedpasswordconfirm.value){
		alert("The passwords entered do not match");
		document.CreateForm.unhashedpassword.focus();
		document.CreateForm.unhashedpassword.select();
		return false;
	}

	var emailString = document.CreateForm.email.value;

	var aPos = emailString.indexOf("@");
	var aLastPos = emailString.lastIndexOf("@");
	var dotPos = emailString.lastIndexOf(".");
	var lastPos = emailString.length-1;

	if((aPos < 1) || (dotPos-aPos < 2) || (lastPos-dotPos > 3) || (lastPos-dotPos < 2) || (aPos != aLastPos)   || (emailString.indexOf(" ") == 0)){
		alert("Must enter a valid E-Mail Address (ex: user@domain.com)");
		document.CreateForm.email.focus();
		document.CreateForm.email.select();
		return false;
	}

	if(document.CreateForm.dayphone.value.length==0){
		alert("You must enter a daytime phone number");
		document.CreateForm.dayphone.focus();
		document.CreateForm.dayphone.select();
		return false;
	}
	if(document.CreateForm.evephone.value.length==0){
		alert("You must enter an evening phone number");
		document.CreateForm.evephone.focus();
		document.CreateForm.evephone.select();
		return false;
	}
	if(document.CreateForm.birthdate.value.length!=10){
		alert("You must enter birthdate in the format: MM/DD/YYY (ex: 01/02/2006)");
		document.CreateForm.birthdate.focus();
		document.CreateForm.birthdate.select();
		return false;
	}
	if(!IsNumeric(document.CreateForm.birthdate.value)){
		alert("Birthdate can not contain any letters");
		document.CreateForm.birthdate.focus();
		document.CreateForm.birthdate.select();
		return false;
	}
	if(document.CreateForm.fname.value.length==0){
		alert("You must enter your first name");
		document.CreateForm.fname.focus();
		document.CreateForm.fname.select();
		return false;
	}
	if(document.CreateForm.lname.value.length==0){
		alert("You must enter your last name");
		document.CreateForm.lname.focus();
		document.CreateForm.lname.select();
		return false;
	}
	if(document.CreateForm.addr1.value.length==0){
		alert("You must enter an address");
		document.CreateForm.addr1.focus();
		document.CreateForm.addr1.select();
		return false;
	}
	if(document.CreateForm.city.value.length==0){
		alert("You must enter a city");
		document.CreateForm.city.focus();
		document.CreateForm.city.select();
		return false;
	}
	if(document.CreateForm.state.value.length==0){
		alert("You must enter a state/providence");
		document.CreateForm.state.focus();
		document.CreateForm.state.select();
		return false;
	}
	if(document.CreateForm.zip.value.length==0){
		alert("You must enter a valid zip/postal code");
		document.CreateForm.zip.focus();
		document.CreateForm.zip.select();
		return false;
	}
	if(document.CreateForm.country.value.length==0){
		alert("You must choose a country");
		document.CreateForm.country.focus();
		document.CreateForm.country.select();
		return false;
	}

	createConvertPassword();
	return true;
}

function IsNumeric(strString){
	//check for valid numeric strings
	var strValidChars = "0123456789/-";
	var strChar;
	var blnResult = true;

	if(strString.length == 0)
		return false;

	//test strString consists of valid characters listed above
	for(i = 0; i < strString.length && blnResult == true; i++){
		strChar = strString.charAt(i);
		if(strValidChars.indexOf(strChar) == -1){
			blnResult = false;
		}
	}
	return blnResult;
}