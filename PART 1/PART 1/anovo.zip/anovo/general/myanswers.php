<?php

class MyAnswerFormHandler extends ListRecordsHandler
{
		public function displayAnswerDetails()
		{
				$uname = $this->user_details['name'];
				$display_username = $this->LANG['myanswers_my'];
				$users_answers = $display_username . ' ' . $this->LANG['myanswers_answered_question_header'];
				$users_questions = $display_username . ' ' . $this->LANG['myanswers_asked_question_header'];
				$users_favorites = $display_username . ' ' . $this->LANG['myanswers_favorite_question_header'];
				if ($this->CFG['user']['user_id'] != $this->fields_arr['uid'])
				{
						$display_username = str_replace('{user_name}', $uname, $this->LANG['myanswers_others']);
						$users_answers = $this->LANG['myanswers_answered_question_header'];
						$users_questions = $this->LANG['myanswers_asked_question_header'];
						$users_favorites = $this->LANG['myanswers_favorite_question_header'];
				}
?>
				<div class="clsQuestionsLink">
					<ul>
					<?php if ($this->CFG['user']['user_id'] != $this->fields_arr['uid'])
				{ ?>
					<li class="clsSubscribe"><?php echo stripString($display_username, $this->CFG['username']['medium_length']); ?></li>
					<?php } ?>
						<li id="selAnsweredQuestionsLI" class="clsLeftActiveQuestionsLink"><span id="selAnsweredQuestionsSPAN" class="clsRightActiveQuestionsLink"><a id="selAnsweredQuestionsA" class="clsMiddleActiveQuestionsLink" onclick="hideBlocks('selAskedQuestions','selFavoriteQuestions');showBlocks('selAnsweredQuestions'); toggleNavBar(); return false;" href="<?php echo $_SERVER['REQUEST_URI']; ?>"><?php echo $users_answers; ?></a></span></li>
						<li id="selAskedQuestionsLI" class="clsLeftInActiveQuestionsLink"><span id="selAskedQuestionsSPAN" class="clsRightInActiveQuestionsLink"><a id="selAskedQuestionsA" class="clsMiddleInActiveQuestionsLink" onclick="hideBlocks('selAnsweredQuestions','selFavoriteQuestions');showBlocks('selAskedQuestions'); toggleNavBar(); return false;" href="<?php echo $_SERVER['REQUEST_URI']; ?>"><?php echo $users_questions; ?></a></span></li>
						<?php if ($this->CFG['admin']['favorite']['allowed'])
				{ ?>
						<li id="selFavoriteQuestionsLI" class="clsLeftInActiveQuestionsLink"><span id="selFavoriteQuestionsSPAN" class="clsRightInActiveQuestionsLink"><a id="selFavoriteQuestionsA" class="clsMiddleInActiveQuestionsLink" onclick="hideBlocks('selAskedQuestions','selAnsweredQuestions');showBlocks('selFavoriteQuestions'); toggleNavBar(); return false;" href="<?php echo $_SERVER['REQUEST_URI']; ?>"><?php echo $users_favorites; ?></a></span></li>
						<?php } ?>
					</ul>
				</div>

				<div id="selAnsweredQuestions" class="clsCommonIndexSection">
					<?php $this->displayAnsweredQuestions(3); ?>
				</div>

				<div id="selAskedQuestions" class="clsCommonIndexSection" style=display:none;>
					<?php $this->displayAskedQuestions(3); ?>
				</div>

				<?php if ($this->CFG['admin']['favorite']['allowed'])
				{ ?>
				<div id="selFavoriteQuestions" class="clsCommonIndexSection" style=display:none;>
					<?php $this->displayFavoriteQuestions(3); ?>
				</div>
				<?php } ?>

<?php
				$display_username = $this->LANG['myanswers_subscribed'];
				if ($this->CFG['user']['user_id'] != $this->fields_arr['uid'])
				{
						$display_username = str_replace('{user_name}', $uname, $this->LANG['myanswers_subscribed_others']);
				}
				if ($this->CFG['admin']['subscribe']['tags'] or $this->CFG['admin']['subscribe']['users'] or $this->CFG['admin']['subscribe']['forums'])
				{
						$userSubscribeStyle = $forumSubscribeStyle = '';
?>
				<div class="clsQuestionsLink">
					<ul>
                    <li class="clsSubscribe"><?php echo stripString($display_username, $this->CFG['username']['medium_length']); ?></li>
						<?php if ($this->CFG['admin']['subscribe']['tags'])
						{
								$userSubscribeStyle = $forumSubscribeStyle = 'style=display:none;';
?>
						<li id="selSubscribedTagsLI" class="clsLeftActiveQuestionsLink"><span id="selSubscribedTagsSPAN" class="clsRightActiveQuestionsLink"><a id="selSubscribedTagsA" class="clsMiddleActiveQuestionsLink" onclick="hideBlocks('selSubscribedUsers','selSubscribedForums');showBlocks('selSubscribedTags'); toggleNavBar(); return false;" href="<?php echo $_SERVER['REQUEST_URI']; ?>"><?php echo $this->LANG['myanswers_subscribed_tag']; ?></a></span></li>
						<?php } ?>
						<?php if ($this->CFG['admin']['subscribe']['users'])
						{
								$forumSubscribeStyle = 'style=display:none;';
?>
							<?php if (!$userSubscribeStyle)
								{ ?>
							<li id="selSubscribedUsersLI" class="clsLeftActiveQuestionsLink"><span id="selSubscribedUsersSPAN" class="clsRightActiveQuestionsLink"><a id="selSubscribedUsersA" class="clsMiddleActiveQuestionsLink" onclick="hideBlocks('selSubscribedTags','selSubscribedForums');showBlocks('selSubscribedUsers'); toggleNavBar(); return false;" href="<?php echo $_SERVER['REQUEST_URI']; ?>"><?php echo $this->LANG['myanswers_subscribed_user']; ?></a></span></li>
							<?php }
								else
								{ ?>
							<li id="selSubscribedUsersLI" class="clsLeftInActiveQuestionsLink"><span id="selSubscribedUsersSPAN" class="clsRightInActiveQuestionsLink"><a id="selSubscribedUsersA" class="clsMiddleInActiveQuestionsLink" onclick="hideBlocks('selSubscribedTags','selSubscribedForums');showBlocks('selSubscribedUsers'); toggleNavBar(); return false;" href="<?php echo $_SERVER['REQUEST_URI']; ?>"><?php echo $this->LANG['myanswers_subscribed_user']; ?></a></span></li>
							<?php } ?>
						<?php } ?>
						<?php if ($this->CFG['admin']['subscribe']['forums'])
						{ ?>
							<?php if (!$forumSubscribeStyle)
								{ ?>
							<li id="selSubscribedForumsLI" class="clsLeftActiveQuestionsLink"><span id="selSubscribedForumsSPAN" class="clsRightActiveQuestionsLink"><a id="selSubscribedForumsA" class="clsMiddleActiveQuestionsLink" onclick="hideBlocks('selSubscribedUsers','selSubscribedTags');showBlocks('selSubscribedForums'); toggleNavBar(); return false;" href="<?php echo $_SERVER['REQUEST_URI']; ?>"><?php echo $this->LANG['myanswers_subscribed_forum']; ?></a></span></li>
							<?php }
								else
								{ ?>
							<li id="selSubscribedForumsLI" class="clsLeftInActiveQuestionsLink"><span id="selSubscribedForumsSPAN" class="clsRightInActiveQuestionsLink"><a id="selSubscribedForumsA" class="clsMiddleInActiveQuestionsLink" onclick="hideBlocks('selSubscribedUsers','selSubscribedTags');showBlocks('selSubscribedForums'); toggleNavBar(); return false;" href="<?php echo $_SERVER['REQUEST_URI']; ?>"><?php echo $this->LANG['myanswers_subscribed_forum']; ?></a></span></li>
							<?php } ?>
						<?php } ?>
					</ul>
				</div>

				<?php if ($this->CFG['admin']['subscribe']['tags'])
						{ ?>
				<div id="selSubscribedTags" class="clsCommonIndexSection">
					<?php $this->displaySubscribedTags(25); ?>
				</div>
				<?php } ?>

				<?php if ($this->CFG['admin']['subscribe']['users'])
						{ ?>
				<div id="selSubscribedUsers" class="clsCommonIndexSection" <?php echo $userSubscribeStyle; ?>>
					<?php $this->displaySubscribedUsers(3); ?>
				</div>
				<?php } ?>

				<?php if ($this->CFG['admin']['subscribe']['forums'])
						{ ?>
				<div id="selSubscribedForums" class="clsCommonIndexSection" <?php echo $forumSubscribeStyle; ?>>
					<?php $this->displaySubscribedForums(5); ?>
				</div>
				<?php } ?>

<?php
				}
		}
		public function displayAnsweredQuestions($limit = 3)
		{
				$uname = $this->user_details['name'];
				$sql = 'SELECT ques_id FROM ' . $this->CFG['db']['tbl']['questions'] . ' as q, ' . $this->CFG['db']['tbl']['users'] . ' as u' . ' WHERE q.user_id=u.' . $this->CFG['users']['user_id'] . ' AND q.status IN (\'Open\', \'Resolved\') AND u.' . $this->CFG['users']['usr_status'] . '=\'Ok\'' . ' AND EXISTS (SELECT ques_id FROM answers AS a WHERE' . ' a.user_id=' . $this->dbObj->Param('user_id') . ' AND q.ques_id = a.ques_id)' . ' ORDER BY q.ques_id DESC LIMIT 0,' . ($limit + 1);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['uid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);

?>
				<div id="selWidgetRecentQuestions" class="clsSideBarSections">
					<h3><?php echo $this->LANG['myanswers_answered_questions']; ?></h3>
				<?php
				if (!$rs->PO_RecordCount())
				{
?>
					<div class="clsNoRecords">
						<p><?php echo $this->LANG['myanswers_no_answered_question']; ?></p>
					</div>
					<?php
				}
				if ($rs->PO_RecordCount())
				{
?>
					<div class="clsSideBarContents">
					<?php
						$this->displayQuestions($rs, $limit);
						if ($rs->PO_RecordCount() > $limit)
						{
?>
								<p class="clsMoreLink"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'questions.php?view=search&uname=' . $uname . '&opt=ans', $this->CFG['site']['relative_url'] . 'answers/search/?uname=' . $uname . '&opt=ans', false); ?>"><?php echo $this->LANG['more']; ?></a></p>
							<?php
						}
?>
					</div>
					<?php
				}
?>
				</div>
				<?php
		}
		public function displayAskedQuestions($limit = 3)
		{
				$uname = $this->user_details['name'];
				$sql = 'SELECT ques_id FROM ' . $this->CFG['db']['tbl']['questions'] . ' as q' . ' WHERE q.user_id=' . $this->dbObj->Param('user_id') . ' AND q.status IN (\'Open\', \'Resolved\')' . ' ORDER BY q.ques_id DESC LIMIT 0,' . ($limit + 1);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['uid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);

?>
				<div id="selWidgetRecentQuestions" class="clsSideBarSections">
					<h3><?php echo $this->LANG['myanswers_asked_questions']; ?></h3>
				<?php
				if (!$rs->PO_RecordCount())
				{
?>
					<div class="clsNoRecords">
						<p><?php echo $this->LANG['myanswers_no_asked_question']; ?></p>
					</div>
					<?php
				}
				if ($rs->PO_RecordCount())
				{
?>
					<div class="clsSideBarContents">
					<?php
						$this->displayQuestions($rs, $limit);
						if ($rs->PO_RecordCount() > $limit)
						{
?>
								<p class="clsMoreLink"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'questions.php?view=search&uname=' . $uname . '&opt=ques', $this->CFG['site']['relative_url'] . 'answers/search/?uname=' . $uname . '&opt=ques', false); ?>"><?php echo $this->LANG['more']; ?></a></p>
							<?php
						}
?>
					</div>
					<?php
				}
?>
				</div>
				<?php
		}
		public function displayFavoriteQuestions($limit = 3)
		{
				$uname = $this->user_details['name'];
				$sql = 'SELECT ques_id FROM ' . $this->CFG['db']['tbl']['user_bookmarked'] . ' AS ub, ' . $this->CFG['db']['tbl']['questions'] . ' as q' . ' WHERE ub.user_id=' . $this->dbObj->Param('user_id') . ' AND ub.content_type=\'Question\' AND ub.content_id=q.ques_id' . ' AND q.status IN (\'Open\', \'Resolved\')' . ' ORDER BY ub.bookmark_id DESC LIMIT 0,' . ($limit + 1);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['uid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);

?>
				<div id="selWidgetRecentQuestions" class="clsSideBarSections">
					<h3><?php echo $this->LANG['myanswers_favorite_questions']; ?></h3>
				<?php
				if (!$rs->PO_RecordCount())
				{
?>
					<div class="clsNoRecords">
						<p><?php echo $this->LANG['myanswers_no_favorite_question']; ?></p>
					</div>
					<?php
				}
				if ($rs->PO_RecordCount())
				{
?>
					<div class="clsSideBarContents">
					<?php
						$this->displayQuestions($rs, $limit);
						if ($rs->PO_RecordCount() > $limit)
						{
?>
								<p class="clsMoreLink"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'questions.php?view=search&uname=' . $uname . '&opt=fav', $this->CFG['site']['relative_url'] . 'answers/search/?uname=' . $uname . '&opt=fav', false); ?>"><?php echo $this->LANG['more']; ?></a></a></p>
							<?php
						}
?>
					</div>
					<?php
				}
?>
				</div>
				<?php
		}
		public function displayQuestions($rs, $limit)
		{
				$i = 0;
				while ($row = $rs->FetchRow())
				{
						$questionDetails = $this->getQuestionDetails($row['ques_id']);
						$i++;
						$clsOddOrEvenQuestion = 'clsEvenQuestion';
						if ($i % 2) $clsOddOrEvenQuestion = 'clsOddQuestion';
						$answer_plural = '';
						if ($questionDetails['total_answer'] != 1) $answer_plural = 's';
?>
			    <div>
			      <div class="<?php echo $clsOddOrEvenQuestion; ?> clsUserThumbDetails">
			        <?php if (chkUserImageAllowed())
						{ ?>
					<div class="clsUserThumb">
			          <p id="selImageBorder">
			            <?php displayUserImage($questionDetails, 'small'); ?>
			          </p>
			        </div>
			        <?php } ?>
			        <div class="clsUserDetails">
			          <p class="clsQuestionLink"><?php echo $questionDetails['question_link']; ?></p>
			          <p> <span class="clsUserLink"><?php echo $this->LANG['common_question_asked_by'] . ' ' . $questionDetails['asked_by_link']; ?></span> <span><?php echo getTimeDiffernceFormat($questionDetails['date_asked']); ?></span> <span class="clsNoBorder"><?php echo $questionDetails['total_answer'] . ' ' . $this->LANG['common_total_answers'] . $answer_plural; ?></span> </p>
			        </div>
			      </div>
			    </div>
				<?php
						if ($i >= $limit) break;
				}
		}
		public function displaySubscribedTags($limit = 25)
		{
				$uname = $this->user_details['name'];
				$uid = $this->fields_arr['uid'];
				$sql = 'SELECT subscribe_keywords FROM ' . $this->CFG['db']['tbl']['users_ans_log'] . ' WHERE user_id = ' . $this->dbObj->Param('user_id');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['uid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
?>
				<div id="selWidgetRecentQuestions" class="clsSideBarSections">
					<h3><?php echo $this->LANG['myanswers_subscribed_tags']; ?></h3>
				<?php
				$found = false;
				if ($rs->PO_RecordCount())
				{
						$row = $rs->FetchRow();
						$subscribed_tags = array();
						if (trim($row['subscribe_keywords']))
						{
								$subscribed_tags = explode(' ', trim($row['subscribe_keywords']));
								$found = true;
?>
						<div class="clsSideBarContents">
						<?php
								$classes = array('clsTagStyleBlue', 'clsTagStyleGrey', 'clsTagStyleGreen', 'clsTagStyleRed');
								$tagClassArray = array();
								$tagArray = array();
								foreach ($subscribed_tags as $eachTag)
								{
										$tagArray[$eachTag] = $this->getTagQuestionsCount($eachTag);
										$class = $classes[rand(0, count($classes)) % count($classes)];
										$tagClassArray[$eachTag] = $class;
								}
								$tagArray = $this->setFontSizeInsteadOfSearchCount($tagArray);
								$cntTags = 0;
								foreach ($tagArray as $tag => $fontSize)
								{
										$url = getUrl($this->CFG['site']['relative_url'] . 'questions.php?view=search&tags=' . $tag, $this->CFG['site']['relative_url'] . 'answers/search/?tags=' . $tag, false);
										$class = $tagClassArray[$tag];
										$fontSizeClass = 'style="font-size:' . $fontSize . 'px"';
										$cntTags++;
?>
		                    	<span class="<?php echo $class; ?>"><a href="<?php echo $url; ?>" <?php echo $fontSizeClass; ?>><?php echo $tag; ?></a></span>
		                    	<?php
										if ($cntTags > $limit) break;
								}
								if ($cntTags >= $limit)
								{
?>
								<p class="clsMoreLink"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'mySubscribedTag.php?uid=' . $uid, $this->CFG['site']['relative_url'] . 'mysubscribedtag/' . $uid . '/', false); ?>"><?php echo $this->LANG['more']; ?></a></a></p>
								<?php
								}
?>
						</div>
						<?php
						}
				}
				if (!$found)
				{
?>
					<div class="clsNoRecords">
						<p><?php echo $this->LANG['myanswers_no_subscribed_tags']; ?></p>
					</div>
					<?php
				}
?>
				</div>
				<?php
		}
		public function populateUserDetails($user_id)
		{
				$fields_arr = array('user_id', 'name', 'email', 'image_path', 'gender', 'usr_status', 'user_access', 't_height', 't_width', 'photo_server_url', 'photo_ext');
				$sql = 'SELECT ' . $this->getUserTableFields($fields_arr) . ' ,' . $this->getUserTableField('user_id') . ' as img_user_id FROM ' . $this->CFG['db']['tbl']['users'] . ' WHERE user_id = ' . $this->dbObj->Param('user_id');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($user_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($row = $rs->FetchRow()) return $row;
				return false;
		}
		public function displaySubscribedUsers($limit = 5)
		{
				$uname = $this->user_details['name'];
				$uid = $this->fields_arr['uid'];
				$sql = 'SELECT content_id FROM ' . $this->CFG['db']['tbl']['user_bookmarked'] . ' WHERE content_type = \'User\' AND user_id = ' . $this->dbObj->Param('user_id') . ' LIMIT 0, ' . $limit;
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['uid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
?>
				<div id="selWidgetRecentQuestions" class="clsSideBarSections">
					<h3><?php echo $this->LANG['myanswers_subscribed_users']; ?></h3>
				<?php
				if (!$rs->PO_RecordCount())
				{
?>
					<div class="clsNoRecords">
						<p><?php echo $this->LANG['myanswers_no_subscribed_users']; ?></p>
					</div>
					<?php
				}
				if ($rs->PO_RecordCount())
				{
						$photosPerRow = 3;
						$count = 0;
						$found = false;
?>
<div class="clsSideBarContents">
<table summary="display subscribed users" class="clsSubscribeTbl">
<?php
						$cntUsers = 0;
						while ($row = $rs->FetchRow())
						{
								$user_details = $this->populateUserDetails($row['content_id']);
								$found = true;
								$cntUsers++;
								if ($count % $photosPerRow == 0)
								{
?>
							<tr>
<?php
								}
?>
<td>
<div class="clsMysubscribeUser">
<?php if (chkUserImageAllowed())
								{ ?>
<p id="selImageBorder"><?php displayUserImage($user_details, 'thumb', false); ?></p>
<?php } ?>
<p class="clsSubscribeName"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'myanswers.php?uid=' . $user_details['user_id'], $this->CFG['site']['relative_url'] . 'my/answers/' . $user_details['user_id'] . '/', false); ?>"><?php echo stripString($user_details['name'], $this->CFG['username']['short_length']); ?></a></p></div>
</td>
<?php
								$count++;
								if ($count % $photosPerRow == 0)
								{
										$count = 0;
?>
							</tr>
<?php
								}
								if ($cntUsers > $limit) break;
						}
?>
</table>
<?php
						if ($cntUsers >= $limit)
						{
?>
					<p class="clsMoreLink"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'mySubscribedUser.php?uid=' . $uid, $this->CFG['site']['relative_url'] . 'mysubscribeduser/' . $uid . '/', false); ?>"><?php echo $this->LANG['more']; ?></a></p>
					<?php
						}
?>
</div>
					<?php
				}
?>
				</div>
				<?php
		}
		public function populateForumDetails($topic_id)
		{
				$sql = 'SELECT forum_id, total_response, forum_topic, user_id' . ' FROM ' . $this->CFG['db']['tbl']['forum_topics'] . ' WHERE topic_id = ' . $this->dbObj->Param('topic_id');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($topic_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($row = $rs->FetchRow()) return $row;
				return false;
		}
		public function displaySubscribedForums($limit = 5)
		{
				$uname = $this->user_details['name'];
				$uid = $this->fields_arr['uid'];
				$sql = 'SELECT content_id FROM ' . $this->CFG['db']['tbl']['user_bookmarked'] . ' WHERE content_type = \'Forum\' AND user_id = ' . $this->dbObj->Param('user_id');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['uid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
?>
				<div id="selWidgetRecentQuestions" class="clsSideBarSections">
					<h3><?php echo $this->LANG['myanswers_subscribed_forums']; ?></h3>
				<?php
				if (!$rs->PO_RecordCount())
				{
?>
					<div class="clsNoRecords">
						<p><?php echo $this->LANG['myanswers_no_subscribed_forums']; ?></p>
					</div>
					<?php
				}
				if ($rs->PO_RecordCount())
				{
?>
<div class="clsSubscribeForum clsSideBarContents">
<?php
						$cntForums = 1;
						while ($row = $rs->FetchRow())
						{
								$forumDetails = $this->populateForumDetails($row['content_id']);
								$cntForums++;
?>
<p><a href="<?php echo getUrl('forumsTopics.php?forum_id=' . $forumDetails['forum_id'], 'forum/' . $forumDetails['forum_id'] . '/'); ?>"><?php echo wordWrapManual($forumDetails['forum_topic'], $this->CFG['admin']['forum']['line_length'], $this->CFG['admin']['forum']['short_length']); ?></a></p>
<?php

								if ($cntForums > $limit) break;
						}
						if ($cntForums >= $limit)
						{
?>
<p class="clsMoreLink"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'mySubscribedForum.php?uid=' . $uid, $this->CFG['site']['relative_url'] . 'mysubscribedforum/' . $uid . '/', false); ?>"><?php echo $this->LANG['more']; ?></a></p>
<?php
						}
?>
</div>
<?php
				}
?>
				</div>
				<?php
		}
		public function getTagQuestionsCount($tag_name)
		{
				$sql = 'SELECT total_count FROM ' . $this->CFG['db']['tbl']['tags'] . ' WHERE tag_name=' . $this->dbObj->Param($tag_name);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($tag_name));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row['total_count'] = 0;
				if ($rs->PO_RecordCount()) $row = $rs->FetchRow();
				return $row['total_count'];
		}
		public function displayUserDetails()
		{
				$sql = 'SELECT total_ques, total_ans, total_points' . ', DATE_FORMAT(date_updated,\'%D %b %Y\') as date_updated' . ' FROM ' . $this->CFG['db']['tbl']['users_ans_log'] . ' WHERE user_id=' . $this->dbObj->Param('uid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['uid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$this->user_ans_log = array('total_ques' => '', 'total_ans' => '', 'total_points' => '', 'date_updated' => '');
				if ($rs->PO_RecordCount()) $this->user_ans_log = $rs->FetchRow();
				$this->user_details = $this->getUserDetailsFromUsersTable($this->CFG['db']['tbl']['users'], $this->fields_arr['uid']);
				$mcomp = $this->user_details['name'];
				$this->user_details['name'] = ucwords($this->user_details['name']);
				$bio = $this->user_details['bio'];
?>
<!--rounded corners-->
 	<div class="lbprofile">
      <div class="rbprofile">
        <div class="bbprofile">
          <div class="blcprofile">
            <div class="brcprofile">
              <div class="tbprofile">
                <div class="tlcprofile">
                  <div class="trcprofile">
      <div class="clsUserInfo">
      <h3 class="clsProfileTitle"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'myanswers.php?uid=' . $this->fields_arr['uid'], $this->CFG['site']['relative_url'] . 'my/answers/' . $this->fields_arr['uid'] . '/', false); ?>"><?php echo $this->user_details['name']; ?></a></h3>
				<div class="clsUserProfileImageInfo">
					<?php if (chkUserImageAllowed())
				{ ?>
					<div class="clsUserProfileImage"><p id="selImageBorder"><?php displayUserImage($this->user_details, 'thumb', false); ?> </p></div>
					<?php } ?>
					<div class="clsUserProfileInfo"><?php if ($this->CFG['admin']['subscribe']['users'] and $this->fields_arr['uid'] != $this->CFG['user']['user_id'])
				{ ?>
					<span class="clsSubscribe" id="selShowFavoriteText_User_<?php echo $this->fields_arr['uid']; ?>">
						<?php if ($this->isMember())
						{ ?>
							<?php if ($this->isFavoriteContent($this->fields_arr['uid'], 'User'))
								{ ?>
								<a href="<?php echo $_SERVER['REQUEST_URI']; ?>" onClick="toggleFavorites('<?php echo $this->CFG['site']['relative_url']; ?>favoriteAnswers.php', 'cid=<?php echo $this->fields_arr['uid']; ?>&ctype=User', 'selShowFavoriteText_User_<?php echo $this->fields_arr['uid']; ?>'); return false;"><?php echo $this->LANG['user_remove_favorites']; ?></a>
							<?php }
								else
								{ ?>
								<a href="<?php echo $_SERVER['REQUEST_URI']; ?>" onClick="toggleFavorites('<?php echo $this->CFG['site']['relative_url']; ?>favoriteAnswers.php', 'cid=<?php echo $this->fields_arr['uid']; ?>&ctype=User', 'selShowFavoriteText_User_<?php echo $this->fields_arr['uid']; ?>'); return false;"><?php echo $this->LANG['user_add_to_favorites']; ?></a>
							<?php } ?>
						<?php }
						else
						{ ?>
						<a href="<?php echo getUrl($this->CFG['site']['url'] . 'members/myanswers.php?uid=' . $this->fields_arr['uid'], $this->CFG['site']['url'] . 'members/my/answers/' . $this->fields_arr['uid'] . '/', false); ?>"><?php echo $this->LANG['user_add_to_favorites']; ?></a>
						<?php } ?>
					</span>
					<?php } ?>
					<?php if ($this->CFG['admin']['ignore_user'] and $this->fields_arr['uid'] != $this->CFG['user']['user_id'])
				{ ?>
					<span class="clsIgnoreUser" id="selShowIgnoreUser">
						<?php if ($this->isMember())
						{ ?>
							<?php if ($this->isIgnoredUser($this->fields_arr['uid']))
								{ ?>
								<a href="<?php echo $_SERVER['REQUEST_URI']; ?>" onClick="toggleFavorites('<?php echo $this->CFG['site']['relative_url']; ?>favoriteAnswers.php', 'ignore_id=<?php echo $this->fields_arr['uid']; ?>', 'selShowIgnoreUser'); return false;"><?php echo $this->LANG['myanswers_unignore_user']; ?></a>
							<?php }
								else
								{ ?>
								<a href="<?php echo $_SERVER['REQUEST_URI']; ?>" onClick="toggleFavorites('<?php echo $this->CFG['site']['relative_url']; ?>favoriteAnswers.php', 'ignore_id=<?php echo $this->fields_arr['uid']; ?>', 'selShowIgnoreUser'); return false;"><?php echo $this->LANG['myanswers_ignore_user']; ?></a>
							<?php } ?>
						<?php }
						else
						{ ?>
						<a href="<?php echo getUrl($this->CFG['site']['url'] . 'members/myanswers.php?uid=' . $this->fields_arr['uid'], $this->CFG['site']['url'] . 'members/my/answers/' . $this->fields_arr['uid'] . '/', false); ?>"><?php echo $this->LANG['myanswers_ignore_user']; ?></a>
						<?php } ?>
					</span>
					<?php } ?>
					<?php if ($this->fields_arr['uid'] != $this->CFG['user']['user_id'] and $this->chkIsIntenalMailAllowed($this->fields_arr['uid']))
				{ ?>
					<span><a class="clsNoBorder" href="<?php echo getUrl($this->CFG['site']['url'] . 'members/' . $this->CFG['admin']['mail_urls']['compose']['normal'] . '?mcomp=' . $mcomp, $this->CFG['site']['url'] . 'members/' . $this->CFG['admin']['mail_urls']['compose']['htaccess'] . '?mcomp=' . $mcomp, false); ?>"><?php echo $this->LANG['myanswers_send_message']; ?></a></span>
					<?php } ?>
					<p class="clsPortfolioTimeStamp"><?php echo $this->LANG['myanswers_total_points']; ?>: <span class="clsTotalPoints"><?php echo $this->user_ans_log['total_points']; ?></span></p>
                    <p class=""><?php echo $this->LANG['member_since']; ?>: <span class="clsDate"><?php echo date('M d, Y', strtotime($this->fields_arr['doj'])); ?></span> </p></div></div>
                   <p class="clsUserBio"> <?php echo nl2br(wordWrapManual($bio, 45)); ?></p>
                    </div>
             	  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
<!--end of rounded corners-->

<?php
				$profileBadgeUrl = '';
				if ($this->isShowPageBlock('block_badge_embed')) $profileBadgeUrl = getUserProfileBadgeUrl($this->CFG['user']['name'])
?>
<div class="clsQuestionsLink">
	<ul>
<?php
						if ($profileBadgeUrl)
						{
?>
		<li id="selActivitySummaryLI" class="clsLeftActiveQuestionsLink"><span id="selActivitySummarySPAN" class="clsRightActiveQuestionsLink"><a id="selActivitySummaryA" class="clsMiddleActiveQuestionsLink" href="<?php echo $_SERVER['REQUEST_URI']; ?>" onclick="hideBlocks('selProfileBadge');showBlocks('selActivitySummary'); toggleNavBar(); return false;"><?php echo $this->LANG['common_activity_summary_title']; ?></a></span></li>
		<li id="selProfileBadgeLI" class="clsLeftInActiveQuestionsLink"><span id="selProfileBadgeSPAN" class="clsRightInActiveQuestionsLink"><a id="selProfileBadgeA" class="clsMiddleInActiveQuestionsLink" href="<?php echo $_SERVER['REQUEST_URI']; ?>" onclick="hideBlocks('selActivitySummary');showBlocks('selProfileBadge'); toggleNavBar(); return false;"><?php echo $this->LANG['common_badge_title']; ?></a></span></li>
<?php
						}
						else
						{
?>
		<li id="selActivitySummaryLI" class="clsLeftActiveQuestionsLink"><span id="selActivitySummarySPAN" class="clsRightActiveQuestionsLink"><a id="selActivitySummaryA" class="clsMiddleActiveQuestionsLink" href="<?php echo $_SERVER['REQUEST_URI']; ?>" onclick="return false;"><?php echo $this->LANG['common_activity_summary_title']; ?></a></span></li>
<?php
						}
?>
	</ul>
</div>

<div id="selActivitySummary" class="clsCommonIndexSection">
	<div class="clsUserAnswerQuestion">
    	<p class="clsUsersTotalPoints"><?php echo $this->LANG['myanswers_total_points']; ?>: <span class="clsTotalPoints"><?php echo $this->user_ans_log['total_points']; ?></span></p>
   		<div class="clsUserAnswers">
    		<h4><?php echo $this->LANG['answers']; ?></h4>
    		<p class="clsPortfolioTimeStamp"><?php echo $this->LANG['myanswers_total_answers']; ?>: <a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'questions.php?view=search&uname=' . $mcomp . '&opt=ans', $this->CFG['site']['relative_url'] . 'answers/search/?uname=' . $mcomp . '&opt=ans', false); ?>"><?php echo $this->user_ans_log['total_ans']; ?></a></p>
		</div>
		<div class="clsUserQuestion">
        	<h4><?php echo $this->LANG['questions']; ?></h4>
        	<p class="clsPortfolioTimeStamp"><?php echo $this->LANG['myanswers_questions_asked']; ?>: <a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'questions.php?view=search&uname=' . $mcomp . '&opt=ques', $this->CFG['site']['relative_url'] . 'answers/search/?uname=' . $mcomp, false); ?>"><?php echo $this->user_ans_log['total_ques']; ?></a></p>
			<p class="clsPortfolioTimeStamp"><?php echo $this->LANG['myanswers_resolved_questions']; ?>: <a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'questions.php?view=search&uname=' . $mcomp . '&opt=resolve', $this->CFG['site']['relative_url'] . 'answers/search/?uname=' . $mcomp . '&opt=resolve', false); ?>"><?php echo $this->getResolvedQuestions(); ?></a></p>
		</div>
	</div>
</div>

<?php
				if ($profileBadgeUrl)
				{
						$badgeUrlWithoutScript = getUserProfileBadgeUrl($this->CFG['user']['name'], false);
						$badgeUrlWithoutScript .= ($this->CFG['url']['rewrite']) ? ('?content=2') : ('&content=2');
?>
<div id="selProfileBadge" class="clsCommonIndexSection" style=display:none;>
	<div id="selUserBadgeEmbed">
	<p class="meta"><?php echo $this->LANG['myanswers_badge_embed_hint']; ?></p>
	<p><input type="text" class="clsBadgeTextBox" value='<?php echo $profileBadgeUrl; ?>' READONLY onclick="this.select()" /></p>
	</div>
</div>
<?php
				}
?>
		<?php
		}
		public function getResolvedQuestions()
		{
				$sql = 'SELECT COUNT(ques_id) AS resolved FROM ' . $this->CFG['db']['tbl']['questions'] . ' WHERE user_id=' . $this->dbObj->Param('uid') . ' AND status=\'Resolved\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['uid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = $rs->FetchRow();
				return $row['resolved'];
		}
		public function chkIsValidUser()
		{
				$this->chkIsNotEmpty('uid', $this->LANG['myanswers_err_tip_compulsory']);
				if (!$this->isValidFormInputs())
				{
						$this->setCommonErrorMsg($this->LANG['myanswers_err_invalid_user']);
						$this->setPageBlockShow('msg_form_error');
						return false;
				}
				if (is_numeric($this->fields_arr['uid']))
				{
						$sql = 'SELECT ' . $this->getUserTableFields(array('user_id', 'name', 't_height', 't_width', 'photo_server_url', 'photo_ext', 'doj')) . ', u.' . $this->getUserTableField('user_id') . ' as img_user_id' . ' FROM ' . $this->CFG['db']['tbl']['users'] . ' AS u' . ' WHERE u.' . $this->getUserTableField('user_id') . '=' . $this->dbObj->Param('uid') . ' AND u.' . $this->getUserTableField('usr_status') . '=\'Ok\'';
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['uid']));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
						if (!$rs->PO_RecordCount())
						{
								$this->setCommonErrorMsg($this->LANG['myanswers_err_invalid_user']);
								$this->setPageBlockShow('msg_form_error');
								return false;
						}
				}
				else
				{
						$sql = 'SELECT ' . $this->getUserTableFields(array('user_id', 'name', 't_height', 't_width', 'photo_server_url', 'photo_ext', 'doj')) . ', u.' . $this->getUserTableField('user_id') . ' as img_user_id' . ' FROM ' . $this->CFG['db']['tbl']['users'] . ' AS u' . ' WHERE u.' . $this->getUserTableField('name') . '=' . $this->dbObj->Param('uid') . ' AND u.' . $this->getUserTableField('usr_status') . '=\'Ok\'';
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['uid']));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
						if (!$rs->PO_RecordCount())
						{
								$this->setCommonErrorMsg($this->LANG['myanswers_err_invalid_user']);
								$this->setPageBlockShow('msg_form_error');
								return false;
						}
				}
				$row = $rs->FetchRow();
				$this->fields_arr['nameofuser'] = $row['name'];
				$this->fields_arr['doj'] = $row['doj'];
				$this->fields_arr['uid'] = $row['user_id'];
				return true;
		}
}
$myanswers = new MyAnswerFormHandler();
$myanswers->setCfgLangGlobal($CFG, $LANG);
$myanswers->setPageBlockNames(array('form_user_details', 'form_points', 'form_answer_details', 'msg_form_error', 'msg_form_success', 'block_badge_embed'));
$myanswers->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$myanswers->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$myanswers->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$myanswers->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$myanswers->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$myanswers->setFormField('search_question', '');
$myanswers->setFormField('msg', '');
$myanswers->setFormField('list', '');
$myanswers->setFormField('nameofuser', '');
$myanswers->setFormField('doj', '');
$myanswers->setFormField('uid', '');
if ($CFG['user']['user_id']) $myanswers->setFormField('uid', $CFG['user']['user_id']);
$pagename = 'My Answers';
$myanswers->display_bold = 3;
$myanswers->setDBObject($db);
$myanswers->numpg = $CFG['data_tbl']['numpg'];
$myanswers->setFormField('start', 0);
$myanswers->setFormField('numpg', $CFG['data_tbl']['numpg']);
$myanswers->setMinRecordSelectLimit($CFG['data_tbl']['min_record_select_limit']);
$myanswers->setMaxRecordSelectLimit($CFG['data_tbl']['max_record_select_limit']);
$myanswers->setNumPerPageListArr($CFG['data_tbl']['numperpage_list_arr']);
$myanswers->setTableNames(array());
$myanswers->setReturnColumns(array());
$myanswers->setFormField('orderby_field', '');
$myanswers->setFormField('orderby', '');
$myanswers->sanitizeFormInputs($_REQUEST);
$myanswers->setAllPageBlocksHide();
$title = 'My Answers';
if ($myanswers->chkIsValidUser())
{
		if ($myanswers->getFormField('uid') == $CFG['user']['user_id'])
		{
				$myanswers->setPageBlockShow('block_badge_embed');
		}
		else
		{
				$title = ucwords($myanswers->getFormField('nameofuser')) . ' Answers';
		}
		$myanswers->setPageBlockShow('form_answer_details');
		$myanswers->setPageBlockShow('form_points');
		$myanswers->setPageBlockShow('form_user_details');
}
$cfg_title = ' - ' . $title;
$CFG['mods']['is_include_only']['non_html_header_files'] = false;
$CFG['mods']['is_include_only']['html_header'] = true;
$CFG['site']['title'] = $CFG['site']['title'] . $cfg_title;
require ($CFG['site']['project_path'] . 'common/application_top.inc.php');
?>
<script type="text/javascript" language="javascript">
var hideBlocks = function(){
	for(var i=0;i<arguments.length;i++){
		var objName = arguments[i];
		var liName = objName+'LI';
		var spanName = objName+'SPAN';
		var aName = objName+'A';
		if(obj = $(objName)){
			obj.style.display = 'none';
			$(liName).className="clsLeftInActiveQuestionsLink";
			$(spanName).className="clsRightInActiveQuestionsLink";
			$(aName).className="clsMiddleInActiveQuestionsLink";
		}
	}
}
var showBlocks = function(){
	for(var i=0;i<arguments.length;i++){
		var objName = arguments[i];
		var liName = objName+'LI';
		var spanName = objName+'SPAN';
		var aName = objName+'A';
		if(obj = $(objName)){
			obj.style.display = '';
			$(liName).className="clsLeftActiveQuestionsLink";
			$(spanName).className="clsRightActiveQuestionsLink";
			$(aName).className="clsMiddleActiveQuestionsLink";
		}
	}
}
</script>
<script type="text/javascript" language="javascript">
function toggleTabsShowHide()
	{
		if($('myAnswersShortList').style.display=='')
			{
				$('myAnswersShortList').style.display='none';
			}
		else
			{
				$('myAnswersShortList').style.display='';
			}
		return false;
	}
</script>
<div id="selMyAnswers">
	<h2><?php echo $title; ?></h2>
<?php
$myanswers->displayAnswersTopLinks();
if ($myanswers->isShowPageBlock('msg_form_error'))
{
?>
    	<div id="selMsgError">
      		<p>
<?php
		echo $LANG['myanswers_err_sorry'] . ' ' . $myanswers->getCommonErrorMsg();
?>
      		</p>
    	</div>
<?php
}
if ($myanswers->isShowPageBlock('msg_form_success'))
{
?>
	    <div id="selMsgSuccess">
	      	<p>
<?php
		echo $myanswers->getCommonErrorMsg();
?>
	      	</p>
	    </div>
    <?php
}
if ($myanswers->isShowPageBlock('form_user_details')) $myanswers->displayUserDetails();

?>
<div id="selShowQuestions">
<?php
if ($myanswers->isShowPageBlock('form_answer_details')) $myanswers->displayAnswerDetails();

?>
</div>
<?php
?>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>
