<?php
// The source code packaged with this file is Free Software, Copyright (C) 2005 by
// Ricardo Galli <gallir at uib dot es>.
// It's licensed under the AFFERO GENERAL PUBLIC LICENSE unless stated otherwise.
// You can get copies of the licenses here:
// 		http://www.affero.org/oagpl.html
// AFFERO GENERAL PUBLIC LICENSE is also included in the file called "COPYING".

include mnminclude.'extra_fields_smarty.php';

$main_smarty->compile_dir = "templates_c/";
$main_smarty->template_dir = "templates/";
$main_smarty->cache_dir = "cache/";
$main_smarty->config_dir = "";
$main_smarty->force_compile = false; // has to be off to use cache

if(isset($_REQUEST['id'])){$main_smarty->assign('request_id', $_REQUEST['id']);}
if(isset($_REQUEST['category'])){$main_smarty->assign('request_category', sanitize($_REQUEST['category'], 3));}
if(isset($_REQUEST['search'])){$main_smarty->assign('request_search', $_REQUEST['search']);}
if(isset($_POST['username'])){$main_smarty->assign('login_username', trim($_POST['username']));}

$main_smarty->assign('dblang', $dblang);
$main_smarty->assign('pligg_language', pligg_language);
$main_smarty->assign('user_logged_in', $current_user->user_login);
$main_smarty->assign('user_authenticated', $current_user->authenticated);
$main_smarty->assign('Enable_Tags', Enable_Tags);
$main_smarty->assign('Enable_Live', Enable_Live);
$main_smarty->assign('Voting_Method', Voting_Method);
$main_smarty->assign('Enable_AddTo', Enable_AddTo);
$main_smarty->assign('my_base_url', my_base_url);
$main_smarty->assign('my_pligg_base', my_pligg_base);
$main_smarty->assign('Spell_Checker', Spell_Checker);
$main_smarty->assign('Allow_User_Change_Templates', Allow_User_Change_Templates);
$main_smarty->assign('urlmethod', urlmethod); //Steef: shakks tagcloud
$main_smarty->assign('enable_gzip_files',enable_gzip_files);
$main_smarty->assign('UseAvatars', do_we_use_avatars());
$main_smarty->assign('Allow_Friends', Allow_Friends);
if($current_user->user_login){$main_smarty->assign('Current_User_Avatar_ImgSrc', get_avatar('small', "", "", "", $current_user->user_id));}

$main_smarty->assign('SearchMethod', SearchMethod);
$main_smarty = SetSmartyURLs($main_smarty);
$main_smarty->display('blank.tpl');
$the_template = The_Template;
$main_smarty->assign('the_template', The_Template);
$main_smarty->assign('the_template_sidebar_modules', The_Template . "/sidebar_modules");
$main_smarty->assign('tpl_head', $the_template . '/head');
$main_smarty->assign('tpl_body', $the_template . '/body');
$main_smarty->assign('tpl_right_sidebar', $the_template . '/sidebar');
$main_smarty->assign('tpl_header', $the_template . '/header');
$main_smarty->assign('tpl_footer', $the_template . '/footer');

//remove this after we eliminate the need for do_header
$canIhaveAccess = 0;
$canIhaveAccess = $canIhaveAccess + checklevel('god');
if($canIhaveAccess == 1){$main_smarty->assign('isgod', 1);}
$canIhaveAccess = $canIhaveAccess + checklevel('admin');
if($canIhaveAccess == 1){$main_smarty->assign('isadmin', 1);}

$vars = '';
check_actions('all_pages_top', $vars);

// setup the sorting links on the index page in smarty
if(isset($_GET['category'])){
	if (urlmethod == 1) {
		$main_smarty->assign('index_url_recent', getmyurl('index_sort', 'recent', '&amp;category='.$_GET['category']));
		$main_smarty->assign('index_url_today', getmyurl('index_sort', 'today', '&amp;category='.$_GET['category']));
		$main_smarty->assign('index_url_yesterday', getmyurl('index_sort', 'yesterday', '&amp;category='.$_GET['category']));
		$main_smarty->assign('index_url_week', getmyurl('index_sort', 'week', '&amp;category='.$_GET['category']));
		$main_smarty->assign('index_url_month', getmyurl('index_sort', 'month', '&amp;category='.$_GET['category']));
		$main_smarty->assign('index_url_year', getmyurl('index_sort', 'year', '&amp;category='.$_GET['category']));
		$main_smarty->assign('cat_url', getmyurl("maincategory"));
	}
	else {
		$main_smarty->assign('index_url_recent', getmyurl('index_sort', 'recent', 'category/'.$_GET['category']));
		$main_smarty->assign('index_url_today', getmyurl('index_sort', 'today', 'category/'.$_GET['category']));
		$main_smarty->assign('index_url_yesterday', getmyurl('index_sort', 'yesterday', 'category/'.$_GET['category']));
		$main_smarty->assign('index_url_week', getmyurl('index_sort', 'week', 'category/'.$_GET['category']));
		$main_smarty->assign('index_url_month', getmyurl('index_sort', 'month', 'category/'.$_GET['category']));
		$main_smarty->assign('index_url_year', getmyurl('index_sort', 'year', 'category/'.$_GET['category']));
		$main_smarty->assign('cat_url', getmyurl("maincategory"));
	}
}	
else {
	$main_smarty->assign('index_url_recent', getmyurl('index_sort', 'recent'));
	$main_smarty->assign('index_url_today', getmyurl('index_sort', 'today'));
	$main_smarty->assign('index_url_yesterday', getmyurl('index_sort', 'yesterday'));
	$main_smarty->assign('index_url_week', getmyurl('index_sort', 'week'));
	$main_smarty->assign('index_url_month', getmyurl('index_sort', 'month'));
	$main_smarty->assign('index_url_year', getmyurl('index_sort', 'year'));
	}
?>
