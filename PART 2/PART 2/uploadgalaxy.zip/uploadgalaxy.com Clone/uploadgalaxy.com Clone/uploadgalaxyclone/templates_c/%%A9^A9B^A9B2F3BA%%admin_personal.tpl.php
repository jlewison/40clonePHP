<?php /* Smarty version 2.6.6, created on 2006-02-01 11:04:52
         compiled from admin/admin_personal.tpl */ ?>
<form action="admin_index.php" method=POST>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse; font-family:Verdana; font-size:10pt" bordercolor="#111111" width="100%" height="100">
  <tr>
    <td width="43%" align="right" height="29">Name</td>
    <td width="1%" height="29">&nbsp;</td>
    <td width="106%" align="left" height="29">
    <input type="text" name="name" size="20" style="font-family: Verdana; font-size: 10pt" value="<?php echo $this->_tpl_vars['aname']; ?>
"></td>
  </tr>
  <tr>
    <td width="43%" align="right" height="28">Password</td>
    <td width="1%" height="28">&nbsp;</td>
    <td width="106%" align="left" height="28">
    <input type="password" name="pass" size="20" style="font-family: Verdana; font-size: 10pt"></td>
  </tr>
  <tr>
    <td width="43%" align="right" height="30">New Password</td>
    <td width="1%" height="30">&nbsp;</td>
    <td width="106%" align="left" height="30">
    <input type="password" name="npass" size="20" style="font-family: Verdana; font-size: 10pt"></td>
  </tr>
  <tr>
    <td width="43%" align="right" height="30">Confirm Password</td>
    <td width="1%" height="30">&nbsp;</td>
    <td width="106%" align="left" height="30">
    <input type="password" name="cpass" size="20" style="font-family: Verdana; font-size: 10pt"></td>
  </tr>
  <tr>
    <td width="43%" align="right" height="30">Email</td>
    <td width="1%" height="30">&nbsp;</td>
    <td width="106%" align="left" height="30">
    <input type="text" name="email" size="20" style="font-family: Verdana; font-size: 10pt" value="<?php echo $this->_tpl_vars['aemail']; ?>
"></td>
  </tr>
  <tr>
    <td width="43%" align="right" height="35">&nbsp;</td>
    <td width="1%" height="35">&nbsp;</td>
    <td width="106%" align="left" height="35">
    <input type="submit" value="Save" name="req"></td>
  </tr>
</table>
<input type="hidden" name="type" value="<?php echo $_REQUEST['change']; ?>
">
</form>