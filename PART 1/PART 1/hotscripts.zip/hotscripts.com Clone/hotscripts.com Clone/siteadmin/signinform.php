<?



?> 
<SCRIPT language=javascript>
function submit_check() {
	  loginForm.submit();
}

</SCRIPT>
<table width="100%" border="0" cellpadding="0" cellspacing="0" dwcopytype="CopyTableCell">
  <tr>
    <td valign="top">&nbsp; </td>
    <td valign="top"><FORM name=loginForm  action="login.php"
      method=post>
        <div align="center"></div>
        <TABLE width="289" border=0 align=center cellPadding=5 cellSpacing=0>
          <TBODY>
            <TR vAlign=center> 
              <TD>&nbsp;</TD>
            </TR>
            <TR vAlign=center bgcolor="#666666"> 
              <TD colspan="2"><font color="#ffffff" size="4" face="Verdana, Arial, Helvetica, sans-serif"><strong>Admin 
                Login</strong></font></TD>
            </TR>
            <TR vAlign=center bgcolor="#CCCCCC"> 
              <TD> <DIV align=right><font color="#000000"><strong><FONT 
            size=2 face="Verdana, Arial, Helvetica, sans-serif">Name</FONT></strong></font></DIV></TD>
              <TD bgcolor="#CCCCCC"><font color="#000000"> 
                <INPUT  class="box1"  name=UserName>
                </font></TD>
            </TR>
            <TR vAlign=center bgcolor="#CCCCCC"> 
              <TD> <DIV align=right><font color="#000000"><strong><FONT 
            size=2 face="Verdana, Arial, Helvetica, sans-serif">Password</FONT></strong></font></DIV></TD>
              <TD><font color="#000000"> 
                <INPUT  class="box1"  type=password name=Password>
                </font></TD>
            </TR>
            <TR align=right bgcolor="#CCCCCC"> 
              <TD 
        colSpan=2><table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr> 
                    <td width="33%" align="right"> <div align="center"> <font color="#000000"> 
                        <input type="submit" name="Submit" value="Sign In" class="btn">
                        </font></div></td>
                  </tr>
                </table></TD>
            </TR>
            <TR align=right> 
              <TD colSpan=2>&nbsp; </TD>
            </TR>
          </TBODY>
        </TABLE>
        <div align="center"></div>
      </FORM></td>
    <td valign="top">&nbsp; </td>
  </tr>
</table>
