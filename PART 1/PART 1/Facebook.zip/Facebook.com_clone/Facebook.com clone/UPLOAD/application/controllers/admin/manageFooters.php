<?php
/**
 * Footer management Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 02/01/2008
 */
class ManageFooters extends controller
{
		function ManageFooters()
		{
				parent::controller();
				//check login
				if ($this->session->userdata('admin_logged_in') != 1 && $this->session->userdata('admin_id') == '') redirect('admin/login');
				//Load the language file
				$this->lang->load('admin/manageFooters', $this->config->item('language_code'));
				$this->load->model('footermodel');
		}
		function index()
		{
				$this->load->library('validation');
				$this->_footerFrm();
				$outputData['addFooters'] = true;
				$outputData['editFooters'] = false;
				$outputData['footersList'] = $this->footermodel->getFooters();
				if ($this->validation->run() == false) $outputData['validationError'] = $this->validation->error_string;
				else
				{
						if (isset($_POST['manage_footer']))
						{
								if ($this->footermodel->isTemplateExist($_POST['page_name'])) $outputData['validationError'] = 'The save as(template) name already exist';
								elseif ($this->footermodel->isPageExist($_POST['title'])) $outputData['validationError'] = 'The title(link name) already exist';
								else
								{
										$this->footermodel->insertFooter($_POST);
										$file_path = BASEPATH . '../application/views/default/footer/' . $_POST['page_name'] . '.tpl';
										$fp = @fopen($file_path, 'a+') or @fopen($file_path, 'w+');
										fwrite($fp, $_POST['content']);
										fclose($fp);
										//Set the flash data
										$this->session->set_flashdata('successMsg', $this->lang->line('managefooters_add_success_msg'));
										redirect('admin/manageFooters');
								}
						}
				}
				$this->smartyextended->view('../admin/manageFooters', $outputData);
		}
		function _footerFrm()
		{
				$rules['content'] = 'trim|required|alphanumeric';
				$rules['page_name'] = 'trim|required|alpha_dash|min_length[2]|max_length[50]';
				$rules['title'] = 'trim|required|alphanumeric|min_length[2]|max_length[15]';
				$fields['content'] = $this->lang->line('managefooters_content');
				$fields['page_name'] = $this->lang->line('managefooters_page_name');
				$fields['title'] = $this->lang->line('managefooters_title_lbl');
				$this->validation->set_rules($rules);
				$this->validation->set_fields($fields);
		}
		#***************************************************************************
		#Method			: deleteFooter
		#Description	: deletes footers
		#Author			
		#***************************************************************************
		function deleteFooter()
		{
				$footer_id = $this->uri->segment(4);
				$outputData['footers'] = $this->footermodel->getFooter($footer_id);
				$this->footermodel->deleteFooter($footer_id);
				$file_path = BASEPATH . '../application/views/default/footer/' . $outputData['footers']['page_name'] . '.tpl';
				unlink($file_path);
				//Set the flash data
				$this->session->set_flashdata('successMsg', $this->lang->line('managefooters_delete_success_msg'));
				redirect('admin/manageFooters');
		}
		#***************************************************************************
		#Method			: editFooter
		#Description	: updates footers
		#Author			
		#***************************************************************************
		function editFooter()
		{
				$this->load->library('validation');
				$footer_id = $this->uri->segment(4);
				$outputData['addFooters'] = false;
				$outputData['editFooters'] = true;
				$outputData['footers'] = $this->footermodel->getFooter($footer_id);
				$outputData['footersList'] = $this->footermodel->getFooters();
				$this->_footerFrm();
				if ($this->validation->run() == false)
				{
						$outputData['validationError'] = $this->validation->error_string;
						$this->smartyextended->view('../admin/manageFooters', $outputData);
				}
				else
				{
						if (isset($_POST['update_footer']))
						{
								if ($this->footermodel->isPageExist($_POST['title'], $_POST['page_id']))
								{
										$outputData['validationError'] = 'The title (link name) name already exist';
										$this->smartyextended->view('../admin/manageFooters', $outputData);
								}
								else
								{
										$this->footermodel->updateFooter($_POST);
										$file_path = BASEPATH . '../application/views/default/footer/' . $_POST['page_name'] . '.tpl';
										unlink($file_path);
										$fp = @fopen($file_path, 'a+') or @fopen($file_path, 'w+');
										fwrite($fp, $_POST['content']);
										fclose($fp);
										//Set the flash data
										$this->session->set_flashdata('successMsg', $this->lang->line('managefooters_update_success_msg'));
										redirect('admin/manageFooters');
								}
						}
				}
		}
}
?>