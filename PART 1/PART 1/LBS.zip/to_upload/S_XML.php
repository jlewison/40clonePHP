<?php include('ip_domain_ban.php'); include('settings.php');?>
<?xml version="1.0" encoding="UTF-8"?>
<OpenSearchDescription xmlns="http://a9.com/-/spec/opensearch/1.1/">
                <ShortName><?php echo("$sitetitle");?></ShortName>
                <Description>LBS powered provider</Description>
                <InputEncoding>UTF-8</InputEncoding><Url type="text/html" template="http://<?php echo("$domainname");?><?php echo("$path");?>search.php?q={searchTerms}"/></OpenSearchDescription>