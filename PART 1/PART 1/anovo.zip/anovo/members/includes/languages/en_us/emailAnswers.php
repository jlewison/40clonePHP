<?php

$LANG['emailanswers_title'] = 'Email this Question';
$LANG['emailanswers_tbl_summary'] = 'Email this Question';
$LANG['emailanswers_user_email'] = 'Your Email';
$LANG['emailanswers_user_name'] = 'Your Name';
$LANG['emailanswers_to_emails'] = 'Friends email ids';
$LANG['emailanswers_to_emails_msg'] = 'To enter multiple recipients, separate addresses with a comma.';
$LANG['emailanswers_subject'] = 'Subject ';
$LANG['emailanswers_message'] = 'Message ';
$LANG['emailanswers_submit'] = 'Submit';
$LANG['emailanswers_err_tip_compulsory'] = 'Required';
$LANG['emailanswers_err_tip_id_compulsory'] = 'Invalid Question ID';
$LANG['contactuserr_tip_invalid_email'] = 'invalid email';
$LANG['contactuserr_tip_invalid_email_ids'] = 'One or more email ids are invalid';
$LANG['contactuserr_tip_enter_valid_email_ids'] = 'Enter valid email ids';
$LANG['emailanswers_success'] = 'Email sent successfully';
$LANG['emailanswers_failure'] = 'Problem in sending mail';
$LANG['emailanswers_failure_message'] = 'The fields should not be empty';
$LANG['import_contacts'] = 'Import Contacts';

?>