<?php

class ManageLanguageFile extends Controller
{
		function ManageLanguageFile()
		{
				parent::controller();
				//check login
				if ($this->session->userdata('admin_logged_in') != 1 && $this->session->userdata('admin_id') == '') redirect('admin/login');
				//Load the language file
				$this->lang->load('admin/manageLanguageFile', $this->config->item('language_code'));
		}
		function index()
		{
				$this->load->helper('string');
				$this->load->library('validation');
				$this->load->model('settingsmodel');
				if ($this->session->userdata('admin_logged_in') != 1 && $this->session->userdata('admin_profileID') == '')
				{
						redirect('admin/logout');
				}
				$outputData['form_directory_list'] = true;
				$outputData['form_files_list'] = false;
				$outputData['form_edit_phrases'] = false;
				$outputData['page_list_phrases'] = false;
				$outputData['languages'] = $this->settingsmodel->getLanguages();
				if (isset($_POST['submit_directory']) && isset($_POST['language']))
				{
						if ($_POST['directory'] == 'admin')
						{
								$dir = BASEPATH . '../application/language/' . $_POST['language'] . '/admin/';
								$dir1 = './application/language/' . $_POST['language'] . '/admin/';
						}
						else
						{
								$dir = BASEPATH . '../application/language/' . $_POST['language'] . '/';
								$dir1 = './application/language/' . $_POST['language'] . '/member/';
						}
						$direxists = is_dir($dir);
						if ($direxists)
						{
								if ($handle = opendir($dir))
								{
										/* This is the correct way to loop over the directory. */
										while (($file = readdir($handle)) != false)
										{
												if (strpos($file, '.php') !== false)
												{
														$outputData['file_arr'][] = $file;
												}
										}
										closedir($handle);
								}
								$outputData['directory'] = $_POST['directory'];
								$outputData['directory_path'] = $dir;
								$outputData['form_directory_list'] = false;
								$outputData['form_edit_phrases'] = false;
								$outputData['page_list_phrases'] = false;
								$outputData['form_files_list'] = true;
						}
						else
						{
								$outputData['validation_error'] = $this->lang->line('managelanguagefile_error');
								$outputData['form_directory_list'] = true;
								$outputData['form_files_list'] = false;
								$outputData['form_edit_phrases'] = false;
								$outputData['page_list_phrases'] = false;
								$outputData['languages'] = $this->settingsmodel->getLanguages();
						}
				}
				elseif (isset($_POST['submit_files']))
				{
						$outputData['form_directory_list'] = false;
						$outputData['form_edit_phrases'] = true;
						$outputData['form_files_list'] = false;
						$outputData['page_list_phrases'] = false;
						$outputData['file'] = $_POST['file'];
						$outputData['directory'] = $_POST['directory'];
						$outputData['directory_path'] = $_POST['directory_path'] . $_POST['file'];
						$fileArr = explode('.', $_POST['file']);
						require_once ($outputData['directory_path']);
						//$this->lang->load((($outputData['directory'] == 'members')? '': $outputData['directory'].'/').trim($fileArr[0],'_lang'), $this->config->item('language_code'));
						$outputData['langArr'] = $lang;
				}
				elseif (isset($_POST['submit_phrases']))
				{
						$outputData['form_directory_list'] = false;
						$outputData['form_edit_phrases'] = false;
						$outputData['form_files_list'] = false;
						$outputData['page_list_phrases'] = true;
						$outputData['directory_path'] = $_POST['directory_path'];
						if ($_POST)
						{
								// set file name with path
								$file_path = $_POST['directory_path'];
								//read file content
								$content = file_get_contents($file_path);
								//include the file as
								require ($file_path);
								// checks whether file edited
								$is_file_edited = false;
								foreach ($_POST as $varname => $value)
								{
										// checks variable value has been changed
										if (isset($lang[$varname]) && isset($_POST[$varname]) && $lang[$varname] != $_POST[$varname])
										{
												$is_file_edited = true;
												// replace value of file content
												// vaiable start pos
												$variable_start = strpos($content, $varname, 0);
												// vaiable end pos
												$end_of_variable = strpos($content, '=', $variable_start) + 1;
												// get content before value
												$content_before_value = trim(substr($content, 0, $end_of_variable));
												// vaiable line end pos
												$variable_end_pos = strpos($content, ';', $end_of_variable);
												// get content after value
												$content_after_value = trim(substr($content, $variable_end_pos));
												// new content+
												$content = $content_before_value . ' \'' . $_POST[$varname] . '\'' . $content_after_value;
										}
								}
								if ($is_file_edited)
								{
										$fw = fopen($file_path, 'w');
										fwrite($fw, $content);
										fclose($fw);
								}
						}
						$outputData['success_msg'] = 'The language file edited successfully!';
						require ($outputData['directory_path']);
						//$this->lang->load((($outputData['directory'] == 'members')? '': $outputData['directory'].'/').trim($fileArr[0],'_lang'), $this->config->item('language_code'));
						$outputData['langArr'] = $lang;
				}
				//}
				$this->smartyextended->view('../admin/manageLanguageFile', $outputData);
		}
}
?>