<!--
//var copyRightRTG = 'Copyright \xA9 2005 RealTime Gaming\nAll Rights Reserved';
//function click(e) {
//if (document.all) {
//if (event.button == 2) {
//alert(copyRightRTG);
//return false;
//}
//}
//if (document.layers) {
//if (e.which == 3) {
//alert(copyRightRTG);
//return false;
//}
//}
//}
//if (document.layers) {
//document.captureEvents(Event.MOUSEDOWN);
//}
//document.onmousedown=click;
// -->