<?php //00461
// Copyright Notice
// Web Site URL:  http://www.zeeways.com
// Script Owner eMail: mail@zeeways.com
// Date: April, 2007
// Script Name: Zeeways Auction Website PHP Script
// Copyright Details: This script is not free.  Do not Remove this Copy Right notice.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the site administrator.');exit(199);
?>
4+oV5BrRlGVliWKeuk0e99axD9RlNfdgzxKdmuAidj3UvWMgyqIsML8jSywD3hFCRjCLMX3JrtWJ
RuGvR9/luG+oIOF6gOnlVhLEOxGH4l6QZm4IuawPmz+B+H5gWrP3cX78Oq7CK65/AYcULzF3j+Hm
KxWJ5YimijjPx7jKWHsgYNMLt2eMZw8IBDJkp4A8gBimrHrv3+8HVEMId4DYl4iNd3yaVkFDEkTv
xqhoaTRgPGKmUPWkbUn4bgOq34npzoskINwscd0HWw9Ya1EIToqd0CHqv/n58FniHXkUV0kAwBsr
yGh0OpI94ZLvluTWqe1MICR8ER3mT6tbY/8R1A/2bxf/8rsuBlvrzrnHuORK0OEew9b1rS4PEchG
gOCwsBICa4f8XZLQf2TvmxLA3DRLLqns5WCVrTmYmHJSsOndrYx0Tunf314tXMQMJYdy5bfXP7Id
SQ7UcBQhu4twvZawxNL8CgkiQPIYP3/tYeDPRvtHGQhfSR5oEJC+HNT74SlfPzAEg0CMgMaz0zbS
NL/KTwoPKSYdewxJtgnAZqE2ejz0Czl/fnu3DLGdfeUrxIB6y+S3PIjzyVvQb+kgW8aTDStQnj0i
LnGPj4cBMZrLuCSY2wb4OAMRy/FlA4TvwJa7hR9WoK2UYvd6P/S6mxgzlRWzCtHh4lQA78/Ki/i1
UNPUqooXXQgrOkpM/MpX4CCGzjn6+aKbE+RU+1ujv4kKpFYFDl4Rc3cuU/itjqYxVAv8bWWfspST
5l0ir/rvjG3V9AWLX2mn0m8VfMylKtfn/9igpaf145BRV8tww8QR833tCsl0O2fVnzbfTDeluGSz
pyUaff+xrWFb44tVGH9PoAtwOMSuAI194EJAZlsD4kcIn0/fxhIDBmr5Q0imvfwl921P5+mwjsG0
i5Nt0kqJWMdLmAJ4mebMomM7tC3DxoAgHmTKR3QWhjo4W3egbkfTHHL2XHPD18zJiMzV5wjWUQmh
UGvguZYFuCi76rXRbWHl+wV/pWpIOG==