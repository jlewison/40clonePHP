<?php

   class calendarwatcheventsData extends Data {

      var $table = CALENDARWATCHEVENTS_TABLE;

      var $config = array (
  'table' => CALENDARWATCHEVENTS_TABLE,
  'idField' => 'osdate_calendarwatchevents_id',
  'addedMsg' => 'Osdate Calendarwatchevents %s Added',
  'added_err' => 'Can\\\'t Add Osdate Calendarwatchevents',
  'editMsg' => 'Osdate Calendarwatchevents %s Updated',
  'editErr' => 'Can\\\'t Update Osdate Calendarwatchevents',
  'delErr' => 'Can\\\'t Delete Osdate Calendarwatchevents',
  'delMsg' => 'Osdate Calendarwatchevents %s Deleted',
  'blankErr' => 'Osdate Calendarwatchevents Empty',
  'fields' => 
  array (
    'userid' => 
    array (
      'name' => 'userid',
      'description' => 'Userid',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'eventid' => 
    array (
      'name' => 'eventid',
      'description' => 'Eventid',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
  ),
);   

      function calendarwatcheventsData() {
      
         $this->Data($this->config);
      }
   }

?>
