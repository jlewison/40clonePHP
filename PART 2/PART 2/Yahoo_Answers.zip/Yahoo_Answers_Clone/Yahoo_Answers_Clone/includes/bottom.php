<div id=y-ks-footer>
	<div class=dotted-line></div>
	<div id=y-ks-footer-intl-links>
		<table cellspacing="4" cellpadding="0" width="100%" border="0">
			<tbody>
				<tr>
					<td valign=top nowrap align="center"><a href="<? echo $configuration['url'] ?>"><strong>
					<span style="text-decoration: none">&copy; 2008, <? echo $configuration['url'] ?>, All Rights Reserved.</span></strong><span style="text-decoration: none"></td></span></a>
					<? include('google_728x90.php'); ?>
					<div class=dotted-line></div>
				</tr>
			</tbody>
		</table>
	</div>
</div>
</div>
</body></html>