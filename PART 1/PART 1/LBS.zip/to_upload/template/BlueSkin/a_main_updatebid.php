<?php include('template/BlueSkin/top_side.php');?>

<!--
###################################################################################
#######################                                     #######################
#######################   M A I N   S E C T I O N   Start   #######################
#######################                                     #######################
###################################################################################
-->
<div id="central">

<h1><?php echo("$lang_132");?></h1>


<div id="gene"><?php echo("$lang_133");?></div>

<div align="center">
  <form action="https://www.paypal.com/cgi-bin/webscr" method="post">
    <input type="hidden" name="cmd" value="_xclick">
    <input type="hidden" name="business" value="<?php echo("$paypal");?>">
    <input type="hidden" name="item_name" value="Payment for Bid ID <?php echo("$bidid");?> for link <?php echo("$url");?>">
    <input type="hidden" name="item_number" value="<?php echo("$bidid");?>">
    <input type="hidden" name="amount" value="<?php echo("$newbid");?>">
    <input type="hidden" name="no_shipping" value="2">
    <input type="hidden" name="no_note" value="1">
    <input type="hidden" name="currency_code" value="<?php echo("$paypalcurrency");?>">
    <input type="hidden" name="bn" value="PP-BuyNowBF">
    <input name="submit" type="image" src="img/PP-4.gif" alt="Make payments with PayPal - it's fast, free and secure!" />
  </form>
</div>
</div>
<!--
###################################################################################
#######################                                     #######################
#######################    M A I N   S E C T I O N   End    #######################
#######################                                     #######################
###################################################################################
-->

<?php include('template/BlueSkin/bottom_side.php');?>
<?php include('template/BlueSkin/footer.php'); ?>