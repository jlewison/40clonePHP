<?php include('template/lbs/b_inside_top.php');?>

<!--
###################################################################################
#######################                                     #######################
#######################   M A I N   S E C T I O N   Start   #######################
#######################                                     #######################
###################################################################################
-->
<style type="text/css">
<!--
.style1 {font-size: 12px}
.style2 {font-size: 11px}
.style5 {font-size: 11px; font-style: italic; }
.style6 {
	font-size: 12px;
	font-weight: bold;
	font-family: Tahoma;
	color: #0066CC;
}
.style7 {
	font-size: 12px;
	font-family: Tahoma;
	color: #000000;
}
.style9 {font-size: 11px; font-family: Tahoma; }
.style11 {font-size: 11px; font-family: Tahoma; color: #006600; }
.style13 {color: #990000}
.style14 {font-size: 11px; font-family: Tahoma; color: #990000; }
.style15 {color: #3333CC}
.style16 {
	font-size: 14px;
	color: #006600;
}
#exam {
	border: 1px solid #FF6633;
}
-->
</style>


<div id="central">

<img src="<?php echo("$path");?>template/lbs/img/submit.png" alt="Submit New Listing" border="0">

<table width="80%"  border="0" align="center" cellpadding="6" cellspacing="0" id="exam">
  <tr>
    <td bgcolor="#FFFFF2"><div class="sample">
        <div class="style6 style16" id="kw"><?php echo("$lang_43");?></div>
        <div class="style7" id="d1"><img src="" width="32" height="6" alt="" style="background-color: #FFFFFF"><br>
          <?php echo("$lang_44");?></div>
        <div>
          <hr />
          <span class="style11" id="d3">http://your_site.com/</span><span class="style9"> :: <span class="style15"><?php echo("$lang_45");?> <?php echo (date("Y-m-d"));?></span> <?php if($fremode == 'N') { ?> :: <em><span class="style13"><?php echo("$minbid");?></span></em></span> <span class="style14"><?php echo("$lang_29");?> <?php } else { } ?></span></div>
    </div></td>
  </tr>
</table>
<?php
mysql_select_db($database_apound, $apound);
$query_LboxCAT = "SELECT * FROM categorylisting ORDER BY categorylisting.categoryname ASC";
$LboxCAT = mysql_query($query_LboxCAT, $apound) or die(mysql_error());
$row_LboxCAT = mysql_fetch_assoc($LboxCAT);
$totalRows_LboxCAT = mysql_num_rows($LboxCAT);

mysql_select_db($database_apound, $apound);
$query_LboxCATa = "SELECT * FROM categorylisting WHERE categorylisting.catlistid = '$selectc' ORDER BY categorylisting.categoryname ASC";
$LboxCATa = mysql_query($query_LboxCATa, $apound) or die(mysql_error());
$row_LboxCATa = mysql_fetch_assoc($LboxCATa);
$totalRows_LboxCATa = mysql_num_rows($LboxCATa);
$ncnam = $row_LboxCATa['categoryname'];

$su_categ = mysql_real_escape_string($_GET[su_categ]);

mysql_select_db($database_apound, $apound);
$query_aLboxCAT = "SELECT * FROM categorylisting WHERE categorylisting.catlistid = '$su_categ' ORDER BY categorylisting.categoryname ASC";
$aLboxCAT = mysql_query($query_aLboxCAT, $apound) or die(mysql_error());
$row_aLboxCAT = mysql_fetch_assoc($aLboxCAT);
$totalRows_aLboxCAT = mysql_num_rows($aLboxCAT);
$selected_id = $row_aLboxCAT['catlistid'];
$selected_name = $row_aLboxCAT['categoryname'];
?>

<form name="pgfrm" onsubmit="return chkfrm();" action="<?php echo("$path");?>submit.php" method="post">
  <table border="0" align="center" cellpadding="2" cellspacing="1" id="sbf">
<?php
if($alphacat <> 'Y') { ?>

    <tr>
      <td><span class="style1"><strong><?php echo("$lang_50");?></strong></span></td>
      <td>&nbsp;</td>
      <td>
	<?php if($su_categ == '') { ?>

			<select name="selectc" id="selectc">
            <?php if($selectc <> '') { ?>
				<option value="<?php echo("$selectc");?>" selected><?php echo("$ncnam");?></option>
                <?php }
                else { ?>
                <option value="" selected>Please select category</option>
                <?php } ?>
				<?php do { ?>
				<option value="<?php echo $row_LboxCAT['catlistid']?>"><?php echo $row_LboxCAT['categoryname']?></option>
				<?php } while ($row_LboxCAT = mysql_fetch_assoc($LboxCAT)); $rows = mysql_num_rows($LboxCAT); if($rows > 0) { mysql_data_seek($LboxCAT, 0); $row_LboxCAT = mysql_fetch_assoc($LboxCAT); } ?>
			</select>

	<?php } else { ?>

			<select name="selectc" id="selectc">
			    <option value="<?php echo("$selected_id");?>" selected><?php echo("$selected_name");?></option>
			    <?php do { ?>
			    <option value="<?php echo $row_LboxCAT['catlistid']?>"><?php echo $row_LboxCAT['categoryname']?></option>
			    <?php } while ($row_LboxCAT = mysql_fetch_assoc($LboxCAT)); $rows = mysql_num_rows($LboxCAT); if($rows > 0) { mysql_data_seek($LboxCAT, 0); $row_LboxCAT = mysql_fetch_assoc($LboxCAT); } ?>
			</select>

<?php } ?>	  </td>
    </tr>
<?php } 
else { }
?>

    <tr>
      <td><span class="style1"><strong><?php echo("$lang_51");?></strong></span></td>
      <td>&nbsp;</td>
      <td><input name="email" type="text" value="<?php echo("$email");?>" size="51" maxLength=50 /></td>
    </tr>
    <tr>
      <td><span class="style1"><strong><?php echo("$lang_52");?></strong><span class="style5"> (<?php echo("$maxtitle");?> <?php echo("$lang_71");?>)</span></span></td>
      <td>&nbsp;</td>
      <td><input name="keyword" type="text" onchange=dodiv(); onkeyup=dodiv(); value="<?php echo("$keyword");?>" size="51" maxLength=<?php echo("$maxtitle");?> /></td>
    </tr>
    <tr>
      <td><span class="style1"><strong><?php echo("$lang_53");?></strong></span></td>
      <td align="right">&nbsp;</td>
      <td><input name="url" type="text" onchange=dodiv(); onkeyup=dodiv(); value="<?php echo("$url");?>" size="51" />
        <br />
        <span class="style1" style="color:#006600">ex: http://www.yourdomain.com/</span></td>
    </tr>


<!-- link back start -->

<?php
if($fremode == 'Y' and $fmwb == 'Y') { ?>

<tr>
  <td><span class="style1"><strong><?php echo("$lang_152");?></strong></span></td>
  <td>&nbsp;</td>
  <td><label>
    <textarea name="textarea" id="textarea" cols="40" rows="4"><?php echo("$linkbacka");?></textarea>
  </label>    </td>
</tr>

<tr>
  <td><span class="style1"><strong><?php echo("$lang_151");?></strong></span></td>
  <td align="center"></td>
  <td><input name="blinkurl" type="text" onchange=dodiv(); onkeyup=dodiv(); value="<?php echo("$blinkurl");?>" size="51" /><br /><span class="style1" style="color:#006600">ex: http://www.yourdomain.com/</span>
</td>
</tr>

<!-- link back end -->

<?php } else {} ?>

    <tr>
      <td valign="top"><span class="style1"><strong><?php echo("$lang_54");?></strong><br />
          <span class="style2"><em>(<?php echo("$maxdesc");?> <?php echo("$lang_71");?>)</em><br />
        <?php echo("$lang_72");?></span></span></td>
      <td>&nbsp;</td>
      <td>
	  
	  <textarea name="descr1" class="buyforminp22" cols="40" rows="5" onchange=dodiv(); onkeyup=dodiv(); maxLength=<?php echo("$maxdesc");?>; onKeyDown="textCounter(document.pgfrm.descr1,document.pgfrm.dlength,<?php echo("$maxdesc");?>)" onKeyUp="textCounter(document.pgfrm.descr1,document.pgfrm.dlength,<?php echo("$maxdesc");?>)"><?php echo("$descr1");?></textarea><br />
	  
	  <input type="text" name="dlength" size="3" maxlength="3" value="<?php echo("$maxdesc");?>" readonly /> 
	  <?php echo("$lang_74");?></td>
    </tr>
    <tr>
      <td valign="top"><span class="style1"><strong><?php echo("$lang_55");?></strong><br />
          <span class="style2"><em>(<?php echo("$maxexdesc");?> <?php echo("$lang_71");?>)</em><br />
        <?php echo("$lang_73");?></span></span></td>
      <td>&nbsp;</td>
      <td><textarea name="descr2" cols="40" rows="8" onKeyDown="textCounter(document.pgfrm.descr2,document.pgfrm.length,<?php echo("$maxexdesc");?>)" onKeyUp="textCounter(document.pgfrm.descr2,document.pgfrm.length,<?php echo("$maxexdesc");?>)"><?php echo("$descr2");?></textarea>
      <br /><input type="text" name="length" size="3" maxlength="3" value="<?php echo("$maxexdesc");?>" readonly /> 
      <?php echo("$lang_74");?></td>
    </tr>
    <tr>
      <td valign="top"><span class="style1"><strong><?php echo("$lang_56");?></strong><br />
          <span class="style5">(<?php echo("$maxmdesc");?> <?php echo("$lang_71");?>)</span></span></td>
      <td>&nbsp;</td>
      <td><textarea name="mdesc" cols="40" rows="6" onKeyDown="textCounter(document.pgfrm.mdesc,document.pgfrm.mlength,<?php echo("$maxmdesc");?>)" onKeyUp="textCounter(document.pgfrm.mdesc,document.pgfrm.mlength,<?php echo("$maxmdesc");?>)"><?php echo("$mdesc");?></textarea>
      <br /><input type="text" name="mlength" size="3" maxlength="3" value="<?php echo("$maxmdesc");?>" readonly /> 
      <?php echo("$lang_74");?></td>
    </tr>
    <tr>
      <td><span class="style1"><strong><?php echo("$lang_57");?></strong><br />
          <span class="style5">(<?php echo("$maxkword");?> <?php echo("$lang_71");?>)</span></span></td>
      <td>&nbsp;</td>
      <td><input name="mword" type="text" value="<?php echo("$mword");?>" size="51" maxLength=<?php echo("$maxkword");?> /></td>
    </tr>
    <tr>
      <td><strong><?php echo("$lang_180");?></strong></td>
      <td>&nbsp;</td>
      <td>
        <input name="tag1" type="text" id="tag1" value="<?php echo("$tag1");?>" size="15" />
        <input name="tag2" type="text" id="tag2" value="<?php echo("$tag2");?>" size="15" />
        <input name="tag3" type="text" id="tag3" value="<?php echo("$tag3");?>" size="15" />
      </td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>
      <input name="tag4" type="text" id="tag4" value="<?php echo("$tag4");?>" size="15" />
      <input name="tag5" type="text" id="tag5" value="<?php echo("$tag5");?>" size="15" />
      <input name="tag6" type="text" id="tag6" value="<?php echo("$tag6");?>" size="15" />
        </td>
    </tr>
<?php if($deepenable == 'Y') { ?>
    <tr>
      <td><span class="style1"><strong><?php echo("$lang_58");?></strong><span class="style5"> (<?php echo("$maxtitle");?> <?php echo("$lang_71");?>)</span></span></td>
      <td>&nbsp;</td>
      <td><input name="deeptf" type="text" value="<?php echo("$deeptf");?>" size="51" maxLength=<?php echo("$maxtitle");?> /></td>
    </tr>
    <tr>
      <td><span class="style1"><strong><?php echo("$lang_59");?></strong></span></td>
      <td align="right">&nbsp;</td>
      <td><input name="dfurl" type="text" value="<?php echo("$dfurl");?>" size="51" />
        <br />
        <span class="style1" style="color:#006600">ex: http://www.yourdomain.com/page/...</span></td>
    </tr>
    <tr>
      <td><span class="style1"><strong><?php echo("$lang_60");?></strong><span class="style5"> (<?php echo("$maxtitle");?> <?php echo("$lang_71");?>)</span></span></td>
      <td>&nbsp;</td>
      <td><input name="deepts" type="text" value="<?php echo("$deepts");?>" size="51" maxLength=<?php echo("$maxtitle");?> /></td>
    </tr>
    <tr>
      <td><span class="style1"><strong><?php echo("$lang_61");?></strong></span></td>
      <td align="right">&nbsp;</td>
      <td><input name="dsurl" type="text" value="<?php echo("$dsurl");?>" size="51" />
        <br />
        <span class="style1" style="color:#006600">ex: http://www.yourdomain.com/<span class="style1" style="color:#006600">page/...</span></span></td>
    </tr>
    <tr>
      <td><span class="style1"><strong><?php echo("$lang_62");?></strong> <span class="style5">(<?php echo("$maxtitle");?> <?php echo("$lang_71");?>)</span></span></td>
      <td>&nbsp;</td>
      <td><input name="deeptt" type="text" value="<?php echo("$deeptt");?>" size="51" maxLength=<?php echo("$maxtitle");?> /></td>
    </tr>
    <tr>
      <td><span class="style1"><strong><?php echo("$lang_63");?></strong></span></td>
      <td align="right">&nbsp;</td>
      <td><input name="dturl" type="text" value="<?php echo("$dturl");?>" size="51" />
        <br />
        <span class="style1" style="color:#006600">ex: http://www.yourdomain.com/<span class="style1" style="color:#006600">page/...</span></span></td>
    </tr>
<?php } else {} ?>


<?php if($fremode == 'N') { ?>  
    <tr>
      <td><span class="style1"><strong><?php echo("$lang_64");?></strong></span></td>
      <td align="right"><?php echo("$currency");?></td>
      <td><input name="bid" onchange=dodiv(); onkeypress="return chknum(event)" onkeyup=dodiv(); value="<?php echo("$minbid");?>" size="4" maxlength="4" />
      .00</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td><div class="attn"><?php echo("$lang_75");?> <?php echo("$currency");?><?php echo("$minbid");?> <?php echo("$lang_76");?></div></td>
    </tr>
<?php } else { ?><input name="bid" id="bid" type="hidden" value="<?php echo("$minbid");?>" /> <?php } ?>




<!-- Start -->

<?php

if($asubm == 'Y') { ?>

    <tr>
      <td class="style1"><strong><?php echo("$lang_66");?></strong></td>
      <td>&nbsp;</td>
      <td><input name="gm_str_nr" type="text" id="gm_str_nr" value="<?php echo("$gm_str_nr");?>" size="10" /></td>
    </tr>
    <tr>
      <td class="style1"><strong><?php echo("$lang_65");?></strong></td>
      <td>&nbsp;</td>
      <td><label>
        <input name="gm_str" type="text" id="gm_str" value="<?php echo("$gm_str");?>" size="51" />
      </label></td>
    </tr>
    <tr>
      <td class="style1"><strong><?php echo("$lang_67");?></strong></td>
      <td>&nbsp;</td>
      <td><input name="gm_city" type="text" id="gm_city" value="<?php echo("$gm_city");?>" size="51" /></td>
    </tr>
    <tr>
      <td class="style1"><strong><?php echo("$lang_68");?></strong></td>
      <td>&nbsp;</td>
      <td><input name="gm_county" type="text" id="gm_county" value="<?php echo("$gm_county");?>" size="51" /></td>
    </tr>
    <tr>
      <td class="style1"><strong><?php echo("$lang_69");?></strong></td>
      <td>&nbsp;</td>
      <td>
<select name="gm_country" id="gm_country">
          <option value="0">Select Country</option>
          <option value="AF">AF - Afghanistan</option>
          <option value="AL">AL - Albania</option>
          <option value="DZ">DZ - Algeria</option>
          <option value="AS">AS - American Samoa</option>
          <option value="AD">AD - Andorra</option>
          <option value="AO">AO - Angola</option>
          <option value="AI">AI - Anguilla</option>
          <option value="AQ">AQ - Antarctica</option>
          <option value="AG">AG - Antigua and Bar</option>
          <option value="AR">AR - Argentina</option>
          <option value="AM">AM - Armenia</option>
          <option value="AW">AW - Aruba</option>
          <option value="AT">AT - Austria</option>
          <option value="AZ">AZ - Azerbaijan</option>
          <option value="BS">BS - Bahamas</option>
          <option value="BH">BH - Bahrain</option>
          <option value="BD">BD - Bangladesh</option>
          <option value="BB">BB - Barbados</option>
          <option value="BY">BY - Belarus</option>
          <option value="BE">BE - Belgium</option>
          <option value="BZ">BZ - Belize</option>
          <option value="BJ">BJ - Benin</option>
          <option value="BM">BM - Bermuda</option>
          <option value="BT">BT - Bhutan</option>
          <option value="BO">BO - Bolivia</option>
          <option value="BA">BA - Bosnia and Herz</option>
          <option value="BW">BW - Botswana</option>
          <option value="BV">BV - Bouvet Island</option>
          <option value="BR">BR - Brazil</option>
          <option value="IO">IO - British Indian </option>
          <option value="BN">BN - Brunei Darussal</option>
          <option value="BG">BG - Bulgaria</option>
          <option value="BF">BF - Burkina Faso</option>
          <option value="BI">BI - Burundi</option>
          <option value="KH">KH - Cambodia</option>
          <option value="CM">CM - Cameroon</option>
          <option value="CA">CA - Canada</option>
          <option value="CV">CV - Cape Verde</option>
          <option value="KY">KY - Cayman Islands</option>
          <option value="CF">CF - Central African</option>
          <option value="TD">TD - Chad</option>
          <option value="CL">CL - Chile</option>
          <option value="CN">CN - China</option>
          <option value="CX">CX - Christmas Islan</option>
          <option value="CC">CC - Cocos (Keeling)</option>
          <option value="CO">CO - Colombia</option>
          <option value="KM">KM - Comoros</option>
          <option value="CG">CG - Congo</option>
          <option value="CK">CK - Cook Islands</option>
          <option value="CR">CR - Costa Rica</option>
          <option value="CI">CI - Cote D'Ivoire</option>
          <option value="HR">HR - Croatia</option>
          <option value="CU">CU - Cuba</option>
          <option value="CY">CY - Cyprus</option>
          <option value="CZ">CZ - Czech Republic</option>
          <option value="DK">DK - Denmark</option>
          <option value="DJ">DJ - Djibouti</option>
          <option value="DM">DM - Dominica</option>
          <option value="DO">DO - Dominican Repub</option>
          <option value="TP">TP - East Timor</option>
          <option value="EC">EC - Ecuador</option>
          <option value="EG">EG - Egypt</option>
          <option value="SV">SV - El Salvador</option>
          <option value="GQ">GQ - Equatorial Guin</option>
          <option value="ER">ER - Eritrea</option>
          <option value="EE">EE - Estonia</option>
          <option value="ET">ET - Ethiopia</option>
          <option value="FK">FK - Falkland Island</option>
          <option value="FO">FO - Faroe Islands</option>
          <option value="FJ">FJ - Fiji</option>
          <option value="FI">FI - Finland</option>
          <option value="FR">FR - France</option>
          <option value="FX">FX - France, Metropo</option>
          <option value="GF">GF - French Guiana</option>
          <option value="PF">PF - French Polynesi</option>
          <option value="TF">TF - French Southern</option>
          <option value="GA">GA - Gabon</option>
          <option value="GM">GM - Gambia</option>
          <option value="GE">GE - Georgia</option>
          <option value="DE">DE - Germany</option>
          <option value="GH">GH - Ghana</option>
          <option value="GI">GI - Gibraltar</option>
          <option value="GR">GR - Greece</option>
          <option value="GL">GL - Greenland</option>
          <option value="GD">GD - Grenada</option>
          <option value="GP">GP - Guadeloupe</option>
          <option value="GU">GU - Guam</option>
          <option value="GT">GT - Guatemala</option>
          <option value="GN">GN - Guinea</option>
          <option value="GW">GW - Guinea-bissau</option>
          <option value="GY">GY - Guyana</option>
          <option value="HT">HT - Haiti</option>
          <option value="HM">HM - Heard and Mc Do</option>
          <option value="HN">HN - Honduras</option>
          <option value="HK">HK - Hong Kong</option>
          <option value="HU">HU - Hungary</option>
          <option value="IS">IS - Iceland</option>
          <option value="ID">ID - In&lt;font colo</option>
          <option value="IN">IN - India</option>
          <option value="IR">IR - Iran (Islamic R</option>
          <option value="IQ">IQ - Iraq</option>
          <option value="IE">IE - Ireland</option>
          <option value="IL">IL - Israel</option>
          <option value="IT">IT - Italy</option>
          <option value="JM">JM - Jamaica</option>
          <option value="JP">JP - Japan</option>
          <option value="JO">JO - Jordan</option>
          <option value="KZ">KZ - Kazakhstan</option>
          <option value="KE">KE - Kenya</option>
          <option value="KI">KI - Kiribati</option>
          <option value="KP">KP - Korea, Democrat</option>
          <option value="KR">KR - Korea, Republic</option>
          <option value="KW">KW - Kuwait</option>
          <option value="KG">KG - Kyrgyzstan</option>
          <option value="LA">LA - Lao People's De</option>
          <option value="LV">LV - Latvia</option>
          <option value="LB">LB - Lebanon</option>
          <option value="LS">LS - Lesotho</option>
          <option value="LR">LR - Liberia</option>
          <option value="LY">LY - Libyan Arab Jam</option>
          <option value="LI">LI - Liechtenstein</option>
          <option value="LT">LT - Lithuania</option>
          <option value="LU">LU - Luxembourg</option>
          <option value="MO">MO - Macau</option>
          <option value="MK">MK - Macedonia, The </option>
          <option value="MG">MG - Madagascar</option>
          <option value="MW">MW - Malawi</option>
          <option value="MY">MY - Malaysia</option>
          <option value="MV">MV - Maldives</option>
          <option value="ML">ML - Mali</option>
          <option value="MT">MT - Malta</option>
          <option value="MH">MH - Marshall Island</option>
          <option value="MQ">MQ - Martinique</option>
          <option value="MR">MR - Mauritania</option>
          <option value="MU">MU - Mauritius</option>
          <option value="YT">YT - Mayotte</option>
          <option value="MX">MX - Mexico</option>
          <option value="FM">FM - Micronesia, Fed</option>
          <option value="MD">MD - Moldova, Republ</option>
          <option value="MC">MC - Monaco</option>
          <option value="MN">MN - Mongolia</option>
          <option value="MS">MS - Montserrat</option>
          <option value="MA">MA - Morocco</option>
          <option value="MZ">MZ - Mozambique</option>
          <option value="MM">MM - Myanmar</option>
          <option value="NA">NA - Namibia</option>
          <option value="NR">NR - Nauru</option>
          <option value="NP">NP - Nepal</option>
          <option value="NL">NL - Netherlands</option>
          <option value="AN">AN - Netherlands Ant</option>
          <option value="NC">NC - New Caledonia</option>
          <option value="NZ">NZ - New Zealand</option>
          <option value="NI">NI - Nicaragua</option>
          <option value="NE">NE - Niger</option>
          <option value="NG">NG - Nigeria</option>
          <option value="NU">NU - Niue</option>
          <option value="NF">NF - Norfolk Island</option>
          <option value="MP">MP - Northern Marian</option>
          <option value="NO">NO - Norway</option>
          <option value="OM">OM - Oman</option>
          <option value="PK">PK - Pakistan</option>
          <option value="PW">PW - Palau</option>
          <option value="PA">PA - Panama</option>
          <option value="PG">PG - Papua New Guine</option>
          <option value="PY">PY - Paraguay</option>
          <option value="PE">PE - Peru</option>
          <option value="PH">PH - Philippines</option>
          <option value="PN">PN - Pitcairn</option>
          <option value="PL">PL - Poland</option>
          <option value="PT">PT - Portugal</option>
          <option value="PR">PR - Puerto Rico</option>
          <option value="QA">QA - Qatar</option>
          <option value="RE">RE - Reunion</option>
          <option value="RO">RO - Romania</option>
          <option value="RU">RU - Russian Federat</option>
          <option value="RW">RW - Rwanda</option>
          <option value="KN">KN - Saint Kitts and</option>
          <option value="LC">LC - Saint Lucia</option>
          <option value="VC">VC - Saint Vincent a</option>
          <option value="WS">WS - Samoa</option>
          <option value="SM">SM - San Marino</option>
          <option value="ST">ST - Sao Tome and Pr</option>
          <option value="SA">SA - Saudi Arabia</option>
          <option value="SN">SN - Senegal</option>
          <option value="SC">SC - Seychelles</option>
          <option value="SL">SL - Sierra Leone</option>
          <option value="SG">SG - Singapore</option>
          <option value="SK">SK - Slovakia (Slova</option>
          <option value="SI">SI - Slovenia</option>
          <option value="SB">SB - Solomon Islands</option>
          <option value="SO">SO - Somalia</option>
          <option value="ZA">ZA - South Africa</option>
          <option value="GS">GS - South Georgia a</option>
          <option value="ES">ES - Spain</option>
          <option value="LK">LK - Sri Lanka</option>
          <option value="SH">SH - St. Helena</option>
          <option value="PM">PM - St. Pierre and </option>
          <option value="SD">SD - Sudan</option>
          <option value="SR">SR - Suriname</option>
          <option value="SJ">SJ - Svalbard and Ja</option>
          <option value="SZ">SZ - Swaziland</option>
          <option value="SE">SE - Sweden</option>
          <option value="CH">CH - Switzerland</option>
          <option value="SY">SY - Syrian Arab Rep</option>
          <option value="TW">TW - Taiwan</option>
          <option value="TJ">TJ - Tajikistan</option>
          <option value="TZ">TZ - Tanzania, Unite</option>
          <option value="TH">TH - Thailand</option>
          <option value="TG">TG - Togo</option>
          <option value="TK">TK - Tokelau</option>
          <option value="TO">TO - Tonga</option>
          <option value="TT">TT - Trinidad and To</option>
          <option value="TN">TN - Tunisia</option>
          <option value="TR">TR - Turkey</option>
          <option value="TM">TM - Turkmenistan</option>
          <option value="TC">TC - Turks and Caico</option>
          <option value="TV">TV - Tuvalu</option>
          <option value="UG">UG - Uganda</option>
          <option value="UA">UA - Ukraine</option>
          <option value="AE">AE - United Arab Emi</option>
          <option value="UK" selected>UK - United Kingdom</option>
          <option value="US">US - United States</option>
          <option value="UM">UM - United States M</option>
          <option value="UY">UY - Uruguay</option>
          <option value="UZ">UZ - Uzbekistan</option>
          <option value="VU">VU - Vanuatu</option>
          <option value="VA">VA - Vatican City St</option>
          <option value="VE">VE - Venezuela</option>
          <option value="VN">VN - Viet Nam</option>
          <option value="VG">VG - Virgin Islands </option>
          <option value="VI">VI - Virgin Islands </option>
          <option value="WF">WF - Wallis and Futu</option>
          <option value="EH">EH - Western Sahara</option>
          <option value="YE">YE - Yemen</option>
          <option value="YU">YU - Yugoslavia</option>
          <option value="ZR">ZR - Zaire</option>
          <option value="ZM">ZM - Zambia</option>
          <option value="ZW">ZW - Zimbabwe</option>
        </select>      </td>
    </tr>

<?php } else {} ?>

<!-- End -->



    <tr>
      <td><span class="style1"><strong><?php echo("$lang_70");?></strong></span></td>
      <td>&nbsp;</td>
      <td><input name="number" type="text" id=\&quot;number\&quot; /> 
      (<?php echo("$lang_77");?> <strong><font color="#FF0000"><?php echo("$lang_78");?></font></strong> <?php echo("$lang_79");?>) </td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td><img src="random_image.php"></td>
    </tr>
  </table>
	<br>
	<div align="right" style="margin:10px;">
		<input type="hidden" value="1" name="categ">
		<input class="submit-btn" type="submit" name="submit" value="Next Step >>">
	</div>
</form>


</div>
<!--
###################################################################################
#######################                                     #######################
#######################    M A I N   S E C T I O N   End    #######################
#######################                                     #######################
###################################################################################
-->
<script type="text/javascript">
function textCounter(field,cntfield,maxlimit, len_name)
{
	if (field.value.length > maxlimit)
		field.value = field.value.substring(0, maxlimit);
	else
		cntfield.value = maxlimit - field.value.length;
}
</script>
<?php include('template/lbs/b_inside_bottom.php');?>
<?php include('template/lbs/b_footer_tpl.php'); ?>

