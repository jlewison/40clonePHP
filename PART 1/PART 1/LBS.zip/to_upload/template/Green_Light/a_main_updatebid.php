<?php include('template/Green_Light/b_inside_top.php');?>
<td valign="top">
<!--
###################################################################################
#######################   M A I N   S E C T I O N   Start   #######################
###################################################################################
-->
<div class="page-header"><h1>Complete Listing Upgrade</h1></div>
<div class="box" style="margin-left:10px">
	<div class="box-cap-left">
		<div class="box-cap-right">
			<div class="box-cap"></div>
		</div>
	</div>
	<div class="box-left">
		<div class="box-right">
<p>Please click on the PayPal image and you will be forwarded to the secure site to complete the payment.</p>

<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
  <div align="center">
    <input type="hidden" name="cmd" value="_xclick">
    <input type="hidden" name="business" value="<?php echo("$paypal");?>">
    <input type="hidden" name="item_name" value="Payment for Bid ID <?php echo("$bidid");?> for link <?php echo("$url");?>">
    <input type="hidden" name="item_number" value="<?php echo("$bidid");?>">
    <input type="hidden" name="amount" value="<?php echo("$newbid");?>">
    <input type="hidden" name="no_shipping" value="2">
    <input type="hidden" name="no_note" value="1">
    <input type="hidden" name="currency_code" value="<?php echo("$paypalcurrency");?>">
    <input type="hidden" name="bn" value="PP-BuyNowBF">
    <input name="submit" type="image" src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/PP-4.gif" alt="Make payments with PayPal - it's fast, free and secure!" />
  </div>
</form>
		</div>
	</div>
	<div class="box-bottom-left">
		<div class="box-bottom-right">
		</div>
	</div>
</div>	
<!--
###################################################################################
#######################    M A I N   S E C T I O N   End    #######################
###################################################################################
-->


<?php include('template/Green_Light/b_footer_tpl.php'); ?>