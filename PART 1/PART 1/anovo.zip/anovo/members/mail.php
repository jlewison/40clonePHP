<?php
require_once ('../common/config.inc.php');
$CFG['lang']['include_files'][] = 'members/includes/languages/%s/mail.php';
$CFG['lang']['include_files'][] = 'members/includes/languages/%s/mailRightLinks.php';
$CFG['html']['header'] = 'members/includes/languages/%s/html_header.php';
$CFG['html']['footer'] = 'members/includes/languages/%s/html_footer.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['mods']['include_files'][] = 'common/classes/class_ListRecordsHandler.lib.php';
$CFG['mods']['include_files'][] = 'common/classes/class_MailHandler.lib.php';
$CFG['lang']['include_files'][] = 'common/configs/config_mails.inc.php';
$CFG['db']['is_use_db'] = true;
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class MailFormHandler extends MailHandler
{
		public function buildMailQuery()
		{
				switch ($this->fields_arr['folder'])
				{
						case 'inbox':
								$this->setTableNames(array($this->CFG['db']['tbl']['users'] . ' AS u', $this->CFG['db']['tbl']['messages'] . ' AS m', $this->CFG['db']['tbl']['messages_info'] . ' AS mi'));
								$this->setReturnColumns(array('mi.info_id, mi.message_id, mi.to_id, mi.from_id, ' . $this->getUserTableField('user_id') . ' AS img_user_id, ' . $this->getUserTableFields(array('user_id', 'name', 'image_path', 'gender', 'photo_server_url', 't_width', 't_height', 's_width', 's_height', 'photo_ext')) . ', m.subject, DATE_FORMAT(m.mess_date, \'' . $this->CFG['format']['date'] . '\') as mess_date, DATE_FORMAT(m.mess_date, \'%I:%i %p\') as mess_time, mi.to_viewed, mi.to_answer'));
								$condition = 'mi.to_id = \'' . $this->CFG['user']['user_id'] . '\' AND mi.from_id = u.' . $this->getUserTableField('user_id') . ' AND mi.message_id = m.message_id AND mi.to_delete = \'No\' AND mi.to_stored = \'No\'';
								$this->fields_arr['orderby_field'] = 'mi.info_id';
								$this->fields_arr['orderby'] = 'DESC';
								$this->mail_title = $this->LANG['mail_title_inbox'];
								break;
						case 'sent':
								$this->setTableNames(array($this->CFG['db']['tbl']['users'] . ' AS u', $this->CFG['db']['tbl']['messages'] . ' AS m', $this->CFG['db']['tbl']['messages_info'] . ' AS mi'));
								$this->setReturnColumns(array('mi.info_id, mi.message_id, mi.to_id, mi.from_id, ' . $this->getUserTableField('user_id') . ' AS img_user_id, ' . $this->getUserTableFields(array('user_id', 'name', 'image_path', 'gender', 'photo_server_url', 't_width', 't_height', 's_width', 's_height', 'photo_ext')) . ', m.subject, DATE_FORMAT(m.mess_date, \'' . $this->CFG['format']['date'] . '\') as mess_date, DATE_FORMAT(m.mess_date, \'%I:%i %p\') as mess_time, mi.from_viewed, mi.from_answer'));
								$condition = 'mi.from_id = \'' . $this->CFG['user']['user_id'] . '\' AND mi.to_id = u.' . $this->getUserTableField('user_id') . ' AND mi.message_id = m.message_id AND mi.from_delete = \'No\' AND mi.from_stored = \'No\' AND mi.email_status = \'Normal\'';
								$this->fields_arr['orderby_field'] = 'mi.info_id';
								$this->fields_arr['orderby'] = 'DESC';
								$this->mail_title = $this->LANG['mail_title_sent'];
								break;
				}
				$this->sql_condition = $condition;
				$this->buildSelectQuery();
				$this->buildSortQuery();
		}
		public function buildSortQuery()
		{
				$this->sql_sort = $this->fields_arr['orderby_field'] . ' ' . $this->fields_arr['orderby'];
		}
		public function showMessages($no_records)
		{
				if (!$this->isResultsFound())
				{
?>
				  	<div id="selMsgAlert">
						<p><?php echo $no_records; ?></p>
					</div>
				<?php
						return;
				}
?>
				<table border="1" cellspacing="0" summary="<?php echo $this->LANG['mail_tbl_summary']; ?>" class="clsMyPhotoAlbumTbl">
		            <tr>
		              <th class="clsAlignCenter"><input type="checkbox" class="clsCheckRadio" id="checkall" onclick="selectAll(this.form)" name="checkall" value="" tabindex="<?php echo $this->getTabIndex(); ?>" /></th>
		              <th class="clsFromTitle">
					  	<?php
				$date_label = '';
				switch ($this->fields_arr['folder'])
				{
						case 'sent':
								echo $this->LANG['mail_to'];
								break;
						default:
								echo $this->LANG['mail_from'];
								break;
				}
?>
					  </th>
		              <th><?php echo $this->LANG['mail_status']; ?></th>
		              <th><?php echo $this->LANG['mail_subject']; ?></th>
		              <th><?php echo $this->LANG['mail_date']; ?></th>
		            </tr>
				<?php
				while ($row = $this->fetchResultRecord())
				{
						switch ($this->fields_arr['folder'])
						{
								case 'sent':
										$answer = $row['from_answer'];
										$viewed = $row['from_viewed'];
										break;
								default:
										$answer = $row['to_answer'];
										$viewed = $row['to_viewed'];
										break;
						}
						$userDetails = $row;
?>
					 <?php if ($answer == 'Reply')
						{ ?>
					 <tr class="<?php echo $this->getCSSRowClass(); ?> clsReplied">
					 <?php } elseif ($answer == 'Forward')
						{ ?>
					  <tr class="<?php echo $this->getCSSRowClass(); ?> clsForward">
					<?php } elseif ($viewed == 'No')
						{ ?>
					<tr class="<?php echo $this->getCSSRowClass(); ?> clsNotRead">
					  <?php }
						else
						{ ?>
					<tr class="<?php echo $this->getCSSRowClass(); ?> clsRead">
					  <?php } ?>
					<td class="clsAlignCenter"><input type="checkbox" class="clsCheckRadio" onclick="disableHeading('selFormMail');" name="message_ids[]" value="<?php echo $row['from_id'] . '_' . $row['to_id'] . '_' . $row['info_id']; ?>" tabindex="<?php echo $this->getTabIndex(); ?>" <?php if ((is_array($this->fields_arr['message_ids'])) && (in_array($row['from_id'] . '_' . $row['to_id'] . '_' . $row['info_id'], $this->fields_arr['message_ids']))) echo "CHECKED"; ?>/></td>
					<td id="selPhotoGallery" class="clsSenderInfo">
						<?php if (chkUserImageAllowed())
						{ ?>
				    	<p id="selImageBorder"><?php displayUserImage($userDetails, 'small'); ?></p>
				    	<?php } ?>
						<p><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'myanswers.php?uid=' . $userDetails['user_id'], $this->CFG['site']['relative_url'] . 'my/answers/' . $userDetails['user_id'] . '/', false); ?>"><?php echo stripString($userDetails['name'], $this->CFG['username']['short_length']); ?></a></p>
					</td>
				  <?php if ($answer == 'Reply')
						{ ?>
				  <td class="clsMessageStatus"><span id="selRepliedMail"><?php echo $this->LANG['replied']; ?></span></td>
				  <?php } elseif ($answer == 'Forward')
						{ ?>
				  <td class="clsMessageStatus"><span id="selForwardedMail"><?php echo $this->LANG['forward']; ?></span></td>
				  <?php } elseif ($viewed == 'No')
						{ ?>
				  <td class="clsMessageStatus"><span id="selNotReadMail"><?php echo $this->LANG['new_mail']; ?></span></td>
				  <?php }
						else
						{ ?>
				  <td class="clsMessageStatus"><span id="selReadMail"><?php echo $this->LANG['read']; ?></span></td>
				  <?php } ?>
				  <td class="clsMailSubject">
    				<a href="<?php echo getUrl($this->getMailReadNormalUrl() . '&message_id=' . $row['info_id'], $this->getMailReadHtaccessUrl() . '?message_id=' . $row['info_id']); ?>">
    				<?php
						echo wordWrapManual($row['subject'], 10, 35);
?></a>
					</td>
				  <td class="clsMessageDate"><p><?php echo $row['mess_date']; ?></p><p><?php echo $row['mess_time']; ?></p></td>
				</tr>
				<?php
				}
?>
	            <tr>
	              <td colspan="5" class="<?php echo $this->getCSSFormFieldCellClass('action'); ?>">
	                <?php echo $this->getFormFieldErrorTip('action'); ?>
	                <select name="action" id="action" tabindex="<?php echo $this->getTabIndex(); ?>">
	                  <option value=""><?php echo $this->LANG['mail_select_action']; ?></option>
	                  <?php $this->populateActions($this->getFormField('action')); ?>
	                </select>
					<a href="<?php echo $_SERVER['REQUEST_URI']; ?>" id="dAltMlti"></a>
	                <input type="button" class="clsSubmitButton" name="mail_action" id="mail_action" onclick="getMultiCheckBoxValue('selFormMail', 'checkall', '<?php echo $this->LANG['mail_select_message']; ?>', 'dAltMlti');if(multiCheckValue!=''){getAction()}" tabindex="<?php echo $this->getTabIndex(); ?>" value="<?php echo $this->LANG['mail_action']; ?>" />
				  </td>
	            </tr>
	          </table>
				<?php
		}
		public function deleteMessages($message_ids)
		{
				$message_ids_arr = explode(',', $message_ids);
				foreach ($message_ids_arr as $combined_id)
				{
						$id_arr = explode('_', $combined_id);
						$from_id = $id_arr[0];
						$to_id = $id_arr[1];
						$message_id = $id_arr[2];
						if ($this->fields_arr['folder'] == 'trash')
						{
								if ($to_id == $this->CFG['user']['user_id']) $this->updateMessageStatusTrash('to_delete', $message_id);
								if ($from_id == $this->CFG['user']['user_id']) $this->updateMessageStatusTrash('from_delete', $message_id);
						}
						else
						{
								if ($to_id == $this->CFG['user']['user_id']) $this->updateMessageStatusDelete('to_delete', $message_id);
								if ($from_id == $this->CFG['user']['user_id']) $this->updateMessageStatusDelete('from_delete', $message_id);
						}
				}
		}
		public function populateActions($highlight_action)
		{
?>
				<option value="mail_delete"<?php echo ($highlight_action == 'mail_delete') ? ' selected="selected"' : ''; ?>><?php echo $this->LANG['mail_delete']; ?></option>
			<?php
		}
}
$mail = new MailFormHandler();
if (!chkAllowedModule(array('mail'))) Redirect2URL($CFG['redirect']['dsabled_module_url']);
$mail->setPageBlockNames(array('msg_form_error', 'msg_form_success', 'msg_form_success_delete', 'form_mail', 'page_nav', 'form_confirm'));
$mail->setCSSAlternativeRowClasses($CFG['data_tbl']['css_alternative_row_classes']);
$mail->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$mail->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$mail->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$mail->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$mail->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$mail->setDBObject($db);
$mail->setCfgLangGlobal($CFG, $LANG);
$mail->setAllPageBlocksHide();
$mail->setFormField('folder', '');
$mail->setFormField('user_id', '');
$mail->setFormField('message_ids', array());
$mail->setFormField('action', '');
$mail->setFormField('orderby_field', '');
$mail->setFormField('orderby', '');
$condition = '';
$mail->numpg = $CFG['data_tbl']['numpg'];
$mail->setFormField('start', 0);
$mail->setFormField('numpg', $CFG['data_tbl']['numpg']);
$mail->setMinRecordSelectLimit($CFG['data_tbl']['min_record_select_limit']);
$mail->setMaxRecordSelectLimit($CFG['data_tbl']['max_record_select_limit']);
$mail->setNumPerPageListArr($CFG['data_tbl']['numperpage_list_arr']);
$mail->setTableNames(array());
$mail->setReturnColumns(array());
$mail->sanitizeFormInputs($_REQUEST);
if (!$mail->chkIsValidFolder())
{
?>
	  	<div id="selMsgAlert">
			<p><?php echo $LANG['mail_invalid_folder']; ?></p>
		</div>
		<?php
		die();
		Redirect2URL(getUrl($CFG['admin']['mail_urls']['inbox']['normal'], $CFG['admin']['mail_urls']['inbox']['htaccess']));
}
if ($mail->isFormGETed($_GET, 'msg'))
{
		$mail->setAllPageBlocksHide();
		$mail->setPageBlockShow('msg_form_success');
		$mail->setCommonErrorMsg($LANG['mail_success_message']);
}
if ($mail->isFormGETed($_GET, 'del'))
{
		$mail->setAllPageBlocksHide();
		$mail->setPageBlockShow('msg_form_success');
		$mail->setCommonErrorMsg($LANG['mail_success_delete_message']);
}
if ($mail->isFormPOSTed($_POST, 'confirm'))
{
		$mail->sanitizeFormInputs($_POST);
		$mail->chkIsNotEmpty('action', $LANG['mail_err_tip_compulsory']) or $mail->setCommonErrorMsg($LANG['mail_select_action']);
		$mail->chkIsNotEmpty('message_ids', $LANG['mail_err_tip_compulsory']) or $mail->setCommonErrorMsg($LANG['mail_select_message']);
		$mail->setAllPageBlocksHide();
		$mail->setPageBlockShow('msg_form_success');
		if ($mail->isValidFormInputs())
		{
				switch ($mail->getFormField('action'))
				{
						case 'mail_delete':
								$mail->deleteMessages($mail->getFormField('message_ids'));
								$mail->setCommonErrorMsg($LANG['mail_success_delete_message']);
								break;
				}
		}
		else
		{
				$mail->setPageBlockShow('msg_form_error');
		}
}
if ($mail->isFormPOSTed($_POST, 'cancel'))
{
		$mail->sanitizeFormInputs($_POST);
		$mail->setAllPageBlocksHide();
		$mail->setFormField('message_ids', array());
		$mail->setFormField('action', '');
}
$mail->buildMailQuery();
$mail->buildQuery();
$mail->executeQuery();
$mail->setPageBlockShow('form_mail');
if ($mail->isResultsFound())
{
		$mail->setPageBlockShow('page_nav');
}



?>
<script type="text/javascript" language="javascript">
	var block_arr= new Array('selMsgConfirm');
	var replace_url = '<?php echo getUrl($CFG['site']['url'] . 'login.php', $CFG['site']['url'] . 'login/', false); ?>';
	var please_select_action = '<?php echo $LANG['mail_select_action']; ?>';
	var confirm_message = '';
	function getAction()
		{
			var act_value = document.selFormMail.action.value;
			if(act_value)
				{
					switch (act_value)
						{
							case 'mail_delete':
								confirm_message = '<?php echo $LANG['mail_confirm_delete_message']; ?>';
								break;
						}
					$('confirmMessage').innerHTML = confirm_message;
					document.msgConfirmform.action.value = act_value;
					Confirmation('dAltMlti', 'selMsgConfirm', 'msgConfirmform', Array('message_ids'), Array(multiCheckValue), Array('value'), -25, -600, 'selFormMail');

				}
			else
				alert_manual(please_select_action, 'dAltMlti');
		}
</script>
<div id="selInboxMessage">
  <h2><span><?php echo $mail->mail_title; ?></span></h2>
    <div id="selLeftNavigation">
      <?php
if ($mail->isShowPageBlock('msg_form_error'))
{
?>
      <div id="selMsgError">
        <p><?php echo $LANG['msg_error_sorry']; ?> <?php echo $mail->getCommonErrorMsg(); ?></p>
      </div>
      <?php
}
if ($mail->isShowPageBlock('msg_form_success'))
{
?>
      <div id="selMsgSuccess">
        <p><?php echo $mail->getCommonErrorMsg(); ?></p>
      </div>
      <?php
}
if ($mail->isShowPageBlock('page_nav') && $CFG['admin']['navigation']['top'])
{
		$mail->populatePageLinks($mail->getFormField('start'), array('folder'));
}
if ($mail->isShowPageBlock('form_mail'))
{
?>
	<!-- Confirmation Div -->
	<div id="selMsgConfirm" class="clsPopupConfirmation" style="display:none;position:absolute;">
		<form name="msgConfirmform" id="msgConfirmform" method="post" action="<?php echo $_SERVER['REQUEST_URI']; ?>">
		<p id="confirmMessage"></p>
		<table summary="<?php echo $LANG['mail_confirm_tbl_summary']; ?>">
			<tr>
		      	<td>
				  	<input type="submit" class="clsSubmitButton" name="confirm" id="confirm" value="<?php echo $LANG['mail_confirm']; ?>" tabindex="<?php echo $mail->getTabIndex(); ?>" /> &nbsp;
		          	<input type="button" class="clsCancelButton" name="cancel" id="cancel" value="<?php echo $LANG['mail_cancel']; ?>" tabindex="<?php echo $mail->getTabIndex(); ?>" onClick="return hideAllBlocks('selFormMail');" />
		          	<input type="hidden" name="message_ids" />
					<input type="hidden" name="action" />
				</td>
	  		</tr>
		</table>
		<?php $mail->populateHiddenFormFields(array('start', 'orderby_field', 'orderby')); ?>
		</form>
	</div>
	<div id="selShowInbox">
		<form name="selFormMail" id="selFormMail" method="post" action="<?php echo $_SERVER['REQUEST_URI']; ?>">
       	<?php $mail->showMessages($LANG['no_records']); ?>
		<?php $mail->populateHiddenFormFields(array('start', 'orderby_field', 'orderby')); ?>
		</form>
    </div>
<?php
}
if ($mail->isShowPageBlock('page_nav') && $CFG['admin']['navigation']['bottom'])
{
		$mail->populatePageLinks($mail->getFormField('start'), array('folder'));
}
?>
    </div>
  </div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>
