<?php
// The format of this file is ---> $lang['message'] = 'text';
//
// You should also try to set a locale and a character encoding (plus direction). The encoding and direction
// will be sent to the template. The locale may or may not work, it's dependent on OS support and the syntax
// varies ... give it your best guess!
//

$lang['ENCODING'] = 'iso-8859-15';
$lang['DIRECTION'] = 'ltr';
$lang['LEFT'] = 'left';
$lang['RIGHT'] = 'right';
$lang['DATE_FORMAT'] =  '%Y-%b-%d'; // This should be changed to the default date format for your language, php date() format
$lang['DATE_TIME_FORMAT'] =  '%Y-%b-%d %I:%M:%S %P'; // This should be changed to the default date format for your language, php date() format
$lang['DISPLAY_DATE_FORMAT'] =  'Y M d';
$lang['DISPLAY_DATETIME_FORMAT'] = 'D M-d-Y H:i:s';
$lang['DB_ERROR'] = "Beg�ran kunde inte utf�ras p� grund av ett databasfel.<br />Prova igen om en liten stund.";
$lang['mail_text_encoding'] = '7bit';
$lang['mail_html_encoding'] = '7bit';
$lang['mail_html_charset'] = 'ISO-8859-1';
$lang['mail_text_charset'] = 'ISO-8859-1';
$lang['mail_head_charset'] = 'ISO-8859-1';

$lang['main_menu'] = 'Huvudmeny';
$lang['homepage'] = 'Hemsida';
$lang['rate_photos'] = 'Betygs�tt foton';
$lang['forum'] = 'Forum';
$lang['manageforum'] = 'Hantera forum';
$lang['chat'] = 'Chat';
$lang['managechat'] = 'Hantera chat';
$lang['member_login'] = 'Medlemsinloggning';
$lang['featured_members'] = 'VIP-medlemmar';
$lang['quick_search'] = 'Snabbs�k';
$lang['my_searches'] = 'Mina s�kningar';
$lang['affiliates'] = 'V�ra partners';
$lang['already_affiliate'] = 'Redan en partner?';
$lang['referals'] = 'H�nvisningar';
$lang['title_colon'] = 'Titel:';
$lang['comments_colon'] = 'Kommentarer:';
$lang['feedback'] = 'Feedback';
$lang['profiles'] = 'Profiler';
$lang['profile_s'] = 's Profil';
$lang['total_amt'] = 'Total summa';
$lang['banner_link'] = 'Annonsl�nk';
$lang['clicks'] = 'Klick';
$lang['finance_calc'] = 'Finansr�knare';
$lang['flash_chat_msg'] = 'FlashChat 4.1.0 och h�gre inneh�ller en integrationsklass f�r osDate. Var v�nlig k�p FlashChat fr�n <a href="http://www.tufat.com/chat.php" target="_blank">http://www.tufat.com/chat.php</a> och kopiera filerna till denna katalog. K�r d�refter installationsprogrammet f�r FlashChat och v�lj osDate som CMS-integrat�r.';
$lang['flash_chat_admin_msg'] = 'FlashChat 4.1.0 och h�gre inneh�ller en integrationsklass f�r osDate. Var v�nlig k�p FlashChat fr�n <a href="http://www.tufat.com/chat.php" target="_blank">http://www.tufat.com/chat.php</a> och kopiera filerna till denna katalog. K�r d�refter installationsprogrammet f�r FlashChat och v�lj osDate som CMS-integrat�r.';
$lang['affiliate_head_msg'] = 'Bli en partner';
$lang['affiliate_head_msg2'] = 'Vi erbjuder kommission f�r webbmasters som vidarebefordrar bes�kare till v�r webbplats.<br />';
$lang['affiliate_success_msg1'] = 'Ditt partner-id �r:';
$lang['affiliate_success_msg2'] = 'Du kan logga in till ditt partnerkonto nu. ';
$lang['affiliate_login_title'] = "Partnerinloggning";
$lang['password_changed_successfully'] = 'Ditt l�senord har uppdaterats.';
$lang['affiliate_registration_success'] = 'Partnerregistreringen lyckades';
$lang['login_now'] = 'Logga in h�r';
$lang['must_be_valid'] = 'M�ste vara giltig';
$lang['characters'] = 'bokst�ver';
$lang['email'] = 'E-postadress:';
$lang['age'] = '�lder';
$lang['years'] = '�r';
$lang['all_states'] = 'Alla stater';

//
// These terms are used at Signup page
//
$lang['welcome'] = 'V�lkommen';
$lang['admin_welcome'] = 'V�lkommen <br /> till <br />administrationspanelen f�r<br />SITENAME';
$lang['title'] = 'V�lkommen till SITENAME';
$lang['site_links'] = array(
	'home' => 'Hem',
	'signup_now' => 'Bli medlem',
	'chat' => 'Chat',
	'forum' => 'Forum',
	'login' => 'Logga in',
	'search' => 'S�k',
	'aboutus' => 'Om oss',
	'forgot' => 'Gl�mt l�senord/anv�ndarnamn?',
	'contactus' => 'Kontakta oss',
	'privacy' => 'Integritet',
	'terms_of_use' => 'Anv�ndarvillkor',
	'services' => 'Tj�nster',
	'faq' => 'FAQ',
	'articles' => 'Artiklar',
	'affliates' => 'Partners',
	'invite_a_friend' => 'Bjud in en v�n',
	'feedback' => 'Feedback'
);
$lang['success_stories'] = 'Lyckade historier';
$lang['members_login'] = 'Medlemslogin';
$lang['poll'] = 'Omr�stning';
$lang['news'] = 'Nyheter';
$lang['articles'] = 'Artiklar';
$lang['poll_result'] = 'Omr�stningsresultat';
$lang['view_poll_archive'] = 'Tidigare omr�stningar';
$lang['member_panel'] = 'Medlemspanel';
$lang['poll_errmsg1'] = 'Du har redan r�stat. F�rs�k igen n�gon annan dag.';
$lang['close'] = 'St�ng';
$lang['all_stories'] = 'Alla ber�ttelser';
$lang['all_news'] = 'Alla nyheter';
$lang['more'] = 'mer';
$lang['by'] = 'av';
$lang['dont_stay_alone'] = 'Var inte ensam,';
$lang['join_now_for_free'] = 'Bli medlem redan idag!!';
$lang['special_offer'] = 'Specialerbjudande!!';
$lang['welcome_to'] = 'V�lkommen till ';
$lang['welcome_to_site'] = 'V�lkommen till SITENAME';
$lang['offer_text'] = 'Se varf�r SITENAME �r den snabbast v�xande dejtingsajten p� webben. Skapa din SITENAME-profil och p�b�rja den sp�nnande resan till att hitta din dr�mdejt.';
$lang['newest_profiles'] = 'Nyaste profilerna';
$lang['edit_profile'] = '�ndra profil';
$lang['total_profiles'] = 'Antal profiler';
$lang['forgot'] = 'Gl�mt anv�ndarnamn/l�senord?';
$lang['hide'] = 'G�m';
$lang['show'] = 'Visa';
$lang['sex'] = 'K�n:';
$lang['sex_without_colon'] = 'K�n';
$lang['pageno'] = 'Sida ';
$lang['page'] = 'Sida';
$lang['previous'] = 'F�reg�ende';
$lang['next'] = 'N�sta';
$lang['time_col'] = 'Tid:';
$lang['save_search'] = 'Spara s�kning';
$lang['find_your_match'] = 'Hitta din tr�ff';
$lang['extended_search'] = 'Avancerad s�kning';
$lang['matches_found'] = 'F�ljande profiler matchar dina s�kkriterier.';
$lang['timezone'] = 'Tidszon:';
$lang['next_section'] = 'N�sta sektion';
$lang['sign_in'] = 'Medlemmar, var v�nliga logga in';
$lang['member_panel'] = 'Medlemspanel';
$lang['aff_panel'] = 'Partnerpanel';
$lang['login_title'] = 'Medlemslogin';
$lang['sign_out'] = 'Logga ut';
$lang['login_submit'] = 'Logga in';
$lang['change_password'] = 'Byt l�senord';
$lang['old_password'] = 'Gammalt l�senord:';
$lang['new_password'] = 'Nytt l�senord:';
$lang['confirm_password'] = 'Bekr�fta l�senord:';
$lang['password_change_msg'] = 'Ditt l�senord har uppdaterats.';
$lang['section_signup_title'] = 'Information om ny medlem';
$lang['signup'] = 'Registrering';
$lang['section_basic_title'] = 'Grundl�ggande Information';
$lang['section_appearance_title'] = 'Utseende';
$lang['section_interests_title'] = 'Intressen';
$lang['section_lifestyle_title'] = 'Livsstil';
$lang['signup_subtitle_login'] = 'Inloggningsdetaljer';
$lang['signup_subtitle_profile'] = 'Min profil';
$lang['signup_subtitle_address'] = 'Adress';
$lang['signup_subtitle_appearacnce'] = 'Utseende';
$lang['signup_subtitle_preference'] = 'S�kinst�llningar';
$lang['signup_username'] = 'Anv�ndarnamn:';
$lang['signup_password'] = 'L�senord:';
$lang['signup_confirm_password'] = 'Bekr�fta l�senord:';
$lang['signup_firstname'] = 'F�rnamn:';
$lang['signup_lastname'] = 'Efternamn:';
$lang['signup_email'] = 'E-postadress:';
$lang['section_mypicture'] = 'Mina Bilder';
$lang['upload'] = 'Ladda Upp';
$lang['upload_pictures'] = 'Hantera bilder';
$lang['upload_format_msgs'] = 'Enbart .jpg, .gif, .bmp och .png �r till�tna filtyper.';
$lang['thumbnail'] = 'Miniatyr';
$lang['picture'] = 'Bilder';
$lang['signup_picture'] = 'Min bild';
$lang['signup_picture2'] = 'Min bild 2:';
$lang['signup_picture3'] = 'Min bild 3:';
$lang['signup_picture4'] = 'Min bild 4:';
$lang['signup_picture5'] = 'Min bild 5:';
$lang['signup_gender'] = 'Jag �r en';
$lang['signup_pref_age_range'] = 'F�redragen �ldersgrupp';
$lang['signup_year_old'] = '�r gammal';
$lang['signup_birthday'] = 'F�delsedag:';
$lang['signup_country'] = 'Land:';
$lang['signup_state_province'] = 'Stat / Provins:';
$lang['signup_zip'] = 'Postnummer:';
$lang['signup_city'] = 'Stad:';
$lang['signup_address1'] = 'Adress, rad 1:';
$lang['signup_address2'] = 'Adress, rad 2:';
$lang['signup_height'] = 'L�ngd: ';
$lang['signup_feet'] = 'fot';
$lang['signup_meter_inches'] = 'tum [ meter om utanf�r USA ]';
$lang['signup_weight'] = 'Vikt:';
$lang['signup_pounds'] = 'pound [ kg om utanf�r USA ]';
$lang['signup_where_should_we_look'] = 'Var ska vi leta?';
$lang['signup_view_online'] = "Till�t andra medlemmar att se n�r jag �r online?";
$lang['signup_gender_values'] = array(
	'M' => 'Man',
	'F' => 'Kvinna',
	'C' => 'Par',
	'G' => 'Grupp'
);
$lang['signup_gender_look'] = array(
	'M' => 'Man',
	'F' => 'Kvinna',
	'C' => 'Par',
	'G' => 'Grupp',
	'B' => 'Man eller kvinna',
	'A' => 'Vilket som'
);
$lang['seeking'] = 's�ker en';
$lang['looking_for_a'] = 's�ker efter en';
$lang['looking_for'] = 's�ker efter';
$lang['of'] = ' av ';
$lang['to'] = ' till ';
$lang['from'] = ' fr�n ';
$lang['for'] = ' f�r ';
$lang['yes'] = 'Ja';
$lang['no'] = 'Nej';
$lang['cancel'] = 'Avbryt';
$lang['change'] = '�ndra';
$lang['reset'] = '�terst�ll';

//Commonly used words
$lang['required_info_indication'] = 'obligatoriskt f�lt';
$lang['required_info_indicator'] = '* ';
$lang['required_info_indicator_color'] = 'Red';
$lang['click_here'] = 'Klicka h�r';
$lang['datetime_dayval']['Sun'] = 'S�n';
$lang['datetime_dayval']['Mon'] = 'M�n';
$lang['datetime_dayval']['Tue'] = 'Tis';
$lang['datetime_dayval']['Wed'] = 'Ons';
$lang['datetime_dayval']['Thu'] = 'Tor';
$lang['datetime_dayval']['Fri'] = 'Fre';
$lang['datetime_dayval']['Sat'] = 'L�r';
$lang['error_msg_color'] = 'Red';
$lang['success_message'] = 'Din information har sparats.<br />Du kommer automatiskt f�rflyttas till n�sta sektion om 5 sekunder. Om du inte f�rflyttas automatiskt, klicka p� l�nken nedan.';
$lang['sendletter_success'] = 'Brevet har skickats.';

/*****************Admin Section Labels********************/

//Commonly used labels
$lang['admin_login_title'] = 'SITENAME' . ' Administrationspanel';
$lang['home_title'] = 'SITENAME' . ' Hem';
$lang['admin_login_msg'] = 'Admin Login';
$lang['admin_title_msg'] = 'SITENAME' . ' Admin-panel';
$lang['admin_panel'] = 'Admin-panel';
$lang['back'] = 'Tillbaka';
$lang['insert_msg'] = 'Infoga ny ';
$lang['question_mark'] = '?';
$lang['id'] = 'Id:';
$lang['name'] = 'Namn: ';
$lang['name_col'] = 'Namn';
$lang['enabled'] = 'Aktiverad';
$lang['action'] = 'Handling';
$lang['edit'] = '�ndra';
$lang['delete'] = 'Ta bort';
$lang['section'] = 'Sektion:';
$lang['insert_section'] = 'L�gg till sektion';
$lang['modify_section'] = '�ndra sektion';
$lang['modify_sections'] = '�ndra sektioner';
$lang['delete_section'] = 'Ta bort sektion';
$lang['delete_sections'] = 'Ta bort sektioner';
$lang['enable_selected'] = 'Aktivera';
$lang['disable_selected'] = 'Inaktivera';
$lang['change_selected'] = '�ndra';
$lang['delete_selected'] = 'Ta bort';
$lang['no_select_msg'] = "Du gjorde inget val. Tryck p� webbl�sarens tillbaka-knapp och v�lj ett eller fler alternativ.";
$lang['delete_confirm_msg'] = '�r du s�ker p� att du vill ta bort den h�r sektionen?';
$lang['delete_group_confirm_msg'] = '�r du s�ker p� att du vill ta bort dessa sektioner? Du kan inte �ngra denna �tg�rd.';
$lang['enabled_values'] = array(
	'Y' => 'Ja',
	'N' => 'Nej'
);
$lang['display_control_type'] = array(
	'checkbox' => 'Kryssruta',
	'radio' => 'Valknapp',
	'select' => 'Rullningslista',
	'textarea' => 'Skriv text'
);
$lang['admin_error_color'] = 'Red';
$lang['col_head_srno'] = '#';
$lang['col_head_id'] = 'Id';
$lang['col_head_question'] = 'Fr�ga';
$lang['col_head_enabled'] = 'Aktiv';
$lang['col_head_name'] = 'Namn';
$lang['col_head_username'] = 'Anv�ndarnamn';
$lang['col_head_firstname'] = 'F�rnamn';
$lang['col_head_lastname'] = 'Efternamn';
$lang['col_head_fullname'] = 'Fullst�ndigt namn';
$lang['col_head_status'] = 'Status';
$lang['col_head_gender'] = 'K�n';
$lang['col_head_email'] = 'E-postadress';
$lang['col_head_country'] = 'Land';
$lang['col_head_city'] = 'Stad';
$lang['col_head_zip'] = 'Postnummer';
$lang['col_head_register_at'] = 'Registrerade sig';
$lang['section_title'] = 'Hantera sektioner';
$lang['total_sections'] = 'Totalt antal sektioner:';
$lang['profile_title'] = 'Hantera profiler';
$lang['total_profiles_found'] = 'Antal profiler funna:';
$lang['modify_profile'] = '�ndra profil';
$lang['profile_signup_title'] = 'Inskrivningsinformation';
$lang['profile_basic_title'] = 'Grundl�ggande information';
$lang['profile_appearance_title'] = 'Utseende';
$lang['profile_interests_title'] = 'Intressen';
$lang['profile_lifestyle_title'] = 'Livsstil';
$lang['profile_subtitle_login'] = 'Inloggningsdetaljer';
$lang['profile_subtitle_profile'] = 'Profil';
$lang['profile_subtitle_address'] = 'Adress';
$lang['profile_subtitle_appearacnce'] = 'Utseende';
$lang['profile_subtitle_preference'] = 'Inst�llningar';
$lang['profile_delete_confirm_msg'] = '�r du s�ker p� att du vill ta bort profilen?';
$lang['delete_profile'] = 'Ta bort profil';
$lang['profile_username'] = 'Anv�ndarnamn:';
$lang['profile_firstname'] = 'F�rnamn:';
$lang['profile_lastname'] = 'Efternamn:';
$lang['profile_email'] = 'E-postadress:';
$lang['profile_gender'] = 'K�n';
$lang['profile_birthday'] = 'F�delsedag:';
$lang['profile_country'] = 'Land:';
$lang['profile_state_province'] = 'L�n/Landskap:';
$lang['profile_zip'] = 'Postnummer:';
$lang['profile_city'] = 'Postadress';
$lang['profile_address1'] = 'Adress, rad 1:';
$lang['profile_address2'] = 'Adress, rad 2:';
$lang['find'] = 'Hitta';
$lang['search'] = 'S�k';
$lang['AND'] = 'och';
$lang['OR'] = 'ELLER';
$lang['order_by'] = 'Sortera p�: ';
$lang['sort_by'] = 'Sortera p�';
$lang['sort_types'] = array(
	'asc' => '�kande',
	'desc' => 'Minskande'
);
$lang['search_results'] = 'S�kresultat';
$lang['no_record_found'] = 'Inga tr�ffar.';
$lang['search_options'] = 'S�kinst�llningar';
$lang['search_simple'] = 'Enkel s�kning';
$lang['search_advance'] = 'S�k';
$lang['search_advance_results'] = 'S�kresultat';
$lang['search_country'] = 'S�k via land';
$lang['search_states'] = 'S�k via stat';
$lang['search_zip'] = 'S�k via postnummer';
$lang['search_city'] = 'S�k via stad';
$lang['search_wildcard_msg'] = 'Du kan anv�nda * i alla f�lt.';
$lang['search_location'] = '<b>S�k p� plats:</b>';
$lang['select_state'] = 'Stat:';
$lang['enter_city'] = 'Stad:';
$lang['enter_zip'] = 'Postnummer:';
$lang['enter_username'] = 'Anv�ndarnamn:';
$lang['results_per_page'] = 'Tr�ffar per sida';
$lang['search_results_per_page'] = array( 2 => 2, 5 => 5 , 10 => 10, 20 => 20, 50 => 50, 100 => 100 );
$lang['order'] = 'Sortera';
$lang['up'] = 'Upp';
$lang['down'] = 'Ner';
$lang['question'] = 'Fr�ga:';
$lang['maxlength'] = 'Maxl�ngd:';
$lang['description'] = 'Beskrivning:';
$lang['mandatory'] = 'Obligatoriskt:';
$lang['guideline'] = 'Guide:';
$lang['control_type'] = 'Kontrolltyp:';
$lang['include_extsearch'] = 'Inkludera ut�kad s�kning:';
$lang['head_extsearch'] = 'Ut�kad s�kning:';
$lang['delete_question'] = 'Ta bort fr�ga';
$lang['modify_question'] = '�ndra fr�ga';
$lang['questions_title'] = 'Hantera fr�gor';
$lang['total_options'] = 'Antal val:';
$lang['insert_question'] = 'L�gg till fr�ga';
$lang['total_questions'] = 'Antal fr�gor';
$lang['delete_questions'] = 'Ta bort fr�gor';
$lang['delete_group_questions_confirm_msg'] = '�r du s�ker p� att du vill ta bort fr�gorna? Denna �tg�rd kan inte �ngras.';
$lang['option'] = 'Val';
$lang['answer'] = 'Svar';
$lang['options_title'] = 'Fr�geinst�llningar';
$lang['col_head_answer'] = 'Svar';
$lang['with_selected'] = 'Med valda';
$lang['ranging'] = 'Utstr�ckning';

// Instant messenger
$lang['instant_messenger'] = 'Direktmeddelande';
$lang['instant_message'] = 'Direktmeddelande';
$lang['im_from'] = 'Fr�n:';
$lang['im_message'] = 'Meddelande:';
$lang['im_reply'] = 'Svara';
$lang['close_window'] = 'St�ng f�nster';

// my matches
$lang['my_matches'] = 'Mina tr�ffar';
$lang['i_am_a'] = 'Jag �r en';
$lang['Between'] = 'mellan';
$lang['who_is_from'] = 'som �r fr�n';
$lang['showing'] = 'Visar';
$lang['your_search_preferences'] = 'Dina aktuella s�kinst�llningar:';
$lang['to_edit_search_preferences'] = 'f�r att redigera s�kinst�llningar';
$lang['unapproved_user'] = 'Profiler att godk�nna';
$lang['gbl_settings'] = 'Globala inst�llningar';
$lang['configurations'] = 'Inst�llningar';
$lang['col_head_variable'] = 'Variabel';
$lang['col_head_value'] = 'V�rde';
$lang['affiliate_title'] = 'Hantera partners';
$lang['col_head_counter'] = 'R�knare';
$lang['col_head_status'] = 'Status';
$lang['tell_later'] = 'Jag ber�ttar sen.';
$lang['view_profile'] = 'Visa profil';
$lang['view_profile_errmsg1']  = 'Du har fortfarande inte skrivit n�got om dig sj�lv.<br />Var v�nlig komplettera din profil f�rst.<br />';
$lang['view_profile_errmsg2'] = '<br />Klicka h�r f�r att �ndra inst�llningar.';
$lang['view_profile_errmsg3'] = 'Anv�ndaren har fortfarande inga profiluppgifter.';
$lang['view_profile_restricted'] = 'Detta �r en begr�nsad profil som du inte har r�tt att titta p�.';
$lang['profile_notset'] = 'Ingen profil funnen f�r anv�ndaren.';
$lang['send_mail'] = 'Skicka meddelande';
$lang['mail_messages'] = 'Meddelanden';
$lang['col_head_subject'] = '�mne';
$lang['col_head_sendtime'] = 'Datum';
$lang['inbox'] = 'Inkorg';
$lang['sent'] = 'Skickat';
$lang['trashcan'] = 'Papperskorg';
$lang['reply'] = 'Svara';
$lang['read'] = 'L�st';
$lang['unread'] = 'Ol�st';
$lang['restore'] = '�terst�ll';
$lang['subject'] = '�mne';
$lang['subject_colon'] = '�mne:';
$lang['message'] = 'Meddelande';
$lang['send'] = 'Skicka';
$lang['send_letter'] = 'Skicka brev';
$lang['image_browser'] = 'Bildbl�ddrare';
$lang['upload_image'] = 'Ladda upp bild';
$lang['delete_image'] = 'Ta bort bild';
$lang['show_image'] = 'Visa bild';
$lang['send_invite'] = 'Skicka inbjudan';
$lang['letter_title'] = 'Nytt brev';
$lang['from_email'] = 'Fr�n e-postadress:';
$lang['from_name'] = 'Fr�n namn:';
$lang['send_to'] = 'Skicka';
$lang['email_subject'] = '�mne:';
$lang['save_as'] = 'Spara som';
$lang['no_message'] = 'Inga nya meddelanden.';
$lang['descrip'] = 'Beskrivning';

//forgot password words
$lang['forgotpass_msg1'] = "Inloggningsuppgifter";
$lang['forgotpass_msg2'] = "Fyll i den e-postadress som du anv�nde d� du skapade din profil. Ett nytt l�senord kommer att skickas till dig. Du rekommenderas att byta l�senord vid n�sta inloggning.";
$lang['retreieve_info'] = 'Skicka';
$lang['forgotpass'] = 'Gl�mt l�senord';

//Tell a friend
$lang['tellafriend'] = 'Bjud in en v�n';
$lang['taf_msg1'] = 'Bjud in en v�n till SITENAME';
$lang['taf_yourname'] = 'Ditt namn:';
$lang['taf_youremail'] = 'Din e-postadress:';
$lang['taf_friendemail'] = 'Din v�ns e-postadress:';

//Auto-mail
$lang['confirm_your_profile'] = 'Bekr�fta registreringen';
$lang['letter_not_avail'] = 'Brevmall ej tillg�nglig';
$lang['confirm_letter_sent'] = 'Ett bekr�ftelsemeddelande har skickats till din e-postadress. �ppna det och f�lj instruktionerna.';
$lang['letter_not_sent'] = 'Det gick inte skicka mail.';
$lang['or'] = 'Eller';
$lang['enter_confirm_code'] = 'Skriv din bekr�ftelsekod f�r att slutf�ra registreringen.';

// Affiliate auto-mail
$lang['aff_email_subject'] = 'Bekr�fta ditt partnerkonto';
$lang['aff_email_body'] = 'Tack f�r att du har skapat ett partnerkonto hos SITENAME. Skriv in denna URL i din webbl�sare f�r att slutf�ra registreringen:<br /><br />#ConfirmationLink#';

//Page management
$lang['manage_pages'] = 'Hantera sidor';
$lang['pagetitle'] = 'Titel:';
$lang['pagetext'] = 'Text:';
$lang['pagekey'] = 'Nyckel:';
$lang['addpage'] = 'L�gg till sida';
$lang['page'] = 'Sida:';
$lang['addnew'] = 'L�gg till ny';
$lang['modpage'] = '�ndra sida';
$lang['pagekey_help'] = 'http://www.yourdomain.com/index.php?page=YOUR_KEY';
$lang['y_o'] = 'y/o';
$lang['lastlogged'] = 'Senast inloggad: ';
$lang['aff_stats'] = 'Partnerstatistik';
$lang['total_referrals'] = 'Antal h�nvisningar (referrer)';
$lang['regis_referals'] = 'Registrerade h�nvisningar';
$lang['globalconfigurations'] = 'Globala inst�llningar';
$lang['send_message_to'] = 'Skicka meddelande till';
$lang['writing_message'] = 'Skriver meddelande till ';
$lang['search_at'] = 'S�k p�';

//Rating module
$lang['rate_profile'] = 'Betygs�tt profil';
$lang['worst'] = 'S�mst';
$lang['excellent'] = 'Utm�rkt';
$lang['rating'] = 'Betyg';
$lang['submitrating'] = 'Betygs�tt';

//Payment Modules
$lang['mship_changed'] = 'Medlemsniv�n har �ndrats';
$lang['mship_changed_successfull'] = 'Din medlemsniv� har �ndrats till Gratis';
$lang['no_payment'] = 'Ingen betalning kr�vs (gratis)';
$lang['payment_modules'] = 'Betalningsmoduler';
$lang['payment_methods'] = 'Betalningsmetoder';
$lang['business'] = 'Bransch:';
$lang['siteid'] = 'Sajt-ID:';
$lang['undefined_quantity'] = 'Odefinierad kvantitet:';
$lang['no_shipping'] = 'Ingen f�rs�ndelse:';
$lang['no_note'] = 'Ingen anteckning:';
$lang['on_off_values'] = array( 1 => 'Ja', 0 => 'Nej' );
$lang['edit_payment_modules'] = '�ndra betalmodul';
$lang['trans_key'] = 'Transaktionsnyckel:';
$lang['trans_mode'] = 'Transaktionsl�ge:';
$lang['trans_method'] = 'Transaktionsmetod:';
$lang['username'] = 'Anv�ndarnamn:';
$lang['username_without_colon'] = 'Anv�ndarnamn';
$lang['country'] = 'Land';
$lang['country_colon'] = 'Land:';
$lang['state'] = 'Stat';
$lang['city'] = 'Stad';
$lang['location_col'] = 'Plats:';
$lang['location_no_col'] = 'Plats';
$lang['zip_code'] = 'Postnummer';
$lang['attached_files'] = 'Bifogade filer:';
$lang['cc_owner'] = 'Kreditkorts�gare:';
$lang['cc_number'] = 'Kreditkortsnummer:';
$lang['cc_type'] = 'Kreditkortstyp:';
$lang['cc_exp_date'] = 'Utg�ngsdatum:';
$lang['cc_cvv_number'] = 'Kontrollkod:';
$lang['cvv_help'] = '(finns p� baksidan av kortet)';
$lang['continue'] = 'Forts�tt';
$lang['trans_method_vals'] = array(
	'CC' => 'Kreditkort',
	'ECHECK' => 'Elektronisk check'
);

$lang['trans_mode_vals'] = array(
	'AUTH_CAPTURE' => 'AUTH_CAPTURE',
	'AUTH_ONLY' => 'AUTH_ONLY',
	'CAPTURE_ONLY' => 'CAPTURE_ONLY',
	'CREDIT' => 'CREDIT',
	'VOID' => 'VOID',
	'PRIOR_AUTH_CAPTURE' => 'PRIOR_AUTH_CAPTURE'
);
$lang['cc_unknown'] = 'Kreditkortsf�retag ok�nt. F�rs�k igen med ett godk�nt kort.';
$lang['cc_invalid_date'] = 'Kreditkortsdatum �r felaktigt. F�rs�k igen med ett godk�nt kort.';
$lang['cc_invalid_number'] = 'Kreditkortsnummer �r felaktigt. F�rs�k igen med ett godk�nt kort.';
$lang['amount'] = 'Summa: ';
$lang['confirmation'] = 'Bekr�ftelse';
$lang['confirm'] = 'Bekr�fta';
$lang['upgrade_membership'] = 'Uppgradera medlemskap';
$lang['changeto'] = 'Byt till';
$lang['current_mship_level'] = 'Aktuell medlemsniv�:';
$lang['membership_status'] = 'Medlemskapsstatus';
$lang['you_currently'] = 'Du �r f�r n�rvarande en ';
$lang['info_confirm'] = '�r denna information korrekt?';
$lang['change_mship_to'] = 'Din medlemsniv� har �ndrats till ';

//Membership
$lang['permitmsg_1'] = 'Din medlemsniv� innefattar inte';
$lang['permitmsg_2'] = 'Du m�ste uppgradera din niv� f�r att anv�nda ';
$lang['permitmsg_3'] = 'Medlemsniv�j�mf�relse';
$lang['permitmsg_4'] = 'D�lj medlemsniv�j�mf�relse';
$lang['membership_packages'] = 'Medlemskapspaket';
$lang['membership_packages_compare'] = 'Medlemskapsj�mf�relse';
$lang['modify'] = 'Spara �ndringar';
$lang['manage_membership'] = 'Hantera medlemskap';
$lang['privileges_msg'] = 'Privilegier';
$lang['price'] = 'Pris: ';
$lang['currency'] = 'Valuta: ';
$lang['choose_membership'] = 'V�lj en medlemsniv�:';
$lang['add_membership'] = 'L�gg till en medlemsniv�';
$lang['membership_types'] = 'Medlemsniv�er';
$lang['member'] = 'medlem';
$lang['select_letter'] = 'V�lj brev:';
$lang['body'] = 'Kropp:';
$lang['module'] = 'Modul';
$lang['uninstall'] = 'Avinstallera';
$lang['install'] = 'Installera';
$lang['modify_option'] = '�ndra inst�llning';
$lang['only_jpg'] = 'Endast JPG, GIF, PNG och BMP-filer �r till�tna.';
$lang['upload_unsuccessful'] = 'Bild kunde ej laddas upp.';
$lang['upload_successful'] = 'Bilderna har laddats upp.';
$lang['between1'] = 'Mellan';
$lang['and'] = 'och';
$lang['profile_details'] = 'Profildetaljer';
$lang['personal_details'] = 'Personliga Uppgifter';

//Banner Management
$lang['manage_banners'] = 'Hantera annonser';
$lang['add_banners'] = 'L�gg till en annons';
$lang['edit_banners'] = 'Redigera annons';
$lang['size'] = 'Storlek';
$lang['size_px'] = 'Storlek (pixlar)';
$lang['banner_linkurl'] = 'Annons-/L�nk-URL';
$lang['banner_sizes'] = array(
	'468X60' => '468 x 60',
	'100X500'=>'100 x 500',
	'120X120'=>'120 x 120'
);

$lang['banner_sizes_name'] = array( 'horisontell', 'vertikal', 'fyrkantig' );
$lang['startdate'] = 'Startdatum:';
$lang['enddate'] = 'Slutdatum:';
$lang['tooltip'] = 'Tooltip:';
$lang['linkurl'] = 'L�nk-URL:';
$lang['banner'] = 'Annons:';
$lang['total_banner'] = 'Antal annonser:';
$lang['online_users'] = 'Medlemmar online: ';
$lang['site_statistics'] = 'Statistik';
$lang['pending_profiles'] = 'V�ntande profiler';
$lang['active_profiles'] = 'Aktiva profiler';
$lang['online_profiles'] = 'Profiler inloggade';
$lang['pending_aff'] = 'V�ntande partners';
$lang['total_affiliates'] = 'Antal partners';
$lang['active_aff'] = 'Aktiva partners';
$lang['no_rating'] = 'Ej betygsatt';

//SEO Words
$lang['seo'] = 'S�kmotoroptimering';
$lang['seo_head'] = 'S�kmotoroptimering';
$lang['sef_msg'] = 'S�kv�nliga URLer';
$lang['seo_enable'] = 'Aktivera URL-f�rflyttning med mod_rewrite:';
$lang['yes_msg'] = 'URL-f�rflyttning �r en funktion som endast finns tillg�nglig tillsammans med Apache webbserver. Se till att din server har st�d f�r funktionen, och gl�m inte att d�pa om .htaccess.txt till .htaccess.';
$lang['keywords'] = 'Nyckelord:';
$lang['page_tags_msg'] = 'Sidtitel & Metataggar';
$lang['max_255'] = 'Maximalt 255 tecken';

//News / Story / Article Manangement
$lang['manage_news'] = 'Hantera nyheter';
$lang['manage_story'] = 'Hantera ber�ttelser';
$lang['manage_article'] = 'Hantera artiklar';
$lang['news_header'] = 'Rubrik';
$lang['total_news'] = 'Antal nyheter:';
$lang['total_articles'] = 'Antal artiklar:';
$lang['total_stories'] = 'Antal ber�ttelser:';
$lang['article_title'] = 'Titel';
$lang['story_sender'] = 'Avs�ndare';
$lang['story_sender_msg'] = 'Profil-ID [siffra]';
$lang['modify_article'] = '�ndra artikel';
$lang['modify_news'] = '�ndra nyhet';
$lang['modify_story'] = '�ndra ber�ttelse';
$lang['insert_article'] = 'L�gg till artikel';
$lang['insert_story'] = 'L�gg till ber�ttelse';
$lang['insert_news'] = 'L�gg till nyhet';
$lang['dat'] = 'Datum:';

//Poll Words
$lang['manage_polls'] = 'Hantera omr�stningar';
$lang['modify_poll'] = '�ndra omr�stning';
$lang['total_polls'] = 'Antal omr�stningar';
$lang['poll'] = 'Omr�stning';
$lang['add_polls'] = 'L�gg till omr�stning';
$lang['add_options'] = 'L�gg till alternativ';
$lang['active'] = 'Aktiv';
$lang['activate'] = 'Aktivera';
$lang['option'] = 'Alternativ';
$lang['modify_options'] = '�ndra alternativ';
$lang['add_option_now'] = 'L�gg till alternativ nu.';
$lang['poll_options'] = 'Omr�stningsalternativ';
$lang['votes'] = 'R�st(er)';

//Filter Records
$lang['filter_options'] = array(
	'id' => 'Id',
	'username' => 'Anv�ndarnamn',
	'city' => 'Stad',
	'zip' => 'Postnummer',
	'status' => 'Status',
	'email' => 'E-postadress',
	'gender' => 'K�n'
);

$lang['loginagain'] = 'Logga ut och in igen f�r att aktivera din nya medlemsniv�';
$lang['online_users_txt'] = 'Medlemmar online';

$lang['first'] = 'F�rsta';
$lang['last'] = 'Sista';
$lang['filter_records'] = 'Filtrera resultat';
$lang['search_at'] = 'S�k p�';
$lang['criteria'] = 'S�kfras';

//Admin Management
$lang['manage_admins'] = 'Hantera administrat�rer';
$lang['total_admins'] = 'Antal administrat�rer';
$lang['add_admin'] = 'L�gg till administrat�r';
$lang['modify_admin'] = '�ndra administrat�r';
$lang['fullname'] = 'Namn';
$lang['please_be_sure'] = 'Kom ih�g att';
$lang['change_your_admin_pwd'] = '�ndra ditt administrat�rsl�senord.';
$lang['superuser'] = 'Superanv�ndare';
$lang['no_admin_user_msg1'] = 'Det finns inga icke-superanv�ndare. Skapa en f�rst.';
$lang['no_admin_user_msg2'] = 'F�r att skapa en ny administrat�r nu';
$lang['access_denied'] = '�tkomst nekad';
$lang['not_authorize'] = 'Du saknar beh�righet till denna sida. Kontakta din superadministrat�r.';

//Admin Permissions Management
$lang['admin_permissions'] = 'Hantera r�ttigheter';
$lang['manage_admin_permissions'] = 'Hantera r�ttigheter';
$lang['admin_users'] = 'Administrat�rsanv�ndare';
$lang['permissions'] = 'Moduler';
$lang['superuser_noteditable'] = 'OBS: Superanv�ndare kan ej �ndras.';
$lang['all'] = 'Alla';
$lang['selected'] = 'Valda';
$lang['selected_users'] = 'Valda anv�ndare';
$lang['separate_users_by_coma'] = 'Skriv in anv�ndarnamn separerade med kommatecken.';
$lang['admin_rights'] = array(
		'site_stats' 			=> 'Statistik',
		'profie_approval'		=> 'Profiler f�r bekr�ftelse',
		'profile_mgt' 			=> 'Hantera profiler',
		'section_mgt' 			=> 'Hantera sektioner',
		'affiliate_mgt' 		=> 'Hantera partners',
		'affiliate_stats'		=> 'Partnerstatistik',
		'news_mgt' 			=> 'Hantera nyheter',
		'article_mgt' 			=> 'Hantera artiklar',
		'story_mgt'			=> 'Hantera ber�ttelser',
		'poll_mgt'		 	=> 'Hantera omr�stningar',
		'search' 			=> 'S�k',
		'ext_search'			=> 'Avancerad s�k',
		'send_letter' 			=> 'Skicka brev',
		'pages_mgt' 			=> 'Hantera sidor',
		'chat' 				=> 'Chat',
		'chat_mgt' 			=> 'Hantera chat',
		'forum_mgt' 			=> 'Hantera forum',
		'mship_mgt' 			=> 'Hantera medlemmar',
		'payment_mgt' 			=> 'Betalningsmoduler',
		'banner_mgt' 			=> 'Hantera annonser',
		'seo_mgt' 			=> 'S�kmotoroptimering',
		'admin_mgt' 			=> 'Hantera administrat�rer',
		'admin_permit_mgt'		=> 'Hantera r�ttigheter',
		'global_mgt' 			=> 'Globala inst�llningar',
		'change_pwd'			=> 'Byt l�senord',
		'cntry_mgt'			=> 'Hantera l�nder/st�der',
		'snaps_require_approval'	=> 'Godk�nn bilder',
		'featured_profiles_mgt'		=> 'VIP-profiler',
		'calendar_mgt'			=> 'Kalendrar',
		'event_mgt'			=> 'Godk�nna h�ndelser',
		'import_mgt'			=> 'Importera',

		/* Added in 2.0 */
      	'plugin_mgt' 				=> 'Hantera instick',
		'blog_mgt'			=> 'Hantera bloggar',
		'profile_ratings'		=> 'Hantera profilbetyg',
);

$lang['cntry_mgt']	= 'Hantera l�nder/st�der/stater';
$lang['register_now'] = 'Registrera dig nu f�r att g� med i v�r community!';
$lang['addtobuddylist'] = 'L�gg till i kompislistan';
$lang['addtobanlist'] = 'L�gg till i ignoreralistan';
$lang['addtohotlist'] = 'L�gg till i intresselistan';
$lang['buddylisthdr'] = 'Kompislista';
$lang['banlisthdr'] = 'Ignoreralista';
$lang['hotlisthdr'] = 'Intresselista';
$lang['username_hdr'] = 'Anv�ndarnamn';
$lang['fullname_hdr'] = 'Namn';
$lang['register'] = 'Registrera dig';
$lang['featured_profiles'] = 'VIP-profiler';
$lang['bigger_pic_size'] = 'Bildstorleken �verskrider den till�tna storleken ('.$config['upload_snap_maxsize'].' KB).';
$lang['snaps_require_approval'] = 'Godk�nn bilder';
$lang['events_require_approval'] = 'Godk�nn h�ndelser';
$lang['upload_picture_caption'] = 'Huvudbild ';
$lang['upload_thumbnail_caption'] = 'Miniatyrbild ';
$lang['Approve'] = 'Godk�nn';
$lang['Remove'] = 'Ta bort';
$lang['userdetails'] = 'Anv�ndarinformation';
$lang['pict'] = 'Bild';
$lang['tnail'] = 'Miniatyrbild';
$lang['reqact'] = '�nskad h�ndelse';
$lang['newmemberlist'] = 'Nyaste medlemmarna';
$lang['yearsold'] = '�r gammal';
$lang['Male'] = 'Man';
$lang['Female'] = 'Kvinna';
$lang['showfulllist'] = 'Visa hela listna';
$lang['featuredprofiles'] = 'VIP-profiler';
$lang['featured_profiles_hdr'] = 'Profiler f�r VIP-medlemmar';
$lang['nonfeatured_profiles_hdr'] = 'Normala anv�ndare';
$lang['level_hdr'] = 'Niv�';
$lang['date_from'] = 'Startdatum';
$lang['date_upto'] = 'Datum till';
$lang['must_show'] = 'M�ste visas';
$lang['reqd_exposures'] = 'Kr�vd exponering';
$lang['total_exposures'] = 'Antal exponeringar';
$lang['add_featured'] = 'L�gg till profil i VIP-profiler';
$lang['mod_featured'] = '�ndra profil i VIP-profiler';
$lang['member_since'] = 'Medlem sedan';
$lang['invalid_username'] = 'Felaktigt anv�ndarnamn';
$lang['weekcnt'] = 'Nya medlemmar senaste veckan:';
$lang['totalgents'] = 'Antal manliga medlemmar:';
$lang['totalfemales'] = 'Antal kvinnliga medlemmar:';
$lang['weeksnaps'] = 'Bilder senaste veckan:';
$lang['since_last_login'] = 'sedan senaste inloggning';
$lang['sincelastlogin_hdr'] ='Sedan senaste inloggning';
$lang['newmessages'] = 'Nya meddelanden:';
$lang['profileviewed'] = 'Antal bes�k till din profil:';
$lang['winks_received'] = 'Antal fl�rtar mottagna:';
$lang['send_wink'] = 'Skicka en fl�rt';
$lang['listofviews'] = 'Lista medlemmar som tittat p� din profil';
$lang['listofwinks'] = 'Lista medlemmar som skickat en fl�rt';
$lang['winkslist'] = 'Fl�rtlista';
$lang['viewslist'] = 'Bes�kslista';
$lang['suggest_poll'] = 'F�resl� en omr�stning';
$lang['savepoll'] = 'Skickar omr�stning';
$lang['moreoptions'] = 'Fler val';
$lang['minimum_options'] = 'Minst tv� valalternativ kr�vs';
$lang['pollsuggested'] = 'Tack! Ditt omr�stningsf�rslag har skickats till sajt�garna.';
$lang['suggested_by'] = 'F�reslaget av:';
$lang['any_where'] = 'Var som helst';
$lang['memberpanel'] = "Medlemmens hemsida";
$lang['feedback_thanks'] = 'Tack f�r din feedback. Ditt meddelande har vidarebefordrats.';
$lang['cancel_hdr'] = 'Avsluta medlemskap';
$lang['cancel_txt01'] = 'Du har beg�rt att avsluta ditt medlemskap p� <b>SITENAME</b>.<br /><br />�r du s�ker? ';
$lang['cancel_opt01'] = 'Ja, jag �r s�ker';
$lang['cancel_opt02'] = 'Nej, jag vill inte avsluta mitt medlemskap';
$lang['cancel_domsg'] = 'Tack f�r att du anv�nt SITENAME.<br /><br />Vi beklagar att du inte l�ngre vill vara med oss, men vi hoppas att du �terkommer i framtiden.';
$lang['cancel_nomsg'] = 'Tack f�r att du anv�nder SITENAME.<br /><br />Vi uppskattar att du forts�tter anv�nda tj�nsten.';
$lang['reject'] = 'Avsl�';
$lang['unread'] = 'Ol�sta';
$lang['membership_hdr'] = 'Medlemsniv�';
$lang['edit_pict'] = 'Redigera huvudbild';
$lang['edit_thmpnail'] = 'Redigera miniatyrbild';
$lang['letter_options'] = 'Brevinst�llningar';
$lang['pic_gallery'] = 'Bilder';
$lang['reactivate'] = '�teraktivera anv�ndare';
$lang['cancel_list'] = 'Lista p� avst�ngda medlemmar';
$lang['cancel_date'] = 'Avst�ngd sedan';
$lang['language_opt'] = 'Spr�kinst�llningar';
$lang['change_language'] = 'Byt spr�k';
$lang['with_photo'] = 'som har ett foto';
$lang['logintime'] = 'Inloggad sedan';
$lang['manage_country_states'] = 'Hantera land/stater';
$lang['manage_countries'] = 'Hantera l�nder';
$lang['countries_count'] = 'Antal l�nder';
$lang['insert_country'] = 'L�gg till ett nytt land';
$lang['modify_country'] = '�ndra land';
$lang['country_code'] = 'Landskod';
$lang['country_name'] = 'Landsnamn';
$lang['manage_states'] = 'Hantera stater';
$lang['states_count'] = 'Antal stater';
$lang['insert_state'] = 'L�gg till en ny stat';
$lang['modify_state'] = '�ndra stat';
$lang['state_code'] = 'Statkod';
$lang['state_name'] = 'Statnamn';
$lang['totalcouples'] = 'Antal parmedlemmar:';
$lang['active_days'] = 'Godk�nd f�r hur m�nga dagar?';
$lang['activedays_array'] = array('1'=>'1','7'=>'7','30'=>'30','90'=>'90','180'=>'180','365'=>'365','999'=>'999');
$lang['expired'] = 'Ditt medlemskap har upph�rt. <a href="payment.php" class="errors">F�rnya ditt medlemskap</a> och forts�tt att dra f�rdel av tj�nsterna h�r p� SITENAME.';
$lang['compose'] = 'F�rfatta';
$lang['logout_login']='F�r att aktivera ditt nya l�senord s� m�ste du logga ut och in p� nytt.';
$lang['makefeatured'] = 'Klicka h�r f�r att l�gga till i listan �ver VIP-profiler.';
$lang['col_head_gender_short'] = 'K�n';
$lang['no_subject'] = 'Inget �mne';
$lang['admin_col_head_fullname'] = $lang['col_head_fullname'];
$lang['select_from_list'] = '--V�lj--';
$lang['default_tz'] = '0.00';
$lang['manage_counties'] = 'L�n/kommun';
$lang['counties_count'] = 'Antal l�n/kommuner';
$lang['insert_county'] = 'L�gg till l�n/kommun';
$lang['modify_county'] = '�ndra l�n/kommun';
$lang['county_code'] = 'L�n/kommun-kod';
$lang['county_name'] = 'L�n/kommun-namn';
$lang['manage_cities'] = 'St�der/samh�llen';
$lang['cities_count'] = ' Antal st�der/samh�llen';
$lang['insert_city'] = 'L�gg till stad/samh�lle';
$lang['modify_city'] = '�ndra stad/samh�lle';
$lang['city_code'] = 'Stads-/samh�llskod';
$lang['city_name'] = 'Stads-/samh�llsnamn';
$lang['manage_zips'] = 'Postnummer';
$lang['zips_count'] = 'Antal postnummer';
$lang['insert_zip'] = 'L�gg till postnummer';
$lang['modify_zip'] = '�ndra postnummer';
$lang['zip_code'] = 'Postnummer';
$lang['show_form'] = 'Visa formul�r:';
$lang['change_album'] = 'Uppdatera';

/* Following array is for Profile Window display heading conversion */
$lang['extsearchhead'] = array(
	'Marital Status'		=> 'Civilstatus',
	'Ethnicity'			=> 'Etnicitet',
	'Religion'			=> 'Religion',
	'Hobbies'			=> 'Fritidsintressen',
	'Height'			=> 'L�ngd',
	'Body Type'			=> 'Kroppstyp',
	'Zodiac Sign'			=> 'Stj�rntecken',
	'Eye color'			=> '�gonf�rg',
	'Hair color'			=> 'H�rf�rg',
	'Body art'			=> 'Kroppsutsmyckningar',
	'Best feature'			=> 'B�sta egenskap',
	'Hot spots'			=> 'Heta punkter',
	'Sports'			=> 'Sporter',
	'Favorite things'  		=> 'Favoritsaker',
	'Last reading'			=> 'Senast l�sta',
	'Common interests'		=> 'Vanliga intressen',
	'Sense of humor'		=> 'K�nsla humor',
	'Exercise'			=> 'Motion',
	'Daily diet'			=> 'Daglig diet',
	'Smoking'			=> 'R�ker',
	'Drinking'			=> 'Dricker',
	'Job schedule'			=> 'Arbetsschema',
	'Current annual income'		=> '�rsinkomst',
	'Living situation'		=> 'Boendeform',
	'Kids'				=> 'Barn',
	'Want children'			=> 'Vill ha barn',
	'Weight'			=> 'Vikt',
	'Employment status'		=> 'Jobbstatus',
	'Education'			=> 'Utbildning',
	'Languages'			=> 'Spr�k',
	'Referred by'			=> 'Refererad av',
);

/* user_stats */
$lang['your_user_stats'] = 'Din anv�ndarstatistik';
$lang['other_user_stats'] = 'Andra anv�ndares statistik';
$lang['user_stats'] = 'Anv�ndarstatus';
$lang['users_match_your_search'] = 'Anv�ndare som matchar dina s�kkriterier';
$lang['in_your_country'] = 'Anv�ndare som bor i ditt land';
$lang['in_your_state'] = 'Anv�ndare som bor i ditt omr�de';
$lang['in_your_county'] = 'Anv�ndare som bor i ditt l�n/kommun';
$lang['in_your_city'] = 'Anv�ndare som bor i din stad/samh�lle';
$lang['in_your_zip'] = 'Anv�ndare som bor i ditt postnummeromr�de';
$lang['in_same_gender'] = 'Anv�ndare som �r av samma k�n';
$lang['in_same_age'] = 'Anv�ndare som �r i din �lder';
$lang['above_lookagestart'] = 'Anv�ndare som �r �ldre �n min start�ldersgr�ns';
$lang['below_lookageend'] = 'Anv�ndare som �r yngre �n min stopp�ldersgr�ns';
$lang['your_lookgender'] = 'Anv�ndare som matchar din k�nspreferens';
$lang['in_look_country'] = 'Anv�ndare som bor i ditt s�kta land';
$lang['in_look_state'] = 'Anv�ndare som bor i ditt s�kta omr�de';
$lang['in_look_county'] = 'Anv�ndare som bor i ditt s�kta l�n/kommun';
$lang['in_look_city'] = 'Anv�ndare som bor i din s�kta stad/samh�lle';
$lang['in_look_zip'] = 'Anv�ndare som bor i ditt s�kta postnummeromr�de';
$lang['in_same_timezone'] = 'Anv�ndare som bor i samma tidszon';
$lang['album_hdr'] = 'Album';
$lang['public'] = 'Publik';
$lang['calendar_admin'] = 'Hantera kalendrar';
$lang['mysettings'] = 'Mina inst�llningar';
$lang['user_lists'] = 'Kataloger';
$lang['login_settings'] = 'Inloggningsinst�llningar';
$lang['no_pics'] = 'Inga bilder';
$lang['my_page'] = 'Min sida';
$lang['write_new_msg'] = 'Skriv nytt meddelande';
$lang['view_winkslist'] = 'Se fl�rtar';

// Import module
$lang['manage_import'] = 'Importera';
$lang['manage_import_datingpro'] = 'Importera fr�n DatingPro';
$lang['manage_import_aedating'] = 'Importera fr�n aeDating';
$lang['manage_import_section'] = 'V�lj importmodul';
$lang['manage_import_select'] = 'V�lj vad som skall importeras';
$lang['module'] = 'Modul';
$lang['imported'] = 'Importerad';
$lang['import'] = 'Importera';
$lang['empty'] = 'Tom';
$lang['select_section'] = 'V�lj sektion f�r fr�gor';
$lang['import_db_configuration'] = 'St�ll in databaskonfiguration';
$lang['db_name'] = 'DB-namn:';
$lang['db_host'] = 'DB-host:';
$lang['db_user'] = 'DB-anv�ndare:';
$lang['db_pass'] = 'DB-l�senord:';
$lang['db_prefix'] = 'Tabellprefix:';

// Calendar
$lang['calendar_title'] = 'Hantera kalendrar';
$lang['total_calendars'] = 'Antal kalendrar:';
$lang['modify_calendar'] = '�ndra kalender';
$lang['modify_calendars'] = '�ndra kalendrar';
$lang['delete_calendar'] = 'Ta bort kalender';
$lang['delete_calendars'] = 'Ta bort kalendrar';

// Calendar Events
$lang['events_title'] = 'Hantera h�ndelser';
$lang['insert_event'] = 'L�gg till en h�ndelse';
$lang['modify_event'] = '�ndra h�ndelse';
$lang['total_events'] = 'Valda h�ndelser';
$lang['event'] = 'H�ndelse:';
$lang['calendar_field'] = 'Kalender:';
$lang['private_to'] = 'Privat till:';
$lang['date_from'] = 'Datum fr�n:';
$lang['date_to'] = 'Datum till:';
$lang['col_head_calendar'] = 'Kalender';
$lang['col_head_username'] = 'Anv�ndare';
$lang['col_head_fullname'] = 'Namn';
$lang['col_head_event'] = 'H�ndelse';
$lang['col_head_datefrom'] = 'Datum fr�n';
$lang['col_head_dateto'] = 'Datum till';
$lang['col_head_date'] = 'Datum';
$lang['col_head_description'] = 'Beskrivning';
$lang['calendar_title'] = 'Kalender';
$lang['calendar'] = 'Kalender:';
$lang['event_title'] = 'H�ndelse';
$lang['add_event'] = 'L�gg till h�ndelse';
$lang['delete_calendar_group_confirm_msg'] = 'Vill du verkligen ta bort kalendrarna? Denna �tg�rd kan inte �ngras.';
$lang['private_only'] = 'Endast privata';
$lang['public_only'] = 'Endast publika';
$lang['public_private'] = 'Publika och privata';
$lang['total_events_found'] = 'Antal h�ndelser:';
$lang['start_date'] = 'Startdatum';
$lang['start_time'] = 'Starttid';
$lang['end_date'] = 'Slutdatum';
$lang['end_time'] = 'Sluttid';
$lang['event_description'] = 'H�ndelsebeskrivning';
$lang['more_events'] = 'fler h�ndelser >>';
$lang['daily_events_list'] = "Lista h�ndelser som intr�ffar ";
$lang['add_to_private'] = "L�gg till i privatlistan";
$lang['close_window'] = "St�ng f�nster";
$lang['main_window_closed'] = "Beklagar, men du st�ngde huvudf�nstret.";
$lang['user_added1'] = "Anv�ndare ";
$lang['user_added2'] = " har lagts till i privatlistan";
$lang['next_month'] = 'N�sta m�nad';
$lang['previous_month'] = 'F�reg�ende m�nad';
$lang['next_week'] = 'N�sta vecka';
$lang['previous_week'] = 'F�reg�ende vecka';
$lang['next_day'] = 'N�sta dag';
$lang['previous_day'] = 'F�reg�ende dag';
$lang['view_day'] = 'Dagsvy';
$lang['view_week'] = 'Veckovy';
$lang['view_month'] = 'M�nadsvy';
$lang['watched_events'] = 'H�ndelser som du bevakar';
$lang['event_notification'] = 'H�ndelsep�minnelse';
$lang['jump_to'] = 'Hoppa till';
$lang['ok'] = 'Ok';
$lang['recurring'] = "Upprepas:";
$lang['recur_every'] = "varje";
$lang['recuring_labels'] = array(
	'0' => 'aldrig',
	'1' => 'dagar',
	'2' => 'veckor',
	'3' => 'm�nader',
	'4' => '�r'
);
$lang['calendat_filter_dates_range'] = "Valt datumomf�ng";
$lang['calendat_filter_last_year'] = "F�rra �ret";
$lang['calendat_filter_last_month'] = "F�rra m�naden";
$lang['calendat_filter_last_week'] = "F�rra veckan";
$lang['calendat_filter_yesterday'] = "Ig�r";
$lang['cannot_determine_membership'] = 'Din medlemsniv� hittades inte';
$lang['no_previous_polls'] = 'Det finns inga tidigare omr�stningar.';
$lang['no_event_for_the_day'] = "Det finns inga h�ndelser f�r detta datum";
$lang['maxsize'] = 'Maximal till�ten storlek (KB)';
$lang['views'] = 'Vyer';

/******************************************/

/* ALL ERROR MESSAGES ARE DEFINED BELOW.  */

/******************************************/

// Affiliates error
$lang['affiliates_error'] = array(
	18 =>'L�senorden st�mmer ej �verens.',
	20 =>'Alla f�lt m�ste fyllas i.',
	21 =>'Alla f�lt m�ste fyllas i.',
	25 =>'Den e-postadress du uppgett tillh�r en redan registrerad partner. Anv�nd en annan adress.'
);

// Javascript error messages

$lang['admin_js_error_msgs'] = array(
	'',
	'V�lj f�rst minst en kryssruta.',
	'�r du s�ker p� att du vill radera?',
	'�r du s�ker p� att du vill ta bort denna annons?'
);

$lang['admin_js__delete_error_msgs'] = array('',
	1=> '�r du s�ker p� att du vill ta bort denna sektion? Du kan inte �ngra denna �tg�rd.',
	2=> '�r du s�ker p� att du vill ta bort denna fr�ga fr�n denna sektion? Du kan inte �ngra denna �tg�rd.',
	3=> '�r du s�ker p� att du vill ta bort detta svarsalternativ? Du kan inte �ngra denna �tg�rd.',
	4=> '�r du s�ker p� att du vill ta bort denna profil? Du kan inte �ngra denna �tg�rd.',
	5=> '�r du s�ker p� att du vill ta bort denna nyhet? Du kan inte �ngra denna �tg�rd.',
	6=> '�r du s�ker p� att du vill ta bort denna ber�ttelse? Du kan inte �ngra denna �tg�rd.',
	7=> '�r du s�ker p� att du vill ta bort denna artikel? Du kan inte �ngra denna �tg�rd.',
	8=> '�r du s�ker p� att du vill ta bort denna omr�stning? Du kan inte �ngra denna �tg�rd.',
	9=> '�r du s�ker p� att du vill ta bort detta omr�stningsalternativ? Du kan inte �ngra denna �tg�rd.',
	10=> '�r du s�ker p� att du vill ta bort denna annons? Du kan inte �ngra denna �tg�rd.',
	11=> '�r du s�ker p� att du vill ta bort denna administrat�r? Du kan inte �ngra denna �tg�rd.',

	/* Added in RC6 */
	12=> '�r du s�ker p� att du vill ta bort detta land? Du kan inte �ngra denna �tg�rd.',
	13=> '�r du s�ker p� att du vill ta bort denna stat/omr�de? Du kan inte �ngra denna �tg�rd.',
	14=> '�r du s�ker p� att du vill ta bort dessa l�nder? Du kan inte �ngra denna �tg�rd.',
	15=> '�r du s�ker p� att du vill ta bort dessa stater/omr�den? Du kan inte �ngra denna �tg�rd.',
	16=> 'Avancerad s�khuvud m�ste anges i en avancerad s�k.',
	17=> 'Anv�ndarnamn m�ste fyllas i n�r anv�ndarnamnomf�ng �r valt.',
	18=> '�r du s�ker p� att du vill ta bort dessa profiler? Du kan inte �ngra denna �tg�rd.',

	/* Added Release 1.0 */
	19=> '�r du s�ker p� att du vill ta bort detta l�n/kommun? Du kan inte �ngra denna �tg�rd.',
	20=> '�r du s�ker p� att du vill ta bort dessa l�n/kommuner? Du kan inte �ngra denna �tg�rd.',
	21=> '�r du s�ker p� att du vill ta bort denna stad/samh�lle? Du kan inte �ngra denna �tg�rd.',
	22=> '�r du s�ker p� att du vill ta bort dessa st�der/samh�llen? Du kan inte �ngra denna �tg�rd.',
	23=> '�r du s�ker p� att du vill ta bort detta postnummer? Du kan inte �ngra denna �tg�rd.',
	24=> '�r du s�ker p� att du vill ta bort dessa postnummer? Du kan inte �ngra denna �tg�rd.',
	25=> '�r du s�ker p� att du vill ta bort denna h�ndelse? Du kan inte �ngra denna �tg�rd.',
	26=> '�r du s�ker p� att du vill ta bort denna kalender? Du kan inte �ngra denna �tg�rd.',
	27=> '�r du s�ker p� att du vill ta bort denna sida? Du kan inte �ngra denna �tg�rd.',
);

// Don't use double qoutes(") in the item's text
$lang['signup_js_errors'] = array(
	'username_noblank' => 'Anv�ndarnamn �r ett obligatoriskt f�lt.',
	'password_noblank' => 'L�senord �r ett obligatoriskt f�lt.',
	'old_password_noblank' => 'Gammalt l�senord �r ett obligatoriskt f�lt.',
	'new_password_noblank' => 'Nytt l�senord �r ett obligatoriskt f�lt.',
	'con_password_noblank' => 'Bekr�fta l�senord �r ett obligatoriskt f�lt.',
	'firstname_noblank' => 'F�rnamn �r ett obligatoriskt f�lt.',
	'name_noblank' => 'Namn �r ett obligatoriskt f�lt.',
	'lastname_noblank' => 'Efternamn �r ett obligatoriskt f�lt.',
	'email_noblank' => 'E-postadress �r ett obligatoriskt f�lt.',
	'city_noblank' => 'Stad �r ett obligatoriskt f�lt.',
	'zip_noblank' => 'Postnummer �r ett obligatoriskt f�lt.',
	'address1_noblank' => 'Adressrad 1 �r ett obligatoriskt f�lt.',
	'sectionname_noblank' => 'Sektionsnamn �r ett obligatoriskt f�lt.',
	'sendname_noblank' => 'Avs�ndarnamn �r ett obligatoriskt f�lt.',
	'calendarname_noblank' => 'Kalendernamn �r ett obligatoriskt f�lt.',
	'comments_noblank' => 'Kommentar �r ett obligatoriskt f�lt.',
	'question_noblank' => 'Fr�ga �r ett obligatoriskt f�lt.',
	'extsearchhead_noblank' => 'Avancerat s�khuvud �r ett obligatoriskt f�lt.',
	'username_charset' => 'Endast bokst�ver, siffror och understreck (_) �r till�tna i anv�ndarnamnet.',
	'password_charset' => 'Endast bokst�ver, siffror och understreck (_) �r till�tna i l�senordet.',
	'firstname_charset' => 'Endast bokst�ver �r till�tna i f�rnamnet.',
	'lastname_charset' => 'Endast bokst�ver �r till�tna i efternamnet.',
	'city_charset' => 'Endast bokst�ver �r till�tna i stadsnamnet.',
	'zip_charset' => 'Endast siffror �r till�tna i postnumret.',
	'address_charset' => 'Fyll i en giltig adress.',
	'sectionname_charset' => 'Endast bokst�ver �r till�tna i sektionsnamn.',
	'calendarname_charset' => 'Endast bokst�ver �r till�tna i f�ltet kalendernamn.',
	'sendname_charset' => 'Endast bokst�ver �r till�tna i f�ltet avs�ndarnamn.',
	'name_charset' => 'Endast bokst�ver �r till�tna i f�ltet namn.',
	'maxlength_charset' => 'Endast heltal �r till�tna i f�ltet maxl�ngd.',
	'email_notvalid' => 'E-postadressen �r ogiltig.',
	'password_nomatch' => 'L�senorden matchar ej varandra.',
	'password_outrange' => 'L�senordet har en otill�ten l�ngd.',
	'username_outrange' => 'Anv�ndarnmanet har en otill�ten l�ngd.',
	'username_start_alpha' => 'Anv�ndarnamn m�ste b�rja med en bokstav.',
	'ccowner_noblank' => 'Kreditkorts�gare �r ett obligatoriskt f�lt.',
	'ccnumber_noblank' => 'Kreditkortsnummer �r ett obligatoriskt f�lt.',
	'cvvnumber_noblank' => 'Kreditkortskontrollnummer �r ett obligatoriskt f�lt.',
	'select_payment' => 'V�lj betalningsmetod.',
	'stateprovince_noblank' => 'Stat/provins �r ett obligatoriskt f�lt.',
	'subject_noblank'	=> '�mnesrad �r ett obligatoriskt f�lt.',
	'county_noblank' => 'L�n/kommun �r ett obligatoriskt f�lt.',
	'county_charset' => 'L�n/kommun m�ste vara ett alfabetiskt v�rde.',
	'timezone_noblank' => 'Tidszon �r ett obligatoriskt f�lt.',

	/* Added in 2.0 */
	'ratingname_noblank' => 'Betygsnamn �r ett obligatoriskt f�lt.',
	'ratingname_charset' => 'Ogiltiga tecken p�tr�ffades i betygsnamnet.',
	'about_me_noblank' 	=> 'Du m�ste skriva en beskrivning av dig sj�lv.',
);

$lang['letter_errormsgs'] = array(
	0 => 'Ditt l�senord har skickats till din registrerade e-postadress.',
	1 => 'Skriv in den e-postadress du anv�nde vid registreringen.',
	2 => 'Mallen hittades inte, kontakta sajt�garen.',
	4 => 'Det gick inte att skicka meddelandet. F�rs�k igen senare eller kontakta sajt�garen om problemet kvarst�r.',
	5 => 'Du �r inte en registrerad medlem p� SITENAME. Skriv in din e-postadress.',
);

$lang['split_file_names_hdr'] = 'Filer som laddas nu';
$lang['worst1'] = '(s�mst)';
$lang['best1'] = '(b�st)';
$lang['profile_auto_confirmed'] = 'Tack f�r att du registrerar dig p� SITENAME.<br><br>Din profil har automatiskt blivit godk�nd av systemet.<br><br><a href="index.php?page=login">Klicka h�r f�r att logga in</a><br><br>';

$lang['taf_errormsgs'] = array(
	0 => 'Inbjudan skickad.',
	'sendername_noblank' => 'Ditt namn �r ett obligatoriskt f�lt.',
	'senderemail_noblank' => 'Din e-postadress �r ett obligatoriskt f�lt.',
	'recipientemail_noblank' => 'Mottagarens e-postadress �r ett obligatoriskt f�lt.',
	'sendername_charset' => 'Avs�ndarnamnet f�r endast inneh�lla bokst�ver.',
	'senderemail_charset' => 'Din e-postadress �r i ett ogiltigt format.',
	'recipientemail_charset' => 'Mottagarens e-postadress �r i ett ogiltigt format.',
	2 => 'Referatmallen hittades ej.',
	3 => 'Din inbjudan kunde inte skickas. F�rs�k igen.',
);

$lang['pages_errormsgs'] = array( '',
	1 => 'Sidtitel saknas.',
	2 => 'Sidnyckel saknas.',
	3 => 'Sidtext saknas.',
	4 => 'Sidnyckel finns redan, v�lj en annan och f�rs�k igen.',
	5 => 'Sidan har raderats.',
);

$lang['artile_error'] = array(
	1 => 'Artikeltitel �r ett obligatoriskt f�lt.',
	2 => 'Artikeltext �r ett obligatoriskt f�lt.',
	3 => 'Artikeldatum �r ett obligatoriskt f�lt.'
);

$lang['story_error'] = array(
	1 => 'Ber�ttelserubrik �r ett obligatoriskt f�lt.',
	2 => 'Ber�ttelsetext �r ett obligatoriskt f�lt.',
	3 => 'Ber�ttelsedatum �r ett obligatoriskt f�lt.',
	4 => 'Ber�ttelsef�rfattare �r ett obligatoriskt f�lt.'
);

$lang['news_error'] = array(
	1 => 'Nyhetsrubrik �r ett obligatoriskt f�lt.',
	2 => 'Nyhetstext �r ett obligatoriskt f�lt.',
	3 => 'Nyhetsdatum �r ett obligatoriskt f�lt.'
);

$lang['mship_errors'] = array (
	1 => 'Namn �r ett obligatoriskt f�lt.',
	2 => 'Pris �r ett obligatoriskt f�lt.',
	3 => 'Valuta �r ett obligatoriskt f�lt.',
	4 => 'Ingen Betalning-metoden �r endast tillg�nglig n�r du byter till medlemsniv�n Gratis.'
);

$lang['admin_error_msgs'] = array (
	'',
	'Sektion �r ett obligatoriskt f�lt.',
	'V�nligen fyll i samtliga f�lt.'
	);

$lang['admin_error'] = array(
	'',
	1 => 'Anv�ndarnamn �r ett obligatoriskt f�lt.',
	2 => 'L�senord �r ett obligatoriskt f�lt.',
	3 => 'Namn �r ett obligatoriskt f�lt.',
	4 => 'Gammalt l�senord �r ett obligatoriskt f�lt.',
	5 => 'Nytt l�senord �r ett obligatoriskt f�lt.',
	6 => 'Bekr�fta l�senord �r ett obligatoriskt f�lt.',
	7 => 'L�senorden st�mmer inte �verens.',
	8 => 'Det gamla l�senordet �r fel. Kontrollera att du skrivit r�tt och f�rs�k igen.',
	9 => 'Anv�ndarnamnet �r redan registrerat. V�lj ett nytt och f�rs�k igen.',
	/* added in 1.1.0 */
	10 => 'Sektionsnamnet f�r endast inneh�lla bokst�ver.'
);

$lang['banner_error_msgs'] = array( '',
	1 => 'Annons �r ett obligatoriskt f�lt.',
	2 => 'L�nk-URL �r ett obligatoriskt f�lt.',
	3 => 'Tooltip �r ett obligatoriskt f�lt.',
	4 => 'Endast filer av typen .jpg �r till�tna.',
	5 => 'Storleken �verskrider den maximalt till�tna storleken.'
);

$lang['poll_error'] = array(
	1 => 'Omr�stning �r ett obligatoriskt f�lt.',
	2 => 'Omr�stningsdatum �r ett obligatoriskt f�lt.',
	3 => 'Omr�stningsalternativ �r ett obligatoriskt f�lt.',
	'txtpoll_noblank'  => 'Omr�stning �r ett obligatoriskt f�lt.',
	'txtpollopt_noblank' => 'Omr�stningsalternativ �r ett obligatoriskt f�lt.'
	);

$lang['datetime_month'] = array(
	1=>'Januari',
	2=>'Februari',
	3=>'Mars',
	4=>'April',
	5=>'Maj',
	6=>'Juni',
	7=>'Juli',
	8=>'Augusti',
	9=>'September',
	10=>'Oktober',
	11=>'November',
	12=>'December'
);

$lang['datetime_day'] = array(
	'sunday'    => 'S�ndag',
	'monday'    => 'M�ndag',
	'tuesday'   => 'Tisdag',
	'wednesday' => 'Onsdag',
	'thursday'  => 'Torsdag',
	'friday'    => 'Fredag',
	'saturday'  => 'L�rdag'
);

/* Release 1.0.2   */

$lang['settings_saved'] = 'Inst�llningarna har sparats.';
$lang['select_image_first'] = 'V�lj en bild f�rst';

/* Release 1.1.0 additions */

$lang['day_names'] = array(
	'Sun' => 'S�ndag',
	'Mon' => 'M�ndag',
	'Tue' => 'Tisdag',
	'Wed' => 'Onsdag',
	'Thu' => 'Torsdag',
	'Fri' => 'Fredag',
	'Sat' => 'L�rdag'
);

$lang['view_type'] = 'Vytyp';

$lang['remember_me'] = 'Kom ih�g mig';
$lang['review'] = 'Granska';
$lang['spammers'] = 'Spammare';
$lang['addquestion'] = 'L�gg till fr�ga';
$lang['mainstats'] = 'Statistik';
$lang['osdate_version'] = 'osDate Version';
$lang['signonstats'] = 'Statistik �ver nya medlemmar';
$lang['usersinpastminute'] = 'Nya anv�ndare senaste minuten';
$lang['usersinpasthour'] = 'Nya anv�ndare senaste timmen';
$lang['usersinpastday'] = 'Nya anv�ndare senaste dygnet';
$lang['usersinpastweek'] = 'Nya anv�ndare senaste veckan';
$lang['usersinpastmonth'] = 'Nya anv�ndare senaste m�naden';
$lang['usersinpastyear'] = 'Nya anv�ndare senaste �ret';
$lang['usersinpast2years'] = 'Nya anv�ndare senaste 2 �ren';
$lang['usersinpast5years'] = 'Nya anv�ndare senaste 5 �ren';
$lang['usersinpast10years'] = 'Nya anv�ndare senaste 10 �ren';
$lang['userstats'] = 'Anv�ndarstatistik';
$lang['totalusers'] = 'Totalt antal anv�ndare';
$lang['totalactiveusers'] = 'Antal aktiva anv�ndare';
$lang['totalpendingusers'] = 'Antal v�ntande anv�ndare';
$lang['totalsuspendedusers'] = 'Antal vilande anv�ndare';
$lang['totalpictureusers'] = 'Antal anv�ndare som har bild';
$lang['totalonlineusers'] = 'Antal anv�ndare online';
$lang['visitorstats'] = 'Bes�karstatistik';
$lang['sitestats'] = 'Statistik';
$lang['visitorstosite'] = 'Sajtbes�k';
$lang['mostactivepage'] = 'Mest aktiva sida';
$lang['timesfeedback'] = 'Antal feedbacks';
$lang['timesim'] = 'Antal direktmeddelanden';
$lang['timeswink'] = 'Antal fl�rtar';
$lang['timesmessage'] = 'Antal meddelanden till en inkorg';
$lang['timesinvitefriend'] = 'Antal inviter';
$lang['timeshowprofile'] = 'Antal profilvisningar';
$lang['timesonlineusers'] = 'Antal klick p� Anv�ndare Online';
$lang['timesbanner'] = 'Antal klick p� annonser';
$lang['timesnewmember'] = 'Antal klick p� Nya Medlemmar';
$lang['timespoll'] = 'Antal klick p� omr�stningar';
$lang['timesgallery'] = 'Antal klick p� bildgallerier';
$lang['timesaffiliates'] = 'Antal klick p� partners';
$lang['timessignup'] = 'Antal klick p� registrering';
$lang['timesnews'] = 'Antal klick p� nyheter';
$lang['timesstories'] = 'Antal klick p� ber�ttelser';
$lang['timessearchmatch'] = 'Antal s�kningar';
$lang['no_affiliates'] = 'Antal partners';
$lang['no_affiliate_refs'] = 'Antal partnerh�nvisningar';
$lang['no_pages_refs'] = 'Antal sidh�nvisningar';
$lang['no_polls'] = 'Antal omr�stningar';
$lang['no_news'] = 'Antal nyheter';
$lang['no_stories'] = 'Antal ber�ttelser';
$lang['no_langs'] = 'Antal tillg�ngliga spr�k';
$lang['glblgroups'] = 'Globala inst�llningar';
$lang['accept_tos'] = 'Jag har l�st och accepterar <a href="javascript:popUpScrollWindow('."'tos.php','center',650,600);".'">Anv�ndaravtalet</a>';
$lang['tos_must'] = 'V�nligen l�s och acceptera anv�ndaravtalet innan du registrerar dig';
$lang['private_event'] = 'Denna h�ndelseinformation �r privat';
$lang['posted_by'] = 'Skriven av';
$lang['countries01']= 'L�nder';
$lang['states01'] = 'Stater';
$lang['latitude'] = 'Latitud';
$lang['longitude'] = 'Longitud';
$lang['search_within'] = 'S�k inom';
$lang['miles'] = ' mil ';
$lang['kms'] = ' kilometer ';
$lang['no_search_results'] = '<font color=red><b>0 objekt hittades.</b></font><br /><br />Det finns inga objekt som matchar dina kriterier. Du kanske vill ut�ka din s�kning. Prova att minska antalet kriterier, t.ex l�ngd och �lder. Eller ut�ka vidden p� s�kningen t.ex ist�llet f�r att s�ka p� personer mellan 40-50 �r, s�k p� personer mellan 30-60 �r.<br /><br />';
$lang['expire_on'] = 'Medlemskap upph�r';
$lang['expire_in'] = 'Dagar kvar tills medlemskap upph�r';
$lang['lang_to_load'] = 'V�lj spr�k att ladda';
$lang['load_lang'] = 'Ladda valt spr�k';
$lang['manage_languages'] = 'Hantera spr�k';
$lang['manage_zips'] = 'Hantera postnummer';
$lang['zipfile'] = 'Postnummerfil';
$lang['zip_loaded'] = 'Postnummer laddas fr�n filen ';
$lang['file_not_found'] = 'Angiven fil finns inte i systemet';

/* Modified in 1.1.0 */
$lang['success_mship_change'] = 'Tack f�r att du f�rnyade ditt medlemskap.<br /><br />Din medlemsniv� har �ndrats till';
$lang['payment_cancel'] = 'Betalning avbruten';
$lang['checkout_cancel'] = 'Betalningen har avbrutits.';
$lang['useronlinetext'] = array(
	'online_now'		=> 	'Inloggad nu',
	'active_24hours'	=> 	'Aktiv senaste 24 timmarna',
	'active_3days'		=>	'Aktiv senaste 3 dagarna',
	'active_1week'		=>	'Aktiv senaste veckan',
	'active_1month'		=>	'Aktiv senaste m�naden',
	'notactive'			=>	'Inte aktiv de senaste'
);

$lang['useronlinecolor'] = array(
	'online_now'		=> 	'#FF0000',
	'active_24hours'	=> 	'#00AA00',
	'active_3days'		=>	'#AA00A0',
	'active_1week'		=>	'#0000AA',
	'active_1month'		=>	'#000000',
	'notactive'		=>	'#838383'
);

$lang['transactions_report'] = 'Betalningsrapport';
$lang['trans_count'] = 'Transaktionsr�knare';
$lang['pay_no'] = 'Bet. nummer';
$lang['ref_no'] = 'Ref. nummer';
$lang['paid_thru'] = 'Betalning sedan';
$lang['pay_status'] = 'Betalningsstatus';
$lang['trans_rep'] = 'Betalningsrapport';
$lang['expiry_interval'] = array(
	'1'	=> '24 timmar',
	'3'	=>	'3 dagar',
	'7'	=>	'7 dagar',
	'15'	=>	'15 dagar',
	'30'	=>	'30 dagar',
	'0'	=>	'F�rfallen'
);
$lang['expiry_hdr'] = 'P�minnelse om upph�rande medlemskap';
$lang['expiry_ltr'] = 'P�minnelse';
$lang['expiry_select'] = 'V�lj upph�randeintervall';
$lang['expird'] = 'Upph�rt';
$lang['expiry_ltr_sent'] = 'P�minnelse om upph�rande har skickats';
$lang['searching_within'] = 'S�ker inom';
$lang['payment_failed'] = 'Betalningen misslyckades. F�rs�k igen.';
$lang['payment_fail'] = 'Betalningen misslyckades';
$lang['deactivate'] = 'Inaktivera';
$lang['open_search'] = '�ppen s�kning';
$lang['replace'] = 'Ers�tt';
$lang['new'] = 'Ny';
$lang['no_save'] = 'Spara ej';
$lang['modify_curr_search'] = 'Redigera aktuella s�kkriterier';
$lang['perform_search'] = 'och utf�r s�kning.';
$lang['start_new_search'] = 'Starta en ny s�kning';
$lang['use_empty_form'] = 'med ett tomt formul�r.';
$lang['of_zip_code'] = 'p� detta postnummer';

/* MOD START */

$lang['profile_ratings'] = 'Profilbetyg';
$lang['total_ratings'] = 'Antal betyg';
$lang['delete_ratings'] = 'Ta bort betyg';
$lang['delete_rating_group_confirm_msg'] = '�r du s�ker p� att du vill ta bort dessa betyg? Du kan inte �ngra �tg�rden.';
$lang['delete_rating_confirm_msg'] = '�r du s�ker p� att du vill ta bort denna gradering? Du kan inte �ngra �tg�rden.';
$lang['modify_rating'] = '�ndra gradering';
$lang['modify_ratings'] = '�ndra graderingar';
$lang['glblsettings_groups']['50'] = 'Profilbetyg';
$lang['mod_lowtohigh']['Low to High'] = 'L�g till h�g';
$lang['mod_lowtohigh']['High to Low'] = 'H�g till l�g';
$lang['admin_rights']['profile_ratings'] = 'Profilbetyg';
$lang['custom_message'] = 'Valfritt meddelande';
$lang['notify_me'] = 'Meddela mig n�r mitt meddelande har l�sts.';
$lang['include_profile'] = 'Inkludera min profil med detta meddelande.';
$lang['message_templates'] = 'Meddelandemallar';
$lang['my_templates'] = 'Mina mallar';
$lang['template_select'] = 'V�lj en mall';
$lang['template_intro'] = 'Om du ofta skickar samma meddelanden till potentiella tr�ffar s� kan du skapa en mall f�r dessa meddelanden f�r att slippa skriva s� mycket. Genom att anv�nda mall-variabler som [username] och [firstname] s� kan du g�ra dina mallar mer personliga f�r mottagaren.';
$lang['add_template'] = 'L�gg till en mall';
$lang['return_message'] = '�terg� till meddelandet';
$lang['delete_template_confirm_msg'] = '�r du s�ker p� att du vill ta bort denna mall? Du kan inte �ngra dig.';
$lang['edit_template'] = '�ndra mall';
$lang['template_instructions'] = 'F�ljande mall-variabler finns tillg�ngliga: <br />[username], [firstname], [city], [state], [country], [age]<br /><br />Du kan anv�nda dessa mall-variabler f�r att l�gga till en personlig k�nsla i ditt meddelande, till exempel:<br /><br />Hej [firstname]!<br /><br />Jag s�g att du �r fr�n [city]... samma h�r! ;) Jag tycker att vi verkar passa... skicka ett mail om du vill l�ra k�nna mig mer!<br /><br />Syns,<br />G�ran';
$lang['your_comment'] = 'Dina kommentarer';
$lang['your_reply'] = 'Ditt svar';
$lang['comment_note'] = 'Kommentarer l�ngre �n 255 tecken kommer att trunkeras';
$lang['chars_remaining'] = 'tecken kvar';
$lang['delete_comment_confirm_msg'] = '�r du s�ker p� att du vill ta bort denna kommentar? Du kan inte �ngra dig.';
$lang['no_msg_templates'] = 'Inga meddelandemallar hittades.';

/* MOD END */
$lang['select'] = '--V�lj--';
$lang['select_country'] = 'V�lj land';
$lang['select_state'] = 'V�lj omr�de';
$lang['select_county'] = 'V�lj l�n';
$lang['select_city'] = 'V�lj stad';
$lang['confirm_success'] = 'Logga in h�r nedan f�r att komma ig�ng med ditt medlemskap.';
$lang['signup_success_message'] = '<b>Tack!!</b><br /><br />&nbsp;Du �r nu en registrerad anv�ndare p� SITENAME.';
$lang['noone_online'] = 'Inga medlemmar inloggade';

$lang['in_hot_list'] = 'Anv�ndaren �r p� intresselistan';

$lang['in_buddy_list'] = 'Anv�ndaren �r p� kompislistan';

$lang['in_ban_list'] = 'Anv�ndaren �r p� ignoreralistan';
$lang['delete_search'] = 'Ta bort denna s�kning';
$lang['select_user_to_send_message'] = 'V�lj en anv�ndare att skicka meddelandet till';
$lang['no_im_msgs'] = 'Inga direktmeddelanden';

$lang['public_event'] = 'Denna h�ndelse �r publik';
$lang['no_event_description'] = 'Ingen beskrivning tillagd';

$lang['signup_js_errors']['country_noblank'] = 'Land m�ste v�ljas';
$lang['msg_sent'] = 'Ditt meddelande har skickats';

$lang['forgotpass_msg4'] = 'Har du gl�mt ditt l�senord? Ditt anv�ndarnamn, med nytt l�senord, kan skickas till din e-postadress. Fyll i den e-postadress du anv�nde vid registreringen.';

/* 	Additions for new email messaging interface

	Vijay Nair

*/

$lang['send_a_message'] = 'Skicka ett meddelande';
$lang['flagged'] = 'Flaggade';
$lang['un_flagged'] = 'Oflaggade';
$lang['unflagged_msg1'] = 'Oflaggade meddelanden �ldre �n ';
$lang['unflagged_msg2'] = ' dagar kommer att raderas.';
$lang['no_messages_in_box'] = 'Det finns inga meddelanden i denna mapp';
$lang['no_flagged_messages_in_box'] = 'Det finns inga flaggade meddelanden i denna mapp';
$lang['no_unflagged_messages_in_box'] = 'Det finns inga oflaggade meddelanden i denna mapp';
$lang['mark'] = 'Markera';
$lang['flag'] = 'Flagga';
$lang['unflag'] = 'Ta bort flagga';
$lang['msg_flagged'] = 'Meddelandet �r flaggat';
$lang['msg_unflagged'] = 'Meddelandet �r oflaggat';
$lang['msg_deleted'] = 'Meddelandet �r raderat';
$lang['sel_msgs_flagged'] = 'Valda meddelanden �r flaggade';
$lang['sel_msgs_unflagged'] = 'Valda meddelanden �r oflaggade';
$lang['sel_msgs_deleted'] = 'Valda meddelanden �r raderade';
$lang['sel_msgs_undeleted'] = 'Valda meddelanden �r �terst�llda';
$lang['sel_msgs_read'] = 'Valda meddelanden �r markerade som ol�sta';
$lang['sel_msgs_unread'] = 'Valda meddelanden �r markerade som nyinkomna';
$lang['FROM1'] = 'Fr�n';
$lang['no_thanks'] = 'Tacka nej';
$lang['reply'] = 'Svara';
$lang['undelete'] = '�terst�ll';
$lang['back_to_messages'] = 'Tillbaka till meddelanden';
$lang['replied'] = 'Ditt svar har skickats';
$lang['no_thanks_subject'] = 'Tack, men nej tack..........';
$lang['total'] = 'Totalt';
$lang['max_allowed'] = 'Max till�tna';
$lang['im_msg_long'] = 'Ditt meddelande �verskrider den till�tna storleken ';
$lang['members'] = 'medlemmar';
$lang['To1'] = 'Till';

/* Items which are modified in 1.1.0 */

$lang['change_email'] = 'Byt e-postadress';

/* Changes made for letters  */

$lang['no_watched_event'] = 'Du bevakar inga h�ndelser just nu.

<br /><br />Det finns #eventcount# h�ndelser som aktiveras under de n�rmaste 30 dagarna. <a "#calendarlink#">�ppna kalendern</a> f�r att titta p� dessa.
<br /><br />F�r att titta p� en h�ndelse, klicka p� h�ndelsen i kalendern och sen p� f�rstoringsglaset. #glassicon#
<br /><br />Den bevakning som du l�gger till kommer att f�rsvinna n�r h�ndelsen f�rsvinner.';

$lang['no_thanks_message']['text'] = 'Hej #recipient_username#,

Tack f�r intresset, men jag m�ste tyv�rr avb�ja. Hoppas att du hittar n�gon annan h�r p� #site_name#...

B�sta lyck�nskningar,
#sender_username#';

$lang['message_read']['text'] = "K�ra #FirstName#,

Ditt meddelande till '#RecipientName#' har l�sts.

Lycka till!

#AdminName#
SITENAME";

$lang['featured_profile_added']['text'] = "K�ra #FirstName#,

Din profil �r nu inkluderad bland v�ra VIP-profiler p� <a href=\"#link#\">#SiteName#</a>.

Din profil kommer att finnas med d�r fr�n #FromDate# till #UptoDate#.

Detta kommer att �ka chanserna att din profil syns och kan leda till betydligt fler tr�ffar fr�n andra profiler.

Lycka till!

#AdminName#
SITENAME";



$lang['wink_received']['text'] = "K�ra #FirstName#,

Du har f�tt en fl�rt fr�n #SenderName# p� #SiteName#.

Bes�k <a href=\"#link#\">#SiteName#</a> f�r att skicka ett meddelande till #SenderName#, eller f�r att svara p� fl�rten.

Lycka till!

#AdminName#
SITENAME";



$lang['invite_a_friend']['text'] = "Hej,

Jag s�g en cool dejtingsajt n�r jag surfade p� webben: #Link#.

Kolla p� den, jag tror att den passar dig.

Bes�k #Link#.

#FromName#";


$lang['profile_confirmation_email']['text'] = "K�ra #FirstName#,

Tack f�r att du registrerat dig p� #SiteName#! Som ny medlem hos oss s� rekommenderas du att unders�ka v�r service och allt godis som finns att h�mta hos oss.

F�r att bekr�fta din registrering, v�nligen klicka p� l�nken nedan. Om den inte �r klickbar, markera den och klistra in den i adressf�ltet p� din webbl�sare.

#ConfirmationLink#=#ConfCode#

Om du fortfarande har sista steget i registreringsguiden �ppen s� kan du �ven skriva in din kod p� direkt p� den sidan.

Din aktiveringskod �r: #ConfCode#

Vi har sparat f�ljande registreringsuppgifter om dig:

Anv�ndarnamn: #StrID#

L�senord: #Password#

E-postadress: #Email#

Beh�ll dessa uppgifter p� ett s�kert st�lle s� att du och ingen annan kan komma in p� ditt konto. Vissa funktioner kr�ver h�gre medlemsniv�, som du kan ordna h�r:

#SiteUrl#payment.php

Tack igen och vi hoppas att du kommer att trivas!

#AdminName#

#SiteName#";


/* Added in 1.1.1 */

$lang['loading'] = 'Laddar...';


/* Changes in 1.1.3 */

$lang['support_currency'] = array(
		'USD' 	=> '$',
		'EUR'	=>'�',
		'INR'	=>'Rs.',
		'AUD'	=> 'AU$',
		'CD'	=> 'CAN$',
		'UKP'	=> chr(163)
		);
$lang['ratings'] = 'Betyg';
$lang['comment'] = 'Kommentar';
$lang['comments'] = 'Kommentarer';
$lang['loadaction'] = 'V�lj �nskad �tg�rd';
$lang['loadintodb'] = 'Ladda till DB';
$lang['createsql'] = 'Skapa SQL-script';
$lang['load_zips'] = 'Behandla postnummerfilen';

/* Version 2.0 additions and modifications */

/* Modifications */

$lang['zip_ensure'] = 'Ladda postnummerfilen till katalogen /zipcodes innan du forts�tter.<br /><br />Filen skall inneh�lla POSTNUMMER, LATITUDE, LONGITUDE, STAT, L�N, STAD (i denna ordning). STAT, L�N och STAD kan skippas och l�ggas till i efterhand. Separera f�lten med kommatecken.<br /><br />F�r att ta bort postnummer fr�n ett land, v�lj landet och tryck p� knappen "Ta bort postnummer"';
$lang['submit'] = 'Skicka';
$lang['lang_ensure'] = 'Definiera f�rst ett nytt spr�k och l�gg till filnamnet i config.php (se $language_options och $language_files definitionerna). L�gg sedan spr�kfilen i katalagen /language/lang_xxxx/ med filnamnet lang_main.php innan du forts�tter (xxxx �r spr�knamnet med sm� bokst�ver). Till exempel: engelska eller holl�ndska.<br /><br /><b>F�r att �ndra och/eller l�gga till nya val till spr�kdefinitionerna, v�nligen g�r n�dv�ndiga �ndringar i spr�kfilen och ladda om den.</b><br /><br />F�r att ta bort redan laddade definitioner f�r ett spr�k, v�lj spr�ket och tryck p� knappen "Ta bort valt spr�k fr�n DB".';
/* $lang['rate_catefully'] is changed as below */
$lang['rate_carefully'] = 'Operat�ren av denna webbplats tar inget ansvar f�r betygss�ttningens v�rde eller �kthet.<br />Betyget s�tts uteslutande av webbplatsens anv�ndare och �vervakas inte av de ansvariga f�r webbplatsen.';

$lang['privileges'] = array (
	'chat' 				=> 'Delta i chat.',
	'blog'				=> 'Delta i blog.',
	'poll'				=> 'Delta i omr�stning.',
	'forum'				=> 'Delta i forum.',
	'includeinsearch'	 	=> 'Inkludera i s�kresultat.',
	'message'			=> 'Skicka meddelanden.',
	/* Added in 1.1.0 */
	'message_keep_cnt' 		=> 'Antal meddelanden som kan sparas.',
	'message_keep_days' 		=> 'Antal dagar ett meddelande kan sparas.',
	/* rel 2.0 */
	'messages_per_day' 		=> 'Antal meddelanden som kan skickas per dag.',
	/* Rel 1.0 added  */
	'allowim'			=> 'Till�t direktmeddelanden.',
	'uploadpicture'			=> 'Ladda upp bilder.',
	'uploadpicturecnt'		=> 'Antal bilder som f�r laddas upp.',
	'allowalbum'			=> 'Till�t privata album.',
	'event_mgt'			=> 'Till�t h�ndelsehantering.',
	/* Above is added in 1.0 */
	'seepictureprofile' 		=> 'Titta p� profilbilder.',
	'favouritelist'			=> 'Hantera kompis-/intresse- och ignoreralistor.',
	'sendwinks'			=> 'Skicka fl�rtar.',
	/* rel 2.0 */
	'winks_per_day'			=> 'Antal fl�rtar som kan skickas per dag.',
	'extsearch'			=> 'Utf�ra avancerad s�kning.',
//	'fullsignup' 			=> 'Full registrering.',
	/* RC6 Patch */
	'activedays'			=> 'Godk�nda dagar f�r denna niv�.',
	/* added in 2.0 */
	'saveprofiles'			=> 'Till�t �ndringar i profilen.',
	'saveprofilescnt'		=> 'Antal profiler som f�r sparas.',
	'allow_videos'			=> 'Till�t uppladdning av video.',
	'videoscnt'			=> 'Antal videos som f�r laddas upp.',
	'allow_mysettings'		=> 'Till�t att st�lla in inst�llningar.',
	'allow_php121'			=> 'Till�t kompisprogrammet PHP121.'
);



/* 	Signup Error Messages

	These are the signup error messages, Please do not change the sequence.

*/



$lang['errormsgs']= array(
	00 => '',
	01 => 'Anv�ndarnamn �r ett obligatoriskt f�lt.',
	02 => 'L�senord �r ett obligatoriskt f�lt.',
	03 => 'Bekr�fta l�senord �r ett obligatoriskt f�lt.',
	04 => 'F�rnamn �r ett obligatoriskt f�lt.',
	05 => 'Efternamn �r ett obligatoriskt f�lt.',
	06 => 'E-postadress �r ett obligatoriskt f�lt.',
	07 => 'Stad �r ett obligatoriskt f�lt.',
	08 => 'Postnummer �r ett obligatoriskt f�lt.',
	09 => 'Adressrad 1 �r ett obligatoriskt f�lt.',
	10 => 'Maximalt antal tecken i f�ltet anv�ndarnamn �r 25 tecken.',
	11 => 'Maximalt antal tecken i f�ltet f�rnamn �r 50 tecken.',
	12 => 'Maximalt antal tecken i f�ltet efternamn �r 50 tecken.',
	13 => 'Maximalt antal tecken i f�ltet e-postadress �r 255 tecken.',
	14 => 'Maximalt antal tecken i f�ltet stad �r 100 tecken.',
	15 => 'Maximalt antal tecken i f�ltet adressrad 1 �r 255 tecken.',
	16 => 'Anv�ndarnamn m�ste b�rja med en bokstav.',
	17 => 'L�senord m�ste b�rja med en bokstav.',
	18 => 'L�senord och bekr�ftat l�senord m�ste st�mma �verens.',
	19 => 'V�nligen anv�nd en giltig e-postadress',
	20 => 'Obligatoriska f�lt m�ste fyllas i.',
	21 => 'Felaktigt anv�ndarnamn och/eller l�senord. Var v�nlig kontrollera uppgifterna och f�rs�k igen.',
	22 => 'Anv�ndarnamnet �r upptaget. V�lj ett nytt och f�rs�k igen.',
	23 => 'Det gamla l�senordet du angett st�mmer inte. F�rs�k igen.',
	25 => 'E-postadressen finns redan registrerad.' ,
//	26 => "Din status �r 'Ej aktiv'." ,
	27 => 'Kan ej hitta meddelande.',
	28 => 'V�lj en fil f�rst.',
	29 => 'Ok�nt filformat, v�lj ett annat',
	30 => 'Fr�gan finns redan i toppen.',
	31 => 'Fr�gan finns redan i botten.',
	32 => 'Tack f�r dina kommentarer.',
	33 => 'Postnumret matchar inte den inskrivna staten.',
	34 => 'Postnumret �r ej till�tet',
	36 => 'Ditt konto �r avst�ngt. Kontakta sajt�garen f�r mer information.',
	37 => 'Dina ins�nda texter har nekats av systemet. Kontakta sajt�garen f�r mer information.',
	38 => 'Du har valt ett felaktigt f�delsedatum. Kontrollera att du skrivit r�tt.',
	39 => 'Det nya l�senordet f�r inte vara detsamma som ditt gamla l�senord',
	40 => 'Fr�n-�lder ska vara mindre eller lika med Till-�lder',
	51 => 'Startdatum m�ste vara f�re slutdatum',
	52 => 'Medlemmen finns redan p� listan',
	53 => 'Fel datum',
	54 => 'Felaktigt anv�ndarnamn och/eller l�senord',
	55 => 'Du m�ste logga in f�r att skicka ett meddelande',
	56 => $lang['bigger_pic_size'],
	57 => $lang['only_jpg'],
	58 => $lang['upload_unsuccessful'],
	59 => 'Profilen har lagts till p� listan.',
	60 => 'Miniatyrbildens storlek �verskrider ('.$config['upload_snap_tnsize'].' X '.$config['upload_snap_tnsize'].')',
	61 => 'Felaktig kod',
	62 => 'Anv�ndarnamnet har tagits bort fr�n listan',
	63 => 'Anv�ndaren har lagts till p� din kompislista',
	64 => 'Anv�ndaren har lagts till p� din ignoreralista',
	65 => 'Anv�ndaren har lagts till p� din intresselista',
	66 => 'Din fl�rt har skickats till anv�ndaren',
	67 => $lang['upload_successful'],
	68 => 'Bilden �r godk�nd',
	69 => 'Bilden �r ej godk�nd',
	70 => 'Bes�ksrekordet �r borttaget',
	71 => 'Fl�rtrekordet �r borttaget',

	/* Added in RC6  */
	72 => 'Kontot har reaktiverats',
	73 => 'Landet har lagts till',
	74 => 'Landet har raderats',
	75 => 'Landskod eller namn redan upptaget',
	76 => 'Landet �r �ndrat',
	77 => 'Staten har lagts till',
	78 => 'Staten har tagits bort',
	79 => 'Statkoden eller namn redan upptaget',
	80 => 'Staten har �ndrats',
	81 => 'Stat/omr�de m�ste specificeras',
	82 => 'Inga bilder har laddats upp av denna medlem. ',
	83 => 'Profilen har raderats',
	84 => 'De valda profilerna har raderats.',
	85 => 'Vald(a) profil(er) aktiverad(e).',
	86 => 'Vald(a) profil(er) nekad(e).',
	87 => 'Vald(a) profil(er) stoppad(e).',
	26 => 'Din profil �r inte aktiverad �nnu. <a href=\'completereg.php\'>Aktivera ditt konto</a> genom att fylla i bekr�ftelsekoden eller genom att anv�nda l�nken som finns i det e-postmeddelande som skickades till dig vid registreringen.',
//	26 => 'Ditt partnerkonto �r �nnu ej granskat.<br />V�nligen inv�nta granskning, eller kontakta en administrat�r.',
	35 => 'Din profil �r �nnu ej granskad.<br />V�nligen inv�nta granskning eller kontakta en administrat�r.',

/* Release 1.0 additions/modifications  */
	88 => 'L�net har lagts till',
	89 => 'L�net har tagits bort',
	90 => 'Kommunkod eller namn redan upptaget',
	91 => 'L�net har �ndrats',
	92 => 'Staden har lagts till',
	93 => 'Staden har tagits bort',
	94 => 'Stadskod eller namn redan upptaget',
	95 => 'Staden har �ndrats',
	96 => 'Postnumret har lagts till',
	97 => 'Postnumret har tagits bort',
	98 => 'Postnumret anv�nds redan',
	99 => 'Postnumret har �ndrats',
	100 => 'L�n �r ett obligatoriskt f�lt',
	101 => 'Felaktigt l�senord',
	102 => 'H�ndelsen har blivit godk�nd.',
	103 => 'H�ndelsen godk�ndes inte.',
	111 => 'Medlemmen finns redan med i VIP-listan.',
	130 => 'Videofilen kunde inte konverteras. Var v�nlig anv�nd videofiler av typen .FLV',
	131 => 'Du har �verskridit gr�nsen f�r till�tet antal meddelanden f�r din medlemsniv�.',
	301 => 'Felaktig tidszon',
	302 => 'Albumet har uppdaterats',

/* 1.1.0 additions */
	104 => 'Anv�ndarnamnet hittades inte. Kontrollera att du skrivit r�tt eller anv�nd valen nedan f�r att f� en p�minnelse om ditt l�senord.',
	105 => 'Anv�ndaren �r i ignoreralistan',

	/* Added in 2.0 */
	120 => 'Du m�ste fylla i s�kerhetskoden',
	121 => 'Felaktig s�kerhetskod ',
	122 => 'Du har redan skickat maximalt antal till�tna meddelanden f�r idag. F�rs�k igen imorgon.',
	123 => 'Du har redan skickat maximalt antal till�tna fl�rtar f�r idag. F�rs�k igen imorgon.',
	124 => 'Videofilen har laddats upp',
	125 => 'Videofilen laddades ej upp eftersom uppladdningen misslyckades.',
	126 => 'Du m�ste skriva om dig sj�lv.',
	128 => 'Individuella anv�ndarnamn p� medlemmar i ett par m�ste anges.',
	129 => 'Anv�ndarnamn m�ste redan finnas.',
	201 => 'Du har redan sparat maximalt antal profiler som till�ts i din bevakningslista',
	202 => 'Profilen har lagts till i din bevakningslista',
	203 => 'Profilen finns redan i din bevakningslista',
);

$lang['alphanumeric'] = "0123456789.+-_#,/ABCDEFGHIJKLMNOPQRSTUVWXYZ���abcdefghijklmnopqrstuvwxyz��� ()_";
$lang['alphanum'] = "0123456789_ABCDEFGHIJKLMNOPQRSTUVWXYZ���abcdefghijklmnopqrstuvwxyz��� ";
$lang['text'] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ���abcdefghijklmnopqrstuvwxyz��� '";
$lang['full_chars'] = "0123456789.+-_#,/ABCDEFGHIJKLMNOPQRSTUVWXYZ���abcdefghijklmnopqrstuvwxyz���() _$+=;:?'";

/* Additions  in Version 2.0 */
$lang['save'] = 'Spara';
$lang['delete_zips'] = 'Ta bort postnummer';
$lang['zipcodes_sql_created'] = 'SQL-fil f�r postnummer skapad ';
$lang['zipcodes_loaded'] = 'Postnummer laddat fr�n ';
$lang['delzips_msg'] = 'Alla postnummer f�r detta land kommer att raderas';
$lang['delzips_succ'] = 'Postnummer f�r #COUNTRY# �r raderade';
$lang['wrong_zipfile'] = 'Denna fil tillh�r inte #COUNTRY#';
$lang['load_states'] = 'Behandla statfilen';
$lang['state_ensure'] = 'V�nligen ladda statkodsfilen till katalogen /states innan du k�r funktionen.<br /><br />Filen ska inneh�lla STATKOD och STATNAMN separerade med kommatecken (ingen rubrik)<br /><br /> F�r att radera statkoder f�r ett land, v�lj landet och tryck d�refter p� knappen "Radera statkoder"';
$lang['statefile'] = 'Statkodfil';
$lang['delete_states'] = 'Radera statkoder';
$lang['delstates_msg'] = 'Alla statkoder f�r detta land kommer raderas';
$lang['delstates_succ'] = 'Statkoder f�r #COUNTRY# �r raderade';
$lang['states_sql_created'] = 'SQL-fil f�r statkoder skapad ';
$lang['states_loaded'] = 'Statkoder laddade fr�n ';
$lang['delete_lang'] = 'Ta bort valt spr�k fr�n DB';
$lang['langfile_loaded'] = 'Spr�kdefinitioner f�r #LANGUAGE# har laddats fr�n ';
$lang['lang_deleted'] = 'Spr�kdefinitioner f�r #LANGUAGE# har tagits bort';
$lang['load_counties'] = 'Behandla l�nfil';
$lang['countyfile'] = 'L�nskodfil';
$lang['county_ensure'] = 'Ladda l�nskodsfilen till katalogen /counties innan du k�r funktionen.<br /><br />Filen ska inneh�lla L�NSKOD, L�NSNAMN och STATKOD separerade med komma (i den ordningen, ingen rubrik)<br /><br />F�r att ta bort l�nskoder f�r ett land, v�lj landet och tryck d�refter p� knappen "Ta bort l�nskoder';
$lang['delete_counties'] = 'Ta bort l�nskoder';
$lang['delcounties_msg'] = 'Alla l�nskoder f�r detta land kommer raderas';
$lang['delcounties_succ'] = 'L�nskoder f�r #COUNTRY# �r raderade';
$lang['counties_sql_created'] = 'SQL-fil f�r l�nskoder skapad ';
$lang['counties_loaded'] = 'L�nskoder laddas fr�n ';
$lang['load_cities'] = 'Behandla stadsfil';
$lang['cityfile'] = 'Stadskodfil';
$lang['city_ensure'] = 'Ladda stadskodsfilen til katalogen /cities innan du k�r funktionen.<br /><br />Filen ska inneh�lla STADSKOD, STADSNAMN, L�NSKOD och STATKOD separerade med kommatecken (i den ordningen, ingen rubrik)<br /><br /> F�r att ta bort, tryck p� knappen "Ta bort stadskoder".';
$lang['delete_cities'] = 'Ta bort stadskoder';
$lang['delcities_msg'] = 'Alla stadskoder kommer att raderas';
$lang['delcities_succ'] = 'Stadskoder f�r #COUNTRY# �r raderade';
$lang['cities_sql_created'] = 'SQL-fil f�r stadskoder skapad ';
$lang['cities_loaded'] = 'Stadskoder laddas fr�n ';
$lang['online'] = 'Inloggad';
$lang['watchedprofiles_1'] = 'L�gg till i bevakade profiler';
$lang['watchedprofiles'] = 'Bevakade profiler';
$lang['poll'] = 'Omr�stning';
$lang['section_poll_title'] = 'Omr�stning';
$lang['section_poll_list'] = 'Lista omr�stningar';
$lang['section_add_poll'] = 'Skapa omr�stning';
$lang['poll_subtitle_list'] = 'Lista omr�stningar';
$lang['poll_subtitle_add'] = 'Skapa omr�stning';
$lang['poll_subtitle_edit'] = '�ndra omr�stning';
$lang['poll_number'] = 'Nummer';
$lang['poll_active_hdr'] = 'Aktiv';
$lang['poll_question_hdr'] = 'Fr�gor';
$lang['poll_responses_hdr'] = 'Svar';
$lang['no_poll_found'] = 'Inga omr�stningar hittades';
$lang['poll_question'] = 'Fr�ga';
$lang['poll_options'] = 'Val';
$lang['poll_active'] = 'Aktiv';
$lang['poll_minimum_two'] = 'Minst tv� kr�vs.';
$lang['results_poll_title'] = 'Resultat';
$lang['poll_subtitle_results'] = 'Omr�stningsresultat';
$lang['take_poll_title'] = 'R�sta';
$lang['poll_entries'] = 'R�sta';
$lang['plugin'] = 'Instick';
$lang['plugin_access'] = 'Medlemskaps�tkomst';
$lang['section_plugin_title'] = 'Instick';
$lang['section_plugin_list'] = 'Instickslista';
$lang['section_add_plugin'] = 'Ladda instick';
$lang['plugin_subtitle_list'] = 'Instickslista';
$lang['plugin_number'] = 'Nummer';
$lang['plugin_name'] = 'Namn';
$lang['plugin_active'] = 'Aktiv';
$lang['plugin_installed'] = 'Installerad';
$lang['plugin_install'] = 'Installera';
$lang['no_plugin_found'] = 'Inga instick hittades';
$lang['plugin_file'] = 'Ladda upp instick';
$lang['plugin_subtitle_edit'] = '�ndra instick';
$lang['add_plugin_summary'] = 'Dokumentation hur du skriver ett instick (plugin) finns i din osDate-installation.';

$lang['blog']['hdr'] = 'Blog';
$lang['admin_blog'] = 'Sajtblog';
$lang['blog_default_bad_words'] = 'xxx|levitra|kuk|r�v';
$lang['blog_bad_words'] = 'Otill�tna ord';
$lang['blog_save_template'] = 'Spara som mall';
$lang['blog_load_template'] = 'Ladda mall';
$lang['blog_bad_words_help'] = '(ett ord per rad)';
$lang['blog_search_results'] = 'S�kresultat';
$lang['section_blog_info'] = 'Bloginst�llningar';
$lang['section_blog_list'] = 'Bloggar';
$lang['section_blog_title'] = 'Blog';
$lang['blog_search_menu'] = 'S�k blog';
$lang['blog_search_username'] = 'Anv�ndarnamn';
$lang['blog_search_title'] = 'Titel';
$lang['blog_search_body'] = 'Text';
$lang['blog_search_Date'] = 'Datum';

$lang['blog_subtitle_list'] = 'Bloglista';
$lang['blog_name'] = 'Blognamn';
$lang['blog_description'] = 'Blogbeskrivning';
$lang['blog_members_comment'] = 'Medlemmars kommentar';
$lang['blog_buddies_comment'] = 'V�nners kommentarer';
$lang['blog_members_vote'] = 'Medlemsr�stning';
$lang['blog_gui_editor'] = 'WYSIWYG-editor';
$lang['blog_max_comments'] = 'Max antal kommentarer';
$lang['no_blog_found'] = 'Inga inl�gg hittades';
$lang['section_add_blog'] = 'Skapa inl�gg i bloggen';
$lang['blog_subtitle_add'] = 'Skapa inl�gg i bloggen';
$lang['blog_subtitle_edit'] = '�ndra blog';
$lang['blog_title'] = 'Titel';
$lang['blog_story'] = 'Inneh�ll';
$lang['blog_posted_date'] = 'Datum';
$lang['blog_title_hdr'] = 'Titel';
$lang['blog_rating_list_hdr'] = 'Betyg';
$lang['blog_number'] = 'Nummer';
$lang['blog_date_posted_hdr'] = 'Datum';
$lang['blog_views_hdr'] = 'Bes�k';
$lang['blog_votes_hdr'] = 'Betyg';
$lang['blog_votes1'] = 'betyg';
$lang['blog_rating_hdr'] = 'baserat p�';
$lang['blog_submit_vote'] = 'R�sta';
$lang['blog_add_vote'] = 'R�sta nu';
$lang['view_blog'] = 'Visa blog';
$lang['blog_entries'] = 'Blog:';
$lang['blog_creator'] = 'F�rfattare';
$lang['blog_comments'] = 'Kommentar';
$lang['add_comment'] = 'Dina kommentarer';
$lang['total_blogs_found'] = 'Antal bloggar hittade:';

$lang['blog_errors'] = array(
   'nosetup' 			=> 'Grundinst�llningar f�r blog saknas.',
   'name_noblank'		=> 'Du m�ste fylla i ett namn.',
   'description_noblank'	=> 'Du m�ste fylla i en beskrivning.',
   'date_posted_noblank'	=> 'Du m�ste fylla i ett datum.',
   'title_noblank'		=> 'Du m�ste fylla i en titel.',
   'story_noblank'		=> 'En ber�ttelse f�r inte vara tom.',
   'max_stories_warning'	=> 'Du har uppn�tt maximalt antal ber�ttelser och kan inte skriva fler.',
   'comment_bad_word'		=> 'Din kommentar inneh�ller de otill�tna orden %s',
);

$lang['spell_check'] = 'Stavningskontroll';
$lang['manage_import_webdate'] = 'Importera fr�n Webdate';
$lang['import_config'] = 'Inst�llning';

$lang['forum_values'] = array(
   'None' => 'Ingen',
   'phpBB' => 'phpBB',
   'vBulletin' => 'vBulletin',
   'myBB' => 'myBB',
   'Phorum' => 'Phorum',
);

$lang['photos_url'] = 'Adress till hemsida:';
$lang['ftp_username'] = 'FTP-anv�ndarnamn:';
$lang['ftp_password'] = 'FTP-l�senord:';
$lang['ftp_hostname'] = 'FTP-URL:';
$lang['ftp_path'] = 'FTP aeDating:';
$lang['ftp_path_help'] = 'S�kv�g till aeDating-katalog n�r du �r inloggad via FTP. Till exempel: public_html/aeDating.';
$lang['nopicsloaded'] = 'Inga bilder';
$lang['loadedpicscnt'] = '#PICSCNT# bild(er)';
$lang['loadedpicscnt1'] = '#PICSCNT# bild';
$lang['picsloaded'] = 'Bilder laddade';
$lang['since'] = 'sedan';
$lang['unknown'] = 'Ok�nd';

$lang['glblsettings_groups'] = array(
1	=>	'Sajtinfo',
2	=> 	'Anv�ndarkontroller',
3	=>	'Kalenderkontroller',
4	=>	'E-postinst�llningar',
5	=>	'Profilbilder och miniatyrer',
6	=>	'Sid- och tabell-layout',
);

$lang['who_is_online'] = 'Endast inloggade medlemmar';
$lang['search_with_photo'] = 'Endast medlemmar med foton';
$lang['search_with_video'] = 'Endast medlemmar med videofilmer';
$lang['expire_on_hdr'] = 'Utg�r';
$lang['expird'] = 'Utg�tt';
$lang['pics'] = 'Bilder';
$lang['pic_deleted'] = 'Det valda fotot har tagits bort';
$lang['entrycode_chars'] = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
$lang['enter_spamcode'] = 'S�kerhetskod';

/* Admin emails portion */

$lang['newpic_sub'] = 'SITENAME Meddelande: Ny bild fr�n anv�ndare ';
$lang['newpic']['html'] ='<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td class="module_head" width="100%" height="25"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25"><div class="module_head">#email_hdr_left#</div>
</td><td width="493" height="25"><div class="module_head">&nbsp;&nbsp;Ny bild fr�n anv�ndare</div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" ><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="1"></td></tr><tr><td width="50%" valign="top" class="evenrow" >K�ra sajt�gare,
<br><br>Anv�ndaren <a href="#SiteUrl#admin/showprofile.php?username=#UserName#">#UserName#</a> har laddat upp en ny bild.<br><br>Anv�ndarnamn: #UserName#<br>Bildnummer: #PicNo#<br><br>#AdminName# <br>SITENAME<br></td><td valign="top" class="evenrow" align="cemter">#smallPic#
</td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['newpic']['text'] = "K�ra sajt�gare,

Anv�ndaren #UserName# har laddat upp en ny bild.

Anv�ndare: #UserName#

Bildnummer: #PicNo#

#AdminName#
SITENAME";


$lang['newvideo_sub'] = 'SITENAME Meddelande: Ny video fr�n anv�ndare ';

$lang['newvideo']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25"><div class="module_head">#email_hdr_left#</div>
</td><td width="493" height="25"><div class="module_head">&nbsp;&nbsp;Ny video fr�n anv�ndare </div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" ><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">K�ra sajt�gare,<br><br>Anv�ndaren #UserName# har laddat upp en ny video. <br><br>Anv�ndarnamn: #UserName#<br>Videonummer: #PicNo#<br><br>#AdminName#<br>SITENAME<br></td>
</tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['newvideo']['text'] = "K�ra sajt�gare,

Anv�ndaren #UserName# har laddat upp en ny video.

Anv�ndare: #UserName#

Videonummer: #PicNo#

#AdminName#
SITENAME";

/* Modified in 2.0 */

$lang['payment_msg1'] = 'Tillg�ngliga betals�tt';
$lang['wrong_activationcode'] = 'Fel bekr�ftelsekod.';
$lang['security_code_txt'] = 'L�s texten i bilden nedan och skriv in denna i f�ltet intill.';
$lang['additional_pics'] = 'Ytterligare bilder';
$lang['view_all_pics'] = 'Se alla bilder';
$lang['insufficientPrivileges'] = 'Du saknar beh�righet f�r att utf�ra denna �tg�rd. Du m�ste uppgradera ditt medlemskap.';
$lang['username_part_msg'] = "Om du �r os�ker p� anv�ndarnamnet, skriv in en valfri del av namnet f�r att visa alla m�jliga tr�ffar. Till exempel, texten korv kommer att ge tr�ffar p� 'korv123', 'sunes_korv', etc.";
$lang['featured_profiles_msg01'] = "M�ste visas: 'Ja' ger denna profil f�rtur att presenteras i VIP-listan. 'Nej' reducerar chansen att profilen v�ljs ut.";
$lang['featured_profiles_msg02'] = "Krav p� exponering: Detta �r antalet exponeringar som kr�vs innan den h�r profilen kan tas bort ur VIP-listan om antalet exponeringar uppn�s f�re stoppdatumet.";
$lang['lookup'] = 'H�mta';

/* for use in shoutbox */
$lang['sb_by'] = 'Skrivet av:';
$lang['sb_hdr'] = 'Klotterplank';
$lang['sb_send'] = 'Skicka';
$lang['sb_error'] = 'Texten �verskrider till�ten l�ngd';
$lang['sb_msg_blank'] = 'Tomt meddelande i klotterplanket?';
$lang['sb_show_all'] = 'Visa alla';
$lang['upload_videos'] = 'Ladda upp video';
$lang['videoupload_format_msgs'] = 'Enbart .swf eller .flv �r till�tna.';
$lang['video'] = 'Video';
$lang['upload_videos_ext'] = 'flv, swf';
$lang['upload_video_caption'] = 'Ladda upp video';
$lang['video_file'] = 'Videofil';
$lang['vds'] = 'Vds';
$lang['manage_videos'] = 'Hantera videos';
$lang['videos_loaded'] = 'Videos laddade';
$lang['novideos_loaded'] = 'Inga videos';
$lang['loadedvdocnt'] = '#PICSCNT# video(s)';
$lang['loadedvdocnt1'] = '#PICSCNT# video';
$lang['video_gallery'] = 'Videogalleri';
$lang['picture_gallery'] = 'Bildgalleri';


/* New timezone display values Modified in 2.0 */
// These are displayed in the timezone select box
$lang['tz']['-25'] = '-- V�lj --';
$lang['tz']['-12.00'] = '(GMT -12:00) Eniwetok, Kwajalein';
$lang['tz']['-11.00'] = '(GMT -11:00) Midway Island, Samoa';
$lang['tz']['-10.00'] = '(GMT -10:00) Hawaii';
$lang['tz']['-9.00'] = '(GMT -9:00) Alaska';
$lang['tz']['-8.00'] = '(GMT -8:00) Pacific Time (US & Canada)';
$lang['tz']['-7.00'] = '(GMT -7:00) Mountain Time (US & Canada)';
$lang['tz']['-6.00'] = '(GMT -6:00) Central Time (US & Canada), Mexico City';
$lang['tz']['-5.00'] = '(GMT -5:00) Eastern Time (US & Canada), Bogota, Lima';
$lang['tz']['-4.00'] = '(GMT -4:00) Atlantic Time (Canada), Caracas, La Paz';
$lang['tz']['-3.5'] = '(GMT -3:30) Newfoundland';
$lang['tz']['-3.00'] = '(GMT -3:00) Brazil, Buenos Aires, Georgetown';
$lang['tz']['-2.00'] = '(GMT -2:00) Mid-Atlantic';
$lang['tz']['-1.00'] = '(GMT -1:00 hour) Azores, Cape Verde Islands';
$lang['tz']['0.00'] = '(GMT) Western Europe Time, London, Lisbon, Casablanca';
$lang['tz']['1.00'] = '(GMT +1:00 hour) Brussels, Copenhagen, Madrid, Paris';
$lang['tz']['2.00'] = '(GMT +2:00) Kaliningrad, South Africa';
$lang['tz']['3.00'] = '(GMT +3:00) Baghdad, Riyadh, Moscow, St. Petersburg';
$lang['tz']['3.5'] = '(GMT +3:30) Tehran';
$lang['tz']['4'] = '(GMT +4:00) Abu Dhabi, Muscat, Baku, Tbilisi';
$lang['tz']['4.5'] = '(GMT +4:30) Kabul';
$lang['tz']['5.00'] = '(GMT +5:00) Ekaterinburg, Islamabad, Karachi, Tashkent';
$lang['tz']['5.5'] = '(GMT +5:30) Bombay, Calcutta, Madras, New Delhi';
$lang['tz']['6.00'] = '(GMT +6:00) Almaty, Dhaka, Colombo';
$lang['tz']['6.5'] = 'GMT + 6.30) ';
$lang['tz']['7.00'] = '(GMT +7:00) Bangkok, Hanoi, Jakarta';
$lang['tz']['8.00'] = '(GMT +8:00) Beijing, Perth, Singapore, Hong Kong';
$lang['tz']['9'] = '(GMT +9:00) Tokyo, Seoul, Osaka, Sapporo, Yakutsk';
$lang['tz']['9.5'] = '(GMT +9:30) Adelaide, Darwin';
$lang['tz']['10.00'] = '(GMT +10:00) Eastern Australia, Guam, Vladivostok';
$lang['tz']['11.00'] = '(GMT +11:00) Magadan, Solomon Islands, New Caledonia';
$lang['tz']['12.00'] = '(GMT +12:00) Auckland, Wellington, Fiji, Kamchatka';
$lang['tz']['13.00'] = '(GMT + 13)';

$lang['myprofile'] = 'Min profil';
$lang['myblog'] = 'Min blog';
$lang['profilesearch'] = 'S�k profil';
$lang['mylists'] = 'Mina listor';
$lang['bans'] = 'Ignoreralistan';
$lang['mybuddies'] = 'Kompislistan';
$lang['hotprofiles'] = 'Intresselistan';
$lang['winks'] = 'Fl�rtar';
$lang['tools'] = 'Verktyg';
$lang['picturegallery'] = 'Mitt bildgalleri';
$lang['videogallery'] = 'Mitt videogalleri';
$lang['membership'] = 'Mitt medlemskap';
$lang['adminhome'] = 'Admin-hem';
$lang['membershdr'] = 'Medlemmar';
$lang['memberprofiles'] = 'Medlemsprofiler';
$lang['membersearch'] = 'S�k medlemmar';
$lang['blogs'] = 'Bloggar';
$lang['blogsearch'] = 'S�k bloggar';
$lang['affiliateshdr'] = 'Partners';
$lang['localities'] = 'Placering';
$lang['contenthdr'] = 'Inneh�ll';
$lang['financial'] = 'Finansiell';
$lang['plugins_hlp'] = 'Administrativa instick anv�nds enbart av administrat�rer och moderatorer med tillr�cklig beh�righet. Instick f�r medlemmar �r tillg�ngliga via medlemspanelen.';

/* HTML and some text emails */

$lang['no_thanks_message']['html'] = 'Hej #recipient_username#,<br><br>Tack f�r visat intresse, men jag m�ste tyv�rr avb�ja. Jag hoppas att du hittar din dr�mdejt p� #site_name# till slut.<br><br>B�sta �nskningar,<br><br>#sender_username#';
$lang['mail']['hdr_text'] = '<font style="color:red; font-size: 9px;">Vill du inte f� denna typ av e-post i forts�ttningen? <a href="#SiteUrl#">Logga in</a> och �ndra dina e-postinst�llningar.<br />F�r att vara s�ker p� att du f�r denna e-post, l�gg till <a href="mailto:#AdminEmail#">#AdminEmail#</a> till din adressbok nu p� en g�ng.</font><br /><br />';
$lang['mail']['hdr_html'] = '<table border=0 cellspacing=0 cellpadding=0 width="570"><tr><td style="padding: 5px;"><font style="color:red; font-size: 9px;">Vill du inte f� denna typ av e-post i forts�ttningen? <a href="#SiteUrl#">Logga in</a> och �ndra dina e-postinst�llningar.<br />F�r att vara s�ker p� att du f�r denna e-post, l�gg till <a href="mailto:#AdminEmail#">#AdminEmail#</a> till din adressbok nu p� en g�ng.</font></td></tr><tr><td height="6"></td></tr></table>';
$lang['letter_winkreceived_sub'] = 'SITENAME Meddelande: #SenderName# har skickat dig en fl�rt! ';

$lang['wink_received']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25px">#email_hdr_left#</td><td width="493" height="25" ><div class="module_head">&nbsp;&nbsp;#SenderName# fl�rtar med dig!</div>
</td></tr></table></div></td></tr><tr><td width="570" class="evenrow" colspan="2" ><div class="evenrow" ><table border="0" cellspacing="2" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="50%" valign="top">#smallProfile#</td><td width="50%" valign="top">#SenderName# har valt att fl�rta med dig! H�ll fl�rten vid liv genom att skicka en fl�rt tillbaka, eller skicka ett meddelande.<br><br><a href="#SiteUrl#compose.php?recipient=#UserId#">Skicka ett meddelande till #SenderName#</a><br><br><a href="#SiteUrl#sendwinks.php?ref_id=#UserId#&amp;rtnurl=showprofile.php">Skicka en fl�rt tillbaka</a><br>
<br><b>Inte intresserad?</b><br>Skicka ett "Nej Tack" till #SenderName#.<br><br><a href="#SiteUrl#compose.php?recipient=#UserId#&amp;reply=11">Tacka nej</a><br><br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['profile_confirmation_email_sub'] = 'SITENAME Meddelande: Tack f�r att du har registrerat dig p� SITENAME!';
$lang['profile_confirmation_email']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570">
<tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%">
<tr><td width="77" height="25" >#email_hdr_left#</td><td width="493"  height="25"><div class="module_head">&nbsp;&nbsp;#Welcome#!</div></td></tr></table></div></td></tr><tr><td width="570" class="evenrow" colspan="2" >
<div class="evenrow" ><table border=0 cellspacing=0 cellpadding=5 width="100%"><tr><td>K�ra #FirstName#,<br><br>Tack f�r att du har valt att registrera dig p� #siteName#! Som ny medlem i detta community s� rekommenderar vi att du utforskar alla v�ra tj�nster och funktioner.<br><br>Klicka p� l�nken nedan f�r att bekr�fta din registrering. Om du inte kan klicka p� l�nken s� kan du sj�lv kopiera in den i din webbl�sares adressf�lt.<br><br>
<a href=\"#ConfirmationLink#=#ConfCode#\">#ConfirmationLink#=#ConfCode#</a><br><br>Om du fortfarande har det avslutande steget i registreringen �ppet s� kan du �ven mata in bekr�ftelsekoden direkt p� sidan.<br><br>Din bekr�ftelsekod �r: <b>#ConfCode#</b><br><br>Vi har registrerat f�ljande kontouppgifter:<br><br>Anv�ndarnamn: <b>#StrID#</b><br>L�senord: <b>#Password#</b><br>E-postadress: <b>#Email#</b><br><br>
F�rvara uppgifterna p� ett s�kert s�tt, s� att du utan problem kan komma �t all information som finns tillg�nglig f�r dig hos oss.
Vissa utav v�ra tj�nster kan kr�va att du uppgraderar ditt konto till en h�gre medlemsniv�. Klicka p� l�nken nedan om du �nskar uppgradera ditt konto nu:<br><br><a href="#SiteUrl#payment.php">#Upgrade#</a><br><br>Vi tackar �n en g�ng f�r att du har valt att anv�nda dig av v�ra tj�nster, och �nskar dig lycka till med dejtandet! <br><br>
#AdminName#<br>#siteName#</td></tr></table></div></td></tr>
<tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['message_received_sub'] = 'SITENAME Message: RE: bara ett tips...';
$lang['message_received']['text'] = "K�ra #FirstName#,

Du har f�tt ett nytt meddelande fr�n '#SenderName#' p� SITENAME.

G� till <a href=\"#link#\">SITENAME</a> f�r att svara p� detta meddelande.

Lycka till!

#AdminName#
SITENAME";

$lang['message_received']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25"><div class="module_head">
#email_hdr_left#</div></td><td width="493" ><div class="module_head">&nbsp;&nbsp;Du har f�tt ett nytt meddelande fr�n #SenderName#! </div></td></tr></table></div></td></tr><tr><td width="570" class="evenrow" colspan="2" ><div class="evenrow" ><table border="0" cellspacing="2" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="50%" valign="top" class="evenrow">
<table width="100%" border=0 cellspacing=0 cellpadding=0><tr><td width="25%" ><div class="newshead">#From#:</div></td><td width="75%">#SenderName#</td></tr><tr><td><div class="newshead">#TO#:</div></td><td>#UserName#</td></tr><tr><td  >
<div class="newshead">#Date#:</div></td><td>#MESSAGE_DATE# </td></tr><tr><td ><div class="newshead">#Subject#:</div></td><td>#MSG_SUBJECT#</td></tr><tr><td colspan="2" height="6">
</td></tr><tr><td colspan=2>K�ra #FirstName#,<br><br>Du har f�tt ett nytt meddelande fr�n #SenderName#.<br><br>Bes�k <a href=\"#link#\">SITENAME</a> f�r att svara p� detta meddelande.<br><br>Lycka till!<br>#AdminName#<br>SITENAME<br></td></tr></table>
</td><td width="50%" valign="top" class="oddrow"><div class="oddrow">#smallProfile#</div></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';


$lang['letter_featuredprofile_sub'] = 'SITENAME Meddelande: Din profil kommer snart att vara en VIP-profil!';

$lang['featured_profile_added']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr>
<td width="77" height="25" ><div class="module_head">#email_hdr_left#</div>
</td><td width="493" ><div class="module_head">&nbsp;&nbsp;Din profil kommer snart att vara en VIP-profil! </div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" >
<div class="evenrow"><table border="0" cellspacing="0" cellpadding="5"><tr><td width="100%" valign="top" class="evenrow">K�ra #FirstName#,<br><br>
Vi har gl�djen att informera dig om att din profil har valts ut att ing� i v�r lista �ver VIP-profiler p� <a href=\"#link#\">SITENAME</a>.<br><br>Din profil ing�r i listan under perioden <b>#FromDate#</b> till <b>#UptoDate#</b>.<br>
<br>Detta kommer att �ka din profils exponering och kan leda till fler bes�k fr�n potentiella dejter.<br><br>Lycka till!<br>#AdminName# <br>SITENAME<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';


$lang['profile_activated_sub'] = 'SITENAME Meddelande: Din profil �r aktiverad!';

$lang['profile_activated']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" ><div class="module_head">
#email_hdr_left#</div></td><td width="493"><div class="module_head">&nbsp;&nbsp;Din profil �r aktiverad!</div></td></tr></table></div></td></tr><tr>
<td width="100%" class="evenrow" colspan="2"><div class="evenrow"><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr>
<tr><td width="100%" valign="top" class="evenrow">K�ra #FirstName#,<br><br>V�lkommen till SITENAME.<br><br>Din profil har aktiverats. Din aktuella medlemsniv� <b>#MembershipLevel#</b> g�ller fram till #ValidDate#.<br><br>Bes�k oss p� <a href=\"#link#\">SITENAME</a>.<br>
<br>Lycka till!<br>#AdminName# <br>SITENAME<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['profile_activated']['text'] = "K�ra #FirstName#,

V�lkommen till SITENAME.

Din profil �r aktiverad med niv�n <b>#MembershipLevel#</b> och godk�nd till <b>#ValidDate#</b>.

Bes�k oss p� <a href=\"#link#\">SITENAME</a>.

Lycka till!

#AdminName#

SITENAME";


$lang['profile_reactivated_sub'] = 'SITENAME Meddelande: Din profil �r �teraktiverad!';
$lang['profile_reactivated']['text'] = "K�ra #FirstName#,

Vi �r glada att meddela dig att din profil �r �teraktiverad till niv�n <b>#MembershipLevel#</b> och g�ller till <b>#ValidDate#</b>.

Bes�k oss p� <a href=\"#link#\">SITENAME</a>.

Lycka till!

#AdminName#

SITENAME";

$lang['profile_reactivated']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head">
<div class="module_head">#email_hdr_left#</div></td><td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;Din profil har aktiverats p� nytt! </div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2">
<div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">K�ra #FirstName#,<br><br>Din profil har aktiverats p� nytt med medlemsniv� <b>#MembershipLevel#</b> som g�ller till <b>#ValidDate#</b>.<br>
<br>Bes�k oss <a href=\"#link#\">SITENAME</a>.<br><br>Lycka till!<br>#AdminName# <br>SITENAME<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';


$lang['added_list_sub'] = "SITENAME Meddelande: Du har blivit tillagd i #SenderName#'s #ListName#!";

$lang['added_list']['text'] = "K�ra #FirstName#,

Medlemmen #SenderName# har just lagt till dig i sin #ListName#.

F�r att bes�ka anv�ndarens profil, logga in p� <a href=\"#link#\">SITENAME</a>.

Lycka till!

#AdminName#

SITENAME";

$lang['added_list']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25px" class="module_head">
<div class="module_head">#email_hdr_left#</div></td><td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;#SenderName# har lagt till dig i sin #ListName#!</div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" >
<div class="evenrow"><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="50%" valign="top" class="evenrow">K�ra #FirstName#,<br><br><b>#SenderName#</b> har lagt till dig i sin <b>#ListName#</b>.<br><br>F�r att titta p� anv�ndarens profil, bes�k <a href=\"#link#\">SITENAME</a>.<br><br>Lycka till!<br>#AdminName# <br>SITENAME<br></td><td valign="top">#smallProfile#</td>
</tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['invite_a_friend_sub'] = "SITENAME Meddelande: Inbjudan fr�n #FromName#!";

$lang['invite_a_friend']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="27" class="module_head" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" valign="top" ><div class="module_head" >#email_hdr_left#</div>
</td>
<td width="493" ><div class="module_head" >&nbsp;&nbsp;Inbjudan fr�n #FromName#!</div></td></tr></table></div></td></tr><tr><td width="100%" colspan="2" ><div class="evenrow"><table border="0" cellspacing="0" cellpadding="5" width="100%"><tr><td height="1"></td></tr><tr><td width="100%" valign="top" class="evenrow">Hej,<br><br>Jag s�g denna dejtingsajt p� n�tet: <a href=\"#SiteUrl#\"><b>SITENAME</b></a><br>Jag tror att den kan vara n�got f�r dig.<br>
<br>Bes�k <a href=\"#SiteUrl#\">SITENAME</a>.<br><br>Lycka till!<br>#FromName# <br><br></td></tr></table></div>
</td></tr><tr><td height="6" class="evenrow" colspan="2" ></td></tr></table>';



$lang['message_read_sub'] = 'SITENAME Meddelande: Ditt meddelande till #RecipientName# har blivit l�st!';

$lang['message_read']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25">
<div class="module_head">#email_hdr_left#</div></td><td width="493" ><div class="module_head">&nbsp;&nbsp;Ditt meddelande till #RecipientName# har blivit l�st! </div></td></tr></table></div></td></tr>
<tr><td width="100%" class="evenrow" colspan="2" >
<div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="50%" valign="top" class="evenrow">K�ra #FirstName#,<br><br>Ditt meddelande till <b>#RecipientName#</b> har blivit l�st.<br><br>F�r att titta p� den h�r anv�ndarens profil, bes�k <a href=\"#link#\">SITENAME</a>.<br><br>Lycka till!<br>#AdminName# <br>SITENAME<br></td>
<td valign="top">#smallProfile#</td></tr></table>
</div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['email_feedback_subject'] = 'SITENAME Meddelande: Feedback fr�n anv�ndare';

$lang['feedback_email_to_admin']['text'] = 'K�ra sajt�gare,

Du har just f�tt feedback fr�n en anv�ndare:

Titel: #txttitle#

Namn: #txtname#

E-postadress: #txtemail#

Land: #txtcountry#

Kommentar: #txtcomments#

Tack,
SITENAME Daemon';

$lang['feedback_email_to_admin']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25"><div class="module_head">
#email_hdr_left#</div></td><td width="493"><div class="module_head">&nbsp;&nbsp;Feedback fr�n anv�ndare <div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" ><div class="evenrow" >
<table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr>
<tr><td width="100%" valign="top" class="evenrow">K�ra sajt�gare,<br><br>Du har f�tt f�ljande meddelande fr�n en anv�ndare p� din webbplats:<br><br><table cellspacing="4" cellpadding="2" border="0" width="100%"><tr><td width="20%"> Titel:</td><td width="80%">#txttitle# </td></tr><tr><td>Namn:</td> <td>#txtname#</td></tr>
<tr><td>E-postadress:</td><td>#txtemail#</td></tr><tr><td>Land:</td><td>#txtcountry#</td></tr><tr><td>Meddelande:</td><td>#txtcomments#</td></tr></table><br>Tack,<br>#siteName# Daemon<br><br></td></tr></table></div></td></tr></table> ';



$lang['forgot_password_sub'] = 'SITENAME Meddelande: Ditt l�senord har �terst�llts';

$lang['forgot_password']['text'] = "K�ra #Name#,

Ditt l�senord �r nu �ndrat.

Ditt medlems-ID: #ID#

Ditt nya l�senord: #Password#

F�r att logga in, g� till #LoginLink#.

Tack f�r att du anv�nder v�ra tj�nster!


#AdminName#

SITENAME";

$lang['forgot_password']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head"><div class="module_head">#email_hdr_left#</div></td>
<td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;Ditt nya l�senord</div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" ><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">K�ra #Name#,<br>
<br>Du har beg�rt ett nytt l�senord p� SITENAME.<br><br>Ditt anv�ndarnamn: <b>#ID#</b><br>Ditt nya l�senord: <b>#Password#</b><br><br>F�r att logga in, g� hit: <a href=\"#LoginLink#\">SITENAME</a>.<br><br>Tack f�r att du anv�nder v�ra tj�nster!<br><br>#AdminName#<br>SITENAME<br></td></tr> </table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['expiry_ltr_sub'] = 'SITENAME Meddelande: P�minnelse om upph�rande medlemskap';
$lang['mship_expired_note']['text'] = "K�ra #FirstName#,

Tack f�r att du anv�nt SITENAME!

Detta meddelande bekr�ftar att medelmskapsniv�n #MembershipLevel# p� SITENAME upph�rde att g�lla #ExpiryDate#.

V�nligen <a href=\"#link#\">logga in p� SITENAME</a> f�r att f�rnya och forts�tta anv�nda v�ra tj�nster.

Lycka till!

#AdminName#

SITENAME";



$lang['mship_expired_note']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head"><div class="module_head">#email_hdr_left#</div></td>
<td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;Ditt medlemskap har g�tt ut </div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" ><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">K�ra #FirstName#,<br>
<br>Tack f�r att du har anv�nt v�r tj�nster p� SITENAME!<br><br>Detta meddelande bekr�ftar att ditt medlemskap med med niv�n #MembershipLevel# p� <a href="\"#link#\"><b>SITENAME</b></a> upph�rt att g�lla <b>#ExpiryDate#</b>.<br><br>Var v�nlig <a href=\"#link#\">logga in p� SITENAME</a> f�r att f�rnya ditt medlemskap om du �nskar forts�tta anv�nda v�ra tj�nster.<br><br>Lycka till!<br>#AdminName# <br>SITENAME<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';



$lang['mship_expiry_note']['text'] = "K�ra #FirstName#,

Tack f�r att du anv�nder SITENAME!

Detta meddelande bekr�ftar att din medlemsniv� #MembershipLevel# p� SITENAME kommer att upph�ra #ExpiryDate#.

V�nligen <a href=\"#link#\">logga in p� SITENAME</a> f�r att f�rnya och forts�tta att anv�nda v�ra tj�nster.

Lycka till!

#AdminName#

SITENAME";

$lang['mship_expiry_note']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head">
<div class="module_head">#email_hdr_left#</div></td><td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;Ditt medlemskap g�r snart ut</div></td></tr></table></div></td></tr>
<tr><td width="100%" class="evenrow" colspan="2" ><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">K�ra #FirstName#,<br><br>Tack f�r att du anv�nder v�ra tj�nster p� SITENAME!<br><br>Vi vill h�rmed p�minna dig om att ditt medlemskap med niv�n <b>#MembershipLevel#</b> p� <a href="\"#link#\"><b>SITENAME</b></a> kommer att g� ut <b>#ExpiryDate#</b>.<br><br>Var v�nlig <a href=\"#link#\">logga in p� SITENAME</a> f�r att f�rnya ditt medlemskap om du �nskar forts�tta anv�nda v�ra tj�nster.<br>
<br>Lycka till!<br>#AdminName# <br>SITENAME<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';


/* Newly added - mail to be sent to member when admin changes membership level */



$lang['profile_membership_changed_sub'] = 'SITENAME Meddelande: Din medlemsniv� har �ndrats!';

$lang['profile_membership_changed']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head">
<div class="module_head">#email_hdr_left#</div></td><td width="493" class="module_head" height="25"><div class="module_head">&nbsp;&nbsp;Din medlemsniv� har �ndrats! </div></td></tr></table></div></td></tr>
<tr><td width="100%" class="evenrow" colspan="2"><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">K�ra #FirstName#,<br><br>Din nuvarande medlemsniv� <b>#CurrentLevel#</b> har �ndrats till <b>#NewLevel#</b>, och g�ller fram till <b>#ValidDate#</b>.<br>
<br>Bes�k <a href=\"#link#\">SITENAME</a>.<br><br>Lycka till!<br>#AdminName# <br>SITENAME<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['profile_membership_changed']['text'] = "K�ra #FirstName#,

Din medlemsniv� <b>#CurrentLevel#</b> har �ndrats till <b>#NewLevel#</b>. Den nya medlemsniv� g�ller tom <b>#ValidDate#</b>.

Bes�k oss nu p� <a href=\"#link#\">SITENAME</a>.

Lycka till!

#AdminName#

SITENAME";



$lang['comment_received_sub'] = 'SITENAME Meddelande: En anv�ndare har just kommenterat din blog!';

$lang['comment_received']['text'] = "K�ra #FirstName#,

Du har f�tt en kommentar p� SITENAME fr�n '<b>#SenderName#</b>'.

Bes�k <a href=\"#link#\"><b>SITENAME</b></a> f�r att se kommentaren.

Lycka till!

#AdminName#

SITENAME";

$lang['comment_received']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head"><div class="module_head">#email_hdr_left#</div></td><td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;En anv�ndare har l�mnat en kommentar i din blogg</div></td></tr></table></div></td></tr>
<tr><td width="100%" class="evenrow" colspan="2"><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">K�ra #FirstName#,<br><br>Du har precis f�tt en kommentar fr�n <b>#SenderName#</b> i din blogg p� SITENAME.<br><br>Bes�k <a href=\"#link#\"><b>SITENAME</b></a> f�r att l�sa kommentaren.<br>
<br>Lycka till!<br>#AdminName# <br>SITENAME<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';


$lang['aff_added_sub'] = 'SITENAME Meddelande: Du �r nu upplagd som partner!';

$lang['aff_added']['text'] = "K�ra #Name#,

Vi �r glada �ver att informera dig om att du nu �r en partner till SITENAME.


Ditt ID: #Affid#

Ditt l�senord: #Password#

Bes�k <a href=\"#SiteUrl#\"><b>SITENAME</b>/a> och logga in p� partnersektionen och �ndra ditt l�senord snarast.

Lycka till!

#AdminName#

SITENAME";


$lang['aff_added']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head"><div class="module_head">#email_hdr_left#</div></td><td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;V�lkommen som partner! </div></td></tr></table></div></td></tr>
<tr><td width="100%" class="evenrow" colspan="2"><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">K�ra #Name#,<br><br>Vi har gl�djen att informera dig om att du nu har registrerats som partner till SITENAME.<br><br><b>Ditt partner-id: #Affid#</b><br><b>Ditt l�senord: #Password#</b><br><br>Bes�k <a href=\"#SiteUrl#\"><b>SITENAME</b></a> och logga in till partnersektionen och �ndra ditt l�senord snarast.<br><br>Lycka till!<br>#AdminName# <br>SITENAME<br></td>
</tr></table></div>
</td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';


$lang['aff_newpwd_sub'] = 'SITENAME Meddelande: Ditt partnerkonto!';

$lang['aff_newpwd']['text'] = "K�ra #Name#,

Ett nytt l�senord har skapats p� ditt partnerkonto hos SITENAME som du �nskade.

Ditt nya l�senord �r: #Password#

Bes�k <a href=\"#SiteUrl#\"><b>SITENAME</b></a> och logga in p� partnersektionen och �ndra ditt l�senord snarast.

Lycka till!

#AdminName#

SITENAME";

$lang['aff_newpwd']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head"><div class="module_head">#email_hdr_left#</div></td>
<td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;Ditt partnerkonto!</div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2"><div class="evenrow"><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">K�ra #Name#,<br><br>Du har beg�rt ett nytt l�senord f�r ditt partnerkonto p� SITENAME.<br>
<br><b>Ditt nya l�senord �r: #Password#</b><br><br>Var v�nlig bes�k <a href=\"#SiteUrl#\"><b>SITENAME</b></a> och logga in till partnersektionen och byt l�senord snarast.<br><br>Lycka till!<br>#AdminName# <br>SITENAME<br></td></tr></table></div>
</td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['add_affiliate'] = 'L�gg till partner';

$lang['mod_affiliate'] = '�ndra partner';

$lang['aff_modified'] = 'Partneruppgifterna har �ndrats';

$lang['newuser']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head"><div class="module_head">#email_hdr_left#</div></td>
<td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;Ny anv�ndarregistrering!</div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" ><div class="evenrow"><table border="0" cellspacing="0" cellpadding="5"><tr><td width="100%" valign="top" class="evenrow">K�ra sajt�gare,<br><br>En ny anv�ndare har registrerats p� #siteName#.<br><br>Anv�ndarnamn: <a href="#SiteUrl#admin/showprofile.php?username=#UserName#">#UserName#</a><br><br>#AdminName# <br>#siteName#<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['newuser']['text'] = "K�ra sajt�gare,

En ny anv�ndare har registrerat sig p� #SiteName#.

Anv�ndarnamn: #UserName#

#AdminName#

SITENAME.";

$lang['newuser_sub'] = 'En ny anv�ndare har registrerat sig';

/* Following user options are managed. Please modify only the description and not these keys */



$lang['user_choices'] = array(

	'email_message_received' 	=> "Skicka e-post n�r jag f�r ett nytt meddelande.",
	'email_wink_received'		=> "Skicka e-post n�r n�gon fl�rtar med mig.",
	'email_blog_commented'		=> "Skicka e-post n�r n�gon l�gger en kommentar i min blog.",
	'email_mship_expiry'		=> "Skicka e-post n�r medlemskapet h�ller p� att g� ut.",
	'email_message_read'		=> "Skicka e-post n�r mottagaren av mitt meddelande l�ser det.",
	'email_buddy_list'		=> "Skicka e-post n�r n�gon l�gger till mig i sin kompislista.",
	'email_ban_list'		=> "Skicka e-post n�r n�gon l�gger till mig i sin ignoreralista.",
	'email_hot_list'		=> "Skicka e-post n�r n�gon l�gger till mig i sin intresselista.",
	"allow_buddy_view_album"	=> "Till�t anv�ndare i min kompislista att titta p� mina privata album.",
	"allow_hotlist_view_album"	=> "Till�t anv�ndare i min intresselista att titta p� mina privata album.",
	'email_match_mail_days'		=> "Frekvens, i dagar, att skicka e-post med \'mina tr�ffar\'. Skriv 0 om du aldrig vill ha denna typ av e-post.",
	);

$lang['mysettings_updated'] = 'Inst�llningarna f�r e-post har uppdaterats.';
$lang['resend_conflink_hdr'] = 'Skicka ett nytt bekr�ftelsemeddelande.';

$lang['resend_conflink_hdr1'] = 'Har du tappat bort eller inte f�tt bekr�ftelsemeddelandet efter registrering? Skriv in den e-postadress som du anv�nde vid registreringen h�r nedan s� skickar vi ett nytt mail.';

$lang['resend_conflink_msg'] = 'Bekr�ftelsemeddelandet har skickats till din e-postadress.';

$lang['resend_conflink_msg1'] = 'Skriv in den e-postadress du anv�nde vid registreringen.';

$lang['resend_conflink_err1'] = 'Du har redan bekr�ftat din profil. V�nligen anv�nd <a href="forgotpass.php">gl�mt l�senord</a> f�r att skapa ett nytt l�senord.';

$lang['about_me'] = 'Om mig sj�lv';

$lang['about_me_hlp'] = 'Skriv n�gra rader om dig sj�lv som du tror kommer att intressera andra och f�r att f� mer respons.';

$lang['aff_forgot_pass'] = 'Har du gl�mt ditt l�senord? Skriv in den e-postadress du anv�nde vid registreringen h�r nedan f�r att f� ett nytt l�senord skickat till dig.';

$lang['send_new_password'] = 'Skicka nytt l�senord';
$lang['not_a_member'] = 'Inte medlem?';

$lang['login_reminded'] = 'Bli p�mind om ditt anv�ndarnamn och l�senord.';

$lang['lost_confemail'] = 'Tappat bort ditt bekr�ftelsemeddelande?';

$lang['couple_usernames'] = 'Par-/gruppnamn';

$lang['couple_usernames_hlp'] = 'Ett par eller en grupp best�r av tv� eller fler anv�ndare. V�nligen skriv anv�ndarnamnen f�r medlemmarna i gruppen i textf�ltet nedan. Till exempel anv�ndare_1,anv�ndare_2,anv�ndare_3. Dessa m�ste redan existerande anv�ndarprofiler.';

$lang['blog']['del01'] = 'Vill du verkligen ta bort denna kommentar?';

$lang['blog']['del02'] = 'Vill du verkligen ta bort de markerade ';

$lang['blog']['del03'] = 'Vill du verkligen avinstallera ';


$lang['feat_prof_del_msg'] = 'Vill du ta bort den valda profilen fr�n listan med VIP-profiler?';

$lang['feat_prof_deleted'] = 'Den valda profilen har tagits bort ur listan.';



$lang['mymatches_sub'] = 'SITENAME meddelande: Dina matchande profiler!';

$lang['mymatches_body']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25"><div class="module_head">#email_hdr_left#</div></td><td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;Dina matchande profiler</div></td></tr></table></div></td></tr>
<tr><td width="570" class="evenrow" colspan="2" ><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="1"></td></tr><tr><td class="evenrow">K�ra #FirstName#,<br><br>H�r kommer en uppdaterad lista p� dina matchande profiler.</td></tr>
<tr><td height="1" class="evenrow"> </td></tr><tr><td valign="top" class="evenrow">#matchedProfiles#</td></tr><tr><td class="evenrow" colspan="2">Bes�k <a href=\"#link#\">SITENAME</a> f�r att titta p� dessa profiler.<br><br>Lycka till!<br>#AdminName#<br>SITENAME<br></td></tr></table></div> </td></tr></table>';

$lang['on'] = ' p� ';

$lang['use_seo_username'] = 'Anv�nd profilens anv�ndarnamn som parameter i URL:en. N�r detta val �r aktiverat s� kommer profilens URL att f� formatet "dom�n/anv�ndarnamn". N�r valet inte �r aktiverat s� kommer profilens URL att vara "dom�n/id.htm", d�r id �r profilens ID-nummer.';
$lang['leave_blank_no_change'] = '(l�mna tomt f�r of�r�ndrat)';

$lang['adminltr']['html']='<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head"><div class="module_head">#email_hdr_left#</div></td><td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;#Subject#</div></td></tr></table></div></td></tr>
<tr><td width="100%" class="evenrow" colspan="2"><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">#LetterContent#</td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';



$lang['adminltr']['text'] = '#LetterContent#';



/* Following is the section headers in appropriate languages */



$lang['sections'] = array(
	'1'	=> 	'Grundl�ggande information',
	'2'	=>	'Utseende',
	'3'	=>	'Yrkesliv',
	'4'	=>	'Livsstil',
	'5'	=>	'Intressen'
	);



$lang['status_disp'] = array(
	'approval' => 'V�ntande',
	'active' => 'Aktiv',
	'rejected' => 'Avslagen',
	'suspended' => 'Vilande',
	/* added in 1.1.0 */
	'cancel' => 'Avslutad'
	);

$lang['status_enum'] = array(
	'approval' => 'V�ntande',
	'active' => 'Aktiv',
	'rejected' => 'Avslagen',
	'suspended' => 'Vilande',
	);

$lang['status_act'] = array(
	'approval' => 'V�ntande',
	'active' => 'Aktivera',
	'rejected' => 'Avsl�',
	'suspended' => 'St�ng av',
	/* added in 1.1.0 */
	'cancel' => 'Avsluta'
	);
?>

