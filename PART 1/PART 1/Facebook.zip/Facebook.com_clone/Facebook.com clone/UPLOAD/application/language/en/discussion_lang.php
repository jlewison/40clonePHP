<?php

	/**
	* Discussion board Language
	*
	*
	* @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
	* @license
	* @since 2/8/2008
	*/

	$lang['page_title']	= 'Discussion Board';

	$lang['discussion_restricted']	= 'You are not allowed to view this discussion board.';
	$lang['discussion_not_member']	= 'You are not allowed to view this discussion board as you are not a member of the network.';

	$lang['discussion_topic_title']	= 'Topic Title';
	$lang['discussion_topic_cont']	= 'Topic Content';
	$lang['discussion_reply_cont']	= 'reply content';

	$lang['discussion_topic_view']			= 'Topic View';
	$lang['discussion_start_new_topic']		= 'Start New Topic';
	$lang['discussion_reply_to']			= 'Reply to';
	$lang['discussion_topic']				= 'Topic';
	$lang['discussion_reply']				= 'Reply';
	$lang['discussion_people']				= 'people';
	$lang['discussion_post_by']				= 'post by';
	$lang['discussion_displaying']			= 'Displaying';
	$lang['discussion_wrote']				= 'wrote';
	$lang['discussion_replied_to']			= 'replied to';
	$lang['discussion_at']					= 'at';
	$lang['discussion_send_message']		= 'Send Message';
	$lang['discussion_delete_post']			= 'Delete Post';
	$lang['discussion_report']				= 'Report';
	$lang['discussion_discussion']			= 'Discussions';
	$lang['discussion_diss_board']			= 'Discussion Board';
	$lang['discussion_title']				= 'Title';
	$lang['discussion_content']				= 'Content';
	$lang['discussion_all_topic']			= 'All Topic';
	$lang['discussion_latest_replies']		= 'Latest Replies';
	$lang['discussion_newest_topic']		= 'Newest Topic';
	$lang['discussion_topics']				= 'topics';
	$lang['discussion_person']				= 'person';
	$lang['discussion_created_on']			= 'Created on ';
	$lang['discussion_latest']				= 'Latest post by';
	$lang['discussion_s']					= 's';
	$lang['discussion_show']				= 'Show';
	$lang['discussion_of']					= 'of';
	$lang['discussion_post']				= 'post';
	
?>