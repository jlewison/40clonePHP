<?php session_start();
include('ip_domain_ban.php');
include('settings.php');
if($onoff == 'N') { include('disabled.php'); exit; } else { }
if($cntIM == 'Y') { ?>

<?php 
$submit = $_POST[Submit];
$number = $_POST['number'];
$mynumber = $_SESSION['image_value'];
if($submit == 'Submit' and md5($number) == "$mynumber") {
$kinek  = "$contactmail";
$targy = "$contactmailsubject";
$uzenet = "Name: $cf_name
Email: $cf_email
Country: $cf_country
Reason: $cf_reason
Message:
$cf_message";
$fejlec = "From: $cf_name <$cf_email>\r\n";
mail($kinek, $targy, $uzenet, $fejlec);
echo("<meta http-equiv='refresh' content='0;URL=contact_sent.php'>");
exit;}
//header("Location: contact_sent.php"); 
elseif($submit == 'Submit' and md5($number) <> "$mynumber") {
include('ip_domain_ban.php');
include('settings.php');
echo '<div align="center" class="style19" id="wrong">Validation code is not correct! Please try again!</div>';
}
else {
include('ip_domain_ban.php');
include('settings.php');
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<?php echo("$lang_0");?>
<?php echo("$lang_01");?>
<title><?php echo("$contact_title");?></title>
<meta name="description" content="<?php echo("$contact_description");?>">
<meta name="keywords" content="<?php echo("$contact_keyword");?>">
<link rel="shortcut icon" href="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/favicon.ico" />
<script src="<?php echo("$path");?>SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<link href="<?php echo("$path");?>SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<script src="<?php echo("$path");?>SpryAssets/SpryValidationSelect.js" type="text/javascript"></script>
<script src="<?php echo("$path");?>SpryAssets/SpryValidationTextarea.js" type="text/javascript"></script>
<link href="<?php echo("$path");?>SpryAssets/SpryValidationSelect.css" rel="stylesheet" type="text/css" />
<link href="<?php echo("$path");?>SpryAssets/SpryValidationTextarea.css" rel="stylesheet" type="text/css" />

<link href="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/style.css" rel="stylesheet" type="text/css">
</head>

<body>

<?php include("template/$lbdtemplate/a_main_contact.php"); ?>

<?php } else { ?>

<?php
$submit = $_POST[Submit];
if($submit == 'Submit') {
$kinek  = "$contactmail";
$targy = "$contactmailsubject";
$uzenet = "Name: $cf_name
Email: $cf_email
Country: $cf_country
Reason: $cf_reason
Message:
$cf_message";
$fejlec = "From: $cf_name <$cf_email>\r\n";
mail($kinek, $targy, $uzenet, $fejlec);
echo("<meta http-equiv='refresh' content='0;URL=contact_sent.php'>");
exit;}
else {
include('ip_domain_ban.php');
include('settings.php');
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title><?php echo("$contact_title");?> - <?php echo("$sitetitle");?></title>
<link rel="shortcut icon" href="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/favicon.ico" />
<link href="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/style.css" rel="stylesheet" type="text/css" />
<meta name="description" content="<?php echo("$contact_description");?>">
<meta name="keywords" content="<?php echo("$contact_keyword");?>">
<script src="<?php echo("$path");?>SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<link href="<?php echo("$path");?>SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<script src="<?php echo("$path");?>SpryAssets/SpryValidationSelect.js" type="text/javascript"></script>
<script src="<?php echo("$path");?>SpryAssets/SpryValidationTextarea.js" type="text/javascript"></script>
<link href="<?php echo("$path");?>SpryAssets/SpryValidationSelect.css" rel="stylesheet" type="text/css" />
<link href="<?php echo("$path");?>SpryAssets/SpryValidationTextarea.css" rel="stylesheet" type="text/css" />
</head>

<body>

<?php include("template/$lbdtemplate/a_main_contact2.php"); ?>

<?php } ?>
</body>
</html>