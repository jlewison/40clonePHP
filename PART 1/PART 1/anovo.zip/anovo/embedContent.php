<?php
require_once ('./common/config.inc.php');
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['mods']['is_include_only']['non_html_header_files'] = true;
$CFG['auth']['is_authenticate'] = false;
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class EmbedHandler extends FormHandler
{
		public function displayEmbedContent()
		{
				switch ($this->fields_arr['embed'])
				{
						case 'user':
								$this->embedUserDetails();
								break;
						case 'question':
								$this->embedQuestionDetails();
								break;
				}
		}
		public function embedUserDetails()
		{
				if ($userDetails = $this->chkIsValidUser($this->fields_arr['user']))
				{
						$uid = $userDetails['user_id'];
						$userLog = $this->getUserLog($uid);
						$uname = $userDetails['name'];
?>
<style type="text/css">
/* rounded corner for myhome section */
.tlcprofile {
	background:transparent url(images/screen_white/tlcprofile.jpg) no-repeat;
}
.trcprofile {
	background:transparent url(images/screen_white/trcprofile.jpg) no-repeat right top;
	padding:10px;
}
.trcprofile {
 *zoom:1;
}
* html .trcprofile {
	height:1%;
}
.blcprofile {
	background:transparent url(images/screen_white/blcprofile.jpg) no-repeat left bottom;
}
.brcprofile {
	background:transparent url(images/screen_white/brcprofile.jpg) no-repeat right bottom;
}
.tbprofile {
	background:transparent url(images/screen_white/tbprofile.jpg) repeat-x;
}
.bbprofile {
	background:transparent url(images/screen_white/bbprofile.jpg) repeat-x center bottom;
}
.rbprofile {
	background:transparent url(images/screen_white/rbprofile.jpg) repeat-y right top;
}
.lbprofile {
	background:#F2F4FF url(images/screen_white/lbprofile.jpg) repeat-y left bottom;
}
.clsUserThumb {
	float:left;
	width:100px;
	text-align:center;
}
h3 {
	margin:0 0 1em 0;
}
	h3 a{
		color:#313D8F;
	}
.clsNormalUserDetails {
	float:left;
	margin:0 0 0 17px;
	width:400px;
	padding:16px 0 0 0;
}
* html .clsNormalUserDetails {
	padding:5px 0 0 0;
}
.clsUserThumbDetails {
	overflow:auto;
	zoom:1;
	padding:0 0 0 10px;
	margin:0 0 5px 0;
}
*html .clsUserThumbDetails {
	height:1%;
	overflow:visible;
}
.clsNormalUserDetails p {
	padding:0 5px 0 0;
	margin:0 5px 0 0;
	font:normal 12px arial;
}
.clsTotalPoints {
	color:#45B434;
	font-weight:bold;
}
.clsDate, .clsBold a {
	color:#444;
	font-weight:bold;
}
</style>
<!--rounded corners-->
<div class="lbprofile">
  <div class="rbprofile">
    <div class="bbprofile">
      <div class="blcprofile">
        <div class="brcprofile">
          <div class="tbprofile">
            <div class="tlcprofile">
              <div class="trcprofile">
                <div class="clsUserThumbDetails">
                  <?php if (chkUserImageAllowed())
						{ ?>
                  <div class="clsUserThumb">
                    <p id="selImageBorder">
                      <?php displayUserImage($userDetails, 'thumb', false); ?>
                    </p>
                  </div>
                  <?php } ?>
                  <div class="clsNormalUserDetails">
                    <h3><a href="<?php echo getUrl($this->CFG['site']['url'] . 'myanswers.php?uid=' . $uid, $this->CFG['site']['url'] . 'my/answers/' . $uid . '/', false); ?>"><?php echo $userDetails['name']; ?></a></h3>
                    <p class="clsOtherInfo"><?php echo $this->LANG['total_points']; ?> <span class="clsTotalPoints"><?php echo $userLog['total_points']; ?></span></p>
                    <p class="clsOtherInfo"><?php echo $this->LANG['question_asked']; ?> <span class="clsBold"><a href="<?php echo getUrl($this->CFG['site']['url'] . 'questions.php?act=search&uname=' . $uname, $this->CFG['site']['url'] . 'answers/search/?uname=' . $uname, false); ?>"><?php echo $userLog['total_ques']; ?></a></span></p>
                    <p class="clsOtherInfo"><?php echo $this->LANG['resolved_questions']; ?> <span class="clsBold"><a href="<?php echo getUrl($this->CFG['site']['url'] . 'questions.php?act=search&uname=' . $uname . '&opt=resolve', $this->CFG['site']['url'] . 'answers/search/?uname=' . $uname . '&opt=resolve', false); ?>"><?php echo $this->getResolvedQuestions($uid); ?></a></span></p>
                    <p class="clsOtherInfo"><?php echo $this->LANG['total_answers']; ?><span class="clsBold"> <a href="<?php echo getUrl($this->CFG['site']['url'] . 'questions.php?act=search&uname=' . $uname . '&opt=ans', $this->CFG['site']['url'] . 'answers/search/?uname=' . $uname . '&opt=ans', false); ?>"><?php echo $userLog['total_ans']; ?></a></span></p>
                    <p><a href="<?php echo $this->CFG['site']['url']; ?>"><?php echo $this->CFG['site']['name']; ?></a></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!--end of rounded corners-->
<?php
				}
		}
		public function chkIsValidUser($username)
		{
				if (!$username) return false;
				$sql = 'SELECT ' . $this->getUserTableFields(array('user_id', 'name', 'image_path', 't_height', 't_width', 'photo_server_url', 'photo_ext')) . ', u.' . $this->getUserTableField('user_id') . ' AS img_user_id' . ' FROM ' . $this->CFG['db']['tbl']['users'] . ' AS u' . ' WHERE u.' . $this->getUserTableField('name') . '=' . $this->dbObj->Param($username) . ' AND u.' . $this->getUserTableField('usr_status') . '=\'Ok\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($username));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if (!$rs->PO_RecordCount())
				{
						return false;
				}
				$row = $rs->FetchRow();
				$row['name'] = ucwords($row['name']);
				return $row;
		}
		public function getResolvedQuestions($uid)
		{
				$sql = 'SELECT COUNT(ques_id) AS resolved FROM ' . $this->CFG['db']['tbl']['questions'] . ' WHERE user_id=' . $this->dbObj->Param($uid) . ' AND status=\'Resolved\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($uid));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = $rs->FetchRow();
				return $row['resolved'];
		}
		public function embedQuestionDetails()
		{
				$qid = $this->fields_arr['qid'];
				if ($questionDetails = $this->chkIsValidQuestion($qid))
				{
?>
<style type="text/css">
#selQuickLinks{
	background:#F2F4FF;
	margin:1em 0;
	overflow:auto;
	zoom:1;
	padding:1em 0 1em 10px;
}
* html #selQuickLinks{
	overflow:visible;
	height:1%;
}
.clsSmallUserThumb{
	float:left;
	width:60px;
	text-align:center;
}
.clsUserDetails{
	float:left;
	margin:0 0 0 17px;
	width:800px;
	padding:0;
}
h3{
	margin:0 0 0.8em 0;
}
h3 a{
		color:#313D8F;
	}
		.clsUserDetails p{
			font:normal 12px arial;
		}
			.clsUserDetails p span{
				border-left:1px solid #000;
				padding:0 0 0 5px;
				margin:0 0 0 5px;
			}	
		.clsTotalPoints{
			color:#45B434;
			font-weight:bold;
		}
		.clsDate, .clsBold a,.clsSiteName a{
			color:#444;
			font-weight:bold;
		}
		.clsSiteName a,.clsTotlaAnswer{
			font-size:1.3em;
			color:#BD060A;
		}
		.clsTotlaAnswer{
			font-size:1em;
		}
		.clsFirstAnswer a{
			font-size:1.2em;
			font-weight:bold;
			color:#3B8901;
		}			
		.clsUserDetails .clsDesc{
			margin:0.5em 0;
			display:block;
		}
			.clsUserDetails .clsNoBorder{
				border:0;
				padding:0;
				margin:0;
			}
			.clsImage a{
				display:block;
				line-height:24px;
			}

</style>
<div id="selQuickLinks">
  <?php if (chkUserImageAllowed())
						{ ?>
  <div class="clsSmallUserThumb">
    <?php displayUserImage($questionDetails, 'small', false); ?>
  </div>
  <?php } ?>
  <div class="clsUserDetails">
    <h3><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'myanswers.php?uid=' . $questionDetails['user_id'], $this->CFG['site']['relative_url'] . 'my/answers/' . $questionDetails['user_id'] . '/', false); ?>"><?php echo ucwords($questionDetails['asked_by']); ?></a></h3>
    <p class="clsImage clsBold"> <strong><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'answer.php?qid=' . $qid, $this->CFG['site']['relative_url'] . 'view/answers/' . $qid . '/', false); ?>"><?php echo $questionDetails['question']; ?></a></strong>
      <?php if ($questionDetails['video_id'])
						{ ?>
      <span class="clsNoBorder"><img src="<?php echo $this->CFG['site']['url'] . 'images/icon-video.png' ?>" alt="video available" /></span>
      <?php } ?>
      <?php if ($questionDetails['audio_id'])
						{ ?>
     <span class="clsNoBorder"><img src="<?php echo $this->CFG['site']['url'] . 'images/icon-audio.png' ?>" alt="audio available" /></span>
      <?php } ?>
    </p>
    <p class="clsDesc"><?php echo nl2br($questionDetails['description']); ?></p>
    <p> <span class="clsNoBorder clsForumAuthor"><?php echo $this->LANG['asked_by']; ?> <a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'myanswers.php?uid=' . $questionDetails['user_id'], $this->CFG['site']['relative_url'] . 'my/answers/' . $questionDetails['user_id'] . '/', false); ?>"><?php echo $questionDetails['asked_by']; ?></a></span>
      <?php $this->showCategoryName($questionDetails['cat_id']); ?>
      -
      <?php if ($questionDetails['total_answer'])
						{ ?>
      <span class="clsTotlaAnswer"><?php echo $questionDetails['total_answer']; ?> <?php echo $this->LANG['answers']; ?> (<?php echo $questionDetails['total_videos'] . ' videos'; ?> | <?php echo $questionDetails['total_audios'] . ' audios'; ?>)</span>
      <?php }
						else
						{ ?>
      <span class="clsFirstAnswer"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'answer.php?qid=' . $qid, $this->CFG['site']['relative_url'] . 'view/answers/' . $qid . '/', false); ?>"><?php echo $this->LANG['be_the_first_one']; ?></a></span>
      <?php } ?>
      - <span><?php echo getTimeDiffernceFormat($questionDetails['date_asked']); ?></span> </p>
    <p class="clsSiteName"><a href="<?php echo $this->CFG['site']['url']; ?>"><?php echo $this->CFG['site']['name']; ?></a></p>
  </div>
</div>
<?php
				}
		}
		public function chkIsValidQuestion($qid)
		{
				if (!$qid) return false;
				$sql = 'SELECT q.ques_id, q.total_answer, q.cat_id, q.best_ans_id, q.description, q.total_stars, q.question, TIMEDIFF(NOW(), date_asked) as date_asked' . ', q.video_id, q.audio_id, ' . $this->getUserTableField('name') . ' as asked_by, u.' . $this->getUserTableField('user_id') . ' as img_user_id,' . $this->getUserTableFields(array('t_height', 't_width', 's_height', 's_width', 'photo_server_url', 'photo_ext')) . ' , ' . $this->getUserTableFields(array('image_path', 'gender'), false) . 'q.status, q.user_id' . ', IF(status=\'Open\' AND date_closed>=NOW(), 1, 0) is_open, TIMEDIFF(date_closed, NOW()) as date_closed' . ', q.total_videos, q.total_audios FROM ' . $this->CFG['db']['tbl']['questions'] . ' AS q, ' . $this->CFG['db']['tbl']['users'] . ' AS u' . ' WHERE q.user_id=u.' . $this->getUserTableField('user_id') . ' AND q.status IN (\'Open\', \'Resolved\')' . ' AND u.' . $this->getUserTableField('usr_status') . '=\'Ok\' AND q.ques_id=' . $this->dbObj->Param($qid);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($qid));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if (!$rs->PO_RecordCount()) return false;
				$row = $rs->FetchRow();
				return $row;
		}
}
$answerRating = new EmbedHandler();
$answerRating->setDBObject($db);
$answerRating->makeGlobalize($CFG, $LANG);
$answerRating->setFormField('embed', '');
$answerRating->setFormField('user', '');
$answerRating->setFormField('qid', '');
$answerRating->sanitizeFormInputs($_REQUEST);
if ($answerRating->isFormGETed($_GET, 'embed'))
{
		ob_start();
		$documentWrite = true;
		$onlyContent = 0;
		if (isset($_REQUEST['content']) and $onlyContent = $_REQUEST['content'])
		{
				$documentWrite = false;
		}
		echo ($onlyContent == 2) ? '<div id="userbadge">' : '';
		$answerRating->displayEmbedContent();
		echo ($onlyContent == 2) ? '</div>' : '';
		$str = ob_get_clean();
		$str = trim($str);
		$str = str_replace(array("\n", "\t", "\r", "'"), array("", "", "", "&rsquo;"), $str);
		if ($documentWrite)
		{
				print 'document.writeln(\'' . $str . '\');';
		}
		else
		{
				print $str;
		}
}



?>
