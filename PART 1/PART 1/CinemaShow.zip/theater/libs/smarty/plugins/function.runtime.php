<?php
function smarty_function_runtime($params, &$smarty) {
	echo date('g \h\r i \m\i\n\s', mktime(0, (int)$params['time']));
}