<?php
session_start();
if (!isset($_SESSION['check']) or !$_SESSION['check']) header('Location: auth.php');
if (!defined('E_STRICT')) define('E_STRICT', 2048);
error_reporting(E_ALL | E_STRICT);
ini_set('display_errors', true);
header('Content-type: image/jpeg');
$im = imagecreate(400, 30);
$white = imagecolorallocate($im, 255, 255, 255);
$grey = imagecolorallocate($im, 128, 128, 128);
$black = imagecolorallocate($im, 0, 0, 0);
$text = 'Testing...';
$slash = stristr(php_sapi_name(), 'apache') ? '/' : DIRECTORY_SEPARATOR;
$CFG['site']['project_path'] = preg_replace(array("/\\\/", "/(common\/|members\/|admin\/)?/"), array('/', ''), substr($_SERVER['SCRIPT_FILENAME'], 0, strrpos($_SERVER['SCRIPT_FILENAME'], $slash) + 1));
$font = $CFG['site']['project_path'] . 'common/gd_fonts/arial.ttf';
imagettftext($im, 20, 0, 11, 21, $grey, $font, $text);
imagettftext($im, 20, 0, 10, 20, $black, $font, $text);
imagejpeg($im);
imagedestroy($im);
?>