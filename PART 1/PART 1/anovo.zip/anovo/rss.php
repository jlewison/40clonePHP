<?php
require_once ('./common/config.inc.php');
$CFG['html']['header'] = 'includes/languages/%s/rss_header.php';
$CFG['html']['footer'] = 'includes/languages/%s/rss_footer.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['benchmark']['is_expose_parse_time'] = false;
$CFG['debug']['is_debug_mode'] = false;
$CFG['debug']['is_db_debug_mode'] = false;
$CFG['auth']['is_authenticate'] = false;
require ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class RssFormHandler extends FormHandler
{
		public function convertDate($date_time)
		{
				return strftime("%a, %d %b %Y %T %Z", strtotime($date_time));
		}
		public function stripString($str, $content_len)
		{
				$str = htmlentities(strip_tags($str, 'ENT_QUOTES'));
				if (strlen($str) > $content_len) $str = substr($str, 0, $content_len) . '...';
				return htmlentities(strip_tags($str, 'ENT_QUOTES'));
		}
		public function generateItemList($title, $link, $content, $date, $content_len)
		{
?>
					     <item>
					        <title> <?php echo htmlentities(strip_tags($title)); ?></title>
					        <link><?php echo $link; ?></link>
					        <description> <?php echo $this->stripString($content, $content_len); ?></description>
					        <pubDate><?php echo $this->convertDate($date); ?></pubDate>
					     </item>
<?php
		}
		public function showCategoryName($cat_id)
		{
				$sql = 'SELECT cat_name, cat_id FROM ' . $this->CFG['db']['tbl']['questions_category'] . ' WHERE cat_id=' . $this->dbObj->Param('cat_id');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($cat_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$cat_name = '';
				if ($rs->PO_RecordCount())
				{
						$row = $rs->FetchRow();
						$cat_name = $row['cat_name'];
				}
				return $cat_name;
		}
		public function getRecentQuestions($limit = 100, $content_len = 5000)
		{
				$sql = 'SELECT q.ques_id, q.total_answer, q.cat_id, q.status, q.total_stars, q.question, date_asked' . ', ' . $this->getUserTableField('name') . ' as asked_by, ' . $this->getUserTableFields(array('image_path', 'gender'), false) . ' q.user_id' . ', video_id, audio_id, IF(status=\'Open\' AND date_closed>=NOW(), 1, 0) is_open, TIMEDIFF(date_closed, NOW()) as date_closed' . ', q.total_videos, q.total_audios FROM ' . $this->CFG['db']['tbl']['questions'] . ' AS q, ' . $this->CFG['db']['tbl']['users'] . ' AS u' . ' WHERE q.user_id=u.' . $this->getUserTableField('user_id') . ' AND q.status IN (\'Open\', \'Resolved\')' . ' AND u.' . $this->getUserTableField('usr_status') . '=\'Ok\'' . ' ORDER BY ques_id DESC LIMIT 0,' . $limit;
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				while ($row = $rs->FetchRow())
				{
						$link = getUrl($this->CFG['site']['url'] . 'answer.php?qid=' . $row['ques_id'], $this->CFG['site']['url'] . 'view/answers/' . $row['ques_id'] . '/', false);
						$description = '';
						if ($catagory_name = $this->showCategoryName($row['cat_id'])) $description .= 'In ' . $catagory_name . ' - ';
						$description .= '<span class="clsForumAuthor">asked by ' . $row['asked_by'] . '</span>';
						$description .= ' - <span>' . $row['total_answer'] . ' answers (' . $row['total_videos'] . ' videos | ' . $row['total_audios'] . ' audios)</span>';
						$this->generateItemList($row['question'], $link, $description, $row['date_asked'], $content_len);
				}
		}
		public function getPopularQuestions($limit = 100, $content_len = 5000)
		{
				$sql = 'SELECT q.ques_id, q.total_answer, q.cat_id, q.status, q.total_stars, q.question, date_asked' . ', ' . $this->getUserTableField('name') . ' as asked_by, ' . $this->getUserTableFields(array('image_path', 'gender'), false) . ' q.user_id' . ', video_id, audio_id, IF(status=\'Open\' AND date_closed>=NOW(), 1, 0) is_open, TIMEDIFF(date_closed, NOW()) as date_closed' . ', q.total_videos, q.total_audios FROM ' . $this->CFG['db']['tbl']['questions'] . ' AS q, ' . $this->CFG['db']['tbl']['users'] . ' AS u' . ' WHERE q.user_id=u.' . $this->getUserTableField('user_id') . ' AND q.status IN (\'Open\', \'Resolved\')' . ' AND u.' . $this->getUserTableField('usr_status') . '=\'Ok\'' . ' AND total_views > 0 ORDER BY total_views DESC LIMIT 0,' . $limit;
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				while ($row = $rs->FetchRow())
				{
						$link = getUrl($this->CFG['site']['url'] . 'answer.php?qid=' . $row['ques_id'], $this->CFG['site']['url'] . 'view/answers/' . $row['ques_id'] . '/', false);
						$description = '';
						if ($catagory_name = $this->showCategoryName($row['cat_id'])) $description .= 'In ' . $catagory_name . ' - ';
						$description .= '<span class="clsForumAuthor">asked by ' . $row['asked_by'] . '</span>';
						$description .= ' - <span>' . $row['total_answer'] . ' answers (' . $row['total_videos'] . ' videos | ' . $row['total_audios'] . ' audios)</span>';
						$this->generateItemList($row['question'], $link, $description, $row['date_asked'], $content_len);
				}
		}
		public function getRecentForums($limit = 100, $content_len = 5000)
		{
				$sql = 'SELECT ft.forum_id, ft.topic_id, ft.forum_topic, ft.user_id, ft.total_response' . ', ft.total_views, ft.last_post_user_id, ft.last_post_date, date_added' . ', u.' . $this->getUserTableField('user_id') . ' AS topic_user_id, u.' . $this->getUserTableField('name') . ' AS topic_user_name' . ', u1.' . $this->getUserTableField('user_id') . ' AS last_user_id, u1.' . $this->getUserTableField('name') . ' AS last_user_name' . ' FROM ' . $this->CFG['db']['tbl']['forum_topics'] . ' AS ft' . ' LEFT JOIN ' . $this->CFG['db']['tbl']['users'] . ' AS u1 ON ft.last_post_user_id = u1.' . $this->getUserTableField('user_id') . ', ' . $this->CFG['db']['tbl']['users'] . ' AS u' . ' WHERE ft.user_id = u.' . $this->getUserTableField('user_id') . ' AND u.' . $this->getUserTableField('usr_status') . ' = \'Ok\'' . ' AND topic_status = \'Yes\'' . ' ORDER BY ft.topic_id DESC LIMIT 0,' . $limit;
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				while ($row = $rs->FetchRow())
				{
						$link = getUrl($this->CFG['site']['url'] . 'forumsResponses.php?forum_id=' . $row['forum_id'] . '&topic_id=' . $row['topic_id'], $this->CFG['site']['url'] . 'forum/' . $row['forum_id'] . '/' . $row['topic_id'] . '/');
						$description = ' Started by: ' . $row['topic_user_name'] . ' (' . $row['total_response'] . ' Responses | ' . $row['total_views'] . ' Views)';
						$this->generateItemList($row['forum_topic'], $link, $description, $row['date_added'], $content_len);
				}
		}
		public function getRecentBlogs($limit = 100, $content_len = 5000)
		{
				$sql = 'SELECT blog_id, subject, message, total_comments, total_views, b.user_id, date_added' . ' FROM ' . $this->CFG['db']['tbl']['blogs'] . ' AS b' . ' WHERE status=\'Active\'' . ' ORDER BY blog_id DESC LIMIT 0,' . $limit;
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				while ($row = $rs->FetchRow())
				{
						$user_details = $this->getUserDetailsFromUsersTable($this->CFG['db']['tbl']['users'], $row['user_id']);
						$link = getUrl($this->CFG['site']['url'] . 'blogComment.php?blog_id=' . $row['blog_id'], $this->CFG['site']['url'] . 'blogcomment/?blog_id=' . $row['blog_id']);
						$description = 'Posted by: ' . $user_details['name'] . ' (' . $row['total_comments'] . ' Comments | ' . $row['total_views'] . ' Views)';
						$description .= ' ' . $row['message'];
						$this->generateItemList($row['subject'], $link, $description, $row['date_added'], $content_len);
				}
		}
}
$rssfrm = new RssFormHandler();
$rssfrm->setDBObject($db);
$rssfrm->setCfgLangGlobal($CFG, $LANG);
$rssfrm->setFormField('act', '');
$rssfrm->setFormField('rcnt', 25);
$rssfrm->setFormField('desc_cnt', 750);
if ($rssfrm->isFormGETed($_GET, 'act'))
{
		$rssfrm->sanitizeFormInputs($_GET);
		switch ($rssfrm->getFormField('act'))
		{
				case 'popularquestions':
?>
						<title><?php echo $CFG['site']['name']; ?>: Popular Questions</title>
<?php
						$rssfrm->getPopularQuestions($rssfrm->getFormField('rcnt'), $rssfrm->getFormField('desc_cnt'));
						break;
				case 'recentforums':
?>
						<title><?php echo $CFG['site']['name']; ?>: Recent Forums</title>
<?php
						$rssfrm->getRecentForums($rssfrm->getFormField('rcnt'), $rssfrm->getFormField('desc_cnt'));
						break;
				case 'recentblogs':
?>
						<title><?php echo $CFG['site']['name']; ?>: Recent Blogs</title>
<?php
						$rssfrm->getRecentBlogs($rssfrm->getFormField('rcnt'), $rssfrm->getFormField('desc_cnt'));
						break;
				default:
?>
						<title><?php echo $CFG['site']['name']; ?>: Recent Questions</title>
<?php
						$rssfrm->getRecentQuestions($rssfrm->getFormField('rcnt'), $rssfrm->getFormField('desc_cnt'));
		}
}
else
{
?>
			<title><?php echo $CFG['site']['name']; ?>: Recent Questions</title>
<?php
		$rssfrm->getRecentQuestions($rssfrm->getFormField('rcnt'), $rssfrm->getFormField('desc_cnt'));
}
require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>
