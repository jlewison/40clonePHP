<?php //00461
// Copyright Notice
// Web Site URL:  http://www.zeeways.com
// Script Owner eMail: mail@zeeways.com
// Date: April, 2007
// Script Name: Zeeways Auction Website PHP Script
// Copyright Details: This script is not free.  Do not Remove this Copy Right notice.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the site administrator.');exit(199);
?>
4+oV5D30Xzg8ANmTGNGI+PY4q45Ce/t+V8a/3E1cIOqvn82TpbzEtENoUmz6SS0zrH5zpEiMKFZr
KXu6P0Y6uYA+5WAWIygVvQs1ARB5OfNoMBhTV4gK3nzDAxYEw948kQ0T2tftwmhww9VF9WRnZUqb
sbDTj9npfmcLCC/yDtuIQmcycKMrAYEwRkFQtvO8mJ5mgLza5P6OU7o0shZqylqpLkp1RYsWS2Kw
qk9AlpQz4ADq/VJPasuaJvQcD0nCS/Sjhab+jffm4OCDPJAYeB7dmFTLCjfidYc08F+TZbTSHX5s
pbtarWRDjFOmaRJPRmigM5dEALxEjUqA77RMbIh5a4GHHcXIwcE3OYqF3sY6gOTV4ohEZxjPwLcJ
Oh7lTFVLZsFqYcbHDZe8h9AquVM29eka4ulA0rITTMTuY2bGgdFFg3UXTf4YAVD+pZfF3wDD+fI5
qX+HjEKCYEno9cyQVinOmQKQAvgnr0JA5npejvHal6ms8uZ3sxwv02en5QfcmOIJXji1SyM1GAq7
mJ8puz8srqhmpAaUX8SdH2kS7zkyhAj1W/a2SXeLnxlNHqji4MxDYxyvdzp/KuXrJLkA4lXcqMXP
tchdZLpYTBRBqdPE6dmSJ0I7X0PN/x+DhckBcTK5uNd0lDgCp1tUXfn8T6hUmfgKS2zILxX0tvea
MS65KytxfCKngbMDq7+fHcd0meCs9e2Lqm7zFbv8C8EHLcpViMf3twQoqel9VEvGVIdRGl6UOIRi
nA8pyWuLuD3SsKXThTldDGfCJ9+0imSZyf5TKloSRuUeG9nzmY4cUUWGXMaoHpUq6Lfhilipu3wj
IhQsejW8b5NNRCvMupQB0zT9OqHN98dhjo0tqb+bQ5QtnY2xVL2pQYnxo8eoJj8HhQ/SDx2HXmxm
ivp1eCU4RAMcGOuG2Ncmifceh9c75JHeIsBHJIC8L/pKhVfPSWVRTKPo1iyslYNI8mILVo4EzLZb
uMVc3QzNsjeOi934aFAO6bWl3TVMEiBxIKX5M4gdMqW9ObERKde+Uig0oSqm9LzBCpMik2UictE3
l7m6/0jjUc38MUMt+knhlrsdIBIpovBNrVY6Xr9wMT7x/CUhpL7FoAFX8X3P9y5Fck1BlZdRrdwa
h2en7yRx5lxxKLJdMMcmdkziEqtkwuKoL5aiVZ+4xK0GynQx90xUNBth5aJaYsT2dO2tApWhMcbu
7eqWZ32pPcgwxLxrikaVq6zZEtPvZz2FTScrvzovPvtO5w3aiwK7Z7/grbY8415P+mzkDAkzU1S2
