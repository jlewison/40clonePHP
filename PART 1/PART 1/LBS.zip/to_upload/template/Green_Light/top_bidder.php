<?php
mysql_select_db($database_apound, $apound);
$query_top_BID = "SELECT * FROM main WHERE TO_DAYS(NOW()) < TO_DAYS(stod) AND main.avail = 'Y' AND main.paid = 'Y' ORDER BY main.bid DESC";
$top_BID = mysql_query($query_top_BID, $apound) or die(mysql_error());
$row_top_BID = mysql_fetch_assoc($top_BID);
$totalRows_top_BID = mysql_num_rows($top_BID);
mysql_free_result($top_BID);
?>
<div class="lead">
	<div class="lead-cap-left">
		<div class="lead-cap-right">
			<div class="lead-cap"></div>
		</div>
	</div>
	<div class="lead-left">
		<div class="lead-right">
		<div class="lead-rate"></div>
			<div class="listing-descr">
				<div class="bid-title"><a href="<?php echo $row_top_BID['site']; ?>" target="_blank"><?php echo $row_top_BID['title']; ?></a></div>
				<div class="bid-descr"><?php echo $row_top_BID['descr1']; ?></div>
				<div class="bid-url"><span style="color:#3a6e2f; font-style:italic;"><?php echo $row_top_BID['site']; ?></span> :: Added <?php echo $row_top_BID['stad']; ?></div>
			</div>
<?php
$category = $row_top_BID['maincategory'];					
mysql_select_db($database_apound, $apound);
$query_LdetCAT = "SELECT * FROM categorylisting WHERE catlistid = '$category'";
$LdetCAT = mysql_query($query_LdetCAT, $apound) or die(mysql_error());
$row_LdetCAT = mysql_fetch_assoc($LdetCAT);
$totalRows_LdetCAT = mysql_num_rows($LdetCAT);
?>
			<div class="listing-stats">Listed in: <a href="<?php echo("$path");?><?php echo $row_LdetCAT['categseoname']; ?>/"><?php echo $row_LdetCAT['categoryname'] ?></a></div>
		</div>
	</div>
	<div class="lead-bottom-left">
		<div class="lead-bottom-right">
		</div>
	</div>
</div>