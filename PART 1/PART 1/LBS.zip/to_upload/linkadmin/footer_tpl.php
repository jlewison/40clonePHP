	</div>
	<div class="bottom-menu">
		<div class="bot-ml">
			<div class="bot-mm"><a href="../linkadmin/setup.php">Configurations</a> :: <a href="../linkadmin/manage_link.php">Manage Links</a> :: <a href="../linkadmin/manage_bid.php">Manage Bids</a> :: <a href="../linkadmin/manage_category.php">Manage Categories</a> :: <a href="http://www.linkbidscript.com/support.php" target="_blank">Help</a> :: <a href="http://www.linkbidscript.com/docs.php" target="_blank">Documents</a> :: <a href="http://forums.linkbidscript.com" target="_blank">Support Forums</a></div>
		</div>
	</div>
</div>
<div class="creds">&copy;<?php echo date("Y");?> <a href="http://www.linkbidscript.com/" target="_blank">Link Bid Script</a> V1.5.2</div>
