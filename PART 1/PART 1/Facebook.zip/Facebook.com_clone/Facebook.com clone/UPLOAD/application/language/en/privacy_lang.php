<?php
	
	/**
	* Privacy Page Language
	*
	*
	* @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
	* @license
	* @since 2/8/2008
	*/

	$lang['page_title']	= 'Privacy';

	$lang['privacy_profile_save_success']	= 'Profile Privacy Settings for your Profile has been saved.';
	$lang['privacy_search_save_success']	= 'Search Privacy Settings for your Profile has been saved.';
	$lang['privacy_feed_save_success']		= 'Feed Privacy Settings for your Profile has been saved.';
	$lang['privacy_message_save_success']	= 'Message Privacy Settings for your Profile has been saved.';
	$lang['privacy_remove_save_success']	= 'You have successfully removed the blocked person.';
	$lang['privacy_block_save_success']		= 'You have successfully blocked the person.';
	
	$lang['privacy_overview']		= 'Privacy Overview';
	$lang['privacy_edit_settings']	= 'Edit Settings';


	$lang['privacy_msg_1']		= 'wants you to share your information with exactly the people you want to see it. On this page, you\'ll find all the controls you need to set who can see your profile and the stuff in it, who can find and contact you on Kootali, and more.';
	$lang['privacy_msg_2']	= 'You are in one network and you can control who can see your profile, contact information, groups, wall, photos, posted items, online status, and status updates.';
	$lang['privacy_msg_3']	= 'You can control who can find you in searches and what appears in your search listing.';
	$lang['privacy_msg_4']	= 'You can control what actions show up in your Mini-Feed.';
	$lang['privacy_msg_5']	= 'You can select which parts of your profile are visible to people you contact through a message, or friend request.';
	$lang['privacy_msg_6']	= 'If you block someone, they will not be able to search for you, see your profile, or contact you on Kootali.';

	$lang['privacy_profile']		= 'Profile';
	$lang['privacy_search']			= 'Search';
	$lang['privacy_minifeed']		= 'Mini-Feed';
	$lang['privacy_message']		= 'Message and Friend Request';
	$lang['privacy_block_people']	= 'Block People';
	$lang['privacy_person']			= 'Person';
	$lang['privacy_block_list']		= 'Block List';
	$lang['privacy_blocked_none']	= 'You have not blocked anyone';
	$lang['privacy_remove']			= 'remove';
	$lang['privacy_settings']		= 'settings';
	$lang['privacy_more']			= 'and more';
	$lang['privacy_contact_info']	= 'Contact Information';
	$lang['privacy_contact_email']	= 'contact email';
	$lang['privacy_which']			= 'Which';


	$lang['privacy_msg_7']	= 'will only publish stories about you on your Mini-Feed';
	$lang['privacy_msg_8']	= 'When you contact someone through a message or friend request';
	$lang['privacy_msg_9']	= 'lets that person see part of your profile temporarily, even if your privacy and network settings would usually prevent him or her from seeing your profile. This helps that person identify who you are before they respond. You can select what information you\'d like them to see using the check boxes below';
	$lang['privacy_msg_10']	= 'Select the information to display in your profile to the people that you contact through a message or friend request.';
	$lang['privacy_msg_11']	= 'Based on your current privacy settings, your friends can see your profile. Your profile may include your picture, interests, photo albums, groups, wall and other things, depending on the profile details you have selected on';
	$lang['privacy_msg_12']	= 'Select who can see your';
	$lang['privacy_msg_13']	= 'You will show up in search results if anyone searches for';
	$lang['privacy_msg_14']	= 'or any part of your name';
	$lang['privacy_msg_15']	= 'Who Can Find Me in Search and See My Public Search Listing';
	$lang['privacy_msg_16']	= 'users can find me in search';
	$lang['privacy_msg_17']	= 'In addition to the people selected above, allow the following people outside your networks to find you in search results';
	$lang['privacy_msg_18']	= 'What Can People Do With My Search Results';

?>