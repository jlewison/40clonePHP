<?php

/**
 * application Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 2/5/2008
 */
class application extends Controller
{
		//Constructor
		function application()
		{
				parent::Controller();
		}
		//Change Language function
		function changeLanguage()
		{
				//$this->config->set_item('language_code', $this->input->post('siteLang'));
				$appLanguage = array('app_language' => $this->input->post('siteLang'));
				$this->session->set_userdata($appLanguage);
				redirect('welcome');
		}
}

?>