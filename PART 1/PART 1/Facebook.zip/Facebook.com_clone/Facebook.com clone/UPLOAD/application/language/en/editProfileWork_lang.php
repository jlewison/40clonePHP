<?php
$lang['page_title']	= 'Edit profile';
$lang['editprofilework_employer']		= 'Employer';
$lang['editprofilework_position']		= 'Position';
$lang['editprofilework_description']	= 'Description';
$lang['editprofilework_city']			= 'City';
$lang['editprofilework_country']		= 'Country';
$lang['editprofilework_current_job']	= 'Time Period';
$lang['editprofilework_current_work']	= 'I currently work here';
$lang['editprofilework_to_present']		= 'to present.';
$lang['editprofilework_remove_job']		= 'Remove this job...';
$lang['editprofilework_add_job']		= 'Add this job...';
$lang['editprofilework_success_msg']	= 'Work profile updated successfully!';
?>