<?php
class Widget
{
		private $_cache_user_details = array();
		protected $tab_index = 1000;
		public function __construct()
		{
				global $db, $CFG, $LANG;
				$this->setDBObject($db);
				$this->makeGlobalize($CFG, $LANG);
		}
		public function setDBObject($dbObj)
		{
				$this->dbObj = $dbObj;
		}
		public function makeGlobalize($cfg = array(), $lang = array())
		{
				$this->CFG = $cfg;
				$this->LANG = $lang;
		}
		public function getTabIndex()
		{
				$this->tab_index = $this->tab_index + 5;
				return $this->tab_index;
		}
		public function displayNoRecordMessage($msg = '')
		{
?>

<div class="selMsgAlert">
  <p><?php echo $msg; ?></p>
</div>
<?php
		}
		public function stripString($str = '', $length = 256)
		{
				if (strlen($str) > $length) $str = substr($str, 0, ($length - 3)) . '...';
				return $str;
		}
		public function getUserTableFields($user_fields, $trim = true)
		{
				$str = '';
				foreach ($user_fields as $field)
				{
						if (isset($this->CFG['users'][$field]) and $this->CFG['users'][$field]) $str .= $this->CFG['users'][$field] . ' AS ' . $field . ', ';
				}
				if ($trim) $str = substr($str, 0, strrpos($str, ', '));
				return $str;
		}
		public function getUserTableField($user_field)
		{
				return $this->CFG['users'][$user_field];
		}
		public function getWidgetIds($widget_name = '', $limit = 10)
		{
				$insertWidget = $updateWidget = true;
				$widgetIds = array();
				if ($widgetLogs = $this->getIdsForThisWidget($widget_name, $limit))
				{
						$insertWidget = false;
						$CFG['cron']['update'] = false;
						if ($CFG['cron']['update'])
						{
								$widgetIds = $widgetLogs['ids'];
						} elseif ($this->chkIsUpdated($widgetLogs['is_updated']))
						{
								$widgetIds = isset($widgetLogs['ids']) ? $widgetLogs['ids'] : 0;
								$updateWidget = false;
						}
				}
				if ($insertWidget || $updateWidget)
				{
						switch ($widget_name)
						{
								case 'RECENT_QUESTIONS':
										$widgetIds = $this->getRecentQuestions($limit);
										break;
								case 'POPULAR_QUESTIONS':
										$widgetIds = $this->getPopularQuestions($limit);
										break;
								case 'RECENT_FORUMS':
										$widgetIds = $this->getRecentForums($limit);
										break;
								case 'RECENT_BLOGS':
										$widgetIds = $this->getRecentBlogs($limit);
										break;
						}
						if ($insertWidget) $this->insertWidgetIds($widget_name, $widgetIds);
						elseif ($updateWidget) $this->updateWidgetIds($widget_name, $widgetIds);
				}
				return $widgetIds;
		}
		public function getIdsForThisWidget($widget_name = '', $limit = 10)
		{
				$id_in_sql = '';
				for ($i = 1; $i <= $limit; $i++)
				{
						$id_in_sql .= "id_{$i},";
				}
				$id_in_sql = substr($id_in_sql, 0, strrpos($id_in_sql, ','));
				$sql = 'SELECT ' . $id_in_sql . ', date_updated, IF((DATE_ADD(date_updated, INTERVAL ' . $this->CFG['admin']['index']['recent_update'] . ' MINUTE)>=NOW() ), 1, 0) AS is_updated' . ' FROM ' . $this->CFG['db']['tbl']['widget_log'] . ' WHERE widget_name = ' . $this->dbObj->Param($widget_name) . ' LIMIT 1';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($widget_name));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$widgetLogs = array();
				if ($rs->PO_RecordCount())
				{
						$row = $rs->FetchRow();
						$widgetLogs['is_updated'] = $row['is_updated'];
						for ($i = 1; $i <= $limit; $i++)
						{
								$field = 'id_' . $i;
								if ($row[$field])
								{
										$widgetLogs['ids'][] = $row[$field];
								}
						}
				}
				return $widgetLogs;
		}
		public function chkIsUpdated($is_updated)
		{
				if ($is_updated) return true;
				return false;
		}
		public function insertWidgetIds($widget_name, $widgetIds)
		{
				$sql = 'INSERT INTO ' . $this->CFG['db']['tbl']['widget_log'] . ' SET widget_name=\'' . $widget_name . '\', date_updated=NOW(),';
				for ($i = 0; $i < count($widgetIds); $i++)
				{
						$sql .= ' id_' . ($i + 1) . '=' . $widgetIds[$i] . ',';
				}
				$sql = substr($sql, 0, strrpos($sql, ','));
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function updateWidgetIds($widget_name, $widgetIds)
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['widget_log'] . ' SET date_updated=NOW(),';
				for ($i = 0; $i < count($widgetIds); $i++)
				{
						$sql .= ' id_' . ($i + 1) . '=' . $widgetIds[$i] . ',';
				}
				$sql = substr($sql, 0, strrpos($sql, ','));
				$sql .= ' WHERE widget_name=\'' . $widget_name . '\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function getQuestionDetails($ques_id = 0)
		{
				$questionDetails = array();
				$sql = 'SELECT q.ques_id, q.total_answer, q.cat_id, q.best_ans_id, q.status, q.total_stars, q.question, TIMEDIFF(NOW(), date_asked) as date_asked' . ', ' . $this->getUserTableField('name') . ' as asked_by, ' . $this->getUserTableFields(array('image_path', 'gender', 't_height', 't_width', 'photo_server_url', 'photo_ext', 's_width', 's_height'), false) . ' q.user_id' . ', q.user_id AS img_user_id, video_id, audio_id, IF(status=\'Open\' AND date_closed>=NOW(), 1, 0) is_open, TIMEDIFF(date_closed, NOW()) as date_closed' . ', q.total_videos, q.total_audios FROM ' . $this->CFG['db']['tbl']['questions'] . ' AS q, ' . $this->CFG['db']['tbl']['users'] . ' AS u' . ' WHERE q.ques_id=' . $this->dbObj->Param($ques_id) . ' AND q.user_id=u.' . $this->getUserTableField('user_id') . ' AND q.status IN (\'Open\', \'Resolved\')' . ' AND u.' . $this->getUserTableField('usr_status') . '=\'Ok\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($ques_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount())
				{
						$questionDetails = $rs->FetchRow();
						$questionDetails['question_link'] = '<a href="' . getUrl($this->CFG['site']['relative_url'] . 'answer.php?qid=' . $questionDetails['ques_id'], $this->CFG['site']['relative_url'] . 'view/answers/' . $questionDetails['ques_id'] . '/', false) . '">' . wordWrapManual($questionDetails['question'], $this->CFG['admin']['question']['line_length'], $this->CFG['admin']['question']['short_length']) . '</a>';
						$questionDetails['asked_by_link'] = '<a href="' . getUrl($this->CFG['site']['relative_url'] . 'myanswers.php?uid=' . $questionDetails['user_id'], $this->CFG['site']['relative_url'] . 'my/answers/' . $questionDetails['user_id'] . '/', false) . '">' . stripString($questionDetails['asked_by'], $this->CFG['username']['medium_length']) . '</a>';
				}
				return $questionDetails;
		}
		public function getAnswerDetails($ans_id)
		{
				$sql = 'SELECT a.ans_id, a.user_id, a.answer, a.source, TIMEDIFF(NOW(), date_answered) as date_answered' . ', u.' . $this->getUserTableField('user_id') . ' as img_user_id, ' . $this->getUserTableFields(array('image_path', 'gender', 't_height', 't_width', 's_height', 's_width', 'photo_server_url', 'photo_ext'), false) . $this->getUserTableField('name') . ' as answered_by' . ' FROM ' . $this->CFG['db']['tbl']['answers'] . ' AS a' . ', ' . $this->CFG['db']['tbl']['users'] . ' AS u' . ' WHERE a.user_id=u.' . $this->getUserTableField('user_id') . ' AND u.' . $this->getUserTableField('usr_status') . '=\'Ok\'' . ' AND a.ans_id=' . $this->dbObj->Param('aid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($ans_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$answerDetails = array();
				if ($rs->PO_RecordCount())
				{
						$answerDetails = $rs->FetchRow();
						$answerDetails['answered_by_link'] = '<a href="' . getUrl($this->CFG['site']['relative_url'] . 'myanswers.php?uid=' . $answerDetails['user_id'], $this->CFG['site']['relative_url'] . 'my/answers/' . $answerDetails['user_id'] . '/', false) . '">' . $answerDetails['answered_by'] . '</a>';
				}
				return $answerDetails;
		}
		public function getForumDetails($forum_id)
		{
				$forumDetails = array();
				$sql = 'SELECT ft.forum_id, ft.topic_id, ft.forum_topic, ft.user_id, ft.total_response' . ', ft.total_views, ft.last_post_user_id, ft.last_post_date, date_added' . ', u.' . $this->getUserTableField('user_id') . ' AS topic_user_id, u.' . $this->getUserTableField('name') . ' AS topic_user_name' . ', u.' . $this->getUserTableField('image_path') . ' AS image_path, u.' . $this->getUserTableField('gender') . ' AS gender' . ', u.' . $this->getUserTableField('user_id') . ' AS img_user_id, u.' . $this->getUserTableField('t_height') . ' AS t_height' . ', u.' . $this->getUserTableField('t_width') . ' AS t_width, u.' . $this->getUserTableField('photo_server_url') . ' AS photo_server_url' . ', u.' . $this->getUserTableField('s_width') . ' AS s_width, u.' . $this->getUserTableField('s_height') . ' AS s_height' . ', u.' . $this->getUserTableField('photo_ext') . ' AS photo_ext, u.' . $this->getUserTableField('name') . ' AS name' . ', u1.' . $this->getUserTableField('user_id') .
						' AS last_user_id, u1.' . $this->getUserTableField('name') . ' AS last_user_name' . ' FROM ' . $this->CFG['db']['tbl']['forum_topics'] . ' AS ft' . ' LEFT JOIN ' . $this->CFG['db']['tbl']['users'] . ' AS u1 ON ft.last_post_user_id = u1.' . $this->getUserTableField('user_id') . ', ' . $this->CFG['db']['tbl']['users'] . ' AS u' . ' WHERE ft.topic_id=' . $this->dbObj->Param($forum_id) . ' AND ft.user_id = u.' . $this->getUserTableField('user_id') . ' AND u.' . $this->getUserTableField('usr_status') . ' = \'Ok\'' . ' AND topic_status = \'Yes\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($forum_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount())
				{
						$forumDetails = $rs->FetchRow();
						$forumDetails['forum_link'] = '<a href="' . getUrl($this->CFG['site']['url'] . 'forumsResponses.php?forum_id=' . $forumDetails['forum_id'] . '&topic_id=' . $forumDetails['topic_id'], $this->CFG['site']['url'] . 'forum/' . $forumDetails['forum_id'] . '/' . $forumDetails['topic_id'] . '/', false) . '">' . wordWrapManual($forumDetails['forum_topic'], $this->CFG['admin']['forum']['line_length'], $this->CFG['admin']['forum']['short_length']) . '</a>';
						$forumDetails['topic_user_name_link'] = '<a href="' . getUrl($this->CFG['site']['relative_url'] . 'myanswers.php?uid=' . $forumDetails['topic_user_id'], $this->CFG['site']['relative_url'] . 'my/answers/' . $forumDetails['topic_user_id'] . '/', false) . '">' . stripString($forumDetails['topic_user_name'], $this->CFG['username']['medium_length']) . '</a>';
				}
				return $forumDetails;
		}
		public function getBlogDetails($blog_id)
		{
				$blogDetails = array();
				$sql = 'SELECT blog_id, subject, message, total_comments, total_views, b.user_id, date_added' . ' FROM ' . $this->CFG['db']['tbl']['blogs'] . ' AS b' . ' WHERE status=\'Active\'' . ' AND blog_id=' . $this->dbObj->Param($blog_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($blog_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount())
				{
						$blogDetails = $rs->FetchRow();
						$blogDetails['blog_link'] = '<a href="' . getUrl($this->CFG['site']['url'] . 'blogComment.php?blog_id=' . $blogDetails['blog_id'], $this->CFG['site']['url'] . 'blogcomment/?blog_id=' . $blogDetails['blog_id'], false) . '">' . wordWrapManual($blogDetails['subject'], $this->CFG['admin']['blog']['line_length'], $this->CFG['admin']['blog']['short_length']) . '</a>';
				}
				return $blogDetails;
		}
		public function getRecentQuestions($limit = 5)
		{
				$sql = 'SELECT q.ques_id FROM ' . $this->CFG['db']['tbl']['questions'] . ' AS q' . ' WHERE q.status IN (\'Open\', \'Resolved\')' . ' ORDER BY ques_id DESC LIMIT 0,' . $limit;
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$recent_questions = array();
				while ($row = $rs->FetchRow())
				{
						$recent_questions[] = $row['ques_id'];
				}
				return $recent_questions;
		}
		public function displayRecentQuestions($limit = 5)
		{
				$recent_questions = $this->getRecentQuestions($limit);

?>
<div id="selWidgetRecentQuestions" class="clsSideBarSections">
  <h3><?php echo $this->LANG['common_recent_question_title']; ?></h3>
  <?php
				if ($recent_questions)
				{
?>
  <div class="clsSideBarContents">
    <?php
						$i = 0;
						foreach ($recent_questions as $eachQuestion)
						{
								$questionDetails = $this->getQuestionDetails($eachQuestion);
								$i++;
								$clsOddOrEvenQuestion = 'clsEvenQuestion';
								if ($i % 2) $clsOddOrEvenQuestion = 'clsOddQuestion';
								$answer_plural = '';
								if ($questionDetails['total_answer'] != 1) $answer_plural = 's';
?>
    <div>
      <div class="<?php echo $clsOddOrEvenQuestion; ?> clsUserThumbDetails">
        <?php if (chkUserImageAllowed())
								{ ?>
		<div class="clsUserThumb">
          <p id="selImageBorder">
            <?php displayUserImage($questionDetails, 'small'); ?>
          </p>
        </div>
        <?php } ?>
        <div class="clsUserDetails">
          <p class="clsQuestionLink"><?php echo $questionDetails['question_link']; ?></p>
          <p> <span class="clsUserLink"><?php echo $this->LANG['common_question_asked_by'] . ' ' . $questionDetails['asked_by_link']; ?></span> <span><?php echo getTimeDiffernceFormat($questionDetails['date_asked']); ?></span> <span class="clsNoBorder"><?php echo $questionDetails['total_answer'] . ' ' . $this->LANG['common_total_answers'] . $answer_plural; ?></span> </p>
        </div>
      </div>
    </div>
    <?php
						}


?>
    <p class="clsMoreLink"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'questions.php?view=recent', $this->CFG['site']['relative_url'] . 'answers/recent/', false); ?>"><?php echo $this->LANG['more']; ?></a></p>
  </div>
  <?php
				}
				else
				{
?>
  <div class="clsNoRecords">
    <p><?php echo $this->LANG['common_no_questions']; ?></p>
  </div>
  <?php
				}
?>
</div>
<?php
		}
		public function getPopularQuestions($limit = 5)
		{
				$sql = 'SELECT q.ques_id FROM ' . $this->CFG['db']['tbl']['questions'] . ' AS q' . ' WHERE q.status IN (\'Open\', \'Resolved\')' . ' AND total_views > 0 ORDER BY total_views DESC LIMIT 0,' . $limit;
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$popular_questions = array();
				while ($row = $rs->FetchRow())
				{
						$popular_questions[] = $row['ques_id'];
				}
				return $popular_questions;
		}
		public function displayPopularQuestions($limit = 5)
		{
				$popular_questions = $this->getWidgetIds('POPULAR_QUESTIONS', $limit);
?>
<div id="selWidgetPopularQuestions" class="clsSideBarSections">
  <h3><?php echo $this->LANG['common_popular_question_title']; ?></h3>
  <?php
				$found = false;
				if ($popular_questions)
				{
?>
  <div class="clsSideBarContents">
    <?php
						$i = 0;
						foreach ($popular_questions as $eachQuestion)
						{
								$questionDetails = $this->getQuestionDetails($eachQuestion);
								if (!$questionDetails) continue;
								$i++;
								$found = true;
								$clsOddOrEvenQuestion = 'clsEvenQuestion';
								if ($i % 2) $clsOddOrEvenQuestion = 'clsOddQuestion';
								$answer_plural = '';
								if ($questionDetails['total_answer'] != 1) $answer_plural = 's';
?>
    <div>
      <div class="<?php echo $clsOddOrEvenQuestion; ?> clsUserThumbDetails">
        <?php if (chkUserImageAllowed())
								{ ?>
		<div class="clsUserThumb">
          <p id="selImageBorder">
            <?php displayUserImage($questionDetails, 'small'); ?>
          </p>
        </div>
        <?php } ?>
        <div class="clsUserDetails">
          <p class="clsQuestionLink"><?php echo $questionDetails['question_link']; ?></p>
          <p> <span class="clsUserLink"><?php echo $this->LANG['common_question_asked_by'] . ' ' . $questionDetails['asked_by_link']; ?></span> <span><?php echo getTimeDiffernceFormat($questionDetails['date_asked']); ?></span> <span class="clsNoBorder"><?php echo $questionDetails['total_answer'] . ' ' . $this->LANG['common_total_answers'] . $answer_plural; ?></span> </p>
        </div>
      </div>
    </div>
    <?php
						}
						if ($found)
						{
?>
    <p class="clsMoreLink"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'questions.php?view=popular', $this->CFG['site']['relative_url'] . 'answers/popular/', false); ?>"><?php echo $this->LANG['more']; ?></a></p>
<?php
						}
?>
  </div>
  <?php
				}
				if (!$found)
				{
?>
  <div class="clsNoRecords">
    <p><?php echo $this->LANG['common_no_questions']; ?></p>
  </div>
  <?php
				}
?>
</div>
<?php
		}
		public function getVideoQuestions($limit = 5)
		{
				$sql = 'SELECT q.ques_id FROM ' . $this->CFG['db']['tbl']['questions'] . ' AS q' . ' WHERE q.status IN (\'Open\', \'Resolved\')' . ' AND video_id != 0 ORDER BY ques_id DESC LIMIT 0,' . $limit;
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$video_questions = array();
				while ($row = $rs->FetchRow())
				{
						$video_questions[] = $row['ques_id'];
				}
				return $video_questions;
		}
		public function displayVideoQuestions($limit = 5)
		{
				$video_questions = $this->getVideoQuestions($limit);
?>
<div id="selWidgetVideoQuestions" class="clsSideBarSections">
  <h3><?php echo $this->LANG['common_video_question_title']; ?></h3>
  <?php
				if ($video_questions)
				{
?>
  <div class="clsSideBarContents">
    <?php
						$i = 0;
						foreach ($video_questions as $eachQuestion)
						{
								$questionDetails = $this->getQuestionDetails($eachQuestion);
								$i++;
								$clsOddOrEvenQuestion = 'clsEvenQuestion';
								if ($i % 2) $clsOddOrEvenQuestion = 'clsOddQuestion';
								$answer_plural = '';
								if ($questionDetails['total_answer'] != 1) $answer_plural = 's';
?>
    <div>
      <div class="<?php echo $clsOddOrEvenQuestion; ?> clsUserThumbDetails">
        <?php if (chkUserImageAllowed())
								{ ?>
		<div class="clsUserThumb">
          <p id="selImageBorder">
            <?php displayUserImage($questionDetails, 'small'); ?>
          </p>
        </div>
        <?php } ?>
        <div class="clsUserDetails">
          <p class="clsQuestionLink"><?php echo $questionDetails['question_link']; ?></p>
          <p> <span class="clsUserLink"><?php echo $this->LANG['common_question_asked_by'] . ' ' . $questionDetails['asked_by_link']; ?></span> <span><?php echo getTimeDiffernceFormat($questionDetails['date_asked']); ?></span> <span class="clsNoBorder"><?php echo $questionDetails['total_answer'] . ' ' . $this->LANG['common_total_answers'] . $answer_plural; ?></span> </p>
        </div>
      </div>
    </div>
    <?php
						}


?>
    <p class="clsMoreLink"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'questions.php?view=search&video=1', $this->CFG['site']['relative_url'] . 'answers/search/?video=1', false); ?>"><?php echo $this->LANG['more']; ?></a></p>
  </div>
  <?php
				}
				else
				{
?>
  <div class="clsNoRecords">
    <p><?php echo $this->LANG['common_no_questions']; ?></p>
  </div>
  <?php
				}
?>
</div>
<?php
		}
		public function getAudioQuestions($limit = 5)
		{
				$sql = 'SELECT q.ques_id FROM ' . $this->CFG['db']['tbl']['questions'] . ' AS q' . ' WHERE q.status IN (\'Open\', \'Resolved\')' . ' AND audio_id != 0 ORDER BY ques_id DESC LIMIT 0,' . $limit;
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$audio_questions = array();
				while ($row = $rs->FetchRow())
				{
						$audio_questions[] = $row['ques_id'];
				}
				return $audio_questions;
		}
		public function displayAudioQuestions($limit = 5)
		{
				$audio_questions = $this->getAudioQuestions($limit);
?>
<div id="selWidgetRecentQuestions" class="clsSideBarSections">
  <h3><?php echo $this->LANG['common_audio_question_title']; ?></h3>
  <?php
				if ($audio_questions)
				{
?>
  <div class="clsSideBarContents">
    <?php
						$i = 0;
						foreach ($audio_questions as $eachQuestion)
						{
								$questionDetails = $this->getQuestionDetails($eachQuestion);
								$i++;
								$clsOddOrEvenQuestion = 'clsEvenQuestion';
								if ($i % 2) $clsOddOrEvenQuestion = 'clsOddQuestion';
								$answer_plural = '';
								if ($questionDetails['total_answer'] != 1) $answer_plural = 's';
?>
    <div>
      <div class="<?php echo $clsOddOrEvenQuestion; ?> clsUserThumbDetails">
        <?php if (chkUserImageAllowed())
								{ ?>
		<div class="clsUserThumb">
          <p id="selImageBorder">
            <?php displayUserImage($questionDetails, 'small'); ?>
          </p>
        </div>
        <?php } ?>
        <div class="clsUserDetails">
          <p class="clsQuestionLink"><?php echo $questionDetails['question_link']; ?></p>
          <p> <span class="clsUserLink"><?php echo $this->LANG['common_question_asked_by'] . ' ' . $questionDetails['asked_by_link']; ?></span> <span><?php echo getTimeDiffernceFormat($questionDetails['date_asked']); ?></span> <span class="clsNoBorder"><?php echo $questionDetails['total_answer'] . ' ' . $this->LANG['common_total_answers'] . $answer_plural; ?></span> </p>
        </div>
      </div>
    </div>
    <?php
						}


?>
    <p class="clsMoreLink"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'questions.php?view=search&audio=1', $this->CFG['site']['relative_url'] . 'answers/search/?audio=1', false); ?>"><?php echo $this->LANG['more']; ?></a></p>
  </div>
  <?php
				}
				else
				{
?>
  <div class="clsNoRecords">
    <p><?php echo $this->LANG['common_no_questions']; ?></p>
  </div>
  <?php
				}
?>
</div>
<?php
		}
		public function getRecentForums($limit = 5)
		{
				$sql = 'SELECT ft.topic_id FROM ' . $this->CFG['db']['tbl']['forum_topics'] . ' AS ft' . ' WHERE topic_status = \'Yes\'' . ' ORDER BY ft.topic_id DESC LIMIT 0,' . $limit;
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$recent_forums = array();
				while ($row = $rs->FetchRow())
				{
						$recent_forums[] = $row['topic_id'];
				}
				return $recent_forums;
		}
		public function displayRecentForums($limit = 5)
		{
				$recent_forums = $this->getRecentForums($limit);
?>
<div id="selWidgetRecentForums" class="clsSideBarSections">
  <h3><?php echo $this->LANG['common_recent_forum_title']; ?></h3>
  <?php
				if ($recent_forums)
				{
?>
  <div class="clsSideBarContents">
    <?php
						$i = 0;
						foreach ($recent_forums as $eachForum)
						{
								$forumDetails = $this->getForumDetails($eachForum);
								$i++;
								$clsOddOrEvenQuestion = 'clsEvenQuestion';
								if ($i % 2) $clsOddOrEvenQuestion = 'clsOddQuestion';
								$resp_plural = '';
								$view_plural = '';
								if ($forumDetails['total_response'] != 1) $resp_plural = 's';
								if ($forumDetails['total_views'] != 1) $view_plural = 's';

?>
    <div>
      <div class="<?php echo $clsOddOrEvenQuestion; ?> clsUserThumbDetails">
        <?php if (chkUserImageAllowed())
								{ ?>
		<div class="clsUserThumb">
          <p id="selImageBorder">
            <?php displayUserImage($forumDetails, 'small'); ?>
          </p>
        </div>
        <?php } ?>
        <div class="clsUserDetails">
          <p class="clsQuestionLink"><?php echo $forumDetails['forum_link']; ?></p>
          <p> <span class="clsUserLink"><?php echo $this->LANG['common_forum_started_by'] . ' ' . $forumDetails['topic_user_name_link']; ?></span> <span><?php echo $forumDetails['total_response'] . ' ' . $this->LANG['common_total_responses'] . $resp_plural; ?></span> <span class="clsNoBorder"><?php echo $forumDetails['total_views'] . ' ' . $this->LANG['common_total_views'] . $view_plural; ?></span> </p>
        </div>
      </div>
    </div>
    <?php
						}


?>
    <p class="clsMoreLink"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'forums.php', $this->CFG['site']['relative_url'] . 'forum/', false); ?>"><?php echo $this->LANG['more']; ?></a></p>
  </div>
  <?php
				}
				else
				{
?>
  <div class="clsNoRecords">
    <p><?php echo $this->LANG['common_no_forums']; ?></p>
  </div>
  <?php
				}
?>
</div>
<?php
		}
		public function getMostRepliedForums($limit = 5)
		{
				$sql = 'SELECT ft.topic_id FROM ' . $this->CFG['db']['tbl']['forum_topics'] . ' AS ft' . ' WHERE topic_status = \'Yes\' AND total_response > 0' . ' ORDER BY ft.total_response DESC LIMIT 0,' . $limit;
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$most_replied_forums = array();
				while ($row = $rs->FetchRow())
				{
						$most_replied_forums[] = $row['topic_id'];
				}
				return $most_replied_forums;
		}
		public function displayMostForumReplies($limit = 5)
		{
				$most_replied_forums = $this->getMostRepliedForums($limit);
?>
<div id="selWidgetRecentForums" class="clsSideBarSections">
  <h3><?php echo $this->LANG['common_most_replied_forum_title']; ?></h3>
  <?php
				if ($most_replied_forums)
				{
?>
  <div class="clsSideBarContents">
    <?php
						$i = 0;
						foreach ($most_replied_forums as $eachForum)
						{
								$forumDetails = $this->getForumDetails($eachForum);
								$i++;
								$clsOddOrEvenQuestion = 'clsEvenQuestion';
								if ($i % 2) $clsOddOrEvenQuestion = 'clsOddQuestion';
								$resp_plural = '';
								$view_plural = '';
								if ($forumDetails['total_response'] != 1) $resp_plural = 's';
								if ($forumDetails['total_views'] != 1) $view_plural = 's';
?>
    <div>
      <div class="<?php echo $clsOddOrEvenQuestion; ?> clsUserThumbDetails">
        <?php if (chkUserImageAllowed())
								{ ?>
		<div class="clsUserThumb">
          <p id="selImageBorder">
            <?php displayUserImage($forumDetails, 'small'); ?>
          </p>
        </div>
        <?php } ?>
        <div class="clsUserDetails">
          <p class="clsQuestionLink"><?php echo $forumDetails['forum_link']; ?></p>
          <p> <span class="clsUserLink"><?php echo $this->LANG['common_forum_started_by'] . ' ' . $forumDetails['topic_user_name_link']; ?></span> <span><?php echo $forumDetails['total_response'] . ' ' . $this->LANG['common_total_responses'] . $resp_plural; ?></span> <span class="clsNoBorder"><?php echo $forumDetails['total_views'] . ' ' . $this->LANG['common_total_views'] . $view_plural; ?></span> </p>
        </div>
      </div>
    </div>
    <?php
						}


?>
    <p class="clsMoreLink"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'forums.php', $this->CFG['site']['relative_url'] . 'forum/', false); ?>"><?php echo $this->LANG['more']; ?></a></p>
  </div>
  <?php
				}
				else
				{
?>
  <div class="clsNoRecords">
    <p><?php echo $this->LANG['common_no_forums']; ?></p>
  </div>
  <?php
				}
?>
</div>
<?php
		}
		public function getRecentBlogs($limit = 5)
		{
				$sql = 'SELECT blog_id FROM ' . $this->CFG['db']['tbl']['blogs'] . ' AS b' . ' WHERE status=\'Active\'' . ' ORDER BY blog_id DESC LIMIT 0,' . $limit;
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$recent_blogs = array();
				while ($row = $rs->FetchRow())
				{
						$recent_blogs[] = $row['blog_id'];
				}
				return $recent_blogs;
		}
		public function displayRecentBlogs($limit = 5)
		{
				$recent_blogs = $this->getRecentBlogs($limit);
?>
<div id="selWidgetRecentBlogs" class="clsSideBarSections">
  <h3><?php echo $this->LANG['common_recent_blog_title']; ?></h3>
  <?php
				if ($recent_blogs)
				{
?>
  <div class="clsSideBarContents">
    <?php
						$i = 0;
						foreach ($recent_blogs as $eachBlog)
						{
								$blogDetails = $this->getBlogDetails($eachBlog);
								$i++;
								$clsOddOrEvenQuestion = 'clsEvenQuestion';
								if ($i % 2) $clsOddOrEvenQuestion = 'clsOddQuestion';
								$comment_plural = '';
								$view_plural = '';
								if ($blogDetails['total_comments'] != 1) $comment_plural = 's';
								if ($blogDetails['total_views'] != 1) $view_plural = 's';
?>
    <div>
      <div class="<?php echo $clsOddOrEvenQuestion; ?> clsUserThumbDetails">
        <div class="clsUserDet">
          <p class="clsQuestionLink"><?php echo $blogDetails['blog_link']; ?></p>
          <p> <span><?php echo $blogDetails['total_comments'] . ' ' . $this->LANG['common_total_comments'] . $comment_plural; ?></span> <span class="clsNoBorder"><?php echo $blogDetails['total_views'] . ' ' . $this->LANG['common_total_views'] . $view_plural; ?></span> </p>
        </div>
      </div>
    </div>
    <?php
						}


?>
    <p class="clsMoreLink"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'blogs.php', $this->CFG['site']['relative_url'] . 'blog/', false); ?>"><?php echo $this->LANG['more']; ?></a></p>
  </div>
  <?php
				}
				else
				{
?>
  <div class="clsNoRecords">
    <p><?php echo $this->LANG['common_no_blogs']; ?></p>
  </div>
  <?php
				}
?>
</div>
<?php
		}
		public function getMostCommentedBlogs($limit = 5)
		{
				$sql = 'SELECT blog_id FROM ' . $this->CFG['db']['tbl']['blogs'] . ' AS b' . ' WHERE status=\'Active\' AND total_comments>0' . ' ORDER BY total_comments DESC LIMIT 0,' . $limit;
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$most_commented_blogs = array();
				while ($row = $rs->FetchRow())
				{
						$most_commented_blogs[] = $row['blog_id'];
				}
				return $most_commented_blogs;
		}
		public function displayMostBlogComments($limit = 5)
		{
				$most_commented_blogs = $this->getMostCommentedBlogs($limit);
?>
<div id="selWidgetRecentBlogs" class="clsSideBarSections">
  <h3><?php echo $this->LANG['common_most_commented_blog_title']; ?></h3>
  <?php
				if ($most_commented_blogs)
				{
?>
  <div class="clsSideBarContents">
    <?php
						$i = 0;
						foreach ($most_commented_blogs as $eachBlog)
						{
								$blogDetails = $this->getBlogDetails($eachBlog);
								$i++;
								$clsOddOrEvenQuestion = 'clsEvenQuestion';
								if ($i % 2) $clsOddOrEvenQuestion = 'clsOddQuestion';
								$comment_plural = '';
								$view_plural = '';
								if ($blogDetails['total_comments'] != 1) $comment_plural = 's';
								if ($blogDetails['total_views'] != 1) $view_plural = 's';
?>
    <div>
      <div class="<?php echo $clsOddOrEvenQuestion; ?> clsUserThumbDetails">
        <div class="clsUserDet">
          <p class="clsQuestionLink"><?php echo $blogDetails['blog_link']; ?></p>
          <p> <span><?php echo $blogDetails['total_comments'] . ' ' . $this->LANG['common_total_comments'] . $comment_plural; ?></span> <span class="clsNoBorder"><?php echo $blogDetails['total_views'] . ' ' . $this->LANG['common_total_views'] . $view_plural; ?></span> </p>
        </div>
      </div>
    </div>
    <?php
						}


?>
    <p class="clsMoreLink"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'blogs.php', $this->CFG['site']['relative_url'] . 'blog/', false); ?>"><?php echo $this->LANG['more']; ?></a></p>
  </div>
  <?php
				}
				else
				{
?>
  <div class="clsNoRecords">
    <p><?php echo $this->LANG['common_no_blogs']; ?></p>
  </div>
  <?php
				}
?>
</div>
<?php
		}
		public function getTags($type, $limit)
		{
				$sql = 'SELECT tag_name, search_count, total_count FROM ' . $this->CFG['db']['tbl']['tags'];
				if ($type == 'SEARCH') $sql .= ' WHERE search_count>0 AND total_count>0 ORDER BY search_count DESC';
				else  $sql .= ' WHERE total_count>0 ORDER BY total_count DESC';
				$sql .= ' LIMIT 0,' . $limit;
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$tagArray = array();
				if ($rs->PO_RecordCount())
				{
						while ($row = $rs->FetchRow())
						{
								$tagArray[] = $row;
						}
				}
				return $tagArray;
		}
		public function setFontSizeInsteadOfSearchCount($tag_array = array())
		{
				$formattedArray = $tag_array;
				$max_qty = max(array_values($formattedArray));
				$min_qty = min(array_values($formattedArray));
				$max_font_size = 28;
				$min_font_size = 12;
				$spread = $max_qty - $min_qty;
				if (0 == $spread)
				{
						$spread = 1;
				}
				$step = ($max_font_size - $min_font_size) / ($spread);
				foreach ($tag_array as $catname => $count)
				{
						$size = $min_font_size + ($count - $min_qty) * $step;
						$formattedArray[$catname] = ceil($size);
				}
				return $formattedArray;
		}
		public function displayTopTags($limit = 5)
		{
				$top_tags = $this->getTags('TOP', $limit);
?>
<div id="selWidgetTopTags" class="clsSideBarSections">
  <div class="clsSideBarContents">
    <!--rounded corners-->
    <div class="lbsidebarsections">
      <div class="rbsidebarsections">
        <div class="bbsidebarsections">
          <div class="blcsidebarsections">
            <div class="brcsidebarsections">
              <div class="tbsidebarsections">
                <div class="tlcsidebarsections">
                  <div class="trcsidebarsections">
                    <h3><?php echo $this->LANG['common_top_tags_title']; ?></h3>
                    <?php
				if (!$top_tags)
				{
?>
<p><?php echo $this->LANG['common_no_tags_found']; ?></p>
<?php
				}
				else
				{
						$classes = array('clsTagStyleBlue', 'clsTagStyleGrey', 'clsTagStyleGreen', 'clsTagStyleRed');
						$tagClassArray = array();
						foreach ($top_tags as $row)
						{
								$tagArray[$row['tag_name']] = $row['total_count'];
								$class = $classes[rand(0, count($classes)) % count($classes)];
								$tagClassArray[$row['tag_name']] = $class;
						}
						$tagArray = $this->setFontSizeInsteadOfSearchCount($tagArray);
						foreach ($tagArray as $tag => $fontSize)
						{
								$url = getUrl($this->CFG['site']['relative_url'] . 'questions.php?view=search&tags=' . $tag, $this->CFG['site']['relative_url'] . 'answers/search/?tags=' . $tag, false);
								$class = $tagClassArray[$tag];
								$fontSizeClass = 'style="font-size:' . $fontSize . 'px"';
?>
                    	<span class="<?php echo $class; ?>"><a href="<?php echo $url; ?>" <?php echo $fontSizeClass; ?>><?php echo $tag; ?></a></span>
<?php
						}


?>
                    	<p class="clsMoreLink"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'tags.php?t=freq&s=f', $this->CFG['site']['relative_url'] . 'tags/?t=freq&s=f', false); ?>"><?php echo $this->LANG['more']; ?></a></p>
<?php
				}
?>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!--end of rounded corners-->
  </div>
</div>
<?php
		}
		public function displayTopSearchedTags($limit = 5)
		{
				$top_tags = $this->getTags('SEARCH', $limit);
?>
<div id="selWidgetTopSearchedTags" class="clsSideBarSections">
  <div class="clsSideBarContents">
    <!--rounded corners-->
    <div class="lbsidebarsections">
      <div class="rbsidebarsections">
        <div class="bbsidebarsections">
          <div class="blcsidebarsections">
            <div class="brcsidebarsections">
              <div class="tbsidebarsections">
                <div class="tlcsidebarsections">
                  <div class="trcsidebarsections">
                    <h3><?php echo $this->LANG['common_top_search_tags_title']; ?></h3>
                    <?php
				if (!$top_tags)
				{
?>
<p><?php echo $this->LANG['common_no_tags_found']; ?></p>
<?php
				}
				else
				{
						$classes = array('clsTagStyleBlue', 'clsTagStyleGrey', 'clsTagStyleGreen', 'clsTagStyleRed');
						$tagClassArray = array();
						foreach ($top_tags as $row)
						{
								$tagArray[$row['tag_name']] = $row['search_count'];
								$class = $classes[rand(0, count($classes)) % count($classes)];
								$tagClassArray[$row['tag_name']] = $class;
						}
						$tagArray = $this->setFontSizeInsteadOfSearchCount($tagArray);
						foreach ($tagArray as $tag => $fontSize)
						{
								$url = getUrl($this->CFG['site']['relative_url'] . 'questions.php?view=search&tags=' . $tag, $this->CFG['site']['relative_url'] . 'answers/search/?tags=' . $tag, false);
								$class = $tagClassArray[$tag];
								$fontSizeClass = 'style="font-size:' . $fontSize . 'px"';
?>
                    <span class="<?php echo $class; ?>"><a href="<?php echo $url; ?>" <?php echo $fontSizeClass; ?>><?php echo $tag; ?></a></span>
<?php
						}


?>
                    <p class="clsMoreLink"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'tags.php?t=search&s=f', $this->CFG['site']['relative_url'] . 'tags/?t=search&s=f', false); ?>"><?php echo $this->LANG['more']; ?></a></p>
<?php
				}
?>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!--end of rounded corners-->
  </div>
</div>
<?php
		}
		public function getBestAnsQuestions($limit = 5)
		{
				$sql = 'SELECT q.ques_id FROM ' . $this->CFG['db']['tbl']['questions'] . ' AS q' . ' WHERE q.status IN (\'Open\', \'Resolved\') AND best_ans_id!=0' . ' ORDER BY date_answered DESC LIMIT 0,' . $limit;
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$best_ans_questions = array();
				while ($row = $rs->FetchRow())
				{
						$best_ans_questions[] = $row['ques_id'];
				}
				return $best_ans_questions;
		}
		public function widgetAutoScrolling($content, $limit = 5)
		{
				$best_ans_questions = $this->getBestAnsQuestions($limit);
?>
<script type="text/javascript">
	var SITE_URL = '<?php echo $this->CFG['site']['url']; ?>';
	var jsBestAnswerScrollTime = '<?php echo $this->CFG['admin']['index_scroll_time'] * 1000; ?>';
	var jsTimerAutoScrollBestAnswer = null;
	var scrollBest = true;
	var isScrolling = true;
	var jsBestAnswerContainer = 'jsBestAnswerContainer';
	var mooSlider = false;
	var mooTransition = !mooSlider;
</script>
<script type="text/javascript" language="javascript" src="<?php echo $this->CFG['site']['url']; ?>js/mootools.js"></script>
<script type="text/javascript" language="javascript" src="<?php echo $this->CFG['site']['url']; ?>js/mootools.ajax.js"></script>
<script type="text/javascript" language="javascript" src="<?php echo $this->CFG['site']['url']; ?>js/questions.js"></script>
<?php
				if (!sizeof($best_ans_questions))
				{
?>
<div class="clsScrollerSection">
  <div class="clsScrollerLeftSection">
    <div class="clsScrollerMiddleSection">
      <div class="clsScrollerRightSection">
        <div class="clsScrollerContent">
          <h3 class="clsAnswersTitle"><?php echo $this->LANG['common_best_answer_title']; ?> <span class="clsText"><?php echo $this->LANG['common_best_answer_text']; ?></span></h3>
          <div id="user1" style="height:165px;overflow:hidden;position:relative;">
            <div id="user1Sub" style="height:165px;overflow:hidden;">
              <div id="user1pad" style="height:165px;overflow:hidden;">
                <div class="" id="jsBestAnswerContainer" style="height:130px;overflow:hidden;">
<?php
						echo 'No questions with best answers found';
?>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php
						return;
				}
?>
<div class="clsScrollerSection">
  <div class="clsScrollerLeftSection">
    <div class="clsScrollerMiddleSection">
      <div class="clsScrollerRightSection">
        <div class="clsScrollerContent">
          <h3 class="clsAnswersTitle"><?php echo $this->LANG['common_best_answer_title']; ?> <span class="clsText"><?php echo $this->LANG['common_best_answer_text']; ?></span></h3>
          <div id="user1" style="height:165px;overflow:hidden;position:relative;">
            <div id="user1Sub" style="height:165px;overflow:hidden;">
              <div id="user1pad" style="height:165px;overflow:hidden;">
                <div class="" id="jsBestAnswerContainer" style="height:130px;overflow:hidden;">
                  <?php
				$content_arr = array();
				$inc = 1;
				$first = true;
				foreach ($best_ans_questions as $eachQuestion)
				{
						$display = ($first) ? 'block' : 'none';
						$first = false;
						$content_arr[] = $inc;
						$questionDetails = $this->getQuestionDetails($eachQuestion);
						$answerDetails = $this->getAnswerDetails($questionDetails['best_ans_id']);
?>
                  <div class="jsBestAnswers" id="best_<?php echo $inc; ?>" style="display:<?php echo $display ?>;overflow:hidden">
                    <div class="clsUserThumbDetails" style="overflow:hidden">
                      <?php if (chkUserImageAllowed())
						{ ?>
					  <div class="clsUserThumb">
                        <p id="selImageBorder">
                          <?php displayUserImage($questionDetails, 'small', false); ?>
                        </p>
                      </div>
                      <?php } ?>
                      <div class="clsUserDetails">
                        <p class="clsQuestion"><?php echo $questionDetails['question_link']; ?></p>
                        <p><span><?php echo $this->LANG['common_question_asked_by'] . ' ' . $questionDetails['asked_by_link']; ?></span> <span><?php echo getTimeDiffernceFormat($questionDetails['date_asked']); ?></span> <span class="clsNoBorder"><?php echo $questionDetails['total_answer'] . ' ' . $this->LANG['common_total_answers']; ?></span></p>
                      </div>
                    </div>
                    <div class="clsUserThumbDetails">
                      <?php if (chkUserImageAllowed())
						{ ?>
					  <div class="clsUserThumb">
                        <p id="selImageBorder">
                          <?php displayUserImage($answerDetails, 'small', false); ?>
                        </p>
                      </div>
                      <?php } ?>
                      <div class="clsUserDetails">
                        <p class="clsQuestion">
                        <p class="clsAnswer"><?php echo wordWrapManual($answerDetails['answer'], 25, 100); ?></p>
                        <p> <span><?php echo $this->LANG['common_question_answered_by'] . ' ' . $answerDetails['answered_by_link']; ?></span><span class="clsMore clsNoBorder"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'answer.php?qid=' . $eachQuestion, $this->CFG['site']['relative_url'] . 'view/answers/' . $eachQuestion . '/', false); ?>"><?php echo $this->LANG['more']; ?></a></span></p>
                        </p>
                      </div>
                    </div>
                  </div>
                  <?php
						$inc++;
				}
?>
                </div>
                <div class="moveThrough" id="jsBestAnswerNavigator"> <a id="jsButtonPrev" href="#" onclick="prevAnswer();return false"><img src="<?php echo $this->CFG['site']['url'] . 'images'; ?>/rewind.gif" /></a> <span>&nbsp;</span> <a id="jsButtonPause" href="#" onclick="pauseBestAnswer();return false"><img src="<?php echo $this->CFG['site']['url'] . 'images'; ?>/pause.gif" alt="pause" /></a> <a style="display: none;" id="jsButtonPlay" style="display: inline;" href="#" onclick="playBestAnswer();return false"><img src="<?php echo $this->CFG['site']['url'] . 'images'; ?>/play.gif" alt="play" /></a> <span>&nbsp;</span> <a id="jsButtonNext" href="#" onclick="nextAnswer();return false"><img src="<?php echo $this->CFG['site']['url'] . 'images'; ?>/forward.gif" /></a> </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript">
	var jsBestAnswerSet = new Array(<?php echo implode(',', $content_arr); ?>);
	var bestAnswer = $('jsBestAnswerContainer');
	if(bestAnswer != null){
		var bestAnswerCoordinates = bestAnswer.getCoordinates();
		str = "";
		for (var i in bestAnswerCoordinates){
			str += i + " = " + bestAnswerCoordinates[i] + "\n";
		}
		//alert(str)
		var bestAnswerStartsFrom = (bestAnswerCoordinates.left + bestAnswerCoordinates.width);
		var bestAnswerEndsTo = (bestAnswerCoordinates.left);
		var jsBestLeft = [];
		var jsBestRight = [];
		var curDiv = 0;
		if(jsBestAnswerSet.length > 1){
			curDiv = 'best_' + jsBestAnswerSet[0];
			scrollBestAnswer();
		}
	}
</script>
<?php
		}
		public function getUserDetails($user_id)
		{
				$sql = 'SELECT ' . $this->getUserTableFields(array('user_id', 'name', 'email', 'image_path', 'gender', 'usr_status', 'user_access', 't_height', 't_width', 's_height', 's_width', 'photo_server_url', 'photo_ext')) . ', ' . $this->getUserTableField('user_id') . ' AS img_user_id' . ' FROM ' . $this->CFG['db']['tbl']['users'] . ' WHERE ' . $this->getUserTableField('user_id') . '=' . $this->dbObj->Param($user_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($user_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = array('name' => '', 'email' => '', 'image_path' => '', 'gender' => '', 'usr_status' => '', 'user_access' => '', 'img_user_id' => '', 't_height' => '', 't_width' => '', 's_height' => '', 's_width' => '', 'photo_server_url' => '', 'photo_ext' => '');
				if ($rs->PO_RecordCount())
				{
						$row = $rs->FetchRow();
				}
				return $row;
		}
		public function getUserLog($uid)
		{
				$sql = 'SELECT total_ques, total_ans, total_points' . ', DATE_FORMAT(date_updated,\'%D %b %Y\') as date_updated' . ' FROM ' . $this->CFG['db']['tbl']['users_ans_log'] . ' WHERE user_id=' . $this->dbObj->Param($uid);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($uid));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$user_ans_log = array('total_ques' => '0', 'total_ans' => '0', 'total_points' => '0', 'date_updated' => '');
				if ($rs->PO_RecordCount()) $user_ans_log = $rs->FetchRow();
				return $user_ans_log;
		}
		public function getResolvedQuestions($uid)
		{
				$sql = 'SELECT COUNT(ques_id) AS resolved FROM ' . $this->CFG['db']['tbl']['questions'] . ' WHERE user_id=' . $this->dbObj->Param($uid) . ' AND status=\'Resolved\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($uid));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = $rs->FetchRow();
				return $row['resolved'];
		}
		public function getFeaturedAnalystIds($limit)
		{
				$sql = 'SELECT user_id FROM ' . $this->CFG['db']['tbl']['users_ans_log'] . ' WHERE date_updated >= DATE_SUB(NOW(), INTERVAL ' . $this->CFG['admin']['index']['featured_analyst_period'] . ' DAY)' . ' ORDER BY total_points DESC LIMIT 0, ' . $limit;
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$featured_analysts = array();
				while ($row = $rs->FetchRow())
				{
						$featured_analysts[] = $row['user_id'];
				}
				return $featured_analysts;
		}
		public function displayFeaturedAnalyst($limit = 2)
		{
				$featured_analysts = $this->getFeaturedAnalystIds($limit);

?>
<div id="selWidgetFeaturedAnalyst" class="clsFeaturedAnalyst clsSideBarSections">
  <h3><?php echo $this->LANG['common_featured_analyst_title']; ?></h3>
    <?php
				if ($featured_analysts)
				{
?>
  <div class="clsSideBarContents">
    <?php
						$i = 0;
						foreach ($featured_analysts as $eachMember)
						{
								$userDetails = $this->getUserDetails($eachMember);
								$i++;
								$clsOddOrEvenQuestion = 'clsEvenQuestion';
								if ($i % 2) $clsOddOrEvenQuestion = 'clsOddQuestion';
								$uid = $userDetails['user_id'];
								$userLog = $this->getUserLog($uid);
								$uname = $userDetails['name'];
?>
    <div class="<?php echo $clsOddOrEvenQuestion; ?> clsUserThumbDetails">
      <?php if (chkUserImageAllowed())
								{ ?>
      <div class="clsFeaturedUserThumb">
        <p id="selImageBorder">
          <?php displayUserImage($userDetails, 'thumb', false); ?>
        </p>
      </div>
      <?php } ?>
      <div class="clsFeaturedUserDetails">
        <h3 class="clsTitleLink"><a href="<?php echo getUrl($this->CFG['site']['url'] . 'myanswers.php?uid=' . $uid, $this->CFG['site']['url'] . 'my/answers/' . $uid . '/', false); ?>"><?php echo $userDetails['name']; ?></a></h3>
        <p class="clsTotalPoints"><?php echo $this->LANG['total_points']; ?> <?php echo $userLog['total_points']; ?></p>
        <p class="clsOtherInfo"><?php echo $this->LANG['question_asked']; ?> <a href="<?php echo getUrl($this->CFG['site']['url'] . 'members/questions.php?act=search&uname=' . $uname, $this->CFG['site']['url'] . 'members/answers/search/?uname=' . $uname, false); ?>"><?php echo $userLog['total_ques']; ?></a></p>
        <p class="clsOtherInfo"><?php echo $this->LANG['resolved_questions']; ?> <a href="<?php echo getUrl($this->CFG['site']['url'] . 'members/questions.php?act=search&uname=' . $uname . '&opt=resolve', $this->CFG['site']['url'] . 'members/answers/search/?uname=' . $uname . '&opt=resolve', false); ?>"><?php echo $this->getResolvedQuestions($uid); ?></a></p>
        <p class="clsOtherInfo"><?php echo $this->LANG['total_answers']; ?> <a href="<?php echo getUrl($this->CFG['site']['url'] . 'members/questions.php?act=search&uname=' . $uname . '&opt=ans', $this->CFG['site']['url'] . 'members/answers/search/?uname=' . $uname . '&opt=ans', false); ?>"><?php echo $userLog['total_ans']; ?></a></p>
      </div>
    </div>
    <?php
						}


?>
  </div>
  <?php
				}
				else
				{
?>
  <div class="clsNoRecords">
    <p><?php echo $this->LANG['common_no_analysts']; ?></p>
  </div>
  <?php
				}
?>
</div>
<?php
		}
		public function getTopAnalystIds($limit)
		{
				$sql = 'SELECT user_id FROM ' . $this->CFG['db']['tbl']['users_ans_log'] . ' WHERE total_points > 0' . ' ORDER BY total_points DESC LIMIT 0, ' . $limit;
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$top_analysts = array();
				while ($row = $rs->FetchRow())
				{
						$top_analysts[] = $row['user_id'];
				}
				return $top_analysts;
		}
		public function displayTopAnalyst($limit = 5)
		{


?>
<div id="selWidgetTopAnalyst" class="clsTopAnalyst clsSideBarSections">
  <h3><?php echo $this->LANG['common_top_analyst_title']; ?></h3>
<?php
				$top_analysts = $this->getTopAnalystIds($limit);
				if (!$top_analysts)
				{
?>
  <div class="clsNoRecords">
    <p><?php echo $this->LANG['common_no_analysts']; ?></p>
  </div>
<?php

				}
				else
				{
?>
  <div class="clsSideBarContents">
    <table summary="<?php echo $this->LANG['common_top_analyst_title']; ?>">
      <tr>
        <th><?php echo $this->LANG['analyst_name']; ?></th>
        <th><?php echo $this->LANG['analyst_points']; ?></th>
      </tr>
      <?php
						$i = 0;
						foreach ($top_analysts as $eachMember)
						{
								$userDetails = $this->getUserDetails($eachMember);
								$uid = $userDetails['user_id'];
								$userLog = $this->getUserLog($uid);
								$uname = $userDetails['name'];
								$i++;
								$clsOddOrEvenQuestion = 'clsEvenQuestion';
								if ($i % 2) $clsOddOrEvenQuestion = 'clsOddQuestion';

?>
      <tr>
        <td class="<?php echo $clsOddOrEvenQuestion; ?> clsUserThumbDetails">
          <?php if (chkUserImageAllowed())
								{ ?>
          <p id="selImageBorder"><?php displayTopAnalystSmallImage($userDetails); ?></p>
          <?php } ?>
          <p><a href="<?php echo getUrl($this->CFG['site']['url'] . 'myanswers.php?uid=' . $uid, $this->CFG['site']['url'] . 'my/answers/' . $uid . '/', false); ?>"><?php echo stripString($userDetails['name'], $this->CFG['username']['short_length']); ?></a></p></td>
        <td class="<?php echo $clsOddOrEvenQuestion; ?> clsUserThumbDetails"><?php echo $userLog['total_points']; ?></td>
      </tr>
      <?php
						}


?>
    </table>
    <p class="clsMoreLink"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'topAnalysts.php', $this->CFG['site']['relative_url'] . 'top/analysts/', false); ?>"><?php echo $this->LANG['more']; ?></a></p>
  </div>
<?php
				}
?>
</div>
<?php
		}
}
?>
