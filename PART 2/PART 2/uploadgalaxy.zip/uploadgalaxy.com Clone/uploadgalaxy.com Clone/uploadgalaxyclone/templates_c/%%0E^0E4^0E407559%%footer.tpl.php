<?php /* Smarty version 2.6.6, created on 2006-03-11 11:09:00
         compiled from footer.tpl */ ?>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%">
  <tr>
    <td width="100%" colspan="3">
    <p align="center"><img border="0" src="images/bottomLine.gif" width="600" height="18"></td>
  </tr>
  <tr>
    <td width="30%">
    <p align="right"><font face="Verdana" size="2">
    <a class="A" href="index.php">Home</a></font></td>
    <td width="40%">
    <p align="center"><font face="Verdana" size="2" color="#0033CC">&nbsp;</font><font face="Verdana" size="2" color="#008000">Developed by</font><font face="Verdana" size="2" color="#0033CC">
    <b>Shaon</b>.</font></td>
    <td width="30%">
    <p align="left"><font face="Verdana" size="2">
    <a class="A" href="contact.php">Contact</a></font></td>
  </tr>
</table>