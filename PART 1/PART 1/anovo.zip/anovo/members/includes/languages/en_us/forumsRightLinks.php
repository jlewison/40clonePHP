<?php
$LANG['forumlinks_back_index'] = 'Back to Forum Index';
$LANG['forumslinks_post_topic'] = 'Post a Topic';
$LANG['forumslinks_post_response'] = 'Post a Response';
?>