Create a SQL database and import the 'database.txt' file.

Edit 'includes/configuration' with the database connection information.

Edit all the other miscellaneous variables in the configuration.php file.

In 'admin/index.php' edit admin login  default is  admin / admin

Upload all the file and folders.

CHMOD 777 the images, and uploads folder.

Done!
