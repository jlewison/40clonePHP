<?php
require_once ('./common/config.inc.php');
$CFG['lang']['include_files'][] = 'members/includes/languages/%s/emailAnswers.php';
$CFG['html']['is_use_header'] = false;
$CFG['html']['is_use_footer'] = false;
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['lang']['include_files'][] = 'common/email_templates/languages/%s/email_notify.inc.php';
$CFG['lang']['include_files'][] = 'common/languages/%s/help.inc.php';
if ($_POST) $CFG['mods']['include_files'][] = 'common/classes/phpmailer/class_PHPMailer.lib.php';
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
require ('general/emailAnswers.php');
?>