<?
show_header(); 
?>
<table width=100% class=body>
<tr><td class='lined padded-6'><!--StartFragment -->
<b>
<span class="text1">Our Tour Page:</span></b><p><span class="text1"><b>Edit this 
	page with your favorite html editor by opening up the file tour.php</b></span></p>
	<p></br></td></table>
<? show_footer(); ?>