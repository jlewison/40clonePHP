<?php
/**
 * events Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 12/26/2007
 */
class eventsModel extends Model
{
		//Constructor
		function eventsModel()
		{
				parent::Model();
				$this->userId = $this->session->userdata('user_id');
		}
		function storePhotos($eventId, $newFileName)
		{
				$strSQL = 'UPDATE events SET event_photo_path = ' . $this->db->escape($newFileName) . ' WHERE event_id =' . $this->db->escape($eventId);
				$this->db->query($strSQL);
		}
		function addMembers($eventId, $receiver, $sender, $memberStatus = 'not sent', $member = true, $receiverMail = '')
		{
				$strSQL = 'SELECT gi.event_id FROM events_invitation AS gi WHERE gi.sender_id = ' . $sender . ' AND gi.event_id =' . $this->db->escape($eventId) . ' AND gi.receiver_id = ' . $this->db->escape($receiver);
				$condSQL = '';
				if (!$member)
				{
						$condSQL = ' AND receiver_email = ' . $this->db->escape($receiverMail);
				}
				$strSQL .= $condSQL;
				$checkResult = $this->db->query($strSQL);
				if ($checkResult->num_rows() == 0)
				{
						$condSQL = '';
						if (!$member)
						{
								//$condSQL = ', receiver_email =  '. $this->db->escape($receiverMail) . ', invitation_status = "requested"';
								$condSQL = ', receiver_email =  ' . $this->db->escape($receiverMail) . ', invitation_status = "not sent"';
						}
						else
						{
								$condSQL = ', invitation_status = ' . $this->db->escape($memberStatus);
						}
						$strSQL = 'INSERT INTO events_invitation SET event_id = ' . $this->db->escape($eventId) . ', receiver_id = ' . $this->db->escape($receiver) . ', sender_id = ' . $this->db->escape($sender);
						$strSQL .= $condSQL;
						$this->db->query($strSQL);
						return 1;
				}
				else  return 0;
		}
		function iseventMember($eventId, $receiver)
		{
				$strSQL = 'SELECT event_id FROM event_members WHERE event_id = ' . $this->db->escape($eventId) . ' AND receiver_id =' . $this->db->escape($receiver);
				$resSQL = $this->db->query($strSQL);
				$res = ($resSQL->num_rows == 0) ? 0 : 1;
				return $res;
		}
		function getFriendsInvitees($eventId, $userId)
		{
				$strSQL = " SELECT results.friendId,
					IFNULL((SELECT gm.event_member_id FROM event_members as gm WHERE  gm.event_id = '" . $eventId . "' AND gm.receiver_id = results.friendId ),'0') as ismember ,
					IFNULL((SELECT gi.event_invitation_id FROM events_invitation as gi WHERE gi.sender_id = " . $this->userId . " AND gi.event_id = " . $this->db->escape($eventId) . " AND gi.receiver_id = results.friendId ),'0') as memberstaus,(SELECT username FROM users WHERE user_id = results.friendId limit 0,1) as username
					FROM
					(
					SELECT friend_id AS FriendId FROM `friends_list` WHERE user_id=" . $this->db->escape($userId) . " and approved_status='yes'
					UNION
					SELECT user_id as FriendId FROM `friends_list` WHERE friend_id=" . $this->db->escape($userId) . " and approved_status='yes'
					) as results   ";
				$resSQL = $this->db->query($strSQL);
				$resArray = array();
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[$resRow['friendId']] = $resRow;
						}
				}
				return $resArray;
		}
		function getMembers($eventId, $status = 'not sent')
		{
				$strSQL = 'SELECT gi.event_invitation_id, gi.event_id, gi.sender_id, gi.invitation_status, gi.receiver_id,u.username FROM events_invitation as gi
						INNER JOIN users as u ON u.user_id = gi.receiver_id AND gi.invitation_status = ' . $this->db->escape($status) . ' AND gi.sender_id = ' . $this->userId . ' AND gi.event_id = ' . $eventId . '
						 UNION
						SELECT gi.event_invitation_id, gi.event_id, gi.sender_id, gi.invitation_status, gi.receiver_id, gi.receiver_email AS username
						FROM events_invitation AS gi
						WHERE (gi.invitation_status != "sent" OR gi.invitation_status = ' . $this->db->escape($status) . ' ) AND gi.sender_id = ' . $this->userId . '  AND gi.event_id = ' . $eventId . ' AND gi.receiver_email != "" AND gi.receiver_id = "0"';
				$strSQL = 'SELECT gi.event_invitation_id, gi.event_id, gi.sender_id, gi.invitation_status, gi.receiver_id,u.username FROM events_invitation as gi
						INNER JOIN users as u ON u.user_id = gi.receiver_id AND (gi.invitation_status = ' . $this->db->escape($status) . ' OR  gi.invitation_status != "sent" )AND gi.sender_id = ' . $this->userId . ' AND gi.event_id = ' . $eventId . '
						 UNION
						SELECT gi.event_invitation_id, gi.event_id, gi.sender_id, gi.invitation_status, gi.receiver_id, gi.receiver_email AS username
						FROM events_invitation AS gi
						WHERE (gi.invitation_status != "sent" OR gi.invitation_status = ' . $this->db->escape($status) . ' ) AND gi.sender_id = ' . $this->userId . '  AND gi.event_id = ' . $eventId . ' AND gi.receiver_email != "" AND gi.receiver_id = "0"';
				$resSQL = $this->db->query($strSQL);
				$resArray = array();
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[$resRow['event_invitation_id']] = $resRow;
						}
				}
				return $resArray;
		}
		function getRequests($eventId, $status = 'requested', $start = '', $limit = '')
		{
				/*
				$strSQL 	= 	'SELECT gi.event_invitation_id, gi.event_id, gi.sender_id, gi.invitation_status, gi.receiver_id,u.username FROM events_invitation as gi
				INNER JOIN users as u ON u.user_id = gi.receiver_id AND  (gi.invitation_status = "requested" OR  gi.invitation_status = "sent") AND gi.event_id = '.$eventId .'
				UNION
				SELECT gi.event_invitation_id, gi.event_id, gi.sender_id, gi.invitation_status, gi.receiver_id, gi.receiver_email AS username
				FROM events_invitation AS gi
				WHERE (gi.invitation_status = "requested" OR  gi.invitation_status = "sent")  AND gi.event_id = '.$eventId .' AND gi.receiver_email != "" AND gi.receiver_id = "0"';
				*/
				$strSQL = 'SELECT results.event_id , results.receiver_id,results.username
						FROM
						(
						SELECT gi.event_invitation_id, gi.event_id, gi.sender_id, gi.invitation_status, gi.receiver_id,u.username
						FROM events_invitation as gi
						INNER JOIN users as u ON u.user_id = gi.receiver_id AND (gi.invitation_status = "requested" OR gi.invitation_status = "sent") AND gi.event_id = ' . $this->db->escape($eventId) . '
						UNION
						SELECT gi.event_invitation_id, gi.event_id, gi.sender_id, gi.invitation_status, gi.receiver_id, gi.receiver_email AS username
						FROM events_invitation AS gi
						WHERE (gi.invitation_status = "requested" OR gi.invitation_status = "sent") AND gi.event_id = ' . $this->db->escape($eventId) . ' AND gi.receiver_email != "" AND gi.receiver_id = "0"
						) as results
						GROUP BY results.event_id , results.receiver_id,results.username  ';
				$strSQL = 'SELECT results.event_id , results.receiver_id,results.username
						FROM
						(
						SELECT gi.event_invitation_id, gi.event_id, gi.sender_id, gi.invitation_status, gi.receiver_id,u.username
						FROM events_invitation as gi
						INNER JOIN users as u ON u.user_id = gi.receiver_id AND (gi.invitation_status = "requested" ) AND gi.event_id = ' . $this->db->escape($eventId) . '
						UNION
						SELECT gi.event_invitation_id, gi.event_id, gi.sender_id, gi.invitation_status, gi.receiver_id, gi.receiver_email AS username
						FROM events_invitation AS gi
						WHERE (gi.invitation_status = "requested" ) AND gi.event_id = ' . $this->db->escape($eventId) . ' AND gi.receiver_email != "" AND gi.receiver_id = "0"
						) as results
						GROUP BY results.event_id , results.receiver_id,results.username  ';
				if (ereg('^[0-9]+$', $start) && ereg('^[0-9]+$', $limit))
				{
						$strSQL .= ' LIMIT ' . $start . ', ' . $limit;
				}
				$resSQL = $this->db->query($strSQL);
				$resArray = array();
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[] = $resRow;
						}
				}
				return $resArray;
		}
		function getRequestsCount($eventId, $status = 'requested')
		{
				/*
				$strSQL 	= 	'SELECT gi.event_invitation_id, gi.event_id, gi.sender_id, gi.invitation_status, gi.receiver_id,u.username FROM events_invitation as gi
				INNER JOIN users as u ON u.user_id = gi.receiver_id AND  (gi.invitation_status = "requested" OR  gi.invitation_status = "sent") AND gi.event_id = '.$eventId .'
				UNION
				SELECT gi.event_invitation_id, gi.event_id, gi.sender_id, gi.invitation_status, gi.receiver_id, gi.receiver_email AS username
				FROM events_invitation AS gi
				WHERE (gi.invitation_status = "requested" OR  gi.invitation_status = "sent")  AND gi.event_id = '.$eventId .' AND gi.receiver_email != "" AND gi.receiver_id = "0"';
				*/
				$strSQL = 'SELECT results.event_id , results.receiver_id,results.username
						FROM
						(
						SELECT gi.event_invitation_id, gi.event_id, gi.sender_id, gi.invitation_status, gi.receiver_id,u.username
						FROM events_invitation as gi
						INNER JOIN users as u ON u.user_id = gi.receiver_id AND (gi.invitation_status = "requested" OR gi.invitation_status = "sent") AND gi.event_id = ' . $this->db->escape($eventId) . '
						UNION
						SELECT gi.event_invitation_id, gi.event_id, gi.sender_id, gi.invitation_status, gi.receiver_id, gi.receiver_email AS username
						FROM events_invitation AS gi
						WHERE (gi.invitation_status = "requested" OR gi.invitation_status = "sent") AND gi.event_id = ' . $this->db->escape($eventId) . ' AND gi.receiver_email != "" AND gi.receiver_id = "0"
						) as results
						GROUP BY results.event_id , results.receiver_id,results.username  ';
				$resSQL = $this->db->query($strSQL);
				return $resSQL->num_rows();
		}
		function isAdmin($eventId, $userId)
		{
				$strSQL = 'SELECT result.event_id, result.user_id
						FROM
						(
						SELECT event_id,user_id FROM events WHERE event_id = ' . $this->db->escape($eventId) . '
						UNION
						SELECT event_id,receiver_id FROM event_members WHERE event_id = ' . $this->db->escape($eventId) . ' AND UPPER(TRIM(is_admin)) = "Y"
						) AS result WHERE result.user_id = ' . $this->db->escape($userId);
				$resSQL = $this->db->query($strSQL);
				$rows = ($resSQL->num_rows() == 0) ? 0 : 1;
				return $rows;
		}
		function removeeventMember($userId, $eventId)
		{
				$strSQL = 'DELETE FROM event_members WHERE event_id = ' . $this->db->escape($eventId) . ' AND receiver_id = ' . $this->db->escape($userId);
				$this->db->query($strSQL);
		}
		function blockeventMember($userId, $eventId)
		{
				$strSQL = 'UPDATE event_members SET member_status = "blocked", date_modified = CURRENT_TIMESTAMP WHERE event_id = ' . $this->db->escape($eventId) . ' AND receiver_id = ' . $this->db->escape($userId);
				$this->db->query($strSQL);
		}
		function unblockeventMember($userId, $eventId)
		{
				$strSQL = 'UPDATE event_members SET member_status = "attending", date_modified = CURRENT_TIMESTAMP WHERE event_id = ' . $this->db->escape($eventId) . ' AND receiver_id = ' . $this->db->escape($userId);
				$this->db->query($strSQL);
		}
		//geteventMembers($eventId, $status = 'attending')
		function geteventMembers($eventId, $status = '', $adminFlag = '', $start = '', $limit = '')
		{
				$condSQL = '';
				if ($status != '' and $status != 'blocked')
				{
						$condSQL = ' AND gm.member_status != "blocked" AND gm.member_status = ' . $this->db->escape($status);
				} elseif ($status != '' and $status == 'blocked')
				{
						$condSQL = ' AND gm.member_status = ' . $this->db->escape($status);
				}
				$adminSQL = '';
				if ($adminFlag == 'Y') $adminSQL = ' AND is_admin = "Y"';
				$strSQL = 'SELECT gm.event_member_id, gm.event_id, gm.sender_id, gm.member_status as invitation_status, gm.receiver_id,u.username,gm.is_admin FROM event_members as gm INNER JOIN users as u ON u.user_id = gm.receiver_id  AND gm.event_id = ' . $eventId . $condSQL . $adminSQL;
				if (ereg('^[0-9]+$', $start) && ereg('^[0-9]+$', $limit))
				{
						$strSQL .= ' LIMIT ' . $start . ', ' . $limit;
				}
				$resSQL = $this->db->query($strSQL);
				$resArray = array();
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[$resRow['event_member_id']] = $resRow;
						}
				}
				return $resArray;
		}
		function geteventMembersCount($eventId, $status = '', $adminFlag = '')
		{
				$condSQL = '';
				if ($status != '' and $status != 'blocked')
				{
						$condSQL = ' AND gm.member_status != "blocked" AND gm.member_status = ' . $this->db->escape($status);
				} elseif ($status != '' and $status == 'blocked')
				{
						$condSQL = ' AND gm.member_status = ' . $this->db->escape($status);
				}
				$adminSQL = '';
				if ($adminFlag == 'Y') $adminSQL = ' AND is_admin = "Y"';
				$strSQL = 'SELECT gm.event_member_id, gm.event_id, gm.sender_id, gm.member_status as invitation_status, gm.receiver_id,u.username,gm.is_admin FROM event_members as gm INNER JOIN users as u ON u.user_id = gm.receiver_id  AND gm.event_id = ' . $eventId . $condSQL . $adminSQL;
				$resSQL = $this->db->query($strSQL);
				return $resSQL->num_rows();
		}
		function getEventMemberStaus($eventId, $receiver = '')
		{
				$condSQL = '';
				if (trim($receiver) != '') $condSQL = ' AND gm.receiver_id =' . $this->db->escape($receiver);
				$strSQL = 'SELECT gm.event_member_id, gm.event_id, gm.sender_id, gm.member_status as invitation_status, gm.receiver_id,u.username,gm.is_admin FROM event_members as gm INNER JOIN users as u ON u.user_id = gm.receiver_id  AND gm.event_id = ' . $eventId . $condSQL;
				$resSQL = $this->db->query($strSQL);
				$resArray = array();
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray = $resRow;
						}
				}
				return $resArray;
		}
		function saveRSVP($eventId, $receiver, $status)
		{
				$strSQL = 'UPDATE event_members SET member_status =' . $this->db->escape($status) . ', date_modified = CURRENT_TIMESTAMP WHERE event_id = ' . $this->db->escape($eventId) . ' AND receiver_id =' . $this->db->escape($receiver);
				$this->db->query($strSQL);
		}
		function getReceiverDetails($invids)
		{
				$strSQL = 'SELECT gi.event_invitation_id ,u.username, gi.receiver_id as user_id,u.email, gi.receiver_email FROM events_invitation AS gi  LEFT JOIN users AS u ON gi.receiver_id = u.user_id WHERE gi.event_invitation_id in (' . $invids . ')';
				$resSQL = $this->db->query($strSQL);
				$resArray = array();
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[] = $resRow;
						}
				}
				return $resArray;
		}
		function updateInvitations($ids, $eventId, $status, $message = '')
		{
				//$strSQL = 'UPDATE events_invitation SET invitation_message = '.$this->db->escape($message).', invitation_status = '.$this->db->escape($status).' WHERE event_invitation_id in ('.$ids.') AND sender_id = '.$this->userId;
				$strSQL = 'UPDATE events_invitation SET invitation_message = ' . $this->db->escape($message) . ', invitation_status = ' . $this->db->escape($status) . ' WHERE event_invitation_id in (' . $ids . ')';
				$this->db->query($strSQL);
				if ($this->db->affected_rows() == 1) return 1;
				else  return 0;
		}
		function leaveevent($eventId, $receiver)
		{
				$strSQL = 'DELETE FROM event_members WHERE event_id =' . $this->db->escape($eventId) . ' AND receiver_id =' . $this->db->escape($receiver);
				$this->db->query($strSQL);
		}
		function getAdminSettingsEventCount()
		{
				$strSQL = 'SELECT total_groups_user_create,total_events_user_create FROM admin_settings';
				$resSQL = $this->db->query($strSQL);
				$count = 0;
				if ($resSQL->num_rows() > 0)
				{
						$resRow = $resSQL->result_array();
						$count = $resRow[0]['total_events_user_create'];
				}
				return $count;
		}
		function getUserEventCount($userId = '')
		{
				if (TRIM($userId) == '')
				{
						$userId = $this->userId;
				}
				else
				{
						if (!ereg('^[0-9]+$', $userId))
						{
								$userId = $this->userId;
						}
				}
				$count = 0;
				$strSQL = 'SELECT user_id,count(event_id) AS event_count FROM events WHERE user_id = ' . $this->db->escape($userId) . ' AND UPPER(TRIM(event_status)) = "OK" GROUP BY user_id';
				$resSQL = $this->db->query($strSQL);
				if ($resSQL->num_rows() > 0)
				{
						$resRow = $resSQL->result_array();
						$count = $resRow[0]['event_count'];
				}
				return $count;
		}
		function joinevent($eventId, $sender, $receiver)
		{
				$strSQL = 'INSERT INTO event_members SET event_id =' . $this->db->escape($eventId) . ', receiver_id =' . $this->db->escape($receiver) . ', sender_id =' . $this->db->escape($sender);
				$this->db->query($strSQL);
		}
		function removeevent($eventId)
		{
				$strSQL = 'UPDATE events SET event_status = "deleted" WHERE event_id = ' . $this->db->escape($eventId) . ' AND user_id =' . $this->db->escape($this->userId);
				$this->db->query($strSQL);
				$postType = 'event';
				$postId = $eventId;
				$this->deletePostByType($postType, $postId);
		}
		function deletePostByType($postFor, $postForId)
		{
				//echo 'DELETE FROM posted_items WHERE post_type=\''.$postFor.'\' AND post_for_id='.$postForId;
				$sql = 'DELETE FROM posted_items WHERE post_type=\'' . $postFor . '\' AND post_for_id=' . $postForId;
				$this->db->query($sql);
				if ($this->db->affected_rows() > 0) return true;
				else  return false;
		} //end deletePostByType()
		function removeInvitation($userId, $eventId, $invitationId = '')
		{
				$condSQL = '';
				if ($invitationId != '') $condSQL = ' AND event_invitation_id =' . $this->db->escape($invitationId);
				$strSQL = 'DELETE FROM events_invitation WHERE event_id =' . $this->db->escape($eventId) . ' AND receiver_id =' . $this->db->escape($userId) . $condSQL;
				$this->db->query($strSQL);
		}
		function removeAllInvitations($eventId)
		{
				$strSQL = 'DELETE FROM events_invitation WHERE event_id =' . $this->db->escape($eventId);
				$this->db->query($strSQL);
		}
		function geteventInfo($eventId)
		{
				$strSQL = '	SELECT event_id, event_type, event_name, event_description, event_category_id, event_sub_category_id
							,event_location,event_email,event_street,event_city,event_state,event_country
							, event_wall, event_photos, event_upload_permission
							, event_type, event_photo_path
							,event_publicize, network_id , IF(event_start_unix_stamp >= UNIX_TIMESTAMP(now()),"upcome",IF(event_end_unix_stamp <= UNIX_TIMESTAMP(now()),"past","")) as event_flag
							FROM events WHERE event_id = ' . $this->db->escape($eventId) . ' AND trim(upper(event_status)) = "OK" ';
				$resSQL = $this->db->query($strSQL);
				$resRow = array();
				if ($resSQL->num_rows() > 0)
				{
						$resArray = $resSQL->result_array();
						$resRow = $resArray[0];
				}
				return $resRow;
		}
		function userGroups($userId)
		{
				$strSQL = 'SELECT group_id, group_name FROM groups WHERE user_id= ' . $this->db->escape($userId) . ' ORDER BY group_name ASC';
				$resSQL = $this->db->query($strSQL);
				$resArray = array();
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[] = $resRow;
						}
				}
				return $resArray;
		}
		function getInfo($eventId)
		{
				$strSQL = 'SELECT g.event_id,g.network_id, IF(TRIM(g.event_host) = "",(SELECT group_name FROM groups WHERE group_id = g.event_host_group LIMIT 0,1),"") AS group_name,g.event_host_group,g.event_end_unix_stamp, FROM_UNIXTIME(g.event_end_unix_stamp,"%W %M %d %Y %r")AS end_time,g.event_start_unix_stamp, FROM_UNIXTIME(g.event_start_unix_stamp,"%W %M %d %Y %r")AS start_time, IF(TRIM(g.event_host) = "","group","non group") as host_type,g.user_id,u.username, u.email, g.event_id,IFNULL(IF(TRIM(n.network_name) = "", n.network_city, n.network_name),"") AS network_name,
					g.event_type, g.event_name, g.event_description, g.event_category_id, g.event_sub_category_id ,
					g.event_location , g.event_email,g.event_street,g.event_city,g.event_state,g.event_country ,
					g.event_wall, g.event_photos, g.event_upload_permission, g.event_type ,g.event_publicize, g.network_id,
					g.event_tags,g.event_host, g.event_phone,g.event_bring_friends,event_show_guest,
					gc.event_category_name,gsc.event_sub_category_name,IFNULL(c.country_name,"") AS country_name
					FROM events AS g
					INNER JOIN events_category AS gc ON gc.event_category_id = g.event_category_id
					INNER JOIN events_sub_category AS gsc ON gsc.event_sub_category_id = g.event_sub_category_id
					INNER JOIN users AS u ON g.user_id = u.user_id
					LEFT JOIN country AS c ON g.event_country = c.country_symbol
					LEFT JOIN networks AS n ON n.network_id = g.network_id AND g.network_id != 0
					WHERE event_id = ' . $this->db->escape($eventId) . ' AND trim(upper(event_status)) = "OK"';
				$resSQL = $this->db->query($strSQL);
				$resRow = array();
				if ($resSQL->num_rows() > 0)
				{
						$resArray = $resSQL->result_array();
						$resRow = $resArray[0];
				}
				return $resRow;
		}
		function saveEventInfo($eventValues, $eventId = '', $action = 'new')
		{
				$dataSQL = '';
				$condSQL = '';
				if ($action == 'new')
				{
						$strSQL = 'INSERT INTO events SET  ';
						foreach ($eventValues as $key => $val)
						{
								if ($dataSQL == '')
								{
										$dataSQL .= $key . ' = ' . $val;
								}
								else
								{
										$dataSQL .= ',' . $key . ' = ' . $val;
								}
						}
				}
				else
				{
						$strSQL = 'UPDATE events SET  ';
						foreach ($eventValues as $key => $val)
						{
								if ($dataSQL == '')
								{
										$dataSQL .= $key . ' = ' . $val;
								}
								else
								{
										$dataSQL .= ',' . $key . ' = ' . $val;
								}
						}
						$dataSQL .= ', date_modified = CURRENT_TIMESTAMP ';
						$condSQL = '  WHERE event_id = ' . $this->db->escape($eventId);
				}
				$strSQL = $strSQL . $dataSQL . $condSQL;
				$this->db->query($strSQL);
				if ($action == 'new')
				{
						if ($this->db->affected_rows() == 1)
						{
								$eventId = $this->db->insert_id();
								$strSQL = "INSERT INTO event_members SET event_id = " . $eventId . ", sender_id = " . $this->userId . ", receiver_id = " . $this->userId . ", is_admin = 'Y', member_status = 'attending'";
								$this->db->query($strSQL);
								return $eventId;
						}
						else  return 0;
				}
				else
				{
						return $eventId;
				}
		}
		//Default function
		function geteventImage($eventId, $thumbnail = false, $relativeURL = false)
		{
				$thumb = ($thumbnail == true) ? '_thumb' : '';
				$strSql = 'SELECT event_photo_path FROM events WHERE event_id =' . $this->db->escape($eventId);
				$resQuery = $this->db->query($strSql);
				if ($resQuery->num_rows() > 0)
				{
						$rowAvatar = $resQuery->result_array();
						if (!$relativeURL) $userAvatar = base_url() . 'application/content/events/' . $eventId . $thumb . '.' . $rowAvatar[0]['event_photo_path'];
						else  $userAvatar = 'content/events/' . $eventId . $thumb . '.' . $rowAvatar[0]['event_photo_path'];
						if (!file_exists(APPPATH . 'content/events/' . $eventId . $thumb . '.' . $rowAvatar[0]['event_photo_path']))
						{
								if (!$relativeURL) $userAvatar = base_url() . 'application/images/default_avatar' . $thumb . '.jpg';
								else  $userAvatar = 'images/default_avatar' . $thumb . '.jpg';
						}
				}
				else
				{
						if (!$relativeURL) $userAvatar = base_url() . 'application/images/default_avatar' . $thumb . '.jpg';
						else  $userAvatar = 'images/default_avatar' . $thumb . '.jpg';
				}
				return $userAvatar;
		}
		function getName($eventId)
		{
				$sql = 'SELECT event_name FROM events WHERE event_id ="' . trim($eventId) . '"';
				$res = $this->db->query($sql);
				$rs = $res->row();
				if ($res->num_rows() > 0)
				{
						return $rs->event_name;
				}
				else
				{
						return false;
				}
		}
		function getInvitationInfo($eventId = '', $receiver = '', $invid = '')
		{
				$condSQL = '';
				$recSQL = '';
				if ($receiver != '') $recSQL = ' AND receiver_id = ' . $this->db->escape($receiver);
				$eventSQL = '';
				if ($eventId != '') $eventSQL = ' AND event_id = ' . $this->db->escape($eventId);
				if ($invid != '') $condSQL = ' AND event_invitation_id = ' . $this->db->escape($invid);
				$strSQL = 'SELECT event_invitation_id, sender_id, receiver_id, event_id, invitation_status, receiver_email, is_admin FROM events_invitation WHERE 1=1 ' . $eventSQL . $recSQL . $condSQL;
				$resSQL = $this->db->query($strSQL);
				if ($resSQL->num_rows() > 0)
				{
						$row = $resSQL->result_array();
						return $row[0];
				}
				else  return false;
		}
		function getAdmin($eventId)
		{
				//$strSQL = 	'SELECT   receiver_id  FROM event_members  WHERE member_status = "attending" AND is_admin = "Y" AND event_id = '. $this->db->escape($eventId);
				$strSQL = 'SELECT   receiver_id  FROM event_members  WHERE is_admin = "Y" AND event_id = ' . $this->db->escape($eventId);
				$resSQL = $this->db->query($strSQL);
				if ($resSQL->num_rows() > 0)
				{
						$row = $resSQL->result_array();
						return $row[0]['receiver_id'];
				}
				else  return false;
		}
		function geteventCategory($status = 'YES')
		{
				$cond1 = '';
				$cond2 = '';
				if ($status != '')
				{
						$cond1 = ' WHERE UPPER(TRIM(ec.event_category_status)) = ' . $this->db->escape(STRTOUPPER(TRIM($status)));
						$cond2 = ' AND UPPER(TRIM(esc.event_sub_category_status)) = ' . $this->db->escape(STRTOUPPER(TRIM($status)));
				}
				$strSQL = "SELECT ec.event_category_id,ec.event_category_name FROM events_category AS ec
					INNER JOIN events_sub_category AS esc ON ec.event_category_id = esc.event_category_id " . $cond1 . $cond2 . "
					GROUP BY ec.event_category_id,ec.event_category_name";
				$resArray = array();
				$resSQL = $this->db->query($strSQL);
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[$resRow['event_category_id']] = $resRow;
						}
				}
				return $resArray;
		}
		function getSubcategories($mainCatId, $status = 'YES')
		{
				$cond = '';
				if (TRIM($status) != '') $cond = '  UPPER(TRIM(event_sub_category_status)) = ' . $this->db->escape(STRTOUPPER(TRIM($status))) . ' AND ';
				$strSQL = 'SELECT event_sub_category_id, event_sub_category_name FROM events_sub_category WHERE ' . $cond . ' event_category_id = "' . $mainCatId . '" ORDER BY event_sub_category_name';
				$resArray = array();
				$resSQL = $this->db->query($strSQL);
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[] = $resRow;
						}
				}
				return $resArray;
		}
		function getCountry()
		{
				$strSQL = 'SELECT country_symbol, country_name FROM country';
				$resArray = array();
				$resSQL = $this->db->query($strSQL);
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[] = $resRow;
						}
				}
				return $resArray;
		}
		function getNetworkEvents($networkId, $user, $start = '', $limit = '')
		{
				$strSQL = 'SELECT   	g.event_id,g.user_id as event_owner, g.event_name,u.username AS owner_name, n.network_id, IF(TRIM(n.network_name) = "", n.network_city , n.network_name) AS network_name,
									gsc.event_sub_category_name,gc.event_category_name,g.event_category_id,g.event_sub_category_id,g.event_publicize,g.event_photo_path, DATE_FORMAT(g.date_added,"%M %d %Y %H:%i") AS date_added
						FROM 		events AS g
						INNER JOIN	events_category AS gc ON gc.event_category_id = g.event_category_id
						INNER JOIN	events_sub_category AS gsc ON gsc.event_sub_category_id = g.event_sub_category_id AND gsc.event_category_id = g.event_category_id
						INNER JOIN 	users As u ON g.user_id = u.user_id
						INNER JOIN 	networks AS n ON n.network_id = g.network_id AND n.network_id = ' . $this->db->escape($networkId) . '
						WHERE 		g.network_id = ' . $this->db->escape($networkId) . ' AND UPPER(TRIM(g.event_status)) = "OK" AND ((g.event_type != "secret" AND g.event_publicize = "yes") OR g.user_id = ' . $this->db->escape($user) . ')
						ORDER BY 	g.date_added DESC ,g.event_name ASC ';
				$limitSQL = '';
				if (trim($start) != '' && trim($limit) != '')
				{
						if (ereg('^[0-9]+$', $start) && ereg('^[0-9]+$', $limit))
						{
								$limitSQL = '  LIMIT ' . $start . ',' . $limit;
						}
				}
				$strSQL .= $limitSQL;
				$resSQL = $this->db->query($strSQL);
				$resArray = array();
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[] = $resRow;
						}
				}
				return $resArray;
		}
		function getOwnEvents($userId = '')
		{
				if ($userId == '') $userId = $this->userId;
				$strSQL = 'SELECT event_id FROM events WHERE ((UNIX_TIMESTAMP(NOW()) BETWEEN event_start_unix_stamp AND event_end_unix_stamp) OR UNIX_TIMESTAMP(NOW()) < event_start_unix_stamp) AND UPPER(TRIM(event_status)) = "OK" AND user_id = ' . $this->db->escape($userId);
				$resSQL = $this->db->query($strSQL);
				return $resSQL->num_rows();
		}
		function getUserEvents($userIds, $search = '', $upComing = true, $start = '', $limit = '')
		{
				if ($upComing == true)
				{
						$condSQL = ' AND ((UNIX_TIMESTAMP(NOW()) BETWEEN e.event_start_unix_stamp AND e.event_end_unix_stamp) OR UNIX_TIMESTAMP(NOW()) < e.event_start_unix_stamp) AND ((e.event_type != "secret" AND e.event_publicize = "yes") OR (e.user_id = ' . $this->userId . ' ) OR (em.receiver_id = ' . $this->userId . ' )) ';
				}
				else
				{
						$condSQL = ' AND ((UNIX_TIMESTAMP(NOW()) NOT BETWEEN e.event_start_unix_stamp AND e.event_end_unix_stamp) OR UNIX_TIMESTAMP(NOW()) > e.event_end_unix_stamp) AND ((e.event_type != "secret" AND e.event_publicize = "yes") OR (e.user_id = ' . $this->userId . ' ) OR (em.receiver_id = ' . $this->userId . ' )) ';
				}
				$searchSQL = '';
				if ($search != '')
				{
						$search = $this->db->escape('%' . $search . '%');
						$searchSQL = ' AND e.event_name LIKE ' . $search;
				}
				$strSQL = 'SELECT  em.event_id, e.event_name, e.event_type, e.event_description, em.receiver_id, e.event_host, e.event_host_group,e.event_category_id,
					e.event_sub_category_id,ec.event_category_name,esc.event_sub_category_name,
					g.group_name,IF(e.event_host = "","group","non_group") AS host_type,
					IFNULL(IF(n.network_name = "", n.network_city,n.network_name),"Global") AS network_name,e.network_id,
					e.user_id AS event_owner,em.receiver_id AS event_member, u.username AS member_name,em.member_status,
					e.event_start_unix_stamp,e.event_end_unix_stamp,FROM_UNIXTIME(e.event_start_unix_stamp,"%W %D %M %Y %r") AS start_time,
					FROM_UNIXTIME(e.event_end_unix_stamp,"%W %D %M %Y %r") AS end_time, em.is_admin
				FROM 	event_members AS em
				INNER JOIN events AS e ON
					e.event_id = em.event_id  AND UPPER(TRIM(e.event_status)) = "OK" ' . $condSQL . $searchSQL . '
				INNER JOIN events_category AS ec ON
					e.event_category_id = ec.event_category_id
				INNER JOIN events_sub_category AS esc ON
					e.event_sub_category_id = esc.event_sub_category_id
				INNER JOIN users AS u ON
					u.user_id = em.receiver_id
				LEFT JOIN groups AS g ON
					e.event_host_group = g.group_id
				LEFT JOIN networks AS n ON
					e.network_id = n.network_id
				WHERE em.member_status != "blocked" AND em.receiver_id IN (' . $userIds . ') ORDER BY e.event_start_unix_stamp ASC';
				//echo $strSQL;
				if (ereg('^[0-9]+$', $start) && ereg('^[0-9]+$', $limit))
				{
						$strSQL .= '  LIMIT ' . $start . ', ' . $limit;
				}
				$resSQL = $this->db->query($strSQL);
				$resArray = array();
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[] = $resRow;
						}
				}
				return $resArray;
		}
		function getUserEventsCount($userIds, $search = '', $upComing = true)
		{
				if ($upComing == true)
				{
						$condSQL = ' AND UNIX_TIMESTAMP(NOW()) < e.event_end_unix_stamp AND ((e.event_type != "secret" AND e.event_publicize = "yes") OR (e.user_id = ' . $this->userId . ' ) OR (em.receiver_id = ' . $this->userId . ' )) ';
				}
				else
				{
						$condSQL = ' AND UNIX_TIMESTAMP(NOW()) >= e.event_end_unix_stamp AND ((e.event_type != "secret" AND e.event_publicize = "yes") OR (e.user_id = ' . $this->userId . ' ) OR (em.receiver_id = ' . $this->userId . ' )) ';
				}
				$searchSQL = '';
				if ($search != '')
				{
						$search = $this->db->escape('%' . $search . '%');
						$searchSQL = ' AND e.event_name LIKE ' . $search;
				}
				$strSQL = 'SELECT  em.event_id, e.event_name, e.event_type, e.event_description, em.receiver_id, e.event_host, e.event_host_group,e.event_category_id,
					e.event_sub_category_id,ec.event_category_name,esc.event_sub_category_name,
					g.group_name,IF(e.event_host = "","group","non_group") AS host_type,
					IFNULL(IF(n.network_name = "", n.network_city,n.network_name),"Global") AS network_name,e.network_id,
					e.user_id AS event_owner,em.receiver_id AS event_member, u.username AS member_name,em.member_status,
					e.event_start_unix_stamp,e.event_end_unix_stamp,FROM_UNIXTIME(e.event_start_unix_stamp,"%W %D %M %Y %r") AS start_time,
					FROM_UNIXTIME(e.event_end_unix_stamp,"%W %D %M %Y %r") AS end_time, em.is_admin
				FROM 	event_members AS em
				INNER JOIN events AS e ON
					e.event_id = em.event_id  AND UPPER(TRIM(e.event_status)) = "OK" ' . $condSQL . $searchSQL . '
				INNER JOIN events_category AS ec ON
					e.event_category_id = ec.event_category_id
				INNER JOIN events_sub_category AS esc ON
					e.event_sub_category_id = esc.event_sub_category_id
				INNER JOIN users AS u ON
					u.user_id = em.receiver_id
				LEFT JOIN groups AS g ON
					e.event_host_group = g.group_id
				LEFT JOIN networks AS n ON
					e.network_id = n.network_id
				WHERE em.member_status != "blocked" AND em.receiver_id IN (' . $userIds . ') ORDER BY e.event_start_unix_stamp ASC';
				$resSQL = $this->db->query($strSQL);
				return $resSQL->num_rows();
		}
		function getevents($userId, $networkId = '', $catId = '', $subCatId = '', $timestamp, $start = '', $limit = '')
		{
				$networkCondSQL = '';
				if (ereg('^[0-9]+$', $networkId))
				{
						if ($networkId > 0)
						{
								$networkCondSQL = ' AND g.network_id = ' . $this->db->escape($networkId);
						}
				}
				$categoryCondSQL = '';
				if (ereg('^[0-9]+$', $catId))
				{
						if ($catId > 0) $categoryCondSQL = ' AND g.event_category_id = ' . $this->db->escape($catId);
				}
				$subCategoryCondSQL = '';
				if (ereg('^[0-9]+$', $subCatId))
				{
						if ($subCatId > 0)
						{
								$subCategoryCondSQL = ' AND g.event_sub_category_id = ' . $this->db->escape($subCatId);
						}
				}
				$timeSQL = '';
				if ($timestamp != '')
				{
						if (ereg('^[0-9]+$', $timestamp))
						{
								$timeSQL = ' AND g.event_start_unix_stamp >= ' . $timestamp;
						}
				}
				$limitSQL = '';
				if (ereg('^[0-9]+$', $start) && ereg('^[0-9]+$', $limit))
				{
						$limitSQL = ' LIMIT ' . $start . ' , ' . $limit;
				}
				$strSQL = 'SELECT	g.event_id, g.event_type, g.user_id,g.date_added, g.event_name, gc.event_category_id, gc.event_category_name, gsc.event_sub_category_id,
						gsc.event_sub_category_name, dt.posted_for_id, w.wall_for_id,g.event_host,g.event_host_group,gr.group_name,gm.member_status,g.event_start_unix_stamp,
						g.event_end_unix_stamp,g.network_id, FROM_UNIXTIME(g.event_start_unix_stamp,"%W %D %M %Y %r") AS start_time,FROM_UNIXTIME(g.event_end_unix_stamp,"%W %D %M %Y %r") AS end_time, IF(TRIM(g.event_host) = "", "group", "non_group")
						AS host_type , IFNULL(IF(n.network_name = "", n.network_city,n.network_name),"Global") AS network_name,count(distinct gi.receiver_id) AS new_member,
						count(distinct gm.receiver_id) AS members, count(distinct w.wall_id) AS wall_posts,
						count(distinct dt.discussion_topic_id) AS topics,COUNT(distinct dp.discussion_post_id) AS topic_posts,
						IF(g.event_start_unix_stamp >= UNIX_TIMESTAMP(now()),"upcome",IF(g.event_end_unix_stamp <= UNIX_TIMESTAMP(now()),"past","")) as event_flag
					FROM 	events AS g
					INNER JOIN
						event_members AS gm ON gm.event_id = g.event_id AND gm.member_status != "blocked"
					INNER JOIN
						events_category AS gc ON gc.event_category_id = g.event_category_id
					INNER JOIN
						events_sub_category AS gsc ON gsc.event_sub_category_id = g.event_sub_category_id
					LEFT JOIN
						groups AS gr ON gr.group_id = g.event_host_group
					LEFT JOIN
						events_invitation AS gi ON gi.event_id = g.event_id
					LEFT JOIN
						wall AS w ON w.wall_for_id = g.event_id AND wall_for = "event"
					LEFT JOIN
						discussion_topic AS dt ON g.event_id = dt.posted_for_id AND dt.posted_for = "event"
					LEFT JOIN
						discussion_post AS dp ON dt.discussion_topic_id = dp.discussion_topic_id
					LEFT JOIN
						networks AS n ON g.network_id = n.network_id
					WHERE
						UPPER(TRIM(g.event_status)) = "OK" AND ((UPPER(TRIM(g.event_type)) != "SECRET" AND UPPER(TRIM(g.event_publicize)) = "YES") OR gm.receiver_id = ' . $userId . ' OR g.user_id = ' . $userId . ')' . $networkCondSQL . $categoryCondSQL . $subCategoryCondSQL . $timeSQL . '
					GROUP BY
						g.event_id, g.event_type, g.user_id,g.date_added,g.event_name, gc.event_category_id, gc.event_category_name, gsc.event_sub_category_id,
						gsc.event_sub_category_name,dt.posted_for_id,w.wall_for_id,g.event_host,g.event_host_group,gr.group_name,g.event_start_unix_stamp,
						g.event_end_unix_stamp,g.network_id
					ORDER BY g.event_start_unix_stamp DESC, g.event_id DESC' . $limitSQL;
				//echo $strSQL;
				$resSQL = $this->db->query($strSQL);
				$resArray = array();
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[$resRow['event_id']] = $resRow;
						}
				}
				return $resArray;
		}
		function getBrowseEventsCount($userId, $networkId = '', $catId = '', $subCatId = '', $timestamp = '')
		{
				$networkCondSQL = '';
				if (ereg('^[0-9]+$', $networkId))
				{
						if ($networkId > 0)
						{
								$networkCondSQL = ' AND g.network_id = ' . $this->db->escape($networkId);
						}
				}
				$categoryCondSQL = '';
				if (ereg('^[0-9]+$', $catId))
				{
						if ($catId > 0) $categoryCondSQL = ' AND g.event_category_id = ' . $this->db->escape($catId);
				}
				$subCategoryCondSQL = '';
				if (ereg('^[0-9]+$', $subCatId))
				{
						if ($subCatId > 0)
						{
								$subCategoryCondSQL = ' AND g.event_sub_category_id = ' . $this->db->escape($subCatId);
						}
				}
				$timeSQL = '';
				if ($timestamp != '')
				{
						if (ereg('^[0-9]+$', $timestamp))
						{
								$timeSQL = ' AND g.event_start_unix_stamp >= ' . $timestamp;
						}
				}
				$strSQL = 'SELECT	g.event_id, g.event_type, g.user_id,g.date_added, g.event_name, gc.event_category_id, gc.event_category_name, gsc.event_sub_category_id,
						gsc.event_sub_category_name, dt.posted_for_id, w.wall_for_id,g.event_host,g.event_host_group,gr.group_name,gm.member_status,g.event_start_unix_stamp,
						g.event_end_unix_stamp,g.network_id, FROM_UNIXTIME(g.event_start_unix_stamp,"%W %D %M %Y %r") AS start_time,FROM_UNIXTIME(g.event_end_unix_stamp,"%W %D %M %Y %r") AS end_time, IF(TRIM(g.event_host) = "", "group", "non_group")
						AS host_type , IFNULL(IF(n.network_name = "", n.network_city,n.network_name),"Global") AS network_name,count(distinct gi.receiver_id) AS new_member,
						count(distinct gm.receiver_id) AS members, count(distinct w.wall_id) AS wall_posts,
						count(distinct dt.discussion_topic_id) AS topics,COUNT(distinct dp.discussion_post_id) AS topic_posts,
						IF(g.event_start_unix_stamp >= UNIX_TIMESTAMP(now()),"upcome",IF(g.event_end_unix_stamp <= UNIX_TIMESTAMP(now()),"past","")) as event_flag
					FROM 	events AS g
					INNER JOIN
						event_members AS gm ON gm.event_id = g.event_id AND gm.member_status != "blocked"
					INNER JOIN
						events_category AS gc ON gc.event_category_id = g.event_category_id
					INNER JOIN
						events_sub_category AS gsc ON gsc.event_sub_category_id = g.event_sub_category_id
					LEFT JOIN
						groups AS gr ON gr.group_id = g.event_host_group
					LEFT JOIN
						events_invitation AS gi ON gi.event_id = g.event_id
					LEFT JOIN
						wall AS w ON w.wall_for_id = g.event_id AND wall_for = "event"
					LEFT JOIN
						discussion_topic AS dt ON g.event_id = dt.posted_for_id AND dt.posted_for = "event"
					LEFT JOIN
						discussion_post AS dp ON dt.discussion_topic_id = dp.discussion_topic_id
					LEFT JOIN
						networks AS n ON g.network_id = n.network_id
					WHERE
						UPPER(TRIM(g.event_status)) = "OK" AND ((UPPER(TRIM(g.event_type)) != "SECRET" AND UPPER(TRIM(g.event_publicize)) = "YES") OR gm.receiver_id = ' . $userId . ' OR g.user_id = ' . $userId . ')' . $networkCondSQL . $categoryCondSQL . $subCategoryCondSQL . $timeSQL . '
					GROUP BY
						g.event_id, g.event_type, g.user_id,g.date_added,g.event_name, gc.event_category_id, gc.event_category_name, gsc.event_sub_category_id,
						gsc.event_sub_category_name,dt.posted_for_id,w.wall_for_id,g.event_host,g.event_host_group,gr.group_name,g.event_start_unix_stamp,
						g.event_end_unix_stamp,g.network_id
					ORDER BY g.event_start_unix_stamp ASC, g.event_id DESC';
				$resSQL = $this->db->query($strSQL);
				return $resSQL->num_rows();
		}
		#***************************************************************************
		#Method			: getRequestCount
		#Description	: returns events request count for the user
		#Author
		#***************************************************************************
		function getRequestCount()
		{
				$userId = $this->session->userdata('user_id');
				//$requestCountQuery = $this->db->query('SELECT event_invitation_id FROM events_invitation WHERE receiver_id = '.$userId.' GROUP BY event_invitation_id');
				$requestCountQuery = $this->db->query('SELECT event_invitation_id FROM events_invitation WHERE receiver_id = ' . $userId . ' AND sender_id != ' . $userId . ' AND ( invitation_status = "sent")');
				return $requestCountQuery->num_rows();
		}
		function getRequestsForevents($userId)
		{
				$strSQL = "SELECT 	gi.event_invitation_id,gi.event_id, g.event_name, g.event_type, g.user_id AS event_owner, gi.sender_id,
						u.username AS sendername,gi.invitation_status,gi.receiver_id
					FROM 	events_invitation AS gi
					INNER JOIN users AS u ON u.user_id = gi.sender_id
					INNER JOIN events AS g ON g.event_id = gi.event_id
					WHERE gi.receiver_id = " . $userId . " AND gi.sender_id != " . $userId . " AND (gi.invitation_status = 'sent' OR gi.invitation_status = 'requested')";
				$strSQL = "SELECT 	gi.event_invitation_id,gi.event_id, g.event_name, g.event_type, g.user_id AS event_owner, gi.sender_id,
						u.username AS sendername,gi.invitation_status,gi.receiver_id
					FROM 	events_invitation AS gi
					INNER JOIN users AS u ON u.user_id = gi.sender_id
					INNER JOIN events AS g ON g.event_id = gi.event_id
					WHERE gi.receiver_id = " . $userId . " AND gi.sender_id != " . $userId . " AND (gi.invitation_status = 'sent')";
				$resSQL = $this->db->query($strSQL);
				$resArray = array();
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[] = $resRow;
						}
				}
				return $resArray;
		}
		#***************************************************************************
		#Method			: getEventsCount
		#Description	: fetches total events count
		#Author
		#***************************************************************************
		function getEventsCount($status = 'ok')
		{
				$this->db->select('event_id');
				$this->db->from('events');
				$this->db->where('event_status', $status);
				return $this->db->count_all_results();
		}
		#***************************************************************************
		#Method			: insertEventCategory
		#Description	: insert event category
		#Author
		#***************************************************************************
		function insertEventCategory($data)
		{
				$eventCategory = array('event_category_name' => $data['event_category_name'], 'event_category_description' => $data['event_category_description'], 'event_category_status' => $data['event_category_status']);
				$this->db->insert('events_category', $eventCategory);
				$this->db->query('UPDATE events_category SET date_added=NOW()');
		}
		#***************************************************************************
		#Method			: updateEventCategory
		#Description	: updates Event Category
		#Author
		#***************************************************************************
		function updateEventCategory($data)
		{
				$eventCategory = array('event_category_name' => $data['event_category_name'], 'event_category_description' => $data['event_category_description'], 'event_category_status' => $data['event_category_status']);
				$this->db->where('event_category_id', $data['event_category_id']);
				$this->db->update('events_category', $eventCategory);
		}
		#***************************************************************************
		#Method			: insertEventSubCategory
		#Description	: insert event sub category
		#Author
		#***************************************************************************
		function insertEventSubCategory($data, $event_category_id)
		{
				$eventSubCategory = array('event_sub_category_name' => $data['event_sub_category_name'], 'event_sub_category_description' => $data['event_sub_category_description'], 'event_sub_category_status' => $data['event_sub_category_status'], 'event_category_id' => $event_category_id);
				$this->db->insert('events_sub_category', $eventSubCategory);
				$this->db->query('UPDATE events_sub_category SET date_added=NOW()');
		}
		#***************************************************************************
		#Method			: updateEventSubCategory
		#Description	: updates Event Sub Category
		#Author
		#***************************************************************************
		function updateEventSubCategory($data)
		{
				$eventSubCategory = array('event_sub_category_name' => $data['event_sub_category_name'], 'event_sub_category_description' => $data['event_sub_category_description'], 'event_sub_category_status' => $data['event_sub_category_status']);
				$this->db->where('event_sub_category_id', $data['event_sub_category_id']);
				$this->db->update('events_sub_category', $eventSubCategory);
		}
		#***************************************************************************
		#Method			: getEventMainCategory
		#Description	: fetches event sub category
		#Author
		#***************************************************************************
		function getEventMainCategory($status = 'Yes')
		{
				$cond = '';
				if ($status != '') $cond = 'WHERE event_category_status = \'' . $status . '\'';
				$strSQL = 'SELECT event_category_id, event_category_description, event_category_status, event_category_name, date_added FROM events_category ' . $cond . ' ORDER BY event_category_name';
				$resArray = array();
				$resSQL = $this->db->query($strSQL);
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[$resRow['event_category_id']] = $resRow;
						}
				}
				return $resArray;
		}
		#***************************************************************************
		#Method			: getGroupsMainSubCategory
		#Description	: fetches event sub category
		#Author
		#***************************************************************************
		function getEventMainSubCategory($mainCatId, $status = 'Yes')
		{
				$cond = '';
				if ($status != '') $cond = 'WHERE event_sub_category_status = \'' . $status . '\' AND ';
				$strSQL = 'SELECT event_sub_category_id, event_category_id, event_sub_category_name,event_sub_category_description,event_sub_category_status,date_added FROM events_sub_category WHERE ' . $cond . ' event_category_id = "' . $mainCatId . '" ORDER BY event_sub_category_name';
				$resArray = array();
				$resSQL = $this->db->query($strSQL);
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[$resRow['event_sub_category_id']] = $resRow;
						}
				}
				return $resArray;
		}
		#***************************************************************************
		#Method			: updateEventStatus
		#Description	: updates Event status
		#Author
		#***************************************************************************
		function updateEventStatus($block_id, $status)
		{
				$eventStatus = array('event_status' => $status);
				$this->db->where('event_id', $block_id);
				$this->db->update('events', $eventStatus);
		}
		#***************************************************************************
		#Method			: getEventCategoryName
		#Description	: fetches event category name
		#Author
		#***************************************************************************
		function getEventCategoryName($id)
		{
				$this->db->select('event_category_name');
				$this->db->from('events_category');
				$this->db->where('event_category_id', $id);
				$query = $this->db->get();
				if ($query->num_rows() > 0)
				{
						foreach ($query->result() as $row)
						{
								$categoryName = $row->event_category_name;
						}
						return $categoryName;
				}
				else  return false;
		}
		//to check whether the event category exist or not
		//added by ilayaraja_22ag06
		function isCategoryExist($categoryName, $categoryId = '')
		{
				$cond = '';
				if (trim($categoryId) != '') $cond = ' AND event_category_id!=' . $this->db->escape($categoryId);
				$strSQL = 'SELECT event_category_id FROM events_category WHERE event_category_name = ' . $this->db->escape($categoryName) . $cond;
				$resSQL = $this->db->query($strSQL);
				$res = ($resSQL->num_rows == 0) ? 0 : 1;
				return $res;
		}
		//to check whether the event category category exist or not
		//added by ilayaraja_22ag06
		function isSubCategoryExist($subCategoryName, $categoryId, $subCategoryId = '')
		{
				$cond = '';
				if (trim($subCategoryId) != '') $cond = ' AND event_sub_category_id!=' . $this->db->escape($subCategoryId);
				//echo 'SELECT event_sub_category_id FROM events_sub_category WHERE event_sub_category_name = '. $this->db->escape($subCategoryName) .' AND event_category_id='. $this->db->escape($categoryId) .$cond;
				$strSQL = 'SELECT event_sub_category_id FROM events_sub_category WHERE event_sub_category_name = ' . $this->db->escape($subCategoryName) . ' AND event_category_id=' . $this->db->escape($categoryId) . $cond;
				$resSQL = $this->db->query($strSQL);
				$res = ($resSQL->num_rows == 0) ? 0 : 1;
				return $res;
		}
}
?>