<?php
/**
 * MyBB 1.4 English Language Pack
 * Copyright � 2008 MyBB Group, All Rights Reserved
 * 
 * $Id: home_credits.lang.php 4342 2009-04-07 02:23:30Z Tikitiki $
 */

$l['mybb_credits'] = "MyBB Credits";
$l['mybb_credits_description'] = "These people have contributed their time and effort to create MyBB.";
$l['about_the_team'] = "About the Team";

$l['product_managers'] = "Product Managers";
$l['developers'] = "Developers";
$l['graphics_and_style'] = "Graphics and Style";
$l['software_quality_assurance'] = "Software Quality Assurance";
$l['support_representative'] = "Support Representative";

?>