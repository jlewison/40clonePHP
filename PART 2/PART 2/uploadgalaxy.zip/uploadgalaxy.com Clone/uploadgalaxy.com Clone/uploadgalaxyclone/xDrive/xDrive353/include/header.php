<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<meta http-equiv="Content-Language" content="en-us">
	<title><?=$sitename?></title>
	<meta http-equiv='Content-Type' content='text/html; charset=windows-1252'/>
	<link href='style.css' type='text/css' rel='stylesheet'/>
</head>
<body bgcolor="F2F2F2">
<p><b><a href="index.php">Home</a></b> | <b><a href="rules.php">Rules</a></b> |
<b><a href="faq.php">F.A.Q.</a></b> | <b><a href="join.php">Join</a></b> | <b>
<a href="account.php">Account</a></b> | <b><a href="contactus.php">Contact Us</a></b></p>