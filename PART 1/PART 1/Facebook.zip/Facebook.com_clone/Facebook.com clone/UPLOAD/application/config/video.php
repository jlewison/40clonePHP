<?php
$config['video_allowed_types'] = 'avi|mpg|mpeg';
$config['video_max_size'] = '40960';
?>