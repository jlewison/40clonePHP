<?php

class Settingsmodel extends Model
{
		//Constructor
		function Settingsmodel()
		{
				parent::Model();
		}
		function readSetting($settingKey)
		{
				$settingQuery = $this->db->query('SELECT ' . $settingKey . ' FROM admin_settings LIMIT 0,1');
				$settingRow = array();
				if ($settingQuery->num_rows() > 0)
				{
						$settingRow = $settingQuery->result_array();
						return $settingRow[0];
						//return $settingRow[0][$settingKey];
				}
				else  return false;
		}
		function readAllSetting()
		{
				$settingQuery = $this->db->query('SELECT * FROM admin_settings LIMIT 0,1');
				$settingRow = array();
				if ($settingQuery->num_rows() > 0)
				{
						$settingRow = $settingQuery->result_array();
						return $settingRow[0];
				}
				else  return false;
		}
		#***************************************************************************
		#Method			: updateAdminSettings
		#Description	: updates player settings
		#Author
		#***************************************************************************
		function updateAdminSettings($data)
		{
				$player = array('mencoder_path' => $data['mencoder_path'], 'mplayer_path' => $data['mplayer_path'], 'webcam_capture_time' => $data['webcam_capture_time'], 'red5_path' => $data['red5_path'], 'recorder_path' => $data['recorder_path'], 'red5_flv_path' => $data['red5_flv_path'], 'flvtool2_path' => $data['flvtool2_path'], 'red5_server_path' => $data['red5_server_path']);
				$this->db->where('settings_id', 1);
				$this->db->update('admin_settings', $player);
		}
		#***************************************************************************
		#Method			: updateOtherSettings
		#Description	: updates other settings
		#Author
		#***************************************************************************
		function updateOtherSettings($data)
		{
				$otherSettings = array('total_albums_per_user' => $data['total_albums_per_user'], 'total_photos_per_album' => $data['total_photos_per_album'], 'total_groups_user_create' => $data['total_groups_user_create'], 'total_events_user_create' => $data['total_events_user_create']);
				$this->db->where('settings_id', 1);
				$this->db->update('admin_settings', $otherSettings);
		}
		#***************************************************************************
		#Method			: updateSiteSettings
		#Description	: updates SITE settings
		#Author
		#***************************************************************************
		function updateSiteSettings($data)
		{
				$otherSettings = array('admin_name' => $data['admin_name'], 'admin_email' => $data['admin_email'], 'site_name' => $data['site_name'], 'site_title' => $data['site_title']);
				$this->db->where('settings_id', 1);
				$this->db->update('admin_settings', $otherSettings);
		}
		#***************************************************************************
		#Method			: getLanguages
		#Description	: fetches the language lists
		#Author
		#***************************************************************************
		function getLanguages()
		{
				$languageQuery = $this->db->query('SELECT * FROM languages');
				$languageRow = array();
				if ($languageQuery->num_rows() > 0)
				{
						$languageRow = $languageQuery->result_array();
						return $languageRow;
				}
				else  return false;
		}
		#***************************************************************************
		#Method			: getPaginationSettings
		#Description	: fetches the pagination settings
		#Author
		#***************************************************************************
		function getPaginationSettings()
		{
				$paginationSettingsQuery = $this->db->query('SELECT * FROM pagination');
				$paginationSettingsRow = array();
				if ($paginationSettingsQuery->num_rows() > 0)
				{
						$paginationSettingsRow = $paginationSettingsQuery->result_array();
						return $paginationSettingsRow;
				}
				else  return false;
		}
		#***************************************************************************
		#Method			: updatePagination
		#Description	: updates pagination settings
		#Author
		#***************************************************************************
		function updatePagination($data)
		{
				foreach ($data as $key => $val)
				{
						$otherSettings['page_max'] = $val;
						$this->db->where('page', $key);
						$this->db->update('pagination', $otherSettings);
				}
		}
		#***************************************************************************
		#Method			: insertLanguage
		#Description	: insert language
		#Author
		#***************************************************************************
		function insertLanguage($data)
		{
				$languages = array('lang_code' => $data['lang_code'], 'lang_name' => $data['lang_name']);
				$this->db->insert('languages', $languages);
		}
		#***************************************************************************
		#Method			: deleteLanguage
		#Description	: delete language
		#Author
		#***************************************************************************
		function deleteLanguage($lang_id)
		{
				$this->db->where('lang_id', $lang_id);
				$this->db->delete('languages');
		}
		function getLanguageDetails($lang_id)
		{
				$this->db->from('languages');
				$this->db->where('lang_id', $lang_id);
				$this->db->limit(1);
				$languageDetailsQuery = $this->db->get();
				$languageDetails = array();
				if ($languageDetailsQuery->num_rows() > 0)
				{
						$languageDetailsRow = $languageDetailsQuery->result_array();
						return $languageDetailsRow[0];
				}
				return $languageDetails;
		}
}
?>