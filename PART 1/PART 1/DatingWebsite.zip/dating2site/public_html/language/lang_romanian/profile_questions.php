<?php

$profile_questions['1']['question'] = 'Care este statutul civil?';

$profile_questions['1']['description'] = '';

$profile_questions['1']['guideline'] = '';

$profile_questions['1']['extsearchhead'] = 'Statut civil';

$profile_questions['1']['1'] = 'Singur';

$profile_questions['1']['2'] = 'Căsătorit';

$profile_questions['1']['3'] = 'Văduv';

$profile_questions['1']['67'] = 'Concubinaj';

$profile_questions['1']['68'] = 'Desparţit';

$profile_questions['1']['69'] = 'Divorţat';

$profile_questions['2']['question'] = 'Ce etnie te descrie cel mai bine?';

$profile_questions['2']['description'] = '';

$profile_questions['2']['guideline'] = '';

$profile_questions['2']['extsearchhead'] = 'Etnie';

$profile_questions['2']['80'] = 'African American';

$profile_questions['2']['10018'] = 'Asiatic';

$profile_questions['2']['10019'] = 'Negru / African';

$profile_questions['2']['10020'] = 'Caucazian (alb)';

$profile_questions['2']['10021'] = 'Est Indian';

$profile_questions['2']['10022'] = 'Hispanic / Latino';

$profile_questions['2']['10023'] = 'Inter-rasial';

$profile_questions['2']['10024'] = 'Estul mijlociu';

$profile_questions['2']['10025'] = 'Nativ American';

$profile_questions['2']['10026'] = 'Pacific Insular';

$profile_questions['2']['10027'] = 'Alta';

$profile_questions['3']['question'] = 'Care este religia ta?';

$profile_questions['3']['description'] = '';

$profile_questions['3']['guideline'] = '';

$profile_questions['3']['extsearchhead'] = 'Religia';

$profile_questions['3']['10001'] = 'Creştin';

$profile_questions['3']['10002'] = 'Creştin / Catolic';

$profile_questions['3']['10003'] = 'Creştin / LDS';

$profile_questions['3']['10004'] = 'Creştin / Protestant';

$profile_questions['3']['10005'] = 'Creştin / Alta';

$profile_questions['3']['10006'] = 'Budist / Taoist';

$profile_questions['3']['10007'] = 'Hindu';

$profile_questions['3']['10008'] = 'Islam';

$profile_questions['3']['10009'] = 'Evreu';

$profile_questions['3']['10010'] = 'Pagan';

$profile_questions['3']['10011'] = 'Ateist';

$profile_questions['3']['10012'] = 'Nimic / Agnostic';

$profile_questions['3']['10014'] = 'Ştiinţific';

$profile_questions['3']['10015'] = 'Spiritual dar nu religios';

$profile_questions['3']['10016'] = 'Alta';

$profile_questions['4']['question'] = 'Cum te distrezi?';

$profile_questions['4']['description'] = 'Aici poţi descrie activităţile tale mai amănunţit. Dacă îţi place sportul, eşti membru al unei echipe? Dacă îţi plac filmele, ce gen de filme îţi plac?';

$profile_questions['4']['guideline'] = '';

$profile_questions['4']['extsearchhead'] = 'Hobbiuri';

$profile_questions['5']['question'] = 'Ce înălţime ai?';

$profile_questions['5']['description'] = '';

$profile_questions['5']['guideline'] = '';

$profile_questions['5']['extsearchhead'] = 'Înălţimea';

$profile_questions['5']['152'] = '4\' 7\" (140 cm) sau sub';

$profile_questions['5']['153'] = '4\' 8\" (142 cm)';

$profile_questions['5']['154'] = '4\' 9\" (145 cm)';

$profile_questions['5']['155'] = '4\' 10\" (147 cm)';

$profile_questions['5']['156'] = '4\' 11\" (150 cm)';

$profile_questions['5']['157'] = '5\'  0\" (152 cm)';

$profile_questions['5']['158'] = '5\' 1\" (155 cm)';

$profile_questions['5']['160'] = '5\' 2\" (157 cm)';

$profile_questions['5']['161'] = '5\' 3\" (160 cm)';

$profile_questions['5']['162'] = '5\' 4\" (162 cm)';

$profile_questions['5']['163'] = '5\' 5\" (165 cm)';

$profile_questions['5']['164'] = '5\' 6\" (167 cm)';

$profile_questions['5']['165'] = '5\' 7\" (170 cm)';

$profile_questions['5']['166'] = '5\' 8\" (173 cm)';

$profile_questions['5']['167'] = '5\' 9\" (175 cm)';

$profile_questions['5']['168'] = '5\' 10\" (178 cm)';

$profile_questions['5']['169'] = '5\' 11\" (180 cm)';

$profile_questions['5']['170'] = '6\' 0\" (183 cm)';

$profile_questions['5']['171'] = '6\' 1\" (185 cm)';

$profile_questions['5']['172'] = '6\' 2\" (188 cm)';

$profile_questions['5']['173'] = '6\' 3\" (190 cm)';

$profile_questions['5']['174'] = '6\' 4\" (193 cm)';

$profile_questions['5']['175'] = '6\' 5\" (196 cm)';

$profile_questions['5']['176'] = '6\' 6\" (198 cm)';

$profile_questions['5']['177'] = '6\' 7\" (201 cm)';

$profile_questions['5']['178'] = '6\' 8\" (203 cm)';

$profile_questions['5']['179'] = '6\' 9\" (206 cm)';

$profile_questions['5']['180'] = '6\' 10\" (208 cm)';

$profile_questions['5']['181'] = '6\' 11\" (211 cm)';

$profile_questions['5']['182'] = '7\' 0\" (213 cm)';

$profile_questions['5']['183'] = '7\' 1\" (216 cm)';

$profile_questions['5']['184'] = '7\' 2\" (218 cm)';

$profile_questions['5']['185'] = '7\' 3\" (221 cm)';

$profile_questions['5']['186'] = '7\' 4\" (224 cm)';

$profile_questions['5']['187'] = '7\' 5\" (226 cm)';

$profile_questions['5']['188'] = '7\' 6\" (229 cm)';

$profile_questions['5']['189'] = '7\' 7\" (231 cm)';

$profile_questions['5']['190'] = '7\' 8\" (234 cm)';

$profile_questions['5']['191'] = '7\' 9\" (236 cm)';

$profile_questions['5']['192'] = '7\' 10\"\' (239 cm) sau mai mult';

$profile_questions['6']['question'] = 'Ce descrie cel mai bine corpul tău?';

$profile_questions['6']['description'] = '';

$profile_questions['6']['guideline'] = '';

$profile_questions['6']['extsearchhead'] = 'Forma corpului';

$profile_questions['6']['10028'] = 'Slab';

$profile_questions['6']['10029'] = 'Subţire';

$profile_questions['6']['10030'] = 'Mediu';

$profile_questions['6']['10031'] = 'Potrivit';

$profile_questions['6']['10032'] = 'Rapid';

$profile_questions['6']['10033'] = 'Atletic';

$profile_questions['6']['10034'] = 'Muscular';

$profile_questions['6']['10035'] = 'Puţin mai ponderal';

$profile_questions['6']['10036'] = 'Gros';

$profile_questions['6']['10037'] = 'Grăsuţ';

$profile_questions['6']['10039'] = 'Voluptous';

$profile_questions['6']['10040'] = 'Voluminos';

$profile_questions['7']['question'] = 'Care este zodia ta?';

$profile_questions['7']['description'] = '';

$profile_questions['7']['guideline'] = '';

$profile_questions['7']['extsearchhead'] = 'Zodia';

$profile_questions['7']['211'] = 'Berbec';

$profile_questions['7']['212'] = 'Taur';

$profile_questions['7']['213'] = 'Gemeni';

$profile_questions['7']['214'] = 'Rac';

$profile_questions['7']['215'] = 'Leu';

$profile_questions['7']['216'] = 'Fecioară';

$profile_questions['7']['217'] = 'Balanţă';

$profile_questions['7']['218'] = 'Scorpion';

$profile_questions['7']['219'] = 'Săgetător';

$profile_questions['7']['220'] = 'Capricorn';

$profile_questions['7']['221'] = 'Vărsător';

$profile_questions['7']['222'] = 'Peşti';

$profile_questions['8']['question'] = 'Ce descrie cel mai bine culoarea ochilor?';

$profile_questions['8']['description'] = '';

$profile_questions['8']['guideline'] = '';

$profile_questions['8']['extsearchhead'] = 'Culoarea ochilor';

$profile_questions['8']['23'] = 'Negri';

$profile_questions['8']['24'] = 'Albaştri';

$profile_questions['8']['25'] = 'Căprui';

$profile_questions['8']['93'] = 'Gri';

$profile_questions['8']['94'] = 'Verzi';

$profile_questions['8']['95'] = 'Maroniu';

$profile_questions['9']['question'] = 'Care este culoarea părului?';

$profile_questions['9']['description'] = '';

$profile_questions['9']['guideline'] = '';

$profile_questions['9']['extsearchhead'] = 'Culoarea părului';

$profile_questions['9']['26'] = 'Brunet';

$profile_questions['9']['27'] = 'Şaten';

$profile_questions['9']['28'] = 'Şaten spre negru';

$profile_questions['9']['96'] = 'Castaniu';

$profile_questions['9']['97'] = 'Blond';

$profile_questions['9']['98'] = 'Şaten deschis';

$profile_questions['9']['99'] = 'Şaten inchis';

$profile_questions['9']['100'] = 'Roşcat';

$profile_questions['9']['101'] = 'Alb/cărunt';

$profile_questions['9']['102'] = 'Chel';

$profile_questions['9']['103'] = 'Puţin cărunt';

$profile_questions['10']['question'] = 'Ai vreun semn pe corp?';

$profile_questions['10']['description'] = '';

$profile_questions['10']['guideline'] = '';

$profile_questions['10']['extsearchhead'] = 'Semn pe corp';

$profile_questions['10']['29'] = 'Tatuaj plasat strategic';

$profile_questions['10']['30'] = 'Tatuaj vizibil';

$profile_questions['10']['31'] = 'Colţat';

$profile_questions['10']['223'] = 'Marcat';

$profile_questions['10']['224'] = 'Înscris peste tot';

$profile_questions['10']['225'] = 'Cicatricizat';

$profile_questions['10']['226'] = 'Piercing...dar numai urechea/urechile';

$profile_questions['10']['227'] = 'Nu m-as gândi vreodată la asta';

$profile_questions['10']['228'] = 'Cercel în buric';

$profile_questions['10']['229'] = 'Piercing-uri despre care voi întreba';

$profile_questions['11']['question'] = 'Un pic de laudă: Care este cea mai importantă calitate a ta?';

$profile_questions['11']['description'] = '';

$profile_questions['11']['guideline'] = '';

$profile_questions['11']['extsearchhead'] = 'Cea mai importantă trăsătură';

$profile_questions['11']['10068'] = 'Braţele';

$profile_questions['11']['10069'] = 'Spatele';

$profile_questions['11']['10070'] = 'Buricul';

$profile_questions['11']['10071'] = 'Fundul';

$profile_questions['11']['10072'] = 'Pieptul';

$profile_questions['11']['10073'] = 'Tenul';

$profile_questions['11']['10074'] = 'Urechile';

$profile_questions['11']['10075'] = 'Ochii';

$profile_questions['11']['10076'] = 'Gleznele';

$profile_questions['11']['10077'] = 'Părul';

$profile_questions['11']['10078'] = 'Mâinile';

$profile_questions['11']['10079'] = 'Şoldul';

$profile_questions['11']['10080'] = 'Picioarele';

$profile_questions['11']['10081'] = 'Buzele';

$profile_questions['11']['10082'] = 'Nasul';

$profile_questions['11']['10083'] = 'Umerii';

$profile_questions['11']['10084'] = 'Coapsele';

$profile_questions['11']['10085'] = 'Altele';

$profile_questions['12']['question'] = 'Locurile preferate sau destinaţiile de călătorie?';

$profile_questions['12']['description'] = 'Odată ce ţi-ai găsit perechea unde ţi-ar plăcea sa mergi cu ea? Unde este locul preferat pentru a mânca?';

$profile_questions['12']['guideline'] = '';

$profile_questions['12']['extsearchhead'] = 'Locurile preferate';

$profile_questions['13']['question'] = 'Ce fel de sport şi exerciţii practici?';

$profile_questions['13']['description'] = '';

$profile_questions['13']['guideline'] = '';

$profile_questions['13']['extsearchhead'] = 'Sporturi';

$profile_questions['13']['34'] = 'Aerobic';

$profile_questions['13']['35'] = 'Curse auto / Motorcross';

$profile_questions['13']['36'] = 'Baseball';

$profile_questions['13']['37'] = 'Baschet';

$profile_questions['13']['372'] = 'Biliard / Biliard american';

$profile_questions['13']['373'] = 'Popice';

$profile_questions['13']['374'] = 'Ciclism';

$profile_questions['13']['375'] = 'Dans';

$profile_questions['13']['376'] = 'Fotbal american';

$profile_questions['13']['377'] = 'Golf';

$profile_questions['13']['378'] = 'Arte marţiale';

$profile_questions['13']['379'] = 'Atletism';

$profile_questions['13']['380'] = 'Ski';

$profile_questions['13']['381'] = 'Fotbal';

$profile_questions['13']['382'] = 'Înot';

$profile_questions['13']['383'] = 'Tenis / Badminton';

$profile_questions['13']['384'] = 'Volei';

$profile_questions['13']['385'] = 'Plimbare / Excursie pe jos';

$profile_questions['13']['386'] = 'Greutăţi / Maşini';

$profile_questions['13']['387'] = 'Yoga';

$profile_questions['14']['question'] = 'Lucruri favorite?';

$profile_questions['14']['description'] = 'Oricine are preferinţe. Care este mâncarea preferată? Care este culoarea preferată?';

$profile_questions['14']['guideline'] = 'acestea sunt pentru a te ghida';

$profile_questions['14']['extsearchhead'] = 'Lucruri favorite';

$profile_questions['15']['question'] = 'Ce ai citit ultima dată?';

$profile_questions['15']['description'] = 'Chiar dacă este un roman sau un ziar, o revista sau o cutie de lapte, spune-ne ce-ai citit ultima dată.';

$profile_questions['15']['guideline'] = '';

$profile_questions['15']['extsearchhead'] = 'Ultima citire';

$profile_questions['16']['question'] = 'Ce alte păreri ai vrea să schimbi cu alţi membri?';

$profile_questions['16']['description'] = '';

$profile_questions['16']['guideline'] = '';

$profile_questions['16']['extsearchhead'] = 'Interese comune';

$profile_questions['16']['38'] = 'Legături cu foşti elevi';

$profile_questions['16']['39'] = 'Night-cluburi/Dans';

$profile_questions['16']['40'] = 'Călătorii';

$profile_questions['16']['41'] = 'Despre gătit';

$profile_questions['16']['388'] = 'Despre afaceri';

$profile_questions['16']['389'] = 'Grup de cititori / Discuţii';

$profile_questions['16']['390'] = 'Cafea şi conversaţii';

$profile_questions['16']['391'] = 'Ieşiri la restaurant';

$profile_questions['16']['392'] = 'Pescuit / Vânătoare';

$profile_questions['16']['393'] = 'Grădinarit / Peisagistică';

$profile_questions['16']['394'] = 'Hobbiuri şi artizanate';

$profile_questions['16']['395'] = 'Filme / Video';

$profile_questions['16']['396'] = 'Muzee şi artă';

$profile_questions['16']['397'] = 'Muzică şi concerte';

$profile_questions['16']['398'] = 'Arta interpretarii';

$profile_questions['16']['399'] = 'Joc de cărţi';

$profile_questions['16']['400'] = 'Sporturi practicate';

$profile_questions['16']['401'] = 'Discuţii politice';

$profile_questions['16']['402'] = 'Religie / Spiritualism';

$profile_questions['16']['403'] = 'Cumpărături / Antichităţi';

$profile_questions['17']['question'] = 'Cum ţi-ai descrie simţul umorului?';

$profile_questions['17']['description'] = '';

$profile_questions['17']['guideline'] = '';

$profile_questions['17']['extsearchhead'] = 'Simţul umorului';

$profile_questions['17']['42'] = 'Sec: Cu cât e mai galben cu atât mai bine';

$profile_questions['17']['43'] = 'Tont: Desenele îmi provoacă accese de râs';

$profile_questions['17']['367'] = 'Inteligent: Nimic nu este mai bun decât o replică bună';

$profile_questions['17']['368'] = 'Neclar: De obicei sunt singurul care râde';

$profile_questions['17']['369'] = 'Fad / Sarcastic: Nu sunt înverşunat pentru că sunt singur. Exact opusul';

$profile_questions['17']['370'] = 'Comediant: Întreabă-mă despre episodul favorit din \'I Love Lucy\'';

$profile_questions['17']['371'] = 'Prietenos: Râd la orice';

$profile_questions['18']['question'] = 'Cât de des faci exerciţii';

$profile_questions['18']['description'] = '';

$profile_questions['18']['guideline'] = '';

$profile_questions['18']['extsearchhead'] = 'Exerciţii';

$profile_questions['18']['10086'] = 'De două ori pe zi';

$profile_questions['18']['10087'] = 'Zilnic';

$profile_questions['18']['10088'] = 'La două zile';

$profile_questions['18']['10089'] = 'Săptămânal';

$profile_questions['18']['10090'] = 'La două săptămâni';

$profile_questions['18']['10091'] = 'Lunar';

$profile_questions['18']['10092'] = 'Neconsecvent';

$profile_questions['18']['10093'] = 'Niciodată';

$profile_questions['19']['question'] = 'Ce descrie cel mai bine dieta ta zilnică?';

$profile_questions['19']['description'] = '';

$profile_questions['19']['guideline'] = '';

$profile_questions['19']['extsearchhead'] = 'Dieta zilnică';

$profile_questions['19']['10094'] = 'Carne şi cartofi';

$profile_questions['19']['10095'] = 'Mâncare nesănătoasă';

$profile_questions['19']['10096'] = 'Fast Food';

$profile_questions['19']['10097'] = 'Păstrează-ţi sănăntatea';

$profile_questions['19']['10098'] = 'Special / Dieta medicală';

$profile_questions['19']['10099'] = 'Vegetarian';

$profile_questions['19']['10100'] = 'Vegetarian înrăit';

$profile_questions['20']['question'] = 'Fumezi?';

$profile_questions['20']['description'] = '';

$profile_questions['20']['guideline'] = '';

$profile_questions['20']['extsearchhead'] = 'Fumător';

$profile_questions['20']['50'] = 'Nu, niciodată';

$profile_questions['20']['51'] = 'Nu, dar am fumat';

$profile_questions['20']['10711'] = 'Da, dar încerc să mă las';

$profile_questions['20']['10712'] = 'Da, ocazional';

$profile_questions['20']['10713'] = 'Da, regulat';

$profile_questions['21']['question'] = 'Cât de des consumi băuturi?';

$profile_questions['21']['description'] = '';

$profile_questions['21']['guideline'] = '';

$profile_questions['21']['extsearchhead'] = 'Consumi băuturi';

$profile_questions['21']['52'] = 'Niciodată';

$profile_questions['21']['53'] = 'Doar la reuniuni sociale';

$profile_questions['21']['54'] = 'Frecvent';

$profile_questions['22']['question'] = 'Lucrezi înainte de masă? Eşti propriul tău şef? Ce fel de job ai?';

$profile_questions['22']['description'] = '';

$profile_questions['22']['guideline'] = '';

$profile_questions['22']['extsearchhead'] = 'Programul de lucru';

$profile_questions['22']['10102'] = 'Normă întreagă de la 9 la 17';

$profile_questions['22']['10103'] = 'Normă întreagă în alte ore';

$profile_questions['22']['10104'] = 'Jumate de normă';

$profile_questions['22']['10105'] = 'Un sfert din program';

$profile_questions['22']['10106'] = 'Sunt independent';

$profile_questions['22']['10107'] = 'Caut de lucru';

$profile_questions['22']['10108'] = 'Momentan plecat';

$profile_questions['22']['10109'] = 'Demisionat';

$profile_questions['22']['10110'] = 'Casnic';

$profile_questions['23']['question'] = 'Venitul anual?';

$profile_questions['23']['description'] = '';

$profile_questions['23']['guideline'] = '';

$profile_questions['23']['extsearchhead'] = 'Venitul anual';

$profile_questions['23']['56'] = 'Mai puţin de $25,000';

$profile_questions['23']['57'] = '$25,001 la $50,000';

$profile_questions['23']['58'] = '$50,001 la $75,000';

$profile_questions['23']['59'] = '$75,001 la $100,000';

$profile_questions['23']['70'] = '$100,001 la $125,000';

$profile_questions['23']['71'] = '$125,001 la $150,000';

$profile_questions['23']['72'] = '$150,001 la $175,000';

$profile_questions['23']['10101'] = 'Peste $175,000';

$profile_questions['23']['10716'] = 'Spun mai târziu';

$profile_questions['24']['question'] = 'Locuieşti singur?';

$profile_questions['24']['description'] = '';

$profile_questions['24']['guideline'] = '';

$profile_questions['24']['extsearchhead'] = 'Cum locuieşti';

$profile_questions['24']['60'] = 'Locuiesc singur';

$profile_questions['24']['61'] = 'Locuiesc cu copii';

$profile_questions['24']['62'] = 'Locuiesc cu părinţii';

$profile_questions['24']['10714'] = 'Locuiesc cu colegii de cameră';

$profile_questions['24']['10715'] = 'Locuiesc cu altă familie';

$profile_questions['25']['question'] = 'Ai copii?';

$profile_questions['25']['description'] = '';

$profile_questions['25']['guideline'] = '';

$profile_questions['25']['extsearchhead'] = 'Dacă ai copii';

$profile_questions['25']['63'] = 'Nu';

$profile_questions['25']['64'] = 'Da - tot timpul acasă';

$profile_questions['25']['230'] = 'Da - partial acasă';

$profile_questions['25']['231'] = 'Da - dar nu acasă';

$profile_questions['26']['question'] = 'Vrei copii?';

$profile_questions['26']['description'] = '';

$profile_questions['26']['guideline'] = '';

$profile_questions['26']['extsearchhead'] = 'Doritor de copii';

$profile_questions['26']['65'] = 'Da';

$profile_questions['26']['66'] = 'Nu';

$profile_questions['26']['232'] = 'Nu sunt sigur';

$profile_questions['27']['question'] = 'Greutatea ta';

$profile_questions['27']['description'] = '';

$profile_questions['27']['guideline'] = '';

$profile_questions['27']['extsearchhead'] = 'Greutatea';

$profile_questions['27']['243'] = 'Sub 78 lbs (35.4 Kg)';

$profile_questions['27']['244'] = '78 lbs (35.4 Kg)';

$profile_questions['27']['245'] = '79 lbs (35.8 Kg)';

$profile_questions['27']['246'] = '80 lbs (36.3 Kg)';

$profile_questions['27']['247'] = '81 lbs (36.7 Kg)';

$profile_questions['27']['248'] = '82 lbs (37.2 Kg)';

$profile_questions['27']['249'] = '83 lbs (37.6 Kg)';

$profile_questions['27']['250'] = '84 lbs (38.1 Kg)';

$profile_questions['27']['251'] = '85 lbs (38.6 Kg)';

$profile_questions['27']['252'] = '86 lbs (39 Kg)';

$profile_questions['27']['253'] = '87 lbs (39.5 Kg)';

$profile_questions['27']['254'] = '88 lbs (39.9 Kg)';

$profile_questions['27']['255'] = '89 lbs (40.4 Kg)';

$profile_questions['27']['256'] = '90 lbs (40.8 Kg)';

$profile_questions['27']['257'] = '91 lbs (41.3 Kg)';

$profile_questions['27']['258'] = '92 lbs (41.7 Kg)';

$profile_questions['27']['259'] = '93 lbs (42.2 Kg)';

$profile_questions['27']['260'] = '94 lbs (42.6 Kg)';

$profile_questions['27']['261'] = '95 lbs (43.1 Kg)';

$profile_questions['27']['262'] = '96 lbs (43.5 Kg)';

$profile_questions['27']['263'] = '97 lbs (44 Kg)';

$profile_questions['27']['264'] = '98 lbs (44.5 Kg)';

$profile_questions['27']['265'] = '99 lbs (44.9 Kg)';

$profile_questions['27']['266'] = '100 lbs (45.4 Kg)';

$profile_questions['27']['267'] = '101 lbs (45.8 Kg)';

$profile_questions['27']['268'] = '102 lbs (46.3 Kg)';

$profile_questions['27']['269'] = '103 lbs (46.7 Kg)';

$profile_questions['27']['270'] = '104 lbs (47.2 Kg)';

$profile_questions['27']['271'] = '105 lbs (47.6 Kg)';

$profile_questions['27']['272'] = '106 lbs (48.1 Kg)';

$profile_questions['27']['273'] = '107 lbs (48.5 Kg)';

$profile_questions['27']['274'] = '108 lbs (49 Kg)';

$profile_questions['27']['275'] = '109 lbs (49.4 Kg)';

$profile_questions['27']['276'] = '110 lbs (49.9 Kg)';

$profile_questions['27']['277'] = '111 lbs (50.3 Kg)';

$profile_questions['27']['278'] = '112 lbs (50.8 Kg)';

$profile_questions['27']['279'] = '113 lbs (51.3 Kg)';

$profile_questions['27']['280'] = '114 lbs (51.7 Kg)';

$profile_questions['27']['281'] = '115 lbs (52.2 Kg)';

$profile_questions['27']['282'] = '116 lbs (52.6 Kg)';

$profile_questions['27']['283'] = '117 lbs (53.1 Kg)';

$profile_questions['27']['284'] = '118 lbs (53.5 Kg)';

$profile_questions['27']['285'] = '119 lbs (54 Kg)';

$profile_questions['27']['286'] = '120 lbs (54.4 Kg)';

$profile_questions['27']['287'] = '121 lbs (54.9 Kg)';

$profile_questions['27']['288'] = '122 lbs (55.3 Kg)';

$profile_questions['27']['289'] = '123 lbs (55.8 Kg)';

$profile_questions['27']['290'] = '124 lbs (56.2 Kg)';

$profile_questions['27']['291'] = '125 lbs (56.7 Kg)';

$profile_questions['27']['292'] = '126 lbs (57.2 Kg)';

$profile_questions['27']['293'] = '127 lbs (57.6 Kg)';

$profile_questions['27']['294'] = '128 lbs (58.1 Kg)';

$profile_questions['27']['295'] = '129 lbs (58.5 Kg)';

$profile_questions['27']['296'] = '130 lbs (59 Kg)';

$profile_questions['27']['297'] = '131 lbs (59.4 Kg)';

$profile_questions['27']['298'] = '132 lbs (59.9 Kg)';

$profile_questions['27']['299'] = '133 lbs (60.3 Kg)';

$profile_questions['27']['300'] = '134 lbs (60.8 Kg)';

$profile_questions['27']['301'] = '135 lbs (61.2 Kg)';

$profile_questions['27']['302'] = '136 lbs (61.7 Kg)';

$profile_questions['27']['303'] = '137 lbs (62.1 Kg)';

$profile_questions['27']['304'] = '138 lbs (62.6 Kg)';

$profile_questions['27']['305'] = '139 lbs (63.1 Kg)';

$profile_questions['27']['306'] = '140 lbs (63.5 Kg)';

$profile_questions['27']['307'] = '141 lbs (64 Kg)';

$profile_questions['27']['308'] = '142 lbs (64.4 Kg)';

$profile_questions['27']['309'] = '143 lbs (64.9 Kg)';

$profile_questions['27']['310'] = '144 lbs (65.3 Kg)';

$profile_questions['27']['311'] = '145 lbs (65.8 Kg)';

$profile_questions['27']['312'] = '146 lbs (66.2 Kg)';

$profile_questions['27']['313'] = '147 lbs (66.7 Kg)';

$profile_questions['27']['314'] = '148 lbs (67.1 Kg)';

$profile_questions['27']['315'] = '149 lbs (67.6 Kg)';

$profile_questions['27']['316'] = '150 lbs (68 Kg)';

$profile_questions['27']['317'] = '151 lbs (68.5 Kg)';

$profile_questions['27']['318'] = '152 lbs (68.9 Kg)';

$profile_questions['27']['319'] = '153 lbs (69.4 Kg)';

$profile_questions['27']['320'] = '154 lbs (69.9 Kg)';

$profile_questions['27']['321'] = '155 lbs (70.3 Kg)';

$profile_questions['27']['322'] = '156 lbs (70.8 Kg)';

$profile_questions['27']['323'] = '157 lbs (71.2 Kg)';

$profile_questions['27']['324'] = '158 lbs (71.7 Kg)';

$profile_questions['27']['325'] = '159 lbs (72.1 Kg)';

$profile_questions['27']['326'] = '160 lbs (72.6 Kg)';

$profile_questions['27']['327'] = '161 lbs (73 Kg)';

$profile_questions['27']['328'] = '162 lbs (73.5 Kg)';

$profile_questions['27']['329'] = '163 lbs (73.9 Kg)';

$profile_questions['27']['330'] = '164 lbs (74.4 Kg)';

$profile_questions['27']['331'] = '165 lbs (74.8 Kg)';

$profile_questions['27']['332'] = '166 lbs (75.3 Kg)';

$profile_questions['27']['333'] = '167 lbs (75.8 Kg)';

$profile_questions['27']['334'] = '168 lbs (76.2 Kg)';

$profile_questions['27']['335'] = '169 lbs (76.7 Kg)';

$profile_questions['27']['336'] = '170 lbs (77.1 Kg)';

$profile_questions['27']['337'] = '171 lbs (77.6 Kg)';

$profile_questions['27']['338'] = '172 lbs (78 Kg)';

$profile_questions['27']['339'] = '173 lbs (78.5 Kg)';

$profile_questions['27']['340'] = '174 lbs (78.9 Kg)';

$profile_questions['27']['341'] = '175 lbs (79.4 Kg)';

$profile_questions['27']['342'] = '176 lbs (79.8 Kg)';

$profile_questions['27']['343'] = '177 lbs (80.3 Kg)';

$profile_questions['27']['344'] = '178 lbs (80.7 Kg)';

$profile_questions['27']['345'] = '179 lbs (81.2 Kg)';

$profile_questions['27']['346'] = '180 lbs (81.6 Kg)';

$profile_questions['27']['347'] = '181 lbs (82.1 Kg)';

$profile_questions['27']['348'] = '182 lbs (82.6 Kg)';

$profile_questions['27']['349'] = '183 lbs (83 Kg)';

$profile_questions['27']['350'] = '184 lbs (83.5 Kg)';

$profile_questions['27']['351'] = '185 lbs (83.9 Kg)';

$profile_questions['27']['352'] = '186 lbs (84.4 Kg)';

$profile_questions['27']['353'] = '187 lbs (84.8 Kg)';

$profile_questions['27']['354'] = '188 lbs (85.3 Kg)';

$profile_questions['27']['355'] = '189 lbs (85.7 Kg)';

$profile_questions['27']['356'] = '190 lbs (86.2 Kg)';

$profile_questions['27']['357'] = '191 lbs (86.6 Kg)';

$profile_questions['27']['358'] = '192 lbs (87.1 Kg)';

$profile_questions['27']['359'] = '193 lbs (87.5 Kg)';

$profile_questions['27']['360'] = '194 lbs (88 Kg)';

$profile_questions['27']['361'] = '195 lbs (88.5 Kg)';

$profile_questions['27']['362'] = '196 lbs (88.9 Kg)';

$profile_questions['27']['363'] = '197 lbs (89.4 Kg)';

$profile_questions['27']['364'] = '198 lbs (89.8 Kg)';

$profile_questions['27']['365'] = '199 lbs (90.3 Kg)';

$profile_questions['27']['366'] = '200 lbs (90.7 Kg)';

$profile_questions['27']['10111'] = '201 lbs (91.2 Kg)';

$profile_questions['27']['10112'] = '202 lbs (91.6 Kg)';

$profile_questions['27']['10113'] = '203 lbs (92.1 Kg)';

$profile_questions['27']['10114'] = '204 lbs (92.5 Kg)';

$profile_questions['27']['10115'] = '205 lbs (93 Kg)';

$profile_questions['27']['10116'] = '206 lbs (93.4 Kg)';

$profile_questions['27']['10117'] = '207 lbs (93.9 Kg)';

$profile_questions['27']['10118'] = '208 lbs (94.3 Kg)';

$profile_questions['27']['10119'] = '209 lbs (94.8 Kg)';

$profile_questions['27']['10120'] = '210 lbs (95.2 Kg)';

$profile_questions['27']['10121'] = '211 lbs (95.7 Kg)';

$profile_questions['27']['10122'] = '212 lbs (96.1 Kg)';

$profile_questions['27']['10123'] = '213 lbs (96.6 Kg)';

$profile_questions['27']['10124'] = '214 lbs (97 Kg)';

$profile_questions['27']['10125'] = '215 lbs (97.5 Kg)';

$profile_questions['27']['10126'] = '216 lbs (97.9 Kg)';

$profile_questions['27']['10127'] = '217 lbs (98.3 Kg)';

$profile_questions['27']['10128'] = '218 lbs (98.8 Kg)';

$profile_questions['27']['10129'] = '219 lbs (99.2 Kg)';

$profile_questions['27']['10130'] = '220 lbs (99.7 Kg)';

$profile_questions['27']['10131'] = '221 lbs (100.2 Kg)';

$profile_questions['27']['10132'] = '222 lbs (100.6 Kg)';

$profile_questions['27']['10133'] = '223 lbs (101 Kg)';

$profile_questions['27']['10134'] = '224 lbs (101.5 Kg)';

$profile_questions['27']['10135'] = '225 lbs (101.9 Kg)';

$profile_questions['27']['10136'] = '226 lbs (102.3 Kg)';

$profile_questions['27']['10137'] = '227 lbs (102.8 Kg)';

$profile_questions['27']['10138'] = '228 lbs (103.2 Kg)';

$profile_questions['27']['10139'] = '229 lbs (103.7 Kg)';

$profile_questions['27']['10140'] = '230 lbs (104.1 Kg)';

$profile_questions['27']['10141'] = '231 lbs (104,6 Kg)';

$profile_questions['27']['10142'] = '232 lbs (105 Kg)';

$profile_questions['27']['10143'] = '233 lbs (105.5 Kg)';

$profile_questions['27']['10144'] = '234 lbs (105.9 Kg)';

$profile_questions['27']['10145'] = '235 lbs (106.4 Kg)';

$profile_questions['27']['10146'] = '236 lbs (106.8 Kg)';

$profile_questions['27']['10147'] = '237 lbs (107.3 Kg)';

$profile_questions['27']['10148'] = '238 lbs (107.7 Kg)';

$profile_questions['27']['10149'] = '239 lbs (108.2 Kg)';

$profile_questions['27']['10150'] = '240 lbs (108.6 Kg)';

$profile_questions['27']['10151'] = '241 lbs (109.1 Kg)';

$profile_questions['27']['10152'] = '242 lbs (109.5 Kg)';

$profile_questions['27']['10153'] = '243 lbs (110 Kg)';

$profile_questions['27']['10154'] = '244 lbs (110.4 Kg)';

$profile_questions['27']['10155'] = '245 lbs (110.9 Kg)';

$profile_questions['27']['10156'] = '246 lbs (111.3 Kg)';

$profile_questions['27']['10157'] = '247 lbs (111.8 Kg)';

$profile_questions['27']['10158'] = '248 lbs (112.2 Kg)';

$profile_questions['27']['10159'] = '249 lbs (112.7 Kg)';

$profile_questions['27']['10160'] = '250 lbs (113.1 Kg)';

$profile_questions['27']['10161'] = '251 lbs (113,6 Kg)';

$profile_questions['27']['10162'] = '252 lbs (114 Kg)';

$profile_questions['27']['10163'] = '253 lbs (114.5 Kg)';

$profile_questions['27']['10164'] = '254 lbs (114.9 Kg)';

$profile_questions['27']['10165'] = '255 lbs (115.3 Kg)';

$profile_questions['27']['10166'] = '256 lbs (115.8 Kg)';

$profile_questions['27']['10167'] = '257 lbs (116.2 Kg)';

$profile_questions['27']['10168'] = '258 lbs (116.7 Kg)';

$profile_questions['27']['10169'] = '259 lbs (117.1 Kg)';

$profile_questions['27']['10170'] = '260 lbs (117.6 Kg)';

$profile_questions['27']['10171'] = '261 lbs (118 Kg)';

$profile_questions['27']['10172'] = '262 lbs (118.5 Kg)';

$profile_questions['27']['10173'] = '263 lbs (118.9 Kg)';

$profile_questions['27']['10174'] = '264 lbs (119.4 Kg)';

$profile_questions['27']['10175'] = '265 lbs (119.8 Kg)';

$profile_questions['27']['10176'] = '266 lbs (120.3 Kg)';

$profile_questions['27']['10177'] = '267 lbs (120.7 Kg)';

$profile_questions['27']['10178'] = '268 lbs (121.1 Kg)';

$profile_questions['27']['10179'] = '269 lbs (121.6 Kg)';

$profile_questions['27']['10180'] = '270 lbs (122 Kg)';

$profile_questions['27']['10181'] = '271 lbs (122.5 Kg)';

$profile_questions['27']['10182'] = '272 lbs (122.9 Kg)';

$profile_questions['27']['10183'] = '273 lbs (123.3 Kg)';

$profile_questions['27']['10184'] = '274 lbs (123.8 Kg)';

$profile_questions['27']['10185'] = '275 lbs (124.2 Kg)';

$profile_questions['27']['10186'] = '276 lbs (124.7 Kg)';

$profile_questions['27']['10187'] = '277 lbs (125.1 Kg)';

$profile_questions['27']['10188'] = '278 lbs (125.5 Kg)';

$profile_questions['27']['10189'] = '279 lbs (126 Kg)';

$profile_questions['27']['10190'] = '280 lbs (126.4 Kg)';

$profile_questions['27']['10191'] = '281 lbs (126.9 Kg)';

$profile_questions['27']['10192'] = '282 lbs (127.3 Kg)';

$profile_questions['27']['10193'] = '283 lbs (127.8 Kg)';

$profile_questions['27']['10194'] = '284 lbs (128.2 Kg)';

$profile_questions['27']['10195'] = '285 lbs (128.7 Kg)';

$profile_questions['27']['10196'] = '286 lbs (129.1 Kg)';

$profile_questions['27']['10197'] = '287 lbs (129.6 Kg)';

$profile_questions['27']['10198'] = '288 lbs (130 Kg)';

$profile_questions['27']['10199'] = '289 lbs (130.5 Kg)';

$profile_questions['27']['10200'] = '290 lbs (130.9 Kg)';

$profile_questions['27']['10201'] = '291 lbs (131.3 Kg)';

$profile_questions['27']['10202'] = '292 lbs (131.8 Kg)';

$profile_questions['27']['10203'] = '293 lbs (132.2 Kg)';

$profile_questions['27']['10204'] = '294 lbs (132.7 Kg)';

$profile_questions['27']['10205'] = '295 lbs (133.1 Kg)';

$profile_questions['27']['10206'] = '296 lbs (133.6 Kg)';

$profile_questions['27']['10207'] = '297 lbs (134 Kg)';

$profile_questions['27']['10208'] = '298 lbs (134.5 Kg)';

$profile_questions['27']['10209'] = '299 lbs (134.9 Kg)';

$profile_questions['27']['10210'] = '300 lbs (135.3 Kg)';

$profile_questions['27']['10211'] = '301 lbs (135.8 Kg)';

$profile_questions['27']['10212'] = '302 lbs (136.2 Kg)';

$profile_questions['27']['10213'] = '303 lbs (136.7 Kg)';

$profile_questions['27']['10214'] = '304 lbs (137.1 Kg)';

$profile_questions['27']['10215'] = '305 lbs (137.6 Kg)';

$profile_questions['27']['10216'] = '306 lbs (138 Kg)';

$profile_questions['27']['10217'] = '307 lbs (138.5 Kg)';

$profile_questions['27']['10218'] = '308 lbs (138.9 Kg)';

$profile_questions['27']['10219'] = '309 lbs (139.4 Kg)';

$profile_questions['27']['10220'] = '310 lbs (139.8 Kg)';

$profile_questions['27']['10221'] = '311 lbs (140.3 Kg)';

$profile_questions['27']['10222'] = '312 lbs (140.7 Kg)';

$profile_questions['27']['10223'] = '313 lbs (141.1 Kg)';

$profile_questions['27']['10224'] = '314 lbs (141.6 Kg)';

$profile_questions['27']['10225'] = '315 lbs (142 Kg)';

$profile_questions['27']['10226'] = '316 lbs (142.5 Kg)';

$profile_questions['27']['10227'] = '317 lbs (142.9 Kg)';

$profile_questions['27']['10228'] = '318 lbs (143.4 Kg)';

$profile_questions['27']['10229'] = '319 lbs (143.8 Kg)';

$profile_questions['27']['10230'] = '320 lbs (144.3 Kg)';

$profile_questions['27']['10231'] = '321 lbs (144.7 Kg)';

$profile_questions['27']['10232'] = '322 lbs (145.2 Kg)';

$profile_questions['27']['10233'] = '323 lbs (145.6 Kg)';

$profile_questions['27']['10234'] = '324 lbs (146.1 Kg)';

$profile_questions['27']['10235'] = '325 lbs (146.6 Kg)';

$profile_questions['27']['10236'] = '326 lbs (147 Kg)';

$profile_questions['27']['10237'] = '327 lbs (147.5 Kg)';

$profile_questions['27']['10238'] = '328 lbs (147.9 Kg)';

$profile_questions['27']['10239'] = '329 lbs (148.4 Kg)';

$profile_questions['27']['10240'] = '330 lbs (148.8 Kg)';

$profile_questions['27']['10241'] = '331 lbs (149.3 Kg)';

$profile_questions['27']['10242'] = '332 lbs (149.7 Kg)';

$profile_questions['27']['10243'] = '333 lbs (150.2 Kg)';

$profile_questions['27']['10244'] = '334 lbs (150.6 Kg)';

$profile_questions['27']['10245'] = '335 lbs (151.1 Kg)';

$profile_questions['27']['10246'] = '336 lbs (151.6 Kg)';

$profile_questions['27']['10247'] = '337 lbs (152 Kg)';

$profile_questions['27']['10248'] = '338 lbs (152.5 Kg)';

$profile_questions['27']['10249'] = '339 lbs (152.9 Kg)';

$profile_questions['27']['10250'] = '340 lbs (153.3 Kg)';

$profile_questions['27']['10251'] = '341 lbs (153.8 Kg)';

$profile_questions['27']['10252'] = '342 lbs (154.2 Kg)';

$profile_questions['27']['10253'] = '343 lbs (154.7 Kg)';

$profile_questions['27']['10254'] = '344 lbs (155.1 Kg)';

$profile_questions['27']['10255'] = '345 lbs (155.6 Kg)';

$profile_questions['27']['10256'] = '346 lbs (156 Kg)';

$profile_questions['27']['10257'] = '347 lbs (156.5 Kg)';

$profile_questions['27']['10258'] = '348 lbs (156.9 Kg)';

$profile_questions['27']['10259'] = '349 lbs (157.4 Kg)';

$profile_questions['27']['10260'] = '350 lbs (157.8 Kg)';

$profile_questions['27']['10261'] = 'Over 350 lbs (157.8 Kg)';

$profile_questions['28']['question'] = 'Statutul de angajat';

$profile_questions['28']['description'] = '';

$profile_questions['28']['guideline'] = '';

$profile_questions['28']['extsearchhead'] = 'Statutul de angajat';

$profile_questions['28']['233'] = 'Normă întreagă';

$profile_questions['28']['234'] = 'Jumate de normă';

$profile_questions['28']['235'] = 'Casnic';

$profile_questions['28']['236'] = 'Demisionat';

$profile_questions['28']['237'] = 'Lucrez singur';

$profile_questions['28']['238'] = 'Student';

$profile_questions['28']['239'] = 'Neangajat';

$profile_questions['28']['240'] = 'Lucrez acasă';

$profile_questions['29']['question'] = 'Cum ai descrie educaţia ta?';

$profile_questions['29']['description'] = '';

$profile_questions['29']['guideline'] = '';

$profile_questions['29']['extsearchhead'] = 'Educatia';

$profile_questions['29']['194'] = 'Liceul';

$profile_questions['29']['195'] = 'Colegiul';

$profile_questions['29']['196'] = 'Grad de asociat';

$profile_questions['29']['197'] = 'Grad de licenţiat';

$profile_questions['29']['198'] = 'Grad de absolvent';

$profile_questions['29']['199'] = 'PhD / Post Doctorat';

$profile_questions['29']['200'] = 'Şcoala vieţii';

$profile_questions['29']['201'] = 'Nici un răspuns';

$profile_questions['30']['question'] = 'Ce limbi străine vorbeşti?';

$profile_questions['30']['description'] = '';

$profile_questions['30']['guideline'] = '';

$profile_questions['30']['extsearchhead'] = 'Limbi';

$profile_questions['30']['10050'] = 'Arabă';

$profile_questions['30']['10051'] = 'Cambodiană';

$profile_questions['30']['10052'] = 'Chineză';

$profile_questions['30']['10053'] = 'Olandeză';

$profile_questions['30']['10054'] = 'Engleză';

$profile_questions['30']['10055'] = 'Franceză';

$profile_questions['30']['10056'] = 'Germană';

$profile_questions['30']['10058'] = 'Ebraică';

$profile_questions['30']['10059'] = 'Hindi';

$profile_questions['30']['10060'] = 'Italiană';

$profile_questions['30']['10061'] = 'Portugheză';

$profile_questions['30']['10062'] = 'Română';

$profile_questions['30']['10063'] = 'Rusă';

$profile_questions['30']['10064'] = 'Spaniolă';

$profile_questions['30']['10065'] = 'Thai';

$profile_questions['30']['10066'] = 'Turcă';

$profile_questions['30']['10067'] = 'Vietnameză';

$profile_questions['30']['10717'] = 'Alta';

$profile_questions['37']['question'] = 'Cum ai auzit despre noi?';

$profile_questions['37']['description'] = 'Te rugăm menţioneză sursa de unde ai auzit despre noi.';

$profile_questions['37']['guideline'] = '';

$profile_questions['37']['extsearchhead'] = 'Indicat de';

$profile_questions['37']['10041'] = 'Email ';

$profile_questions['37']['10042'] = 'Ziare sau alte publicaţii';

$profile_questions['37']['10043'] = 'Bannere';

$profile_questions['37']['10044'] = 'Radio';

$profile_questions['37']['10045'] = 'Indicat de un prieten';

$profile_questions['37']['10046'] = 'Televizor';

$profile_questions['37']['10047'] = 'Căutare pe Internet';

$profile_questions['37']['10048'] = 'Mi-a zis cineva';

$profile_questions['37']['10049'] = 'Alte surse';

?>