<?php
/**
 * MyBB 1.4 English Language Pack
 * Copyright © 2008 MyBB Group, All Rights Reserved
 * 
 * $Id: helpsections.lang.php 4304 2009-01-02 01:11:56Z chris $
 */

// Help Section 1
$l['s1_name'] = "User Maintenance";
$l['s1_desc'] = "Basic instructions for maintaining a forum account.";

// Help Section 2
$l['s2_name'] = "Posting";
$l['s2_desc'] = "Posting, replying, and basic usage of forum.";
?>