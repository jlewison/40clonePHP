<?
error_reporting(0);
$dbhost="localhost";
$dbuname="122083";
$dbpass="azerty12345";
$dbname="122083";
mysql_connect($dbhost, $dbuname, $dbpass) or die("<br><br><center><br><br><b>Impossible de se connecter</center></b>");
mysql_select_db($dbname);
?>