<?php
/**
 * Group category Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 02/01/2008
 */
class GroupCategory extends controller
{
		function GroupCategory()
		{
				parent::controller();
				//check login
				if ($this->session->userdata('admin_logged_in') != 1 && $this->session->userdata('admin_id') == '') redirect('admin/login');
				//Load the language file
				$this->lang->load('admin/groupCategory', $this->config->item('language_code'));
				$this->load->model('groupsmodel');
		}
		function index()
		{
				$this->load->library('validation');
				$this->_eventCategoryFrm();
				$outputData['addGroupCategory'] = true;
				$outputData['editGroupCategory'] = false;
				$outputData['groupsList'] = $this->groupsmodel->getGroupsMainCategory($status = '');
				if (!empty($outputData['groupsList'])) $outputData['groupsListArr'] = $outputData['groupsList'];
				else  $outputData['groupsListArr'] = false;
				if ($this->validation->run() == false) $outputData['validationError'] = $this->validation->error_string;
				else
				{
						if (isset($_POST['add_group_category']))
						{
								$this->groupsmodel->insertGroupCategory($_POST);
								//Set the flash data
								$this->session->set_flashdata('successMsg', $this->lang->line('groupcategory_add_success_msg'));
								redirect('admin/groupCategory');
						}
				}
				$this->smartyextended->view('../admin/groupCategory', $outputData);
		}
		function _eventCategoryFrm()
		{
				$rules['group_category_name'] = 'trim|required|alphanumeric';
				$rules['group_category_description'] = 'trim|required|alphanumeric';
				$fields['event_category_name'] = $this->lang->line('groupcategory_category_name');
				$fields['event_category_description'] = $this->lang->line('groupcategory_description');
				$this->validation->set_rules($rules);
				$this->validation->set_fields($fields);
		}
		#***************************************************************************
		#Method			: editGroupCategory
		#Description	: updates Group Category
		#Author			
		#***************************************************************************
		function editGroupCategory()
		{
				$this->load->library('validation');
				$outputData['group_category_id'] = $this->uri->segment(4);
				$outputData['addGroupCategory'] = false;
				$outputData['editGroupCategory'] = true;
				$outputData['groupsList'] = $this->groupsmodel->getGroupsMainCategory($status = '');
				if (!empty($outputData['groupsList'])) $outputData['groupsListArr'] = $outputData['groupsList'];
				else  $outputData['groupsListArr'] = false;
				//$outputData['events'] = $this->eventsmodel->geteventCategory($status='');
				//echo '<pre>';
				//print_r($outputData['eventsList']); exit();
				$this->_eventCategoryFrm();
				if ($this->validation->run() == false) $outputData['validationError'] = $this->validation->error_string;
				else
				{
						if (isset($_POST['update_group_category']))
						{
								$this->groupsmodel->updateGroupCategory($_POST);
								//Set the flash data
								$this->session->set_flashdata('successMsg', $this->lang->line('groupcategory_update_success_msg'));
								redirect('admin/groupCategory');
						}
				}
				$this->smartyextended->view('../admin/groupCategory', $outputData);
		}
}
?>