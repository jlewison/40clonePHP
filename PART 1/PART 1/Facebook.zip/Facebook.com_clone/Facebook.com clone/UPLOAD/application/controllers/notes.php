<?php

/**
 * manage notes
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 11/13/2007
 */
class Notes extends Controller
{
		var $userId, $notesImagePath, $notesPhotoPath;
		//Constructor
		function Notes()
		{
				parent::Controller();
				loginRequired();
				//Load the language file
				$this->userId = $this->session->userdata('user_id');
				$this->lang->load('posted', $this->config->item('language_code'));
				$this->lang->load('notes', $this->config->item('language_code'));
				//Load the notes model
				$this->load->model('notesModel');
				//Load the user model
				$this->load->model('userModel');
				//Load the Friends model
				$this->load->model('friendsModel');
				$this->notesImagePath = base_url() . 'application/content/notes/photos/';
				$this->notesPhotoPath = APPPATH . 'content/notes/photos/';
		}
		function index()
		{
				$this->home();
		} //end method
		function home($friendId = '')
		{
				$friendsContent = "";
				$content = "";
				$userId = $this->session->userdata('user_id');
				$select = '';
				$friendsId = implode(",", $this->friendsModel->getFriends($userId));
				if ($friendsId == '')
				{
						$data['friendsResult'] = array();
				}
				else
				{
						$data['totalCount'] = $this->friendsModel->notesCount($friendsId);
						$data['friendsResult'] = $this->userModel->getUserNotes($friendsId);
						$recentlyTaggedFriends = $this->friendsModel->recentlyTagged($friendsId);
						$data['recentlyTaggedFriends'] = $recentlyTaggedFriends;
						/*
						if($_POST)
						{
						if(isset($_POST['lstFriends']) && intval($_POST['lstFriends']) !== 0)
						{
						$friendsId = $_POST['lstFriends'];
						}
						}
						*/
						if ($friendId == '')
						{
								$friendId = 0;
						}
						if ($friendId != 0)
						{
								$friendsId = $friendId;
						}
						//getNotes($userIds, $notesId='', $orderBy = 'n.date_created', $start = '', $limit = '')
						//Load the pagination model
						$this->load->model('paginationmodel');
						//Load the pagination language file
						$this->lang->load('pagination', $this->config->item('language_code'));
						$perPage = $this->paginationmodel->getPerPage('notes');
						$start = (trim($this->uri->segment(4)) != '' && is_numeric($this->uri->segment(4)) && $this->uri->segment(4) > 0) ? $this->uri->segment(4) : 1;
						$start = ($start - 1) * $perPage;
						$arrUserNotesIds = $this->userModel->getNotes($friendsId, '', 'n.date_created', $start, $perPage);
						$data['friendsNotesList'] = array();
						foreach ($arrUserNotesIds as $key => $val)
						{
								$data['friendsNotesList'][$val] = $this->notesModel->listNotes($val);
						}
						$data['resultcount'] = count($arrUserNotesIds);
						$data['resultTotal'] = $this->userModel->getNotesCount($friendsId);
						$data['currentPage'] = (trim($this->uri->segment(4)) != '' && is_numeric($this->uri->segment(4))) ? $this->uri->segment(4) : 1;
						$data['totalPages'] = ($data['resultTotal'] > $perPage) ? ceil(($data['resultTotal'] / $perPage)) : 0;
						$data['pageUrl'] = base_url() . 'notes/home/' . $friendId . '/';
				}
				$data['friend'] = $friendId;
				$this->smartyextended->view('notes_home', $data);
		}
		###################################################################################################
		#Method			: userNotes()
		#Type			: main
		#Description	: To show all users' notes
		#Author			: B. Sivanantham
		###################################################################################################
		function userNotes($user = '', $notesId = '', $cmt = '', $commentId = '')
		{
				/*
				$user	=	$this->uri->segment(3);
				$notesId= 	$this->uri->segment(4);
				$cmt	=	$this->uri->segment(5);
				*/
				$notesResultView = array();
				$user = (!ereg("^[0-9]+$", $user)) ? $this->session->userdata('user_id') : $user;
				$strCond = "";
				//Load the pagination model
				$this->load->model('paginationmodel');
				//Load the pagination language file
				$this->lang->load('pagination', $this->config->item('language_code'));
				$perPage = $this->paginationmodel->getPerPage('notes');
				$start = (trim($this->uri->segment(7)) != '' && is_numeric($this->uri->segment(7)) && $this->uri->segment(7) > 0) ? $this->uri->segment(7) : 1;
				$start = ($start - 1) * $perPage;
				if ($notesId == '')
				{
						$notesId = 'n';
				}
				if ($cmt == '')
				{
						$cmt = 'cmt';
				}
				if ($commentId == '')
				{
						$commentId = 'n';
				}
				$data = array();
				$data['errmsg'] = '';
				if ($this->input->post('hdnAction') !== false and $this->input->post('hdnAction') == 'addcomment')
				{
						$hdnNotesId = $this->input->post('hdnId');
						if ($hdnNotesId != false)
						{
								$cmtText = $this->input->post('txtComment' . $hdnNotesId);
								if ($cmtText != false && trim($cmtText) != '')
								{
										$this->notesModel->addComment($hdnNotesId, $cmtText);
										//Set the flash data
										//$this->lang->line('notes_comment_success')
										$this->session->set_flashdata('flash_msg', $this->lang->line('notes_comment_success'));
										redirect($this->uri->uri_string());
								}
								else
								{
										$data['errmsg'] = $this->lang->line('notes_enter_comment');
										$cmt = 'addcomment';
								}
						}
						else
						{
								$data['cmt'] = 'addcomment';
						}
				} elseif (trim($cmt) == 'deletecomment')
				{
						if (ereg('^[0-9]+$', $commentId))
						{
								$this->notesModel->removeComment($commentId);
								$this->session->set_flashdata('flash_msg', $this->lang->line('notes_comment_delete_success'));
								redirect('notes/userNotes/' . $user . '/' . $notesId . '/');
						}
				}
				$arrUserNotes = $this->userModel->getNotes($user, $notesId, 'n.date_created', $start, $perPage);
				if (count($arrUserNotes) > 0)
				{
						foreach ($arrUserNotes as $key => $val)
						{
								$notesResultView[$val] = $this->notesModel->_dispNotes($val);
								$notesResultView[$val]['message'] = implode('<br/><br/>', $this->parseMessage($notesResultView[$val]['message'], $notesResultView[$val]['photos'])); //$notesResultView[$val]['message'];
						}
						$data['resultcount'] = count($arrUserNotes);
						$data['resultTotal'] = $this->userModel->getNotesCount($user);
						$data['currentPage'] = (trim($this->uri->segment(7)) != '' && is_numeric($this->uri->segment(7))) ? $this->uri->segment(7) : 1;
						$data['totalPages'] = ($data['resultTotal'] > $perPage) ? ceil(($data['resultTotal'] / $perPage)) : 0;
						$data['pageUrl'] = base_url() . 'notes/userNotes/' . $user . '/' . $notesId . '/' . $cmt . '/' . $commentId . '/';
				}
				//echo 'Notes ID : '.$notesId.'---';
				$data['cmt'] = $cmt;
				$data['userId'] = $user;
				$data['avatar'] = $this->userModel->getAvatar($user, true);
				$data['user_name'] = ucwords($this->userModel->getName($user));
				$data['notes_id'] = $notesId;
				$data['notesViewArray'] = $notesResultView;
				$this->smartyextended->view('notes_user', $data);
		}
		# To disp message with actual image in listing notes
		function parseMessage($msg, $photos)
		{
				//print htmlspecialchars($msg);
				//$newmsg = ereg_replace('<photos-[0-9]+>','hihihi',$msg);
				//print '<br> new msg = '.$newmsg;
				preg_match_all("<photos-[0-9]+>", $msg, $arrPhotos);
				$arrTexts = split("&lt;photos-[0-9]+&gt;", htmlentities($msg));
				$diff = count($arrTexts) - count($arrPhotos[0]);
				if ($diff > 0)
				{
						for ($i = 1; $i <= $diff; $i++)
						{
								$arrPhotos[0][] = '';
						}
				}
				$resArr = array();
				for ($i = 0; $i < count($arrTexts); $i++)
				{
						if ($arrTexts[$i] != '')
						{
								$resArr[] = wordwrap($arrTexts[$i], 58, "\n", true);
						}
						if ($arrPhotos[0][$i] != '') $resArr[] = $arrPhotos[0][$i];
				}
				$cnt = count($resArr);
				for ($i = 0; $i < $cnt; $i++)
				{
						if (substr($resArr[$i], 0, 5) == 'photo')
						{
								$indexValArr = explode('-', $resArr[$i]);
								$indexVal = intval($indexValArr[1]) - 1;
								if ($indexVal >= 0 and $indexVal < count($photos)) $resArr[$i] = "<img width='180px' height='135px' src='" . base_url() . "application/content/notes/photos/" . $photos[$indexVal]['notes_id'] . "_" . $photos[$indexVal]['photo_id'] . "." . $photos[$indexVal]['file_name'] . "' border='0'>";
						}
				}
				return $resArr;
		}
		function aboutNotes($user = '', $notesId = '', $cmt = '', $commentId = '')
		{
				$notesResultView = array();
				$user = (!ereg("^[0-9]+$", $user)) ? $this->session->userdata('user_id') : $user;
				$strCond = "";
				//Load the pagination model
				$this->load->model('paginationmodel');
				//Load the pagination language file
				$this->lang->load('pagination', $this->config->item('language_code'));
				$perPage = $this->paginationmodel->getPerPage('notes');
				$start = (trim($this->uri->segment(7)) != '' && is_numeric($this->uri->segment(7)) && $this->uri->segment(7) > 0) ? $this->uri->segment(7) : 1;
				$start = ($start - 1) * $perPage;
				if ($notesId == '')
				{
						$notesId = 'n';
				}
				if ($cmt == '')
				{
						$cmt = 'cmt';
				}
				if ($commentId == '')
				{
						$commentId = 'n';
				}
				$arrUserNotes = $this->userModel->getAboutNotes($user, $notesId, 'n.date_created', $start, $perPage);
				//getAboutNotesCount($userIds, $notesId='')
				//$arrUserNotes	= 	$this->userModel->getAboutNotes($user,$notesId);
				$data = array();
				$data['errmsg'] = '';
				if ($this->input->post('hdnAction') !== false and $this->input->post('hdnAction') == 'addcomment')
				{
						$hdnNotesId = $this->input->post('hdnId');
						if ($hdnNotesId != false)
						{
								$cmtText = $this->input->post('txtComment' . $hdnNotesId);
								if ($cmtText != false && trim($cmtText) != '')
								{
										$this->notesModel->addComment($hdnNotesId, $cmtText);
										$this->session->set_flashdata('flash_msg', $this->lang->line('notes_comment_success'));
										redirect($this->uri->uri_string());
								}
								else
								{
										$data['errmsg'] = $this->lang->line('notes_enter_comment');
								}
						}
						else
						{
								$data['cmt'] = 'addcomment';
						}
				} elseif (trim($cmt) == 'deletecomment')
				{
						if (ereg('^[0-9]+$', $commentId))
						{
								$this->notesModel->removeComment($commentId);
								$this->session->set_flashdata('flash_msg', $this->lang->line('notes_comment_delete_success'));
								redirect('notes/aboutNotes/' . $user . '/' . $notesId . '/');
						}
				}
				if (count($arrUserNotes) > 0)
				{
						foreach ($arrUserNotes as $key => $val)
						{
								$notesResultView[$val] = $this->notesModel->_dispNotes($val);
								$notesResultView[$val]['message'] = implode('<br /><br/>', $this->parseMessage($notesResultView[$val]['message'], $notesResultView[$val]['photos']));
						}
						$data['resultcount'] = count($arrUserNotes);
						$data['resultTotal'] = $this->userModel->getAboutNotesCount($user);
						$data['currentPage'] = (trim($this->uri->segment(7)) != '' && is_numeric($this->uri->segment(7))) ? $this->uri->segment(7) : 1;
						$data['totalPages'] = ($data['resultTotal'] > $perPage) ? ceil(($data['resultTotal'] / $perPage)) : 0;
						$data['pageUrl'] = base_url() . 'notes/aboutNotes/' . $user . '/' . $notesId . '/' . $cmt . '/' . $commentId . '/';
				}
				$data['cmt'] = $cmt;
				$data['userId'] = $user;
				$data['avatar'] = $this->userModel->getAvatar($user, true);
				$data['user_name'] = ucwords($this->userModel->getName($user));
				$data['notes_id'] = $notesId;
				$data['notesViewArray'] = $notesResultView;
				$this->smartyextended->view('notes_about', $data);
		}
		function addNotes()
		{
				$this->load->library('validation');
				$this->_notesFrmRules();
				$data = array();
				$arrPictureAlignList = $this->notesModel->notesPhotoAlign();
				//Do the validation
				$fileFlag = true;
				$fileMsg = '';
				if ($_POST) $fileMsg = $this->validateFiles();
				if (trim($fileMsg) != '')
				{
						$fileFlag = false;
				}
				if ($this->validation->run() == false || $fileFlag == false)
				{
						//Oops! validation Error.
						$data['validationError'] = $this->validation->error_string;
						$data['validationError'] .= $fileMsg;
						$data['photoAlignList'] = $arrPictureAlignList;
						$this->smartyextended->view('addnotes', $data);
				}
				else
				{
						//Create the new user
						$newNotesId = $this->notesModel->addNewNotes($_POST);
						if ($newNotesId > 0)
						{
								$msg = $this->storePhotos($newNotesId);
								if (trim($msg) != '') $data['validationError'] = $msg;
								else
								{
										if (isset($_POST['hdnTag']))
										{
												$msg = $this->notesModel->saveTags($newNotesId, $_POST['hdnTag']);
												$this->_sendNotification($_POST['hdnTag'], $newNotesId, 'tag_notification');
										}
										else  $msg = $this->notesModel->saveTags($newNotesId, array());
										if (trim($msg) != '') $data['validationError'] = $this->lang->line('notes_notes_save_fail');
										else  $data['validationError'] = $this->lang->line('notes_notes_save_success');
								}
						}
						else
						{
								$data['validationError'] = $this->lang->line('notes_notes_save_fail');
						}
						redirect("notes/userNotes/");
				}
		}
		function editNotes($notesId)
		{
				$this->load->library('validation');
				$this->_notesFrmRules();
				$data = array();
				$arrPictureAlignList = $this->notesModel->notesPhotoAlign();
				//Do the validation
				$fileFlag = true;
				$fileMsg = '';
				if ($_POST) $fileMsg = $this->validateFiles();
				if (trim($fileMsg) != '')
				{
						$fileFlag = false;
				}
				if (ereg("^[0-9]+$", $notesId))
				{
						$notesData = $this->notesModel->checkExist($notesId);
						if (count($notesData) == 0)
						{
								redirect("notes/");
						}
						else
						{
								$arrPhotos = $this->notesModel->getPhotos($notesId);
								$arrTags = $this->notesModel->getTags($notesId);
						}
				}
				else
				{
						redirect("notes/");
				}
				if ($this->validation->run() == false || $fileFlag == false)
				{
						//Oops! validation Error.
						$tags = '';
						if (count($arrTags) > 0)
								foreach ($arrTags as $key => $valArr)
								{
										$data['userId'] = $valArr['user_id'];
										$data['username'] = $this->userModel->getName($valArr['user_id']);
										$data['avatar'] = $this->userModel->getAvatar($valArr['user_id']);
										$tags .= $this->smartyextended->view('notes_tag_profile', $data, true);
								}
						$data['tags'] = $tags;
						$data['photos'] = $arrPhotos;
						$data['photoCount'] = count($arrPhotos);
						$data['hdnId'] = $notesData[0]['notes_id'];
						$data['txtTitle'] = $notesData[0]['title'];
						$data['txtBody'] = $notesData[0]['message'];
						$data['validationError'] = $this->validation->error_string;
						$data['validationError'] .= $fileMsg;
						$data['photoAlignList'] = $arrPictureAlignList;
						$this->smartyextended->view('editNotes', $data);
				}
				else
				{
						//Create the new user
						$newNotesId = $this->notesModel->updateNotes($_POST);
						if ($newNotesId > 0)
						{
								$msg = $this->storePhotos($newNotesId, 'edit');
								if (trim($msg) != '') $data['validationError'] = $msg;
								else
								{
										if (isset($_POST['hdnTag']))
										{
												$msg = $this->notesModel->saveTags($newNotesId, $_POST['hdnTag']);
												$this->_sendNotification($_POST['hdnTag'], $newNotesId, 'tag_notification');
										}
										else
										{
												$msg = $this->notesModel->saveTags($newNotesId, array());
										}
										if (trim($msg) != '') $data['validationError'] = $this->lang->line('notes_notes_save_fail');
										else  $data['validationError'] = $this->lang->line('notes_notes_save_success');
								}
						}
						else
						{
								$data['validationError'] = $this->lang->line('notes_notes_save_fail');
						}
						redirect("notes/userNotes");
				}
		}
		function deleteNotes($notesId = '')
		{
				if (ereg("^[0-9]+$", $notesId) || trim($notesId) != '')
				{
						$notesData = $this->notesModel->checkExist($notesId);
						if (count($notesData) == 0)
						{
								redirect("notes/userNotes");
						}
						else
						{
								$this->notesModel->deleteNotes($notesId);
								$arrPhotos = $this->notesModel->getPhotos($notesId);
								if (count($arrPhotos) > 0)
								{
										foreach ($arrPhotos as $key => $valArr)
										{
												//$fileName 		= 	trim($notesId)."_".trim($valArr['photo_id']).".".trim($valArr['file_name']);
												$this->deleteFiles(trim($notesId), trim($valArr['photo_id']), trim($valArr['file_name']));
										}
								}
								//$data['validationError'] = "Your Note Deleted Successfully";
								//$this->smartyextended->view('user_notes',$data);
								$this->session->set_flashdata('flash_msg', $this->lang->line('notes_notes_delete_success'));
								redirect("notes/userNotes");
						}
				}
				else
				{
						redirect("notes/userNotes");
				}
		}
		function deleteFiles($notesId, $photoId, $fileExt)
		{
				$fileName = $notesId . '_' . $photoId . '.' . $fileExt;
				$notesPhotoPath = $this->notesPhotoPath;
				$fullPath = $notesPhotoPath . $fileName;
				unlink($fullPath);
				$this->notesModel->delPhotos($notesId, $photoId);
		}
		function removePhoto()
		{
				$notesId = $this->input->post('notes_id');
				$photoId = $this->input->post('photo_id');
				$fileExt = $this->input->post('file_ext');
				if ($notesId != false && $photoId != false && $fileExt != false)
				{
						$this->deleteFiles($notesId, $photoId, $fileExt);
				}
				echo 'done';
		}
		function removeTag()
		{
				$tagId = $this->input->post('tag_id');
				$notesId = $this->input->post('notes_id');
				$data = array();
				if ($tagId != false && $tagId != false && ereg('^[0-9]+$', $tagId) && ereg('^[0-9]+$', $notesId))
				{
						$res = $this->notesModel->removeTag($tagId);
						$resTags = $this->notesModel->getTagInfo($notesId);
						$data['tagDetail'] = $resTags;
						$data['content'] = $this->smartyextended->view('remove_tag', $data, true);
				}
				echo json_encode($data);
		}
		function _notesFrmRules()
		{
				$rules['txtTitle'] = 'trim|required|min_length[5]';
				$rules['txtBody'] = 'required';
				$this->validation->set_rules($rules);
				$fields['txtTitle'] = $this->lang->line('notes_validation_title');
				$fields['txtBody'] = $this->lang->line('notes_validation_body');
				$this->validation->set_fields($fields);
		}
		function validateFiles()
		{
				$intCount = intval($_POST['hdnFile']);
				$msg = "";
				for ($i = 1; $i <= $intCount; $i++)
				{
						if (!isset($_FILES['file' . $i]['error']))
						{
								continue;
						}
						if ($_FILES['file' . $i]['error'] == 0 && $_FILES['file' . $i]['error'] != 4 && trim($_FILES['file' . $i]['name']) != '')
						{
								//if(!($_FILES['file'.$i]['type'] == 'image/jpeg' || $_FILES['file'.$i]['type'] == 'image/pjpeg' || $_FILES['file'.$i]['type'] == 'image/x-png' || $_FILES['file'.$i]['type'] == 'image/gif' || $_FILES['file'.$i]['type'] == 'image/png' || $_FILES['file'.$i]['type'] == 'image/bmp'))
								if (!($_FILES['file' . $i]['type'] == 'image/jpeg' || $_FILES['file' . $i]['type'] == 'image/pjpeg' || $_FILES['file' . $i]['type'] == 'image/x-png' || $_FILES['file' . $i]['type'] == 'image/gif' || $_FILES['file' . $i]['type'] == 'image/png' || $_FILES['file' . $i]['type'] == 'image/bmp'))
								{
										$msg .= $_FILES['file' . $i]['name'] . $this->lang->line('notes_validation_file_msg');
								}
								if (intval($_FILES['file' . $i]['size']) > 4194304)
								{
										$msg .= $_FILES['file' . $i]['name'] . $this->lang->line('notes_validation_file_size');
								}
						}
				}
				if (trim($msg) != '')
				{
						$msg = "<br>" . $msg;
				}
				return $msg;
		}
		function storePhotos($notesId, $action = '')
		{
				$arrPhotoResult = array();
				$msg = '';
				if ($action == 'edit')
				{
						$arrPhotos = $this->notesModel->getPhotos($notesId);
						if (count($arrPhotos) > 0)
						{
								foreach ($arrPhotos as $key => $value)
								{
										//$fileAlign = $_POST['alignEdit'.$key];
										$fileAlign = 'ALIGN1';
										$this->notesModel->updatePhotoAlign($notesId, $key, $fileAlign);
								}
						}
				}
				for ($i = 1; $i <= 5; $i++)
				{
						if (!isset($_FILES['file' . $i]['name']))
						{
								continue;
						}
						$fileName = $_FILES['file' . $i]['name'];
						$error = $_FILES['file' . $i]['error'];
						$size = $_FILES['file' . $i]['size'];
						//$fileAlign	=	$_POST['align'.$i];
						$fileAlign = 'ALIGN1';
						if (trim($fileName) != '' and $error === 0 and $size > 0)
						{
								$arrSplitedName = split("\.", $fileName);
								$extension = trim($arrSplitedName[count($arrSplitedName) - 1]);
								$photoId = $this->notesModel->AddPhotos($notesId, $fileAlign, $extension);
								$newFileName = trim($notesId) . '_' . trim($photoId) . '.' . $extension;
								$extension = $arrSplitedName[count($arrSplitedName) - 1];
								if ($photoId > 0)
								{
										$pathToUpload = $this->notesPhotoPath;
										$fullNamePath = $pathToUpload . $newFileName;
										if (!move_uploaded_file($_FILES['file' . $i]['tmp_name'], $fullNamePath))
										{
												$msg = $this->lang->line('notes_validation_upload_fail') . $fileName . "<br>";
										}
								}
								else
								{
										$msg = $this->lang->line('notes_validation_upload_fail') . $fileName . "<br>";
								}
						} // End of if
				} // End of Loop
				if (trim($msg) != '') $msg = "<br>" . $msg;
				return $msg;
		}
		function _sendNotification($toUserIdArray, $notesId, $action)
		{
				$this->load->model('settingsModel');
				$this->load->model('emailTemplateModel');
				$this->load->library('email');
				$this->load->model('userModel');
				$this->load->model('messageModel');
				// Choosing Email Templates
				if ($action == 'tag_notification')
				{
						$emailTemplate = $this->emailTemplateModel->readEmailTemplate('notes_tag');
				}
				// Choosing Users
				$userIds = implode(',', $toUserIdArray);
				$arrUserdetail = $this->userModel->getDetails($userIds);
				$settings = $this->settingsmodel->readSetting('admin_email, admin_name, site_name, site_title');
				$adminEmail = $settings['admin_email'];
				$adminName = $settings['admin_name'];
				//Set the user activation key
				$notesDetailArray = $this->notesModel->listNotes($notesId);
				//$arrTitle = $this->settingsModel->readSetting('site_title');
				//exit;
				foreach ($arrUserdetail as $key => $valArray)
				{
						//echo $email = $valArray['email'];
						if ($action == 'tag_notification')
						{
								$attachUrl = base_url() . 'notes/userNotes/' . $notesDetailArray['userId'] . '/' . $notesDetailArray['notes_id'] . '/';
								$splVars = array("~~senderName~~" => ucfirst($notesDetailArray['username']), "~~noteTitle~~" => $notesDetailArray['title'], "~~siteName~~" => $settings['site_title'], "~~attachUrl~~" => $attachUrl, "~~adminEmail~~" => $adminEmail, "~~adminName~~" => $adminName);
						}
						$subject = strtr($emailTemplate['template_subject'], $splVars);
						$message = strtr($emailTemplate['template_content'], $splVars);
						$email = $valArray['email'];
						$msgConfig['to_id'] = $valArray['user_id'];
						$msgConfig['subject'] = $subject;
						$msgConfig['message'] = $message;
						$this->messageModel->sendMessage($msgConfig);
						$this->email->from($adminEmail, $adminName);
						$this->email->to($email);
						$this->email->subject($subject);
						$this->email->message(nl2br($message));
						$this->email->send();
				}
		}
		function getToNames()
		{
				$hdnIds = '';
				if (count($_POST) > 1 && trim($_POST['hidden']) != '')
				{
						$hdnIds = trim($this->input->post('hidden'), ',');
				}
				$this->load->model('messageModel');
				$this->load->model('userModel');
				$arrResult = $this->notesModel->getFriendsAddress($this->input->post('q'), $hdnIds);
				foreach ($arrResult as $key => $valArr)
				{
						$data = array();
						$data['avatar'] = $this->userModel->getAvatar($arrResult[$key]['user_id']);
						$data['username'] = $arrResult[$key]['username'];
						$data['userId'] = $arrResult[$key]['user_id'];
						$arrResult[$key]['content'] = $this->smartyextended->view('notes_tag_profile', $data, true);
				}
				echo json_encode($arrResult);
		}
		// Disp message methods Ends Here
}
?>
