<?php
require_once ('../common/config.inc.php');
require_once ('../common/configs/config_encoder.inc.php');
require_once ('../common/configs/config_ans_video.inc.php');
require_once ('../common/configs/config_ans_audio.inc.php');
require_once ('../common/configs/config_ans_photo.inc.php');
$CFG['lang']['include_files'][] = 'admin/includes/languages/%s/manageAnswers.php';
$CFG['lang']['include_files'][] = 'common/email_templates/languages/%s/email_notify.inc.php';
$CFG['html']['header'] = 'admin/includes/languages/%s/html_header.php';
$CFG['html']['footer'] = 'admin/includes/languages/%s/html_footer.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['mods']['include_files'][] = 'common/classes/class_ListRecordsHandler.lib.php';
$CFG['mods']['include_files'][] = 'common/classes/class_AnsVideoUpload.lib.php';
$CFG['mods']['include_files'][] = 'common/classes/class_Image.lib.php';
if ($_POST) $CFG['mods']['include_files'][] = 'common/classes/phpmailer/class_PHPMailer.lib.php';
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class AnswersFormHandler extends VideoUploadLib
{
		private $current_user_id;
		public function ConditionQueryNoSearch()
		{
				$this->sql_condition .= ' q.user_id=u.' . $this->getUserTableField('user_id') . ' ';
		}
		public function ConditionQuery()
		{
				$this->sql_condition = 'q.user_id=u.' . $this->getUserTableField('user_id') . ' ';
				$and = 1;
				if ($this->fields_arr['search_name'])
				{
						if ($this->fields_arr['search_cat'] == 1)
						{
								if ($and == 1) $this->sql_condition .= ' AND ';
								$this->sql_condition .= ' ' . $this->getUserTableField('name') . ' LIKE \'%' . addslashes($this->fields_arr['search_name']) . '%\'';
								$and = 1;
						} elseif ($this->fields_arr['search_cat'] == 2)
						{
								if ($and == 1) $this->sql_condition .= ' AND ';
								$this->sql_condition .= ' ' . $this->getUserTableField('email') . ' like \'%' . addslashes($this->fields_arr['search_name']) . '%\'';
								$and = 1;
						} elseif ($this->fields_arr['search_cat'] == 3)
						{
								if ($and == 1) $this->sql_condition .= ' AND ';
								$this->sql_condition .= ' (status = \'Open\' AND date_closed>=NOW()) AND (tags REGEXP \'[[:<:]]' . addslashes($this->fields_arr['search_name']) . '[[:>:]]\' OR question REGEXP \'[[:<:]]' . addslashes($this->fields_arr['search_name']) . '[[:>:]]\' OR ' . $this->getUserTableField('name') . ' LIKE \'%' . addslashes($this->fields_arr['search_name']) . '%\')';
								$and = 1;
						} elseif ($this->fields_arr['search_cat'] == 4)
						{
								if ($and == 1) $this->sql_condition .= ' AND ';
								$this->sql_condition .= ' (q.status = \'Resolved\' OR q.date_closed<NOW()) AND (tags REGEXP \'[[:<:]]' . addslashes($this->fields_arr['search_name']) . '[[:>:]]\' OR question REGEXP \'[[:<:]]' . addslashes($this->fields_arr['search_name']) . '[[:>:]]\' OR ' . $this->getUserTableField('name') . ' LIKE \'%' . addslashes($this->fields_arr['search_name']) . '%\')';
								$and = 1;
						} elseif ($this->fields_arr['search_cat'] == 5)
						{
								if ($and == 1) $this->sql_condition .= ' AND ';
								$this->sql_condition .= ' status = \'Blocked\' AND (tags REGEXP \'[[:<:]]' . addslashes($this->fields_arr['search_name']) . '[[:>:]]\' OR question REGEXP \'[[:<:]]' . addslashes($this->fields_arr['search_name']) . '[[:>:]]\' OR ' . $this->getUserTableField('name') . ' LIKE \'%' . addslashes($this->fields_arr['search_name']) . '%\')';
								$and = 1;
						} elseif ($this->fields_arr['search_cat'] == 6)
						{
								if ($and == 1) $this->sql_condition .= ' AND ';
								$this->sql_condition .= ' question REGEXP \'[[:<:]]' . addslashes($this->fields_arr['search_name']) . '[[:>:]]\'';
								$and = 1;
						} elseif ($this->fields_arr['search_cat'] == 7)
						{
								if ($and == 1) $this->sql_condition .= ' AND ';
								$this->sql_condition .= ' tags REGEXP \'[[:<:]]' . addslashes($this->fields_arr['search_name']) . '[[:>:]]\'';
								$and = 1;
						} elseif ($this->fields_arr['search_cat'] == 8)
						{
								if ($and == 1) $this->sql_condition .= ' AND ';
								$this->sql_condition .= ' cat_id IN (SELECT cat_id FROM ' . $this->CFG['db']['tbl']['questions_category'] . ' WHERE cat_name LIKE \'%' . addslashes($this->fields_arr['search_name']) . '%\')';
								$and = 1;
						} elseif ($this->fields_arr['search_cat'] == 9)
						{
								if ($and == 1) $this->sql_condition .= ' AND ';
								$this->sql_condition .= ' video_id!=0 AND (tags REGEXP \'[[:<:]]' . addslashes($this->fields_arr['search_name']) . '[[:>:]]\' OR question REGEXP \'[[:<:]]' . addslashes($this->fields_arr['search_name']) . '[[:>:]]\' OR ' . $this->getUserTableField('name') . ' LIKE \'%' . addslashes($this->fields_arr['search_name']) . '%\')';
								$and = 1;
						} elseif ($this->fields_arr['search_cat'] == 10)
						{
								if ($and == 1) $this->sql_condition .= ' AND ';
								$this->sql_condition .= ' audio_id!=0 AND (tags REGEXP \'[[:<:]]' . addslashes($this->fields_arr['search_name']) . '[[:>:]]\' OR question REGEXP \'[[:<:]]' . addslashes($this->fields_arr['search_name']) . '[[:>:]]\' OR ' . $this->getUserTableField('name') . ' LIKE \'%' . addslashes($this->fields_arr['search_name']) . '%\')';
								$and = 1;
						}
				} elseif ($this->fields_arr['search_cat'] == 3)
				{
						if ($and == 1) $this->sql_condition .= ' AND ';
						$this->sql_condition .= ' (q.status = \'Open\' AND q.date_closed>=NOW())';
						$and = 1;
				} elseif ($this->fields_arr['search_cat'] == 4)
				{
						if ($and == 1) $this->sql_condition .= ' AND ';
						$this->sql_condition .= ' (q.status = \'Resolved\' OR q.date_closed<NOW())';
						$and = 1;
				} elseif ($this->fields_arr['search_cat'] == 5)
				{
						if ($and == 1) $this->sql_condition .= ' AND ';
						$this->sql_condition .= ' status = \'Blocked\'';
						$and = 1;
				} elseif ($this->fields_arr['search_cat'] == 9)
				{
						if ($and == 1) $this->sql_condition .= ' AND ';
						$this->sql_condition .= ' video_id!=0';
						$and = 1;
				} elseif ($this->fields_arr['search_cat'] == 10)
				{
						if ($and == 1) $this->sql_condition .= ' AND ';
						$this->sql_condition .= ' audio_id!=0';
						$and = 1;
				}
		}
		public function buildSortQuery()
		{
				$this->sql_sort = $this->fields_arr['orderby_field'] . ' ' . $this->fields_arr['orderby'];
		}
		public function common_hidden($hidden_field = array())
		{
				foreach ($hidden_field as $hidden_name)
				{
?>

<input type="hidden" name="ques_ids[]" value="<?php echo $hidden_name; ?>" />
<?php
				}
		}
		public function chkIsValidQuestion()
		{
				$this->chkIsNotEmpty('qid', $this->LANG['member_err_tip_compulsory']);
				if (!$this->isValidFormInputs())
				{
						$this->setCommonErrorMsg($this->LANG['questions_err_invalid_question']);
						return false;
				}
				$sql = 'SELECT q.ques_id, q.total_answer, q.cat_id, q.pcat_id, q.tags, q.best_ans_id, q.description, q.total_stars, q.question, TIMEDIFF(NOW(), date_asked) as date_asked' . ', ' . $this->getUserTableField('name') . ' as asked_by, ' . $this->getUserTableFields(array('image_path', 'gender'), false) . 'q.status, q.user_id' . ', video_id, audio_id, IF(status=\'Open\' AND date_closed>=NOW(), 1, 0) is_open, TIMEDIFF(date_closed, NOW()) as date_closed' . ', q.total_videos, q.total_audios FROM ' . $this->CFG['db']['tbl']['questions'] . ' AS q' . ', ' . $this->CFG['db']['tbl']['users'] . ' AS u' . ' WHERE q.user_id=u.' . $this->getUserTableField('user_id') . ' AND q.status IN (\'Open\', \'Resolved\')' . ' AND u.' . $this->getUserTableField('usr_status') . '=\'Ok\' AND q.ques_id=' . $this->dbObj->Param('qid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['qid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if (!$rs->PO_RecordCount())
				{
						$this->setCommonErrorMsg($this->LANG['questions_err_invalid_question']);
						return false;
				}
				$this->question_details = $rs->FetchRow();
				return true;
		}
		public function setCategoryFormField()
		{
				$cat_id = $this->question_details['pcat_id'];
				if ($this->question_details['cat_id'] > 0) $cat_id = $this->question_details['cat_id'];
				$sql = 'SELECT cat_id, parent_id FROM ' . $this->CFG['db']['tbl']['questions_category'] . ' WHERE cat_id=' . $this->dbObj->Param('cat_id');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($cat_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount())
				{
						$row = $rs->FetchRow();
						$this->fields_arr['category'] = $row['cat_id'];
						if ($row['parent_id'])
						{
								$this->fields_arr['category'] = $row['parent_id'];
								$this->fields_arr['sub_category'] = $row['cat_id'];
						}
				}
		}
		public function populateCategories($cid)
		{
				$sql = 'SELECT cat_id, cat_name FROM ' . $this->CFG['db']['tbl']['questions_category'] . ' WHERE parent_id=0 AND status=\'1\' ORDER BY cat_name';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount())
				{
						while ($row = $rs->FetchRow())
						{
?>
							<option value="<?php echo $row['cat_id']; ?>" <?php echo ($row['cat_id'] == $cid) ? 'selected' : ''; ?>><?php echo $row['cat_name']; ?></option>
							<?php
						}
				}
		}
		public function populateSubCategories($cid, $scid)
		{
				if (!$cid) return;
				$sql = 'SELECT cat_id, cat_name FROM ' . $this->CFG['db']['tbl']['questions_category'] . ' WHERE parent_id=' . $this->dbObj->Param('cid') . ' AND status=\'1\' ORDER BY cat_name';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($cid));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount())
				{
						while ($row = $rs->FetchRow())
						{
?>
							<option value="<?php echo $row['cat_id']; ?>" <?php echo ($row['cat_id'] == $scid) ? 'selected' : ''; ?>><?php echo $row['cat_name']; ?></option>
							<?php
						}
				}
		}
		public function chkIsQuestionExists($field, $err_tip = '')
		{
				$sql = 'SELECT ques_id FROM ' . $this->CFG['db']['tbl']['questions'] . ' WHERE question LIKE ' . $this->dbObj->Param('question');
				if ($this->fields_arr['qid']) $sql .= ' AND ques_id != \'' . addslashes($this->fields_arr['qid']) . '\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr[$field]));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if (!$rs->PO_RecordCount()) return true;
				$this->setCommonErrorMsg($err_tip);
				return false;
		}
		public function updateQuestion()
		{
				$this->updateCategoryQuestionCount($this->question_details['pcat_id']);
				if ($this->question_details['cat_id']) $this->updateCategoryQuestionCount($this->question_details['cat_id']);
				$pcat_id = $this->fields_arr['category'];
				if ($this->fields_arr['sub_category']) $cat_id = $this->fields_arr['sub_category'];
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['questions'] . ' SET question=' . $this->dbObj->Param('question') . ', description=' . $this->dbObj->Param('description') . ', tags=' . $this->dbObj->Param('tags') . ', pcat_id=' . $this->dbObj->Param('pcat_id') . ', cat_id=' . $this->dbObj->Param('cat_id') . ', video_id=' . $this->dbObj->Param('video_id') . ', audio_id=' . $this->dbObj->Param('audio_id') . ' WHERE ques_id=' . $this->dbObj->Param('qid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['question'], $this->fields_arr['description'], $this->fields_arr['tags'], $this->fields_arr['category'], $this->fields_arr['sub_category'], $this->fields_arr['video_id'], $this->fields_arr['audio_id'], $this->fields_arr['qid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$this->increaseCategoryQuestionCount($this->fields_arr['category']);
				if ($this->fields_arr['sub_category']) $this->increaseCategoryQuestionCount($this->fields_arr['sub_category']);
				if ($this->fields_arr['video'] or ($this->fields_arr['video_id'] == 0))
				{
						$sql = 'UPDATE ' . $this->CFG['db']['tbl']['ans_video'] . ' SET' . ' video_status=\'Deleted\' WHERE' . ' content_id=' . $this->dbObj->Param('content_id') . ' AND' . ' video_for=\'Question\'';
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['qid']));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
						$this->fields_arr['content_id'] = $this->fields_arr['qid'];
						if ($this->fields_arr['video']) $this->addNewVideo();
				}
				if ($this->fields_arr['audio'] or ($this->fields_arr['audio_id'] == 0))
				{
						$sql = 'UPDATE ' . $this->CFG['db']['tbl']['ans_audio'] . ' SET' . ' audio_status=\'Deleted\' WHERE' . ' content_id=' . $this->dbObj->Param('content_id') . ' AND' . ' audio_for=\'Question\'';
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['qid']));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
						$this->fields_arr['content_id'] = $this->fields_arr['qid'];
						if ($this->fields_arr['audio']) $this->addNewAudio();
				}
		}
		public function addNewVideo()
		{
				if ($this->fields_arr['video'])
				{
						$this->fields_arr['video_id'] = $this->insertAnsVideoTable();
						if ($this->fp)
						{
								$log_str = 'Video Record created : ' . $this->fields_arr['video_id'] . "\r\n";
								$this->writetoTempFile($log_str);
						}
						$video_name = getImageName($this->fields_arr['video_id']);
						$temp_dir = '../' . $this->CFG['admin']['ans_videos']['temp_folder'];
						$this->chkAndCreateFolder($temp_dir);
						$temp_file = $temp_dir . $video_name . '.flv';
						$file_name = $this->CFG['admin']['video']['red5_flv_path'] . $this->fields_arr['rid'] . '.flv';
						copy($file_name, $temp_file);
						unlink($file_name);
						if ($this->fp)
						{
								$log_str = 'Video stored in temp server : ' . $temp_file . "\r\n";
								$this->writetoTempFile($log_str);
						}
						$this->changeAnsVideoStatus($this->fields_arr['video_id'], 'No');
						if ($this->CFG['admin']['ans_videos']['video_auto_encode'])
						{
								if ($this->fp)
								{
										$log_str = 'Calling Video Encode \r\n';
										$this->writetoTempFile($log_str);
								}
								$this->videoEncode($this->fields_arr['video_id']);
						}
						$temp_dir = '../' . $this->CFG['admin']['ans_videos']['temp_folder'];
						$temp_file = $temp_dir . $this->fields_arr['rid'] . '.flv';
						if (file_exists($temp_file)) unlink($temp_file);
				}
		}
		public function addNewAudio()
		{
				if ($this->fields_arr['audio'])
				{
						$this->fields_arr['audio_id'] = $this->insertAnsAudioTable();
						if ($this->fp)
						{
								$log_str = 'Audio Record created : ' . $this->fields_arr['audio_id'] . "\r\n";
								$this->writetoTempFile($log_str);
						}
						$audio_name = getImageName($this->fields_arr['audio_id']);
						$temp_dir = '../' . $this->CFG['admin']['ans_audios']['temp_folder'];
						$this->chkAndCreateFolder($temp_dir);
						$temp_file = $temp_dir . $audio_name . '.flv';
						$file_name = $this->CFG['admin']['video']['red5_flv_path'] . $this->fields_arr['rid'] . 'AUD.flv';
						copy($file_name, $temp_file);
						unlink($file_name);
						if ($this->fp)
						{
								$log_str = 'Audio stored in temp server : ' . $temp_file . "\r\n";
								$this->writetoTempFile($log_str);
						}
						$this->changeAnsAudioStatus($this->fields_arr['audio_id'], 'No');
						if ($this->CFG['admin']['ans_audios']['audio_auto_encode'])
						{
								if ($this->fp)
								{
										$log_str = 'Calling Audio Encode \r\n';
										$this->writetoTempFile($log_str);
								}
								$this->audioEncode($this->fields_arr['audio_id']);
						}
						$temp_dir = '../' . $this->CFG['admin']['ans_audios']['temp_folder'];
						$temp_file = $temp_dir . $this->fields_arr['rid'] . 'AUD.flv';
						if (file_exists($temp_file)) unlink($temp_file);
				}
		}
		public function insertAnsVideoTable()
		{
				$sql = 'INSERT INTO ' . $this->CFG['db']['tbl']['ans_video'] . ' SET' . ' content_id=' . $this->dbObj->Param('content_id') . ',' . ' user_id=' . $this->dbObj->Param('user_id') . ',' . ' video_for=\'Question\',' . ' video_ext=\'flv\',' . ' date_added=NOW(),' . ' video_encoded_status=\'Partial\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['content_id'], $this->CFG['user']['user_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return $this->dbObj->Insert_ID();
		}
		public function insertAnsAudioTable()
		{
				$sql = 'INSERT INTO ' . $this->CFG['db']['tbl']['ans_audio'] . ' SET' . ' content_id=' . $this->dbObj->Param('content_id') . ',' . ' user_id=' . $this->dbObj->Param('user_id') . ',' . ' audio_for=\'Question\',' . ' audio_ext=\'flv\',' . ' date_added=NOW(),' . ' audio_encoded_status=\'Partial\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['content_id'], $this->CFG['user']['user_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return $this->dbObj->Insert_ID();
		}
		public function changeAnsVideoStatus($video_id, $status)
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['ans_video'] . ' SET' . ' video_encoded_status=' . $this->dbObj->Param('video_encoded_status') . ' WHERE video_id=' . $this->dbObj->Param('video_id');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($status, $video_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function changeAnsAudioStatus($audio_id, $status)
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['ans_audio'] . ' SET' . ' audio_encoded_status=' . $this->dbObj->Param('audio_encoded_status') . ' WHERE audio_id=' . $this->dbObj->Param('audio_id');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($status, $audio_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function updateStatus($table_name, $status)
		{
				if (!$this->fields_arr['ques_ids']) return;
				$id = $this->fields_arr['ques_ids'];
				$date_closed = '';
				if ($status == 'Open') $date_closed = ', date_closed = DATE_ADD(NOW(), INTERVAL ' . $this->CFG['admin']['question']['open_days'] . ' DAY)';
				elseif ($status == 'Resolved') $date_closed = ', date_closed = NOW()';
				$sql = 'UPDATE ' . $table_name . ' SET status=' . $this->dbObj->Param($status) . $date_closed . ' WHERE ques_id IN (' . $id . ')';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($status));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function increaseCategoryQuestionCount($cat_id)
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['questions_category'] . ' SET total_questions=total_questions+1' . ' WHERE cat_id=' . $this->dbObj->Param($cat_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($cat_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function deleteQuestions($table_name, $answers_table, $users_ans_log_table)
		{
				if (!$this->fields_arr['ques_ids']) return;
				$id = $this->fields_arr['ques_ids'];
				$sql = 'SELECT user_id, video_id, audio_id, pcat_id, cat_id FROM ' . $table_name . ' WHERE ques_id IN (' . $id . ')';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount())
				{
						while ($row = $rs->FetchRow())
						{
								$sql = 'UPDATE ' . $users_ans_log_table . ' SET total_ques=total_ques-1,' . ' total_points=total_points-' . $this->CFG['admin']['ask_answers']['points'] . ' WHERE user_id=' . $this->dbObj->Param('uid');
								$stmt = $this->dbObj->Prepare($sql);
								$rs_user_log = $this->dbObj->Execute($stmt, array($row['user_id']));
								if (!$rs_user_log) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
								$this->updateQuestionVideoStatus($row['video_id']);
								$this->updateQuestionAudioStatus($row['audio_id']);
								$this->updateCategoryQuestionCount($row['pcat_id']);
								if ($row['cat_id']) $this->updateCategoryQuestionCount($row['cat_id']);
						}
				}
				$sql = 'DELETE FROM ' . $table_name . ' WHERE ques_id IN (' . $id . ')';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$sql = 'SELECT user_id, video_id, audio_id FROM ' . $answers_table . ' WHERE ques_id IN (' . $id . ')';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount())
				{
						while ($row = $rs->FetchRow())
						{
								$sql = 'UPDATE ' . $users_ans_log_table . ' SET total_ans=total_ans-1' . ' WHERE user_id=' . $this->dbObj->Param('uid');
								$stmt = $this->dbObj->Prepare($sql);
								$rs_user_log = $this->dbObj->Execute($stmt, array($row['user_id']));
								if (!$rs_user_log) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
								$this->updateAnswerVideoStatus($row['video_id']);
								$this->updateAnswerAudioStatus($row['audio_id']);
						}
				}
				$sql = 'DELETE FROM ' . $answers_table . ' WHERE ques_id IN (' . $id . ')';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function updateCategoryQuestionCount($cat_id)
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['questions_category'] . ' SET total_questions=total_questions-1' . ' WHERE cat_id=' . $this->dbObj->Param($cat_id) . ' AND total_questions>0';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($cat_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function updateQuestionVideoStatus($video_id)
		{
				if (!$video_id) return;
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['ans_video'] . ' SET video_status=\'Deleted\'' . ' WHERE video_id=' . $this->dbObj->Param($video_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($video_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function updateQuestionAudioStatus($audio_id)
		{
				if (!$audio_id) return;
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['ans_audio'] . ' SET audio_status=\'Deleted\'' . ' WHERE audio_id=' . $this->dbObj->Param($audio_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($audio_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function updateAnswerVideoStatus($video_id)
		{
				if (!$video_id) return;
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['ans_video'] . ' SET video_status=\'Deleted\'' . ' WHERE video_id=' . $this->dbObj->Param($video_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($video_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function updateAnswerAudioStatus($audio_id)
		{
				if (!$audio_id) return;
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['ans_audio'] . ' SET audio_status=\'Deleted\'' . ' WHERE audio_id=' . $this->dbObj->Param($audio_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($audio_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function abuseQuestions()
		{
				if (!$this->fields_arr['ques_ids']) return;
				$id = '';
				$eques_id = explode(',', $this->fields_arr['ques_ids']);
				foreach ($eques_id as $ques_id)
				{
						$id .= '\'' . $ques_id . '\',';
						$this->updateAbuseQuestion($ques_id);
				}
				$id = substr($id, 0, strrpos($id, ','));
		}
		public function updateAbuseQuestion($ques_id)
		{
				$sql = 'SELECT abuse_id FROM ' . $this->CFG['db']['tbl']['abuse_questions'] . ' WHERE ques_id=' . $this->dbObj->Param('qid') . ' AND reported_by=' . $this->dbObj->Param('rid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($ques_id, $this->CFG['user']['user_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if (!$rs->PO_RecordCount())
				{
						$sql = 'INSERT INTO ' . $this->CFG['db']['tbl']['abuse_questions'] . ' SET ques_id=' . $this->dbObj->Param('qid') . ', reported_by=' . $this->dbObj->Param('rid') . ', date_abused=NOW()';
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($ques_id, $this->CFG['user']['user_id']));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
						if ($this->dbObj->Affected_Rows())
						{
								$this->updateQuestionAbuseCount($ques_id);
								$this->getQuestionDetails($ques_id);
								$this->updateAbuseUserPoints($this->CFG['admin']['abuse_questions_points']['allowed'], $this->question_details['user_id'], $this->CFG['admin']['abuse_questions']['points']);
								$this->sendAbuseMailToAsker($ques_id);
						}
				}
		}
		public function updateQuestionAbuseCount($ques_id)
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['questions'] . ' SET abuse_count=abuse_count+1' . ' WHERE ques_id=' . $this->dbObj->Param('qid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($ques_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function getQuestionDetails($ques_id = 0)
		{
				$sql = 'SELECT user_id, question FROM ' . $this->CFG['db']['tbl']['questions'] . ' WHERE ques_id=' . $this->dbObj->Param('qid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($ques_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$this->question_details = $rs->FetchRow();
		}
		public function updateAbuseUserPoints($config_abuse, $uid, $points)
		{
				if (!$config_abuse or $points == 0 or !isset($this->CFG['user']['user_id']) or empty($this->CFG['user']['user_id'])) return;
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['users_ans_log'] . ' SET total_points=total_points+' . $points . ', date_updated=NOW()' . ' WHERE user_id=' . $this->dbObj->Param('uid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($uid));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return;
		}
		public function sendAbuseMailToAsker($ques_id)
		{
				$email_options = $this->getEmailOptionsOfUser($this->question_details['user_id']);
				if ($email_options['abuse_mail'] == 'Yes')
				{
						$asker_details = $this->getUserDetailsFromUsersTable($this->CFG['db']['tbl']['users'], $this->question_details['user_id']);
						$abuse_question_subject = str_replace('{username}', $asker_details['name'], $this->LANG['abuse_question_email_subject']);
						$receiver_url = getUrl($this->CFG['site']['url'] . 'myanswers.php?uid=' . $this->question_details['user_id'], $this->CFG['site']['url'] . 'my/answers/' . $this->question_details['user_id'], false);
						$abuse_question_content = str_replace('{username}', '<a href="' . $receiver_url . '">' . $asker_details['name'] . '</a>', $this->LANG['abuse_question_email_content']);
						$sender_url = getUrl($this->CFG['site']['url'] . 'myanswers.php?uid=' . $this->CFG['user']['user_id'], $this->CFG['site']['url'] . 'my/answers/' . $this->CFG['user']['user_id'] . '/', false);
						$sender_name = '<a href="' . $sender_url . '">' . $this->CFG['user']['name'] . '</a>';
						$abuse_question_content = str_replace('{sender name}', $sender_name, $abuse_question_content);
						$abuse_question_content = str_replace('{sitename}', $this->CFG['site']['name'], $abuse_question_content);
						$abuse_question_content = str_replace('{question asked}', '<strong>' . $this->question_details['question'] . '</strong>', $abuse_question_content);
						$question_link = getUrl($this->CFG['site']['url'] . 'answer.php?qid=' . $ques_id . '/', $this->CFG['site']['url'] . 'view/answers/' . $ques_id . '/', false);
						$abuse_question_content = str_replace('{link}', '<a href="' . $question_link . '">' . $question_link . '</a>', $abuse_question_content);
						$this->_sendMail($asker_details['email'], $abuse_question_subject, nl2br($abuse_question_content), $this->CFG['site']['noreply_name'], $this->CFG['site']['noreply_email']);
				}
		}
		private function _sendMail($to_email, $subject, $body, $sender_name, $sender_email)
		{
				$mail = new PHPMailer();
				$mail->AddAddress($to_email);
				$mail->FromName = $sender_name;
				$mail->From = $mail->Sender = $sender_email;
				$mail->Subject = $subject;
				$mail->Body = $body;
				$mail->IsMail();
				$mail->IsHTML(true);
				return ($mail->Send());
		}
		public function getCategoryName($pcat_id, $scat_id)
		{
				$cat_id = $pcat_id;
				if ($scat_id > 0) $cat_id = $scat_id;
				$sql = 'SELECT cat_name FROM ' . $this->CFG['db']['tbl']['questions_category'] . ' WHERE cat_id=' . $this->dbObj->Param('cid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($cat_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = array('cat_name' => '');
				if ($rs->PO_RecordCount()) $row = $rs->FetchRow();
				return $row['cat_name'];
		}
		public function deleteQuestionVideo()
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['ans_video'] . ' SET' . ' video_status=\'Deleted\' WHERE content_id=' . $this->dbObj->Param('content_id') . ' AND' . ' video_for=\'Question\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['qid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['questions'] . ' SET' . ' video_id=\'0\' WHERE video_id=' . $this->dbObj->Param('video_id');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['qid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function deleteQuestionAudio()
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['ans_audio'] . ' SET' . ' audio_status=\'Deleted\' WHERE content_id=' . $this->dbObj->Param('content_id') . ' AND' . ' audio_for=\'Question\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['qid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['questions'] . ' SET' . ' audio_id=\'0\' WHERE audio_id=' . $this->dbObj->Param('audio_id');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['qid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function populateSearchOptions($highlight_search)
		{
				foreach ($this->search_options as $key => $value)
				{
						$selected = ($highlight_search == $key) ? 'SELECTED' : '';
?>
<option value="<?php echo $key; ?>" <?php echo $selected; ?>><?php echo $value; ?></option>
<?php
				}
		}
		public function generateRandomId()
		{
				$time = time();
				$this->fields_arr['rid'] = md5($time);
		}
		public function chkIsValidCaptureVideoFile()
		{
				$file_name = $this->CFG['admin']['video']['red5_flv_path'] . $this->fields_arr['rid'] . '.flv';
				if ($this->fields_arr['video'] == $this->fields_arr['rid'])
				{
						if (is_file($file_name))
						{
								return true;
						}
						$this->fields_arr['video'] = '';
						return false;
				}
				if (is_file($file_name)) unlink($file_name);
		}
		public function chkIsValidCaptureAudioFile()
		{
				$file_name = $this->CFG['admin']['video']['red5_flv_path'] . $this->fields_arr['rid'] . 'AUD.flv';
				if ($this->fields_arr['audio'] == $this->fields_arr['rid'])
				{
						if (is_file($file_name))
						{
								return true;
						}
						$this->fields_arr['audio'] = '';
						return false;
				}
				if (is_file($file_name)) unlink($file_name);
		}
		public function getVideoAudioCount($qid)
		{
				$sql = 'SELECT ans_id, video_id, audio_id FROM ' . $this->CFG['db']['tbl']['answers'] . ' WHERE ques_id=' . $qid . ' AND (video_id != 0 OR audio_id <> 0)';
				echo $sql;
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount())
				{
						return true;
				}
		}
		public function printQuery()
		{
				print 'Query:<br>' . $this->sql;
		}
}
$questions = new AnswersFormHandler();
$questions->setDBObject($db);
$questions->setCfgLangGlobal($CFG, $LANG);
$questions->setLang(array('sort_ascending' => $LANG['list_sort_ascending'], 'sort_descending' => $LANG['list_sort_descending']));
$questions->setPageBlockNames(array('list_records', 'msg_no_records', 'msg_form_success', 'form_edit', 'page_nav', 'show_form_search', 'show_form_confirm', 'msg_form_error'));
$questions->setAllPageBlocksHide();
$questions->setColumnSortUrl($_SERVER['PHP_SELF']);
$questions->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$questions->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$questions->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$questions->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$questions->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$questions->setCSSColumnHeaderCellAscSortClasses(array('clsColumnHeaderCellAscSort1', 'clsColumnHeaderCellAscSort2', 'clsColumnHeaderCellAscSort3', 'clsColumnHeaderCellAscSort4', 'clsColumnHeaderCellAscSort5'));
$questions->setCSSColumnHeaderCellDefaultClass('clsColumnHeaderCellDefault');
$questions->setCSSColumnHeaderCellDescSortClasses(array('clsColumnHeaderCellDscSort1', 'clsColumnHeaderCellDscSort2', 'clsColumnHeaderCellDscSort3', 'clsColumnHeaderCellDscSort4', 'clsColumnHeaderCellDscSort5'));
$questions->setCSSAlternativeRowClasses(array('clsTblRow1', 'clsTblRow2', 'clsTblRow3'));
$questions->setSearchFormFieldNames('start', 'numpg', 'dsc', 'asc');
$questions->setFormField('search_name', '');
$questions->setFormField('search_cat', '');
$questions->setFormField('action', '');
$questions->setFormField('qid', '');
$questions->setFormField('f', '');
$questions->setFormField('question', '');
$questions->setFormField('description', '');
$questions->setFormField('category', '');
$questions->setFormField('sub_category', '');
$questions->setFormField('video', '');
$questions->setFormField('audio', '');
$questions->setFormField('video_id', '');
$questions->setFormField('audio_id', '');
$questions->setFormField('rid', '');
$questions->setFormField('sort', 'date');
$questions->setFormField('order', '');
$questions->setFormField('uname', '');
$questions->setFormField('tags', '');
$questions->setFormField('with', '');
$questions->setFormField('type', '');
$questions->setFormField('more_questions', '');
$questions->setFormField('tags', '');
$questions->setFormField('ques_ids', array());
$questions->setFormField('asc', '');
$questions->setFormField('dsc', '');
$questions->setFormField('start', 0);
$questions->setFormField('act', '');
$questions->setFormField('numpg', $CFG['data_tbl']['numpg']);
$questions->setMinRecordSelectLimit($CFG['data_tbl']['min_record_select_limit']);
$questions->setMaxRecordSelectLimit($CFG['data_tbl']['max_record_select_limit']);
$questions->setNumPerPageListArr($CFG['data_tbl']['numperpage_list_arr']);
$questions->member_url = $CFG['site']['relative_url'] . $CFG['redirect']['member'] . '/';
$questions->setTableNames(array($CFG['db']['tbl']['questions'] . ' as q', $CFG['db']['tbl']['users'] . ' as u'));
$questions->setReturnColumns(array('ques_id', 'q.user_id', 'q.video_id', 'q.audio_id', 'q.pcat_id', 'q.cat_id', 'q.abuse_count', 'q.tags', 'q.total_answer', $questions->getUserTableFields(array('name')), 'question', 'total_stars', 'TIMEDIFF(NOW(), date_asked) as date_asked', 'TIMEDIFF(date_closed, NOW()) as date_closed', 'CASE when status=\'Open\' AND date_closed>=NOW() then \'Open\' when status=\'Blocked\' then \'Blocked\' ELSE \'Resolved\' END status', 'video_id', 'audio_id', 'total_videos', 'total_audios'));
$questions->setFormField('orderby_field', 'ques_id');
$questions->setFormField('orderby', 'DESC');
$questions->search_options = array(1 => 'Username', 2 => 'email', 3 => 'Open questions', 4 => 'Resolved questions', 5 => 'Blocked questions', 6 => 'Questions', 7 => 'Tags', 8 => 'Categories', 9 => 'Video questions', 10 => 'Audio questions');
$questions->sanitizeFormInputs($_REQUEST);
if ($questions->getFormField('f')) $questions->setFormField('f', 'v');
if (!$questions->getFormField('rid')) $questions->generateRandomId();
$questions->buildSelectQuery();
if ($questions->isFormGETed($_GET, 'delmsg'))
{
		$questions->setPageBlockShow('msg_form_success');
		$questions->setCommonErrorMsg($LANG['question_deleted_succesfully']);
}
if ($questions->isFormPOSTed($_POST, 'todo'))
{
		$questions->setAllPageBlocksHide();
		$num_selected = count($questions->getFormField('ques_ids'));
		if ($num_selected > 0)
		{
				$questions->setPageBlockShow('show_form_confirm');
				$questions->ConditionQuery();
		}
} elseif ($questions->isFormPOSTed($_POST, 'action') and $questions->getFormField('ques_ids'))
{
		if ($questions->getFormField('action') == 'block_question') $questions->updateStatus($CFG['db']['tbl']['questions'], 'Blocked');
		elseif ($questions->getFormField('action') == 'open_question') $questions->updateStatus($CFG['db']['tbl']['questions'], 'Open');
		elseif ($questions->getFormField('action') == 'resolve_question') $questions->updateStatus($CFG['db']['tbl']['questions'], 'Resolved');
		elseif ($questions->getFormField('action') == 'delete_question') $questions->deleteQuestions($CFG['db']['tbl']['questions'], $CFG['db']['tbl']['answers'], $CFG['db']['tbl']['users_ans_log']);
		elseif ($questions->getFormField('action') == 'abuse_question') $questions->abuseQuestions();
		$questions->ConditionQuery();
		$questions->setCommonErrorMsg($LANG['question_status_updated_succesfully']);
		$questions->setPageBlockShow('msg_form_success');
} elseif ($questions->isFormPOSTed($_POST, 'go') || $questions->isFormPOSTed($_GET, 'search_cat'))
{
		$questions->ConditionQuery();
} elseif (($questions->isFormPOSTed($_POST, 'dcancel')) or ($questions->isFormGETed($_GET, 'change')))
{
		$questions->ConditionQuery();
} elseif (($questions->isFormPOSTed($_POST, 'submit')))
{
		$questions->chkIsValidQuestion();
		$questions->chkIsNotEmpty('question', $LANG['member_err_tip_compulsory']) and $questions->chkIsQuestionExists('question', $LANG['questions_err_exists_already']);
		if ($CFG['admin']['category']['mandatory']) $questions->chkIsNotEmpty('category', $LANG['questions_err_tip_compulsory']);
		if ($CFG['admin']['description']['mandatory']) $questions->chkIsNotEmpty('description', $LANG['questions_err_tip_compulsory']);
		$questions->chkIsValidCaptureVideoFile();
		$questions->chkIsValidCaptureAudioFile();
		if ($questions->isValidFormInputs())
		{
				if ($CFG['debug']['store_log'])
				{
						$questions->createErrorLogFile('question');
				}
				$questions->updateQuestion();
				if ($CFG['debug']['store_log'])
				{
						$questions->closeErrorLogFile();
				}
				if ($questions->getFormField('f') == 'v') Redirect2URL($CFG['site']['relative_url'] . 'viewAnswers.php?qid=' . $questions->getFormField('qid') . '&msg=4');
				Redirect2URL($CFG['site']['relative_url'] . 'manageAnswers.php?msg=1');
		}
		else
		{
				$questions->setPageBlockShow('msg_form_error');
				$questions->setPageBlockShow('form_edit');
		}
		$questions->ConditionQuery();
} elseif (($questions->isFormGETed($_GET, 'qid') and $questions->chkIsValidQuestion()))
{
		$questions->setPageBlockShow('form_edit');
		$questions->setFormField('question', $questions->question_details['question']);
		$questions->setFormField('description', $questions->question_details['description']);
		$questions->setCategoryFormField();
		$questions->setFormField('video_id', $questions->question_details['video_id']);
		$questions->setFormField('audio_id', $questions->question_details['audio_id']);
		$questions->setFormField('tags', $questions->question_details['tags']);
		$questions->ConditionQuery();
}
else  $questions->ConditionQueryNoSearch();
if ($questions->isFormGETed($_GET, 'msg'))
{
		$questions->setPageBlockShow('msg_form_success');
		$questions->setCommonErrorMsg($LANG['question_updated_succesfully']);
}
if ($questions->isFormPOSTed($_POST, 'act'))
{
		switch ($questions->getFormField('act'))
		{
				case 'deletevideo':
						$questions->deleteQuestionVideo();
						break;
				case 'deleteaudio':
						$questions->deleteQuestionAudio();
						break;
		}
}
$questions->buildSortQuery();
$questions->buildQuery();
$questions->executeQuery();
$questions->setPageBlockShow('list_records');
if (!$questions->isResultsFound()) $questions->setPageBlockShow('msg_no_records');
else  $questions->setPageBlockShow('page_nav');




?>
<script type="text/javascript" language="javascript">
	var block_arr= new Array('selMsgConfirm');
	var replace_url = '<?php echo $CFG['site']['url']; ?>login.php';
	var please_select_action = 'please select action';
	var confirm_message = '';
	function getAction()
		{
			var act_value = document.selMemberForum.action.value;
			if(act_value)
				{
					switch(act_value)
					{
						case 'block_question':
								confirm_message = 'Are you sure want to Block the answer';
								break;
							case 'open_question':
								confirm_message = 'Are you sure want to open the answer';
								break;
							case 'resolve_question':
								confirm_message = 'Are you sure want to Resolve the answer';
								break;
							case 'delete_question':
								confirm_message = 'Are you sure want to Delete the answer';
								break;
							case 'abuse_question':
								confirm_message = 'Are you sure want to abuse the answer';
								break;
					}


					$('msgConfirmText').innerHTML = confirm_message;
					document.msgConfirmform.action.value = act_value;
					Confirmation('dAltMlti', 'selMsgConfirm', 'msgConfirmform', Array('ques_ids'), Array(multiCheckValue), Array('value'), -25, -290, 'selMemberForum');
				}
				else{
						alert_manual(please_select_action, 'dAltMlti');
					}
		}
</script>
<div id="selMembers">
  <h2 class="clsManageAnswers"><?php echo $LANG['member_title']; ?></h2>
  <?php
if ($questions->isShowPageBlock('msg_form_error'))
{
?>
  <div id="selMsgError">
    <p><?php echo $LANG['member_err_tip_error'] . ' ' . $questions->getCommonErrorMsg(); ?></p>
  </div>
  <?php
}
if ($questions->isShowPageBlock('msg_form_success'))
{
?>
	    <div id="selMsgSuccess">
	      	<p>
<?php
		echo $questions->getCommonErrorMsg();
?>
	      	</p>
	    </div>
    <?php
}
if ($questions->isShowPageBlock('show_form_confirm'))
{
?>
  <div id="selMsgError">
    <form name="form_delete_event" id="selFormselDeleteEvents" method="post" action="<?php echo URL($_SERVER['PHP_SELF']); ?>" autocomplete="off">
      <table class="clsCommonTable" summary="<?php echo $LANG['member_tbl_summary']; ?>" >
        <tr>
          <td colspan="2"><?php echo $LANG['confirm_message']; ?></td>
        </tr>
        <tr>
          <td><?php $questions->common_hidden($questions->getFormField('ques_ids')); ?>
            <input type="hidden" name="action" value="<?php echo $questions->getFormField('action'); ?>" />
            <input type="submit" class="clsSubmitButton" name="cdelete" id="cdelete" value="<?php echo $LANG['member_yes']; ?>" tabindex="<?php echo $questions->getTabIndex(); ?>" />
          </td>
          <td><input type="submit" class="clsCancelButton" name="dcancel" id="dcancel" value="<?php echo $LANG['member_no']; ?>" tabindex="<?php echo $questions->getTabIndex(); ?>" />
          	<?php $questions->populateHiddenFormFields(array('start', 'numpg', 'search_name', 'search_cat')); ?>
          </td>
        </tr>
      </table>
    </form>
  </div>
  <?php
}
if ($questions->isShowPageBlock('form_edit'))
{
		$style_add_video = '';
		$style_delete_video = 'style="display:none"';
		$style_preview_video = 'style="display:none"';
		$video_preview_url = getUrl($questions->CFG['site']['url'] . 'members/ansPreviewVideo.php', $questions->CFG['site']['url'] . 'members/ansPreviewVideo.php', false) . '?pg=Question_' . $questions->getFormField('rid');
?>
<script language="javascript" type="text/javascript">
var videoPreviewUrl = '<?php echo $video_preview_url; ?>';
</script>
<?php
		if ($questions->getFormField('video') or $questions->getFormField('video_id'))
		{
				$style_delete_video = '';
				$style_preview_video = '';
				$style_add_video = 'style="display:none"';
				if ($questions->getFormField('video_id')) $video_preview_url = getUrl($questions->CFG['site']['url'] . 'members/ansViewVideo.php', $questions->CFG['site']['url'] . 'members/ansViewVideo.php', false) . '?pg=Question_' . $questions->getFormField('video_id');
				if ($questions->getFormField('video')) $video_preview_url = getUrl($questions->CFG['site']['url'] . 'members/ansPreviewVideo.php', $questions->CFG['site']['url'] . 'members/ansPreviewVideo.php', false) . '?pg=Question_' . $questions->getFormField('video');
		}
		$style_add_audio = '';
		$style_delete_audio = 'style="display:none"';
		$style_preview_audio = 'style="display:none"';
		$audio_preview_url = getUrl($questions->CFG['site']['url'] . 'members/ansPreviewAudio.php', $questions->CFG['site']['url'] . 'members/ansPreviewAudio.php', false) . '?pg=Question_' . $questions->getFormField('rid');
?>
<script language="javascript" type="text/javascript">
var audioPreviewUrl = '<?php echo $audio_preview_url; ?>';
</script>
<?php
		if ($questions->getFormField('audio') or $questions->getFormField('audio_id'))
		{
				$style_delete_audio = '';
				$style_preview_audio = '';
				$style_add_audio = 'style="display:none"';
				if ($questions->getFormField('audio_id')) $audio_preview_url = getUrl($questions->CFG['site']['url'] . 'members/ansViewAudio.php', $questions->CFG['site']['url'] . 'members/ansViewAudio.php', false) . '?pg=Question_' . $questions->getFormField('audio_id');
				if ($questions->getFormField('audio')) $audio_preview_url = getUrl($questions->CFG['site']['url'] . 'members/ansPreviewAudio.php', $questions->CFG['site']['url'] . 'members/ansPreviewAudio.php', false) . '?pg=Question_' . $questions->getFormField('audio');
		}

?>
	<div id="selQuestionEdit">
	<form name="selFormAskQuestion" id="selFormAskQuestion" method="post" action="<?php echo URL($_SERVER['PHP_SELF']); ?>" autocomplete="off">
		<?php $questions->populateHidden(array('rid', 'video', 'audio', 'video_id', 'audio_id', 'f')); ?>
		<table class="clsCommonTable" summary="<?php echo $LANG['post_your_question']; ?>">
			<tr>
				<td class="<?php echo $questions->getCSSFormLabelCellClass('question'); ?>"><label for="question"><?php echo $LANG['member_question']; ?></label></td>
				<td class="<?php echo $questions->getCSSFormFieldCellClass('question'); ?>"><?php echo $questions->getFormFieldErrorTip('question'); ?>
					<input type="text" class="clsTextBox" name="question" id="question" maxlength="250" tabindex="<?php echo $questions->getTabIndex(); ?>" value="<?php echo $questions->getFormField('question'); ?>" />
				</td>
			</tr>
			<tr>
				<td class="<?php echo $questions->getCSSFormLabelCellClass('description'); ?>"><label for="description"><?php echo $LANG['add_details']; ?></label></td>
				<td class="<?php echo $questions->getCSSFormFieldCellClass('description'); ?>"><?php echo $questions->getFormFieldErrorTip('description'); ?>
					<textarea name="description" id="description" maxlength="<?php echo $questions->CFG['admin']['description']['limit']; ?>" tabindex="<?php echo $questions->getTabIndex(); ?>" onFocus="updatelength(this);" onKeyUp="updatelength(this);"><?php echo stripslashes($questions->getFormField('description')); ?></textarea>
					<div><?php echo $LANG['total_characters_entered']; ?> <span id="ss">0  (<?php echo $LANG['limit']; ?> <?php echo $questions->CFG['admin']['description']['limit']; ?>)</span></div>
				</td>
			</tr>
			<tr>
      			<td class="<?php echo $questions->getCSSFormLabelCellClass('video'); ?>"><label for="video"><?php echo $questions->LANG['questions_add_video_details']; ?></label></td>
      			<td class="<?php echo $questions->getCSSFormFieldCellClass('video'); ?>"><?php echo $questions->getFormFieldErrorTip('video'); ?> <a <?php echo $style_add_video; ?> id="video_add" href="<?php echo getUrl($questions->CFG['site']['url'] . 'members/videoUpload.php', $questions->CFG['site']['url'] . 'members/videoupload/', false) . '?rid=' . $questions->getFormField('rid'); ?>" onClick="return openAjaxWindow('video_add', -50, -200);"><?php echo $questions->LANG['add_video']; ?></a> <a <?php echo $style_delete_video; ?> id="video_delete" href="<?php echo $_SERVER['REQUEST_URI']; ?>" onClick="return removeVideo();"><?php echo $questions->LANG['delete_video']; ?></a> <a <?php echo $style_preview_video; ?> id="video_preview" href="<?php echo $video_preview_url; ?>" onClick="return openAjaxWindow('video_preview', -50, -200);"><?php echo 'Preview Video'; ?></a></td>
    		</tr>

		    <tr>
		      <td class="<?php echo $questions->getCSSFormLabelCellClass('audio'); ?>"><label for="audio"><?php echo $questions->LANG['questions_add_audio_details']; ?></label></td>
		      <td class="<?php echo $questions->getCSSFormFieldCellClass('audio'); ?>"><?php echo $questions->getFormFieldErrorTip('audio'); ?> <a <?php echo $style_add_audio; ?> id="audio_add" href="<?php echo getUrl($questions->CFG['site']['url'] . 'members/audioUpload.php', $questions->CFG['site']['url'] . 'members/audioupload/', false) . '?rid=' . $questions->getFormField('rid') . 'AUD'; ?>" onClick="return openAjaxWindow('audio_add', -50, -200);"><?php echo $questions->LANG['add_audio']; ?></a> <a <?php echo $style_delete_audio; ?> id="audio_delete" href="<?php echo $_SERVER['REQUEST_URI']; ?>" onClick="return removeAudio();"><?php echo $questions->LANG['delete_audio']; ?></a> <a <?php echo $style_preview_audio; ?> id="audio_preview" href="<?php echo $audio_preview_url; ?>"  onClick="return openAjaxWindow('audio_preview', -50, -80);"><?php echo 'Preview Audio'; ?></a></td>
		    </tr>
		   	<?php
		$cat_tab_index = $questions->getTabIndex();
		$sub_cat_tab_index = $questions->getTabIndex();
?>
		   	<tr>
				<td class="<?php echo $questions->getCSSFormLabelCellClass('category'); ?>"><label for="category"><?php echo $LANG['select_category_for_question']; ?></label></td>
				<td class="<?php echo $questions->getCSSFormFieldCellClass('category'); ?>"><?php echo $questions->getFormFieldErrorTip('category'); ?>
					<select name="category" id="category" tabindex="<?php echo $cat_tab_index; ?>" onchange="return call_ajax_populate_sub_categories('<?php echo $questions->CFG['site']['url'] . 'members/'; ?>questions_ajax.php', 't=<?php echo $sub_cat_tab_index; ?>','subCatDiv');"><option value=""><?php echo $LANG['choose']; ?></option><?php $questions->populateCategories($questions->getFormField('category')); ?></select>
				</td>
			</tr>
			<tr>
				<td class="<?php echo $questions->getCSSFormLabelCellClass('sub_category'); ?>"><label for="sub_category"><?php echo $LANG['select_sub_category_for_question']; ?></label></td>
				<td class="<?php echo $questions->getCSSFormFieldCellClass('sub_category'); ?>" id="subCatDiv"><?php echo $questions->getFormFieldErrorTip('sub_category'); ?>
					<select name="sub_category" id="sub_category" tabindex="<?php echo $sub_cat_tab_index; ?>"><option value=""><?php echo $LANG['choose']; ?></option><?php $questions->populateSubCategories($questions->getFormField('category'), $questions->getFormField('sub_category')); ?></select>
				</td>
			</tr>
			<tr>
				<td class="<?php echo $questions->getCSSFormLabelCellClass('tags'); ?>"><label for="tags"><?php echo $LANG['tags_for_questions']; ?></label></td>
				<td class="<?php echo $questions->getCSSFormFieldCellClass('tags'); ?>"><?php echo $questions->getFormFieldErrorTip('tags'); ?>
					<input type="text" class="clsTextBox" name="tags" id="tags" maxlength="250" tabindex="<?php echo $questions->getTabIndex(); ?>" value="<?php echo $questions->getFormField('tags'); ?>" />
				</td>
			</tr>
			<tr>
				<td class="<?php echo $questions->getCSSFormFieldCellClass('submit'); ?>" colspan="2">
					<input type="submit" class="clsSubmitButton" name="submit" id="submit" tabindex="<?php echo $questions->getTabIndex(); ?>" value="<?php echo $LANG['question_submit']; ?>" />
					&nbsp;&nbsp;
					<input type="submit" class="clsSubmitButton" name="cancel" id="cancel" tabindex="<?php echo $questions->getTabIndex(); ?>" value="<?php echo $LANG['question_cancel']; ?>" />
				</td>
			</tr>
		</table>
		<input type="hidden" name="qid" value="<?php echo $questions->getFormField('qid'); ?>" />
	</form>
	</div>
<?php
}
if ($questions->isShowPageBlock('list_records'))
{
		$tab = 4000;
?>
  <div id="selMsgConfirm" class="clsPopupConfirmation" style="display:none;position:absolute;">
      <p id="msgConfirmText"></p>
      <form name="msgConfirmform" id="msgConfirmform" method="post" action="<?php echo $_SERVER['REQUEST_URI']; ?>" autocomplete="off">
        <table class="clsCommonTable" summary="<?php echo $LANG['member_tbl_summary']; ?>">
          <tr>
            <td>
		 	<input type="submit" class="clsSubmitButton" name="yes" id="yes" value="<?php echo $LANG['yes']; ?>" tabindex="<?php echo $questions->getTabIndex(); ?>" />
              	&nbsp;
              	<input type="button" class="clsCancelButton" name="no" id="no" value="<?php echo $LANG['no']; ?>" tabindex="<?php echo $questions->getTabIndex(); ?>" onClick="return hideAllBlocks('selMemberForum')" />
              	<input type="hidden" name="act" id="act" />
              	<input type="hidden" name="qid" id="qid" />
              	<input type="hidden" name="ques_ids" id="ques_id" />
              	<input type="hidden" name="action" id="action" />
              	<input type="hidden" name="search_name" id="search_name" value="<?php echo $questions->getFormField('search_name'); ?>"/>
              	<input type="hidden" name="search_cat" id="search_cat" value="<?php echo $questions->getFormField('search_cat'); ?>" />
				<?php $questions->populateHiddenFormFields(array('start', 'numpg')); ?>
            </td>
          </tr>
        </table>
      </form>
  </div>


  <form name="selMemberForum" id="selMemberForum" method="post" action="<?php echo URL($_SERVER['PHP_SELF']); ?>" autocomplete="off">
    <table class="clsCommonTable" summary="<?php echo $LANG['member_tbl_summary']; ?>">
      <tr>
        <td class="<?php echo $questions->getCSSFormLabelCellClass('search_name'); ?>"><label for="search_name"><?php echo $LANG['member_search_name']; ?></label></td>
        <td class="<?php echo $questions->getCSSFormFieldCellClass('search_name'); ?>"><?php echo $questions->getFormFieldErrorTip('search_name'); ?>
          <input type="text" class="clsTextBox" name="search_name" id="search_name" tabindex="<?php echo $questions->getTabIndex(); ?>" value="<?php echo $questions->getFormField('search_name'); ?>" /></td>
      </tr>
      <tr>
        <td class="<?php echo $questions->getCSSFormLabelCellClass('search_cat'); ?>"><label for="search_cat"><?php echo $LANG['member_search_cat']; ?></label></td>
        <td class="<?php echo $questions->getCSSFormFieldCellClass('search_cat'); ?>"><?php echo $questions->getFormFieldErrorTip('search_cat'); ?>
          <select class="clsCommonListBox" name="search_cat" id="search_cat" tabindex="<?php echo $questions->getTabIndex(); ?>" >
          	<?php $questions->populateSearchOptions($questions->getFormField('search_cat')); ?>
          </select>
        </td>
      </tr>
      <tr>
      <td>&nbsp;</td>
        <td class="<?php echo $questions->getCSSFormFieldCellClass('submit'); ?>"><input type="submit" class="clsSubmitButton" name="go" tabindex="<?php echo $questions->getTabIndex(); ?>" value="<?php echo $LANG['member_go']; ?>" /></td>
      </tr>
    </table>
    <?php
		if ($questions->isShowPageBlock('page_nav') && $CFG['admin']['navigation']['top'])
		{
?>
	    <table cellspacing="0" summary="Filter Table" class="clsCommonTable clsFilterTable">
	      <tr>
	        <td><?php
				$questions->populatePageLinks($questions->getFormField('start'), array('search_cat', 'search_name'));
?>
	        </td>
	      </tr>
	    </table>

	  <br/>
	  <?php
		}
?>
    <table class="clsCommonTable" summary="<?php echo $LANG['member_tbl_summary']; ?>" border="1">
      <tr>
        <th>&nbsp;<input type="checkbox" class="clsCheckRadio" id="checkall" onclick="selectAll(this.form)" name="checkall" tabindex="<?php echo $questions->getTabIndex(); ?>" /></th>
		<th><?php echo $LANG['member_question']; ?></th>
		<th><?php echo $LANG['member_category']; ?></th>
		<th><?php echo $LANG['member_tags']; ?></th>
        <th><?php echo $LANG['member_name']; ?></th>
		<th><?php echo $LANG['member_answers']; ?></th>
		<th><?php echo $LANG['member_abuse_count']; ?></th>
		<th class="clsPortCount"><?php echo $LANG['member_status']; ?></th>
		<th><?php echo $LANG['member_date_asked']; ?></th>
		<th><?php echo $LANG['manage']; ?></th>
      </tr>
<?php
		while ($questions->fetchResultRecord())
		{
				$anchor = 'selConPos_' . $questions->getColumnValue('video_id');
?>
      <tr>
        <td class="clsSelectAllMember"><input type="checkbox" class="clsCheckRadio" name="ques_ids[]" tabindex="<?php echo $questions->getTabIndex(); ?>" value="<?php echo $questions->getColumnValue('ques_id'); ?>" /></td>
		<td>
			<a href="<?php echo $CFG['site']['relative_url'] . 'viewAnswers.php?qid=' . $questions->getColumnValue('ques_id'); ?>"><?php echo wordWrapManual($questions->getColumnValue('question'), 50); ?></a>
			<?php if (chkVideoAllowed('question') and $questions->getColumnValue('video_id'))
				{ ?>
				<span><a href="<?php echo $CFG['site']['relative_url'] . 'viewAnswers.php?qid=' . $questions->getColumnValue('ques_id'); ?>"><img src="<?php echo $CFG['site']['url'] . 'images/icon-video.png' ?>" alt="video available" /></a></span>
			<?php } ?>
			<?php if (chkAudioAllowed('question') and $questions->getColumnValue('audio_id'))
				{ ?>
				<span><a href="<?php echo $CFG['site']['relative_url'] . 'viewAnswers.php?qid=' . $questions->getColumnValue('ques_id'); ?>"><img src="<?php echo $CFG['site']['url'] . 'images/icon-audio.png' ?>" alt="audio available" /></a></span>
			<?php } ?>
		</td>
		<td><?php echo $questions->getCategoryName($questions->getColumnValue('pcat_id'), $questions->getColumnValue('cat_id')); ?></td>
		<td><?php echo $questions->getColumnValue('tags'); ?></td>
		<td><?php echo $questions->getColumnValue('name'); ?></td>
		<td>
			<?php echo $questions->getColumnValue('total_answer'); ?><p>
			<?php if (chkVideoAllowed('question') and $questions->getColumnValue('total_videos') > 0)
				{ ?>
			<span><a href="<?php echo $CFG['site']['relative_url'] . 'viewAnswers.php?qid=' . $questions->getColumnValue('ques_id'); ?>"><img src="<?php echo $CFG['site']['url'] . 'images/icon-video.png' ?>" alt="video available" /></a></span>
			<?php } ?>
			<?php if (chkAudioAllowed('question') and $questions->getColumnValue('total_audios') > 0)
				{ ?>
			<span><a href="<?php echo $CFG['site']['relative_url'] . 'viewAnswers.php?qid=' . $questions->getColumnValue('ques_id'); ?>"><img src="<?php echo $CFG['site']['url'] . 'images/icon-audio.png' ?>" alt="audio available" /></a></span>
			<?php } ?></p>
		</td>
		<td><?php echo $questions->getColumnValue('abuse_count'); ?></td>
        <td class="clsPortCount"><?php echo $questions->getColumnValue('status'); ?></td>
		<td><?php echo getTimeDiffernceFormat($questions->getColumnValue('date_asked')); ?></td>
		<td>
			<a href="manageAnswers.php?qid=<?php echo $questions->getColumnValue('ques_id'); ?>"><?php echo $LANG['edit']; ?></a>
			<?php if (chkVideoAllowed('question') and $questions->getColumnValue('video_id'))
				{ ?>
			<a id="<?php echo $anchor; ?>"  href="#" title="<?php echo $LANG['delete_video']; ?>" onClick="return Confirmation('<?php echo $anchor; ?>', 'selMsgConfirm', 'msgConfirmform', Array('act','qid', 'msgConfirmText'), Array('deletevideo','<?php echo $questions->getColumnValue('video_id'); ?>', '<?php echo $LANG['delete_video_confirmation']; ?>'), Array('value','value', 'innerHTML'), -100, -750);"><?php echo $LANG['delete_video']; ?></a>
			<?php } ?>
			<?php if (chkAudioAllowed('question') and $questions->getColumnValue('audio_id'))
				{ ?>
			<a id="<?php echo $anchor; ?>"  href="#" title="<?php echo $LANG['delete_audio']; ?>" onClick="return Confirmation('<?php echo $anchor; ?>', 'selMsgConfirm', 'msgConfirmform', Array('act','qid', 'msgConfirmText'), Array('deleteaudio','<?php echo $questions->getColumnValue('audio_id'); ?>', '<?php echo $LANG['delete_audio_confirmation']; ?>'), Array('value','value', 'innerHTML'), -100, -750);"><?php echo $LANG['delete_audio']; ?></a>
			<?php } ?>
		</td>
      </tr>
      <?php
		}
		if ($questions->isResultsFound())
		{
?>
      <tr>
        <td colspan="10"  class="<?php echo $questions->getCSSFormFieldCellClass('submit'); ?>"><select class="clsCommonListBox" name="action" id="action" tabindex="<?php echo $questions->getTabIndex(); ?>" >
            <option value="block_question" <?php if ($questions->getFormField('action') == 'block_question') echo 'selected=\'selected\''; ?>><?php echo $LANG['member_block_question']; ?></option>
            <option value="open_question" <?php if ($questions->getFormField('action') == 'open_question') echo 'selected=\'selected\''; ?>><?php echo $LANG['member_open_question']; ?></option>
			<option value="resolve_question" <?php if ($questions->getFormField('action') == 'resolve_question') echo 'selected=\'selected\''; ?>><?php echo $LANG['member_resolve_question']; ?></option>
			<option value="delete_question" <?php if ($questions->getFormField('action') == 'delete_question') echo 'selected=\'selected\''; ?>><?php echo $LANG['member_delete_question']; ?></option>
			<option value="abuse_question" <?php if ($questions->getFormField('action') == 'abuse_question') echo 'selected=\'selected\''; ?>><?php echo $LANG['member_abuse_question']; ?></option>
          </select>
          &nbsp;
          <a href="#" id="dAltMlti"></a>
		  <input type="button"  class="clsSubmitButton"  name="todo" id="todo" onclick="getMultiCheckBoxValue('selMemberForum', 'checkall', '<?php echo 'Please select Answer'; ?>', 'dAltMlti');if(multiCheckValue!=''){getAction()}" value="<?php echo 'go'; ?>" tabindex="<?php echo $questions->getTabIndex(); ?>" />

		</td>
      </tr>
      <?php
		}
}
else
{
?>
      <tr>
        <td colspan="2"><?php echo $LANG['msg_no_records'] ?></td>
      </tr>
      <?php
}
if ($questions->isShowPageBlock('msg_no_records'))
{
?>
      <tr>
        <td colspan="2"><?php echo $LANG['msg_no_records']; ?></td>
      </tr>
      <?php
}
?>
    </table>
  </form>
  <?php
if ($questions->isShowPageBlock('page_nav') && $CFG['admin']['navigation']['bottom'])
{
?>
    <table cellspacing="0" summary="Filter Table" class="clsCommonTable clsFilterTable">
      <tr>
        <td><?php
		$questions->populatePageLinks($questions->getFormField('start'), array('search_cat', 'search_name'));
?>
        </td>
      </tr>
    </table>
    <br/>
  <?php
}
?>
</div>
<script language="javascript">
	var saveVideo = function(){
		$('video_add').style.display = 'none';
		$('video_delete').style.display = '';
		if (($('video_preview'))) {
			$('video_preview').style.display = '';
			$('video_preview').href = videoPreviewUrl;
		}
		$('video').value = $('rid').value;
		hideAllBlocks();
	}
	var removeVideo = function(){
		$('video_delete').style.display = 'none';
		if (($('video_preview'))) $('video_preview').style.display = 'none';
		$('video_add').style.display = '';
		$('video').value = '';
		$('video_id').value = '0';
		return false;
	}
	var deleteVideo = function(){
		hideAllBlocks();
	}
	var saveAudio = function(){
		$('audio_add').style.display = 'none';
		$('audio_delete').style.display = '';
		if (($('audio_preview'))) {
			$('audio_preview').style.display = '';
			$('audio_preview').href = audioPreviewUrl;
		}
		$('audio').value = $('rid').value;
		hideAllBlocks();
	}
	var removeAudio = function(){
		$('audio_delete').style.display = 'none';
		if (($('audio_preview'))) $('audio_preview').style.display = 'none';
		$('audio_add').style.display = '';
		$('audio').value = '';
		$('audio_id').value = '0';
		return false;
	}
	var deleteAudio = function(){
		hideAllBlocks();
	}
</script>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>
