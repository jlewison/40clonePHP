<?php
require_once ('../common/config.inc.php');
require_once ('../common/configs/config_ans_video.inc.php');
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['mods']['include_files'][] = 'common/classes/class_ftp.lib.php';
$CFG['mods']['is_include_only']['non_html_header_files'] = true;
$CFG['auth']['is_authenticate'] = false;
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
set_time_limit(0);
class ManageDeleted extends FormHandler
{
		public function deleteVideosTable()
		{
				$video_id = $this->video_details['video_id'];
				if ($video_id)
				{
						$tablename_arr = array('ans_video');
						for ($i = 0; $i < sizeof($tablename_arr); $i++)
						{
								$sql = 'DELETE FROM ' . $this->CFG['db']['tbl'][$tablename_arr[$i]] . ' WHERE video_id =' . $this->dbObj->Param('video_id');
								$stmt = $this->dbObj->Prepare($sql);
								$rs = $this->dbObj->Execute($stmt, array($video_id));
								if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
						}
				}
		}
		public function chkIsLocalServer()
		{
				$server_url = $this->video_details['video_server_url'];
				if (strstr($server_url, $this->CFG['site']['url']))
				{
						$server_url = str_replace($this->CFG['site']['url'], '', $server_url);
						if (trim($server_url) == '')
						{
								return true;
						}
				}
				return false;
		}
		public function getServerDetails()
		{
				$server_url = str_replace($this->CFG['admin']['ans_videos']['video_folder'], '', $this->video_details['video_server_url']);
				$sql = 'SELECT ftp_server, ftp_folder, ftp_usrename, ftp_password, category FROM' . ' ' . $this->CFG['db']['tbl']['server_settings'] . ' WHERE server_for=\'Ans_video\' AND server_url=' . $this->dbObj->Param('server_url') . ' LIMIT 0,1';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($server_url));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if (!$rs->PO_RecordCount()) return false;
				while ($row = $rs->FetchRow())
				{
						$this->fields_arr['ftp_server'] = $row['ftp_server'];
						$this->fields_arr['ftp_folder'] = $row['ftp_folder'];
						$this->fields_arr['ftp_usrename'] = $row['ftp_usrename'];
						$this->fields_arr['ftp_password'] = $row['ftp_password'];
						return true;
				}
				return false;
		}
		public function removeFiles($file)
		{
				if (is_file($file))
				{
						unlink($file);
						return true;
				}
				return false;
		}
		public function deleteDeletedVideo()
		{
				$thumbnail_folder = '../' . $this->CFG['admin']['ans_videos']['thumbnail_folder'];
				$flv_folder = '../' . $this->CFG['admin']['ans_videos']['video_folder'];
				$extension = $this->CFG['video']['image']['extensions'];
				if ($this->chkIsLocalServer())
				{
						$thumb_filename = $thumbnail_folder . getImageName($this->video_details['video_id']);
						$flv_filename = $flv_folder . getImageName($this->video_details['video_id']);
						$this->removeFiles($flv_filename . '.' . $this->video_details['video_ext']);
						$this->removeFiles($thumb_filename . 'T.' . $extension);
				}
				else
				{
						if ($this->getServerDetails())
						{
								if ($FtpObj = new FtpHandler($this->fields_arr['ftp_server'], $this->fields_arr['ftp_usrename'], $this->fields_arr['ftp_password']))
								{
										if ($this->fields_arr['ftp_folder']) $FtpObj->changeDirectory($this->fields_arr['ftp_folder']);
										$filename = getImageName($this->video_details['video_id']);
										$dir_video = $this->CFG['admin']['ans_videos']['video_folder'];
										$dir_thumb = $this->CFG['admin']['ans_videos']['thumbnail_folder'];
										$FtpObj->deleteFile($dir_video . $filename . '.' . $this->video_details['video_ext']);
										$FtpObj->deleteFile($dir_thumb . $filename . 'T.' . $extension);
										$FtpObj->ftpClose();
								}
						}
				}
				$this->deleteVideosTable();
				return true;
		}
		public function deleteVideos()
		{
				$sql = 'SELECT video_id, video_ext, user_id, video_for, content_id, video_server_url' . ' FROM ' . $this->CFG['db']['tbl']['ans_video'] . ' WHERE' . ' video_status=\'Deleted\' OR (video_encoded_status!=\'Yes\' AND' . ' date_added<=DATE_SUB(NOW(),INTERVAL 48 HOUR))';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount())
				{
						$this->video_details = array();
						while ($row = $rs->FetchRow())
						{
								$this->video_details = $row;
								echo $row['video_id'], '<br>';
								$this->deleteDeletedVideo();
						}
				}
		}
}
$ManageDeleted = new ManageDeleted();
$ManageDeleted->setDBObject($db);
$ManageDeleted->makeGlobalize($CFG, $LANG);
$ManageDeleted->deleteVideos();


?>