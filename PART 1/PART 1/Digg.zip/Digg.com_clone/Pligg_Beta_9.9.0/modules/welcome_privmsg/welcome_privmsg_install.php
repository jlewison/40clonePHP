<?php
	$module_info['name'] = 'Send Welcome Private Message';
	$module_info['desc'] = 'Sends a private message to welcome a user who just registered.';
	$module_info['version'] = 0.1;
	$module_info['requires'][] = array('simple_messaging', 0.1);
?>