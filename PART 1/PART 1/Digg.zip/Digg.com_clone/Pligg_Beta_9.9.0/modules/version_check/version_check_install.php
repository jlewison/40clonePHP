<?php
	$module_info['name'] = 'Version Check';
	$module_info['desc'] = 'Checks to see if you are running the latest version of Pligg.';
	$module_info['version'] = 0.2;
?>