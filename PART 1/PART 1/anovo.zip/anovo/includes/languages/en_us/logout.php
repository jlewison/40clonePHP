<?php
$LANG['logout_title'] = 'Logout';
$LANG['logout_message'] = 'You have been successfully logged off.';
?>