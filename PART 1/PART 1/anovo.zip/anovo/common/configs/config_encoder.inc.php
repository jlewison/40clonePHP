<?php

$CFG['admin']['video']['mplayer_path'] = '/usr/bin/mplayer';
$CFG['admin']['video']['flvtool2_path'] = '/usr/bin/flvtool2';
$CFG['admin']['video']['red5_path'] = 'rtmp://127.0.0.1/SOSample';
$CFG['admin']['video']['red5_flv_path'] = '/opt/red5/webapps/SOSample/streams/';
$CFG['admin']['ans_videos']['capture_second'] = 60;
?>