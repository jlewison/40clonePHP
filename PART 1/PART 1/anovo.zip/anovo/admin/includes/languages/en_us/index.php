<?php
$LANG['index_title'] = 'Home';
$LANG['index_tbl_summary'] = 'Table';
$LANG['settings'] = 'Settings';
$LANG['video_player'] = 'Video Player';
$LANG['answers'] = 'Answers';
$LANG['forums'] = 'Forums';
$LANG['blogs'] = 'Blogs';
$LANG['members'] = 'Members';
$LANG['banners'] = 'Banners';
$LANG['news_letter'] = 'News Letter';
$LANG['member_login'] = 'Member Login';
?>