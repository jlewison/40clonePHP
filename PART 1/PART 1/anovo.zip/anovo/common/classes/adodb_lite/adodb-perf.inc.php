<?php
if (!defined(ADODB_DIR)) include_once (dirname(__file__) . '/adodb.inc.php');
include_once (ADODB_DIR . '/tohtml.inc.php');
define('ADODB_OPT_HIGH', 2);
define('ADODB_OPT_LOW', 1);
function adodb_getmem()
{
		if (function_exists('memory_get_usage')) return (integer)((memory_get_usage() + 512) / 1024);
		$pid = getmypid();
		if (strncmp(strtoupper(PHP_OS), 'WIN', 3) == 0)
		{
				$output = array();
				exec('tasklist /FI "PID eq ' . $pid . '" /FO LIST', $output);
				return substr($output[5], strpos($output[5], ':') + 1);
		}
		exec("ps --pid $pid --no-headers -o%mem,size", $output);
		if (sizeof($output) == 0) return 0;
		$memarr = explode(' ', $output[0]);
		if (sizeof($memarr) >= 2) return (integer)$memarr[1];
		return 0;
}
function adodb_round($n, $prec)
{
		return number_format($n, $prec, '.', '');
}
function adodb_microtime()
{
		$t = microtime();
		$t = explode(' ', $t);
		return (float)$t[1] + (float)$t[0];
}
function &adodb_log_sql(&$conn, $sql, $inputarr)
{
		$perf_table = adodb_perf::table();
		$conn->_logsql = false;
		$t0 = microtime();
		$rs = &$conn->Execute($sql, $inputarr);
		$t1 = microtime();
		$conn->_logsql = true;
		if (!empty($conn->_logsql))
		{
				$conn->_logsql = false;
				$dbT = $conn->dbtype;
				$a0 = split(' ', $t0);
				$a0 = (float)$a0[1] + (float)$a0[0];
				$a1 = split(' ', $t1);
				$a1 = (float)$a1[1] + (float)$a1[0];
				$time = $a1 - $a0;
				if (!$rs)
				{
						$errM = $conn->ErrorMsg();
						$errN = $conn->ErrorNo();
						$tracer = substr('ERROR: ' . htmlspecialchars($errM), 0, 250);
				}
				else
				{
						$tracer = '';
						$errM = '';
						$errN = 0;
				}
				if (isset($_SERVER['HTTP_HOST']))
				{
						$tracer .= '<br>' . $_SERVER['HTTP_HOST'];
						if (isset($_SERVER['PHP_SELF']))
						{
								$tracer .= $_SERVER['PHP_SELF'];
						}
				} elseif (isset($_SERVER['PHP_SELF']))
				{
						$tracer .= '<br>' . $_SERVER['PHP_SELF'];
				}
				$tracer = (string )substr($tracer, 0, 500);
				if (is_array($inputarr))
				{
						if (is_array(reset($inputarr)))
						{
								$params = 'Array sizeof=' . sizeof($inputarr);
						}
						else
						{
								$xar_params = $inputarr;
								foreach ($xar_params as $xar_param_key => $xar_param)
								{
										if (gettype($xar_param) == 'string') $xar_params[$xar_param_key] = '"' . $xar_param . '"';
								}
								$params = implode(', ', $xar_params);
								if (strlen($params) >= 3000) $params = substr($params, 0, 3000);
						}
				}
				else
				{
						$params = '';
				}
				if (is_array($sql)) $sql = $sql[0];
				$arr = array('b' => strlen($sql) . '.' . crc32($sql), 'c' => substr($sql, 0, 3900), 'd' => $params, 'e' => $tracer, 'f' => adodb_round($time, 6));
				$saved = $conn->debug;
				$conn->debug = 0;
				$d = $conn->sysTimeStamp;
				if (empty($d))
				{
						$d = date("'Y-m-d H:i:s'");
				}
				$isql = "insert into $perf_table (created,sql0,sql1,params,tracer,timer) values( $d,?,?,?,?,?)";
				$ok = $conn->Execute($isql, $arr);
				$conn->debug = $saved;
				if ($ok)
				{
						$conn->_logsql = true;
				}
				else
				{
						$err2 = $conn->ErrorMsg();
						$conn->_logsql = true;
						$perf = &NewPerfMonitor($conn);
						if ($perf)
						{
								if ($perf->CreateLogTable()) $ok = $conn->Execute($isql, $arr);
						}
						else
						{
								$ok = $conn->Execute("create table $perf_table (
				created varchar(50),
				sql0 varchar(250), 
				sql1 varchar(4000),
				params varchar(3000),
				tracer varchar(500),
				timer decimal(16,6))");
						}
				}
				$conn->_errorMsg = $errM;
				$conn->_errorCode = $errN;
		}
		return $rs;
}
class adodb_perf
{
		function adodb_perf()
		{
		}
		function table($newtable = false)
		{
				$rt = perfmon_parent_ADOConnection::table($newtable);
				return $rt;
		}
}

?>
