<?php

class AnswerFormHandler extends VideoUploadLib
{
		public $question_details = array();
		public function chkIsValidQuestion()
		{
				$this->chkIsNotEmpty('qid', $this->LANG['answers_err_tip_compulsory']);
				if (!$this->isValidFormInputs())
				{
						$this->setCommonErrorMsg($this->LANG['answers_err_invalid_question']);
						return false;
				}
				$sql = 'SELECT q.ques_id, q.total_answer, q.pcat_id, q.cat_id, q.best_ans_id, q.description, q.total_stars, q.question, TIMEDIFF(NOW(), date_asked) as date_asked' . ', q.video_id, q.audio_id, ' . $this->getUserTableField('name') . ' as asked_by, u.' . $this->getUserTableField('user_id') . ' as img_user_id,' . $this->getUserTableFields(array('t_height', 't_width', 's_height', 's_width', 'photo_server_url', 'photo_ext')) . ' , ' . $this->getUserTableFields(array('image_path', 'gender'), false) . 'q.status, q.user_id' . ', IF(status=\'Open\' AND date_closed>=NOW(), 1, 0) is_open, TIMEDIFF(date_closed, NOW()) as date_closed' . ', q.total_videos, q.total_audios FROM ' . $this->CFG['db']['tbl']['questions'] . ' AS q, ' . $this->CFG['db']['tbl']['users'] . ' AS u' . ' WHERE q.user_id=u.' . $this->getUserTableField('user_id') . ' AND q.status IN (\'Open\', \'Resolved\')' . ' AND u.' . $this->getUserTableField('usr_status') . '=\'Ok\' AND q.ques_id=' . $this->dbObj->Param('qid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['qid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if (!$rs->PO_RecordCount())
				{
						$this->setCommonErrorMsg($this->LANG['answers_err_invalid_question']);
						return false;
				}
				$this->question_details = $rs->FetchRow();
				return true;
		}
		public function chkIsValidAnswer()
		{
				$this->chkIsNotEmpty('aid', $this->LANG['answers_err_tip_compulsory']);
				if (!$this->isValidFormInputs())
				{
						$this->setCommonErrorMsg($this->LANG['answers_err_invalid_answer']);
						return false;
				}
				$sql = 'SELECT a.ques_id, a.user_id, a.answer, a.source, a.video_id, a.audio_id' . ' FROM ' . $this->CFG['db']['tbl']['answers'] . ' AS a' . ', ' . $this->CFG['db']['tbl']['questions'] . ' AS q, ' . $this->CFG['db']['tbl']['users'] . ' AS u' . ' WHERE a.ques_id=q.ques_id AND a.user_id=u.' . $this->getUserTableField('user_id') . ' AND q.status IN (\'Open\', \'Resolved\')' . ' AND u.' . $this->getUserTableField('usr_status') . '=\'Ok\' AND a.ans_id=' . $this->dbObj->Param('aid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['aid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if (!$rs->PO_RecordCount())
				{
						$this->setCommonErrorMsg($this->LANG['answers_err_invalid_question']);
						return false;
				}
				$this->answer_details = $rs->FetchRow();
				$this->fields_arr['qid'] = $this->answer_details['ques_id'];
				return true;
		}
		public function displayBestAnswer()
		{
				if ($this->question_details['best_ans_id'])
				{
						$sql = 'SELECT a.ans_id, a.user_id, a.answer, a.video_id, a.audio_id, a.source, TIMEDIFF(NOW(), date_answered) as date_answered' . ', u.' . $this->getUserTableField('user_id') . ' as img_user_id, ' . $this->getUserTableFields(array('image_path', 'gender', 't_height', 't_width', 's_height', 's_width', 'photo_server_url', 'photo_ext'), false) . $this->getUserTableField('name') . ' as answered_by' . ' FROM ' . $this->CFG['db']['tbl']['answers'] . ' AS a' . ', ' . $this->CFG['db']['tbl']['users'] . ' AS u' . ' WHERE a.user_id=u.' . $this->getUserTableField('user_id') . ' AND u.' . $this->getUserTableField('usr_status') . '=\'Ok\'' . ' AND a.ques_id=' . $this->dbObj->Param('qid') . ' AND a.ans_id=' . $this->dbObj->Param('aid') . ' ORDER BY a.ans_id DESC';
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['qid'], $this->question_details['best_ans_id']));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
						if (!$rs->PO_RecordCount()) return;
						$row = $rs->FetchRow();
						$best_ans_id = $this->question_details['best_ans_id'];
?>

 <!--rounded corners-->
  <div class="clsFirstBestAnswers">  <div class="lbbestanswers">
      <div class="rbbestanswers">
        <div class="bbbestanswers">
          <div class="blcbestanswers">
            <div class="brcbestanswers">
              <div class="tbbestanswers">
                <div class="tlcbestanswers">
                  <div class="trcbestanswers">
 <div class="clsBestAnswers"><h3><?php echo $this->LANG['answers_best_answer']; ?></h3>
<table id="selAuthorTbl" class="clsDataTable">
  <tr>
    <td class="clsForumTitle"><div class="clsUserThumbDetails">
	  <?php if (chkUserImageAllowed())
						{ ?>
	  <div class="clsUserThumb"><?php displayUserImage($row, 'small'); ?></div>
	  <?php } ?>
      <div class="clsUserDetails"><div class="clsAnswers">

        <p><?php echo nl2br(wordWrapManual($row['answer'], $this->CFG['admin']['answer']['line_length'])); ?></p>
        <?php if (chkVideoAllowed('answer') and $row['video_id'])
						{ ?>
        <span><a id="video_add_<?php echo $best_ans_id; ?>" href="<?php echo getUrl('ansViewVideo.php', 'ansViewVideo.php'); ?>?pg=Answer_<?php echo $row['video_id']; ?>" onClick="return openAjaxWindow('video_add_<?php echo $best_ans_id; ?>', -150, -200);"><img src="<?php echo $this->CFG['site']['url'] . 'images/icon-video.png' ?>" alt="<?php echo $this->LANG['questions_video_available']; ?>" /></a></span>
        <?php } ?>
        <?php if (chkAudioAllowed('answer') and $row['audio_id'])
						{ ?>
        <span><a id="audio_add_<?php echo $best_ans_id; ?>" href="<?php echo getUrl('ansViewAudio.php', 'ansViewAudio.php'); ?>?pg=Answer_<?php echo $row['audio_id']; ?>" onClick="return openAjaxWindow('audio_add_<?php echo $best_ans_id; ?>', -150, -100);"><img src="<?php echo $this->CFG['site']['url'] . 'images/icon-audio.png' ?>" alt="<?php echo $this->LANG['questions_audio_available']; ?>" /></a></span>
        <?php } ?>
        <?php if ($row['source'])
						{ ?>
        <p><?php echo $this->LANG['answers_sources']; ?></p>
        <p><?php echo nl2br(wordWrapManual($row['source'], $this->CFG['admin']['answer']['line_length'])); ?></p>
        <?php } ?>
        <p> <span class="clsForumAuthor clsNoBorder"><?php echo $this->LANG['answers_answered_by']; ?> <a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'myanswers.php?uid=' . $row['user_id'], $this->CFG['site']['relative_url'] . 'my/answers/' . $row['user_id'] . '/', false); ?>"><?php echo stripString($row['answered_by'], $this->CFG['username']['short_length']); ?></a></span> <span><?php echo getTimeDiffernceFormat($row['date_answered']); ?></span> </p>
      </div></div></div></td>
  </tr>
</table></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!--end of rounded corners--></div>
<?php
				}
		}
		public function showAnotherQuestion()
		{
				$sql = 'SELECT ques_id FROM ' . $this->CFG['db']['tbl']['questions'] . ' WHERE ques_id<' . $this->dbObj->Param('qid');
				if ($this->question_details['is_open']) $sql .= ' AND status=\'Open\' AND date_closed>=NOW()';
				else  $sql .= ' AND (status!=\'Open\' OR date_closed<NOW())';
				$sql .= ' ORDER BY ques_id DESC LIMIT 1';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['qid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount())
				{
						$row = $rs->FetchRow();
?>
<p class="clsShowAnotherQuestion"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'answer.php?qid=' . $row['ques_id'], $this->CFG['site']['relative_url'] . 'view/answers/' . $row['ques_id'] . '/', false); ?>"><?php echo $this->LANG['answers_show_another_question']; ?></a></p>
<?php
				}
		}
		public function isQuestionOpen()
		{
				return ($this->question_details['is_open']) ? true : false;
		}
		public function displayQuestionDetails()
		{
				if (!$this->question_details) return false;
				$video_plural = '';
				$audio_plural = '';
				$answer_plural = '';
				$audio_class = 'clsNoBorder';
				$video_class = '';
				if ($this->question_details['total_videos'] != 1) $video_plural = 's';
				if ($this->question_details['total_audios'] != 1) $audio_plural = 's';
				if ($this->question_details['total_answer'] != 1) $answer_plural = 's';
				if ($this->question_details['video_id']) $video_class = 'clsNoBorder';
				if ($this->question_details['audio_id']) $video_class = '';
				$video_audio_count = '';
				$video_audio_count .= chkVideoAllowed('answer') ? $this->question_details['total_videos'] . ' ' . $this->LANG['question_total_videos'] . $video_plural . ' | ' : '';
				$video_audio_count .= chkAudioAllowed('answer') ? $this->question_details['total_audios'] . ' ' . $this->LANG['question_total_audios'] . $audio_plural . ' | ' : '';
				$video_audio_count = substr($video_audio_count, 0, strrpos($video_audio_count, '|'));
				$video_audio_count = trim($video_audio_count);
				$video_audio_count = $video_audio_count ? '(' . $video_audio_count . ')' : '';
?>
<div id="selQuickLinks">
  <?php $this->showAnotherQuestion(); ?><div class="clsQuestionDetails">
  <table summary="<?php echo $this->LANG['question_details_tbl']; ?>" id="selAuthorTbl" class="clsDataTable">
    <tr>
      <td class="clsForumTitle"><div class="clsUserThumbDetails">
      	<?php if (chkUserImageAllowed())
				{ ?>
	  	<div class="clsUserThumb"><?php displayUserImage($this->question_details, 'small'); ?></div>
	  	<?php } ?>
 		<div class="clsUserDetails">
		<p class="clsBold"><?php echo wordWrapManual($this->question_details['question'], 45); ?></p>
		<p>
	      <?php if (chkVideoAllowed('question') and $this->question_details['video_id'])
				{ ?>
		  <span class="<?php echo $video_class; ?>"><a id="video_add_<?php echo $this->fields_arr['qid']; ?>" href="<?php echo getUrl('ansViewVideo.php', 'ansViewVideo.php'); ?>?pg=Question_<?php echo $this->question_details['video_id']; ?>" onClick="return openAjaxWindow('video_add_<?php echo $this->fields_arr['qid']; ?>', -150, -200);"><img src="<?php echo $this->CFG['site']['url'] . 'images/icon-video.png' ?>" alt="<?php echo $this->LANG['questions_video_available']; ?>" /></a></span>
          <?php } ?>
          <?php if (chkAudioAllowed('question') and $this->question_details['audio_id'])
				{ ?>
		  <span class="<?php echo $audio_class; ?>"><a id="audio_add_<?php echo $this->fields_arr['qid']; ?>" href="<?php echo getUrl('ansViewAudio.php', 'ansViewAudio.php'); ?>?pg=Question_<?php echo $this->question_details['audio_id']; ?>" onClick="return openAjaxWindow('audio_add_<?php echo $this->fields_arr['qid']; ?>', -150, -100);"><img src="<?php echo $this->CFG['site']['url'] . 'images/icon-audio.png' ?>" alt="<?php echo $this->LANG['questions_audio_available']; ?>" /></a></span>
          <?php } ?>
		</p>
        <p class=""><?php echo nl2br(wordWrapManual($this->question_details['description'], $this->CFG['admin']['description']['line_length'])); ?></p>
        <p>
          <?php $anchor = 'resolve'; ?>
          <a href="<?php echo $_SERVER['REQUEST_URI']; ?>" id="<?php echo $anchor; ?>"></a>
          <?php
				$cat_id = $this->question_details['cat_id'];
				if (!$cat_id) $cat_id = $this->question_details['pcat_id'];
				$this->showCategoryName($cat_id);
?>
          <span class="clsNoBorder clsForumAuthor"><?php echo $this->LANG['question_asked_by']; ?> <a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'myanswers.php?uid=' . $this->question_details['user_id'], $this->CFG['site']['relative_url'] . 'my/answers/' . $this->question_details['user_id'] . '/', false); ?>"><?php echo stripString($this->question_details['asked_by'], $this->CFG['username']['short_length']); ?></a></span></p><p>  <span class="clsTotalAnswer"><?php echo $this->question_details['total_answer']; ?>&nbsp;<?php echo $this->LANG['question_total_answer'] . $answer_plural; ?> <?php echo $video_audio_count; ?></span>
           <span class="clsNoBorder"><?php echo getTimeDiffernceFormat($this->question_details['date_asked']); ?></span>
         <p>
		 <?php if ($this->question_details['is_open'])
				{ ?>
         <span class="clsNoBorder"><?php echo getTimeToGoFormat($this->question_details['date_closed']); ?></span>
          <?php }
				else
				{ ?>
          <span class="clsResolved clsNoBorder"><?php echo $this->LANG['question_resolved']; ?></span>
          <?php } ?></p></p></div></div>
        <ul class="clsMisNavSubLink">
          <?php if ($this->question_details['user_id'] == $this->CFG['user']['user_id'] and $this->isQuestionOpen())
				{ ?>
          <li><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'answer.php?action=view&qid=' . $this->fields_arr['qid'], $this->CFG['site']['relative_url'] . 'view/answers/' . $this->fields_arr['qid'] . '/', false); ?>" onClick="doActionOnQuestion('resolve', '<?php echo $anchor; ?>', '<?php echo $this->LANG['confirm_resolve_message']; ?>'); return false;"><?php echo $this->LANG['answers_resolve_question']; ?></a></li>
          <?php }
				else
						if ($this->CFG['admin']['abuse_questions']['allowed'] and $this->question_details['user_id'] != $this->CFG['user']['user_id'] and $this->isQuestionOpen())
						{ ?>
          <?php if ($this->CFG['user']['user_id'])
								{ ?>
          	<?php if ($this->chkIsQuestionAbusedAlready($this->fields_arr['qid']))
										{ ?>
          	<li><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'answer.php?action=view&qid=' . $this->fields_arr['qid'], $this->CFG['site']['relative_url'] . 'view/answers/' . $this->fields_arr['qid'] . '/', false); ?>" onClick="return false;"><?php echo $this->LANG['already_abused_question']; ?></a></li>
          	<?php }
										else
										{ ?>
          	<li><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'answer.php?action=view&qid=' . $this->fields_arr['qid'], $this->CFG['site']['relative_url'] . 'view/answers/' . $this->fields_arr['qid'] . '/', false); ?>" onClick="abuseContent('abusequestion', '<?php echo $this->fields_arr['qid']; ?>', '<?php echo $anchor; ?>', '<?php echo $this->LANG['confirm_abuse_question_message']; ?>'); return false;"><?php echo $this->LANG['answers_report_abuse']; ?></a></li>
          	<?php } ?>
          <?php }
								else
								{ ?>
          <li><a href="<?php echo getUrl($this->CFG['site']['url'] . 'members/answer.php?action=view&qid=' . $this->fields_arr['qid'], $this->CFG['site']['url'] . 'members/view/answers/' . $this->fields_arr['qid'] . '/', false); ?>"><?php echo $this->LANG['answers_report_abuse']; ?></a></li>
          <?php } ?>
          <?php } ?>
          <?php if ($this->CFG['admin']['email_to_friend']['allowed'])
				{ ?>
          <?php if ($this->CFG['user']['user_id'])
						{ ?>
          <li> <span><a id="emailToFriends" href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'emailAnswers.php?qid=' . $this->fields_arr['qid'], $this->CFG['site']['relative_url'] . 'email-answers/' . $this->fields_arr['qid'] . '/', false); ?>" class="lWOn" onClick="return false;"><?php echo $this->LANG['answers_email_to_friends']; ?></a> </span></li>
          <?php }
						else
						{ ?>
          <li><a href="<?php echo getUrl($this->CFG['site']['url'] . 'members/answer.php?action=view&qid=' . $this->fields_arr['qid'], $this->CFG['site']['url'] . 'members/view/answers/' . $this->fields_arr['qid'] . '/', false); ?>"><?php echo $this->LANG['answers_email_to_friends']; ?></a></li>
          <?php } ?>
          <?php } ?>
          <?php if ($this->CFG['admin']['favorite']['allowed'])
				{ ?>
          <li id="selShowFavoriteText_Question_<?php echo $this->fields_arr['qid']; ?>">
            <?php if ($this->CFG['user']['user_id'])
						{ ?>
            <?php if ($this->isFavoriteContent($this->fields_arr['qid'], 'Question'))
								{ ?>
            <a class="clsFavourite" href="#" onClick="toggleFavorites('<?php echo $this->CFG['site']['relative_url']; ?>favoriteAnswers.php', 'cid=<?php echo $this->fields_arr['qid']; ?>&ctype=Question', 'selShowFavoriteText_Question_<?php echo $this->fields_arr['qid']; ?>'); return false;"><?php echo $this->LANG['answers_remove_favorites']; ?></a>
            <?php }
								else
								{ ?>
            <a class="clsFavourite" href="#" onClick="toggleFavorites('<?php echo $this->CFG['site']['relative_url']; ?>favoriteAnswers.php', 'cid=<?php echo $this->fields_arr['qid']; ?>&ctype=Question', 'selShowFavoriteText_Question_<?php echo $this->fields_arr['qid']; ?>'); return false;"><?php echo $this->LANG['answers_add_to_favorites']; ?></a>
            <?php } ?>
            <?php }
						else
						{ ?>
            <a class="clsFavourite" href="<?php echo getUrl($this->CFG['site']['url'] . 'members/answer.php?action=view&qid=' . $this->fields_arr['qid'], $this->CFG['site']['url'] . 'members/view/answers/' . $this->fields_arr['qid'] . '/', false); ?>"><?php echo $this->LANG['answers_add_to_favorites']; ?></a>
            <?php } ?>
          </li>
          <?php } ?>
          <?php if ($this->question_details['user_id'] == $this->CFG['user']['user_id'] and $this->isQuestionOpen())
				{ ?>
          <?php if ($this->CFG['admin']['question']['edit'])
						{ ?>
          <li><a href="<?php echo getUrl($this->CFG['site']['url'] . 'members/questions.php?view=ask&cid=' . $this->fields_arr['qid'], $this->CFG['site']['url'] . 'members/answers/ask/' . $this->fields_arr['qid'] . '/', false) ?>"><?php echo $this->LANG['answers_edit_question']; ?></a></li>
          <?php } ?>
          <?php if ($this->CFG['admin']['question']['delete'])
						{ ?>
          <li><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'answer.php?action=view&qid=' . $this->fields_arr['qid'], $this->CFG['site']['relative_url'] . 'view/answers/' . $this->fields_arr['qid'] . '/', false); ?>" onClick="doActionOnQuestion('delete', '<?php echo $anchor; ?>', '<?php echo $this->LANG['confirm_delete_message']; ?>'); return false;"><?php echo $this->LANG['answers_delete_question']; ?></a></li>
          <?php } ?>
          <?php } ?>
		  <?php
				$questionBadgeUrl = getQuestionBadgeUrl($this->fields_arr['qid']);
				if ($questionBadgeUrl)
				{
?>
          <li><a href="<?php echo $_SERVER['REQUEST_URI']; ?>" onclick="Effect.toggle('selQuestionBadgeEmbed', 'BLIND'); return false;"><?php echo $this->LANG['question_badge']; ?></a></li>
			<?php
				}
?>
        </ul>
<?php
				if ($questionBadgeUrl)
				{
						$badgeUrlWithoutScript = getQuestionBadgeUrl($this->fields_arr['qid'], false);
						$badgeUrlWithoutScript .= ($this->CFG['url']['rewrite']) ? ('?content=2') : ('&content=2');
?>
<div id="selQuestionBadgeEmbed" class="block" style="display:none;">
  <?php
?>
  <p class="meta"><?php echo $this->LANG['answers_badge_embed_hint']; ?></p>
  <p>
    <input type="text" class="clsBadgeTextBox" value='<?php echo $questionBadgeUrl; ?>' READONLY onclick="this.select()" />
  </p>
</div>
<?php
				}
?>
        </p>
      </td>
    </tr>
  </table>
</div></div>
<?php if ($this->CFG['admin']['question']['ratings'])
				{ ?>
<div id="selQuestionRatingContent">
<?php
						$question_url = getUrl($this->CFG['site']['url'] . 'members/answer.php?action=view&qid=' . $this->fields_arr['qid'], $this->CFG['site']['url'] . 'members/view/answers/' . $this->fields_arr['qid'] . '/', false);
						$this->getQuestionRatings($this->CFG['db']['tbl']['users_stared_question'], $this->CFG['db']['tbl']['questions'], $this->fields_arr['qid'], $this->question_details['user_id'], $this->CFG['site']['project_path_relative'], $this->CFG['site']['relative_url'], $question_url);
?>
</div>
<?php } ?>
<?php $this->displayBestAnswer(); ?>
<?php
				if ($this->isQuestionOpen())
				{
						if ($this->question_details['user_id'] != $this->CFG['user']['user_id'])
						{
								$onclick_action = '';
								if ($this->CFG['user']['user_id']) $onclick_action = 'onClick="Effect.toggle(\'subAnsPostForm\', \'BLIND\'); return false;"';
								if ($this->question_details['total_answer'])
								{
										$submit_answer_text = $this->LANG['answers_this_question'];
?>
	<div class="clsAnswerQuestion"><span><a href="<?php echo getUrl($this->CFG['site']['url'] . 'members/answer.php?action=reply&qid=' . $this->fields_arr['qid'], $this->CFG['site']['url'] . 'members/reply/answers/' . $this->fields_arr['qid'] . '/', false); ?>" <?php echo $onclick_action; ?>><?php echo $submit_answer_text; ?></a></span></div>
<?php
								}
								else
								{
										$submit_answer_text = $this->LANG['be_the_first_to_answer'];
?>
<div class="clsFirstQuestionAnswer">
    <div class="clsFirstQuestion"><span><a href="<?php echo getUrl($this->CFG['site']['url'] . 'members/answer.php?action=reply&qid=' . $this->fields_arr['qid'], $this->CFG['site']['url'] . 'members/reply/answers/' . $this->fields_arr['qid'] . '/', false); ?>" <?php echo $onclick_action; ?>><?php echo $submit_answer_text; ?></a></span></div>
</div>
<?php
								}
?>
<div id="subAnsPostForm" style="display:none;">
  <?php $this->postAnswersForm('sub'); ?>
</div>
<?php
						}
						else
						{
?>
<div class="clsFirstQuestionAnswer">
    <div class="clsFirstQuestion"><span><a href="#" onclick="return false;"><?php echo $this->LANG['you_cant_answer_your_question']; ?></a></span></div>
</div>
<?php
						}
				}
				else
				{
?>
<div class="clsFirstQuestionAnswer">
    <div class="clsFirstQuestion"><span><a href="<?php echo $_SERVER['REQUEST_URI']; ?>" onclick="return false;"><?php echo $this->LANG['question_resolved_cant_answer']; ?></a></span></div>
</div>
<?php
				}
		}
		public function postAnswersForm($for)
		{
				if (!$this->isAllowedToAsk())
				{
?>
<div id="selMsgAlert">
	<p><?php echo $this->LANG['info_not_allowed_to_ask']; ?></p>
</div>
<?php
						return;
				}
				$style_add_video = '';
				$style_delete_video = 'style="display:none"';
				$style_preview_video = 'style="display:none"';
				$video_preview_url = getUrl('ansPreviewVideo.php', 'ansPreviewVideo.php') . '?pg=Answer_' . $this->getFormField('rid');
?>
<script language="javascript" type="text/javascript">
var videoPreviewUrl = '<?php echo $video_preview_url; ?>';
</script>
<?php
				if ($this->fields_arr['video'] or $this->fields_arr['video_id'])
				{
						$style_delete_video = '';
						$style_preview_video = '';
						$style_add_video = 'style="display:none"';
						if ($this->fields_arr['video_id']) $video_preview_url = getUrl('ansViewVideo.php', 'ansViewVideo.php') . '?pg=Answer_' . $this->getFormField('video_id');
						if ($this->fields_arr['video']) $video_preview_url = getUrl('ansPreviewVideo.php', 'ansPreviewVideo.php') . '?pg=Answer_' . $this->getFormField('video');
				}
				$style_add_audio = '';
				$style_delete_audio = 'style="display:none"';
				$style_preview_audio = 'style="display:none"';
				$audio_preview_url = getUrl('ansPreviewAudio.php', 'ansPreviewAudio.php') . '?pg=Answer_' . $this->getFormField('rid');
?>
<script language="javascript" type="text/javascript">
var audioPreviewUrl = '<?php echo $audio_preview_url; ?>';
</script>
<?php
				if ($this->fields_arr['audio'] or $this->fields_arr['audio_id'])
				{
						$style_delete_audio = '';
						$style_preview_audio = '';
						$style_add_audio = 'style="display:none"';
						if ($this->fields_arr['audio_id']) $audio_preview_url = getUrl('ansViewAudio.php', 'ansViewAudio.php') . '?pg=Answer_' . $this->getFormField('audio_id');
						if ($this->fields_arr['audio']) $audio_preview_url = getUrl('ansPreviewAudio.php', 'ansPreviewAudio.php') . '?pg=Answer_' . $this->getFormField('audio');
				}
?>
<div class="clsReplyAnswers">
  <form name="selFormReplyAnswers" id="selFormReplyAnswers" method="post" action="<?php echo getUrl($this->CFG['site']['url'] . 'members/answer.php?action=reply&qid=' . $this->fields_arr['qid'], $this->CFG['site']['url'] . 'members/reply/answers/' . $this->fields_arr['qid'] . '/', false); ?>" autocomplete="off">
    <?php $this->populateHidden(array('rid', 'video', 'video_id', 'audio', 'audio_id')); ?>
    <table summary="<?php echo $this->LANG['post_your_answers']; ?>">
      <tr>
        <td colspan="2" class="<?php echo $this->getCSSFormFieldCellClass('question'); ?>"><?php echo wordWrapManual($this->question_details['question'], $this->CFG['admin']['question']['line_length']); ?></td>
      </tr>
      <tr>
        <td class="<?php echo $this->getCSSFormLabelCellClass('answer'); ?>"><?php ShowHelpTip('answers'); ?><label for="answer"><?php echo $this->LANG['your_answer']; ?></label></td>
        <td class="<?php echo $this->getCSSFormFieldCellClass('answer'); ?>"><?php echo $this->getFormFieldErrorTip('answer'); ?>
          <textarea name="answer" id="answer" cols="70" rows="5" tabindex="<?php echo $this->getTabIndex(); ?>" maxlength="<?php echo $this->CFG['admin']['answers']['limit']; ?>" tabindex="<?php echo $this->getTabIndex(); ?>" onFocus="updatelength(this);" onKeyUp="updatelength(this);"><?php echo $this->getFormField('answer'); ?></textarea>
          <div><?php echo $this->LANG['answers_total_charaters_entered']; ?> <span id="ss">0  (Limit <?php echo $this->CFG['admin']['answers']['limit']; ?>)</span></div>
		</td>
      </tr>
      <?php if (chkVideoAllowed('answer'))
				{ ?>
      <tr>
        <td class="<?php echo $this->getCSSFormLabelCellClass('video'); ?>"><?php ShowHelpTip('answers_video'); ?><label for="video"><?php echo $this->LANG['answers_add_video_details']; ?></label></td>
        <td class="<?php echo $this->getCSSFormFieldCellClass('video'); ?>"><?php echo $this->getFormFieldErrorTip('video'); ?> <a <?php echo $style_add_video; ?> id="video_add" href="<?php echo getUrl('videoUpload.php', 'videoupload/') . '?rid=' . $this->fields_arr['rid']; ?>" onClick="return openAjaxWindow('video_add', -150, -200);"><?php echo $this->LANG['add_video']; ?></a> <a <?php echo $style_delete_video; ?> id="video_delete" href="<?php echo $_SERVER['REQUEST_URI']; ?>" onClick="return confrimRemove('video', 'video_delete', '<?php echo $this->LANG['are_you_sure_to_delete'] ?>', -100, -500);"><?php echo $this->LANG['delete_video']; ?></a> <a <?php echo $style_preview_video; ?> id="video_preview" href="<?php echo $video_preview_url; ?>" onClick="return openAjaxWindow('video_preview', -150, -200);"><?php echo $this->LANG['preview_video']; ?></a></td>
      </tr>
      <?php } ?>
      <?php if (chkAudioAllowed('answer'))
				{ ?>
      <tr>
        <td class="<?php echo $this->getCSSFormLabelCellClass('audio'); ?>"><?php ShowHelpTip('answers_audio'); ?><label for="audio"><?php echo $this->LANG['answers_add_audio_details']; ?></label></td>
        <td class="<?php echo $this->getCSSFormFieldCellClass('audio'); ?>"><?php echo $this->getFormFieldErrorTip('audio'); ?> <a <?php echo $style_add_audio; ?> id="audio_add" href="<?php echo getUrl('audioUpload.php', 'audioupload/') . '?rid=' . $this->fields_arr['rid'] . 'AUD'; ?>" onClick="return openAjaxWindow('audio_add', -150, -200);"><?php echo $this->LANG['add_audio']; ?></a> <a <?php echo $style_delete_audio; ?> id="audio_delete" href="<?php echo $_SERVER['REQUEST_URI']; ?>" onClick="return confrimRemove('audio', 'audio_delete', '<?php echo $this->LANG['are_you_sure_to_delete'] ?>', -100, -500);"><?php echo $this->LANG['delete_audio']; ?></a> <a <?php echo $style_preview_audio; ?> id="audio_preview" href="<?php echo $audio_preview_url; ?>" onClick="return openAjaxWindow('audio_preview', -150, -100);"><?php echo $this->LANG['preview_audio']; ?></a></td>
      </tr>
      <?php } ?>
      <?php if ($this->CFG['admin']['answers']['source'])
				{ ?>
      <tr>
        <td class="<?php echo $this->getCSSFormLabelCellClass('source'); ?>"><?php ShowHelpTip('answers_source'); ?><label for="source"><?php echo $this->LANG['know_your_source_list_it_here']; ?></label></td>
        <td class="<?php echo $this->getCSSFormFieldCellClass('source'); ?>"><?php echo $this->getFormFieldErrorTip('source'); ?>
          <textarea name="source" id="source" cols="70" rows="5" tabindex="<?php echo $this->getTabIndex(); ?>"><?php echo $this->getFormField('source'); ?></textarea>
        </td>
      </tr>
      <?php } ?>
      <tr>
        <td class="<?php echo $this->getCSSFormFieldCellClass('submit'); ?>" colspan="2"><?php
				if ($this->fields_arr['aid'])
				{
?>
          <input type="submit" class="clsSubmitButton clsMediumSubmitButton" name="update_answer" id="update_answer" tabindex="<?php echo $this->getTabIndex(); ?>" value="<?php echo $this->LANG['answers_update_yours']; ?>" />
          <?php
				}
				else
				{
?>
          <input type="submit" class="clsSubmitButton clsMediumSubmitButton" name="submit" id="submit" tabindex="<?php echo $this->getTabIndex(); ?>" value="<?php echo $this->LANG['answers_submit_yours']; ?>" />
          <?php
				}
				if ($for == 'main')
				{
?>
          &nbsp;&nbsp;
          <input type="submit" class="clsCancelButton" name="cancel" id="cancel" tabindex="<?php echo $this->getTabIndex(); ?>" value="<?php echo $this->LANG['answers_cancel_question']; ?>" />
          <?php
				}
				else
				{
?>
          &nbsp;&nbsp;
          <input type="button" class="clsCancelButton" name="cancel" id="cancel" tabindex="<?php echo $this->getTabIndex(); ?>" value="<?php echo $this->LANG['answers_cancel_question']; ?>" onClick="Effect.toggle('subAnsPostForm', 'BLIND'); return false;" />
          <?php
				}
?>
        </td>
      </tr>
    </table>
    <input type="hidden" name="aid" value="<?php echo $this->fields_arr['aid']; ?>" />
  </form>
</div>
<?php
		}
		public function buildConditionQuery()
		{
				$this->sql_condition = 'a.user_id=u.' . $this->getUserTableField('user_id') . ' AND u.' . $this->getUserTableField('usr_status') . '=\'Ok\'';
				$this->sql_condition .= ' AND a.ques_id=\'' . addslashes($this->fields_arr['qid']) . '\' AND a.ans_id!=\'' . addslashes($this->question_details['best_ans_id']) . '\'';
				if ($this->CFG['admin']['ignore_user'])
				{
						$this->sql_condition .= ' AND NOT EXISTS (SELECT 1 FROM ' . $this->CFG['db']['tbl']['user_ignored'] . ' AS ui WHERE ui.user_id=' . $this->CFG['user']['user_id'] . ' AND ui.ignored_id=a.user_id)';
				}
		}
		public function buildSortQuery()
		{
				$this->sql_sort = $this->fields_arr['orderby_field'] . ' ' . $this->fields_arr['orderby'];
		}
		public function displayAllAnswers()
		{
				if (!$this->isResultsFound())
				{
?>
<div id="selMsgAlert">
  <p><?php echo $this->LANG['answers_not_added']; ?></p>
</div>
<?php
						return;
				}
?>
<div class="clsPagingCollapse">
<?php if ($this->CFG['comments']['expand_collapse'])
				{ ?>
<span class="expand-all" onclick="toggleExpandAnswers();"></span>
<script type="text/javascript" language="javascript">
	var commentsArray = new Array();
</script>
<?php } ?>
</div>
<div class="clsUsersAnswers">
<h3>Answers</h3>
<table class="clsDataTable" summary="<?php echo $this->LANG['answers_details_tbl']; ?>">
  <?php
				$id_cnt = $this->fields_arr['start'];
				$i = 0;
				while ($row = $this->fetchResultRecord())
				{
						$i++;
						$clsOddOrEvenQuestion = 'clsEvenQuestion';
						if ($i % 2) $clsOddOrEvenQuestion = 'clsOddQuestion';
						$anchor = 'abuseAnswer' . $row['ans_id'];
						$ansId = $row['ans_id'];
?>
<?php if ($this->CFG['comments']['expand_collapse'])
						{ ?>
<script type="text/javascript" language="javascript">
	commentsArray['<?php echo $i; ?>'] = '<?php echo $ansId; ?>';
</script>
<?php } ?>
<tr>
 <td>
  <div><!-- answers div start-->

	<?php if ($this->CFG['comments']['expand_collapse'])
						{ ?>
	<span id="icon<?php echo $ansId; ?>" class="collapse expand" onclick="toggleAnswer(this, '<?php echo $ansId; ?>');"></span>
	<?php } ?>

	<!-- answermore div start-->
    <div id="answermore<?php echo $ansId; ?>">
		<div class="<?php echo $clsOddOrEvenQuestion; ?> clsUserThumbDetails">
			<?php if (chkUserImageAllowed())
						{ ?>
			<div id="answeruser<?php echo $ansId; ?>" class="clsUserThumb"><?php displayUserImage($row, 'small'); ?></div>
			<?php } ?>
     		<div class="clsUserDetails">
				<div class="clsAnswers">
        			<p><?php echo nl2br(wordWrapManual($row['answer'], $this->CFG['admin']['answer']['line_length'])); ?></p>
			        <?php if (chkVideoAllowed('answer') and $row['video_id'])
						{ ?>
			        <span><a id="video_add_<?php echo $ansId; ?>" href="<?php echo getUrl('ansViewVideo.php', 'ansViewVideo.php'); ?>?pg=Answer_<?php echo $row['video_id']; ?>" onClick="return openAjaxWindow('video_add_<?php echo $ansId; ?>', -150, -200);"><img src="<?php echo $this->CFG['site']['url'] . 'images/icon-video.png' ?>" alt="<?php echo $this->LANG['questions_video_available']; ?>" /></a></span>
			        <?php } ?>
			        <?php if (chkAudioAllowed('answer') and $row['audio_id'])
						{ ?>
			        <span><a id="audio_add_<?php echo $ansId; ?>" href="<?php echo getUrl('ansViewAudio.php', 'ansViewAudio.php'); ?>?pg=Answer_<?php echo $row['audio_id']; ?>" onClick="return openAjaxWindow('audio_add_<?php echo $ansId; ?>', -150, -100);"><img src="<?php echo $this->CFG['site']['url'] . 'images/icon-audio.png' ?>" alt="<?php echo $this->LANG['questions_audio_available']; ?>" /></a></span>
			        <?php } ?>
			        <?php if ($row['source'])
						{ ?>
			        <p><?php echo $this->LANG['answers_sources']; ?>:</p>
			        <p><?php echo nl2br(wordWrapManual($row['source'], $this->CFG['admin']['answer']['line_length'])); ?></p>
			        <?php } ?>
        			<p>
					<a href="<?php echo $_SERVER['REQUEST_URI']; ?>" id="<?php echo $anchor; ?>"></a>
					<span class="clsForumAuthor clsNoBorder"><?php echo $this->LANG['answers_answered_by']; ?> <a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'myanswers.php?uid=' . $row['user_id'], $this->CFG['site']['relative_url'] . 'my/answers/' . $row['user_id'] . '/', false); ?>"><?php echo stripString($row['answered_by'], $this->CFG['username']['short_length']); ?></a></span> <span><?php echo getTimeDiffernceFormat($row['date_answered']); ?></span>
		          	<?php if ($this->CFG['admin']['abuse_answers']['allowed'] and $this->CFG['user']['user_id'] != $row['user_id'] and $this->isQuestionOpen())
						{ ?>
			          	<?php if ($this->CFG['user']['user_id'])
								{ ?>
				          	<?php if ($this->chkIsAnswerAbusedAlready($ansId))
										{ ?>
				          	<span><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'answer.php?action=view&qid=' . $this->fields_arr['qid'], $this->CFG['site']['relative_url'] . 'view/answers/' . $this->fields_arr['qid'] . '/', false); ?>" onClick="return false;"><?php echo $this->LANG['already_abused_answer']; ?></a></span>
				          	<?php }
										else
										{ ?>
							<span><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'answer.php?action=view&qid=' . $this->fields_arr['qid'], $this->CFG['site']['relative_url'] . 'view/answers/' . $this->fields_arr['qid'] . '/', false); ?>" onClick="abuseContent('abuseanswer', '<?php echo $row['ans_id']; ?>', '<?php echo $anchor; ?>', '<?php echo $this->LANG['confirm_abuse_answer_message']; ?>'); return false;"><?php echo $this->LANG['answers_report_abuse']; ?></a></span>
							<?php } ?>
			          	<?php }
								else
								{ ?>
			          	<span><a href="<?php echo getUrl($this->CFG['site']['url'] . 'members/answer.php?action=view&qid=' . $this->fields_arr['qid'], $this->CFG['site']['url'] . 'members/view/answers/' . $this->fields_arr['qid'] . '/', false); ?>"><?php echo $this->LANG['answers_report_abuse']; ?></a></span>
			          	<?php } ?>
		          	<?php } ?>
          			<?php if ($this->CFG['admin']['best_answers']['allowed'] and $this->CFG['user']['user_id'] == $this->question_details['user_id'] and $this->isQuestionOpen() and $this->question_details['best_ans_id'] == 0)
						{ ?>
          			<span><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'answer.php?action=view&qid=' . $this->fields_arr['qid'], $this->CFG['site']['relative_url'] . 'view/answers/' . $this->fields_arr['qid'] . '/', false); ?>"  onClick="doActionOnAnswer('bestanswers', '<?php echo $anchor; ?>', '<?php echo $this->LANG['best_answer_confirm_message']; ?>', '<?php echo $row['ans_id']; ?>'); return false;"><?php echo $this->LANG['answers_best_answer']; ?></a></span>
          			<?php } ?>
          			<?php if ($row['user_id'] == $this->CFG['user']['user_id'] and $this->isQuestionOpen())
						{ ?>
          				<?php if ($this->CFG['admin']['answer']['edit'])
								{ ?>
        				<li><a href="<?php echo getUrl($this->CFG['site']['url'] . 'members/answer.php?action=edit&qid=' . $this->fields_arr['qid'] . '&aid=' . $row['ans_id'], $this->CFG['site']['url'] . 'members/edit/answers/' . $this->fields_arr['qid'] . '/' . $row['ans_id'] . '/', false) ?>"><?php echo $this->LANG['answers_edit_question']; ?></a></li>
        				<?php } ?>
        				<?php if ($this->CFG['admin']['answer']['delete'])
								{ ?>
        				<li><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'answer.php?qid=' . $this->fields_arr['qid'], $this->CFG['site']['relative_url'] . 'view/answers/' . $this->fields_arr['qid'] . '/', false); ?>" onClick="doActionOnAnswer('deleteanswer', '<?php echo $anchor; ?>', '<?php echo $this->LANG['confirm_delete_message_answer']; ?>', '<?php echo $row['ans_id']; ?>'); return false;"><?php echo $this->LANG['answers_delete_question']; ?></a></li>
        				<?php } ?>
        			<?php } ?>
       				</p>
				</div>
			</div>
		</div>
	    <?php if ($this->CFG['admin']['answer']['ratings'])
						{ ?>
	    <div id="answerrating<?php echo $ansId; ?>">
		    <div class="clsAnswersRate" id="selAnswersRatingContent<?php echo $id_cnt; ?>">
				<?php
								$question_url = getUrl($this->CFG['site']['url'] . 'members/answer.php?action=view&qid=' . $this->fields_arr['qid'], $this->CFG['site']['url'] . 'members/view/answers/' . $this->fields_arr['qid'] . '/', false);
								$this->getAnswersRatings($this->CFG['db']['tbl']['users_stared_answer'], $this->CFG['db']['tbl']['answers'], $row['ans_id'], $row['user_id'], $this->CFG['site']['project_path_relative'], $this->CFG['site']['relative_url'], $id_cnt, $question_url);
								$id_cnt += 4;
?>
		    </div>
	    </div>
	    <?php } ?>
    </div><!-- answermore div end-->

    <!-- answerless div start-->
	<div id="answerless<?php echo $ansId; ?>" style="display:none;">
		<div class="<?php echo $clsOddOrEvenQuestion; ?> clsUserThumbDetails">
			<div class="clsUserDetails">
				<div class="clsAnswers">
					<p><span class="clsForumAuthor clsNoBorder"><?php echo $this->LANG['answers_answered_by']; ?> <a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'myanswers.php?uid=' . $row['user_id'], $this->CFG['site']['relative_url'] . 'my/answers/' . $row['user_id'] . '/', false); ?>"><?php echo $row['answered_by']; ?></a></span> <span><?php echo getTimeDiffernceFormat($row['date_answered']); ?></span></p>
				</div>
			</div>
		</div>
	</div><!-- answerless div end-->

  </div><!-- answers div end-->
 </td>
</tr>
<?php
				}


?>
</table></div>
<?php
				if ($this->CFG['url']['rewrite']) $pagingArr = array();
				else  $pagingArr = array('qid');
				if ($this->CFG['admin']['navigation']['bottom']) $this->populatePageLinks($this->getFormField('start'), $pagingArr);
		}
		public function abuseQuestion()
		{
?>
<div class="clsAbuseQuestions">
  <form name="selFormAbuseQuestions" id="selFormAbuseQuestions" method="post" action="<?php echo URL($_SERVER['REQUEST_URI']); ?>">
    <table summary="<?php echo $this->LANG['abuse_answers']; ?>">
      <tr>
        <td class="<?php echo $this->getCSSFormLabelCellClass('reported'); ?>"><?php echo $this->LANG['answers_reported_by']; ?></td>
        <td class="<?php echo $this->getCSSFormFieldCellClass('reported'); ?>"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'myanswers.php', $this->CFG['site']['relative_url'] . 'my/answers/', false); ?>"><?php echo $this->CFG['user']['name']; ?></a></td>
      </tr>
      <tr>
        <td class="<?php echo $this->getCSSFormLabelCellClass('Question'); ?>"><?php echo $this->LANG['answers_question']; ?></td>
        <td class="<?php echo $this->getCSSFormFieldCellClass('Question'); ?>"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'answer.php?qid=' . $this->fields_arr['qid'], $this->CFG['site']['relative_url'] . 'view/answers/' . $this->fields_arr['qid'] . '/', false); ?>"><?php echo wordWrapManual($this->question_details['question'], $this->CFG['admin']['question']['line_length']); ?></a></td>
      </tr>
      <tr>
        <td class="<?php echo $this->getCSSFormLabelCellClass('reason'); ?>"><label for="reason"><?php echo $this->LANG['answers_reason']; ?></label></td>
        <td class="<?php echo $this->getCSSFormFieldCellClass('reason'); ?>"><?php echo $this->getFormFieldErrorTip('reason'); ?>
          <textarea name="reason" id="reason" cols="70" rows="5" tabindex="<?php echo $this->getTabIndex(); ?>"><?php echo $this->getFormField('reason'); ?></textarea>
        </td>
      </tr>
      <tr>
        <td class="<?php echo $this->getCSSFormFieldCellClass('abuse_question'); ?>" colspan="2"><input type="submit" class="clsSubmitButton" name="abuse_question" id="abuse_question" tabindex="<?php echo $this->getTabIndex(); ?>" value="<?php echo $this->LANG['answers_submit_question']; ?>" />
          &nbsp;&nbsp;
          <input type="submit" class="clsSubmitButton" name="cancel" id="cancel" tabindex="<?php echo $this->getTabIndex(); ?>" value="<?php echo $this->LANG['answers_cancel_question']; ?>" />
        </td>
      </tr>
    </table>
  </form>
</div>
<?php
		}
		public function abuseAnswer()
		{
?>
<div class="clsAbuseAnswers">
  <form name="selFormAbuseAnswers" id="selFormAbuseAnswers" method="post" action="<?php echo URL($_SERVER['REQUEST_URI']); ?>">
    <table summary="<?php echo $this->LANG['abuse_answers']; ?>">
      <tr>
        <td class="<?php echo $this->getCSSFormLabelCellClass('reported'); ?>"><?php echo $this->LANG['answers_reported_by']; ?></td>
        <td class="<?php echo $this->getCSSFormFieldCellClass('reported'); ?>"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'myanswers.php', $this->CFG['site']['relative_url'] . 'my/answers/', false); ?>"><?php echo $this->CFG['user']['name']; ?></a></td>
      </tr>
      <tr>
        <td class="<?php echo $this->getCSSFormLabelCellClass('Question'); ?>"><?php echo $this->LANG['answers_question']; ?></td>
        <td class="<?php echo $this->getCSSFormFieldCellClass('Question'); ?>"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'answer.php?qid=' . $this->fields_arr['qid'], $this->CFG['site']['relative_url'] . 'view/answers/' . $this->fields_arr['qid'] . '/', false); ?>"><?php echo wordWrapManual($this->question_details['question'], $this->CFG['admin']['question']['line_length']); ?></a></td>
      </tr>
      <tr>
        <td class="<?php echo $this->getCSSFormLabelCellClass('Answer'); ?>"><?php echo $this->LANG['answers_answer']; ?></td>
        <td class="<?php echo $this->getCSSFormFieldCellClass('Answer'); ?>"><?php echo nl2br(wordWrapManual($this->answer_details['answer'], $this->CFG['admin']['answer']['line_length'])); ?></td>
      </tr>
      <tr>
        <td class="<?php echo $this->getCSSFormLabelCellClass('reason'); ?>"><label for="reason"><?php echo $this->LANG['answers_reason']; ?></label></td>
        <td class="<?php echo $this->getCSSFormFieldCellClass('reason'); ?>"><?php echo $this->getFormFieldErrorTip('reason'); ?>
          <textarea name="reason" id="reason" cols="70" rows="5" tabindex="<?php echo $this->getTabIndex(); ?>"><?php echo $this->getFormField('reason'); ?></textarea>
        </td>
      </tr>
      <tr>
        <td class="<?php echo $this->getCSSFormFieldCellClass('abuse_answer'); ?>" colspan="2"><input type="submit" class="clsSubmitButton" name="abuse_answer" id="abuse_answer" tabindex="<?php echo $this->getTabIndex(); ?>" value="<?php echo $this->LANG['answers_submit_question']; ?>" />
          &nbsp;&nbsp;
          <input type="submit" class="clsSubmitButton" name="cancel" id="cancel" tabindex="<?php echo $this->getTabIndex(); ?>" value="<?php echo $this->LANG['answers_cancel_question']; ?>" />
        </td>
      </tr>
    </table>
  </form>
</div>
<?php
		}
		public function displayConfirmOption()
		{
?>
<div id="selMsgConfirm">
  <form name="selFormConfirm" id="selFormConfirm" method="post" action="<?php echo URL(getUrl($this->CFG['site']['relative_url'] . 'answer.php?qid=' . $this->fields_arr['qid'], $this->CFG['site']['relative_url'] . 'view/answers/' . $this->fields_arr['qid'] . '/', false)); ?>">
    <p><?php echo $this->LANG['confirm_resolve_message']; ?></p>
    <table summary="<?php echo $this->LANG['confirm_tbl_summary']; ?>" border="1">
      <tr>
        <td><input type="submit" class="clsSubmitButton" name="resolve_question" id="resolve_question" tabindex="<?php echo $this->getTabIndex(); ?>" value="<?php echo $this->LANG['member_yes']; ?>" />
        </td>
        <td><input type="submit" class="clsSubmitButton" name="cancel" id="cancel" tabindex="<?php echo $this->getTabIndex(); ?>" value="<?php echo $this->LANG['member_no']; ?>"  />
        </td>
      </tr>
    </table>
  </form>
</div>
<?php
		}
		public function bestAnswerConfirm()
		{
?>
<div id="selMsgConfirm">
  <form name="selFormConfirm" id="selFormConfirm" method="post" action="<?php echo URL(getUrl($this->CFG['site']['relative_url'] . 'answer.php?qid=' . $this->fields_arr['qid'], $this->CFG['site']['relative_url'] . 'view/answers/' . $this->fields_arr['qid'] . '/', false)); ?>">
    <p><?php echo $this->LANG['best_answer_confirm_message']; ?></p>
    <table summary="<?php echo $this->LANG['confirm_tbl_summary']; ?>" border="1">
      <tr>
        <td><input type="submit" class="clsSubmitButton" name="best_answers" id="best_answers" tabindex="<?php echo $this->getTabIndex(); ?>" value="<?php echo $this->LANG['member_yes']; ?>" />
        </td>
        <td><input type="submit" class="clsSubmitButton" name="cancel" id="cancel" tabindex="<?php echo $this->getTabIndex(); ?>" value="<?php echo $this->LANG['member_no']; ?>"  />
        </td>
      </tr>
    </table>
    <input type="hidden" name="aid" value="<?php echo $this->fields_arr['aid']; ?>" />
  </form>
</div>
<?php
		}
		public function updateAbuseQuestion()
		{
				$sql = 'SELECT abuse_id FROM ' . $this->CFG['db']['tbl']['abuse_questions'] . ' WHERE ques_id=' . $this->dbObj->Param('qid') . ' AND reported_by=' . $this->dbObj->Param('rid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['qid'], $this->CFG['user']['user_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if (!$rs->PO_RecordCount())
				{
						$sql = 'INSERT INTO ' . $this->CFG['db']['tbl']['abuse_questions'] . ' SET ques_id=' . $this->dbObj->Param('qid') . ', reported_by=' . $this->dbObj->Param('rid') . ', reason=' . $this->dbObj->Param('reason') . ', date_abused=NOW()';
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['qid'], $this->CFG['user']['user_id'], $this->fields_arr['reason']));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
						if ($this->dbObj->Affected_Rows())
						{
								$this->updateQuestionAbuseCount();
								$this->updateAbuseUserPoints($this->CFG['admin']['abuse_questions_points']['allowed'], $this->question_details['user_id'], $this->CFG['admin']['abuse_questions']['points']);
								$this->sendAbuseMailToAsker();
						}
				}
		}
		public function updateQuestionAbuseCount()
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['questions'] . ' SET abuse_count=abuse_count+1' . ' WHERE ques_id=' . $this->dbObj->Param('qid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['qid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function updateAbuseAnswer()
		{
				$sql = 'SELECT abuse_id FROM ' . $this->CFG['db']['tbl']['abuse_answers'] . ' WHERE ans_id=' . $this->dbObj->Param('aid') . ' AND reported_by=' . $this->dbObj->Param('uid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['aid'], $this->CFG['user']['user_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if (!$rs->PO_RecordCount())
				{
						$sql = 'INSERT INTO ' . $this->CFG['db']['tbl']['abuse_answers'] . ' SET ques_id=' . $this->dbObj->Param('qid') . ', ans_id=' . $this->dbObj->Param('aid') . ', reported_by=' . $this->dbObj->Param('uid') . ', reason=' . $this->dbObj->Param('reason') . ', date_abused=NOW()';
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['qid'], $this->fields_arr['aid'], $this->CFG['user']['user_id'], $this->fields_arr['reason']));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
						if ($this->dbObj->Affected_Rows())
						{
								$this->updateAnswerAbuseCount();
								$this->updateAbuseUserPoints($this->CFG['admin']['abuse_answers_points']['allowed'], $this->answer_details['user_id'], $this->CFG['admin']['abuse_answers']['points']);
								$this->sendAbuseMailToAnswerer();
						}
				}
		}
		public function updateAnswerAbuseCount()
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['answers'] . ' SET abuse_count=abuse_count+1' . ' WHERE ans_id=' . $this->dbObj->Param('aid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['aid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function updateAbuseUserPoints($config_abuse, $uid, $points)
		{
				if (!$config_abuse or $points == 0 or !isset($this->CFG['user']['user_id']) or empty($this->CFG['user']['user_id'])) return;
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['users_ans_log'] . ' SET total_points=total_points+' . $points . ', date_updated=NOW()' . ' WHERE user_id=' . $this->dbObj->Param('uid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($uid));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return;
		}
		public function updateBestAnswer()
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['questions'] . ' SET best_ans_id=' . $this->dbObj->Param('aid') . ' WHERE ques_id=' . $this->dbObj->Param('qid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['aid'], $this->fields_arr['qid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($this->dbObj->Affected_Rows()) $this->sendMailToAnswerer();
		}
		public function resolveQuestion()
		{
				if ($this->isQuestionOpen())
				{
						$sql = 'UPDATE ' . $this->CFG['db']['tbl']['questions'] . ' SET status=\'Resolved\'' . ' WHERE user_id=' . $this->dbObj->Param('uid') . ' AND ques_id=' . $this->dbObj->Param('qid');
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($this->CFG['user']['user_id'], $this->fields_arr['qid']));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				}
				return;
		}
		public function deleteQuestion()
		{
				$this->updateQuestionVideoStatus($this->question_details['video_id']);
				$this->updateQuesitionAudioStatus($this->question_details['audio_id']);
				$sql = 'DELETE FROM ' . $this->CFG['db']['tbl']['questions'] . ' WHERE ques_id=' . $this->dbObj->Param('qid') . ' AND user_id=' . $this->dbObj->Param('uid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['qid'], $this->CFG['user']['user_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$sql = 'SELECT video_id, audio_id FROM ' . $this->CFG['db']['tbl']['answers'] . ' WHERE ques_id=' . $this->dbObj->Param('qid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['qid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount())
				{
						while ($row = $rs->FetchRow())
						{
								$this->updateAnswerVideoStatus($row['video_id']);
								$this->updateAnswerAudioStatus($row['audio_id']);
						}
				}
				$sql = 'DELETE FROM ' . $this->CFG['db']['tbl']['answers'] . ' WHERE ques_id=' . $this->dbObj->Param('qid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['qid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$pcat_id = $this->question_details['pcat_id'];
				$cat_id = $this->question_details['cat_id'];
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['questions_category'] . ' SET total_questions=total_questions-1' . ' WHERE cat_id=' . $this->dbObj->Param($pcat_id) . ' OR cat_id=' . $this->dbObj->Param($cat_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($pcat_id, $cat_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['users_ans_log'] . ' SET total_ques=total_ques-1' . ', total_points=total_points-' . $this->CFG['admin']['ask_answers']['points'] . ' WHERE user_id=' . $this->dbObj->Param('uid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->CFG['user']['user_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function updateAnswer()
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['answers'] . ' SET answer=' . $this->dbObj->Param('answer') . ', source=' . $this->dbObj->Param('source') . ', video_id=' . $this->dbObj->Param('video_id') . ', audio_id=' . $this->dbObj->Param('audio_id') . ' WHERE user_id=' . $this->dbObj->Param('uid') . ' AND ques_id=' . $this->dbObj->Param('qid') . ' AND ans_id=' . $this->dbObj->Param('aid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['answer'], $this->fields_arr['source'], $this->fields_arr['video_id'], $this->fields_arr['audio_id'], $this->CFG['user']['user_id'], $this->fields_arr['qid'], $this->fields_arr['aid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($this->fields_arr['video'] or ($this->fields_arr['video_id'] == 0))
				{
						$sql = 'UPDATE ' . $this->CFG['db']['tbl']['ans_video'] . ' SET' . ' video_status=\'Deleted\' WHERE' . ' content_id=' . $this->dbObj->Param('content_id') . ' AND' . ' video_for=\'Answer\'';
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['aid']));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
						if ($this->dbObj->Affected_Rows())
						{
								$sql = 'UPDATE ' . $this->CFG['db']['tbl']['questions'] . ' SET' . ' total_videos=total_videos-1 WHERE' . ' ques_id=' . $this->dbObj->Param('ques_id') . ' AND total_videos>0';
								$stmt = $this->dbObj->Prepare($sql);
								$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['qid']));
								if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
						}
				}
				if ($this->fields_arr['audio'] or ($this->fields_arr['audio_id'] == 0))
				{
						$sql = 'UPDATE ' . $this->CFG['db']['tbl']['ans_audio'] . ' SET' . ' audio_status=\'Deleted\' WHERE' . ' content_id=' . $this->dbObj->Param('content_id') . ' AND' . ' audio_for=\'Answer\'';
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['aid']));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
						if ($this->dbObj->Affected_Rows())
						{
								$sql = 'UPDATE ' . $this->CFG['db']['tbl']['questions'] . ' SET' . ' total_audios=total_audios-1 WHERE' . ' ques_id=' . $this->dbObj->Param('ques_id') . ' AND total_audios>0';
								$stmt = $this->dbObj->Prepare($sql);
								$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['qid']));
								if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
						}
				}
				$this->fields_arr['content_id'] = $this->fields_arr['aid'];
				$this->addNewVideo();
				$this->addNewAudio();
				return;
		}
		public function addAnswer()
		{
				if ($this->isQuestionOpen())
				{
						$this->fields_arr['content_id'] = $this->insertAnswer();
						$this->updateQuestion();
						$this->updateUserAnswerLog();
						$this->addNewVideo();
						$this->addNewAudio();
						$this->sendMailToAsker();
				}
		}
		public function insertAnsVideoTable()
		{
				$sql = 'INSERT INTO ' . $this->CFG['db']['tbl']['ans_video'] . ' SET' . ' content_id=' . $this->dbObj->Param('content_id') . ',' . ' user_id=' . $this->dbObj->Param('user_id') . ',' . ' video_for=\'Answer\',' . ' video_ext=\'flv\',' . ' date_added=NOW(),' . ' video_encoded_status=\'Partial\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['content_id'], $this->CFG['user']['user_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return $this->dbObj->Insert_ID();
		}
		public function addNewVideo()
		{
				if ($this->fields_arr['video'])
				{
						$this->fields_arr['video_id'] = $this->insertAnsVideoTable();
						if ($this->fp)
						{
								$log_str = 'Video Record created : ' . $this->fields_arr['video_id'] . "\r\n";
								$this->writetoTempFile($log_str);
						}
						$video_name = getImageName($this->fields_arr['video_id']);
						$temp_dir = '../' . $this->CFG['admin']['ans_videos']['temp_folder'];
						$this->chkAndCreateFolder($temp_dir);
						$temp_file = $temp_dir . $video_name . '.flv';
						$file_name = $this->CFG['admin']['video']['red5_flv_path'] . $this->fields_arr['rid'] . '.flv';
						copy($file_name, $temp_file);
						unlink($file_name);
						if ($this->fp)
						{
								$log_str = 'Video stored in temp server : ' . $temp_file . "\r\n";
								$this->writetoTempFile($log_str);
						}
						$this->changeAnsVideoStatus($this->fields_arr['video_id'], 'No');
						if ($this->CFG['admin']['ans_videos']['video_auto_encode'])
						{
								if ($this->fp)
								{
										$log_str = 'Calling Video Encode \r\n';
										$this->writetoTempFile($log_str);
								}
								$this->videoEncode($this->fields_arr['video_id']);
						}
						$temp_dir = '../' . $this->CFG['admin']['ans_videos']['temp_folder'];
						$temp_file = $temp_dir . $this->fields_arr['rid'] . '.flv';
						if (file_exists($temp_file)) unlink($temp_file);
				}
		}
		public function insertAnsAudioTable()
		{
				$sql = 'INSERT INTO ' . $this->CFG['db']['tbl']['ans_audio'] . ' SET' . ' content_id=' . $this->dbObj->Param('content_id') . ',' . ' user_id=' . $this->dbObj->Param('user_id') . ',' . ' audio_for=\'Answer\',' . ' audio_ext=\'flv\',' . ' date_added=NOW(),' . ' audio_encoded_status=\'Partial\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['content_id'], $this->CFG['user']['user_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return $this->dbObj->Insert_ID();
		}
		public function addNewAudio()
		{
				if ($this->fields_arr['audio'])
				{
						$this->fields_arr['audio_id'] = $this->insertAnsAudioTable();
						if ($this->fp)
						{
								$log_str = 'Audio Record created : ' . $this->fields_arr['audio_id'] . "\r\n";
								$this->writetoTempFile($log_str);
						}
						$audio_name = getImageName($this->fields_arr['audio_id']);
						$temp_dir = '../' . $this->CFG['admin']['ans_audios']['temp_folder'];
						$this->chkAndCreateFolder($temp_dir);
						$temp_file = $temp_dir . $audio_name . '.flv';
						$file_name = $this->CFG['admin']['video']['red5_flv_path'] . $this->fields_arr['rid'] . 'AUD.flv';
						copy($file_name, $temp_file);
						unlink($file_name);
						if ($this->fp)
						{
								$log_str = 'Audio stored in temp server : ' . $temp_file . "\r\n";
								$this->writetoTempFile($log_str);
						}
						$this->changeAnsAudioStatus($this->fields_arr['audio_id'], 'No');
						if ($this->CFG['admin']['ans_audios']['audio_auto_encode'])
						{
								if ($this->fp)
								{
										$log_str = 'Calling Audio Encode \r\n';
										$this->writetoTempFile($log_str);
								}
								$this->audioEncode($this->fields_arr['audio_id']);
						}
						$temp_dir = '../' . $this->CFG['admin']['ans_audios']['temp_folder'];
						$temp_file = $temp_dir . $this->fields_arr['rid'] . 'AUD.flv';
						if (file_exists($temp_file)) unlink($temp_file);
				}
		}
		public function insertAnswer()
		{
				$sql = 'INSERT INTO ' . $this->CFG['db']['tbl']['answers'] . ' SET user_id=' . $this->dbObj->Param('uid') . ', ques_id=' . $this->dbObj->Param('qid') . ', answer=' . $this->dbObj->Param('answer') . ', source=' . $this->dbObj->Param('source') . ', date_answered=NOW()';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->CFG['user']['user_id'], $this->fields_arr['qid'], $this->fields_arr['answer'], $this->fields_arr['source']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return $this->dbObj->Insert_ID();
		}
		public function updateQuestion()
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['questions'] . ' SET total_answer=total_answer+1' . ', email_sent=\'No\', date_answered=NOW()' . ' WHERE ques_id=' . $this->dbObj->Param('qid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['qid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function updateUserAnswerLog()
		{
				if (!$this->CFG['admin']['reply_answers']['allowed']) return;
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['users_ans_log'] . ' SET total_ans=total_ans+1' . ', total_points=total_points+' . $this->CFG['admin']['reply_answers']['points'] . ', date_updated=NOW()' . ' WHERE user_id=' . $this->dbObj->Param('uid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->CFG['user']['user_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function sendMailToAsker()
		{
				if ($this->question_details['user_id'] == $this->CFG['user']['user_id']) return;
				$email_options = $this->getEmailOptionsOfUser($this->question_details['user_id']);
				if ($email_options['reply_mail'] == 'Yes')
				{
						$asker_details = $this->getUserDetailsFromUsersTable($this->CFG['db']['tbl']['users'], $this->question_details['user_id']);
						$answers_reply_subject = str_replace('{username}', $asker_details['name'], $this->LANG['answers_reply_email_subject']);
						$answers_reply_subject = str_replace('{sender name}', $this->CFG['user']['name'], $answers_reply_subject);
						$answers_reply_content = str_replace('{username}', '<a href="' . getUrl($this->CFG['site']['url'] . 'myanswers.php?uid=' . $this->question_details['user_id'], $this->CFG['site']['url'] . 'my/answers/' . $this->question_details['user_id'] . '/', false) . '">' . $asker_details['name'] . '</a>', $this->LANG['answers_reply_email_content']);
						$sender_name = '<a href="' . getUrl($this->CFG['site']['url'] . 'myanswers.php?uid=' . $this->CFG['user']['user_id'], $this->CFG['site']['url'] . 'my/answers/' . $this->CFG['user']['user_id'] . '/', false) . '">' . $this->CFG['user']['name'] . '</a>';
						$answers_reply_content = str_replace('{sender name}', $sender_name, $answers_reply_content);
						$answers_reply_content = str_replace('{sitename}', $this->CFG['site']['name'], $answers_reply_content);
						$answers_reply_content = str_replace('{question asked}', '<strong>' . $this->question_details['question'] . '</strong>', $answers_reply_content);
						$answers_reply_content = str_replace('{question reply}', nl2br($this->fields_arr['answer']), $answers_reply_content);
						$question_link = getUrl($this->CFG['site']['url'] . 'answer.php?qid=' . $this->fields_arr['qid'] . '/', $this->CFG['site']['url'] . 'view/answers/' . $this->fields_arr['qid'] . '/', false);
						$answers_reply_content = str_replace('{link}', '<a href="' . $question_link . '">' . $question_link . '</a>', $answers_reply_content);
						$this->_sendMail($asker_details['email'], $answers_reply_subject, nl2br($answers_reply_content), $this->CFG['site']['noreply_name'], $this->CFG['site']['noreply_email']);
				}
		}
		public function sendMailToAnswerer()
		{
				if ($this->question_details['user_id'] != $this->CFG['user']['user_id']) return;
				$answer_details = $this->getAnswerDetails($this->fields_arr['aid']);
				$email_options = $this->getEmailOptionsOfUser($answer_details['user_id']);
				if ($email_options['best_ans_mail'] == 'Yes')
				{
						$answerer_details = $this->getUserDetailsFromUsersTable($this->CFG['db']['tbl']['users'], $answer_details['user_id']);
						$best_answers_subject = str_replace('{username}', $answerer_details['name'], $this->LANG['best_answer_email_subject']);
						$best_answers_content = str_replace('{username}', '<a href="' . getUrl($this->CFG['site']['url'] . 'myanswers.php?uid=' . $answer_details['user_id'], $this->CFG['site']['url'] . 'my/answers/' . $answer_details['user_id'] . '/', false) . '">' . $answerer_details['name'] . '</a>', $this->LANG['best_answer_email_content']);
						$sender_name = '<a href="' . getUrl($this->CFG['site']['url'] . 'myanswers.php?uid=' . $this->CFG['user']['user_id'], $this->CFG['site']['url'] . 'my/answers/' . $this->CFG['user']['user_id'] . '/', false) . '">' . $this->CFG['user']['name'] . '</a>';
						$best_answers_content = str_replace('{sender name}', $sender_name, $best_answers_content);
						$best_answers_content = str_replace('{sitename}', $this->CFG['site']['name'], $best_answers_content);
						$best_answers_content = str_replace('{question asked}', '<strong>' . $this->question_details['question'] . '</strong>', $best_answers_content);
						$best_answers_content = str_replace('{question reply}', nl2br($answer_details['answer']), $best_answers_content);
						$question_link = getUrl($this->CFG['site']['url'] . 'answer.php?qid=' . $this->fields_arr['qid'] . '/', $this->CFG['site']['url'] . 'view/answers/' . $this->fields_arr['qid'] . '/', false);
						$best_answers_content = str_replace('{link}', '<a href="' . $question_link . '">' . $question_link . '</a>', $best_answers_content);
						$this->_sendMail($answerer_details['email'], $best_answers_subject, nl2br($best_answers_content), $this->CFG['site']['noreply_name'], $this->CFG['site']['noreply_email']);
				}
		}
		public function getAnswerDetails($aid)
		{
				$sql = 'SELECT user_id, answer FROM ' . $this->CFG['db']['tbl']['answers'] . ' WHERE ans_id=' . $this->dbObj->Param('aid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['aid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = $rs->FetchRow();
				return $row;
		}
		public function sendAbuseMailToAsker()
		{
				$email_options = $this->getEmailOptionsOfUser($this->question_details['user_id']);
				if ($email_options['abuse_mail'] == 'Yes')
				{
						$asker_details = $this->getUserDetailsFromUsersTable($this->CFG['db']['tbl']['users'], $this->question_details['user_id']);
						$abuse_question_subject = str_replace('{username}', $asker_details['name'], $this->LANG['abuse_question_email_subject']);
						$abuse_question_content = str_replace('{username}', '<a href="' . getUrl($this->CFG['site']['url'] . 'myanswers.php?uid=' . $this->question_details['user_id'], $this->CFG['site']['url'] . 'my/answers/' . $this->question_details['user_id'] . '/', false) . '">' . $asker_details['name'] . '</a>', $this->LANG['abuse_question_email_content']);
						$sender_name = '<a href="' . getUrl($this->CFG['site']['url'] . 'myanswers.php?uid=' . $this->CFG['user']['user_id'], $this->CFG['site']['url'] . 'my/answers/' . $this->CFG['user']['user_id'] . '/', false) . '">' . $this->CFG['user']['name'] . '</a>';
						$abuse_question_content = str_replace('{sender name}', $sender_name, $abuse_question_content);
						$abuse_question_content = str_replace('{sitename}', $this->CFG['site']['name'], $abuse_question_content);
						$abuse_question_content = str_replace('{question asked}', '<strong>' . $this->question_details['question'] . '</strong>', $abuse_question_content);
						$question_link = getUrl($this->CFG['site']['url'] . 'answer.php?qid=' . $this->fields_arr['qid'], $this->CFG['site']['url'] . 'view/answers/' . $this->fields_arr['qid'] . '/', false);
						$abuse_question_content = str_replace('{link}', '<a href="' . $question_link . '">' . $question_link . '</a>', $abuse_question_content);
						$this->_sendMail($asker_details['email'], $abuse_question_subject, nl2br($abuse_question_content), $this->CFG['site']['noreply_name'], $this->CFG['site']['noreply_email']);
				}
		}
		public function sendAbuseMailToAnswerer()
		{
				$email_options = $this->getEmailOptionsOfUser($this->answer_details['user_id']);
				if ($email_options['abuse_mail'] == 'Yes')
				{
						$answerer_details = $this->getUserDetailsFromUsersTable($this->CFG['db']['tbl']['users'], $this->answer_details['user_id']);
						$abuse_answers_subject = str_replace('{username}', $answerer_details['name'], $this->LANG['abuse_answer_email_subject']);
						$abuse_answers_content = str_replace('{username}', '<a href="' . getUrl($this->CFG['site']['url'] . 'myanswers.php?uid=' . $this->answer_details['user_id'], $this->CFG['site']['url'] . 'my/answers/' . $this->answer_details['user_id'] . '/', false) . '">' . $answerer_details['name'] . '</a>', $this->LANG['abuse_answer_email_content']);
						$sender_name = '<a href="' . getUrl($this->CFG['site']['url'] . 'myanswers.php?uid' . $this->CFG['user']['user_id'], $this->CFG['site']['url'] . 'my/answers/' . $this->CFG['user']['user_id'] . '/', false) . '">' . $this->CFG['user']['name'] . '</a>';
						$abuse_answers_content = str_replace('{sender name}', $sender_name, $abuse_answers_content);
						$abuse_answers_content = str_replace('{sitename}', $this->CFG['site']['name'], $abuse_answers_content);
						$abuse_answers_content = str_replace('{question asked}', '<strong>' . $this->question_details['question'] . '</strong>', $abuse_answers_content);
						$abuse_answers_content = str_replace('{question reply}', nl2br($this->answer_details['answer']), $abuse_answers_content);
						$question_link = getUrl($this->CFG['site']['url'] . 'answer.php?qid=' . $this->fields_arr['qid'] . '/', $this->CFG['site']['url'] . 'view/answers/' . $this->fields_arr['qid'] . '/', false);
						$abuse_answers_content = str_replace('{link}', '<a href="' . $question_link . '">' . $question_link . '</a>', $abuse_answers_content);
						$this->_sendMail($answerer_details['email'], $abuse_answers_subject, nl2br($abuse_answers_content), $this->CFG['site']['noreply_name'], $this->CFG['site']['noreply_email']);
				}
		}
																																																																		/**
																																																																		 * 
																																																																		 * 	[iAG] NULLED
																																																																		 * 
																																																																		 **/
		private function _sendMail($to_email, $subject, $body, $sender_name, $sender_email)
		{
				$mail = new PHPMailer();
				$mail->AddAddress($to_email);
				$mail->FromName = $sender_name;
				$mail->From = $mail->Sender = $sender_email;
				$mail->Subject = $subject;
				$mail->Body = $body;
				$mail->IsMail();
				$mail->IsHTML(true);
				return ($mail->Send());
		}
		public function getQuestionRatings($users_stared_question_table, $stock_question_table, $ques_id, $user_id, $cfg_project_path_relative, $relative_path, $question_url)
		{
				$start = 1000;
				$end = 1004;
?>
<div class="blctitle">
  <div class="brctitle">
    <div class="tlctitle">
      <div class="trctitle">
        <p class="clsRatingImg">
          <?php
				if ($this->CFG['user']['user_id'] == 0)
				{
?>
          <span class="clsRateStars"><?php echo $this->LANG['rate_now']; ?>
          <?php
						$pointer = 1;
						for ($j = $start; $j < $end; $j++)
						{
?>
          <img id="rate<?php echo ($j + 1); ?>" src="<?php echo $cfg_project_path_relative; ?>images/icon-rate.gif" alt="<?php echo ($pointer); ?>" onMouseOver="mouseOverAnswers(<?php echo ($j + 1); ?>, <?php echo $start; ?>, '<?php echo $cfg_project_path_relative; ?>images/icon-ratehover.gif', '<?php echo $cfg_project_path_relative; ?>images/icon-rate.gif');" onMouseOut="mouseOutAnswers(<?php echo $start; ?>);" onClick="window.location='<?php echo $question_url; ?>';" />
          <?php
								$pointer++;
						}
?>
          </span>
          <?php
				} elseif ($this->CFG['user']['user_id'] == $user_id)
				{
?>
			<span class="clsRateStars"><?php echo $this->LANG['you_cant_rate_your_question']; ?></span>
<?php
				}
				else
				{
						$sql = 'SELECT rating FROM ' . $users_stared_question_table . ' WHERE ques_id = ' . $this->dbObj->Param($ques_id) . ' AND user_id = ' . $this->dbObj->Param($this->CFG['user']['user_id']);
						$stmt = $this->dbObj->Prepare($sql);
						$result = $this->dbObj->Execute($stmt, array($ques_id, $this->CFG['user']['user_id']));
						if (!$result) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
						$rating = 0;
						if ($result->PO_RecordCount() or !$this->isQuestionOpen())
						{
?>
          <span class="clsRateStars"><?php echo $this->LANG['your_rating']; ?>
          <?php
								$row['rating'] = 0;
								if ($result->PO_RecordCount()) $row = $result->FetchRow();
								$rating = $row['rating'];
								$pointer = 1;
								for ($i = $start; $i < $rating + $start; $i++)
								{
										if ($this->isQuestionOpen())
										{
?>
          <img id="rate<?php echo ($i + 1); ?>" src="<?php echo $cfg_project_path_relative; ?>images/icon-ratehover.gif" alt="<?php echo ($pointer); ?>" onMouseOver="mouseOverAnswers(<?php echo ($i + 1); ?>, <?php echo $start; ?>, '<?php echo $cfg_project_path_relative; ?>images/icon-ratehover.gif', '<?php echo $cfg_project_path_relative; ?>images/icon-rate.gif');" onMouseOut="mouseOutAnswers(<?php echo $start; ?>);" onClick="getQuestionRatingDetails('<?php echo $relative_path; ?>ratingAnswer.php', 'action=question&qid=<?php echo $ques_id; ?>&uid=<?php echo $user_id; ?>&rating=<?php echo ($pointer); ?>', 'selQuestionRatingContent');" />
          <?php
										}
										else
										{
?>
          <img id="rate<?php echo ($i + 1); ?>" src="<?php echo $cfg_project_path_relative; ?>images/icon-ratehover.gif" alt="<?php echo ($pointer); ?>" />
          <?php
										}
										$pointer++;
								}
								for ($j = $i; $j < $end; $j++)
								{
										if ($this->isQuestionOpen())
										{
?>
          <img id="rate<?php echo ($j + 1); ?>" src="<?php echo $cfg_project_path_relative; ?>images/icon-rate.gif" alt="<?php echo ($pointer); ?>" onMouseOver="mouseOverAnswers(<?php echo ($j + 1); ?>, <?php echo $start; ?>, '<?php echo $cfg_project_path_relative; ?>images/icon-ratehover.gif', '<?php echo $cfg_project_path_relative; ?>images/icon-rate.gif');" onMouseOut="mouseOutAnswers(<?php echo $start; ?>);" onClick="getQuestionRatingDetails('<?php echo $relative_path; ?>ratingAnswer.php', 'action=question&qid=<?php echo $ques_id; ?>&uid=<?php echo $user_id; ?>&rating=<?php echo ($pointer); ?>', 'selQuestionRatingContent');" />
          <?php
										}
										else
										{
?>
          <img id="rate<?php echo ($j + 1); ?>" src="<?php echo $cfg_project_path_relative; ?>images/icon-rate.gif" alt="<?php echo ($pointer); ?>" />
          <?php
										}
										$pointer++;
								}
?>
          </span>
          <?php
						}
						else
						{
?>
          <span class="clsRateStars"><?php echo $this->LANG['rate_now']; ?>
          <?php
								$pointer = 1;
								for ($j = $start; $j < $end; $j++)
								{
?>
          <img id="rate<?php echo ($j + 1); ?>" src="<?php echo $cfg_project_path_relative; ?>images/icon-rate.gif" alt="<?php echo ($pointer); ?>" onMouseOver="mouseOverAnswers(<?php echo ($j + 1); ?>, <?php echo $start; ?>, '<?php echo $cfg_project_path_relative; ?>images/icon-ratehover.gif', '<?php echo $cfg_project_path_relative; ?>images/icon-rate.gif');" onMouseOut="mouseOutAnswers(<?php echo $start; ?>);" onClick="getQuestionRatingDetails('<?php echo $relative_path; ?>ratingAnswer.php', 'action=question&qid=<?php echo $ques_id; ?>&uid=<?php echo $user_id; ?>&rating=<?php echo ($pointer); ?>', 'selQuestionRatingContent');" />
          <?php
										$pointer++;
								}
?>
          </span>
          <?php
						}
				}
				$sql = 'SELECT COUNT(star_id) as cnt FROM ' . $users_stared_question_table . ' WHERE ques_id = ' . $this->dbObj->Param($ques_id);
				$stmt = $this->dbObj->Prepare($sql);
				$result = $this->dbObj->Execute($stmt, array($ques_id));
				if (!$result) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = $result->FetchRow();
				$rating_count = $row['cnt'];
				$sql = 'SELECT total_stars FROM ' . $stock_question_table . ' WHERE ques_id = ' . $this->dbObj->Param($ques_id);
				$stmt = $this->dbObj->Prepare($sql);
				$result = $this->dbObj->Execute($stmt, array($ques_id));
				if (!$result) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$rating = 0;
				if ($result->PO_RecordCount())
				{
						$row = $result->FetchRow();
						$rating = $row['total_stars'];
				}
?>
          <span class="clsRateScores"><?php echo $this->LANG['average_rating']; ?> <span class="clsScore"><?php echo $rating; ?> / <?php echo $rating_count; ?></span> <?php echo $this->LANG['ratings']; ?> </span> </p>
      </div>
    </div>
  </div>
</div>
<?php
		}
		public function getAnswersRatings($users_stared_answer_table, $stock_answers_table, $ans_id, $user_id, $cfg_project_path_relative, $relative_path, $id_cnt, $question_url)
		{
				$start = $id_cnt;
				$end = $id_cnt + 4;
?>
<div class="blctitle">
  <div class="brctitle">
    <div class="tlctitle">
      <div class="trctitle">
        <p class="clsRatingImg">
          <?php
				if ($this->CFG['user']['user_id'] == 0)
				{
?>
          <span class="clsRateStars"><?php echo $this->LANG['rate_now']; ?>
          <?php
						$pointer = 1;
						for ($j = $start; $j < $end; $j++)
						{
?>
          <img id="rate<?php echo ($j + 1); ?>" src="<?php echo $cfg_project_path_relative; ?>images/icon-rate.gif" alt="<?php echo ($pointer); ?>" onMouseOver="mouseOverAnswers(<?php echo ($j + 1); ?>, <?php echo $start; ?>, '<?php echo $cfg_project_path_relative; ?>images/icon-ratehover.gif', '<?php echo $cfg_project_path_relative; ?>images/icon-rate.gif');" onMouseOut="mouseOutAnswers(<?php echo $start; ?>);" onClick="window.location='<?php echo $question_url; ?>';" />
          <?php
								$pointer++;
						}
?>
          </span>
          <?php
				} elseif ($this->CFG['user']['user_id'] == $user_id)
				{
?>
			<span class="clsRateStars"><?php echo $this->LANG['you_cant_rate_your_answer']; ?></span>
<?php
				}
				else
				{
						$sql = 'SELECT rating FROM ' . $users_stared_answer_table . ' WHERE ans_id = ' . $this->dbObj->Param($ans_id) . ' AND user_id = ' . $this->dbObj->Param($this->CFG['user']['user_id']);
						$stmt = $this->dbObj->Prepare($sql);
						$result = $this->dbObj->Execute($stmt, array($ans_id, $this->CFG['user']['user_id']));
						if (!$result) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
						$rating = 0;
						if ($result->PO_RecordCount() or !$this->isQuestionOpen())
						{
?>
          <span class="clsRateStars"><?php echo $this->LANG['your_rating']; ?>
          <?php
								$row['rating'] = 0;
								if ($result->PO_RecordCount()) $row = $result->FetchRow();
								$rating = $row['rating'];
								$pointer = 1;
								for ($i = $start; $i < $rating + $start; $i++)
								{
										if ($this->isQuestionOpen())
										{
?>
          <img id="rate<?php echo ($i + 1); ?>" src="<?php echo $cfg_project_path_relative; ?>images/icon-ratehover.gif" alt="<?php echo ($pointer); ?>" onMouseOver="mouseOverAnswers(<?php echo ($i + 1); ?>, <?php echo $start; ?>, '<?php echo $cfg_project_path_relative; ?>images/icon-ratehover.gif', '<?php echo $cfg_project_path_relative; ?>images/icon-rate.gif');" onMouseOut="mouseOutAnswers(<?php echo $start; ?>);" onClick="getRatingDetails('<?php echo $relative_path; ?>ratingAnswer.php', 'action=answers&aid=<?php echo $ans_id; ?>&uid=<?php echo $user_id; ?>&rating=<?php echo ($pointer); ?>&id_cnt=<?php echo ($id_cnt); ?>', 'selAnswersRatingContent<?php echo $id_cnt; ?>');" />
          <?php
										}
										else
										{
?>
          <img id="rate<?php echo ($i + 1); ?>" src="<?php echo $cfg_project_path_relative; ?>images/icon-ratehover.gif" alt="<?php echo ($pointer); ?>" />
          <?php
										}
										$pointer++;
								}
								for ($j = $i; $j < $end; $j++)
								{
										if ($this->isQuestionOpen())
										{
?>
          <img id="rate<?php echo ($j + 1); ?>" src="<?php echo $cfg_project_path_relative; ?>images/icon-rate.gif" alt="<?php echo ($pointer); ?>" onMouseOver="mouseOverAnswers(<?php echo ($j + 1); ?>, <?php echo $start; ?>, '<?php echo $cfg_project_path_relative; ?>images/icon-ratehover.gif', '<?php echo $cfg_project_path_relative; ?>images/icon-rate.gif');" onMouseOut="mouseOutAnswers(<?php echo $start; ?>);" onClick="getRatingDetails('<?php echo $relative_path; ?>ratingAnswer.php', 'action=answers&aid=<?php echo $ans_id; ?>&uid=<?php echo $user_id; ?>&rating=<?php echo ($pointer); ?>&id_cnt=<?php echo ($id_cnt); ?>', 'selAnswersRatingContent<?php echo $id_cnt; ?>');" />
          <?php
										}
										else
										{
?>
          <img id="rate<?php echo ($j + 1); ?>" src="<?php echo $cfg_project_path_relative; ?>images/icon-rate.gif" alt="<?php echo ($pointer); ?>" />
          <?php
										}
										$pointer++;
								}
?>
          </span>
          <?php
						}
						else
						{
?>
          <span class="clsRateStars"><?php echo $this->LANG['rate_now']; ?>
          <?php
								$pointer = 1;
								for ($j = $start; $j < $end; $j++)
								{
?>
          <img id="rate<?php echo ($j + 1); ?>" src="<?php echo $cfg_project_path_relative; ?>images/icon-rate.gif" alt="<?php echo ($pointer); ?>" onMouseOver="mouseOverAnswers(<?php echo ($j + 1); ?>, <?php echo $start; ?>, '<?php echo $cfg_project_path_relative; ?>images/icon-ratehover.gif', '<?php echo $cfg_project_path_relative; ?>images/icon-rate.gif');" onMouseOut="mouseOutAnswers(<?php echo $start; ?>);" onClick="getRatingDetails('<?php echo $relative_path; ?>ratingAnswer.php', 'action=answers&aid=<?php echo $ans_id; ?>&uid=<?php echo $user_id; ?>&rating=<?php echo ($pointer); ?>&id_cnt=<?php echo ($id_cnt); ?>', 'selAnswersRatingContent<?php echo $id_cnt; ?>');" />
          <?php
										$pointer++;
								}
?>
          </span>
          <?php
						}
				}
				$sql = 'SELECT COUNT(star_id) as cnt FROM ' . $users_stared_answer_table . ' WHERE ans_id = ' . $this->dbObj->Param($ans_id);
				$stmt = $this->dbObj->Prepare($sql);
				$result = $this->dbObj->Execute($stmt, array($ans_id));
				if (!$result) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = $result->FetchRow();
				$rating_count = $row['cnt'];
				$sql = 'SELECT total_stars FROM ' . $stock_answers_table . ' WHERE ans_id = ' . $this->dbObj->Param($ans_id);
				$stmt = $this->dbObj->Prepare($sql);
				$result = $this->dbObj->Execute($stmt, array($ans_id));
				if (!$result) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$rating = 0;
				if ($result->PO_RecordCount())
				{
						$row = $result->FetchRow();
						$rating = $row['total_stars'];
				}
?>
          <span class="clsRateScores"><?php echo $this->LANG['average_rating']; ?> <span class="clsScore"><?php echo $rating; ?> / <?php echo $rating_count; ?></span> <?php echo $this->LANG['ratings']; ?> </span> </p>
      </div>
    </div>
  </div>
</div>
<?php
		}
		public function chkIsAnswerOwner($err_tip = '')
		{
				$sql = 'SELECT 1 FROM ' . $this->CFG['db']['tbl']['answers'] . ' WHERE ans_id=' . $this->dbObj->Param($this->fields_arr['aid']) . ' AND user_id=' . $this->dbObj->Param($this->CFG['user']['user_id']) . ' AND ques_id=' . $this->dbObj->Param($this->fields_arr['qid']);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['aid'], $this->CFG['user']['user_id'], $this->fields_arr['qid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$ok = true;
				if (!$rs->PO_RecordCount())
				{
						$ok = false;
						$this->setCommonErrorMsg($err_tip);
				}
				return $ok;
		}
		public function deleteAnswer()
		{
				$this->updateAnswerVideoStatus($this->answer_details['video_id']);
				$this->updateAnswerAudioStatus($this->answer_details['audio_id']);
				$sql = 'DELETE FROM ' . $this->CFG['db']['tbl']['answers'] . ' WHERE ans_id=' . $this->dbObj->Param($this->fields_arr['aid']) . ' AND user_id=' . $this->dbObj->Param($this->CFG['user']['user_id']) . ' AND ques_id=' . $this->dbObj->Param($this->fields_arr['qid']);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['aid'], $this->CFG['user']['user_id'], $this->fields_arr['qid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['questions'] . ' SET total_answer=total_answer-1' . ' WHERE ques_id=' . $this->dbObj->Param($this->fields_arr['qid']);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['qid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['users_ans_log'] . ' SET total_ans=total_ans-1' . ' WHERE user_id=' . $this->dbObj->Param($this->CFG['user']['user_id']);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->CFG['user']['user_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($this->CFG['admin']['reply_answers']['allowed'])
				{
						$sql = 'UPDATE ' . $this->CFG['db']['tbl']['users_ans_log'] . ' SET total_points=total_points-' . $this->CFG['admin']['reply_answers']['points'] . ' WHERE user_id=' . $this->dbObj->Param($this->CFG['user']['user_id']);
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($this->CFG['user']['user_id']));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				}
		}
		public function updateQuestionVideoStatus($video_id)
		{
				if (!$video_id) return;
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['ans_video'] . ' SET video_status=\'Deleted\'' . ' WHERE video_id=' . $this->dbObj->Param($video_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($video_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function updateQuesitionAudioStatus($audio_id)
		{
				if (!$audio_id) return;
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['ans_audio'] . ' SET audio_status=\'Deleted\'' . ' WHERE audio_id=' . $this->dbObj->Param($audio_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($audio_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function updateAnswerVideoStatus($video_id)
		{
				if (!$video_id) return;
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['ans_video'] . ' SET video_status=\'Deleted\'' . ' WHERE video_id=' . $this->dbObj->Param($video_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($video_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($this->dbObj->Affected_Rows())
				{
						$sql = 'SELECT content_id FROM ' . $this->CFG['db']['tbl']['ans_video'] . ' WHERE video_id=' . $this->dbObj->Param($video_id);
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($video_id));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
						$row = $rs->FetchRow();
						$sql = 'SELECT ques_id FROM ' . $this->CFG['db']['tbl']['answers'] . ' WHERE' . ' ans_id=' . $this->dbObj->Param('ans_id');
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($row['content_id']));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
						$row = $rs->FetchRow();
						$sql = 'UPDATE ' . $this->CFG['db']['tbl']['questions'] . ' SET' . ' total_videos=total_videos-1 WHERE' . ' ques_id=' . $this->dbObj->Param('ques_id') . ' AND total_videos>0';
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($row['ques_id']));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				}
		}
		public function updateAnswerAudioStatus($audio_id)
		{
				if (!$audio_id) return;
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['ans_audio'] . ' SET audio_status=\'Deleted\'' . ' WHERE audio_id=' . $this->dbObj->Param($audio_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($audio_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($this->dbObj->Affected_Rows())
				{
						$sql = 'SELECT content_id FROM ' . $this->CFG['db']['tbl']['ans_audio'] . ' WHERE audio_id=' . $this->dbObj->Param($audio_id);
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($audio_id));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
						$row = $rs->FetchRow();
						$sql = 'SELECT ques_id FROM ' . $this->CFG['db']['tbl']['answers'] . ' WHERE' . ' ans_id=' . $this->dbObj->Param('ans_id');
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($row['content_id']));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
						$row = $rs->FetchRow();
						$sql = 'UPDATE ' . $this->CFG['db']['tbl']['questions'] . ' SET' . ' total_audios=total_audios-1 WHERE' . ' ques_id=' . $this->dbObj->Param('ques_id') . ' AND total_audios>0';
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($row['ques_id']));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				}
		}
		public function chkIsValidCaptureVideoFile()
		{
				if (0)
				{
						$temp_file = '../files/cgi-php-out.flv';
						$file_name = $this->CFG['admin']['video']['red5_flv_path'] . $this->fields_arr['rid'] . '.flv';
						copy($temp_file, $file_name);
				}
				$file_name = $this->CFG['admin']['video']['red5_flv_path'] . $this->fields_arr['rid'] . '.flv';
				if ($this->fields_arr['video'] == $this->fields_arr['rid'])
				{
						if (is_file($file_name)) return true;
						$this->fields_arr['video'] = '';
						return false;
				}
				if (is_file($file_name)) unlink($file_name);
		}
		public function chkIsValidCaptureAudioFile()
		{
				if (0)
				{
						$temp_file = '../files/cgi-php-out.flv';
						$file_name = $this->CFG['admin']['video']['red5_flv_path'] . $this->fields_arr['rid'] . 'AUD.flv';
						copy($temp_file, $file_name);
				}
				$file_name = $this->CFG['admin']['video']['red5_flv_path'] . $this->fields_arr['rid'] . 'AUD.flv';
				if ($this->fields_arr['audio'] == $this->fields_arr['rid'])
				{
						if (is_file($file_name))
						{
								return true;
						}
						$this->fields_arr['audio'] = '';
						return false;
				}
				if (is_file($file_name)) unlink($file_name);
		}
		public function generateRandomId()
		{
				$time = time();
				$this->fields_arr['rid'] = md5($time);
		}
		public function changeAnsVideoStatus($video_id, $status)
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['ans_video'] . ' SET' . ' video_encoded_status=' . $this->dbObj->Param('video_encoded_status') . ' WHERE video_id=' . $this->dbObj->Param('video_id');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($status, $video_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function changeAnsAudioStatus($audio_id, $status)
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['ans_audio'] . ' SET' . ' audio_encoded_status=' . $this->dbObj->Param('audio_encoded_status') . ' WHERE audio_id=' . $this->dbObj->Param('audio_id');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($status, $audio_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
}
$answers = new AnswerFormHandler();
$CFG['comments']['expand_collapse'] = false;
$answers->setCfgLangGlobal($CFG, $LANG);
$answers->setPageBlockNames(array('form_add', 'form_abuse_question', 'form_abuse_answer', 'form_confirm', 'form_question', 'form_answers', 'msg_form_error', 'msg_form_success', 'form_information', 'form_best_answer'));
$answers->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$answers->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$answers->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$answers->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$answers->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$answers->setFormField('qid', '');
$answers->setFormField('aid', '');
$answers->setFormField('search_question', '');
$answers->setFormField('answer', '');
$answers->setFormField('source', '');
$answers->setFormField('action', '');
$answers->setFormField('content_id', '');
$answers->setFormField('reason', '');
$answers->setFormField('str', '');
$answers->setFormField('msg', '');
$answers->setFormField('video', '');
$answers->setFormField('video_id', '');
$answers->setFormField('audio', '');
$answers->setFormField('audio_id', '');
$answers->setFormField('rid', '');
$pagename = 'View Answers';
$answers->setDBObject($db);
$answers->numpg = $CFG['data_tbl']['numpg'];
$answers->setFormField('start', 0);
$answers->setFormField('numpg', $CFG['data_tbl']['numpg']);
$answers->setMinRecordSelectLimit($CFG['data_tbl']['min_record_select_limit']);
$answers->setMaxRecordSelectLimit($CFG['data_tbl']['max_record_select_limit']);
$answers->setNumPerPageListArr($CFG['data_tbl']['numperpage_list_arr']);
$answers->setTableNames(array());
$answers->setReturnColumns(array());
$answers->setFormField('orderby_field', '');
$answers->setFormField('orderby', '');
$answers->sanitizeFormInputs($_REQUEST);
if (!$answers->getFormField('rid')) $answers->generateRandomId();
$answers->setAllPageBlocksHide();
$answers->updateQuestionViews();
$title = 'Open Question';
$cfg_title = ' - ' . $title;
if ($answers->isFormGETed($_GET, 'aid')) $answers->chkIsValidAnswer();
if ($answers->chkIsValidQuestion())
{
		if (!$answers->isQuestionOpen()) $title = 'Resolved Question';
		else  $title = 'Open Question';
		$cfg_title = ' - ' . $answers->question_details['question'];
		$answers->setPageBlockShow('form_question');
		$answers->setPageBlockShow('form_answers');
		if ($answers->isFormPOSTed($_POST, 'update_answer'))
		{
				$title = $LANG['answers_edit_your_answer'];
				$cfg_title = ' - ' . $title;
				$answers->chkIsNotEmpty('answer', $LANG['answers_err_tip_compulsory']);
				if (!$answers->isQuestionOpen()) $answers->setCommonErrorMsg($LANG['answers_err_not_open']);
				$answers->chkIsValidCaptureVideoFile();
				$answers->chkIsValidCaptureAudioFile();
				if ($answers->isValidFormInputs())
				{
						$answers->updateAnswer();
						$answers->setCommonErrorMsg($LANG['answers_updated_successfully']);
						$answers->setPageBlockShow('msg_form_success');
						Redirect2URL(getUrl($CFG['site']['relative_url'] . 'answer.php?qid=' . $answers->getFormField('qid') . '&msg=7', $CFG['site']['relative_url'] . 'view/answers/' . $answers->getFormField('qid') . '/?msg=7', false));
				}
				else
				{
						$answers->setPageBlockHide('form_question');
						$answers->setPageBlockHide('form_answers');
						$answers->setPageBlockShow('form_add');
						$answers->setPageBlockShow('msg_form_error');
				}
		}
		else
				if ($answers->isFormPOSTed($_POST, 'confirm_action'))
				{
						switch ($answers->getFormField('action'))
						{
								case 'resolve':
										$title = 'Resolve Question';
										$cfg_title = ' - ' . $title;
										if ($answers->question_details['user_id'] == $CFG['user']['user_id'])
										{
												$answers->resolveQuestion();
												$answers->question_details['status'] = 'Resolved';
												$answers->setPageBlockShow('msg_form_success');
												$answers->setCommonErrorMsg($LANG['answers_resolved_successfully']);
												Redirect2URL(getUrl($CFG['site']['relative_url'] . 'answer.php?qid=' . $answers->getFormField('qid') . '&msg=8', $CFG['site']['relative_url'] . 'view/answers/' . $answers->getFormField('qid') . '/?msg=8', false));
										}
										else
										{
												$answers->setAllPageBlocksHide();
												$answers->setPageBlockShow('msg_form_error');
												$answers->setCommonErrorMsg($LANG['answers_err_invalid_action']);
										}
										break;
								case 'delete':
										if ($answers->question_details['user_id'] == $CFG['user']['user_id'])
										{
												$answers->deleteQuestion();
												Redirect2URL(getUrl($CFG['site']['relative_url'] . 'questions.php?view=' . strtolower($answers->question_details['status']) . '&msg=3', $CFG['site']['relative_url'] . 'answers/' . strtolower($answers->question_details['status']) . '/?msg=3', false));
										}
										else
										{
												$answers->setAllPageBlocksHide();
												$answers->setPageBlockShow('msg_form_error');
												$answers->setCommonErrorMsg($LANG['answers_err_invalid_action']);
										}
										break;
								case 'abusequestion':
										$answers->chkIsNotEmpty('reason', $LANG['answers_err_tip_compulsory']);
										$title = 'Report Abuse';
										$cfg_title = ' - ' . $title;
										if ($answers->isValidFormInputs() and $answers->question_details['user_id'] != $CFG['user']['user_id'])
										{
												$answers->updateAbuseQuestion();
												$answers->setPageBlockShow('msg_form_success');
												$answers->setPageBlockShow('form_question');
												$answers->setPageBlockShow('form_answers');
												$answers->setCommonErrorMsg($LANG['answers_question_abused_successfully']);
												Redirect2URL(getUrl($CFG['site']['relative_url'] . 'answer.php?qid=' . $answers->getFormField('qid') . '&msg=2', $CFG['site']['relative_url'] . 'view/answers/' . $answers->getFormField('qid') . '/?msg=2', false));
										}
										else
										{
												$answers->setPageBlockShow('msg_form_error');
										}
										break;
								case 'abuseanswer':
										$answers->chkIsNotEmpty('reason', $LANG['answers_err_tip_compulsory']);
										$title = 'Report Abuse';
										$cfg_title = ' - ' . $title;
										$answers->setFormField('aid', $answers->getFormField('content_id'));
										$answers->chkIsValidAnswer();
										if ($answers->isValidFormInputs())
										{
												$answers->updateAbuseAnswer();
												$answers->setPageBlockShow('msg_form_success');
												$answers->setPageBlockShow('form_question');
												$answers->setPageBlockShow('form_answers');
												$answers->setCommonErrorMsg($LANG['answers_answer_abused_successfully']);
												Redirect2URL(getUrl($CFG['site']['relative_url'] . 'answer.php?qid=' . $answers->getFormField('qid') . '&msg=3', $CFG['site']['relative_url'] . 'view/answers/' . $answers->getFormField('qid') . '/?msg=3', false));
										}
										else
										{
												$answers->setPageBlockShow('msg_form_error');
										}
										break;
								case 'deleteanswer':
										$answers->chkIsNotEmpty('aid', $LANG['answers_err_tip_compulsory']) and $answers->chkIsAnswerOwner($LANG['answers_err_invalid_action']);
										if ($answers->isValidFormInputs() and $CFG['admin']['answer']['delete'])
										{
												$answers->chkIsValidAnswer();
												$answers->deleteAnswer();
												$answers->setPageBlockShow('msg_form_success');
												$answers->setCommonErrorMsg($LANG['answers_answer_deleted_successfully']);
												Redirect2URL(getUrl($CFG['site']['relative_url'] . 'answer.php?qid=' . $answers->getFormField('qid') . '&msg=6', $CFG['site']['relative_url'] . 'view/answers/' . $answers->getFormField('qid') . '/?msg=6', false));
										}
										else
										{
												$answers->setPageBlockShow('msg_form_error');
										}
										break;
								case 'bestanswers':
										$answers->chkIsNotEmpty('aid', $LANG['answers_err_tip_compulsory']);
										$title = 'Best Answer';
										$cfg_title = ' - ' . $title;
										if ($answers->isValidFormInputs() and $CFG['user']['user_id'] == $answers->question_details['user_id'] and $answers->isQuestionOpen() and $answers->question_details['best_ans_id'] == 0)
										{
												$answers->updateBestAnswer();
												$answers->setPageBlockShow('msg_form_success');
												$answers->setPageBlockShow('form_question');
												$answers->setPageBlockShow('form_answers');
												$answers->setCommonErrorMsg($LANG['answers_best_answer_added_successfully']);
												Redirect2URL(getUrl($CFG['site']['relative_url'] . 'answer.php?qid=' . $answers->getFormField('qid') . '&msg=4', $CFG['site']['relative_url'] . 'view/answers/' . $answers->getFormField('qid') . '/?msg=4', false));
										}
										else
										{
												$answers->setPageBlockShow('msg_form_error');
										}
										break;
						}
				}
				else
						if ($answers->isFormPOSTed($_POST, 'submit'))
						{
								$title = $LANG['answers_what_is_your_answer'];
								$cfg_title = ' - ' . $title;
								$answers->chkIsNotEmpty('answer', $LANG['answers_err_tip_compulsory']);
								if (!$answers->isQuestionOpen()) $answers->setCommonErrorMsg($LANG['answers_err_not_open']);
								elseif (!$answers->isAllowedToAsk()) $answers->setCommonErrorMsg($LANG['info_not_allowed_to_ask']);
								$answers->chkIsValidCaptureVideoFile();
								$answers->chkIsValidCaptureAudioFile();
								if ($answers->isValidFormInputs())
								{
										if ($CFG['debug']['store_log'])
										{
												$answers->createErrorLogFile('answer');
										}
										$answers->addAnswer();
										if ($CFG['debug']['store_log'])
										{
												$answers->closeErrorLogFile();
										}
										$answers->setCommonErrorMsg($LANG['answers_added_successfully']);
										$answers->setPageBlockShow('msg_form_success');
										Redirect2URL(getUrl($CFG['site']['relative_url'] . 'answer.php?qid=' . $answers->getFormField('qid') . '&msg=1', $CFG['site']['relative_url'] . 'view/answers/' . $answers->getFormField('qid') . '/?msg=1', false));
								}
								else
								{
										$answers->setPageBlockShow('msg_form_error');
								}
						}
		if ($answers->isFormGETed($_GET, 'action'))
		{
				if (!$CFG['user']['user_id']) Redirect2URL(getUrl($CFG['site']['url'] . 'login.php', $CFG['site']['url'] . 'login/', false));
				switch ($answers->getFormField('action'))
				{
						case 'reply':
								if ($answers->isQuestionOpen())
								{
										$answers->setPageBlockHide('form_question');
										$answers->setPageBlockHide('form_answers');
										if ($answers->isAllowedToAsk()) $answers->setPageBlockShow('form_add');
										else
										{
												$answers->setPageBlockShow('form_information');
												$answers->setCommonErrorMsg($LANG['info_not_allowed_to_ask']);
										}
										$title = $LANG['answers_what_is_your_answer'];
										$cfg_title = ' - ' . $title;
								}
								else
								{
										$answers->setPageBlockShow('msg_form_error');
										$answers->setCommonErrorMsg($LANG['answers_err_not_open']);
								}
								break;
						case 'resolve':
								if ($answers->question_details['user_id'] == $CFG['user']['user_id'])
								{
										$answers->setPageBlockShow('form_confirm');
										$title = 'Resolve Question';
										$cfg_title = ' - ' . $title;
								}
								else
								{
										$answers->setAllPageBlocksHide();
										$answers->setPageBlockShow('msg_form_error');
										$answers->setCommonErrorMsg($LANG['answers_err_invalid_action']);
								}
								break;
						case 'abusequestion':
								if ($answers->isValidFormInputs() and $answers->question_details['user_id'] != $CFG['user']['user_id'])
								{
										$answers->setPageBlockHide('form_question');
										$answers->setPageBlockHide('form_answers');
										$answers->setPageBlockShow('form_abuse_question');
										$title = 'Report Abuse';
										$cfg_title = ' - ' . $title;
								}
								else
								{
										$answers->setAllPageBlocksHide();
										$answers->setPageBlockShow('msg_form_error');
										$answers->setCommonErrorMsg($LANG['answers_err_invalid_action']);
								}
								break;
						case 'abuseanswer':
								if ($answers->isValidFormInputs() and $answers->answer_details['user_id'] != $CFG['user']['user_id'])
								{
										$answers->setPageBlockHide('form_question');
										$answers->setPageBlockHide('form_answers');
										$answers->setPageBlockShow('form_abuse_answer');
										$title = 'Report Abuse';
										$cfg_title = ' - ' . $title;
								}
								else
								{
										$answers->setAllPageBlocksHide();
										$answers->setPageBlockShow('msg_form_error');
										$answers->setCommonErrorMsg($LANG['answers_err_invalid_action']);
								}
								break;
						case 'bestanswers':
								if ($answers->isValidFormInputs() and $answers->question_details['user_id'] == $CFG['user']['user_id'])
								{
										$answers->setPageBlockShow('form_best_answer');
										$title = 'Best Answer';
										$cfg_title = ' - ' . $title;
								}
								else
								{
										$answers->setAllPageBlocksHide();
										$answers->setPageBlockShow('msg_form_error');
										$answers->setCommonErrorMsg($LANG['answers_err_invalid_action']);
								}
								break;
						case 'edit':
								if ($answers->isValidFormInputs() and $answers->isQuestionOpen() and $answers->answer_details['user_id'] == $CFG['user']['user_id'])
								{
										$answers->setPageBlockHide('form_question');
										$answers->setPageBlockHide('form_answers');
										$answers->setPageBlockShow('form_add');
										$answers->setFormField('answer', $answers->answer_details['answer']);
										$answers->setFormField('source', $answers->answer_details['source']);
										$answers->setFormField('video_id', $answers->answer_details['video_id']);
										$answers->setFormField('audio_id', $answers->answer_details['audio_id']);
										$title = $LANG['answers_edit_your_answer'];
										$cfg_title = ' - ' . $title;
								}
								else
								{
										$answers->setPageBlockShow('msg_form_error');
										$answers->setCommonErrorMsg($LANG['answers_err_invalid_action']);
								}
								break;
				}
		}
		if ($answers->isFormPOSTed($_POST, 'cancel'))
		{
				Redirect2URL(getUrl($CFG['site']['relative_url'] . 'answer.php?qid=' . $answers->getFormField('qid'), $CFG['site']['relative_url'] . 'view/answers/' . $answers->getFormField('qid') . '/', false));
		}
		if ($answers->isFormGETed($_GET, 'msg'))
		{
				switch ($answers->getFormField('msg'))
				{
						case 2:
								$answers->setCommonErrorMsg($LANG['answers_question_abused_successfully']);
								break;
						case 3:
								$answers->setCommonErrorMsg($LANG['answers_answer_abused_successfully']);
								break;
						case 4:
								$answers->setCommonErrorMsg($LANG['answers_best_answer_added_successfully']);
								break;
						case 5:
								$answers->setCommonErrorMsg($LANG['answers_updated_question_successfully']);
								break;
						case 6:
								$answers->setCommonErrorMsg($LANG['answers_answer_deleted_successfully']);
								break;
						case 7:
								$answers->setCommonErrorMsg($LANG['answers_updated_successfully']);
								break;
						case 8:
								$answers->setCommonErrorMsg($LANG['answers_resolved_successfully']);
								break;
						default:
								$answers->setCommonErrorMsg($LANG['answers_added_successfully']);
								break;
				}
				$answers->setPageBlockShow('msg_form_success');
		}
}
else
{
		$answers->setPageBlockShow('msg_form_error');
		$cfg_title = '';
}
$CFG['mods']['is_include_only']['non_html_header_files'] = false;
$CFG['mods']['is_include_only']['html_header'] = true;
$CFG['site']['title'] = $CFG['site']['title'] . $cfg_title;
require ($CFG['site']['project_path'] . 'common/application_top.inc.php');
?>
<script language="javascript" type="text/javascript">
var block_arr= new Array('selMsgConfirm', 'selDelMsgConfirm', 'selMsgAbuseConfirm');
</script>
<div id="selListAll">
  <h2><?php echo $title; ?></h2>
  <?php
$answers->displayAnswersTopLinks();
if ($answers->isShowPageBlock('msg_form_error'))
{
?>
  <div id="selMsgError">
    <p>
      <?php
		echo $LANG['answers_err_sorry'] . ' ' . $answers->getCommonErrorMsg();
?>
    </p>
  </div>
  <?php
}
if ($answers->isShowPageBlock('msg_form_success'))
{
?>
  <div id="selMsgSuccess">
    <p>
      <?php
		echo $answers->getCommonErrorMsg();
?>
    </p>
  </div>
  <?php
}
if ($answers->isShowPageBlock('form_information'))
{
?>
  <div id="selMsgAlert">
    <p><?php echo $answers->getCommonErrorMsg(); ?></p>
  </div>
  <?php
}
if ($answers->isShowPageBlock('form_confirm')) $answers->displayConfirmOption();
if ($answers->isShowPageBlock('form_best_answer')) $answers->bestAnswerConfirm();
if ($answers->isShowPageBlock('form_question') or $answers->isShowPageBlock('form_answers') or $answers->isShowPageBlock('form_add'))
{
?>
  <div id="selDelMsgConfirm" class="selMsgConfirm" style="display:none;position:absolute;">
    <form name="formDelConfirm" id="formDelConfirm" method="post" action="<?php echo URL($_SERVER['REQUEST_URI']); ?>">
      <p id="confirmDelMessage"></p>
      <table summary="<?php echo $LANG['container_to_get_confirmation']; ?>">
        <tr>
          <td><input type="button" class="clsSubmitButton" name="confirm_del_action" id="confirm_del_action" value="<?php echo $LANG['yes']; ?>" tabindex="<?php echo $answers->getTabIndex(); ?>" onClick="hideAllBlocks(); doRemoveAction();"/>
            &nbsp;
            <input type="button" class="clsCancelButton" name="del_cancel" id="del_cancel" value="<?php echo $LANG['no']; ?>" tabindex="<?php echo $answers->getTabIndex(); ?>" onClick="return hideAllBlocks();" />
          </td>
        </tr>
      </table>
      <?php $answers->populateHidden(array('action', 'aid')); ?>
    </form>
  </div>
<?php
}
if ($answers->isShowPageBlock('form_question') or $answers->isShowPageBlock('form_answers'))
{
?>
  <!-- Confirmation Div -->
  <div id="selMsgConfirm" class="selMsgConfirm" style="display:none;position:absolute;">
    <form name="formConfirm" id="formConfirm" method="post" action="<?php echo URL($_SERVER['REQUEST_URI']); ?>">
      <p id="confirmMessage"></p>
      <table summary="<?php echo $LANG['container_to_get_confirmation']; ?>">
        <tr>
          <td><input type="submit" class="clsSubmitButton" name="confirm_action" id="confirm_action" value="<?php echo $LANG['member_yes']; ?>" tabindex="<?php echo $answers->getTabIndex(); ?>" />
            &nbsp;
            <input type="button" class="clsCancelButton" name="cancel" id="cancel" value="<?php echo $LANG['member_no']; ?>" tabindex="<?php echo $answers->getTabIndex(); ?>" onClick="return hideAllBlocks();" />
          </td>
        </tr>
      </table>
      <?php $answers->populateHidden(array('action', 'aid')); ?>
    </form>
  </div>
  <!-- Confirmation Div -->
  <div id="selMsgAbuseConfirm" class="selMsgAbuseConfirm" style="display:none;position:absolute;">
    <form name="formAbuseConfirm" id="formAbuseConfirm" method="post" action="<?php echo URL($_SERVER['REQUEST_URI']); ?>">
      <p id="confirmAbuseMessage"></p>
      <table summary="<?php echo $LANG['container_to_get_confirmation']; ?>">
        <tr>
          <td><p><?php echo $LANG['answers_reason']; ?></p>
            <p>
              <textarea name="reason" id="reason" cols="70" rows="5" tabindex="<?php echo $answers->getTabIndex(); ?>"><?php echo $answers->getFormField('reason'); ?></textarea>
            </p>
            <p id="validReason"></p></td>
        </tr>
        <tr>
          <td><input type="submit" class="clsSubmitButton" name="confirm_action" id="confirm_action" value="<?php echo $LANG['member_yes']; ?>" tabindex="<?php echo $answers->getTabIndex(); ?>" onClick="return chkIsAbuseReasonExists();" />
            &nbsp;
            <input type="button" class="clsCancelButton" name="cancel" id="cancel" value="<?php echo $LANG['member_no']; ?>" tabindex="<?php echo $answers->getTabIndex(); ?>" onClick="removeReasonErrors(); return hideAllBlocks();" />
          </td>
        </tr>
      </table>
      <?php $answers->populateHidden(array('action', 'content_id')); ?>
    </form>
  </div>
  <?php
}
if ($answers->isShowPageBlock('form_question')) $answers->displayQuestionDetails();
if ($answers->isShowPageBlock('form_answers'))
{
		$answers->setTableNames(array($CFG['db']['tbl']['answers'] . ' as a', $CFG['db']['tbl']['users'] . ' as u'));
		$answers->setReturnColumns(array('a.ans_id', 'a.video_id', 'a.audio_id', 'a.user_id', 'a.answer', 'a.source', 'TIMEDIFF(NOW(), date_answered) as date_answered', 'u.' . $answers->getUserTableField('user_id') . ' as img_user_id', $answers->getUserTableFields(array('image_path', 't_height', 't_width', 's_height', 's_width', 'photo_server_url', 'photo_ext')), $answers->getUserTableField('gender') . ' as gender', $answers->getUserTableField('name') . ' as answered_by'));
		$answers->setFormField('orderby_field', 'a.ans_id');
		$answers->setFormField('orderby', 'DESC');
		$answers->buildSelectQuery();
		$answers->buildConditionQuery();
		$answers->buildSortQuery();
		$answers->buildQuery();
		$answers->executeQuery();
		$answers->displayAllAnswers();
}
if ($answers->isShowPageBlock('form_add')) $answers->postAnswersForm('main');
if ($answers->isShowPageBlock('form_abuse_question')) $answers->abuseQuestion();
if ($answers->isShowPageBlock('form_abuse_answer')) $answers->abuseAnswer();
?>
</div>
<script language="javascript">
	var saveVideo = function(){
		$('video_add').style.display = 'none';
		$('video_delete').style.display = '';
		if (($('video_preview'))) {
			$('video_preview').style.display = '';
			$('video_preview').href = videoPreviewUrl;
		}
		$('video').value = $('rid').value;
		hideAllBlocks();
	}
	var removeVideo = function(){
		alert_manual('<?php echo $LANG['successfully_video_deleted']; ?>', 'video_delete');
		$('video_delete').style.display = 'none';
		if (($('video_preview'))) $('video_preview').style.display = 'none';
		$('video_add').style.display = '';
		$('video').value = '';
		$('video_id').value = '0';
		return false;
	}
	var confrimRemove = function(){
		var act_value = arguments[0];
		var anchorLink = arguments[1];
		var msg_confirm = arguments[2];

		var add_left_position = 0
		var add_top_position = 0;
		if(arguments.length>=4)
			add_top_position = arguments[4];
		if(arguments.length>=6)
			add_left_position = arguments[5];

		var confirm_message = msg_confirm;

		$('confirmDelMessage').innerHTML = confirm_message;
		document.formDelConfirm.action.value = act_value;
		Confirmation(anchorLink, 'selDelMsgConfirm', 'formDelConfirm', Array(), Array(), Array(), add_left_position, add_top_position);

		return false;
	}
	var doRemoveAction = function(){
		if (document.formDelConfirm.action.value == 'video')
			removeVideo();
		else
			removeAudio();
	}
	var deleteVideo = function(){
		hideAllBlocks();
	}
	var saveAudio = function(){
		$('audio_add').style.display = 'none';
		$('audio_delete').style.display = '';
		if (($('audio_preview'))) {
			$('audio_preview').style.display = '';
			$('audio_preview').href = audioPreviewUrl;
		}
		$('audio').value = $('rid').value;
		hideAllBlocks();
	}
	var removeAudio = function(){
		alert_manual('<?php echo $LANG['successfully_audio_deleted']; ?>', 'audio_delete');
		$('audio_delete').style.display = 'none';
		if (($('audio_preview'))) $('audio_preview').style.display = 'none';
		$('audio_add').style.display = '';
		$('audio').value = '';
		$('audio_id').value = '0';
		return false;
	}
	var deleteAudio = function(){
		hideAllBlocks();
	}

function toggleAnswer(spanObj, ansID){
	var moreObj = 'answermore'+ansID;
	var lessObj = 'answerless'+ansID;

	Effect.toggle(moreObj, 'slide');
	Effect.toggle(lessObj, 'slide');
}
var expand = true;
var clicked = true;
var toggleExpandAnswers = function(){
	if (clicked){
			clicked = false;
	for (var i=1; i<=commentsArray.length; i++){
		moreObj = 'answermore'+commentsArray[i];
		lessObj = 'answerless'+commentsArray[i];
		if ($(moreObj)){
			if (expand){
				Effect.SlideUp(moreObj);
				Effect.SlideDown(lessObj);
			}else{
				Effect.SlideDown(moreObj);
				Effect.SlideUp(lessObj);
			}
		}
	}
	expand = (expand)?false:true;
	setTimeout('changeClickedStatus()', 2000);
	}
}
var changeClickedStatus = function(){
		toggleNavBar();
		clicked = true;
	}
</script>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>
