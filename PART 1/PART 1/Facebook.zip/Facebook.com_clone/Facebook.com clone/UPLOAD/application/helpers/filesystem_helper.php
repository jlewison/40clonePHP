<?php
//Dir copy
function copyDir($source, $target)
{
		if (is_dir($source))
		{
				@mkdir($target);
				$d = dir($source);
				while (false !== ($entry = $d->read()))
				{
						if ($entry == '.' || $entry == '..')
						{
								continue;
						}
						$Entry = $source . '/' . $entry;
						if (is_dir($Entry))
						{
								copyDir($Entry, $target . '/' . $entry);
								continue;
						}
						copy($Entry, $target . '/' . $entry);
				}
				$d->close();
		}
		else
		{
				copy($source, $target);
		}
}
//Delete the entire directory
function deleteDir($dir)
{
		// open the directory
		$dhandle = opendir($dir);
		if ($dhandle)
		{
				// loop through it
				while (false !== ($fname = readdir($dhandle)))
				{
						// if the element is a directory, and
						// does not start with a '.' or '..'
						// we call deleteDir function recursively
						// passing this element as a parameter
						if (is_dir("{$dir}/{$fname}"))
						{
								if (($fname != '.') && ($fname != '..'))
								{
										deleteDir("$dir/$fname");
								}
								// the element is a file, so we delete it
						}
						else
						{
								unlink("{$dir}/{$fname}");
						}
				}
				closedir($dhandle);
		}
		// now directory is empty, so we can use
		// the rmdir() function to delete it
		rmdir($dir);
}
?>