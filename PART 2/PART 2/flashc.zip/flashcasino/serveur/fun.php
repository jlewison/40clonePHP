<?
include ("setup.php");
########################
function statistika()
{
$date=date("d.m.Y");
$darkweb_user_stat=mysql_num_rows(mysql_query("SELECT * FROM users"));
$darkweb_newuser_stat=mysql_num_rows(mysql_query("SELECT * FROM users WHERE date='$date'"));
$darkweb_game_stat=mysql_num_rows(mysql_query("SELECT * FROM stat_game"));
$darkweb_babki_stat=mysql_num_rows(mysql_query("SELECT * FROM stat_game WHERE win='$win'"));


 $requete=mysql_query("SELECT SUM(win) FROM stat_game");


$donnee = mysql_fetch_array($requete);
$somme=$donnee['SUM(win)'];

$somme=$somme/10;



$darkweb_stat = "<span style='font-weight: bold;' >Nb total de joueurs : $darkweb_user_stat<br>Nouveaux joueurs : $darkweb_newuser_stat<br>Nb de parties jou�es : $darkweb_game_stat<br>Gain revers� : $somme &#8364<br></span> ";
echo $darkweb_stat;
}
###########################################

############################################
function viigrish()
{
$conf=mysql_query("select * from seting");
$con=mysql_fetch_array($conf);
echo $con['4'];
}
############################################

################################# 
function support()
{
$conf=mysql_query("select * from seting");
$con=mysql_fetch_array($conf);
$darkweb_support_email="<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\"><tr><td align=\"CENTER\"><a href=mailto:$con[2]>$con[2]</a><br></td></tr></table><br>";
if ($con[icq]<>""){
$darkweb_support_icq="<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\"><tr><td align=\"CENTER\">ICQ: $con[icq];<br></td></tr><tr><td align=\"CENTER\"><a href=\"http://web.icq.com/whitepages/message_me?uin=$con[icq];&action=message\"><img src=\"http://web.icq.com/whitepages/online?icq=$con[icq];&img=2\" border=0> </a></td></tr></table>";
}
$darkweb_support=$darkweb_support_email.$darkweb_support_icq;
echo $darkweb_support;
}
############################################


############################################
function procent()
{
$conf=mysql_query("select * from seting");
$con=mysql_fetch_array($conf);
echo $con['pcash'];
}
############################################


############################################
function name()
{
$conf=mysql_query("select * from seting");
$con=mysql_fetch_array($conf);
echo $con['4'];
}
############################################

function config()
{
$conf=mysql_query("select * from seting");
$con=mysql_fetch_array($conf);
return $con;
}
$con=config();

$date=date("d.m.Y");
?>