<?php

/**
 * Photos Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 15-12-2007
 */
class Photos extends Controller
{
		//Constructor
		function Photos()
		{
				parent::Controller();
				loginRequired();
				//Load the language file
				$this->lang->load('wall', $this->config->item('language_code'));
				$this->lang->load('posted', $this->config->item('language_code'));
				$this->lang->load('photos', $this->config->item('language_code'));
				//Load the photo model
				$this->load->model('photomodel');
		}
		//Default function
		function index()
		{
				$this->friendsalbum();
		}
		function friendsalbum()
		{
				//Load the config file related to photo
				$this->config->load('photo');
				//Load the pagination model
				$this->load->model('paginationmodel');
				//Load the pagination language file
				$this->lang->load('pagination', $this->config->item('language_code'));
				$perPage = $this->paginationmodel->getPerPage('photos');
				$start = (trim($this->uri->segment(3)) != '' && is_numeric($this->uri->segment(3)) && $this->uri->segment(3) > 0) ? $this->uri->segment(3) : 1;
				$start = ($start - 1) * $perPage;
				$outputData['albumPrefix'] = $this->config->item('photo_album_prefix');
				$outputData['photoPrefix'] = $this->config->item('photo_prefix');
				$outputData['friendsAlbums'] = $this->photomodel->getFriendsAlbums($this->session->userdata('user_id'), 'datestamp desc', $start, $perPage);
				$outputData['friendsAlbumsCount'] = $this->photomodel->getFriendsAlbumsCount($this->session->userdata('user_id'));
				$outputData['currentPage'] = (trim($this->uri->segment(3)) != '' && is_numeric($this->uri->segment(3))) ? $this->uri->segment(3) : 1;
				$outputData['totalPages'] = ($outputData['friendsAlbumsCount'] > $perPage) ? ceil(($outputData['friendsAlbumsCount'] / $perPage)) : 0;
				$outputData['pageUrl'] = base_url() . 'photos/friendsalbum/';
				$outputData['endCount'] = $start + count($outputData['friendsAlbums']);
				$outputData['startCount'] = $start + 1;
				if ($this->session->userdata('result_msg') != '')
				{
						$outputData['result_msg'] = $this->session->userdata('result_msg');
						$this->session->set_userdata(array("result_msg" => ''));
				}
				$this->smartyextended->view('photosfriendsalbums', $outputData);
		}
		function createalbum()
		{
				$this->load->model('usermodel');
				//Load the validation lib
				$this->load->library('validation');
				$this->_createAlbumFrmRules();
				$outputData['albumVisibilitySettings'] = $this->photomodel->getAlbumVisibilitySettings();
				//Do the validation
				if ($this->validation->run() == false)
				{
						//check maximum album per user
						$this->load->model('settingsModel');
						$settings = $this->settingsmodel->readSetting('total_albums_per_user');
						$albumPerUser = $settings['total_albums_per_user'];
						$curUserAlbumCnt = $this->photomodel->getAlbumsCount('active', $this->session->userdata('user_id'));
						if ($curUserAlbumCnt > $albumPerUser or $curUserAlbumCnt == $albumPerUser)
						{
								//$outputData['validationError']	= $this->lang->line('photos_maximum_album_reached_err');
								$this->session->set_flashdata('flash_msg_error', $this->lang->line('photos_maximum_album_reached_err'));
								redirect('photos/myphotos');
						}
						else //Oops! validation Error.
 										$outputData['validationError'] = $this->validation->error_string;
						$outputData['userJoinedInNw'] = $this->usermodel->isUserJoinedAnyNetworks();
						$outputData['userNetworks'] = $this->usermodel->getUserNetworks();
						$outputData['privacy'] = $this->photomodel->getAlbumVisibilitySettings(); //$this->usermodel->getPrivacy();
						$this->smartyextended->view('photosalbumcreate', $outputData);
				}
				else
				{
						$albumID = $this->photomodel->newAlbum($this->input->post('album_name'), $this->input->post('album_location'), $this->input->post('album_desc'), $this->input->post('create_album_privacy'));
						if ($albumID == false)
						{
								//Oops! validation Error.
								$outputData['validationError'] = $this->lang->line('photos_create_album_info_error');
								$outputData['userJoinedInNw'] = $this->usermodel->isUserJoinedAnyNetworks();
								$outputData['userNetworks'] = $this->usermodel->getUserNetworks();
								$outputData['privacy'] = $this->photomodel->getAlbumVisibilitySettings(); //$this->usermodel->getPrivacy();
								$this->smartyextended->view('photosalbumcreate', $outputData);
						}
						else
						{
								if ($this->usermodel->isUserJoinedAnyNetworks() and $this->input->post('create_album_privacy') == '3')
								{
										$networkArray = array();
										if ($this->input->post('chk_network')) $networkArray = $this->input->post('chk_network');
										$this->photomodel->updateAlbumVisibility($networkArray, $albumID);
								}
								//Load the config file related to photo
								$this->config->load('photo');
								$albumPath = APPPATH . 'content/photos/' . $this->config->item('photo_album_prefix') . $albumID . '/';
								//create the album dir.
								if (!file_exists($albumPath))
								{
										mkdir($albumPath);
								}
								redirect('photos/uploadphoto/' . $albumID);
						}
				}
		}
		function _createAlbumFrmRules()
		{
				$rules['album_name'] = 'trim|required|min_length[4]|max_length[25]';
				$rules['album_location'] = 'trim|max_length[25]';
				$this->validation->set_rules($rules);
				$fields['album_name'] = $this->lang->line('photos_label_album_name');
				$fields['album_location'] = $this->lang->line('photos_label_location');
				$this->validation->set_fields($fields);
		}
		function uploadphoto()
		{
				$outputData['albumId'] = $this->uri->segment(3);
				$outputData['albumDetails'] = $this->photomodel->getAlbumDetails($outputData['albumId']);
				if ($outputData['albumDetails'] != false && $outputData['albumDetails']['user_id'] == $this->session->userdata('user_id'))
				{
						$this->load->model('settingsModel');
						$settings = $this->settingsmodel->readSetting('total_photos_per_album');
						$photosPerAlbum = $settings['total_photos_per_album'];
						$curAlbumPhotos = 0;
						$photos = $this->photomodel->getPhotos($outputData['albumId']);
						if (is_array($photos)) $curAlbumPhotos = count($this->photomodel->getPhotos($outputData['albumId']));
						if ($curAlbumPhotos > $photosPerAlbum or $curAlbumPhotos == $photosPerAlbum) //check maximum photos per album

						{
								//$outputData['validationError']	= $this->lang->line('photos_maximum_photos_reached_err');
								$this->session->set_flashdata('flash_msg_error', $this->lang->line('photos_maximum_photos_reached_err'));
								redirect('photos/viewalbum/' . $outputData['albumId']);
						}
						else
						{
								$eligible = ($photosPerAlbum - $curAlbumPhotos);
								$cnt = 0;
								$i = 1;
								for ($i = 1; $i <= count($_FILES); $i++)
								{
										if (isset($_FILES['userfile' . $i]['name']) && $_FILES['userfile' . $i]['name'] != '')
										{
												$cnt++;
										}
								}
								$nowUplaoding = $cnt + $curAlbumPhotos;
								if ($nowUplaoding > $photosPerAlbum) //check maximum photos per album

								{
										//$outputData['validationError']	= $this->lang->line('photos_eligible_photos_reached_err').' '.$eligible.' '.$this->lang->line('photos_label_photos');
										$this->session->set_flashdata('flash_msg_error', $this->lang->line('photos_eligible_photos_reached_err') . ' ' . $eligible . ' ' . $this->lang->line('photos_label_photos'));
										redirect('photos/viewalbum/' . $outputData['albumId']);
								}
								else
								{
										//Load the config file related to photo
										$this->config->load('photo');
										//Upload path where the files are needs to be uploaded
										$uploadPath = APPPATH . 'content/photos/' . $this->config->item('photo_album_prefix') . $outputData['albumId'] . '/';
										//Check whether the upload path exist. if not creat it.
										if (!file_exists($uploadPath))
										{
												mkdir($uploadPath);
										}
										$config['upload_path'] = $uploadPath;
										$config['allowed_types'] = $this->config->item('photo_allowed_types');
										$config['max_size'] = $this->config->item('photo_max_size');
										$config['max_width'] = $this->config->item('photo_max_width');
										$config['max_height'] = $this->config->item('photo_max_height');
										$this->load->library('upload');
										$this->load->library('image_lib');
										$this->load->library('ImageTransform');
										//Form posted
										if (isset($_POST) && count($_POST) > 0)
										{
												$i = 1;
												for ($i = 1; $i <= count($_FILES); $i++)
												{
														if (isset($_FILES['userfile' . $i]['name']) && $_FILES['userfile' . $i]['name'] != '')
														{
																//initial the upload lib
																$this->upload->initialize($config);
																//upload the file
																if (!$this->upload->do_upload('userfile' . $i))
																{
																		//File upload error
																		$error['error_msg'] = $this->upload->display_errors('', '');
																		$error['details'] = $_FILES['userfile' . $i];
																		$outputData['uploadError'][] = $error;
																}
																else
																{
																		$slideImgFlag = false;
																		//File uploaded successfully. Get the uploaded photo details
																		$uploadedData = $this->upload->data('userfile' . $i);
																		$newPhotoDetails = array('album_id' => $outputData['albumId'], 'caption' => $uploadedData['raw_name'], 'photo_ext' => $uploadedData['file_ext'], 'photo_status' => 'active');
																		$photoId = $this->photomodel->newPhoto($newPhotoDetails);
																		//thumb image creation process starts here
																		$this->imagetransform->sourceFile = $uploadPath . $uploadedData['file_name'];
																		$this->imagetransform->targetFile = $uploadPath . $this->config->item('photo_prefix') . $outputData['albumId'] . '_' . $photoId . '_thumb' . $uploadedData['file_ext'];
																		$this->imagetransform->resizeToWidth = $this->config->item('photo_thumb_width');
																		$this->imagetransform->resizeToHeight = $this->config->item('photo_thumb_height');
																		$this->imagetransform->resize();
																		//medium image creation process ends here
																		//slide show image creation process starts here
																		$this->imagetransform->sourceFile = $uploadPath . $uploadedData['file_name'];
																		$this->imagetransform->targetFile = $uploadPath . $this->config->item('photo_prefix') . $outputData['albumId'] . '_' . $photoId . '_slide' . $uploadedData['file_ext'];
																		$this->imagetransform->resizeToWidth = $this->config->item('photo_slide_width');
																		$this->imagetransform->resizeToHeight = $this->config->item('photo_slide_height');
																		$this->imagetransform->resize();
																		//rename the photos
																		rename($uploadPath . $uploadedData['file_name'], $uploadPath . $this->config->item('photo_prefix') . $outputData['albumId'] . '_' . $photoId . $uploadedData['file_ext']);
																		//Load the user model
																		$this->load->model('usermodel');
																		$userFeedSettings = $this->usermodel->getUserFeedSetting();
																		if (isset($userFeedSettings[15]) && $userFeedSettings[15] == 'yes')
																		{
																				//Load the minifeed model
																				$albumDetails = $this->photomodel->getAlbumDetails($newPhotoDetails['album_id']);
																				$this->load->model('minifeedmodel');
																				$splVars = array('~~postedBy~~' => $this->session->userdata('username'), '~~photoName~~' => $newPhotoDetails['caption'], '~~albumName~~' => $albumDetails['name']);
																				$albumViewLink = base_url() . 'photos/viewalbum/' . $newPhotoDetails['album_id'];
																				$photoViewLink = base_url() . 'photos/slideshow/' . $newPhotoDetails['album_id'] . '/' . $photoId;
																				$this->minifeedmodel->postMiniFeed('ADD_PHOTO', $splVars, array($photoViewLink, $albumViewLink));
																		}
																		//Set the album cover
																		if (trim($outputData['albumDetails']['album_cover']) == 0)
																		{
																				$this->photomodel->updateAlbum(array('album_cover' => $photoId, 'album_cover_ext' => $uploadedData['file_ext']), $outputData['albumId']);
																		}
																} //End of if..else
														} //End of if
												} //End of for
												$outputData['uploadErrorCount'] = (isset($outputData['uploadError'])) ? count($outputData['uploadError']) : 0;
												if ($outputData['uploadErrorCount'] == 0)
												{
														//All process completed successfully. Go to the album view page
														redirect('photos/viewalbum/' . $outputData['albumId']);
												}
										} //end if posted
								}
						} //end check maximum photos per album
						$this->smartyextended->view('photosalbumuploadphoto', $outputData);
				}
				else  redirect('photos');
		}
		function _resizeImage($imgFile, $width, $height, $thumbMarker = false)
		{
				$config['image_library'] = 'GD2';
				$config['source_image'] = $imgFile;
				$config['create_thumb'] = true;
				$config['maintain_ratio'] = true;
				$config['width'] = $width;
				$config['height'] = $height;
				if ($thumbMarker) $config['thumb_marker'] = '_slide';
				$this->image_lib->initialize($config);
				if (!$this->image_lib->resize())
				{
						return $this->image_lib->display_errors('', '');
				}
				else  return true;
		}
		function editAlbum()
		{
				//Load the config file related to photo
				$this->config->load('photo');
				$this->load->model('usermodel');
				$outputData['albumPrefix'] = $this->config->item('photo_album_prefix');
				$outputData['photoPrefix'] = $this->config->item('photo_prefix');
				$outputData['albumId'] = $this->uri->segment(3);
				$outputData['albumDetails'] = $this->photomodel->getAlbumDetails($outputData['albumId']);
				if ($outputData['albumDetails'] != false)
				{
						//Load the validation lib
						$this->load->library('validation');
						$this->_createAlbumFrmRules();
						//Do the validation
						if ($this->validation->run() == false)
						{
								//Oops! validation Error.
								$outputData['userJoinedInNw'] = $this->usermodel->isUserJoinedAnyNetworks();
								$outputData['userNetworks'] = $this->usermodel->getUserNetworks();
								$outputData['privacy'] = $this->photomodel->getAlbumVisibilitySettings(); //$this->usermodel->getPrivacy();
								$outputData['albumPhotos'] = $this->photomodel->getAlbumPhotos($outputData['albumId']);
								$outputData['albumVisibilityNetworks'] = $this->photomodel->getAlbumVisibilityNetworks($outputData['albumId']);
								$outputData['validationError'] = $this->validation->error_string;
								if (isset($_POST) && is_array($_POST) && count($_POST) > 0)
								{
										$outputData['posted'] = 1;
										$outputData['visibility_id'] = $_POST['create_album_privacy'];
								}
								else  $outputData['posted'] = 0;
								$this->smartyextended->view('photoseditalbum', $outputData);
						}
						else
						{
								$albumDetails = array("name" => $_POST['album_name'], "location" => $_POST['album_location'], "description" => $_POST['album_desc'], "visibility_id" => $_POST['create_album_privacy']);
								if ($this->photomodel->updateAlbum($albumDetails, $outputData['albumId'])) $this->session->set_flashdata('flash_msg_success', $this->lang->line('photos_edit_album_info_success'));
								//$this->session->set_userdata(array("success_msg"=>$this->lang->line('photos_edit_album_info_success')));
								else  $this->session->set_flashdata('flash_msg_error', $this->lang->line('photos_edit_album_info_error'));
								//$this->session->set_userdata(array("success_msg"=>$this->lang->line('photos_edit_album_info_error')));
								if ($this->usermodel->isUserJoinedAnyNetworks() and $_POST['create_album_privacy'] == '3')
								{
										$networkArray = array();
										if ($this->input->post('chk_network')) $networkArray = $this->input->post('chk_network');
										$this->photomodel->updateAlbumVisibility($networkArray, $outputData['albumId']);
								}
								redirect("photos/viewalbum/" . $outputData['albumId']);
						}
				}
				else  redirect('photos');
		}
		function viewalbum()
		{
				//Load the config file related to photo
				$this->config->load('photo');
				$outputData['albumPrefix'] = $this->config->item('photo_album_prefix');
				$outputData['photoPrefix'] = $this->config->item('photo_prefix');
				$outputData['thumb_width'] = $this->config->item('photo_thumb_width');
				$outputData['thumb_height'] = $this->config->item('photo_thumb_height');
				$outputData['albumId'] = $this->uri->segment(3);
				$outputData['albumDetails'] = $this->photomodel->getAlbumDetails($outputData['albumId']);
				if ($this->photomodel->checkVisibility($outputData['albumId']))
				{
						if ($outputData['albumDetails'] != false)
						{
								//Load the pagination model
								$this->load->model('paginationmodel');
								$perPage = 8; //$this->paginationmodel->getPerPage('photos');
								$start = (trim($this->uri->segment(4)) != '' && is_numeric($this->uri->segment(4)) && $this->uri->segment(4) > 0) ? $this->uri->segment(4) : 1;
								$start = ($start - 1) * $perPage;
								$outputData['albumPhotos'] = $this->photomodel->getAlbumPhotos($outputData['albumId'], 'datetime desc', $start, $perPage);
								$outputData['albumPhotosCount'] = count($outputData['albumPhotos']);
								$outputData['albumPhotosTotal'] = $this->photomodel->getAlbumPhotosCount($outputData['albumId']);
								$outputData['currentPage'] = (trim($this->uri->segment(4)) != '' && is_numeric($this->uri->segment(4))) ? $this->uri->segment(4) : 1;
								$outputData['totalPages'] = ($outputData['albumPhotosTotal'] > $perPage) ? ceil(($outputData['albumPhotosTotal'] / $perPage)) : 0;
								$outputData['pageUrl'] = base_url() . 'photos/viewalbum/' . $this->uri->segment(3) . '/';
								$this->smartyextended->view('photosviewalbum', $outputData);
						}
						else  redirect('photos');
				}
				else  redirect('photos');
		}
		function editAlbumPhotos()
		{
				//Load the config file related to photo
				$this->config->load('photo');
				$outputData['albumPrefix'] = $this->config->item('photo_album_prefix');
				$outputData['photoPrefix'] = $this->config->item('photo_prefix');
				$outputData['albumId'] = $this->uri->segment(3);
				$outputData['albumDetails'] = $this->photomodel->getAlbumDetails($outputData['albumId']);
				if ($outputData['albumDetails'] != false)
				{
						if (isset($_POST) && is_array($_POST) && count($_POST) > 0)
						{
								//Set the album cover
								if (isset($_POST['albumcover']))
								{
										$photoId = $_POST['albumcover'];
										$this->photomodel->updateAlbum(array('album_cover' => $photoId, 'album_cover_ext' => $_POST['fileext'][$photoId]), $outputData['albumId']);
								}
								//Delete the selected photos
								if (isset($_POST['deletephoto']))
								{
										foreach ($_POST['deletephoto'] as $photoId => $deletePhoto)
										{
												$this->photomodel->removePhoto($photoId);
												//						if($this->photomodel->removePhoto($photoId))
												//						{
												//							//Delete the file & thumb
												//							$uploadPath		= APPPATH . 'content/photos/' . $this->config->item('photo_album_prefix') . $outputData['albumId'] . '/';
												//							@unlink($uploadPath . $this->config->item('photo_prefix') .  $outputData['albumId'] . '_' . $photoId . $_POST['fileext'][$photoId]);
												//							@unlink($uploadPath . $this->config->item('photo_prefix') .  $outputData['albumId'] . '_' . $photoId . '_thumb' . $_POST['fileext'][$photoId]);
												//						}
										}
								}
								//Update the photo captions
								if (isset($_POST['photocaption']))
								{
										foreach ($_POST['photocaption'] as $photoId => $photoCaption)
										{
												//Check whether the photo is selected for deletion
												if (!isset($_POST['deletephoto'][$photoId]))
												{
														$updatePhotoDetails = array('album_id' => $outputData['albumId'], 'caption' => $photoCaption);
														$this->photomodel->updatePhoto($updatePhotoDetails, $photoId);
												}
										}
								}
								//All process completed successfully. Go to the album view page
								redirect('photos/viewalbum/' . $outputData['albumId']);
						}
						$outputData['albumPhotos'] = $this->photomodel->getAlbumPhotos($outputData['albumId']);
						$outputData['photoCount'] = count($outputData['albumPhotos']);
						$this->smartyextended->view('photoseditalbumphotos', $outputData);
				}
				else  redirect('photos');
		}
		#***************************************************************************
		#Method			: slideshow
		#Description	: show all photos for the selected album as manual slide show
		#Arguents		: $albumId
		#				: $action	=> this is combination of action and photo id
		#								example, p29(p->previous,29->current photoId)
		#								n29(n->next,29->current photoId)
		#created by		: ilayaraja_22ag06
		#***************************************************************************
		function slideshow($albumId, $action = '')
		{
				$this->load->model('photomodel');
				$this->load->model('usermodel');
				$this->load->model('wallmodel');
				if ($this->input->post('rotate')) //if rotate is clicked

				{
						$imgPath = $this->input->post('imgPath');
						$rotateType = $this->input->post('rotate_type');
						$rotateAngle = $this->input->post('rotate_angle');
						$pathArry = explode(".", $imgPath);
						$thumbPath = $pathArry[0] . '_thumb.' . $pathArry[1];
						$slidePath = $pathArry[0] . '_slide.' . $pathArry[1];
						$this->rotateImage($this->input->post('imgPath'), $rotateType, $rotateAngle);
						$this->rotateImage($thumbPath, $rotateType, $rotateAngle);
						$this->rotateImage($slidePath, $rotateType, $rotateAngle);
				}
				$this->session->set_userdata(array("slide_show_album_id" => '', "slide_show_photo_ids" => ''));
				if ($albumId != '' and $albumId > 0 and $this->photomodel->isAlbum($albumId) and $this->photomodel->checkVisibility($albumId))
				{
						if ($this->session->userdata('slide_show_album_id') == '' or $this->session->userdata('slide_show_album_id') != $albumId or $action == '')
						{
								$photoIds = $this->photomodel->getPhotos($albumId);
								$this->session->set_userdata(array("slide_show_album_id" => $albumId, "slide_show_photo_ids" => $photoIds));
						}
						$photos = $this->session->userdata('slide_show_photo_ids'); //get all photo ids for the current albumId
						if (is_array($photos) and !empty($photos))
						{
								if ($action != '')
								{
										$process = substr($action, 0, 1);
										$prevPhotoId = substr($action, 1, (strlen($action) - 1));
										if (($process != 'n' or $process != 'p') and $process > 0)
										{
												$process = '';
												$prevPhotoId = $action;
										}
								}
								else
								{
										$process = ''; //default action,'n=>next'
										$prevPhotoId = $photos[0]; //default photoId, from the photoIds array
								}
								$curPhotoKey = array_search($prevPhotoId, $photos);
								if ($process == 'n')
								{
										if (($curPhotoKey + 1) >= count($photos)) $exactKey = 0;
										else  $exactKey = $curPhotoKey + 1;
								} elseif ($process == 'p')
								{
										if (($curPhotoKey - 1) < 0) $exactKey = count($photos) - 1;
										else  $exactKey = $curPhotoKey - 1;
								}
								else  $exactKey = $curPhotoKey;
								$albumDetails = $this->photomodel->getAlbumDetails($albumId);
								$photoDetails = $this->photomodel->getPhotoDetails($photos[$exactKey]);
								$outputData['album_owner'] = $this->usermodel->getName($albumDetails['user_id']);
								$outputData['album_owner_avatar'] = $this->usermodel->getAvatar($albumDetails['user_id']);
								$outputData['album_name'] = $albumDetails['name'];
								$outputData['album_details'] = $albumDetails;
								$outputData = array_merge($outputData, $photoDetails);
								//For wall
								$outputData['wall'] = $this->wallmodel->getWall('photo', $outputData['photo_id'], 'wall_date desc', 0, 5);
								$outputData['wallCount'] = count($outputData['wall']);
								$outputData['wallTotal'] = $this->wallmodel->getWallCount('photo', $outputData['photo_id']);
								$outputData['prev_action'] = $action;
								$totalPhotos = $this->photomodel->getPhotos($albumId);
								if (is_array($totalPhotos)) $outputData['total_photos'] = count($totalPhotos);
								$this->smartyextended->view('photosslideshow', $outputData);
						}
						else  redirect("photos");
				}
				else  redirect("photos");
		} //end show()
		#***************************************************************************
		#Method			: rotateImage()
		#Description	: rotate image by left or right
		#created by		: ilayaraja_22ag06
		#***************************************************************************
		function rotateImage($imgPath, $rotateType = 'left', $rotateAngle = '90')
		{
				/*$result		= '';
				$config		= array();
				$imgPath	= APPPATH.$imgPath;
				$config['source_image'] 	= $imgPath;
				$config['rotation_angle'] 	= 90;
				$this->load->library('image_lib');
				$this->image_lib->initialize($config);

				if ( ! $this->image_lib->rotate())
				{
				$result	= $this->image_lib->display_errors();
				}
				echo $result;*/
				$imgArry = explode(".", $imgPath);
				$type = $imgArry[1];
				$imgPath = APPPATH . $imgPath;
				if ($rotateType == 'right') $degrees = intval('-' . $rotateAngle);
				else  $degrees = intval($rotateAngle);
				if ($type == "jpeg" || $type == "jpg")
				{
						$source = imagecreatefromjpeg($imgPath); // Load
						$rotate = imagerotate($source, $degrees, 0); // Rotate
						imagejpeg($rotate, $imgPath);
				} elseif ($type == "gif")
				{
						$source = imagecreatefromgif($imgPath); // Load
						$rotate = imagerotate($source, $degrees, 0); // Rotate
						imagegif($rotate, $imgPath);
				} elseif ($type == "bmp")
				{
						$source = imagecreatefromwbmp($imgPath); // Load
						$rotate = imagerotate($source, $degrees, 0); // Rotate
						imagewbmp($rotate, $imgPath);
				} elseif ($type == "png")
				{
						$source = imagecreatefrompng($imgPath); // Load
						$rotate = imagerotate($source, $degrees, 0); // Rotate
						imagepng($rotate, $imgPath);
				}
		} //end rotateImage()
		#***************************************************************************
		#Method			: deletephoto()
		#Description	: delete album photo
		#created by		: ilayaraja_22ag06
		#***************************************************************************
		function deletephoto()
		{
				$this->load->model('photomodel');
				if ($this->input->post('photo_del_submit'))
				{
						$photoId = $this->input->post('hdn_photo_id');
						$albumId = $this->input->post('hdn_album_id');
						if ($this->photomodel->removePhoto($photoId))
						{
								$this->load->model('postedmodel');
								$this->postedmodel->deletePostByType('photo', $photoId); //delete all posts for this photo
								$this->session->set_flashdata('flash_msg_success', $this->lang->line('photos_del_success_msg'));
								$this->session->set_userdata(array("slide_show_album_id" => '', "slide_show_photo_ids" => ''));
						}
						redirect("photos/viewalbum/" . $albumId);
				}
				else  redirect("photos");
		}
		#***************************************************************************
		#Method			: deletealbum()
		#Description	: delete entire album
		#created by		: ilayaraja_22ag06
		#***************************************************************************
		function deletealbum()
		{
				$this->load->model('photomodel');
				if ($this->input->post('album_del_submit'))
				{
						$albumId = $this->input->post('hdn_album_id');
						$photoIds = $this->photomodel->getPhotos($albumId);
						if ($this->photomodel->removeAlbum($albumId))
						{
								//delete all post for the given album,ie all photos from the album
								$this->load->model('postedmodel');
								foreach ($photoIds as $key => $value) $this->postedmodel->deletePostByType('photo', $value); //delete all posts for this photo
								$this->session->set_userdata(array("slide_show_album_id" => '', "slide_show_photo_ids" => ''));
								//Set the flash data
								$this->session->set_flashdata('flash_msg_success', $this->lang->line('photos_album_del_success_msg'));
						}
						else //Set the flash data
 										$this->session->set_flashdata('flash_msg_error', $this->lang->line('photos_album_del_error_msg'));
				}
				redirect("photos/myphotos");
		}
		function myphotos($userId = '')
		{
				//Load the config file related to photo
				$this->config->load('photo');
				if ($userId == '') $userId = $this->session->userdata('user_id');
				if ($this->usermodel->isMember($userId))
				{
						//Load the pagination model
						$this->load->model('paginationmodel');
						//Load the pagination language file
						$this->lang->load('pagination', $this->config->item('language_code'));
						$perPage = $this->paginationmodel->getPerPage('photos');
						$start = (trim($this->uri->segment(4)) != '' && is_numeric($this->uri->segment(4)) && $this->uri->segment(4) > 0) ? $this->uri->segment(4) : 1;
						$start = ($start - 1) * $perPage;
						$this->load->model('usermodel');
						$outputData['albumPrefix'] = $this->config->item('photo_album_prefix');
						$outputData['photoPrefix'] = $this->config->item('photo_prefix');
						$outputData['userAlbums'] = $this->photomodel->getUserAlbums($userId, 'datestamp desc', $start, $perPage);
						$outputData['userAlbumsCount'] = $this->photomodel->getUserAlbumsCount($userId);
						$outputData['username'] = $this->usermodel->getName($userId);
						$outputData['userId'] = $userId;
						$outputData['userAvatar'] = $this->usermodel->getAvatar($userId);
						$outputData['currentPage'] = (trim($this->uri->segment(4)) != '' && is_numeric($this->uri->segment(4))) ? $this->uri->segment(4) : 1;
						$outputData['totalPages'] = ($outputData['userAlbumsCount'] > $perPage) ? ceil(($outputData['userAlbumsCount'] / $perPage)) : 0;
						$outputData['pageUrl'] = base_url() . 'photos/myphotos/' . $userId . '/';
						$outputData['endCount'] = $start + count($outputData['userAlbums']);
						$outputData['startCount'] = $start + 1;
						$this->smartyextended->view('photosmyphotoalbums', $outputData);
				}
				else  redirect("home");
		}
}

?>