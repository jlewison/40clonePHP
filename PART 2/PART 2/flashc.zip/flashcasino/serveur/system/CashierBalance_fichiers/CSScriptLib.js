// -- Adobe GoLive JavaScript Library
// -- Global Functions
CSAg = window.navigator.userAgent; CSBVers = parseInt(CSAg.charAt(CSAg.indexOf("/")+1),10);
CSIsW3CDOM = ((document.getElementById) && !(IsIE()&&CSBVers<6)) ? true : false;
function IsIE() { return CSAg.indexOf("MSIE") > 0;}
function newImage(arg) {
	if (document.images) {
		rslt = new Image();
		rslt.src = arg;
		return rslt;
	}
}
function changeImages() {
	d = document;
	if (d.images) {
		//for (var b=0; b < d.images.length; b++)
		//{
		//	alert('name='+d.images[b].name+', src='+d.images[b].src);
		//}
		var img;
		for (var i=0; i<changeImages.arguments.length; i+=2) {
			img = null;
			if (d.layers) {img = findElement(changeImages.arguments[i],0);}
			else {
				img = d.images[changeImages.arguments[i]];
			}
			if (img) {
			img.src = changeImages.arguments[i+1];
			}

		}
	}
}
// EOF
