<?php

	$lang['load_template_error']	= 'Unable to load the requested template file: %s';

?>