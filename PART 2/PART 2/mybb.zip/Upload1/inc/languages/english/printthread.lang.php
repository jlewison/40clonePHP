<?php 
/**
 * MyBB 1.4 English Language Pack
 * Copyright © 2008 MyBB Group, All Rights Reserved
 * 
 * $Id: printthread.lang.php 4304 2009-01-02 01:11:56Z chris $
 */

$l['forum'] = "Forum:";
$l['printable_version'] = "Printable Version";
$l['thread'] = "Thread:";
?>