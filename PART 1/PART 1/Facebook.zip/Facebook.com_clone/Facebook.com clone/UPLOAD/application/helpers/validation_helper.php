<?php

/**
 * validation helper Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 1/9/2008
 */
function isValidEmail($email, $required = true)
{
		if ($required && trim($email) == '') return false;
		if (trim($email) !== '')
		{
				$pattern = "/^[a-zA-Z0-9]([a-zA-Z0-9]*\_[a-zA-Z0-9]+)*([a-zA-Z0-9\-]*\.[a-zA-Z0-9\-]+)*[a-zA-Z0-9]*@[a-zA-Z0-9]{2,}\.[a-zA-Z0-9]{2,}(\.[a-zA-Z0-9]{2,})?$/";
				if (preg_match($pattern, $email)) return true;
				else  return false;
		}
		else  return true;
}
function valid_url($str, $required = true)
{
		if ($required && trim($str) == '') return false;
		// SCHEME
		$urlregex = "^(https?|ftp)\:\/\/";
		// USER AND PASS (optional)
		$urlregex .= "([a-z0-9+!*(),;?&=\$_.-]+(\:[a-z0-9+!*(),;?&=\$_.-]+)?@)?";
		// HOSTNAME OR IP
		$urlregex .= "[a-z0-9+\$_-]+(\.[a-z0-9+\$_-]+)*"; // http://x = allowed (ex. http://localhost, http://routerlogin)
		//$urlregex .= "[a-z0-9+\$_-]+(\.[a-z0-9+\$_-]+)+";  // http://x.x = minimum
		//$urlregex .= "([a-z0-9+\$_-]+\.)*[a-z0-9+\$_-]{2,3}";  // http://x.xx(x) = minimum
		//use only one of the above
		// PORT (optional)
		$urlregex .= "(\:[0-9]{2,5})?";
		// PATH  (optional)
		$urlregex .= "(\/([a-z0-9+\$_-]\.?)+)*\/?";
		// GET Query (optional)
		$urlregex .= "(\?[a-z+&\$_.-][a-z0-9;:@/&%=+\$_.-]*)?";
		// ANCHOR (optional)
		$urlregex .= "(#[a-z_.-][a-z0-9+\$_.-]*)?\$";
		// check
		return (eregi($urlregex, $str)) ? true : false;
}

?>