<?php

class AnalystsFormHanlder extends ListRecordsHandler
{
		public function buildConditionQuery()
		{
				$this->sql_condition = 'u.' . $this->getUserTableField('user_id') . '=ua.user_id AND u.' . $this->getUserTableField('usr_status') . '=\'Ok\'';
		}
		public function buildSortQuery()
		{
				$this->sql_sort = $this->fields_arr['orderby_field'] . ' ' . $this->fields_arr['orderby'];
		}
		public function displayTopAnalysts()
		{
				if (!$this->isResultsFound())
				{
?>
					<div id="selMsgAlert">
						<p><?php echo $this->LANG['analysts_no_records']; ?></p>
					</div>
					<?php
						return;
				}
?>
				<table summary="<?php echo $this->LANG['display_all_analysts']; ?>" id="selForumTable">
					<tr>
			         <th class="clsCenter clsForumSubject"><?php echo $this->LANG['analysts_name'] ?></th>
			         <th class="clsCenter"><div class="clsMiddleTitle"><?php echo $this->LANG['analysts_points']; ?></div></th>
			         <th class="clsCenter clsReplies"><div class="clsMiddleTitle"><?php echo $this->LANG['analysts_questions']; ?></div></th>
			         <th class="clsCenter clsLastPost"><?php echo $this->LANG['analysts_answers'] ?></th>
			       </tr>
				<?php
				$i = 0;
				while ($row = $this->fetchResultRecord())
				{
?>
					<tr>
					<td class="clsCenter">
							<?php if (chkUserImageAllowed())
						{ ?>
							<p id="selImageBorder"><?php displayTopAnalystSmallImage($row, true, true); ?></p>
							<?php } ?>
							<a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'myanswers.php?uid=' . $row['user_id'], $this->CFG['site']['relative_url'] . 'my/answers/' . $row['user_id'] . '/', false); ?>"><?php echo stripString($row['analyst_by'], $this->CFG['username']['short_length']); ?></a>
						</td>
						<td class="clsCenter"><span class="clsTotalPoints"><?php echo $row['total_points']; ?></span></td>
						<td class="clsCenter"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'questions.php?act=search&uname=' . $row['analyst_by'] . '&opt=ques', $this->CFG['site']['relative_url'] . 'answers/search/?uname=' . $row['analyst_by'] . '&opt=ques', false); ?>"><?php echo $row['total_ques']; ?></a></td>
						<td class="clsCenter"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'questions.php?act=search&uname=' . $row['analyst_by'] . '&opt=ans', $this->CFG['site']['relative_url'] . 'answers/search/?uname=' . $row['analyst_by'] . '&opt=ans', false); ?>"><?php echo $row['total_ans']; ?></a></td>
					</tr>
				<?php
						$i++;
				}


?>
				</table>
				<?php
				$pagingArr = array();
				if ($this->CFG['admin']['navigation']['bottom']) $this->populatePageLinks($this->getFormField('start'), $pagingArr);
		}
}
$analysts = new AnalystsFormHanlder();
$analysts->setCfgLangGlobal($CFG, $LANG);
$analysts->setPageBlockNames(array('form_search', 'form_analysts', 'msg_form_error', 'msg_form_success'));
$analysts->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$analysts->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$analysts->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$analysts->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$analysts->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$analysts->setFormField('search_question', '');
$pagename = 'Top Analysts';
$title = 'Top Analysts';
$cfg_title = ' - ' . $title;
$analysts->setDBObject($db);
$analysts->numpg = $CFG['data_tbl']['numpg'];
$analysts->setFormField('start', 0);
$analysts->setFormField('numpg', $CFG['data_tbl']['numpg']);
$analysts->setMinRecordSelectLimit($CFG['data_tbl']['min_record_select_limit']);
$analysts->setMaxRecordSelectLimit($CFG['data_tbl']['max_record_select_limit']);
$analysts->setNumPerPageListArr($CFG['data_tbl']['numperpage_list_arr']);
$analysts->setTableNames(array());
$analysts->setReturnColumns(array());
$analysts->setFormField('orderby_field', '');
$analysts->setFormField('orderby', '');
$analysts->sanitizeFormInputs($_REQUEST);
$analysts->setAllPageBlocksHide();
$analysts->setPageBlockShow('form_search');
$analysts->setPageBlockShow('form_analysts');
$CFG['html']['page_id'] .= 'analysts';
$CFG['mods']['is_include_only']['non_html_header_files'] = false;
$CFG['mods']['is_include_only']['html_header'] = true;
$CFG['site']['title'] = $CFG['site']['title'] . $cfg_title;
require ($CFG['site']['project_path'] . 'common/application_top.inc.php');

?>
<script language="javascript" type="text/javascript">
var popupPosition = -10;
</script>
<div id="selListAll">
	<h2><?php echo $title; ?></h2>
<?php

$analysts->displayAnswersTopLinks();
if ($analysts->isShowPageBlock('msg_form_error'))
{
?>
    	<div id="selMsgError">
      		<p>
<?php
		echo $LANG['questions_err_sorry'] . ' ' . $analysts->getCommonErrorMsg();
?>
      		</p>
    	</div>
<?php
}
if ($analysts->isShowPageBlock('msg_form_success'))
{
?>
	    <div id="selMsgSuccess">
	      	<p>
<?php
		echo $analysts->getCommonErrorMsg();
?>
	      	</p>
	    </div>
    <?php
}
if ($analysts->isShowPageBlock('form_analysts'))
{
		$analysts->setTableNames(array($CFG['db']['tbl']['users_ans_log'] . ' as ua', $CFG['db']['tbl']['users'] . ' as u'));
		$analysts->setReturnColumns(array('ua.user_id', 'total_ques', 'total_ans', 'total_points', $analysts->getUserTableField('name') . ' as analyst_by', 'u.' . $analysts->getUserTableField('user_id') . ' as img_user_id', $analysts->getUserTableFields(array('image_path', 'gender', 't_height', 't_width', 's_height', 's_width', 'photo_server_url', 'photo_ext'), false) . 'TIMEDIFF(NOW(), date_updated) as date_updated'));
		$analysts->setFormField('orderby_field', 'ua.total_points');
		$analysts->setFormField('orderby', 'DESC');
		$analysts->buildSelectQuery();
		$analysts->buildConditionQuery();
		$analysts->buildSortQuery();
		$analysts->buildQuery();
		$analysts->executeQuery();
		$analysts->displayTopAnalysts();
}
?>
</div>
<?php
require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>