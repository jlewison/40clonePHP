<?php

header( 'location: ../flashchat.php' );

?>
