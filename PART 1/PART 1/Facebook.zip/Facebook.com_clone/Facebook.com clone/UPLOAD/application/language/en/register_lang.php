<?php

/**
* Language File for register
*
*
* @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
* @license
* @since 2007-12-13
*/

	$lang['page_title']	= 'Register';
	
	$lang['register_error_email_exists']	= 'Registration Error. Email already used for registration.';
	$lang['register_high_school_required']	= 'The High School field is required';
	$lang['register_confirm_success']		= 'Your account has been confirmed Successfully. You can Login now';
	$lang['register_date_invalid']			= 'The date selected is not valid';
	$lang['register_code_mismatch']			= 'Security Code does not match';
	$lang['register_the']					= 'The';
	$lang['register_required']				= 'field is required';
	$lang['register_fullname']				= 'Fullname';
	$lang['register_iam']					= 'I am';
	$lang['register_email']					= 'E-Mail';
	$lang['register_password']				= 'Password';
	$lang['register_security_answer']		= 'Security Answer';
	$lang['register_captcha']				= 'captcha';
	$lang['register_terms']					= 'Terms';
	
	$lang['register_signup_title']		= 'Sign Up and Start Using Kootali';
	$lang['register_join']				= 'Join';
	$lang['register_to']				= 'to';
	$lang['register_connect']			= 'connect with your friends';
	$lang['register_share']				= 'share photos';
	$lang['register_and']				= 'and';
	$lang['register_create_profile']	= 'create your own profile';
	$lang['register_fill_form']			= 'Fill out the form below to get started';
	$lang['register_fields_required']	= 'all fields are required to sign up';
	$lang['register_college_status']	= 'College / School Status';
	$lang['register_class_year']		= 'Class Year';
	$lang['register_high_school']		= 'High School';
	$lang['register_birthday']			= 'Birthday';
	$lang['register_security_question']	= 'Security Question';
	$lang['register_security_check']	= 'Security Check';
	$lang['register_text_in_box']		= 'Text in the box';
	$lang['register_not_readable']		= 'Can\'t read this';
	$lang['register_try_another']		= 'Try another';
	$lang['register_agree_terms']		= 'I have read and agree to the';
	$lang['register_terms_title']		= 'Terms of Use';
	$lang['register_privacy_policy']	= 'Privacy Policy';
	$lang['register_signup_problem']	= 'Problems signing up';
	$lang['register_help_page']			= 'Check out our help pages';
	
	$lang['register_complete']			= 'Sign Up Complete';
	$lang['register_success_note_1']	= 'Sign Up completed successfully. We have sent a mail to';
	$lang['register_success_note_2']	= 'to confirm your account.Please confirm your account before login';
	
?>