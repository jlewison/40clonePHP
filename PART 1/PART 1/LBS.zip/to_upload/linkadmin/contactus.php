<?php include('restrict.php'); include('../settings.php'); require_once('../Connections/apound.php'); ?>
<?php
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = (!get_magic_quotes_gpc()) ? addslashes($theValue) : $theValue;

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form1")) {
  $updateSQL = sprintf("UPDATE confset SET cntIM=%s WHERE indc=%s",
                       GetSQLValueString($_POST['cntIM'], "text"),
                       GetSQLValueString($_POST['indc'], "int"));

  mysql_select_db($database_apound, $apound);
  $Result1 = mysql_query($updateSQL, $apound) or die(mysql_error());
  $done = "<div align='center'><font color='red'><b>Update ... DONE</b></font></div>";
}

mysql_select_db($database_apound, $apound);
$query_cufSP = "SELECT confset.indc, confset.cntIM FROM confset";
$cufSP = mysql_query($query_cufSP, $apound) or die(mysql_error());
$row_cufSP = mysql_fetch_assoc($cufSP);
$totalRows_cufSP = mysql_num_rows($cufSP);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>Captcha Management - Link Bid Script Admin Panel</title>
<link rel="shortcut icon" href="img/favicon.ico" />
<link rel="stylesheet" type="text/css" href="admin.css" />
</head>

<body>
<?php $x = getenv("HTTP_HOST").getenv("REQUEST_URI"); ?>
<?php include('header_tpl.php'); ?>

<h2>Manage Spam Verification Images</h2>
<?php echo("$done");?>
<form method="post" name="form1" action="<?php echo $editFormAction; ?>">
  <table align="center" cellspacing="3" cellpadding="5">
    <tr valign="baseline">
      <td valign="baseline"><table>
          <tr>
            <td valign="top"><input type="radio" name="cntIM" value="Y" <?php if (!(strcmp($row_cufSP['cntIM'],"Y"))) {echo "CHECKED";} ?>></td>
              <td><span class="style67 style82">Enable Image Verification for SPAM protection</span><br />
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(<em>This function is only available if PHP is compiled with freetype support (--with-freetype-dir=DIR)</em>)</td>
            </tr>
          <tr>
            <td valign="top"><input type="radio" name="cntIM" value="N" <?php if (!(strcmp($row_cufSP['cntIM'],"N"))) {echo "CHECKED";} ?>></td>
              <td valign="top"><span class="style67 style82">Disable Image Verification</span></td>
            </tr>
        </table>
    </tr>
    <tr valign="baseline">
      <td><input type="submit" class="login-but" value="Update settings"></td>
    </tr>
  </table>
  <input type="hidden" name="MM_update" value="form1">
  <input type="hidden" name="indc" value="<?php echo $row_cufSP['indc']; ?>">
</form>

<?php include('footer_tpl.php'); ?>
</body>
</html>
<?php
mysql_free_result($cufSP);
?>
