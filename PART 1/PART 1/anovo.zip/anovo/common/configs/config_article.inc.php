<?php
$CFG['admin']['blogs']['comment_edit_allowed_time'] = 120;
$CFG['admin']['blogs_editor'] = true;
$CFG['admin']['short_description_size'] = 200;
?>
