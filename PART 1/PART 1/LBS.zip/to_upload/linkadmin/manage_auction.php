<?php include('restrict.php'); include('../settings.php'); require_once('../Connections/apound.php'); ?>
<?php
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = (!get_magic_quotes_gpc()) ? addslashes($theValue) : $theValue;

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form1")) {
  $updateSQL = sprintf("UPDATE confset SET minbid=%s, minup=%s WHERE indc=%s",
                       GetSQLValueString($_POST['minbid'], "text"),
                       GetSQLValueString($_POST['minup'], "text"),
                       GetSQLValueString($_POST['indc'], "int"));

  mysql_select_db($database_apound, $apound);
  $Result1 = mysql_query($updateSQL, $apound) or die(mysql_error());

  $updateGoTo = "manage_auction.php?upd=Y";
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $updateGoTo));
}

mysql_select_db($database_apound, $apound);
$query_STP = "SELECT * FROM confset";
$STP = mysql_query($query_STP, $apound) or die(mysql_error());
$row_STP = mysql_fetch_assoc($STP);
$totalRows_STP = mysql_num_rows($STP);
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Manage Auctions - Link Bid Script Admin Panel</title>
<link rel="shortcut icon" href="img/favicon.ico" />
<link rel="stylesheet" type="text/css" href="admin.css" />
<style type="text/css">
<!--
.style84 {color: #FF0000}
#admnav li {
	padding-top: 0px;
	padding-bottom: 0px;
	margin-top: 0px;
	margin-bottom: 0px;
}
#admnav ul {
	padding-top: 0px;
	padding-bottom: 0px;
	margin-top: 0px;
	margin-bottom: 0px;
}
.style86 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
	font-weight: bold;
}
.style87 {color: #009900}
-->
</style>
</head>

<body>
<?php include('header_tpl.php'); ?>
<h2>Manage Minimum Bid and Upgrades</h2>
<table width="770"  border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="770" bgcolor="#FFFFFF"><?php $x = getenv("HTTP_HOST").getenv("REQUEST_URI"); echo("<font color=white>$x</font>"); ?></td>
  </tr>
</table>
<table width="770"  border="0" align="center" cellpadding="3" cellspacing="1" bgcolor="#FFFFFF">
  <tr>
    <td width="760" valign="top" bgcolor="#FFFFFF">    
      <table width="100%"  border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td>
          <?php $upd = $_GET[upd]; if($upd == 'Y') { echo("<div align='center'><font color='red'><b>Update ... DONE</b></font></div>"); } else { } ?>
          <form method="post" name="form1" action="<?php echo $editFormAction; ?>">
            <table align="center">
              <tr valign="baseline">
                <td nowrap align="right"><span class="style67 style87">Minimum Initial Bid:</span></td>
                <td><input name="minbid" type="text" class="edtab" value="<?php echo $row_STP['minbid']; ?>" size="9"></td>
              </tr>
              <tr valign="baseline">
                <td nowrap align="right"><span class="style67 style87">Minimum Upgrade Bid:</span></td>
                <td><input name="minup" type="text" class="edtab" value="<?php echo $row_STP['minup']; ?>" size="9"></td>
              </tr>
              <tr valign="baseline">
                <td nowrap align="right"><span class="style87"></span></td>
                <td><input type="submit" class="login-but" value="Update record"></td>
              </tr>
            </table>
            <input type="hidden" name="MM_update" value="form1">
            <input type="hidden" name="indc" value="<?php echo $row_STP['indc']; ?>">
          </form></td>
        </tr>
      </table></td>
  </tr>
</table>
<?php include('footer_tpl.php'); ?>
</body>
</html>
<?php
mysql_free_result($STP);
?>
