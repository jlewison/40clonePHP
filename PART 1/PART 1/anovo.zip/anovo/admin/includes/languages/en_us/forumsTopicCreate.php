<?php
$LANG['forumlistall_title_index'] = 'Forum Index';
$LANG['forumstopic_topic_start'] = 'Start New Topic';
$LANG['forumlistall_back_topic'] = 'Back to Forum Topics';
$LANG['forumslinks_header'] = 'Forums';
$LANG['forumslinks_post_topic'] = 'Post a Topic';
$LANG['forumslinks_List_topic'] = 'List Topics';
$LANG['forumslinks_search_topics'] = 'Search Topics';
$LANG['forumslinks_most_response'] = 'Most Response';
$LANG['forumslinks_most_views'] = 'Most Views';
$LANG['forumstopic_forum_title'] = 'Forum Title ';
$LANG['forumstopic_topic'] = 'Topic';
$LANG['forumstopic_subject'] = 'Subject';
$LANG['forumstopic_body'] = 'Body';
$LANG['forumstopic_response'] = 'Your Response';
$LANG['forumstopic_ratings'] = 'Rate This Topic (optional): ';
$LANG['forumstopic_ratings_information'] = '( 1 = lowest   and 10 = highest )';
$LANG['forumstopic_submit'] = 'Submit';
$LANG['forumstopic_cancel'] = 'Cancel';
$LANG['forumstopic_active'] = 'Active';
$LANG['forumstopic_inactive'] = 'Inactive';
$LANG['forumstopic_forum_title_description'] = 'Description:';
$LANG['forumstopic_err_tip_compulsory'] = 'Compulsory';
$LANG['forumstopic_err_tip_topic_exists'] = 'Topic already exists.';
$LANG['forumstopic_err_tip_invalid_forum_id'] = 'Invalid Forum ID.';
$LANG['forumstopic_err_tip_invalid_forum_topic_id'] = 'Invalid Forum Topic ID.';
$LANG['forumstopic_err_tip_cannot_create_forum_topic'] = 'You have already created XCOUNTX topics in this XFORUMX. You can\'t create any topics in this XFORUMX';
$LANG['forumstopic_tbl_summary'] = 'Container to create topic';
?>