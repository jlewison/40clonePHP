<?php

$profile_questions['1']['question'] = 'Wat is de status van je relatie?';

$profile_questions['1']['description'] = '';

$profile_questions['1']['guideline'] = '';

$profile_questions['1']['extsearchhead'] = 'Huwelijksstatus';

$profile_questions['1']['1'] = 'Vrijgezel';

$profile_questions['1']['2'] = 'Getrouwd';

$profile_questions['1']['3'] = 'Weduwe/weduwenaar';

$profile_questions['1']['67'] = 'Bezet';

$profile_questions['1']['68'] = 'Uit elkaar';

$profile_questions['1']['69'] = 'Gescheiden';

$profile_questions['2']['question'] = 'Tot welke etnische groep behoor je?';

$profile_questions['2']['description'] = '';

$profile_questions['2']['guideline'] = '';

$profile_questions['2']['extsearchhead'] = 'Etniciteit';

$profile_questions['2']['80'] = 'Afrikaans-Amerikaans';

$profile_questions['2']['10018'] = 'Aziatisch';

$profile_questions['2']['10019'] = 'Zwart / Afrikaans';

$profile_questions['2']['10020'] = 'Kaukasisch';

$profile_questions['2']['10021'] = 'Oosters / Indisch';

$profile_questions['2']['10022'] = 'Spaans / Latino';

$profile_questions['2']['10023'] = 'Interraciaal';

$profile_questions['2']['10024'] = 'Midden-Oosters';

$profile_questions['2']['10025'] = 'Native Amerikaans';

$profile_questions['2']['10026'] = 'Groenlander';

$profile_questions['2']['10027'] = 'Andere';

$profile_questions['3']['question'] = 'Welk geloof heb je?';

$profile_questions['3']['description'] = '';

$profile_questions['3']['guideline'] = '';

$profile_questions['3']['extsearchhead'] = 'Religie';

$profile_questions['3']['10001'] = 'Christelijk';

$profile_questions['3']['10002'] = 'Christelijk / Katholiek';

$profile_questions['3']['10003'] = 'Christelijk / LDS';

$profile_questions['3']['10004'] = 'Christelijk / Protestant';

$profile_questions['3']['10005'] = 'Christelijk / Andere';

$profile_questions['3']['10006'] = 'Boedhist / Taoist';

$profile_questions['3']['10007'] = 'Hindoe';

$profile_questions['3']['10008'] = 'Islamiet';

$profile_questions['3']['10009'] = 'Jood';

$profile_questions['3']['10010'] = 'Pagan';

$profile_questions['3']['10011'] = 'Atheist';

$profile_questions['3']['10012'] = 'Geen / Agnostisch';

$profile_questions['3']['10014'] = 'Scientology';

$profile_questions['3']['10015'] = 'Spiritueel maar niet religieus';

$profile_questions['3']['10016'] = 'Andere';

$profile_questions['4']['question'] = 'Wat doe je voor je plezier?';

$profile_questions['4']['description'] = 'Hier kan je je activiteiten iets beter omschrijven. Als je van sporten houdt, kan je vermelden dat je bij een club bent aangesloten. Als je van films houd kan je hier het genre vermelden';

$profile_questions['4']['guideline'] = '';

$profile_questions['4']['extsearchhead'] = 'Hobby\'s';

$profile_questions['5']['question'] = 'Hoe groot ben je?';

$profile_questions['5']['description'] = '';

$profile_questions['5']['guideline'] = '';

$profile_questions['5']['extsearchhead'] = 'Lengte';

$profile_questions['5']['152'] = '140 cm of kleiner';

$profile_questions['5']['153'] = '142 cm';

$profile_questions['5']['154'] = '145 cm';

$profile_questions['5']['155'] = '147 cm';

$profile_questions['5']['156'] = '150 cm';

$profile_questions['5']['157'] = '152 cm';

$profile_questions['5']['158'] = '155 cm';

$profile_questions['5']['160'] = '157 cm';

$profile_questions['5']['161'] = '160 cm';

$profile_questions['5']['162'] = '162 cm';

$profile_questions['5']['163'] = '165 cm';

$profile_questions['5']['164'] = '167 cm';

$profile_questions['5']['165'] = '170 cm';

$profile_questions['5']['166'] = '173 cm';

$profile_questions['5']['167'] = '175 cm';

$profile_questions['5']['168'] = '178 cm';

$profile_questions['5']['169'] = '180 cm';

$profile_questions['5']['170'] = '183 cm';

$profile_questions['5']['171'] = '185 cm';

$profile_questions['5']['172'] = '188 cm';

$profile_questions['5']['173'] = '190 cm';

$profile_questions['5']['174'] = '193 cm';

$profile_questions['5']['175'] = '196 cm';

$profile_questions['5']['176'] = '198 cm';

$profile_questions['5']['177'] = '201 cm';

$profile_questions['5']['178'] = '203 cm';

$profile_questions['5']['179'] = '206 cm';

$profile_questions['5']['180'] = '208 cm';

$profile_questions['5']['181'] = '211 cm';

$profile_questions['5']['182'] = '213 cm';

$profile_questions['5']['183'] = '216 cm';

$profile_questions['5']['184'] = '218 cm';

$profile_questions['5']['185'] = '221 cm';

$profile_questions['5']['186'] = '224 cm';

$profile_questions['5']['187'] = '226 cm';

$profile_questions['5']['188'] = '229 cm';

$profile_questions['5']['189'] = '231 cm';

$profile_questions['5']['190'] = '234 cm';

$profile_questions['5']['191'] = '236 cm';

$profile_questions['5']['192'] = '239 cm of meer';

$profile_questions['6']['question'] = 'Hoe zou je je lichaamsbouw omschrijven?';

$profile_questions['6']['description'] = '';

$profile_questions['6']['guideline'] = '';

$profile_questions['6']['extsearchhead'] = 'Lichaamsbouw';

$profile_questions['6']['10028'] = 'Mager';

$profile_questions['6']['10029'] = 'Slank';

$profile_questions['6']['10030'] = 'Gemiddeld';

$profile_questions['6']['10031'] = 'Fit';

$profile_questions['6']['10032'] = 'In goede vorm';

$profile_questions['6']['10033'] = 'Atletisch';

$profile_questions['6']['10034'] = 'Gespierd';

$profile_questions['6']['10035'] = 'Een paar kilo extra';

$profile_questions['6']['10036'] = 'Dik';

$profile_questions['6']['10037'] = 'Wat zwaarder';

$profile_questions['6']['10039'] = 'Ronde vormen';

$profile_questions['6']['10040'] = 'Groot';

$profile_questions['7']['question'] = 'Wat is je sterrenbeeld?';

$profile_questions['7']['description'] = '';

$profile_questions['7']['guideline'] = '';

$profile_questions['7']['extsearchhead'] = 'Sterrenbeeld';

$profile_questions['7']['211'] = 'Ram';

$profile_questions['7']['212'] = 'Stier';

$profile_questions['7']['213'] = 'Tweeling';

$profile_questions['7']['214'] = 'Kreeft';

$profile_questions['7']['215'] = 'Leeuw';

$profile_questions['7']['216'] = 'Maagd';

$profile_questions['7']['217'] = 'Weegschaal';

$profile_questions['7']['218'] = 'Scorpioen';

$profile_questions['7']['219'] = 'Boogschutter';

$profile_questions['7']['220'] = 'Steenbok';

$profile_questions['7']['221'] = 'Waterman';

$profile_questions['7']['222'] = 'Vis';

$profile_questions['8']['question'] = 'Wat is je oogkleur?';

$profile_questions['8']['description'] = '';

$profile_questions['8']['guideline'] = '';

$profile_questions['8']['extsearchhead'] = 'Oogkleur';

$profile_questions['8']['23'] = 'Zwart';

$profile_questions['8']['24'] = 'Blauw';

$profile_questions['8']['25'] = 'Bruin';

$profile_questions['8']['93'] = 'Grijs';

$profile_questions['8']['94'] = 'Groen';

$profile_questions['8']['95'] = 'Hazel';

$profile_questions['9']['question'] = 'Welke haarkleur heb je?';

$profile_questions['9']['description'] = '';

$profile_questions['9']['guideline'] = '';

$profile_questions['9']['extsearchhead'] = 'Haarkleur';

$profile_questions['9']['26'] = 'Zwart';

$profile_questions['9']['27'] = 'Bruin';

$profile_questions['9']['28'] = 'Zwart-bruin';

$profile_questions['9']['96'] = 'Rood';

$profile_questions['9']['97'] = 'Blond';

$profile_questions['9']['98'] = 'Lichtbruin';

$profile_questions['9']['99'] = 'Donkerbruin';

$profile_questions['9']['100'] = 'Rood';

$profile_questions['9']['101'] = 'Wit/grijs';

$profile_questions['9']['102'] = 'Kaal';

$profile_questions['9']['103'] = 'Een beetje grijs';

$profile_questions['10']['question'] = 'Heb je enige lichaamsversiering?';

$profile_questions['10']['description'] = '';

$profile_questions['10']['guideline'] = '';

$profile_questions['10']['extsearchhead'] = 'Lichaamsversiering';

$profile_questions['10']['29'] = 'Strategisch geplaatste tattoo';

$profile_questions['10']['30'] = 'Zichtbare tattoo';

$profile_questions['10']['31'] = 'Gescherpte tanden';

$profile_questions['10']['223'] = 'Gebrandmerkt';

$profile_questions['10']['224'] = 'Volledig voorzien van tattoos';

$profile_questions['10']['225'] = 'Gescarred';

$profile_questions['10']['226'] = 'Gepierced...maar enkel de oren';

$profile_questions['10']['227'] = 'Denk er niet eens aan';

$profile_questions['10']['228'] = 'Navelpiercing';

$profile_questions['10']['229'] = 'Piercings op geheime plaatsen';

$profile_questions['11']['question'] = 'Schep een beetje op: wat is je beste troef?';

$profile_questions['11']['description'] = '';

$profile_questions['11']['guideline'] = '';

$profile_questions['11']['extsearchhead'] = 'Beste troef';

$profile_questions['11']['10068'] = 'Armen';

$profile_questions['11']['10069'] = 'Rug';

$profile_questions['11']['10070'] = 'Buik';

$profile_questions['11']['10071'] = 'Kont';

$profile_questions['11']['10072'] = 'Borst';

$profile_questions['11']['10073'] = 'Bouw';

$profile_questions['11']['10074'] = 'Oren';

$profile_questions['11']['10075'] = 'Ogen';

$profile_questions['11']['10076'] = 'Voeten';

$profile_questions['11']['10077'] = 'Haar';

$profile_questions['11']['10078'] = 'Handen';

$profile_questions['11']['10079'] = 'Heupen';

$profile_questions['11']['10080'] = 'Benen';

$profile_questions['11']['10081'] = 'Lippen';

$profile_questions['11']['10082'] = 'Neus';

$profile_questions['11']['10083'] = 'Schouder';

$profile_questions['11']['10084'] = 'Dijen';

$profile_questions['11']['10085'] = 'Andere';

$profile_questions['12']['question'] = 'Favoriete lokale uithangplek of vakantiebestemming?';

$profile_questions['12']['description'] = 'Waar zou je je match naartoe willen nemen? Wat is je favoriete plaats om uit te gaan eten?';

$profile_questions['12']['guideline'] = '';

$profile_questions['12']['extsearchhead'] = 'Favoriete plekken';

$profile_questions['13']['question'] = 'Welke soorten sport of lichaamstraining beoefen je?';

$profile_questions['13']['description'] = '';

$profile_questions['13']['guideline'] = '';

$profile_questions['13']['extsearchhead'] = 'Sporten';

$profile_questions['13']['34'] = 'Aerobics';

$profile_questions['13']['35'] = 'Auto racen / Motorcross';

$profile_questions['13']['36'] = 'Baseball';

$profile_questions['13']['37'] = 'Basketball';

$profile_questions['13']['372'] = 'Biljart / Pool';

$profile_questions['13']['373'] = 'Bowlen';

$profile_questions['13']['374'] = 'Fietsen';

$profile_questions['13']['375'] = 'Dansen';

$profile_questions['13']['376'] = 'Voetbal';

$profile_questions['13']['377'] = 'Golf';

$profile_questions['13']['378'] = 'Oosterse gevechtsporten';

$profile_questions['13']['379'] = 'Lopen';

$profile_questions['13']['380'] = 'Ski�n';

$profile_questions['13']['381'] = 'Voetal';

$profile_questions['13']['382'] = 'Zwemmen';

$profile_questions['13']['383'] = 'Tennis / Racketsporten';

$profile_questions['13']['384'] = 'Volleyball';

$profile_questions['13']['385'] = 'Wandelen';

$profile_questions['13']['386'] = 'Gewichten / Machines';

$profile_questions['13']['387'] = 'Yoga';

$profile_questions['14']['question'] = 'Favoriete dingen?';

$profile_questions['14']['description'] = 'Iedereen heeft favorieten. Wat is je favoriete maaltijd? Wat zijn je favoriete kleuren?';

$profile_questions['14']['guideline'] = '';

$profile_questions['14']['extsearchhead'] = 'Favoriete dingen';

$profile_questions['15']['question'] = 'Wat heb je het laatst gelezen?';

$profile_questions['15']['description'] = 'Was het een boek, een tijdschrift , de tekst op je ontbijtgranen of de krant? Laat het ons weten.';

$profile_questions['15']['guideline'] = '';

$profile_questions['15']['extsearchhead'] = 'Laatst Gelezen';

$profile_questions['16']['question'] = 'Welke interesses zou je willen delen met andere leden?';

$profile_questions['16']['description'] = '';

$profile_questions['16']['guideline'] = '';

$profile_questions['16']['extsearchhead'] = 'Gemeenschappelijke interesses';

$profile_questions['16']['38'] = 'Alumni connecties';

$profile_questions['16']['39'] = 'Nightclubs/Dancing';

$profile_questions['16']['40'] = 'Kamperen';

$profile_questions['16']['41'] = 'Koken';

$profile_questions['16']['388'] = 'Business networking';

$profile_questions['16']['389'] = 'Boekenclub';

$profile_questions['16']['390'] = 'Koffie en gesprekken';

$profile_questions['16']['391'] = 'Uit eten';

$profile_questions['16']['392'] = 'Vissen / Jagen ';

$profile_questions['16']['393'] = 'Tuinieren';

$profile_questions['16']['394'] = 'Hobby\'s en handwerkjes';

$profile_questions['16']['395'] = 'Films / Video\'s';

$profile_questions['16']['396'] = 'Museums en kunst';

$profile_questions['16']['397'] = 'Muziek en concerten';

$profile_questions['16']['398'] = 'Kunst beoefenen';

$profile_questions['16']['399'] = 'Kaartspel';

$profile_questions['16']['400'] = 'Sporten';

$profile_questions['16']['401'] = 'Politieke intresses';

$profile_questions['16']['402'] = 'Religieus / Spiritueel';

$profile_questions['16']['403'] = 'Winkelen / Antiek';

$profile_questions['17']['question'] = 'Hoe zou je je gevoel voor humor omschrijven?';

$profile_questions['17']['description'] = '';

$profile_questions['17']['guideline'] = '';

$profile_questions['17']['extsearchhead'] = 'Gevoel voor humor';

$profile_questions['17']['42'] = 'Flauw: Hoe dommer, hoe beter';

$profile_questions['17']['43'] = 'Raar: Cartoons laten me nog steeds lachen';

$profile_questions['17']['367'] = 'Intelligent: niets leuker dan een leuke woordspeling';

$profile_questions['17']['368'] = 'Obscuur: Ik ben meestal de enige die ermee kan lachen';

$profile_questions['17']['369'] = 'Droog / Sarcastisch';

$profile_questions['17']['370'] = 'Slapstick';

$profile_questions['17']['371'] = 'Vriendelijk: Ik lach met alles';

$profile_questions['18']['question'] = 'Hoe vaak train je?';

$profile_questions['18']['description'] = '';

$profile_questions['18']['guideline'] = '';

$profile_questions['18']['extsearchhead'] = 'Training';

$profile_questions['18']['10086'] = 'Tweemaal per dag';

$profile_questions['18']['10087'] = 'Dagelijks';

$profile_questions['18']['10088'] = 'Om de twee dagen';

$profile_questions['18']['10089'] = 'Wekelijks';

$profile_questions['18']['10090'] = 'Eenmaal per twee weken';

$profile_questions['18']['10091'] = 'Maandelijks';

$profile_questions['18']['10092'] = 'Onregelmatig';

$profile_questions['18']['10093'] = 'Nooit';

$profile_questions['19']['question'] = 'Wat zijn je eetgewoontes?';

$profile_questions['19']['description'] = '';

$profile_questions['19']['guideline'] = '';

$profile_questions['19']['extsearchhead'] = 'Dagelijkse eetgewoontes';

$profile_questions['19']['10094'] = 'Vlees met aardappelen';

$profile_questions['19']['10095'] = 'Junk food';

$profile_questions['19']['10096'] = 'Fast food';

$profile_questions['19']['10097'] = 'Gezond';

$profile_questions['19']['10098'] = 'Speciaal / Medisch dieet';

$profile_questions['19']['10099'] = 'Vegetarisch';

$profile_questions['19']['10100'] = 'Veganistisch';

$profile_questions['20']['question'] = 'Rook je?';

$profile_questions['20']['description'] = '';

$profile_questions['20']['guideline'] = '';

$profile_questions['20']['extsearchhead'] = 'Roken';

$profile_questions['20']['50'] = 'Nee, nooit';

$profile_questions['20']['51'] = 'Nee, ik heb wel in het verleden gerookt';

$profile_questions['20']['10711'] = 'Ja, maar ik probeer te stoppen';

$profile_questions['20']['10712'] = 'Ja, af en toe';

$profile_questions['20']['10713'] = 'Ja, regelmatig';

$profile_questions['21']['question'] = 'Hoe veel drink je?';

$profile_questions['21']['description'] = '';

$profile_questions['21']['guideline'] = '';

$profile_questions['21']['extsearchhead'] = 'Drinkgewoontes';

$profile_questions['21']['52'] = 'Nooit';

$profile_questions['21']['53'] = 'Enkel sociaal';

$profile_questions['21']['54'] = 'Vaak';

$profile_questions['22']['question'] = 'Werk je van 9 tot 5? Ben je je eigen baas? Wat voor job heb je?';

$profile_questions['22']['description'] = '';

$profile_questions['22']['guideline'] = '';

$profile_questions['22']['extsearchhead'] = 'Werkschema';

$profile_questions['22']['10102'] = 'Voltijds van 9 tot 5';

$profile_questions['22']['10103'] = 'Voltijds tijdens andere uren';

$profile_questions['22']['10104'] = 'Halftijds';

$profile_questions['22']['10105'] = '25 percent';

$profile_questions['22']['10106'] = 'Eigen baas';

$profile_questions['22']['10107'] = 'Op zoek naar werk';

$profile_questions['22']['10108'] = 'Tijdelijke werkonderbreking';

$profile_questions['22']['10109'] = 'Gepensioneerd';

$profile_questions['22']['10110'] = 'Huisvrouw/man';

$profile_questions['23']['question'] = 'Huidig jaarlijks inkomen?';

$profile_questions['23']['description'] = '';

$profile_questions['23']['guideline'] = '';

$profile_questions['23']['extsearchhead'] = 'Huidig jaarlijks inkomen';

$profile_questions['23']['56'] = 'Minder dan �25 000';

$profile_questions['23']['57'] = '�25 001 tot �50 000';

$profile_questions['23']['58'] = '�50 001 tot �75 000';

$profile_questions['23']['59'] = '�75 001 tot �100 000';

$profile_questions['23']['70'] = '�100 001 tot �125 000';

$profile_questions['23']['71'] = '�125 001 tot �150 000';

$profile_questions['23']['72'] = '�150 001 tot �175 000';

$profile_questions['23']['10101'] = 'Meer dan �175 000';

$profile_questions['23']['10716'] = 'Dat vertel ik later wel';

$profile_questions['24']['question'] = 'Woon je alleen?';

$profile_questions['24']['description'] = '';

$profile_questions['24']['guideline'] = '';

$profile_questions['24']['extsearchhead'] = 'Woonsituatie';

$profile_questions['24']['60'] = 'Alleen';

$profile_questions['24']['61'] = 'Met kinderen';

$profile_questions['24']['62'] = 'Met ouders';

$profile_questions['24']['10714'] = 'Met huisgenoten';

$profile_questions['24']['10715'] = 'Met andere familieleden';

$profile_questions['25']['question'] = 'Heb je kinderen?';

$profile_questions['25']['description'] = '';

$profile_questions['25']['guideline'] = '';

$profile_questions['25']['extsearchhead'] = 'Kinderen';

$profile_questions['25']['63'] = 'Nee';

$profile_questions['25']['64'] = 'Ja - ze zijn steeds thuis';

$profile_questions['25']['230'] = 'Ja - ze zijn halftijds thuis';

$profile_questions['25']['231'] = 'Ja - maar niet thuis';

$profile_questions['26']['question'] = 'Wil je kinderen?';

$profile_questions['26']['description'] = '';

$profile_questions['26']['guideline'] = '';

$profile_questions['26']['extsearchhead'] = 'Wil kinderen';

$profile_questions['26']['65'] = 'Ja';

$profile_questions['26']['66'] = 'Nee';

$profile_questions['26']['232'] = 'Niet zeker';

$profile_questions['27']['question'] = 'Je gewicht';

$profile_questions['27']['description'] = '';

$profile_questions['27']['guideline'] = '';

$profile_questions['27']['extsearchhead'] = 'Gewicht';

$profile_questions['27']['243'] = 'Onder de 35.4 kg';

$profile_questions['27']['244'] = '35.4 kg';

$profile_questions['27']['245'] = '35.8 kg';

$profile_questions['27']['246'] = '36.3 kg';

$profile_questions['27']['247'] = '36.7 kg';

$profile_questions['27']['248'] = '37.2 kg';

$profile_questions['27']['249'] = '37.6 kg';

$profile_questions['27']['250'] = '38.1 kg';

$profile_questions['27']['251'] = '38.6 kg';

$profile_questions['27']['252'] = '39 kg';

$profile_questions['27']['253'] = '39.5 kg';

$profile_questions['27']['254'] = '39.9 kg';

$profile_questions['27']['255'] = '40.4 kg';

$profile_questions['27']['256'] = '40.8 kg';

$profile_questions['27']['257'] = '41.3 kg';

$profile_questions['27']['258'] = '41.7 kg';

$profile_questions['27']['259'] = '42.2 kg';

$profile_questions['27']['260'] = '42.6 kg';

$profile_questions['27']['261'] = '43.1 kg';

$profile_questions['27']['262'] = '43.5 kg';

$profile_questions['27']['263'] = '44 kg';

$profile_questions['27']['264'] = '44.5 kg';

$profile_questions['27']['265'] = '44.9 kg';

$profile_questions['27']['266'] = '45.4 kg';

$profile_questions['27']['267'] = '45.8 kg';

$profile_questions['27']['268'] = '46.3 kg';

$profile_questions['27']['269'] = '46.7 kg';

$profile_questions['27']['270'] = '47.2 kg';

$profile_questions['27']['271'] = '47.6 kg';

$profile_questions['27']['272'] = '48.1 kg';

$profile_questions['27']['273'] = '48.5 kg';

$profile_questions['27']['274'] = '49 kg';

$profile_questions['27']['275'] = '49.4 kg';

$profile_questions['27']['276'] = '49.9 kg';

$profile_questions['27']['277'] = '50.3 kg';

$profile_questions['27']['278'] = '50.8 kg';

$profile_questions['27']['279'] = '51.3 kg';

$profile_questions['27']['280'] = '51.7 kg';

$profile_questions['27']['281'] = '52.2 kg';

$profile_questions['27']['282'] = '52.6 kg';

$profile_questions['27']['283'] = '53.1 kg';

$profile_questions['27']['284'] = '53.5 kg';

$profile_questions['27']['285'] = '54 kg';

$profile_questions['27']['286'] = '54.4 kg';

$profile_questions['27']['287'] = '54.9 kg';

$profile_questions['27']['288'] = '55.3 kg';

$profile_questions['27']['289'] = '55.8 kg';

$profile_questions['27']['290'] = '56.2 kg';

$profile_questions['27']['291'] = '56.7 kg';

$profile_questions['27']['292'] = '57.2 kg';

$profile_questions['27']['293'] = '57.6 kg';

$profile_questions['27']['294'] = '58.1 kg';

$profile_questions['27']['295'] = '58.5 kg';

$profile_questions['27']['296'] = '59 kg';

$profile_questions['27']['297'] = '59.4 kg';

$profile_questions['27']['298'] = '59.9 kg';

$profile_questions['27']['299'] = '60.3 kg';

$profile_questions['27']['300'] = '60.8 kg';

$profile_questions['27']['301'] = '61.2 kg';

$profile_questions['27']['302'] = '61.7 kg';

$profile_questions['27']['303'] = '62.1 kg';

$profile_questions['27']['304'] = '62.6 kg';

$profile_questions['27']['305'] = '63.1 kg';

$profile_questions['27']['306'] = '63.5 kg';

$profile_questions['27']['307'] = '64 kg';

$profile_questions['27']['308'] = '64.4 kg';

$profile_questions['27']['309'] = '64.9 kg';

$profile_questions['27']['310'] = '65.3 kg';

$profile_questions['27']['311'] = '65.8 kg';

$profile_questions['27']['312'] = '66.2 kg';

$profile_questions['27']['313'] = '66.7 kg';

$profile_questions['27']['314'] = '67.1 kg';

$profile_questions['27']['315'] = '67.6 kg';

$profile_questions['27']['316'] = '68 kg';

$profile_questions['27']['317'] = '68.5 kg';

$profile_questions['27']['318'] = '68.9 kg';

$profile_questions['27']['319'] = '69.4 kg';

$profile_questions['27']['320'] = '69.9 kg';

$profile_questions['27']['321'] = '70.3 kg';

$profile_questions['27']['322'] = '70.8 kg';

$profile_questions['27']['323'] = '71.2 kg';

$profile_questions['27']['324'] = '71.7 kg';

$profile_questions['27']['325'] = '72.1 kg';

$profile_questions['27']['326'] = '72.6 kg';

$profile_questions['27']['327'] = '73 kg';

$profile_questions['27']['328'] = '73.5 kg';

$profile_questions['27']['329'] = '73.9 kg';

$profile_questions['27']['330'] = '74.4 kg';

$profile_questions['27']['331'] = '74.8 kg';

$profile_questions['27']['332'] = '75.3 kg';

$profile_questions['27']['333'] = '75.8 kg';

$profile_questions['27']['334'] = '76.2 kg';

$profile_questions['27']['335'] = '76.7 kg';

$profile_questions['27']['336'] = '77.1 kg';

$profile_questions['27']['337'] = '77.6 kg';

$profile_questions['27']['338'] = '78 kg';

$profile_questions['27']['339'] = '78.5 kg';

$profile_questions['27']['340'] = '78.9 kg';

$profile_questions['27']['341'] = '79.4 kg';

$profile_questions['27']['342'] = '79.8 kg';

$profile_questions['27']['343'] = '80.3 kg';

$profile_questions['27']['344'] = '80.7 kg';

$profile_questions['27']['345'] = '81.2 kg';

$profile_questions['27']['346'] = '81.6 kg';

$profile_questions['27']['347'] = '82.1 kg';

$profile_questions['27']['348'] = '82.6 kg';

$profile_questions['27']['349'] = '83 kg';

$profile_questions['27']['350'] = '83.5 kg';

$profile_questions['27']['351'] = '83.9 kg';

$profile_questions['27']['352'] = '84.4 kg';

$profile_questions['27']['353'] = '84.8 kg';

$profile_questions['27']['354'] = '85.3 kg';

$profile_questions['27']['355'] = '85.7 kg';

$profile_questions['27']['356'] = '86.2 kg';

$profile_questions['27']['357'] = '86.6 kg';

$profile_questions['27']['358'] = '87.1 kg';

$profile_questions['27']['359'] = '87.5 kg';

$profile_questions['27']['360'] = '88 kg';

$profile_questions['27']['361'] = '88.5 kg';

$profile_questions['27']['362'] = '88.9 kg';

$profile_questions['27']['363'] = '89.4 kg';

$profile_questions['27']['364'] = '89.8 kg';

$profile_questions['27']['365'] = '90.3 kg';

$profile_questions['27']['366'] = '90.7 kg';

$profile_questions['27']['10111'] = '91.2 kg';

$profile_questions['27']['10112'] = '91.6 kg';

$profile_questions['27']['10113'] = '92.1 kg';

$profile_questions['27']['10114'] = '92.5 kg';

$profile_questions['27']['10115'] = '93 kg';

$profile_questions['27']['10116'] = '93.4 kg';

$profile_questions['27']['10117'] = '93.9 kg';

$profile_questions['27']['10118'] = '94.3 kg';

$profile_questions['27']['10119'] = '94.8 kg';

$profile_questions['27']['10120'] = '95.2 kg';

$profile_questions['27']['10121'] = '95.7 kg';

$profile_questions['27']['10122'] = '96.1 kg';

$profile_questions['27']['10123'] = '96.6 kg';

$profile_questions['27']['10124'] = '97 kg';

$profile_questions['27']['10125'] = '97.5 kg';

$profile_questions['27']['10126'] = '97.9 kg';

$profile_questions['27']['10127'] = '98.3 kg';

$profile_questions['27']['10128'] = '98.8 kg';

$profile_questions['27']['10129'] = '99.2 kg';

$profile_questions['27']['10130'] = '99.7 kg';

$profile_questions['27']['10131'] = '100.2 kg';

$profile_questions['27']['10132'] = '100.6 kg';

$profile_questions['27']['10133'] = '101 kg';

$profile_questions['27']['10134'] = '101.5 kg';

$profile_questions['27']['10135'] = '101.9 kg';

$profile_questions['27']['10136'] = '102.3 kg';

$profile_questions['27']['10137'] = '102.8 kg';

$profile_questions['27']['10138'] = '103.2 kg';

$profile_questions['27']['10139'] = '103.7 kg';

$profile_questions['27']['10140'] = '104.1 kg';

$profile_questions['27']['10141'] = '104,6 kg';

$profile_questions['27']['10142'] = '105 kg';

$profile_questions['27']['10143'] = '105.5 kg';

$profile_questions['27']['10144'] = '105.9 kg';

$profile_questions['27']['10145'] = '106.4 kg';

$profile_questions['27']['10146'] = '106.8 kg';

$profile_questions['27']['10147'] = '107.3 kg';

$profile_questions['27']['10148'] = '107.7 kg';

$profile_questions['27']['10149'] = '108.2 kg';

$profile_questions['27']['10150'] = '108.6 kg';

$profile_questions['27']['10151'] = '109.1 kg';

$profile_questions['27']['10152'] = '109.5 kg';

$profile_questions['27']['10153'] = '110 kg';

$profile_questions['27']['10154'] = '110.4 kg';

$profile_questions['27']['10155'] = '110.9 kg';

$profile_questions['27']['10156'] = '111.3 kg';

$profile_questions['27']['10157'] = '111.8 kg';

$profile_questions['27']['10158'] = '112.2 kg';

$profile_questions['27']['10159'] = '112.7 kg';

$profile_questions['27']['10160'] = '113.1 kg';

$profile_questions['27']['10161'] = '113,6 kg';

$profile_questions['27']['10162'] = '114 kg';

$profile_questions['27']['10163'] = '114.5 kg';

$profile_questions['27']['10164'] = '114.9 kg';

$profile_questions['27']['10165'] = '115.3 kg';

$profile_questions['27']['10166'] = '115.8 kg';

$profile_questions['27']['10167'] = '116.2 kg';

$profile_questions['27']['10168'] = '116.7 kg';

$profile_questions['27']['10169'] = '117.1 kg';

$profile_questions['27']['10170'] = '117.6 kg';

$profile_questions['27']['10171'] = '118 kg';

$profile_questions['27']['10172'] = '118.5 kg';

$profile_questions['27']['10173'] = '118.9 kg';

$profile_questions['27']['10174'] = '119.4 kg';

$profile_questions['27']['10175'] = '119.8 kg';

$profile_questions['27']['10176'] = '120.3 kg';

$profile_questions['27']['10177'] = '120.7 kg';

$profile_questions['27']['10178'] = '121.1 kg';

$profile_questions['27']['10179'] = '121.6 kg';

$profile_questions['27']['10180'] = '122 kg';

$profile_questions['27']['10181'] = '122.5 kg';

$profile_questions['27']['10182'] = '122.9 kg';

$profile_questions['27']['10183'] = '123.3 kg';

$profile_questions['27']['10184'] = '123.8 kg';

$profile_questions['27']['10185'] = '124.2 kg';

$profile_questions['27']['10186'] = '124.7 kg';

$profile_questions['27']['10187'] = '125.1 kg';

$profile_questions['27']['10188'] = '125.5 kg';

$profile_questions['27']['10189'] = '126 kg';

$profile_questions['27']['10190'] = '126.4 kg';

$profile_questions['27']['10191'] = '126.9 kg';

$profile_questions['27']['10192'] = '127.3 kg';

$profile_questions['27']['10193'] = '127.8 kg';

$profile_questions['27']['10194'] = '128.2 kg';

$profile_questions['27']['10195'] = '128.7 kg';

$profile_questions['27']['10196'] = '129.1 kg';

$profile_questions['27']['10197'] = '129.6 kg';

$profile_questions['27']['10198'] = '130 kg';

$profile_questions['27']['10199'] = '130.5 kg';

$profile_questions['27']['10200'] = '130.9 kg';

$profile_questions['27']['10201'] = '131.3 kg';

$profile_questions['27']['10202'] = '131.8 kg';

$profile_questions['27']['10203'] = '132.2 kg';

$profile_questions['27']['10204'] = '132.7 kg';

$profile_questions['27']['10205'] = '133.1 kg';

$profile_questions['27']['10206'] = '133.6 kg';

$profile_questions['27']['10207'] = '134 kg';

$profile_questions['27']['10208'] = '134.5 kg';

$profile_questions['27']['10209'] = '134.9 kg';

$profile_questions['27']['10210'] = '135.3 kg';

$profile_questions['27']['10211'] = '135.8 kg';

$profile_questions['27']['10212'] = '136.2 kg';

$profile_questions['27']['10213'] = '136.7 kg';

$profile_questions['27']['10214'] = '137.1 kg';

$profile_questions['27']['10215'] = '137.6 kg';

$profile_questions['27']['10216'] = '138 kg';

$profile_questions['27']['10217'] = '138.5 kg';

$profile_questions['27']['10218'] = '138.9 kg';

$profile_questions['27']['10219'] = '139.4 kg';

$profile_questions['27']['10220'] = '139.8 kg';

$profile_questions['27']['10221'] = '140.3 kg';

$profile_questions['27']['10222'] = '140.7 kg';

$profile_questions['27']['10223'] = '141.1 kg';

$profile_questions['27']['10224'] = '141.6 kg';

$profile_questions['27']['10225'] = '142 kg';

$profile_questions['27']['10226'] = '142.5 kg';

$profile_questions['27']['10227'] = '142.9 kg';

$profile_questions['27']['10228'] = '143.4 kg';

$profile_questions['27']['10229'] = '143.8 kg';

$profile_questions['27']['10230'] = '144.3 kg';

$profile_questions['27']['10231'] = '144.7 kg';

$profile_questions['27']['10232'] = '145.2 kg';

$profile_questions['27']['10233'] = '145.6 kg';

$profile_questions['27']['10234'] = '146.1 kg';

$profile_questions['27']['10235'] = '146.6 kg';

$profile_questions['27']['10236'] = '147 kg';

$profile_questions['27']['10237'] = '147.5 kg';

$profile_questions['27']['10238'] = '147.9 kg';

$profile_questions['27']['10239'] = '148.4 kg';

$profile_questions['27']['10240'] = '148.8 kg';

$profile_questions['27']['10241'] = '149.3 kg';

$profile_questions['27']['10242'] = '149.7 kg';

$profile_questions['27']['10243'] = '150.2 kg';

$profile_questions['27']['10244'] = '150.6 kg';

$profile_questions['27']['10245'] = '151.1 kg';

$profile_questions['27']['10246'] = '151.6 kg';

$profile_questions['27']['10247'] = '152 kg';

$profile_questions['27']['10248'] = '152.5 kg';

$profile_questions['27']['10249'] = '152.9 kg';

$profile_questions['27']['10250'] = '153.3 kg';

$profile_questions['27']['10251'] = '153.8 kg';

$profile_questions['27']['10252'] = '154.2 kg';

$profile_questions['27']['10253'] = '154.7 kg';

$profile_questions['27']['10254'] = '155.1 kg';

$profile_questions['27']['10255'] = '155.6 kg';

$profile_questions['27']['10256'] = '156 kg';

$profile_questions['27']['10257'] = '156.5 kg';

$profile_questions['27']['10258'] = '156.9 kg';

$profile_questions['27']['10259'] = '157.4 kg';

$profile_questions['27']['10260'] = '157.8 kg';

$profile_questions['27']['10261'] = 'Meer dan 157.8 kg';

$profile_questions['28']['question'] = 'Werkstatus';

$profile_questions['28']['description'] = '';

$profile_questions['28']['guideline'] = '';

$profile_questions['28']['extsearchhead'] = 'Werkstatus';

$profile_questions['28']['233'] = 'Full-time';

$profile_questions['28']['234'] = 'Part-time';

$profile_questions['28']['235'] = 'Huisvrouw/man';

$profile_questions['28']['236'] = 'Gepensioneerd';

$profile_questions['28']['237'] = 'Eigen baas';

$profile_questions['28']['238'] = 'Student';

$profile_questions['28']['239'] = 'Werkloos';

$profile_questions['28']['240'] = 'Werk thuis';

$profile_questions['29']['question'] = 'Welke opleiding heb je genoten?';

$profile_questions['29']['description'] = '';

$profile_questions['29']['guideline'] = '';

$profile_questions['29']['extsearchhead'] = 'Opleiding';

$profile_questions['29']['194'] = 'Middelbaar';

$profile_questions['29']['195'] = 'Hogeschool';

$profile_questions['29']['196'] = 'Master';

$profile_questions['29']['197'] = 'Bachelor';

$profile_questions['29']['198'] = 'Graduaat';

$profile_questions['29']['199'] = 'Doctoraat';

$profile_questions['29']['200'] = 'Levenslessen';

$profile_questions['29']['201'] = 'Geen antwoord';

$profile_questions['30']['question'] = 'Welke taal spreek je?';

$profile_questions['30']['description'] = '';

$profile_questions['30']['guideline'] = '';

$profile_questions['30']['extsearchhead'] = 'Talen';

$profile_questions['30']['10050'] = 'Arabisch';

$profile_questions['30']['10051'] = 'Cambodiaans';

$profile_questions['30']['10052'] = 'Chinees';

$profile_questions['30']['10053'] = 'Nederlands';

$profile_questions['30']['10054'] = 'Engels';

$profile_questions['30']['10055'] = 'Frans';

$profile_questions['30']['10056'] = 'Duits';

$profile_questions['30']['10058'] = 'Hebreeuws';

$profile_questions['30']['10059'] = 'Hindi';

$profile_questions['30']['10060'] = 'Italiaans';

$profile_questions['30']['10061'] = 'Portuguees';

$profile_questions['30']['10062'] = 'Roemeens';

$profile_questions['30']['10063'] = 'Russisch';

$profile_questions['30']['10064'] = 'Spaans';

$profile_questions['30']['10065'] = 'Thais';

$profile_questions['30']['10066'] = 'Turks';

$profile_questions['30']['10067'] = 'Vietnamees';

$profile_questions['30']['10717'] = 'Andere';

$profile_questions['37']['question'] = 'Van waar ken je onze site?';

$profile_questions['37']['description'] = 'Gelieve hier de bron te vermelden die je met onze site heeft laten kennismaken.';

$profile_questions['37']['guideline'] = '';

$profile_questions['37']['extsearchhead'] = 'Doorverwezen door';

$profile_questions['37']['10041'] = 'email';

$profile_questions['37']['10042'] = 'krant of gedrukte advertentie';

$profile_questions['37']['10043'] = 'online banner';

$profile_questions['37']['10044'] = 'advertentie op de radio';

$profile_questions['37']['10045'] = 'vriend';

$profile_questions['37']['10046'] = 'advertentie op tv';

$profile_questions['37']['10047'] = 'zoekmachine';

$profile_questions['37']['10048'] = 'mond aan mond reclame';

$profile_questions['37']['10049'] = 'andere referenties';

?>