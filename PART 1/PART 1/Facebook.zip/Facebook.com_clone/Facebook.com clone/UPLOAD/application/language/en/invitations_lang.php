<?php

	$lang['page_title']	= 'Invitations';

	$lang['invitations_friends_note']	= 'You don\'t have any friends invitation.';
	$lang['invitations_groups_note']	= 'You don\'t have any groups invitation.';
	$lang['invitations_events_note']	= 'You don\'t have any events invitation.';
	$lang['invitations_friends']	= 'Friends';
	$lang['invitations_groups']		= 'Groups';
	$lang['invitations_events']		= 'Events';
	$lang['invitations_name']		= 'Name';
	$lang['invitations_confirm']	= 'Confirm Request';
	$lang['invitations_reject']		= 'Reject Request';
	$lang['invitations_sender']		= 'Sender';
	$lang['invitations_group']		= 'Group';
	$lang['invitations_event']		= 'Event';
	$lang['invitations_admin']		= 'Admin';

	$lang['invitations_event_confirm']	= 'Event request has been successfully confirmed';
	$lang['invitations_event_reject']	= 'Event request has been rejected';
	$lang['invitations_group_confirm']	= 'Group request has been successfully confirmed';
	$lang['invitations_group_reject']	= 'Group request has been rejected';
	$lang['invitations_friend_confirm']	= 'Friend request has been successfully confirmed';
	$lang['invitations_friend_reject']	= 'Friend request has been rejected';


?>