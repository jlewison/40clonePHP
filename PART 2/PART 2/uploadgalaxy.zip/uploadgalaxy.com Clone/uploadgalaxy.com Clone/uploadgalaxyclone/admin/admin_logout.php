<?
setcookie('admin_uname','');
setcookie('admin_uid','');
header("location: index.php");
?>
