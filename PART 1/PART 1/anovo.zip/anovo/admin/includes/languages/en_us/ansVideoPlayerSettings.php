<?php
$LANG['page_title'] = 'Video Player Settings';
$LANG['play_settings'] = 'Play Settings';
$LANG['auto_play'] = 'Auto Play';
$LANG['click_to_play'] = 'Click to play';
$LANG['title'] = 'Title';
$LANG['share_link'] = 'Share link';
$LANG['repeat_link'] = 'Repeat link';
$LANG['skin'] = 'Theme';
$LANG['play_list_settings'] = 'Play List Settings';
$LANG['show_play_list_by'] = 'Show Playlist by';
$LANG['update'] = 'Update';
$LANG['on'] = 'On';
$LANG['off'] = 'Off';
$LANG['tags'] = 'Tags';
$LANG['channel'] = 'Channel';
$LANG['random'] = 'Random';
$LANG['msg_success_updated'] = 'Successfully! Updated';
?>