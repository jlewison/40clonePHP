<?php
require_once ('../common/config.inc.php');
require_once ('../common/configs/config_ans_audio.inc.php');
$CFG['lang']['include_files'][] = 'members/includes/languages/%s/ansViewAudio.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['mods']['is_include_only']['non_html_header_files'] = true;
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
require_once ('../ansViewAudio.inc.php');
?>