<?php
$LANG['forums_title_index'] = 'Forum Index';
$LANG['forums_err_tip_compulsory'] = 'Compulsory';
$LANG['forums_no_titles'] = 'No Forum Title created';
$LANG['forums_title'] = 'Title';
$LANG['forums_last_post'] = 'Last Post';
$LANG['forums_friends'] = ' Friends';
$LANG['forums_videos'] = ' Videos';
$LANG['forums_photos'] = ' Photos';
$LANG['forums_topics'] = ' Topics: ';
$LANG['forums_posts'] = 'Posts';
$LANG['forums_responses'] = ' Responses';
$LANG['forums_tbl_summary'] = 'Container to view the forum details';
$LANG['forums_tbl_page_nav_summary'] = 'Container to view page list';
?>
