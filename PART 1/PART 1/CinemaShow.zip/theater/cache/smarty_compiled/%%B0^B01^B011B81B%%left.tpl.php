<?php /* Smarty version 2.6.18, created on 2007-11-21 12:04:28
         compiled from ../advertisements/left.tpl */ ?>
<a href="http://www.anrdoezrs.net/click-2720081-10459965" target="_top">
<img src="http://www.tqlkg.com/image-2720081-10459965" width="120" height="240" alt="300 - Get the Movie!" border="0"/></a>