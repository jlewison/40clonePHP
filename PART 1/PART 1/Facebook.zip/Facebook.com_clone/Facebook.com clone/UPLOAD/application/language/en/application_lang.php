<?php

	$lang['app_home']		= 'Home';
	$lang['app_account']	= 'Account';
	$lang['app_privacy']	= 'Privacy';
	$lang['app_logout']		= 'Logout';
	$lang['app_language']	= 'Language';
	
	$lang['app_profile']	= 'Profile';
	$lang['app_edit']		= 'Edit';
	$lang['app_friends']	= 'Friends';
	$lang['app_network']	= 'Network';
	$lang['app_inbox']		= 'Inbox';
	
	$lang['app_hi']			= 'Hi';
	
	$lang['app_online_now']			= 'Online Now';
	$lang['app_recently_updated']	= 'Recently Updated';
	$lang['app_recently_added']		= 'Recently Added';
	$lang['app_all_friends']		= 'All Friends';
	$lang['app_invite_friends']		= 'Invite Friends';
	
	$lang['app_browse_network']		= 'Browse All';
	$lang['app_join_network']		= 'Joined Network(s)';
	
	$lang['app_inbox']		= 'Inbox';
	$lang['app_sent']		= 'Sent';
	$lang['app_trash']		= 'Trash';
	$lang['app_compose']	= 'Compose';
	
	$lang['app_browse']	= 'Browse';
	$lang['app_search']	= 'Search';
	
	$lang['app_application']	= 'Application';
	
	$lang['report_post']	= 'Post your report';
	$lang['report_type']	= 'Report Type';
	$lang['report_comment']	= 'Comment';
	$lang['report_error']	= 'Enter a comment';
?>