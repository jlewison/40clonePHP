<?php
class blogList extends ListRecordsHandler
{
		public $enabled_edit_fields = array();
		public $msg = '';
		public function buildSortQuery()
		{
				$this->sql_sort = $this->fields_arr['orderby_field'] . ' ' . $this->fields_arr['orderby'];
		}
		public function buildConditionQuery()
		{
				$this->sql_condition = 'blog_id=\'' . $this->fields_arr['blog_id'] . '\'';
				if ($this->CFG['admin']['ignore_user'])
				{
						$this->sql_condition .= ' AND NOT EXISTS (SELECT 1 FROM ' . $this->CFG['db']['tbl']['user_ignored'] . ' AS ui WHERE ui.user_id=' . $this->CFG['user']['user_id'] . ' AND ui.ignored_id=bc.user_id)';
				}
		}
		public function showCommentsList()
		{
				$this->buildSelectQuery();
				$this->buildConditionQuery();
				$this->buildSortQuery();
				$this->buildQuery();
				$this->executeQuery();

?>
<h2><?php echo $this->LANG['page_title']; ?> - <?php echo $this->LANG['comments_title']; ?></h2>
<?php
				if ($this->isResultsFound())
				{
						$paging_arr = array('blog_id');
?>
<?php if ($this->isShowPageBlock('selAcceptCommentBlock') and $this->isMember())
						{ ?>
<?php if ($this->isAllowedToAsk())
								{ ?>
<span id="selTop"><a href="#selAddComment" onclick="new Effect.ScrollTo('selAddComment'); return false;"><?php echo $this->LANG['add_comments']; ?></a></span>
<?php }
								else
								{ ?>
<div id="selMsgError">
  <p><?php echo $this->LANG['info_not_allowed_to_post']; ?></p>
</div>
<?php }
						} ?>
<div class="clsPagingCollapse">
  <?php if ($this->CFG['comments']['expand_collapse'])
						{ ?>
  <span class="expand-all" onclick="toggleExpandComments();"></span>
  <script type="text/javascript" language="javascript">
	var commentsArray = new Array();
</script>
  <?php } ?>
  <?php
						if ($this->CFG['admin']['navigation']['top']) $this->populatePageLinks($this->getFormField('start'), $paging_arr);
?>
</div>
<?php
						$i = 0;
						while ($row = $this->fetchResultRecord())
						{
								$i++;
								$clsOddOrEvenQuestion = 'clsEvenQuestion';
								if ($i % 2) $clsOddOrEvenQuestion = 'clsOddQuestion';
								$row['date_added'] = ($row['date_added'] != '') ? getTimeDiffernceFormat($row['date_added']) : '';
								$userDetails = $this->getUserDetailsFromUsersTable($this->CFG['db']['tbl']['users'], $row['user_id']);
								$name = $userDetails['name'];
								$commentId = $row['comment_id'];
?>
<?php if ($this->CFG['comments']['expand_collapse'])
								{ ?>
<script type="text/javascript" language="javascript">
	commentsArray['<?php echo $i; ?>'] = '<?php echo $commentId; ?>';
</script>
<?php } ?>
<div class="clsBlogDisplay" id="cmd<?php echo $row['comment_id']; ?>">
  <div class="lbprofile">
    <div class="rbprofile">
      <div class="bbprofile">
        <div class="blcprofile">
          <div class="brcprofile">
            <div class="tbprofile">
              <div class="tlcprofile">
                <div class="trcprofile">
                  <?php if ($this->CFG['comments']['expand_collapse'])
								{ ?>
                  <span id="icon<?php echo $row['comment_id']; ?>" class="collapse expand" onclick="Effect.toggle('comment<?php echo $row['comment_id']; ?>', 'slide');"></span>
                  <?php } ?>
                  <div class="clsUserBlogDetails" id="comment<?php echo $row['comment_id']; ?>">
                    <?php if (chkUserImageAllowed())
								{ ?>
					<div class="clsBlogUserThumb">
                      <p id="selImageBorder">
                        <?php displayBlogUserSmallImage($userDetails); ?>
                      </p>
                    </div>
                    <?php } ?>
                    <div class="clsBlogDetails">
                      <p><span id="selEditCommentTxt_<?php echo $row['comment_id']; ?>"><?php echo wordWrapManual($row['comment'], $this->CFG['admin']['blog']['line_length']); ?></span><span id="selEditComments_<?php echo $row['comment_id']; ?>"></span></p>
                    </div>
                  </div>
                  <ul class="clsBlogDisplayLinks">
                    <li class="clsLastBlogInfo"><span class="clsBlogInfoTitle"><?php echo $this->LANG['posted_by']; ?><?php echo $this->LANG['title_seperator']; ?></span>&nbsp;<a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'myanswers.php?uid=' . $userDetails['user_id'], $this->CFG['site']['relative_url'] . 'my/answers/' . $userDetails['user_id'] . '/', false); ?>"><?php echo stripString($name, $this->CFG['username']['short_length']); ?></a></li>
                    <li><span class="clsBlogInfoTitle"><?php echo $this->LANG['date_added']; ?><?php echo $this->LANG['title_seperator']; ?></span>&nbsp;<?php echo $row['date_added']; ?></li>
                  </ul>
                  <?php
								if ($this->isMember() and $row['user_id'] == $this->CFG['user']['user_id'])
								{
										$time = $this->CFG['admin']['blogs']['comment_edit_allowed_time'] - $row['date_edit'];
										if ($time > 2)
										{
												$this->enabled_edit_fields[$row['comment_id']] = $time;
?>
                  <p class="clsCommentsReplySection"><span id="selViewTimerComment_<?php echo $row['comment_id']; ?>"><?php echo $time; ?></span></p>
                  <p class="clsCommentsReplySection"><span id="selViewDeleteComment_<?php echo $row['comment_id']; ?>"><a href="#" onClick="return deleteCommand('<?php echo $this->CFG['site']['url']; ?>members/blogComment.php', 'blog_id=<?php echo $this->fields_arr['blog_id']; ?>&comment_id=<?php echo $row['comment_id']; ?>&ajax_page=true&page=deletecomment','cmd<?php echo $row['comment_id']; ?>')"><?php echo $this->LANG['blogs_delete']; ?></a></span></p>
                  <!--<p class="clsCommentsReplySection"><span id="selViewEditComment_<?php echo $row['comment_id']; ?>" class="clsViewPostComment"><a href="#" onClick="return callAjaxEdit('<?php echo $this->CFG['site']['url']; ?>members/blogComment.php', 'blog_id=<?php echo $this->fields_arr['blog_id']; ?>&ajax_page=true', '<?php echo $row['comment_id']; ?>')"><?php echo $this->LANG['blogs_edit']; ?></a></span></p>-->
                  <?php
										}
								}
?>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php
						}
						if ($this->CFG['admin']['navigation']['bottom']) $this->populatePageLinks($this->getFormField('start'), $paging_arr);
						$key = array_flip($this->enabled_edit_fields);
						$key = '\'' . implode('\',\'', $key) . '\'';
?>
<script language="javascript">
var enabled_edit_fields_time = new Array();
var enabled_edit_fields_comment = new Array(<?php echo $key; ?>);
<?php foreach ($this->enabled_edit_fields as $key => $value)
						{ ?>
	enabled_edit_fields_time[<?php echo $key; ?>] = <?php echo $value; ?>;
<?php } ?>
</script>
<?php
				}
				else
				{
?>
<?php if ($this->isShowPageBlock('selAcceptCommentBlock') and $this->isMember())
						{ ?>
<?php if ($this->isAllowedToAsk())
								{ ?>
<span id="selTop"><a href="#selAddComment" onclick="new Effect.ScrollTo('selAddComment'); return false;"><?php echo $this->LANG['add_comments']; ?></a></span>
<?php }
								else
								{ ?>
<div id="selMsgError">
  <p><?php echo $this->LANG['info_not_allowed_to_post']; ?></p>
</div>
<?php }
						} ?>

<div id="selMsgAlert">
  <p><?php echo $this->LANG['no_records_found']; ?></p>
</div>
<?php
				}
				if ($this->isShowPageBlock('msg_form_info'))
				{
?>
<div id="selMsgSuccess">
    <p><?php echo $this->msg; ?></p>
</div>
<?php
				}
		}
		public function resetFieldsArray()
		{
				$this->setFormField('ajax_page', '');
				$this->setFormField('blog_id', '');
				$this->setFormField('act', '');
				$this->setFormField('comment', '');
				$this->setFormField('reason', '');
		}
		public function populateBlogsValue()
		{
				$sql = 'SELECT blog_id, subject, message, accept_comments, user_id, status,' . ' TIMEDIFF(NOW(), date_added) AS date_added, total_views, total_comments' . ' FROM ' . $this->CFG['db']['tbl']['blogs'] . ' WHERE' . ' blog_id=' . $this->dbObj->Param('blog_id') . ' AND status=\'Active\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['blog_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($row = $rs->FetchRow())
				{
						$row['date_added'] = ($row['date_added'] != '') ? getTimeDiffernceFormat($row['date_added']) : '';
						$this->fields_arr['subject'] = $row['subject'];
						$this->fields_arr['message'] = $row['message'];
						$this->fields_arr['date_added'] = $row['date_added'];
						$this->fields_arr['user_id'] = $row['user_id'];
						$this->fields_arr['total_views'] = $row['total_views'];
						$this->fields_arr['total_comments'] = $row['total_comments'];
						$this->fields_arr['accept_comments'] = $row['accept_comments'];
						return true;
				}
				return false;
		}
		public function displayBlog()
		{
				$userDetails = $this->getUserDetailsFromUsersTable($this->CFG['db']['tbl']['users'], $this->fields_arr['user_id']);
				$name = $userDetails['name'];
				$anchor = 'abuseContent';
?>
<div class="clsBlogDisplay">
  <div class="clsUserBlogDetails">
    <div class="clsBlogUserThumb">
      <p id="selImageBorder">
        <?php displayBlogUserSmallImage($userDetails); ?>
      </p>
    </div>
    <div class="clsBlogDetails">
      <p> <?php echo wordWrapManual($this->fields_arr['message'], $this->CFG['admin']['blog']['line_length']); ?></p>
    </div>
  </div>
  <ul class="clsBlogDisplayLinks">
    <li class="clsLastBlogInfo"><span class="clsBlogInfoTitle"><?php echo $this->LANG['posted_by']; ?><?php echo $this->LANG['title_seperator']; ?></span>&nbsp;<a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'myanswers.php?uid=' . $userDetails['user_id'], $this->CFG['site']['relative_url'] . 'my/answers/' . $userDetails['user_id'] . '/', false); ?>"><?php echo stripString($name, $this->CFG['username']['short_length']); ?></a></li>
    <li><span class="clsBlogInfoTitle"><?php echo $this->LANG['date_added']; ?><?php echo $this->LANG['title_seperator']; ?></span>&nbsp;<?php echo $this->fields_arr['date_added']; ?></li>
  </ul>
  <ul class="clsBlogDisplayLinks">
    <li class="clsLastBlogInfo"><span class="clsBlogInfoTitle"><?php echo $this->LANG['total_views']; ?><?php echo $this->LANG['title_seperator']; ?></span>&nbsp;<?php echo $this->fields_arr['total_views']; ?></li>
    <li><span class="clsBlogInfoTitle"><?php echo $this->LANG['total_comments']; ?><?php echo $this->LANG['title_seperator']; ?></span>&nbsp;<?php echo $this->fields_arr['total_comments']; ?></li>
  </ul>
  <ul class="clsBlogDisplayLinks">
    <?php
				if ($this->CFG['admin']['email_to_friend']['allowed'])
				{
?>
    <?php if ($this->CFG['user']['user_id'])
						{ ?>
    <li class="clsLastBlogInfo"> <a id="emailToFriends" href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'emailBlogs.php?bid=' . $this->getFormField('blog_id'), $this->CFG['site']['relative_url'] . 'email-blogs/' . $this->getFormField('blog_id') . '/', false); ?>" class="lWOn" onClick="return false;"><?php echo $this->LANG['email_to_friends']; ?></a> </li>
    <?php }
						else
						{ ?>
    <li class="clsLastBlogInfo"><a href="<?php echo getUrl($this->CFG['site']['url'] . 'members/blogComment.php?blog_id=' . $this->fields_arr['blog_id'], $this->CFG['site']['url'] . 'members/blogcomment/?blog_id=' . $this->fields_arr['blog_id'], false); ?>"><?php echo $this->LANG['email_to_friends']; ?></a></li>
    <?php } ?>
    <?php
				}
?>
    <?php if ($this->isMember() and ($this->getFormField('user_id') != $this->CFG['user']['user_id']))
				{ ?>
	<?php if ($this->chkIsBlogAbusedAlready($this->getFormField('blog_id')))
						{ ?>

	<li class=""><a href="<?php echo $_SERVER['REQUEST_URI']; ?>" onClick="return false;"><?php echo $this->LANG['blogs_abused_already']; ?></a></li>

	<?php }
						else
						{ ?>

	<li class=""><a href="<?php echo $_SERVER['REQUEST_URI']; ?>" onClick="abuseContent('abuseforum', '<?php echo $this->getFormField('blog_id'); ?>', '<?php echo $anchor; ?>', '<?php echo $this->LANG['confirm_abuse_blog_message']; ?>'); return false;"><?php echo $this->LANG['blogs_report_abuse']; ?></a></li>

	<?php } ?>
	<?php } ?>
  </ul>
</div>
<?php if ($this->CFG['admin']['blogs']['ratings'])
				{ ?>
<div id="selBlogRatingContent">
  <?php
						$blog_url = getUrl($this->CFG['site']['url'] . 'members/blogComment.php?blog_id=' . $this->fields_arr['blog_id'], $this->CFG['site']['url'] . 'members/blogcomment/?blog_id=' . $this->fields_arr['blog_id'], false);
						$this->getBlogRatings($this->CFG['db']['tbl']['users_stared_blogs'], $this->CFG['db']['tbl']['blogs'], $this->fields_arr['blog_id'], $this->fields_arr['user_id'], $this->CFG['site']['project_path_relative'], $this->CFG['site']['relative_url'], $blog_url);
?>
</div>
<?php } ?>
<?php
				if ($this->fields_arr['accept_comments'] == 'Yes')
				{
						$this->setPageBlockShow('selAcceptCommentBlock');
				}
		}
		public function getBlogRatings($users_stared_blog_table, $blog_table, $blog_id, $user_id, $cfg_project_path_relative, $relative_path, $blog_url)
		{
				$start = 1000;
				$end = 1004;
?>
<div class="blctitle">
  <div class="brctitle">
    <div class="tlctitle">
      <div class="trctitle">
        <p class="clsRatingImg">
          <?php
				if ($this->CFG['user']['user_id'] == 0)
				{
?>
          <span class="clsRateStars"><?php echo $this->LANG['rate_now']; ?>
          <?php
						$pointer = 1;
						for ($j = $start; $j < $end; $j++)
						{
?>
          <img id="rate<?php echo ($j + 1); ?>" src="<?php echo $cfg_project_path_relative; ?>images/icon-rate.gif" alt="<?php echo ($pointer); ?>" onMouseOver="mouseOverAnswers(<?php echo ($j + 1); ?>, <?php echo $start; ?>, '<?php echo $cfg_project_path_relative; ?>images/icon-ratehover.gif', '<?php echo $cfg_project_path_relative; ?>images/icon-rate.gif');" onMouseOut="mouseOutAnswers(<?php echo $start; ?>);" onClick="window.location='<?php echo $blog_url; ?>';" />
          <?php
								$pointer++;
						}
?>
          </span>
          <?php
				} elseif ($this->CFG['user']['user_id'] == $user_id)
				{
?>
			<span class="clsRateStars"><?php echo $this->LANG['you_cant_rate_your_blog']; ?></span>
<?php
				}
				else
				{
						$sql = 'SELECT rating FROM ' . $users_stared_blog_table . ' WHERE blog_id = ' . $this->dbObj->Param($blog_id) . ' AND user_id = ' . $this->dbObj->Param($this->CFG['user']['user_id']);
						$stmt = $this->dbObj->Prepare($sql);
						$result = $this->dbObj->Execute($stmt, array($blog_id, $this->CFG['user']['user_id']));
						if (!$result) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
						$rating = 0;
						if ($result->PO_RecordCount())
						{
?>
          <span class="clsRateStars"><?php echo $this->LANG['your_rating']; ?>
          <?php
								$row['rating'] = 0;
								if ($result->PO_RecordCount()) $row = $result->FetchRow();
								$rating = $row['rating'];
								$pointer = 1;
								for ($i = $start; $i < $rating + $start; $i++)
								{
?>
          <img id="rate<?php echo ($i + 1); ?>" src="<?php echo $cfg_project_path_relative; ?>images/icon-ratehover.gif" alt="<?php echo ($pointer); ?>" onMouseOver="mouseOverAnswers(<?php echo ($i + 1); ?>, <?php echo $start; ?>, '<?php echo $cfg_project_path_relative; ?>images/icon-ratehover.gif', '<?php echo $cfg_project_path_relative; ?>images/icon-rate.gif');" onMouseOut="mouseOutAnswers(<?php echo $start; ?>);" onClick="getQuestionRatingDetails('<?php echo $relative_path; ?>ratingAnswer.php', 'action=blogs&blog_id=<?php echo $blog_id; ?>&uid=<?php echo $user_id; ?>&rating=<?php echo ($pointer); ?>', 'selBlogRatingContent');" />
          <?php
										$pointer++;
								}
								for ($j = $i; $j < $end; $j++)
								{
?>
          <img id="rate<?php echo ($j + 1); ?>" src="<?php echo $cfg_project_path_relative; ?>images/icon-rate.gif" alt="<?php echo ($pointer); ?>" onMouseOver="mouseOverAnswers(<?php echo ($j + 1); ?>, <?php echo $start; ?>, '<?php echo $cfg_project_path_relative; ?>images/icon-ratehover.gif', '<?php echo $cfg_project_path_relative; ?>images/icon-rate.gif');" onMouseOut="mouseOutAnswers(<?php echo $start; ?>);" onClick="getQuestionRatingDetails('<?php echo $relative_path; ?>ratingAnswer.php', 'action=blogs&blog_id=<?php echo $blog_id; ?>&uid=<?php echo $user_id; ?>&rating=<?php echo ($pointer); ?>', 'selBlogRatingContent');" />
          <?php
										$pointer++;
								}
?>
          </span>
          <?php
						}
						else
						{
?>
          <span class="clsRateStars"><?php echo $this->LANG['rate_now']; ?>
          <?php
								$pointer = 1;
								for ($j = $start; $j < $end; $j++)
								{
?>
          <img id="rate<?php echo ($j + 1); ?>" src="<?php echo $cfg_project_path_relative; ?>images/icon-rate.gif" alt="<?php echo ($pointer); ?>" onMouseOver="mouseOverAnswers(<?php echo ($j + 1); ?>, <?php echo $start; ?>, '<?php echo $cfg_project_path_relative; ?>images/icon-ratehover.gif', '<?php echo $cfg_project_path_relative; ?>images/icon-rate.gif');" onMouseOut="mouseOutAnswers(<?php echo $start; ?>);" onClick="getQuestionRatingDetails('<?php echo $relative_path; ?>ratingAnswer.php', 'action=blogs&blog_id=<?php echo $blog_id; ?>&uid=<?php echo $user_id; ?>&rating=<?php echo ($pointer); ?>', 'selBlogRatingContent');" />
          <?php
										$pointer++;
								}
?>
          </span>
          <?php
						}
				}
				$sql = 'SELECT COUNT(star_id) as cnt FROM ' . $users_stared_blog_table . ' WHERE blog_id = ' . $this->dbObj->Param($blog_id);
				$stmt = $this->dbObj->Prepare($sql);
				$result = $this->dbObj->Execute($stmt, array($blog_id));
				if (!$result) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = $result->FetchRow();
				$rating_count = $row['cnt'];
				$sql = 'SELECT total_stars FROM ' . $blog_table . ' WHERE blog_id = ' . $this->dbObj->Param($blog_id);
				$stmt = $this->dbObj->Prepare($sql);
				$result = $this->dbObj->Execute($stmt, array($blog_id));
				if (!$result) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$rating = 0;
				if ($result->PO_RecordCount())
				{
						$row = $result->FetchRow();
						$rating = $row['total_stars'];
				}
?>
          <span class="clsRateScores"><?php echo $this->LANG['average_rating']; ?> <span class="clsScore"><?php echo $rating; ?> / <?php echo $rating_count; ?></span> <?php echo $this->LANG['ratings']; ?> </span> </p>
      </div>
    </div>
  </div>
</div>
<?php
		}
		public function postComment()
		{
				$sql = 'INSERT INTO ' . $this->CFG['db']['tbl']['blog_comment'] . ' SET blog_id=' . $this->dbObj->Param('blog_id') . ', user_id=' . $this->dbObj->Param('user_id') . ', comment=' . $this->dbObj->Param('comment') . ', date_added=NOW()';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['blog_id'], $this->CFG['user']['user_id'], strip_tags(html_entity_decode($this->fields_arr['comment']), '<br><br />')));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$next_id = $this->dbObj->Insert_ID();
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['blogs'] . ' SET total_comments=total_comments+1' . ' WHERE blog_id=' . $this->dbObj->Param('blog_id') . ' AND accept_comments=\'Yes\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['blog_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				echo $next_id;
				echo '***--***!!!';
		}
		public function incrementViews()
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['blogs'] . ' SET total_views=total_views+1' . ' WHERE blog_id=' . $this->dbObj->Param('blog_id');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['blog_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function getEditCommentBlock()
		{
				$comment_id = $this->fields_arr['comment_id'];
?>
<form name="addEdit_<?php echo $comment_id; ?>" id="addEdit_<?php echo $comment_id; ?>" method="post" action="<?php echo $_SERVER['REQUEST_URI']; ?>" autocomplete="off">
  <table>
    <tr>
      <td><textarea class="clsCommonTextArea" name="comment" id="comment" rows="5" cols="80"><?php echo $this->getComment(); ?></textarea>
      </td>
    </tr>
    <tr>
      <td colspan="2"><input type="button" onClick="return addToEdit(<?php echo $comment_id; ?>, '<?php echo $this->CFG['site']['url'] . 'members/blogComment.php?blog_id=' . $this->fields_arr['blog_id'] . '&ajax_page=true'; ?>')" name="post_comment" id="post_comment" tabindex="<?php echo $this->getTabIndex(); ?>" value="<?php echo $this->LANG['postcomment_post_comment']; ?>" />
        &nbsp;&nbsp;
        <input type="button" onClick="return discardEdit(<?php echo $comment_id; ?>)" name="cancel" id="cancel" tabindex="<?php echo $this->getTabIndex(); ?>" value="<?php echo $this->LANG['postcomment_cancel']; ?>" />
      </td>
    </tr>
  </table>
</form>
<?php
		}
		public function getComment()
		{
				$sql = 'SELECT comment FROM ' . $this->CFG['db']['tbl']['blog_comment'] . ' WHERE comment_id=' . $this->dbObj->Param('comment_id');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['comment_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($row = $rs->FetchRow())
				{
						return $row['comment'];
				}
		}
		public function updateCommentAndVideoTable()
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['blog_comment'] . ' SET comment=' . $this->dbObj->Param('comment') . ' WHERE comment_id=' . $this->dbObj->Param('comment_id');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['f'], $this->fields_arr['comment_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				echo $this->getFormField('comment_id');
				echo '***--***!!!';
				echo $this->getFormField('f');
		}
		public function deleteComment()
		{
				$sql = 'SELECT blog_id FROM ' . $this->CFG['db']['tbl']['blog_comment'] . ' WHERE comment_id=' . $this->dbObj->Param('comment_id') . ' LIMIT 0,1';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['comment_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = $rs->FetchRow();
				$sql = 'DELETE FROM ' . $this->CFG['db']['tbl']['blog_comment'] . ' WHERE comment_id=' . $this->dbObj->Param('comment_id');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['comment_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($this->dbObj->Affected_Rows())
				{
						$sql = 'UPDATE ' . $this->CFG['db']['tbl']['blogs'] . ' SET total_comments = total_comments-1' . ' WHERE blog_id=' . $this->dbObj->Param('blog_id');
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($row['blog_id']));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				}
				echo $this->LANG['success_deleted'];
		}
		public function updateBlogAbuseCount()
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['blogs'] . ' SET abuse_count=abuse_count+1' . ' WHERE blog_id=' . $this->dbObj->Param('blog_id');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['blog_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function updateAbuseBlog()
		{
				$sql = 'SELECT abuse_id FROM ' . $this->CFG['db']['tbl']['abuse_blog'] . ' WHERE blog_id=' . $this->dbObj->Param('blog_id') . ' AND reported_by=' . $this->dbObj->Param('reported_by');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['blog_id'], $this->CFG['user']['user_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if (!$rs->PO_RecordCount())
				{
						$sql = 'INSERT INTO ' . $this->CFG['db']['tbl']['abuse_blog'] . ' SET blog_id=' . $this->dbObj->Param('blog_id') . ', reported_by=' . $this->dbObj->Param('reported_by') . ', reason=' . $this->dbObj->Param('reason') . ', date_abused=NOW()';
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['blog_id'], $this->CFG['user']['user_id'], $this->fields_arr['reason']));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
						if ($this->dbObj->Affected_Rows())
						{
								$this->updateBlogAbuseCount();
						}
				}
		}
}
$blogList = new blogList();
$blogList->setDBObject($db);
$blogList->makeGlobalize($CFG, $LANG);
if (!chkAllowedModule(array('blog'))) Redirect2URL($CFG['redirect']['dsabled_module_url']);
$blogList->setPageBlockNames(array('msg_form_success', 'msg_form_error', 'msg_form_info', 'selCommentListBlock', 'selAcceptCommentBlock', 'selBlogDetails'));
$blogList->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$blogList->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$blogList->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$blogList->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$blogList->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$blogList->setFormField('f', '');
$blogList->setFormField('type', '');
$blogList->setFormField('page', '');
$blogList->setFormField('comment_id', '');
$blogList->setFormField('orderby_field', 'comment_id');
$blogList->setFormField('orderby', 'DESC');
$blogList->setFormField('start', '0');
$blogList->setFormField('numpg', $CFG['data_tbl']['numpg']);
$blogList->setCSSColumnHeaderCellAscSortClasses(array('clsColumnHeaderCellAscSort1', 'clsColumnHeaderCellAscSort2', 'clsColumnHeaderCellAscSort3', 'clsColumnHeaderCellAscSort4', 'clsColumnHeaderCellAscSort5'));
$blogList->setCSSColumnHeaderCellDefaultClass('clsColumnHeaderCellDefault');
$blogList->setCSSColumnHeaderCellDescSortClasses(array('clsColumnHeaderCellDscSort1', 'clsColumnHeaderCellDscSort2', 'clsColumnHeaderCellDscSort3', 'clsColumnHeaderCellDscSort4', 'clsColumnHeaderCellDscSort5'));
$blogList->setMinRecordSelectLimit(2);
$blogList->setMaxRecordSelectLimit($CFG['data_tbl']['max_record_select_limit']);
$blogList->setNumPerPageListArr($CFG['data_tbl']['numperpage_list_arr']);
$blogList->setTableNames(array($CFG['db']['tbl']['blog_comment'] . ' AS bc'));
$blogList->setReturnColumns(array('comment_id', 'blog_id', 'bc.user_id', 'comment', 'TIME_TO_SEC(TIMEDIFF(NOW(), date_added)) AS date_edit', 'TIMEDIFF(NOW(), date_added) AS date_added'));
$blogList->resetFieldsArray();
$blogList->sanitizeFormInputs($_REQUEST);
if ($blogList->populateBlogsValue())
{
		if ($blogList->isAjax())
		{
				if ($blogList->getFormField('act') == 'postcomment')
				{
						$blogList->setFormField('comment', strip_tags(html_entity_decode($blogList->getFormField('comment')), '<a><i><br><br />'));
						$blogList->msg = $LANG['comment_post_failure'];
						if (trim($blogList->getFormField('comment')))
						{
								$blogList->postComment();
								$blogList->msg = $LANG['comment_post_success'];
						}
						$blogList->setPageBlockShow('selAcceptCommentBlock');
						$blogList->setPageBlockShow('msg_form_info');
						$blogList->showCommentsList();
						die();
				}
				if ($blogList->isFormGETed($_GET, 'f') and $blogList->getFormField('type') == 'edit')
				{
						$blogList->setHeaderStart();
						$blogList->setAllPageBlocksHide();
						$htmlstring = trim(urldecode($blogList->getFormField('f')));
						$htmlstring = strip_tags(html_entity_decode($htmlstring), '<br><br />');
						$blogList->setFormField('f', $htmlstring);
						$blogList->updateCommentAndVideoTable();
						$blogList->setHeaderEnd();
						exit;
				}
				else
						if ($blogList->getFormField('type') == 'edit')
						{
								echo $blogList->getFormField('comment_id');
								echo '***--***!!!';
								$blogList->getEditCommentBlock();
								die();
						}
						else
								if ($blogList->getFormField('page') == 'deletecomment')
								{
										$blogList->setAllPageBlocksHide();
										$blogList->deleteComment();
								}
		}
		else
		{
				$blogList->incrementViews();
				$blogList->setPageBlockShow('selBlogDetails');
				$blogList->setPageBlockShow('selCommentListBlock');
				$LANG['page_title'] = wordWrapManual($blogList->getFormField('subject'), $CFG['admin']['blog']['line_length']);
				if ($blogList->isFormPOSTed($_POST, 'confirm_action'))
				{
						$blogList->chkIsNotEmpty('reason', $LANG['answers_err_tip_compulsory']);
						if ($blogList->isValidFormInputs())
						{
								$blogList->updateAbuseBlog();
								$blogList->setPageBlockShow('msg_form_success');
								$blogList->setCommonErrorMsg($LANG['blog_abused_successfully']);
						}
						else
						{
								$blogList->setCommonErrorMsg($LANG['err_msg_reason_empty']);
								$blogList->setPageBlockShow('msg_form_error');
						}
				}
		}
}
else
{
		$blogList->setCommonErrorMsg($LANG['invalid_blogs_id']);
		$blogList->setPageBlockShow('msg_form_error');
}
if (!$blogList->isAjax())
{
?>
<script language="javascript" type="text/javascript" src="<?php echo $CFG['site']['url']; ?>js/blogs.js"></script>
<script language="javascript" type="text/javascript">
	var site_url = '<?php echo $CFG['site']['url']; ?>';
	var block_arr = new Array('selEditPhotoComments','selMsgAbuseConfirm');
	var replace_url = '<?php echo getUrl($CFG['site']['url'] . 'login.php', $CFG['site']['url'] . 'login/', false); ?>';
	var deleteConfirmation = "<?php echo $LANG['delete_confirmation']; ?>";
	var total_comments = 10;
	var minimum_counts = 10000;
</script>
<div id="selblogList">
  <div class="clsManageBlogHeading">
    <div class="clsBlogHeading">
      <h2><?php echo $LANG['page_title']; ?></h2>
    </div>
    <div class="clsManageBlog"><span class=""><a href="<?php echo getUrl($CFG['site']['relative_url'] . 'blogs.php', $CFG['site']['relative_url'] . 'blog/', false); ?>"><?php echo $LANG['back_to_blog']; ?></a></span></div>
  </div>
  <?php
		if ($blogList->isShowPageBlock('msg_form_error'))
		{
?>
  <div id="selMsgError">
    <p><?php echo $LANG['msg_error_sorry']; ?></p>
    <p><?php echo $blogList->getCommonErrorMsg(); ?></p>
  </div>
  <?php
		}
		if ($blogList->isShowPageBlock('msg_form_success'))
		{
?>
  <div id="selMsgSuccess">
    <p><?php echo $blogList->getCommonErrorMsg(); ?></p>
  </div>
  <?php
		}
		if ($blogList->isShowPageBlock('selBlogDetails'))
		{
?>
  <div>
    <?php $blogList->displayBlog(); ?>
  </div>
  <?php
				if ($blogList->isMember() and ($blogList->getFormField('user_id') != $CFG['user']['user_id']))
				{
						$anchor = 'abuseContent';
?>
  <a href="#" id="<?php echo $anchor; ?>"></a>
  <div id="selMsgAbuseConfirm" class="selMsgAbuseConfirm" style="display:none;position:absolute;">
    <form name="formAbuseConfirm" id="formAbuseConfirm" method="post" action="<?php echo URL($_SERVER['REQUEST_URI']); ?>">
      <p id="confirmAbuseMessage"></p>
      <table>
        <tr>
          <td><p><?php echo $LANG['answers_reason']; ?></p>
            <p>
              <textarea class="clsCommonTextArea" name="reason" id="reason" tabindex="<?php echo $blogList->getTabIndex(); ?>"><?php echo $blogList->getFormField('reason'); ?></textarea>
            </p>
            <p id="validReason"></p></td>
        </tr>
        <tr>
          <td><input type="submit" class="clsSubmitButton" name="confirm_action" id="confirm_action" value="<?php echo $LANG['member_yes']; ?>" tabindex="<?php echo $blogList->getTabIndex(); ?>" onClick="return chkIsAbuseReasonExists();" />
            &nbsp;
            <input type="button" class="clsCancelButton" name="cancel" id="cancel" value="<?php echo $LANG['member_no']; ?>" tabindex="<?php echo $blogList->getTabIndex(); ?>" onClick="removeReasonErrors(); return hideAllBlocks();" />
          </td>
        </tr>
      </table>
      <input type="hidden" name="content_id" id="content_id" value="" />
    </form>
  </div>
  <!-- 	<a href="<?php echo $_SERVER['REQUEST_URI']; ?>" onClick="abuseContent('abuseforum', '<?php echo $blogList->getFormField('blog_id'); ?>', '<?php echo $anchor; ?>', '<?php echo $LANG['confirm_abuse_blog_message']; ?>'); return false;"><?php echo $LANG['blogs_report_abuse']; ?></a> -->
  <?php
				}
		}
		if ($blogList->isShowPageBlock('selCommentListBlock'))
		{
?>
  <div id="selCommentBlock">
    <?php $blogList->showCommentsList(); ?>
  </div>
  <?php
				if ($blogList->isShowPageBlock('selAcceptCommentBlock') and $blogList->isMember() and $blogList->isAllowedToAsk())
				{
?>
  <div id="selAddComment">
    <h2 class="clsBlogComment"><?php echo $LANG['post_comment']; ?></h2>
    <span id="backtotop"><a href="#selTop" onclick="new Effect.ScrollTo('selTop'); return false;"><?php echo $LANG['back_to_top']; ?></a></span>
    <form name="addComments" id="addComments" method="post" action="<?php echo getUrl('blogComment.php', 'blogcomment/'); ?>" autocomplete="off" onsubmit="return false">
      <table class="clsPostBlogTbl">
        <tr>
          <td><textarea class="clsCommonTextArea" name="comment" id="comment" tabindex="<?php echo $blogList->getTabIndex(); ?>" rows="5" cols="180" maxlength="<?php echo $CFG['admin']['comment']['limit']; ?>" onFocus="updatelength(this);" onKeyUp="updatelength(this);"></textarea>
            <div><?php echo $LANG['total_charaters_entered']; ?> <span id="ss">0  (<?php echo $LANG['limit']; ?> <?php echo $CFG['admin']['comment']['limit']; ?>)</span></div></td>
        </tr>
        <tr>
          <td class="clsBlogPostCommentCell"><input type="button" onClick="return addBlogComment('<?php echo getUrl('blogComment.php', 'blogcomment/'); ?>', 'ajax_page=true&blog_id=<?php echo $blogList->getFormField('blog_id'); ?>&act=postcomment');" name="post_comment" id="post_comment" tabindex="<?php echo $blogList->getTabIndex(); ?>" value="<?php echo $LANG['post_comment']; ?>" />
          </td>
        </tr>
      </table>
    </form>
  </div>
  <?php
				}
		}
?>
</div>
<?php

		require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
}
?>
<script language="javascript" type="text/javascript">
	var max_timer = '<?php echo $CFG['admin']['blogs']['comment_edit_allowed_time']; ?>';
	changeTimer();
	var dontUse = 0;

	var expand = true;
	var clicked = true;
	var toggleExpandComments = function(){
		if (clicked){
			clicked = false;
			for (var i=1; i<=commentsArray.length; i++){
				commentObj = 'comment'+commentsArray[i];
				if ($(commentObj)){
					if (expand){
						Effect.SlideUp(commentObj);
					}else{
						Effect.SlideDown(commentObj);
					}
				}
			}
			expand = (expand)?false:true;
			setTimeout('changeClickedStatus()', 2000);
		}
	}
	var changeClickedStatus = function(){
		toggleNavBar();
		clicked = true;
	}
</script>
