<?php /* Smarty version 2.6.6, created on 2006-03-11 11:26:19
         compiled from admin/admin_config.tpl */ ?>
<form action="admin_index.php" method=POST>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse; font-family:Verdana; font-size:10pt" bordercolor="#111111" width="100%" height="69">
  <tr>
    <td width="38%" align="right" height="20" bgcolor="#C0C0C0">
    <p align="center"><b>Name</b></td>
    <td width="2%" height="20" bgcolor="#C0C0C0">&nbsp;</td>
    <td width="30%" align="left" height="20" bgcolor="#C0C0C0">
    <b>Value</b></td>
    <td width="30%" align="left" height="20" bgcolor="#C0C0C0">
    <b>Display Text</b></td>
  </tr>
  <tr>
    <td width="100%" align="right" height="1" colspan="4" bgcolor="#F0F0F0">
    </td>
  </tr>
  <tr>
    <td width="38%" align="right" height="29">Max Upload File Size (Free)</td>
    <td width="2%" height="29">&nbsp;</td>
    <td width="30%" align="left" height="29">
    <input name="MAX_SIZE" size="8" style="font-family: Verdana; font-size: 10pt" value="<?php echo $this->_tpl_vars['MAX_SIZE']; ?>
"> 
    KB</td>
    <td width="30%" align="left" height="29">
    &nbsp;</td>
  </tr>
  <tr>
    <td width="38%" align="right" height="30">Max Upload File Size (Premium)</td>
    <td width="2%" height="30">&nbsp;</td>
    <td width="30%" align="left" height="30">
    <input name="PRE_MAX_SIZE" size="8" style="font-family: Verdana; font-size: 10pt" value="<?php echo $this->_tpl_vars['PRE_MAX_SIZE']; ?>
"> 
    KB</td>
    <td width="30%" align="left" height="30">
    &nbsp;</td>
  </tr>
  <tr>
    <td width="38%" align="right" height="30">Blocked Mime Types</td>
    <td width="2%" height="30">&nbsp;</td>
    <td width="30%" align="left" height="30">
    <input name="MIME_TYPES" size="20" style="font-family: Verdana; font-size: 10pt" value="<?php echo $this->_tpl_vars['MIME_TYPES']; ?>
"></td>
    <td width="30%" align="left" height="30">
    &nbsp;</td>
  </tr>
  <tr>
    <td width="38%" align="right" height="30">Max No. Of Download</td>
    <td width="2%" height="30">&nbsp;</td>
    <td width="30%" align="left" height="30">
    <input type="text" name="MAX_COUNT" size="8" style="font-family: Verdana; font-size: 10pt" value="<?php echo $this->_tpl_vars['MAX_COUNT']; ?>
"> 
    Times</td>
    <td width="30%" align="left" height="30">
    <input name="D4" size="20" style="font-family: Verdana; font-size: 10pt" value="<?php echo $this->_tpl_vars['MND']; ?>
"></td>
  </tr>
  <tr>
    <td width="38%" align="right" height="35">Expire Time</td>
    <td width="2%" height="35">&nbsp;</td>
    <td width="30%" align="left" height="35">
    <input name="MAX_TIME" size="8" style="font-family: Verdana; font-size: 10pt" value="<?php echo $this->_tpl_vars['MAX_TIME']; ?>
"> 
    Days</td>
    <td width="30%" align="left" height="35">
    &nbsp;</td>
  </tr>
  <tr>
    <td width="38%" align="right" height="35">Max. Daily Transfer</td>
    <td width="2%" height="35">&nbsp;</td>
    <td width="30%" align="left" height="35">
    <input name="DAILY_TRANSFER" size="8" style="font-family: Verdana; font-size: 10pt" value="<?php echo $this->_tpl_vars['DAILY_TRANSFER']; ?>
"> 
    KB</td>
    <td width="30%" align="left" height="35">
    &nbsp;</td>
  </tr>
  <tr>
    <td width="38%" align="right" height="35">Download Limit per Day</td>
    <td width="2%" height="35">&nbsp;</td>
    <td width="30%" align="left" height="35">
    <input name="MAX_DL" size="8" style="font-family: Verdana; font-size: 10pt" value="<?php echo $this->_tpl_vars['MAX_DL']; ?>
"> 
    KB</td>
    <td width="30%" align="left" height="35">
    &nbsp;</td>
  </tr>
  <tr>
    <td width="38%" align="right" height="35">Bandwidth Limit (Free)</td>
    <td width="2%" height="35">&nbsp;</td>
    <td width="30%" align="left" height="35">
    <input name="FRE_BW" size="8" style="font-family: Verdana; font-size: 10pt" value="<?php echo $this->_tpl_vars['FRE_BW']; ?>
"> 
    KB</td>
    <td width="30%" align="left" height="35">
    &nbsp;</td>
  </tr>
  <tr>
    <td width="38%" align="right" height="35">Bandwidth Limit (Premium)</td>
    <td width="2%" height="35">&nbsp;</td>
    <td width="30%" align="left" height="35">
    <input name="PRE_BW" size="8" style="font-family: Verdana; font-size: 10pt" value="<?php echo $this->_tpl_vars['PRE_BW']; ?>
"> 
    KB</td>
    <td width="30%" align="left" height="35">
    &nbsp;</td>
  </tr>
  <tr>
    <td width="38%" align="right" height="35">Limit Download Speed</td>
    <td width="2%" height="35">&nbsp;</td>
    <td width="30%" align="left" height="35">
    <input type="radio" name="LIMIT_SPEED" value="Yes" <?php if ($this->_tpl_vars['LIMIT_SPEED'] == 'Yes'): ?>Checked<?php endif; ?>>Enable
    <input type="radio" name="LIMIT_SPEED" value="No" <?php if ($this->_tpl_vars['LIMIT_SPEED'] == 'No'): ?>Checked<?php endif; ?>>Disable</td>
    <td width="30%" align="left" height="35">
    &nbsp;</td>
  </tr>
  <tr>
    <td width="38%" align="right" height="35">My PayPal Address</td>
    <td width="2%" height="35">&nbsp;</td>
    <td width="30%" align="left" height="35">
    <input name="PAY_TO" size="20" style="font-family: Verdana; font-size: 10pt" value="<?php echo $this->_tpl_vars['PAY_TO']; ?>
"></td>
    <td width="30%" align="left" height="35">
    &nbsp;</td>
  </tr>
  <tr>
    <td width="38%" align="right" height="35">User Reporting Mail</td>
    <td width="2%" height="35">&nbsp;</td>
    <td width="30%" align="left" height="35">
    <input name="ADMIN_MAIL" size="20" style="font-family: Verdana; font-size: 10pt" value="<?php echo $this->_tpl_vars['ADMIN_MAIL']; ?>
"></td>
    <td width="30%" align="left" height="35">
    &nbsp;</td>
  </tr>
  <tr>
    <td width="38%" align="right" height="35">Auto File Delete</td>
    <td width="2%" height="35">&nbsp;</td>
    <td width="30%" align="left" height="35">
    <input type="radio" name="AUTO_FILE_DELETE" value="Yes" <?php if ($this->_tpl_vars['AUTO_FILE_DELETE'] == 'Yes'): ?>Checked<?php endif; ?>>Enable
    <input type="radio" name="AUTO_FILE_DELETE" value="No" <?php if ($this->_tpl_vars['AUTO_FILE_DELETE'] == 'No'): ?>Checked<?php endif; ?>>Disable
    <input type="hidden" name="savetype" value></td>
    <td width="30%" align="left" height="35">
    &nbsp;</td>
  </tr>
  <tr>
    <td width="38%" align="right" height="48">&nbsp;</td>
    <td width="2%" height="48">&nbsp;</td>
    <td width="30%" align="left" height="48">        
    <input type="submit" value="Save" name="req" style="font-family: Verdana; font-size: 10pt;width:100"></td>
    <td width="30%" align="left" height="48">
    &nbsp;</td>
  </tr>
</table>
<input type="hidden" name="type" value="<?php echo $_REQUEST['change']; ?>
">
</form>