<?php

/**
 * popup Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 1/3/2008
 */
class popup extends Controller
{
		//Constructor
		function popup()
		{
				parent::Controller();
				//Load the language file
				//$this->lang->load('popup', $this->config->item('language_code'));
		}
		function postedItem()
		{
				$this->_showPage('postInterface');
		}
		function removeFriend()
		{
				$this->_showPage('removefriend');
		}
		function _showPage($template)
		{
				//check login
				$outputData['loggedIn'] = 1;
				if ($this->session->userdata('logged_in') != 1 && $this->session->userdata('user_id') == '')
				{
						$outputData['loggedIn'] = 0;
				}
				$this->smartyextended->view($template, $outputData);
		}
}


?>