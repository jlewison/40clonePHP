<?php
require_once ('../common/config.inc.php');
$CFG['mods']['is_include_only']['non_html_header_files'] = true;
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['auth']['is_authenticate'] = false;
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class CategoryFormHandler extends FormHandler
{
		public function setHeaderStart()
		{
				ob_start();
				header("Pragma: no-cache");
				header("Cache-Control: no-cache, must-revalidate");
				header("Expires: 0");
				header("Content-type: text/css; charset=iso-8859-1");
		}
		public function setHeaderEnd()
		{
				ob_end_flush();
		}
		public function getUserId($username)
		{
				$sql = 'SELECT user_id FROM users WHERE name=\'' . addslashes($username) . '\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if (!$rs->PO_RecordCount()) return false;
				$row = $rs->FetchRow();
				return $row['user_id'];
		}
		public function populateSubCategories($cid)
		{
				if (!$cid) return;
				$sql = 'SELECT cat_id, cat_name FROM ' . $this->CFG['db']['tbl']['questions_category'] . ' WHERE parent_id=' . $this->dbObj->Param('cid') . ' AND status=\'1\'ORDER BY cat_name';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($cid));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount())
				{
						while ($row = $rs->FetchRow())
						{
?>
							<option value="<?php echo $row['cat_id']; ?>"><?php echo $row['cat_name']; ?></option>
							<?php
						}
				}
		}
}
$categoryfrm = new CategoryFormHandler();
$categoryfrm->setHeaderStart();
$categoryfrm->setPageBlockNames();
$categoryfrm->setDBObject($db);
$categoryfrm->setCfgLangGlobal($CFG, $LANG);
$categoryfrm->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$categoryfrm->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$categoryfrm->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$categoryfrm->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$categoryfrm->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$categoryfrm->setFormField('cid', '');
$categoryfrm->setFormField('t', '');
$categoryfrm->sanitizeFormInputs($_GET);
$cid = $categoryfrm->getFormField('cid');
$sub_cat_tab_index = $categoryfrm->getFormField('t');


?>
<select name="sub_category" id="sub_category" tabIndex="<?php echo $sub_cat_tab_index; ?>">
<option value="">Choose..</option>
<?php $categoryfrm->populateSubCategories($categoryfrm->getFormField('cid')); ?>
</select>
<?php
$categoryfrm->setHeaderend();
?>