<?php include('restrict.php'); include('../settings.php'); require_once('../Connections/apound.php'); ?>
<?php
mysql_select_db($database_apound, $apound);
$query_CBL = "SELECT * FROM main WHERE dtu = $_GET[BLID]";
$CBL = mysql_query($query_CBL, $apound) or die(mysql_error());
$row_CBL = mysql_fetch_assoc($CBL);
$totalRows_CBL = mysql_num_rows($CBL);

$page_to_check = $row_CBL['blinkurl'];
$ch = curl_init();
$timeout = 0;
curl_setopt($ch, CURLOPT_USERAGENT, "User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0)");
curl_setopt ($ch, CURLOPT_URL, "$page_to_check");
curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
$file_contents = curl_exec($ch);
curl_close($ch);

$out = "";

$match_expression = "$linkbacka";
eregi("$match_expression", $file_contents, $out);
$murl = $out[0];

if($murl == "$match_expression") { $contain = "Y"; echo("<font color='green'>Yes, the page $page_to_check contain the back link $linkbacka</font>"); } else { $contain = "N"; echo("<font color='red'>No, the page $page_to_check not contain the code $linkbacka</font>"); }

$out = "";

mysql_free_result($CBL);
?>
