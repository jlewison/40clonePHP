<?php
require_once('Connections/apound.php'); 
$avail = "N";
$paid = "N";
$upbid = $oldbid + $newbid;
$link = mysql_pconnect($hostname_apound,$username_apound,$password_apound);
mysql_select_db($database_apound);
mysql_query("UPDATE main SET ujbid='$upbid' WHERE dtu='$bidid'");

$kinek  = "$adminmail" . ", " ;
$kinek .= "$email";
$targy = "$bidmailsubject";
$uzenet = "Your Listing ID: $bidid\n
Your Listing Title: $keyword\n
Your Listing URL: $url\n
View details or upgrade your listing: http://$domainname$pathmail/upgrade.php?ucat=$bidid
--------------------------------------------------------------------------
$bidmailmessage
--------------------------------------------------------------------------
Contact and Support: http://$domainname$pathmail/contact.php";
$fejlec = "From: $sitetitle <$frommail>\r\n";
mail($kinek, $targy, $uzenet, $fejlec);
?>