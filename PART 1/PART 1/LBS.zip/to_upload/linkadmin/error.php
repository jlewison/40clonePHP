<?php include('../settings.php');?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Untitled Document</title>
<style type="text/css">
<!--
.style1 {
	color: #000000;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.style2 {
	color: #FF0000;
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 24px;
}
.style3 {color: #FF0000}
-->
</style>
</head>

<body>
<p align="center" class="style2">&nbsp;</p>
<p align="center" class="style2">&nbsp;</p>
<p align="center" class="style2">Login Failed</p>
<p align="center" class="style1">Please <a href="<?php echo("$path");?>linkadmin/index.php" class="style3">click here</a> and type the correct username and password  
</p>
</body>
</html>
