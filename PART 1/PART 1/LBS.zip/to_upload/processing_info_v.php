<?php $str = "$keyword";
$resu = ord($str);
if($resu == '97') { $fres = "A"; }
elseif($resu == '98') { $fres = "B"; }
elseif($resu == '99') { $fres = "C"; }
elseif($resu == '100') { $fres = "D"; }
elseif($resu == '101') { $fres = "E"; }
elseif($resu == '102') { $fres = "F"; }
elseif($resu == '103') { $fres = "G"; }
elseif($resu == '104') { $fres = "H"; }
elseif($resu == '105') { $fres = "I"; }
elseif($resu == '106') { $fres = "J"; }
elseif($resu == '107') { $fres = "K"; }
elseif($resu == '108') { $fres = "L"; }
elseif($resu == '109') { $fres = "M"; }
elseif($resu == '110') { $fres = "N"; }
elseif($resu == '111') { $fres = "O"; }
elseif($resu == '112') { $fres = "P"; }
elseif($resu == '113') { $fres = "Q"; }
elseif($resu == '114') { $fres = "R"; }
elseif($resu == '115') { $fres = "S"; }
elseif($resu == '116') { $fres = "T"; }
elseif($resu == '117') { $fres = "U"; }
elseif($resu == '118') { $fres = "V"; }
elseif($resu == '119') { $fres = "W"; }
elseif($resu == '120') { $fres = "X"; }
elseif($resu == '121') { $fres = "Y"; }
elseif($resu == '122') { $fres = "Z"; }
elseif($resu == '65') { $fres = "A"; }
elseif($resu == '66') { $fres = "B"; }
elseif($resu == '67') { $fres = "C"; }
elseif($resu == '68') { $fres = "D"; }
elseif($resu == '69') { $fres = "E"; }
elseif($resu == '70') { $fres = "F"; }
elseif($resu == '71') { $fres = "G"; }
elseif($resu == '72') { $fres = "H"; }
elseif($resu == '73') { $fres = "I"; }
elseif($resu == '74') { $fres = "J"; }
elseif($resu == '75') { $fres = "K"; }
elseif($resu == '76') { $fres = "L"; }
elseif($resu == '77') { $fres = "M"; }
elseif($resu == '78') { $fres = "N"; }
elseif($resu == '79') { $fres = "O"; }
elseif($resu == '80') { $fres = "P"; }
elseif($resu == '81') { $fres = "Q"; }
elseif($resu == '82') { $fres = "R"; }
elseif($resu == '83') { $fres = "S"; }
elseif($resu == '84') { $fres = "T"; }
elseif($resu == '85') { $fres = "U"; }
elseif($resu == '86') { $fres = "V"; }
elseif($resu == '87') { $fres = "W"; }
elseif($resu == '88') { $fres = "X"; }
elseif($resu == '89') { $fres = "Y"; }
elseif($resu == '90') { $fres = "Z"; }
elseif($resu == '48') { $fres = "0"; }
elseif($resu == '49') { $fres = "1"; }
elseif($resu == '50') { $fres = "2"; }
elseif($resu == '51') { $fres = "3"; }
elseif($resu == '52') { $fres = "4"; }
elseif($resu == '53') { $fres = "5"; }
elseif($resu == '54') { $fres = "6"; }
elseif($resu == '55') { $fres = "7"; }
elseif($resu == '56') { $fres = "8"; }
elseif($resu == '57') { $fres = "9"; }
else { $resu = ""; }
$categ = "$fres";

require_once('Connections/apound.php'); 

if($fremode == 'Y' and $fmau == 'Y') { $avail = "Y"; $paid = "Y"; }
else { $avail = "N"; $paid = "N"; }

$one = date("Y")+1; $two = date("m-d"); $mydate = "$one-$two";

$gep = gethostbyaddr($_SERVER['REMOTE_ADDR']);
$gep_ip = gethostbyname("$gep");

if($badword <> '') {

$bad_words = explode('|', "$badword");
foreach ($bad_words as $naughty)
{
$url = eregi_replace($naughty, "CENSORED", $url);
}

$bad_words = explode('|', "$badword");
foreach ($bad_words as $naughty)
{
$keyword = eregi_replace($naughty, "CENSORED", $keyword);
}

$bad_words = explode('|', "$badword");
foreach ($bad_words as $naughty)
{
$descr1 = eregi_replace($naughty, "CENSORED", $descr1);
}

$bad_words = explode('|', "$badword");
foreach ($bad_words as $naughty)
{
$descr2 = eregi_replace($naughty, "CENSORED", $descr2);
}

$bad_words = explode('|', "$badword");
foreach ($bad_words as $naughty)
{
$mword = eregi_replace($naughty, "CENSORED", $mword);
}

$bad_words = explode('|', "$badword");
foreach ($bad_words as $naughty)
{
$mdesc = eregi_replace($naughty, "CENSORED", $mdesc);
}

$bad_words = explode('|', "$badword");
foreach ($bad_words as $naughty)
{
$deeptf = eregi_replace($naughty, "CENSORED", $deeptf);
}

$bad_words = explode('|', "$badword");
foreach ($bad_words as $naughty)
{
$deepts = eregi_replace($naughty, "CENSORED", $deepts);
}

$bad_words = explode('|', "$badword");
foreach ($bad_words as $naughty)
{
$deeptt = eregi_replace($naughty, "CENSORED", $deeptt);
}
} else {}

mysql_select_db($database_apound, $apound);
$result = mysql_query ("INSERT INTO main (categ, email, site, title, descr1, descr2, mword, mdesc, deeptf, dfurl, deepts, dsurl, deeptt, dturl, bid, stad, stup, stod, avail, paid, maincategory, gm_str, gm_str_nr, gm_city, gm_county, gm_country, gep_ip, blinkurl, tag1, tag2, tag3, tag4, tag5, tag6) VALUES('$categ', '$email', '$url', '$keyword', '$descr1', '$descr2', '$mword', '$mdesc', '$deeptf', '$dfurl', '$deepts', '$dsurl', '$deeptt', '$dturl', '$bid', NOW(), NOW(), '$mydate', '$avail', '$paid', '$selectc', '$gm_str', '$gm_str_nr', '$gm_city', '$gm_county', '$gm_country', '$gep_ip', '$blinkurl', '$tag1', '$tag2', '$tag3', '$tag4', '$tag5', '$tag6')");
//echo mysql_errno() . ": " . mysql_error(). "\n";

mysql_select_db($database_apound, $apound);
$query_CKNID = "SELECT * FROM main WHERE categ = '$categ' AND email = '$email' AND site = '$url' AND title = '$keyword' AND bid = '$bid'";
$CKNID = mysql_query($query_CKNID, $apound) or die(mysql_error());
$row_CKNID = mysql_fetch_assoc($CKNID);
$totalRows_CKNID = mysql_num_rows($CKNID);

$linkid = $row_CKNID['dtu'];

$kinek  = "$adminmail" . ", " ;
$kinek .= "$email";
$targy = "$buymailsubject";
$uzenet = "Your Listing ID: $linkid\n
Your Listing Title: $keyword\n
URL Submitted: $url\n
View details or upgrade your listing: http://$domainname$pathmail/upgrade.php?ucat=$linkid
--------------------------------------------------------------------------
$buymailmessage
--------------------------------------------------------------------------
Contact and Support: http://$domainname$pathmail/contact.php";
$fejlec = "From: $sitetitle <$frommail>\r\n";
mail($kinek, $targy, $uzenet, $fejlec);
// send mail for new registration

// TAG Section
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}
// TAG1
mysql_select_db($database_apound, $apound);
$query_tagA = "SELECT * FROM tags WHERE tag = '$tag1'";
$tagA = mysql_query($query_tagA, $apound) or die(mysql_error());
$row_tagA = mysql_fetch_assoc($tagA);
$totalRows_tagA = mysql_num_rows($tagA);

if($totalRows_tagA == '' and $tag1 <> '') {

$count = "1";
mysql_select_db($database_apound, $apound);
$result = mysql_query ("INSERT INTO tags (tag, count) VALUES('$tag1', '$count')");

}

else {

$id = $row_tagA['id'];
$tag = $row_tagA['tag'];
$count_old = $row_tagA['count'];
$count_new = "1";
$count = $count_old + $count_new;

mysql_select_db($database_apound);
mysql_query("UPDATE tags SET count='$count' WHERE id='$id'");
}

mysql_free_result($tagA);

// TAG2
mysql_select_db($database_apound, $apound);
$query_tagB = "SELECT * FROM tags WHERE tag = '$tag2'";
$tagB = mysql_query($query_tagB, $apound) or die(mysql_error());
$row_tagB = mysql_fetch_assoc($tagB);
$totalRows_tagB = mysql_num_rows($tagB);

if($totalRows_tagB == '' and $tag2 <> '') {

$count = "1";
mysql_select_db($database_apound, $apound);
$result = mysql_query ("INSERT INTO tags (tag, count) VALUES('$tag2', '$count')");

}

else {

$id = $row_tagB['id'];
$tag = $row_tagB['tag'];
$count_old = $row_tagB['count'];
$count_new = "1";
$count = $count_old + $count_new;

mysql_select_db($database_apound);
mysql_query("UPDATE tags SET count='$count' WHERE id='$id'");
}

mysql_free_result($tagB);

// TAG3
mysql_select_db($database_apound, $apound);
$query_tagC = "SELECT * FROM tags WHERE tag = '$tag3'";
$tagC = mysql_query($query_tagC, $apound) or die(mysql_error());
$row_tagC = mysql_fetch_assoc($tagC);
$totalRows_tagC = mysql_num_rows($tagC);

if($totalRows_tagC == '' and $tag3 <> '') {

$count = "1";
mysql_select_db($database_apound, $apound);
$result = mysql_query ("INSERT INTO tags (tag, count) VALUES('$tag3', '$count')");

}

else {

$id = $row_tagC['id'];
$tag = $row_tagC['tag'];
$count_old = $row_tagC['count'];
$count_new = "1";
$count = $count_old + $count_new;

mysql_select_db($database_apound);
mysql_query("UPDATE tags SET count='$count' WHERE id='$id'");
}

mysql_free_result($tagC);

// TAG4
mysql_select_db($database_apound, $apound);
$query_tagD = "SELECT * FROM tags WHERE tag = '$tag4'";
$tagD = mysql_query($query_tagD, $apound) or die(mysql_error());
$row_tagD = mysql_fetch_assoc($tagD);
$totalRows_tagD = mysql_num_rows($tagD);

if($totalRows_tagD == '' and $tag4 <> '') {

$count = "1";
mysql_select_db($database_apound, $apound);
$result = mysql_query ("INSERT INTO tags (tag, count) VALUES('$tag4', '$count')");

}

else {

$id = $row_tagD['id'];
$tag = $row_tagD['tag'];
$count_old = $row_tagD['count'];
$count_new = "1";
$count = $count_old + $count_new;

mysql_select_db($database_apound);
mysql_query("UPDATE tags SET count='$count' WHERE id='$id'");
}

mysql_free_result($tagD);

// TAG5
mysql_select_db($database_apound, $apound);
$query_tagE = "SELECT * FROM tags WHERE tag = '$tag5'";
$tagE = mysql_query($query_tagE, $apound) or die(mysql_error());
$row_tagE = mysql_fetch_assoc($tagE);
$totalRows_tagE = mysql_num_rows($tagE);

if($totalRows_tagE == '' and $tag5 <> '') {

$count = "1";
mysql_select_db($database_apound, $apound);
$result = mysql_query ("INSERT INTO tags (tag, count) VALUES('$tag5', '$count')");

}

else {

$id = $row_tagE['id'];
$tag = $row_tagE['tag'];
$count_old = $row_tagE['count'];
$count_new = "1";
$count = $count_old + $count_new;

mysql_select_db($database_apound);
mysql_query("UPDATE tags SET count='$count' WHERE id='$id'");
}

mysql_free_result($tagE);

// TAG6
mysql_select_db($database_apound, $apound);
$query_tagF = "SELECT * FROM tags WHERE tag = '$tag6'";
$tagF = mysql_query($query_tagF, $apound) or die(mysql_error());
$row_tagF = mysql_fetch_assoc($tagF);
$totalRows_tagF = mysql_num_rows($tagF);

if($totalRows_tagF == '' and $tag6 <> '') {

$count = "1";
mysql_select_db($database_apound, $apound);
$result = mysql_query ("INSERT INTO tags (tag, count) VALUES('$tag6', '$count')");

}

else {

$id = $row_tagF['id'];
$tag = $row_tagF['tag'];
$count_old = $row_tagF['count'];
$count_new = "1";
$count = $count_old + $count_new;

mysql_select_db($database_apound);
mysql_query("UPDATE tags SET count='$count' WHERE id='$id'");
}

mysql_free_result($tagF);
?>