<?php
include('class_HTTPRequest.php');

if($_REQUEST['language'] == '' && $_POST['submit'] == ''){
	header('Content-type: text/html; charset=UTF-8');
	$url = 'http://www.pligg.com/languages/getLanguageList.php?type=upgrade&version=B990';

	$r = new CD_HTTPRequest($url);
	$data = $r->DownloadToString();
	if(strpos($data, '!--Pligg Language Select-->') > 0){
		echo $data;
	} else {
		echo 'We just tried to connect to Pligg.com to get a list of available languages but there was a problem.<br /><br /><a href = "upgrade.php?language=local">Click to Continue in English</a>';
	}

	die();

} else {

	$language = $_REQUEST['language'];

	if($language != 'local'){
		$url = 'http://www.pligg.com/languages/getLanguageFile.php?type=installer&version=B990&language=' . $language;
		$r = new CD_HTTPRequest($url);
		$data = $r->DownloadToString();

		$filename = '../languages/installer_lang.php';

		$fh=fopen($filename,"w");

		if (fwrite($fh, $data)) {
			fclose($fh);
		} else {
			$url = 'http://www.pligg.com/languages/chmod_' . $language . '.php';
			$r = new CD_HTTPRequest($url);
			echo $r->DownloadToString();
			die();
		}
	}	

	$step = 1;

}


$include='header.php'; if (file_exists($include)) { include_once($include); }
$include='functions.php'; if (file_exists($include)) { include_once($include); }


echo '<h3>' . $lang['UpgradeTop'] . '</h3>';

$file='../config.php';
if (!file_exists($file)) { $errors[]="'$file' was not found! This is a fatal error."; }
elseif (filesize($file) <= 0) { $errors[]="'$file' is 0 bytes! This is a fatal error."; }

$file='../settings.php';
if (!file_exists($file)) { $errors[]="'$file' was not found! Try renaming 'config2.php' to 'settings.php'"; }
elseif (filesize($file) <= 0) { $errors[]="'$file' is 0 bytes!"; }
elseif (!is_writable($file)) { $errors[]="'$file' is not writable! Please chmod this file to 777 while editing."; }

$file='../libs/dbconnect.php';
if (!file_exists($file)) { $errors[]="'$file' was not found! This is a fatal error."; }
elseif (filesize($file) <= 0) { $errors[]="'$file' is 0 bytes! This is a fatal error."; }

if (!$errors) {

echo $lang['UpgradeHome'];

//this checks to see if they actually do want to upgrade.
if ($_POST['submit'] != "Yes") {
echo '<p>' . $lang['UpgradeAreYouSure'] . '</p>
	<form id="form" name="form" method="post">
	<input type="submit" name="submit" value="' . $lang['UpgradeYes'] . '" />
	</form>';
}
else { //they clicked yes!

$include='../config.php';
if (file_exists($include)) { 
	include_once($include);
	include(mnminclude.'html1.php');
}

echo $lang['UpgradingTables'] . '<br />';

include(mnminclude.'ts.php');

	$result = $db->get_results("select * from `" . table_config . "` where `var_name` = 'enable_captcha';");
	if (count($result) == 0) {
		$db->query("INSERT INTO `" . table_config . "` VALUES (69, 'Captcha', 'enable_captcha', 'true', 'true', 'true / false', 'User Registration Captcha', 'Enable or disable the user registration captcha.', 'define', NULL);");
	}
	
	$result = $db->get_results("select * from `" . table_config . "` where `var_name` = 'enable_gzip_files';");
	if (count($result) == 0) {
		$db->query("INSERT INTO `" . table_config . "` VALUES (70, 'Misc', 'enable_gzip_files', 'false', 'false', 'true / false', 'Enable Gzip File Compression', 'Enable or disable gzip compression on js files.', 'define', NULL);");
	}

	$result = $db->get_results("select * from `" . table_config . "` where `var_name` = 'minTitleLength';");
	if (count($result) == 0) {
		$db->query("INSERT INTO `" . table_config . "` VALUES (71, 'Submit', 'minTitleLength', '10', '10', 'number', 'Minimum Title Length', 'Set the minimum number of characters for the story title.', 'define', NULL);");
	}
	
	$result = $db->get_results("select * from `" . table_config . "` where `var_name` = 'minStoryLength';");
	if (count($result) == 0) {
		$db->query("INSERT INTO `" . table_config . "` VALUES (72, 'Submit', 'minStoryLength', '10', '10', 'number', 'Minimum Story Length', 'Set the minimum number of characters for the story description.', 'define', NULL);");
	}

	$result = $db->get_results("select * from `" . table_config . "` where `var_name` = 'tags_min_pts_s';");
	if (count($result) == 0) {
		$db->query("INSERT INTO `" . table_config . "` VALUES (73, 'Tags', 'tags_min_pts_s', '6', '6', 'number (should be at least 6)', 'Tag minimum points (sidebar)', '<b>Only used if Tags are enabled.</b> How small should the text for the smallest tags be(sidebar).', 'define', NULL);");
	}
	
	$result = $db->get_results("select * from `" . table_config . "` where `var_name` = 'tags_max_pts_s';");
	if (count($result) == 0) {
		$db->query("INSERT INTO `" . table_config . "` VALUES (74, 'Tags', 'tags_max_pts_s', '15', '15', 'number', 'Tag maximum points (sidebar)', '<b>Only used if Tags are enabled.</b> How big should the text for the largest tags be (sidebar).', 'define', NULL);");
	}
	
	$result = $db->get_results("select * from `" . table_config . "` where `var_name` = 'tags_words_limit_s';");
	if (count($result) == 0) {
		$db->query("INSERT INTO `" . table_config . "` VALUES (75, 'Tags', 'tags_words_limit_s', '5', '5', 'number', 'Tag cloud word limit (sidebar)', '<b>Only used if Tags are enabled.</b> The most tags to show in the cloud (sidebar).', 'define', NULL);");
	}

	$result = $db->get_results("select * from `" . table_config . "` where `var_name` = 'comments_length_sidebar';");
	if (count($result) == 0) {
		$db->query("INSERT INTO `" . table_config . "` VALUES (76, 'Comments', 'comments_length_sidebar', '75', '75', 'number', 'Comment length (sidebar)', 'The maximum number of characters shown for each comment (sidebar).', 'define', NULL);");
	}
	
	$result = $db->get_results("select * from `" . table_config . "` where `var_name` = 'comments_size_sidebar';");
	if (count($result) == 0) {
		$db->query("INSERT INTO `" . table_config . "` VALUES (77, 'Comments', 'comments_size_sidebar', '8', '8', 'number', 'Number of comments (sidebar)', 'How many comments are shown in the Latest Comments sidebar module', 'define', NULL);");
	}

	$result = $db->get_results("select * from `" . table_config . "` where `var_name` = 'ShowProfileLastViewers';");
	if (count($result) == 0) {
		$db->query("INSERT INTO `" . table_config . "` VALUES (78, 'PageViews', 'ShowProfileLastViewers', 'false', 'false', 'true / false', 'Show the last 5 people to view a profile.', 'Show the last 5 people to view a profile.', 'define', NULL);");
	}
	
	$result = $db->get_results("select * from `" . table_config . "` where `var_name` = 'Recommend_Time_Limit';");
	if (count($result) == 0) {
		$db->query("INSERT INTO `" . table_config . "` VALUES (79, 'Summary-Recommend', 'Recommend_Time_Limit', '30', '30', 'number', 'Email time limit.', 'Limit how many seconds in between a users recommend a friend emails.', 'define', NULL);");
	}

	// add in google site search
	$sql = "UPDATE `" . table_config . "` set `var_optiontext` = '1 - 4', `var_desc` = '<br><b>1</b> = uses MySQL MATCH for FULLTEXT indexes (or something). <b>Problems are MySQL STOP words and words less than 4 characters. Note: these limitations do not affect clicking on a TAG to search by it.</b>\r\n<br><b>2</b> = uses MySQL LIKE and is much slower, but returns better results. Also supports \"*\" and \"-\"\r\n<br><b>3</b> = is a hybrid, using method 1 if possible, but method 2 if needed.<br><b>4</b> = uses Google to search your site.' WHERE `var_id` = 43;";
	$db->query($sql);
	
	// uninstall the RSS importer so that the user has to re-install it to make sure
	// some SQL queries get run
	$sql = "DELETE FROM `" . table_modules . "` WHERE `name` = 'RSS Importer';";
	$db->query($sql);
	

$tableexists = checkfortable(table_saved_links);
if (!$tableexists) {
	$sql = "CREATE TABLE `" . table_saved_links . "` (
  `saved_id` int(11) NOT NULL auto_increment,
  `saved_user_id` int(11) NOT NULL,
  `saved_link_id` int(11) NOT NULL,
  PRIMARY KEY  (`saved_id`)
) TYPE = MyISAM;";
	$db->query($sql);
	}

$fieldexists = checkforfield('link_reports', table_links);
if (!$fieldexists) {
	$sql = "ALTER TABLE `" . table_links . "` ADD `link_reports` int(20) NOT NULL default '0'";
	$db->query($sql);
} else {
	// this is for caching link_reports in the links table instead of checking the 
	// votes table every link->read()
	// this is here for people who already upgraded to the SVN and may have
	// stories that have been reported. this field wasn't used right away so may
	// show 0 even though there have been reports (stored in the votes table)
	$sql = "update `" . table_links . "` set link_reports = -1 where link_reports = 0;";
	$db->query($sql);
}
$fieldexists = checkforfield('link_comments', table_links);
if (!$fieldexists) {
	$sql = "ALTER TABLE `" . table_links . "` ADD `link_comments` int(20) NOT NULL default '0'";
	$db->query($sql);
}

$fieldexists = checkforfield('link_blog', table_links); 	 
	 if ($fieldexists) { 	 
	         $sql = "ALTER TABLE `" . table_links . "` drop column `link_blog`"; 	 
	         $db->query($sql); 	 
}

$fieldexists = checkforfield('user_lang', table_users); 	 
	 if ($fieldexists) { 	 
	         $sql = "ALTER TABLE `" . table_users . "` drop column `user_lang`"; 	 
	         $db->query($sql); 	 
}

$fieldexists = checkforfield('comment_nick', table_comments); 	 
	 if ($fieldexists) { 	 
	         $sql = "ALTER TABLE `" . table_comments . "` drop column `comment_nick`"; 	 
	         $db->query($sql); 	 
}


// for the 'totals' table for summarizing
$tableexists = checkfortable(table_totals);
if (!$tableexists) {
	$sql = "CREATE TABLE `" . table_totals . "` (
  	`name` varchar(10) NOT NULL,
  	`total` int(11) NOT NULL,
  	PRIMARY KEY  (`name`)
		) TYPE = MyISAM;";
	$db->query($sql);

	$db->query("insert into `" . table_totals . "` (`name`, `total`) values ('published', 0);");	
	$db->query("insert into `" . table_totals . "` (`name`, `total`) values ('queued', 0);");	
	$db->query("insert into `" . table_totals . "` (`name`, `total`) values ('discard', 0);");	
}

//echo '<br />Regenerating the totals table...<br />';
totals_regenerate();


$tableexists = checkfortable(table_misc_data);
if (!$tableexists) {
	$sql = "CREATE TABLE `" . table_misc_data . "` (
		`name` VARCHAR( 20 ) NOT NULL ,
		`data` TEXT NOT NULL ,
		PRIMARY KEY ( `name` )
		) TYPE = MyISAM;";
	$db->query($sql);
	
	$sql = "INSERT INTO `" . table_misc_data . "` ( `name` , `data` ) VALUES ('pligg_version', '9.9.0');";
	$db->query($sql);
} else {
	$sql = "UPDATE `" . table_misc_data . "` SET `data` = '9.9.0' WHERE `name` = 'pligg_version';";
	$db->query($sql);
}


$fieldexists = checkforfield('rgt', table_categories);
if ($fieldexists) {
	$sql = "ALTER TABLE `" . table_categories . "` CHANGE `rgt` `rgt` int(11) NOT NULL default '0';";
	$db->query($sql);

	$sql = "ALTER TABLE `" . table_categories . "` CHANGE `lft` `lft` int(11) NOT NULL default '0';";
	$db->query($sql);
}

$sql = "ALTER TABLE `" . table_pageviews . "` CHANGE `pv_type` `pv_type` enum('story','out','profile');";
$db->query($sql);

$sql = "UPDATE `" . table_categories . "` SET `category__auto_id` = '0' WHERE `category_name` = 'all' LIMIT 1;";
$db->query($sql);

$fieldexists = checkforfield('last_reset_code', table_users);
if (!$fieldexists) {
	$sql = "ALTER TABLE `" . table_users . "` ADD `last_reset_code` varchar(255) default NULL;";
	$db->query($sql);
}

$fieldexists = checkforfield('last_email_friend', table_users);
if (!$fieldexists) {
	$sql = "ALTER TABLE `" . table_users . "` ADD `last_email_friend` timestamp NOT NULL;";
	$db->query($sql);
}

$sql = "ALTER TABLE `" . table_links . "` ADD FULLTEXT `link_search` (
`link_title` ,
`link_content` ,
`link_tags`
);";

$show_errors = $db->show_errors;
$db->show_errors = false;
$db->query($sql);
$db->show_errors = $show_errors;


$tableexists = checkfortable(table_formulas);
if (!$tableexists) {
	$sql = "CREATE TABLE `" . table_formulas . "` (
	  `id` int(11) NOT NULL auto_increment,
	  `type` varchar(10) NOT NULL,
	  `enabled` tinyint(1) NOT NULL,
	  `title` varchar(50) NOT NULL,
	  `formula` text NOT NULL,
	  PRIMARY KEY  (`id`)
	) TYPE = MyISAM;";
	$db->query($sql);

	$sql = 'INSERT INTO `' . table_formulas . '` VALUES (1, \'report\', 1, \'Simple Story Reporting\', \'$reports > $votes * 3\');';
	$db->query($sql);
}



// echo 'Clearing templates_c directory...<br />';

include_once('../Smarty.class.php');
$smarty = new Smarty;
$smarty->config_dir= '';
$smarty->compile_dir = "../templates_c";
$smarty->template_dir = "../templates";
$smarty->config_dir = "..";
$smarty->clear_compiled_tpl();


include(mnminclude.'admin_config.php');
$config = new pliggconfig;
$config->create_file("../settings.php");


echo '<br /><b>' . $lang['IfNoError'] . '</b>';


//end of if post submit is Yes.
}
//end of no errors
}
else { 
	echo DisplayErrors($errors);
	echo '<p>' . $lang['PleaseFix'] . '</p>';
}
$include='footer.php'; if (file_exists($include)) { include_once($include); }

?>
