<?
//db access info
$sql_host='db41.perfora.net';//host
$sql_user='dbo89724436';//db user
$sql_pass='l032693';//db pass
$sql_db='db89724436';//db name

//path and url
$base_path="/homepages/12/d88896517/isoft.ws/MySpace";//full path to script
$main_url="http://isoft.ws/MySpace";//url to the script
$cookie_url=".isoft.ws";//the domain name of your website without http://www
$tribes_folder="groups";//folder for groups to be created

//mail addresses
$admin_mail="admin@popscript.com";//admin e-mail
$system_mail="admin@popscript.com";//system messages e-mail

//admin access info
$admin_login="admin";//login
$admin_password="admin";//password
//(note: please, use password without any meaning to prevent hackers attack)
/* Constant Variables */
$lines=10;
$lines10=10;
$lines15=15;
$lines25=25;
$lines50=50;
$lcoun=1;
/********************************/

$site_name="MySpace Clone";
?>