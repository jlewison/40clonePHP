<?php

   class countiesData extends Data {

      var $table = COUNTIES_TABLE;

      var $config = array (
  'table' => COUNTIES_TABLE,
  'idField' => 'osdate_counties_id',
  'addedMsg' => 'Osdate Counties %s Added',
  'added_err' => 'Can\\\'t Add Osdate Counties',
  'editMsg' => 'Osdate Counties %s Updated',
  'editErr' => 'Can\\\'t Update Osdate Counties',
  'delErr' => 'Can\\\'t Delete Osdate Counties',
  'delMsg' => 'Osdate Counties %s Deleted',
  'blankErr' => 'Osdate Counties Empty',
  'fields' => 
  array (
    'id' => 
    array (
      'name' => 'id',
      'description' => 'Id',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 8,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'code' => 
    array (
      'name' => 'code',
      'description' => 'Code',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 10,
      'blank_ok' => 1,
      'duplicate_ok' => 1,
    ),
    'name' => 
    array (
      'name' => 'name',
      'description' => 'Name',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 100,
      'blank_ok' => 1,
      'duplicate_ok' => 1,
    ),
    'enabled' => 
    array (
      'name' => 'enabled',
      'description' => 'Enabled',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 1,
      'blank_ok' => 1,
      'duplicate_ok' => 1,
    ),
    'countrycode' => 
    array (
      'name' => 'countrycode',
      'description' => 'Countrycode',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 5,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'statecode' => 
    array (
      'name' => 'statecode',
      'description' => 'Statecode',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 10,
      'blank_ok' => 1,
      'duplicate_ok' => 1,
    ),
  ),
);   

      function countiesData() {
      
         $this->Data($this->config);
      }
   }

?>
