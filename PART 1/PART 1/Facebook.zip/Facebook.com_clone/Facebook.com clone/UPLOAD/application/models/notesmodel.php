<?php

/**
 * Notes model
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 11/13/2007
 */
class Notesmodel extends Model
{
		var $userId;
		function Notesmodel()
		{
				parent::Model();
				$this->load->model('userModel');
				$this->userId = $this->session->userdata('user_id');
		} //end method
		function getRecentlyTaggedFriends($limit = 5)
		{
				if (!is_integer($limit)) $limit = 5;
				$strSql = "SELECT u.username, nt.user_id, count(nt.notes_id) AS cntTags,date_format((SELECT s.date_created FROM notes_tags AS s WHERE s.user_id = nt.user_id ORDER BY s.date_created DESC LIMIT 0,1),'%M %D %Y') AS date_info FROM notes_tags AS nt INNER JOIN notes AS n ON n.notes_id = nt.notes_id AND n.is_deleted = '0' AND n.is_approved = 'Y' INNER JOIN users AS u ON u.user_id = nt.user_id AND nt.user_id IN (" . $friendsId . ") GROUP BY u.username,u.user_id ORDER BY date_info DESC LIMIT 0," . $limit;
				$resFriendsRs = $this->db->query($strSql);
				$friendsRows = array();
				if ($resFriendsRs->num_rows() > 0)
				{
						foreach ($resFriendsRs->result() as $row)
						{
								$friendsRows[] = array("name" => $row->username, "user_id" => $row->user_id, "count" => $row->cntTags, "date_info" => $row->date_info);
						}
				}
		}
		function listNotes($notesId)
		{
				$strSql = "SELECT u.username, nt.date_created, nt.notes_id,nt.title,nt.user_id,nt.title,nt.message,nt.user_id FROM notes as nt INNER JOIN users AS u ON u.user_id = nt.user_id WHERE nt.notes_id = '" . trim($notesId) . "' AND nt.is_deleted = '0' and nt.is_approved = 'Y' ";
				$resQuery = $this->db->query($strSql);
				$resRow = "";
				if ($resQuery->num_rows() > 0)
				{
						$rowRes = $resQuery->result_array();
						$imagePath = $this->userModel->getAvatar($rowRes[0]['user_id'], true);
						$title = $rowRes[0]['title'];
						$body = $rowRes[0]['message'];
						$shareMsg = substr($rowRes[0]['title'], 0, 20) . "  By " . $rowRes[0]['username'] . " " . substr($body, 0, 40);
						$sqlTags = " SELECT nt.tag_id,nt.notes_id,nt.user_id,u.username FROM notes_tags as nt INNER JOIN users as u ON u.user_id = nt.user_id WHERE nt.notes_id = '" . trim($rowRes[0]['notes_id']) . "'";
						$resTags = $this->db->query($sqlTags);
						$tagArr = array();
						$tags = '';
						if ($resTags)
						{
								if ($resTags->num_rows() > 0)
								{
										foreach ($resTags->result_array() as $rowTags)
										{
												//$tags	.= 'user_id=>'.$rowTags['user_id'].',';
												$tagArr[] = $rowTags['user_id'];
										}
								}
						}
						$strCommentsCount = "";
						$sqlComments = "SELECT comment_id FROM notes_comments WHERE notes_id = '" . trim($rowRes[0]['notes_id']) . "'";
						$resComments = $this->db->query($sqlComments);
						if ($resComments->num_rows() > 0)
						{
								$countCmt = $resComments->num_rows();
								$strCommentsCount = ($countCmt == 0) ? "" : ("   $countCmt comment(s) ");
						}
						$resultArr[$notesId] = array("notes_id" => $notesId, "username" => $rowRes[0]['username'], "userId" => $rowRes[0]['user_id'], "avatar" => $imagePath, "dateInfo" => $rowRes[0]['date_created'], "message" => $body, "title" => $title, "notesLink" => base_url() . '/notes/userNotes/' . $rowRes[0]['user_id'] . '/' . $notesId . '/', "taggedUsers" => $tagArr, "commentsCount" => $strCommentsCount, "share_content" => $shareMsg);
						return $resultArr[$notesId];
				}
		}
		function commentList($notesId)
		{
				$this->load->model('userModel');
				$strSql = "SELECT nc.comment_id,nc.user_id, nc.notes_id, nc.message, nc.date_created as comment_date, u.username,IFNULL(pp.thumb_path,'') as thumb_path
							FROM notes_comments AS nc
							INNER JOIN users AS u ON u.user_id = nc.user_id
							LEFT JOIN picture_profile as pp ON pp.user_id = u.user_id
							WHERE nc.notes_id = '" . trim($notesId) . "' ";
				$strSql = "SELECT nc.comment_id,nc.user_id, nc.notes_id, nc.message, nc.date_created as comment_date, u.username
							FROM notes_comments AS nc
							INNER JOIN users AS u ON u.user_id = nc.user_id
							WHERE nc.notes_id = '" . trim($notesId) . "' ";
				$resComments = $this->db->query($strSql);
				$commentCount = $resComments->num_rows();
				$arrCommentList = array();
				if ($commentCount > 0)
				{
						foreach ($resComments->result_array() as $rowComments)
						{
								$arrCommentList[$rowComments['comment_id']] = array("comment_id" => $rowComments['comment_id'], "notes_id" => $rowComments['notes_id'], "comment_msg" => $rowComments['message'], "comment_date" => $rowComments['comment_date'], "commented_user" => $rowComments['user_id'], "commented_by" => $rowComments['username'], "thumb_path" => $this->userModel->getAvatar($rowComments['user_id'], true));
						}
				}
				return $arrCommentList;
		}
		function taggedList($notesId)
		{
				$this->load->model('userModel');
				$strSql = "SELECT nc.tag_id,nc.user_id, nc.notes_id , nc.date_created as tagged_date, u.username,IFNULL(pp.thumb_path,'') as thumb_path
							FROM notes_tags AS nc
							INNER JOIN users AS u ON u.user_id = nc.user_id
							LEFT JOIN picture_profile as pp ON pp.user_id = u.user_id
							WHERE nc.notes_id = '" . trim($notesId) . "' ";
				$strSql = "SELECT nc.tag_id,nc.user_id, nc.notes_id , nc.date_created as tagged_date, u.username
							FROM notes_tags AS nc
							INNER JOIN users AS u ON u.user_id = nc.user_id
							WHERE nc.notes_id = '" . trim($notesId) . "' ";
				$resTags = $this->db->query($strSql);
				$tagCount = $resTags->num_rows();
				$arrTaggedList = array();
				if ($tagCount > 0)
				{
						foreach ($resTags->result_array() as $rowTags)
						{
								$arrTaggedList[$rowTags['tag_id']] = array("tag_id" => $rowTags['tag_id'], "notes_id" => $rowTags['notes_id'], "tagged_date" => $rowTags['tagged_date'], "tagged_user" => $rowTags['user_id'], "tagged_user_name" => $rowTags['username'], "thumb_path" => $this->userModel->getAvatar($rowTags['user_id'], true));
						}
				}
				return $arrTaggedList;
		}
		function _dispNotes($notesId)
		{
				$this->load->model('userModel');
				$strSql = " SELECT 	n.notes_id, n.title, n.message, n.user_id,u.username as notes_by, n.date_created as notes_on,IFNULL(pp.thumb_path,'') as thumb_path
							FROM 		notes as n
							INNER JOIN 	users AS u ON u.user_id = n.user_id
							LEFT JOIN 	picture_profile AS pp ON pp.user_id = u.user_id
							WHERE 		n.is_deleted = '0' AND n.is_approved = 'Y' AND n.notes_id = '" . $notesId . "'";
				$strSql = " SELECT 	n.notes_id, n.title, n.message, n.user_id,u.username as notes_by, n.date_created as notes_on
							FROM 		notes as n
							INNER JOIN 	users AS u ON u.user_id = n.user_id
							WHERE 		n.is_deleted = '0' AND n.is_approved = 'Y' AND n.notes_id = '" . $notesId . "'";
				$resNotes = $this->db->query($strSql);
				$tagArr = array();
				if ($resNotes->num_rows() > 0)
				{
						foreach ($resNotes->result_array() as $resRow)
						{
								$userId = $resRow['user_id'];
								$userName = $resRow['notes_by'];
								$notesOn = $resRow['notes_on'];
								$title = $resRow['title'];
								$message = $resRow['message'];
								$thumbPath = $this->userModel->getAvatar($resRow['user_id'], true);
								$userName = $resRow['notes_by'];
						}
				}
				$arrCommentList = $this->commentList($notesId);
				$tagArr = $this->taggedList($notesId);
				//$photos				= 	$this->getPhotos($notesId);
				$photos = $this->notesPhotos($notesId);
				$shareMsg = substr($title, 0, 20) . "<br>By " . $userName . "<br>" . substr($message, 0, 40);
				$rowRes[$notesId] = array("user_id" => $userId, "notes_by" => $userName, "notes_on" => $notesOn, "title" => $title, "thumb_path" => $thumbPath, "notes_id" => $notesId, "sharelink" => '', "message" => $message, "commentCount" => count($arrCommentList), "tagList" => $tagArr, "commentList" => $arrCommentList, "photos" => $photos, "share_content" => $shareMsg);
				return $rowRes[$notesId];
		}
		function checkExist($notesId)
		{
				$strSql = "SELECT notes_id,title,message,date_created FROM notes WHERE is_deleted = '0' AND is_approved = 'Y' AND notes_id ='" . trim($notesId) . "' AND user_id = '" . $this->session->userdata('user_id') . "'";
				$arrNotes = array();
				$resNotes = $this->db->query($strSql);
				if ($resNotes->num_rows() > 0)
				{
						$arrNotes = $resNotes->result_array();
				}
				return $arrNotes;
		}
		function notesPhotoAlign()
		{
				$strSql = "SELECT detail_id, description FROM global_detail WHERE header_id = 'ALIGNMENT_NT' AND is_deleted = 'N' AND is_approved = 'Y'";
				$res = $this->db->query($strSql);
				$rowAlign = array();
				if ($res->num_rows() > 0)
				{
						foreach ($res->result_array() as $row)
						{
								$rowAlign[$row['detail_id']] = array("detail_id" => $row['detail_id'], "description" => $row['description']);
						}
				}
				return $rowAlign;
		}
		function updateNotes($editNotesValues)
		{
				$status = 'pending';
				$editNotesSQL = 'UPDATE notes SET title = ' . $this->db->escape($editNotesValues['txtTitle']) . ',message =' . $this->db->escape($editNotesValues['txtBody']) . ', date_modified=CURRENT_TIMESTAMP WHERE notes_id = ' . $editNotesValues['hdnId'];
				$this->db->query($editNotesSQL);
				if ($this->db->affected_rows() == 1)
				{
						return $editNotesValues['hdnId'];
				}
				else  return 0;
		}
		function addNewNotes($newNotesValues)
		{
				$status = 'pending';
				$newNotesSQL = 'INSERT INTO notes
							(title, message,user_id,date_created)
							VALUES
							(	' . $this->db->escape($newNotesValues['txtTitle']) . ',
								' . $this->db->escape($newNotesValues['txtBody']) . ',
								' . $this->session->userdata('user_id') . ',CURRENT_TIMESTAMP)';
				$this->db->query($newNotesSQL);
				if ($this->db->affected_rows() == 1)
				{
						$notesId = $this->db->insert_id();
						return $notesId;
				}
				else  return 0;
		}
		function addComment($notesId, $cmtText)
		{
				$commentAddSQL = 'INSERT INTO notes_comments(notes_id, user_id, message) VALUES(' . $this->db->escape($notesId) . ',' . $this->db->escape($this->session->userdata('user_id')) . ',' . $this->db->escape($cmtText) . ')';
				$this->db->query($commentAddSQL);
		}
		function removeComment($commentId)
		{
				$removeCmtSQL = 'DELETE FROM notes_comments WHERE comment_id = ' . $this->db->escape($commentId) . ' AND user_id =' . $this->db->escape($this->session->userdata('user_id'));
				$this->db->query($removeCmtSQL);
		}
		function deleteNotes($notesId)
		{
				$strSql = "UPDATE notes SET is_deleted = '1', date_modified = CURRENT_TIMESTAMP WHERE notes_id = " . $this->db->escape($notesId);
				$this->db->query($strSql);
				$postType = 'note';
				$postId = $notesId;
				$this->deletePostByType($postType, $postId);
		}
		function deletePostByType($postFor, $postForId)
		{
				//echo 'DELETE FROM posted_items WHERE post_type=\''.$postFor.'\' AND post_for_id='.$postForId;
				$sql = 'DELETE FROM posted_items WHERE post_type=\'' . $postFor . '\' AND post_for_id=' . $postForId;
				$this->db->query($sql);
				if ($this->db->affected_rows() > 0) return true;
				else  return false;
		} //end deletePostByType()
		function delPhotos($notesId, $photoId)
		{
				$strSql = "DELETE FROM notes_photos WHERE notes_id = " . $this->db->escape($notesId) . " AND photo_id =" . $this->db->escape($photoId);
				$this->db->query($strSql);
		}
		function AddPhotos($notesId, $fileAlign, $extension)
		{
				$newPhotosSQL = 'INSERT INTO notes_photos(notes_id,file_align,file_name) VALUES (
									' . $this->db->escape($notesId) . ',' . $this->db->escape($fileAlign) . ',' . $this->db->escape($extension) . ')';
				$this->db->query($newPhotosSQL);
				if ($this->db->affected_rows() == 1) return $this->db->insert_id();
				else  return 0;
		} // End of storePhotos
		function getPhotos($notesId, $photoId = '')
		{
				$arrPhotos = array();
				$condSql = '';
				if (trim($photoId) != '' and is_integer($photoId))
				{
						$condSql = " AND photo_id = " . $this->db->escape($photoId);
				}
				$strSql = "SELECT notes_id, photo_id,file_name,file_align FROM notes_photos WHERE notes_id = " . $this->db->escape($notesId) . $condSql;
				$resPhotos = $this->db->query($strSql);
				if ($resPhotos->num_rows() > 0)
				{
						foreach ($resPhotos->result_array() as $resRow)
						{
								$arrPhotos[$resRow['photo_id']] = $resRow;
						}
				}
				return $arrPhotos;
		}
		function notesPhotos($notesId, $photoId = '')
		{
				$arrPhotos = array();
				$condSql = '';
				if (trim($photoId) != '' and is_integer($photoId))
				{
						$condSql = " AND photo_id = " . $this->db->escape($photoId);
				}
				$strSql = "SELECT notes_id, photo_id,file_name,file_align FROM notes_photos WHERE notes_id = " . $this->db->escape($notesId) . $condSql;
				$resPhotos = $this->db->query($strSql);
				if ($resPhotos->num_rows() > 0)
				{
						foreach ($resPhotos->result_array() as $resRow)
						{
								$arrPhotos[] = $resRow;
						}
				}
				return $arrPhotos;
		}
		function updatePhotoAlign($notesId, $photoId, $photoAlign)
		{
				$strSql = "UPDATE notes_photos SET file_align = " . $this->db->escape($photoAlign) . " WHERE notes_id =" . $this->db->escape($notesId) . " AND photo_id =" . $this->db->escape($photoId);
				$this->db->query($strSql);
		}
		function getFriendsAddress($suggest = '', $hdnIds)
		{
				$condSql = '';
				if (trim($hdnIds) != '')
				{
						$condSql = ' AND u.user_id NOT IN(' . $hdnIds . ')';
				}
				$addressSql = 'SELECT results.FriendId as user_id , u.username 
							FROM(
								SELECT friend_id AS FriendId FROM friends_list WHERE user_id=' . $this->userId . ' AND approved_status="yes"
								UNION
								SELECT user_id as FriendId FROM friends_list WHERE friend_id=' . $this->userId . ' AND approved_status="yes"
							) AS results 
							INNER JOIN users AS u ON u.user_id = results.FriendId AND u.username like "' . $suggest . '%"' . $condSql;
				$addressQuery = $this->db->query($addressSql);
				$address = array();
				if ($addressQuery->num_rows() > 0)
				{
						foreach ($addressQuery->result_array() as $addressRow)
						{
								$address[$addressRow['user_id']] = $addressRow;
						}
				}
				return $address;
		}
		function saveTags($notesId, $taggedUsersArray)
		{
				$this->removeTags($notesId);
				$msg = '';
				if (count($taggedUsersArray) > 0)
				{
						foreach ($taggedUsersArray as $key => $val)
						{
								$sqlInsert = 'INSERT INTO notes_tags(notes_id,user_id) VALUES (' . $this->db->escape($notesId) . ',' . $this->db->escape($val) . ')';
								$this->db->query($sqlInsert);
						}
				}
				return $msg;
		}
		function removeTags($notesId, $taggedUser = '')
		{
				$condSQL = '';
				if (trim($taggedUser) != '') $condSQL = ' AND user_id =' . $this->db->escape($taggedUser);
				$delSQL = 'DELETE FROM notes_tags WHERE notes_id = ' . $this->db->escape($notesId) . $condSQL;
				$this->db->query($delSQL);
		}
		function removeTag($tagId)
		{
				$delSQL = 'DELETE FROM notes_tags WHERE tag_id = ' . $this->db->escape($tagId) . ' AND user_id = ' . $this->db->escape($this->userId);
				$this->db->query($delSQL);
				if ($this->db->affected_rows() == 1) return 1;
				else  return 0;
		}
		function getTagInfo($notesId)
		{
				$strSQL = 'SELECT nt.notes_id, nt.user_id AS tagged_user,u.username AS tagged_user_name,nt.date_created FROM notes_tags AS nt 
						INNER JOIN users AS u ON nt.user_id = u.user_id WHERE nt.notes_id = ' . $this->db->escape($notesId) . '  ORDER BY nt.date_created DESC ';
				$resSQL = $this->db->query($strSQL);
				$resArray = array();
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[] = $resRow;
						}
				}
				return $resArray;
		}
		function getTags($notesId)
		{
				$strSQL = 'SELECT tag_id, user_id, notes_id FROM notes_tags WHERE notes_id =' . $this->db->escape($notesId);
				$resSQL = $this->db->query($strSQL);
				$resArray = array();
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[] = $resRow;
						}
				}
				return $resArray;
		}
}

?>