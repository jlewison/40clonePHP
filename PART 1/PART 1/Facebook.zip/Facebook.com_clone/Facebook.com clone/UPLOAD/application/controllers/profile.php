<?php

/**
 * profile Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 1/21/2008
 */
class profile extends Controller
{
		var $settingsResultCache;
		//Constructor
		function profile()
		{
				parent::Controller();
				//check login
				loginRequired();
				//Load the language file
				$this->lang->load('search', $this->config->item('language_code'));
				$this->lang->load('posted', $this->config->item('language_code'));
				$this->lang->load('wall', $this->config->item('language_code'));
				$this->lang->load('profile', $this->config->item('language_code'));
		}
		//Default function
		function index()
		{
				if ($this->uri->segment(2)) $user_id = $this->uri->segment(2);
				else  $user_id = $this->session->userdata('user_id');
				$outputData['current_user_id'] = $this->uri->segment(2);
				if ($this->_checkIsCurrentUser($user_id) == false)
				{
						//Load the user model
						$this->load->model('usermodel');
						//Load the friends model
						$this->load->model('friendsmodel');
						if ($this->usermodel->isUserBlocked($this->session->userdata('user_id'), $user_id) == false)
						{
								if ($this->_canViewProfile($user_id) == false)
								{
										//Set the flash data
										$this->session->set_flashdata('flash_msg', $this->lang->line('profile_restricted'));
										redirect('welcome');
								}
						}
						else
						{
								//Set the flash data
								$this->session->set_flashdata('flash_msg', $this->lang->line('profile_blocked'));
								redirect('welcome');
						}
				}
				//Load  the needed models
				$this->load->model('wallmodel');
				$this->load->model('minifeedmodel');
				$this->load->model('groupsmodel');
				$this->load->model('postedmodel');
				$this->load->model('marketplacemodel');
				$outputData['profileSectionViewSettings'] = $this->_getProfileSectionViewSettings($user_id);
				//basic profile
				$outputData['basic_profile'] = $this->usermodel->getBasicProfile($user_id);
				$outputData['releviousview'] = '';
				if ($outputData['basic_profile']) $outputData['releviousview'] = $this->usermodel->getReligiousViews($outputData['basic_profile'][0]['religious_view']);
				//contact profile
				$outputData['contact_profile'] = $this->usermodel->getProfileContact($user_id);
				//personal profile
				$outputData['personal_profile'] = $this->usermodel->getPersonalProfile($user_id);
				//user details
				$userDetails = $this->usermodel->getUserDetails($user_id);
				$userDetails[$user_id]['avatar_med'] = getAvatar($user_id, $userDetails[$user_id]['avatar_ext'], 'medium');
				$userDetails[$user_id]['avatar_profile'] = getAvatar($user_id, $userDetails[$user_id]['avatar_ext'], 'profile');
				$outputData['userDetails'] = $userDetails[$user_id];
				//screen status
				$outputData['screenStatus'] = $this->usermodel->getScreenStatus();
				$outputData['screenMessengers'] = $this->usermodel->getScreenMessengers($user_id);
				$outputData['screen_messengers'] = array();
				if ($outputData['screenMessengers'] != false) $outputData['screen_messengers'] = $outputData['screenMessengers'];
				//works
				$outputData['work_profile'] = $this->usermodel->getWorkProfile($work_id = '', $user_id);
				if (!empty($outputData['work_profile'])) $outputData['works'] = $outputData['work_profile'];
				else  $outputData['works'] = false;
				$outputData['months'] = array('01' => $this->lang->line('profile_jan'), '02' => $this->lang->line('profile_feb'), '03' => $this->lang->line('profile_mar'), '04' => $this->lang->line('profile_apr'), '05' => $this->lang->line('profile_may'), '06' => $this->lang->line('profile_jun'), '07' => $this->lang->line('profile_jul'), '08' => $this->lang->line('profile_aug'), '09' => $this->lang->line('profile_sep'), '10' => $this->lang->line('profile_oct'), '11' => $this->lang->line('profile_nov'), '12' => $this->lang->line('profile_dec'));
				//Education
				$outputData['education_profile'] = $this->usermodel->getEducationProfile($user_id);
				if (!empty($outputData['education_profile'])) $outputData['educations'] = $outputData['education_profile'];
				else  $outputData['educations'] = false;
				$outputData['schoolProfile'] = $this->usermodel->getHighSchool();
				//user networks
				$userNetworks = $this->usermodel->getUserNetworks($user_id, 'region', 'date_joined desc', 0, 1);
				$outputData['userNetworks'] = current($userNetworks);
				//friends
				$outputData['friends'] = $this->friendsmodel->getFriends($user_id);
				$outputData['friendsCount'] = count($outputData['friends']);
				$outputData['friendsTotal'] = $this->friendsmodel->getFriendsCount($user_id);
				if ($outputData['friendsCount'] > 0) $outputData['friendsDetails'] = $this->usermodel->getDetails(implode(",", $outputData['friends']));
				//For wall
				$outputData['wall'] = $this->wallmodel->getWall('profile', $user_id, 'wall_date desc', 0, 5);
				$outputData['wallCount'] = count($outputData['wall']);
				$outputData['wallTotal'] = $this->wallmodel->getWallCount('profile', $user_id);
				//minifeed
				$outputData['miniFeed'] = $this->minifeedmodel->getMiniFeed($user_id, 'datestamp desc', 0, 5);
				$outputData['miniFeedCount'] = count($outputData['miniFeed']);
				$outputData['miniFeedTotal'] = $this->minifeedmodel->getMiniFeedCount($user_id);
				//posted items
				$outputData['postedItem'] = $this->postedmodel->getPosts('', '', $user_id, 'post_date', 0, 5);
				$outputData['postCount'] = count($outputData['postedItem']);
				$outputData['postTotal'] = $this->postedmodel->getPostCount('', '', $user_id);
				//Groups
				//$user, $search = '',$ownerFlag = '', $start='',$limit=''
				$search = '';
				$ownerFlag = 'Y';
				$start = 0;
				$limit = 10;
				$usergroups = $this->groupsmodel->getUserGroups($user_id, $search, $start, $limit);
				$outputData['resultcount'] = count($usergroups);
				$outputData['resultgroups'] = $usergroups;
				$outputData['profileuser'] = $user_id;
				$search = '';
				$ownerFlag = 'Y';
				$start = 0;
				$limit = 10;
				$usermarket = $this->marketplacemodel->getProfileListings($user_id, $start, $limit);
				foreach ($usermarket as $key => $detailArr)
				{
						$usermarket[$key]['avatar'] = $this->marketplacemodel->getMarketplaceImage($detailArr['list_id'], $detailArr['list_type'], true);
				}
				$outputData['marketcount'] = count($usermarket);
				$outputData['resultmarket'] = $usermarket;
				$outputData['profileuser'] = $user_id;
				$this->smartyextended->view('profile', $outputData);
		}
		function saveScreenStatus()
		{
				//Load  the needed models
				$this->load->model('usermodel');
				$this->usermodel->setScreenStatus('', $this->input->post('screen_status_id'));
				$screenStatus = $this->usermodel->getScreenStatus();
				$userFeedSettings = $this->usermodel->getUserFeedSetting();
				if (isset($userFeedSettings[13]) && $userFeedSettings[13] == 'yes')
				{
						//Load the minifeed model
						$this->load->model('minifeedmodel');
						$splVars = array('~~postedBy~~' => substr($this->usermodel->getName(), 0, 30), '~~userStatus~~' => $screenStatus[$this->input->post('screen_status_id')]);
						$this->minifeedmodel->postMiniFeed('USER_STATUS', $splVars, array());
				}
				echo json_encode(array('msg' => 'DONE', 'status' => ($this->input->post('screen_status_id') == 0) ? '' : $screenStatus[$this->input->post('screen_status_id')]));
		}
		function _checkIsCurrentUser($user_id)
		{
				//Someone viewing some other's profile
				if ($user_id != $this->session->userdata('user_id')) return false;
				else //one viewing his own profile
 								return true;
		}
		function _checkAllMyNetworksAndFriends($user_id)
		{
				$viewingUserNetworks = $this->usermodel->getUserNetworks($user_id);
				$currUserNetworks = $this->usermodel->getUserNetworks();
				$commonNetworks = '';
				if (is_array($viewingUserNetworks) && count($viewingUserNetworks) > 0 && is_array($currUserNetworks) && count($currUserNetworks) > 0) $commonNetworks = array_intersect_key($viewingUserNetworks, $currUserNetworks);
				if (is_array($commonNetworks) && count($commonNetworks) > 0) return true;
				$isFriend = $this->friendsmodel->isFriend($user_id);
				if ($isFriend) return true;
				return false;
		}
		function _checkSomeNetworksAndFriends($user_id)
		{
				$viewingUserNetworks = $this->usermodel->getUserPrivacySettingNetwork($user_id);
				$currUserNetworks = $this->usermodel->getUserNetworks();
				$commonNetworks = '';
				if (is_array($viewingUserNetworks) && count($viewingUserNetworks) > 0 && is_array($currUserNetworks) && count($currUserNetworks) > 0) $commonNetworks = array_intersect_key(current($viewingUserNetworks), $currUserNetworks);
				if (is_array($commonNetworks) && count($commonNetworks) > 0) return true;
				$isFriend = $this->friendsmodel->isFriend($user_id);
				if ($isFriend) return true;
				return false;
		}
		function _checkIsFriend($user_id)
		{
				$isFriend = $this->friendsmodel->isFriend($user_id);
				if ($isFriend) return true;
				return false;
		}
		function _canViewProfile($user_id)
		{
				$userPrivacySetting = $this->usermodel->getUserPrivacySetting($user_id);
				//Check whether the user had made any privacy setting
				if (count($userPrivacySetting) > 0 && isset($userPrivacySetting[1]))
				{
						if ($userPrivacySetting[1] == 1) //All my networks and all my friends
 										return $this->_checkAllMyNetworksAndFriends($user_id);
						elseif ($userPrivacySetting[1] == 2) //Some of my networks and all my friends
 										return $this->_checkSomeNetworksAndFriends($user_id);
						elseif ($userPrivacySetting[1] == 3) //Only my friends
 										return $this->_checkIsFriend($user_id);
				}
				else  return true;
		}
		function _getProfileSectionViewSettings($user_id)
		{
				$sectionViewSettings = array();
				$userPrivacySetting = $this->usermodel->getUserPrivacySetting($user_id);
				//Check whether the user had made any privacy setting
				if (count($userPrivacySetting) > 0)
				{
						foreach ($userPrivacySetting as $userPrivacySettingId => $userPrivacySettingValue)
						{
								if ($userPrivacySettingValue == 1) //All my networks and all my friends

								{
										if (!isset($this->settingsResultCache[1])) $this->settingsResultCache[1] = ($this->_checkIsCurrentUser($user_id)) ? 1 : (($this->_checkAllMyNetworksAndFriends($user_id)) ? 1 : 0);
										$sectionViewSettings[$userPrivacySettingId] = $this->settingsResultCache[1];
								} elseif ($userPrivacySettingValue == 2) //Some of my networks and all my friends

								{
										if (!isset($this->settingsResultCache[2])) $this->settingsResultCache[2] = ($this->_checkIsCurrentUser($user_id)) ? 1 : (($this->_checkSomeNetworksAndFriends($user_id)) ? 1 : 0);
										$sectionViewSettings[$userPrivacySettingId] = $this->settingsResultCache[2];
								} elseif ($userPrivacySettingValue == 3) //Only my friends

								{
										if (!isset($this->settingsResultCache[3])) $this->settingsResultCache[3] = ($this->_checkIsCurrentUser($user_id)) ? 1 : (($this->_checkIsFriend($user_id)) ? 1 : 0);
										$sectionViewSettings[$userPrivacySettingId] = $this->settingsResultCache[3];
								} elseif ($userPrivacySettingValue == 4) //Only Me

								{
										if (!isset($this->settingsResultCache[4])) $this->settingsResultCache[4] = ($this->_checkIsCurrentUser($user_id)) ? 1 : 0;
										$sectionViewSettings[$userPrivacySettingId] = $this->settingsResultCache[4];
								} elseif ($userPrivacySettingValue == 5) //No One
 										$sectionViewSettings[$userPrivacySettingId] = 0;
						}
				}
				else  $sectionViewSettings['viewAll'] = true;
				return $sectionViewSettings;
		}
}

?>