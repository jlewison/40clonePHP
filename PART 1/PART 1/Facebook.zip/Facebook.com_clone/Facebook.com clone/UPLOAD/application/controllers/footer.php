<?php

/**
 * Footer Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 09-02-2008
 */
class footer extends Controller
{
		//Constructor
		function footer()
		{
				parent::Controller();
		}
		//Default function
		function index()
		{
				$this->load->model('footermodel');
				$pageName = $this->uri->segment(2);
				if ($this->footermodel->isTemplateExist(trim($pageName)))
				{
						$outputData['page_name'] = 'footer/' . $pageName . '.tpl';
						$this->smartyextended->view('dynamicfooter', $outputData);
				}
				else  redirect('home');
		}
}

?>