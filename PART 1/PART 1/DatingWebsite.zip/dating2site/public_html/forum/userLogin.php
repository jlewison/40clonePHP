<?php
include_once(DOC_ROOT.'init.php');
include_once(  FORUM_DIR . 'forum_inc.php' );

if ( $config['forum_installed'] == '' ) {

    include_once('None_forum.php');
} else {

    include_once($config['forum_installed'] . '_forum.php');
}

forum_userLogin();

?>

