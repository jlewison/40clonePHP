<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Application Hook
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 1/2/2008
 */
class Application
{
		var $CI;
		var $userApplications;
		var $currentPage;
		//Constructor
		function Application()
		{
				$this->CI = &get_instance();
		}
		//Init the application
		function initApplication()
		{
				//Store the page that the user actually access
				$this->currentPage = strtolower($this->CI->uri->segment(1));
				$settings = $this->CI->settingsmodel->readAllSetting();
				$this->userApplications = $this->CI->applicationmodel->getUserApplications();
				$isApplication = $this->CI->applicationmodel->isApplication($this->currentPage);
				$canAccess = true;
				if ($isApplication && $this->CI->applicationmodel->isUserCanAccessTheApplication($isApplication) == false && $this->session->userdata('logged_in') == 1 && $this->session->userdata('user_id') != '') $canAccess = false;
				if ($canAccess)
				{
						$this->CI->smartyextended->assign('settings', $settings);
						$this->CI->smartyextended->assign('sitename', $settings['site_name']);
						$this->CI->smartyextended->assign('sitetitle', $settings['site_title']);
						$this->CI->smartyextended->assign('userApplications', $this->userApplications);
						$this->CI->smartyextended->assign('base_url', base_url());
						$this->CI->smartyextended->assign('app_url', base_url() . 'application/');
						$this->CI->smartyextended->assign('user_id', $this->CI->session->userdata('user_id'));
						$this->CI->smartyextended->assign('language', $this->CI->config->item('language_code'));
						$this->CI->smartyextended->assign('curr_page', $this->currentPage);
						$this->CI->smartyextended->assign('avatar_thumb_width', $this->CI->config->item('avatar_thumb_width'));
						$this->CI->smartyextended->assign('avatar_thumb_height', $this->CI->config->item('avatar_thumb_height'));
				}
				else
				{
						redirect('home');
				}
		}
}
?>