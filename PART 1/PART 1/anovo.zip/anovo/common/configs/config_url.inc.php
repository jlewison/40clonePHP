<?php
$CFG['admin']['mail_urls']['compose']['normal'] = 'mailCompose.php';
$CFG['admin']['mail_urls']['compose']['htaccess'] = 'mails/compose/';
$CFG['admin']['mail_urls']['inbox']['normal'] = 'mail.php?folder=inbox';
$CFG['admin']['mail_urls']['inbox']['htaccess'] = 'mails/inbox/';
$CFG['admin']['mail_urls']['sent']['normal'] = 'mail.php?folder=sent';
$CFG['admin']['mail_urls']['sent']['htaccess'] = 'mails/sent/';
$CFG['admin']['mail_urls']['read_inbox']['normal'] = 'mailRead.php?folder=inbox';
$CFG['admin']['mail_urls']['read_inbox']['htaccess'] = 'readmail/inbox/';
$CFG['admin']['mail_urls']['read_sent']['normal'] = 'mailRead.php?folder=sent';
$CFG['admin']['mail_urls']['read_sent']['htaccess'] = 'readmail/sent/';


?>