<?php
/**
 * videos Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 2007-01-17
 */
class videos extends Controller
{
		//Constructor
		var $userId;
		function videos()
		{
				parent::Controller();
				loginRequired();
				//Load the language file
				$this->lang->load('wall', $this->config->item('language_code'));
				$this->lang->load('posted', $this->config->item('language_code'));
				$this->lang->load('videos', $this->config->item('language_code'));
				$this->load->model('videomodel');
				$this->userId = $this->session->userdata('user_id');
		}
		#***************************************************************************
		#Method			: index()---default method
		#Description	: show all friends for the current user
		#***************************************************************************
		function index()
		{
				$outputData['video_list'] = $this->videomodel->getVideoByUser();
				$outputData['video_count'] = count($outputData['video_list']);
				$this->smartyextended->view('videos', $outputData);
		} //end index()
		#***************************************************************************
		#Method			: myvideos()
		#Description	: show current users videos
		#***************************************************************************
		function myvideos()
		{
				$outputData['video_list'] = $this->videomodel->getVideoByUser($this->session->userdata('user_id'));
				$outputData['video_count'] = count($outputData['video_list']);
				if ($this->session->userdata('success_msg') != '')
				{
						$outputData['success_msg'] = $this->session->userdata('success_msg');
						$this->session->set_userdata(array("success_msg" => ''));
				} elseif ($this->session->userdata('error_msg') != '')
				{
						$outputData['error_msg'] = $this->session->userdata('error_msg');
						$this->session->set_userdata(array("error_msg" => ''));
				}
				$this->smartyextended->view('videosmyvideos', $outputData);
		} //end myvideos()
		#***************************************************************************
		#Method			: friendsvideos()
		#Description	: show current users friends videos
		#***************************************************************************
		function friendsvideos()
		{
				$this->load->model('friendsmodel');
				$friendsList = $this->friendsmodel->getFriends($this->session->userdata('user_id'));
				if (!empty($friendsList))
				{
						$outputData['video_list'] = $this->videomodel->getVideoByUser($friendsList, true);
						$outputData['video_count'] = count($outputData['video_list']);
				}
				$outputData['friends_count'] = count($friendsList);
				$this->smartyextended->view('videosfriends', $outputData);
		} //end friendsvideos()
		#***************************************************************************
		#Method			: upload()
		#Description	: to upload video files
		#***************************************************************************
		function upload()
		{
				//reads common site settings
				$this->load->model('settingsModel');
				$settings = $this->settingsmodel->readSetting('mencoder_path');
				$mencoder = $settings['mencoder_path'];
				$outputData = array();
				$userId = $this->userId;
				$success = '';
				$error = '';
				if ($this->input->post('upload_video'))
				{
						if (!$this->input->post('agree')) $error = $this->lang->line('video_label_terms');
						else
						{
								$this->config->load('video'); //Load the config file related to photo
								$appDir = APPPATH . 'content/videos/user_' . $userId . '/'; //upload path
								if (!file_exists($appDir)) //Check whether the upload path exist. if not creat it.

								{
										mkdir($appDir);
										mkdir($appDir . 'temp/');
								}
								$config['upload_path'] = $appDir; //upload image settings
								$config['allowed_types'] = $this->config->item('video_allowed_types');
								$config['max_size'] = $this->config->item('video_max_size'); //in KB, 4 MB
								$this->load->library('upload', $config); //load upload library with new settings
								if (!$this->upload->do_upload()) //if file upload failed
 												$error = $this->upload->display_errors();
								else // if file uplaod succeed

								{
										$uploadedData = $this->upload->data();
										$newVideoDetails = array('video_status' => 'active', 'video_type' => 'uploaded');
										$videoId = $this->videomodel->newVideo($newVideoDetails); //add new video entry in videos table
										if ($videoId)
										{
												$srcFile = $appDir . $uploadedData['file_name'];
												$destFile = $appDir . 'video_' . $videoId . '.flv';
												//flv convertion
												exec("$mencoder $srcFile -o $destFile -of lavf -oac mp3lame -lameopts abr:br=56 -ovc lavc -lavcopts vcodec=flv:vbitrate=9600:mbd=2:mv0:trell:v4mv:cbp:last_pred=3 -lavfopts i_certify_that_my_video_stream_does_not_use_b_frames -srate 22050");
												unlink($srcFile);
												if (file_exists($destFile)) $this->videomodel->video_to_frame($destFile, $videoId); //video to frame
												$success = $this->lang->line('video_upload_success_msg');
										}
								} //end upload
						} //end else
				} //end post
				if ($success != '')
				{
						$outputData['success_msg'] = $success;
						$outputData['video_privacy'] = $this->videomodel->getVideoVisibilitySettings();
						$outputData['video_id'] = $videoId;
						$this->smartyextended->view('videoscreateinfo', $outputData);
				}
				else
				{
						$outputData['error_msg'] = $error;
						$this->smartyextended->view('videosupload', $outputData);
				}
		} //end upload()
		//temporary method, for testing purpose
		function removefolder($userId)
		{
				//APPPATH.'content/videos/user_'.$userId.'/temp';
				$this->videomodel->recursive_remove_directory(APPPATH . 'content/videos/user_' . $userId . '/temp', true);
				$this->videomodel->recursive_remove_directory(APPPATH . 'content/videos/user_' . $userId, true);
		} //end removeDir()
		function _videoFrmRules()
		{
				$rules['video_title'] = 'trim|required|min_length[6]';
				$this->validation->set_rules($rules);
				$fields['video_title'] = 'Title';
				$this->validation->set_fields($fields);
		} //end _videoFrmRules()
		function editvideoinfo()
		{
				$this->load->library('validation');
				$this->_videoFrmRules();
				if ($this->validation->run() == false)
				{
						//Oops! validation Error.
						$outputData['validationError'] = $this->validation->error_string;
						$outputData['video_privacy'] = $this->videomodel->getVideoVisibilitySettings();
						$this->smartyextended->view('videoscreateinfo', $outputData);
				}
				else
				{
						if ($this->videomodel->editVideoInfo($_POST)) $this->session->set_userdata(array("success_msg" => $this->lang->line('video_info_success_msg')));
						else  $this->session->set_userdata(array("error_msg" => $this->lang->line('video_info_error_msg')));
						redirect("videos/myvideos");
				}
		} //end newvideoinfo()
		function playvideo($videoId)
		{
				if (trim($videoId) > 0 and $this->videomodel->isExist(trim($videoId)))
				{
						$video = $this->videomodel->getVideo($videoId);
						$this->load->model('wallmodel');
						if (!empty($video))
						{
								//				$ipAddress	= $_SERVER['REMOTE_ADDR'];
								//				if($this->session->userdata('remote_ip_address')!='')
								//				{
								//					if($ipAddress!=$this->session->userdata('remote_ip_address'))
								//						$this->session->set_userdata(array("remote_ip_address"=> $ipAddress)));
								//				}
								//				else
								//					$this->session->set_userdata(array("remote_ip_address"=> $ipAddress)));
								$this->load->model('usermodel');
								$outputData = $video;
								$outputData['video_owner'] = $this->usermodel->getName($video['user_id']);
								$views = $video['views'];
								if ($views == '' or $views == 0) $views = 1; //assing 1, if it viewes first time
								elseif ($views > 0) $views++; //increase one, if it already viewed
								$this->videomodel->updateTable('videos', array('views' => $views), array('video_id' => $videoId));
								$outputData['total_views'] = $views;
								$rates = $this->videomodel->getRateValues($videoId);
								$outputData['rate_image'] = $this->videomodel->getRatingImg($rates['rate_count'], $rates['rate_sum']);
								$outputData['rate_sum'] = $rates['rate_sum'];
								//For wall
								$outputData['wall'] = $this->wallmodel->getWall('video', $videoId, 'wall_date desc', 0, 5);
								$outputData['wallCount'] = count($outputData['wall']);
								$outputData['wallTotal'] = $this->wallmodel->getWallCount('video', $videoId);
								$this->smartyextended->view('videosplay', $outputData);
						}
						else  redirect("videos");
				}
				else  redirect("videos");
		} //end newvideoinfo()
		###################################################################################################
		#Method			: flvplayer()
		#Type			: Main
		#Description	: this is used to call play flv file,it calls the config.tpl, in which
		#				  we have the xml content for this flv file
		#Arguments		: video_id,user_id to retrieve the video path
		##################################################################################################
		function flvplayer($videoId, $userId)
		{
				//reads common site settings
				$this->load->model('settingsModel');
				$settings = $this->settingsmodel->readSetting('red5_path');
				$red5SettingsPath = $settings['red5_path'];
				$outputData['red5SettingsPath'] = $red5SettingsPath;
				$outputData['share_path'] = base_url() . "videos/share/" . $videoId;
				$outputData['video_id'] = $videoId;
				$outputData['user_id'] = $userId;
				header('Content-type: text/xml');
				$this->smartyextended->view('videosconfig', $outputData);
		} //end flvplayer()
		#***************************************************************************
		#Method			: record()
		#Description	: to record video throu web camera
		#***************************************************************************
		function record()
		{
				//reads common site settings
				$this->load->model('settingsModel');
				$settings = $this->settingsmodel->readSetting('red5_path');
				$red5SettingsPath = $settings['red5_path'];
				//show recorder page
				$randNo = rand(00001, 32768); //random number to create filename
				if ($this->session->userdata('video_name') != '') $this->session->set_userdata(array('video_name' => ''));
				$this->session->set_userdata(array('video_name' => $randNo));
				if ($this->session->userdata('sess_error_msg') != '')
				{
						$outputData['error_msg'] = $this->session->userdata('sess_error_msg');
						$this->session->set_userdata(array('sess_error_msg' => ''));
				}
				$outputData['temp_video_name'] = $randNo;
				$outputData['red5_settings_path'] = $red5SettingsPath;
				$this->smartyextended->view('videosrecorder', $outputData);
		} //end record()
		#***************************************************************************
		#Method			: storevideo()
		#Description	: to add a new entry in videos table
		#***************************************************************************
		function storevideo()
		{
				//reads common site settings
				$this->load->model('settingsModel');
				$settings = $this->settingsmodel->readSetting('red5_flv_path, flvtool2_path');
				$red5FlvPath = $settings['red5_flv_path'];
				$flvtool2Path = $settings['flvtool2_path'];
				$userId = $this->session->userdata('user_id');
				$this->config->load('video'); //Load the config file related to photo
				$appDir = APPPATH . 'content/videos/user_' . $userId . '/'; //upload path
				$tempVideoName = $this->session->userdata('video_name');
				$srcFile = $red5FlvPath . $tempVideoName . ".flv";
				if (!file_exists($srcFile))
				{
						$errorMsg = $this->lang->line('video_record_error_msg');
						$this->session->set_userdata(array('sess_error_msg' => $errorMsg));
						redirect("videos/record");
				}
				else
				{
						if (!file_exists($appDir)) //Check whether the upload path exist. if not creat it.

						{
								mkdir($appDir);
								mkdir($appDir . 'temp/');
						}
						$newVideoDetails = array('video_status' => 'active', 'video_type' => 'recorded');
						$videoId = $this->videomodel->newVideo($newVideoDetails); //add new video entry in videos table
						if ($videoId)
						{
								$destFile = $appDir . 'video_' . $videoId . '.flv';
								copy($srcFile, $destFile);
								exec($flvtool2Path . " -UP " . $destFile);
								//unlink($srcFile);
								if (file_exists($destFile)) $this->videomodel->video_to_frame($destFile, $videoId); //video to frame
								$success = $this->lang->line('video_record_success_msg');
								$outputData['success_msg'] = $success;
								$outputData['video_privacy'] = $this->videomodel->getVideoVisibilitySettings();
								$outputData['video_id'] = $videoId;
								$this->smartyextended->view('videoscreateinfo', $outputData);
						}
						else
						{
								$errorMsg = $this->lang->line('video_new_entry_error_msg');
								$this->session->set_userdata(array('sess_error_msg' => $errorMsg));
								//unlink($srcFile);
								redirect("videos/record");
						}
				}
		} //end storevideo()
		function ratevideo()
		{
				$videoId = $this->input->post('videoId');
				$rateValue = $this->input->post('rateValue');
				$errMsg = '';
				$sucsMsg = '';
				$comnMsg = '';
				if ($this->videomodel->isRated($videoId)) //check whether this video already rated by the current user
 								$comnMsg = $this->lang->line('video_already_rated');
				else
				{
						if (!$this->videomodel->newRate($videoId, $rateValue)) $errMsg = $this->lang->line('video_rate_error_msg');
						else
						{
								$video = $this->videomodel->getVideo($videoId);
								$singleRate = $video['rate_value'];
								$rateCount = $video['rate_count'];
								if ($singleRate == '' or $singleRate == 0)
								{
										$singleRate = $rateValue; //assing rate value, if it rated first time
										$rateCount = 1;
								} elseif ($singleRate > 0)
								{
										$singleRate += $rateValue; //add ratevalue , if it already rated
										$rateCount++;
								}
								//execute query for updating rate_value field
								if ($this->videomodel->updateTable('videos', array('rate_value' => $singleRate, 'rate_count' => $rateCount), array('video_id' => $videoId))) $sucsMsg = $this->lang->line('video_rate_success_msg');
								else  $errMsg = $this->lang->line('video_rate_error_msg');
						}
				}
				//get rate value for the given cntent id
				$rates = $this->videomodel->getRateValues($videoId);
				$outputData['rate_image'] = $this->videomodel->getRatingImg($rates['rate_count'], $rates['rate_sum']);
				$outputData['rate_sum'] = $rates['rate_sum'];
				$outputData['rate_error_msg'] = $errMsg;
				$outputData['rate_success_msg'] = $sucsMsg;
				$outputData['rate_common_msg'] = $comnMsg;
				$outputData['video_id'] = $videoId;
				echo json_encode(array('template' => $this->smartyextended->view('videosrate', $outputData, true)));
		} //end ratevideo
		function editvideo($videoId)
		{
				if (trim($videoId) > 0 and $this->videomodel->isExist(trim($videoId)))
				{
						$outputData = $this->videomodel->getVideo($videoId);
						$outputData['video_privacy'] = $this->videomodel->getVideoVisibilitySettings();
						$outputData['video_id'] = $videoId;
						$this->smartyextended->view('videoscreateinfo', $outputData);
				}
				else  redirect('videos');
		} //end editvideo()
		function deletevideo($videoId)
		{
				if (trim($videoId) > 0 and $this->videomodel->isExist(trim($videoId)) and $this->videomodel->isVideoOwner($videoId))
				{
						if ($this->videomodel->deleteVideo($videoId))
						{
								$userId = $this->session->userdata('user_id');
								unlink(APPPATH . 'content/videos/user_' . $userId . '/video_' . $videoId . '.flv');
								unlink(APPPATH . 'content/videos/user_' . $userId . '/video_' . $videoId . '_thumb.jpg');
								$this->session->set_userdata(array("success_msg" => $this->lang->line('video_delete_success_msg')));
								$this->load->model('postedmodel');
								$this->postedmodel->deletePostByType('video', $videoId); //delete all posts for this photo
						}
						else  $this->session->set_userdata(array("error_msg" => $this->lang->line('video_delete_error_msg')));
				}
				redirect("videos/myvideos");
		} //end deletevideo()
		#***************************************************************************
		#Method			: sharevideo()
		#Description	: share the current video
		#***************************************************************************
		function sharevideo($videoId)
		{
				$this->load->model("postedmodel");
				if (trim($videoId) > 0 and $this->videomodel->isExist(trim($videoId)))
				{
						$videoDetails = $this->videomodel->getVideo($videoId);
						$outputData = array_merge($this->postedmodel->getShareContent($videoId, 'video'), $videoDetails);
						$this->smartyextended->view('videossharevideo', $outputData);
				}
				else  redirect("videos");
		} //end editvideo()
}
?>