<? include ("header.php"); ?>










<table cellpadding="0" cellspacing="0" border="0" width="100%">
	<tr class="top3">
		<td colspan="3"><img src="template/v3/i/b.gif" border="0" height="15" width="1"></td>
	</tr>
	<tr class="top4">
		<td>&nbsp;</td>
		<td align="center">
			<table cellpadding="0" cellspacing="0" border="0" width="778">
				<tr>
					<td valign="top" height="109"><object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" width="257" height="109" id="logo" align="middle"><param name="movie" value="flash/logo.swf" /><param name="quality" value="high" /><param name="wmode" value="transparent" /><param name="bgcolor" value="#ffffff" /><embed src="flash/logo.swf" quality="high" wmode="transparent" bgcolor="#ffffff" width="257" height="109" name="rotator" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /></object></td>
					<td valign="top" height="109"><img src="template/v3/i/content12.jpg" border="0"></td>
					<td rowspan="3" valign="top" class="box_right"><object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" width="204" height="128" id="innerstar" align="middle"><param name="allowScriptAccess" value="sameDomain" /><param name="movie" value="flash/innerstar.swf" /><param name="quality" value="high" /><param name="wmode" value="transparent" /><param name="bgcolor" value="#ffffff" /><embed src="flash/innerstar.swf" quality="high" wmode="transparent" bgcolor="#ffffff" width="204" height="128" name="innerstar" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /></object><a href="promotions.php"><img src="template/v3/i/innerstar-1b2.gif" border="0"></a>
						











<? include ("mg.php"); ?>
				<tr>
					<td class="subtitle_path" colspan="2" valign="top" height="35"><div><a href="index.php"><img src="template/v3/i/home_ico.jpg" border="0" vspace="0" style="margin-left: 36px;margin-right: 27px" align="left"></a></div>Cashier</td>
				</tr>
				<tr>
					<td colspan="2" class="content" valign="top"><img src="template/v3/i/b.gif" width="1" height="500" border="0" align="left">Casino offers you the following secure payment solutions because they are guaranteed to be fast, easy and effective. only uses payment processors that are secure and reputable. Our wide variety of deposit and withdrawal options cater to your individual needs. Feel free to contact us for more transaction information of for any assistance during the deposit or Withdrawal process.<br><br>


<script language="JavaScript">
function setClass(id,id_child){
	if (document.getElementById(id_child).style.display == 'none') id.className = 'cash_h';
	else id.className = 'cash_h_selected';
}
function switchDisplay(obj,id){
	obj.className = 'cash_h_selected'; 
	a = document.getElementById('div' + id).style.display;
	document.getElementById('div' + id).style.display = (a == 'block') ? 'none' : 'block';
	b = document.getElementById('col' + id).className;
	document.getElementById('col' + id).className = (b == 'expl_off') ? 'expl' : 'expl_off';
}
</script>
<table width="97%" border="0">
	<tr>
		<td height="219"><table width="100%"  cellpadding="0" cellspacing="0">
				<tbody>
					<tr>
						<td width="100%" height="215" valign="top"><b><img src="images/ar-org.gif" align="absmiddle" border="0" hspace="8"></b><b>Making Deposits:</b><br>
    							<br>							   <table width="100%" border="0">
                                	<tr>
                                		<td width="48">&nbsp;</td>
                                		<td width="924">In order to play our Casino games and win REAL MONEY, you must first deposit money into your casino account. All transactions take place in US$ and all deposited funds must be processed and approved before you are allowed to bet for real money. To learn how to deposit using the method best for you, click on the following deposit options. Remember, you receive an additional 15% cash bonus for such non-credit card deposit methods such as NETeller [Non US Only]! Cash processing services are provided for by world- and industry-renowned AquaPay London, who allow the Network to accept secure real-time credit card payments over the Internet. The AquaPay&#8482; gateway is a multi-currency processing system that enables it's clients to offer their products and services in a number of different currencies.<font color="#ffffff">&nbsp;</font><font color="#ffffff">&nbsp;</font><font color="#ffffff" size="3">&nbsp;</font><font color="#ffffff" face="trebuchet ms" size="3">&nbsp;</font></td>
                               		</tr>
                                	</table>    							<font color="#ffffff" face="trebuchet ms" size="3"><br>
						</font></td>
					</tr>
					<br />
				</tbody>
		</table></td>
	</tr>
	<tr>
		<td height="100%"><table width="100%" cellpadding="0" cellspacing="1" bgcolor="#ffcc00" class="exp_table">
				<tbody>
					<tr>
						<th width="243" bgcolor="#001F6F"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><strong>Payment Method</strong></font></font></th>
						<th width="265" bgcolor="#001F6F"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><strong>Funding</strong></font></font></th>
						<th width="251" bgcolor="#001F6F"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><strong>Deposit Time</strong></font></font></th>
						<th width="236" bgcolor="#001F6F"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><strong>Available</strong></font></font></th>
					</tr>
					<tr bgcolor="#00234C" class="cash_h" onClick="switchDisplay(this,'6');" onMouseOver="if (this.className != 'cash_h_selected') this.className = 'expl_h';" onMouseOut="setClass(this,'div6')">
						<td valign="top"><div align="center"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><img src="images/cashier/cc.gif" alt="" border="0"></font></div></td>
						<td valign="middle"><div align="center"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><b>Click for details</b></font></font></div></td>
						<td valign="middle"><div align="center"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><strong>Instant</strong></font></font></div></td>
						<td valign="middle"><div align="center"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><strong>International <br>
								$<br />
                    								<!-- &#8364;-->
                    								<!--?-->
						</strong></font></font></div></td>
					</tr>
					<tr bgcolor="#00234C" class="cash_s">
						<td colspan="4" class="expl_off" id="col6"><div id="div6" style="display: none;">
								<ul>
									<li><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><b>About</b><br>
										Although the casino accepts <strong>Visa and MasterCard</strong>, some banks prohibit their cardholders from making transactions with online casinos.<br>
										For this reason, we strongly recommend that you open an alternative payment method for your transactions. All approved transactions will be credited to your casino account immediately so you can begin play at your convenience<br>
										<li><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><b>Funding</b><br>
										You must register your Credit Card prior to depositing money. You will be prompted to enter your personal details for registration with the secure casino server.<br>
										Transactions are identified on your credit card statement as .com. This casino is owned and operated by Cytech Ltd., 1934 Driftwood Bay, Belize City, Belize<br />
										<br />
										<li><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><b>Casino Support</b><br>
										Toll Free [Canada]: +1(800)761-1303<br>
										Phone [International]: +(800)761-1303<br>
										Email Support: <a href="mailto:support@.com" class="bot1">support@.com</a></font></li>
									<li><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><b>Fees</b><br>
										No Fees</font></li>
								</ul>
						</div></td>
					</tr>
					<tr bgcolor="#00234C" class="cash_h" onClick="switchDisplay(this,'18');" onMouseOver="if (this.className != 'cash_h_selected') this.className = 'expl_h';" onMouseOut="setClass(this,'div18')">
						<td valign="top"><div align="center"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><img src="images/cashier/neteller.gif" alt="" border="0"></font></div></td>
						<td valign="middle"><div align="center"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><b>Click for details</b></font></font></div></td>
						<td valign="middle"><div align="center"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><strong>Instant</strong></font></font></div></td>
						<td valign="middle"><div align="center"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><strong>International [Non-US]<br>
								$<br />
                    								<!-- &#8364;-->
                    								<!--?-->
						</strong></font></font></div></td>
					</tr>
					<tr bgcolor="#00234C" class="cash_s">
						<td colspan="4" class="expl_off" id="col18"><div id="div18" style="display: none;">
								<ul>
									<li><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><b>About</b><br>
        										<strong>NETeller</strong> is a fast &amp; secure payment transfer service which allows you to deposit money instantly into your casino account. <br>
        										<a title="" onClick="openexitstatus = 0;" href="https://www.neteller.com/ab/register/index.cfm" target="_blank" class="bot1">Click here</a> to register for a NETeller account.<br />
									<li><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><b>Funding</b><br>
										You can fund your NETeller account with either Visa credit card, Bank Wire, Internet Banking &amp; EFT.                            <li><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><b>NETeller Support</b><br>
										Live chat &#8211; available 24/7<br>
										Phone &#8211; available 24/7<br>
										North America &#8211; Toll Free: 1 888 258 5859<br>
										Other countries &#8211; Toll free: (+) 800-7767-6343 <br>
										Australia, Austria, Belgium, China, Denmark, Finland, France, Germany, Hong Kong, Ireland, Italy, Japan, Macau, Netherlands, Norway, Portugal, Singapore, Spain, Taiwan, UK.<br>
										All other countries (not toll free) +1 403 233 9466<br>
										E-mail support: <a href="mailto:support@neteller.com" class="bot1">support@neteller.com</a><br />
										<li><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><b>Bonus</b><br>
										will award all NETeller deposits with a 15% Bonus. Cashback bonuses are usually issued within 48-72 hours of original deposit.</font></li>
									<li><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><b>Fees</b><br>
										Visa &#8211; 3.9%<br>
										Free with Bank Wire, EFT &amp; Online Banking</font></li>
								</ul>
						</div></td>
					</tr>
					<tr bgcolor="#00234C" class="cash_h" onClick="switchDisplay(this,'22');" onMouseOver="if (this.className != 'cash_h_selected') this.className = 'expl_h';" onMouseOut="setClass(this,'div22')">
						<td valign="top"><div align="center"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><img src="images/cashier/instacash.gif" alt="" border="0"></font></div></td>
						<td valign="middle"><div align="center"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><b>Click for details</b></font></font></div></td>
						<td valign="middle"><div align="center"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><strong>Instant</strong></font></font></div></td>
						<td valign="middle"><div align="center"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><strong>Canada ONLY <br>
								$</strong></font></font></div></td>
					</tr>
					<tr bgcolor="#00234C" class="cash_s">
						<td colspan="4" class="expl_off" id="col22"><div id="div22" style="display: none;">
								<ul>
									<li><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><b>About</b><br>
										Use your Canadian bank account with <strong>NETeller</strong>&#39;s payment option of <strong>instaCA$H</strong> &amp; you'll be able to make instant deposits directly from your bank into the casino. <br>
										<a title="" onClick="openexitstatus = 0;" href="https://www.neteller.com/ab/register/index.cfm" target="_blank" class="bot1">Click here</a> to register for a NETeller account.<br />
									<li><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><b>Funding</b><br>
										Select the instaCA$H option. Register your bank account &amp; provide the bank account details which can be found on any personal check attached to your checking account.<br />
									<li><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><b>Bonus</b><br>
										will award all instaCa$H deposits with a 10% Bonus.<br />
<li><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><b>NETeller Support</b><br>
										Live chat &#8211; available 24/7<br>
										Phone &#8211; available 24/7<br>
										North America &#8211; Toll Free: 1 888 258 5859<br>
										E-mail support: <a href="mailto:support@neteller.com" class="bot1">support@neteller.com</a></font></li>
									<li><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><b>Fees</b><br>
										No Fees &#8211; The casino will cover the instaCA$H 8.9% fee when you deposit using instaCA$H through the casino cashier.</font></li>
								</ul>
						</div></td>
					</tr>
					<tr bgcolor="#00234C" class="cash_h" onClick="switchDisplay(this,'55');" onMouseOver="if (this.className != 'cash_h_selected') this.className = 'expl_h';" onMouseOut="setClass(this,'div55')">
						<td valign="top"><div align="center"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><img src="images/cashier/ewalletexpress.gif" alt="" border="0"></font></div></td>
						<td valign="middle"><div align="center"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><b>Click for details</b></font></div></td>
						<td valign="middle"><div align="center"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><strong>Instant</strong></font></div></td>
						<td valign="middle"><div align="center"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><strong>Canada<br>
								$</strong></font></div></td>
					</tr>
					<tr bgcolor="#00234C" class="cash_s">
						<td colspan="4" class="expl_off" id="col55"><div id="div55" style="display: none;">
								<ul>
									<li><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><b>About</b><br>
										eWalletXpress is an instant online money transfer service that provides a fast &amp; secure method of transferring cash to your casino account. <br>
										<a title="" onClick="openexitstatus = 0;" href="https://jump.navahonetworks.com/navaho/app;jsessionid=Zs3X8+GBZ+0w2j4cX2Rj-%20A**?sub=register" target="_blank" class="bot1">Click here</a> to register your EwalletXpress account.<br />
								<li><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><b>Funding</b><br>
										eWalletXpress can be funded by Basic checking/ACH, Xpress funds, 900pay, Bank Wire &amp; Money order.<br />
					<li><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><b>EwalletXpressSupport </b><br>
										24/7 Phone support : 1-877-245-6799<br>
										E-mail support &#8211; 24/7 : <a href="mailto:support@navahonetworks.com" class="bot1">support@navahonetworks.com</a></font></li>
									<br />
										<!-- <b>Bonus</b><br>will award all eWalletXpress deposits with a 10% Bonus.<b>Fees</b><br> -->
							<li><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><b>Fees</b><br>No fees</font></li>
								</ul>
						</div></td>
					</tr>
					<tr bgcolor="#00234C" class="cash_h" onClick="switchDisplay(this,'42');" onMouseOver="if (this.className != 'cash_h_selected') this.className = 'expl_h';" onMouseOut="setClass(this,'div42')">
						<td valign="top"><div align="center"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><img src="images/cashier/moneybookers.gif" alt="" border="0"></font></div></td>
						<td valign="middle"><div align="center"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><b>Click for details</b></font></div></td>
						<td valign="middle"><div align="center"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><strong>Up to 5 days</strong></font></div></td>
						<td valign="middle"><div align="center"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><strong>International <br>
								$<br />
                								<!-- &#8364;-->
                								<!--?-->
						</strong></font></div></td>
					</tr>
					<tr bgcolor="#00234C" class="cash_s">
						<td colspan="4" class="expl_off" id="col42"><div id="div42" style="display: none;"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"></font><br />
        								<ul>
        							<li><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><b>About</b><br>
                										<strong>Moneybookers</strong> is a tool that allows you to send and receive money online. <br>
                										<a title="" onClick="openexitstatus = 0;" href="https://www.moneybookers.com/app/register.pl" target="_blank" class="bot1">Click here</a> to register a new Moneybookers account.<br />
									<li><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><b>Funding</b><br>
										You can use a visa credit card, bank wire or checking account transfer to fund your account.<br />
					  <li><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><b>Moneybookers Support </b><br>
										Monday to Friday. 9am &#8211; 6pm UK time<br>
										Phone support &#8211; Monday to Friday 9am &#8211; 6pm UK time<br>
										UK: 0905 848 0011 (calls cost 25p / minute)<br>
										Germany: 0190 210 217 (calls cost<br />
										<!-- &#8364;-->
										0.62 / minute)<br>
										International: +44 709 204 2000<br>
										E-mail support : <a href="mailto:service@Moneybookers.com" class="bot1">service@Moneybookers.com</a></font></li>
        									<li><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><b>Fees</b><br>
										There is a 3% service charge when using a credit card</font></li>
								</ul>
        								<font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"></font></div></td>
					</tr>
					<tr bgcolor="#00234C" class="cash_h" onClick="switchDisplay(this,'58');" onMouseOver="if (this.className != 'cash_h_selected') this.className = 'expl_h';" onMouseOut="setClass(this,'div58')">
						<td valign="top"><div align="center"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><img src="images/cashier/instadebit.gif" alt="" border="0"></font></div></td>
						<td valign="middle"><div align="center"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><b>Click for details</b></font></div></td>
						<td valign="middle"><div align="center"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><strong>Instant</strong></font></div></td>
						<td valign="middle"><div align="center"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><strong>Canada<br>
								$</strong></font></div></td>
					</tr>
					<tr bgcolor="#00234C" class="cash_s">
						<td colspan="4" class="expl_off" id="col58"><div id="div58" style="display: none;">
								<ul>
									<li><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><b>About</b><br>
        										<strong>InstaDEBIT</strong> is a simple way to make instant online deposits directly from your Canadian bank account &amp; works the same as writing a check or using your debit card. <br>
        										<a title="" onClick="openexitstatus = 0;" href="http://www.instadebit.com/html/whatarethebenefits.asp#easyregister" target="_blank" class="bot1">Click here</a> to register your InstaDEBIT account.<br />
									<li><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><b>Funding</b><br>
										You will need to complete the online form &amp; enter your bank account information.<br />
						<li><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><b>InstaDEBIT Support </b><br>
										Live chat &#8211; available 24/7<br>
										Phone support: Toll Free 1-877-88DEBIT.<br>
										E-mail support: <a href="mailto:support@INSTADEBIT.com" class="bot1">support@INSTADEBIT.com</a></font></li>
									<li><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><b>Fees</b><br>
										No fees</font></li>
								</ul>
						</div></td>
					</tr>
					<tr bgcolor="#00234C" class="cash_h" onClick="switchDisplay(this,'38');" onMouseOver="if (this.className != 'cash_h_selected') this.className = 'expl_h';" onMouseOut="setClass(this,'div38')">
						<td valign="top"><div align="center"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><img src="images/cashier/click.gif" alt="" border="0"></font></div></td>
						<td valign="middle"><div align="center"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><b>Click for details</b></font></div></td>
						<td valign="middle"><div align="center"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><strong>Instant</strong></font></div></td>
						<td valign="middle"><div align="center"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><strong>International<br>
								$<br />
                								<!-- &#8364;-->
                								<!--?-->
						</strong></font></div></td>
					</tr>
					<tr bgcolor="#00234C" class="cash_s">
						<td colspan="4" class="expl_off" id="col38"><div id="div38" style="display: none;"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"></font><br />
        								<ul>
        									<li><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><b>About</b><br>
                										<strong>Click2Pay</strong> is an instant, international &amp; secure web wallet that allows you to transfer funds instantly from a variety of different options. <br>
                										<a title="" onClick="openexitstatus = 0;" href="http://www.click2pay.com/en/" target="_blank" class="bot1">Click here</a> to register your Click2Pay account.<br />
									<li><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><b>Funding</b><br>
										You can fund your Click2Pay account with: Visa, Mastercard, Online Banking, Bank Deposit &amp; ACH (Direct Debit).<br />
						<li><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><b>Click2Pay Support</b><br>
										Phone &#8211; available 24/7<br>
										USA Toll Free: 1-888-254-2729<br>
										International (long distance): +49 (0)30 300 110 100<br>
										E-mail support : <a href="mailto:service@Click2Pay.com" class="bot1">service@Click2Pay.com</a></font></li>
        									<li><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><b>Fees</b><br>
										There is a 3% fee when funding the account with a credit card.</font></li>
								</ul>
        								<font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"> </font></div></td>
					</tr>
					<tr bgcolor="#00234C" class="cash_h" onClick="switchDisplay(this,'46');" onMouseOver="if (this.className != 'cash_h_selected') this.className = 'expl_h';" onMouseOut="setClass(this,'div46')">
						<td valign="top"><div align="center"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><img src="images/cashier/ecocard.gif" alt="" border="0"></font></div></td>
						<td valign="middle"><div align="center"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><b>Click for details</b></font></div></td>
						<td valign="middle"><div align="center"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><strong>Up to 5 days</strong></font></div></td>
						<td valign="middle"><div align="center"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><strong>International<br>
								$<br />
                								<!-- &#8364;-->
                								<!--?-->
						</strong></font></div></td>
					</tr>
					<tr bgcolor="#00234C" class="cash_s">
						<td colspan="4" class="expl_off" id="col46"><div id="div46" style="display: none;">
								<ul>
									<li><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><b>About</b><br>
        										<strong>EcoCard</strong> is a prepaid virtual debit card that utilizes a fully developed network of major banks across Europe with branch representations all over the world. <br>
        										<a title="" onClick="openexitstatus = 0;" href="https://www.ecocard.com/cgi-bin/navigation.pl?&amp;vid=2432809&amp;sel=3100" target="_blank" class="bot1">Click here</a> to register your EcoCard account.<br />
									<li><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><b>Funding</b><br>
										EcoCard can be funded by Bank Payments, MoneyGram, PrivatMoney or Western Union.<br />
							<li><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><b>EcoCard Support</b><br>
										Monday to Friday between 7am &#8211; 5pm GMT<br>
										Phone support &#8211; Answering machine: +44 (0) 870 763 0177<br>
										E-mail support &#8211; General Information : <a href="mailto:info@ecocard.com" class="bot1">info@ecocard.com</a><br>
										User Support : <a href="mailto:support@ecocard.com" class="bot1">support@ecocard.com</a></font></li>
									<li><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><b>Fees</b><br>
										No Fees</font></li>
								</ul>
						</div></td>
					</tr>
				<!-- 	<tr bgcolor="#00234C" class="cash_h" onClick="switchDisplay(this,'50');" onMouseOver="if (this.className != 'cash_h_selected') this.className = 'expl_h';" onMouseOut="setClass(this,'div50')">
						<td valign="top"><div align="center"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><img src="images/cashier/ach.gif" alt="" border="0"></font></div></td>
						<td valign="middle"><div align="center"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><b>Click for details</b></font></div></td>
						<td valign="middle"><div align="center"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><strong>Instant</strong></font></div></td>
						<td valign="middle"><div align="center"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><strong>US/Canada <br>
								$</strong></font></div></td>
					</tr>
					<tr bgcolor="#00234C" class="cash_s">
						<td colspan="4" class="expl_off" id="col50"><div id="div50" style="display: none;">
								<ul>
									<li><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><b>About</b><br>
        										<strong>ACH/eCheck</strong> - available to US residents only, you can use electronic checks directly from your Bank Account and with no hassle. The minimum amount you can deposit is $20 and the maximum accepted is $150 per check [VIPs may be higher]. The information you need in order to make your deposits is your U.S. Bank Account and a valid U.S. issued driver's license. You will also need your checking account number, which you will find at the bottom of the checks. <br>
										Contact <a href="support.html" class="bot1">customer support</a> or go to the 'Cashier' section of our software for more details.
										<li><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><b>Funding</b><br>
										Bank Account</font></li>
									<li><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><b>Fees</b><br>
										No fees</font></li>
								</ul>
						</div></td>
					</tr> 
					<tr bgcolor="#00234C" class="cash_h" onClick="switchDisplay(this,'34');" onMouseOver="if (this.className != 'cash_h_selected') this.className = 'expl_h';" onMouseOut="setClass(this,'div34')">
						<td height="36" valign="top"><div align="center"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><img src="images/cashier/firepay.gif" alt="" border="0"></font></div></td>
						<td valign="middle"><div align="center"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><b>Click for details</b></font></div></td>
						<td valign="middle"><div align="center"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><strong>Instant</strong></font></div></td>
						<td valign="middle"><div align="center"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><strong>UK/Canada<br>
								$</strong></font></div></td>
					</tr>
<tr bgcolor="#00234C" class="cash_s">
		<td class="expl_off" id="col34" colspan="4"><div id="div34" style="display: none;"><font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;"><ul>
			<li><b>About</b><br><strong>FirePay</strong> is similar to a debit or credit card as you will be given a 16-digit number &amp; expiry date. <br><a title="" onclick="openexitstatus = 0;" href="https://account.firepay.com/processSignup.jsp" target="_blank" class="bot1">Click here</a> to register a FirePay account in minutes. Normally, the first transfer from a bank account to a FirePay Personal Account takes between 2-3 business days.<br>Make sure the FirePay account registered e-mail address is the same e-mail address registered with the casino.</li>
			<li><b>Funding</b><br>In order to deposit funds into your FirePay account you will need to register a British or Canadian bank account. You can fund your account either directly from your bank account, via  ACH or e-checks.</li>
			<li><b>FPA Support</b><br>E-mail support &#8211; 24/7 : <a href="mailto:info@FirePay.com" class="bot1">info@FirePay.com</a></li>
			<li><b>Bonus</b><br>will award all Firepay deposits with a 15% Bonus. Cashback bonuses are usually issued within 48-72 hours of original deposit.</li>
			<li><b>Fees</b><br>$3.99 per deposit if you have validated your bank account.<br></li></ul></font></div></td>
	</tr>-->
				</tbody>
		</table><br><br>
		<font style="color: rgb(255, 255, 255); font-size: 12px; font-family: trebuchet ms;">Have you completed your <a href="faxbackform.html" class="bot1" target="_blank"><strong>FaxBackForm</strong></a>?  In order to most deposits and/or process any withdrawal, our Casino may require you to complete one of the forms. To help speed your play, we strongly advise supplying Customer Support with one. <a href="faxbackform.html" class="bot1" target="_blank"><strong>CLICK HERE TO GET STARTED</strong></a>.</font><br />
		</td>
	</tr>
</table></td>
				</tr>
				<tr>
					<td colspan="2" valign="bottom" class="content_bot"><img src="template/v3/i/content_bot.jpg" border="0"></td>
					<td class="box_right" valign="bottom"><img src="template/v3/i/box_right_bot.jpg" border="0"></td>
				</tr>
			</table>
		</td>
		<td>&nbsp;</td>
	</tr>
		<?		include ("footer.php") ?>	






