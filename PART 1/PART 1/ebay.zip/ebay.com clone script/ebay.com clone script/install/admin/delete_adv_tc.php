<?php //00461
// Copyright Notice
// Web Site URL:  http://www.zeeways.com
// Script Owner eMail: mail@zeeways.com
// Date: April, 2007
// Script Name: Zeeways Auction Website PHP Script
// Copyright Details: This script is not free.  Do not Remove this Copy Right notice.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the site administrator.');exit(199);
?>
4+oV58v3s+EzgZ/KhFXEm4VU3u2uNgK6BoAEROcii2u94+sRBti1zoX2S61pm6a5NDc6SAesmDKx
ALv1JtNTBl1i/1vpCU3tRt6+yhc+5S22EZvSeX3JQxqKUNvSdvpLOjdPD9JvAUOARKCwuYh2V7mr
EdJxzPMPjsrXRQkdNBYWHQY0upjDyFm1LYudO8dnbGKolRRhrnn7VBzHUFi/qIwyXrMEBioMP5qI
GDLbSV7nVkMcxHwvdpT/bgOq34npzoskINwscd0HWvnZ6fBbRoqYHGDzt6p6ce8Z/xbVZrIDkmuW
XKtpTmhvuvZnm9K3q8rPuzk8YzudMpAY9v25qjUG4pE6gFDFXiiF5hyj3PZVJx/yIzf7P9Zvnm/o
lWw/f3AR/b6kBgKavwT8fxeGumzZCryJ9e9F+5B2+hUdUg+cBzNVN8e09FXhzCmYYcewNs+gzrxq
ijcUCQRKlxsPLlSJvVa0WRKSSoxNAsL7FzeFJi9Dq85gkx+UcLxpPpgEqEebozIsaD8R6EzYJ5Yu
51/vUFrsLPFUFNbZw3RZAVOQ3VlfDOZcTAAUKjhAg7+FO+D1lqlQwPVpZpYErApNOcwkGxI+q7Dy
GggM5gR51Gfaw78G4MKhve8R6I1rdG5sAZ5oUi2L9d6FGj7RCWIe1PeIWaA61wQP2Ytxjnkdqt3Z
AwzBIk2/GP5LZjIxdFxH2E0+cduZL5obnpRzQz5mGkA5P5pu4QuUo1woNtybTIvN5PzHU44Y9JVJ
bQVXh0ZKEwA15XAqOhken/oqL1Boqo+DWBD6YMs1YTAb+9I9+WQnXIIwTHRJGjxs2D1ET+Z5BEXq
UW+Pw5CNbut+XxrcZFnHfkpFeEeDn6iYrdOpMIxs6MOhDcHtb8P1zQIUccxgQiFz7xEA+jBx9xuH
6j6A11D2Qs3Gyk+hYeib2TMDx4W1WU0QikhWVRNOobkbgf+2m4BeQiQBMt7CQ3t8rYmm9f0U2PKh
xw+p6OYuZ8W/Tk0IZdPxnkl2ZekhKNMHJgX9wQ34rpJtG9wFiTG9fLLOrmIHZ9kC+usPd+rcicDJ
aYWx0Mi8da/zHQCqKKgXV0qWVPP9hpwz2KHaspytzvLwEEHoQWnl/xCogIrQzfi/7LLfkpJvRZzZ
JZX4uygc7+VB6VmZ+LciJqwfnuEelJ7ZBPEcJrJL+m==