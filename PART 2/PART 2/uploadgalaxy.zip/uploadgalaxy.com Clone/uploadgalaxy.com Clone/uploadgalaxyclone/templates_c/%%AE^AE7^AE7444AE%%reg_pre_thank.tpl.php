<?php /* Smarty version 2.6.6, created on 2006-07-16 08:03:53
         compiled from reg_pre_thank.tpl */ ?>
<html>

<head>
<title><?php echo $this->_tpl_vars['page']; ?>
</title>
<!--<?php echo '-->
<link href="templates/style.css" rel="stylesheet" type="text/css">
<!--'; ?>
-->

</head>

<body>
<p align=center>
<table border="0" width="600" height="129" cellspacing="0" cellpadding="0">
  <tr>
    <td width="600" height="250" valign="top">
      <table border="0" width="100%" cellspacing="0" cellpadding="0" height="314">
        <tr>
          <td width="100%" height="29" colspan="2">
<!---------------------------------------------------------------->          
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "header.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<!---------------------------------------------------------------->
          </td>
        </tr>
        <tr>
          <td width="100%" height="29" colspan="2">
          <p align="left">
          <font face="Verdana" size="3" color="#7777D2"><b>Premium Member</b></font>
          </p>
          </td>
        </tr>
        <tr>
          <td width="100%" colspan="2" height="49" bgcolor="#F2F2FF">
            <p align="right"><i><b><font size="2">THANK YOU</font></b></i></p>
          </td>
        </tr>
        
        
        <tr>
          <td width="51%" height="18"></td>
          <td width="49%" height="18" align=right valign="bottom">            
          </td>
        </tr>
        
        
        <tr>
          <td width="100%" colspan="2" height="127" valign="top">
           <form method="POST" action="register.php">
            <table border="0" width="100%" cellspacing="0" cellpadding="0" height="202">
              <tr>
                <td width="40%" align="right" height="37">
                  <p align="right">
                <b>Nickname</b></td>
                <td width="4%" height="37">
                </td>
                <td width="56" height="37">
                  <p align="left">
					<?php echo $this->_tpl_vars['puinf']['username']; ?>

                </td>
              </tr>
              <tr>
                <td width="40%" align="right" height="36">
                  <p align="right">
                <b>First Name</b> </td>
                <td width="4%" height="36">
                </td>
                <td width="56" height="36">
                  <p align="left">
                <?php echo $this->_tpl_vars['puinf']['fname']; ?>

                </td>
              </tr>
              <tr>
                <td width="40%" align="right" height="36">
                <p align="right">
                <b>Last Name</b>
                </td>
                <td width="4%" height="36">
                </td>
                <td width="56" height="36">
                <p align="left">
                <?php echo $this->_tpl_vars['puinf']['lname']; ?>
</p>
                </td>
              </tr>
              <tr>
                <td width="40%" align="right" height="36">
                <p align="right">
                <b>Address 1</b>
                </p>
                </td>
                <td width="4%" height="36">
                </td>
                <td width="56" height="36">
                <?php echo $this->_tpl_vars['puinf']['address1']; ?>

                </td>
              </tr>
              <tr>
                <td width="40%" align="right" height="36">
                <p align="right">
                <b>Address 2</b>
                </p>
                </td>
                <td width="4%" height="36">
                </td>
                <td width="56" height="36">
                <?php echo $this->_tpl_vars['puinf']['address2']; ?>

                </td>
              </tr>
              <tr>
                <td width="40%" align="right" height="36">
                <p align="right">
                <b>City</b>
                </p>
                </td>
                <td width="4%" height="36">
                </td>
                <td width="56" height="36">
                <p align="left">
                <?php echo $this->_tpl_vars['puinf']['city']; ?>

                </td>
              </tr>
              <tr>
                <td width="40%" align="right" height="36">
                <p align="right">
                <b>Country</b>
                </p>
                </td>
                <td width="4%" height="36">
                </td>
                <td width="56" height="36">
                <p align="left">
                <?php echo $this->_tpl_vars['puinf']['country']; ?>

                </td>
              </tr>
              <tr>
                <td width="40%" align="right" height="36">
                <p align="right">
                <b>Your E-mail address</b>
                </td>
                <td width="4%" height="36">
                </td>
                <td width="56" height="36">
                <p align="left">
                <?php echo $this->_tpl_vars['puinf']['email']; ?>

                </td>
              </tr>
              <tr>
                <td width="40%" align="right" height="36">
                <p align="right">
                <b>Paypal E-mail account</b>
                </td>
                <td width="4%" height="36">
                </td>
                <td width="56" height="36">
                <p align="left">
                <?php echo $this->_tpl_vars['puinf']['paypal']; ?>

                </td>
              </tr>
              <tr>
                <td width="40%" align="right" height="36">
                <p align="right">
                <b>Password</b>
                </p>
                </td>
                <td width="4%" height="36">
                </td>
                <td width="56" height="36">
                <p align="left">
                [HIDDEN]
                </td>
              </tr>
              <tr>
                <td width="40%" align="right" height="36">
                <p align="right">
                <b>Your Website</b>
                </p>
                </td>
                <td width="4%" height="36">
                </td>
                <td width="56" height="36">
                <p align="left">
                <?php echo $this->_tpl_vars['puinf']['website']; ?>

                </td>
              </tr>
              <tr>
                <td width="40%" align="right" height="35">
                  <p align="right"></td>
                <td width="4%" height="35">
                </td>
                <td width="56" height="35">
                  <p align="left"><a href="premium.php" class="A">Signin</a>
                </td>
              </tr>
            </table>
            </form>
          </td>
        </tr>
        <tr>
          <td width="100%" colspan="2" height="18">
          
          
          </td>
        </tr>
        <tr>
          <td width="100%" colspan="2" height="48" bgcolor="#F7F3FF"></td>
        </tr>
        <tr>
<!--------------------------------------------------------------------------------------------------------->        
   <td width="100%" colspan="2" height="25">
  <p align="center"><?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "bottom_link.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
       
          </td>
<!--------------------------------------------------------------------------------------------------------->                  
        </tr>
      </table>
    </td>
  </tr>
  <tr>
    <td width="600" height="25"><img border="0" src="images/bottomLine.gif" width="600" height="18">      
    </td>
  </tr>
  <tr>
    <td width="600" height="109" valign="top" align="center">
      <p>&nbsp;</p>
      <p><b><font color="#FF0000">Important Service Announcement:</font><br>
      <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "msg1title.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
      </b></p>
      <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "msg1.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>      
      </td>
  </tr>
  <tr>
    <td width="600" height="15" valign="top">
    <p align="center"><?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
      </td>
  </tr>
</table>
</body>

</html>