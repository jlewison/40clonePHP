<?php

class EmailAnswersFormHandler extends FormHandler
{
		public $sent_email_arr = array();
		public function chkIsValidQuestionId($err_msg = '')
		{
				if ($this->fields_arr['qid'] == '' or $this->fields_arr['qid'] == 0)
				{
						$this->setCommonErrorMsg($err_msg);
						return false;
				}
				$sql = 'SELECT q.ques_id, q.total_answer, q.cat_id, q.best_ans_id, q.description, q.total_stars, q.question, TIMEDIFF(NOW(), date_asked) as date_asked' . ', ' . $this->getUserTableField('name') . ' as asked_by, q.status, q.user_id' . ' FROM ' . $this->CFG['db']['tbl']['questions'] . ' AS q' . ', ' . $this->CFG['db']['tbl']['users'] . ' AS u' . ' WHERE q.user_id=u.' . $this->getUserTableField('user_id') . ' AND q.status IN (\'Open\', \'Resolved\')' . ' AND u.' . $this->getUserTableField('usr_status') . '=\'Ok\' AND q.ques_id=' . $this->dbObj->Param('qid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['qid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$numrows = $rs->PO_RecordCount();
				if ($numrows > 0)
				{
						$this->question_details = $rs->FetchRow();
						return true;
				}
				$this->setCommonErrorMsg($err_msg);
				return false;
		}
		public function chkIsValidEmail($field_name, $err_tip = '', $is_chk_mxrr = false)
		{
				return $is_ok = (eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$", $this->fields_arr[$field_name]));
		}
		public function validateEmailInAnswers($email)
		{
				if (!($email = $email)) return;
				$this->fields_arr['email_temp'] = $email;
				if (!$this->chkIsValidEmail('email_temp'))
				{
						$this->invalid_email_arr['email'][] = $email;
						return;
				}
				$this->sent_email_arr['email'][] = $email;
		}
		public function chkIsValidInputsProvided($field_name)
		{
				$email_arr = str_replace(' ', '', $this->fields_arr[$field_name]);
				$email_arr = explode(',', $email_arr);
				$email_arr = array_unique($email_arr);
				foreach ($email_arr as $key => $value)
				{
						$this->validateEmailInAnswers($email_arr[$key]);
				}
		}
		public function chkIsValidEmailIDs($field_name, $err_tip = '')
		{
				$this->chkIsValidInputsProvided($field_name);
				$email_arr = explode(',', $this->fields_arr[$field_name]);
				$emails_arr = array();
				foreach ($email_arr as $val)
				{
						if (empty($val) || $val == '') continue;
						$is_ok = (eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$", $val));
						if (!$is_ok)
						{
								$this->fields_err_tip_arr[$field_name] = $err_tip;
								return false;
						}
						else
						{
								$emails_arr[] = $val;
						}
				}
				if (!$emails_arr)
				{
						$this->fields_err_tip_arr[$field_name] = $this->LANG['contactuserr_tip_enter_valid_email_ids'];
						return false;
				}
				return $emails_arr;
		}
		public function sendAlertMail($email, $subj, $msg, $sender_name, $sender_email)
		{
				$is_ok = $this->_sendMail($email, $subj, $msg, $sender_name, $sender_email);
				return $is_ok;
		}
		private function _sendMail($to_email, $subject, $body, $sender_name, $sender_email)
		{
				$mail = new PHPMailer();
				$mail->AddAddress($to_email);
				$mail->FromName = $sender_name;
				$mail->From = $mail->Sender = $sender_email;
				$mail->Subject = $subject;
				$mail->Body = $body;
				$mail->IsMail();
				$mail->IsHTML(true);
				return ($mail->Send());
		}
}
$emailanswersfrm = new EmailAnswersFormHandler();
$emailanswersfrm->setCfgLangGlobal($CFG, $LANG);
$emailanswersfrm->setPageBlockNames(array('form_contactus_show', 'msg_form_success', 'msg_form_error'));
$emailanswersfrm->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$emailanswersfrm->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$emailanswersfrm->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$emailanswersfrm->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$emailanswersfrm->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
if ($emailanswersfrm->isMember())
{
		$emailanswersfrm->setFormField('userename', $CFG['user']['name']);
		$emailanswersfrm->setFormField('useremail', $CFG['user']['email']);
}
else
{
		$emailanswersfrm->setFormField('userename', $CFG['site']['noreply_name']);
		$emailanswersfrm->setFormField('useremail', $CFG['site']['noreply_email']);
}
$emailanswersfrm->setFormField('to_emails', '');
$emailanswersfrm->setFormField('qid', '');
$emailanswersfrm->setDBObject($db);
if ($emailanswersfrm->isFormGETed($_GET, 'qid'))
{
		$emailanswersfrm->sanitizeFormInputs($_GET);
		$emailanswersfrm->chkIsValidQuestionId($LANG['emailanswers_err_tip_id_compulsory']);
		if ($emailanswersfrm->isValidFormInputs())
		{
				$emailanswersfrm->setAllPageBlocksHide();
				$emailanswersfrm->setPageBlockShow('form_contactus_show');
		}
		else
		{
				$emailanswersfrm->setAllPageBlocksHide();
				$emailanswersfrm->setPageBlockShow('msg_form_error');
		}
}
if ($emailanswersfrm->isFormPOSTed($_POST, 'submit_contactus'))
{
		$emailanswersfrm->sanitizeFormInputs($_POST);
		$emailanswersfrm->chkIsValidQuestionId($LANG['emailanswers_err_tip_id_compulsory']);
		$emailanswersfrm->chkIsNotEmpty('userename', $LANG['emailanswers_err_tip_compulsory']);
		$emailanswersfrm->chkIsNotEmpty('to_emails', $LANG['emailanswers_err_tip_compulsory']);
		$email_arr = $emailanswersfrm->chkIsValidEmailIDs('to_emails', $LANG['contactuserr_tip_invalid_email_ids']);
		if ($emailanswersfrm->isValidFormInputs())
		{
				foreach ($email_arr as $email_ids)
				{
						$subject = $emailanswersfrm->getMailContent($LANG['send_question_to_friend_subject'], array('question' => $emailanswersfrm->question_details['question'], 'sitename' => $CFG['site']['name'], 'sender name' => $emailanswersfrm->getFormField('userename'), 'question description' => $emailanswersfrm->question_details['description']));
						$content = $emailanswersfrm->getMailContent($LANG['send_question_to_friend_content'], array('question' => '<strong><a href="' . getUrl($CFG['site']['url'] . 'answer.php?qid=' . $emailanswersfrm->getFormField('qid'), $CFG['site']['url'] . 'view/answers/' . $emailanswersfrm->getFormField('qid') . '/', false) . '">' . $emailanswersfrm->question_details['question'] . '</a></strong>', 'sitename' => $CFG['site']['name'], 'sender name' => $emailanswersfrm->getFormField('userename'), 'question description' => $emailanswersfrm->question_details['description']));
						$emailanswersfrm->sendAlertMail($email_ids, $subject, $content, $CFG['site']['noreply_name'], $CFG['site']['noreply_email']);
				}
				$emailanswersfrm->setAllPageBlocksHide();
				$emailanswersfrm->setDisplayVar('mail_status', $emailanswersfrm->getFormField('to_emails'));
				$emailanswersfrm->setPageBlockShow('msg_form_success');
		}
		else
		{
				$emailanswersfrm->setAllPageBlocksHide();
				$emailanswersfrm->setPageBlockShow('msg_form_error');
				$emailanswersfrm->setPageBlockShow('form_contactus_show');
		}
}



?>
<script language="javascript">
	function popupWindow(url){
		 window.open (url, "","status=0,toolbar=0,resizable=0,scrollbars=1");
		 return false;
	}
</script>
<div id="selContactUs">
	<!--<p class="clsClose"><a href="#" onClick="return closLightWindow()"><?php echo $LANG['close']; ?></a></p>-->
	<h2><?php echo $LANG['emailanswers_title'] . ' - ' . wordWrapManual($emailanswersfrm->question_details['question'], $CFG['admin']['question']['line_length'], $CFG['admin']['question']['total_length']); ?></h2>
	<a href="#" id="posAlert"></a>
<?php
if ($emailanswersfrm->isShowPageBlock('msg_form_success'))
{
?>
<div id="selMsgSuccess">
	<p><?php echo $LANG['emailanswers_success']; ?></p>
	<script language="javascript">
		alert_manual('<?php echo $LANG['emailanswers_success']; ?>', 'posAlert');
		window.close();
	</script>
</div>
<?php
}
if ($emailanswersfrm->isShowPageBlock('msg_form_error'))
{
?>
<div id="selMsgError">
	<p><?php echo $LANG['msg_error_sorry'] . ' ' . $emailanswersfrm->getCommonErrorMsg(); ?></p>
</div>
<?php
}
if ($emailanswersfrm->isShowPageBlock('form_contactus_show'))
{
?>
		<form name="form_contactus_show" id="form_contactus_show" method="post" action="<?php echo URL($_SERVER['REQUEST_URI']); ?>" autocomplete="off">
			<table summary="<?php echo $LANG['emailanswers_tbl_summary']; ?>" class="clsPopupTbl">
				<tr>
					<td class="<?php echo $emailanswersfrm->getCSSFormLabelCellClass('userename'); ?>"><?php ShowHelpTip('forward_friend_name'); ?><label for="useremail"><?php echo $LANG['emailanswers_user_name']; ?></label></td>
					<td class="<?php echo $emailanswersfrm->getCSSFormFieldCellClass('userename'); ?>"><?php echo $emailanswersfrm->getFormFieldErrorTip('userename'); ?><span class="clsTextLeft"><span class="clsTextMiddle"><span class="clsTextRight"><input<?php echo ($CFG['user']['user_id'] > 0) ? ' readonly' : ''; ?> type="text" class="clsTextBox" name="userename" id="userename" tabindex="<?php echo $emailanswersfrm->getTabIndex(); ?>" value="<?php echo $emailanswersfrm->getFormField('userename'); ?>" /></span></span></span></td>
				</tr>
				<!--
				<tr>
					<td class="<?php echo $emailanswersfrm->getCSSFormLabelCellClass('useremail'); ?>"><?php ShowHelpTip('forward_friend_email'); ?><label for="useremail"><?php echo $LANG['emailanswers_user_email']; ?></label></td>
					<td class="<?php echo $emailanswersfrm->getCSSFormFieldCellClass('useremail'); ?>"><?php echo $emailanswersfrm->getFormFieldErrorTip('useremail'); ?><span class="clsTextLeft"><span class="clsTextMiddle"><span class="clsTextRight"><input<?php echo ($CFG['user']['user_id'] > 0) ? ' readonly' : ''; ?> type="text" class="clsTextBox" name="useremail" id="useremail" tabindex="<?php echo $emailanswersfrm->getTabIndex(); ?>" value="<?php echo $emailanswersfrm->getFormField('useremail'); ?>" /></span></span></span></td>
				</tr>
				-->
				<tr>
					<td class="<?php echo $emailanswersfrm->getCSSFormLabelCellClass('to_emails'); ?>"><?php ShowHelpTip('forward_friend_emails'); ?><label for="to_emails"><?php echo $LANG['emailanswers_to_emails']; ?></label></td>
					<td class="<?php echo $emailanswersfrm->getCSSFormFieldCellClass('to_emails'); ?>">
						<?php echo $emailanswersfrm->getFormFieldErrorTip('to_emails'); ?><textarea name="to_emails" id="to_emails" tabindex="<?php echo $emailanswersfrm->getTabIndex(); ?>" rows="2" cols="45"><?php echo $emailanswersfrm->getFormField('to_emails'); ?></textarea>
						<p><a href="#" onClick="return popupWindow('<?php echo getUrl($CFG['site']['url'] . 'importer/index.php?frmname=form_contactus_show&fname=to_emails', $CFG['site']['url'] . 'importer/index.php?frmname=form_contactus_show&fname=to_emails', false); ?>')"><?php echo $LANG['import_contacts']; ?></a></p>
						<p class="clsEmailNote"><?php echo $LANG['emailanswers_to_emails_msg']; ?></p>
					</td>
				</tr>
				<tr>
					<td class="<?php echo $emailanswersfrm->getCSSFormFieldCellClass('submit'); ?>" colspan="2"><p class="clsPopupSubmitTextBox"><input type="button" class="clsSubmitButton" name="submit_contactus" id="submit_contactus" value="<?php echo $LANG['emailanswers_submit']; ?>" tabindex="<?php echo $emailanswersfrm->getTabIndex(); ?>" onClick="ajaxFormSubmit('form_contactus_show', 'lightwindow_contents')" /></p></td>
				</tr>
			</table>
		</form>
<?php
}
?>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>