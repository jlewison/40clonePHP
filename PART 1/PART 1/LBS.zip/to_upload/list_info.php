<?php
require_once('Connections/apound.php');

$currentPage = $_SERVER["PHP_SELF"];

$maxRows_lisPcatLN = "$lnbalphabet";
$pageNum_lisPcatLN = 0;
if (isset($_GET['pageNum_lisPcatLN'])) {
  $pageNum_lisPcatLN = $_GET['pageNum_lisPcatLN'];
}
$startRow_lisPcatLN = $pageNum_lisPcatLN * $maxRows_lisPcatLN;

mysql_select_db($database_apound, $apound);
if($lexv == 'LIMITED') {
$query_lisPcatLN = "SELECT * FROM main WHERE main.categ = '$categ' AND main.avail = 'Y' AND main.paid = 'Y' AND TO_DAYS(NOW()) < TO_DAYS(stod) ORDER BY main.$AL_ordby_F $AL_ordby_O";
}
else {
$query_lisPcatLN = "SELECT * FROM main WHERE main.categ = '$categ' AND main.avail = 'Y' AND main.paid = 'Y' ORDER BY main.$AL_ordby_F $AL_ordby_O";
}
$query_limit_lisPcatLN = sprintf("%s LIMIT %d, %d", $query_lisPcatLN, $startRow_lisPcatLN, $maxRows_lisPcatLN);
$lisPcatLN = mysql_query($query_limit_lisPcatLN, $apound) or die(mysql_error());
$row_lisPcatLN = mysql_fetch_assoc($lisPcatLN);

if (isset($_GET['totalRows_lisPcatLN'])) {
  $totalRows_lisPcatLN = $_GET['totalRows_lisPcatLN'];
} else {
  $all_lisPcatLN = mysql_query($query_lisPcatLN);
  $totalRows_lisPcatLN = mysql_num_rows($all_lisPcatLN);
}
$totalPages_lisPcatLN = ceil($totalRows_lisPcatLN/$maxRows_lisPcatLN)-1;

$queryString_lisPcatLN = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_lisPcatLN") == false && 
        stristr($param, "totalRows_lisPcatLN") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_lisPcatLN = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_lisPcatLN = sprintf("&totalRows_lisPcatLN=%d%s", $totalRows_lisPcatLN, $queryString_lisPcatLN);
$srf = "/";


?>