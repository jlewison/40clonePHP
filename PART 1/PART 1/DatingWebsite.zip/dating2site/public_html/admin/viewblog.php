<?php
if ( !defined( 'SMARTY_DIR' ) ) {

	include_once( '../init.php' );
}
include( 'sessioninc.php' );
include_once(LIB_DIR . 'blog_class.php');

$blog = new Blog(true);

// Delete the comment
//
if ( $_GET['action'] == 'delete' && $_GET['delete'] == 'Y'  ) {

      $blog->adminDeleteComment($_REQUEST['deleteid']);
}

$blog->addBlogView($_REQUEST['id'], $_SESSION['AdminId']);
$blog->loadBlog($_REQUEST['id']);

if ( $_POST['action'] == 'add_comment' ) {

   $blog->addComment($_REQUEST['id'], $_SESSION['AdminId']);
   $blog->prepComment();
   $comments = $blog->getComment();
   $t->assign ( 'comment', $comments['comment'] );

   $t->assign ( 'error_message', $blog->getErrorMessage() );
}
else {

   $t->assign ( 'error_message', '' );
   $t->assign ( 'comment', '' );
}

$blog_data = $blog->getData();

$blog->loadSettings( $blog_data['userid'] || $blog_data['adminid'] );

$t->assign('blog',  $blog_data);
$t->assign('pref',  $blog->getSettings());
$t->assign('numcomments',  $blog->getCommentCount($_REQUEST['id']));
$t->assign('comments',  $blog->getAllComments($_REQUEST['id']));
$t->assign('now',  date('Y-m-d') );
$t->assign('allowcomments',  $blog->allowComments($_REQUEST['id'], $_SESSION['AdminId']) );


$js = '<script type="text/javascript" src="' . DOC_ROOT . 'javascript/functions.js"></script>';
$t->assign('addtional_javascript', $js);

$t->assign('lang', $lang);

$t->assign( 'rendered_page', $t->fetch( 'admin/viewblog.tpl' ) );

$t->display ( 'admin/index.tpl' );


?>
