<?php

/**
 * Models that is related to friends
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 2007-12-14
 */
class Friendsmodel extends Model
{
		function Friendsmodel()
		{
				parent::Model();
				$this->load->model('usermodel');
		} //end method
		function getFriends($userId, $orderBy = 'datestamp desc', $start = '', $limit = '')
		{
				$friendsArray = array();
				$orderByQuery = '';
				if (trim($orderBy) != '') $orderByQuery = ' ORDER BY ' . $orderBy;
				$query = "SELECT friend_id AS FriendId FROM `friends_list` WHERE user_id='$userId' and approved_status='yes'
					UNION
					SELECT user_id as FriendId FROM `friends_list` WHERE friend_id='$userId' and approved_status='yes'";
				if (trim($limit) != '' && is_numeric($limit))
				{
						if (trim($start) != '' && is_numeric($start)) $query .= ' LIMIT ' . $start . ', ' . $limit;
						else  $query .= ' LIMIT ' . $limit;
				}
				$resFriends = $this->db->query($query);
				if ($resFriends->num_rows() > 0)
				{
						foreach ($resFriends->result_array() as $friendsRow)
						{
								$friendsArray[] = $friendsRow['FriendId'];
						}
				} //end res
				return $friendsArray;
		} //end getFriends()
		function getFriendsCount($userId)
		{
				$query = "SELECT friend_id AS FriendId FROM `friends_list` WHERE user_id='$userId' and approved_status='yes'
					UNION
					SELECT user_id as FriendId FROM `friends_list` WHERE friend_id='$userId' and approved_status='yes' ";
				$resFriends = $this->db->query($query);
				return $resFriends->num_rows();
		} //end getFriends()
		function notesCount($userIds)
		{
				$query = "SELECT count(n.notes_id) as all_count FROM notes as n WHERE is_deleted ='0' AND n.user_id IN(" . $userIds . ")";
				$resFriends = $this->db->query($query);
				$count = 0;
				if ($resFriends->num_rows() > 0)
				{
						$friendsRow = $resFriends->result_array();
						$count = $friendsRow[0]['all_count'];
				} //end res
				return $count;
		} //end getFriends()
		function recentlyTagged($friendsId)
		{
				//$strSql		=	"SELECT u.username, nt.user_id, count(nt.notes_id) AS cntTags,date_format((SELECT s.date_created FROM notes_tags AS s WHERE s.user_id = nt.user_id ORDER BY s.date_created DESC LIMIT 0,1),'%M %D %Y') AS date_info FROM notes_tags AS nt INNER JOIN notes AS n ON n.notes_id = nt.notes_id AND n.is_deleted = '0' AND n.is_approved = 'Y' INNER JOIN users AS u ON u.user_id = nt.user_id AND nt.user_id IN (". $friendsId .") GROUP BY u.username,u.user_id ORDER BY date_info DESC";
				$strSql = "SELECT u.username, nt.user_id, IFNULL(ns.network_city,'') AS network_name ,count(nt.notes_id) AS cntTags,
						date_format((SELECT s.date_created FROM notes_tags AS s WHERE s.user_id = nt.user_id ORDER BY s.date_created DESC LIMIT 0,1),'%M %D %Y') AS date_info
						FROM notes_tags AS nt
						INNER JOIN notes AS n ON n.notes_id = nt.notes_id AND n.is_deleted = '0' AND n.is_approved = 'Y'
						INNER JOIN users AS u ON u.user_id = nt.user_id AND nt.user_id IN (" . $friendsId . ")
						LEFT JOIN networks AS ns ON ns.network_id IN (SELECT nus.network_id FROM  network_users AS nus WHERE nus.user_id = nt.user_id AND nus.is_deleted = '0') AND ns.network_type = 'region'  AND ns.network_status = 'enabled'
						WHERE nt.user_id IN (" . $friendsId . ")
						GROUP BY u.username,u.user_id, ns.network_city ORDER BY date_info, cntTags DESC";
				$resTags = $this->db->query($strSql);
				$resArray = array();
				if ($resTags->num_rows() > 0)
				{
						foreach ($resTags->result_array() as $resRow)
						{
								$resArray[$resRow['user_id']] = $resRow;
						}
				}
				return $resArray;
		}
		#***************************************************************************
		#Method			: deleteFriend
		#Description	: delete the given friend id form current users friend list
		#Author			: ilayaraja_22ag06
		#***************************************************************************
		function deleteFriend($friendId)
		{
				if ($this->usermodel->isMember($friendId))
				{
						$sql = 'DELETE FROM friends_list WHERE (user_id=' . $this->session->userdata('user_id') . ' AND friend_id=' . $friendId . ') OR (user_id=' . $friendId . ' AND friend_id=' . $this->session->userdata('user_id') . ')';
						$res = $this->db->query($sql);
						if ($this->db->affected_rows() > 0) return true;
						else  return false;
				}
				else  return false;
		} //end deleteFriend()
		############################################################################
		#Method			: isEmail()
		#Type			: sub
		#Description	: check for valid email
		#Author			: ilayaraja_22ag06
		############################################################################
		function isEmail($email)
		{
				$pattern = "^[a-zA-Z0-9]([a-zA-Z0-9]*\_[a-zA-Z0-9]+)*([a-zA-Z0-9\-]*\.[a-zA-Z0-9\-]+)*[a-zA-Z0-9]*@[a-zA-Z0-9]{2,}\.[a-zA-Z0-9]{2,}(\.[a-zA-Z0-9]{2,})?$";
				if (!ereg($pattern, $email))
				{
						//$this->validation->set_message('_isMail', 'The %s Entered is Not valid ');
						return false;
				}
				else  return true;
		}
		############################################################################
		#Method			: isRegistered()
		#Type			: sub
		#Description	: checks whether the given email id registered or not
		#Author			: ilayaraja_22ag06
		############################################################################
		function isRegistered($email)
		{
				$sql = "SELECT user_id FROM users WHERE email='$email'";
				$res = $this->db->query($sql);
				if ($res->num_rows() > 0) return true;
				else  return false;
		}
		############################################################################
		#Method			: isConfirmed()
		#Type			: sub
		#Description	: checks whether already sent invitation and confirmed or not
		#Author			: ilayaraja_22ag06
		############################################################################
		function isConfirmed($email)
		{
				$friendSql = "SELECT user_id FROM users WHERE email='$email'";
				$friendRes = $this->db->query($friendSql);
				if ($friendRes->num_rows() > 0)
				{
						$friendRs = $friendRes->row();
						$sql = "SELECT friends_list_id FROM friends_list WHERE approved_status='yes' AND user_id=" . $this->session->userdata('user_id') . " AND friend_id=" . $friendRs->user_id;
						$res = $this->db->query($sql);
						if ($res->num_rows() > 0) return true;
						else  return false;
				}
				else  return false;
		} //END isConfirmed()
		############################################################################
		#Method			: isInvited()
		#Type			: sub
		#Description	: checks whether already sent invitation for this email id
		#Author			: ilayaraja_22ag06
		############################################################################
		function isInvited($email)
		{
				$friendSql = "SELECT user_id FROM users WHERE email='$email'";
				$friendRes = $this->db->query($friendSql);
				if ($friendRes->num_rows() > 0)
				{
						$friendRs = $friendRes->row();
						$sql = "SELECT friends_list_id FROM friends_list WHERE user_id=" . $this->session->userdata('user_id') . " AND friend_id=" . $friendRs->user_id;
				}
				else  $sql = "SELECT friends_list_id FROM friends_list WHERE user_id=" . $this->session->userdata('user_id') . " AND friend_id=0 AND friend_mail='$email'";
				$res = $this->db->query($sql);
				if ($res->num_rows() > 0) return true;
				else  return false;
		}
		############################################################################
		#Method			: newInvitation()
		#Type			: sub
		#Description	: store new friend invitation to friends_list table
		#Author			: ilayaraja_22ag06
		############################################################################
		function newInvitation($inviteValues)
		{
				if ($this->isInvited($inviteValues['friend_email']) == false)
				{
						$status = 'no';
						$userId = $this->session->userdata('user_id');
						$newSQL = 'INSERT INTO friends_list
							(user_id, approved_status,friend_id,friend_mail,invite_message,datestamp)
							VALUES
							(	' . $userId . ',
								' . $this->db->escape($status) . ',
								' . $inviteValues['friend_id'] . ',
								' . $this->db->escape($inviteValues['friend_email']) . ',
								' . $this->db->escape($inviteValues['invite_message']) . ',CURRENT_TIMESTAMP
							)';
						$this->db->query($newSQL);
						if ($this->db->affected_rows() == 1)
						{
								$inviteId = $this->db->insert_id();
								return $inviteId;
						}
						else  return false;
				}
				else
				{
						return false;
				}
		} //end newInvitation()
		function recentlyUpdated($userId = '', $userStatus = 'active', $orderBy = 'last_modified desc', $start = '', $limit = '')
		{
				if ($userId == '') $userId = $this->session->userdata('user_id');
				$friendsList = $this->getFriends($userId);
				$friendsArray = array();
				if (!empty($friendsList))
				{
						$this->db->select(' user_id AS FriendId');
						$this->db->from('users');
						$this->db->where('user_status', $userStatus);
						$this->db->where_in('user_id', $friendsList);
						if (trim($orderBy) != '') $this->db->order_by($orderBy);
						if (trim($limit) != '' && is_numeric($limit))
						{
								if (trim($start) != '' && is_numeric($start)) $this->db->limit($limit, $start);
								else  $this->db->limit($limit);
						}
						$resQuery = $this->db->get();
						if ($resQuery->num_rows() > 0)
						{
								foreach ($resQuery->result_array() as $resRow)
								{
										$usrArray = $this->usermodel->getDetails($resRow['FriendId']);
										$friendsArray[] = $usrArray[$resRow['FriendId']];
								}
						} //end res
				} //
				return $friendsArray;
		} //end getFriends()
		function recentlyUpdatedCount($userId = '', $userStatus = 'active')
		{
				if ($userId == '') $userId = $this->session->userdata('user_id');
				$friendsList = $this->getFriends($userId);
				if (!empty($friendsList))
				{
						$this->db->select(' user_id AS FriendId');
						$this->db->from('users');
						$this->db->where('user_status', $userStatus);
						$this->db->where_in('user_id', $friendsList);
						return $this->db->count_all_results();
				}
				else  return 0;
		}
		function recentlyadded($userId = '', $start = '', $limit = '')
		{
				$limitCond = '';
				if ($userId == '') $userId = $this->session->userdata('user_id');
				if (trim($start) != '' and trim($limit) != '') $limitCond = ' LIMIT ' . $start . ',' . $limit;
				$friendsArray = array();
				$query = "SELECT r.FriendId AS FriendId,r.datestamp FROM
						(
						SELECT friend_id AS FriendId,datestamp FROM `friends_list` WHERE user_id='$userId' and approved_status='yes'
						UNION
						SELECT user_id as FriendId, datestamp FROM `friends_list` WHERE friend_id='$userId' and approved_status='yes'
						) AS r WHERE r.datestamp >= (CURRENT_TIMESTAMP - INTERVAL 1 WEEK) ORDER BY r.datestamp DESC" . $limitCond;
				$resFriends = $this->db->query($query);
				if ($resFriends->num_rows() > 0)
				{
						foreach ($resFriends->result_array() as $friendsRow)
						{
								$usrArray = $this->usermodel->getDetails($friendsRow['FriendId']);
								$friendsArray[] = $usrArray[$friendsRow['FriendId']];
						}
				} //end res
				return $friendsArray;
		} //end getFriends()
		function onlinenow($userId = '', $userStatus = 'active', $orderBy = 'last_modified desc', $start = '', $limit = '')
		{
				if ($userId == '') $userId = $this->session->userdata('user_id');
				$friendsList = $this->getFriends($userId);
				$friendsArray = array();
				if (!empty($friendsList))
				{
						$this->db->select(' user_id AS FriendId');
						$this->db->from('users');
						$this->db->where('user_status', $userStatus);
						$this->db->where_in('user_id', $friendsList);
						$this->db->where('logged_in', '1');
						$this->db->where(' (UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(last_login)) < ' . $this->config->item("sess_expiration"));
						if (trim($orderBy) != '') $this->db->order_by($orderBy);
						if (trim($limit) != '' && is_numeric($limit))
						{
								if (trim($start) != '' && is_numeric($start)) $this->db->limit($limit, $start);
								else  $this->db->limit($limit);
						}
						$resQuery = $this->db->get();
						if ($resQuery->num_rows() > 0)
						{
								foreach ($resQuery->result_array() as $resRow)
								{
										$usrArray = $this->usermodel->getDetails($resRow['FriendId']);
										$friendsArray[] = $usrArray[$resRow['FriendId']];
								}
						} //end res
				} //
				//$query		= "SELECT user_id AS FriendId FROM `users` WHERE user_id IN($friendsList) AND user_status='active' AND logged_in='1' AND (UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(last_login)) < " . $this->config->item('sess_expiration');
				//$resFriends	= $this->db->query($query);
				//if($resFriends->num_rows() > 0)
				//{
				//foreach($resFriends->result_array() as $friendsRow)
				//{
				//$usrArray		=  $this->usermodel->getDetails($friendsRow['FriendId']);
				//$friendsArray[] = $usrArray[$friendsRow['FriendId']];
				//}
				//}//end res
				return $friendsArray;
		} //end getFriends()
		function getRequest($userId = '')
		{
				if ($userId == '') $userId = $this->session->userdata('user_id');
				$this->db->select('friends_list.friends_list_id, users.user_id, users.avatar_ext, users.username');
				$this->db->from('friends_list');
				$this->db->join('users', 'friends_list.user_id=users.user_id', 'INNER');
				$this->db->where('friends_list.friend_id', $userId);
				$this->db->where('friends_list.approved_status', 'no');
				$friendRequestQuery = $this->db->get();
				$friendRequest = array();
				if ($friendRequestQuery->num_rows() > 0)
				{
						foreach ($friendRequestQuery->result_array() as $friendRequestRow)
						{
								$friendRequestRow['avatar'] = getAvatar($friendRequestRow['user_id'], $friendRequestRow['avatar_ext'], 'thumb');
								$friendRequest[] = $friendRequestRow;
						}
				}
				return $friendRequest;
		}
		#***************************************************************************
		#Method			: getRequestCount
		#Description	: returns friends request count for the user
		#Author
		#***************************************************************************
		function getRequestCount($userId = '')
		{
				if ($userId == '') $userId = $this->session->userdata('user_id');
				$userId = $this->session->userdata('user_id');
				$requestCountQuery = $this->db->query('SELECT friends_list_id FROM friends_list WHERE approved_status=\'no\' AND friend_id = ' . $userId . ' GROUP BY friends_list_id');
				return $requestCountQuery->num_rows();
		}
		function acceptRequest($requestId)
		{
				$this->db->where('friends_list_id', $requestId);
				$this->db->update('friends_list', array('approved_status' => 'yes'));
		}
		function rejectRequest($requestId)
		{
				$this->db->where('friends_list_id', $requestId);
				$this->db->delete('friends_list');
		}
		#***************************************************************************
		#Method			: getInvitation($invitationId)
		#Description	: returns invitation records for the given invitation id
		#***************************************************************************
		function getInvitation($invitationId)
		{
				$this->db->select('user_id, approved_status, datestamp, friend_id, friend_mail, invite_message');
				$this->db->from('friends_list');
				$this->db->where('friends_list_id', $invitationId);
				$this->db->limit(1, 0);
				$query = $this->db->get();
				$friends = array();
				if ($query->num_rows() > 0)
				{
						$friends = $query->row_array();
				}
				return $friends;
		} //end getVideos()
		function isFriend($friendId, $userId = '')
		{
				$userId = (trim($userId) == '') ? $this->session->userdata('user_id') : $userId;
				$this->db->from('friends_list');
				$this->db->where('approved_status', 'yes');
				$this->db->where('((user_id=' . $userId . ' AND friend_id=' . $friendId . ')');
				$this->db->or_where('(friend_id=' . $userId . ' AND user_id=' . $friendId . '))');
				$this->db->limit(1, 0);
				$isFriendQuery = $this->db->get();
				//echo $this->db->last_query();
				if ($isFriendQuery->num_rows() > 0) return true;
				else  return false;
		}
}

?>