	<div class="fTop"><img style="float:left;" src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/f1.gif" alt="footer border 1" /><img style="float:right;" src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/f2.gif" alt="footer border 2" /></div>
	<div class="footer">
		<p class="fnav">
			<a href="<?php echo("$path");?>"><?php echo("$lang_11");?></a> | 
			<a href="<?php echo("$path");?>new-links.php"><?php echo("$lang_12");?></a> | 
			<?php if($p_top == 'Y') { ?> 
				<a href="<?php echo("$path");?>links.php"><?php echo("$lang_13");?></a> | 
			<?php } else {} ?>
			<a href="<?php echo("$path");?>submit.php?su_categ="><?php echo("$lang_14");?></a> | 
			<?php if($p_about == 'Y') { ?> 
				<a href="<?php echo("$path");?>about.php"><?php echo("$lang_22");?></a> | 
			<?php } else {} ?>
			<?php if($p_terms == 'Y') { ?> 
				<a href="<?php echo("$path");?>terms.php"><?php echo("$lang_16");?></a> | 
			<?php } else {} ?>
			<a href="<?php echo("$path");?>contact.php"><?php echo("$lang_23");?></a>
		</p>
		<p>&copy; <?php echo date("Y");?>  <a href="<?php echo("$path");?>" target="_blank" title="<?php echo("$sitetitle");?>"><?php echo("$sitetitle");?></a> &nbsp;&nbsp;&nbsp;&nbsp;<?php echo("$lang_149");?> <a href="http://www.linkbidscript.com/"><?php echo("$lang_150");?></a> &nbsp;&nbsp;&nbsp;&nbsp;Template by <a href="http://www.webmasterserve.com/webmaster-marketplace/">Webmaster Marketplace</a>
	</div>
	<div class="fBottom"><img style="float:left;" src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/f3.gif" alt="footer border 3" /><img style="float:right;" src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/f4.gif" alt="footer border 4" /></div>
</div>
