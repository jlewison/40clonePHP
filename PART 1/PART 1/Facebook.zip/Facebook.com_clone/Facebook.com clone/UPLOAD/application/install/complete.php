<?php
	session_start();
	
	if($_SESSION['baseurl'] == '')
		$url	= '../../';
	else
		$url	= $_SESSION['baseurl']; 
?>
<html>
<head>
<title>Installation Complete</title>
<META HTTP-EQUIV="refresh" CONTENT="5;URL=<?php echo $url; ?>">
</head>
<body>

	Installation Complete, will be redirected to the home page. If not <a href="<?php echo $url; ?>">click here</a>.

</body>
</html>
