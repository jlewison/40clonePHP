//Apertura Gallery

function OpenGallery( file,title,w,h ){
	window.open('http://casino.tv/include/Gallery.asp?file='+ file +'&title=' + title ,'Gallery','width=' + w + ',height=' + h )
}

//caricamento giochi

function LoadGame( id ){
var session = '<% =Session("UserName") %>'

  //if (session != "" ) {	
	window.open('http://casino.tv/freegames/LoadGame.asp?id=' + id ,'Gioco',' height=450,width=470,resizable=yes')
  /*}	
  else{
  	window.location.replace("/Error/loginerror.asp")
  }*/
  
}

//Controllo autenticazione
function checkMember( Myform ){
	if (Myform.uname.value=="" || Myform.password.value=="") {
		return false
	}
	
	return true
}


//script x status bar
function hidestatus(){
	//window.status='Casino.tv'
return true
}

if (document.layers)
document.captureEvents(Event.MOUSEOVER | Event.MOUSEOUT | Event.MOUSEDOWN | Event.DBLCLICK)
document.onmouseover=hidestatus
document.onmouseout=hidestatus
document.onmousedown=hidestatus
document.ondblclick=hidestatus



//apertura chat
function aprichat(){
	window.open('http://casino.tv/community/bhgbsda/index.asp?lingue=' + Jlingua,'chatWindow','height=550,width=600,menubar=no,resizable,status')
}

function OpenWindow(ind){
	window.open(ind,'CliccaBanner','')
}

//script caricamnto banner
function Banner(type){
 if (type !='' ){
	//document.write('<SCRIPT LANGUAGE="JavaScript" SRC="http://216.94.0.164/?DC=' + type + '&JS=Y&TARGET=_blank"></SCRIPT>')
	//document.write('<noscript><A HREF="http://216.94.0.164/?SHT=' + type + '" TARGET=_blank >')
	//document.write('<IMG SRC="http://216.94.0.164/?SIT=' + type + '" border=0 ></A></noscript>')
	
	// Cioco clicca banner
	document.write('<A HREF=# onclick=OpenWindow("/freegames/clicca/openUrl.asp?Link=http://216.94.0.164/?SHT=' + type + '");return false  >')
	document.write('<IMG SRC="http://216.94.0.164/?SIT=' + type + '" border=0 ></A>')
 }
}

// inizio funzione per il controllo della validit� di un indirizzo email
function checkEmail(field) 
	{
	
	var goodEmail = field.value.match(/\b(^(\S+@).+((\.com)|(\.net)|(\.edu)|(\.mil)|(\.gov)|(\.org)|(\..{2,2}))$)\b/gi);

	if (goodEmail)
		{
   		return true
		}
	else
		{
   		return false
   		}
	}
// fine


	function Delete( obj ){
		obj.value=''
	}

	
//Controllo campi
function CheckField( MyForm ){
	
		//alert( MyForm.elements.length)
		
	
		for(var i=0;i< MyForm.elements.length ;i++){
		   if (MyForm.item(i) != null){
		   		Field = MyForm.item(i)
				
				//alert("//"+Field.type+"//"+Field.name+"//"+Field.OBL)
						
		   		if (Field.OBL == '-1'){
					switch (Field.type)
					{
						case 'text':
							if (Field.name.toLowerCase().indexOf('mail')>=0)
							{
			
								if ( !checkEmail(Field) ){alert( AlertMailText );Field.focus();return false}
							}
							else{
								if (Field.value ==""){alert( Field.name + ' - ' + AlertText );Field.focus();return false}
							}
							break;
						case 'checkbox':
							if ( !Field.checked ){alert( Field.name + ' - ' + AlertText );Field.focus();Field.checked=true;return false}
							break;
						case 'select-one':
							if ( Field.value=='' ){alert( Field.name + ' - ' + AlertText );Field.focus();return false}
							break;
						case 'password':
							
							if ( Field.value=='' && Field.value.length<4 ){alert( Field.name + ' - ' + AlertText );Field.focus();return false}
							break;
					}
				}
				
		   
		   
		   }
		}
		
		return true
		
	}

