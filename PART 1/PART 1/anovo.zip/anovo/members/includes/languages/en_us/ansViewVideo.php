<?php
$LANG['pg_title'] = '';
$LANG['error_video'] = 'Invalid Video';
$LANG['close'] = 'Close';
?>