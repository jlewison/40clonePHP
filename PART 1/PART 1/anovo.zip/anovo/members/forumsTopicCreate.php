<?php
require_once ('../common/config.inc.php');
$CFG['lang']['include_files'][] = 'members/includes/languages/%s/forumsTopicCreate.php';
$CFG['lang']['include_files'][] = 'members/includes/languages/%s/forumsRightLinks.php';
$CFG['html']['header'] = 'members/includes/languages/%s/html_header.php';
$CFG['html']['footer'] = 'members/includes/languages/%s/html_footer.php';
$CFG['lang']['include_files'][] = 'common/languages/%s/help.inc.php';
$CFG['lang']['include_files'][] = 'common/configs/config_forums.inc.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['mods']['include_files'][] = 'common/classes/class_ForumHandler.lib.php';
$CFG['db']['is_use_db'] = true;
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class ForumTopicFormHandler extends ForumHandler
{
		public $forum_details_arr;
		public function countForumTopic($forum_id, $max_allowed, $err_tip = '')
		{
				$sql = 'SELECT COUNT(ft.topic_id) AS count ' . 'FROM ' . $this->CFG['db']['tbl']['forum_topics'] . ' AS ft ' . 'WHERE ft.forum_id = ' . $this->dbObj->Param($forum_id) . ' ' . 'AND ft.user_id = ' . $this->dbObj->Param($this->CFG['user']['user_id']) . ' ';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($forum_id, $this->CFG['user']['user_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = $rs->FetchRow();
				if ($row['count'] < $max_allowed)
				{
						return true;
				}
				$err_tip = str_replace('{COUNT}', $row['count'], $err_tip);
				$this->setCommonErrorMsg($err_tip);
				return false;
		}
		public function chkLength($field_name, $err_tip = '')
		{
				$url_len = strlen($this->fields_arr[$field_name]);
				if ($url_len < 3 || $url_len > 20)
				{
						$this->fields_err_tip_arr[$field_name] = $err_tip;
						return false;
				}
				return true;
		}
		public function chkIsNotExists($forum_topic, $forum_id, $err_tip = '')
		{
				$sql = 'SELECT COUNT(topic_id) AS count ' . 'FROM ' . $this->CFG['db']['tbl']['forum_topics'] . ' ' . 'WHERE forum_id = ' . $this->dbObj->Param($forum_id) . ' ' . 'AND forum_topic = ' . $this->dbObj->Param($forum_topic) . ' ';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($forum_id, $forum_topic));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = $rs->FetchRow();
				if ($row['count'])
				{
						$this->fields_err_tip_arr['forum_topic'] = $err_tip;
						return false;
				}
				return true;
		}
		public function createForumTopic()
		{
				$topic_id = $this->insertForumTopic();
				if ($topic_id)
				{
						$this->insertForumResponse($topic_id);
						$this->updateForums($this->fields_arr['forum_id']);
						$this->updateUsersAnsLog();
				}
		}
		public function insertForumTopic()
		{
				$sql = 'INSERT INTO ' . $this->CFG['db']['tbl']['forum_topics'] . ' SET ' . 'forum_id = ' . $this->dbObj->Param($this->fields_arr['forum_id']) . ', ' . 'forum_topic = ' . $this->dbObj->Param($this->fields_arr['forum_topic']) . ', ' . 'user_id = ' . $this->dbObj->Param($this->CFG['user']['user_id']) . ', ' . 'total_response = 1, ' . 'total_views = 1, ' . 'last_post_user_id = ' . $this->dbObj->Param($this->CFG['user']['user_id']) . ', ' . 'last_post_date = now(), ' . 'date_added = now()';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['forum_id'], $this->fields_arr['forum_topic'], $this->CFG['user']['user_id'], $this->CFG['user']['user_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return $this->dbObj->Insert_ID();
		}
		public function setError($field_name, $err_tip = '')
		{
				$this->fields_err_tip_arr[$field_name] = $err_tip;
		}
}
$forumstopic = new ForumTopicFormHandler();
if (!chkAllowedModule(array('forums'))) Redirect2URL($CFG['redirect']['dsabled_module_url']);
$forumstopic->setPageBlockNames(array('msg_form_error', 'msg_form_success', 'form_create_topic'));
$forumstopic->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$forumstopic->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$forumstopic->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$forumstopic->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$forumstopic->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$forumstopic->setDBObject($db);
$forumstopic->setCfgLangGlobal($CFG, $LANG);
$forumstopic->setFormField('forum_id', '');
$forumstopic->setFormField('forum_topic', '');
$forumstopic->setFormField('forum_response', '');
$forumstopic->setAllPageBlocksHide();
if ($forumstopic->isFormGETed($_GET, 'forum_id'))
{
		$forumstopic->sanitizeFormInputs($_GET);
		$forumstopic->chkIsNotEmpty('forum_id', $LANG['forumstopic_err_tip_compulsory']) and $forumstopic->chkIsNumeric('forum_id', $LANG['forumstopic_err_tip_compulsory']) and $forumstopic->isValidForumId($forumstopic->getFormField('forum_id'), $LANG['forumstopic_err_tip_invalid_forum_id']);
		$forumstopic->isValidFormInputs() and $forumstopic->countForumTopic($forumstopic->getFormField('forum_id'), $CFG['admin']['forums']['topic']['max_allowed'], $LANG['forumstopic_err_tip_cannot_create_forum_topic']);
		if (!$forumstopic->isAllowedToAsk())
		{
				$forumstopic->setCommonErrorMsg($LANG['info_not_allowed_to_post']);
		}
		if ($forumstopic->isValidFormInputs())
		{
				$forumstopic->setPageBlockShow('form_create_topic');
		}
		else
		{
				$forumstopic->setPageBlockShow('msg_form_error');
		}
		if ($forumstopic->isFormPOSTed($_POST, 'forumstopic_submit'))
		{
				$forumstopic->sanitizeFormInputs($_POST);
				$forumstopic->chkIsNotEmpty('forum_topic', $LANG['forumstopic_err_tip_compulsory']) and $forumstopic->chkIsNotExists($forumstopic->getFormField('forum_topic'), $forumstopic->getFormField('forum_id'), $LANG['forumstopic_err_tip_topic_exists']);
				$forumstopic->chkIsNotEmpty('forum_response', $LANG['forumstopic_err_tip_compulsory']);
				if ($forumstopic->isValidFormInputs())
				{
						$forumstopic->createForumTopic();
						$forumstopic->setAllPageBlocksHide();
						$forumstopic->setPageBlockShow('form_create_topic');
						Redirect2URL(getUrl('forumsTopics.php?forum_id=' . $forumstopic->getFormField('forum_id'), 'forum/' . $forumstopic->getFormField('forum_id') . '/'));
				}
				else
				{
						$forumstopic->setAllPageBlocksHide();
						$forumstopic->setPageBlockShow('msg_form_error');
						$forumstopic->setPageBlockShow('form_create_topic');
				}
		}
		if ($forumstopic->isFormPOSTed($_POST, 'forumstopic_cancel'))
		{
				$forumstopic->sanitizeFormInputs($_POST);
				Redirect2URL(getUrl('forumsTopics.php?forum_id=' . $forumstopic->getFormField('forum_id'), 'forum/' . $forumstopic->getFormField('forum_id') . '/'));
		}
}
else
{
		$forumstopic->setAllPageBlocksHide();
		Redirect2URL(getUrl('forums.php', 'forum/'));
}



?>
<script type="text/javascript" language="javascript">
	var palette_url = '<?php echo $CFG['site']['url'] . 'admin/palette.htm'; ?>';
	var block_arr= new Array('selMsgConfirm');
</script>
<div id="selForumTopicCreate">
	<h2 id="selForumTitle"><span>
		<a href="<?php echo getUrl('forums.php', 'forum/'); ?>"><?php echo $LANG['forumlistall_title_index']; ?></a>
		&nbsp;-&nbsp;
		<a href="<?php echo getUrl('forumsTopics.php?forum_id=' . $forumstopic->getFormField('forum_id'), 'forum/' . $forumstopic->getFormField('forum_id') . '/'); ?>">
			<?php echo $forumstopic->forum_details_arr['forum_title']; ?></a>
		&nbsp;-&nbsp;
		<?php echo $LANG['forumstopic_topic_start']; ?>
	</span></h2>
<?php
if ($forumstopic->isShowPageBlock('msg_form_error'))
{
?>
<div id="selMsgError">
	 <p><?php echo $LANG['msg_error_sorry'] . ' ' . $forumstopic->getCommonErrorMsg(); ?></p>
</div>
<?php
}
if ($forumstopic->isShowPageBlock('msg_form_success'))
{
?>
<div id="selMsgSuccess">
 	<p><?php echo $LANG['forumstopic_success']; ?></p>
</div>
<?php
}
if ($forumstopic->isShowPageBlock('form_create_topic'))
{
?>
<div id="selShowCreateForum">
 <div id="selGroupForumPost">
  <h3 id="selBackToForum">
		<a href="<?php echo getUrl('forumsTopics.php?forum_id=' . $forumstopic->getFormField('forum_id'), 'forum/' . $forumstopic->getFormField('forum_id') . '/'); ?>">
			<?php echo $LANG['forumlistall_back_topic']; ?>
		</a>
	</h3>
</div>
	<form name="selFormCreateForum" id="selFormCreateForum" method="post" action="<?php echo $_SERVER['REQUEST_URI']; ?>" autocomplete="off" onsubmit="return getHTMLSource('rte1', 'selFormCreateForum', 'forum_response');">
		<table summary="<?php echo $LANG['forumstopic_tbl_summary']; ?>" class="clsRichTextTable">
		   	<tr>
				<td class="<?php echo $forumstopic->getCSSFormLabelCellClass('forum_topic'); ?>"><?php ShowHelpTip('forum_topic_subject'); ?><label for="forum_topic"><?php echo $LANG['forumstopic_subject']; ?></label></td>
				<td class="<?php echo $forumstopic->getCSSFormFieldCellClass('forum_topic'); ?>">
					<?php echo $forumstopic->getFormFieldErrorTip('forum_topic'); ?>
					<input type="text" class="clsTextBox" name="forum_topic" id="forum_topic" maxlength="200" tabindex="<?php echo $forumstopic->getTabIndex(); ?>" value="<?php echo $forumstopic->getFormField('forum_topic'); ?>" />
				</td>
		   	</tr>

			 <?php if (strchr(strtolower($_SERVER['HTTP_USER_AGENT']), "opera") == '')
		{ ?>
			<tr>
				<td class="<?php echo $forumstopic->getCSSFormFieldCellClass('forum_response'); ?>" colspan="2">
					<?php echo $forumstopic->getFormFieldErrorTip('forum_response'); ?>
					<?php populateRichTextEdit('forum_response', $forumstopic->getFormField('forum_response'), $forumstopic->isValidFormInputs()); ?>
				</td>
		    </tr>
			<?php }
		else
		{ ?>
			<tr>
				<td class="<?php echo $forumstopic->getCSSFormFieldCellClass('forum_response'); ?>" colspan="2">
					<?php echo $forumstopic->getFormFieldErrorTip('forum_response'); ?>
					<textarea class="clsCommonTextArea" name="forum_response" id="forum_response" cols="100" rows="5"><?php echo $forumstopic->getFormField('forum_response'); ?></textarea>
				</td>
		    </tr>
			<?php } ?>
			</tr>
		    <tr>
				<td class="<?php echo $forumstopic->getCSSFormFieldCellClass('submit'); ?>" colspan="2">
					<input type="submit" class="clsSubmitButton" name="forumstopic_submit" id="forumstopic_submit" tabindex="<?php echo $forumstopic->getTabIndex(); ?>" value="<?php echo $LANG['forumstopic_submit']; ?>" />
					&nbsp;&nbsp;
					<input type="submit" class="clsCancelButton" name="forumstopic_cancel" id="forumstopic_cancel" tabindex="<?php echo $forumstopic->getTabIndex(); ?>" value="<?php echo $LANG['forumstopic_cancel']; ?>" />
				</td>
			</tr>
		</table>
		<input type="hidden" name="forum_id" id="forum_id" value="<?php echo $forumstopic->getFormField('forum_id'); ?>" />
	</form>
</div>
<?php
}
?>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>
