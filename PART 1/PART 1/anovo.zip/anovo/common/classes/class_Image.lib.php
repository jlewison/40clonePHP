<?php
class ImageHandler
{
		protected $file_original;
		protected $image_original_width;
		protected $image_original_height;
		protected $image_original_type_code;
		protected $image_original_type_abbr;
		protected $image_original_html_sizes;
		protected $image_resized;
		protected $file_resized;
		protected $image_resized_width;
		protected $image_resized_height;
		protected $image_resized_type_code;
		protected $image_resized_type_abbr;
		protected $image_resized_html_sizes;
		protected $jpeg_quality;
		protected $use_gd2;
		public function ImageHandler($file_original)
		{
				global $ERR;
				$this->clear();
				if (file_exists($file_original))
				{
						$this->file_original = $file_original;
						$this->image_original = $this->imagecreatefromfile($file_original);
						if (!$this->image_original)
						{
								return false;
						}
				}
				else
				{
				}
		}
		public function clear()
		{
				$this->image_original = 0;
				$this->file_original = "";
				$this->image_original_width = 0;
				$this->image_original_height = 0;
				$this->image_original_type_code = 0;
				$this->image_original_type_abbr = "";
				$this->image_original_html_sizes = "";
				$this->image_resized = 0;
				$this->file_resized = "";
				$this->image_resized_width = 0;
				$this->image_resized_height = 0;
				$this->image_resized_type_code = -1;
				$this->image_resized_type_abbr = "";
				$this->image_resized_html_sizes = "";
				$this->set_parameters();
		}
		public function set_parameters($jpeg_quality = "85", $use_gd2 = true)
		{
				$this->jpeg_quality = $jpeg_quality;
				$this->use_gd2 = $use_gd2;
		}
		public function imagecreatefromfile($img_file)
		{
				global $ERR;
				$img = 0;
				$img_sz = getimagesize($img_file);
				switch ($img_sz[2])
				{
						case 1:
								$img = $this->_imagecheckandcreate("ImageCreateFromGif", $img_file);
								$img_type = "GIF";
								break;
						case 2:
								$img = $this->_imagecheckandcreate("ImageCreateFromJpeg", $img_file);
								$img_type = "JPG";
								break;
						case 3:
								$img = $this->_imagecheckandcreate("ImageCreateFromPng", $img_file);
								$img_type = "PNG";
								break;
						case 4:
								$img = $this->_imagecheckandcreate("ImageCreateFromSwf", $img_file);
								$img_type = "SWF";
								break;
						default:
								$img = 0;
								$img_type = "UNKNOWN";
								break;
				}
				if ($img)
				{
						$this->image_original_width = $img_sz[0];
						$this->image_original_height = $img_sz[1];
						$this->image_original_type_code = $img_sz[2];
						$this->image_original_type_abbr = $img_type;
						$this->image_original_html_sizes = $img_sz[3];
				}
				else
				{
						$this->clear();
				}
				return $img;
		}
		public function _imagecheckandcreate($function, $img_file)
		{
				global $ERR;
				if (function_exists($function))
				{
						$img = false;
						$img = @$function($img_file);
				}
				else
				{
						$img = false;
				}
				return $img;
		}
		public function resize($desired_width, $desired_height, $mode = "-")
		{
				global $ERR;
				if ($desired_width == "*" && $desired_height == "*")
				{
						$this->image_resized = $this->image_original;
						return true;
				}
				if ($this->image_original_width < $desired_width && $this->image_original_height < $desired_height)
				{
						$new_width = $this->image_original_width;
						$new_height = $this->image_original_height;
				}
				else
				{
						switch ($mode)
						{
								case "-":
								case '+':
										if ($desired_width != "*") $mult_x = $desired_width / $this->image_original_width;
										if ($desired_height != "*") $mult_y = $desired_height / $this->image_original_height;
										$ratio = $this->image_original_width / $this->image_original_height;
										if ($desired_width == "*")
										{
												$new_height = $desired_height;
												$new_width = $ratio * $desired_height;
										} elseif ($desired_height == "*")
										{
												$new_height = $desired_width / $ratio;
												$new_width = $desired_width;
										}
										else
										{
												if ($mode == "-")
												{
														if ($this->image_original_height * $mult_x < $desired_height)
														{
																$new_width = $desired_width;
																$new_height = $this->image_original_height * $mult_x;
														}
														else
														{
																$new_width = $this->image_original_width * $mult_y;
																$new_height = $desired_height;
														}
												}
												else
												{
														if ($this->image_original_height * $mult_x > $desired_height)
														{
																$new_width = $desired_width;
																$new_height = $this->image_original_height * $mult_x;
														}
														else
														{
																$new_width = $this->image_original_width * $mult_y;
																$new_height = $desired_height;
														}
												}
										}
										break;
								case '0':
										if ($desired_width == "*") $desired_width = $this->image_original_width;
										if ($desired_height == "*") $desired_height = $this->image_original_height;
										$new_width = $desired_width;
										$new_height = $desired_height;
										break;
								default:
										$this->error($ERR["UNKNOWN_RESIZE_MODE"] . "  $mode");
										break;
						}
				}
				if ($this->use_gd2)
				{
						if (function_exists("imagecreatetruecolor"))
						{
								$this->image_resized = imagecreatetruecolor($new_width, $new_height) or $this->error($ERR["GD2_NOT_CREATED"]);
						}
						else
						{
								$this->error($ERR["GD2_UNAVALABLE"] . " ImageCreateTruecolor()");
						}
				}
				else
				{
						$this->image_resized = imagecreate($new_width, $new_height) or $this->error($ERR["IMG_NOT_CREATED"]);
				}
				if ($this->use_gd2)
				{
						if (function_exists("imagecopyresampled"))
						{
								$res = imagecopyresampled($this->image_resized, $this->image_original, 0, 0, 0, 0, $new_width, $new_height, $this->image_original_width, $this->image_original_height) or $this->error($ERR["GD2_NOT_RESIZED"]);
						}
						else
						{
								error($ERR["GD2_UNAVALABLE"] . " ImageCopyResampled()");
						}
				}
				else
				{
						$res = imagecopyresized($this->image_resized, $this->image_original, 0, 0, 0, 0, $new_width, $new_height, $this->image_original_width, $this->image_original_height) or $this->error($ERR["IMG_NOT_RESIZED"]);
				}
		}
		public function fitresize($reqwidth, $reqheight)
		{
				$ratiowidth = $this->image_original_width / $reqwidth;
				$ratioheight = $this->image_original_height / $reqheight;
				if ($this->image_original_width > $reqwidth || $this->image_original_height > $reqheight)
				{
						if ($ratiowidth > $ratioheight)
						{
								$new_width = intval($this->image_original_width / $ratiowidth);
								$new_height = intval($this->image_original_height / $ratiowidth);
						}
						else
						{
								$new_width = intval($this->image_original_width / $ratioheight);
								$new_height = intval($this->image_original_height / $ratioheight);
						}
				}
				else
				{
						$new_width = intval($this->image_original_width);
						$new_height = intval($this->image_original_height);
				}
				if ($this->use_gd2)
				{
						if (function_exists("imagecreatetruecolor"))
						{
								$this->image_resized = imagecreatetruecolor($new_width, $new_height) or $this->error($ERR["GD2_NOT_CREATED"]);
						}
						else
						{
								$this->error($ERR["GD2_UNAVALABLE"] . " ImageCreateTruecolor()");
						}
				}
				else
				{
						$this->image_resized = imagecreate($new_width, $new_height) or $this->error($ERR["IMG_NOT_CREATED"]);
				}
				if ($this->use_gd2)
				{
						if (function_exists("imagecopyresampled"))
						{
								$res = imagecopyresampled($this->image_resized, $this->image_original, 0, 0, 0, 0, $new_width, $new_height, $this->image_original_width, $this->image_original_height) or $this->error($ERR["GD2_NOT_RESIZED"]);
						}
						else
						{
								error($ERR["GD2_UNAVALABLE"] . " ImageCopyResampled()");
						}
				}
				else
				{
						$res = imagecopyresized($this->image_resized, $this->image_original, 0, 0, 0, 0, $new_width, $new_height, $this->image_original_width, $this->image_original_height) or $this->error($ERR["IMG_NOT_RESIZED"]);
				}
		}
		public function output_original($destination_file, $image_type = "JPG")
		{
				return $this->_output_image($destination_file, $image_type, $this->image_original);
		}
		public function output_resized($destination_file, $image_type = "JPG")
		{
				$res = $this->_output_image($destination_file, $image_type, $this->image_resized);
				if (trim($destination_file))
				{
						$sz = getimagesize($destination_file);
						$this->file_resized = $destination_file;
						$this->image_resized_width = $sz[0];
						$this->image_resized_height = $sz[1];
						$this->image_resized_type_code = $sz[2];
						$this->image_resized_html_sizes = $sz[3];
						switch ($this->image_resized_html_sizes)
						{
								case 0:
										$this->image_resized_type_abbr = "GIF";
										break;
								case 1:
										$this->image_resized_type_abbr = "JPG";
										break;
								case 2:
										$this->image_resized_type_abbr = "PNG";
										break;
								case 3:
										$this->image_resized_type_abbr = "SWF";
										break;
								default:
										$this->image_resized_type_abbr = "UNKNOWN";
										break;
						}
				}
				return $res;
		}
		public function _output_image($destination_file, $image_type, $image)
		{
				global $ERR;
				$destination_file = trim($destination_file);
				$res = false;
				if ($image)
				{
						switch ($image_type)
						{
								case 'JPEG':
								case 'JPG':
										$res = imagejpeg($image, $destination_file, $this->jpeg_quality);
										break;
								case 'PNG':
										$res = imagepng($image, $destination_file);
										break;
								case 'GIF':
										$res = imagegif($image, $destination_file);
										break;
								default:
										$this->error($ERR["UNKNOWN_OUTPUT_FORMAT"] . " $image_type");
										break;
						}
				}
				else
				{
						$this->error($ERR["NO_IMAGE_FOR_OUTPUT"]);
				}
				if (!$res) $this->error($ERR["UNABLE_TO_OUTPUT"] . " $destination_file");
				return $res;
		}
		public function error($err = '')
		{
		}
}

?>