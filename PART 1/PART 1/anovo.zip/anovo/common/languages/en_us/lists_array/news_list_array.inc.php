<?php
$LANG_LIST_ARR['news'][1] = array('title' => 'Framework News1!', 'date' => '[ February, 03 / 2008 ] ', 'subject' => 'FAQ, Sitemap and News pages are added in Framework.', );
$LANG_LIST_ARR['news'][2] = array('title' => 'Framework Updation Test', 'date' => '[ February, 03 / 2008 ] ', 'subject' => 'Checking for Framework updation test w.r.t abcHYIP pages.', );
?>