<?php

	$lang['page_title']	= 'Report';
	
	$lang['report_post']	= 'Post your report';
	$lang['report_type']	= 'Report Type';
	$lang['report_comment']	= 'Comment';
	$lang['report_error']	= 'Enter a comment';

?>