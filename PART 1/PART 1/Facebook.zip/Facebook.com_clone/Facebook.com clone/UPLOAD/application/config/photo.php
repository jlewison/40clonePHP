<?php
$config['photo_album_prefix']	= 'album_';
$config['photo_prefix']			= 'photo_';
$config['photo_allowed_types'] 	= 'gif|jpg';
$config['photo_max_size']		= '1024';	//in KB
$config['photo_max_width']  	= '1024';
$config['photo_max_height']  	= '768';
$config['photo_thumb_width']	= 115;
$config['photo_thumb_height']	= 115;
$config['photo_slide_width']	= 550;
$config['photo_slide_height']	= 550;
?>