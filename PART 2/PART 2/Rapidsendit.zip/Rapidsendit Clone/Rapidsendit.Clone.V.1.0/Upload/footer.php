		</td>
	

	<tr>
		<td>
			<img src="images/split_content_middle.gif" width="650" height="49" alt=""></td>
	
	<tr>
		<td align="center" valign="top" background="images/content_bottom.gif">
		
		
Content or Ads Here
		
		</td>
	<tr>
		<td>
			<img src="images/end_content_footer.gif" width="650" height="24" alt=""></td>
	</tr>
		<tr>
		<td>
			<img src="images/bottom.gif" width="650" height="25" alt=""></td>
	</tr>
	
		<tr>
		<td height="25" colspan="3" align="center" valign="middle" background="images/bottom.gif">
			<font size="2" face="Verdana"> <a href="http://www.rapidsendit.com/script" target="new">Powered By: Rapidsendit Clone V.1.0</a></td></font>
	</tr>

</table>
</body>
</html>