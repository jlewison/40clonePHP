<?php

/* This is the program which checks for cache and takes necessary action.
 *  Vijay Nair
 *
 * This works only for the index.php
 *
 */

/* Now we are ready to process */

include_once(FULL_PATH.'includes/internal/osdate_cache.php');

saveCache('page_' . $_SERVER['REQUEST_URI'] , $cached_data);
?>