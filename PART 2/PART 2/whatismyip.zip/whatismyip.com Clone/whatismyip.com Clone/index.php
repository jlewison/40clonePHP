<Created by Katalystz of ProjectW.org>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<HTML>
<HEAD>
<TITLE>WhatIsMyIP Clone</TITLE>
<META NAME="Keywords" CONTENT="IP, address, address translation, proxy, firewall, dhcp, network, games, voice chat, tutorials, find ip address, ip addres, whats ip, ip find, ipconfig, ipaddress">
<META NAME="Description" CONTENT="WhatIsMyIP Clone - The #1 Way To Find Your IP Address !">
<META HTTP-EQUIV="Pragma" CONTENT="no-cache">
<LINK TITLE="" HREF="clone.css" TYPE="text/css" REL="stylesheet">
</HEAD>
<body>
<div align="center">
  <SCRIPT TYPE="text/javascript"><!-- 
    doad2();
//--></SCRIPT>
  <table class="maintable" align="center" border="1" cellSpacing="0" cellPadding="0">
    
    <tr>
      <td class="head"><div align="left"><img src="banner.jpg" width="485" height="150"></div></td>
    <tr>
      <td class="ip"><h1 align="center">Your IP Is 
        <p align="center">
              <?php $ip=@$REMOTE_ADDR;
echo "<b>IP Address= $ip</b>";  ?></h1>
        </p>
      </td>
    </tr>
    <tr>
      <td height="88" class="ad"><img src="ad.gif" width="743" height="87">
      <SCRIPT TYPE="text/javascript"><!-- 
                doad1();
            //--></SCRIPT>        </td>
    <tr>
        <td class="body">
          
          <h3 align="center">WhatIsMyIP Clone is the fastest and easiest way<br />to determine your IP address.</h3>
          <p> <!-- Search Google -->
<center>
<FORM method=GET action="http://www.google.com/search">
<input type=hidden name=ie value=UTF-8>
<input type=hidden name=oe value=UTF-8>
<TABLE bgcolor="#FFFFFF"><tr><td>
<A HREF="http://www.google.com/"></A>
<INPUT TYPE=text name=q size=25 maxlength=255 value="">
<INPUT type=submit name=btnG VALUE="Google Search">
</td></tr></TABLE>
</FORM>
</center>
<!-- Search Google -->
 </p>
          <div align="center">
            <script type="text/javascript"><!-- 
                doad3();
            //--></script>
          Courtesy of WhatIsMyIP Clone          </div></td>
    </tr>
  </table>
</div>
</BODY>
</HTML>

