          </td>
      </tr>
    </table>
  </div>
<!-- MIDDLE SECTION END -->

</div>
<!--PAGE END -->

<!--FOOTER START -->
<div class="footer">
  <div class="bottom">
    <div class="clear"></div>
    <table class="bm" width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td align="center"><a href="<?php echo("$path");?>"><?php echo("$lang_11");?></a> - <a href="<?php echo("$path");?>new-links.php"><?php echo("$lang_12");?></a> - <?php if($p_top == 'Y') { ?> <a href="<?php echo("$path");?>links.php"><?php echo("$lang_13");?></a> - <?php } else {} ?> <a href="<?php echo("$path");?>submit.php?su_categ="><?php echo("$lang_14");?></a> - <?php if($p_about == 'Y') { ?> <a href="<?php echo("$path");?>about.php"><?php echo("$lang_22");?></a> - <?php } else {} ?> <?php if($p_terms == 'Y') { ?> <a href="<?php echo("$path");?>terms.php"><?php echo("$lang_16");?></a> - <?php } else {} ?> <a href="<?php echo("$path");?>contact.php"><?php echo("$lang_23");?></a></td>
      </tr>
    </table>
    <table cellpadding="0" cellspacing="0" width="100%">
      <tr>
        <td align="left" valign="middle">
        
        <div class="copy1">Template by <a href="http://www.sedn.org.uk/" target="_blank">Directory Promotion Network</a><span class="copy">&nbsp;&nbsp;&nbsp; -&nbsp;&nbsp;&nbsp; &copy; <?php echo date("Y");?> <a href="<?php echo("$path");?>" target="_blank" title="<?php echo("$sitetitle");?>"><?php echo("$sitetitle");?></a> &nbsp;&nbsp;&nbsp;-&nbsp;&nbsp;&nbsp; <?php echo("$lang_149");?> <a href="http://www.linkbidscript.com/"><?php echo("$lang_150");?></a></span></div>
        
        </td>
      </tr>
    </table>
  </div>
</div>
<!--FOOTER END -->


<img src="<?php echo("$path");?>template/Green_Light/img/images/copy-bg.gif" class="preload" alt="" /> <img src="<?php echo("$path");?>template/Green_Light/img/images/menu-button-hover.png" class="preload" alt="" /> <img src="<?php echo("$path");?>template/Green_Light/img/images/shape.png" class="preload" alt="" /> <img src="<?php echo("$path");?>template/Green_Light/img/images/thumb-bg.png" class="preload" alt="" /> <img src="<?php echo("$path");?>template/Green_Light/img/images/box-bottom-right.gif" class="preload" alt="" /> <img src="<?php echo("$path");?>template/Green_Light/img/images/alpha-hover.gif" class="preload" alt="" /> <img src="<?php echo("$path");?>template/Green_Light/img/images/cat-bl-hv.gif" class="preload" alt="" />
</body>
</html>
