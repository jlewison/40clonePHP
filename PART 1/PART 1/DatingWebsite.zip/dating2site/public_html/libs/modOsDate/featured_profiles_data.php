<?php

   class featuredProfilesData extends Data {

      var $table = FEATURED_PROFILES_TABLE;

      var $config = array (
  'table' => FEATURED_PROFILES_TABLE,
  'idField' => 'id',
  'addedMsg' => 'Osdate Featured Profiles %s Added',
  'added_err' => 'Can\\\'t Add Osdate Featured Profiles',
  'editMsg' => 'Osdate Featured Profiles %s Updated',
  'editErr' => 'Can\\\'t Update Osdate Featured Profiles',
  'delErr' => 'Can\\\'t Delete Osdate Featured Profiles',
  'delMsg' => 'Osdate Featured Profiles %s Deleted',
  'blankErr' => 'Osdate Featured Profiles Empty',
  'fields' => 
  array (
    'userid' => 
    array (
      'name' => 'userid',
      'description' => 'Userid',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'start_date' => 
    array (
      'name' => 'start_date',
      'description' => 'Start Date',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'end_date' => 
    array (
      'name' => 'end_date',
      'description' => 'End Date',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'must_show' => 
    array (
      'name' => 'must_show',
      'description' => 'Must Show',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 1,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'req_exposures' => 
    array (
      'name' => 'req_exposures',
      'description' => 'Req Exposures',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'exposures' => 
    array (
      'name' => 'exposures',
      'description' => 'Exposures',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 1,
      'duplicate_ok' => 1,
    ),
  ),
);   

      function featuredProfilesData() {
      
         $this->Data($this->config);
      }
   }

?>
