<?php //00461
// Copyright Notice
// Web Site URL:  http://www.zeeways.com
// Script Owner eMail: mail@zeeways.com
// Date: April, 2007
// Script Name: Zeeways Auction Website PHP Script
// Copyright Details: This script is not free.  Do not Remove this Copy Right notice.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the site administrator.');exit(199);
?>
4+oV55rgwOERpT6qTj1ye5amL2WBaofNCt5nH9wiLLNCt5cIULAfC1B5PA2MKI1UbQYw6ksRhdg7
Wi7yItJW73kCJzGGUV1FhtpxAuag+mImxowopPrmOdD/6WiSOlbILJOH7Z6J+M9fKxCiZ0m5SVd+
S5COx5QG9sPMVI1P9wWltta9f7JZMczGDrcHtgmC9npRCrcii69EBy1OaEca4jIk4GXRtynM+8Q8
A6K6Isk5aycw5TZ+YLEebgOq34npzoskINwscd0HWzfSudUIHlLEs+N+YMp65/jG/rJBdVuujhhM
99H0qQYOh0p/kF1BmOjbfx27xK+oOqezLcJKadcRWoHfG/Is7xBuN/nmQfSDBEMfchC2jLj6iNdB
uh/1oOHOEOboNUaUtxIpkiab9DW7hDFg9bos3eP4x/lcK3XwWuxjIeR4cCEwtni/OImXYMjnhrYB
QKIEQ7rtW8lePoE7wXfk8FIeR3kTTsNuU0qf546DCXTR9KbErhvJe1WhrItgznt65Wv1naErkkM9
M3uLDD8U/UvvLMwqo9+lHuGOP5AMfdCc/Rk15draDskyRFWmZmwFgMh6lEt8YMyJMbVphDz/wsqG
AIUblyAvql2RGah//IWDCLR2uHWfuLYNeXptpVFKhztwKuXAoJO2AGXhQQ4tZdBnPkzjqfTPDig3
tUGS1I2OFoGqJDtwWAU5UBIkqlSlitN5yJPqeXRdqQ4wYdjcJRurHuL2+dSr4LVMv+yfnEmj3p5q
aZ1PV8IPCIZw54TTt81upZi9+2S9U2PN2Sn2MktWeYkzNUMSCJh/8rEEtGKHEH8bknJ9BIe=