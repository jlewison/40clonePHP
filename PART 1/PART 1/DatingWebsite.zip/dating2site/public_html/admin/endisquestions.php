<?php
if ( !defined( 'SMARTY_DIR' ) ) {
	include_once( '../init.php' );
}

include ( 'sessioninc.php' );

define( 'PAGE_ID', 'section_mgt' );

if ( !checkAdminPermission( PAGE_ID ) ) {

	header( 'location: not_authorize.php' );
	exit;
}


if( $_POST['frm'] == 'frmGroupDelete' ){

	$section = $_POST['sectionid'];

	foreach( $_POST['txtid'] as $arr ) {

		$id = $arr;

		$sqldel = 'DELETE FROM ! WHERE id = ? and section = ?';

		$result = $db->query( $sqldel, array( QUESTIONS_TABLE, $id, $section ) );
	}

	$sql = 'SELECT id FROM ! WHERE section = ? order by displayorder';

	$questions = $db->getAll( $sql, array( QUESTIONS_TABLE, $section ) );

	$i=1;

	foreach ($questions as $qid ){

		$sql = 'UPDATE ! SET displayorder = ? WHERE id = ?
			AND section = ?';

		$db->query( $sql, array( QUESTIONS_TABLE, $i , $qid['id'], $section ));

		$i++;
	}

	header ( "location: sectionquestions.php?sectionid=" . $section );
	exit;
}

$arr = $_POST[ 'txtcheck' ];

if ( count( $arr ) == 0 ) {

	header( 'location: sectionquestions.php?sectionid=' . $_POST['sectionid'] . '&msg=' . urlencode(get_lang('no_select_msg')) );
	exit;

}
if ( $_POST['groupaction'] == get_lang('enable_selected') ) {

	foreach ( $arr as $id ) {

		$sql = 'UPDATE ! SET enabled = ? WHERE id = ?';

		$result = $db->query( $sql, array( QUESTIONS_TABLE, 'Y', $id ) );

	}

	header ( "location: sectionquestions.php?sectionid=" . $_POST['sectionid'] );
	exit;
} elseif ($_POST['groupaction'] == get_lang('disable_selected') ) {

	foreach ( $arr as $id ) {

		$sql = 'UPDATE ! SET enabled = ? WHERE id = ?';

		$result = $db->query( $sql, array( QUESTIONS_TABLE, 'N', $id ) );

	}

	header ( "location: sectionquestions.php?sectionid=" . $_POST['sectionid'] );
	exit;

} else if ($_POST['groupaction'] == get_lang('delete_selected') ) {

	$sql = 'SELECT * from ! Where 0 ';

	foreach ( $arr as $questionid ) {
		$sql .= " or id=" . $questionid;
	}
	$rsQuestions = $db->getAll( $sql, array( QUESTIONS_TABLE ) );
	$data = array();
	foreach ( $rsQuestions as $row ) {
		$row['question'] = stripslashes($row['question']);
		$row['description'] = stripslashes($row['description']);
		$row['guideline'] = stripslashes($row['guideline']);
		$row['extsearchhead'] = stripslashes($row['extsearchhead']);
		$data[] = $row;
	}

	$t->assign( 'lang', $lang );

	$t->assign( 'data', $data );

	$t->assign('sectionid', $_POST['sectionid']);

	$t->assign('rendered_page', $t->fetch('admin/groupquestiondel.tpl'));

	$t->display( 'admin/index.tpl' );
	exit;
}
?>