﻿<? include ("header.php"); ?>









<?

require("setup.php");

$resultk=mysql_query("select * from jackpot where name='ttuz'");
$rowk=mysql_fetch_array($resultk);


$tj=$rowk[1]+$rowk[2]+$rowk[3]+$rowk[4]+$rowk[6]+$rowk[7]+$rowk[9]+$rowk[10]+$rowk[11]+$rowk[12]+$rowk[13];



?>






<table cellpadding="0" cellspacing="0" border="0" width="100%">
	<tr class="top3">
		<td colspan="3"><img src="template/v3/i/b.gif" border="0" height="15" width="1"></td>
	</tr>
	<tr class="top4">
		<td>&nbsp;</td>
		<td width="778">
<table cellpadding="0" cellspacing="0" border="0" width="778">
				<tr>
					<td><object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" width="257" height="109" id="logo" align="middle"><param name="movie" value="flash/logo.swf" /><param name="quality" value="high" /><param name="wmode" value="transparent" /><param name="bgcolor" value="#ffffff" /><embed src="flash/logo.swf" quality="high" wmode="transparent" bgcolor="#ffffff" width="257" height="109" name="rotator" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /></object></td>
					<td class="index12" width="287" valign="top"><span>NO DOWNLOAD REQUIRED
</span><br>
						<b></b> <br>
						<b></b> <br>
						<b></b> </td>
					<td rowspan="2" class="index13" valign="top">
						<table cellpadding="0" cellspacing="0" border="0" width="234">
							<tr>
								<td style="padding: 16px 0px 0px 22px" height="141" valign="top"><object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" width="197" height="120" id="rotator" align="middle"><param name="allowScriptAccess" value="sameDomain" /><param name="movie" value="flash/rotator_final.swf" /><param name="quality" value="high" /><param name="wmode" value="transparent" /><param name="bgcolor" value="#ffffff" /><embed src="flash/rotator_final.swf" quality="high" wmode="transparent" bgcolor="#ffffff" width="197" height="120" name="rotator" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /></object></td>
							</tr>
							<tr>
								<td style="padding-left: 52px;"><span class="itexts_sel" id="it1">QUICKPAYOUTS</span></td>
							</tr>
							<tr>
								<td style="padding-left: 39px;"><span class="itexts" id="it2">SAFE AND SECURE</span></td>
							</tr>
							<tr>
								<td style="padding-left: 26px;"><span class="itexts" id="it3">24/7 SUPPORT</span></td>
							</tr>
							<tr>
								<td style="padding-left: 13px;"><span class="itexts" id="it4">FAIR GAMING</span></td>
							</tr>
							<tr>
								<td style="padding-left: 0px;"><span class="itexts" id="it5">COMPLETE PRIVACY</span></td>
							</tr>
						</table>
						<br>
					</td>
				</tr>
				<tr>
					<td valign="top">
						<table cellpadding="0" cellspacing="0" border="0" width="100%">
							<tr>
								<td valign="middle" align="center"    background="template/v3/i/home_playcasino_bg.jpg" height="109"   onClick="window.location='system/login.php'"> <a href="system/login.php"></a></td>
							</tr>
							<tr>
								<td><a href="preview.php"><img src="template/v3/i/100games.gif" border="0"></a></td>
							</tr>
							<tr>
								<td><img src="template/v3/i/slice3.jpg" border="0"></td>
							</tr>
						</table>
					</td>
					<td><object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" width="287" height="122" id="homestar" align="middle"><param name="allowScriptAccess" value="sameDomain" /><param name="movie" value="flash/homestar.swf" /><param name="quality" value="high" /><param name="wmode" value="transparent" /><param name="bgcolor" value="#ffffff" /><embed src="flash/homestar.swf" quality="high" wmode="transparent" bgcolor="#ffffff" width="287" height="122" name="homestar" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /></object><a href="promotions.php"><img src="template/v3/i/homestar-1b2.gif" border="0"></a></td>
				</tr>
				<tr>
					<td colspan="2" rowspan="2" class="index31" valign="top">
						<table cellpadding="0" cellspacing="0" border="0" width="100%">
							<tr class="indexgames" valign="bottom">
								<td></td>
								<td height="35"><a href="preview.php">SLOTS</a></td>
								<td><a href="preview.php">BLACKJACK</a></td>
								<td><a href="preview.php">CARDS</a></td>
								
								<td><a href="preview.php">VIDEO POKER</a></td>
								<td><a href="preview.php">ROULETTE</a></td>
							</tr>
							<tr class="index4">
								<td><a href="preview.php"><img src="template/v3/i/index4l.jpg"></a></td>
								<td><a href="preview.php"><img src="template/v3/i/islots.jpg"></a></td>
								<td><a href="preview.php"><img src="template/v3/i/iblackjack.jpg"></a></td>
								<td><a href="preview.php"><img src="template/v3/i/icards.jpg"></a></td>
								
								<td><a href="preview.php"><img src="template/v3/i/ivideo_poker.jpg"></a></td>
								<td><a href="preview.php"><img src="template/v3/i/iroulette.jpg"></a></td>
							</tr>
						</table>
					</td>
					<td width="234"><img src="template/v3/i/index33.jpg"></td>
				</tr>
				<tr>
					<td align="center" height="81" class="index4r"><a href="system/login_procdemo.php"><img src="template/v3/i/playinstant.gif" border="0"></a><br>NO DOWNLOAD REQUIRED</td>
				</tr>
				<tr>
					<td colspan="3" class="index5">
						<table cellpadding="0" cellspacing="0" border="0" width="100%">
							<tr>
								<td width="4"><img src="template/v3/i/index5l.jpg"></td>
								<td valign="top" width="203" class="iprogressive"><div>PROGRESSIVE JACKPOTS<br><br>$ <? echo $tj; ?></b></div></td>
								<td class="customercare" width="203"><a href="system/login.php"><img src="template/v3/i/special/winner_ronin_vicki.gif" alt=""  border="0"></a><!-- <span>CUSTOMER CARE</span><br>Let us know what you think:<br><a href="support.php">CLICK HERE</a> --></td>
								<td class="support">
									<table cellpadding="0" cellspacing="0" border="0">
										<tr>
											<td class="support_big"><a href="support.php"><b>24/7</b><br>SUPPORT</a></td>
											<td class="support_small">
												<table cellpadding="0" cellspacing="0" border="0">
													<tr>
														<td><a href="support.php">Canada Toll-Free:&nbsp;</a></td>
														<td><a href="support.php"><b>1 (800) 761-1304</b></a></td>
													</tr>
													<tr>
														<td><a href="support.php">UK Toll-Free:&nbsp;</a></td>
														<td><a href="support.php"><b>0 (808) 238 0021</b></a></td>
													</tr>
													<tr>
														<td><a href="support.php">International:&nbsp;</a></td>
														<td><a href="support.php"><b>+ (800) 761-1304</b></a></td>
													</tr>
												</table>
											</td>
										</tr>
									</table>
								</td>
								<td width="4"><img src="template/v3/i/index5r.jpg"></td>
							</tr>
						</table>

<tr class="top5">
<td class="menu_bottom2" colspan="3"><h1>DEMO CASINO DEMO CASINO DEMO CASINO DEMO CASINO DEMO  DEMO CASINO DEMO CASINO DEMO CASINO DEMO CASINO DEMO CASINO DEMO CASINO</h1></td>
			</tr>
</td>
				</tr>
			</table>

<br />		</td>
</body>

</html>

<?		include ("footer.php") ?>