<?php
//Include init.php
if ( !defined( 'SMARTY_DIR' ) ) {
	include_once( '../init.php' );
}

include ( 'sessioninc.php' );


if (isset($_REQUEST['act']) && $_REQUEST['act'] != '' ) {

	$error = '';

	$act = $_REQUEST['act'];

	if ($act == 'added' || $act == 'modified') {

		$name = strip_tags(trim( $_POST[ 'txtname' ] ) );

		$password = strip_tags(trim( $_POST[ 'txtpassword' ] ) );

		$email = strip_tags(trim( $_POST[ 'txtemail' ] ) );

		$conpassword = strip_tags(trim( $_POST[ 'txtconpassword' ] ) );

		if( $name=='' ||  $email == '' || ($act == 'added' && ( $conpassword == '' || $password == '' )) || ($password != '' && $conpassword == '')){

			$error= get_lang('affiliates_error',0);

		} elseif( $password != '' && $conpassword != $password ){

			$error = get_lang('affiliates_error',1);
		}
		if ($error != '') {

			$t->assign('error',$error);

			$t->assign('name',$name);

			$t->assign('email',$email);

			$t->assign('password',$password);

			$t->assign('affid',$affid);

			$t->assign('lang',$lang);

			$t->assign("act", $act);

			$t->assign('rendered_page', $t->fetch('admin/affiliate.tpl') );

			$t->display( 'admin/index.tpl' );

			exit;
		}

	}

	switch($act) {

		case 'added':

			$sqlc = 'SELECT count(*)  from ! where email= ? ';

			$rowc = $db->getOne( $sqlc, array( AFFILIATE_TABLE, $email ) );

			if ($rowc > 0) {

				$error = get_lang('affiliates_error','25');

				$act = 'added';

			} else {

				$sqlins = "INSERT INTO ! (  name, email, password, status, regdate ) VALUES ( ?, ?, ?, ?, ? )";

				$result = $db->query ( $sqlins, array( AFFILIATE_TABLE, $name, $email, md5($password), 'approval', time() ) );

				$affid = $db->getOne('select id from ! where name = ? and email = ?',array( AFFILIATE_TABLE, $name, $email)) ;

				$message = get_lang('aff_added', MAIL_FORMAT);

				$Subject = get_lang('aff_added_sub');

				$From= $config['admin_email'];

				$message = str_replace("#Name#", $name, $message);

				$message = str_replace("#Affid#", $affid, $message);

				$message = str_replace("#Password#", $password, $message);

				mailSender($From, $email, $email, $Subject, $message);

				$error = get_lang('affiliate_registration_success');

				$act = '';

			}

			break;
		case 'add':

			$act='added';

			break;

		case 'modify':

			$affid = $_REQUEST['affid'];

			$affrec = $db->getRow('select * from ! where id = ?', array(AFFILIATE_TABLE, $affid));

			$name = $affrec['name'];

			$email = $affrec['email'];

			$password = '';

			$act = 'modified';

			break;

		case 'modified':

			$affid = $_REQUEST['affid'];

			$affrec = $db->getRow('select * from ! where id = ?', array(AFFILIATE_TABLE, $affid));

			$sql = 'update ! set name = ?, email = ? ';

			if ($password != '') {
				$sql .= ", password = md5('".$password."')";
			}

			$sql .= 'where id = ?';

			$db->query($sql,array(AFFILIATE_TABLE, $name, $email, $affid) );

			$error = get_lang('aff_modified');

			break;
	}

} else { $act = 'added'; }


$t->assign('error',$error);

$t->assign('name',$name);

$t->assign('email',$email);

$t->assign('password',$password);

$t->assign('affid',$affid);

$t->assign('lang',$lang);

$t->assign("act", $act);

$t->assign('rendered_page', $t->fetch('admin/affiliate.tpl') );

$t->display( 'admin/index.tpl' );

exit;
?>

