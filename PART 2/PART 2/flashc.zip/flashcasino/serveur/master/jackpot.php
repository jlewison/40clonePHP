<? include ("header.php");
include ("../setup.php");
$resultg=mysql_query("select * from jackpot ");
$rog=mysql_fetch_array($resultg);
?>

<center><h4><font color=7C87C2>Jackpot</font></h4><br></center>


<table border="0" align="center" cellpadding="0" cellspacing="10">
<FORM action=jackpot.php method=post>





<TR><td>Astro : </td><TD><INPUT size=40 name=a1 value=<? echo $rog[1] ?>></TD></TR>

<TR><td>Birds: </td><TD><INPUT size=40 name=a2 value=<? echo $rog[2] ?>></TD></TR>

<TR><td>far-west : </td><TD><INPUT size=40 name=a3 value=<? echo $rog[3] ?>></TD></TR>

<TR><td>fruit : </td><TD><INPUT size=40 name=a4 value=<? echo $rog[4] ?>></TD></TR>


<TR><td>Magicien : </td><TD><INPUT size=40 name=a5 value=<? echo $rog[6] ?>></TD></TR>

<TR><td>shuki : </td><TD><INPUT size=40 name=a6 value=<? echo $rog[7] ?>></TD></TR>

<TR><td>Tomraider: </td><TD><INPUT size=40 name=a7 value=<? echo $rog[9] ?>></TD></TR>

<TR><td>Pirate : </td><TD><INPUT size=40 name=a8 value=<? echo $rog[10] ?>></TD></TR>


<TR><td>Sea: </td><TD><INPUT size=40 name=a9 value=<? echo $rog[11] ?>></TD></TR>

<TR><td>Skull : </td><TD><INPUT size=40 name=a10 value=<? echo $rog[12] ?>></TD></TR>

<TR><td>Fairy : </td><TD><INPUT size=40 name=a11 value=<? echo $rog[13] ?>></TD></TR>





<TR><td>Jackpot enable (rng win or nowin )</td><TD><input type=checkbox name="t1" value="yes" ></TD></TR>



<TR><TD><INPUT type=hidden value=1 name=send><INPUT type=submit value="Submit"></TD></TR>
</FORM>
</table>


<?

if ($send=="1"){
mysql_query("UPDATE jackpot SET astro='$a1',birds='$a2',farwest='$a3',fruit='$a4',magicien='$a5',shuki='$a6',tomraider='$a7',pirate='$a8',sea='$a9',skull='$a10',fairy='$a11',total='$t1'");
echo "<script> alert('OK!'); document.location.href='jackpot.php';</script>";
}

include ("footer.php"); ?>