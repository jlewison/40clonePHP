<?php

require_once ('../common/config.inc.php');
$CFG['lang']['include_files'][] = 'admin/includes/languages/%s/editConfigIndex.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['mods']['include_files'][] = 'common/classes/class_Parser.lib.php';
$CFG['lang']['include_files'][] = 'common/languages/%s/help.inc.php';
$CFG['html']['header'] = 'admin/includes/languages/%s/html_header.php';
$CFG['html']['footer'] = 'admin/includes/languages/%s/html_footer.php';
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class ConfigProfileEditFormHandler extends FormHandler
{
		public function setBooleanOption($boolean_option_array)
		{
				$this->boolean_option_array = $boolean_option_array;
		}
		public function populateBooleanOption($option_to_highlight)
		{
				if ($option_to_highlight == 'true') $option_to_highlight = 1;
				else
						if ($option_to_highlight == 'false') $option_to_highlight = 0;
				foreach ($this->boolean_option_array as $key => $value)
				{
?>
	<option value="<?php echo $key; ?>" <?php echo ($option_to_highlight == $key) ? 'selected="selected"' : ''; ?>><?php echo $value; ?></option>
<?php
				}
		}
		public function getFileContent($file_path)
		{
				$this->fields_arr['file_content'] = file_get_contents($file_path);
		}
		public function setFilterOptionArray($filter_option_array, $first_option_array)
		{
				$this->filter_option_array = $first_option_array + $filter_option_array;
		}
		public function populateConfigFilterOption($option_to_highlight)
		{
				foreach ($this->filter_option_array as $key => $value)
				{
?>
	<option value="<?php echo $key; ?>" <?php echo ($option_to_highlight == $key) ? 'selected="selected"' : ''; ?>><?php echo $value; ?></option>
<?php
				}
		}
		public function renderLabelTableCell($label_for, $label)
		{
?>
<label for="<?php echo $label_for; ?>"><?php echo $label; ?></label>
<?php
		}
		public function renderTextField($input_type, $name, $value, $tab_index)
		{
?>
<input type="<?php echo $input_type ?>" name="<?php echo $name ?>" id="<?php echo $name ?>" value="<?php echo $value ?>" tabindex="<?php echo $tab_index ?>" />
<?php
		}
		public function renderTextArea($name, $rows, $cols, $tab_index, $content)
		{
?>
<textarea name="<?php echo $name ?>" id="<?php echo $name ?>" rows="<?php echo $rows ?>" cols="<?php echo $cols ?>" tabindex="<?php echo $tab_index ?>"><?php echo $content; ?></textarea>
<?php
		}
		public function renderCheckBox($name, $tab_index, $highlight_item)
		{
				$checked = ($highlight_item == '1' or $highlight_item == 'true') ? 'checked' : '';
?>
<input type="checkbox" class="clsCheckRadio" name="<?php echo $name ?>" id="<?php echo $name ?>" tabindex="<?php echo $tab_index ?>" <?php echo $checked; ?> />
<?php
		}
		public function isCheckedRadio($current_field_value, $current_value)
		{
				$checked = ($current_value == $current_field_value) ? ' checked' : '';
				return $checked;
		}
		public function populateArray($list, $highlight_value = '')
		{
				foreach ($list as $key => $value)
				{
						$selected = $highlight_value == $key ? ' selected' : '';
?>
						<option value="<?php echo $key; ?>"<?php echo $selected; ?>><?php echo $value; ?></option>
<?php
				}
		}
		public function populateSettings()
		{
				$sql = 'SELECT variable_name, value FROM ' . $this->CFG['db']['tbl']['player_settings'];
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				while ($row = $rs->FetchRow())
				{
						$this->fields_arr[$row['variable_name']] = $row['value'];
				}
		}
}
$editfilefrm = new ConfigProfileEditFormHandler();
$CFG['config_video_path'] = '../common/configs/config_index.inc.php';
$editfilefrm->setBooleanOption(array(1 => 'Yes', 0 => 'No'));
$adult_content_view_arr = array('Yes' => $LANG['allow_all'], 'No' => $LANG['only_adult_user'], 'Confirmation' => $LANG['confirmation_to_display']);
$editfilefrm->setPageBlockNames(array('msg_form_error', 'msg_form_success', 'show_config_variable'));
$editfilefrm->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$editfilefrm->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$editfilefrm->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$editfilefrm->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$editfilefrm->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$editfilefrm->setDisplayVar('file_content', '');
$editfilefrm->setDisplayVar('variable_start_string', '$LANG');
$editfilefrm->setDisplayVar('config_section_to_show', '');
$editfilefrm->setFormField('LogoUrl', '');
$editfilefrm->setFormField('TopUrlUrl', '');
$editfilefrm->getFileContent($CFG['config_video_path']);
$editfilefrm->setAllPageBlocksHide();
$editfilefrm->setAllPageBlocksHide();
if ($editfilefrm->isFormPOSTed($_POST, 'selected_configuration_submit'))
{
		$editfilefrm->sanitizeFormInputs($_POST);
		if ($editfilefrm->getFormField('config_section_to_show') != 'all')
		{
				$temp_array = array();
				$temp_array = array($editfilefrm->getFormField('config_section_to_show') => $config_types[$editfilefrm->getFormField('config_section_to_show')]);
				$config_types = array();
				$config_types = $temp_array;
		}
}
if ($editfilefrm->isFormPOSTed($_POST, 'edit_submit'))
{
		$obj = new Parser();
		$content = '';
		$new_content = '';
		$content = $editfilefrm->getDisplayVar('file_content');
		$start_of_comment = $end_of_comment = 0;
		$remaining = $content;
		$is_repeat = true;
		while ($is_repeat)
		{
				$start_of_comment = strpos($content, "/**", 0);
				$end_of_comment = strpos($content, "*/", 0);
				if ($start_of_comment !== false and $end_of_comment !== false)
				{
						$var_name = '';
						$var_value = '';
						$remaining = '';
						$doc_block = '';
						$content_before_doc_block = '';
						$content_before_doc_block = ($start_of_comment !== false and $end_of_comment !== false) ? substr($content, 0, strpos($content, "/**", 0)) : '';
						$doc_block = trim(substr($content, $start_of_comment + 3, ($end_of_comment - $start_of_comment) - 2));
						$doc_block_with_comment = trim(substr($content, $start_of_comment, ($end_of_comment - $start_of_comment) + 2));
						$doc = $obj->extractPhpdoc($doc_block);
						$tags = $obj->getTags($doc);
						if (isset($tags['@cfg_key']) and isset($tags['@var']))
						{
								$start_of_eq = strpos($content, "=", $end_of_comment);
								$variable_line_end_pos = strpos($content, ';', $end_of_comment);
								$remaining = trim(substr($content, $variable_line_end_pos + 1));
								$var_name = trim(substr($content, strpos($content, '$CFG', $end_of_comment), (strpos($content, '=', $end_of_comment) - strpos($content, '$CFG', $end_of_comment))));
								$var_value = trim(substr($content, strpos($content, '=', $end_of_comment) + 1, (strpos($content, ';', $end_of_comment) - strpos($content, '=', $end_of_comment)) - 1));
								$variable_data_type = '';
								$variable_data_type = substr($tags['@var'], 0, strpos($tags['@var'], ' '));
								switch ($variable_data_type)
								{
										case 'array':
												$no_of_tabs = 0;
												$no_of_tabs = (strlen($var_name) / 5) + 6;
												$tab_string = "\n" . str_repeat("\t", $no_of_tabs);
												$comma_sep_arr_string = explode(',', trim($_POST[$tags['@cfg_key']]));
												$arr_new_value = 'array(';
												if ($tags['@cfg_arr_type'] == 'key')
												{
														$remove_arr_string = stristr($var_value, '(');
														$original_value_str = substr($remove_arr_string, 1, strlen($remove_arr_string) - 2);
														$original_value_arr = explode(',', $original_value_str);
														$comma_sep_arr_string = explode(',', trim($_POST[$tags['@cfg_key']]));
														$add_key_quote = ($tags['@cfg_arr_key'] == 'string') ? '\'' : '';
														foreach ($comma_sep_arr_string as $index => $arr_element)
														{
																if ($arr_element)
																{
																		if ($tags['@cfg_arr_key'] == 'string')
																		{
																				$arr_new_value .= '\'' . trim($arr_element) . '\'' . ', ';
																		}
																		else
																				if ($tags['@cfg_arr_key'] == 'int')
																				{
																						if (ctype_digit(trim($arr_element)))
																						{
																								$arr_new_value .= trim($arr_element) . ', ';
																						}
																						else
																								if (isset($original_value_arr[$index]))
																								{
																										$arr_new_value .= trim($original_value_arr[$index]) . ', ';
																								}
																				}
																}
														}
												}
												else
														if ($tags['@cfg_arr_type'] == 'associative')
														{
																$add_key_quote = ($tags['@cfg_arr_key'] == 'string') ? '\'' : '';
																$add_value_quote = ($tags['@cfg_arr_value'] == 'string') ? '\'' : '';
																foreach ($comma_sep_arr_string as $arr_element)
																{
																		if ($arr_element)
																		{
																				$arr_new_value .= $add_key_quote . trim(substr($arr_element, 0, strrpos($arr_element, '='))) . $add_key_quote . ' => ' . $add_value_quote . trim(substr($arr_element, strpos($arr_element, '=') + 1)) . $add_value_quote . ',' . $tab_string;
																		}
																}
														}
												$arr_new_value = substr($arr_new_value, 0, strrpos($arr_new_value, ','));
												$arr_new_value .= ')';
												$var_value = ' = ' . $arr_new_value . ';';
												break;
										case 'boolean':
												$bool_value = (isset($_POST[$tags['@cfg_key']]) and $_POST[$tags['@cfg_key']] == 'true') ? 'true;':
												'false;';
												$var_value = ' = ' . $bool_value;
												break;
										case 'string':
												$var_value = ' = \'' . trim($_POST[$tags['@cfg_key']]) . '\';';
												break;
										case 'int':
												if (ctype_digit(trim($_POST[$tags['@cfg_key']])))
												{
														$var_value = ' = ' . trim($_POST[$tags['@cfg_key']]) . ';';
												}
												else
												{
														$var_value = ' = ' . $var_value . ';';
												}
												break;
								}
								$new_content .= $content_before_doc_block . $doc_block_with_comment . "\n" . $var_name . $var_value . "\n";
								$content = $remaining;
						}
						else
						{
								$remaining = trim(substr($content, $end_of_comment + 2));
								$new_content .= $content_before_doc_block . $doc_block_with_comment . "\n";
								$content = $remaining;
						}
				}
				else
				{
						$new_content .= $remaining;
						$is_repeat = false;
						$fw = fopen($CFG['config_video_path'], 'w');
						fwrite($fw, $new_content);
						fclose($fw);
						$editfilefrm->setAllPageBlocksHide();
						$editfilefrm->setPageBlockShow('msg_form_success');
				}
		}
}
$editfilefrm->setPageBlockShow('show_config_variable');



?>
<script language="javascript" type="text/javascript">
	function chkValidFileFormat(field_name, format)
		{
			var str = Trim($(field_name).value);
			var index = str.indexOf('.');
			if(index>=0)
				{
					str = str.substring(index+1);
					str = str.toLowerCase();
					var valid_format = format;
					index = valid_format.indexOf(str);
					if(index<0)
						return true;
					return false;
				}
			return true;
		}
	function $(elmt){
		return document.getElementById(elmt);
	}
	function chkMandatoryFields()
		{
			if(Trim($('LogoUrl').value)=='')
				return true;

			if(Trim($('TopUrlUrl').value)=='')
				return true;

			if(chkValidFileFormat('LogoUrl', 'swf,jpg'))
				{
					alert('<?php echo $LANG['err_tip_invalid_logo_file_type']; ?>');
					return false;
				}
			if(chkValidFileFormat('TopUrlUrl', 'jpg,flv'))
				{
					alert('<?php echo $LANG['err_tip_invalid_top_file_type']; ?>');
					return false;
				}
			return true;
		}
</script>
</script>
<div id="selGeneralConfiguration">
	<h2 class="clsIndexTitle"><?php echo $LANG['page_title']; ?></h2>
<?php
if ($editfilefrm->isShowPageBlock('msg_form_success'))
{
?>
<div id="selMsgSuccess">
	<p><?php echo $LANG['general_config_success_msg']; ?></p>
</div>
<?php
}
if ($editfilefrm->isShowPageBlock('show_config_variable'))
{
		$parser_obj = new Parser();
		$config_content = '';
		$ret_array = array();
		$config_content = file_get_contents($CFG['config_video_path']);
		$ret_array = $parser_obj->getPhpdocParagraphs($config_content);
?>
<form name="form_config" id="selFormConfig" method="post" action="<?php echo $CFG['site']['url']; ?>admin/editConfigIndex.php" autocomplete="off"  enctype="multipart/form-data" onsubmit="return chkMandatoryFields();">
<?php
		$tab_index = 1000;
		$prev_sec_name = '';
		foreach ($ret_array as $config_type => $value)
		{
				$prev_sec_name = $ret_array[$config_type][0]['tags']['@cfg_sec_name'];


?>
	<div id="selConfigSection">
		<h3><?php echo $prev_sec_name; ?></h3>
		<table class="clsCommonTable" summary="<?php echo $LANG['tbl_summary']; ?>">
<?php
				foreach ($ret_array[$config_type] as $key => $value)
				{
?>
<?php
						$input_type = '';
						$result = (isset($value['tags']['@cfg_coding'])) ? $value['tags']['@cfg_coding'] : '';
						print $result;
						$input_type = (isset($value['tags']['@cfg_is_password'])) ? 'password' : 'text';
						$variable_data_type = '';
						$variable_data_type = substr($value['tags']['@var'], 0, strpos($value['tags']['@var'], ' '));
						if (isset($value['tags']['@cfg_sub_head']))
						{
?>
					<tr>
						<th colspan="2"><?php echo $value['tags']['@cfg_sub_head'] ?></th>
					</tr>
<?php
						}
						switch ($variable_data_type)
						{
								case 'string':
										$value['value'] = str_replace('\'', '', $value['value']);
?>
		<tr>
			<td class="clsFormLabelCellDefault"><?php $editfilefrm->renderLabelTableCell($value['tags']['@cfg_key'], $value['tags']['@cfg_label']); ?></td>
			<td class="clsFormFieldCellDefault">
				<select name="<?php echo $value['tags']['@cfg_key']; ?>" id="<?php echo $value['tags']['@cfg_key']; ?>" tabindex="<?php echo $tab_index; ?>">
					<?php $editfilefrm->populateArray(array('yes' => 'yes', 'no' => 'no', 'compulsory' => 'compulsory'), $value['value']); ?>
				</select>
			</td>
		</tr>
<?php
										break;
								case 'int':
										$value['value'] = str_replace('\'', '', $value['value']);
?>
		<tr>
			<td class="clsFormLabelCellDefault"><?php $editfilefrm->renderLabelTableCell($value['tags']['@cfg_key'], $value['tags']['@cfg_label']); ?></td>
			<td class="clsFormFieldCellDefault"><?php $editfilefrm->renderTextField('text', $value['tags']['@cfg_key'], $value['value'], $tab_index) ?><?php eval($result); ?></td>
		</tr>
<?php
										break;
								case 'array':
										if ($value['tags']['@cfg_arr_type'])
										{
												$arr_value = '';
												$start_post = strpos($value['value'], '(') + 1;
												$end_post = strpos($value['value'], ')') - $start_post;
												$arr_value = substr($value['value'], $start_post, $end_post);
												$arr_value = preg_replace("/[\t\r\n\' ]/", "", $arr_value);
												$arr_value = str_replace(',', ",\n", $arr_value);
												$arr_value = str_replace('=>', "=", $arr_value);
												$no_of_row = substr_count($arr_value, ',') + 1;
?>
		<tr>
			<td class="clsFormLabelCellDefault"><?php $editfilefrm->renderLabelTableCell($value['tags']['@cfg_key'], $value['tags']['@cfg_label']); ?></td>
			<td class="clsFormFieldCellDefault"><?php $editfilefrm->renderTextArea($value['tags']['@cfg_key'], $no_of_row, '15', $tab_index, $arr_value); ?><?php eval($result); ?></td>
		</tr>
<?php
										}
										break;
								case 'boolean':
										switch ($value['tags']['@cfg_key'])
										{
												case 'AutoPlay':
?>
		<tr>
			<td class="clsFormLabelCellDefault"><?php $editfilefrm->renderLabelTableCell($value['tags']['@cfg_key'], $value['tags']['@cfg_label']); ?></td>
			<td class="clsFormFieldCellDefault">
				<input class="clsCheckRadio" name="AutoPlay" id="AutoPlay1" tabindex="<?php echo $tab_index; ?>" type="radio" class="clsCheckRadio" value="true" <?php echo $editfilefrm->isCheckedRadio('true', $value['value']); ?> />
				<label for="AutoPlay1"><?php echo $LANG['auto_on']; ?></label>
				<input class="clsCheckRadio" name="AutoPlay" id="AutoPlay2" tabindex="<?php echo $tab_index; ?>" type="radio" class="clsCheckRadio" value="false" <?php echo $editfilefrm->isCheckedRadio('false', $value['value']); ?> />
				<label for="AutoPlay2"><?php echo $LANG['auto_off']; ?></label>
			</td>
		</tr>
<?php
														break;
												default:
?>
		<tr>
			<td class="clsFormLabelCellDefault"><?php $editfilefrm->renderLabelTableCell($value['tags']['@cfg_key'], $value['tags']['@cfg_label']); ?></td>
			<td class="clsFormFieldCellDefault">
				<input class="clsCheckRadio" name="<?php echo $value['tags']['@cfg_key']; ?>" id="<?php echo $value['tags']['@cfg_key']; ?>1" tabindex="<?php echo $tab_index; ?>" type="radio" class="clsCheckRadio" value="true" <?php echo $editfilefrm->isCheckedRadio('true', $value['value']); ?> />
				<label for="<?php echo $value['tags']['@cfg_key']; ?>1"><?php echo $LANG['on']; ?></label>
				<input class="clsCheckRadio" name="<?php echo $value['tags']['@cfg_key']; ?>" id="<?php echo $value['tags']['@cfg_key']; ?>2" tabindex="<?php echo $tab_index; ?>" type="radio" class="clsCheckRadio" value="false" <?php echo $editfilefrm->isCheckedRadio('false', $value['value']); ?> />
				<label for="<?php echo $value['tags']['@cfg_key']; ?>2"><?php echo $LANG['off']; ?></label>
			</td>
		</tr>
<?php
														break;
										}
										break;
						}
						$tab_index += 5;
				}
?><tr><td>&nbsp;</td><td><input type="submit" class="clsSubmitButton" name="edit_submit" id="edit_submit" value="<?php echo $LANG['general_config_declare_submit']; ?>" tabindex="<?php echo $tab_index; ?>" /></td></tr>
				</table>
				</div>
<?php
		}
?>

		</form>
<?php
}
?>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>
