<?php
/**
 * View reports Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 02/01/2008
 */
class ViewReport extends controller
{
		function ViewReport()
		{
				parent::controller();
				//check login
				if ($this->session->userdata('admin_logged_in') != 1 && $this->session->userdata('admin_id') == '') redirect('admin/login');
				//Load the language file
				$this->lang->load('admin/manageReports', $this->config->item('language_code'));
				$this->load->model('reportmodel');
		}
		function index()
		{
				$outputData['reportTypes'] = array('group' => $this->lang->line('managereports_groups'), 'event' => $this->lang->line('managereports_event'), 'photo' => $this->lang->line('managereports_photo'), 'network' => $this->lang->line('managereports_network'), 'posted_item' => $this->lang->line('managereports_posted_item'), 'profile' => $this->lang->line('managereports_profile'));
				$outputData['report_id'] = $this->uri->segment(3);
				$outputData['report'] = $this->reportmodel->getReport($outputData['report_id']);
				//print_r($outputData['report']); exit();
				$this->smartyextended->view('../admin/viewReport', $outputData);
		}
		#***************************************************************************
		#Method			: deleteReport
		#Description	: deletes report
		#Author			
		#***************************************************************************
		function block()
		{
				$report_type = $this->uri->segment(4);
				$report_id = $this->uri->segment(5);
				$this->load->model('groupsmodel');
				$this->load->model('eventsmodel');
				$this->load->model('photomodel');
				$this->load->model('networkmodel');
				$this->load->model('postedmodel');
				$this->load->model('usermodel');
				if ($report_type == 'group')
				{
						$this->groupsmodel->updateGroupStatus($report_id);
						$this->session->set_flashdata('successMsg', $this->lang->line('managereports_group_block_success'));
				}
				else
						if ($report_type == 'event')
						{
								$this->eventsmodel->updateEventStatus($report_id);
								$this->session->set_flashdata('successMsg', $this->lang->line('managereports_event_block_success'));
						}
						else
								if ($report_type == 'photo')
								{
										$this->photomodel->updatePhotoStatus($report_id);
										$this->session->set_flashdata('successMsg', $this->lang->line('managereports_photo_block_success'));
								}
								else
										if ($report_type == 'network')
										{
												$this->networkmodel->updateNetworkStatus($report_id);
												$this->session->set_flashdata('successMsg', $this->lang->line('managereports_network_block_success'));
										}
										else
												if ($report_type == 'posted_item')
												{
														$this->postedmodel->updatePostedItemStatus($report_id);
														$this->session->set_flashdata('successMsg', $this->lang->line('managereports_posted_item_block_success'));
												}
												else
														if ($report_type == 'profile')
														{
																$this->usermodel->updateProfileStatus($report_id);
																$this->session->set_flashdata('successMsg', $this->lang->line('managereports_profile_block_success'));
														}
				//Set the flash data
				redirect('admin/manageReports');
		}
}
?>