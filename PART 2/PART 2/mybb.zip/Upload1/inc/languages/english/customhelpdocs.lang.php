<?php
/**
 * MyBB 1.4 English Language Pack
 * Copyright © 2008 MyBB Group, All Rights Reserved
 * 
 * $Id: customhelpdocs.lang.php 4304 2009-01-02 01:11:56Z chris $
 */

/*
 * Custom Help Document Translation Format
 *
 * // Help Document {hid}
 * $l['d{hid}_name'] = "Document name";
 * $l['d{hid}_desc'] = "Document description";
 * $l['d{hid}_document'] = "Document text";
 */
?>