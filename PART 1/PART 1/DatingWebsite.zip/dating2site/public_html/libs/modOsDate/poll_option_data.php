<?php

   class poll_optionData extends Data {

      var $table = POLL_OPTION_TABLE;

      var $config = array (
  'table' => POLL_OPTION_TABLE,
  'idField' => 'osdate_poll_option_id',
  'addedMsg' => 'Osdate Poll Option %s Added',
  'added_err' => 'Can\\\'t Add Osdate Poll Option',
  'editMsg' => 'Osdate Poll Option %s Updated',
  'editErr' => 'Can\\\'t Update Osdate Poll Option',
  'delErr' => 'Can\\\'t Delete Osdate Poll Option',
  'delMsg' => 'Osdate Poll Option %s Deleted',
  'blankErr' => 'Osdate Poll Option Empty',
  'fields' => 
  array (
    'id' => 
    array (
      'name' => 'id',
      'description' => 'Id',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'questionid' => 
    array (
      'name' => 'questionid',
      'description' => 'Questionid',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'answeroption' => 
    array (
      'name' => 'answeroption',
      'description' => 'Answeroption',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 255,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
  ),
);   

      function poll_optionData() {
      
         $this->Data($this->config);
      }
   }

?>
