<?php //00461
// Copyright Notice
// Web Site URL:  http://www.zeeways.com
// Script Owner eMail: mail@zeeways.com
// Date: April, 2007
// Script Name: Zeeways Auction Website PHP Script
// Copyright Details: This script is not free.  Do not Remove this Copy Right notice.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the site administrator.');exit(199);
?>
4+oV57drJ5ROGxMPiK/PTO+hSyUrw3V0Gbzh4f+it3lj6gts4qgHylZCMdGc37ruNSNLmme2+ajo
5gfFnLKEnmwxtzZon6UMKhBHa58V0o3qES8sc4LOQ8AGtDGckSriaaHulm4ckK9QZ4SUHsAdutw1
hGKf37uZjsc3ttYqbMHHnVY5CwGayaJ11hWUxfeftsvdG3bMUX8NST2dt5hSzP/iHBNCdsosHhP/
hirJMVjwiir5GPYgC2tobgOq34npzoskINwscd0HWyvZtZbMnZkTUaqdRPpvMWKGArKVv1eC6fIg
oBMddm3tTrY+/XLezi2dl9OKIfBKtvcrEGz2focyiVE6SXQGS1w0YAqrprzg0BzGtpfn7O9RbQ+t
IZ+mEbD/kV2G1L9amoz3/jCKnHJQzdHKPYX/auWtYUWx1CUHxXQ11Kh21oLkbDCFl85Q/7GaQQNG
SHh04Hs+gnVgYEKSLRX3TBserTclXwHu0Z2x1ULnQliWY4vciim6qrbZkjbmR3bLWh7y2h2jsbNq
Vm==