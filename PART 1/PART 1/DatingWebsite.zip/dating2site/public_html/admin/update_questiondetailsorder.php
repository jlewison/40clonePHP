<?php
if ( !defined( 'SMARTY_DIR' ) ) {
	include_once( '../init.php' );
}

/* Set display order for existing options */

$question_details = $db->getAll('select * from ! order by questionid, id',array(OPTIONS_TABLE));

$questionid = '';

$seq = 0;

foreach ($question_details as $option) {
	if ($questionid != $option['questionid']) {
		$questionid = $option['questionid'];
		$seq = 0;
	}
	$seq++;
	$db->query('update ! set displayorder = ? where id = ?', array( OPTIONS_TABLE, $seq, $option['id']) );
}

?>