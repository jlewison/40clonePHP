<?php
require_once ('../common/config.inc.php');
$CFG['lang']['include_files'][] = 'members/includes/languages/%s/mailRead.php';
$CFG['lang']['include_files'][] = 'members/includes/languages/%s/mailRightLinks.php';
$CFG['html']['header'] = 'members/includes/languages/%s/html_header.php';
$CFG['html']['footer'] = 'members/includes/languages/%s/html_footer.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['mods']['include_files'][] = 'common/classes/class_MailHandler.lib.php';
$CFG['lang']['include_files'][] = 'common/configs/config_mails.inc.php';
$CFG['lang']['include_files'][] = 'common/email_templates/languages/%s/email_notify.inc.php';
$CFG['db']['is_use_db'] = true;
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class MailReadFormHandler extends MailHandler
{
		public $mail_details_arr;
		public function updateMessageViews()
		{
				$viewed_column = '';
				if ($this->mail_details_arr['to_id'] == $this->CFG['user']['user_id'])
				{
						$viewed_column = 'to_viewed = \'Yes\'';
				}
				if ($this->mail_details_arr['from_id'] == $this->CFG['user']['user_id'])
				{
						if ($viewed_column) $viewed_column .= ', ';
						$viewed_column .= 'from_viewed = \'Yes\'';
				}
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['messages_info'] . ' SET ' . $viewed_column . ' WHERE info_id = ' . $this->dbObj->Param($this->fields_arr['message_id']) . '';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['message_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return true;
		}
		public function showPrevious($message_id)
		{
				switch ($this->fields_arr['folder'])
				{
						case 'inbox':
								$sql = 'SELECT MIN(mi.info_id) AS info_id' . ' FROM ' . $this->CFG['db']['tbl']['users'] . ' AS u' . ', ' . $this->CFG['db']['tbl']['messages'] . ' AS m' . ', ' . $this->CFG['db']['tbl']['messages_info'] . ' AS mi' . ' WHERE mi.to_id = ' . $this->dbObj->Param($this->CFG['user']['user_id']) . ' AND mi.from_id = u.' . $this->getUserTableField('user_id') . ' AND mi.message_id = m.message_id' . ' AND mi.to_delete = \'No\'' . ' AND mi.to_stored = \'No\'' . ' AND mi.info_id > ' . $this->dbObj->Param($message_id) . ' ORDER BY mi.info_id DESC';
								$fields_value_arr = array($this->CFG['user']['user_id'], $message_id);
								break;
						case 'sent':
								$sql = 'SELECT MIN(mi.info_id) AS info_id' . ' FROM ' . $this->CFG['db']['tbl']['users'] . ' AS u' . ', ' . $this->CFG['db']['tbl']['messages'] . ' AS m' . ', ' . $this->CFG['db']['tbl']['messages_info'] . ' AS mi' . ' WHERE mi.from_id = ' . $this->dbObj->Param($this->CFG['user']['user_id']) . ' AND mi.to_id = u.' . $this->getUserTableField('user_id') . ' AND mi.message_id = m.message_id' . ' AND mi.from_delete = \'No\'' . ' AND mi.from_stored = \'No\'' . ' AND mi.info_id > ' . $this->dbObj->Param($message_id) . ' ORDER BY mi.info_id DESC';
								$fields_value_arr = array($this->CFG['user']['user_id'], $message_id);
								break;
				}
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, $fields_value_arr);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($row = $rs->FetchRow()) return $row['info_id'];
				return 0;
		}
		public function showNext($message_id)
		{
				switch ($this->fields_arr['folder'])
				{
						case 'inbox':
								$sql = 'SELECT MAX(mi.info_id) AS info_id' . ' FROM ' . $this->CFG['db']['tbl']['users'] . ' AS u' . ', ' . $this->CFG['db']['tbl']['messages'] . ' AS m' . ', ' . $this->CFG['db']['tbl']['messages_info'] . ' AS mi' . ' WHERE mi.to_id = ' . $this->dbObj->Param($this->CFG['user']['user_id']) . ' AND mi.from_id = u.' . $this->getUserTableField('user_id') . ' AND mi.message_id = m.message_id' . ' AND mi.to_delete = \'No\'' . ' AND mi.to_stored = \'No\'' . ' AND mi.info_id < ' . $this->dbObj->Param($message_id) . ' ORDER BY mi.info_id DESC';
								$fields_value_arr = array($this->CFG['user']['user_id'], $message_id);
								break;
						case 'sent':
								$sql = 'SELECT MAX(mi.info_id) AS info_id' . ' FROM ' . $this->CFG['db']['tbl']['users'] . ' AS u' . ', ' . $this->CFG['db']['tbl']['messages'] . ' AS m' . ', ' . $this->CFG['db']['tbl']['messages_info'] . ' AS mi' . ' WHERE mi.from_id = ' . $this->dbObj->Param($this->CFG['user']['user_id']) . ' AND mi.to_id = u.' . $this->getUserTableField('user_id') . ' AND mi.message_id = m.message_id' . ' AND mi.from_delete = \'No\'' . ' AND mi.from_stored = \'No\'' . ' AND mi.info_id < ' . $this->dbObj->Param($message_id) . ' ORDER BY mi.info_id DESC';
								$fields_value_arr = array($this->CFG['user']['user_id'], $message_id);
								break;
				}
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, $fields_value_arr);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($row = $rs->FetchRow()) return $row['info_id'];
				return 0;
		}
		public function isValidMessageId()
		{
				$this->chkIsNotEmpty('message_id', $this->LANG['mailread_err_tip_compulsory']) and $this->chkIsNumeric('message_id', $this->LANG['mailread_err_tip_compulsory']);
				if (!$this->isValidFormInputs())
				{
						$this->setCommonErrorMsg($this->LANG['mailread_err_tip_invalid_mail_id']);
						$this->setPageBlockShow('msg_form_error');
						return false;
				}
				switch ($this->fields_arr['folder'])
				{
						case 'inbox':
								$sql = 'SELECT mi.info_id, mi.message_id, ' . $this->getUserTableField('user_id') . ' AS img_user_id, ' . $this->getUserTableFields(array('user_id', 'name', 'image_path', 'gender', 'photo_server_url', 't_width', 't_height', 's_width', 's_height', 'photo_ext')) . ', m.subject, m.message, mi.to_viewed, mi.to_answer, attachment, mi.to_id, mi.from_id, mi.email_status' . ', DATE_FORMAT(m.mess_date, \'' . $this->CFG['format']['date'] . '\') AS mess_date, DATE_FORMAT(m.mess_date, \'%I:%i %p\') AS mess_time' . ' FROM ' . $this->CFG['db']['tbl']['users'] . ' AS u ' . ', ' . $this->CFG['db']['tbl']['messages'] . ' AS m' . ', ' . $this->CFG['db']['tbl']['messages_info'] . ' AS mi' . ' WHERE mi.to_id = ' . $this->dbObj->Param($this->CFG['user']['user_id']) . ' AND mi.from_id = u.' . $this->getUserTableField('user_id') . ' AND mi.message_id = m.message_id' . ' AND mi.to_delete = \'No\'' . ' AND mi.to_stored = \'No\'' . ' AND mi.info_id = ' . $this->dbObj->Param($this->fields_arr['message_id']) .
										' ORDER BY mi.info_id DESC';
								$fields_value_arr = array($this->CFG['user']['user_id'], $this->fields_arr['message_id']);
								$this->mail_title = $this->LANG['mail_title_inbox'];
								break;
						case 'sent':
								$sql = 'SELECT mi.info_id, mi.message_id, ' . $this->getUserTableField('user_id') . ' AS img_user_id, ' . $this->getUserTableFields(array('user_id', 'name', 'image_path', 'gender', 'photo_server_url', 't_width', 't_height', 's_width', 's_height', 'photo_ext')) . ', m.subject, m.message, mi.from_viewed, mi.from_answer, attachment, mi.to_id, mi.from_id' . ', DATE_FORMAT(m.mess_date, \'' . $this->CFG['format']['date'] . '\') AS mess_date, DATE_FORMAT(m.mess_date, \'%I:%i %p\') AS mess_time' . ' FROM ' . $this->CFG['db']['tbl']['users'] . ' AS u' . ', ' . $this->CFG['db']['tbl']['messages'] . ' AS m' . ', ' . $this->CFG['db']['tbl']['messages_info'] . ' AS mi' . ' WHERE mi.from_id = ' . $this->dbObj->Param($this->CFG['user']['user_id']) . ' AND mi.to_id = u.' . $this->getUserTableField('user_id') . ' AND mi.message_id = m.message_id' . ' AND mi.from_delete = \'No\'' . ' AND mi.from_stored = \'No\'' . ' AND mi.info_id = ' . $this->dbObj->Param($this->fields_arr['message_id']) .
										' ORDER BY mi.info_id DESC';
								$fields_value_arr = array($this->CFG['user']['user_id'], $this->fields_arr['message_id']);
								$this->mail_title = $this->LANG['mail_title_sent'];
								break;
				}
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, $fields_value_arr);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if (!$rs->PO_RecordCount())
				{
						$this->setCommonErrorMsg($this->LANG['mailread_err_tip_invalid_mail_id']);
						$this->setPageBlockShow('msg_form_error');
						return false;
				}
				$this->mail_details_arr = $rs->FetchRow();
				return true;
		}
		public function deleteMessage()
		{
				if ($this->mail_details_arr['to_id'] == $this->CFG['user']['user_id']) $this->updateMessageStatusDelete('to_delete', $this->fields_arr['message_id']);
				if ($this->mail_details_arr['from_id'] == $this->CFG['user']['user_id']) $this->updateMessageStatusDelete('from_delete', $this->fields_arr['message_id']);
				return true;
		}
		public function showMessageHeader()
		{
?>

<table id="" border="0" class="clsMisNavLinksTbl">
  <tr>
    <td><div id="selMisNavLinks">
        <ul>
          <?php if ($this->fields_arr['folder'] != 'sent')
				{ ?>
		  <li><a href="<?php echo getUrl($this->CFG['admin']['mail_urls']['compose']['normal'], $this->CFG['admin']['mail_urls']['compose']['htaccess']); ?>?action=reply&msgFolder=<?php echo $this->fields_arr['folder']; ?>&message_id=<?php echo $this->fields_arr['message_id']; ?>"><?php echo $this->LANG['mailread_reply']; ?></a></li>
          <?php } ?>
		  <?php if ($this->CFG['admin']['mails']['forward'])
				{ ?>
          <li><a href="<?php echo getUrl($this->CFG['admin']['mail_urls']['compose']['normal'], $this->CFG['admin']['mail_urls']['compose']['htaccess']); ?>?action=forward&msgFolder=<?php echo $this->fields_arr['folder']; ?>&message_id=<?php echo $this->fields_arr['message_id']; ?>"><?php echo $this->LANG['mailread_forward']; ?></a></li>
          <?php } ?>
          <?php $anchor = 'dAlt1_' . $this->fields_arr['message_id']; ?>
          <li><a href="<?php echo getUrl($this->getMailReadNormalUrl() . '&message_id=' . $this->fields_arr['message_id'], $this->getMailReadHtaccessUrl() . '?message_id=' . $this->fields_arr['message_id']); ?>"  onclick="return Confirmation('<?php echo $anchor; ?>', 'selMsgConfirm', 'msgConfirmform', Array('action', 'confirmMessage'), Array('mail_delete', '<?php echo addslashes($this->LANG['mailread_confirm_delete_message']); ?>'), Array('value', 'innerHTML'), -25, -600);"><?php echo $this->LANG['mailread_delete']; ?></a></li>
        </ul>
      </div>
      <a href="<?php echo getUrl($this->CFG['admin']['mail_urls']['compose']['normal'], $this->CFG['admin']['mail_urls']['compose']['htaccess']); ?>?action=forward&msgFolder=<?php echo $this->fields_arr['folder']; ?>&message_id=<?php echo $this->fields_arr['message_id']; ?>" id="<?php echo $anchor; ?>"></a> </td>
    <td class="clsMsgNavigationCell"><div id="selMessageNavLinks">
        <?php
				$this->prev_id = 0;
				if ($this->prev_id = $this->showPrevious($this->fields_arr['message_id']))
				{
?>
        <span id="selPreviousMail"><a href="<?php echo getUrl($this->getMailReadNormalUrl() . '&message_id=' . $this->prev_id, $this->getMailReadHtaccessUrl() . '?message_id=' . $this->prev_id); ?>"><?php echo $this->LANG['mailread_pervious']; ?></a></span>
        <?php

				}
				else
				{
						echo $this->LANG['mailread_pervious'];
				}
?>
        |
        <?php
				$this->next_id = 0;
				if ($this->next_id = $this->showNext($this->fields_arr['message_id']))
				{
?>
        <span id="selNextMail"><a href="<?php echo getUrl($this->getMailReadNormalUrl() . '&message_id=' . $this->next_id, $this->getMailReadHtaccessUrl() . '?message_id=' . $this->next_id); ?>"><?php echo $this->LANG['mailread_next']; ?></a></span>
        <?php
				}
				else
				{
						echo $this->LANG['mailread_next'];
				}
?>
      </div></td>
  </tr>
</table>
<?php
		}
		public function showMessageBottomHeader()
		{
?>
<table id="" class="clsMisNavLinksTbl">
  <tr>
    <td><div id="selMisNavLinks">
        <ul>
          <?php if ($this->fields_arr['folder'] != 'sent')
				{ ?>
		  <li><a href="<?php echo getUrl($this->CFG['admin']['mail_urls']['compose']['normal'], $this->CFG['admin']['mail_urls']['compose']['htaccess']); ?>?action=reply&msgFolder=<?php echo $this->fields_arr['folder']; ?>&message_id=<?php echo $this->fields_arr['message_id']; ?>"><?php echo $this->LANG['mailread_reply']; ?></a></li>
          <?php } ?>
		  <?php if ($this->CFG['admin']['mails']['forward'])
				{ ?>
          <li><a href="<?php echo getUrl($this->CFG['admin']['mail_urls']['compose']['normal'], $this->CFG['admin']['mail_urls']['compose']['htaccess']); ?>?action=forward&msgFolder=<?php echo $this->fields_arr['folder']; ?>&message_id=<?php echo $this->fields_arr['message_id']; ?>"><?php echo $this->LANG['mailread_forward']; ?></a></li>
          <?php } ?>
          <?php $anchor = 'dAlt2_' . $this->fields_arr['message_id']; ?>
          <li><a href="<?php echo getUrl($this->getMailReadNormalUrl() . '&message_id=' . $this->fields_arr['message_id'], $this->getMailReadHtaccessUrl() . '?message_id=' . $this->fields_arr['message_id']); ?>"  onclick="return Confirmation('<?php echo $anchor; ?>', 'selMsgConfirm', 'msgConfirmform', Array('action', 'confirmMessage'), Array('mail_delete', '<?php echo addslashes($this->LANG['mailread_confirm_delete_message']); ?>'), Array('value', 'innerHTML'), -25, -600);"><?php echo $this->LANG['mailread_delete']; ?></a></li>
        </ul>
      </div>
      <a href="<?php echo getUrl($this->CFG['admin']['mail_urls']['compose']['normal'], $this->CFG['admin']['mail_urls']['compose']['htaccess']); ?>?action=forward&msgFolder=<?php echo $this->fields_arr['folder']; ?>&message_id=<?php echo $this->fields_arr['message_id']; ?>" id="<?php echo $anchor; ?>"></a> </td>
    <td class="clsMsgNavigationCell"><div id="selMessageNavLinks">
        <?php
				if ($this->prev_id)
				{
?>
        <span id="selPreviousMail"><a href="<?php echo getUrl($this->getMailReadNormalUrl() . '&message_id=' . $this->prev_id, $this->getMailReadHtaccessUrl() . '?message_id=' . $this->prev_id); ?>"><?php echo $this->LANG['mailread_pervious']; ?></a></span>
        <?php
				}
				else
				{
						echo $this->LANG['mailread_pervious'];
				}
?>
        |
        <?php
				if ($this->next_id)
				{
?>
        <span id="selNextMail"><a href="<?php echo getUrl($this->getMailReadNormalUrl() . '&message_id=' . $this->next_id, $this->getMailReadHtaccessUrl() . '?message_id=' . $this->next_id); ?>"><?php echo $this->LANG['mailread_next']; ?></a></span>
        <?php
				}
				else
				{
						echo $this->LANG['mailread_next'];
				}
?>
      </div></td>
  </tr>
</table>
<?php
		}
		public function showMessage()
		{
				if ($this->mail_details_arr)
				{
						$userDetails = $this->mail_details_arr;
						$this->showMessageHeader();
?>
<table border="0" cellspacing="0" summary="<?php echo $this->LANG['mailread_tbl_summary']; ?>" class="clsMailReadTbl">
   <tr>
    <?php ?>
    <td class="clsVerticalAlign"><p>
	<span class="clsBold">
	<?php echo ($this->fields_arr['folder'] != 'sent') ? $this->LANG['mailread_from'] : $this->LANG['mailread_to']; ?>
	</span>
	<?php if (chkUserImageAllowed())
						{ ?>
	<span id="selImageBorder">
        <?php displayUserImage($userDetails, 'small'); ?>
    </span>
	<?php } ?>
	<span class="clsUserName"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'myanswers.php?uid=' . $userDetails['user_id'], $this->CFG['site']['relative_url'] . 'my/answers/' . $userDetails['user_id'] . '/', false); ?>"><?php echo stripString($userDetails['name'], $this->CFG['username']['short_length']); ?></a></span>
	<span class="clsBold"><?php echo $this->LANG['mailread_date'] . '</span>, ' . $this->mail_details_arr['mess_date']; ?>&nbsp;&nbsp;<?php echo $this->mail_details_arr['mess_time']; ?></p></td>
  </tr>
  <tr>
    <td class=""><p class="">
      <h3><?php echo stripslashes(wordWrapManual($this->mail_details_arr['subject'], 35)); ?></h3>
      </p>
      <p class="clsLargeImage"><?php echo wordWrapManualWithSpace(html_entity_decode(stripslashes($this->mail_details_arr['message']), ENT_QUOTES, $this->CFG['site']['charset']), $this->CFG['admin']['mail']['line_length']); ?></p>
      <?php $anchor = 'dAlt2_' . $this->fields_arr['message_id']; ?>
      <a href="#" id="<?php echo $anchor; ?>" ></a> </td>
  </tr>
</table>
<?php
						$this->showMessageBottomHeader();
				}
		}
}
$mailread = new MailReadFormHandler();
if (!chkAllowedModule(array('mail'))) Redirect2URL($CFG['redirect']['dsabled_module_url']);
$mailread->setPageBlockNames(array('msg_form_error', 'msg_form_success', 'form_show_message', 'page_nav', 'form_confirm'));
$mailread->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$mailread->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$mailread->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$mailread->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$mailread->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$mailread->setDBObject($db);
$mailread->setCfgLangGlobal($CFG, $LANG);
$mailread->setFormField('folder', '');
$mailread->setFormField('message_id', '');
$mailread->setFormField('action', '');
$mailread->setFormField('delete', '');
$mailread->setFormField('save', '');
$mailread->setFormField('msg', '');
$mailread->setAllPageBlocksHide();
$mailread->sanitizeFormInputs($_REQUEST);
if (!$mailread->chkIsValidFolder())
{
?>
<div id="selMsgAlert">
  <p><?php echo $LANG['mail_invalid_folder']; ?></p>
</div>
<?php
		Redirect2URL(getUrl($CFG['admin']['mail_urls']['inbox']['normal'], $CFG['admin']['mail_urls']['inbox']['htaccess']));
}
if ($mailread->isValidMessageId())
{
		if ($mailread->isFormPOSTed($_POST, 'confirm'))
		{
				$mailread->chkIsNotEmpty('action', $LANG['mailread_err_tip_compulsory']) or $mailread->setCommonErrorMsg($LANG['mailread_select_action']);
				$mailread->setAllPageBlocksHide();
				$mailread->setPageBlockShow('msg_form_success');
				if ($mailread->isValidFormInputs())
				{
						switch ($mailread->getFormField('action'))
						{
								case 'mail_delete':
										$mailread->deleteMessage();
										break;
						}
						$next_id = $mailread->showNext($mailread->getFormField('message_id'));
						if ($next_id)
						{
								switch ($mailread->getFormField('action'))
								{
										case 'mail_delete':
												$redirectUrl = getUrl($mailread->getMailReadNormalUrl() . '&message_id=' . $next_id . '&msg=2', $mailread->getMailReadHtaccessUrl() . '?message_id=' . $next_id . '&msg=2');
												break;
								}
								Redirect2URL($redirectUrl);
						}
						else
						{
								Redirect2URL(getUrl($mailread->getMailListNormalUrl() . '&del=1', $mailread->getMailListHtaccessUrl() . '?del=1'));
						}
				}
				else
				{
						$mailread->setPageBlockShow('msg_form_error');
				}
		}
}
if ($mailread->isValidFormInputs())
{
		$mailread->updateMessageViews();
		$mailread->setPageBlockShow('form_show_message');
		if ($mailread->getFormField('msg'))
		{
				$mailread->setPageBlockShow('msg_form_success');
		}
}
else
{
		$mailread->setPageBlockShow('msg_form_error');
}



?>
<script type="text/javascript" language="javascript">
	var block_arr= new Array('selMsgConfirm');
	var replace_url = '<?php echo getUrl($CFG['site']['url'] . 'login.php', $CFG['site']['url'] . 'login/', false); ?>';
</script>
<div id="selInboxMessage">
  <h2><span><?php echo $mailread->mail_title; ?></span></h2>
  <div id="selLeftNavigation">
    <?php
if ($mailread->isShowPageBlock('msg_form_error'))
{
?>
    <div id="selMsgError">
      <p><?php echo $LANG['msg_error_sorry']; ?> <?php echo $mailread->getCommonErrorMsg(); ?></p>
    </div>
    <?php
}
if ($mailread->isShowPageBlock('msg_form_success'))
{
?>
    <div id="selMsgSuccess">
      <p>
        <?php
		switch ($mailread->getFormField('msg'))
		{
				case 1:
						echo $LANG['mailread_success_saved_message'];
						break;
				case 2:
						echo $LANG['mailread_success_delete_message'];
						break;
				case 3:
						echo $LANG['mailread_success_reply_message'];
						break;
				case 4:
						echo $LANG['mailread_success_forward_message'];
						break;
		}


?>
      </p>
    </div>
    <?php
}
if ($mailread->isShowPageBlock('form_show_message'))
{
?>
    <!-- Confirmation Div -->
    <div id="selMsgConfirm" class="clsPopupConfirmation" style="display:none;position:absolute;">
      <form name="msgConfirmform" id="msgConfirmform" method="post" action="<?php echo $_SERVER['REQUEST_URI']; ?>">
        <p id="confirmMessage"></p>
        <table summary="<?php echo $LANG['mailread_confirm_tbl_summary']; ?>">
          <tr>
            <td><input type="submit" class="clsSubmitButton" name="confirm" id="confirm" value="<?php echo $LANG['mailread_confirm']; ?>" tabindex="<?php echo $mailread->getTabIndex(); ?>" />
              &nbsp;
              <input type="button" class="clsCancelButton" name="cancel" id="cancel" value="<?php echo $LANG['mailread_cancel']; ?>" tabindex="<?php echo $mailread->getTabIndex(); ?>" onClick="return hideAllBlocks();" />
              <input type="hidden" name="action" />
            </td>
          </tr>
        </table>
      </form>
    </div>
    <div id="selshowMessage">
      <?php $mailread->showMessage(); ?>
    </div>
    <?php
}
?>
  </div>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>
