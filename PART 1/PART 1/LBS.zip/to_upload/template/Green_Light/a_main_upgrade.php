<?php include('template/Green_Light/b_inside_top.php');?>

<td valign="top">

<div class="page-header"><h1><?php echo("$lang_134");?></h1></div>

<div class="box" style="margin-left:10px">
	<div class="dbox_top"></div>
	<div class="dbox_middle1">
	<table border="0" cellpadding="3" cellspacing="2" width="100%">
		<tr>
			<td valign="top" width="150px"><div class="thumb"><a href="<?php echo $row_UPBID['site']; ?>" target="_blank"><img src="http://open.thumbshots.org/image.aspx?url=<?php echo $row_UPBID['site']; ?>" alt="<?php echo $row_UPBID['title']; ?>" border="0" /></a></div></td>
			<td valign="top"><div class="bid-title"><a href="<?php echo $row_UPBID['site']; ?>" target="_blank" class="style1"><?php echo $row_UPBID['title']; ?></a></div><div class="bid-descr"><?php echo $row_UPBID['descr2']; ?></div><div class="bid-url"><a href="<?php echo $row_UPBID['site']; ?>" target="_blank"><?php echo $row_UPBID['site']; ?></a></div></td>
		</tr>
	</table>
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="2%"><img src="" alt="" width="51" height="1" style="background-color: #FFFFFF" /></td>
        <td width="98%"><table width="60%" border="0" cellpadding="3" cellspacing="2">
          <tr>
            <td valign="top"><strong><?php echo("$lang_95");?>:</strong></td>
            <td valign="top"><?php
							$category = $row_UPBID['maincategory'];					
							mysql_select_db($database_apound, $apound);
							$query_LdetCAT = "SELECT * FROM categorylisting WHERE catlistid = '$category'";
							$LdetCAT = mysql_query($query_LdetCAT, $apound) or die(mysql_error());
							$row_LdetCAT = mysql_fetch_assoc($LdetCAT);
							$totalRows_LdetCAT = mysql_num_rows($LdetCAT);?>
                <div class="bid-cat"><a href="<?php echo("$path");?><?php echo $row_LdetCAT['categseoname']; ?>/"><?php echo $row_LdetCAT['categoryname'] ?></a></div></td>
            <td rowspan="4" align="right"><div class="rate1"><?php echo("$currency");?><?php echo $row_UPBID['bid']; ?></div></td>
          </tr>
          <?php if($prenabled == 'Y') { ?>
          <tr>
            <td valign="top"><strong><strong><?php echo("$lang_100");?></strong></strong></td>
            <td valign="top"><?php $sitewww = $row_UPBID['site']; $sitewwwA = str_replace("http://", "", $sitewww); $googlepagerankA = "$sitewwwA"; $sitewwwB = str_replace("/", "", $googlepagerankA); $googlepagerankB = "$sitewwwB"; ?>
                <img src="http://services.velnetweb.co.uk/gpr/gpr.php?sitepr=<?php echo("$sitewww");?>" alt="" border="0" /></td>
          </tr>
          <?php } else {} ?>
          <tr>
            <td valign="top"><strong><?php echo("$lang_96");?>:</strong></td>
            <td valign="top"><?php echo $row_UPBID['stad']; ?></td>
          </tr>
          <tr>
            <td valign="top"><strong><?php echo("$lang_97");?>:</strong></td>
            <td valign="top"><?php echo $row_UPBID['stup']; ?></td>
          </tr>
        </table></td>
      </tr>
    </table>
	<div class="box" style="margin-top:10px; margin-right:10px;">
	<div class="box-cap-left">
		<div class="box-cap-right">
			<div class="box-cap"></div>
		</div>
	</div>
	<div class="box-left">
		<div class="box-right">	
<table border="0" cellpadding="3" cellspacing="2">
	<tr>
		<td>	
<form action="<?php echo("$path");?>upgrade.php" method="post" name="form1" onsubmit="return chkfrm();">
    <?php echo("$currency");?> 
    <input name="newbid" type="text" id="newbid" value="<?php echo("$minup");?>" size="6" maxlength="6"  onchange="dodiv();" onkeypress="return chknum(event)" onkeyup="dodiv();" /> .00
    
    
    <br />
    1 point will be added to the listing rating for every <?php echo("$currency");?>1 you contribute<br />
Minimum contribution of <?php echo("$currency");?><?php echo("$minup");?> is required for the upgrade.<br>
<br>
Validation code: <input name="number" type="text" id=\&quot;number\&quot; /> 
(Type just with <strong><font color="#FF0000">CAPITAL</font></strong> letters)<br>
<img src="<?php echo("$path");?>random_image.php">
    
    <input name="oldbid" type="hidden" id="oldbid" value="<?php echo $row_UPBID['bid']; ?>">
    <input name="bidid" type="hidden" value="<?php echo $row_UPBID['dtu']; ?>">
    <input name="url" type="hidden" id="url" value="<?php echo $row_UPBID['site']; ?>">
    <input name="keyword" type="hidden" id="keyword" value="<?php echo $row_UPBID['title']; ?>">
    <input name="email" type="hidden" id="email" value="<?php echo $row_UPBID['email']; ?>">
    <input name="submit" type="submit" value="Continue >>">
    </form>
</table>
		</div>
	</div>
	<div class="box-bottom-left">
		<div class="box-bottom-right">
		</div>
	</div>
</div>	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	</div>
	</div>
	
</div>


<?php include('template/Green_Light/b_footer_tpl.php'); ?>