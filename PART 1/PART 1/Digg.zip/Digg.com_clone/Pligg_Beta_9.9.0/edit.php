<?php
// The source code packaged with this file is Free Software, Copyright (C) 2005 by
// Ricardo Galli <gallir at uib dot es>.
// It's licensed under the AFFERO GENERAL PUBLIC LICENSE unless stated otherwise.
// You can get copies of the licenses here:
// 		http://www.affero.org/oagpl.html
// AFFERO GENERAL PUBLIC LICENSE is also included in the file called "COPYING".

include_once('Smarty.class.php');
$main_smarty = new Smarty;

include('config.php');
include(mnminclude.'html1.php');
include(mnminclude.'ts.php');
include(mnminclude.'link.php');
include(mnminclude.'tags.php');
include(mnminclude.'smartyvariables.php');

if(is_numeric($_REQUEST['id'])) {

	$link = new Link;
	$link->id=$_REQUEST['id'];
	$link->commentid=$_REQUEST['commentid'];
	$link->read();

	$comments = $db->get_row("SELECT comment_user_id FROM " . table_comments . " WHERE comment_id=$link->commentid");
	$commentownerid = $comments->comment_user_id;
	$commentowner = $db->get_var("SELECT user_login FROM " . table_users . " WHERE user_id = ". $commentownerid);

	if ($_POST['process']=='newcomment') {
		insert_comment();
	}
	// Set globals
	$globals['link_id']=$link->id;
	$globals['commentid'] = $link->commentid;
	$globals['category_id']=$link->category;
	$globals['category_name']=$link->category_name();

	$main_smarty->assign('the_story', $link->print_summary('summary', true));

	if($current_user->user_level == "admin" or $current_user->user_level == "god"){
		$comments = $db->get_col("SELECT comment_id FROM " . table_comments . " WHERE comment_id=$link->commentid ORDER BY comment_date");
	} else {
		$comments = $db->get_col("SELECT comment_id FROM " . table_comments . " WHERE comment_id=$link->commentid and comment_user_id=$current_user->user_id ORDER BY comment_date");
	}	
	if ($comments) {
		$current_user->owncomment = "YES";
		require_once(mnminclude.'comment.php');
		$comment = new Comment;
		foreach($comments as $comment_id) {
			$comment->id=$comment_id;
			$comment->read();
			$comment->hideedit='yes';
			$main_smarty->assign('the_comment', $comment->print_summary($link, true));
			$link->thecomment = $comment->quickread();
			$main_smarty->assign('TheComment', $comment->quickread());
		}
	} else {
		$current_user->owncomment = "NO";
		echo $main_smarty->get_config_vars("PLIGG_Visual_EditComment_NotYours") . '<br/><br/>';
		echo $main_smarty->get_config_vars("PLIGG_Visual_EditComment_Click") . '<a href = "'.getmyurl('story', $_REQUEST['id']).'">'.$main_smarty->get_config_vars("PLIGG_Visual_EditComment_Here").'</a> '.$main_smarty->get_config_vars("PLIGG_Visual_EditComment_ToReturn").'<br/><br/>';
	}

	if($current_user->authenticated) {
		if($current_user->owncomment=="YES"){
			$main_smarty->assign('comment_form', print_comment_form(true));
		}
		if($current_user->user_level == "admin" or $current_user->user_level == "god"){
			$main_smarty->assign('removed_link', '<a href="#" onclick=(document.getElementById("comment").value="'.$main_smarty->get_config_vars("PLIGG_Visual_EditComment_Removed").'")>'.$main_smarty->get_config_vars("PLIGG_Visual_EditComment_Removed").'</a>');
		}
	} 

	// misc smarty
	$main_smarty->assign('Spell_Checker',Spell_Checker);

	// pagename
	define('pagename', 'edit'); 
	$main_smarty->assign('pagename', pagename);

	// show the template
	$main_smarty->assign('tpl_center', $the_template . '/edit_comment_center');
	$main_smarty->display($the_template . '/pligg.tpl');
}



// display comment for for editing
function print_comment_form($fetch = false) {
	global $link, $current_user, $main_smarty, $the_template;

	// misc smarty
	$main_smarty->assign('randkey', rand(1000000,100000000));
	$main_smarty->assign('link_id', $link->id);
	$main_smarty->assign('user_id', $current_user->user_id);

	if($fetch == false){
		// show the template
		$main_smarty->display($the_template . '/comment_form.tpl');
	} else {
		return $main_smarty->fetch($the_template . '/comment_form.tpl');
	}
}

function insert_comment () {
	global $commentownerid, $link, $db, $current_user;
	// Check if is a POST of a comment
	if($_POST['link_id'] == $link->id && $current_user->authenticated && $_POST['user_id'] == $current_user->user_id &&
		$_POST['randkey'] > 0 && strlen($_POST['comment_content']) > 0 ) {
		require_once(mnminclude.'comment.php');
		$comment = new Comment;
		$comment->id=$link->commentid;
		$comment->read();
		$comment->link=$link->id;
		$comment->randkey=$_POST['randkey'];
		$comment->author=$commentownerid; //$_POST['user_id'];
		$comment->content=$_POST['comment_content'];
		$comment->store();
		header('Location: ' . getmyurl('story', $_GET['id']));
		die;
	}
}

?>
