<?php
/**
 * MyBB 1.4 English Language Pack
 * Copyright � 2008 MyBB Group, All Rights Reserved
 * 
 * $Id: style_module_meta.lang.php 4304 2009-01-02 01:11:56Z chris $
 */
 
$l['templates_and_style'] = "Templates &amp; Style";

$l['themes'] = "Themes";
$l['templates'] = "Templates";

$l['can_manage_themes'] = "Can manage themes?";
$l['can_manage_templates'] = "Can manage templates?";

?>