<?php
if (class_exists('ListRecordsHandler'))
{
		class Handler extends ListRecordsHandler
		{
		}
}
else
{
		class Handler extends FormHandler
		{
		}
}
class ForumHandler extends Handler
{
		public function isValidForumId($forum_id, $err_tip = '')
		{
				$sql = 'SELECT forum_id, forum_title, forum_description, forum_status ' . 'FROM ' . $this->CFG['db']['tbl']['forums'] . ' ' . 'WHERE forum_id = ' . $this->dbObj->Param($forum_id) . ' ' . 'AND forum_status = \'Yes\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($forum_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($this->forum_details_arr = $rs->FetchRow())
				{
						return true;
				}
				$this->setCommonErrorMsg($err_tip);
				return false;
		}
		public function isValidForumTopicId($forum_id, $topic_id, $err_tip = '')
		{
				$sql = 'SELECT g.topic_id, g.forum_id, g.forum_topic, g.user_id, DATE_FORMAT(g.date_added, \'' . $this->CFG['format']['date'] . '\') AS date_added' . ', u.' . $this->getUserTableField('name') . ' AS name, u.' . $this->getUserTableField('image_path') . ' AS image_path, u.' . $this->getUserTableField('gender') . ' AS gender' . ' FROM ' . $this->CFG['db']['tbl']['forum_topics'] . ' AS g, ' . $this->CFG['db']['tbl']['users'] . ' AS u' . ' WHERE g.user_id = u.' . $this->getUserTableField('user_id') . ' AND topic_id = ' . $this->dbObj->Param($topic_id) . ' AND forum_id = ' . $this->dbObj->Param($forum_id) . ' AND g.topic_status = \'Yes\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($topic_id, $forum_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($this->forum_topic_details_arr = $rs->FetchRow())
				{
						return true;
				}
				$this->setCommonErrorMsg($err_tip);
				return false;
		}
		public function isValidForumResponseId($topic_id, $response_id, $err_tip = '')
		{
				$sql = 'SELECT response_id, topic_id, forum_response, response_user_id ' . 'FROM ' . $this->CFG['db']['tbl']['forum_response'] . ' ' . 'WHERE topic_id = ' . $this->dbObj->Param($topic_id) . ' ' . 'AND response_id = ' . $this->dbObj->Param($response_id) . ' ' . 'AND response_status = \'Yes\' ' . 'AND response_user_id = ' . $this->dbObj->Param($this->CFG['user']['user_id']);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($topic_id, $response_id, $this->CFG['user']['user_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($row = $rs->FetchRow())
				{
						$this->setFormField('forum_response', $row['forum_response']);
						return true;
				}
				$this->setCommonErrorMsg($err_tip);
				return false;
		}
		public function updateUsersAnsLog()
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['users_ans_log'] . ' SET total_posts = total_posts + 1' . ' WHERE ' . $this->getUserTableField('user_id') . ' = ' . $this->dbObj->Param($this->CFG['user']['user_id']);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->CFG['user']['user_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return true;
		}
		public function updateForums($forum_id)
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['forums'] . ' SET last_post_user_id = ' . $this->dbObj->Param($this->CFG['user']['user_id']) . ', last_post_date = now()' . ', total_topics = total_topics + 1' . ', total_response = total_response + 1' . ' WHERE forum_id = ' . $this->dbObj->Param($forum_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->CFG['user']['user_id'], $forum_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return true;
		}
		public function insertForumResponse($topic_id)
		{
				$sql = 'INSERT INTO ' . $this->CFG['db']['tbl']['forum_response'] . ' SET topic_id = ' . $this->dbObj->Param($topic_id) . ', forum_response = ' . $this->dbObj->Param($this->fields_arr['forum_response']) . ', response_user_id = ' . $this->dbObj->Param($this->CFG['user']['user_id']) . ', date_added = NOW()';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($topic_id, html_entity_decode($this->fields_arr['forum_response'], ENT_QUOTES, $this->CFG['site']['charset']), $this->CFG['user']['user_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return true;
		}
		public function showForumDetails($pageName = '')
		{
?>
			<div id="selGroupForumPost">
				<div class="clsBackForum"><h3 id="selBackToForum">
			  	<a href="<?php echo getUrl('forums.php', 'forum/'); ?>"> <?php echo $this->LANG['forumlinks_back_index']; ?></a>
			  	</h3></div>
		 		<div class="clsForumPost"><p class="clsAlignRight" id="post">
				<?php if ($pageName != 'responselist')
				{ ?>
					<a href="<?php echo getUrl($this->CFG['site']['url'] . 'members/forumsTopicCreate.php?forum_id=' . $this->forum_details_arr['forum_id'], $this->CFG['site']['url'] . 'members/forumcreate/' . $this->forum_details_arr['forum_id'] . '/', false); ?>"><?php echo $this->LANG['forumslinks_post_topic']; ?></a>
				<?php }
				else
				{ ?>
					<a href="<?php echo getUrl($this->CFG['site']['url'] . 'members/forumsResponseCreate.php?forum_id=' . $this->forum_details_arr['forum_id'] . '&topic_id=' . $this->forum_topic_details_arr['topic_id'], $this->CFG['site']['url'] . 'members/forumcreate/' . $this->forum_details_arr['forum_id'] . '/' . $this->forum_topic_details_arr['topic_id'] . '/', false); ?>"><?php echo $this->LANG['forumslinks_post_response']; ?></a>
				<?php } ?>
				</p></div>
			</div>
			<?php
		}
}
?>
