<?php

$LANG['err_tip_verified'] = 'Already verified';
$LANG['err_tip_invalid'] = 'Invalid';
$LANG['err_tip_locked'] = 'Account Locked';
$LANG['verified_successfully'] = 'Verified sucessfully';
$LANG['email_successfully'] = 'Email Changed sucessfully';
$LANG['err_tip_compulsory'] = 'Compulsory';
$LANG['verifymail_title'] = 'Mail Verification';
$LANG['verifymail_tbl_summary'] = 'form for mail Verification';
$LANG['verifymail_submit'] = 'Submit';
$LANG['verifymail_new_mail'] = 'Enter Your New MailID';
$LANG['err_tip_invalid_link'] = 'Invalid activation code';
$LANG['err_tip_invalid_mail'] = 'Invalid Mail';
$LANG['err_tip_already'] = 'Already Exists Mail';
?>