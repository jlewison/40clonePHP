<?php
$LANG['welcome_title'] = 'You\'re ready to go!';
$LANG['welcome_tbl'] = 'Welcome Page Content table';
$LANG['welcome_errors'] = 'Sorry errors Found.';
$LANG['welcome_content'] = 'Now that you have filled in the blanks, you can take advantage of all features of Anova! Answers.
Just one last reminder before you jump in - please respect the Anova {guidelines} when posting and remember that your use of Anova is subject to the Anova {term of service}
 ';
$LANG['welcome_enjoy'] = 'Enjoy !';
$LANG['welcome_continue'] = 'Continue';
?>