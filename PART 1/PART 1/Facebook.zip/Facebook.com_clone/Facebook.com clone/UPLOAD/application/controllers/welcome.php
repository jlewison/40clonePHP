<?php
/**
 * Welcome Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 2007-12-10
 */
class Welcome extends Controller
{
		function Welcome()
		{
				parent::Controller();
				loginRequired();
				//Load the language file
				$this->lang->load('welcome', $this->config->item('language_code'));
		}
		function index()
		{
				$this->load->model('usermodel');
				$this->load->model('groupsmodel');
				$this->load->model('eventsmodel');
				$this->load->model('friendsmodel');
				$user_id = $this->session->userdata('user_id');
				//user details
				$userDetails = $this->usermodel->getUserDetails($user_id);
				$outputData['userDetails'] = $userDetails[$user_id];
				$outputData['screenStatus'] = $this->usermodel->getScreenStatus();
				$outputData['groups_request_count'] = $this->groupsmodel->getRequestCount();
				$outputData['events_request_count'] = $this->eventsmodel->getRequestCount();
				$outputData['friends_request_count'] = $this->friendsmodel->getRequestCount();
				$this->smartyextended->view('welcome', $outputData);
		}
}
?>