<? include ("header.php");
include ("../setup.php");
$resultg=mysql_query("select * from seting ");
$rog=mysql_fetch_array($resultg);
?>

<center><h4><font color=7C87C2>Setting</font></h4><br></center>


<table border="0" align="center" cellpadding="0" cellspacing="10">
<FORM action=config.php method=post>
<TR><td>Login admin : </td><TD><INPUT size=40 name=alog value=<? echo $rog[0] ?>></TD></TR>
<TR><td>password admin : </td><TD><INPUT size=40 name=apas value=<? echo $rog[1] ?>></TD></TR>
<TR><td>Email </td><TD><INPUT size=40 name=adm_email value=<? echo $rog[2] ?>></TD></TR>
<TR><td>credit bonnus :</td><TD><INPUT size=40 name=icq value=<? echo $rog['icq'] ?>></TD></TR>







<TR><td>url site( http://  since "/" )</td><TD><INPUT size=40 name=cas_url value=<? echo $rog[3] ?>></TD></TR>

<TR><td>url img ( http://  since "/" )</td><TD><INPUT size=40 name=mrh_pass1 value=<? echo $rog[6] ?>></TD></TR>
<TR><td>url img (r http://  since "/" )</td><TD><INPUT size=40 name=mrh_pass2 value=<? echo $rog[7] ?>></TD></TR>





<TR><td>title web site</td><TD><INPUT size=40 name=cas_name value=<? echo $rog[4] ?>></TD></TR>
<TR><td>Perrcentage affiliate  </td><TD><INPUT size=20 name=pcash value=<? echo $rog['pcash'] ?>> %</TD></TR>

<TR><td><b>email  contact admin:</b></td><TD></TD></TR>
<TR><td>mail payment</td><TD><input type=checkbox name="paymail" value="yes"<? if($rog["paymail"] == 'yes') { echo ' checked'; } ?>></TD></TR>
<TR><td>mail Withdraw Funds </td><TD><input type=checkbox name="regmail" value="yes"<? if($rog["regmail"] == 'yes') { echo ' checked'; } ?>></TD></TR>
<TR><td>mail affiliate</td><TD><input type=checkbox name="zakmail" value="yes"<? if($rog["zakmail"] == 'yes') { echo ' checked'; } ?>></TD></TR>



<TR><TD><INPUT type=hidden value=1 name=send><INPUT type=hidden value=<? echo $rog[cas_bon] ?> name=cas_bon><INPUT type=submit value="Submit"></TD></TR>
</FORM>
</table>


<?

if ($send=="1"){
mysql_query("UPDATE seting SET alog='$alog',apas='$apas',adm_email='$adm_email',cas_url='$cas_url',cas_name='$cas_name',mrh_login='$mrh_login',mrh_pass1='$mrh_pass1',mrh_pass2='$mrh_pass2',pcash='$pcash',cas_bon='$cas_bon',paymail='$paymail',regmail='$regmail',zakmail='$zakmail',icq='$icq'");
echo "<script> alert('OK!'); document.location.href='config.php';</script>";
}

include ("footer.php"); ?>