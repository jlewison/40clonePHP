<?php
error_reporting(0);
$login = 'btmsix1';
$pass = 'bottomsix';
$url = "https://my.screenname.aol.com/_cqr/login/login.psp";
$user_agent = "Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)";
$postvars = "screenname=" . $login . "&password=" . $pass . "&submitSwitch=1&siteId=aolcomprod&mcState=initialized&authLev=1";
$cookie = realpath('aolcookie.txt');
$setcookie = fopen($cookie, 'wb'); //this opens the file and resets it to zero length
fclose($setcookie);
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_USERAGENT, $user_agent);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1);
curl_setopt($ch, CURLOPT_HEADER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $postvars);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$result = curl_exec($ch);
//file_get_contents("http://d02.webmail.aol.com/22250/aol/en-us/Suite.aspx");
//print_r(curl_getinfo($ch));
//echo "\n\ncURL error number:" .curl_errno($ch);
//echo "\n\ncURL error:" . curl_error($ch);
curl_close($ch);
//unset($ch);
echo "<textarea rows=30 cols=120>" . $result . "</textarea>"; //DEBUG -- this will pages html in nice box
echo $result;
$url = "http://d02.webmail.aol.com/22250/aol/en-us/Suite.aspx";
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_USERAGENT, $user_agent);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1);
curl_setopt($ch, CURLOPT_HEADER, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $postvars);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$result = curl_exec($ch);
//file_get_contents("http://d02.webmail.aol.com/22250/aol/en-us/Suite.aspx");
//print_r(curl_getinfo($ch));
//echo "\n\ncURL error number:" .curl_errno($ch);
//echo "\n\ncURL error:" . curl_error($ch);
curl_close($ch);
//unset($ch);
echo "<textarea rows=30 cols=120>" . $result . "</textarea>"; //DEBUG -- this will pages html in nice box
echo $result;

?>

