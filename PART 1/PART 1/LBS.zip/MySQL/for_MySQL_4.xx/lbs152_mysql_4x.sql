-- phpMyAdmin SQL Dump
-- version 2.8.2.4
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Dec 16, 2008 at 04:42 PM
-- Server version: 5.0.45
-- PHP Version: 5.2.5
-- 
-- Database: `lbs15pack`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `about`
-- 

CREATE TABLE `about` (
  `abid` int(4) NOT NULL auto_increment,
  `abcontent` longtext,
  UNIQUE KEY `abid` (`abid`)
) TYPE=MyISAM AUTO_INCREMENT=2 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `about`
-- 

INSERT INTO `about` (`abid`, `abcontent`) VALUES (1, 'This is a classic example of an LBS script about us page, please update the contents of this page.\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<br><br>\r\n\r\nUt enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.<br><br>\r\n\r\nExcepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est misi.<br><br>');

-- --------------------------------------------------------

-- 
-- Table structure for table `adsense`
-- 

CREATE TABLE `adsense` (
  `adsenseid` int(4) NOT NULL auto_increment,
  `adsensecode` longtext NOT NULL,
  UNIQUE KEY `adsenseid` (`adsenseid`)
) TYPE=MyISAM AUTO_INCREMENT=2 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `adsense`
-- 

INSERT INTO `adsense` (`adsenseid`, `adsensecode`) VALUES (1, '<a href="http://www.haabaa.com/sitepromotion/" target="_blank"><img src="/template/lbs/img/haabaapromo.gif" alt="Get Top 10 Exposure" width="120" height="600" border="0" /></a>');

-- --------------------------------------------------------

-- 
-- Table structure for table `captcha`
-- 

CREATE TABLE `captcha` (
  `chp_id` int(4) NOT NULL auto_increment,
  `chp_onoff` varchar(255) NOT NULL default 'Y',
  `chp_distors` varchar(255) NOT NULL default '2',
  `chp_leng` varchar(255) NOT NULL default '5',
  `chp_typ` varchar(255) NOT NULL default 'A',
  `chp_simp` varchar(255) NOT NULL default '10',
  UNIQUE KEY `chp_id` (`chp_id`)
) TYPE=MyISAM AUTO_INCREMENT=2 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `captcha`
-- 

INSERT INTO `captcha` (`chp_id`, `chp_onoff`, `chp_distors`, `chp_leng`, `chp_typ`, `chp_simp`) VALUES (1, 'Y', '3', '7', 'N', '30');

-- --------------------------------------------------------

-- 
-- Table structure for table `categorylisting`
-- 

CREATE TABLE `categorylisting` (
  `catlistid` int(4) NOT NULL auto_increment,
  `categoryname` varchar(255) NOT NULL default '',
  `categtitle` varchar(255) NOT NULL default '',
  `categdescription` varchar(255) NOT NULL default '',
  `categkeyword` varchar(255) NOT NULL default '',
  `categenable` char(1) NOT NULL default 'Y',
  `categseoname` varchar(255) NOT NULL default '',
  `parentid` int(11) NOT NULL default '0',
  `categauxC` varchar(255) NOT NULL default '',
  UNIQUE KEY `catlistid` (`catlistid`)
) TYPE=MyISAM AUTO_INCREMENT=55 AUTO_INCREMENT=55 ;

-- 
-- Dumping data for table `categorylisting`
-- 

INSERT INTO `categorylisting` (`catlistid`, `categoryname`, `categtitle`, `categdescription`, `categkeyword`, `categenable`, `categseoname`, `parentid`, `categauxC`) VALUES (1, 'Advertising', 'Advertising', 'Advertising and promotion services', 'Advertising, promotion', 'Y', 'advertising', 0, ''),
(2, 'Bid Directories', 'Bid Directories', 'Bid Directories', 'Bid Directories', 'Y', 'Bid-Directories', 0, ''),
(3, 'Blogs', 'Blogs', 'Blogs', 'Blogs', 'Y', 'Blogs', 0, ''),
(4, 'Business', 'Business', 'Business', 'Business', 'Y', 'Business', 0, ''),
(5, 'Education', 'Education', 'Education', 'Education', 'Y', 'Education', 0, ''),
(6, 'Entertainment', 'Entertainment', 'Entertainment', 'Entertainment', 'Y', 'Entertainment', 0, ''),
(7, 'Forums', 'Forums', 'Forums', 'Forums', 'Y', 'Forums', 0, ''),
(8, 'Free Directories', 'Free Directories', 'Free Directories', 'Free Directories', 'Y', 'Free-Directories', 0, ''),
(9, 'Games', 'Games', 'Games', 'Games', 'Y', 'Games', 0, ''),
(10, 'Internet', 'Internet', 'Internet', 'Internet', 'Y', 'Internet', 0, ''),
(11, 'Paid Directories', 'Paid Directories', 'Paid Directories', 'Paid Directories', 'Y', 'Paid-Directories', 0, ''),
(12, 'Shopping', 'Shopping', 'Shopping', 'Shopping', 'Y', 'Shopping', 0, ''),
(13, 'Sports', 'Sports', 'Sports', 'Sports', 'Y', 'Sports', 0, ''),
(14, 'Technology', 'Technology', 'Technology', 'Technology', 'N', 'Technology', 0, ''),
(15, 'Web Development', 'Web Development', 'Web Development', 'Web Development', 'Y', 'Web-Development', 0, ''),
(16, 'Web Hosting', 'Web Hosting', 'Web Hosting', 'Web Hosting', 'Y', 'web-hosting', 0, ''),
(17, 'Outdoors', 'Outdoors', 'Outdoors', 'Outdoors', 'Y', 'Outdoors', 0, ''),
(18, 'Webmaster Resources', 'Webmaster Resources', 'Webmaster Resources', 'Webmaster Resources', 'Y', 'webmaster-resources', 0, ''),
(19, 'Web Design', 'Web Design', 'Web Design', 'Web Design', 'Y', 'web-design', 0, ''),
(25, 'History', 'History', 'History', 'History', 'Y', 'History', 0, ''),
(21, 'Computers', 'Computers', 'Computer products, resources, and services', 'computer, software, hardware, windows, operating system', 'Y', 'computers', 0, ''),
(22, 'Directory Resources', 'Directory Resources', 'Directory Resources', 'Directory Resources', 'Y', 'directory-resources', 0, ''),
(23, 'Holidays', 'Holidays', 'Holidays', 'Holidays', 'Y', 'Holidays', 0, ''),
(24, 'Home and Garden', 'Home and Garden', 'Home and Garden', 'Home and Garden', 'Y', 'Home-and-Garden', 0, ''),
(27, 'USA', 'USA', 'USA', 'USA', 'Y', 'USA', 0, ''),
(31, 'UK', 'UK', 'UK', 'UK', 'Y', 'UK', 0, '');

-- --------------------------------------------------------

-- 
-- Table structure for table `confset`
-- 

CREATE TABLE `confset` (
  `indc` int(4) NOT NULL auto_increment,
  `path` varchar(255) NOT NULL default '/',
  `paypal` varchar(255) NOT NULL default 'yourname@paypal.com',
  `paypalcurrency` varchar(255) NOT NULL default 'USD',
  `contactmail` varchar(255) NOT NULL default 'yourname@yourdomain.com',
  `adminmail` varchar(255) NOT NULL default 'yourname@yourdomain.com',
  `currency` varchar(255) NOT NULL default '1',
  `minbid` varchar(9) NOT NULL default '1.00',
  `minup` varchar(9) NOT NULL default '1.00',
  `currencymail` varchar(255) NOT NULL default '1',
  `pathmail` varchar(255) NOT NULL default '/',
  `frommail` varchar(255) NOT NULL default 'yourname@yourdomain.com',
  `contactmailsubject` varchar(255) NOT NULL default 'message from yoursite.com',
  `domainname` varchar(255) NOT NULL default 'www.yourdomain.com',
  `sitetitle` varchar(255) NOT NULL default 'Your Site Title Slogan',
  `custom` varchar(255) NOT NULL default '',
  `lbdtemplate` varchar(255) NOT NULL default 'default',
  `alphacat` char(1) NOT NULL default 'C',
  `prenabled` char(1) NOT NULL default 'Y',
  `screenshot` char(1) NOT NULL default 'Y',
  `buymailsubject` varchar(255) NOT NULL default 'Your submission at LinkBidScript.com',
  `buymailmessage` longtext NOT NULL,
  `bidmailsubject` varchar(255) NOT NULL default 'Thank you for your bid!',
  `bidmailmessage` longtext NOT NULL,
  `pr_google` char(1) NOT NULL default 'Y',
  `pr_yahoo` char(1) NOT NULL default 'Y',
  `pr_msn` char(1) NOT NULL default 'Y',
  `pr_alexa` char(1) NOT NULL default 'Y',
  `prp_latest` char(1) NOT NULL default 'Y',
  `prp_category` char(1) NOT NULL default 'Y',
  `prp_details` char(1) NOT NULL default 'Y',
  `prp_home` char(1) NOT NULL default 'Y',
  `prp_links` char(1) NOT NULL default 'Y',
  `prp_list` char(1) NOT NULL default 'Y',
  `prp_search` char(1) NOT NULL default 'Y',
  `cntIM` char(1) NOT NULL default 'N',
  `pstats` varchar(255) NOT NULL default 'Y',
  `overbid` char(1) NOT NULL default 'Y',
  `overbid_L_s` varchar(255) default NULL,
  `overbid_L` longtext,
  `overbid_C_s` varchar(255) default NULL,
  `overbid_C` longtext,
  `HP_ordby_F` varchar(255) NOT NULL default 'bid',
  `HP_ordby_O` varchar(255) NOT NULL default 'DESC',
  `TL_ordby_F` varchar(255) NOT NULL default 'bid',
  `TL_ordby_O` varchar(255) NOT NULL default 'DESC',
  `CL_ordby_F` varchar(255) NOT NULL default 'bid',
  `CL_ordby_O` varchar(255) NOT NULL default 'DESC',
  `AL_ordby_F` varchar(255) NOT NULL default 'bid',
  `AL_ordby_O` varchar(255) NOT NULL default 'DESC',
  `onoff` varchar(255) NOT NULL default 'Y',
  `htL` varchar(255) NOT NULL default 'Y',
  `google_m` char(1) NOT NULL default 'Y',
  `google_m_k` longtext,
  `lexv` varchar(255) NOT NULL default 'LIMITED',
  `fremode` char(1) NOT NULL default 'N',
  `langu_id` varchar(255) NOT NULL default '1',
  `p_about` char(1) NOT NULL default 'Y',
  `p_top` char(1) NOT NULL default 'Y',
  `p_terms` char(1) NOT NULL default 'Y',
  `linkbacka` longtext,
  `fmwb` char(1) NOT NULL default 'N',
  `fmau` varchar(1) NOT NULL default 'N',
  `asubm` char(1) default 'N',
  UNIQUE KEY `indc` (`indc`)
) TYPE=MyISAM AUTO_INCREMENT=2 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `confset`
-- 

INSERT INTO `confset` (`indc`, `path`, `paypal`, `paypalcurrency`, `contactmail`, `adminmail`, `currency`, `minbid`, `minup`, `currencymail`, `pathmail`, `frommail`, `contactmailsubject`, `domainname`, `sitetitle`, `custom`, `lbdtemplate`, `alphacat`, `prenabled`, `screenshot`, `buymailsubject`, `buymailmessage`, `bidmailsubject`, `bidmailmessage`, `pr_google`, `pr_yahoo`, `pr_msn`, `pr_alexa`, `prp_latest`, `prp_category`, `prp_details`, `prp_home`, `prp_links`, `prp_list`, `prp_search`, `cntIM`, `pstats`, `overbid`, `overbid_L_s`, `overbid_L`, `overbid_C_s`, `overbid_C`, `HP_ordby_F`, `HP_ordby_O`, `TL_ordby_F`, `TL_ordby_O`, `CL_ordby_F`, `CL_ordby_O`, `AL_ordby_F`, `AL_ordby_O`, `onoff`, `htL`, `google_m`, `google_m_k`, `lexv`, `fremode`, `langu_id`, `p_about`, `p_top`, `p_terms`, `linkbacka`, `fmwb`, `fmau`, `asubm`) VALUES (1, '/', 'doNotReply@linkbidscript.com', 'USD', 'doNotReply@linkbidscript.com', 'doNotReply@linkbidscript.com', '3', '1', '1', '3', '', 'doNotReply@linkbidscript.com', 'Message from linkbidscript.com', 'lbs152.com', 'Link Bid Script Powered Site', '1', 'lbs', 'C', 'Y', 'Y', 'Submission details at LinkBidScript Directory', 'Your new listing details have been received and will be processed shortly.\r\n\r\nAfter your payment is confirmed the listing will be live in the category you selected and on the alphabetical list under first letter of your title.\r\nPosition of your listing will depend on current rating and can be upgraded at any time by purchasing more rating points.\r\n\r\nKeep in mind that listings with top 10 ratings will be displayed on the home page which will give most benefits for search engine rankings and potential traffic.\r\n\r\nThank you\r\nLinkBidScript Support Team\r\n\r\nGet more exposure! Submit your site to http://biddirectory.linkbidscript.com/', 'Thank you for upgrading your listing!', 'Your listing upgrade request has been received and will be processed shortly.\r\n\r\nAfter your payment is confirmed new contribution will be added to the listing rating and position will be updated automatically.\r\n\r\nThank you\r\nLinkBidScript Support Team\r\n\r\nGet more exposure! Submit your site to http://biddirectory.linkbidscript.com/', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Outbid notification from LBS', 'Someone outbid your link on $sitetitle for:\r\n\r\n$old_site_L\r\n\r\nBid now to reclaim your rank!\r\n\r\nhttp://$domainname/$old_id_L/$seo_name.html\r\n\r\nBest Regards,\r\n\r\n$sitetitle\r\nhttp://$domainname/\r\n======================================================================\r\nYou may want to submit your site to other bidding directory:\r\nhttp://biddirectory.linkbidscript.com\r\nhttp://www.linkslinky.net\r\nhttp://www.definiteweb.net\r\nhttp://www.wura.co.uk\r\n======================================================================', 'Outbid notification from LBS A', 'Someone outbid your link on $sitetitle for:\r\n\r\n$old_site_C $old_email_C\r\n\r\nBid now to reclaim your rank!\r\n\r\nhttp://$domainname/$old_id_C/$seo_name.html\r\n\r\nBest Regards,\r\n\r\n$sitetitle\r\nhttp://$domainname/\r\n======================================================================\r\nYou may want to submit your site to other bidding directory:\r\nhttp://biddirectory.linkbidscript.com\r\nhttp://www.linkslinky.net\r\nhttp://www.definiteweb.net\r\nhttp://www.wura.co.uk\r\n======================================================================', 'bid', 'DESC', 'bid', 'DESC', 'bid', 'DESC', 'bid', 'DESC', 'Y', 'Y', 'N', 'ABQIAAAA6oBw57Pd73YoFGfdis4DzBQDfyK-hge5YIymf_xbb-DnqKsC_BT5-6wDR3zBPpvIgCwY3inPf6Tyuw', 'UNLIMITED', 'N', '1', 'Y', 'Y', 'Y', '<a href="http://www.linkbidscript.com/">LBS</a>', 'N', 'N', 'N');

-- --------------------------------------------------------

-- 
-- Table structure for table `country`
-- 

CREATE TABLE `country` (
  `iso` varchar(2) NOT NULL default '',
  `name` varchar(80) NOT NULL default '',
  `printable_name` varchar(80) NOT NULL default '',
  `iso3` varchar(3) default NULL,
  `numcode` smallint(6) default NULL,
  PRIMARY KEY  (`iso`)
) TYPE=MyISAM;

-- 
-- Dumping data for table `country`
-- 

INSERT INTO `country` (`iso`, `name`, `printable_name`, `iso3`, `numcode`) VALUES ('AD', 'ANDORRA', 'Andorra', 'AND', 20),
('AE', 'UNITED ARAB EMIRATES', 'United Arab Emirates', 'ARE', 784),
('AF', 'AFGHANISTAN', 'Afghanistan', 'AFG', 4),
('AG', 'ANTIGUA AND BARBUDA', 'Antigua and Barbuda', 'ATG', 28),
('AI', 'ANGUILLA', 'Anguilla', 'AIA', 660),
('AL', 'ALBANIA', 'Albania', 'ALB', 8),
('AM', 'ARMENIA', 'Armenia', 'ARM', 51),
('AN', 'NETHERLANDS ANTILLES', 'Netherlands Antilles', 'ANT', 530),
('AO', 'ANGOLA', 'Angola', 'AGO', 24),
('AQ', 'ANTARCTICA', 'Antarctica', NULL, NULL),
('AR', 'ARGENTINA', 'Argentina', 'ARG', 32),
('AS', 'AMERICAN SAMOA', 'American Samoa', 'ASM', 16),
('AT', 'AUSTRIA', 'Austria', 'AUT', 40),
('AU', 'AUSTRALIA', 'Australia', 'AUS', 36),
('AW', 'ARUBA', 'Aruba', 'ABW', 533),
('AZ', 'AZERBAIJAN', 'Azerbaijan', 'AZE', 31),
('BA', 'BOSNIA AND HERZEGOVINA', 'Bosnia and Herzegovina', 'BIH', 70),
('BB', 'BARBADOS', 'Barbados', 'BRB', 52),
('BD', 'BANGLADESH', 'Bangladesh', 'BGD', 50),
('BE', 'BELGIUM', 'Belgium', 'BEL', 56),
('BF', 'BURKINA FASO', 'Burkina Faso', 'BFA', 854),
('BG', 'BULGARIA', 'Bulgaria', 'BGR', 100),
('BH', 'BAHRAIN', 'Bahrain', 'BHR', 48),
('BI', 'BURUNDI', 'Burundi', 'BDI', 108),
('BJ', 'BENIN', 'Benin', 'BEN', 204),
('BM', 'BERMUDA', 'Bermuda', 'BMU', 60),
('BN', 'BRUNEI DARUSSALAM', 'Brunei Darussalam', 'BRN', 96),
('BO', 'BOLIVIA', 'Bolivia', 'BOL', 68),
('BR', 'BRAZIL', 'Brazil', 'BRA', 76),
('BS', 'BAHAMAS', 'Bahamas', 'BHS', 44),
('BT', 'BHUTAN', 'Bhutan', 'BTN', 64),
('BV', 'BOUVET ISLAND', 'Bouvet Island', NULL, NULL),
('BW', 'BOTSWANA', 'Botswana', 'BWA', 72),
('BY', 'BELARUS', 'Belarus', 'BLR', 112),
('BZ', 'BELIZE', 'Belize', 'BLZ', 84),
('CA', 'CANADA', 'Canada', 'CAN', 124),
('CC', 'COCOS (KEELING) ISLANDS', 'Cocos (Keeling) Islands', NULL, NULL),
('CD', 'CONGO, THE DEMOCRATIC REPUBLIC OF THE', 'Congo, the Democratic Republic of the', 'COD', 180),
('CF', 'CENTRAL AFRICAN REPUBLIC', 'Central African Republic', 'CAF', 140),
('CG', 'CONGO', 'Congo', 'COG', 178),
('CH', 'SWITZERLAND', 'Switzerland', 'CHE', 756),
('CI', 'COTE D''IVOIRE', 'Cote D''Ivoire', 'CIV', 384),
('CK', 'COOK ISLANDS', 'Cook Islands', 'COK', 184),
('CL', 'CHILE', 'Chile', 'CHL', 152),
('CM', 'CAMEROON', 'Cameroon', 'CMR', 120),
('CN', 'CHINA', 'China', 'CHN', 156),
('CO', 'COLOMBIA', 'Colombia', 'COL', 170),
('CR', 'COSTA RICA', 'Costa Rica', 'CRI', 188),
('CS', 'SERBIA AND MONTENEGRO', 'Serbia and Montenegro', NULL, NULL),
('CU', 'CUBA', 'Cuba', 'CUB', 192),
('CV', 'CAPE VERDE', 'Cape Verde', 'CPV', 132),
('CX', 'CHRISTMAS ISLAND', 'Christmas Island', NULL, NULL),
('CY', 'CYPRUS', 'Cyprus', 'CYP', 196),
('CZ', 'CZECH REPUBLIC', 'Czech Republic', 'CZE', 203),
('DE', 'GERMANY', 'Germany', 'DEU', 276),
('DJ', 'DJIBOUTI', 'Djibouti', 'DJI', 262),
('DK', 'DENMARK', 'Denmark', 'DNK', 208),
('DM', 'DOMINICA', 'Dominica', 'DMA', 212),
('DO', 'DOMINICAN REPUBLIC', 'Dominican Republic', 'DOM', 214),
('DZ', 'ALGERIA', 'Algeria', 'DZA', 12),
('EC', 'ECUADOR', 'Ecuador', 'ECU', 218),
('EE', 'ESTONIA', 'Estonia', 'EST', 233),
('EG', 'EGYPT', 'Egypt', 'EGY', 818),
('EH', 'WESTERN SAHARA', 'Western Sahara', 'ESH', 732),
('ER', 'ERITREA', 'Eritrea', 'ERI', 232),
('ES', 'SPAIN', 'Spain', 'ESP', 724),
('ET', 'ETHIOPIA', 'Ethiopia', 'ETH', 231),
('FI', 'FINLAND', 'Finland', 'FIN', 246),
('FJ', 'FIJI', 'Fiji', 'FJI', 242),
('FK', 'FALKLAND ISLANDS (MALVINAS)', 'Falkland Islands (Malvinas)', 'FLK', 238),
('FM', 'MICRONESIA, FEDERATED STATES OF', 'Micronesia, Federated States of', 'FSM', 583),
('FO', 'FAROE ISLANDS', 'Faroe Islands', 'FRO', 234),
('FR', 'FRANCE', 'France', 'FRA', 250),
('GA', 'GABON', 'Gabon', 'GAB', 266),
('GD', 'GRENADA', 'Grenada', 'GRD', 308),
('GE', 'GEORGIA', 'Georgia', 'GEO', 268),
('GF', 'FRENCH GUIANA', 'French Guiana', 'GUF', 254),
('GH', 'GHANA', 'Ghana', 'GHA', 288),
('GI', 'GIBRALTAR', 'Gibraltar', 'GIB', 292),
('GL', 'GREENLAND', 'Greenland', 'GRL', 304),
('GM', 'GAMBIA', 'Gambia', 'GMB', 270),
('GN', 'GUINEA', 'Guinea', 'GIN', 324),
('GP', 'GUADELOUPE', 'Guadeloupe', 'GLP', 312),
('GQ', 'EQUATORIAL GUINEA', 'Equatorial Guinea', 'GNQ', 226),
('GR', 'GREECE', 'Greece', 'GRC', 300),
('GS', 'SOUTH GEORGIA AND THE SOUTH SANDWICH ISLANDS', 'South Georgia and the South Sandwich Islands', NULL, NULL),
('GT', 'GUATEMALA', 'Guatemala', 'GTM', 320),
('GU', 'GUAM', 'Guam', 'GUM', 316),
('GW', 'GUINEA-BISSAU', 'Guinea-Bissau', 'GNB', 624),
('GY', 'GUYANA', 'Guyana', 'GUY', 328),
('HK', 'HONG KONG', 'Hong Kong', 'HKG', 344),
('HM', 'HEARD ISLAND AND MCDONALD ISLANDS', 'Heard Island and Mcdonald Islands', NULL, NULL),
('HN', 'HONDURAS', 'Honduras', 'HND', 340),
('HR', 'CROATIA', 'Croatia', 'HRV', 191),
('HT', 'HAITI', 'Haiti', 'HTI', 332),
('HU', 'HUNGARY', 'Hungary', 'HUN', 348),
('ID', 'INDONESIA', 'Indonesia', 'IDN', 360),
('IE', 'IRELAND', 'Ireland', 'IRL', 372),
('IL', 'ISRAEL', 'Israel', 'ISR', 376),
('IN', 'INDIA', 'India', 'IND', 356),
('IO', 'BRITISH INDIAN OCEAN TERRITORY', 'British Indian Ocean Territory', NULL, NULL),
('IQ', 'IRAQ', 'Iraq', 'IRQ', 368),
('IR', 'IRAN, ISLAMIC REPUBLIC OF', 'Iran, Islamic Republic of', 'IRN', 364),
('IS', 'ICELAND', 'Iceland', 'ISL', 352),
('IT', 'ITALY', 'Italy', 'ITA', 380),
('JM', 'JAMAICA', 'Jamaica', 'JAM', 388),
('JO', 'JORDAN', 'Jordan', 'JOR', 400),
('JP', 'JAPAN', 'Japan', 'JPN', 392),
('KE', 'KENYA', 'Kenya', 'KEN', 404),
('KG', 'KYRGYZSTAN', 'Kyrgyzstan', 'KGZ', 417),
('KH', 'CAMBODIA', 'Cambodia', 'KHM', 116),
('KI', 'KIRIBATI', 'Kiribati', 'KIR', 296),
('KM', 'COMOROS', 'Comoros', 'COM', 174),
('KN', 'SAINT KITTS AND NEVIS', 'Saint Kitts and Nevis', 'KNA', 659),
('KP', 'KOREA, DEMOCRATIC PEOPLE''S REPUBLIC OF', 'Korea, Democratic People''s Republic of', 'PRK', 408),
('KR', 'KOREA, REPUBLIC OF', 'Korea, Republic of', 'KOR', 410),
('KW', 'KUWAIT', 'Kuwait', 'KWT', 414),
('KY', 'CAYMAN ISLANDS', 'Cayman Islands', 'CYM', 136),
('KZ', 'KAZAKHSTAN', 'Kazakhstan', 'KAZ', 398),
('LA', 'LAO PEOPLE''S DEMOCRATIC REPUBLIC', 'Lao People''s Democratic Republic', 'LAO', 418),
('LB', 'LEBANON', 'Lebanon', 'LBN', 422),
('LC', 'SAINT LUCIA', 'Saint Lucia', 'LCA', 662),
('LI', 'LIECHTENSTEIN', 'Liechtenstein', 'LIE', 438),
('LK', 'SRI LANKA', 'Sri Lanka', 'LKA', 144),
('LR', 'LIBERIA', 'Liberia', 'LBR', 430),
('LS', 'LESOTHO', 'Lesotho', 'LSO', 426),
('LT', 'LITHUANIA', 'Lithuania', 'LTU', 440),
('LU', 'LUXEMBOURG', 'Luxembourg', 'LUX', 442),
('LV', 'LATVIA', 'Latvia', 'LVA', 428),
('LY', 'LIBYAN ARAB JAMAHIRIYA', 'Libyan Arab Jamahiriya', 'LBY', 434),
('MA', 'MOROCCO', 'Morocco', 'MAR', 504),
('MC', 'MONACO', 'Monaco', 'MCO', 492),
('MD', 'MOLDOVA, REPUBLIC OF', 'Moldova, Republic of', 'MDA', 498),
('MG', 'MADAGASCAR', 'Madagascar', 'MDG', 450),
('MH', 'MARSHALL ISLANDS', 'Marshall Islands', 'MHL', 584),
('MK', 'MACEDONIA, THE FORMER YUGOSLAV REPUBLIC OF', 'Macedonia, the Former Yugoslav Republic of', 'MKD', 807),
('ML', 'MALI', 'Mali', 'MLI', 466),
('MM', 'MYANMAR', 'Myanmar', 'MMR', 104),
('MN', 'MONGOLIA', 'Mongolia', 'MNG', 496),
('MO', 'MACAO', 'Macao', 'MAC', 446),
('MP', 'NORTHERN MARIANA ISLANDS', 'Northern Mariana Islands', 'MNP', 580),
('MQ', 'MARTINIQUE', 'Martinique', 'MTQ', 474),
('MR', 'MAURITANIA', 'Mauritania', 'MRT', 478),
('MS', 'MONTSERRAT', 'Montserrat', 'MSR', 500),
('MT', 'MALTA', 'Malta', 'MLT', 470),
('MU', 'MAURITIUS', 'Mauritius', 'MUS', 480),
('MV', 'MALDIVES', 'Maldives', 'MDV', 462),
('MW', 'MALAWI', 'Malawi', 'MWI', 454),
('MX', 'MEXICO', 'Mexico', 'MEX', 484),
('MY', 'MALAYSIA', 'Malaysia', 'MYS', 458),
('MZ', 'MOZAMBIQUE', 'Mozambique', 'MOZ', 508),
('NA', 'NAMIBIA', 'Namibia', 'NAM', 516),
('NC', 'NEW CALEDONIA', 'New Caledonia', 'NCL', 540),
('NE', 'NIGER', 'Niger', 'NER', 562),
('NF', 'NORFOLK ISLAND', 'Norfolk Island', 'NFK', 574),
('NG', 'NIGERIA', 'Nigeria', 'NGA', 566),
('NI', 'NICARAGUA', 'Nicaragua', 'NIC', 558),
('NL', 'NETHERLANDS', 'Netherlands', 'NLD', 528),
('NO', 'NORWAY', 'Norway', 'NOR', 578),
('NP', 'NEPAL', 'Nepal', 'NPL', 524),
('NR', 'NAURU', 'Nauru', 'NRU', 520),
('NU', 'NIUE', 'Niue', 'NIU', 570),
('NZ', 'NEW ZEALAND', 'New Zealand', 'NZL', 554),
('OM', 'OMAN', 'Oman', 'OMN', 512),
('PA', 'PANAMA', 'Panama', 'PAN', 591),
('PE', 'PERU', 'Peru', 'PER', 604),
('PF', 'FRENCH POLYNESIA', 'French Polynesia', 'PYF', 258),
('PG', 'PAPUA NEW GUINEA', 'Papua New Guinea', 'PNG', 598),
('PH', 'PHILIPPINES', 'Philippines', 'PHL', 608),
('PK', 'PAKISTAN', 'Pakistan', 'PAK', 586),
('PL', 'POLAND', 'Poland', 'POL', 616),
('PM', 'SAINT PIERRE AND MIQUELON', 'Saint Pierre and Miquelon', 'SPM', 666),
('PN', 'PITCAIRN', 'Pitcairn', 'PCN', 612),
('PR', 'PUERTO RICO', 'Puerto Rico', 'PRI', 630),
('PS', 'PALESTINIAN TERRITORY, OCCUPIED', 'Palestinian Territory, Occupied', NULL, NULL),
('PT', 'PORTUGAL', 'Portugal', 'PRT', 620),
('PW', 'PALAU', 'Palau', 'PLW', 585),
('PY', 'PARAGUAY', 'Paraguay', 'PRY', 600),
('QA', 'QATAR', 'Qatar', 'QAT', 634),
('RE', 'REUNION', 'Reunion', 'REU', 638),
('RO', 'ROMANIA', 'Romania', 'ROM', 642),
('RU', 'RUSSIAN FEDERATION', 'Russian Federation', 'RUS', 643),
('RW', 'RWANDA', 'Rwanda', 'RWA', 646),
('SA', 'SAUDI ARABIA', 'Saudi Arabia', 'SAU', 682),
('SB', 'SOLOMON ISLANDS', 'Solomon Islands', 'SLB', 90),
('SC', 'SEYCHELLES', 'Seychelles', 'SYC', 690),
('SD', 'SUDAN', 'Sudan', 'SDN', 736),
('SE', 'SWEDEN', 'Sweden', 'SWE', 752),
('SG', 'SINGAPORE', 'Singapore', 'SGP', 702),
('SH', 'SAINT HELENA', 'Saint Helena', 'SHN', 654),
('SI', 'SLOVENIA', 'Slovenia', 'SVN', 705),
('SJ', 'SVALBARD AND JAN MAYEN', 'Svalbard and Jan Mayen', 'SJM', 744),
('SK', 'SLOVAKIA', 'Slovakia', 'SVK', 703),
('SL', 'SIERRA LEONE', 'Sierra Leone', 'SLE', 694),
('SM', 'SAN MARINO', 'San Marino', 'SMR', 674),
('SN', 'SENEGAL', 'Senegal', 'SEN', 686),
('SO', 'SOMALIA', 'Somalia', 'SOM', 706),
('SR', 'SURINAME', 'Suriname', 'SUR', 740),
('ST', 'SAO TOME AND PRINCIPE', 'Sao Tome and Principe', 'STP', 678),
('SV', 'EL SALVADOR', 'El Salvador', 'SLV', 222),
('SY', 'SYRIAN ARAB REPUBLIC', 'Syrian Arab Republic', 'SYR', 760),
('SZ', 'SWAZILAND', 'Swaziland', 'SWZ', 748),
('TC', 'TURKS AND CAICOS ISLANDS', 'Turks and Caicos Islands', 'TCA', 796),
('TD', 'CHAD', 'Chad', 'TCD', 148),
('TF', 'FRENCH SOUTHERN TERRITORIES', 'French Southern Territories', NULL, NULL),
('TG', 'TOGO', 'Togo', 'TGO', 768),
('TH', 'THAILAND', 'Thailand', 'THA', 764),
('TJ', 'TAJIKISTAN', 'Tajikistan', 'TJK', 762),
('TK', 'TOKELAU', 'Tokelau', 'TKL', 772),
('TL', 'TIMOR-LESTE', 'Timor-Leste', NULL, NULL),
('TM', 'TURKMENISTAN', 'Turkmenistan', 'TKM', 795),
('TN', 'TUNISIA', 'Tunisia', 'TUN', 788),
('TO', 'TONGA', 'Tonga', 'TON', 776),
('TR', 'TURKEY', 'Turkey', 'TUR', 792),
('TT', 'TRINIDAD AND TOBAGO', 'Trinidad and Tobago', 'TTO', 780),
('TV', 'TUVALU', 'Tuvalu', 'TUV', 798),
('TW', 'TAIWAN, PROVINCE OF CHINA', 'Taiwan, Province of China', 'TWN', 158),
('TZ', 'TANZANIA, UNITED REPUBLIC OF', 'Tanzania, United Republic of', 'TZA', 834),
('UA', 'UKRAINE', 'Ukraine', 'UKR', 804),
('UG', 'UGANDA', 'Uganda', 'UGA', 800),
('UK', 'UNITED KINGDOM', 'United Kingdom', 'GBR', 826),
('UM', 'UNITED STATES MINOR OUTLYING ISLANDS', 'United States Minor Outlying Islands', NULL, NULL),
('US', 'UNITED STATES', 'United States', 'USA', 840),
('UY', 'URUGUAY', 'Uruguay', 'URY', 858),
('UZ', 'UZBEKISTAN', 'Uzbekistan', 'UZB', 860),
('VA', 'HOLY SEE (VATICAN CITY STATE)', 'Holy See (Vatican City State)', 'VAT', 336),
('VC', 'SAINT VINCENT AND THE GRENADINES', 'Saint Vincent and the Grenadines', 'VCT', 670),
('VE', 'VENEZUELA', 'Venezuela', 'VEN', 862),
('VG', 'VIRGIN ISLANDS, BRITISH', 'Virgin Islands, British', 'VGB', 92),
('VI', 'VIRGIN ISLANDS, U.S.', 'Virgin Islands, U.s.', 'VIR', 850),
('VN', 'VIET NAM', 'Viet Nam', 'VNM', 704),
('VU', 'VANUATU', 'Vanuatu', 'VUT', 548),
('WF', 'WALLIS AND FUTUNA', 'Wallis and Futuna', 'WLF', 876),
('WS', 'SAMOA', 'Samoa', 'WSM', 882),
('YE', 'YEMEN', 'Yemen', 'YEM', 887),
('YT', 'MAYOTTE', 'Mayotte', NULL, NULL),
('ZA', 'SOUTH AFRICA', 'South Africa', 'ZAF', 710),
('ZM', 'ZAMBIA', 'Zambia', 'ZMB', 894),
('ZW', 'ZIMBABWE', 'Zimbabwe', 'ZWE', 716);

-- --------------------------------------------------------

-- 
-- Table structure for table `currency`
-- 

CREATE TABLE `currency` (
  `curid` int(4) NOT NULL auto_increment,
  `curenc` varchar(255) NOT NULL default '',
  `cursign` varchar(255) NOT NULL default '',
  UNIQUE KEY `curid` (`curid`)
) TYPE=MyISAM AUTO_INCREMENT=4 AUTO_INCREMENT=4 ;

-- 
-- Dumping data for table `currency`
-- 

INSERT INTO `currency` (`curid`, `curenc`, `cursign`) VALUES (1, '£', '&pound;'),
(2, '€', '&#8364;'),
(3, 'USD', '$');

-- --------------------------------------------------------

-- 
-- Table structure for table `do_ban`
-- 

CREATE TABLE `do_ban` (
  `do_do` int(4) NOT NULL auto_increment,
  `do_ban` varchar(255) NOT NULL default '',
  `do_enable` varchar(255) NOT NULL default 'Y',
  UNIQUE KEY `do_do` (`do_do`)
) TYPE=MyISAM AUTO_INCREMENT=5 AUTO_INCREMENT=5 ;

-- 
-- Dumping data for table `do_ban`
-- 

INSERT INTO `do_ban` (`do_do`, `do_ban`, `do_enable`) VALUES (4, 'hacker.com', 'Y');

-- --------------------------------------------------------

-- 
-- Table structure for table `field_config`
-- 

CREATE TABLE `field_config` (
  `flid` int(4) NOT NULL auto_increment,
  `maxdesc` varchar(10) NOT NULL default '180',
  `maxtitle` varchar(10) NOT NULL default '50',
  `maxkword` varchar(10) NOT NULL default '150',
  `maxexdesc` varchar(10) NOT NULL default '300',
  `maxmdesc` varchar(10) NOT NULL default '250',
  `deepenable` char(1) NOT NULL default 'Y',
  UNIQUE KEY `flid` (`flid`)
) TYPE=MyISAM AUTO_INCREMENT=2 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `field_config`
-- 

INSERT INTO `field_config` (`flid`, `maxdesc`, `maxtitle`, `maxkword`, `maxexdesc`, `maxmdesc`, `deepenable`) VALUES (1, '180', '50', '150', '300', '200', 'Y');

-- --------------------------------------------------------

-- 
-- Table structure for table `google_cse`
-- 

CREATE TABLE `google_cse` (
  `cse_id` int(4) NOT NULL auto_increment,
  `cse_main` longtext,
  `cse_on` char(1) NOT NULL default 'Y',
  UNIQUE KEY `cse_id` (`cse_id`)
) TYPE=MyISAM AUTO_INCREMENT=2 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `google_cse`
-- 

INSERT INTO `google_cse` (`cse_id`, `cse_main`, `cse_on`) VALUES (1, '<!-- Google CSE code begins -->\r\n<form id="searchbox_007439867492849857234:pnfmn5b-sg0" onsubmit="return false;">\r\n  <input type="text" name="q" id="q" onFocus="this.value='''';" value="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;LBS Network Search" size="40"/>\r\n  <input type="submit" name="button" id="button" value="Search"/>\r\n</form>\r\n\r\n\r\n<div id="results_007439867492849857234:pnfmn5b-sg0" style="display:none">\r\n  <div class="cse-closeResults"> \r\n    <a>Ã— close</a>\r\n  </div>\r\n  <div class="cse-resultsContainer"></div>\r\n</div>\r\n\r\n<style type="text/css">\r\n@import url(http://www.google.com/cse/api/overlay.css);\r\n</style>\r\n\r\n<script src="http://www.google.com/uds/api?file=uds.js&v=1.0&key=ABQIAAAAeN-mwY5Iis-oLSmTkYNJgBSYtDEEkDuo7u5y31Xax8e755ILERRfq51f_Ik1A2JnmYj8XFxkOK86OQ" type="text/javascript"></script>\r\n<script src="http://www.google.com/cse/api/overlay.js"></script>\r\n<script type="text/javascript">\r\nfunction OnLoad() {\r\n  new CSEOverlay("007439867492849857234:pnfmn5b-sg0",\r\n                 document.getElementById("searchbox_007439867492849857234:pnfmn5b-sg0"),\r\n                 document.getElementById("results_007439867492849857234:pnfmn5b-sg0"));\r\n}\r\nGSearch.setOnLoadCallback(OnLoad);\r\n</script>\r\n<!-- Google CSE Code ends -->', 'Y');

-- --------------------------------------------------------

-- 
-- Table structure for table `ig_admin`
-- 

CREATE TABLE `ig_admin` (
  `adid` int(4) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `pass` varchar(255) NOT NULL default '',
  `email` varchar(255) NOT NULL default '',
  UNIQUE KEY `adid` (`adid`)
) TYPE=MyISAM AUTO_INCREMENT=17 PACK_KEYS=0 AUTO_INCREMENT=17 ;

-- 
-- Dumping data for table `ig_admin`
-- 

INSERT INTO `ig_admin` (`adid`, `name`, `pass`, `email`) VALUES (16, 'lbsadmin', 'lbspassword', 'your@mail.com');

-- --------------------------------------------------------

-- 
-- Table structure for table `ip_ban`
-- 

CREATE TABLE `ip_ban` (
  `ip_id` int(4) NOT NULL auto_increment,
  `ip_ip` varchar(255) NOT NULL default '',
  `ip_enable` varchar(255) NOT NULL default 'Y',
  UNIQUE KEY `ip_id` (`ip_id`)
) TYPE=MyISAM AUTO_INCREMENT=5 AUTO_INCREMENT=5 ;

-- 
-- Dumping data for table `ip_ban`
-- 

INSERT INTO `ip_ban` (`ip_id`, `ip_ip`, `ip_enable`) VALUES (4, '192.186.25.0', 'Y');

-- --------------------------------------------------------

-- 
-- Table structure for table `language`
-- 

CREATE TABLE `language` (
  `langu_id` int(4) NOT NULL auto_increment,
  `langu_name` varchar(255) NOT NULL default 'lang_english',
  UNIQUE KEY `langu_id` (`langu_id`)
) TYPE=MyISAM AUTO_INCREMENT=6 AUTO_INCREMENT=6 ;

-- 
-- Dumping data for table `language`
-- 

INSERT INTO `language` (`langu_id`, `langu_name`) VALUES (1, 'lang_english'),
(2, 'lang_romanian'),
(4, 'lang_hungaryan'),
(5, 'lang_french.php');

-- --------------------------------------------------------

-- 
-- Table structure for table `linknumber`
-- 

CREATE TABLE `linknumber` (
  `lnbid` int(4) NOT NULL auto_increment,
  `lnbhome` varchar(255) NOT NULL default '5',
  `lnbcategory` varchar(255) NOT NULL default '2',
  `lnbalphabet` varchar(255) NOT NULL default '2',
  `lnbtoplinks` varchar(255) NOT NULL default '30',
  `lnbnewlinks` varchar(255) NOT NULL default '30',
  UNIQUE KEY `lnbid` (`lnbid`)
) TYPE=MyISAM AUTO_INCREMENT=2 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `linknumber`
-- 

INSERT INTO `linknumber` (`lnbid`, `lnbhome`, `lnbcategory`, `lnbalphabet`, `lnbtoplinks`, `lnbnewlinks`) VALUES (1, '10', '10', '10', '10', '10');

-- --------------------------------------------------------

-- 
-- Table structure for table `main`
-- 

CREATE TABLE `main` (
  `dtu` int(4) NOT NULL auto_increment,
  `categ` varchar(255) NOT NULL default '',
  `email` varchar(255) NOT NULL default '',
  `site` varchar(255) NOT NULL default '',
  `title` varchar(255) NOT NULL default '',
  `descr1` varchar(255) NOT NULL default '',
  `descr2` varchar(255) NOT NULL default '',
  `mdesc` varchar(255) NOT NULL default '',
  `mword` varchar(255) NOT NULL default '',
  `deeptf` varchar(255) NOT NULL default 'Deep Link 1',
  `deepts` varchar(255) NOT NULL default 'Deep Link 2',
  `deeptt` varchar(255) NOT NULL default 'Deep Link 3',
  `dfurl` varchar(255) NOT NULL default 'http://',
  `dsurl` varchar(255) NOT NULL default 'http://',
  `dturl` varchar(255) NOT NULL default 'http://',
  `bid` int(4) NOT NULL default '0',
  `stad` date NOT NULL default '0000-00-00',
  `stod` date NOT NULL default '0000-00-00',
  `stup` date NOT NULL default '0000-00-00',
  `avail` varchar(255) NOT NULL default '',
  `paid` varchar(255) NOT NULL default '',
  `ujbid` varchar(255) NOT NULL default '',
  `maincategory` varchar(255) NOT NULL default '17',
  `google` varchar(255) NOT NULL default '',
  `yahoo` varchar(255) NOT NULL default '',
  `msn` varchar(255) NOT NULL default '',
  `alexa` varchar(255) NOT NULL default '',
  `pr_date` date default NULL,
  `gm_str` varchar(255) default NULL,
  `gm_str_nr` varchar(255) default NULL,
  `gm_city` varchar(255) default NULL,
  `gm_county` varchar(255) default NULL,
  `gm_country` varchar(255) default NULL,
  `gep_ip` varchar(255) default NULL,
  `blinkurl` varchar(255) default NULL,
  `tag1` varchar(255) default NULL,
  `tag2` varchar(255) default NULL,
  `tag3` varchar(255) default NULL,
  `tag4` varchar(255) default NULL,
  `tag5` varchar(255) default NULL,
  `tag6` varchar(255) default NULL,
  UNIQUE KEY `dtu` (`dtu`),
  KEY `bid` (`bid`),
  KEY `bid_2` (`bid`)
) TYPE=MyISAM AUTO_INCREMENT=1103 AUTO_INCREMENT=1103 ;

-- 
-- Dumping data for table `main`
-- 

INSERT INTO `main` (`dtu`, `categ`, `email`, `site`, `title`, `descr1`, `descr2`, `mdesc`, `mword`, `deeptf`, `deepts`, `deeptt`, `dfurl`, `dsurl`, `dturl`, `bid`, `stad`, `stod`, `stup`, `avail`, `paid`, `ujbid`, `maincategory`, `google`, `yahoo`, `msn`, `alexa`, `pr_date`, `gm_str`, `gm_str_nr`, `gm_city`, `gm_county`, `gm_country`, `gep_ip`, `blinkurl`, `tag1`, `tag2`, `tag3`, `tag4`, `tag5`, `tag6`) VALUES (25, 'h', 'info@haabaa.com', 'http://www.haabaa.com', 'Haabaa Website Directory', 'aaa provides free and premium inclusion in', 'our search engine friendly web directory.', '', 'our search engine friendly web directory', 'Deep Link 1', 'Deep Link 2', 'Deep Link 3', 'http://', 'http://', 'http://', 61, '2007-01-04', '2008-02-04', '2008-07-17', 'Y', 'Y', '64', '11', '375', '292,776<i class="tl"></i><i class="tr"></i><i class="bl"></i><i class="br"></i></a></li>', '4', '<span class="cd03">17</span><span class="ca17">48</span>4,<span class="c247">26</span><span class="c3a7">8</span>4</span></a>', '2008-12-15', 'Liverpool Street', '16', 'London', 'London', 'UK', NULL, NULL, 'haabaa', 'website', 'search', 'uk', 'advert', 'directory'),
(1085, 'P', 'temi@haabaamail.com', 'http://phplinkbid.linkbidscript.com/', 'phpLinkBiD - bidding CENSORED script', 'Make money online with your own bid CENSORED script. Just download CENSORED install LBS CENSORED script free of charge.', 'Make money online with your own bid CENSORED script. Just download CENSORED install LBS CENSORED script free of charge.', 'Make money online with your own bid CENSORED script. Just download CENSORED install LBS CENSORED script free of charge.', 'Make money online', '', '', '', 'http://', 'http://', 'http://', 5, '2008-08-03', '2009-08-03', '2008-08-03', 'Y', 'Y', '8', '2', '', '347<i class="tl"></i><i class="tr"></i><i class="bl"></i><i class="br"></i></a></li>', '', '7<span class="ca57">74</span><span class="ca11">2,</span><span class="c8ad">2</span><span class="c52c">67</span>421</span></a>', '2008-12-15', '226 Seven sisters Road', 'London', 'London', 'London', 'UK', '81.129.32.18', '', 'LBS', 'bid', 'add url', 'free', 'advert', 'directory'),
(1086, 'U', 'temi@haabaamail.com', 'http://directory.velnetsearch.co.uk', 'UK Web Directory', 'Velnet search web Directory is a leading UK web directory. It is human edited to ensure quality listing, add your site to Velnet Search for one off fee today.', 'Velnet search web Directory is a leading UK web directory. It is human edited to ensure quality listing, add your site to Velnet Search for one off fee today.', 'Velnet search web Directory is a leading UK web directory. It is human edited to ensure quality listing, add your site to Velnet Search for one off fee today.', 'velnet search web hosting directory web CENSORED add your site', '', '', '', 'http://', 'http://', 'http://', 65, '2008-08-03', '2009-08-03', '2008-08-03', 'Y', 'Y', '', '8', '17', '9,148<i class="tl"></i><i class="tr"></i><i class="bl"></i><i class="br"></i></a></li>', '', '5<span class="c9a5">50</span><span class="c52c">88</span><span class="c347">,6</span><span class="cde7">04</span></span></a>', '2008-12-15', '226 Seven sisters Road', '44', 'London', 'London', 'UK', '81.129.32.18', '', 'Velnet', 'website', 'search', 'demo', 'advert', 'directory');

-- --------------------------------------------------------

-- 
-- Table structure for table `meta`
-- 

CREATE TABLE `meta` (
  `m_id` int(4) NOT NULL auto_increment,
  `m_page` varchar(255) NOT NULL default 'page_meta',
  `m_title` varchar(255) NOT NULL default 'lbs_title',
  `m_keyword` varchar(255) NOT NULL default 'lbs_keyword',
  `m_description` varchar(255) NOT NULL default 'lbs_description',
  UNIQUE KEY `m_id` (`m_id`)
) TYPE=MyISAM AUTO_INCREMENT=16 AUTO_INCREMENT=16 ;

-- 
-- Dumping data for table `meta`
-- 

INSERT INTO `meta` (`m_id`, `m_page`, `m_title`, `m_keyword`, `m_description`) VALUES (1, 'latest.php', 'This is the latest sites to be added to this directory.', 'lbs,linkbidscript,bid for position directory,free directory,script,link exchange script,free,download,make money online,promote your site,build links,link exchange.', 'This is the latest sites to be added to this directory.'),
(2, 'category.php', 'category title', 'category keyword', 'category description'),
(3, 'details.php', 'pag_details', 'pag_details', 'pag_details'),
(4, 'index.php', 'Link Bid Script Powered site - Add Your Site', 'lbs,linkbidscript,bid for position directory,free directory,script,link exchange script,free,download,make money online,promote your site,build links,link exchange.', 'This website is a link bid script powered website, fell free to submit your site for review.'),
(5, 'links.php', 'pag_links', 'pag_links', 'pag_links'),
(6, 'list.php', 'pag_list', 'pag_list', 'pag_list'),
(7, 'search.php', 'pag_search', 'pag_search', 'pag_search'),
(8, 'about.php', 'LBS Script - About this directory', 'lbs,linkbidscript,bid for position directory,free directory,script,link exchange script,free,download,make money online,promote your site,build links,link exchange.', 'lbs,linkbidscript,bid for position directory,free directory,script,link exchange script,free,download,make money online,promote your site,build links,link exchange.'),
(9, 'contact.php', 'pag_contact', 'pag_contact', 'pag_contact'),
(10, 'processing.php', 'pag_processing', 'pag_processing', 'pag_processing'),
(11, 'sorry.php', 'pag_sorry', 'pag_sorry', 'pag_sorry'),
(12, 'terms.php', 'pag_terms', 'pag_terms', 'pag_terms'),
(13, 'thankyou.php', 'pag_thankyou', 'pag_thankyou', 'pag_thankyou'),
(14, 'update.php', 'pag_update', 'pag_update', 'pag_update'),
(15, 'upgrade.php', 'pag_upgrade', 'pag_upgrade', 'pag_upgrade');

-- --------------------------------------------------------

-- 
-- Table structure for table `paypal_cart_info`
-- 

CREATE TABLE `paypal_cart_info` (
  `txnid` varchar(30) NOT NULL default '',
  `itemname` varchar(255) NOT NULL default '',
  `itemnumber` varchar(50) default NULL,
  `os0` varchar(20) default NULL,
  `on0` varchar(50) default NULL,
  `os1` varchar(20) default NULL,
  `on1` varchar(50) default NULL,
  `quantity` char(3) NOT NULL default '',
  `invoice` varchar(255) NOT NULL default '',
  `custom` varchar(255) NOT NULL default ''
) TYPE=MyISAM;

-- 
-- Dumping data for table `paypal_cart_info`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `paypal_payment_info`
-- 

CREATE TABLE `paypal_payment_info` (
  `firstname` varchar(100) NOT NULL default '',
  `lastname` varchar(100) NOT NULL default '',
  `buyer_email` varchar(100) NOT NULL default '',
  `street` varchar(100) NOT NULL default '',
  `city` varchar(50) NOT NULL default '',
  `state` char(3) NOT NULL default '',
  `zipcode` varchar(11) NOT NULL default '',
  `memo` varchar(255) default NULL,
  `itemname` varchar(255) default NULL,
  `itemnumber` varchar(50) default NULL,
  `os0` varchar(20) default NULL,
  `on0` varchar(50) default NULL,
  `os1` varchar(20) default NULL,
  `on1` varchar(50) default NULL,
  `quantity` char(3) default NULL,
  `paymentdate` varchar(50) NOT NULL default '',
  `paymenttype` varchar(10) NOT NULL default '',
  `txnid` varchar(30) NOT NULL default '',
  `mc_gross` varchar(6) NOT NULL default '',
  `mc_fee` varchar(5) NOT NULL default '',
  `paymentstatus` varchar(15) NOT NULL default '',
  `pendingreason` varchar(10) default NULL,
  `txntype` varchar(10) NOT NULL default '',
  `tax` varchar(10) default NULL,
  `mc_currency` varchar(5) NOT NULL default '',
  `reasoncode` varchar(20) NOT NULL default '',
  `custom` varchar(255) NOT NULL default '',
  `country` varchar(20) NOT NULL default '',
  `datecreation` date NOT NULL default '0000-00-00'
) TYPE=MyISAM;

-- 
-- Dumping data for table `paypal_payment_info`
-- 

INSERT INTO `paypal_payment_info` (`firstname`, `lastname`, `buyer_email`, `street`, `city`, `state`, `zipcode`, `memo`, `itemname`, `itemnumber`, `os0`, `on0`, `os1`, `on1`, `quantity`, `paymentdate`, `paymenttype`, `txnid`, `mc_gross`, `mc_fee`, `paymentstatus`, `pendingreason`, `txntype`, `tax`, `mc_currency`, `reasoncode`, `custom`, `country`, `datecreation`) VALUES ('Test', 'User', 'misi_1183481435_per@haabaamail.com', '1 Main Terrace', 'Wolverhampton', 'Wes', 'W12 4LQ', '', 'Payment from APoundALink.com Bid ID 208 for link http://www.yahamisi.comfrom site UKWEB', 'Link Title Ajh jh jbh hjb jbh hjhb for misi@haabaa', '', '', '', '', '1', '12:25:14 Jul 03, 2007 PDT', 'instant', '1DY39457BB756905Y', '1.00', '0.23', 'Completed', '', '', '0.00', '', '', '', 'United Kingdom', '2007-07-03'),
('Test', 'User', 'misi_1183481435_per@haabaamail.com', '1 Main Terrace', 'Wolverhampton', 'Wes', 'W12 4LQ', '', 'Payment from APoundALink.com Bid ID 209 for link http://www.googlematyi.comfrom site UKWEB', 'Link Title Akjn knj jknjkn jkn kj for misi@haabaam', '', '', '', '', '1', '13:24:08 Jul 03, 2007 PDT', 'instant', '72V96618FF942274N', '1.00', '0.23', 'Completed', '', '', '0.00', '', '', '', 'United Kingdom', '2007-07-03'),
('Test', 'User', 'misi_1183481435_per@haabaamail.com', '1 Main Terrace', 'Wolverhampton', 'Wes', 'W12 4LQ', '', 'Payment from APoundALink.com Bid ID 210 for link http://www.cnn.comfrom site UKWEB', '210', '', '', '', '', '1', '13:40:52 Jul 03, 2007 PDT', 'instant', '2RX64024PP213321T', '1.00', '0.23', 'Completed', '', '', '0.00', '', '', '', 'United Kingdom', '2007-07-03'),
('Test', 'User', 'misi_1183481435_per@haabaamail.com', '1 Main Terrace', 'Wolverhampton', 'Wes', 'W12 4LQ', '', 'Payment from APoundALink.com Bid ID 211 for link http://www.amd.comfrom site UKWEB', '211', '', '', '', '', '1', '14:23:16 Jul 03, 2007 PDT', 'instant', '8SD26263SX399333C', '1.00', '0.23', 'Completed', '', '', '0.00', '', '', '', 'United Kingdom', '2007-07-03');

-- --------------------------------------------------------

-- 
-- Table structure for table `paypal_subscription_info`
-- 

CREATE TABLE `paypal_subscription_info` (
  `subscr_id` varchar(255) NOT NULL default '',
  `sub_event` varchar(50) NOT NULL default '',
  `subscr_date` varchar(255) NOT NULL default '',
  `subscr_effective` varchar(255) NOT NULL default '',
  `period1` varchar(255) NOT NULL default '',
  `period2` varchar(255) NOT NULL default '',
  `period3` varchar(255) NOT NULL default '',
  `amount1` varchar(255) NOT NULL default '',
  `amount2` varchar(255) NOT NULL default '',
  `amount3` varchar(255) NOT NULL default '',
  `mc_amount1` varchar(255) NOT NULL default '',
  `mc_amount2` varchar(255) NOT NULL default '',
  `mc_amount3` varchar(255) NOT NULL default '',
  `recurring` varchar(255) NOT NULL default '',
  `reattempt` varchar(255) NOT NULL default '',
  `retry_at` varchar(255) NOT NULL default '',
  `recur_times` varchar(255) NOT NULL default '',
  `username` varchar(255) NOT NULL default '',
  `password` varchar(255) default NULL,
  `payment_txn_id` varchar(50) NOT NULL default '',
  `subscriber_emailaddress` varchar(255) NOT NULL default '',
  `datecreation` date NOT NULL default '0000-00-00'
) TYPE=MyISAM;

-- 
-- Dumping data for table `paypal_subscription_info`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `tags`
-- 

CREATE TABLE `tags` (
  `id` int(11) NOT NULL auto_increment,
  `tag` varchar(100) NOT NULL,
  `count` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=InnoDB AUTO_INCREMENT=27 AUTO_INCREMENT=27 ;

-- 
-- Dumping data for table `tags`
-- 

INSERT INTO `tags` (`id`, `tag`, `count`) VALUES (15, 'haabaa', 1),
(16, 'website', 2),
(17, 'search', 2),
(18, 'uk', 1),
(19, 'advert', 3),
(20, 'directory', 3),
(21, 'LBS', 1),
(22, 'bid', 1),
(23, 'add url', 1),
(24, 'free', 1),
(25, 'Velnet', 1),
(26, 'demo', 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `template`
-- 

CREATE TABLE `template` (
  `teind` int(4) NOT NULL auto_increment,
  `template` varchar(255) NOT NULL default '',
  UNIQUE KEY `teind` (`teind`)
) TYPE=MyISAM AUTO_INCREMENT=15 AUTO_INCREMENT=15 ;

-- 
-- Dumping data for table `template`
-- 

INSERT INTO `template` (`teind`, `template`) VALUES (7, 'lbs'),
(10, 'Green_Light'),
(11, 'redtheme'),
(12, 'BlueSkin'),
(13, 'BrownLBS'),
(14, 'GreenAndBlack');

-- --------------------------------------------------------

-- 
-- Table structure for table `terms`
-- 

CREATE TABLE `terms` (
  `termsid` int(4) NOT NULL auto_increment,
  `termsdetails` longtext NOT NULL,
  UNIQUE KEY `termsid` (`termsid`)
) TYPE=MyISAM AUTO_INCREMENT=2 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `terms`
-- 

INSERT INTO `terms` (`termsid`, `termsdetails`) VALUES (1, 'This document states the terms at which your link will be accepted for listing in Link Bid Directory.\r\n      <p> By pacing a bid you agree to abide by the following terms: </p>\r\n      <strong> Link Policy\r\n       </strong>\r\n      <ul>\r\n        <li> We reserve the right to make a small admin charge if you want to modify your link.</li>\r\n        <li> Position of your link is determined by how much money you bid.</li>\r\n        <li> Links may be removed if it violates inclusion policy.</li>\r\n      </ul>\r\n      <p><strong>Refunds\r\n       </strong></p>\r\n      <ul>\r\n        <li> Bids may be refunded at our discretion.</li>\r\n      </ul>\r\n      You must use the contact form if you need to contact us.');

-- --------------------------------------------------------

-- 
-- Table structure for table `welcome`
-- 

CREATE TABLE `welcome` (
  `wind` int(4) NOT NULL auto_increment,
  `wecontent` longtext,
  UNIQUE KEY `wind` (`wind`)
) TYPE=MyISAM AUTO_INCREMENT=2 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `welcome`
-- 

INSERT INTO `welcome` (`wind`, `wecontent`) VALUES (1, '<h1>Welcome to LBS powered website!</h1>\r\n\r\nThe content of this site has been carefully reviewed by our editors and found to be of the highest quality possible before it was approved for listing on this site. You are also welcomed to suggest your site for listing in this LBS powered directory.');

-- --------------------------------------------------------

-- 
-- Table structure for table `word_b`
-- 

CREATE TABLE `word_b` (
  `wid` int(4) NOT NULL auto_increment,
  `w_bad` longtext,
  UNIQUE KEY `wid` (`wid`)
) TYPE=MyISAM AUTO_INCREMENT=2 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `word_b`
-- 

INSERT INTO `word_b` (`wid`, `w_bad`) VALUES (1, 'porn');
