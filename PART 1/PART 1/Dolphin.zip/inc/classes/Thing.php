<?

/*
 * parent object for all classes
 */
class Thing
{
	
// public functions

	/**
	 * constructor
	 */
	function Thing ()
	{
	}


// private functions

}

?>