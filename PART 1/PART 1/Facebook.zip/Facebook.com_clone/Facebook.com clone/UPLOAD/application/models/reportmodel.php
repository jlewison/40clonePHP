<?php

/**
 * Wall Model
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 12/24/2007
 *
 * Tables: report, report_type
 *
 */
class Reportmodel extends Model
{
		//Constructor
		function Reportmodel()
		{
				parent::Model();
		}
		function createReport($newReport)
		{
				if (!isset($newReport['user_id']) || trim($newReport['user_id']) == '') $newReport['user_id'] = $this->session->userdata('user_id');
				if (isset($newReport['report_type_id']) && isset($newReport['report_comment']) && isset($newReport['report_for']) && isset($newReport['report_for_id']))
				{
						$this->db->set('report_date', 'NOW()', false);
						$this->db->set($newReport);
						$this->db->insert('report');
						return true;
				}
				else  return false;
		}
		function getReportType()
		{
				$reportTypeQuery = $this->db->query('SELECT report_type_id, report_type FROM report_type ORDER BY report_type');
				$reportType = array();
				if ($reportTypeQuery->num_rows() > 0)
				{
						foreach ($reportTypeQuery->result_array() as $reportTypeRow)
						{
								$reportType[$reportTypeRow['report_type_id']] = $reportTypeRow['report_type'];
						}
				}
				return $reportType;
		}
		#***************************************************************************
		#Method			: getReportList
		#Description	: fetches reports list
		#Author
		#***************************************************************************
		function getReportList($report_for)
		{
				$this->db->select('report.report_id,report.report_for, users.username, report_type.report_type');
				$this->db->from('report');
				$this->db->join('report_type', 'report.report_type_id = report_type.report_type_id', 'inner');
				$this->db->join('users', 'report.user_id = users.user_id', 'inner');
				$this->db->where('report.report_for', $report_for);
				$reportsQuery = $this->db->get();
				//print $this->db->last_query(); exit();
				if ($reportsQuery->num_rows() > 0)
				{
						foreach ($reportsQuery->result_array() as $row)
						{
								$reports[$row['report_id']] = $row;
						}
						return $reports;
				}
				else  return false;
		}
		#***************************************************************************
		#Method			: deleteReport
		#Description	: deletes report
		#Author
		#***************************************************************************
		function deleteReport($report_id)
		{
				$this->db->where('report_id', $report_id);
				$this->db->delete('report');
		}
		#***************************************************************************
		#Method			: getReport
		#Description	: fetches a report
		#Author
		#***************************************************************************
		function getReport($report_id)
		{
				$this->db->select('report.report_id,report.report_for_id,report.report_for, users.username, report_type.report_type');
				$this->db->from('report');
				$this->db->join('report_type', 'report.report_type_id = report_type.report_type_id', 'inner');
				$this->db->join('users', 'report.user_id = users.user_id', 'inner');
				$this->db->where('report.report_id', $report_id);
				$reportsQuery = $this->db->get();
				//print $this->db->last_query(); exit();
				if ($reportsQuery->num_rows() > 0)
				{
						foreach ($reportsQuery->result_array() as $row)
						{
								$reports[$row['report_id']] = $row;
						}
						return $reports;
				}
				else  return false;
		}
}
?>