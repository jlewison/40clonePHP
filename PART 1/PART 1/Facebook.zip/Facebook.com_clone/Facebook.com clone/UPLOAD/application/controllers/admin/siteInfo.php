<?php
/**
 * Edit Profile Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 02/01/2008
 */
class SiteInfo extends controller
{
		function SiteInfo()
		{
				parent::controller();
				//check login
				if ($this->session->userdata('admin_logged_in') != 1 && $this->session->userdata('admin_id') == '') redirect('admin/login');
				//Load the language file
				$this->lang->load('admin/siteInfo', $this->config->item('language_code'));
		}
		function index()
		{
				$this->load->model('usermodel');
				$this->load->model('groupsmodel');
				$this->load->model('eventsmodel');
				$this->load->model('photomodel');
				$outputData['membersCount'] = $this->usermodel->getUserCount();
				$outputData['groupsCount'] = $this->groupsmodel->getGroupCount();
				$outputData['eventsCount'] = $this->eventsmodel->getEventsCount();
				$outputData['albumCount'] = $this->photomodel->getAlbumsCount();
				$this->smartyextended->view('../admin/siteInfo', $outputData);
		}
}
?>