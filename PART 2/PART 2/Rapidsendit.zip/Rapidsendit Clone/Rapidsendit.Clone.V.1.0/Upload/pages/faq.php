<u><font face="Verdana" size="3"><b>Who uses Rapidsendit?</b></font></u>

<div style="text-align: justify; width:610px;">
<font face="Verdana" size="2">
Everyone. Millions of people from all walks of life in many countries. Students, professional business people, moms, doctors, plumbers, insurance salesmen, mortgage brokers, you name it.</div>
</font>
<br>

<u><font face="Verdana" size="3"><b>Why should I use Rapidsendit?</b></font></u>
<font face="Verdana" size="2">
<div style="text-align: justify; width:610px;">
You should use Rapidsendit.com because we are simply the best way to get files from one person to another.</div>
</font>
<br>

<u><font face="Verdana" size="3"><b>Rapidsendit eliminates the following problems:</b></font></u>


<div style="text-align: center; width:610px;">
<center>
	<table style="color: #565656; font-family: tahoma; font-size: 11px; margin:auto">
	<tr>
		<td width="20" valign="top"><img src="images/check.jpg" alt=""></td>

		<td  width="450" style="text-align: justify;">
			It is more secure than normal e-mail.			</td>
	</tr>
	<tr>
		<td  width="20" valign="top"><img src="images/check.jpg" alt=""></td>
		<td width="450" style="text-align: justify;" align="left">
		   You don't have to worry about the size of file and being rejected because their e-mail server won't allow a file that big or their e-mail is full.		</td>
	</tr>
	<tr>
		<td  width="20" valign="top"><img src="images/check.jpg" alt=""></td>
		<td width="450" style="text-align: justify;" align="left">
		   If you send a file to several people and discover you forgot someone you don't have to upload the attachment again. Simply send the Rapidsendit file link to the person you forgot.				</td>
	</tr>
	<tr>
		<td  width="20" valign="top"><img src="images/check.jpg" alt=""></td>
		<td width="450" style="text-align: justify;" align="left">
			The download is the exact file you uploaded and no one had a chance to spoof or replace the file with another. Our servers are secure, and after a file is uploaded and you have the link it can be removed but not changed.				</td>
	</tr>
	<tr>
		<td  width="20" valign="top"><img src="images/check.jpg" alt=""></td>
		<td width="450" style="text-align: justify;" align="left">
		 Now you are able to e-mail out from an internet cafe, friends PC, or while you're at a company pc. You can easily upload the files from the PC and then download them when you get to your destination.				</td>
	</tr>
	<tr>
		<td  width="20" valign="top"><img src="images/check.jpg" alt=""></td>
		<td width="450" style="text-align: justify;" align="left">
			Stop being shouted at by your friends saying it took forever to get your e-mail attachment and they couldn't receive or send an e-mail until it's completed. Not everyone is on a high speed connection, and files get larger every day. By sending the link people, can download your files at their leisure when they are ready.				</td>
	</tr>
	<tr>
		<td width="20" valign="top"><img src="images/check.jpg" alt=""></td>
		<td width="450" style="text-align: justify;" align="left">
			Eliminate country or domain blocking problems for e-mail. Because of spam, more and more companies are implementing new rules about receiving e-mails. It is not uncommon for companies to delete e-mail from certain countries or even domains. If someone can't receive your e-mail, just telephone them and give them the file link over the telephone. This will allow them to download the file easily and simply.				</td>
	</tr>
	</table>
</center>

</div>

<br>

<u><font face="Verdana" size="3"><b>What are my benefits?</b></font></u>

<div style="text-align: center; width:610px;">
<table  style="color: #565656; font-family: tahoma; font-size: 11px;">
			<tr>
				<td width="20" valign="top"><img src="images/check.jpg" alt=""></td>

				<td  width="450" style="text-align: justify;">
						<div class="fajka2">Absolutely free.</div>
				</td>
			</tr>
			<tr>
				<td width="20" valign="top"><img src="images/check.jpg" alt=""></td>

				<td  width="450" style="text-align: justify;">
				<div class="fajka2">No special software or equipment needed.</div>
				</td>
			</tr>
			<tr>
				<td width="20" valign="top"><img src="images/check.jpg" alt=""></td>

				<td  width="450" style="text-align: justify;">
					<div class="fajka2">We won't lose the file and it isn't going anywhere.</div>
				</td>
			</tr>
		
		
			<tr>
				<td width="20" valign="top"><img src="images/check.jpg" alt=""></td>

				<td  width="450" style="text-align: justify;">
					<div class="fajka2">Allows download of the file at your convenience.</div>
				</td>
			</tr>

			<tr>
				<td width="20" valign="top"><img src="images/check.jpg" alt=""></td>

				<td  width="450" style="text-align: justify;">
					  <div class="fajka2">You can download the file again if you lost it or accidentally deleted it.</div>
				</td>
			</tr>

			<tr>
				<td width="20" valign="top"><img src="images/check.jpg" alt=""></td>

				<td  width="450" style="text-align: justify;">
					<div class="fajka2">The file can't be removed or deleted by anyone but Rapidsendit.com or yourself.</div>
				</td>
			</tr>
			</table>
</div>

<br>

<u><font face="Verdana" size="3"><b>What kind of files do people upload?</b></font></u>
<font face="Verdana" size="2">

<div style="text-align: justify; width:610px;">
For the individuals, it can be things like : music videos, mp3s, songs, computer games, computer software, cell phone ring tones, digital camera photos and albums. Anything from family to automobiles to pets.<br>

For the professional it can be: Excel spreadsheets, PowerPoint presentations, data files, Word documents, project plans, home construction architect drawings, voice recordings, sales brochures, completed home mortgage contracts, medical lab results, computerserver configuration files, advertising brochures. As you can see, the list is endless. You can upload virtually anything and everything on your PC hard drive.</div>

</font>

<br><br>




 
<u><font face="Verdana" size="3"><b>How often can my files be downloaded from Rapidsendit?</b></font></u>
<font face="Verdana" size="2">
<br>
<div style="text-align:justify; width:610px;">
There is no limit! We host files which have been downloaded more than a million times.
</font>
</div>

<br>


<u><font face="Verdana" size="3"><b>How long does Rapidsendit store my files?</b></font></u>
<div style="text-align:justify; width:610px;">
<font face="Verdana" size="2">
Your files will be stored forever until you delete them yourself. Also If a file was not downloaded for 30 days, it gets deleted automatically.</div>
</font>
<br>


<u><font face="Verdana" size="3"><b>Which files are allowed to be uploaded?</b></font></u>
<div style="text-align:justify; width:610px;">
<font face="Verdana" size="2">
All files that do not violate our <a href="index.php?page=tos" target="_blank" style="text-decoration:underline; font-weight: normal;">terms of service</a> or the laws of concerned countries. This means that files violating copyrights, or pornography displaying minors, are forbidden and will be removed as soon as we notice.</div>
</font>
<br>








