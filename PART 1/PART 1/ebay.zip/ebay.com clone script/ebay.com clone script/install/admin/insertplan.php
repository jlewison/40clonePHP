<?php //00461
// Copyright Notice
// Web Site URL:  http://www.zeeways.com
// Script Owner eMail: mail@zeeways.com
// Date: April, 2007
// Script Name: Zeeways Auction Website PHP Script
// Copyright Details: This script is not free.  Do not Remove this Copy Right notice.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the site administrator.');exit(199);
?>
4+oV5D3dTMc4JqvFHLBWIdElXgVwbAzs+f7RoF1mkzEJpMC06itLQ0/X5YHeHOZ4BAp97zhQ3FrB
LHLkzidpsGVNG34+QUku8V7XFYYnt74xZ2tozKWtBouTE7bFA4byxIchUe7h+Q4UeJdbARVCQjI5
sX/QLpSXYCvs1GBogm+rnmJE8PKlAkvd7GhTbV8CDHQ/eOZGIdxHwghGi2x8NsaTAC3oxB6KSq5z
Qjvx0caFQdlaYbjiH5nC+cYMfZGCJ7FtBQv9VhQQS163HcIBXmH1X4OJOBHy/9Ng+aF/zuC7QknV
/hARQ3RHdD4XwRiWCHSTZahJTqwROC9c5FkFI0hjd8DG7CAYzYQIVUNHEgZ156vLT5v3jenHpKHy
S5+yjHDO1P0ZoNWwZFulHxEZ0W7k++0nhUQ8J9MvYRtiEXJfXqJMgMFhodk7kSyLJC2OxXOY525I
LYsrkF+BgcVbSzY0c2YpmQBjPjt86NDm7SnavAzTU5LwAFXHi8tLrSijHmyzPRnOmWT/Awr0G2c3
AK8UQRHoibrUjpIZJLNBiKgkBMFZroLmEOhILGAQRh+KbYgYxHWIDpqw2cpNnIcK3gMXcrMcoOgZ
g7Pdb+f4Lxx0ASTejqQV9rZPAWWBR/y50Ub2sgyRG3J8bhvcNsyuMgfDSqEWWecLlRXrv2zxxoze
dmYPbzvvFfB/ELsHHrDz5zsoswi5RwFeDNAqt3LZKiD24IlJ97b204yB5apeWyyGca5w/uKtLmEA
S+WIa6kvRLj38u8M1kpy8wV4B2UW4JGSfgWko89UNqoWevGQEveAmHEznNmIWw0sNeV5m3Rs6Oki
PPoDP63HOjo7P5jMUrLJ8j5lldazeD6+e14J8yPn8CANiFFLcfzc36uOezbOrh0DjCgRqYXZpqfA
PNFoCfKWdgpbNWBAZNAFOzLLUQU+UYYGURZspyDxPNow+qkKCA0eayXDl+3J8JHJWamN/nlE4OCM
/8XprZeZk/qAydJDynTUX5qzO9V3FS+aLeqVhklJ4yem94yQSR3ogjmgezEXhE4mifpykFNU0k/F
uQ2uLWdzUTxkYsLDju/fjWF9hLIdtHkXODIEicmn7Ls0lNtMpihWd6Icaflzpx40lBGX+rxyT1Uh
B1qGwrc7cZscUn8BgOi2vLKvcfxjcnhoYlhVJxDKIUSGrqkROyAMgTXBDkr1JNke75lM2QkCCcEO
GmzgsDVZHDOgb0boB5GBS7GTyJVlJ/vNk08Rz00u8W7Thulw2T0R+VZzrgbSZF60uA+Q53XKDO8A
l9BQ4n5LARU+uAJLanwZjfBacCX73rKqqNq+htFXyLBNrePhVmz26aZzh1DVGE58xTG5SVHLbL1R
T+UQ94Z08REW4pZKmN6yiNpkpfKSPQVc4dO767vC4atmyY5+I+/AamCEwcp5BW04CL3fpL7lFvRZ
jsREIJiFRWr77exyXNFVySYYNk9+dGbAuGj750n+u0twPirQ5P8h8in1A8WKtnaqXHCe9Ac1wlyE
rfmsRnfNcncSXh6a74r+7obK9Yg8hBrGDBQJg/jQpYE02UdHCUaRAsLV902rOqRVWihL9xhJgbRh
a1WiUtIPS0a7+HbvjPIYSeR39A+awInP