<?
include("include/config.php");
include("include/functions.php");

$action=$_REQUEST['action'];
if($action=='Submit')
{
$reporter=$_REQUEST['reporter'];
$filekey=$_REQUEST['filekey'];
$report=$_REQUEST['report'];
$qry="select * from fileinfo where idkey='$filekey'";
$rs=$conn->execute($qry);
$dir=$rs->fields['dir'];
$filename=$rs->fields['file_name'];
$sneder=$rs->fields['sneder'];
$mimetype=$rs->fields['mime_type'];
$size=$rs->fields['size'];
$time=time();
$tomeout=$time+($config['TIME_OUT_ABUSE']*86400);
$filepath=$config['UP_DIR']."/".$rs->fields['dir']."/".$rs->fields['file_name'];
$content=getContents($filepath);
$qry="insert into abuse_reported_files set dir='$dir',name='$filename',sender='$sender',reporter='$reporter',content='$content',mime_type='$mimetype',size=$size,report='$report',entry=$time,timeout=$tomeout";
$conn->execute($qry);
STemplate::display("thank_for_report.tpl");
exit();
}
STemplate::display("report_abuse.tpl");

?>
