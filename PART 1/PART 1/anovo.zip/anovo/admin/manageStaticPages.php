<?php
require_once ('../common/config.inc.php');
$CFG['lang']['include_files'][] = 'admin/includes/languages/%s/manageStaticPages.php';
$CFG['html']['header'] = 'admin/includes/languages/%s/html_header.php';
$CFG['html']['footer'] = 'admin/includes/languages/%s/html_footer.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['mods']['include_files'][] = 'common/classes/class_ListRecordsHandler.lib.php';
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class ManageEditableMessagesFormHandler extends ListRecordsHandler
{
		public $user_id = '';
		public function buildConditionQuery()
		{
				$this->sql_condition = '';
		}
		public function buildSortQuery()
		{
				$this->sql_sort = ' page_id ASC';
		}
		public function getEditableMessages($table_name, $id)
		{
				$sql = 'SELECT page_id, page_title, page_display_title, page_content, page_status FROM ' . $table_name . ' WHERE page_id = \'' . $id . '\'';
				$stmt = $this->dbObj->Prepare($sql);
				$result_set = $this->dbObj->Execute($stmt);
				if (!$result_set) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$is_ok = false;
				if ($row = $result_set->FetchRow())
				{
						$this->setFormField('page_id', $row['page_id']);
						$this->setFormField('page_title', $row['page_title']);
						$this->setFormField('page_display_title', $row['page_display_title']);
						$this->setFormField('page_content', $row['page_content']);
						$this->setFormField('page_status', $row['page_status']);
						$is_ok = true;
				}
				return ($is_ok);
		}
		public function insertFormFieldsInTable($tableName, $fields_to_insert_arr = array())
		{
				$sql = 'INSERT ' . $tableName . ' SET page_added_date=NOW(), ';
				foreach ($fields_to_insert_arr as $field_name)
						if (isset($this->fields_arr[$field_name])) $sql .= $field_name . '=\'' . addslashes($this->fields_arr[$field_name]) . '\', ';
				$sql = substr($sql, 0, strrpos($sql, ','));
				$stmt = $this->dbObj->Prepare($sql);
				$result_set = $this->dbObj->Execute($stmt);
				if (!$result_set) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return ($this->dbObj->Insert_ID());
		}
		public function updateFormFieldsInTable($tableName, $fields_to_insert_arr = array())
		{
				$sql = 'UPDATE ' . $tableName . ' SET page_added_date=NOW(), ';
				foreach ($fields_to_insert_arr as $field_name)
						if (isset($this->fields_arr[$field_name])) $sql .= $field_name . '=\'' . addslashes($this->fields_arr[$field_name]) . '\', ';
				$sql = substr($sql, 0, strrpos($sql, ','));
				$sql .= 'WHERE ' . 'page_id=\'' . $this->fields_arr['id'] . '\'';
				$stmt = $this->dbObj->Prepare($sql);
				$result_set = $this->dbObj->Execute($stmt);
				if (!$result_set) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function common_hidden($hidden_field = array())
		{
				foreach ($hidden_field as $hidden_name)
				{
?>
						<input type="hidden" name="delete[]" value="<?php echo $hidden_name; ?>" />
<?php }
		}
		public function deleteMessages($tableName, $did)
		{
				$id = $did;
				$sql = 'DELETE FROM ' . $tableName . ' WHERE page_id IN(' . $id . ')';
				$stmt = $this->dbObj->Prepare($sql);
				$result_set = $this->dbObj->Execute($stmt);
				if (!$result_set) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function chkIsTitleExists($table_name, $err_tip = '')
		{
				$sql = 'SELECT page_id FROM ' . $table_name . ' WHERE page_title=' . $this->dbObj->Param('page_title');
				if ($this->fields_arr['id']) $sql .= ' AND page_id!=\'' . addslashes($this->fields_arr['id']) . '\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['page_title']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if (!$rs->PO_RecordCount()) return true;
				$this->setCommonErrorMsg($err_tip);
				$this->fields_err_tip_arr['page_title'] = $err_tip;
				return false;
		}
		public function dateWithTime($dateTimeValue)
		{
				if ($dateTimeValue != '')
				{
						$formatDate = date("M jS, h.i a", strtotime($dateTimeValue));
				}
				else
				{
						$formatDate = '';
				}
				return ($formatDate);
		}
		public function resetFieldsArray()
		{
				$this->setFormField('id', 0);
				$this->setFormField('page_title', '');
				$this->setFormField('page_display_title', '');
				$this->setFormField('page_content', '');
				$this->setFormField('page_status', 'Yes');
		}
}
$editablefrm = new ManageEditableMessagesFormHandler();
$editablefrm->setDBObject($db);
$editablefrm->setLang(array('sort_ascending' => $LANG['list_sort_ascending'], 'sort_descending' => $LANG['list_sort_descending']));
$editablefrm->setPageBlockNames(array('msg_no_records', 'page_nav', 'msg_form_error', 'msg_form_success', 'form_add_messages', 'form_disp_messages', 'form_confirm'));
$editablefrm->setColumnSortUrl($_SERVER['PHP_SELF']);
$editablefrm->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$editablefrm->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$editablefrm->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$editablefrm->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$editablefrm->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$editablefrm->setCSSColumnHeaderCellAscSortClasses(array('clsColumnHeaderCellAscSort1', 'clsColumnHeaderCellAscSort2', 'clsColumnHeaderCellAscSort3', 'clsColumnHeaderCellAscSort4', 'clsColumnHeaderCellAscSort5'));
$editablefrm->setCSSColumnHeaderCellDefaultClass('clsColumnHeaderCellDefault');
$editablefrm->setCSSColumnHeaderCellDescSortClasses(array('clsColumnHeaderCellDscSort1', 'clsColumnHeaderCellDscSort2', 'clsColumnHeaderCellDscSort3', 'clsColumnHeaderCellDscSort4', 'clsColumnHeaderCellDscSort5'));
$editablefrm->setCSSAlternativeRowClasses(array('clsTblRow1', 'clsTblRow2', 'clsTblRow3'));
$editablefrm->setSearchFormFieldNames('start', 'numpg', 'dsc', 'asc');
$editablefrm->setCfgLangGlobal($CFG, $LANG);
$editablefrm->setFormField('page_id', '');
$editablefrm->resetFieldsArray();
$editablefrm->setFormField('delete', array());
$editablefrm->setFormField('to_do', '');
$editablefrm->setFormField('action', '');
$editablefrm->tabindex = 995;
$editablefrm->setFormField('asc', '');
$editablefrm->setFormField('dsc', '');
$editablefrm->setFormField('start', 0);
$editablefrm->setFormField('numpg', $CFG['data_tbl']['numpg']);
$editablefrm->setMinRecordSelectLimit($CFG['data_tbl']['min_record_select_limit']);
$editablefrm->setMaxRecordSelectLimit($CFG['data_tbl']['max_record_select_limit']);
$editablefrm->setNumPerPageListArr($CFG['data_tbl']['numperpage_list_arr']);
$editablefrm->setTableNames(array($CFG['db']['tbl']['static_pages']));
$editablefrm->setReturnColumns(array('page_id', 'page_title', 'page_display_title', 'page_content', 'page_status', 'page_added_date'));
$editablefrm->setAllPageBlocksHide();
$editablefrm->setPageBlockShow('form_add_messages');
if ($editablefrm->isFormGETed($_GET, 'showadd'))
{
		$editablefrm->setPageBlockShow('form_add_messages');
		$editablefrm->setPageBlockShow('form_disp_messages');
} elseif ($editablefrm->isFormGETed($_GET, 'id'))
{
		$editablefrm->sanitizeFormInputs($_GET);
		$id = addslashes($editablefrm->getFormField('id'));
		$editablefrm->setFormField('id', $id);
		if ($editablefrm->getEditableMessages($CFG['db']['tbl']['static_pages'], $editablefrm->getFormField('id')))
		{
				$editablefrm->setPageBlockShow('form_disp_messages');
				$editablefrm->setPageBlockShow('form_add_messages');
		}
		else
		{
				$editablefrm->setPageBlockShow('msg_form_error');
		}
} elseif ($editablefrm->isFormPOSTed($_POST, 'addeditablemessage'))
{
		$editablefrm->sanitizeFormInputs($_POST);
		$editablefrm->chkIsNotEmpty('page_title', $LANG['editable_messages_err_tip_compulsory']) and $editablefrm->chkIsTitleExists($CFG['db']['tbl']['static_pages'], $LANG['editable_messages_err_tip_title_exists']);
		$editablefrm->chkIsNotEmpty('page_content', $LANG['editable_messages_err_tip_compulsory']);
		$editablefrm->chkIsNotEmpty('page_status', $LANG['editable_messages_err_tip_compulsory']);
		if ($editablefrm->isValidFormInputs())
		{
				$editablefrm->setAllPageBlocksHide();
				$succesMsg = '';
				$editablefrm->setPageBlockShow('msg_form_success');
				$editablefrm->setPageBlockShow('form_add_messages');
				$editablefrm->setPageBlockShow('form_disp_messages');
				$page_content = html_entity_decode($editablefrm->getFormField('page_content'));
				$editablefrm->setFormField('page_content', $page_content);
				if (trim($editablefrm->getFormField('id')) == '0')
				{
						$inputArr = array('page_title', 'page_display_title', 'page_content', 'page_status');
						$currentEventId = $editablefrm->insertFormFieldsInTable($CFG['db']['tbl']['static_pages'], $inputArr);
						$succesMsg = $LANG['editable_messages_success_add_message'];
				}
				else
				{
						$inputArr = array('page_title', 'page_display_title', 'page_content', 'page_status');
						$editablefrm->updateFormFieldsInTable($CFG['db']['tbl']['static_pages'], $inputArr);
						$succesMsg = $LANG['editable_messages_success_update_message'];
				}
				$editablefrm->resetFieldsArray();
		}
		else
		{
				$editablefrm->setAllPageBlocksHide();
				$editablefrm->setPageBlockShow('msg_form_error');
				$editablefrm->setPageBlockShow('form_disp_messages');
				$editablefrm->setPageBlockShow('form_add_messages');
		}
} elseif ($editablefrm->isFormPOSTed($_POST, 'canceleditablemessage'))
{
		Redirect2URL($CFG['site']['url'] . "admin/manageStaticPages.php");
} elseif ($editablefrm->isFormPOSTed($_POST, 'confirm_action'))
{
		$editablefrm->sanitizeFormInputs($_POST);
		if ($editablefrm->getFormField('action') == 1) $editablefrm->deleteMessages($CFG['db']['tbl']['static_pages'], $editablefrm->getFormField('delete'));
		Redirect2URL($CFG['site']['url'] . "admin/manageStaticPages.php?delete");
} elseif ($editablefrm->isFormGETed($_GET, 'change'))
{
		$editablefrm->sanitizeFormInputs($_GET);
}
if ($editablefrm->isFormGETed($_GET, 'delete'))
{
		$editablefrm->setAllPageBlocksHide();
		$editablefrm->setPageBlockShow('msg_form_success');
		$editablefrm->setPageBlockShow('form_add_messages');
		$editablefrm->setPageBlockShow('form_disp_messages');
		$succesMsg = $LANG['editable_messages_success_delete_message'];
		;
}
$editablefrm->buildSelectQuery();
$editablefrm->buildConditionQuery();
$editablefrm->buildSortQuery();
$editablefrm->buildQuery();
$editablefrm->executeQuery();
$editablefrm->setPageBlockShow('form_disp_messages');
if (!$editablefrm->isResultsFound()) $editablefrm->setPageBlockShow('msg_no_records');
else  $editablefrm->setPageBlockShow('page_nav');
$editablefrm->setPageBlockHide('page_nav');
?>
<script language="javascript">
	var block_arr= new Array('selMsgConfirm');
	var replace_url = '<?php echo $CFG['site']['url']; ?>login.php';
</script>

<div id="selEditableMessages">
	<h2 class="clsManageStaticPageHeading"><?php echo $LANG['editable_messages_page_title']; ?></h2>

<?php
if ($editablefrm->isShowPageBlock('msg_form_error'))
{
?>
<div id="selMsgError">
	 <p><?php echo $LANG['editable_messages_err_tip_error'] . ' ' . $editablefrm->getCommonErrorMsg(); ?></p>
</div>
<?php
}
if ($editablefrm->isShowPageBlock('msg_form_success'))
{
?>
<div id="selMsgSuccess">
 	<p><?php echo $succesMsg; ?></p>
</div>
  <?php
}


?>
	<div id="selMsgConfirm" class="clsPopupConfirmation" style="display:none;position:absolute;">
		<p id="confirmMessage"></p>
		<form name="msgConfirmform" id="msgConfirmform" method="post" action="<?php echo URL($_SERVER['PHP_SELF']); ?>">
			<table summary="<?php echo $LANG['editable_messages_tbl_summary']; ?>">
				<tr>
					<td>
						<input type="submit" class="clsSubmitButton" name="confirm_action" id="confirm_action" tabindex="<?php echo $editablefrm->tabindex += 5; ?>" value="<?php echo $LANG['editable_messages_yes']; ?>" />&nbsp;
						<input type="button" class="clsCancelButton" name="cancel" id="cancel" tabindex="<?php echo $editablefrm->tabindex += 5; ?>" value="<?php echo $LANG['editable_messages_no']; ?>"  onClick="return hideAllBlocks('form_disp_editable_message');" />
						<input type="hidden" name="delete" id="delete1" />
						<input type="hidden" name="action" id="action" />
					</td>
				</tr>
			</table>
		</form>
	</div>

<?php


if ($editablefrm->isShowPageBlock('form_add_messages'))
{
		$submitName = '';
		if ($editablefrm->getFormField('id') != 0) $submitName = $LANG['editable_messages_update'];
		else  $submitName = $LANG['editable_messages_add'];
?>
		<form name="form_editable_message" id="form_editable_message" method="post" action="<?php echo URL($_SERVER['PHP_SELF']); ?>" autocomplete="off">
			<table summary="<?php echo $LANG['editable_messages_tbl_summary']; ?>" class="clsStaticContentTbl">
				<tr>
					<td class="<?php echo $editablefrm->getCSSFormLabelCellClass('page_title'); ?>"><label for="page_title"><?php echo $LANG['editable_messages_title']; ?></label></td>
					<td class="<?php echo $editablefrm->getCSSFormFieldCellClass('page_title'); ?>"><?php echo $editablefrm->getFormFieldErrorTip('page_title'); ?>
					<?php if ($editablefrm->getFormField('id') != 0)
		{ ?>
						<strong><?php echo stripslashes($editablefrm->getFormField('page_title')); ?></strong>
						<input type="hidden" name="page_title" id="page_title" value="<?php echo stripslashes($editablefrm->getFormField('page_title')); ?>" />
					<?php }
		else
		{ ?>
						<input type="text" class="clsTextBox" maxlength="50" name="page_title" id="page_title" tabindex="<?php echo $editablefrm->tabindex += 5; ?>" value="<?php echo stripslashes($editablefrm->getFormField('page_title')); ?>" />
					<?php } ?>
					</td>
			    </tr>
			    <tr>
					<td class="<?php echo $editablefrm->getCSSFormLabelCellClass('page_display_title'); ?>"><label for="page_display_title"><?php echo $LANG['editable_messages_display_title']; ?></label></td>
					<td class="<?php echo $editablefrm->getCSSFormFieldCellClass('page_display_title'); ?>"><?php echo $editablefrm->getFormFieldErrorTip('page_display_title'); ?>
						<input type="text" class="clsTextBox" maxlength="50" name="page_display_title" id="page_display_title" tabindex="<?php echo $editablefrm->tabindex += 5; ?>" value="<?php echo stripslashes($editablefrm->getFormField('page_display_title')); ?>" />
					</td>
			    </tr>
			    <tr>
					<td class="<?php echo $editablefrm->getCSSFormLabelCellClass('page_content'); ?>"><label for="page_content"><?php echo $LANG['editable_messages_content']; ?></label></td>
					<td class="<?php echo $editablefrm->getCSSFormFieldCellClass('page_content'); ?>"><?php echo $editablefrm->getFormFieldErrorTip('page_content'); ?>
						<textarea name="page_content" id="page_content" tabindex="<?php echo $editablefrm->tabindex += 5; ?>"><?php echo stripslashes($editablefrm->getFormField('page_content')); ?></textarea>
					</td>
			    </tr>
			   	<tr>
					<td class="<?php echo $editablefrm->getCSSFormLabelCellClass('page_status'); ?>"><label for="status_yes"><?php echo $LANG['editable_messages_status']; ?></label></td>
					<td class="<?php echo $editablefrm->getCSSFormFieldCellClass('page_status'); ?>"><?php echo $editablefrm->getFormFieldErrorTip('page_status'); ?>
						<input type="radio" name="page_status" id="status_yes" value="Yes"<?php echo ($editablefrm->getFormField('page_status') == 'Yes') ? ' checked' : ''; ?> /><label for="status_yes"><?php echo $LANG['editable_messages_yes']; ?></label>
						<input type="radio" name="page_status" id="status_no" value="No"<?php echo ($editablefrm->getFormField('page_status') == 'No') ? ' checked' : ''; ?> /><label for="status_no"><?php echo $LANG['editable_messages_no']; ?></label>
					</td>
			   </tr>
			   <tr>
		   			<td class="<?php echo $editablefrm->getCSSFormFieldCellClass('submit'); ?>" colspan="2"><input type="submit" class="clsSubmitButton" name="addeditablemessage" id="addeditablemessage" tabindex="<?php echo $editablefrm->tabindex += 5; ?>" value="<?php echo $submitName; ?>" />
					   <?php
		if ($editablefrm->getFormField('id') != 0)
		{
?><input type="submit" class="clsSubmitButton" name="canceleditablemessage" id="canceleditablemessage" tabindex="<?php echo $editablefrm->tabindex += 5; ?>" value="<?php echo $LANG['editable_messages_cancel']; ?>" /><?php
		}
?>
					   <input type="hidden" name="id" id="id" value="<?php echo $editablefrm->getFormField('id'); ?>" /></td>
				</tr>
			</table>
		</form>
<?php
}
if ($editablefrm->isShowPageBlock('form_disp_messages'))
{
?>
		<form name="form_disp_editable_message" id="form_disp_editable_message" method="post" action="<?php echo URL($_SERVER['PHP_SELF']); ?>">
		   <table summary="<?php echo $LANG['editable_messages_tbl_summary']; ?>">
			<?php
		if ($editablefrm->isResultsFound())
		{
?>
						<tr>
							<th class="clsSelectAllItems"><input type="checkbox" name="checkall" id="checkall" tabindex="<?php echo $editablefrm->getTabIndex(); ?>" onclick="selectAll(this.form)"/></th>
							<th><?php echo $LANG['editable_messages_title']; ?></th>
							<th><?php echo $LANG['editable_messages_display_title']; ?></th>
							<th><?php echo $LANG['editable_messages_status']; ?></th>
							<th class="clsSpotLightDate"><?php echo $LANG['editable_messages_date']; ?></th>
							<th class="clsMembersManage"><?php echo $LANG['editable_messages_manage']; ?></th>
						</tr>
<?php
				$i = 1;
				while ($row = $editablefrm->fetchResultRecord())
				{
?>
								<tr>
									<td class="clsSelectAllItems"><input type="checkbox" name="delete[]" onclick="disableHeading('form_disp_editable_message');" value="<?php echo $row['page_id']; ?>" <?php if ((($editablefrm->getFormField('delete') != 0)) && (in_array($row['page_id'], $editablefrm->getFormField('delete')))) echo "checked=\"checked\""; ?> /></td>
									<td><?php echo $row['page_title']; ?></a></td>
									<td class="clsStaticContent"><?php echo $row['page_display_title']; ?></a></td>
									<td><?php echo $row['page_status']; ?></a></td>
									<td class="clsSpotLightDate"><?php echo $editablefrm->dateWithTime($row['page_added_date']); ?></td>
									<td class="clsMembersManage"><a href="<?php echo URL($_SERVER['PHP_SELF']) . '?id=' . $row['page_id']; ?>"><?php echo $LANG['editable_messages_edit']; ?></a></td>
								</tr>
<?php
						$i++;
				}
?>
						<tr>
							<td colspan="6">
								<a href="#" id="dAltMlti"></a>
								<select name="to_do" name="to_do">
									<option value="1" <?php if ($editablefrm->getFormField('to_do') == 1) echo 'selected=\'selected\''; ?>><?php echo $LANG['editable_messages_delete']; ?></option>
								</select>
								<input type="button" class="clsSubmitButton" name="submit_do" value="<?php echo $LANG['editable_messages_go']; ?>" onClick="if(getMultiCheckBoxValue('form_disp_editable_message', 'checkall', '<?php echo 'Please select a title'; ?>', 'dAltMlti', -25, -290)){Confirmation('dAltMlti', 'selMsgConfirm', 'msgConfirmform', Array('delete1', 'action', 'confirmMessage'), Array(multiCheckValue, document.form_disp_editable_message.to_do.value, '<?php echo $editablefrm->LANG['editable_messages_confirm']; ?>'), Array('value', 'value', 'innerHTML'), -25, -290);}" tabindex="<?php echo $editablefrm->tabindex += 5; ?>" />
							</td>
						</tr>
<?php
		}
		else
		{
?>
						<tr>
							<td colspan="6"><?php echo $LANG['editable_messages_no_records']; ?></td>
						</tr>
<?php
		}
?>
		   </table>
		</form>
<?php
}
if ($editablefrm->isShowPageBlock('page_nav'))
{
?>
  <form name="form_pref" id="selFormPref" method="get" action="<?php echo URL($_SERVER['PHP_SELF']); ?>" autocomplete="off">
    <table cellspacing="0" border="1" summary="Filter Table" class="clsFilterTable">
      <tr>
        <?php if ($CFG['data_tbl']['page_style_list'])
		{
?>
        <td><?php
				$editablefrm->populatePageLinks($editablefrm->getFormField('start'), array('asc', 'dsc'));
?>
        </td>
        <?php
		}
		else
		{
?>
        <td><label for="numpg"><?php echo $LANG['list_recpage']; ?></label></td>
        <td><select name="numpg" id="numpg" tabindex="4020">
            <?php $editablefrm->populateNumPerPageList($editablefrm->getFormField('numpg')); ?>
          </select></td>
        <td><label for="start"><?php echo $LANG['list_choosepage']; ?></label></td>
        <td><select name="start" id="start" tabindex="4025">
            <?php $editablefrm->populatePageNumbersList($editablefrm->getFormField('start')); ?>
          </select></td>
        <td><?php $editablefrm->populateHiddenFormFields(array('asc', 'dsc')); ?>
          <input type="submit" class="clsSubmitButton" name="change" id="change" value="<?php echo $LANG['list_show']; ?>" tabindex="4030"/></td>
        <?php
		}
?>
      </tr>
    </table>
  </form>
  <?php
}
?>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>
