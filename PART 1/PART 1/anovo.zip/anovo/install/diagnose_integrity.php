<?php
session_start();
if (!isset($_SESSION['check']) or !$_SESSION['check']) header('Location: auth.php');

$checksum['../news.php'] = 'b1fbb097b6ddd464e69e4dd941c42294';
$checksum['../accessibility.php'] = '589f749a1ade3d44ac5e30e7a177a16c';
$checksum['../captchaSignup.php'] = '546f9aa5279c4b5f992cb4fd5dc27036';
$checksum['../devLogin.php'] = '6147107981c2541eed791b1a60f2d69c';
$checksum['../favicon.ico'] = 'f749f7816f7c932b53467dac597cc265';
$checksum['../logout.php'] = 'e8575c0e4d0ab9dc5d135044eb18f676';
$checksum['../forgotPassword.php'] = '337ee87683579fd879c70144b22f035d';
$checksum['../privacyPolicy.php'] = '5ae6a3daec26a9c1986a6a92b6303bae';
$checksum['../signup.php'] = '3f143158f346f825f3ef5473d3a02e5c';
$checksum['../useTerms.php'] = 'a4a3cb69e00e3c4accc20d1d3bf36028';
$checksum['../verifyMail.php'] = '3333b9690e318481e74d2d9600086846';
$checksum['../index.php'] = 'f443836ca6f620f6e1069d0ed120a6dd';
$checksum['../login.php'] = '85caee5cee16dfbfe8ab0c86a28032f0';
$checksum['../help.php'] = '54adbc9c95a055496fb665b6a4d7396d';
$checksum['../sitemap.php'] = 'e2134db155f80dc0c0452b77bd2e4518';
$checksum['../contactUs.php'] = 'd5998b6ffb71d064a91f54c83cce88a0';
$checksum['../faq.php'] = 'a6b35b5dfb273d64d4b4befcba318881';
$checksum['../css/print.css'] = '0b3ddea0209bb73ca83e11e7da454b3d';
$checksum['../css/debug.css'] = 'fb3c3020279fc848be5e0d2c1e74c106';
$checksum['../css/projection.css'] = 'd371e0b17adae1a6fd564c31a145bb60';
$checksum['../css/screen_dark.css'] = 'e57028dca4fc0c675b4ceeaacf382016';
$checksum['../css/screen_blue.css'] = '117514696791f63bb88c18ea1b70935d';
$checksum['../common/titles.inc.php'] = 'f254d0233844a5db4fd9039a84987ff1';
$checksum['../common/application_top.inc.php'] = '1ed22d586c19fe511d20e6dbed7cdf34';
$checksum['../common/application_bottom.inc.php'] = '37848740ffd36015655c185ccc377fd2';
$checksum['../common/http_headers.inc.php'] = 'd803334c112b9bf897f48a220030eb86';
$checksum['../common/config.inc.php'] = '94098e96a8d1816d369a329db2cdc7f6';
$checksum['../common/email_templates/languages/en_us/email_notify.inc.php'] = '50186c4d18d04e63f9f9eff4c81268e5';
$checksum['../common/gd_fonts/arial.ttf'] = '124a965ffc59a680c2c20c69c2984032';
$checksum['../common/gd_fonts/realpolitik.ttf'] = 'ca92df0dcee22a470e946594a5d791eb';
$checksum['../common/authentication/authenticate_user.inc.php'] = '2b9ca9cb4ff3a7451a54cc36a35bc7de';
$checksum['../common/languages/ta.inc.php'] = 'e38cfdd511b41faea224b9de272ef1ab';
$checksum['../common/languages/es.inc.php'] = 'f2f5c0cd6dded712b0ed67bf0f007046';
$checksum['../common/languages/select_language.inc.php'] = 'afd53758fea0e996d2fffb967a1141ae';
$checksum['../common/languages/en_us.inc.php'] = '467d8e2ef312b6b5d553ef58b086eae6';
$checksum['../common/languages/en_us/help.inc.php'] = '752e5b34c502e2eaf54614b55c84f619';
$checksum['../common/languages/en_us/lists_array/countries_list_array.inc.php'] = 'e885df18127478c2d50d64df3c8edbc1';
$checksum['../common/languages/en_us/lists_array/months_list_array.inc.php'] = 'fb7b1c9baede294a12680e93c69b580d';
$checksum['../common/languages/en_us/lists_array/payment_processors_list_array.inc.php'] = '720fb3150fa17741d7a3bf4baba9bd5a';
$checksum['../common/languages/en_us/lists_array/faq_list_array.inc.php'] = '34f58e8e085677a46333b691c4783e68';
$checksum['../common/languages/en_us/lists_array/news_list_array.inc.php'] = 'e1fb26f8ef28e7a1de7984742d8a9fbb';
$checksum['../common/languages/es/help.inc.php'] = '33505ae52a9046d55859fa00d4043e0f';
$checksum['../common/classes/class_User.lib.php'] = '34c2d8e2a49eaeee2011fe9162c3b1cd';
$checksum['../common/classes/class_ErrorHandler.lib.php'] = '552d3457d9e0e7ec8c3ce584dad6bf99';
$checksum['../common/classes/class_ListRecordsHandler.lib.php'] = '301052e15e596a5ee3c64fb78b5ea569';
$checksum['../common/classes/class_Parser.lib.php'] = '357b36016fa7c705983cdc1b5a7f4332';
$checksum['../common/classes/class_CustomSession.lib.php'] = '8eddc12ac679ccd75149e4454b2807f8';
$checksum['../common/classes/class_FormHandler.lib.php'] = '08b7923e2dd9149a08907278a254b021';
$checksum['../common/classes/phpmailer/class_PHPMailer.lib.php'] = '13fec9bff4266068b61c329f515dfe58';
$checksum['../common/classes/phpmailer/class_SMTP.lib.php'] = '092dcb7eee2f9f25ec0148391b251a89';
$checksum['../common/classes/db/sqlite.php'] = '0594b1b2021016372e0aabb1208c6491';
$checksum['../common/classes/db/mysql4.php'] = '4586bd801e58fbffe8264a0a9d0b1d5d';
$checksum['../common/stylesheets/select_stylesheet.inc.php'] = 'e772f74ecd40e6e4bac678286906e3a2';
$checksum['../admin/editConfig.php'] = 'd0fdb5f64059851398abf6b582853f90';
$checksum['../admin/editEmailTemplates.php'] = 'ca3b56f965486855eb2bc0d84abb2f05';
$checksum['../admin/messageList.php'] = 'b8ac3b4e53e24ccf63e37d0a459edbb2';
$checksum['../admin/userProfiles.php'] = 'eca41bee957186cffc19b3a138a1da0f';
$checksum['../admin/index.php'] = '5bd0fc809fce068a05bedb9a25bf4413';
$checksum['../admin/userProfilesEdit.php'] = '8100acabbabca48307273c9d218ab5fd';
$checksum['../admin/includes/languages/en_us/html_footer.php'] = 'bdf6075afc05433b28df88290ba01f28';
$checksum['../admin/includes/languages/en_us/editConfig.php'] = '85215a5916f95c13a901b024688c07c1';
$checksum['../admin/includes/languages/en_us/html_header.php'] = 'b2b91217a2f13a7df7581df7d6bad2ca';
$checksum['../admin/includes/languages/en_us/editEmailTemplates.php'] = '9bf50153bffed2089ae8851b395a40a0';
$checksum['../admin/includes/languages/en_us/messageList.php'] = 'afb49c7dbe9da9a8bfca51b12a4de46d';
$checksum['../admin/includes/languages/en_us/userProfiles.php'] = '2d1b0faf9b8f51a1623ea64cba1d8fb0';
$checksum['../admin/includes/languages/en_us/userProfilesEdit.php'] = '5cadd44bee6997a9da626bb44136ae74';
$checksum['../admin/includes/languages/es/html_header.php'] = '425c2e8265d8c799c23fd2d285352dc2';
$checksum['../admin/includes/languages/es/html_footer.php'] = '354dbb55188525d5c642192403cf2bb3';
$checksum['../admin/includes/languages/es/userProfiles.php'] = '56144595f551ba0124cf4d52a0aed29c';
$checksum['../admin/includes/languages/es/userProfilesEdit.php'] = '4ca781c186d68738530e6550abd3eb6c';
$checksum['../admin/css/screen_dark.css'] = '702c748a2ec523173a71f0eb6130080c';
$checksum['../admin/css/screen_blue.css'] = '04d5432db18721474092b4a2296e21f7';
$checksum['../members/editProfile.php'] = '94a2e54a819d0a63be9b08f1e28f77d3';
$checksum['../members/index.php'] = 'ef553dc3c6938ffdd3579f83ec1ddc67';
$checksum['../members/includes/languages/en_us/html_header.php'] = '0ca3e0820ab6f4048edac00e43107bc8';
$checksum['../members/includes/languages/en_us/html_footer.php'] = '46cfbe495b9bc9d9cf5bb1a07aa3920f';
$checksum['../members/includes/languages/en_us/editProfile.php'] = '8596df0a42b23a756a68fe596c450ce4';
$checksum['../members/includes/languages/es/html_header.php'] = 'befe4790d5eea28a7e119955b32c4b38';
$checksum['../members/includes/languages/es/html_footer.php'] = '7134361bb2411151862d581e1cea43ad';
$checksum['../members/includes/languages/es/editProfile.php'] = 'f395ab5fa52f625f33a9df8d97c9e79f';
$checksum['../members/css/screen_dark.css'] = 'c57a36003041d2d8fccfaaa72e2e7f0a';
$checksum['../members/css/screen_blue.css'] = '8bcc79503d04086798634eca5abf475a';
$checksum['../images/icon-css.png'] = '54e2bfd1fc890b7d6cabf6a921263d9a';
$checksum['../images/icon-xhtml10.png'] = '74415f068c16d422cfa2a8dfecd8d1ab';
$checksum['../images/icon-wai-aaa.png'] = '0a8d9585be578f0055cbfe15540094b8';
$checksum['../images/alert.png'] = '344416da49fa4ac6ef53112ed3006e83';
$checksum['../images/icon-help-book.gif'] = '98e828c9bbf0d082f224fbc2d95817bd';
$checksum['../images/icon-help.png'] = '4e5f81b48ac6ff144f0400f11261200c';
$checksum['../images/dsc9.png'] = '2e116bbb71cc1a4deb3dc5862bd27a75';
$checksum['../images/asc1.png'] = 'f29de7b0f2c0efb7be0fed257ee317c6';
$checksum['../images/asc2.png'] = '882941b7431d177d8278ddc02af2298f';
$checksum['../images/asc3.png'] = '38912dea2e11a844514a794103e72b50';
$checksum['../images/asc4.png'] = '90fa2013c1d7c6d11273f005c9c161ab';
$checksum['../images/asc5.png'] = 'a22eb4fd19b9017d3ad386b09a60f810';
$checksum['../images/asc6.png'] = '2f1ad22efd02c5ba776f2dc2ac032bf0';
$checksum['../images/asc7.png'] = 'ae9f5313b347b8534a6abf93320708dd';
$checksum['../images/asc8.png'] = '6b7459678eb978664c5f5d8bd8b20f25';
$checksum['../images/asc9.png'] = '9c7e5c0cb81c01985fae1d0446b403f2';
$checksum['../images/dsc1.png'] = '6ad41d2516bc651ab18d37de5babb02d';
$checksum['../images/dsc2.png'] = 'a85fe2a78e69acc517531e94cfee3710';
$checksum['../images/dsc3.png'] = '6f825644095360a71243b6cfcea9b7fa';
$checksum['../images/dsc4.png'] = 'fc823499dedef73906dbdd3effc99f26';
$checksum['../images/dsc5.png'] = '9ae8009584e1e06cda164810a39ef647';
$checksum['../images/dsc6.png'] = 'a4dd83227fc6c44a3004d44a9a51aa81';
$checksum['../images/dsc7.png'] = '95e248f4f6ece5a180b1c465770ff3c7';
$checksum['../images/dsc8.png'] = '6c2ec6e0fee5ecf8fcff3e9ebef93a94';
$checksum['../includes/languages/en_us/verifyMail.php'] = '21b06a6b401c02a05c27b851f3b943b0';
$checksum['../includes/languages/en_us/faq.php'] = '27cd4d68c254814ca8eb3d82acaaab29';
$checksum['../includes/languages/en_us/html_header.php'] = '0bf9fc6abe8d9234b83c7e8652bd9b35';
$checksum['../includes/languages/en_us/contactUs.php'] = 'a0d307a854c0ece94e3f488103ae0024';
$checksum['../includes/languages/en_us/news.php'] = 'd118b7ec08d19ecb6e3a61b5aedb7585';
$checksum['../includes/languages/en_us/signup.php'] = '355a3bcb6c24f52f59569b0a0b050ee6';
$checksum['../includes/languages/en_us/login.php'] = 'fc3aa497ef22640268aab15da47b9e00';
$checksum['../includes/languages/en_us/html_footer.php'] = '96d81ff2e1f03ffdcffcda2186023794';
$checksum['../includes/languages/en_us/logout.php'] = 'd5d97d204ccbf6d5769d66867fdee01e';
$checksum['../includes/languages/en_us/privacyPolicy.php'] = '7c1c55677fdfce25d239778a7a5064bd';
$checksum['../includes/languages/en_us/forgotPassword.php'] = 'beea0163d41e1ca9f1fd49dbd12ae15e';
$checksum['../includes/languages/en_us/accessibility.php'] = 'dc984366160281590a9d814054c5bd5b';
$checksum['../includes/languages/en_us/devLogin.php'] = 'f33491ac81e8c3fd36dbec8ab223e5ca';
$checksum['../includes/languages/en_us/useTerms.php'] = '56f1455a56ccb2f3f715c9fdb1e06125';
$checksum['../includes/languages/en_us/help.php'] = '60576ce8925319144322e9a9a9fb5a3b';
$checksum['../includes/languages/en_us/sitemap.php'] = '1427e67f1140f52000ad12f6fa1c7724';
$checksum['../includes/languages/es/logout.php'] = '28d3d0eb0db84539eb1aedf0a1339294';
$checksum['../includes/languages/es/html_header.php'] = 'b104c85d0a82ccbbc9bf297107c5fe17';
$checksum['../includes/languages/es/privacyPolicy.php'] = '7c24709d72b7fd70928674edab55db56';
$checksum['../includes/languages/es/html_footer.php'] = '3e6e6691621152d5d8eab34ff8e182ea';
$checksum['../includes/languages/es/forgotPassword.php'] = '443ec141ad76fb02b5500cbeb7e2ed96';
$checksum['../includes/languages/es/signup.php'] = 'fc03dcad0001295ccc3ee6e4dd138c9e';
$checksum['../includes/languages/es/useTerms.php'] = '94a092add8bf102d408ae942f289f3a6';
$checksum['../includes/languages/es/devLogin.php'] = '767e2db8a0382534b5602af2f4e633ae';
$checksum['../includes/languages/es/verifyMail.php'] = 'c949f01a2fb1875db4c67b788e13fb5a';
$checksum['../includes/languages/es/accessibility.php'] = '462818553117c7237813e2db581792ed';
$checksum['../includes/languages/es/login.php'] = '1cbf4c9a0fdc3b944813f5df199e5a2b';
$checksum['../install/updates.rdf'] = '46de5f15ed124abe380ad15fa0360292';
$checksum['../install/diagnose.php'] = '823b80fc59060212769de4f68bb2bbe7';
$checksum['../install/diagnose_development.php'] = '7bacf3f195db224083cc4dd6617f9ca4';
$checksum['../install/diagnose_imagettftext.php'] = '787724ad7e5aeedb1986f6a414958711';
$checksum['../install/phpinfo.php'] = '56f6fccae921d07f3c16ec128f50ccc5';
$checksum['../install/diagnose_integrity.php'] = '64ad42ae1fa7fb42023f6e4c2d2acc6d';
$checksum['../install/framework.sql'] = '7faee22be5f18eff1b8e343e7ac3d506';
$checksum['../install/readme.html'] = '51adaf5cc5239738263eb1283d2c7951';
$checksum['../install/readme.txt'] = '5768e009c7f7321c4a60e22a62d16a04';
$checksum['../js/script.js'] = '7dfbb7ca88494c4dc2c72fe6b2231c72';
$checksum['../js/lib/behaviour.js'] = '84961e468931407d04f431cfa45c7316';
$checksum['../js/lib/cssQuery-p.js'] = 'c260e94c53eca2a4c27de8e948664d2b';
function TraverseDirectory($dir, $dir_count)
{
		global $checksum;
		$handle = opendir($dir);
		while (false !== ($readdir = readdir($handle)))
		{
				if ($readdir != '.' && $readdir != '..')
				{
						$path = $dir . '/' . $readdir;
						$pad_str = str_pad('', $dir_count, "\t", STR_PAD_LEFT);
						if (is_dir($path))
						{
								echo $pad_str . '<li class="clsFolder"><a href="' . $path . '">' . $readdir . "</a>\n";
								++$dir_count;
								$pad_str .= "\t";
								echo $pad_str . '<ul>' . "\n";
								TraverseDirectory($path, $dir_count);
								echo $pad_str . '</ul>' . "\n";
								echo $pad_str . '</li>' . "\n";
						}
						if (is_file($path))
						{
								if (!isset($checksum[$path])) $file_status = 'New';
								else
										if ($checksum[$path] != md5_file($path)) $file_status = 'Tampered';
										else  $file_status = 'Ok';
								$cls_status = 'cls' . $file_status;
								echo $pad_str . '<li><a href="' . $path . '">' . $readdir . '</a> <span class="' . $cls_status . '">' . $file_status . '</span></li>' . "\n";
						}
				}
		}
		closedir($handle);
}
?>
<html>
<head>
<style type="text/css">
body {
  font-family: Verdana;
}
a {
  text-decoration: none;
}
a:hover {
  text-decoration: underline;
}
ul {
  list-style: circle;
  font-weight: normal;
  font-size: 9pt;
}
.clsFolder {
  list-style: square;
  font-weight: bold;
}
.clsNew {
  background-color: #ffff00;
}
.clsTampered {
  background-color: #ff0000;
}
.clsOk {
  background-color: #00ff00;
}
</style>
</head>
<h1>Diagnose Files Integrity</h1>
<body>
<ul>
<?php
TraverseDirectory('..', 0);
?>
</ul>
</body>
</html>