<?php
class HeaderHandler extends FormHandler
{
		public $tab_index = 900;
		public function HeaderHandler()
		{
				$this->setFormField('cid', '');
				$this->setFormField('parent_id', 0);
				$this->setFormField('qid', '');
				$this->setFormField('al', '');
				$this->setFormField('more_questions', '');
				$this->setFormField('subject', '');
				$this->setFormField('forum_topic', '');
				$this->setFormField('search_question', 'search for questions');
				$this->setFormField('search_forum_topic', 'search for forum topics');
				$this->setFormField('search_blog_subject', 'search for blogs subject');
				$this->sanitizeFormInputs($_REQUEST);
		}
		public function getHeaderQuestionDetails($question_table, $cat_table)
		{
				if (!$this->fields_arr['qid']) return;
				$sql = 'SELECT q.ques_id, q.pcat_id, q.cat_id FROM ' . $question_table . ' AS q' . ' WHERE q.status IN (\'Open\', \'Resolved\') AND q.ques_id=' . $this->dbObj->Param('qid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['qid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount())
				{
						$row = $rs->FetchRow();
						$this->fields_arr['cid'] = $row['cat_id'];
						$this->fields_arr['parent_id'] = $row['pcat_id'];
				}
		}
		public function getCategoryDetails($cat_table)
		{
				$sql = 'SELECT cat_name, parent_id FROM ' . $cat_table . ' WHERE cat_id=' . $this->dbObj->Param('cid') . ' AND status=\'1\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['cid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount())
				{
						$row = $rs->FetchRow();
						$this->fields_arr['parent_id'] = 0;
						if ($row['parent_id'] > 0) $this->fields_arr['parent_id'] = $row['parent_id'];
				}
				else  $this->fields_arr['cid'] = 0;
		}
		public function getAllCategories($cat_table, $limit)
		{
				$sql = 'SELECT cat_id, cat_name, has_child, total_questions FROM ' . $cat_table . ' WHERE status=\'1\'' . ' AND parent_id=0' . ' ORDER BY total_questions DESC';
				if ($limit) $sql .= ' LIMIT 0,' . ($limit + 1);
				$parent_id = 0;
				$cat_id = 0;
				if ($this->fields_arr['parent_id'])
				{
						$parent_id = $this->fields_arr['parent_id'];
						$cat_id = $this->fields_arr['cid'];
				} elseif ($this->fields_arr['cid'])
				{
						$parent_id = $this->fields_arr['cid'];
				}
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
?>

<div class="clsSideBarSections" id="selCategories">
  <div class="clsSideBarContents">
    <!--rounded corners-->
    <div class="lbsidebarsections">
      <div class="rbsidebarsections">
        <div class="bbsidebarsections">
          <div class="blcsidebarsections">
            <div class="brcsidebarsections">
              <div class="tbsidebarsections">
                <div class="tlcsidebarsections">
                  <div class="trcsidebarsections">
                    <h3><?php echo $this->LANG['categories']; ?></h3>
                    <ul class="clsSideBarLinks">
                      <?php
				if ($count = $rs->PO_RecordCount())
				{
						$i = 1;
						while ($row = $rs->FetchRow())
						{
								$class = 'clsInactive';
								if ($parent_id == $row['cat_id']) $class = 'clsActive';
								$clsDropDown = '';
								if ($row['has_child'] == '1') $clsDropDown = 'class="clsDropDown"';
?>
                      <li class="<?php echo $class; ?>"><a <?php echo $clsDropDown; ?> href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'questions.php?cid=' . $row['cat_id'], $this->CFG['site']['relative_url'] . 'answers/dir/' . $row['cat_id'] . '/', false); ?>"><span><?php echo stripString($row['cat_name']); ?>
                        <?php if ($row['total_questions']) echo '(' . $row['total_questions'] . ')'; ?>
                        </span></a>
                        <?php
								if ($parent_id == $row['cat_id'])
								{
										$this->getAllSubCategories($cat_table, $parent_id, $cat_id);
								}
?>
                      </li>
                      <?php
								if ($i++ >= $limit) break;
						}
				}
				else
				{
?>
                      <li class="clsNoCategory"><?php echo $this->LANG['no_categories_added']; ?></li>
                      <?php
				}
?>
                    </ul>
                    <?php if ($count)
				{ ?>
                    <p class="clsMoreLink"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'categories.php', $this->CFG['site']['relative_url'] . 'category/', false); ?>"><?php echo $this->LANG['more']; ?></a></p>
                    <?php } ?>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!--end of rounded corners-->
  </div>
</div>
<?php
		}
		public function getAllSubCategories($cat_table, $parent_id, $cat_id)
		{
				if (!$parent_id) return;
				$sql = 'SELECT cat_id, cat_name, total_questions FROM ' . $cat_table . ' WHERE parent_id=' . $this->dbObj->Param('parent_id') . ' AND status=\'1\'' . ' ORDER BY cat_name';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($parent_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($count = $rs->PO_RecordCount())
				{
?>
<ul>
  <?php
						while ($row = $rs->FetchRow())
						{
								$class = 'clsInactive';
								if ($cat_id == $row['cat_id']) $class = 'clsActive';
?>
  <li class="<?php echo $class; ?>"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'questions.php?cid=' . $row['cat_id'], $this->CFG['site']['relative_url'] . 'answers/dir/' . $row['cat_id'] . '/', false); ?>"><span><?php echo stripString($row['cat_name']); ?>
    <?php if ($row['total_questions']) echo '(' . $row['total_questions'] . ')'; ?>
    </span></a></li>
  <?php
						}
?>
</ul>
<?php
				}
		}
		public function showTopTags()
		{
				if ($this->CFG['admin']['index']['top_tags'])
				{
						$WIDGET_OBJ = new Widget();
						$WIDGET_OBJ->displayTopTags($this->CFG['admin']['index']['top_tags_count']);
				}
		}
		public function showTopSearchedTags()
		{
				if ($this->CFG['admin']['index']['top_search_tags'])
				{
						$WIDGET_OBJ = new Widget();
						$WIDGET_OBJ->displayTopSearchedTags($this->CFG['admin']['index']['top_search_tags_count']);
				}
		}
		public function countUnReadMail()
		{
				$sql = 'SELECT COUNT( mi.info_id ) AS mail_count' . ' FROM ' . $this->CFG['db']['tbl']['users'] . ' AS u, ' . $this->CFG['db']['tbl']['messages'] . ' AS ms, ' . $this->CFG['db']['tbl']['messages_info'] . ' AS mi' . ' WHERE mi.to_id = ' . $this->dbObj->Param($this->CFG['user']['user_id']) . ' AND mi.from_id = u.' . $this->getUserTableField('user_id') . ' AND mi.message_id = ms.message_id' . ' AND mi.to_viewed = \'No\'' . ' AND mi.to_delete = \'No\'' . ' AND mi.to_stored = \'No\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->CFG['user']['user_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = $rs->FetchRow();
				return $row['mail_count'];
		}
		public function populateMailRightNavigation()
		{
				$allowed_pages_array = array('mail.php', 'mailCompose.php', 'mailRead.php');
				if (!displayBlock($allowed_pages_array)) return;
				$cssClassToHighlightSubLink = 'clsActiveSidebarLinks';
				$mail = $mailCompose = $mail_pg_inbox = $mail_pg_sent = $mail_pg_compose = '';
				$currentPage = $this->CFG['html']['current_script_name'];
				$$currentPage = $cssClassToHighlightSubLink;
				$pg = (isset($_REQUEST['folder'])) ? $_REQUEST['folder'] : '';
				$pgRelatedPage = $currentPage . '_pg_' . $pg;
				$$pgRelatedPage = $cssClassToHighlightSubLink;
				if ($currentPage == 'mailRead' and $pg == 'inbox') $mail_pg_inbox = $cssClassToHighlightSubLink;
				if ($currentPage == 'mailRead' and $pg == 'sent') $mail_pg_sent = $cssClassToHighlightSubLink;

?>
<div class="clsSideBarSections" id="selMails">
  <div class="clsSideBarContents">
    <!--rounded corners-->
    <div class="lbsidebarsections">
      <div class="rbsidebarsections">
        <div class="bbsidebarsections">
          <div class="blcsidebarsections">
            <div class="brcsidebarsections">
              <div class="tbsidebarsections">
                <div class="tlcsidebarsections">
                  <div class="trcsidebarsections">
                    <h3><?php echo $this->LANG['nav_mail_mail']; ?></h3>
                    <ul class="clsSideBarLinks">
                      <li class="<?php echo $mail_pg_inbox; ?>"><a href="<?php echo getUrl($this->CFG['admin']['mail_urls']['inbox']['normal'], $this->CFG['admin']['mail_urls']['inbox']['htaccess']); ?>"><span><?php echo $this->LANG['nav_mail_inbox']; ?> ( <?php echo $this->countUnReadMail(); ?> )</span></a></li>
                      <li class="<?php echo $mail_pg_sent; ?>"><a href="<?php echo getUrl($this->CFG['admin']['mail_urls']['sent']['normal'], $this->CFG['admin']['mail_urls']['sent']['htaccess']); ?>"><span><?php echo $this->LANG['nav_mail_sent']; ?></span></a></li>
                      <li class="<?php echo $mailCompose; ?>"><a href="<?php echo getUrl($this->CFG['admin']['mail_urls']['compose']['normal'], $this->CFG['admin']['mail_urls']['compose']['htaccess']); ?>"><span><?php echo $this->LANG['nav_mail_compose']; ?></span></a></li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!--end of rounded corners-->
  </div>
</div>
<?php
		}
		public function showConfigFilePages()
		{
				$allowed_pages_array = array('editConfig.php', 'editDbConfig.php', 'editConfigIndex.php', 'editConfigModule.php', 'editAnswersConfig.php', 'editEncoderConfig.php', 'editUsersTableConfig.php', 'editEmailTemplates.php', 'editLanguageFile.php');
				if (!displayBlock($allowed_pages_array)) return;
				$currentPage = $this->CFG['html']['current_script_name'];
				$cssClassToHighlightMainLink = 'clsActiveHeaderMainLink';
				$editConfig = $editDbConfig = $editUsersTableConfig = $editConfigIndex = $editConfigModule = $editAnswersConfig = $editEncoderConfig = $editConfigAnsVideo = $editEmailTemplates = $editLanguageFile = '';
				$$currentPage = $cssClassToHighlightMainLink;
?>
<div class="clsSideBarSections">
  <div class="clsSideBarContents">
    <div class="clsHomeAdminModules">
      <div class="clsBackHome"><span class="clsMyHome"><a href="index.php"><?php echo $this->LANG['back_to_home']; ?></a></span> <span class="clsSettings"><?php echo $this->LANG['settings']; ?></span></div>
      <div class="clsAdminModules">
        <ul>
          <li class="<?php echo $editConfig; ?>"><a class="clsGeneral" href="editConfig.php"><?php echo $this->LANG['general']; ?></a></li>
          <!-- <li class="<?php echo $editUsersTableConfig; ?>"><a class="clsDatabase" href="editUsersTableConfig.php"><?php echo $this->LANG['user_table_config']; ?></a></li> -->
          <li class="<?php echo $editConfigIndex; ?>"><a class="clsHomePage" href="editConfigIndex.php"><?php echo $this->LANG['home_page']; ?></a></li>
          <li class="<?php echo $editConfigModule; ?>"><a class="clsModule" href="editConfigModule.php"><?php echo $this->LANG['module']; ?></a></li>
          <li class="<?php echo $editAnswersConfig; ?>"><a class="clsAdminAnswerLink" href="editAnswersConfig.php"><?php echo $this->LANG['answers']; ?></a></li>
          <li class="<?php echo $editEmailTemplates; ?>"><a class="clsAdminAnswerLink" href="editEmailTemplates.php"><?php echo $this->LANG['email_templates']; ?></a></li>
          <li class="<?php echo $editLanguageFile; ?>"><a class="clsAdminAnswerLink" href="editLanguageFile.php"><?php echo $this->LANG['edit_languages']; ?></a></li>
          <li class="<?php echo $editEncoderConfig; ?>"><a class="clsEncoder" href="editEncoderConfig.php"><?php echo $this->LANG['encoder']; ?></a></li>
        </ul>
      </div>
    </div>
  </div>
</div>
<?php
		}
		public function showConfigVideoPlayerPages()
		{
				$allowed_pages_array = array('ansVideoAdvertisement.php', 'ansVideoLogo.php', 'ansVideoPlayerSettings.php');
				if (!displayBlock($allowed_pages_array)) return;
				$currentPage = $this->CFG['html']['current_script_name'];
				$cssClassToHighlightMainLink = 'clsActiveHeaderMainLink';
				$ansVideoAdvertisement = $ansVideoLogo = $ansVideoPlayerSettings = '';
				$$currentPage = $cssClassToHighlightMainLink;
?>
<div class="clsSideBarSections">
  <div class="clsSideBarContents">
    <div class="clsHomeAdminModules">
      <div class="clsBackHome"> <span><a href="index.php"><?php echo $this->LANG['back_to_home']; ?></a></span> <span class="clsVideoPlayer"><?php echo $this->LANG['video_player']; ?></span></div>
      <div class="clsAdminModules">
        <ul>
          <li class="<?php echo $ansVideoPlayerSettings; ?>"><a class="clsVideoPlayerLink" href="ansVideoPlayerSettings.php"><?php echo $this->LANG['video_player_settings']; ?></a></li>
          <li class="<?php echo $ansVideoLogo; ?>"><a class="clsVideoPlayerLogo" href="ansVideoLogo.php"><?php echo $this->LANG['video_logo_settings']; ?></a></li>
          <li class="<?php echo $ansVideoAdvertisement; ?>"><a class="clsVideoAdvertisement" href="ansVideoAdvertisement.php"><?php echo $this->LANG['video_advertisement_settings']; ?></a></li>
        </ul>
      </div>
    </div>
  </div>
</div>
<?php
		}
		public function showAnswersPages()
		{
				$allowed_pages_array = array('questionCategory.php', 'manageAnswers.php', 'viewAnswers.php');
				if (!displayBlock($allowed_pages_array)) return;
				$currentPage = $this->CFG['html']['current_script_name'];
				$cssClassToHighlightMainLink = 'clsActiveHeaderMainLink';
				$questionCategory = $manageAnswers = $viewAnswers = '';
				$$currentPage = $cssClassToHighlightMainLink;
				$sub_arr = array('manageAnswers', 'viewAnswers');
				if (in_array($currentPage, $sub_arr)) $manageAnswers = $cssClassToHighlightMainLink;
?>
<div class="clsSideBarSections">
  <div class="clsSideBarContents">
    <div class="clsHomeAdminModules">
      <div class="clsBackHome"> <span><a href="index.php"><?php echo $this->LANG['back_to_home']; ?></a></span> <span class="clsAnswersLink"><?php echo $this->LANG['answers']; ?></span></div>
      <div class="clsAdminModules">
        <ul>
          <li class="<?php echo $manageAnswers; ?>"><a class="clsManageAnswerLink" href="manageAnswers.php"><?php echo $this->LANG['manage_answers']; ?></a></li>
          <li class="<?php echo $questionCategory; ?>"><a class="clsQuestionCategoryLink" href="questionCategory.php"><?php echo $this->LANG['question_category']; ?></a></li>
        </ul>
      </div>
    </div>
  </div>
</div>
<?php
		}
		public function showForumsPages()
		{
				$allowed_pages_array = array('forums.php', 'forumsAddTitle.php', 'forumsTopics.php', 'forumsTopicCreate.php', 'forumsResponses.php', 'forumsResponseCreate.php');
				if (!displayBlock($allowed_pages_array)) return;

?>
<div class="clsSideBarSections">
  <div class="clsSideBarContents">
    <div class="clsHomeAdminModules">
      <div class="clsBackHome"> <span><a href="index.php"><?php echo $this->LANG['back_to_home']; ?></a></span> <span class="clsForum"><?php echo $this->LANG['forumslinks_forums']; ?></span></div>
      <div class="clsAdminModules">
        <ul>
          <?php
				if (displayBlock(array('forums.php', 'forumsAddTitle.php')))
				{
						$currentPage = $this->CFG['html']['current_script_name'];
						$cssClassToHighlightMainLink = 'clsActiveHeaderMainLink';
						$forums = $forumsAddTitle = $topicsClass = $responseClass = '';
						$$currentPage = $cssClassToHighlightMainLink;
						if ($this->fields_arr['srch'] == 'mosttopics')
						{
								$topicsClass = $cssClassToHighlightMainLink;
								$forums = '';
						} elseif ($this->fields_arr['srch'] == 'mostresponses')
						{
								$responseClass = $cssClassToHighlightMainLink;
								$forums = '';
						}
?>
          <li class="<?php echo $forums; ?>"><a class="clsForumLink" href="forums.php"><?php echo $this->LANG['forumslinks_forums']; ?></a></li>
          <li class="<?php echo $forumsAddTitle; ?>"><a class="clsAddForumTitle" href="forumsAddTitle.php"><?php echo $this->LANG['forumslinks_add_title']; ?></a></li>
          <li class="<?php echo $topicsClass; ?>"><a class="clsMostTopic" href="forums.php?srch=mosttopics"><?php echo $this->LANG['forumslinks_most_topics']; ?></a></li>
          <li class="<?php echo $responseClass; ?>"><a class="clsMostResponse" href="forums.php?srch=mostresponses"><?php echo $this->LANG['forumslinks_most_responses']; ?></a></li>
          <?php
				}
				if (displayBlock(array('forumsTopics.php', 'forumsTopicCreate.php')))
				{
						$currentPage = $this->CFG['html']['current_script_name'];
						$cssClassToHighlightMainLink = 'clsActiveHeaderMainLink';
						$forumsTopics = $forumsTopicCreate = $responseClass = $viewClass = '';
						$$currentPage = $cssClassToHighlightMainLink;
						if ($this->fields_arr['srch'] == 'mostresponse')
						{
								$responseClass = $cssClassToHighlightMainLink;
								$forumsTopics = '';
						} elseif ($this->fields_arr['srch'] == 'mostviews')
						{
								$viewClass = $cssClassToHighlightMainLink;
								$forumsTopics = '';
						}
?>
          <li class="<?php echo $forumsTopics; ?>"><a href="forumsTopics.php?forum_id=<?php echo $this->fields_arr['forum_id']; ?>"><?php echo $this->LANG['forumslinks_topic']; ?></a></li>
          <li class="<?php echo $forumsTopicCreate; ?>"><a href="forumsTopicCreate.php?forum_id=<?php echo $this->fields_arr['forum_id']; ?>"><?php echo $this->LANG['forumslinks_post_topic']; ?></a></li>
          <li class="<?php echo $responseClass; ?>"><a href="forumsTopics.php?forum_id=<?php echo $this->fields_arr['forum_id']; ?>&srch=mostresponse"><?php echo $this->LANG['forumslinks_most_responses']; ?></a></li>
          <li class="<?php echo $viewClass; ?>"><a href="forumsTopics.php?forum_id=<?php echo $this->fields_arr['forum_id']; ?>&srch=mostviews"><?php echo $this->LANG['forumslinks_most_views']; ?></a></li>
          <?php
				}
				if (displayBlock(array('forumsResponses.php', 'forumsResponseCreate.php')))
				{
						$currentPage = $this->CFG['html']['current_script_name'];
						$cssClassToHighlightMainLink = 'clsActiveHeaderMainLink';
						$forumsResponses = $forumsResponseCreate = '';
						$$currentPage = $cssClassToHighlightMainLink;
?>
          <li class="<?php echo $forumsResponses; ?>"><a href="forumsResponses.php?forum_id=<?php echo $this->fields_arr['forum_id']; ?>&topic_id=<?php echo $this->fields_arr['topic_id']; ?>"><?php echo $this->LANG['forumslinks_response']; ?></a></li>
          <li class="<?php echo $forumsResponseCreate; ?>"><a href="forumsResponseCreate.php?forum_id=<?php echo $this->fields_arr['forum_id']; ?>&topic_id=<?php echo $this->fields_arr['topic_id']; ?>"><?php echo $this->LANG['forumslinks_post_response']; ?></a></li>
          <?php
				}
?>
        </ul>
      </div>
    </div>
  </div>
</div>
<?php
		}
		public function showBlogsPages()
		{
				$allowed_pages_array = array('manageBlogs.php', 'manageBlogCategory.php');
				if (!displayBlock($allowed_pages_array)) return;
				$currentPage = $this->CFG['html']['current_script_name'];
				$cssClassToHighlightMainLink = 'clsActiveHeaderMainLink';
				$manageBlogs = $manageBlogCategory = '';
				$$currentPage = $cssClassToHighlightMainLink;

?>
<div class="clsSideBarSections">
  <div class="clsSideBarContents">
    <div class="clsHomeAdminModules">
      <div class="clsBackHome"> <span><a href="index.php"><?php echo $this->LANG['back_to_home']; ?></a></span> <span class="clsBlogLink"><?php echo $this->LANG['blogs']; ?></span></div>
      <div class="clsAdminModules">
        <ul>
          <li class="<?php echo $manageBlogs; ?>"><a class="clsManageAnswerLink" href="<? echo $this->CFG['site']['relative_url'] . 'manageBlogs.php'; ?>"><?php echo $this->LANG['manage_blogs']; ?></a></li>
          <li class="<?php echo $manageBlogCategory; ?>"><a class="clsManageAnswerLink" href="<? echo $this->CFG['site']['relative_url'] . 'manageBlogCategory.php'; ?>"><?php echo $this->LANG['manage_blogs_category']; ?></a></li>
        </ul>
      </div>
    </div>
  </div>
</div>
<?php
		}
		public function showMemberPages()
		{
				$allowed_pages_array = array('manageAnswersMembers.php', 'editMembers.php', 'viewMembers.php');
				if (!displayBlock($allowed_pages_array)) return;
				$currentPage = $this->CFG['html']['current_script_name'];
				$cssClassToHighlightMainLink = 'clsActiveHeaderMainLink';
				$ManageAnswersMembers = '';
				$$currentPage = $cssClassToHighlightMainLink;

?>
<div class="clsSideBarSections">
  <div class="clsSideBarContents">
    <div class="clsHomeAdminModules">
      <div class="clsBackHome"> <span><a href="index.php"><?php echo $this->LANG['back_to_home']; ?></a></span> <span class="clsMembersLink"><?php echo $this->LANG['members']; ?></span></div>
      <div class="clsAdminModules">
        <ul>
          <li><a class="clsManageAnswerLink" href="manageAnswersMembers.php"><?php echo $this->LANG['manage_answers_members']; ?></a></li>
        </ul>
      </div>
    </div>
  </div>
</div>
<?php
		}
		public function showBannerPages()
		{
				$allowed_pages_array = array('manageBanner.php');
				if (!displayBlock($allowed_pages_array)) return;
				$currentPage = $this->CFG['html']['current_script_name'];
				$cssClassToHighlightMainLink = 'clsActiveHeaderMainLink';
				$manageBanner = '';
				$$currentPage = $cssClassToHighlightMainLink;

?>
<div class="clsSideBarSections">
  <div class="clsSideBarContents">
    <div class="clsHomeAdminModules">
      <div class="clsBackHome"> <span><a href="index.php"><?php echo $this->LANG['back_to_home']; ?></a></span> <span class="clsBannerLink"><?php echo $this->LANG['banners']; ?></span></div>
    </div>
  </div>
</div>
<?php
		}
		public function showAvatarPages()
		{
				$allowed_pages_array = array('manageAvatars.php');
				if (!displayBlock($allowed_pages_array)) return;
				$currentPage = $this->CFG['html']['current_script_name'];
				$cssClassToHighlightMainLink = 'clsActiveHeaderMainLink';
				$manageAvatars = '';
				$$currentPage = $cssClassToHighlightMainLink;

?>
<div class="clsSideBarSections">
  <div class="clsSideBarContents">
    <div class="clsHomeAdminModules">
      <div class="clsBackHome"> <span><a href="index.php"><?php echo $this->LANG['back_to_home']; ?></a></span> <span class="clsBannerLink"><?php echo $this->LANG['manage_avatars']; ?></span></div>
    </div>
  </div>
</div>
<?php
		}
		public function showNewsletterPages()
		{
				$allowed_pages_array = array('addNewsLetter.php');
				if (!displayBlock($allowed_pages_array)) return;
				$currentPage = $this->CFG['html']['current_script_name'];
				$cssClassToHighlightMainLink = 'clsActiveHeaderMainLink';
				$addNewsLetter = '';
				$$currentPage = $cssClassToHighlightMainLink;

?>
<div class="clsSideBarSections">
  <div class="clsSideBarContents">
    <div class="clsHomeAdminModules">
      <div class="clsBackHome"> <span><a href="index.php"><?php echo $this->LANG['back_to_home']; ?></a></span> <span class="clsNewsLetter"><?php echo $this->LANG['newsletter']; ?></span> </div>
    </div>
  </div>
</div>
<?php
		}
		public function showStaticPages()
		{
				$allowed_pages_array = array('staticPage.php', 'manageStaticPages.php');
				if (!displayBlock($allowed_pages_array)) return;
				$currentPage = $this->fields_arr['pg'];
				if ($this->CFG['html']['current_script_name'] == 'manageStaticPages') $currentPage = $this->CFG['html']['current_script_name'];
				$cssClassToHighlightMainLink = 'clsActiveHeaderMainLink';
				$faq = $privacy = $terms = $manageStaticPages = '';
				$$currentPage = $cssClassToHighlightMainLink;

?>
<div class="clsSideBarSections">
  <div class="clsSideBarContents">
    <div class="clsHomeAdminModules">
      <div class="clsBackHome"> <span><a href="index.php"><?php echo $this->LANG['back_to_home']; ?></a></span> <span class="clsStaticPagesLink"><?php echo $this->LANG['manage_static_pages']; ?></span></div>
      <div class="clsAdminModules">
        <ul>
          <li class="<?php echo $manageStaticPages; ?>"><a class="clsManageStaticLink" href="<? echo $this->CFG['site']['relative_url'] . 'manageStaticPages.php'; ?>"><?php echo $this->LANG['manage_static_pages']; ?></a></li>
          <li class="<?php echo $faq; ?>"><a class="clsFaq" href="<? echo $this->CFG['site']['relative_url'] . 'staticPage.php?pg=faq'; ?>">Faq</a></li>
          <li class="<?php echo $privacy; ?>"><a class="clsPrivacy" href="<? echo $this->CFG['site']['relative_url'] . 'staticPage.php?pg=privacy'; ?>">Privacy</a></li>
          <li class="<?php echo $terms; ?>"><a class="clsTerms" href="<? echo $this->CFG['site']['relative_url'] . 'staticPage.php?pg=terms'; ?>">Terms</a></li>
        </ul>
      </div>
    </div>
  </div>
</div>
<?php
		}
		public function getBestVideoAnswers()
		{
?>
<div class="clsVideoPopup">
  <div class="clsSideBarContents"> <img src="<?php echo $this->CFG['site']['url']; ?>images/flash-player.jpg" width="270px" /> </div>
</div>
<?php
		}
		public function getStartMessage()
		{
				if (chkAllowedModule(array('registration')))
				{
?>
<div class="clsSideBarSections">
  <div class="clsSideBarContents">
    <!--rounded corners-->
    <div class="lbsidebarsections">
      <div class="rbsidebarsections">
        <div class="bbsidebarsections">
          <div class="blcsidebarsections">
            <div class="brcsidebarsections">
              <div class="tbsidebarsections">
                <div class="tlcsidebarsections">
                  <div class="trcsidebarsections">
                    <div class="clsStartMessage">
                      <h4 class="clsStartMessageTitle"><span class="clsReadyTitle"><?php echo $this->LANG['ready_to_participate']; ?></span></h4>
                      <p class="clsStartMessageText"><a href="<?php echo getUrl($this->CFG['site']['url'] . 'signup.php', $this->CFG['site']['url'] . 'signup/', false); ?>"><?php echo $this->LANG['get_started']; ?></a></p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!--end of rounded corners-->
  </div>
</div>
<?php
				}
		}
		public function showAnswerSearchOption()
		{
				$not_allowed_pages_array = array('blogCategory.php', 'blogComment.php', 'blogs.php', 'manageBlog.php', 'forums.php', 'forumsResponses.php', 'forumsTopics.php', 'forumsResponseCreate.php', 'forumsTopicCreate.php', 'mySubscribedForum.php');
				if (displayBlock($not_allowed_pages_array)) return;
				if ($this->getFormField('more_questions')) $question_field_value = $this->getFormField('more_questions');
				else
						if ($this->getFormField('search_question')) $question_field_value = $this->getFormField('search_question');
						else  $question_field_value = $this->LANG['search_for_questions'];
				$defaultText = strtolower($this->LANG['search_for_questions']);
?>
<div id="selSearchForm" class="clsSearchForm">
  <form name="selFormSearchQuestion" id="selFormSearchQuestion" method="post" action="<?php echo URL(getUrl($this->CFG['site']['relative_url'] . 'questions.php?view=search', $this->CFG['site']['relative_url'] . 'answers/search/', false)); ?>" autocomplete="off">
    <table summary="Search question" class="clsSearchTable">
      <tr>
        <td><input type="text" class="clsTextBox" name="search_question" id="search_question" maxlength="250" tabindex="<?php echo $this->getTabIndex(); ?>" value="<?php echo $question_field_value; ?>" onBlur="displayDefaultValue(this, '<?php echo $defaultText ?>')" onFocus="clearDefaultValue(this, '<?php echo $defaultText ?>')" />
        </td>
        <td><input type="submit" class="clsSubmitButton" name="search" id="search" tabindex="<?php echo $this->getTabIndex(); ?>" value="<?php echo $this->LANG['search']; ?>" />
        </td>
        <td><a class="clsAdvanceSearchLink" href="<?php echo URL(getUrl($this->CFG['site']['relative_url'] . 'questions.php?so=adv', $this->CFG['site']['relative_url'] . 'answers/search/?so=adv', false)); ?>"><?php echo $this->LANG['advanced_search']; ?></a> </td>
      </tr>
    </table>
  </form>
</div>
<?php
		}
		public function showForumsSearchOption()
		{
				$allowed_pages_array = array('forumsResponses.php', 'forumsResponseCreate.php', 'forumsTopics.php', 'forumsTopicCreate.php');
				if (!displayBlock($allowed_pages_array)) return;
				if ($this->getFormField('forum_topic')) $forum_field_value = $this->getFormField('forum_topic');
				else
						if ($this->getFormField('search_forum_topic')) $forum_field_value = $this->getFormField('search_forum_topic');
						else  $forum_field_value = $this->LANG['search_for_forum_topics'];
				$defaultText = strtolower($this->LANG['search_for_forum_topics']);
?>
<div id="selSearchForm" class="clsSearchForm">
  <form name="selFormSearchForum" id="selFormSearchForum" method="post" action="<?php echo getUrl('forumsTopics.php?forum_id=' . $this->fields_arr['forum_id'], 'forum/' . $this->fields_arr['forum_id'] . '/'); ?>" autocomplete="off">
    <table summary="Search Forum Topic" class="clsSearchTable">
      <tr>
        <td><input type="text" class="clsTextBox" name="search_forum_topic" id="search_forum_topic" maxlength="250" tabindex="<?php echo $this->getTabIndex(); ?>" value="<?php echo $forum_field_value; ?>" onBlur="displayDefaultValue(this, '<?php echo $defaultText ?>')" onFocus="clearDefaultValue(this, '<?php echo $defaultText ?>')" />
        </td>
        <td><input type="submit" class="clsSubmitButton" name="search" id="search" tabindex="<?php echo $this->getTabIndex(); ?>" value="<?php echo $this->LANG['search']; ?>" />
        </td>
        <td><a class="clsAdvanceSearchLink" href="<?php echo getUrl('forumsTopics.php?forum_id=' . $this->fields_arr['forum_id'] . '&so=adv', 'forum/' . $this->fields_arr['forum_id'] . '/?so=adv'); ?>"><?php echo $this->LANG['advanced_search']; ?></a> </td>
      </tr>
    </table>
  </form>
</div>
<?php
		}
		public function showBlogsSearchOption()
		{
				$allowed_pages_array = array('blogCategory.php', 'blogComment.php', 'blogs.php', 'manageBlog.php');
				if (!displayBlock($allowed_pages_array)) return;
				if ($this->getFormField('subject')) $blog_field_value = $this->getFormField('subject');
				else
						if ($this->getFormField('search_blog_subject')) $blog_field_value = $this->getFormField('search_blog_subject');
						else  $blog_field_value = $this->LANG['search_for_blog_subject'];
				$defaultText = strtolower($this->LANG['search_for_blog_subject']);
?>
<div id="selSearchForm" class="clsSearchForm">
  <form name="selFormSearchBlog" id="selFormSearchBlog" method="post" action="<?php echo getUrl('blogs.php', 'blog/'); ?>" autocomplete="off">
    <table summary="Search Forum Blogs" class="clsSearchTable">
      <tr>
        <td><input type="text" class="clsTextBox" name="search_blog_subject" id="search_blog_subject" maxlength="250" tabindex="<?php echo $this->getTabIndex(); ?>" value="<?php echo $blog_field_value; ?>" onBlur="displayDefaultValue(this, '<?php echo $defaultText ?>')" onFocus="clearDefaultValue(this, '<?php echo $defaultText ?>')" />
        </td>
        <td><input type="submit" class="clsSubmitButton" name="search" id="search" tabindex="<?php echo $this->getTabIndex(); ?>" value="<?php echo $this->LANG['search']; ?>" />
        </td>
        <td><a class="clsAdvanceSearchLink" href="<?php echo getUrl('blogs.php?so=adv', 'blog/?so=adv'); ?>"><?php echo $this->LANG['advanced_search']; ?></a> </td>
      </tr>
    </table>
  </form>
</div>
<?php
		}
		public function showUserInfo()
		{
				$userLog = $this->getUserLog($this->CFG['user']['user_id']);
				$userDetails = $this->getUserDetailsFromUsersTable($this->CFG['db']['tbl']['users'], $this->CFG['user']['user_id']);
?>
<div class="clsSideBarSections">
  <div class="clsSideBarContents">
    <!--rounded corners-->
    <div class="lbsidebarsections">
      <div class="rbsidebarsections">
        <div class="bbsidebarsections">
          <div class="blcsidebarsections">
            <div class="brcsidebarsections">
              <div class="tbsidebarsections">
                <div class="tlcsidebarsections">
                  <div class="trcsidebarsections">
                    <div class="clsUserInfo">
                      <?php if (chkUserImageAllowed())
				{ ?>
                      <p id="selImageBorder">
                        <?php displayUserImage($userDetails, 'thumb', false); ?>
                      </p>
                      <?php } ?>
                      <h3><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'myanswers.php', $this->CFG['site']['relative_url'] . 'my/answers/' . $this->CFG['user']['user_id'] . '/', false); ?>"><?php echo stripString(ucwords($this->CFG['user']['name']), 20); ?></a></h3>
                      <p class=""><?php echo $this->LANG['total_points']; ?>: <span class="clsTotalPoints"><?php echo $userLog['total_points']; ?></span></p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!--end of rounded corners-->
  </div>
</div>
<?php
		}
		public function showAskAnswersOption()
		{
				$allowed_pages_array = array('index.php');
				if (displayBlock($allowed_pages_array))
				{
						$this->showIndexAskAnswersOption();
				}
				else
				{
						$this->showOtherAskAnswersOption();
				}
		}
		public function showIndexAskAnswersOption()
		{
?>
<div class="clsAskAnswerBanners">
  <!-- Home page -->
  <div class="clsAskBannerLeft">
    <div class="clsAskBannerRight">
      <div class="clsAskBannerMiddle">
        <div class="clsBannerSection"><div class="clsAskBanner"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'questions.php?view=ask', $this->CFG['site']['relative_url'] . 'answers/ask/', false); ?>">ask banner</a></div>
          <div class="clsAskSection">
            <ul>
             <li class="clsAskAnswerLinks clsAskTextLink"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'questions.php?view=ask', $this->CFG['site']['relative_url'] . 'answers/ask/', false); ?>">Ask Text Questions</a></li>
              <?php if (chkVideoAllowed('question'))
				{ ?>
              <li class="clsAskAnswerLinks clsAskVideoLink"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'questions.php?view=ask', $this->CFG['site']['relative_url'] . 'answers/ask/', false); ?>">Ask Video Questions</a></li>
              <?php } ?>
              <?php if (chkAudioAllowed('question'))
				{ ?>
              <li class="clsAskAnswerLinks clsAskAudioLink"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'questions.php?view=ask', $this->CFG['site']['relative_url'] . 'answers/ask/', false); ?>">Ask Audio Questions</a></li>
              <?php } ?>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="clsAnswerBanner">
    <div class="clsAnswerBannerLeft">
      <div class="clsAnswerBannerRight">
        <div class="clsAnswerBannerMiddle">
         <div class="clsBannerSection"> <div class="clsCommonAnswerBanner"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'questions.php?view=open', $this->CFG['site']['relative_url'] . 'answers/open/', false); ?>">answer banner</a></div>
            <div class="clsAnswerSection">
              <ul>

                <li class="clsAskAnswerLinks clsAnswerTextLink"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'questions.php?view=open', $this->CFG['site']['relative_url'] . 'answers/open/', false); ?>">Answer Text Questions</a></li>
                <?php if (chkVideoAllowed('answer'))
				{ ?>
                <li class="clsAskAnswerLinks clsAnswerVideoLink"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'questions.php?view=open', $this->CFG['site']['relative_url'] . 'answers/open/', false); ?>">Answer Video Questions</a></li>
                <?php } ?>
				<?php if (chkAudioAllowed('answer'))
				{ ?>
                <li class="clsAskAnswerLinks clsAnswerAudioLink"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'questions.php?view=open', $this->CFG['site']['relative_url'] . 'answers/open/', false); ?>">Answer Audio Questions</a></li>
                <?php } ?>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Home page ends -->
</div>
<?php
		}
		public function showOtherAskAnswersOption()
		{
?>
<div class="clsAskAnswerBanners">
  <!-- Other pages -->
  <div class="clsAskSmallBanner">
      <div class="clsAskBannerLeft">
    <div class="clsAskBannerRight">
      <div class="clsAskBannerMiddle">
      <ul>
        <li class="clsAskAnswerLinks clsAskSmallLink"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'questions.php?view=ask', $this->CFG['site']['relative_url'] . 'answers/ask/', false); ?>">Ask</a></li>
      </ul>
    </div>
  </div>
  </div></div>
   <div class="clsAskAnswerSection">
  <div class="clsAnswerBannerLeft">
      <div class="clsAnswerBannerRight">
        <div class="clsAnswerBannerMiddle">
      <ul>
        <li class="clsAskAnswerLinks "><a class="clsAnswerSmallLink" href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'questions.php?view=open', $this->CFG['site']['relative_url'] . 'answers/open/', false); ?>">Answer</a></li>
      </ul>
    </div>
  </div>
  </div></div>
  <!-- Other pages ends -->
</div>
<?php
		}
		public function populateAlphabetPagingList($paging_list_arr)
		{

?>
<div class="clsSideBarSections">
  <div class="clsSideBarContents">
    <!--rounded corners-->
    <div class="lbsidebarsections">
      <div class="rbsidebarsections">
        <div class="bbsidebarsections">
          <div class="blcsidebarsections">
            <div class="brcsidebarsections">
              <div class="tbsidebarsections">
                <div class="tlcsidebarsections">
                  <div class="trcsidebarsections">
                    <div class="clsQuestionlibrary">
                      <h3><?php echo $this->LANG['nav_question_library']; ?></h3>
                      <?php
				foreach ($paging_list_arr as $key => $value)
				{
						$alphaUrl = getUrl($this->CFG['site']['relative_url'] . 'questions.php?view=open&al=' . $key, $this->CFG['site']['relative_url'] . 'answers/open/?al=' . $key, false);
						$clsActiveQuestionLib = '';
						if ($this->fields_arr['al'] == $value) $clsActiveQuestionLib = ' class="clsActiveQuestionLib"';
						elseif ($this->fields_arr['al'] == 1 and $value == '#') $clsActiveQuestionLib = ' class="clsActiveQuestionLib"';
?>
                      <a href="<?php echo $alphaUrl; ?>" <?php echo $clsActiveQuestionLib; ?>><?php echo $value; ?></a>
                      <?php
				}
?>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!--end of rounded corners-->
  </div>
</div>
<?php
		}
		public function populateTopMenu()
		{
				$currentPage = $this->CFG['html']['current_script_name'];
				$cssClassToMainLink = 'clsActiveHeaderMainLink';
				$cssClassToHighlightMainLink = 'clsActiveLink clsHighlightHeaderLink';
				$forums = $blogs = $mail = $login = $logout = $cssClassToMainLink;
				$questions = $cssClassToHighlightMainLink;
				$$currentPage = $cssClassToHighlightMainLink;
				$ans_page_arr = array('forums', 'forumsTopics', 'forumsTopicCreate', 'forumsResponses', 'forumsResponseCreate');
				if (in_array($currentPage, $ans_page_arr))
				{
						$questions = $cssClassToMainLink;
						$forums = $cssClassToHighlightMainLink;
				}
				$ans_page_arr = array('blogs', 'blogCategory', 'blogComment', 'manageBlog');
				if (in_array($currentPage, $ans_page_arr))
				{
						$questions = $cssClassToMainLink;
						$blogs = $cssClassToHighlightMainLink;
				}
				$ans_page_arr = array('mail', 'mailCompose', 'mailRead');
				if (in_array($currentPage, $ans_page_arr))
				{
						$questions = $cssClassToMainLink;
						$mail = $cssClassToHighlightMainLink;
				}
				$ans_page_arr = array('login', 'devLogin');
				if (in_array($currentPage, $ans_page_arr))
				{
						$questions = $cssClassToMainLink;
						$login = $cssClassToHighlightMainLink;
				}
?>
<div id="selMainNavLinks">
  <h2>Navigational Links</h2>
  <ul>
    <li class="answers"><a class="<?php echo $questions; ?>" href="<? echo getUrl($this->CFG['site']['relative_url'] . 'questions.php', $this->CFG['site']['relative_url'] . 'answers/', false); ?>"><?php echo $this->LANG['answers']; ?></a></li>
    <?php if (chkAllowedModule(array('forums')))
				{ ?>
    <li class="forums"><a class="<?php echo $forums; ?>" href="<? echo getUrl($this->CFG['site']['relative_url'] . 'forums.php', $this->CFG['site']['relative_url'] . 'forum/', false); ?>"><?php echo $this->LANG['forums']; ?></a></li>
    <?php } ?>
    <?php if (chkAllowedModule(array('blog')))
				{ ?>
    <li class="blogs"><a class="<?php echo $blogs; ?>" href="<? echo getUrl($this->CFG['site']['relative_url'] . 'blogs.php', $this->CFG['site']['relative_url'] . 'blog/', false); ?>"><?php echo $this->LANG['blogs']; ?></a></li>
    <?php } ?>
    <?php if (chkAllowedModule(array('mail')))
				{ ?>
    <li class="mail"><a class="<?php echo $mail; ?>" href="<? echo getUrl($this->CFG['site']['url'] . 'members/' . $this->CFG['admin']['mail_urls']['inbox']['normal'], $this->CFG['site']['url'] . 'members/' . $this->CFG['admin']['mail_urls']['inbox']['htaccess'], false); ?>"><?php echo $this->LANG['inbox']; ?></a></li>
    <?php } ?>
    <?php if (!$this->isMember())
				{ ?>
    <li class="clsLastHeaderLink login"><a class="<?php echo $login; ?>" href="<? echo getUrl($this->CFG['site']['url'] . 'login.php', $this->CFG['site']['url'] . 'login/', false); ?>"><?php echo $this->LANG['login']; ?></a></li>
    <?php } ?>
    <?php if ($this->isMember())
				{ ?>
    <li class="clsLastHeaderLink logout"><a class="<?php echo $logout; ?>" href="<?php echo getUrl($this->CFG['site']['url'] . 'logout.php', $this->CFG['site']['url'] . 'logout/', false); ?>"><?php echo $this->LANG['logout']; ?></a></li>
    <?php } ?>
  </ul>
</div>
<?php
		}
		public function storeUserStyle($user_style_title)
		{
				$uid = $this->CFG['user']['user_id'];
				if (!$uid) return;
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['users_ans_log'] . ' SET style=' . $this->dbObj->Param($user_style_title) . ' WHERE user_id=' . $this->dbObj->Param($uid);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($user_style_title, $uid));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function getRandVideo()
		{
				if (!chkVideoAllowed('answer')) return;
				$sql = 'SELECT av.video_id FROM ' . $this->CFG['db']['tbl']['ans_video'] . ' AS av' . ' JOIN ' . $this->CFG['db']['tbl']['questions'] . ' AS q ON q.best_ans_id = av.video_id' . ' WHERE av.video_for = \'Answer\' AND video_status=\'Ok\' AND video_encoded_status=\'Yes\'' . ' ORDER BY RAND() LIMIT 0,1';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);

?>
<div class="clsVideoPopup">
  <div class="clsSideBarSections clsSideBarContents">
    <div class="lbsidebarsections">
      <div class="rbsidebarsections">
        <div class="bbsidebarsections">
          <div class="blcsidebarsections">
            <div class="brcsidebarsections">
              <div class="tbsidebarsections">
                <div class="tlcsidebarsections">
                  <div class="trcsidebarsections">
                    <h3><?php echo $this->LANG['best_answers_in_videos']; ?></h3>
                    <?php
				if ($row = $rs->FetchRow())
				{
						$videos_folder = $this->CFG['admin']['ans_videos']['video_folder'];
						$flv_player_url = $this->CFG['site']['url'] . 'files/flash/flv_player/mini_flvplayer.swf';
						$arguments_play = 'pg=smallvideo_' . $row['video_id'];
						$configXmlcode_url = $this->CFG['site']['url'] . 'ansVideoConfigXmlCode.php?';
						echo '<embed src="' . $flv_player_url . '" FlashVars="config=' . $configXmlcode_url . $arguments_play . '" quality="high" allowFullScreen="true" bgcolor="#000000" width="247" height="212" name="flvplayer" align="middle" allowScriptAccess="always" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" wmode="transparent" />';
				}
				else
				{
?>
                    <p><?php echo $this->LANG['no_best_answers_in_videos']; ?></p>
                    <?php
				}
?>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!--end of rounded corners-->
<?php
		}
}
?>
