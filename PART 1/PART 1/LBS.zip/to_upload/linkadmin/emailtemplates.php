<?php include('restrict.php'); include('../settings.php'); require_once('../Connections/apound.php'); ?>
<?php
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = (!get_magic_quotes_gpc()) ? addslashes($theValue) : $theValue;

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form1")) {
  $updateSQL = sprintf("UPDATE confset SET buymailsubject=%s, buymailmessage=%s, bidmailsubject=%s, bidmailmessage=%s, overbid_L_s=%s, overbid_L=%s WHERE indc=%s",
                       GetSQLValueString($_POST['buymailsubject'], "text"),
                       GetSQLValueString($_POST['buymailmessage'], "text"),
                       GetSQLValueString($_POST['bidmailsubject'], "text"),
                       GetSQLValueString($_POST['bidmailmessage'], "text"),
					   GetSQLValueString($_POST['overbid_L_s'], "text"),
					   GetSQLValueString($_POST['overbid_L'], "text"),
					   GetSQLValueString($_POST['indc'], "int"));

  mysql_select_db($database_apound, $apound);
  $Result1 = mysql_query($updateSQL, $apound) or die(mysql_error());

  $updateGoTo = "emailtemplates.php?upd=Y";
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $updateGoTo));
}

mysql_select_db($database_apound, $apound);
$query_UET = "SELECT indc, buymailsubject, buymailmessage, bidmailsubject, bidmailmessage, overbid_L_s, overbid_L, overbid_C_s, overbid_C FROM confset";
$UET = mysql_query($query_UET, $apound) or die(mysql_error());
$row_UET = mysql_fetch_assoc($UET);
$totalRows_UET = mysql_num_rows($UET);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Manage Email Templates - Link Bid Script Admin Panel</title>
<link rel="shortcut icon" href="img/favicon.ico" />
<link rel="stylesheet" type="text/css" href="admin.css" />
<style type="text/css">
<!--
.style84 {font-size: 12px}
-->
</style>
</head>

<body>
<?php include('header_tpl.php'); ?>
<h2>Manage Email Templates</h2>
<table width="770"  border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
  <tr>
    <td width="770"><?php $x = getenv("HTTP_HOST").getenv("REQUEST_URI"); echo("<font color=white>$x</font>"); ?></td>
  </tr>
</table>
<table width="770"  border="0" align="center" cellpadding="3" cellspacing="1" bgcolor="#FFFFFF">
  <tr>
    <td width="760" valign="top">
      <form method="post" name="form1" action="<?php echo $editFormAction; ?>">
        <?php $upd = $_GET[upd]; if($upd == 'Y') { echo("<div align='center'><font color='red'><b>Update ... DONE</b></font></div>"); } else { } ?>
        <table align="center">
          <tr bgcolor="#FFFFCC">
            <td height="24" colspan="2" align="right" nowrap class="style80 style84">Buy Link Email&nbsp;&nbsp;&nbsp; </td>
          </tr>
          <tr valign="baseline">
            <td align="right" valign="middle" nowrap><span class="style67 style82">Mail subject:</span></td>
            <td valign="baseline"><input name="buymailsubject" type="text" class="style70" value="<?php echo $row_UET['buymailsubject']; ?>" size="45"></td>
          </tr>
          <tr valign="baseline">
            <td nowrap align="right" valign="top"><span class="style67 style82">Message:</span></td>
            <td><textarea name="buymailmessage" cols="95" rows="10" class="style70"><?php echo $row_UET['buymailmessage']; ?></textarea>            </td>
          </tr>
          <tr valign="baseline">
            <td nowrap align="right">&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr bgcolor="#FFFFCC">
            <td height="24" colspan="2" align="right" nowrap class="style80 style84">Change Bid Email&nbsp;&nbsp;&nbsp; </td>
          </tr>
          <tr valign="baseline">
            <td align="right" valign="middle" nowrap><span class="style67 style82">Mail Subject:</span></td>
            <td align="left" nowrap><input name="bidmailsubject" type="text" class="style70" value="<?php echo $row_UET['bidmailsubject']; ?>" size="45"></td>
          </tr>
          <tr valign="baseline">
            <td nowrap align="right" valign="top"><span class="style67 style82">Message:</span></td>
            <td><textarea name="bidmailmessage" cols="95" rows="10" class="style70"><?php echo $row_UET['bidmailmessage']; ?></textarea>            </td>
          </tr>
          <tr valign="baseline">
            <td align="right" valign="middle" nowrap>&nbsp;</td>
            <td height="24" align="right" valign="middle"><span class="style80 style84">Over Bid Notification Email&nbsp;&nbsp;&nbsp; </span></td>
          </tr>
          <tr valign="baseline">
            <td nowrap align="right" valign="top"><span class="style67 style82">Mail Subject:</span></td>
            <td><label>
              <input name="overbid_L_s" type="text" class="style70" id="overbid_L_s" value="<?php echo $row_UET['overbid_L_s']; ?>" size="45">
            </label></td>
          </tr>
          <tr valign="baseline">
            <td nowrap align="right" valign="top"><span class="style67 style82">Message:</span></td>
            <td><label>
              <textarea name="overbid_L" cols="95" rows="10" class="style70" id="overbid_L"><?php echo $row_UET['overbid_L']; ?></textarea>
            </label></td>
          </tr>
          <tr valign="baseline">
            <td nowrap align="right">&nbsp;</td>
            <td><input type="submit" class="login-but" value="Update record"></td>
          </tr>
        </table>
        <input type="hidden" name="MM_update" value="form1">
        <input type="hidden" name="indc" value="<?php echo $row_UET['indc']; ?>">
      </form>    </td>
  </tr>
</table>
<?php include('footer_tpl.php'); ?>
</body>
</html>
<?php
mysql_free_result($UET);
?>
