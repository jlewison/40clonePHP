<?php

   class paymentModulesData extends Data {

      var $table = PAYMENT_MODULE_TABLE;

      var $config = array (
  'table' => PAYMENT_MODULE_TABLE,
  'idField' => 'id',
  'addedMsg' => 'Osdate Payment Modules %s Added',
  'added_err' => 'Can\\\'t Add Osdate Payment Modules',
  'editMsg' => 'Osdate Payment Modules %s Updated',
  'editErr' => 'Can\\\'t Update Osdate Payment Modules',
  'delErr' => 'Can\\\'t Delete Osdate Payment Modules',
  'delMsg' => 'Osdate Payment Modules %s Deleted',
  'blankErr' => 'Osdate Payment Modules Empty',
  'fields' => 
  array (
    'name' => 
    array (
      'name' => 'name',
      'description' => 'Name',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 255,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'module_key' => 
    array (
      'name' => 'module_key',
      'description' => 'Module Key',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 255,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'class_file' => 
    array (
      'name' => 'class_file',
      'description' => 'Class File',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 255,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'formfile' => 
    array (
      'name' => 'formfile',
      'description' => 'Formfile',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 255,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'enabled' => 
    array (
      'name' => 'enabled',
      'description' => 'Enabled',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 1,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
  ),
);   

      function paymentModulesData() {
      
         $this->Data($this->config);
      }
   }

?>
