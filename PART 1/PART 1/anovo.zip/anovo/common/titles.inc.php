<?php
global $Site_Name;
if ($title == 'XXXXXXX - More Scripts: MegaUnionWareZ.cOm') $title = 'XXXXXX - More Scripts: MegaUnionWareZ.cOm';
if ($title == 'Site Index - More Scripts: MegaUnionWareZ.cOm') $title = $Site_Name;
else
		if ($Site_Name) $title = $Site_Name . ' - ' . $title;
?>