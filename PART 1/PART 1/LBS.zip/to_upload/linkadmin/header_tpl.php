<div class="main-page">
	<div class="header">
		<div class="logo"><a href="../linkadmin/home.php"><img src="img/lbs-logo.gif" alt="LBS Admin Home"  /></a></div>
		<div class="header-menu">
			<div class="hed-ml">
				<div class="hed-mm"><a href="../linkadmin/home.php" class="style66">Admin Home</a> | <a href="../index.php" target="_blank">Directory Home</a> | <a href="../linkadmin/index.php">Log Out</a></div>
			</div>
		</div>
	</div>
	<div class="main-menu">
		<ul>
			<li><a href="../linkadmin/template_add.php">Add Template</a></li>
			<li><a href="../linkadmin/manage_category.php">Manage Categories</a></li>
			<li><a href="../linkadmin/manage_bid.php">Manage Bids</a></li>
			<li><a href="../linkadmin/manage_link.php">Manage Listings</a></li>
			<li><a href="../linkadmin/setup.php">Configuration</a></li>
			<li><a href="../linkadmin/home.php">Main Page</a></li>
		</ul>
	</div>
	<div class="main-content">