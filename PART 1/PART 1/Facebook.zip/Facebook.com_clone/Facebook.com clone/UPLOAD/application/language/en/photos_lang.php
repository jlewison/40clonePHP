<?php

	$lang['page_title']								= 'Photos';
	$lang['photos_del_success_msg']					= 'Photo has been deleted.';
	$lang['photos_album_del_success_msg']			= 'Album has been deleted successfully.';
	$lang['photos_album_del_error_msg']				= 'Album has not been deleted.';
	$lang['photos_edit_album_info_success']			= 'Album information has been successfully saved.';
	$lang['photos_edit_album_info_error']			= 'Album information has not been saved.';
	$lang['photos_create_album_info_error']			= 'Error in creating the album. Try again.';

	$lang['photos_label_album_name']				= 'Album Name';
	//photosalbumcreate.tpl
	$lang['photos_label_add_new_photos']			= 'Add New Photos';
	$lang['photos_label_create_album']				= 'Create Album';
	$lang['photos_label_album_info']				= 'Album Information';
	$lang['photos_label_upload_photo']				= 'Upload Photo';
	$lang['photos_label_name']						= 'Name';
	$lang['photos_label_location']					= 'Location';
	$lang['photos_label_description']				= 'Description';
	$lang['photos_label_visible_to']				= 'Visible to';
	//photosalbumuploadphoto.tpl
	$lang['photos_label_upload_photos_to_album']	= 'Upload photos to album';
	$lang['photos_file_upload_error']				= 'Some of the files are not uploaded successfully during the last upload';
	$lang['photos_label_the_files_are']				= 'The files are';
	$lang['photos_label_for_the_file']				= 'For the file';
	$lang['photos_label_remove']					= 'Remove';
	//photoseditalbum.tpl
	$lang['photos_label_edit_album']				= 'Edit Album';
	$lang['photos_label_edit_info']					= 'Edit Information';
	$lang['photos_label_edit_photos']				= 'Edit Photos';
	$lang['photos_label_remove']					= 'Remove';
	//photoseditalbumphotos.tpl
	$lang['photos_label_delete_album']				= 'Delete Album';
	$lang['photos_delete_album_confirm_msg']		= 'Do you really want to delete this album';
	$lang['photos_label_back_to_myphotos']			= 'Back to My Photos';
	$lang['photos_label_add_more']					= 'Add More';
	$lang['photos_label_delete']					= 'Delete';
	$lang['photos_label_album_cover']				= 'This is the album cover';
	$lang['photos_label_delete_this_photo']			= 'Delete this photo';
	$lang['photos_label_caption']					= 'Caption';
	//photosfriendsalbum.tpl
	$lang['photos_label_my_photos']					= 'My Photos';
	$lang['photos_label_photos']					= 'Photos';
	$lang['photos_label_recent_photo_albums']		= 'Recent Photo Albums';
	$lang['photos_label_no_friends_album']			= 'Your friends not yet created any albums';
	$lang['photos_label_displaying']				= 'Displaying';
	$lang['photos_label_friends']					= 'friends';
	$lang['photos_label_out_of']					= 'out of';
	$lang['photos_label_recent_albums']				= 'recent albums';
	$lang['photos_label_by']						= 'by';
	//photosmyphotoalbums.tpl
	$lang['photos_label_my']						= 'My';
	$lang['photos_label_profile']					= 'Profile';
	$lang['photos_label_send_message']				= 'Send Message';
	$lang['photos_label_create_photo_album']		= 'Create a Photo Album';
	$lang['photos_label_no_albums']					= 'You are not yet created any albums';
	$lang['photos_label_albums']					= 'albums';
	$lang['photos_label_created']					= 'Created';
	//photosslideshow.tpl
	$lang['photos_label_delete_album_photo']		= 'Delete Album Photo';
	$lang['photos_delete_photo_confirm_msg']		= 'Do you really want to delete this photo';
	$lang['photos_label_upload_more_photos']		= 'Upload more photos';
	$lang['photos_label_previous']					= 'Previous';
	$lang['photos_label_next']						= 'Next';
	$lang['photos_label_photo_title']				= 'Photo Title';
	$lang['photos_label_delete_photo']				= 'Delete Photo';

	$lang['photos_label_see_all']					= 'See All';
	$lang['photos_label_wrote']						= 'wrote';
	$lang['photos_label_at']						= 'at';
	$lang['photos_label_delete_post']				= 'Delete';
	$lang['photos_label_posts']						= 'posts';
	$lang['photos_label_write_on']					= 'Write on';
	$lang['photos_label_wall']						= 'Wall';
	$lang['photos_label_back_to']					= 'Back to';
	$lang['photos_label_location']					= 'Location';
	$lang['photos_label_album']						= 'Album';
	$lang['photos_label_no_photos_available']		= 'No photos available';
	$lang['photos_label_required']					= 'Required';
	$lang['photos_maximum_album_reached_err']		= 'You have reached maximum albums per user';
	$lang['photos_maximum_photos_reached_err']		= 'You have reached maximum photos per album';
	$lang['photos_eligible_photos_reached_err']		= 'You are eligible to upload';

?>