<?php
require_once ('./common/configs/config_encoder.inc.php');
if ($_GET['fname'])
{
		$file_name = $CFG['admin']['video']['red5_flv_path'] . $_GET['fname'] . '.flv';
		if (is_file($file_name))
		{
				unlink($file_name);
		}
}
?>