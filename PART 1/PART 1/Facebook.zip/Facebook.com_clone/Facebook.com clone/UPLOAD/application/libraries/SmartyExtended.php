<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
* Extending the smarty class to make it usable with CodeIgniter
*
*
* @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
* @license
* @since 2007-12-10
*/

define('SMARTY_DIR', APPPATH . 'libraries/smartyCore/'); 
require(SMARTY_DIR . 'Smarty.class.php');

class SmartyExtended extends Smarty 
{
	
	var $CI;
	var $lang_code;
	
	//Constructor
	function SmartyExtended() 
	{
		$this->CI			=& get_instance();
		
		//Change the Language
		if($this->CI->session->userdata('app_language') != FALSE)
			$this->CI->config->set_item('language_code', $this->CI->session->userdata('app_language'));
		
		//Load the settings model
		$this->CI->load->model('settingsmodel');
		//Load the application model
		$this->CI->load->model('applicationmodel');
		//Load the report model
		$this->CI->load->model('reportmodel');
		//Load  the footer model
		$this->CI->load->model('footermodel');
		
		//Load the language file
		$this->CI->lang->load('libraries/smarty', $this->CI->config->item('language_code'));
		
		//Load the application language file
		$this->CI->lang->load('application', $this->CI->config->item('language_code'));
		
		//Create the cache dir if not exists & set the permission
		if (!file_exists(APPPATH . 'libraries/smartyCore/cache'))
		{
			mkdir(APPPATH . 'libraries/smartyCore/cache', 0777);
		}
		@chmod(APPPATH . 'libraries/smartyCore/cache', 0777);
		
		//Create the cache dir if not exists & set the permission
		if (!file_exists(APPPATH . 'libraries/smartyCore/configs'))
		{
			mkdir(APPPATH . 'libraries/smartyCore/configs', 0777);
		}
		@chmod(APPPATH . 'libraries/smartyCore/cache', 0777);
		
		//Create the cache dir if not exists & set the permission
		if (!file_exists(APPPATH . 'libraries/smartyCore/templates_c'))
		{
			mkdir(APPPATH . 'libraries/smartyCore/templates_c', 0777);
		}
		@chmod(APPPATH . 'libraries/smartyCore/cache', 0777);
		
		$this->template_dir = APPPATH . 'views/' . $this->CI->config->item('layout') . '/';
        $this->compile_dir  = APPPATH . 'libraries/smartyCore/templates_c/';
        $this->config_dir   = APPPATH . 'libraries/smartyCore/configs/';
        $this->cache_dir    = APPPATH . 'libraries/smartyCore/cache/';
		
		$this->caching 			= TRUE; 
		$this->force_compile	= TRUE;
		$this->compile_check	= TRUE;
		
		//The following are the variables that are used throught the site
		$this->assign_by_ref('lang', $this->CI->lang);
		$this->assign_by_ref('session', $this->CI->session);
		$this->assign('base_url', base_url());
		$this->assign('app_url', base_url() . 'application/');
		$this->assign('language', $this->CI->config->item('language_code'));
		$this->assign('avatar_thumb_width', $this->CI->config->item('avatar_thumb_width'));
		$this->assign('avatar_thumb_height', $this->CI->config->item('avatar_thumb_height'));
		$this->assign('app_languages', $this->CI->applicationmodel->getLanguages());
		$this->assign('reportType', $this->CI->reportmodel->getReportType());
		$this->assign('footerLinks', $this->CI->footermodel->getFooters());
		$this->assign('curr_uri_string', $this->CI->uri->uri_string());
				
		if(isLoggedIn())
		{
			$this->_initApplication();
		}
		
		log_message('debug', "SmartyExtended Class Initialized");
    }
	
	//Display the template
	function view($template, $data='', $show = FALSE) 
	{		
		if(is_array($data))
		{
			foreach($data as $key=>$val)
			{
				$this->assign($key, $val);
			}
		}
		
		if(file_exists($this->template_dir . $template . '.tpl'))
		{
			if($show == FALSE)
				$this->display($template . '.tpl');
			else
			{
				//Start the output buffer
				ob_start();
				//display the template. so the that its content will be caught in the output buffer
				$this->display($template . '.tpl');
				//Catch the output buffer
				$content = ob_get_contents();
				//clean the buffer
				ob_end_clean();
				
				return $content;
			}
		}
		else
			show_error(sprintf($this->CI->lang->line('load_template_error'), 'views/' . $this->CI->config->item('layout') . '/' . $template . '.tpl'));
	}
	
	//Do Some application initialization 
	function _initApplication()
	{
		$settings	= $this->CI->settingsmodel->readAllSetting();	
		$userApps	= $this->CI->applicationmodel->getUserApplications();
		$isApp		= $this->CI->applicationmodel->isApplication(strtolower($this->CI->uri->segment(1)));
		
		$canAccess	= TRUE;	
		if($isApp && $this->CI->applicationmodel->isUserCanAccessTheApplication($isApp) == FALSE)
			$canAccess	= FALSE;
		
		if($canAccess)
		{
			$this->assign('userApplications', $userApps);	//Used in left.tpl
			
			//settings			
			$this->assign('settings', $settings);
			$this->assign('sitename', $settings['site_name']);
			$this->assign('sitetitle', $settings['site_title']);
			
			//The following are the variables that are used throught the site
			$this->assign('user_id', $this->CI->session->userdata('user_id'));
			$this->assign('curr_page', strtolower($this->CI->uri->segment(1)));
		}
		else
		{
			redirect('welcome');
		}
	}
}
?>