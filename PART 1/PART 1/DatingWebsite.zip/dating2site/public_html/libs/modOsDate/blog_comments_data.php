<?php

   class blog_commentsData extends Data {

      var $table = BLOG_COMMENTS_TABLE;

      var $config = array (
  'table' => BLOG_COMMENTS_TABLE,
  'idField' => 'osdate_blog_comments_id',
  'addedMsg' => 'Osdate Blog Comments %s Added',
  'added_err' => 'Can\\\'t Add Osdate Blog Comments',
  'editMsg' => 'Osdate Blog Comments %s Updated',
  'editErr' => 'Can\\\'t Update Osdate Blog Comments',
  'delErr' => 'Can\\\'t Delete Osdate Blog Comments',
  'delMsg' => 'Osdate Blog Comments %s Deleted',
  'blankErr' => 'Osdate Blog Comments Empty',
  'fields' => 
  array (
    'id' => 
    array (
      'name' => 'id',
      'description' => 'Id',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'userid' => 
    array (
      'name' => 'userid',
      'description' => 'Userid',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 1,
      'duplicate_ok' => 1,
    ),
    'adminid' => 
    array (
      'name' => 'adminid',
      'description' => 'Adminid',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 1,
      'duplicate_ok' => 1,
    ),
    'blogid' => 
    array (
      'name' => 'blogid',
      'description' => 'Blogid',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'datetime' => 
    array (
      'name' => 'datetime',
      'description' => 'Datetime',
      'type' => 'datetime',
      'min_len' => 0,
      'max_len' => 19,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'comment' => 
    array (
      'name' => 'comment',
      'description' => 'Comment',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 16777215,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
  ),
);   

      function blog_commentsData() {
      
         $this->Data($this->config);
      }
   }

?>
