<?php /* Smarty version 2.6.6, created on 2006-03-11 11:56:41
         compiled from admin/admin_server.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'cycle', 'admin/admin_server.tpl', 58, false),)), $this); ?>


<head>
<?php echo '
<style>
a{
        text-decoration: none;
        color: #191970;
}
</style>
</head>
'; ?>

<table border="0" width="100%" height="62" cellspacing="0" cellpadding="0">
  <tr>
    <td width="104%" colspan="5" height="31">
      <p align="left">&nbsp;</p>
    </td>
  </tr>
  <tr bgcolor="#DDDDDD">
    <td width="15%" height=30>
      <p align="left"><font color="#003366" size="2" face="Verdana"><b>&nbsp;
      <a href="admin_server.php?sort=name" title="Sort">Name</a>
      </b></font></p>
    </td>
    <td width="15%">
      <p align="left"><font color="#003366" size="2" face="Verdana">
      <b>User</b>
      </font></p>
    </td>
    <td width="15%">
      <p align="left"><font color="#003366" size="2" face="Verdana">
      <b>Password</b>
      </font></p>
    </td>
    <td width="12%">
      <p align="left"><font color="#003366" size="2" face="Verdana">
      <b>UpDir</b>
      </font></p>
    </td>
    <td width="12%">
      <p align="left"><font color="#003366" size="2" face="Verdana">
      <a href="admin_server.php?sort=used" title="Sort"><b>Size</b></a>
      </font></p>
    </td>

    <td width="13%">
      <p align="left"><font color="#003366" size="2" face="Verdana">
      <a href="admin_server.php?sort=used" title="Sort"><b>Used</b></a>
      </font></p>
    </td>
    <td width="20%">
      <p align="left"><font color="#003366" size="2" face="Verdana"><b>Action</b></font></p>
    </td>
  </tr>
  <tr><td colspan=7 width=1 bgcolor="#BBBBBB"> </td> </tr>
<!---------------------------------------------------------------------------->  
<?php unset($this->_sections['i']);
$this->_sections['i']['name'] = 'i';
$this->_sections['i']['loop'] = is_array($_loop=$this->_tpl_vars['server']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['i']['show'] = true;
$this->_sections['i']['max'] = $this->_sections['i']['loop'];
$this->_sections['i']['step'] = 1;
$this->_sections['i']['start'] = $this->_sections['i']['step'] > 0 ? 0 : $this->_sections['i']['loop']-1;
if ($this->_sections['i']['show']) {
    $this->_sections['i']['total'] = $this->_sections['i']['loop'];
    if ($this->_sections['i']['total'] == 0)
        $this->_sections['i']['show'] = false;
} else
    $this->_sections['i']['total'] = 0;
if ($this->_sections['i']['show']):

            for ($this->_sections['i']['index'] = $this->_sections['i']['start'], $this->_sections['i']['iteration'] = 1;
                 $this->_sections['i']['iteration'] <= $this->_sections['i']['total'];
                 $this->_sections['i']['index'] += $this->_sections['i']['step'], $this->_sections['i']['iteration']++):
$this->_sections['i']['rownum'] = $this->_sections['i']['iteration'];
$this->_sections['i']['index_prev'] = $this->_sections['i']['index'] - $this->_sections['i']['step'];
$this->_sections['i']['index_next'] = $this->_sections['i']['index'] + $this->_sections['i']['step'];
$this->_sections['i']['first']      = ($this->_sections['i']['iteration'] == 1);
$this->_sections['i']['last']       = ($this->_sections['i']['iteration'] == $this->_sections['i']['total']);
?>
  <tr bgcolor=<?php echo smarty_function_cycle(array('values' => "#EFEFEF,#DFDFDF"), $this);?>
>
    <td width="15%" valign=middle>
      <p align="left"><font face="Verdana" size="2">&nbsp;<font color="#3366CC"><?php echo $this->_tpl_vars['server'][$this->_sections['i']['index']]['name']; ?>
</font></font></p>
    </td>
    <td width="15%" valign=middle>
      <p align="left"><font color="#3366CC" face="Verdana" size="2"><?php echo $this->_tpl_vars['server'][$this->_sections['i']['index']]['uname']; ?>
</font></p>
    </td>
    <td width="15%" valign=middle>
      <p align="left"><font color="#3366CC" face="Verdana" size="2"><?php echo $this->_tpl_vars['server'][$this->_sections['i']['index']]['upass']; ?>
</font></p>
    </td>
    <td width="15%" valign=middle>
      <p align="left"><font color="#3366CC" face="Verdana" size="2"><?php echo $this->_tpl_vars['server'][$this->_sections['i']['index']]['updir']; ?>
</font></p>
    </td>
    <td width="12%" valign=middle>
      <p align="left"><font color="#3366CC" face="Verdana" size="2"><?php echo $this->_tpl_vars['server'][$this->_sections['i']['index']]['size']; ?>
</font></p>
    </td>    
    <td width="13%" valign=middle>
      <p align="left"><font color="#3366CC" face="Verdana" size="2"><?php echo $this->_tpl_vars['server'][$this->_sections['i']['index']]['used']; ?>
</font></p>
    </td>
    <!--------------------------------------------------->
    <td width="15%"  valign=middle>
    <font face="Verdana" size="2">         
    <a href="admin_server.php?action=del&srvrid=<?php echo $this->_tpl_vars['server'][$this->_sections['i']['index']]['id']; ?>
" style="text-decoration: none">Delete</a>|<a href="admin_index.php?change=Server&action=edit&srvrid=<?php echo $this->_tpl_vars['server'][$this->_sections['i']['index']]['id']; ?>
&n=<?php echo $this->_tpl_vars['server'][$this->_sections['i']['index']]['name']; ?>
&s=<?php echo $this->_tpl_vars['server'][$this->_sections['i']['index']]['size']; ?>
&u=<?php echo $this->_tpl_vars['server'][$this->_sections['i']['index']]['uname']; ?>
&d=<?php echo $this->_tpl_vars['server'][$this->_sections['i']['index']]['updir']; ?>
" style="text-decoration: none">Edit</a>
    </font>
    </td>
   <!--------------------------------------------------->       
  </tr>
  <tr><td colspan=7 width=1 bgcolor="#BBBBBB"> </td> </tr>
<?php endfor; endif; ?>  
<!---------------------------------------------------------------------------->    
</table>
<p align="center">
<form method="POST" action="admin_server.php">
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse; font-family:Verdana; font-size:10pt" bordercolor="#111111" width="300" height="104">
                    <tr>
                      <td width="300" align="right" height="16" colspan="3">
                      <p align="left"><font color="#3366CC"><u><b>
                      <?php $this->assign('act1', 'Add New '); ?>
                      <?php if ($_REQUEST['action'] == 'edit'): ?>
                      <?php $this->assign('act1', 'Update '); ?>
                      <?php endif; ?> <?php echo $this->_tpl_vars['act1']; ?>

                      Server&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                      </b></u></font></td>
                    </tr>
                    <tr>
                      <td width="118" align="right" height="29">Name</td>
                      <td width="9" align="left" height="29">&nbsp;</td>
                      <td width="173" align="left" height="29">
                      <input type="text" name="n" size="20" style="font-family: Verdana; font-size: 8pt" value="<?php echo $_REQUEST['n']; ?>
"></td>
                    </tr>
                    <tr>
                      <td width="118" align="right" height="29">User</td>
                      <td width="9" align="left" height="29">&nbsp;</td>
                      <td width="173" align="left" height="29">
                      <input type="text" name="u" size="20" style="font-family: Verdana; font-size: 8pt" value="<?php echo $_REQUEST['u']; ?>
"></td>
                    </tr>
                    <tr>
                      <td width="118" align="right" height="29">Password</td>
                      <td width="9" align="left" height="29">&nbsp;</td>
                      <td width="173" align="left" height="29">
                      <input type="text" name="p" size="20" style="font-family: Verdana; font-size: 8pt" value="<?php echo $_REQUEST['p']; ?>
"></td>
                    </tr>
                    <tr>
                      <td width="118" align="right" height="29">Upload Dir</td>
                      <td width="9" align="left" height="29">&nbsp;</td>
                      <td width="173" align="left" height="29">
                      <input type="text" name="d" size="20" style="font-family: Verdana; font-size: 8pt" value="<?php echo $_REQUEST['d']; ?>
"></td>
                    </tr>
                    <tr>
                      <td width="118" align="right" height="30">Size</td>
                      <td width="9" align="left" height="30">&nbsp;</td>
                      <td width="173" align="left" height="30">
                      <input type="text" name="s" size="9" style="font-family: Verdana; font-size: 8pt" value="<?php echo $_REQUEST['s']; ?>
">
                      GB</td>
                    </tr>
                    <tr>
                      <td width="118" align="right" height="29">&nbsp;</td>
                      <td width="9" align="left" height="29">&nbsp;</td>
                      <td width="173" align="left" height="29">
                      <input type="hidden" name="srvrid" value="<?php echo $_REQUEST['srvrid']; ?>
">
                      <?php $this->assign('act', 'Include'); ?>
                      <?php if ($_REQUEST['action'] == 'edit'): ?>
                      <?php $this->assign('act', 'Update'); ?>
                      <?php endif; ?>
                      <input type="submit" value="<?php echo $this->_tpl_vars['act']; ?>
" name="action" style="font-family: Verdana; font-size: 10pt"></td>
                    </tr>
</table>
</form>