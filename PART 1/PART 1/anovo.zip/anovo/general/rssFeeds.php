<?php
class RssFeedsFormHandler extends FormHandler
{
		public function generateLinks($rss_url, $title, $yahoo_ext_text, $img_rss, $img_yhoo, $img_goog, $img_blog)
		{
?>
				<tr>
					<th><div class="blctitle">
                <div class="brctitle">
                  <div class="tlctitle">
                    <div class="trctitle"><?php echo $title; ?></div>
                  </div>
                </div>
              </div></th>
					<td>
						<a target="_blank" href="<?php echo $rss_url; ?>"><img src="<?php echo $img_rss; ?>" alt="Rss feed" border="0" /></a></td>
						<td><a target="_blank" href="http://us.rd.yahoo.com/my/atm/<?php echo $this->CFG['site']['title']; ?>/<?php echo $yahoo_ext_text; ?>/*http://add.my.yahoo.com/rss?url=<?php echo str_replace(':', '%3A', $rss_url); ?>"><img src="<?php echo $img_yhoo; ?>" width="91"  border="0" alt="Add to My Yahoo!"></a></td>
						<td><a target="_blank" href="http://fusion.google.com/add?feedurl=<?php echo str_replace(':', '%3A', $rss_url); ?>"><img src="<?php echo $img_goog; ?>" alt="Add to Google" border="0" height="17" width="104"></a></td>
						<td><a target="_blank" href="http://www.bloglines.com/sub/<?php echo $rss_url; ?>"><img src="<?php echo $img_blog; ?>" border="0" alt="Subscribe with Bloglines" /></a></td>
					
				</tr>
<?php
		}
}


$rssfeedsfrm = new RssFeedsFormHandler();
$rssfeedsfrm->setCfgLangGlobal($CFG, $LANG);
?>

<div id="selRssFeeds">
  	<h2><?php echo $LANG['feed_title']; ?></h2>
  	<div class="clsRssFeeds">
      	<table cellspacing="0" summary="<?php echo $LANG['feed_tbl']; ?>">
<?php
$rssfeedsfrm->generateLinks(getUrl($CFG['site']['url'] . 'rss.php?act=recentquestions', $CFG['site']['url'] . 'feed/recentquestions/', false), $LANG['feed_recent_questions'], 'recentquestions', $CFG['site']['url'] . 'images/rss.gif', $CFG['site']['url'] . 'images/myyhoo.gif', $CFG['site']['url'] . 'images/mygoog.gif', $CFG['site']['url'] . 'images/myblogline.gif');
$rssfeedsfrm->generateLinks(getUrl($CFG['site']['url'] . 'rss.php?act=popularquestions', $CFG['site']['url'] . 'feed/popularquestions/', false), $LANG['feed_popular_questions'], 'popularquestions', $CFG['site']['url'] . 'images/rss.gif', $CFG['site']['url'] . 'images/myyhoo.gif', $CFG['site']['url'] . 'images/mygoog.gif', $CFG['site']['url'] . 'images/myblogline.gif');
$rssfeedsfrm->generateLinks(getUrl($CFG['site']['url'] . 'rss.php?act=recentforums', $CFG['site']['url'] . 'feed/recentforums/', false), $LANG['feed_recent_forums'], 'recentforums', $CFG['site']['url'] . 'images/rss.gif', $CFG['site']['url'] . 'images/myyhoo.gif', $CFG['site']['url'] . 'images/mygoog.gif', $CFG['site']['url'] . 'images/myblogline.gif');
$rssfeedsfrm->generateLinks(getUrl($CFG['site']['url'] . 'rss.php?act=recentblogs', $CFG['site']['url'] . 'feed/recentblogs/', false), $LANG['feed_recent_blogs'], 'recentblogs', $CFG['site']['url'] . 'images/rss.gif', $CFG['site']['url'] . 'images/myyhoo.gif', $CFG['site']['url'] . 'images/mygoog.gif', $CFG['site']['url'] . 'images/myblogline.gif');
?>
      	</table>
 	</div>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>
