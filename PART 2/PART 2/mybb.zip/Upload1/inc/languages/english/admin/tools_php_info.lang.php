<?php
/**
 * MyBB 1.4 English Language Pack
 * Copyright � 2008 MyBB Group, All Rights Reserved
 * 
 * $Id: tools_php_info.lang.php 4304 2009-01-02 01:11:56Z chris $
 */

$l['php_info'] = "PHP Info";
$l['browser_no_iframe_support'] = "Your browser does not support iFrames.";

?>