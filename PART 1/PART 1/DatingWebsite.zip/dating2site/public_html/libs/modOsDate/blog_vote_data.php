<?php

   class blog_voteData extends Data {

      var $table = BLOG_VOTE_TABLE;

      var $config = array (
  'table' => BLOG_VOTE_TABLE,
  'idField' => 'osdate_blog_vote_id',
  'addedMsg' => 'Osdate Blog Vote %s Added',
  'added_err' => 'Can\\\'t Add Osdate Blog Vote',
  'editMsg' => 'Osdate Blog Vote %s Updated',
  'editErr' => 'Can\\\'t Update Osdate Blog Vote',
  'delErr' => 'Can\\\'t Delete Osdate Blog Vote',
  'delMsg' => 'Osdate Blog Vote %s Deleted',
  'blankErr' => 'Osdate Blog Vote Empty',
  'fields' => 
  array (
    'id' => 
    array (
      'name' => 'id',
      'description' => 'Id',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'storyid' => 
    array (
      'name' => 'storyid',
      'description' => 'Storyid',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'userid' => 
    array (
      'name' => 'userid',
      'description' => 'Userid',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'adminid' => 
    array (
      'name' => 'adminid',
      'description' => 'Adminid',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'vote' => 
    array (
      'name' => 'vote',
      'description' => 'Vote',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
  ),
);   

      function blog_voteData() {
      
         $this->Data($this->config);
      }
   }

?>
