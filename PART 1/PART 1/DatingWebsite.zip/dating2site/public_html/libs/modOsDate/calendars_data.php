<?php

   class calendarsData extends Data {

      var $table = CALENDARS_TABLE;

      var $config = array (
  'table' => CALENDARS_TABLE,
  'idField' => 'id',
  'addedMsg' => 'Osdate Calendars %s Added',
  'added_err' => 'Can\\\'t Add Osdate Calendars',
  'editMsg' => 'Osdate Calendars %s Updated',
  'editErr' => 'Can\\\'t Update Osdate Calendars',
  'delErr' => 'Can\\\'t Delete Osdate Calendars',
  'delMsg' => 'Osdate Calendars %s Deleted',
  'blankErr' => 'Osdate Calendars Empty',
  'fields' => 
  array (
    'calendar' => 
    array (
      'name' => 'calendar',
      'description' => 'Calendar',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 255,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'displayorder' => 
    array (
      'name' => 'displayorder',
      'description' => 'Displayorder',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 2,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'enabled' => 
    array (
      'name' => 'enabled',
      'description' => 'Enabled',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 1,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
  ),
);   

      function calendarsData() {
      
         $this->Data($this->config);
      }
   }

?>
