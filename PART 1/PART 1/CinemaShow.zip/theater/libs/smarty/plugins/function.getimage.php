<?php
function smarty_function_getimage($params, &$smarty) {
	if (preg_match('/\.jpg$/i',$params['href'])) {
		echo $params['href'];
	} else {
		echo '/content/images/no_poster.gif';
	}
}