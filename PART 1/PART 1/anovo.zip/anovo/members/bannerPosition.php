<div id="selPhotoPreviewFrm">  
	<p id="selPreviewImage"><img src="../images/preview.jpg" /></p>
</div> 