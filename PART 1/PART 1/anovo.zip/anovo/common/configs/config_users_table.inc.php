<?php
$CFG['db']['tbl']['users'] = 'users';
$CFG['users']['user_id'] = 'user_id';
$CFG['users']['name'] = 'name';
$CFG['users']['bio'] = 'bio';
$CFG['users']['gender'] = 'sex';
$CFG['users']['email'] = 'email';
$CFG['users']['usr_status'] = 'usr_status';
$CFG['users']['user_access'] = 'user_access';
$CFG['users']['image_path'] = 'img_path';
$CFG['users']['t_width'] = 't_width';
$CFG['users']['t_height'] = 't_height';
$CFG['users']['s_width'] = 's_width';
$CFG['users']['s_height'] = 's_height';
$CFG['users']['l_width'] = 'l_width';
$CFG['users']['l_height'] = 'l_height';
$CFG['users']['photo_server_url'] = 'photo_server_url';
$CFG['users']['photo_ext'] = 'photo_ext';
$CFG['users']['dob'] = 'dob';
$CFG['users']['doj'] = 'doj';
$CFG['users']['ip'] = 'ip';
$CFG['users']['session'] = 'session';
$CFG['users']['password'] = 'password';
$CFG['users']['last_logged'] = 'last_logged';
$CFG['users']['time_zone'] = 'time_zone';
$CFG['users']['pref_lang'] = 'pref_lang';
$CFG['users']['num_visits'] = 'num_visits';
if ($CFG['debug']['debug_standalone_modules'])
{
		echo '<pre>' . "\n";
		print_r($GLOBALS);
		echo '</pre>' . "\n";
}
?>