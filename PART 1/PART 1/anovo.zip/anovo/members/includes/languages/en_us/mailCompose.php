<?php
$LANG['mailcompose_title'] = 'Compose Mail';
$LANG['mailcompose_success_mail'] = 'Mail sent sucessfully';
$LANG['mailcompose_to'] = 'To';
$LANG['mailcompose_recent_send'] = '-- Recent Sent --';
$LANG['mailcompose_my_friends'] = '-- Your Friends --';
$LANG['mailcompose_my_relations'] = '-- Your Relations --';
$LANG['mailcompose_select'] = 'Select Username';
$LANG['mailcompose_subject'] = 'Subject';
$LANG['mailcompose_message'] = 'Message';
$LANG['mailcompose_include_message'] = 'Include Original message';
$LANG['mailcompose_include_message_yes'] = 'Yes';
$LANG['mailcompose_include_message_no'] = 'No';
$LANG['mailcompose_err_sorry'] = 'Sorry, errors detected!';
$LANG['mailcompose_err_tip_cannot_create_dir'] = 'Cannot create dir. Try again.';
$LANG['mailcompose_err_tip_uploading_problem'] = 'File not attached properly. Try again';
$LANG['mailcompose_err_tip_update_upload_problem'] = 'File not updated properly. Try again';
$LANG['mailcompose_err_tip_compulsory'] = 'Compulsory';
$LANG['mailcompose_err_tip_mail_not_sent'] = 'Mail not sent. Try again';
$LANG['mailcompose_err_tip_username_not_exceeds'] = '{friend} is not a valid username';
$LANG['mailcompose_err_tip_username_not_allowed_to_send_mail'] = '{friend} is not like to receive internal messages';
$LANG['mailcompose_err_tip_username_blocked'] = '{friend} has blocked you to send message to him/her.';
$LANG['mailcompose_err_tip_relation_no_contacts'] = 'No contacts found in {relation} relation';
$LANG['mailcompose_err_tip_invalid_relation'] = '{relation} is not a valid relation.';
$LANG['mailcompose_select_contacts'] = '-- Select Contacts --';
$LANG['mailcompose_recent_contacts'] = '-- Recent Contacts --';
$LANG['mailcompose_go_to'] = 'After sending mail go to ';
$LANG['mailcompose_goto_inbox'] = 'Inbox';
$LANG['mailcompose_goto_sent'] = 'Sent';
$LANG['mailcompose_goto_compose'] = 'Compose';
$LANG['mailcompose_send'] = 'Send Mail';
$LANG['mailcompose_notify'] = 'Notify me when recipient opens this message';
$LANG['mailcompose_original_message'] = '---------Original Message ---------';
$LANG['mailcompose_from'] = 'From';
$LANG['mailcompose_sent'] = 'Sent';
$LANG['mailcompose_reply_subject'] = 'RE: ';
$LANG['mailcompose_forward_subject'] = 'FWD: ';
$LANG['mailcompose_profile_message'] = 'Check this link:

{profile_link}
';
$LANG['mailcompose_tbl_summary'] = 'Container to accept mail and from address';
$LANG['mailcompose_tbl_adderss_summary'] = 'Container to show members names';
?>
