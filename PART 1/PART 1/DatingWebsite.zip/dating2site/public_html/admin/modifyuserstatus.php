<?php

include ('../init.php');

$statuses = $db->getAll('select distinct descr, subkey from ! where mainkey =  ?',array(LANGUAGE_TABLE, 'status_disp') );

$stat = array();

foreach ($statuses as $stat) {

	$db->query('update ! set status = ? where status = ?', array(USER_TABLE, $stat['subkey'], $stat['descr']) );

}

echo(" User Status updation is completed.. <br />");

exit;
?>