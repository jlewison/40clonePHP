<?
//$_SERVER['HTTP_RANGE']="1024";
print($_SERVER['HTTP_RANGE']);
?>
