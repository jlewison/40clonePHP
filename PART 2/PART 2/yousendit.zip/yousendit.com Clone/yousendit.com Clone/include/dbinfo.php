<?php
$db['host']     = 'db204.perfora.net';   //Your database host, I.E. localhost
$db['username'] = 'dbo130214200';        //Your database username
$db['password'] = 'f9nXwKQg';            //Your database password
$db['db']       = 'db130214200';   //Your database name
$db['prefix']   = '';            //Your table prefix, can be left blank
?>
