<?php
include_once(MODOSDATE_DIR . 'data.php');

   class pluginData extends Data {

      var $table = PLUGIN_TABLE;

      var $config = array (
  'table' => PLUGIN_TABLE,
  'idField' => 'id',
  'addedMsg' => 'Osdate Plugin %s Added',
  'added_err' => 'Can\\\'t Add Osdate Plugin',
  'editMsg' => 'Osdate Plugin %s Updated',
  'editErr' => 'Can\\\'t Update Osdate Plugin',
  'delErr' => 'Can\\\'t Delete Osdate Plugin',
  'delMsg' => 'Osdate Plugin %s Deleted',
  'blankErr' => 'Osdate Plugin Empty',
  'fields' =>
  array (
    'name' =>
    array (
      'name' => 'name',
      'description' => 'Name',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 255,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'active' =>
    array (
      'name' => 'active',
      'description' => 'Active',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 4,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
  ),
);

      function pluginData() {

         $this->Data($this->config);
      }
   }

?>
