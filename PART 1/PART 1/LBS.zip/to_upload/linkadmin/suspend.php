<?php
include('restrict.php');
include('../settings.php');
require_once('../Connections/apound.php');

$id = $_GET[id];
$x = $_GET[x];
$avail = "N";
$paid = "N";

$link = mysql_pconnect($hostname_apound,$username_apound,$password_apound);
mysql_select_db($database_apound);
mysql_query("UPDATE main SET avail='$avail' WHERE dtu='$id'");
mysql_query("UPDATE main SET paid='$paid' WHERE dtu='$id'");

mysql_select_db($database_apound, $apound);
$query_SMTC = "SELECT * FROM main WHERE main.dtu = '$id'";
$SMTC = mysql_query($query_SMTC, $apound) or die(mysql_error());
$row_SMTC = mysql_fetch_assoc($SMTC);
$totalRows_SMTC = mysql_num_rows($SMTC);
$custm = $row_SMTC['email'];
$cbidid = $row_SMTC['dtu'];
$ckeyword = $row_SMTC['title'];
$curl = $row_SMTC['site'];

$kinek  = "$adminmail" . ", " ;
$kinek .= "$custm";
$targy = "SUSPENDED - Thank you for your listing";
$uzenet = "Your Listing ID: $cbidid is DISABLED\n
Your Listing Title: $ckeyword\n
Your Listing URL: $curl\n
View details or upgrade your listing: http://$domainname$pathmail/upgrade.php?ucat=$cbidid
--------------------------------------------------------------------------
$bidmailmessage
--------------------------------------------------------------------------
Contact and Support: http://$domainname$pathmail/contact.php";
$fejlec = "From: $sitetitle <$frommail>\r\n";
mail($kinek, $targy, $uzenet, $fejlec);

mysql_free_result($SMTC);

header("Location: http://$x");
?>