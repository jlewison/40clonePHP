<?php

class Photomodel extends Model
{
		//Constructor
		function Photomodel()
		{
				parent::Model();
				$this->load->model('usermodel');
				$this->load->model('friendsmodel');
				$this->load->model('networkmodel');
		}
		function getAlbumVisibilitySettings()
		{
				$albumVisibilitySettingsQuery = $this->db->query('SELECT * FROM photo_album_visibility ORDER BY visibility_id');
				$albumVisibilitySettings = array();
				if ($albumVisibilitySettingsQuery->num_rows() > 0)
				{
						foreach ($albumVisibilitySettingsQuery->result_array() as $albumVisibilitySettingsRow) $albumVisibilitySettings[$albumVisibilitySettingsRow['visibility_id']] = $albumVisibilitySettingsRow['visible_to'];
				}
				return $albumVisibilitySettings;
		}
		function newAlbum($albumName, $albumLocation, $albumDescription, $albumVisibility)
		{
				$newAlbum = 'INSERT INTO photo_album
						(name, location, description, datestamp, user_id, album_cover, visibility_id)
						VALUES (' . $this->db->escape($albumName) . ', ' . $this->db->escape($albumLocation) . ', ' . $this->db->escape($albumDescription) . ', ' . 'NOW(), ' . $this->session->userdata('user_id') . ',
									0, ' . $this->db->escape($albumVisibility) . ')';
				$this->db->query($newAlbum);
				if ($this->db->affected_rows() == 1) return $this->db->insert_id();
				else  return false;
		}
		function updateAlbum($updateAlbumDetails, $albumId)
		{
				if (isset($albumId) && trim($albumId) != '' && is_numeric($albumId))
				{
						$this->db->where('album_id', $albumId);
						$this->db->update('photo_album', $updateAlbumDetails);
						return true;
				}
				else  return false;
		}
		function getAlbumDetails($albumId)
		{
				$this->db->select('photo_album.album_id, photo_album.name, photo_album.location, photo_album.description, photo_album.user_id, photo_album.album_cover,
							photo_album.album_cover_ext, photo_album.visibility_id, photo_album.photo_order, photo_album.datestamp, users.avatar_ext');
				$this->db->from('photo_album');
				$this->db->join('users', 'users.user_id = photo_album.user_id', 'INNER');
				$this->db->where('album_id', $albumId);
				$this->db->limit(1, 0);
				$albumDetailsQuery = $this->db->get();
				if ($albumDetailsQuery->num_rows() > 0)
				{
						$albumDetailsRow = $albumDetailsQuery->result_array();
						$albumDetailsRow[0]['avatar'] = getAvatar($albumDetailsRow[0], $albumDetailsRow[0]['avatar_ext'], 'thumb');
						$albumDetailsRow[0]['album_owner'] = $this->usermodel->getName($albumDetailsRow[0]['user_id']);
						return $albumDetailsRow[0];
				}
				else  return false;
		}
		function getUserAlbums($userId, $orderBy = 'datestamp desc', $start = '', $limit = '')
		{
				$albumDetails = array();
				$this->db->from('photo_album');
				$this->db->where('user_id', $userId);
				if (trim($orderBy) != '') $this->db->orderby($orderBy);
				if (trim($limit) != '' && is_numeric($limit))
				{
						if (trim($start) != '' && is_numeric($start)) $this->db->limit($limit, $start);
						else  $this->db->limit($limit);
				}
				$albumDetailsQuery = $this->db->get();
				if ($albumDetailsQuery->num_rows() > 0)
				{
						foreach ($albumDetailsQuery->result_array() as $albumDetailsRow)
						{
								$albumDetails[$albumDetailsRow['album_id']] = $albumDetailsRow;
								$albumDetails[$albumDetailsRow['album_id']]['user_name'] = $this->usermodel->getName($albumDetailsRow['user_id']);
								$albumDetails[$albumDetailsRow['album_id']]['created_on'] = date($this->config->item('date_format_medium'), strtotime($albumDetailsRow['datestamp']));
								$networkDetail = $this->networkmodel->getUserNetwork($albumDetailsRow['user_id'], 'region', '', 0, 1);
								if (!empty($networkDetail))
								{
										$networkDetail = current($networkDetail);
										$albumDetails[$albumDetailsRow['album_id']]['regional_network'] = $networkDetail['network_name'];
								}
						}
				}
				return $albumDetails;
		}
		function getUserPhotosCount($userId = '')
		{
				if ($userId == '') $userId = $this->session->userdata('user_id');
				$strSQL = 'SELECT photo_id FROM photos WHERE user_id = ' . $this->db->escape($userId) . ' AND photo_status = "active"';
				$resSQL = $this->db->query($strSQL);
				return $resSQL->num_rows();
		}
		function getUserAlbumsCount($userId)
		{
				$userAlbumCountQuery = $this->db->query('SELECT count(album_id) as cnt FROM photo_album WHERE user_id=' . $userId);
				if ($userAlbumCountQuery->num_rows() > 0)
				{
						$userAlbumCountRow = $userAlbumCountQuery->result_array();
						return $userAlbumCountRow[0]['cnt'];
				}
				else  return false;
		}
		function getAlbumPhotos($albumId, $orderBy = 'datetime desc', $start = '', $limit = '')
		{
				$this->db->from('photos');
				$this->db->where('album_id', $albumId);
				if (trim($orderBy) != '') $this->db->orderby($orderBy);
				if (trim($limit) != '' && is_numeric($limit))
				{
						if (trim($start) != '' && is_numeric($start)) $this->db->limit($limit, $start);
						else  $this->db->limit($limit);
				}
				$photosInAlbumQuery = $this->db->get();
				$photosInAlbum = array();
				if ($photosInAlbumQuery->num_rows() > 0)
				{
						foreach ($photosInAlbumQuery->result_array() as $photosInAlbumRow)
						{
								$photosInAlbum[$photosInAlbumRow['photo_id']] = $photosInAlbumRow;
						}
				}
				return $photosInAlbum;
		}
		function getAlbumPhotosCount($albumId)
		{
				$this->db->from('photos');
				$this->db->where('album_id', $albumId);
				return $this->db->count_all_results();
		}
		function newPhoto($photoDetails)
		{
				if (isset($photoDetails['album_id']) && trim($photoDetails['album_id']) != '' && is_numeric($photoDetails['album_id']))
				{
						$newPhotoSQL = 'INSERT INTO photos
								(album_id, caption, user_id, photo_ext, photo_status, datetime)
								VALUES
								(	' . $this->db->escape((isset($photoDetails['album_id'])) ? $photoDetails['album_id'] : '') . ',
									' . $this->db->escape((isset($photoDetails['caption'])) ? $photoDetails['caption'] : '') . ',
									' . $this->db->escape($this->session->userdata('user_id')) . ',
									' . $this->db->escape((isset($photoDetails['photo_ext'])) ? $photoDetails['photo_ext'] : '') . ',
									' . $this->db->escape((isset($photoDetails['photo_status'])) ? $photoDetails['photo_status'] : '') . ',
									NOW()' . '
								)';
						$this->db->query($newPhotoSQL);
						if ($this->db->affected_rows() == 1)
						{
								return $this->db->insert_id();
						}
						else  return false;
				}
				else  return false;
		}
		function updatePhoto($updatePhotoDetails, $photoID)
		{
				if (isset($photoID) && trim($photoID) != '' && is_numeric($photoID))
				{
						if (isset($updatePhotoDetails['album_id']) && trim($updatePhotoDetails['album_id']) != '' && !is_numeric($updatePhotoDetails['album_id'])) return false;
						else
						{
								$this->db->where('photo_id', $photoID);
								$this->db->update('photos', $updatePhotoDetails);
								return true;
						}
				}
				else  return false;
		}
		//	function deletePhoto($photoID)
		//	{
		//		if(isset($photoID) && trim($photoID) != '' && is_numeric($photoID))
		//		{
		//			$this->db->query('DELETE FROM photos WHERE photo_id=' . $this->db->escape($photoID) . ' LIMIT 1');
		//
		//			return TRUE;
		//		}
		//		else
		//			return FALSE;
		//	}
		#***************************************************************************
		#Method			: getPhotos
		#Description	: returns an array photo ids, for the given album id, if no
		#					photos available for this album returns FALSE.
		#Arguents		: $albumId
		#created by		: ilayaraja_22ag06
		#***************************************************************************
		function getPhotos($albumId)
		{
				$res = $this->db->query('SELECT photo_id FROM photos WHERE album_id=' . $this->db->escape($albumId));
				if ($res->num_rows() > 0)
				{
						foreach ($res->result_array() as $rs)
						{
								$photos[] = $rs['photo_id'];
						}
						return $photos;
				}
				else  return false;
		} //end getPhotos()
		#***************************************************************************
		#Method			: isAlbum
		#Description	: returns TRUE, if the given album id is valid, otherwise
		#					returns FALSE.
		#Arguents		: $albumId
		#created by		: ilayaraja_22ag06
		#***************************************************************************
		function isAlbum($albumId)
		{
				$res = $this->db->query('SELECT album_id FROM photo_album WHERE album_id=' . $this->db->escape($albumId));
				if ($res->num_rows() > 0) return true;
				else  return false;
		} //end isAlbum()
		#***************************************************************************
		#Method			: getPhotoDetails
		#Description	: returns TRUE, if the given album id is valid, otherwise
		#					returns FALSE.
		#Arguents		: $photoId
		#created by		: ilayaraja_22ag06
		#***************************************************************************
		function getPhotoDetails($photoId)
		{
				$res = $this->db->query('SELECT * FROM photos WHERE photo_id=' . $this->db->escape($photoId));
				if ($res->num_rows() > 0) return $res->row_array();
				else  return false;
		} //end getPhotoDetails()
		#***************************************************************************
		#Method			: removePhoto()
		#Description	: returns TRUE, if the given photo deleted successcully, else
		#					returns FALSE.
		#Arguents		: $photoId
		#created by		: ilayaraja_22ag06
		#***************************************************************************
		function removePhoto($photoId)
		{
				$photoDetails = $this->getPhotoDetails($photoId);
				//echo 'DELETE FROM photos WHERE photo_id=' . $this->db->escape($photoId);
				$this->db->query('DELETE FROM photos WHERE photo_id=' . $this->db->escape($photoId));
				if ($this->db->affected_rows() > 0)
				{
						if ($this->isAlbumCover($photoDetails['album_id'], $photoId))
						{
								//				echo '<pre>';
								//				print_r($photoDetails);
								//				echo '</pre>';
								$this->updateAlbum(array('album_cover' => '0', 'album_cover_ext' => ''), $photoDetails['album_id']);
								//$this->updateAlbum(array('album_cover' => '0'),$photoDetails['album_id']);
						}
						$this->load->helper('file');
						$filePath1 = APPPATH . 'content/photos/album_' . $photoDetails['album_id'] . '/photo_' . $photoDetails['album_id'] . '_' . $photoId . $photoDetails['photo_ext'];
						$filePath2 = APPPATH . 'content/photos/album_' . $photoDetails['album_id'] . '/photo_' . $photoDetails['album_id'] . '_' . $photoId . '_thumb' . $photoDetails['photo_ext'];
						@unlink($filePath1);
						@unlink($filePath2);
						return true;
				}
				else  return false;
		} //end removePhoto()
		#***************************************************************************
		#Method			: removeAlbum()
		#Description	: returns TRUE, if the given photo deleted successcully, else
		#					returns FALSE.
		#Arguents		: $albumId
		#created by		: ilayaraja_22ag06
		#***************************************************************************
		function removeAlbum($albumId)
		{
				$this->db->query('DELETE FROM photo_album WHERE album_id=' . $this->db->escape($albumId));
				if ($this->db->affected_rows() > 0)
				{
						$this->db->query('DELETE FROM photos WHERE album_id=' . $this->db->escape($albumId));
						$filePath = APPPATH . 'content/photos/album_' . $albumId;
						$this->recursive_remove_directory($filePath);
						return true;
				}
				else  return false;
		} //end removeAlbum()
		function updateAlbumVisibility($networks, $albumId)
		{
				$this->db->query('DELETE FROM photo_album_visibility_setting WHERE album_id=' . $albumId);
				foreach ($networks as $networkId)
				{
						$newPrivacySettingNetwork = array('album_id' => $albumId, 'network_id' => $networkId);
						$this->db->insert('photo_album_visibility_setting', $newPrivacySettingNetwork);
				}
		}
		function getAlbumVisibilityNetworks($albumId)
		{
				$query = $this->db->query('SELECT * FROM photo_album_visibility_setting WHERE album_id=' . $this->db->escape($albumId));
				$visibilityNetworks = array();
				if ($query->num_rows() > 0)
				{
						foreach ($query->result_array() as $row)
						{
								$visibilityNetworks[$row['photo_album_visibility_setting_id']] = $row;
						}
				}
				return $visibilityNetworks;
		}
		function getFriendsAlbums($userId, $orderBy = 'datestamp desc', $start = '', $limit = '')
		{
				$albumDetails = array();
				$friendsList = $this->friendsmodel->getFriends($this->session->userdata('user_id'));
				if (!empty($friendsList))
				{
						$this->db->from('photo_album');
						$this->db->where_in('user_id', $friendsList);
						if (trim($orderBy) != '') $this->db->orderby($orderBy);
						if (trim($limit) != '' && is_numeric($limit))
						{
								if (trim($start) != '' && is_numeric($start)) $this->db->limit($limit, $start);
								else  $this->db->limit($limit);
						}
						$albumDetailsQuery = $this->db->get();
						if ($albumDetailsQuery->num_rows() > 0)
						{
								foreach ($albumDetailsQuery->result_array() as $albumDetailsRow)
								{
										$albumDetails[$albumDetailsRow['album_id']] = $albumDetailsRow;
										$albumDetails[$albumDetailsRow['album_id']]['friend_name'] = $this->usermodel->getName($albumDetailsRow['user_id']);
										$albumDetails[$albumDetailsRow['album_id']]['created_on'] = date($this->config->item('date_format_medium'), strtotime($albumDetailsRow['datestamp']));
										//$networkDetail	= $this->networkmodel->getUserNetwork($albumDetailsRow['user_id'],'region','',0,1);
										//$albumDetails[$albumDetailsRow['album_id']]['regional_network']	= $networkDetail[$albumDetailsRow['user_id']]['network_name'];
										$networkDetail = current($this->networkmodel->getUserNetwork($albumDetailsRow['user_id']));
										$albumDetails[$albumDetailsRow['album_id']]['regional_network'] = $networkDetail['network_name'];
								}
						}
				}
				return $albumDetails;
		}
		function getFriendsAlbumsCount($userId)
		{
				$friendsList = implode(",", $this->friendsmodel->getFriends($userId));
				//echo $friendsList;
				if ($friendsList != '')
				{
						$albumCountQuery = $this->db->query('SELECT count(album_id) as cnt FROM photo_album WHERE user_id IN (' . $friendsList . ')');
						if ($albumCountQuery->num_rows() > 0)
						{
								$albumCountRow = $albumCountQuery->result_array();
								return $albumCountRow[0]['cnt'];
						}
						else  return false;
				}
				else  return false;
		}
		#***************************************************************************
		#Method			: checkVisibility()
		#Description	: returns allowed user ids for the given visibility type
		#Arguents		: $visibilityType
		#created by		: ilayaraja_22ag06
		#***************************************************************************
		function checkVisibility($albumId)
		{
				$albumDetails = $this->getAlbumDetails($albumId);
				$allowed = false;
				$albumOwnerId = $albumDetails['user_id']; // album owner id
				$userId = $this->session->userdata('user_id'); //current user Id
				if ($userId == $albumOwnerId) $allowed = true;
				else
				{
						switch ($albumDetails['visibility_id'])
						{
								case "1": //Everyone
										$allowed = true;
										break;
								case "2": //All my networks and all my friends
										$userNetworks = $this->networkmodel->getUserNetwork($albumOwnerId);
										foreach ($userNetworks as $key => $value)
										{
												$networkMembers = $this->networkmodel->getMembers($key);
												if (array_key_exists($userId, $networkMembers))
												{
														$allowed = true;
														break;
												}
										}
										if ($allowed != true)
										{
												$friendsList = $this->friendsmodel->getFriends($albumOwnerId);
												if (in_array($userId, $friendsList)) $allowed = true;
										}
										break;
								case "3": //Some of my networks and all my friends
										$userVisibilities = $this->getAlbumVisibilityNetworks($albumId);
										foreach ($userVisibilities as $key => $value) $userNetworks[] = $userVisibilities[$key]['network_id'];
										foreach ($userNetworks as $key => $value)
										{
												$networkMembers = $this->networkmodel->getMembers($value);
												if (array_key_exists($userId, $networkMembers))
												{
														$allowed = true;
														break;
												}
										}
										if ($allowed != true)
										{
												$friendsList = $this->friendsmodel->getFriends($albumOwnerId);
												if (in_array($userId, $friendsList)) $allowed = true;
										}
										break;
								case "4": //Only my friends
										$friendsList = $this->friendsmodel->getFriends($albumOwnerId);
										if (in_array($userId, $friendsList)) $allowed = true;
										break;
						} //end switch
				} //end else
				return $allowed;
		} //end removePhoto()
		#***************************************************************************
		#Method			: getAlbumsCount
		#Description	: fetches total albums count
		#Author
		#***************************************************************************
		function getAlbumsCount($status = 'active', $userId = '')
		{
				$this->db->select('album_id');
				$this->db->from('photo_album');
				if ($userId != '' and $userId > 0) $this->db->where('user_id', $userId);
				return $this->db->count_all_results();
		}
		// ------------ lixlpixel recursive PHP functions -------------
		// recursive_remove_directory( directory to delete, empty )
		// expects path to directory and optional TRUE / FALSE to empty
		// of course PHP has to have the rights to delete the directory
		// you specify and all files and folders inside the directory
		// ------------------------------------------------------------
		// to use this function to totally remove a directory, write:
		// recursive_remove_directory('path/to/directory/to/delete');
		// to use this function to empty a directory, write:
		// recursive_remove_directory('path/to/full_directory',TRUE);
		function recursive_remove_directory($directory, $empty = false)
		{
				// if the path has a slash at the end we remove it here
				if (substr($directory, -1) == '/')
				{
						$directory = substr($directory, 0, -1);
				}
				// if the path is not valid or is not a directory ...
				if (!file_exists($directory) || !is_dir($directory))
				{
						// ... we return false and exit the function
						return false;
						// ... if the path is not readable
				} elseif (!is_readable($directory))
				{
						// ... we return false and exit the function
						return false;
						// ... else if the path is readable
				}
				else
				{
						// we open the directory
						$handle = opendir($directory);
						// and scan through the items inside
						while (false !== ($item = readdir($handle)))
						{
								// if the filepointer is not the current directory
								// or the parent directory
								if ($item != '.' && $item != '..')
								{
										// we build the new path to delete
										$path = $directory . '/' . $item;
										// if the new path is a directory
										if (is_dir($path))
										{
												// we call this function with the new path
												recursive_remove_directory($path);
												// if the new path is a file
										}
										else
										{
												// we remove the file
												unlink($path);
										}
								}
						}
						// close the directory
						closedir($handle);
						// if the option to empty is not set to true
						if ($empty == false)
						{
								// try to delete the now empty directory
								if (!rmdir($directory))
								{
										// return false if not possible
										return false;
								}
						}
						// return success
						return true;
				}
		}
		#***************************************************************************
		#Method			: updatePhotoStatus
		#Description	: updates Photo status
		#Author
		#***************************************************************************
		function updatePhotoStatus($block_id, $status)
		{
				$photoStatus = array('photo_status' => $status);
				$this->db->where('photo_id', $block_id);
				$this->db->update('photos', $photoStatus);
		}
		#***************************************************************************
		#Method			: isAlbumCover
		#Description	: returns TRUE, if the given photo id is album cover for the
		#					given album id
		#Arguents		: $albumId, $photoId
		#created by		: ilayaraja_22ag06
		#***************************************************************************
		function isAlbumCover($albumId, $photoId)
		{
				$res = $this->db->query('SELECT album_id FROM photo_album WHERE album_id=' . $this->db->escape($albumId) . ' AND album_cover=' . $this->db->escape($photoId));
				if ($res->num_rows() > 0) return true;
				else  return false;
		} //end isAlbum()
}

?>