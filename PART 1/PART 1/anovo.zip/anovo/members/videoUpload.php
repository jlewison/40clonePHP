<?php
require_once ('../common/config.inc.php');
require_once ('../common/configs/config_encoder.inc.php');
require_once ('../common/configs/config_ans_video.inc.php');
$CFG['lang']['include_files'][] = 'members/includes/languages/%s/videoUpload.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['mods']['is_include_only']['non_html_header_files'] = true;
$CFG['is']['ajax_page'] = true;
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
set_time_limit(0);
class VideoUpload extends FormHandler
{
		public function chkIsValidCaptureFile()
		{
				$file_name = $this->CFG['admin']['video']['red5_flv_path'] . $this->fields_arr['rid'] . '.flv';
				if (1 or is_file($file_name)) return true;
				return false;
		}
		public function resetFieldsArray()
		{
				$this->setFormField('rid', '');
		}
}
$VideoUpload = new VideoUpload();
$VideoUpload->setDBObject($db);
$VideoUpload->makeGlobalize($CFG, $LANG);
if (!isAjax()) Redirect2URL($CFG['site']['url']);
$VideoUpload->setHeaderStart();
$VideoUpload->setPageBlockNames(array('msg_form_error', 'msg_form_success', 'video_upload_form_capture'));
$VideoUpload->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$VideoUpload->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$VideoUpload->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$VideoUpload->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$VideoUpload->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$VideoUpload->resetFieldsArray();
$VideoUpload->setAllPageBlocksHide();
$VideoUpload->setPageBlockShow('video_upload_form_capture');
$VideoUpload->sanitizeFormInputs($_REQUEST);
if ($VideoUpload->isFormGETed($_GET, 'upload'))
{
		if ($VideoUpload->chkIsValidCaptureFile())
		{
				$VideoUpload->setAllPageBlocksHide();
				$VideoUpload->setCommonSuccessMsg($LANG['success_uploaded']);
				$VideoUpload->setPageBlockShow('msg_form_success');
		}
		else
		{
				$VideoUpload->setCommonSuccessMsg($LANG['error_uploaded']);
				$VideoUpload->setPageBlockShow('msg_form_error');
		}
}



?>
<div id="selVideoUpload" class="">
	<p class="clsPopupClose"><a href="#" onClick="return closLightWindow()"><?php echo $LANG['close']; ?></a></p>
	<div id="selLeftNavigation">
<?php
if ($VideoUpload->isShowPageBlock('msg_form_error'))
{
?>
		  <div id="selMsgError">
		    <p><?php echo $VideoUpload->getCommonErrorMsg(); ?></p>
		  </div>
<?php
}
if ($VideoUpload->isShowPageBlock('msg_form_success'))
{
?>
		  <div id="selMsgSuccess">
		   	<p><?php echo $VideoUpload->getCommonSuccessMsg(); ?></p>
		  </div>
<?php
}
if ($VideoUpload->isShowPageBlock('video_upload_form_capture'))
{
		$settingspath = $CFG['site']['url'] . 'quickCaptureConfigXmlCode.php?file_name=' . $VideoUpload->getFormField('rid');
		$skinpath = $CFG['site']['url'] . 'files/flash/video_capture/skins/skin.xml';
		$quick_recorder_path = $CFG['site']['url'] . 'files/flash/video_capture/QuickRecorder.swf?filename=' . $VideoUpload->getFormField('rid') . '&settingspath=' . $settingspath . '&skinpath=' . $skinpath;
?>
		<div class="clsUploadSection">
			<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" width="400" height="340" id="QuickRecorder" align="middle">
				<param name="allowScriptAccess" value="sameDomain" />
				<param name="movie" value="<?php echo $quick_recorder_path; ?>" />
				<param name="quality" value="high" />
				<param name="wmode" value="<?php echo $CFG['admin']['wmode_value']; ?>" />
				<param name="bgcolor" value="#ffffff" />
				<embed src="<?php echo $quick_recorder_path; ?>" quality="high" bgcolor="#ffffff" width="400" height="340" name="QuickRecorder" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />
			</object>
		</div>
<?php
}
?>
	</div>
</div>
<?php


$VideoUpload->setHeaderEnd();
?>