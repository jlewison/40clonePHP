<?php include('template/Green_Light/b_inside_top.php');?>

<td valign="top">

<!--HOMEPAGE TOP TENT TITLE START -->
          <div class="page-header">
            <h1><?php echo("$lang_39");?></h1>
          </div>
<!--HOMEPAGE TOP TENT TITLE END -->

<!--LISTING TITLE START -->
          <div class="listing-count">
            <div class="xml-icon"><a href="<?php echo("$path");?>linkstopxml.php" target="_blank"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/xml.gif" alt="RSS Feed" border="0" /></a></div>
            <?php echo("$lang_25");?> <?php echo ($startRow_NLlista + 1) ?> <?php echo("$lang_26");?> <?php echo min($startRow_NLlista + $maxRows_NLlista, $totalRows_NLlista) ?> <?php echo("$lang_27");?> <?php echo $totalRows_NLlista ?> <?php echo("$lang_28");?></div>
<!--LISTING TITLE END -->


<!--LISTING START -->
<?php do { ?>
<?php $wsn = $row_NLlista['title']; $step8 = str_replace(" ", "-", $wsn); $wsseoname = "$step8"; ?>
          <div class="box" style="margin-left:10px; ">
            <div class="dbox_top"></div>
            <div class="dbox_middle">
              <div class="box2-left">
                <div class="box2-right">
                  <?php if($fremode == 'N') { ?><div class="rate"><?php echo("$currency"); ?><?php echo $row_NLlista['bid']; ?></div><?php } else {}?>
                  <div class="listing-descr">
                    <div class="bid-title"><a href="<?php echo $row_NLlista['site']; ?>" target="_blank"><?php echo $row_NLlista['title']; ?></a></div>
                    <div class="bid-descr"><?php echo $row_NLlista['descr1']; ?></div>
                    <?php $NLcategory = $row_NLlista['maincategory']; mysql_select_db($database_apound, $apound); $query_LdetCAT = "SELECT * FROM categorylisting WHERE catlistid = '$NLcategory'"; $LdetCAT = mysql_query($query_LdetCAT, $apound) or die(mysql_error()); $row_LdetCAT = mysql_fetch_assoc($LdetCAT); $totalRows_LdetCAT = mysql_num_rows($LdetCAT); ?>
                    <div class="bid-url">
                    	<span style="color:#3a6e2f; font-style:italic;"><?php echo $row_NLlista['site']; ?></span> :: <?php echo("$lang_5");?> <?php echo $row_NLlista['stad']; ?>
						<?php if($prenabled == 'Y' and $enb_latest == 'Y') { ?>
                        
                        	<?php include('pr_latest.php');?>
                        
								<?php if($enb_google == 'Y') { ?> <img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/googleIcon.gif" width="12" height="12" /><?php echo $row_NLlista['google']; ?>
                                <?php } else {} ?>
                                          
                                <?php if($enb_yahoo == 'Y') { ?> <img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/yahooIcon.gif" width="12" height="12" /><?php echo $row_NLlista['yahoo']; ?>
                                <?php } else {} ?>
                                          
                                <?php if($enb_msn == 'Y') { ?> <img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/msnIcon.gif" width="12" height="12" /><?php echo $row_NLlista['msn']; ?>
                                <?php } else {} ?>
                                          
                                <?php if($enb_alexa == 'Y') { ?> <img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/alexaIcon.gif" width="12" height="12" /><?php echo $row_NLlista['alexa']; ?>
                                <?php } else {} ?>
                        
                        <?php } else {} ?>
                    </div>
                  </div>
                  <div class="listing-stats"><?php echo("$lang_30");?> <a href="<?php echo("$path");?><?php echo $row_LdetCAT['categseoname']; ?>/"><?php echo $row_LdetCAT['categoryname'] ?></a></div>
                </div>
              </div>
            </div>
            <div class="dbox_bottom">
              <div style="padding:8px 15px 0 0">
                    <?php if($fremode == 'N') { ?> <?php echo $row_NLlista['bid']; ?> <?php echo("$lang_29");?> ::  <?php } else { } ?>
                    
                    <a href="<?php echo("$path");?><?php echo $row_NLlista['dtu'];?>/<?php echo("$wsseoname"); ?>.html"><?php echo("$lang_7");?></a>
	                <?php if($fremode == 'N') { ?> :: <a href="<?php echo("$path");?>upgrade.php?ucat=<?php echo $row_NLlista['dtu']; ?>"><?php echo("$lang_8");?></a> <?php } else { } ?>
			  </div>
            </div>
          </div>
<?php } while ($row_NLlista = mysql_fetch_assoc($NLlista)); ?>
<!--LISTING END -->

<div class="subnl" style="background:none; border:none"><a href="<?php echo("$path");?>submit.php?su_categ=<?php echo("$su_categ");?>"><?php echo("$lang_31");?></a></div>

<table  border="0" align="right" cellpadding="0" cellspacing="1">
    <tr>
        <td>
        
<?php if ($pageNum_NLlista > 0) { // Show if not first page ?>
<a href="<?php echo("$path");?><?php echo("0");?>/<?php echo("$totalRows_NLlista");?>/<?php echo("new-links");?>.html">&lt;&lt; First</a>
<?php } // Show if not first page ?>

<?php if ($pageNum_NLlista > 0) { // Show if not first page ?>
<a href="<?php echo("$path");?><?php $mb = max(0, $pageNum_NLlista - 1); echo("$mb");?>/<?php echo("$totalRows_NLlista");?>/<?php echo("new-links");?>.html">&lt; Previous</a>
<?php } // Show if not first page ?>

<?php if ($pageNum_NLlista < $totalPages_NLlista) { // Show if not last page ?>
<a href="<?php echo("$path");?><?php $mb = min($totalPages_NLlista, $pageNum_NLlista + 1); echo("$mb");?>/<?php echo("$totalRows_NLlista");?>/<?php echo("new-links");?>.html">Next &gt;</a>
<?php } // Show if not last page ?>

<?php if ($pageNum_NLlista < $totalPages_NLlista) { // Show if not last page ?>
<a href="<?php echo("$path");?><?php $mb = min($totalPages_NLlista, $pageNum_NLlista + 1); echo("$totalPages_NLlista");?>/<?php echo("$totalRows_NLlista");?>/<?php echo("new-links");?>.html">Last &gt;</a>
<?php } // Show if not last page ?>
        
        </td>
    </tr>
</table>
  
<?php include('template/Green_Light/b_footer_tpl.php'); ?>