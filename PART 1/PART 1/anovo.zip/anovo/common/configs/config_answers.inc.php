<?php
$CFG['admin']['category']['mandatory'] = true;
$CFG['admin']['description']['mandatory'] = false;
$CFG['admin']['question']['edit'] = true;
$CFG['admin']['question']['delete'] = true;
$CFG['admin']['question']['ratings'] = true;
$CFG['admin']['question']['open_days'] = 5;
$CFG['admin']['best_answers']['allowed'] = true;
$CFG['admin']['answers']['source'] = false;
$CFG['admin']['answers']['limit'] = 500;
$CFG['admin']['answer']['edit'] = true;
$CFG['admin']['answer']['delete'] = true;
$CFG['admin']['answer']['ratings'] = true;
$CFG['admin']['recent']['limit'] = 20;
$CFG['admin']['description']['limit'] = 500;
$CFG['admin']['profile_image']['allowed'] = true;
$CFG['admin']['view_answers']['allowed'] = true;
$CFG['admin']['view_answers']['points'] = 1;
$CFG['admin']['ask_answers']['allowed'] = true;
$CFG['admin']['ask_answers']['points'] = 5;
$CFG['admin']['reply_answers']['allowed'] = true;
$CFG['admin']['reply_answers']['points'] = 5;
$CFG['admin']['three_stars']['points'] = 1;
$CFG['admin']['four_stars']['points'] = 2;
$CFG['admin']['two_stars']['points'] = 0;
$CFG['admin']['single_star']['points'] = 0;
$CFG['admin']['abused_user']['points'] = -2;
$CFG['admin']['abuse_questions']['allowed'] = true;
$CFG['admin']['abuse_questions_points']['allowed'] = true;
$CFG['admin']['abuse_questions']['points'] = -3;
$CFG['admin']['abuse_answers']['allowed'] = true;
$CFG['admin']['abuse_answers_points']['allowed'] = true;
$CFG['admin']['abuse_answers']['points'] = -2;
$CFG['question']['send_count'] = 5;
$CFG['admin']['blogs']['ratings'] = true;
$CFG['admin']['ignore_user'] = true;
$CFG['admin']['email_to_friend']['allowed'] = true;
$CFG['admin']['favorite']['allowed'] = true;
$CFG['admin']['subscribe']['forums'] = true;
$CFG['admin']['subscribe']['users'] = true;
$CFG['admin']['bio_count'] = 700;
$CFG['admin']['subscribe']['tags'] = true;
$CFG['admin']['tool_tip']['allowed'] = true;
$CFG['side_bar']['show_hide'] = true;
$CFG['comments']['expand_collapse'] = true;
if ($CFG['debug']['debug_standalone_modules'])
{
		echo '<pre>' . "\n";
		print_r($GLOBALS);
		echo '</pre>' . "\n";
}
?>