<?php //00461
// Copyright Notice
// Web Site URL:  http://www.zeeways.com
// Script Owner eMail: mail@zeeways.com
// Date: April, 2007
// Script Name: Zeeways Auction Website PHP Script
// Copyright Details: This script is not free.  Do not Remove this Copy Right notice.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the site administrator.');exit(199);
?>
4+oV58fvh6vrt1H15C8vJIeigAQCIB3KIy5t1T03HcZChAXkTVCqeo+RuGMRcNRr2Hy+eKCskovf
LQ+PqAM0Jcl56CxjnPib7l6ADuQfD7lT0uIlOTMxM+RfjN/QjN/alkIi9sXactvp+UzSuw0enzCP
urd9INQ/AoSF4IPXx6nzmp++Q7PlAG/Ch2XJT3K4VCtjYldRIeI1jzJgy3C4nZSFSv8md1XuxBMu
K4cgZVh5cT4nM3NVALVtz9QcD0nCS/Sjhab+jffm4OEWP4ReeNQBmjxeytriZedw7F+ranULqfku
Ny3yX8ZiEyaJRJ6lkvhKKu9bnPsZfL5FaLqdkjjc9uyUVvQqjSdwXb1j0Jw8rfS4yNlLBjhx8511
xw+uZHF67rgyoblJFIINvtuTs28IRYCZ4OlgyGwpgY/W9hGtM6HYRbSnvJIge85s4anro/BIMwMM
jic9pG4BDK1oytzVYR5Cy52EWL+ZNihfQzeEfPmgqP8f10AVplLqdrqOzBdVS/1gItZoFnfdJ08R
33M+rD6+PdKmLQzGs1yfaSD88nUNEBYh3ZyKtxHP54k7k1W0KJyboMZIV+C9QpDHP5W7VNeV9PJN
DG0TW1AZm9PrLDtHea0o30h4YICIrrQH7EM6hcnskySG1/0O5GiL1VjBngv8ZE9Fh9jmDIDFzaAp
Z6PfiskWMg0m/N4rLTJENTKUK2BM0wIjmMgQLfVbLkn3wzme/oDfoSXC8JlEQsUlegCuBc0kQBef
+vNEQKNEzCUqtHrLT8PcORe4m9Gf51JkkM10n88VNPWaAAJnOvCGaGeHiOiNFYMF352k8QyOux28
ZPOOCmWB5cB9xSHldAj2W81AYfxQmMMU3RiigttL9mkHkAOqbEXKrQIBTQPElAutJ4cOYDR2ZeS3
hVhrPzCHon2ufxJYiaG=