<?php
$LANG['devlogin_title'] = 'Developer Login - Testing Only';
$LANG['devlogin_error'] = 'Error in login!';
$LANG['devlogin_submit'] = 'Submit';
$LANG['devlogin_user_id'] = 'Email';
$LANG['devlogin_tbl_summary'] = 'Container for login form';
$LANG['devlogin_choose'] = 'Choose...';
$LANG['devlogin_err_tip_compulsory'] = 'Required';
$LANG['devlogin_err_sorry'] = 'Sorry, errors detected!';
$LANG['devlogin_err_cookies_not_set'] = 'Need to enable cookies to login.';
$LANG['devlogin_err_invalid_user_id'] = 'Invalid userid';
?>