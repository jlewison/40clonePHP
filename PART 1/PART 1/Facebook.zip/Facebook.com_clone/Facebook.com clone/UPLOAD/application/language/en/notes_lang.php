<?php

/**
* Language File for Notes
*
*
* @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
* @license
* @since 02/05/2008
*/
	$lang['page_title']					= 	'Notes';
	$lang['notes_my_notes']				= 	'My Notes';
	$lang['notes_notes_about_you']		= 	'Notes about you';
	$lang['notes_main_title']			= 	'Notes';
	$lang['notes_show_recent_notes']	= 	'Showing recent notes by';
	$lang['notes_all_friends']			=	'All friends';
	$lang['notes_displaying']			=	'Displaying';
	$lang['notes_of']					=	'of';
	$lang['notes_no_friend_notes']		=	'Your friend(s) haven\'t wrote any notes!';
	$lang['notes_by']					=	'by';
	$lang['notes_at']					=	'at';
	$lang['notes_no_comments']			=	'No Comments';
	$lang['notes_add_comments']			=	'Add a Comment';
	$lang['notes_recently_tagged']		=	'Recently Tagged Friends:';
	$lang['notes_no_network']			=	'no network';
	$lang['notes_notes_about']			=	'Notes about';
	$lang['notes_recently_tagged_on']	=	'Recently Tagged on';
	$lang['notes_usernames_notes']		=	'\' Notes';
	$lang['notes_write_note']			=	'Write a note';
	$lang['notes_notes_about_me']		=	'Notes about Me';
	$lang['notes_notes_about']			=	'Notes about';
	$lang['notes_notes_post_comment']	=	'Post your comment:';
	$lang['notes_you']					=	'You';
	$lang['notes_edit']					=	'Edit';
	$lang['notes_delete']				=	'Delete';
	$lang['notes_comment_label']		=	'comment(s)';
	$lang['notes_remove_tag']			=	'Remove Tag';
	$lang['notes_peoples_tag']			=	'In this note the following peoples have been tagged:';
	$lang['notes_notes_no']				=	'You haven\'t wrote any notes!';
	$lang['notes_notes_have_no']		=	'haven\'t wrote any notes!';
	$lang['notes_click_del_comment']	=	'Click to Delete Comment';
	$lang['notes_no_tag_friend']		=	'haven\'t tagged in any of his/her friends notes!';
	$lang['notes_no_tag_you']			=	'You haven\'t tagged in any of your friends notes!'; 
	$lang['notes_form_title']			=	'Title : ';								
	$lang['notes_form_body']			=	'Body : ';
	$lang['notes_notes_tag_people']		=	'Tag people in this note :';
	$lang['notes_notes_edit_your']		=	'Edit your Note';
	$lang['notes_comment_success']		=	'Your comment added Successfully....';
	$lang['notes_enter_comment']		=	'Please enter comment....';
	$lang['notes_comment_delete_success']=	'Comment deleted Successfully....';
	$lang['notes_notes_delete_success']	=	'Notes deleted Successfully....';
	$lang['notes_notes_save_fail']		=	'Failed to save your note!';
	$lang['notes_notes_save_success']	=	'Your note added successfully';
	$lang['notes_validation_title']		=	'Notes Title';
	$lang['notes_validation_body']		=	'Notes Body';
	$lang['notes_validation_file_msg']	=	'- Invalid photo format, allowed formats are jpeg, gif, png and bmp of size of 1MB <br>';
	$lang['notes_validation_file_size']	=	'- Photo size must be less than 4MB<br>';
 	$lang['notes_validation_upload_fail']=	'Failed to upload file -';
 
 
  
 				
?>
