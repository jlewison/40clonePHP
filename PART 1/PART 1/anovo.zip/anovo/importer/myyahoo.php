<?php
error_reporting(0);
include_once ('functions.php');
//******************************* | SETTING VARIABLES | ***********************************\\
$username = $_POST["username"];
$password = $_POST["password"];
$refering_site = "http://yahoo.com/"; //setting the site for refer
$browser_agent = "Mozilla/5.0 (Windows; U; Windows NT 5.0; en-US; rv:1.4) Gecko/20030624 Netscape/7.1 (ax)"; //setting browser type
$path_to_cookie = realpath('yahoocookie.txt');
$setcookie = fopen($path_to_cookie, 'wb'); //this opens the file and resets it to zero length
fclose($setcookie);
//******************************* | OPENING YAHOO LOGIN PAGE | ***********************************\\
$login_page = "https://login.yahoo.com/config/mail?.intl=us";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $login_page);
curl_setopt($ch, CURLOPT_USERAGENT, $browser_agent);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, $path_to_cookie);
curl_setopt($ch, CURLOPT_COOKIEJAR, $path_to_cookie);
$page_result = curl_exec($ch);
curl_close($ch);
// echo "<textarea rows=30 cols=120>".$page_result."</textarea>";       //DEBUG -- this will pages html in nice box
//******************************* | GET HIDDEN FIELDS | ***********************************\\
// (1) get .tries fieled
preg_match_all("/name=\".tries\" value=\"(.*?)\"/", $page_result, $tries);
//print_r($tries);                     // DEBUG -- this will print the whole array
$tries_found = $tries[1][0]; // stores the hidden text in a ariable to use later in POST
// (2) get .src fieled
preg_match_all("/name=\".src\" value=\"(.*?)\"/", $page_result, $src);
//print_r($src);                     // DEBUG -- this will print the whole array
$src_found = $src[1][0]; // stores the hidden text in a ariable to use later in POST
// (3) get .u fieled
preg_match_all("/name=\".u\" value=\"(.*?)\"/", $page_result, $u);
//print_r($u);                     // DEBUG -- this will print the whole array
$u_found = $u[1][0]; // stores the hidden text in a ariable to use later in POST
// (4) get .v fieled
preg_match_all("/name=\".v\" value=\"(.*?)\"/", $page_result, $v);
//print_r($v);                     // DEBUG -- this will print the whole array
$v_found = $v[1][0]; // stores the hidden text in a ariable to use later in POST
// (5) get .challenge fieled
preg_match_all("/name=\".challenge\" value=\"(.*?)\"/", $page_result, $challenge);
//print_r($challenge);                     // DEBUG -- this will print the whole array
$challenge_found = $challenge[1][0]; // stores the hidden text in a ariable to use later in POST
//******************************* | SUBMITTING LOGIN INFO | ***********************************\\
$postal_data = '.tries=' . $tries_found . '&.src=' . $src_found . '&.md5=&.hash=&.js=&.last=&promo=&.intl=us&.bypass=&.partner=&.u=6bu841h2d7p4o&.v=0&.challenge=' . $challenge_found . '&.yplus=&.emailCode=&pkg=&stepid=&.ev=&hasMsgr=1&.chkP=Y&.done=http://mail.yahoo.com&.pd=ym_ver%253d0&login=' . $username . '&passwd=' . $password;
$login_page2 = 'https://login.yahoo.com/config/login?';
$refering_site2 = 'https://login.yahoo.com/config/mail?.intl=us';
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $login_page2);
curl_setopt($ch, CURLOPT_USERAGENT, $browser_agent);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $postal_data);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_REFERER, $refering_site2);
curl_setopt($ch, CURLOPT_COOKIEFILE, $path_to_cookie);
curl_setopt($ch, CURLOPT_COOKIEJAR, $path_to_cookie);
$result3 = curl_exec($ch);
curl_close($ch);
//echo $result3;
preg_match_all("/replace\(\"(.*?)\"/", $result3, $redirected);
$myyahoo = $redirected[1][0];
//******************************* | REDIRECT TO WELCOME PAGE | ***********************************\\
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $myyahoo);
curl_setopt($ch, CURLOPT_USERAGENT, $browser_agent);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_REFERER, $refering_site2);
curl_setopt($ch, CURLOPT_COOKIEFILE, $path_to_cookie);
curl_setopt($ch, CURLOPT_COOKIEJAR, $path_to_cookie);
$result4 = curl_exec($ch);
curl_close($ch);
// echo $result4
//******************************* | OPEN ADDRESS BOOK | ***********************************\\
$addressbook = 'http://us.rd.yahoo.com/mail_us/pimnav/ab/*http://address.mail.yahoo.com';
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $addressbook);
curl_setopt($ch, CURLOPT_USERAGENT, $browser_agent);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_REFERER, $myyahoo);
curl_setopt($ch, CURLOPT_COOKIEFILE, $path_to_cookie);
curl_setopt($ch, CURLOPT_COOKIEJAR, $path_to_cookie);
$result5a = curl_exec($ch);
curl_close($ch);
//echo $result5a;
//echo "<textarea rows=30 cols=120>".$result5a."</textarea>";       //DEBUG -- this will pages html in nice box
//******************************* | REDIRECT ADDRESS BOOK | ***********************************\\
$addressbook = 'http://address.mail.yahoo.com';
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $addressbook);
curl_setopt($ch, CURLOPT_USERAGENT, $browser_agent);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_REFERER, $myyahoo);
curl_setopt($ch, CURLOPT_COOKIEFILE, $path_to_cookie);
curl_setopt($ch, CURLOPT_COOKIEJAR, $path_to_cookie);
$result5 = curl_exec($ch);
curl_close($ch);
//echo "<textarea rows=30 cols=120>".$result5."</textarea>";       //DEBUG -- this will pages html in nice box
//echo $result5;
preg_match_all("/rand=(.*?)\"/", $result5, $array_names);
//print_r($array_names);                                       //DEBUG - Show array
$rand_value = str_replace('"', '', $array_names[0][0]);
//echo $rand_value;
$addressURL = 'http://address.mail.yahoo.com/?1&VPC=import_export&A=B&.rand=' . $randURL;
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $addressURL);
curl_setopt($ch, CURLOPT_USERAGENT, $browser_agent);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_REFERER, $addressbook);
curl_setopt($ch, CURLOPT_COOKIEFILE, $path_to_cookie);
curl_setopt($ch, CURLOPT_COOKIEJAR, $path_to_cookie);
$result5 = curl_exec($ch);
curl_close($ch);
//echo "<textarea rows=30 cols=120>".$result5."</textarea>";
//echo $result5;
preg_match_all("/id=\"crumb1\" value=\"(.*?)\"/", $result5, $array_names);
//print_r($array_names);
$crumb = $array_names[1][0];
//echo $crumb;
if (empty($crumb))
{
?>
<p align="center"><font face="Verdana" size="2"><b>No Details Found:</b> Please make sure you have entered correct login details and try again.</font></p><p align="center">
<?php
}
else
{
		//******************************* | SUBMITTING DOWNLOAD INFO | ***********************************\\
		$postal_data = '.crumb=' . $crumb . '&VPC=import_export&A=B&submit%5Baction_export_yahoo%5D=Export+Now';
		$login_page = 'http://address.mail.yahoo.com/index.php';
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $login_page);
		curl_setopt($ch, CURLOPT_USERAGENT, $browser_agent);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $postal_data);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_REFERER, $addressURL);
		curl_setopt($ch, CURLOPT_COOKIEFILE, $path_to_cookie);
		curl_setopt($ch, CURLOPT_COOKIEJAR, $path_to_cookie);
		$result = curl_exec($ch);
		curl_close($ch);
		//echo $result; - show csv result
		//WRITING OUTPUT TO CSV FILE
		$myFile = $username;
		$fh = fopen($myFile, 'w') or die("can't open file");
		fwrite($fh, $result);
		fclose($fh);
		//*********************** | START OF HTML | ***********************************\\
		// [header section - html]

?>
<html>
<head>
<title>MY CONTACTS</title>
<script type="text/javascript"><!--

var formblock;
var forminputs;

function prepare() {
formblock= document.getElementById('form_id');
forminputs = formblock.getElementsByTagName('input');
}

function select_all(name, value) {
for (i = 0; i < forminputs.length; i++) {
// regex here to check name attribute
var regex = new RegExp(name, "i");
if (regex.test(forminputs[i].getAttribute('name'))) {
if (value == '1') {
forminputs[i].checked = true;
} else {
forminputs[i].checked = false;
}
}
}
}

if (window.addEventListener) {
window.addEventListener("load", prepare, false);
} else if (window.attachEvent) {
window.attachEvent("onload", prepare)
} else if (document.getElementById) {
window.onload = prepare;
}

//--></script>
</head>
<body>	
<div align="center">
<center>
<table border="0" width="578"><tr>
<TD width="622"><IMG height=2 alt="" src="images/spacer.gif" width=1 border=0></TD>
</tr><tr><TD align=middle width="622"><TABLE cellSpacing=0 cellPadding=0 width=640 border=0>
<TBODY><TR><TD width=5 height=5><IMG height=5 alt="" src="images/tls.gif" width=5 border=0></TD>
<TD background="images/t.gif" colSpan=2 width="716"><IMG height=1 alt="" src="images/spacer.gif" width=1 border=0></TD>
<TD width=6 height=5><IMG height=5 alt="" src="images/trs.gif" width=5 border=0></TD></TR><TR>
<TD width=5 background="images/l.gif" height=5><IMG height=5 alt="" src="images/spacer.gif" width=5 border=0></TD>
<TD width=6><IMG height=1 alt="" src="images/spacer.gif" width=6 border=0></TD><TD vAlign=top width=704>
<table border="0" width="100%"><tr><td width="100%" bgcolor="#D7D8DF">
<p align="center"><font face="Arial" size="3" color="#333333">My Contacts</font></td></tr></table>
<p align="center">
<form id="form_id" name="myform" method="post" action="postage.php" onsubmit="return false">
	<div align="center"><center>
<table border="0" cellpadding="3" cellspacing="6" width="100%">
	<tr>
		<th width="22" bgcolor="#F5F5F5"><input type="checkbox" class="clsCheckRadio" name="check_all" onclick="CheckAll(document.myform.name, document.myform.check_all.name)" /></th>
		<!--<th width="22" bgcolor="#F5F5F5">Name</th>-->
		<th width="22" bgcolor="#F5F5F5">Email</th>
	</tr>
<?php
		//OPEING CSV FILE FOR PROCESSING
		$fp = fopen($username, "r");
		while (!feof($fp))
		{
				$data = fgetcsv($fp, 4100, ","); //this uses the fgetcsv function to store the quote info in the array $data
				//print_r($data);
				$dataname = $data[0];
				if (empty($dataname))
				{
						$dataname = $data[2];
				}
				if (empty($dataname))
				{
						$dataname = $data[3];
				}
				if (empty($dataname))
				{
						continue;
						$dataname = "None";
				}
				$email = $data[4];
				if (empty($email))
				{ //Skip table if email is blank
				}
				else
				{
						$email = $data[4];
						if ($dataname != "First")
						{ // skiping table to remove first line of csv file
								$data[4] = getEmailAddress($data[4]);
								if (empty($data[4]))
								{
										continue;
								}
?>
	<tr>
		<td width="22" bgcolor="#F5F5F5"><input type="checkbox" name="list[]" value="<?php echo $data[4]; ?>"></td>
		<!--<td width="269" bgcolor="#F5F5F5"><p align="center"><font face="Verdana" size="2"><?php echo $dataname; ?></font></td>-->
		<td width="296" bgcolor="#F5F5F5"><p align="center"><font face="Verdana" size="2"><?php echo $data[4]; ?></font></td>
	</tr>
<?php
						}
				}
		}

?>
</table></center></div>
<table border="0" width="100%"><tr><td width="100%">
<p align="center"><input type="button" value="Add contacts" name="B1" style="background-color: #808080; color: #FFFFFF; font-family: Arial; font-size: 10pt; font-weight: bold; border: 1 solid #333333" onClick="addContacts()"></p></form></td></tr>
</table><IMG height=1 alt="" src="images/spacer.gif" width=1 border=0></TD>
<TD width=6 background="images/r.gif" height=5><IMG height=1 alt="" src="images/spacer.gif" width=1 border=0></TD></TR>
<TR><TD width=5 height=5><IMG height=5 alt="" src="images/bls.gif" width=5 border=0></TD>
<TD background="images/b.gif" colSpan=2 width="716"><IMG height=1 alt="" src="images/spacer.gif" width=1 border=0></TD>
<TD width=6 height=5><IMG height=5 alt="" src="images/brs.gif" width=5 border=0></TD></TR></TBODY></TABLE></TD>                      </tr></table></center></div>
<?php
		unlink($username); //deleting csv file
}

?>