<?php
	$module_info['name'] = 'Agree To Terms';
	$module_info['desc'] = 'Makes users check a box that states that they agree to your sites terms of use.';
	$module_info['version'] = 0.1;
	//$module_info['db_add_field'][]=array(table_prefix . 'links', 'akismet', 'TINYINT',  3, "UNSIGNED", 0, '0');
?>

