/*  
Theme Name: i2Theme 1.1 GrassyGreen (Right Edition)
Theme URI: http://www.mangoorange.com
Description: WordPress theme designed by <a href="http://www.ndesign-studio.com">N.Design Studio</a>, customized by <a href="http://www.mangoorange.com">MangoOrange&trade;</a>, sponsored by <a href="http://www.web-hosting-top.com/">Best Web Hosting</a>.
Version: 1.1
Author: Mickey Cheong
Author URI: http://www.mangoorange.com/about/

Ported to CPG  by: Billy Bullock
Porter URI: http://www.billygbullock.com
i2Theme 1.1 GrassyGreen (Right Edition) Coppermine Theme Version: 1.0.0
Tested on CPG v1.4.19
Released on Sept. 22, 2008
*/


Thank you for downloading the i2Theme 1.1 GrassyGreen (Right Edition) theme ported from a WordPress theme by N.Design Studio (http://www.ndesign-studio.com).

I've overwritten some of the configuration settings by using variables in the theme.php file and added a new variable for retrieving the album description. The reason for this is to prevent the standard settings in the Configuration tables set by you from "breaking" the theme. If you wish to change these settings, do so here or delete them altogether and use the Configuration Manager in Coppermine. These changes are:

// These parameters overide what the user inputs in the Configuration setup to prevent the theme from breaking.
$CONFIG['max_film_strip_items'] = 4; //overrides the number of thumbnails.
$CONFIG['thumbcols'] = 4; //overrides the number of columns for thumbnails.
$CONFIG['main_table_width'] = '100%'; //overrides the Width of the main table (pixels or %).
$CONFIG['picture_table_width'] = '100%'; //overrides the Width of the table for file display (pixels or %).
$CONFIG['album_list_cols'] = 2; // sets "Number of columns for the album list = 2"
$CONFIG['first_level'] = 0 ; //sets "Show first level album thumbnails in categories = no".
$album_desc = get_album_desc($_GET[album]);

This theme has the first level of album thumbnails turned off to make large galleries look move attractive. This will prevent the main page from being cluttered with thumbnails and easier to chose a particular category. There is also a new function for truncating the album descriptions when viewing on the index or category pages. When you view a single album, the full description is printed out at the top of the album. This makes the index and category pages much cleaner looking. I've also adapted it to truncate long image captions when viewing on a thumbnail page but prints the full caption when viewing the intermediate image.

To edit the number of characters in the truncated album description, find in 2 places in the theme.php file - '{ALB_DESC}' => myTruncate($album['album_desc'], 20, " "), and change the number (20) to any length your desire. You can also change the padding characters (...) to any other set of characters by editing function myTruncate($string, $limit, $break=".", $pad="...") in the theme.php file.

To edit the number of characters in the truncated image caption, find in 2 places in the theme.php file - '{CAPTION}' => myTruncate($caption, 120, " "), // changing the number changes the # of characters printed for the thumbnail caption. and change the number (120) to an length you desire. This number doesn't seem to be match the string length but it is consistant so change it and view the results.

I've also adapted the compute_img_size($width, $height, $max) function to manage the size of the intermediate image. As in some cases (example would be the Coppermine demo page), some galleries have intermediate images of different sizes. This function was changed and added to the theme.php to make view all intermediate images at 400px wide. This function is now compute_img_size_max($width, $height) and you can change the view size by editing $max = 400;. If you have intermediate images smaller than 400px wide then this function will increase the image size when viewing which could result in a distorted image. Since the default size in Coppermine is "400", this should not be a problem unless you've decreased it. This setting in the theme.php file does not affect the setting in your Coppermine configuration but only resizes the images in the browser. Here's a link to additional info in the manual - http://coppermine-gallery.net/demo/cpg14x/docs/index.htm#admin_picture_thumbnail.

Another edit I made was remove the thumbnail from the categories list. These category thumbnails are added to the gallery in the Category Manager with no way in the configuration to turn them off so I remove the {CAT_THUMB} from the $template_cat_list variable in the theme.php. Below is how you add it back in if you wish.
____________________________________________________________
Find in theme.php:

				<td class="catrow" align="left"><table border="0"><tr><td><span class="catlink"><b>{CAT_TITLE}</b></span>{CAT_DESC}</td></tr></table></td>


And replace with:

				<td class="catrow" align="left"><table border="0"><tr><td>{CAT_THUMB}</td><td><span class="catlink"><b>{CAT_TITLE}</b></span>{CAT_DESC}</td></tr></table></td>
____________________________________________________________

I've tested this theme without issue on FireFox 3.0.1 (Mac & PC), Safari 3.1.2 and IE 7.0.5.X (PC). Sorry I do not have IE 6.X on my PC and will not test this browser version.

Items to note:
1.	If you want to add more sidebars with different icons, check in the image folder as there are lots of other icons to use.
2.	When using Internet Explorer, some of the fill-in boxes in the admin forms run off the main content area. This doesn't hurt anything but does look sort of strange when compared to FireFox. These boxes can be made to fit by editing the various pages (ie. profile.php, etc). By the way, Internet Explorer sucks!
3.	In some languages the "Album" and "Files" titles run together. This can be fixed by editing the "h3" style in style.css and there's a note on what to edit there. Be sure to check your theme pages carefully as this change does affect other items but if you can't find them then no need to worry about them. :)

Please enjoy the theme.

Cheers,

Billy
http://www.billygbullock.com