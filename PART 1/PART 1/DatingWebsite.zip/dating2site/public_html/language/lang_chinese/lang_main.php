<?php
// The format of this file is ---> $lang['message'] = 'text';
//
// You should also try to set a locale and a character encoding (plus direction). The encoding and direction
// will be sent to the template. The locale may or may not work, it's dependent on OS support and the syntax
// varies ... give it your best guess!
//

$lang['ENCODING'] = 'UTF-8';
$lang['DIRECTION'] = 'ltr';
$lang['LEFT'] = 'left'; 
$lang['RIGHT'] = 'right';
$lang['DATE_FORMAT'] =  '%Y-%m-%d'; // This should be changed to the default date format for your language, php date() format
$lang['DATE_TIME_FORMAT'] =  '%Y-%m-%d %I:%M:%S %P'; // This should be changed to the default date format for your language, php date() format
$lang['DISPLAY_DATE_FORMAT'] =  'Y-m-d';
$lang['DISPLAY_DATETIME_FORMAT'] = 'D Y-m-d H:i:s';
//$lang['DATE_FORMAT'] =  '%b %d, %Y'; // This should be changed to the default date format for your language, php date() format
//$lang['DATE_TIME_FORMAT'] =  '%b %d, %Y %I:%M:%S %P'; // This should be changed to the default date format for your language, php date() format
//$lang['DISPLAY_DATE_FORMAT'] =  'M d, Y';
//$lang['DISPLAY_DATETIME_FORMAT'] = 'D M-d-Y H:i:s';
$lang['DB_ERROR'] = "由于数据库出现问题,系统暂时无法执行您的请求.<br />请稍后再试.";

$lang['main_menu'] = '主菜单';
$lang['homepage'] = '主页';
$lang['rate_photos'] = '照片评分';
$lang['forum'] = '论坛';
$lang['manageforum'] = '论坛管理';
$lang['chat'] = '聊天';
$lang['managechat'] = '聊天管理';
$lang['member_login'] = '会员登录';
$lang['featured_members'] = '特别会员';
$lang['quick_search'] = '快速搜索';
$lang['my_searches'] = '我的搜索';
$lang['affiliates'] = '分销会员';
$lang['already_affiliate'] = '已经成为分销会员?';
$lang['referals'] = '介绍人';
$lang['title_colon'] = '主题:';
$lang['comments_colon'] = '意见:';
$lang['feedback'] = '反馈';

$lang['profiles'] = '档案';
$lang['profile_s'] = 'USERNAME' . '的档案';
$lang['total_amt'] = '总数';
$lang['banner_link'] = '横幅广告/链接';
$lang['clicks'] = '点击';
$lang['finance_calc'] = '财务计算器';
$lang['flash_chat_msg'] = 'FlashChat 4.1.0 或更新版本直接支持 osDate. 请通过 <a href="http://www.tufat.com/chat.php" target="_blank">http://www.tufat.com/chat.php</a> 购买 FlashChat, 然后拷贝里面所有的文件到这个文件夹内. 之后, 请启动 FlashChat 的安装程序, 指定 osDate 作为要整合的内容管理系统.';
$lang['flash_chat_admin_msg'] = 'FlashChat 4.1.0 或更新版本直接支持 osDate. 请通过 <a href="http://www.tufat.com/chat.php" target="_blank">http://www.tufat.com/chat.php</a> 购买 FlashChat, 然后拷贝里面所有的文件到这个文件夹内. 之后, 请启动 FlashChat 的安装程序, 指定 osDate 作为要整合的内容管理系统.';
$lang['affiliate_head_msg'] = '成为分销会员';
$lang['affiliate_head_msg2'] = '所有介绍用户到我们网站的站长,我们都提供佣金.<br/>';
$lang['affiliate_success_msg1'] = '您的介绍人帐户 id 是:';
$lang['affiliate_success_msg2'] = '您可以登录到您的介绍人帐户. ';
$lang['affiliate_login_title'] = "分销会员登录";
$lang['password_changed_successfully'] = '您已经成功更改您的密码';
$lang['affiliate_registration_success'] = '分销会员帐户注册成功';
$lang['login_now'] = '这里登录';
$lang['must_be_valid'] = '必须有效';
$lang['characters'] = '个字符';
$lang['email'] = '电子邮件地址:';
$lang['age'] = '年龄';
$lang['years'] = '岁';

$lang['all_states'] = '所有地区';
//
// These terms are used at Signup page
//
$lang['welcome'] = '欢迎';
$lang['admin_welcome'] = '欢迎 <br /> 来到 <br />' . 'SITENAME' . '<br /> 管理员面板';
$lang['title'] = '欢迎来到 ' . 'SITENAME';
$lang['site_links'] = array(
	'home' => '主页',
	'signup_now' => '现在就注册',
	'chat' => '聊天',
	'forum' => '论坛',
	'login' => '登录',
	'search' => '搜索',
	'aboutus' => '关于我们',
	'forgot' => '忘记您的密码或登录帐号?',
	'contactus' => '联系我们',
	'privacy' => '隐私保护',
	'terms_of_use' => '使用协议',
	'services' => '服务条款',
	'faq' => '常见问题',
	'articles' => '文章',
	'affliates' => '加盟分销',
	'invite_a_friend' => '推荐给好友',
	'feedback' => '意见反馈'
	);

$lang['success_stories'] = '成功故事';
$lang['members_login'] = '会员登录';
$lang['poll'] = '投票项目';
$lang['poll'] = '投票项目';
$lang['news'] = '新闻';
$lang['articles'] = '文章';
$lang['poll_result'] = '投票结果';
$lang['view_poll_archive'] = '过去的投票项目';
$lang['member_panel'] = '会员管理面板';
$lang['poll_errmsg1'] = '您已经参与过这个投票项目. 请继续参与其他的投票项目.';
$lang['close'] = '关闭';
$lang['all_stories'] = '所有故事';
$lang['all_news'] = '所有新闻';
$lang['more'] = '更多';
$lang['by'] = '按';

$lang['dont_stay_alone'] = '还在寻觅中?';
$lang['join_now_for_free'] = '现在就免费注册吧!';
$lang['special_offer'] = '特别优惠!';
$lang['welcome_to'] = '欢迎来到 ';
$lang['welcome_to_site'] = '欢迎来到 '.'SITENAME';

$lang['offer_text'] = 'SITENAME' . ' 是现今网络上增长最快的交友网站. 创建您的 ' . 'SITENAME' . ' 个人档案,开始踏上寻找伴侣的刺激旅程吧.';

$lang['newest_profiles'] = '最新会员档案';

$lang['edit_profile'] = '更改档案';
$lang['total_profiles'] = '档案总数';
$lang['forgot'] = '忘记您的登录帐号?';
$lang['hide'] = '隐藏';
$lang['show'] = '显示';
$lang['sex'] = '性别:';
$lang['sex_without_colon'] = '性别';
$lang['pageno'] = '页 ';
$lang['page'] = '页';
$lang['previous'] = '前页';
$lang['next'] = '后页';
$lang['time_col'] = '时间:';

$lang['save_search'] = '保存搜索';
$lang['find_your_match'] = '搜索适合您的人';

$lang['extended_search'] = '扩展搜索';
$lang['matches_found'] = '以下的个人档案符合您的搜索要求.';
$lang['timezone'] = '时区:';
$lang['next_section'] = '下部分';
$lang['sign_in'] = '会员登录';
$lang['member_panel'] = '会员管理面板';
$lang['aff_panel'] = '分销会员管理面板';
$lang['login_title'] = '会员登录区';
$lang['sign_out'] = '退出';
$lang['login_submit'] = '登录';

$lang['change_password'] = '更改密码';
$lang['old_password'] = '旧密码:';
$lang['new_password'] = '新密码:';
$lang['confirm_password'] = '确认密码:';
$lang['password_change_msg'] = '您已经成功更改您的密码.';

$lang['section_signup_title'] = '注册信息';
$lang['signup'] = '注册';
$lang['section_basic_title'] = '基本信息';
$lang['section_appearance_title'] = '外表';
$lang['section_interests_title'] = '兴趣';
$lang['section_lifestyle_title'] = '生活方式';

$lang['signup_subtitle_login'] = '登录详情';
$lang['signup_subtitle_profile'] = '我的个人档案';
$lang['signup_subtitle_address'] = '地址';
$lang['signup_subtitle_appearacnce'] = '外表';
$lang['signup_subtitle_preference'] = '搜索偏好';

$lang['signup_username'] = '帐号:';
$lang['signup_password'] = '密码:';
$lang['signup_confirm_password'] = '确认密码:';

$lang['signup_firstname'] = '名字:';
$lang['signup_lastname'] = '姓氏:';
$lang['signup_email'] = '电子邮件地址:';
$lang['section_mypicture'] = '我的相片';
$lang['upload'] = '上传';
$lang['upload_pictures'] = '管理相片';
$lang['upload_format_msgs'] = '只允许 .jpg 或 .gif 或 .bmp 或 .png 文件.';
$lang['thumbnail'] = '缩略图';
$lang['picture'] = '相片';
$lang['signup_picture'] = '我的相片';
$lang['signup_picture2'] = '我的相片 2:';
$lang['signup_picture3'] = '我的相片 3:';
$lang['signup_picture4'] = '我的相片 4:';
$lang['signup_picture5'] = '我的相片 5:';

$lang['signup_gender'] = '我是一名';
$lang['signup_pref_age_range'] = '年龄范围';
$lang['signup_year_old'] = '岁';
$lang['signup_birthday'] = '出生日期:';
$lang['signup_country'] = '国家:';
$lang['signup_state_province'] = '省份:';
$lang['signup_zip'] = '邮政编码:';
$lang['signup_city'] = '城市:';
$lang['signup_address1'] = '地址:';
$lang['signup_address2'] = '地址(续):';
$lang['signup_height'] = '身高: ';
$lang['signup_feet'] = '尺';
$lang['signup_meter_inches'] = '英寸 [ 如果身在美国以外,米 ]';
$lang['signup_weight'] = '体重:';
$lang['signup_pounds'] = '磅 [ 如果身在美国以外, 公斤 ]';
$lang['signup_where_should_we_look'] = '搜索的地理范围';
$lang['signup_view_online'] = "是否显示我的在线状态?";

$lang['signup_gender_values'] = array(
	'M' => '男性',
	'F' => '女性',
	'C' => '情侣',
	'G' => '群组'
	);

$lang['signup_gender_look'] = array(
	'M' => '男性',
	'F' => '女性',
	'C' => '情侣',
	'G' => '群组',
	'B' => '男性或女性',
	'A' => '任何皆可'
	);

$lang['seeking'] = '寻找一位';
$lang['looking_for_a'] = '寻找一位';
$lang['looking_for'] = '寻找';

$lang['of'] = ' ';
$lang['to'] = ' 到 ';
$lang['from'] = ' 从 ';
$lang['for'] = ' ';
$lang['yes'] = '是';
$lang['no'] = '否';
$lang['cancel'] = '取消';

$lang['change'] = '更改';
$lang['reset'] = '重置';

//Commonly used words

$lang['required_info_indication'] = '标明的项必须填写';
$lang['required_info_indicator'] = '* ';
$lang['required_info_indicator_color'] = 'Red';
$lang['click_here'] = '单击此处';

$lang['datetime_dayval']['Sun'] = '星期日';
$lang['datetime_dayval']['Mon'] = '星期一';
$lang['datetime_dayval']['Tue'] = '星期二';
$lang['datetime_dayval']['Wed'] = '星期三';
$lang['datetime_dayval']['Thu'] = '星期四';
$lang['datetime_dayval']['Fri'] = '星期五';
$lang['datetime_dayval']['Sat'] = '星期六';

$lang['error_msg_color'] = 'Red';
$lang['success_message'] = "您所填写的资料已经成功保存.<br />页面将在五秒钟内自动转向到下一部分. 如果不能自动跳转, 请点击下面的链接.";
$lang['sendletter_success'] = '信件已经成功发出.';


/*****************Admin Section Labels********************/

//Commonly used labels
$lang['admin_login_title'] = 'SITENAME' . ' 管理面板';
$lang['home_title'] = 'SITENAME' . ' 主页';
$lang['admin_login_msg'] = '管理员登录';
$lang['admin_title_msg'] = 'SITENAME' . ' 管理员面板';
$lang['admin_panel'] = '管理员面板';
$lang['back'] = '返回';
$lang['insert_msg'] = '增加新的 ';
$lang['question_mark'] = '?';
$lang['id'] = '编号:';
$lang['name'] = '名称: ';
$lang['name_col'] = '名称';
$lang['enabled'] = '启用:';
$lang['action'] = '操作';
$lang['edit'] = '更改';
$lang['delete'] = '删除';
$lang['section'] = '部分:';
$lang['insert_section'] = '加入新的部分';
$lang['modify_section'] = '更改部分';
$lang['modify_sections'] = '更改部分';
$lang['delete_section'] = '删除部分';
$lang['delete_sections'] = '删除部分';
$lang['enable_selected'] = '启用';
$lang['disable_selected'] = '禁用';
$lang['change_selected'] = '更改';
$lang['delete_selected'] = '删除';
$lang['no_select_msg'] = "您没有选择任何选项. 请点击浏览器上的后退按钮,然后选择一个或多个选项.";
$lang['delete_confirm_msg'] = '您确定要删除这个部分?';
$lang['delete_group_confirm_msg'] = '您确定要删除这个部分? 此操作将无法撤消.';
$lang['enabled_values'] = array(
	'Y' => '是',
	'N' => '否'
	);
$lang['display_control_type'] = array(
	'checkbox' => '复选框',
	'radio' => '单选框',
	'select' => '下拉框',
	'textarea' => '文字输入'
	);
$lang['admin_error_color'] = 'Red';

$lang['col_head_srno'] = '#';
$lang['col_head_id'] = '帐号';
$lang['col_head_question'] = '问题';
$lang['col_head_enabled'] = '启用';
$lang['col_head_name'] = '名称';
$lang['col_head_username'] = '用户名';
$lang['col_head_firstname'] = '名字';
$lang['col_head_lastname'] = '姓氏';
$lang['col_head_fullname'] = '全名';
$lang['col_head_status'] = '状态';
$lang['col_head_gender'] = '性别';
$lang['col_head_email'] = '电子邮箱';
$lang['col_head_country'] = '国家';
$lang['col_head_city'] = '城市';
$lang['col_head_zip'] = '邮政编码';
$lang['col_head_register_at'] = '注册于';

$lang['section_title'] = '部分管理';
$lang['total_sections'] = '部分总数:';
$lang['profile_title'] = '个人档案管理';
$lang['total_profiles_found'] = '找到档案总数:';
$lang['modify_profile'] = '更改个人档案';

$lang['profile_signup_title'] = '注册信息';
$lang['profile_basic_title'] = '基本信息';
$lang['profile_appearance_title'] = '外表';
$lang['profile_interests_title'] = '兴趣';
$lang['profile_lifestyle_title'] = '生活方式';

$lang['profile_subtitle_login'] = '登录详情';
$lang['profile_subtitle_profile'] = '个人档案';
$lang['profile_subtitle_address'] = '地址';
$lang['profile_subtitle_appearacnce'] = '外表';
$lang['profile_subtitle_preference'] = '使用偏好';
$lang['profile_delete_confirm_msg'] = '您确定要删除这份档案?';
$lang['delete_profile'] = '删除档案';
$lang['profile_username'] = '用户名:';
$lang['profile_firstname'] = '名字:';
$lang['profile_lastname'] = '姓氏:';
$lang['profile_email'] = '电子邮箱:';
$lang['profile_gender'] = '性别:';
$lang['profile_birthday'] = '出生日期:';
$lang['profile_country'] = '国家:';
$lang['profile_state_province'] = '省份:';
$lang['profile_zip'] = '邮政编码:';
$lang['profile_city'] = '城市';
$lang['profile_address1'] = '地址:';
$lang['profile_address2'] = '地址(续):';
$lang['find'] = '寻找';
$lang['search'] = '搜索';
$lang['AND'] = '并且';
$lang['OR'] = '或者';
$lang['order_by'] = '排序: ';
$lang['sort_by'] = '分类';
$lang['sort_types'] = array(
	'asc' => '升序',
	'desc' => '降序'
	);
$lang['search_results'] = '搜索结果';
$lang['no_record_found'] = '没有找到匹配的结果.';
$lang['search_options'] = '搜索选项';
$lang['search_simple'] = '普通搜索';
$lang['search_advance'] = '搜索';
$lang['search_advance_results'] = '搜索结果';
$lang['search_country'] = '按国家搜索';
$lang['search_states'] = '按省份搜索';
$lang['search_zip'] = '按邮政编码搜索';
$lang['search_city'] = '按城市搜索';
$lang['search_wildcard_msg'] = '您可以在文字输入框内输入 * 来搜索所有的记录 .';
$lang['search_location'] = '<b>按地区搜索:</b>';
$lang['select_state'] = '省份:';
$lang['enter_city'] = '城市:';
$lang['enter_zip'] = '邮政编码:';
$lang['enter_username'] = '用户名:';
$lang['results_per_page'] = '每页显示结果数';
$lang['search_results_per_page'] = array( 2 => 2, 5 => 5 , 10 => 10, 20 => 20, 50 => 50, 100 => 100 );
$lang['order'] = '排序';
$lang['up'] = '上';
$lang['down'] = '下';

$lang['question'] = '问题:';

$lang['maxlength'] = '最大长度:';
$lang['description'] = '描述:';
$lang['mandatory'] = '必须:';
$lang['guideline'] = '指引:';
$lang['control_type'] = '显示控制:';
$lang['include_extsearch'] = '在扩展搜索中加入:';
$lang['head_extsearch'] = '扩展搜索主题:';

$lang['delete_question'] = '删除问题';
$lang['modify_question'] = '更改问题';
$lang['questions_title'] = '问题管理';
$lang['total_options'] = '选项总数:';
$lang['insert_question'] = '加入新的问题';
$lang['total_questions'] = '问题总数:';
$lang['delete_questions'] = '删除问题';
$lang['delete_group_questions_confirm_msg'] = '确定要删除这些问题吗? 此操作无法撤消.';

$lang['option'] = '选项';
$lang['answer'] = '答案';
$lang['options_title'] = '问题选项';
$lang['col_head_answer'] = '答案';
$lang['with_selected'] = '选择';
$lang['ranging'] = '包括';

// Instant messenger
$lang['instant_messenger'] = '即时通';
$lang['instant_message'] = '即时消息';
$lang['im_from'] = '来自:';
$lang['im_message'] = '消息:';
$lang['im_reply'] = '回复';
$lang['close_window'] = '关闭窗口';

// my matches
$lang['my_matches'] = '我的配对';
$lang['i_am_a'] = '我是一名';
$lang['Between'] = '到';
$lang['who_is_from'] = '年龄范围';
$lang['showing'] = '显示';
$lang['your_search_preferences'] = '您的搜索偏好:';
$lang['to_edit_search_preferences'] = '更改搜索偏好';

$lang['unapproved_user'] = '待批准个人档案';
$lang['gbl_settings'] = '网站的全局设置';
$lang['configurations'] = '设置';
$lang['col_head_variable'] = '参数';
$lang['col_head_value'] = '数值';

$lang['affiliate_title'] = '分销会员管理';
$lang['col_head_counter'] = '计数器';
$lang['col_head_status'] = '状态';

$lang['tell_later'] = '以后再说';
$lang['view_profile'] = '查看档案';
$lang['view_profile_errmsg1']  = '您尚未设置使用偏好.<br />请先设置个人档案详细信息.<br />';
$lang['view_profile_errmsg2'] = '<br />单击此处设置您的使用偏好.';
$lang['view_profile_errmsg3'] = '用户尚未设置他的个人档案.';
$lang['view_profile_restricted'] = '您无法查看此受限档案.';
$lang['profile_notset'] = '没有找到这用户的个人档案.';
$lang['send_mail'] = '发送消息';
$lang['mail_messages'] = '消息';
$lang['col_head_subject'] = '主题';
$lang['col_head_sendtime'] = '日期';

$lang['inbox'] = '收件箱';
$lang['sent'] = '已发送';
$lang['trashcan'] = '已删除';
$lang['reply'] = '回复';
$lang['read'] = '已读';
$lang['unread'] = '未读';
$lang['restore'] = '恢复';
$lang['subject'] = '主题';
$lang['subject_colon'] = '主题:';
$lang['message'] = '消息';
$lang['send'] = '发送';

$lang['send_letter'] = '发送信件';
$lang['image_browser'] = '图像浏览器';
$lang['upload_image'] = '上传图像';
$lang['delete_image'] = '删除图像';
$lang['show_image'] = '显示图像';
$lang['send_invite'] = '发送邀请';
$lang['letter_title'] = '新信件';
$lang['from_email'] = '电子邮件来自:';
$lang['from_name'] = '来自:';
$lang['send_to'] = '发送';
$lang['email_subject'] = '主题:';
$lang['save_as'] = '保存为';

$lang['no_message'] = '您的收件箱没有新消息.';
$lang['descrip'] = '描述';

//forgot password words
$lang['forgotpass_msg1'] = "登入提醒";
$lang['forgotpass_msg2'] = "请提供您在创建个人档案时使用的电子邮件地址以便我们发送用户名和新的密码给您. 为安全起见, 请在收到新密码后立即登录并修改此密码.";
$lang['retreieve_info'] = '发送';
$lang['forgotpass'] = '忘记密码';

//Tell a friend
$lang['tellafriend'] = '邀请朋友';
$lang['taf_msg1'] = '邀请朋友到' . 'SITENAME';
$lang['taf_yourname'] = '您的名字:';
$lang['taf_youremail'] = '您的邮箱:';
$lang['taf_friendemail'] = "朋友的邮箱:";

//Auto-mail
$lang['confirm_your_profile'] = '确认您的注册';
$lang['letter_not_avail'] = '信件模板不存在';
$lang['confirm_letter_sent'] = '一封确认邮件已经发送到您注册时使用的电子邮箱.请打开这封确认电子邮件来完成您的注册.';
$lang['letter_not_sent'] = '发送邮件出现问题. 请联系系统管理员.';
$lang['or'] = '或者';
$lang['enter_confirm_code'] = '请填写您的确认码来完成您的注册过程.';
// Affiliate auto-mail

$lang['aff_email_subject'] = '确认您的分销会员帐号';
$lang['aff_email_body'] = '感谢您在' . 'SITENAME' . '创建一个分销会员帐户. 请在您的浏览器的地址条栏中填写以下地址来完成您的分销会员帐户注册:<br><br>#ConfirmationLink#';

//Page management

$lang['manage_pages'] = '网页管理';
$lang['pagetitle'] = '主题:';
$lang['pagetext'] = '文本:';
$lang['pagekey'] = '索引:';
$lang['addpage'] = '添加网页';
$lang['page'] = '网页:';
$lang['addnew'] = '添加';
$lang['modpage'] = '更改网页';
$lang['pagekey_help'] = 'http://www.yourdomain.com/index.php?page=YOUR_KEY';

$lang['y_o'] = 'y/o';
$lang['lastlogged'] = '最近一次登录: ';
$lang['aff_stats'] = '分销会员统计';
$lang['total_referrals'] = '下线总数';
$lang['regis_referals'] = '已注册下线';
$lang['globalconfigurations'] = '全局设置';

$lang['send_message_to'] = '发送消息到';
$lang['writing_message'] = '编写消息';
$lang['search_at'] = '搜索';

//Rating module
$lang['rate_profile'] = '评价档案';
$lang['worst'] = '最糟';
$lang['excellent'] = '非常好';
$lang['rating'] = '评价';
$lang['submitrating'] = '提交评价';

//Payment Modules
$lang['mship_changed'] = '会员等级已经更改';
$lang['mship_changed_successfull'] = '您的会员等级已经变为免费会员.';
$lang['no_payment'] = '无需付费(免费)';
$lang['payment_modules'] = '支付组件';
$lang['payment_methods'] = '支付方式';
$lang['business'] = '生意:';
$lang['siteid'] = '网站帐号:';
$lang['undefined_quantity'] = '没有设定数量:';
$lang['no_shipping'] = '无需配送:';
$lang['no_note'] = '没有备注:';
$lang['on_off_values'] = array( 1 => '是', 0 => '否' );
$lang['edit_payment_modules'] = '更改支付组件';
$lang['trans_key'] = '交易码:';
$lang['trans_mode'] = '交易方式:';
$lang['trans_method'] = '交易方法:';
$lang['username'] = '用户名:';
$lang['username_without_colon'] = '用户名';
$lang['country'] = '国家';
$lang['country_colon'] = '国家:';
$lang['state'] = '省份';
$lang['city'] = '城市';
$lang['location_col'] = '位置:';
$lang['location_no_col'] = '位置';
$lang['zip_code'] = '邮政编码';
$lang['attached_files'] = '附件';
$lang['cc_owner'] = '信用卡主人:';
$lang['cc_number'] = '信用卡号码:';
$lang['cc_type'] = '信用卡类型:';
$lang['cc_exp_date'] = '信用卡有效日期:';
$lang['cc_cvv_number'] = '信用卡检测号:';
$lang['cvv_help'] = '(信用卡背面)';
$lang['continue'] = '继续';
$lang['trans_method_vals'] = array(
	'CC' => '信用卡',
	'ECHECK' => '电子支票'
	);
$lang['trans_mode_vals'] = array(
	'AUTH_CAPTURE' => 'AUTH_CAPTURE',
	'AUTH_ONLY' => 'AUTH_ONLY',
	'CAPTURE_ONLY' => 'CAPTURE_ONLY',
	'CREDIT' => 'CREDIT',
	'VOID' => 'VOID',
	'PRIOR_AUTH_CAPTURE' => 'PRIOR_AUTH_CAPTURE'
 );
$lang['cc_unknown'] = '信用卡公司无效.请使用一张有效的信用卡.';
$lang['cc_invalid_date'] = '信用卡有效日期无效. 请使用一张有效的信用卡.';
$lang['cc_invalid_number'] = '信用卡号码无效. 请使用一张有效的信用卡.';
$lang['amount'] = '数额: ';
$lang['confirmation'] = '确认';
$lang['confirm'] = '确认';
$lang['upgrade_membership'] = '升级会员级别';
$lang['changeto'] = '更改成';
$lang['current_mship_level'] = '当前会员级别:';
$lang['membership_status'] = '会员状态';
$lang['you_currently'] = '您现在是 ';
$lang['info_confirm'] = '以下资料是否正确?';
$lang['change_mship_to'] = '更改会员级别为 ';
//Membership
$lang['permitmsg_1'] = '抱歉, 您的会员级别并不包含';
$lang['permitmsg_2'] = '请升级您的会员级别来使用 ';
$lang['permitmsg_3'] = '会员级别比较表';
$lang['permitmsg_4'] = '隐藏会员级别比较表';
$lang['membership_packages'] = '会员套餐';
$lang['membership_packages_compare'] = '会员套餐比较';
$lang['modify'] = '保存更改';
$lang['manage_membership'] = '会员级别管理';
$lang['privileges_msg'] = '权限';
$lang['price'] = '价格: ';
$lang['currency'] = '外汇: ';
$lang['choose_membership'] = '选择会员级别:';
$lang['add_membership'] = '添加新的会员级别';
$lang['membership_types'] = '会员级别';
$lang['member'] = '会员';

$lang['select_letter'] = '选择信件:';
$lang['body'] = '内容:';
$lang['module'] = '组件';
$lang['uninstall'] = '卸载';
$lang['install'] = '安装';
$lang['modify_option'] = '更改选项';

$lang['only_jpg'] = '只允许 .jpg 或 .gif 或 .bmp 或 .png 文件.';
$lang['upload_unsuccessful'] = '无法上传图像.';
$lang['upload_successful'] = '已经上传图像.';
$lang['between1'] = '之间';
$lang['and'] = '和';
$lang['profile_details'] = '档案详情';
$lang['personal_details'] = '个人档案详情';


//Banner Management
$lang['manage_banners'] = '横幅广告管理';
$lang['add_banners'] = '添加横幅广告';
$lang['edit_banners'] = '更改横幅广告';
$lang['size'] = '尺寸';
$lang['size_px'] = '尺寸(px)';
$lang['banner_linkurl'] = '横幅广告 / 链接 URL';
$lang['banner_sizes'] = array(
	'468X60' => '468 x 60',
	'100X500'=>'100 x 500',
	'120X120'=>'120 x 120'
);
$lang['banner_sizes_name'] = array( '横向', '纵向', '四方' );
$lang['startdate'] = '开始日期:';
$lang['enddate'] = '结束日期:';
$lang['tooltip'] = 'Tooltip提示:';
$lang['linkurl'] = '链接 Url:';
$lang['banner'] = '横幅广告:';
$lang['total_banner'] = '横幅广告总数:';
$lang['online_users'] = '在线会员: ';
$lang['site_statistics'] = '网站统计';
$lang['pending_profiles'] = '待处理个人档案';
$lang['active_profiles'] = '活跃个人档案';
$lang['online_profiles'] = '在线个人档案';
$lang['pending_aff'] = '待处理分销会员';
$lang['total_affiliates'] = '分销会员总数';
$lang['active_aff'] = '活跃分销会员';
$lang['no_rating'] = '没有评价';

//SEO Words
$lang['seo'] = '搜索引擎优化设置';
$lang['seo_head'] = '搜索引擎优化';
$lang['sef_msg'] = '搜索引擎友好链接';
$lang['seo_enable'] = '启用 mod_rewrite URL地址重写 :';
$lang['yes_msg'] ='URL 重写功能只在启用了 mod_rewrite 扩展的 Apache 服务器下可用. 请确定您的服务器符合这些要求. 另外,请记得将 .htaccess.txt 文件重命名为 .htaccess.';
$lang['keywords'] = '关键词:';
$lang['page_tags_msg'] = '网页标题及Meta 标签';
$lang['max_255'] = '最多 255 个字符';

//News / Story / Article Manangement
$lang['manage_news'] = '新闻管理';
$lang['manage_story'] = '故事管理';
$lang['manage_article'] = '文章管理';
$lang['news_header'] = '标题';
$lang['total_news'] = '新闻总数:';
$lang['total_articles'] = '文章总数:';
$lang['total_stories'] = '故事总数:';
$lang['article_title'] = '主题';
$lang['story_sender'] = '发送者';
$lang['story_sender_msg'] = '个人档案编码 [数字]';
$lang['modify_article'] = '更改文章';
$lang['modify_news'] = '更改新闻';
$lang['modify_story'] = '更改新闻';
$lang['insert_article'] = '添加文章';
$lang['insert_story'] = '添加新闻';
$lang['insert_news'] = '添加新闻';
$lang['dat'] = '日期:';

//Poll Words
$lang['manage_polls'] = '投票管理';
$lang['modify_poll'] = '更改投票项目';
$lang['total_polls'] = '投票总数';
$lang['poll'] = '投票';
$lang['add_polls'] = '添加投票项目';
$lang['add_options'] = '添加选项';
$lang['active'] = '活跃';
$lang['activate'] = '启动';
$lang['option'] = '选项';
$lang['modify_options'] = '更改选项';
$lang['add_option_now'] = '添加选项.';
$lang['poll_options'] = '投票项目选项';
$lang['votes'] = '票';
//Filter Records
$lang['filter_options'] = array(
	'id' => '帐号',
	'username' => '用户名',
	'city' => '城市',
	'zip' => '邮政编码',
	'status' => '状态',
	'email'	=> '电子邮箱',
	'gender' => '性别'
	);
$lang['first'] = '最先';
$lang['last'] = '最后';
$lang['filter_records'] = '过滤结果';
$lang['search_at'] = '搜索';
$lang['criteria'] = '条件';

//Admin Management
$lang['manage_admins'] = '管理员管理';
$lang['total_admins'] = '管理员总数';
$lang['add_admin'] = '添加管理员';
$lang['modify_admin'] = '更改管理员';
$lang['fullname'] = '全名';
$lang['please_be_sure'] = '请确定';
$lang['change_your_admin_pwd'] = '更改您的管理员帐户密码.';
$lang['superuser'] = '超级用户';
$lang['no_admin_user_msg1'] = '没有非超级用户的管理员. 请先创建一个.';
$lang['no_admin_user_msg2'] = '创建新的管理员用户';
$lang['access_denied'] = '拒绝访问';
$lang['not_authorize'] = '您没被授权访问此网页. 请联系您的超级管理员.';

//Admin Permissions Management
$lang['admin_permissions'] = '管理员许可';
$lang['manage_admin_permissions'] = '管理员许可管理';
$lang['admin_users'] = '管理员用户';
$lang['permissions'] = '组件';
$lang['superuser_noteditable'] = '注意: 超级用户不可编辑.';
$lang['all'] = '全部';
$lang['selected'] = '选择';
$lang['selected_users'] = '被选用户';
$lang['separate_users_by_coma'] = '输入用户名, 用户名之间用逗号隔开';
$lang['admin_rights'] = array(
		'site_stats' 				=> '网站统计',
		'profie_approval'		 	=> '待批准档案',
		'profile_mgt' 				=> '档案管理',
		'section_mgt' 				=> '部分管理',
		'affiliate_mgt' 			=> '分销会员管理',
		'affiliate_stats'		 	=> '分销会员统计',
		'news_mgt' 					=> '新闻管理',
		'article_mgt' 				=> '文章管理',
		'story_mgt'					=> '故事管理',
		'poll_mgt'		 			=> '投票管理',
		'search' 					=> '搜索',
		'ext_search'				=> '扩展搜索',
		'send_letter' 				=> '发送信件',
		'pages_mgt' 				=> '网页管理',
		'chat' 						=> '聊天',
		'chat_mgt' 					=> '聊天管理',
		'forum_mgt' 				=> '论坛管理',
		'mship_mgt' 				=> '会员管理',
		'payment_mgt' 				=> '付费模块',
		'banner_mgt' 				=> '横幅广告管理',
		'seo_mgt' 					=> '搜索引擎优化设置',
		'admin_mgt' 				=> '管理员管理',
		'admin_permit_mgt'			=> '管理员许可',
		'global_mgt' 				=> '网站全局设置',
		'change_pwd'				=> '更改密码',
		'cntry_mgt'					=> '管理国家/省份/城市',
		'snaps_require_approval'	=> '批准图像',
		'featured_profiles_mgt'		=> '特色档案',
		'calendar_mgt'				=> '日历',
		'event_mgt'					=> '批准活动',
		'import_mgt'				=> '导入',
	/* Added in 2.0 */
      	'plugin_mgt'            	=> '插件管理',
		'blog_mgt'					=> '博客管理',
		'profile_ratings'			=> '个人档案评价管理',
		);

$lang['cntry_mgt']	= '管理国家/省份/城市';
$lang['register_now'] = '立即注册加入我们的社区!';
$lang['addtobuddylist'] = '添加到好友列表';
$lang['addtobanlist'] = '添加到封锁列表';
$lang['addtohotlist'] = '添加到热门列表';
$lang['buddylisthdr'] = '好友列表';
$lang['banlisthdr'] = '封锁列表';
$lang['hotlisthdr'] = '热门列表';
$lang['username_hdr'] = '用户名';
$lang['fullname_hdr'] = '全名';
$lang['register'] = '立即注册';
$lang['featured_profiles'] = '特色档案';
$lang['bigger_pic_size'] = '图像大小超过了所允许的大小'.$config['upload_snap_maxsize'].' KB.';
$lang['snaps_require_approval'] = '批准图像';
$lang['events_require_approval'] = '批准活动';
$lang['upload_picture_caption'] = '主图像 ';
$lang['upload_thumbnail_caption'] = '缩略图 ';
$lang['Approve'] = '批准';
$lang['Remove'] = '移除';
$lang['userdetails'] = '用户信息';
$lang['pict'] = '图像';
$lang['tnail'] = '缩略图';
$lang['reqact'] = '动作';
$lang['newmemberlist'] = '最新加入会员';
$lang['yearsold'] = '岁';
$lang['Male'] = '男';
$lang['Female'] = '女';
$lang['showfulllist'] = '显示全部列表';
$lang['featuredprofiles'] = '特色档案';
$lang['featured_profiles_hdr'] = '特色会员档案';
$lang['nonfeatured_profiles_hdr'] = '普通会员';
$lang['level_hdr'] = '等级';
$lang['date_from'] = '开始日期';
$lang['date_upto'] = '致';
$lang['must_show'] = '必须显示';
$lang['reqd_exposures'] = '所须曝光率';
$lang['total_exposures'] = '曝光率总数';
$lang['add_featured'] = '添加个人档案到特色列表';
$lang['mod_featured'] = '在特色列表更改个人档案';
$lang['member_since'] = '会员自';
$lang['invalid_username'] = '用户名无效';
$lang['weekcnt'] = '最近一周新会员:';
$lang['totalgents'] = '男性会员总数:';
$lang['totalfemales'] = '女性会员总数:';
$lang['weeksnaps'] = '最近一周照片数量:';
$lang['since_last_login'] = '自上次登入';
$lang['sincelastlogin_hdr'] ='自上次登入';
$lang['newmessages'] = '收到新消息:';
$lang['profileviewed'] = '您的个人档案被浏览的次数:';
$lang['winks_received'] = '您收到眨眼动作的次数:';
$lang['send_wink'] = '发送眨眼动作';
$lang['listofviews'] = '浏览您个人档案的会员列表';
$lang['listofwinks'] = '发送眨眼动作给您的会员列表';
$lang['winkslist'] = '眨眼动作列表';
$lang['viewslist'] = '浏览列表';
$lang['suggest_poll'] = '提议一个投票项目';
$lang['savepoll'] = '提交投票项目';
$lang['moreoptions'] = '更多选项';
$lang['minimum_options'] = '至少需要两个选项';
$lang['pollsuggested'] = '谢谢! 您所建议的投票项目已经被传送到网站的管理员.';
$lang['suggested_by'] = '提议者:';
$lang['any_where'] = '任何地方';
$lang['memberpanel'] = "会员的主页";
$lang['feedback_thanks'] = '谢谢您的反馈. 您的消息已经被传送到网站的管理员.';
$lang['cancel_hdr'] = '取消会员资格';
$lang['cancel_txt01'] = '您已经要求取消您在 <b>'.'SITENAME'.'</b> 的会员资格.<br /><br />您确定吗? ';
$lang['cancel_opt01'] = '是,我确定';
$lang['cancel_opt02'] = '否,我暂时不要取消';
$lang['cancel_domsg'] = '谢谢您使用 '.'SITENAME'.'. <br><br>我们为您的退出感到遗憾, 可是我们依旧欢迎您在任何时候重新加入我们, 也希望我们的服务给您提供了帮助.';
$lang['cancel_nomsg'] = '谢谢您使用 '.'SITENAME'.'.<br><br>我们感谢您继续使用我们的服务, 也希望我们的服务给您提供了帮助.';
$lang['reject'] = '拒绝';
$lang['unread'] = '未读';
$lang['membership_hdr'] = '会员等级';
$lang['edit_pict'] = '更改主图像';
$lang['edit_thmpnail'] = '更改缩略图';
$lang['letter_options'] = '信件选项';
$lang['pic_gallery'] = '图像';
$lang['reactivate'] = '重新激活用户帐户';
$lang['cancel_list'] = '取消会员资格列表';
$lang['cancel_date'] = '取消日期';
$lang['language_opt'] = '语言' ;
$lang['change_language'] = '更换语言';
$lang['with_photo'] = '有照片';
$lang['logintime'] = '登录时间';
$lang['manage_country_states'] = '管理国家/省份';
$lang['manage_countries'] = '管理国家';
$lang['countries_count'] = '国家总数';
$lang['insert_country'] = '添加新国家';
$lang['modify_country'] = '更改国家';
$lang['country_code'] = '国家代码';
$lang['country_name'] = '国家名字';
$lang['manage_states'] = '管理省份';
$lang['states_count'] = '省份总数';
$lang['insert_state'] = '添加新省份';
$lang['modify_state'] = '更改省份';
$lang['state_code'] = '省份代码';
$lang['state_name'] = '省份名称';
$lang['totalcouples'] = '情侣会员总数:';
$lang['active_days'] = '保持有效状态几天?';
$lang['activedays_array'] = array('1'=>'1','7'=>'7','30'=>'30','90'=>'90','180'=>'180','365'=>'365');
$lang['expired'] = '您的会员资格已经过期. <a href="payment.php" class="errors">更新您的会员资格/a> 以继续享用'. 'SITENAME'.'的功能';
$lang['compose'] = '编辑';

$lang['logout_login']='请登出,然后重新登录来测试您的新密码.';
$lang['makefeatured'] = '点击这里来添加此档案到特色档案列表';
$lang['col_head_gender_short'] = '性别';
$lang['no_subject'] = '没有主题';
$lang['admin_col_head_fullname'] = $lang['col_head_fullname'];
$lang['select_from_list'] = '--选择--';

$lang['default_tz'] = '0.00';

$lang['manage_counties'] = '县 / 区';
$lang['counties_count'] = '县 / 区总数';
$lang['insert_county'] = '添加新的县 / 区';
$lang['modify_county'] = '更改县 / 区';
$lang['county_code'] = '县 / 区 代码';
$lang['county_name'] = '县 / 区 名字';
$lang['manage_cities'] = '城 / 镇';
$lang['cities_count'] = ' 城 / 镇 总数';
$lang['insert_city'] = '添加新 城 / 镇';
$lang['modify_city'] = '更改 城 / 镇';
$lang['city_code'] = '城 / 镇 代码';
$lang['city_name'] = '城 / 镇 名字';
$lang['manage_zips'] = '邮政编码';
$lang['zips_count'] = '邮政编码总数';
$lang['insert_zip'] = '添加新的邮政编码';
$lang['modify_zip'] = '更改邮政编码';
$lang['zip_code'] = '邮政编码';
$lang['show_form'] = '显示表格:';
$lang['change_album'] = '更新';


/* Following array is for Profile Window display heading conversion */
$lang['extsearchhead'] = array(
	'Marital Status'		=> '婚姻状态',
	'Ethnicity'				=> '种族',
	'Religion'				=> '宗教',
	'Hobbies'				=> '爱好',
	'Height'				=> '身高',
	'Body Type'				=> '体型',
	'Zodiac Sign'			=> '星座',
	'Eye color'				=> '眼睛颜色',
	'Hair color'			=> '头发颜色',
	'Body art'				=> '身体艺术',
	'Best feature'			=> '最佳特征',
	'Hot spots'				=> '热点',
	'Sports'				=> '运动',
	'Favorite things'  		=> '最喜爱的东西',
	'Last reading'			=> '最新阅读物',
	'Common interests'		=> '一般兴趣',
	'Sense of humor'		=> '幽默感',
	'Exercise'				=> '运动量',
	'Daily diet'			=> '每日进食',
	'Smoking'				=> '吸烟',
	'Drinking'				=> '喝酒',
	'Job schedule'			=> '工作时间表',
	'Current annual income' => '目前年度收入',
	'Living situation'		=> '生活状态',
	'Kids'					=> '孩子',
	'Want children'			=> '想要孩子',
	'Weight'				=> '体重',
	'Employment status'		=> '就业状况',
	'Education'				=> '教育',
	'Languages'				=> '语言',
	'Referred by'			=> '介绍人',
);

/* user_stats */

$lang['your_user_stats'] = '您的用户统计数据';
$lang['other_user_stats'] = '其它用户的统计数据';

$lang['user_stats'] = '用户统计数据';
$lang['users_match_your_search'] = '符合您搜索条件的用户';
$lang['in_your_country'] = '住在您的国家的用户';
$lang['in_your_state'] = '住在您同一省份的用户';
$lang['in_your_county'] = '住在您同一区域的用户';
$lang['in_your_city'] = '住在您同一城市的用户';
$lang['in_your_zip'] = '住在您同一邮政编码的用户';
$lang['in_same_gender'] = '与您同一性别的用户';
$lang['in_same_age'] = '与您同一年龄的用户';
$lang['above_lookagestart'] = '在您所设定的最底年龄以上的用户';
$lang['below_lookageend'] = '在您所设定最高年龄以下的用户';
$lang['your_lookgender'] = '符合您的性别偏好的用户';
$lang['in_look_country'] = '住在您所搜索的国家的用户';
$lang['in_look_state'] = '住在您所搜索的省份的用户';
$lang['in_look_county'] = '住在您所搜索的区域的用户';
$lang['in_look_city'] = '住在您所搜索的城市的用户';
$lang['in_look_zip'] = '住在您所搜索的邮政编码的用户';
$lang['in_same_timezone'] = '住在您时区的用户';
$lang['album_hdr'] = '相册';
$lang['public'] = '公开';
$lang['calendar_admin'] = '日历管理';

$lang['mysettings'] = '我的设定';
$lang['user_lists'] = '文件夹';
$lang['login_settings'] = '登录设置';
$lang['no_pics'] = '没有照片';
$lang['my_page'] = '我的主页';
$lang['write_new_msg'] = '书写新的消息';
$lang['view_winkslist'] = '浏览眨眼';

// Import module
$lang['manage_import'] = '导入';
$lang['manage_import_datingpro'] = '从 DatingPro 输入';
$lang['manage_import_aedating'] = '从 aeDating 输入';
$lang['manage_import_section'] = '选择导入组件';
$lang['manage_import_select'] = '选择导入的项目';
$lang['module'] = '组件';
$lang['imported'] = '已经导入';
$lang['import'] = '导入';
$lang['empty'] = '空白';
$lang['select_section'] = '为问题选择一个部分';
$lang['import_db_configuration'] = '设置数据库的参数';
$lang['db_name'] = '数据库名:';
$lang['db_host'] = '数据库服务器:';
$lang['db_user'] = '数据库用户名:';
$lang['db_pass'] = '数据库密码:';
$lang['db_prefix'] = '数据表前缀:';


// Calendar
$lang['calendar_title'] = '日历管理';
$lang['total_calendars'] = '日历总数:';
$lang['modify_calendar'] = '更改日历';
$lang['modify_calendars'] = '更改日历';
$lang['delete_calendar'] = '删除日历';
$lang['delete_calendars'] = '删除日历';

// Calendar Events
$lang['events_title'] = '活动管理';
$lang['insert_event'] = '添加活动';
$lang['modify_event'] = '更改活动';
$lang['total_events'] = '选择的活动';
$lang['event'] = '活动:';
$lang['calendar_field'] = '日历:';
$lang['private_to'] = '私人的:';
$lang['date_from'] = '自日期:';
$lang['date_to'] = '至日期:';
$lang['col_head_calendar'] = '日历';
$lang['col_head_username'] = '用户';
$lang['col_head_fullname'] = '全名';
$lang['col_head_event'] = '活动';
$lang['col_head_datefrom'] = '自日期';
$lang['col_head_dateto'] = '致日期';
$lang['col_head_date'] = '日期';
$lang['col_head_description'] = '描述';

$lang['calendar_title'] = '日历';
$lang['calendar'] = '日历:';
$lang['event_title'] = '活动';
$lang['add_event'] = '添加活动';
$lang['delete_calendar_group_confirm_msg'] = '您确定删除这日历项目? 此操作将无法撤消.';
$lang['private_only'] = '私人';
$lang['public_only'] = '公开';
$lang['public_private'] = '公开及私人';
$lang['total_events_found'] = '搜索到的活动总数:';
$lang['start_date'] = '开始日期';
$lang['start_time'] = '开始时间';
$lang['end_date'] = '结束日期';
$lang['end_time'] = '结束时间';
$lang['event_description'] = '活动描述';

$lang['more_events'] = '更多活动 >>';
$lang['daily_events_list'] = "活动列表 ";
$lang['add_to_private'] = "添加到私人列表";
$lang['close_window'] = "关闭窗口";
$lang['main_window_closed'] = "对不起, 您已经关闭了主窗口.";
$lang['user_added1'] = "用户 ";
$lang['user_added2'] = " 添加到私人列表";
$lang['next_month'] = '下个月';
$lang['previous_month'] = '上个月';
$lang['next_week'] = '下周';
$lang['previous_week'] = '上周';
$lang['next_day'] = '后一天';
$lang['previous_day'] = '前一天';
$lang['view_day'] = '日浏览数';
$lang['view_week'] = '周浏览数';
$lang['view_month'] = '月浏览数';

$lang['watched_events'] = '您所留意的活动';
$lang['event_notification'] = '活动通知';

$lang['jump_to'] = '跳到';
$lang['ok'] = '确定';

$lang['recurring'] = "重复:";
$lang['recur_every'] = "每";

$lang['recuring_labels'] = array(
	'0' => '从来没有',
	'1' => '天',
	'2' => '周',
	'3' => '月',
	'4' => '年'
	);

$lang['calendat_filter_dates_range'] = "选择的日期范围";
$lang['calendat_filter_last_year'] = "去年";
$lang['calendat_filter_last_month'] = "上个月";
$lang['calendat_filter_last_week'] = "上周";
$lang['calendat_filter_yesterday'] = "昨天";


$lang['cannot_determine_membership'] = '无法确定您的会员等级';
$lang['no_previous_polls'] = '没有过去的投票项目.';
$lang['no_event_for_the_day'] = "这个日期没有活动";
$lang['maxsize'] = '最大允许的大小 (KB)';
$lang['views'] = '浏览数';

/******************************************/
/* ALL ERROR MESSAGES ARE DEFINED BELOW.  */
/******************************************/

// Affiliates error
$lang['affiliates_error'] = array(
	18 =>'密码不符',
	20 =>'所有的栏目都需要填写.',
	21 =>'所有的栏目都需要填写.',
	25 =>'您所输入的电子邮箱已经被使用来注册分销会员帐号. 请使用其他的电子邮箱.'
);


// Javascript error messages
$lang['admin_js_error_msgs'] = array(
	'',
	'请先选择相应的复选框.',
	'您确定要删除?',
	'您确定要删除这篇横幅广告?'
	);

$lang['admin_js__delete_error_msgs'] = array('',
	1=> '您确定要删除这部分? 此操作将无法撤消.',
	2=> '您确定要从这部分删除这问题? 此操作将无法撤消.',
	3=> '您确定要删除这问题选项? 此操作将无法撤消.',
	4=> '您确定要删除这个人档案? 此操作将无法撤消.',
	5=> '您确定要删除这新闻项目? 此操作将无法撤消.',
	6=> '您确定要删除这新闻? 此操作将无法撤消.',
	7=> '您确定要删除这文章? 此操作将无法撤消.',
	8=> '您确定要删除这投票项目? 此操作将无法撤消.',
	9=> '您确定要删除这投票项目选项? 此操作将无法撤消.',
	10=> '您确定要删除这横幅广告? 此操作将无法撤消.',
	11=> '您确定要删除这管理员? 此操作将无法撤消.',
/* Added in RC6 */
	12=>'您确定要删除这国家?',
	13=>'您确定要删除这省份?',
	14=>'您确定要删除这些国家?',
	15=>'您确定要删除这些省份?',
	16=>'当进行详细搜索时,必须加入扩展搜索头条.',
	17 => '当选择用户名范围时必须填写用户名.',
	18 => '您确定要删除这些档案? 此操作将无法撤消.',
/* Added Release 1.0 */
	19=>'您确定要删除此区域?',
	20=>'您确定要删除这些区域?',
	21=>'您确定要删除此城镇?',
	22=>'您确定要删除这些城镇?',
	23=>'您确定要删除此邮政编码?',
	24=>'您确定要删除这些邮政编码?',

	25 => '您确定要删除此活动? 此操作将无法撤消.',
	26 => '您确定要删除这些日历? 此操作将无法撤消.',
	27 => '您确定要删除此网页? 此操作将无法撤消.',
	);


// Don't use double qoutes(") in the item's text
$lang['signup_js_errors'] = array(
	'username_noblank' => '请填写用户名.' ,
	'password_noblank' => '请填写密码.',
	'old_password_noblank' => '必须填写旧密码.',
	'new_password_noblank' => '必须填写新密码.',
	'con_password_noblank' => '必须填写确认密码.',
	'firstname_noblank' => '必须填写名字.',
	'name_noblank' => '请填写您的名字.',
	'lastname_noblank' => '必须填写姓.',
	'email_noblank' => '必须填写电子邮件.',
	'city_noblank' => '必须填写城镇.',
	'zip_noblank' => '必须填写邮政编码.',
	'address1_noblank' => '必须填写至少一个地址.',
	'sectionname_noblank' => '请为这部分输入名字.',
	'sendname_noblank' => '请输入发送者名字.',
	'calendarname_noblank' => '请为这日历输入名字.',
	'comments_noblank' => '请输入您要发送评论.',
	'question_noblank' => '请输入一个问题.',
	'extsearchhead_noblank' => '请输入详细搜索头条.',
	'username_charset' => '用户名只能包含字母, 数字以及下划线 \'_\'.',
	'password_charset' => '密码只能包含字母, 数字以及下划线 \'_\'.',
	'firstname_charset' => '名字项只允许填写文字.',
	'lastname_charset' => '姓氏项只允许填写文字.',
	'city_charset' => '城市名必须是文字.',
	'zip_charset' => '邮政编码只允许输入数字.',
	'address_charset' => '请填写有效的电子邮件地址.',
	'sectionname_charset' => '部分名只允许字母.',
	'calendarname_charset' => '日历名只允许字母.',
	'sendname_charset' => '发送者名字只允许字母.',
	'name_charset' => '请在名字项中使用文字.',
	'maxlength_charset' => '请输入所允许的最长数.',
	'email_notvalid' => '电子邮件地址无效.',
	'password_nomatch' => '密码不符.',
	'password_outrange' => '密码长度必须符合指定的范围.',
	'username_outrange' => '用户名必须符合指定的范围.',
	'username_start_alpha' => '用户名必须以字母开头.',
	'ccowner_noblank' => '必须填写信用卡所有者.',
	'ccnumber_noblank' => '必须填写信用卡号码.',
	'cvvnumber_noblank' => '必须填写信用卡检测号.',
	'select_payment' => '请先选择支付方式.',
	'stateprovince_noblank' => '必须填写省份名.',
	'subject_noblank'	=> '必须填写信件主题.',
	'county_noblank' => '必须填写区域.',
	'county_charset' => '区域名字必须是字符.',
	'timezone_noblank' => '必须选择时区.',
/* Added in 2.0 */
	'ratingname_noblank' => '必须填写评价名字.',
	'ratingname_charset' => '评价名字有无效的文字.',
	'about_me_noblank' 	=> '您必须填写关于您自己的介绍.',
	);

$lang['letter_errormsgs'] = array(
		0 => '您的密码已经通过电子邮件发送给您.请检查您的电子邮件.',
		1 => '请填写您用来注册的电子邮件.',
		2 => '找不到忘记密码信件的模板. 请联系网站管理员.',
		4 => '发送电子邮件时发生问题. 请联系网站管理员.',
		5 => '您不是 SITENAME 的注册会员. 请填写您用来注册的电子邮件.'
	);

$lang['taf_errormsgs'] = array(
		0 => '邀请已经发出.',
		'sendername_noblank' => '请填写您的名字.',
		'senderemail_noblank' => '请填写您的电子邮件.',
		'recipientemail_noblank' => '请填写收信者的电子邮件.',
		'sendername_charset' => '请只使用文字填写您的名字.',
		'senderemail_charset' => '请填写有效的电子邮件.',
		'recipientemail_charset' => '请填写有效的收件者电子邮件.',
		2 => '找不到告诉朋友信件模板. 请联系网站管理员.',
		3 => '发送邀请电子邮件时发生问题. 请联系网站管理员.',
	);
$lang['pages_errormsgs'] = array( '',
	1 => '缺少网页主题.',
	2 => '缺少网页索引.',
	3 => '缺少网页内容.',
	4 => '网页索引已经存在. 请选择另一个索引.',
	5 => '网页已经被删除.',
	);

$lang['artile_error'] = array(
	1 => '文章主题项是必填项.',
	2 => '文章内容项是必填项.',
	3 => '文章日期项是必填项.'
);
$lang['story_error'] = array(
	1 => '新闻主题项是必填项.',
	2 => '新闻内容项是必填项.',
	3 => '新闻日期项是必填项.',
	4 => '新闻发送者项是必填项项.'
);
$lang['news_error'] = array(
	1 => '新闻主题项是必填项.',
	2 => '新闻内容项是必填项.',
	3 => '新闻日期项是必填项.'
);

$lang['mship_errors'] = array (
	1 => '名字项是必填项.',
	2 => '价格项是必填项.',
	3 => '外汇项是必填项.',
	4 => '当转变会员等级成免付费时, 系统将不会提供任何付费方法.'
);
$lang['admin_error_msgs'] = array (
	'',
	'部分项是必填项.',
	'请填写所有必填项.'
	);
$lang['admin_error'] = array(
	'',
	1 => '管理员用户名不能为空.',
	2 => '管理员密码不能为空.',
	3 => '管理员全名不能为空.',
	4 => '旧密码项不能为空.',
	5 => '新密码项不能为空.',
	6 => '确认密码项不能为空.',
	7 => '新密码及确认密码必须一致.',
	8 => '您所填写的旧密码不正确. 请再试一次.',
	9 => '您所填写的用户名已经被使用. 请再选另一个.',
	/* added in 1.1.0 */
	10 => '在部分名字项只可使用文字.'
);

$lang['banner_error_msgs'] = array( '',
	1 => '横幅广告项不能为空.',
	2 => '链接地址项不能为空.',
	3 => '弹出窗口注解项不能为空.',
	4 => '横幅广告项只允许 .jpg文件 .'
);
$lang['poll_error'] = array(
	1 => '投票项不能为空.',
	2 => '投票日期项不能为空.',
	3 => '选项不能为空.',
	'txtpoll_noblank'  => '投票项是必填项.',
	'txtpollopt_noblank'  => '投票选项是必填项.'
	);

$lang['datetime_month'] = array(
	1=>'一月',
	2=>'二月',
	3=>'三月',
	4=>'四月',
	5=>'五月',
	6=>'六月',
	7=>'七月',
	8=>'八月',
	9=>'九月',
	10=>'十月',
	11=>'十一月',
	12=>'十二月'
);
$lang['datetime_day'] = array(
	'sunday' => '星期日',
	'monday' => '星期一',
	'tuesday' => '星期二',
	'wednesday' => '星期三',
	'thursday' => '星期四',
	'friday' => '星期五',
	'saturday' => '星期六'
);

/* Release 1.0.2   */
$lang['settings_saved'] = '已经成功保存设置';
$lang['select_image_first'] = '请先选择图像';

/* Release 1.1.0 additions */
$lang['day_names'] = array(
	'Sun' => '星期日',
	'Mon' => '星期一',
	'Tue' => '星期二',
	'Wed' => '星期三',
	'Thu' => '星期四',
	'Fri' => '星期五',
	'Sat' => '星期六'
);
$lang['view_type'] = '浏览类型';
$lang['remember_me'] = '记住我';
$lang['review'] = '检查';
$lang['spammers'] = '垃圾信息';
$lang['addquestion'] = '添加问题';
$lang['mainstats'] = '主要统计数据';
$lang['osdate_version'] = 'osDate版本';
$lang['signonstats'] = '登录统计数据';
$lang['usersinpastminute'] = '最近一分钟的用户';
$lang['usersinpasthour'] = '最近一小时的用户';
$lang['usersinpastday'] = '最近一天的用户';
$lang['usersinpastweek'] = '最近一周的用户';
$lang['usersinpastmonth'] = '最近一个月的用户';
$lang['usersinpastyear'] = '最近一年的用户';
$lang['usersinpast2years'] = '最近两年的用户';
$lang['usersinpast5years'] = '最近五年的用户';
$lang['usersinpast10years'] = '最近十年的用户';
$lang['userstats'] = '用户统计数据';
$lang['totalusers'] = '用户总数';
$lang['totalactiveusers'] = '活跃用户数据';
$lang['totalpendingusers'] = '待处理用户数据';
$lang['totalsuspendedusers'] = '被中止用户数据';
$lang['totalpictureusers'] = '拥有照片的用户数据';
$lang['totalonlineusers'] = '在线用户';
$lang['visitorstats'] = '访问者统计数据';
$lang['sitestats'] = '网站统计数据';
$lang['visitorstosite'] = '到访者';
$lang['mostactivepage'] = '最活跃的网页';
$lang['timesfeedback'] = '反馈表单被使用的次数';
$lang['timesim'] = '即时通被使用的次数';
$lang['timeswink'] = '发送眨眼的次数';
$lang['timesmessage'] = '消息发送到收件箱的次数';
$lang['timesinvitefriend'] = '邀请朋友功能被使用的次数';
$lang['timeshowprofile'] = '显示个人档案功能被使用的次数';
$lang['timesonlineusers'] = '在线用户被点击的次数';
$lang['timesbanner'] = '横幅广告被点击的次数';
$lang['timesnewmember'] = '新会员列表被点击的次数';
$lang['timespoll'] = '投票功能被使用的次数';
$lang['timesgallery'] = '图片库功能被使用的次数';
$lang['timesaffiliates'] = '分销会员被点击的次数';
$lang['timessignup'] = '注册被点击的次数';
$lang['timesnews'] = '新闻被点击的次数';
$lang['timesstories'] = '故事被点击的次数';
$lang['timessearchmatch'] = '搜索配对被点击的次数';
$lang['no_affiliates'] = '分销会员总数';
$lang['no_affiliate_refs'] = '分销会员的下线总数';
$lang['no_pages_refs'] = '网页引用总数';
$lang['no_polls'] = '投票项目总数';
$lang['no_news'] = '新闻项目总数';
$lang['no_stories'] = '故事总数';
$lang['no_langs'] = '翻译语言版本总数';
$lang['glblgroups'] = '全局设置组别';
$lang['accept_tos'] = '我已阅读并同意<a href="javascript:popUpScrollWindow('."'tos.php','center',650,600);".'">服务条款</a>';
$lang['tos_must'] = '请在注册前阅读以及接受服务条款';
$lang['private_event'] = '此活动资料保密';
$lang['posted_by'] = '发布人';

$lang['countries01']='国家';
$lang['states01'] = '省份';
$lang['latitude'] = '纬度';
$lang['longitude'] = '经度';
$lang['search_within'] = '搜索范围';
$lang['miles'] = ' 码 ';
$lang['kms'] = ' 公里 ';
$lang['no_search_results'] = '<font color=red><b>找到 0 记录</b></font><br /><br />没有任何记录配合您的搜索条件. 或许您可以考虑扩展您的搜索范围. 请尝试减少条件的数量, 例如搜索身高以及年龄, 而不是身高, 年龄以及体型. 或者, 扩展您的搜索范围. 例如, 本来搜索年龄是 40 - 50 岁, 但是改成 30 - 60 岁.<br /><br />';
$lang['expire_on'] = '会员资格将过期';
$lang['expire_in'] = '天过后会员资格将过期';
$lang['lang_to_load'] = '载入语言';
$lang['load_lang'] = '载入语言';
$lang['manage_languages'] = '语言管理';
$lang['manage_zips'] = '管理邮政编码';
$lang['zipfile'] = '邮政编码文件';
$lang['zip_loaded'] = '从文件载入邮政编码';
$lang['file_not_found'] = '在系统里找不到所提供的文件';
/* Modified in 1.1.0 */
$lang['success_mship_change'] = '谢谢您升级 / 更新您的会员资格. <br /><br />您的会员等级已经被成功地改成';
$lang['payment_cancel'] = '取消付费';
$lang['checkout_cancel'] = '按照您的请求, 付费处理已经被取消.';
$lang['useronlinetext'] = array(
	'online_now'		=> 	'在线',
	'active_24hours'	=> 	'过去24小时活跃',
	'active_3days'		=>	'过去三天活跃',
	'active_1week'		=>	'过去一周活跃',
	'active_1month'		=>	'过去一个月活跃',
	'notactive'			=>	'近来不活跃'
);
$lang['useronlinecolor'] = array(
	'online_now'		=> 	'#FF0000',
	'active_24hours'	=> 	'#00AA00',
	'active_3days'		=>	'#AA00A0',
	'active_1week'		=>	'#0000AA',
	'active_1month'		=>	'#000000',
	'notactive'			=>	'#838383'
);

$lang['transactions_report'] = '付费交易报表达式';
$lang['trans_count'] = '交易量';
$lang['pay_no'] = '付费号码';
$lang['ref_no'] = '参考号码';
$lang['paid_thru'] = '付费者';
$lang['pay_status'] = '付费状态';
$lang['trans_rep'] = '付费报表';
$lang['expiry_interval'] = array(
	'1'		=> '24 小时',
	'3'		=>	'3 天',
	'7'		=>	'7 天',
	'15'	=>	'15 天',
	'30'	=>	'30 天',
	'0'		=>	'过期'
	);
$lang['expiry_hdr'] = '会员资格过期提醒信';
$lang['expiry_ltr'] = '会员资格过期通知信';
$lang['expiry_select'] = '选择有效期的间隔';
$lang['expird'] = '已经过期';
$lang['expiry_ltr_sent'] = '已经发送过期提醒信';
$lang['searching_within'] = '搜索';
$lang['payment_failed'] = '付费处理失败. 请在尝试付费.';
$lang['payment_fail'] = '付费失败';
$lang['deactivate'] = '中止';

$lang['open_search'] = '搜索';
$lang['replace'] = '替换';
$lang['new'] = '新';
$lang['no_save'] = '不保存';
$lang['modify_curr_search'] = '更改当前的搜索条件';
$lang['perform_search'] = '然后进行搜索.';
$lang['start_new_search'] = '开始新的搜索';
$lang['use_empty_form'] = '使用空表单.';
$lang['of_zip_code'] = '属于这个邮政编码';

/* MOD START */

$lang['profile_ratings'] = '档案评价';
$lang['total_ratings'] = '评价总数';
$lang['delete_ratings'] = '删除评价';
$lang['delete_rating_group_confirm_msg'] = '您确定要删除这个评价? 这个选择将无法取消.';
$lang['delete_rating_confirm_msg'] = '您确定要删除这个评价? 这个选择将无法取消.';
$lang['modify_rating'] = '更改评价';
$lang['modify_ratings'] = '更改评价';

$lang['glblsettings_groups']['50'] = '档案评价';
$lang['mod_lowtohigh']['Low to High'] = '由低到高';
$lang['mod_lowtohigh']['High to Low'] = '由高到低';
$lang['admin_rights']['profile_ratings'] = '档案评价';

$lang['custom_message'] = '自定义消息';
$lang['notify_me'] = '我的消息被阅读时通知我.';
$lang['include_profile'] = '在此消息中加入我的个人档案.';
$lang['message_templates'] = '消息模板';
$lang['my_templates'] = '我的模板';
$lang['template_select'] = '请选择模板';
$lang['template_intro'] = '如果您经常发送同样的消息给您潜在的配偶, 您可以为这消息创建一个模板, 以减少您输入的时间. 通过使用模板变量例如 [username] 和 [firstname], 您可以使您的模板像是个别发送给收件者.';

$lang['add_template'] = '添加模板';
$lang['return_message'] = '回到消息';
$lang['delete_template_confirm_msg'] = '您确定要删除这个模板? 这个选择将无法取消.';
$lang['edit_template'] = '更改模板';

$lang['template_instructions'] = '您可以使用以下的模板变量: <br />
[username], [firstname], [city], [state], [country], [age]<br /><br />您可以使用这些模板变量,使您的消息像是个别发送给收件者, 例如:<br /><br />嗨 [firstname]!<br /><br />我留意到您来自 [city].... 我也是! :) 我认为我们将是很好的配对... 如果您想进一步认识我, 发送电子邮件给我吧.<br /><br />cheers,<br />Jamie';

$lang['your_comment'] = '您的评论';
$lang['your_reply'] = '您的回复';
$lang['comment_note'] = '多于 255 个字符的评论将被截断';
$lang['chars_remaining'] = '个字符剩余';

$lang['delete_comment_confirm_msg'] = '您确定要删除这个评论? 此操作将无法撤消.';
$lang['no_msg_templates'] = '找不到任何消息模板.';
/* MOD END */

$lang['select'] = '- 选择 -';
$lang['select_country'] = '选择国家';
$lang['select_state'] = '选择省份';
$lang['select_county'] = '选择县区';
$lang['select_city'] = '选择城市';
$lang['confirm_success'] = '请在下面登录以享受会员的优势.';
$lang['signup_success_message'] = '<b>谢谢!</b><br /><br />&nbsp;您现在已经是 SITENAME 注册用户.';
$lang['noone_online'] = '没有会员在线';
$lang['in_hot_list'] = '用户在热门列表中';
$lang['in_buddy_list'] = '用户在好友列表中';
$lang['in_ban_list'] = '用户在禁止列列表中';
$lang['delete_search'] = '删除这个搜索';
$lang['select_user_to_send_message'] = '选择用户发送您的消息';
$lang['no_im_msgs'] = '没有即时消息';
$lang['public_event'] = '公众可以浏览这活动';
$lang['no_event_description'] = '没有提供描述';
$lang['signup_js_errors']['country_noblank'] = '请选择国家';
$lang['msg_sent'] = '您的消息已经发送';
$lang['forgotpass_msg4'] = '您忘了您的登录帐号了吗? 系统可以发送您的用户名以及一组新的密码到您的电子邮箱. 请使用您注册时使用的邮箱地址.';

/* 	Additions for new email messaging interface
	Vijay Nair
*/
$lang['send_a_message'] = '发送消息';
$lang['flagged'] = '标记';
$lang['un_flagged'] = '取消标记';
$lang['unflagged_msg1'] = '取消标记,如果它超过 ';
$lang['unflagged_msg2'] = ' 天将自动被删除.';
$lang['no_messages_in_box'] = '您的收件箱里没有消息';
$lang['no_flagged_messages_in_box'] = '这个收件箱里没有被标记的消息';
$lang['no_unflagged_messages_in_box'] = '这个收件箱里没有未标记的消息';
$lang['mark'] = '标记';
$lang['flag'] = '标记';
$lang['unflag'] = '取消标记';
$lang['msg_flagged'] = '消息被标记';
$lang['msg_unflagged'] = '取消消息的标记';
$lang['msg_deleted'] = '消息被删除';
$lang['sel_msgs_flagged'] = '已经为所选择的消息做标记';
$lang['sel_msgs_unflagged'] = '取消了所选择的消息的标记';
$lang['sel_msgs_deleted'] = '所选择的消息已经被删除';
$lang['sel_msgs_undeleted'] = '所选择的消息已经被还原';
$lang['sel_msgs_read'] = '所选择的消息已经被标记成已读';
$lang['sel_msgs_unread'] = '所选择的消息已经被标记成新消息';
$lang['FROM1'] = '来自';
$lang['no_thanks'] = '说 \"不,谢谢了\"';
$lang['reply'] = '回复';
$lang['undelete'] = '还原';
$lang['back_to_messages'] = '回到消息';
$lang['replied'] = '回复已经发送';
$lang['no_thanks_subject'] = '谢谢, 可是不需要...';
$lang['total'] = '总数';
$lang['max_allowed'] = '最大限制';
$lang['im_msg_long'] = '即时消息已经超出所允许的大小';
$lang['members'] = '会员';
$lang['To1'] = '给';

/* Items which are modified in 1.1.0 */


$lang['change_email'] = '更改邮件';

/* Changes made for letters  */
$lang['no_watched_event'] = '您没有监视任何活动.
<br /><br />在接下来的 30 天内总共有 #eventcount# 个活动. <a "#calenderlink#">打开日历</a> 浏览这些活动.
<br /><br />想监视任何一个活动, 在日历上点击相关活动, 然后点击放大镜图标. #glassicon#
<br /><br />您所添加监视的活动将在活动结束后自动停止.';

$lang['no_thanks_message']['text'] = '嗨 #recipient_username#,

谢谢你感兴趣, 可是我必须回绝您. 我希望您可以在 #site_name# 找到您的配偶.

#sender_username#';

$lang['message_read']['text'] = "亲爱的 #FirstName#,

您发送给 '#RecipientName#' 的消息已经被读取.

祝您好运!
#AdminName#
SITENAME";


$lang['featured_profile_added']['text'] = "亲爱的 #FirstName#,

我们很高兴地将您的个人档案添加到 <a href=\"#link#\">#siteName#</a> 的特色档案列表上 .

您的个人档案将从 #FromDate# 到 #UptoDate# 被列为特色档案.

这将有助于您个人档案的曝光次数, 也将增加您的个人档案被浏览的次数.

祝您好运!
#AdminName#
SITENAME";

$lang['wink_received']['text'] = "亲爱的 #FirstName#,

#siteName# 用户 '#SenderName#' 给了您一个眨眼的动作.

请访问 <a href=\"#link#\">#siteName#</a> 发送消息给 '#SenderName#' , 或者回给 '#SenderName#' 一个眨眼的动作.

祝您好运!
#AdminName#
SITENAME";

$lang['invite_a_friend']['text'] = "嗨,

我在网上浏览的时候发现了一个很酷的社交网站: #SiteUrl#.
我想您可能会感兴趣.

访问 #SiteUrl#.

#FromName#";

$lang['profile_confirmation_email']['text'] = "亲爱的 #FirstName#,

感谢您在 #SiteName# 注册! 作为我们的最新会员, 我想鼓励您先多多探索我们所提供的服务以及特色.

请点击下面的链接来确认您的个人档案. 如果链接无法被点击, 请将链接地址拷贝并粘贴到您的浏览器的地址栏里, 直接访问.

#ConfirmationLink#=#ConfCode#

如果您还打开着注册向导最后一个步骤的窗口, 您也可以直接输入您的确认码.

您的确认码是: #ConfCode#

我们已经将您以下注册信息存档:

用户名: #StrID#
密码: #Password#
电子邮件地址: #Email#

请您将这些资料保管好, 以随时使用我们所提供给您的所有服务及特色. 其中一些服务可能需要您升级您的会员等级,您可以在这里进行操作:

#SiteUrl#payment.php

再次感谢您使用我们的服务, 我们也衷心希望您早日找到您的配偶!

#AdminName#
#SiteName#";

/* Added in 1.1.1 */
$lang['loading'] = '载入..';


/* Changes in 1.1.3 */
$lang['support_currency'] = array(
		'USD' 	=> '$',
		'EUR'	=>'€',
		'INR'	=>'Rs.',
		'AUD'	=> 'AU$',
		'CD'	=> 'CAN$',
		'UKP'	=> chr(163)
		);


$lang['ratings'] = '评价';
$lang['comment'] = '评论';
$lang['comments'] = '评论';
$lang['loadaction'] = '请选择';
$lang['loadintodb'] = '载入数据库';
$lang['createsql'] = '创建 SQL 脚本';

$lang['load_zips'] = '载入邮政编码文件';



/* Version 2.0 additions and modifications */
/* Modifications */
$lang['zip_ensure'] = '请先载入邮政编码文件到 /zipcodes 文件夹,然后继续. <br /><br />此文件必须载有 邮政编码, 纬度, 经度, 地区代码, 城市代码 (根据上述顺序. 省份代码, 地区代码, 城市代码 可以暂时略去, 以后才另行加入) 分别以逗号分隔.<br /><br />要删除国家邮政编码, 请选择一个国家,然后点击删除键';
$lang['submit'] = '提交';
$lang['lang_ensure'] = '首先在 config.php 定义一个新的语言以及文件 (请注意 $language_options 和 $language_files 的定义). 然后载入相关的语言文件到 /language/lang_xxxx/ 命名成 lang_main.php, 之后再继续. (xxxx 是语言的名字,用英文小字母书写. 例如: english, dutch, 等等.).<br /><br /><b>要更改以及/或者在以存在的语言定义里添加新的语言记录, 请先在相关的语言文件里作必要的修改, 然后再重新载入.</b><br /><br />要删除已经载入的语言定义, 选择相关的语言然后点击 "从数据库删除语言" 键.';

/* $lang['rate_catefully'] is changed as below */
$lang['rate_carefully'] = '这网站拥有者不会对这些评价的可信度以及准确性作任何担保.<br />这些评价是由用户提交, 我们的员工不会审核这些评价.';


$lang['privileges'] = array (
	'chat' 				=> '参与聊天.',
	'blog'				=> '参与博客.',
	'poll'				=> '参与投票.',
	'forum'				=> '参与论坛.',
	'includeinsearch' 	=> '加入到搜索结果.',
	'message'			=> '发送消息到邮箱.',
	/* Added in 1.1.0 */
	'message_keep_cnt'  => '保存消息的数量.',
	'message_keep_days' => '保存消息的天数.',
	/* rel 2.0 */
	'messages_per_day' 	=> '每天可以发送消息的数量.',
	/* Rel 1.0 added  */
	'allowim'			=> '允许即时通讯.',
	'uploadpicture'		=> '上传图片.',
	'uploadpicturecnt'	=> '允许上传图片数量.',
	'allowalbum'		=> '允许私人相册.',
	'event_mgt'			=> '允许活动管理.',
	/* Above is added in 1.0 */
	'seepictureprofile' => '浏览个人档案图片.',
	'favouritelist'		=> '管理好友/封锁/热门列表.',
	'sendwinks'			=> '发送眨眼.',
	/* rel 2.0 */
	'winks_per_day' 	=> '每天可以发送眨眼动作的数量.',
	'extsearch'			=> '进行扩展搜索.',
	'fullsignup' 		=> '完整注册.',
	/* RC6 Patch */
	'activedays'		=> '此等级的有效期.',
	/* added in 2.0 */
	'saveprofiles'		=> '允许保存档案.',
	'saveprofilescnt'	=> '所允许保存档案的数量.',
	'allow_videos'		=> '允许视频上传.',
	'videoscnt'			=> '所允许上传视频的数量.',
	'allow_mysettings'	=> '允许设定用户偏好.',
	'allow_php121'		=> '允许 php121 即时通.',

);

/* 	Signup Error Messages
	These are the signup error messages, Please do not change the sequence.
*/

$lang['errormsgs']= array(
	00 => '',
	01 => '用户名是必填项.',
	02 => '密码是必填项.',
	03 => '确认密码是必填项.',
	04 => '名字是必填项.',
	05 => '姓氏是必填项.',
	06 => '电子邮件地址是必填项.',
	07 => '城市是必填项.',
	08 => '邮政编码是必填项.',
	09 => '地址是必填项.',
	10 => '用户名只允许最多 25 个字母.',
	11 => '名字只允许最多 50 个字母.',
	12 => '姓氏只允许最多 50 个字母.',
	13 => '电子邮件地址只允许最多 255 个字母.',
	14 => '城市只允许最多 100 个字母.',
	15 => '地址只允许最多 255 个字母.',
	16 => '用户名必须以字母开头.',
	17 => '密码必须以字母开头.',
	18 => '密码和确认密码必须相符.',
	19 => '请填写一个有效的电子邮件地址',
	20 => '所需的资料必须填写.',
	21 => '您所提供的登录资料不被允许访问系统. 请检查您的输入,然后重试.',
	22 => '用户名已经被使用, 请另选一个.',
	23 => '您所提供的旧密码不正确. 请检查您的旧密码,然后重试.',
	25 => '电子邮件地址曾经被用来注册.' ,
//	26 => "Your status is 'Not Active'. Please wait while activating or mail to administrator." ,
	27 => '无法找到消息.',
	28 => '请先选择文件.',
	29 => '系统不支持文件格式, 请另选一个',
	30 => '问题已经显示在顶部.',
	31 => '问题已经显示在底部.',
	32 => '谢谢您的建议. 您的反馈将尽快被处理.',
	33 => '您的邮政编码不符合您所选的省份.',
	34 => '邮政编码无效',
	36 => '您的帐户已经被中止. 请联系管理员以获得更多详情.',
	37 => '您的提交已经被拒绝. 请联系管理员以获得更多详情.',
	38 => '您所提供的生日不正确. 请检查您的输入,然后重试.',
	39 => '旧密码必须不同于新密码',
	40 => '最小年龄必须小于或等于最大年龄',
	51 => '开始日期必须早于结束日期',
	52 => '此会员已经在列表里',
	53 => '无效的日期',
	54 => '无效的用户名或密码',
	55 => '您必须先登录,才可以发送消息',
	56 => $lang['bigger_pic_size'],
	57 => $lang['only_jpg'],
	58 => $lang['upload_unsuccessful'],
	59 => '此档案已经加入到列表',
	60 => '缩略图尺寸超过了所允许的尺寸 ('.$config['upload_snap_tnsize'].' X '.$config['upload_snap_tnsize'].')',
	61 => '无效的激活代码',
	62 => '用户名已经从列表从中删除',
	63 => '此用户已经加入到您的好友列表',
	64 => '此用户已经加入到您的封锁列表',
	65 => '此用户已经加入到您的热门列表',
	66 => '您已经向这用户眨眼',
	67 => $lang['upload_successful'],
	68 => '图片被批准',
	69 => '图片被拒绝',
	70 => '浏览记录已被删除',
	71 => '眨眼记录已被删除',
	/* Added in RC6  */
	72 => '此用户帐号已经被重新开通',
	73 => '国家名已经添加',
	74 => '国家名已经被删除',
	75 => '国家代码或名字已经被使用',
	76 => '国家记录已经更改',
	77 => '省份名已经添加',
	78 => '省份名已经被删除',
	79 => '省份代码或名字已经被使用',
	80 => '省份记录已经更改',
	81 => '省份/辖区的名字必须填写',
	82 => '此会员没有上传任何图片. ',
	83 => '档案已经被删除',
	84 => '所选的档案已经被删除.',

	85 => '所选的档案已经被激活.',
	86 => '所选的档案已经被拒绝.',
	87 => '所选的档案已经被中止.',

	26 => '您的档案尚未被激活. 要<a href=\'completereg.php\'>激活您的帐户</a>,请填写确认码或者使用发送到您注册使用的电子邮件中的链接.',

//	26 => 'Your affiliate account hasn\'t yet been activated by an administrator. Please wait for this activation before using your affiliate account.',

	35 => '您的档案尚未被批准.<br />请等待管理员的批准或联系系统管理员',

/* Release 1.0 additions/modifications  */

	88 => '县/区已经添加',
	89 => '县/区已被被删除',
	90 => '县/区代码或名称已经被使用',
	91 => '县/区已经更改',
	92 => '城镇已经添加',
	93 => '城镇已被删除',
	94 => '城镇代码或名称已经被使用',
	95 => '城镇已经更改',
	96 => '邮政编码已经添加',
	97 => '邮政编码已被删除',
	98 => '邮政编码已经被使用',
	99 => '邮政编码已经更改',
	100 => '县/区是必填项',
	101 => '无效的密码',
	102 => '活动已经被批准.',
	103 => '活动已经被拒绝.',
	301 => '无效的时区',
	302 => '相册已经被更新',
/* 1.1.0 additions */
	104 => '无法找到您所提供的登录. 请检查您的输入,然后重试, 或者使用以下的选项来提醒.',
	105 => '用户在封锁列表上',
	/* Added in 2.0 */
	111 => '此会员已经在特色会员列表中',
	120	=> '验证码项必须填写',
	121 => '无效的验证码 ',
	122 => '您今天已经发送的消息数量已经是所允许的最高数了. 请明日再试.',
	123 => '您今天已经发送的眨眼动作数量已经是所允许的最高数了. 请明日再试.',
	124 => '视频文件已经载入',
	125 => '没有载入视步文件,因为文件上传失败.',
	126 => '您必须填写关于您自己.',
	128 => '组成配偶的个人会员的用户名必须填写.',
	129 => '用户名必须已经登记.',
	130 => '视频文件不能被转换. 请使用 .flv 格式的视频.',
	131 => '您的消息数量已经超过了您的会员级别所允许的数量',
	201 => '您已经保存了所允许的档案数量到监视列表',
	202 => '此档案已经加入到您的档案监视列表',
	203 => '此档案在监视列表中已经存在',
	);


$lang['alphanumeric'] = "0123456789.+-_#,/ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz ()_";
$lang['alphanum'] = "0123456789_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz ";
$lang['text'] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz '";
$lang['full_chars'] = "0123456789.+-_#,/ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz() _$+=;:'";
/* Additions  in Version 2.0 */

$lang['save'] = '保存';
$lang['delete_zips'] = '删除邮政编码';
$lang['zipcodes_sql_created'] = '邮政编码 sql 文件已经被创建';
$lang['zipcodes_loaded'] = '邮政编码载入自 ';
$lang['delzips_msg'] = '此国家所有的邮政编码将被删除';
$lang['delzips_succ'] = '#COUNTRY# 的邮政编码已被删除';
$lang['wrong_zipfile'] = '此文件不属于 #COUNTRY#';
$lang['load_states'] = '处理省份文件';
$lang['state_ensure'] = '请载入省份代码文件到 /states 文件夹里,然后再进行处理. <br /><br />此文件必须包含以逗号分隔的 省份代码和省份名.(无表头)<br /><br /> 要删除指定国家的省份代码, 选择相关的国家,然后点击 "删除省份代码" 按钮';
$lang['statefile'] = '省份代码文件';
$lang['delete_states'] = '删除省份代码';
$lang['delstates_msg'] = '此国家所有的省份代码将被删除';
$lang['delstates_succ'] = '#COUNTRY# 所有的省份代码已被删除';
$lang['states_sql_created'] = '省份代码 sql 文件已经被创建';
$lang['states_loaded'] = '省份代码载入自 ';
$lang['delete_lang'] = '从数据库中删除语言';
$lang['langfile_loaded'] = '#LANGUAGE# 的语言定义载入自 ';
$lang['lang_deleted'] = '#LANGUAGE# 的语言定义已被删除';
$lang['load_counties'] = '处理县区文件';
$lang['countyfile'] = '县区代码文件';
$lang['county_ensure'] = '请载入地区代码文件到 /counties 文件夹里,然后再进行处理. <br /><br />此文件必须包含以逗号分隔的 地区代码, 地区名以及省份代码.(依据顺序)<br /><br />要删除国家的县区代码, 选择相关的国家,然后点击 "删除县区代码" 键';
$lang['delete_counties'] = '删除县区代码';
$lang['delcounties_msg'] = '此国家所有的地区代码将被删除';
$lang['delcounties_succ'] = '#COUNTRY# 的地区代码已被删除';
$lang['counties_sql_created'] = '地区代码 sql 文件已经被创建 ';
$lang['counties_loaded'] = '地区代码载入自 ';
$lang['load_cities'] = '处理城市文件';
$lang['cityfile'] = '城市代码文件';
$lang['city_ensure'] = '请载入城市代码文件到 /cities 文件夹里,然后再进行处理. <br /><br />此文件必须包含以以逗号分隔的 城市代码, 城市名, 地区代码以及省份代码.(依据顺序)<br /><br /> 要删除国家的城市代码, 选择相关的国家,然后点击 "删除城市代码" 键';
$lang['delete_cities'] = '删除城市代码';
$lang['delcities_msg'] = '此国家所有的城市代码将被删除';
$lang['delcities_succ'] = '#COUNTRY# 的城市代码已被删除';
$lang['cities_sql_created'] = '城市代码 sql 文件已经被创建 ';
$lang['cities_loaded'] = '城市代码载入自 ';
$lang['online'] = '在线';
$lang['watchedprofiles_1'] = '添加到监视档案';
$lang['watchedprofiles'] = '监视档案';


$lang['poll'] = '投票';
$lang['section_poll_title'] = '投票';
$lang['section_poll_list'] = '投票列表';
$lang['section_add_poll'] = '创建投票';
$lang['poll_subtitle_list'] = '投票列表';
$lang['poll_subtitle_add'] = '创建投票';
$lang['poll_subtitle_edit'] = '更改投票';
$lang['poll_number'] = '数量';
$lang['poll_active_hdr'] = '活跃';
$lang['poll_question_hdr'] = '问题';
$lang['poll_responses_hdr'] = '回复';
$lang['no_poll_found'] = '没有找到投票项目';
$lang['poll_question'] = '问题';
$lang['poll_options'] = '选项';
$lang['poll_active'] = '活跃';
$lang['poll_minimum_two'] = '至少需要两个.';
$lang['results_poll_title'] = '结果';
$lang['poll_subtitle_results'] = '投票结果';
$lang['take_poll_title'] = '进行投票';
$lang['poll_entries'] = '投票';


$lang['plugin'] = '插件';
$lang['plugin_access'] = '会员资格使用权';
$lang['section_plugin_title'] = '插件';
$lang['section_plugin_list'] = '插件列表';
$lang['section_add_plugin'] = '载入插件';
$lang['plugin_subtitle_list'] = '插件列表';
$lang['plugin_number'] = '数量';
$lang['plugin_name'] = '名字';
$lang['plugin_active'] = '激活';
$lang['plugin_installed'] = '已经安装';
$lang['plugin_install'] = '安装';
$lang['no_plugin_found'] = '没有找到插件';
$lang['plugin_file'] = '上传插件 Zip 文件';
$lang['plugin_subtitle_edit'] = '更改插件';
$lang['add_plugin_summary'] = '您的 osDate 安装里已经包含了创建插件的说明.';

$lang['blog']['hdr'] = '博客';
$lang['admin_blog'] = '网站博客';
$lang['blog_default_bad_words'] = 'xxx|levitra';
$lang['blog_bad_words'] = '脏话';
$lang['blog_save_template'] = '保存为模板';
$lang['blog_load_template'] = '载入模板';
$lang['blog_bad_words_help'] = '(每行一句)';
$lang['blog_search_results'] = '博客搜索结果';
$lang['section_blog_info'] = '博客设置';
$lang['section_blog_list'] = '博客条目';
$lang['section_blog_title'] = '博客';
$lang['blog_search_menu'] = '博客搜索';
$lang['blog_search_username'] = '用户名';
$lang['blog_search_title'] = '主题';
$lang['blog_search_body'] = '内容';
$lang['blog_search_Date'] = '日期';

$lang['blog_subtitle_list'] = '博客列表';
$lang['blog_name'] = '博客名';
$lang['blog_description'] = '博客评论';
$lang['blog_members_comment'] = '会员评论';
$lang['blog_buddies_comment'] = '好友评论';
$lang['blog_members_vote'] = '会员投票';
$lang['blog_gui_editor'] = 'WYSIWYG 编辑器';
$lang['blog_max_comments'] = '最多所允许的评论';
$lang['no_blog_found'] = '找不到记录';
$lang['section_add_blog'] = '创建博客';
$lang['blog_subtitle_add'] = '创建博客';
$lang['blog_subtitle_edit'] = '更改博客';
$lang['blog_title'] = '主题';
$lang['blog_story'] = '内容';
$lang['blog_posted_date'] = '发布日期';
$lang['blog_title_hdr'] = '主题';
$lang['blog_rating_list_hdr'] = '评价';
$lang['blog_number'] = '数量';
$lang['blog_date_posted_hdr'] = '日期';
$lang['blog_views_hdr'] = '浏览';
$lang['blog_votes_hdr'] = '投票';
$lang['blog_votes1'] = '投票';
$lang['blog_rating_hdr'] = '根据';
$lang['blog_submit_vote'] = '投票';
$lang['blog_add_vote'] = '投票';
$lang['view_blog'] = '浏览博客';
$lang['blog_entries'] = '博客:';
$lang['blog_creator'] = '作者';
$lang['blog_comments'] = '评论';
$lang['add_comment'] = '您的评论';
$lang['total_blogs_found'] = '总共找到的博客:';

$lang['blog_errors'] = array(
   'nosetup' => '最初博客设置必须完成.' ,
   'name_noblank' => '博客名必须填写.' ,
   'description_noblank' => '博客描述必须填写. ',
   'date_posted_noblank' => '发布日期必须填写.' ,
   'title_noblank' => '主题必须填写.' ,
   'story_noblank' => '博客内容必须填写.' ,
   'max_stories_warning' => '您已经达到了最高允许的故事数目. 无法加入新的故事.' ,
   'comment_bad_word' => '您的评论里含有脏话 %s' ,
);
$lang['spell_check'] = '拼写检查';

$lang['manage_import_webdate'] = '自 Webdate 载入';
$lang['import_config'] = '设置';

$lang['forum_values'] = array(
   'None' => '无',
   'phpBB' => 'phpBB',
   'vBulletin' => 'vBulletin',
   'myBB' => 'myBB',
   'Phorum' => 'Phorum',
   );

$lang['photos_url'] = '主页 URL:';
$lang['ftp_username'] = 'FTP 用户名:';
$lang['ftp_password'] = 'FTP 密码:';
$lang['ftp_hostname'] = 'FTP 服务器地址:';
$lang['ftp_path'] = 'FTP aeDating 路径:';
$lang['ftp_path_help'] = '登录到 ftp 时 aeDating 系统文件夹的路径.  例如. public_html/aeDating';

$lang['nopicsloaded'] = '没有图片';
$lang['loadedpicscnt'] = '#PICSCNT# 图片';
$lang['loadedpicscnt1'] = '#PICSCNT# 图片';
$lang['picsloaded'] = '载入的图片';
$lang['since'] = '从';
$lang['unknown'] = '未知';

$lang['glblsettings_groups'] = array(
1	=>	'网站信息',
2	=> 	'用户管理',
3	=>	'日历管理',
4	=>	'邮件设置',
5	=>	'档案图片及缩略图',
6	=>	'网页及表格布局',
);

$lang['who_is_online'] = '仅在线用户';
$lang['search_with_photo'] = '仅有照片的用户';
$lang['search_with_video'] = '仅有视频的用户';
$lang['expire_on_hdr'] = '失效日期';
$lang['expird'] = '过期';
$lang['pics'] = '图片';
$lang['pic_deleted'] = '选中的图片已被删除';
$lang['entrycode_chars'] = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
$lang['enter_spamcode'] = '验证码';

/* Admin emails portion */

$lang['newpic']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td class="module_head" width="100%" height="25"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25"><div class="module_head">#email_hdr_left#</div>
</td><td width="493" height="25"><div class="module_head">&nbsp;&nbsp;用户载入新图片 </div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" ><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="1"></td></tr><tr><td width="50%" valign="top" class="evenrow" >亲爱的网站管理员,
<br><br>用户 <a href="#SiteUrl#admin/showprofile.php?username=#UserName#">#UserName#</a> 载入一张新图片. <br><br>用户名: #UserName#<br>图片编号.: #PicNo#<br><br>#AdminName# <br>SITENAME<br></td><td valign="top" class="evenrow" align="cemter">#smallPic#
</td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> '; 

$lang['newpic']['text'] = "亲爱的网站管理员,

用户 #UserName# 已经载入新的图片.

用户名: #UserName#
图片号码.: #PicNo#

#AdminName#
SITENAME";

$lang['newpic_sub'] = 'SITENAME 消息: 用户载入了新的图片 ';

$lang['newvideo']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25"><div class="module_head">#email_hdr_left#</div>
</td><td width="493" height="25"><div class="module_head">&nbsp;&nbsp;用户载入新视频! </div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" ><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">亲爱的网站管理员,<br><br>用户 #UserName# 载入一个新视频. <br><br>用户名: #UserName#<br>视频编号.: #PicNo#<br><br>#AdminName#<br>SITENAME<br></td>
</tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> '; 

$lang['newvideo']['text'] = "亲爱的网站管理员,

用户 #UserName# 已经载入新的视频.

用户名: #UserName#
视频编号.: #PicNo#

#AdminName#
SITENAME";

$lang['newvideo_sub'] = 'SITENAME 消息: 用户载入了新的视频 ';

/* Modified in 2.0 */
$lang['payment_msg1'] = '可用的支付方式:';

$lang['wrong_activationcode'] = '所提供的确认码不正确,或者帐户已经被确认.';

$lang['security_code_txt'] = '请阅读以下图像内的文字,然后输入到它旁边的文字栏中. 这将确保您的这个动作不是一个自动化的动作.';
$lang['additional_pics'] = '更多图片';
$lang['view_all_pics'] = '浏览所有图片';
$lang['insufficientPrivileges'] = '您无权使用这个选项. 请升级您的会员等级.';
$lang['username_part_msg'] = "如果您不确定用户名, 请输入用户名中任何的一个部分来显示所有符合的记录. 例如, 输入 'user' 将会显示 'user123', 'someuser', 等等."
;
$lang['featured_profiles_msg01'] = "必须显示: '是' 将使此档案优先被进特色档案列表里. '不' 将减少被选中的机会. ";

$lang['featured_profiles_msg02'] = "所须曝光率: 这是在结束日期前档案从特色档案列表中移除所必须被展示的次数.";
$lang['lookup'] = '获得';
/* for use in shoutbox */
$lang['sb_by'] = '发布人:';
$lang['sb_hdr'] = '大喊箱';
$lang['sb_send'] = '发送';
$lang['sb_error'] = '所输入的文字已经超过了所允许的长度';
$lang['sb_msg_blank'] = '大喊箱消息留空?';
$lang['sb_show_all'] = '显示全部';

$lang['upload_videos'] = '上传视频';
$lang['videoupload_format_msgs'] = '只允许 .swf 或 .flv 格式.';
$lang['video'] = '视频';
$lang['upload_videos_ext'] = 'flv, swf';
$lang['upload_video_caption'] = '上传视频';
$lang['video_file'] = '视频文件';
$lang['vds'] = '视频';
$lang['manage_videos'] = '管理视频';
$lang['videos_loaded'] = '载入视频';
$lang['novideos_loaded'] = '没有视频';
$lang['loadedvdocnt'] = '#PICSCNT# 视频文件';
$lang['loadedvdocnt1'] = '#PICSCNT# 视频';
$lang['video_gallery'] = '视频长廊';
$lang['picture_gallery'] = '图片长廊';


/* New timezone display values Modified in 2.0 */
// These are displayed in the timezone select box
$lang['tz']['-25'] = '-- 请选择 --';
$lang['tz']['-12.00'] = '(GMT -12:00) 埃尼威托克岛, 夸贾林环礁';
$lang['tz']['-11.00'] = '(GMT -11:00) 中途岛、萨摩亚群岛';
$lang['tz']['-10.00'] = '(GMT -10:00) 夏威夷';
$lang['tz']['-9.00'] = '(GMT -9:00) 阿拉斯加';
$lang['tz']['-8.00'] = '(GMT -8:00) 太平洋时间(美国和加拿大)';
$lang['tz']['-7.00'] = '(GMT -7:00) 山地时间(美国和加拿大)';
$lang['tz']['-6.00'] = '(GMT -6:00) 中部时间(美国和加拿大), 墨西哥城';
$lang['tz']['-5.00'] = '(GMT -5:00) 东部时间(美国和加拿大), 波哥大, 利马';
$lang['tz']['-4.00'] = '(GMT -4:00) 大西洋时间(加拿大), 加拉加斯, 拉巴斯';
$lang['tz']['-3.5'] = '(GMT -3:30) 纽芬兰';
$lang['tz']['-3.00'] = '(GMT -3:00) 巴西, 布宜诺斯艾利斯, 乔治敦';
$lang['tz']['-2.00'] = '(GMT -2:00) 中大西洋';
$lang['tz']['-1.00'] = '(GMT -1:00 hour) 亚速尔群岛, 佛得角群岛';
$lang['tz']['0.00'] = '(GMT) 西欧时间, 伦敦, 里斯本, 卡萨布兰卡';
$lang['tz']['1.00'] = '(GMT +1:00 hour) 布鲁塞尔, 哥本哈根, 马德里, 巴黎';
$lang['tz']['2.00'] = '(GMT +2:00) 加里宁格勒, 南非';
$lang['tz']['3.00'] = '(GMT +3:00) 巴格达, 利雅德, 莫斯科, 圣彼得堡';
$lang['tz']['3.5'] = '(GMT +3:30) 德黑兰';
$lang['tz']['4'] = '(GMT +4:00) 阿布扎比, 马斯喀特, 巴库, 第比利斯';
$lang['tz']['4.5'] = '(GMT +4:30) 喀布尔';
$lang['tz']['5.00'] = '(GMT +5:00) 伊卡特琳堡, 伊斯兰堡, 卡拉奇, 塔什干';
$lang['tz']['5.5'] = '(GMT +5:30) 孟买, 加尔各答, 马德拉斯, 新德里';
$lang['tz']['6.00'] = '(GMT +6:00) 阿蒙提, 达卡, 科伦坡';
$lang['tz']['6.5'] = '(GMT + 6.30) 仰光';
$lang['tz']['7.00'] = '(GMT +7:00) 曼谷, 河内, 雅加达';
$lang['tz']['8.00'] = '(GMT +8:00) 北京, 佩思, 新加坡, 香港';
$lang['tz']['9'] = '(GMT +9:00) 东京, 汉城, 大阪, 札幌, 雅库茨克';
$lang['tz']['9.5'] = '(GMT +9:30) 阿得雷德, 达尔文';
$lang['tz']['10.00'] = '(GMT +10:00) 澳大利亚东部, 关岛, 符拉迪沃斯托克';
$lang['tz']['11.00'] = '(GMT +11:00) 马加丹, 所罗门群岛, 新卡里多尼亚';
$lang['tz']['12.00'] = '(GMT +12:00) 奥克兰, 惠灵顿, 斐济, 堪察加半岛';
$lang['tz']['13.00'] = '(GMT + 13) 努库阿洛法';

$lang['myprofile'] = '我的档案';
$lang['myblog'] = '我的博客';
$lang['profilesearch'] = '档案搜索';
$lang['mylists'] = '我的列表';
$lang['bans'] = '封锁';
$lang['mybuddies'] = '我的好友';
$lang['hotprofiles'] = '热门档案';
$lang['winks'] = '眨眼';
$lang['tools'] = '工具';
$lang['picturegallery'] = '我的照片长廊';
$lang['videogallery'] = '我的影视长廊';
$lang['membership'] = '我的会员级别';
$lang['adminhome'] = '管理员主页';
$lang['membershdr'] = '会员';
$lang['memberprofiles'] = '会员档案';
$lang['membersearch'] = '会员搜索';
$lang['blogs'] = '博客';
$lang['blogsearch'] = '搜索博客';
$lang['affiliateshdr'] = '分销会员';
$lang['localities'] = '地区';
$lang['contenthdr'] = '内容';
$lang['financial'] = '财务';
$lang['plugins_hlp'] = '只有拥有特定权限的管理员可以使用管理插件, 这插件在激活之后会自动出现在管理员菜单的左下角. 会员插件可以从会员面板内使用';

/* HTML and some text emails */
$lang['no_thanks_message']['html'] = '嗨 #recipient_username#,<br><br>谢谢您感兴趣, 可是我必须回绝您. 我希望您可以在 #site_name# 找到您的配偶.<br><br>祝您好运,<br><br><br><br>#sender_username#';


/* old format
$lang['wink_received']['html'] = "Dear #FirstName#,<br><br>You have received a wink from #siteName# user '#SenderName#'.<br><br>Please visit <a href=\"#link#\">#siteName#</a> to send '#SenderName#' a message, or to reciprocate the wink.<br><br>Good Luck!<br>#AdminName#";
$lang['letter_winkreceived_sub'] = '#SITENAME# - You received a wink';

New format below
*/

$lang['mail']['hdr_text'] = '<font style="color:red; font-size: 9px;">如果要停止接收此类邮件, 请<a href="#SiteUrl#">登录</a>, 然后通过用户菜单更改您的订阅偏好.<br>为了确保您可以收取这些电子邮件, 请添加 <a href="mailto:#AdminEmail#">#AdminEmail#</a> 到您电子邮件的地址簿上.</font><br><br>';
$lang['mail']['hdr_html'] = '<table border=0 cellspacing=0 cellpadding=0 width="570"><tr><td style="padding: 5px;"><font style="color:red; font-size: 9px;">如果要停止接收此类邮件, 请<a href="#SiteUrl#">登录</a>, 然后通过用户菜单更改您的订阅偏好.<br>为了确保您可以收取这些电子邮件, 请添加 <a href="mailto:#AdminEmail#">#AdminEmail#</a> 到您电子邮件的地址簿上.</font></td></tr><tr><td height="6"></td></tr></table>';

$lang['letter_winkreceived_sub'] = 'SITENAME 消息: #SenderName# 向您眨眼! ';
$lang['wink_received']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25px">#email_hdr_left#</td><td width="493" height="25" ><div class="module_head">&nbsp;&nbsp;#SenderName# 向您眨眼!!</div>
</td></tr></table></div></td></tr><tr><td width="570" class="evenrow" colspan="2" ><div class="evenrow" ><table border="0" cellspacing="2" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="50%" valign="top">#smallProfile#</td><td width="50%" valign="top">从众多会员中, #SenderName# 选择了向您眨眼! 您可以选择回敬眨眼来培养感情, 或者发送一封电子邮件.<br><br><a href="#SiteUrl#compose.php?recipient=#UserId#">现在就给 #SenderName# 发邮件</a><br><br><a href="#SiteUrl#sendwinks.php?ref_id=#UserId#&amp;rtnurl=showprofile.php">回敬眨眼</a><br>
<br><b>没有兴趣?</b><br>请发送 "不, 谢谢" 的消息礼貌地让 #SenderName# 知道您没有兴趣<br><br><a href="#SiteUrl#compose.php?recipient=#UserId#&amp;reply=11">说 "不, 谢谢"</a><br><br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> '; 

/* old format
$lang['profile_confirmation_email']['html'] = "Dear #FirstName#,<br><br>Thank you for registering with #SiteName#! As the newest member of our community, I encourage you to explore our services and features.<br><br>To confirm your profile addition, please click the link below. Or, if the link is not clickable, copy and paste it into address bar of your web browser, to directly access it.<br><br><a href=\"#ConfirmationLink#=#ConfCode#\">#ConfirmationLink#=#ConfCode#</a><br><br>If you still have the final step of the registration wizard open, you can input your confirmation code on that screen.<br><br>Your confirmation code is: #ConfCode#<br><br>We have recorded the following registration information for you:<br><br>Username: #StrID#<br>Password: #Password#<br>E-Mail: #Email#<br><br>Please keep this information in a safe, secure place, so that you will be able to access all of the services and features available to you. Some services may require an upgrade to a higher membership level, which you can do here:<br><br>#SiteUrl#payment.php<br><br>Thanks again for using our services, and we hope that you find your match!<br><br>#AdminName#<br>#SiteName#";

New format below
*/
$lang['profile_confirmation_email_sub'] = 'SITENAME 消息: 谢谢您在 SITENAME 注册!';
$lang['profile_confirmation_email']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570">
<tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%">
<tr><td width="77" height="25" >#email_hdr_left#</td><td width="493"  height="25"><div class="module_head">&nbsp;&nbsp;#Welcome#!</div></td></tr></table></div></td></tr><tr><td width="570" class="evenrow" colspan="2" >
<div class="evenrow" ><table border=0 cellspacing=0 cellpadding=5 width="100%"><tr><td>亲爱的 #FirstName#,<br><br>感谢您在#siteName#注册! 作为我们社区的新会员, 我建议您先多多探索我们所提供的服务及特色.<br><br>要确认增加您的档案, 请点击下面的链接. 或者, 如果链接不能被点击, 请将链接地址拷贝并粘贴到您浏览器的地址栏中直接访问.<br><br>
<a href=\"#ConfirmationLink#=#ConfCode#\">#ConfirmationLink#=#ConfCode#</a><br><br>如果您还打开着注册向导最后一个步骤的窗口, 您也可以直接输入您的确认码.<br><br>您的确认码是: <b>#ConfCode#</b><br><br>我们已经为您记录以下注册信息:<br>
<br>用户名: <b>#StrID#</b><br>密码: <b>#Password#</b><br>电子邮件: <b>#Email#</b><br><br>请您将这些资料保管好, 以便随时访问我们为您提供的所有服务及特色. 其中一些服务可能需要您升级您的会员等级, 您可以在此进行操作:<br><br><a href="#SiteUrl#payment.php">#Upgrade#</a><br><br>再次感谢您使用我们的服务, 我们也衷心希望您早日找到您的配偶! <br><br>
#AdminName#<br>#siteName#</td></tr></table></div></td></tr>
<tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

/* old format
$lang['message_received']['text'] = "Dear #FirstName#,

You have received a message from SITENAME user '#SenderName#'.

Please visit <a href=\"#link#\">SITENAME</a> to reply to this message.

Good Luck!
#AdminName#";

$lang['message_received']['html'] = "Dear #FirstName#,<br><br>You have received a message from #siteName# user '#SenderName#'.<br><br>Please visit <a href=\"#link#\">#siteName#</a> to reply to this message.<br><br>Good Luck!<br>#AdminName#";

New format below
*/
$lang['message_received_sub'] = 'SITENAME 消息: 您有一条新消息';
$lang['message_received']['text'] = "亲爱的 #FirstName#,

SITENAME 用户 '#SenderName#' 给您发送了一条消息.

请访问 <a href=\"#link#\">SITENAME</a> 回复这个消息.

祝你好运!
#AdminName#
SITENAME";

$lang['message_received']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25"><div class="module_head">
#email_hdr_left#</div></td><td width="493" ><div class="module_head">&nbsp;&nbsp;来自 #SenderName# 的一条新消息! </div></td></tr></table></div></td></tr><tr><td width="570" class="evenrow" colspan="2" ><div class="evenrow" ><table border="0" cellspacing="2" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="50%" valign="top" class="evenrow">
<table width="100%" border=0 cellspacing=0 cellpadding=0><tr><td width="25%" ><div class="newshead">#From#:</div></td><td width="75%">#SenderName#</td></tr><tr><td><div class="newshead">#TO#:</div></td><td>#UserName#</td></tr><tr><td  >
<div class="newshead">#Date#:</div></td><td>#MESSAGE_DATE# </td></tr><tr><td ><div class="newshead">#Subject#:</div></td><td>#MSG_SUBJECT#</td></tr><tr><td colspan="2" height="6">
</td></tr><tr><td colspan=2>亲爱的 #FirstName#,<br><br>您收到了一条 #SenderName# 发送的消息.<br><br>请访问 <a href=\"#link#\">SITENAME</a> 回复消息. <br><br>祝您好运!<br>#AdminName#<br>SITENAME<br></td></tr></table>
</td><td width="50%" valign="top" class="oddrow"><div class="oddrow">#smallProfile#</div></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

/* Old format
$lang['letter_featuredprofile_sub'] = '#SITENAME# - Featured Profiles List';
$lang['featured_profile_added']['html'] = "Dear #FirstName#,<br><br>It gives us great pleasure to include your profile in the Featured Profiles List on <a href=\"#link#\">#siteName#</a>.<br><br>Your profile will be featured from #FromDate# to #UptoDate#.<br><br>This will increase your profile visibility and may result in many more views from prospective matches.<br><br>Good Luck!<br>#AdminName#";

new format
*/
$lang['letter_featuredprofile_sub'] = 'SITENAME 消息: 您的档案近期内将被标记成特色档案!';
$lang['featured_profile_added']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr>
<td width="77" height="25" ><div class="module_head">#email_hdr_left#</div>
</td><td width="493" ><div class="module_head">&nbsp;&nbsp;您的档案近期内将被标记成特色档案! </div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" >
<div class="evenrow"><table border="0" cellspacing="0" cellpadding="5"><tr><td width="100%" valign="top" class="evenrow">亲爱的 #FirstName#,<br><br>
我们很高兴将您的个人档案在 <a href=\"#link#\">SITENAME</a> 列为特色档案.<br><br>您的个人档案将从 <b>#FromDate#</b> 到 <b>#UptoDate#</b> 被标记成特色档案.<br>
<br>这将增加您的档案的曝光率并且可以让更多可能成为您的配偶的会员看到您的档案.<br><br>祝您好运!<br>#AdminName# <br>SITENAME<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

/* old format

$lang['profile_activated_sub'] = '#SITENAME# - Your profile is activated';
$lang['profile_activated']['html'] = "Dear #FirstName#,<br><br>This is an automatic notification to inform you that your profile on #siteName# has been activated with the membership level of #MembershipLevel#. Come visit us soon at <a href=\"#link#\">#siteName#</a>.<br><br>Good Luck!<br>#AdminName#";

new format */

$lang['profile_activated_sub'] = 'SITENAME 消息:  您的档案已经被激活!';
$lang['profile_activated']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" ><div class="module_head">
#email_hdr_left#</div></td><td width="493"><div class="module_head">&nbsp;&nbsp;您的个人档案已经被激活!</div></td></tr></table></div></td></tr><tr>
<td width="100%" class="evenrow" colspan="2"><div class="evenrow"><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr>
<tr><td width="100%" valign="top" class="evenrow">亲爱的 #FirstName#,<br><br>我们很高兴的欢迎您光临 SITENAME. <br><br>您的档案已经被激活, 会员等级是 <b>#MembershipLevel#</b> 有效期至 #ValidDate#.<br><br>请尽快访问 <a href=\"#link#\">SITENAME</a>.<br>
<br>祝您好运!<br>#AdminName# <br>SITENAME<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['profile_activated']['text'] = "亲爱的 #FirstName#,

我们很高兴的欢迎您光临 SITENAME.

您的个人档案已经被激活, 会员等级是 <b>#MembershipLevel#</b> 有效期至 <b>#ValidDate#</b>.

请尽快访问 <a href=\"#link#\">SITENAME</a>.

祝您好运!
#AdminName#
SITENAME";

/* old format
$lang['profile_reactivated_sub'] = '#SITENAME# - Your profile is reactivated';
$lang['profile_reactivated']['html'] = "Dear #FirstName#,<br><br>This is an automatic notification to inform you that your profile on #siteName# has been reactivated with the 会员等级 of #MembershipLevel#. Come visit us soon at <a href=\"#link#\">#siteName#</a>.<br><br>Good Luck!<br>#AdminName#";

New format
*/
$lang['profile_reactivated_sub'] = 'SITENAME 消息: 您的档案已经被重新激活!';
$lang['profile_reactivated']['text'] = "亲爱的 #FirstName#,

我们很高兴通知您, 您的个人档案已经被重新激活,会员等级是 <b>#MembershipLevel#</b> 有效期到 <b>#ValidDate#</b>.

请尽快访问 <a href=\"#link#\">SITENAME</a>.

祝您好运!
#AdminName#
SITENAME";

$lang['profile_reactivated']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head">
<div class="module_head">#email_hdr_left#</div></td><td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;您的档案已经被重新激活! </div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2">
<div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">亲爱的 #FirstName#,<br><br>我们很高兴通知您的个人档案已经被重新激活,会员等级是 <b>#MembershipLevel#</b> 有效期至 <b>#ValidDate#</b>.<br>
<br>Come visit us soon at <a href=\"#link#\">SITENAME</a>.<br><br>祝您好运!<br>#AdminName# <br>SITENAME<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

/* old format
$lang['added_banlist_sub'] = '#SITENAME# - Information message';
$lang['added_buddylist_sub'] = '#SITENAME# - Information message';
$lang['added_hotlist_sub'] = '#SITENAME# - Information message';

$lang['added_buddylist']['html'] = "Dear #FirstName#,<br><br>You have been added to #SenderName#'s Buddy List.<br><br>To view this user's profile, please visit <a href=\"#link#\">#siteName#</a>.<br><br>Good Luck!<br>#AdminName#";

$lang['added_hotlist']['html'] = "Dear #FirstName#,<br><br>You have been added to #SenderName#'s Hot List.<br><br>To view this user's profile, please visit <a href=\"#link#\">#siteName#</a>.<br><br>Good Luck!<br>#AdminName#";

$lang['added_banlist']['html'] = "Dear #FirstName#,<br><br>You have been added to #SenderName#'s Ban List.<br><br>To view this user's profile, please visit <a href=\"#link#\">#siteName#</a>.<br><br>#AdminName#";

$lang['added_buddylist']['text'] = "Dear #FirstName#,

You have been added to #SenderName#'s Buddy List.

To view this user's profile, please visit <a href=\"#link#\">#siteName#</a>.

Good Luck!
#AdminName#
SITENAME";

$lang['added_hotlist']['text'] = "Dear #FirstName#,

You have been added to #SenderName#'s Hot List.

To view this user's profile, please visit <a href=\"#link#\">#siteName#</a>.

Good Luck!
#AdminName#
SITENAME";

$lang['added_banlist']['text'] = "Dear #FirstName#,

You have been added to #SenderName#'s Ban List.

To view this user's profile, please visit <a href=\"#link#\">#siteName#</a>.

#AdminName#";

New format
*/
$lang['added_list_sub'] = "SITENAME 消息: 您已经被添加到 #SenderName# 的 #ListName#!";
$lang['added_list']['text'] = "亲爱的 #FirstName#,

会员 #SenderName# 已经将您添加到他的 #ListName#.

要浏览此用户的档案, 请访问 <a href=\"#link#\">SITENAME</a>.

祝您好运!
#AdminName#
SITENAME";
$lang['added_list']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25px" class="module_head">
<div class="module_head">#email_hdr_left#</div></td><td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;您已经被添加到 #SenderName# 的 #ListName#!</div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" >
<div class="evenrow"><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="50%" valign="top" class="evenrow">亲爱的 #FirstName#,<br><br>会员 <b>#SenderName#</b> 已经将您添加到他的 <b>#ListName#</b>.<br><br>要浏览此用户的档案, 请访问 <a href=\"#link#\">SITENAME</a>.<br><br>祝您好运!<br>#AdminName# <br>SITENAME<br></td><td valign="top">#smallProfile#</td>
</tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

/* old format
$lang['invite_a_friend_sub'] = 'Invite a Friend';
$lang['invite_a_friend']['html'] = "Hi,<br><br>I found a cool dating site while surfing the web: #Link#.<br>I thought it might be interesting to you.<br><br>#FromName#";

New format
*/
$lang['invite_a_friend_sub'] = "SITENAME 消息: 来自 #FromName# 的邀请! ";
$lang['invite_a_friend']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="27" class="module_head" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" valign="top" ><div class="module_head" >#email_hdr_left#</div>
</td>
<td width="493" ><div class="module_head" >&nbsp;&nbsp;来自 #FromName# 的邀请!</div></td></tr></table></div></td></tr><tr><td width="100%" colspan="2" ><div class="evenrow"><table border="0" cellspacing="0" cellpadding="5" width="100%"><tr><td height="1"></td></tr><tr><td width="100%" valign="top" class="evenrow">嗨,<br><br>在上网的时候, 我发现了一个很酷的交友网站: <a href=\"#SiteUrl#\"><b>SITENAME</b></a><br>我想你可能会感兴趣.<br>
<br>访问 <a href=\"#SiteUrl#\">SITENAME</a>.<br><br>祝您好运!<br>#FromName# <br><br></td></tr></table></div>
</td></tr><tr><td height="6" class="evenrow" colspan="2" ></td></tr></table>';

/* old format
$lang['message_read_sub'] = '#SITENAME# - Information message';
$lang['message_read']['html'] = "Dear #FirstName#,<br><br>The message you sent to '#RecipientName#' has been read.<br><br>Good Luck!<br>#AdminName#";

New format */
$lang['message_read_sub'] = 'SITENAME 消息: 您发送给 #RecipientName#  的消息已经被阅读!';
$lang['message_read']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25">
<div class="module_head">#email_hdr_left#</div></td><td width="493" ><div class="module_head">&nbsp;&nbsp;您发送给 #RecipientName# 的消息已经被阅读! </div></td></tr></table></div></td></tr>
<tr><td width="100%" class="evenrow" colspan="2" >
<div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="50%" valign="top" class="evenrow">亲爱的 #FirstName#,<br><br>您发送给 <b>#RecipientName#</b> 的消息已经被阅读.<br><br>想浏览此用户的档案, 请访问 <a href=\"#link#\">SITENAME</a>.<br><br>祝您好运!<br>#AdminName# <br>SITENAME<br></td>
<td valign="top">#smallProfile#</td></tr></table>
</div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';


/* old format
$lang['email_feedback_subject'] = 'Feedback from user of '.SITENAME;
$lang['feedback_email_to_admin']['text'] = 'Dear Site Administrator,

You have just received comments from a visitor to your dating site. The details are as follows:

Title: #txttitle#
Name: #txtname#
Email: #txtemail#
Country: #txtcountry#
Comments: #txtcomments#

Thanks,
#SITENAME# Daemon';

$lang['feedback_email_to_admin']['html'] = 'Dear Site Administrator,<br><br>You have just received comments from a visitor to your dating site. The details are as follows:<br><br>Title: #txttitle#<br>Name: #txtname#<br>Email: #txtemail#<br>Country: #txtcountry#<br>Comments: #txtcomments#<br><br>Thanks,<br>#SITENAME# Daemon';

New format */
$lang['email_feedback_subject'] = 'SITENAME 消息: 用户的反馈 ';
$lang['feedback_email_to_admin']['text'] = '亲爱的管理员,

您刚接收到来自您网站的访问者的建议,以下是详细的内容:

题目: #txttitle#
名字: #txtname#
电子邮件: #txtemail#
国家: #txtcountry#
建议: #txtcomments#

谢谢,
SITENAME Daemon';
$lang['feedback_email_to_admin']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25"><div class="module_head">
#email_hdr_left#</div></td><td width="493"><div class="module_head">&nbsp;&nbsp;用户的反馈 <div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" ><div class="evenrow" >
<table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr>
<tr><td width="100%" valign="top" class="evenrow">亲爱的管理员,<br><br>您刚刚收到来自您网站的访问者的邮件. 以下是详细的内容:<br><br><table cellspacing="4" cellpadding="2" border="0" width="100%"><tr><td width="20%"> 标题:</td><td width="80%">#txttitle# </td></tr><tr><td>姓名:</td> <td>#txtname#</td></tr>
<tr><td>Email:</td><td>#txtemail#</td></tr><tr><td>国家:</td><td>#txtcountry#</td></tr><tr><td>意见:</td><td>#txtcomments#</td></tr></table><br>谢谢,<br>#siteName# 后台程序<br><br></td></tr></table></div></td></tr></table> ';

/* old format
$lang['forgot_password_sub'] = 'Password Request';
$lang['forgot_password']['text'] = "Dear #Name#,

Your member ID: #ID#
Your password:  #Password#

To login, go here: #LoginLink#.

Thank you for using our services!

#SiteTitle# mail delivery system
<Auto-generated e-mail, please do not reply>";
$lang['forgot_password']['html'] = "Dear #Name#,<br><br>Your member ID: #ID#<br>Your password: #Password#<br><br>To login, go here: #LoginLink#.<br><br>Thank you for using our services!<br><br>#SiteTitle# mail delivery system<br><Auto-generated e-mail, please do not reply>";



New format */
$lang['forgot_password_sub'] = 'SITENAME 消息: 您的密码重设请求';
$lang['forgot_password']['text'] = "亲爱的 #Name#,

此电子邮件回复您的密码重设要求.

您的会员 ID: #ID#
您的新密码:  #Password#

登录系统, 请点击这里: #LoginLink#.

感谢您使用我们的服务!

#AdminName#
SITENAME";
$lang['forgot_password']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head"><div class="module_head">#email_hdr_left#</div></td>
<td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;您的密码重设请求</div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" ><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">亲爱的 #Name#,<br>
<br>此信息回复您的密码重设请求.<br><br>您的会员编码: <b>#ID#</b><br>您的新密码: <b>#Password#</b><br><br>登录系统, 请点击这里: <a href=\"#LoginLink#\">SITENAME</a>.<br><br>感谢您使用我们的服务!<br><br>#AdminName#<br>SITENAME<br></td></tr> </table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';


/* old format
$lang['expiry_ltr_sub'] = 'Reminder of Membership Expiry';
$lang['mship_expired_note']['text'] = "Dear #FirstName#,

This is an automatic notification to inform you that your Membership level of #MembershipLevel# in #siteName# expired on #ExpiryDate#.

Please <a href=\"#link#\">login to  #siteName#</a> to renew your membership and continue to enjoy our services.

Good Luck!
#AdminName#";
$lang['mship_expired_note']['html'] = "Dear #FirstName#,<br><br>This is an automatic notification to inform you that your Membership level of #MembershipLevel# in #siteName# expired on #ExpiryDate#.<br><br>Please <a href=\"#link#\">login to  #siteName#</a> to renew your membership and continue to enjoy our services.<br><br>Good Luck!<br>#AdminName#";

New format */
$lang['expiry_ltr_sub'] = 'SITENAME 消息: 会员资格过期提醒';

$lang['mship_expired_note']['text'] = "亲爱的 #FirstName#,

谢谢您使用 SITENAME!

我们想提醒您在 SITENAME 的会员资格, #MembershipLevel#, 已经在 #ExpiryDate# 过期.

请 <a href=\"#link#\">登录 SITENAME</a> 更新您的会员资格以便继续使用我们的服务.

祝您好运!
#AdminName#
SITENAME";

$lang['mship_expired_note']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head"><div class="module_head">#email_hdr_left#</div></td>
<td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;您的会员资格已经过期! </div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" ><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">亲爱的 #FirstName#,<br>
<br>感谢您使用 SITENAME!<br><br>我们想提醒您在 <a href="\"#link#\"><b>SITENAME</b></a> 的 <b>#MembershipLevel#</b> 级会员资格已经于 <b>#ExpiryDate#</b> 过期.<br><br>请 <a href=\"#link#\">登录 SITENAME</a> 更新您的会员资格以便继续使用我们的服务.<br><br>祝您好运!<br>#AdminName# <br>SITENAME<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

/* old format
$lang['mship_expiry_note']['text'] = 'Dear #FirstName#,

This is an automatic notification to inform you that your Membership with #siteName# will expire on #ExpiryDate#.

Please <a href="#link#">log in to #siteName#</a> and renew your membership.

Good Luck!
#AdminName#';

$lang['mship_expiry_note']['html'] = 'Dear #FirstName#,<br><br>This is an automatic notification to inform you that your Membership with #siteName# will expire on #ExpiryDate#.<br><br>Please <a href="#link#">log in to #siteName#</a> and renew your membership.<br><br>Good Luck!<br>#AdminName#';


New format */
$lang['mship_expiry_note']['text'] = '亲爱的 #FirstName#,

谢谢您使用 SITENAME!

我们想提醒您在 SITENAME 的 #MembershipLevel# 级会员资格将在 #ExpiryDate# 过期.

请 <a href="#link#">登录 SITENAME</a> 更新您的会员资格以便继续使用我们的服务.

祝您好运!
#AdminName#
SITENAME';

$lang['mship_expiry_note']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head">
<div class="module_head">#email_hdr_left#</div></td><td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;您的会员资格将过期! </div></td></tr></table></div></td></tr>
<tr><td width="100%" class="evenrow" colspan="2" ><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">亲爱的 #FirstName#,<br><br>感谢您使用 SITENAME!<br><br>我们想提醒您在 <a href="\"#link#\"><b>SITENAME</b></a> 的 <b>#MembershipLevel#</b> 级会员资格将于 <b>#ExpiryDate#</b> 过期.<br><br>请 <a href=\"#link#\">登录 SITENAME</a> 更新您的会员资格以便继续使用我们的服务.<br>
<br>祝您好运!<br>#AdminName# <br>SITENAME<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

/* Newly added - mail to be sent to member when admin changes membership level */

$lang['profile_membership_changed_sub'] = 'SITENAME 消息:  您的会员等级已经更改!';
$lang['profile_membership_changed']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head">
<div class="module_head">#email_hdr_left#</div></td><td width="493" class="module_head" height="25"><div class="module_head">&nbsp;&nbsp;您的会员等级已经更改! </div></td></tr></table></div></td></tr>
<tr><td width="100%" class="evenrow" colspan="2"><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">亲爱的 #FirstName#,<br><br>您当前的会员等级已由 <b>#CurrentLevel#</b> 变成 <b>#NewLevel#</b>, 将于 <b>#ValidDate#</b> 过期.<br>
<br>请尽快访问 <a href=\"#link#\">SITENAME</a>.<br><br>祝您好运!<br>#AdminName# <br>SITENAME<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['profile_membership_changed']['text'] = "亲爱的 #FirstName#,

您当前的会员等级 <b>#CurrentLevel#</b> 已经更改成 <b>#NewLevel#</b>, 有效日期到 <b>#ValidDate#</b>.

请尽快访问 <a href=\"#link#\">SITENAME</a>.

祝您好运!
#AdminName#
SITENAME
";

$lang['comment_received_sub'] = 'SITENAME 消息: 有位用户在您的博客上添加了新的评论';
$lang['comment_received']['text'] = "亲爱的 #FirstName#,

您刚从 SITENAME 用户 '<b>#SenderName#</b>' 接收到新的评论.

请访问 <a href=\"#link#\"><b>SITENAME</b></a> 浏览 '<b>#SenderName#</b>' 的评论.

祝您好运!
#AdminName#
SITENAME";

$lang['comment_received']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head"><div class="module_head">#email_hdr_left#</div></td><td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;有用户在您的博客上添加了新的评论! </div></td></tr></table></div></td></tr>
<tr><td width="100%" class="evenrow" colspan="2"><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">亲爱的 #FirstName#,<br><br>您刚刚收到来自 SITENAME 用户 <b>#SenderName#</b> 的评论.<br><br>请访问 <a href=\"#link#\"><b>SITENAME</b></a> 浏览 <b>#SenderName#</b> 的评论.<br>
<br>祝您好运!<br>#AdminName# <br>SITENAME<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';
$lang['aff_added_sub'] = 'SITENAME Message: You are added as an affiliate!';

$lang['aff_added_sub'] = 'SITENAME 消息: 您已经被添加成分销会员!';
$lang['aff_added']['text'] = "亲爱的 #Name#,

我们很高兴通知您已经被添加成 SITENAME 的分销会员.

您的编码: #Affid#
您的密码: #Password#

请访问 <a href=\"#SiteUrl#\"><b>SITENAME</b></a> ,尽快登录到分销会员部分更改您的密码.

祝您好运!
#AdminName#
SITENAME";

$lang['aff_added']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head"><div class="module_head">#email_hdr_left#</div></td><td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;您已经被添加成分销会员! </div></td></tr></table></div></td></tr>
<tr><td width="100%" class="evenrow" colspan="2"><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">亲爱的 #Name#,<br><br>我们很高兴通知您已经被添加成 SITENAME 的分销会员..<br><br><b>您的编码: #Affid#</b><br><b>您的密码: #Password#</b><br><br>请访问 <a href=\"#SiteUrl#\"><b>SITENAME</b></a> 尽快登录到分销会员部分更改您的密码.<br><br>祝您好运!<br>#AdminName# <br>SITENAME<br></td>
</tr></table></div>
</td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['aff_newpwd_sub'] = 'SITENAME 消息: 您的分销会员帐户!';
$lang['aff_newpwd']['text'] = "亲爱的 #Name#,

依您的要求, 系统已经为您在 SITENAME 的分销会员帐户重新生成一组新密码.

您的新密码: #Password#

请访问 <a href=\"#SiteUrl#\"><b>SITENAME</b></a> ,尽快登录到分销会员部分更改您的密码.

祝您好运!
#AdminName#
SITENAME";

$lang['aff_newpwd']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head"><div class="module_head">#email_hdr_left#</div></td>
<td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;您的分销会员帐户! </div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2"><div class="evenrow"><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">亲爱的 #Name#,<br><br>应您的请求, 系统已经为您在 SITENAME 的分销会员帐户重新生成一个新密码.<br>
<br><b>您的密码: #Password#</b><br><br>请访问 <a href=\"#SiteUrl#\"><b>SITENAME</b></a> 尽快登录到分销会员部分更改您的密码.<br><br>祝您好运!<br>#AdminName# <br>SITENAME<br></td></tr></table></div>
</td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['add_affiliate'] = '添加分销会员';
$lang['mod_affiliate'] = '更改分销会员';
$lang['aff_modified'] = '分销会员资料已经被更改';

$lang['newuser']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head"><div class="module_head">#email_hdr_left#</div></td>
<td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;新用户注册!</div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" ><div class="evenrow"><table border="0" cellspacing="0" cellpadding="5"><tr><td width="100%" valign="top" class="evenrow">亲爱的网站管理员,<br><br>有新用户在 #siteName# 注册.<br><br>用户名: <a href="#SiteUrl#admin/showprofile.php?username=#UserName#">#UserName#</a><br><br>#AdminName# <br>#siteName#<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['newuser']['text'] = "亲爱的管理员,

有新用户在 #SiteName# 注册.

用户名: #UserName#

#AdminName#
#siteName#";

$lang['newuser_sub'] = '新用户注册';

/* Following user options are managed. Please modify only the description and not these keys */

$lang['user_choices'] = array(
	'email_message_received' 	=> "当接收到新消息时发送电子邮件通知.",
	'email_wink_received'		=> "有人对我眨眼时发送电子邮件通知.",
	'email_blog_commented'		=> "有人在我的博客添加评论时发送电子邮件通知.",
	'email_mship_expiry'		=> "发送会员资格过期提醒电子邮件.",
	'email_message_read'		=> "当接收者阅读我所发送的消息时发送电子邮件通知.",
	'email_buddy_list'			=> "有人添加我进好友列表时发送电子邮件通知.",
	'email_ban_list'			=> "有人添加我进封锁列表时发送电子邮件通知.",
	'email_hot_list'			=> "有人添加我进热门列表时发送电子邮件通知.",
	"allow_buddy_view_album"	=> "允许我的好友列表上的用户观看我的私人相册.",
	"allow_hotlist_view_album"	=> "允许我的热表上的用户观看我的私人相册.",
	'email_match_mail_days'		=> "发送 '我的配对' 电子邮件的频率(以天数为单位). 如果您不想接收这些电子邮件,请填写 0.",
	);
$lang['mysettings_updated'] = '您的接收电子邮件偏好已经被更新.';
$lang['mysettings_updated'] = '您的接收电子邮件偏好已经被更新';
$lang['resend_conflink_hdr'] = '重新发送确认电子邮件';
$lang['resend_conflink_hdr1'] = '注册后遗失了或者没有接收到您的确认电子邮件? 请填写您用来注册的电子邮件以便系统重新发送您的确认电子邮件.';
$lang['resend_conflink_msg'] = '您的确认电子邮件已经重新寄出.';
$lang['resend_conflink_msg1'] = '请填写您在注册时使用的电子邮件地址.';
$lang['resend_conflink_err1'] = '您已经确认了您的个人档案. 请使用 <a href="forgotpass.php">忘记密码</a> 链接来生成一组新的密码.';
$lang['about_me'] = '关于我';
$lang['about_me_hlp'] = '请填写关于您自己的简介, 这将使其他人感兴趣,从而帮助您得到更多的回应.';
$lang['aff_forgot_pass'] = '忘记您的密码? 在这里填写您的电子邮件来接收新密码:';
$lang['send_new_password'] = '发送新密码';
$lang['not_a_member'] = '还不是会员?';
$lang['login_reminded'] = '提醒您的用户名和密码.';
$lang['lost_confemail'] = '遗失了确认电子邮件?';
$lang['couple_usernames'] = '情侣 / 组用户名';
$lang['couple_usernames_hlp'] = '情侣或组由两个或多个个人组成. 请在以下的文字栏填写这情侣或组的各个会员的用户名. 例如: user_1,user_2,user_3. 这些用户必须已经有个人的个人档案.';
$lang['blog']['del01'] = '您确定要删除这个评论?';
$lang['blog']['del02'] = '您确定要删除所选的 ';
$lang['feat_prof_del_msg'] = '您确定要从特色档案列表中删除此档案吗?';
$lang['feat_prof_deleted'] = '所选择的档案已从特色档案列表中删除.';

$lang['mymatches_sub'] = 'SITENAME 消息: 您搜索配对档案的电子邮件!';
$lang['mymatches_body']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25"><div class="module_head">#email_hdr_left#</div></td><td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;您搜索配对档案的电子邮件 </div></td></tr></table></div></td></tr>
<tr><td width="570" class="evenrow" colspan="2" ><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="1"></td></tr><tr><td class="evenrow">亲爱的 #FirstName#,<br><br>以下是符合您所设定的搜索偏好的档案.</td></tr>
<tr><td height="1" class="evenrow"> </td></tr><tr><td valign="top" class="evenrow">#matchedProfiles#</td></tr><tr><td class="evenrow" colspan="2">请访问 <a href=\"#link#\">SITENAME</a> 浏览这些档案.<br><br>祝您好运!<br>#AdminName#<br>SITENAME<br></td></tr></table></div> </td></tr></table>';

$lang['on'] = ' 开 ';

$lang['use_seo_username'] = '使用个人档案用户名作为 URL 的参数. 开启这个选项将会使您的个人档案页的 URLs 格式成 "domain/username". 关闭这个选项将会使您的个人档案页的 URLs 格式成 "domain/id.htm"';
$lang['leave_blank_no_change'] = '(不修改留空)';

$lang['adminltr']['html']='<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head"><div class="module_head">#email_hdr_left#</div></td><td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;#Subject#</div></td></tr></table></div></td></tr>
<tr><td width="100%" class="evenrow" colspan="2"><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">#LetterContent#</td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['adminltr']['text'] = '#LetterContent#';


$lang['status_disp'] = array(
	'approval' => '待处理',
	'active' => '活跃',
	'rejected' => '被拒绝',
	'suspended' => '被中止',
	/* added in 1.1.0 */
	'cancel' => '被取消'
	);


$lang['status_enum'] = array(
	'approval' => '待处理',
	'active' => '活跃',
	'rejected' => '被拒绝',
	'suspended' => '被中止',
	);


$lang['status_act'] = array(
	'approval' => '待处理',
	'active' => '激活',
	'rejected' => '拒绝',
	'suspended' => '中止',
	/* added in 1.1.0 */
	'cancel' => '取消'
	);

/* Following is for mail encoding */
$lang['mail_text_encoding'] = '8bit';
$lang['mail_html_encoding'] = '8bit';
$lang['mail_html_charset'] = 'UTF-8';
$lang['mail_text_charset'] = 'UTF-8';
$lang['mail_head_charset'] = 'UTF-8';

/* Updated to latest version */
$lang['banner_sizes']['100x500'] = '100 x 500';
$lang['activedays_array'][999] = '999';
$lang['banner_error_msgs'][5] = '横幅广告的尺寸超过了允许的大小.';
$lang['blog']['del03'] = '您确定要卸载吗? ';
$lang['sections'] = array(
  1 => '基本信息',
  2 => '外表',
  3 => '职业生活',
  4 => '生活方式',
  5 => '兴趣'
);
$lang['split_file_names_hdr'] = '文件正在被载入';
$lang['worst1'] = '(最糟)';
$lang['best1'] = '(最好)';
$lang['profile_auto_confirmed'] = '感谢您成为 SITENAME 的一名会员.<br><br>作为特别的表示, 您的档案已经被我们的系统自动确认.<br><br>请 <a href="index.php?page=login">登录</a> 享用我们的服务.<br><br>';
$lang['zip_load_over'] = '载入 #COUNTRY# 的邮政编码已经完成.';
$lang['loginagain'] = '退出并重新登录以享用新的会员级别';
$lang['online_users_txt'] = '在线会员';
?>
