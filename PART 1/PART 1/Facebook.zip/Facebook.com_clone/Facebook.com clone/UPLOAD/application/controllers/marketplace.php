<?php

/**
 * Marketplace Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 12/19/2007
 */
class Marketplace extends Controller
{
		//Constructor
		var $userId, $listpath, $wantPath, $listURL, $wantURL;
		function Marketplace()
		{
				parent::Controller();
				//check login
				if ($this->session->userdata('logged_in') != true && $this->session->userdata('user_id') == '')
				{
						redirect('home');
				}
				$this->userId = $this->session->userdata('user_id');
				//Load the language file
				$this->lang->load('posted', $this->config->item('language_code'));
				$this->lang->load('marketplace', $this->config->item('language_code'));
				$this->load->model('marketplaceModel');
				$this->load->model('networkModel');
				$this->listPath = APPPATH . 'content/marketplace/list/';
				$this->wantPath = APPPATH . 'content/marketplace/want/';
				$this->listURL = base_url() . 'application/content/marketplace/list/';
				$this->wantURL = base_url() . 'application/content/marketplace/want/';
		}
		//Default function
		function index()
		{
				$this->home();
		}
		function home($networkId = '', $catId = '', $mode = '')
		{
				$this->load->model('userModel');
				$this->load->model('friendsModel');
				$this->load->model('networkModel');
				$friendsArray = $this->friendsModel->getFriends($this->userId);
				$catList = $this->marketplaceModel->getMainCategory();
				$lstSearch = ($this->input->post('lstSearch') == false) ? '0' : $this->input->post('lstSearch');
				$friendsCount = 0;
				$myCount = 0;
				if (count($friendsArray))
				{
						$friendsIds = implode(",", $friendsArray);
						if (trim($friendsIds) != '')
						{
								$friendsCount = $this->userModel->marketplaceListCount($friendsIds);
						}
				}
				$myCount = $this->userModel->marketplaceListCount($this->userId);
				$userNetworks = $this->userModel->networks($this->userId);
				if (count($userNetworks) > 0)
				{
						$firstNetworkId = $userNetworks[0]['network_id'];
				}
				if ($mode != '' && $mode != 'n')
				{
						if ($mode != 'list' && $mode != 'want')
						{
								redirect("marketplace");
						}
				}
				else
				{
						$mode = 'n';
				}
				if ($catId != '' && ereg('^[0-9]+$', $catId))
				{
						if ($this->marketplaceModel->isMainCatExist($catId) == 0)
						{
								$catId = 'n';
						}
				}
				else
				{
						$catId = 'n';
				}
				if ($this->input->post('networkId') != false)
				{
						$firstNetworkId = $this->input->post('networkId');
						//echo $firstNetworkId;
						$networkId = $firstNetworkId;
				}
				if (trim($networkId) != -1 && ereg('^[0-9]+$', $networkId))
				{
						$networkExist = $this->networkModel->isExist($networkId);
						if ($networkExist > 0)
						{
								$firstNetworkId = $networkId;
						}
						else
						{
								$firstNetworkId = -1;
						}
				}
				else
				{
						$firstNetworkId = -1;
				}
				//Load the pagination model
				$this->load->model('paginationmodel');
				//Load the pagination language file
				$this->lang->load('pagination', $this->config->item('language_code'));
				$perPage = $this->paginationmodel->getPerPage('marketplace');
				$start = (trim($this->uri->segment(6)) != '' && is_numeric($this->uri->segment(6)) && $this->uri->segment(6) > 0) ? $this->uri->segment(6) : 1;
				$start = ($start - 1) * $perPage;
				$arrCategoryListingsCount = $this->marketplaceModel->getCatListingsCount($firstNetworkId);
				$arrCategoryWantedCount = $this->marketplaceModel->getCatWantedCount($firstNetworkId);
				$arrListings = $this->marketplaceModel->getHomeListings($firstNetworkId, $catId, $mode, $start, $perPage);
				$networkNameArray = $this->networkModel->getName($firstNetworkId);
				foreach ($arrListings as $key => $valArr)
				{
						$arrListings[$key]['list_div'] = $this->showDetail($valArr['list_id'], $valArr['tag_id'], $valArr['list_type']);
				}
				$networkName = '';
				if (count($networkNameArray) > 0)
				{
						$networkName = $networkNameArray[$firstNetworkId]['network_name'];
				}
				$data = array();
				$data['catList'] = $catList;
				$data['resultTotal'] = $this->marketplaceModel->getHomeListingsCount($firstNetworkId, $catId, $mode);
				$data['currentPage'] = (trim($this->uri->segment(6)) != '' && is_numeric($this->uri->segment(6))) ? $this->uri->segment(6) : 1;
				$data['totalPages'] = ($data['resultTotal'] > $perPage) ? ceil(($data['resultTotal'] / $perPage)) : 0;
				$data['pageUrl'] = base_url() . 'marketplace/home/' . $firstNetworkId . '/' . $catId . '/' . $mode . '/';
				$data['listingCount'] = count($arrListings);
				$data['listURL'] = $this->listURL;
				$data['wantURL'] = $this->wantURL;
				$data['listCat'] = $arrCategoryListingsCount;
				$data['wantCat'] = $arrCategoryWantedCount;
				$data['networks'] = $userNetworks;
				$data['selectedNetwork'] = $firstNetworkId;
				$data['homeListings'] = $arrListings;
				$data['networkName'] = $networkName;
				$data['myCount'] = $myCount;
				$data['myFriendsCount'] = $friendsCount;
				$data['listval'] = $lstSearch;
				$this->smartyextended->view('marketplace_home', $data);
		}
		function search()
		{
				if (!$_POST)
				{
						redirect('marketplace/');
				}
				$this->load->model('userModel');
				$this->load->model('friendsModel');
				$this->load->model('networkModel');
				$catList = $this->marketplaceModel->getMainCategory();
				$userNetworks = $this->userModel->networks($this->userId);
				$arrItemCondition = $this->marketplaceModel->getItemCondition();
				$txtSearch = $this->input->post('txtSearch');
				$lstSearch = $this->input->post('lstSearch');
				$arrSubcategory = array();
				$mainCatId = '';
				$mode = '';
				$catCode = '';
				$arrSubcategory = array();
				$networkId = $this->input->post('networkId');
				$subCatCode = '';
				//$txtSearch = '', $criteriaA = '', $criteriaB = '', $criteriaC = '';
				if ($lstSearch != false and TRIM($lstSearch) != '0')
				{
						$arrValues = split('_', $lstSearch);
						$mode = $arrValues[0];
						$mainCatId = $arrValues[1];
						$arrSubcategory = $this->marketplaceModel->getSubCategory($mainCatId);
						$catCode = $arrValues[2];
						$subCatCode = (count($arrValues) == 4) ? $arrValues[3] : '';
						$arrSubcategory = $this->marketplaceModel->getSubCategory($mainCatId);
						foreach ($arrSubcategory as $key => $valSubArr)
						{
								$arrSubcategory[$key]['cat_code'] = $catCode;
						}
						if (count($arrValues) > 3)
						{
								foreach ($arrSubcategory as $key => $valSubArr)
								{
										if ($subCatCode == $valSubArr['sub_cat_code'])
										{
												$arrSubcategory[$key]['selstatus'] = ' selected ';
										}
										else
										{
												$arrSubcategory[$key]['selstatus'] = ' ';
										}
								}
						}
						else
						{
								foreach ($catList as $key => $valMainArr)
								{
										if ($mainCatId == $valMainArr['cat_id'])
										{
												$catList[$key]['selstatus'] = ' selected ';
										}
										else
										{
												$catList[$key]['selstatus'] = '  ';
										}
								}
						}
				}
				$data = array();
				//searchListings($networkId='',$catId='',$subCatCode='',$mode='',$txtSearch = '', $criteriaA = '', $criteriaB = '', $criteriaC = '' )
				$txtSearch = TRIM($this->input->post('txtSearch'));
				$criteriaA = '';
				if ($this->input->post('val1') != false) $criteriaA = $this->input->post('val1');
				$criteriaB = '';
				if ($this->input->post('val2') != false) $criteriaB = $this->input->post('val2');
				$criteriaC = '';
				if ($this->input->post('val3') != false && $this->input->post('val3') != '') $criteriaC = $this->input->post('val3');
				$networkId = (trim($networkId) == '') ? -1 : $networkId;
				//Load the pagination model
				$this->load->model('paginationmodel');
				//Load the pagination language file
				$this->lang->load('pagination', $this->config->item('language_code'));
				$perPage = $this->paginationmodel->getPerPage('marketplace');
				/*
				$start		= (trim($this->uri->segment(3)) != '' && is_numeric($this->uri->segment(3))) ? $this->uri->segment(3) : 1;
				$start		= ($start - 1) * $perPage;
				*/
				$start = ($this->input->post('pageNo')) ? $this->input->post('pageNo') : 0;
				//$txtSearch 			= 	($txtSearch == 'Search Marketplace') ? '' : $txtSearch ;
				$arrListings = $this->marketplaceModel->searchListings($networkId, $mainCatId, $subCatCode, $mode, $txtSearch, $criteriaA, $criteriaB, $criteriaC, $start, $perPage);
				foreach ($arrListings as $key => $valArr)
				{
						$arrListings[$key]['list_div'] = $this->showDetail($valArr['list_id'], $valArr['tag_id'], $valArr['list_type']);
				}
				$friendsArray = $this->friendsModel->getFriends($this->userId);
				$friendsCount = 0;
				if (count($friendsArray))
				{
						$friendsIds = implode(",", $friendsArray);
						if (trim($friendsIds) != '')
						{
								$friendsCount = $this->userModel->marketplaceListCount($friendsIds);
						}
				}
				$myCount = $this->userModel->marketplaceListCount($this->userId);
				$networkNameArray = $this->networkModel->getName($networkId);
				$networkName = '';
				if (count($networkNameArray) > 0) $networkName = $networkNameArray[$networkId]['network_name'];
				$data['resultTotal'] = $this->marketplaceModel->searchListingsCount($networkId, $mainCatId, $subCatCode, $mode, $txtSearch, $criteriaA, $criteriaB, $criteriaC);
				//$data['currentPage']	= 	(trim($this->uri->segment(3)) != '' && is_numeric($this->uri->segment(3))) ? $this->uri->segment(3) : 1;
				$data['currentPage'] = ($this->input->post('pageNo')) ? $this->input->post('pageNo') : 0;
				$data['totalPages'] = ($data['resultTotal'] > $perPage) ? ceil(($data['resultTotal'] / $perPage)) : 0;
				$data['pageUrl'] = base_url() . 'marketplace/search/';
				$myCount = $this->userModel->marketplaceListCount($this->userId);
				$data['item_condition'] = $arrItemCondition;
				$data['mainCatCode'] = $catCode;
				$data['listURL'] = $this->listURL;
				$data['wantURL'] = $this->wantURL;
				$data['networkName'] = $networkName;
				$data['mode'] = $mode;
				$data['catList'] = $catList;
				$data['mainCatId'] = $mainCatId;
				$data['subCats'] = $arrSubcategory;
				$data['networks'] = $userNetworks;
				$data['catList'] = $catList;
				$data['listingCount'] = count($arrListings);
				$data['homeListings'] = $arrListings;
				$data['myCount'] = $myCount;
				$data['myFriendsCount'] = $friendsCount;
				$data['listval'] = $lstSearch;
				$this->smartyextended->view('marketplace_search', $data);
		}
		function getNetworkNames()
		{
				$this->load->model('marketplaceModel');
				echo json_encode($this->marketplaceModel->getNetworks($this->input->post('q')));
		}
		function myListings($networkId = '', $catId = '', $mode = '')
		{
				$this->load->model('userModel');
				$this->load->model('friendsModel');
				$this->load->model('networkModel');
				$friendsArray = $this->friendsModel->getFriends($this->userId);
				$catList = $this->marketplaceModel->getMainCategory();
				$friendsCount = 0;
				$myCount = 0;
				$lstSearch = ($this->input->post('lstSearch') == false) ? '0' : $this->input->post('lstSearch');
				if (trim($mode) != '' && $mode != 'list' && $mode != 'want' && $mode != 'n')
				{
						redirect('marketplace/');
				}
				if (count($friendsArray))
				{
						$friendsIds = implode(",", $friendsArray);
						if (trim($friendsIds) != '')
						{
								$friendsCount = $this->userModel->marketplaceListCount($friendsIds);
						}
				}
				$myCount = $this->userModel->marketplaceListCount($this->userId);
				$userNetworks = $this->userModel->networks($this->userId);
				if (count($userNetworks) > 0)
				{
						$firstNetworkId = $userNetworks[0]['network_id'];
				}
				if ($mode != '')
				{
						if ($mode != 'list' && $mode != 'want' && $mode != 'n')
						{
								redirect("marketplace");
						}
				}
				else
				{
						$mode = 'n';
				}
				if ($catId != '' && ereg('^[0-9]+$', $catId))
				{
						if ($this->marketplaceModel->isMainCatExist($catId) == 0)
						{
								$catId = 'n';
						}
				}
				else
				{
						$catId = 'n';
				}
				if (trim($networkId) != -1 && ereg('^[0-9]+$', $networkId))
				{
						$networkExist = $this->networkModel->isExist($networkId);
						if ($networkExist > 0)
						{
								$firstNetworkId = $networkId;
						}
						else
						{
								$firstNetworkId = -1;
						}
				}
				else
				{
						$firstNetworkId = -1;
				}
				//Load the pagination model
				$this->load->model('paginationmodel');
				//Load the pagination language file
				$this->lang->load('pagination', $this->config->item('language_code'));
				$perPage = $this->paginationmodel->getPerPage('marketplace');
				$start = (trim($this->uri->segment(7)) != '' && is_numeric($this->uri->segment(7)) && $this->uri->segment(7) > 0) ? $this->uri->segment(7) : 1;
				$start = ($start - 1) * $perPage;
				$arrCategoryListingsCount = $this->marketplaceModel->getCatListingsCount($firstNetworkId);
				$arrCategoryWantedCount = $this->marketplaceModel->getCatWantedCount($firstNetworkId);
				$arrListings = $this->marketplaceModel->getUserListings($this->userId, $catId, $mode, $start, $perPage);
				$networkNameArray = $this->networkModel->getName($firstNetworkId);
				foreach ($arrListings as $key => $valArr)
				{
						$arrListings[$key]['list_div'] = $this->showDetail($valArr['list_id'], $valArr['tag_id'], $valArr['list_type']);
				}
				$networkName = '';
				if (count($networkNameArray) > 0)
				{
						$networkName = $networkNameArray[$firstNetworkId]['network_name'];
				}
				$data = array();
				$data['resultTotal'] = $this->marketplaceModel->getUserListingsCount($this->userId, $firstNetworkId, $catId, $mode);
				$data['currentPage'] = (trim($this->uri->segment(7)) != '' && is_numeric($this->uri->segment(7))) ? $this->uri->segment(7) : 1;
				$data['totalPages'] = ($data['resultTotal'] > $perPage) ? ceil(($data['resultTotal'] / $perPage)) : 0;
				$data['pageUrl'] = base_url() . 'marketplace/myListings/' . $this->userId . '/' . $firstNetworkId . '/' . $catId . '/' . $mode . '/';
				$data['catList'] = $catList;
				$data['listingCount'] = count($arrListings);
				$data['listURL'] = $this->listURL;
				$data['wantURL'] = $this->wantURL;
				$data['listCat'] = $arrCategoryListingsCount;
				$data['wantCat'] = $arrCategoryWantedCount;
				$data['networks'] = $userNetworks;
				$data['selectedNetwork'] = $firstNetworkId;
				$data['homeListings'] = $arrListings;
				$data['networkName'] = $networkName;
				$data['myCount'] = $myCount;
				$data['myFriendsCount'] = $friendsCount;
				$data['listval'] = $lstSearch;
				$this->smartyextended->view('mylistings', $data);
		}
		function profilelist($userId = 'n')
		{
				if (!ereg('^[0-9]+$', $userId))
				{
						redirect('marketplace/');
				}
				$this->load->model('userModel');
				//Load the pagination model
				$this->load->model('paginationmodel');
				//Load the pagination language file
				$this->lang->load('pagination', $this->config->item('language_code'));
				$perPage = $this->paginationmodel->getPerPage('marketplace');
				$start = (trim($this->uri->segment(4)) != '' && is_numeric($this->uri->segment(4)) && $this->uri->segment(4) > 0) ? $this->uri->segment(4) : 1;
				$start = ($start - 1) * $perPage;
				$arrListings = $this->marketplaceModel->getProfileListings($userId, $start, $perPage);
				foreach ($arrListings as $key => $valArr)
				{
						$arrListings[$key]['list_div'] = $this->showDetail($valArr['list_id'], $valArr['tag_id'], $valArr['list_type']);
				}
				$data = array();
				$data['profile_id'] = $userId;
				$data['profile_name'] = $this->userModel->getName($userId);
				$data['profile_avatar'] = $this->userModel->getAvatar($userId, true);
				$data['resultTotal'] = $this->marketplaceModel->getProfileListingsCount($userId);
				$data['currentPage'] = (trim($this->uri->segment(4)) != '' && is_numeric($this->uri->segment(4))) ? $this->uri->segment(4) : 1;
				$data['totalPages'] = ($data['resultTotal'] > $perPage) ? ceil(($data['resultTotal'] / $perPage)) : 0;
				$data['pageUrl'] = base_url() . 'marketplace/profilelist/' . $userId . '/';
				$data['listingCount'] = count($arrListings);
				$data['listURL'] = $this->listURL;
				$data['wantURL'] = $this->wantURL;
				$data['homeListings'] = $arrListings;
				$this->smartyextended->view('marketplace_profilelist', $data);
		}
		function myFriendListings($networkId = '', $catId = '', $mode = '')
		{
				$this->load->model('userModel');
				$this->load->model('friendsModel');
				$this->load->model('networkModel');
				$catList = $this->marketplaceModel->getMainCategory();
				$friendsArray = $this->friendsModel->getFriends($this->userId);
				$friendsCount = 0;
				$myCount = 0;
				$lstSearch = ($this->input->post('lstSearch') == false) ? '0' : $this->input->post('lstSearch');
				if (trim($mode) != '' && $mode != 'list' && $mode != 'want' && $mode != 'n')
				{
						redirect('marketplace/');
				}
				else
				{
						$mode = 'n';
				}
				$friendsIds = '';
				if (count($friendsArray) > 0)
				{
						$friendsIds = implode(",", $friendsArray);
						if (trim($friendsIds) != '')
						{
								$friendsCount = $this->userModel->marketplaceListCount($friendsIds);
						}
				}
				$myCount = $this->userModel->marketplaceListCount($this->userId);
				$userNetworks = $this->userModel->networks($this->userId);
				if (count($userNetworks) > 0)
				{
						$firstNetworkId = $userNetworks[0]['network_id'];
				}
				if ($catId != '' && ereg('^[0-9]+$', $catId))
				{
						if ($this->marketplaceModel->isMainCatExist($catId) == 0)
						{
								$catId = 'n';
						}
				}
				else
				{
						$catId = 'n';
				}
				if (trim($networkId) != -1 && ereg('^[0-9]+$', $networkId))
				{
						$networkExist = $this->networkModel->isExist($networkId);
						if ($networkExist > 0)
						{
								$firstNetworkId = $networkId;
						}
						else
						{
								$firstNetworkId = -1;
						}
				}
				else
				{
						$firstNetworkId = -1;
				}
				//Load the pagination model
				$this->load->model('paginationmodel');
				//Load the pagination language file
				$this->lang->load('pagination', $this->config->item('language_code'));
				$perPage = $this->paginationmodel->getPerPage('marketplace');
				$start = (trim($this->uri->segment(6)) != '' && is_numeric($this->uri->segment(6)) && $this->uri->segment(6) > 0) ? $this->uri->segment(6) : 1;
				$start = ($start - 1) * $perPage;
				//echo $perPage, '--',$start;
				$arrCategoryListingsCount = $this->marketplaceModel->getCatListingsCount($firstNetworkId);
				$arrCategoryWantedCount = $this->marketplaceModel->getCatWantedCount($firstNetworkId);
				$arrListings = array();
				if (trim($friendsIds) != '' && strlen(TRIM($friendsIds)) > 0)
				{
						$arrListings = $this->marketplaceModel->getUserListings($friendsIds, $catId, $mode, $start, $perPage);
						foreach ($arrListings as $key => $valArr)
						{
								$arrListings[$key]['list_div'] = $this->showDetail($valArr['list_id'], $valArr['tag_id'], $valArr['list_type']);
						}
				}
				$networkNameArray = $this->networkModel->getName($firstNetworkId);
				$networkName = '';
				if (count($networkNameArray) > 0)
				{
						$networkName = $networkNameArray[$firstNetworkId]['network_name'];
				}
				$data = array();
				$data['resultTotal'] = 0;
				if (trim($friendsIds) != '') $data['resultTotal'] = $this->marketplaceModel->getUserListingsCount($friendsIds, $firstNetworkId, $catId, $mode);
				$data['currentPage'] = (trim($this->uri->segment(6)) != '' && is_numeric($this->uri->segment(6))) ? $this->uri->segment(6) : 1;
				$data['totalPages'] = ($data['resultTotal'] > $perPage) ? ceil(($data['resultTotal'] / $perPage)) : 0;
				$data['pageUrl'] = base_url() . 'marketplace/myFriendListings/' . $firstNetworkId . '/' . $catId . '/' . $mode . '/';
				$data['listingCount'] = count($arrListings);
				$data['listURL'] = $this->listURL;
				$data['wantURL'] = $this->wantURL;
				$data['listCat'] = $arrCategoryListingsCount;
				$data['wantCat'] = $arrCategoryWantedCount;
				$data['networks'] = $userNetworks;
				$data['selectedNetwork'] = $firstNetworkId;
				$data['homeListings'] = $arrListings;
				$data['networkName'] = $networkName;
				$data['myCount'] = $myCount;
				$data['catList'] = $catList;
				$data['myFriendsCount'] = $friendsCount;
				$data['listval'] = $lstSearch;
				$this->smartyextended->view('myfriendlistings', $data);
		}
		function showDetail($id = '', $subCatCode = '', $mode = '')
		{
				$data = array();
				if ($id !== '' && $subCatCode !== '' && $mode !== '')
				{
						$arrCatInfo = $this->marketplaceModel->getCatInfo($subCatCode, $mode);
						$arrListInfo = $this->marketplaceModel->getListInfo($id, $mode);
						$networkList = $this->marketplaceModel->getListNetworkIds($id, $mode);
						$listPhotos = $this->marketplaceModel->getListPhotos($id, $mode);
						$data = array();
						$data['listURL'] = $this->listURL;
						$data['wantURL'] = $this->wantURL;
						$data['catinfo'] = $arrCatInfo;
						$data['listinfo'] = $arrListInfo;
						$data['networks'] = $networkList;
						$data['photos'] = $listPhotos;
						$data['photoscount'] = count($listPhotos);
						$data['mode'] = $mode;
						$data['listId'] = $id;
				}
				return ($this->smartyextended->view('marketplace_showlist', $data, true));
		}
		function showListingInfo($id = '', $subCatCode = '', $mode = '')
		{
				$id = $this->input->post('listId');
				$subCatCode = $this->input->post('tagId');
				$mode = $this->input->post('mode');
				$divId = $id . $mode;
				$arrCatInfo = $this->marketplaceModel->getCatInfo($subCatCode, $mode);
				$arrListInfo = $this->marketplaceModel->getListInfo($id, $mode);
				$networkList = $this->marketplaceModel->getListNetworkIds($id, $mode);
				$listPhotos = $this->marketplaceModel->getListPhotos($id, $mode);
				$data = array();
				$data['listURL'] = $this->listURL;
				$data['wantURL'] = $this->wantURL;
				$data['catinfo'] = $arrCatInfo;
				$data['listinfo'] = $arrListInfo;
				$data['networks'] = $networkList;
				$data['photos'] = $listPhotos;
				$data['photoscount'] = count($listPhotos);
				$data['mode'] = $mode;
				$data['listId'] = $id;
				$this->smartyextended->view('marketplace_showlist', $data);
		}
		function show($id = '', $subCatCode = '', $mode = '')
		{
				$this->load->model('userModel');
				$arrListInfo = $this->marketplaceModel->getListInfo($id, $mode);
				$arrCatInfo = $this->marketplaceModel->getCatInfo($subCatCode, $mode);
				if (count($arrListInfo) == 0) redirect('marketplace/');
				if ($mode != 'list' && $mode != 'want') redirect('marketplace/');
				if (count($arrCatInfo) == 0) redirect('marketplace/');
				if ($_POST && $this->input->post('delListId') != false && $this->input->post('delListMode') != false)
				{
						$this->deletePhotos($this->input->post('delListId'), $this->input->post('delListMode'));
						$this->marketplaceModel->deleteListPhotos($this->input->post('delListId'), $this->input->post('delListMode'));
						$this->marketplaceModel->deleteListNetworks($this->input->post('delListId'), $this->input->post('delListMode'));
						$this->marketplaceModel->deleteListing($this->input->post('delListId'), $this->input->post('delListMode'), $this->input->post('listStatus'));
						redirect('marketplace/myListings/');
				}
				//echo $this->marketplaceModel->getMarketplaceImage($id, $mode, TRUE, TRUE);
				$networkList = $this->marketplaceModel->getListNetworkIds($id, $mode);
				$listPhotos = $this->marketplaceModel->getListPhotos($id, $mode);
				$data = array();
				$data['username'] = $this->userModel->getName($arrListInfo[0]['user_id']);
				$data['listedUser'] = $arrListInfo[0]['user_id'];
				$data['listURL'] = $this->listURL;
				$data['wantURL'] = $this->wantURL;
				$data['catinfo'] = $arrCatInfo;
				$data['listinfo'] = $arrListInfo;
				$data['networks'] = $networkList;
				$data['photos'] = $listPhotos;
				$data['mode'] = $mode;
				$data['listId'] = $id;
				$this->smartyextended->view('marketplace_show', $data);
		}
		function deleteList()
		{
				$this->load->model('marketplaceModel');
				$id = $this->input->post('listId');
				$mode = $this->input->post('mode');
				$status = $this->input->post('status');
				$this->deletePhotos($id, $mode);
				$this->marketplaceModel->deleteListPhotos($id, $mode);
				$this->marketplaceModel->deleteListNetworks($id, $mode);
				$this->marketplaceModel->deleteListing($id, $mode, $status);
				echo $this->lang->line('market_list_delete_success_msg');
		}
		function deletePhotos($id, $mode, $photoId = '')
		{
				//$this->load->model('marketplaceModel');
				$arrPhotos = $this->marketplaceModel->getListPhotos($id, $mode);
				if ($mode == 'list') $pathToPhoto = $this->listPath;
				else  $pathToPhoto = $this->wantPath;
				foreach ($arrPhotos as $key => $valArr)
				{
						$delPath = $pathToPhoto . $valArr['file_name'];
						@unlink($delPath);
						//echo "<br><br>";
						//echo $delPath;
				}
		}
		function addListing($mode = 'list')
		{
				$this->load->model('userModel');
				$userNetworks = $this->userModel->networks($this->userId);
				if (count($userNetworks) == 0) redirect('marketplace/');
				if ($mode != 'list' && $mode != 'want') redirect('marketplace/');
				$arrMainCatList = $this->marketplaceModel->getMainCategory($mode);
				$data = array();
				$data['mode'] = $mode;
				$data['maincats'] = $arrMainCatList;
				$this->smartyextended->view('marketplace_main_cat', $data);
		}
		function showSubcat($mainCatId, $mode = 'list')
		{
				$this->load->model('userModel');
				$userNetworks = $this->userModel->networks($this->userId);
				if (count($userNetworks) == 0) redirect('marketplace/');
				if ($mode != 'list' && $mode != 'want') redirect('marketplace/');
				$arrSubCatList = $this->marketplaceModel->getSubCategory($mainCatId);
				$data = array();
				$data['cat_name'] = '';
				$maincatNameArr = $this->marketplaceModel->getMaincatName($mainCatId);
				if (count($maincatNameArr) > 0)
				{
						if ($mode == 'list')
						{
								$data['cat_name'] = $maincatNameArr[0]['cat_name'];
						}
						else
						{
								$data['cat_name'] = $maincatNameArr[0]['cat_alias_name'];
						}
				}
				else
				{
						redirect('marketplace/');
				}
				$data['mode'] = $mode;
				$data['subcats'] = $arrSubCatList;
				$this->smartyextended->view('marketplace_sub_cat', $data);
		}
		function showSubcatForm($subCatCode, $mode, $listId = '', $action = 'create')
		{
				if ($mode != 'list' && $mode != 'want') redirect('marketplace/');
				if ($action != 'create' && $action != 'edit') redirect('marketplace/');
				$this->load->library('validation');
				$this->load->model('userModel');
				$data = array();
				$userNetworks = $this->userModel->networks($this->userId);
				$arrItemCondition = $this->marketplaceModel->getItemCondition();
				$arrCurrencyCode = $this->marketplaceModel->getCurrencyCode();
				$allowedThings = $this->marketplaceModel->getAllowedThings();
				$jobCategory = $this->marketplaceModel->getJobSubCategories();
				$otherStuff = $this->marketplaceModel->getOtherStuff();
				$compensation = $this->marketplaceModel->getCompensation();
				$arrGetListedNetworks = array();
				$arrListedAllowables = array();
				$arrListedOtherStuffs = array();
				if ($_POST)
				{
						if (count($this->input->post('listnetworks')) > 0 && is_array($this->input->post('listnetworks')))
						{
								foreach ($this->input->post('listnetworks') as $key => $val)
								{
										$arrGetListedNetworks[] = array('network_id' => $val);
								}
						}
						if (count($this->input->post('chkAllowed')) > 0 && is_array($this->input->post('chkAllowed')))
						{
								foreach ($this->input->post('chkAllowed') as $key => $val)
								{
										$arrListedAllowables[] = $val;
								}
						}
						if (count($this->input->post('otherStuff')) > 0 && is_array($this->input->post('otherStuff')))
						{
								foreach ($this->input->post('otherStuff') as $key => $val)
								{
										$arrListedOtherStuffs[] = $val;
								}
						}
				}
				if ($action == 'edit' and ereg('^[0-9]+$', $listId))
				{
						$arrGetListDetails = $this->marketplaceModel->getListDetail($mode, $listId);
						if (count($arrGetListDetails) > 0)
						{
								if (!$_POST)
								{
										$arrGetListedNetworks = $this->marketplaceModel->getListedNetworks($mode, $listId);
								}
								$arrGetListedPhotos = $this->marketplaceModel->getListedPhotos($mode, $listId);
								$arrListedAllowables = split(',', $arrGetListDetails[0]['allowed_ids']);
								$arrListedOtherStuffs = split(',', $arrGetListDetails[0]['other_stuff_ids']);
								$data['selectedAllowables'] = $arrListedAllowables;
								$data['listedPhotos'] = $arrGetListedPhotos;
								$data['listedNetworks'] = $arrGetListedNetworks;
								$data['selectedOtherStuff'] = $arrListedOtherStuffs;
								$data['item_title'] = $arrGetListDetails[0]['title'];
								$data['jobType'] = $arrGetListDetails[0]['condition'];
								$data['item_description'] = $arrGetListDetails[0]['description'];
								$data['hours'] = $arrGetListDetails[0]['hours'];
								$data['compensation'] = $arrGetListDetails[0]['compensation'];
								$data['amount'] = $arrGetListDetails[0]['amount'];
								$data['currencyCode'] = $arrGetListDetails[0]['currencyCode'];
								$data['bedRooms'] = $arrGetListDetails[0]['bedRooms'];
								$data['bathRooms'] = $arrGetListDetails[0]['bathRooms'];
								$data['bathRooms'] = $arrGetListDetails[0]['bathRooms'];
								$data['condition'] = $arrGetListDetails[0]['condition'];
								$data['street'] = $arrGetListDetails[0]['street'];
								$data['crossStreet'] = $arrGetListDetails[0]['crossStreet'];
								$data['postalCode'] = $arrGetListDetails[0]['postalCode'];
								$data['squareFeet'] = $arrGetListDetails[0]['squareFeet'];
								$data['isbn'] = $arrGetListDetails[0]['isbn'];
								$data['profileFlag'] = $arrGetListDetails[0]['profileFlag'];
								$data['privacy'] = $arrGetListDetails[0]['privacy'];
						}
						else
						{
								redirect('marketplace/');
						}
				}
				$data['catInfo'] = $this->marketplaceModel->getCatInfo($subCatCode);
				$data['selectedAllowables'] = $arrListedAllowables;
				$data['selectedOtherStuff'] = $arrListedOtherStuffs;
				$data['listedNetworks'] = $arrGetListedNetworks;
				$data['listURL'] = $this->listURL;
				$data['wantURL'] = $this->wantURL;
				$data['compensation'] = $compensation;
				$data['otherstuff'] = $otherStuff;
				$data['jobcats'] = $jobCategory;
				$data['allowed'] = $allowedThings;
				$data['currency_code'] = $arrCurrencyCode;
				$data['item_condition'] = $arrItemCondition;
				$data['networks'] = $userNetworks;
				$data['cat_code'] = $subCatCode;
				$data['mode'] = $mode;
				$data['listId'] = $listId;
				$data['action'] = $action;
				if ($mode == 'list') $this->_listFormRules($subCatCode, $mode, $action);
				else  $this->_wantFormRules($subCatCode, $mode, $action);
				if ($this->validation->run() == false || $this->_checkNetwork() == false)
				{
						//Oops! validation Error.
						$data['validationError'] = $this->validation->error_string;
						if ($this->_checkNetwork() == false) $data['validationError'] .= $this->lang->line('market_label_select') . ' ' . $this->lang->line('market_label_networks_list');
						if ($_POST)
						{
								$fileMsg = $this->validateFiles();
								$data['validationError'] .= $fileMsg;
						}
				}
				else
				{
						// Success Part
						if ($_POST['hdnMode'] == 'list')
						{
								if ($_POST['hdnAction'] == 'create')
								{
										$listId = $this->marketplaceModel->insertList($_POST, $subCatCode);
								}
								else
								{
										$listId = $this->marketplaceModel->updateList($_POST, $subCatCode);
								}
						}
						else
						{
								if ($_POST['hdnAction'] == 'create')
								{
										$listId = $this->marketplaceModel->insertWant($_POST, $subCatCode);
								}
								else
								{
										$listId = $this->marketplaceModel->updateWant($_POST, $subCatCode);
								}
						}
						if ($listId > 0)
						{
								$networkMsg = $this->marketplaceModel->saveNetworks($listId, $_POST['listnetworks'], $mode);
								if ($networkMsg != '')
								{
										$data['validationError'] = $this->lang->line('market_list_save_network_error_msg');
								}
								else
								{
										$photoMsg = $this->storePhotos($listId, $mode);
										if ($photoMsg != '')
										{
												$data['validationError'] = $this->lang->line('market_list_upload_photo_error_msg');
										}
										else
										{
												//redirect("marketplace/myListings/");
												redirect("marketplace/show/" . $listId . "/" . $subCatCode . "/" . $mode . "/");
										}
								}
						}
						else
						{
								$data['validationError'] = $this->lang->line('market_list_save_error_msg');
						}
				}
				if ($mode == 'list') $this->smartyextended->view('marketplace_item_list_form', $data);
				else  $this->smartyextended->view('marketplace_item_wanted_form', $data);
		}
		function storePhotos($listId, $mode)
		{
				$msg = '';
				$marketplaceListPath = APPPATH . 'content/marketplace/list/';
				$marketplaceWantPath = APPPATH . 'content/marketplace/want/';
				$path = $marketplaceListPath;
				if ($mode == 'want')
				{
						$path = $marketplaceWantPath;
				}
				for ($i = 1; $i <= 5; $i++)
				{
						if (!isset($_FILES['file' . $i]['name']))
						{
								continue;
						}
						$fileName = $_FILES['file' . $i]['name'];
						$error = $_FILES['file' . $i]['error'];
						$size = $_FILES['file' . $i]['size'];
						if (trim($fileName) != '' and $error === 0 and $size > 0)
						{
								$arrSplitedName = split("\.", $fileName);
								$extension = trim($arrSplitedName[count($arrSplitedName) - 1]);
								$photoId = $this->marketplaceModel->AddPhotos($listId, $extension, $mode);
								$newFileName = trim($listId) . '_' . trim($photoId) . '.' . $extension;
								/*
								$fp = fopen('photo.txt','ab+');
								fwrite($fp,$newFileName);
								fclose($fp);
								*/
								$extension = $arrSplitedName[count($arrSplitedName) - 1];
								if ($photoId > 0)
								{
										$pathToUpload = $path;
										$fullNamePath = $pathToUpload . $newFileName;
										if (!move_uploaded_file($_FILES['file' . $i]['tmp_name'], $fullNamePath))
										{
												$msg = " " . $this->lang->line('market_upload_file_error_msg') . " - " . $fileName . "<br>";
										}
								}
								else
								{
										$msg = " " . $this->lang->line('market_upload_file_error_msg') . " - " . $fileName . "<br>";
								}
						} // End of if
				} // End of Loop
				if (trim($msg) != '') $msg = "<br>" . $msg;
				return $msg;
		}
		function validateFiles()
		{
				$msg = "";
				for ($i = 1; $i <= 5; $i++)
				{
						if (!isset($_FILES['file' . $i]['error']))
						{
								continue;
						}
						if ($_FILES['file' . $i]['error'] == 0 && $_FILES['file' . $i]['error'] != 4 && trim($_FILES['file' . $i]['name']) != '')
						{
								//if(!($_FILES['file'.$i]['type'] == 'image/jpeg' || $_FILES['file'.$i]['type'] == 'image/pjpeg' || $_FILES['file'.$i]['type'] == 'image/x-png' || $_FILES['file'.$i]['type'] == 'image/gif' || $_FILES['file'.$i]['type'] == 'image/png' || $_FILES['file'.$i]['type'] == 'image/bmp'))
								if (!($_FILES['file' . $i]['type'] == 'image/jpeg' || $_FILES['file' . $i]['type'] == 'image/pjpeg' || $_FILES['file' . $i]['type'] == 'image/x-png' || $_FILES['file' . $i]['type'] == 'image/gif' || $_FILES['file' . $i]['type'] == 'image/png' || $_FILES['file' . $i]['type'] == 'image/bmp'))
								{
										$msg .= $_FILES['file' . $i]['name'] . " - " . $this->lang->line('Invalid photo format, allowed formats are jpeg, gif, png and bmp') . " <br>";
								}
								if (intval($_FILES['file' . $i]['size']) > 4194304)
								{
										$msg .= $_FILES['file' . $i]['name'] . " - " . $this->lang->line('Photo size must be less than 4MB') . "<br>";
								}
						}
				}
				if (trim($msg) != '')
				{
						$msg = "<br>" . $msg;
				}
				return $msg;
		}
		function deleteFiles($mode, $listId, $photoId, $fileExt)
		{
				$fileName = $listId . '_' . $photoId . '.' . $fileExt;
				$pathToPhoto = $this->listPath;
				if ($mode == 'want') $pathToPhoto = $this->wantPath;
				$fullPath = $pathToPhoto . $fileName;
				unlink($fullPath);
				$this->marketplaceModel->delPhotos($mode, $listId, $photoId);
		}
		function removePhoto()
		{
				$mode = $this->input->post('mode');
				$listId = $this->input->post('list_id');
				$photoId = $this->input->post('photo_id');
				$fileExt = $this->input->post('file_ext');
				if ($listId != false && $photoId != false && $fileExt != false && $mode !== false)
				{
						$this->deleteFiles($mode, $listId, $photoId, $fileExt);
				}
				echo 'done';
		}
		function _listFormRules($subCatCode, $mode, $action)
		{
				if ($subCatCode == 'BOOK')
				{
						$this->_bookRules($mode, $action);
				}
				if ($subCatCode == 'FURNITURE')
				{
						$this->_furnitureRules($mode, $action);
				}
				if ($subCatCode == 'CAR')
				{
						$this->_carRules($mode, $action);
				}
				if ($subCatCode == 'TICKET')
				{
						$this->_ticketRules($mode, $action);
				}
				if ($subCatCode == 'ELECTRONIC')
				{
						$this->_electronicRules($mode, $action);
				}
				if ($subCatCode == 'OTHERSALE')
				{
						$this->_otherSaleRules($mode, $action);
				}
				if ($subCatCode == 'FREE')
				{
						$this->_freeRules($mode, $action);
				}
				if ($subCatCode == 'OTHERHOUSING')
				{
						$this->_otherHousingRules($mode, $action);
				}
				if ($subCatCode == 'REALESTATE')
				{
						$this->_realEstateRules($mode, $action);
				}
				if ($subCatCode == 'RENTAL')
				{
						$this->_rentalRules($mode, $action);
				}
				if ($subCatCode == 'SUBLET')
				{
						$this->_subletRules($mode, $action);
				}
				if ($subCatCode == 'JOB')
				{
						$this->_jobRules($mode, $action);
				}
				if ($subCatCode == 'EVERYTHING')
				{
						$this->_everythingRules($mode, $action);
				}
				if ($subCatCode == 'FOUNDITEM')
				{
						$this->_foundItemRules($mode, $action);
				}
		}
		function _wantFormRules($subCatCode, $mode, $action)
		{
				if ($subCatCode == 'BOOK')
				{
						$this->_bookRulesWant($mode, $action);
				}
				if ($subCatCode == 'FURNITURE')
				{
						$this->_furnitureRulesWant($mode, $action);
				}
				if ($subCatCode == 'CAR')
				{
						$this->_carRulesWant($mode, $action);
				}
				if ($subCatCode == 'TICKET')
				{
						$this->_ticketRulesWant($mode, $action);
				}
				if ($subCatCode == 'ELECTRONIC')
				{
						$this->_electronicRulesWant($mode, $action);
				}
				if ($subCatCode == 'OTHERSALE')
				{
						$this->_otherSaleRulesWant($mode, $action);
				}
				if ($subCatCode == 'FREE')
				{
						$this->_freeRulesWant($mode, $action);
				}
				if ($subCatCode == 'OTHERHOUSING')
				{
						$this->_otherHousingRulesWant($mode, $action);
				}
				if ($subCatCode == 'REALESTATE')
				{
						$this->_realEstateRulesWant($mode, $action);
				}
				if ($subCatCode == 'RENTAL')
				{
						$this->_rentalRulesWant($mode, $action);
				}
				if ($subCatCode == 'SUBLET')
				{
						$this->_subletRulesWant($mode, $action);
				}
				if ($subCatCode == 'JOB')
				{
						$this->_jobRulesWant($mode, $action);
				}
				if ($subCatCode == 'EVERYTHING')
				{
						$this->_everythingRulesWant($mode, $action);
				}
				if ($subCatCode == 'FOUNDITEM')
				{
						$this->_foundItemRulesWant($mode, $action);
				}
		}
		function _foundItemRulesWant($mode, $action)
		{
				$rules['title'] = 'trim|required|min_length[5]';
				$rules['description'] = 'trim|required|min_length[10]';
				//$rules['listnetworks']		= 'required';
				$this->validation->set_rules($rules);
				$fields['title'] = $this->lang->line('market_label_title');
				$fields['description'] = $this->lang->line('market_label_description');
				//$fields['listnetworks']		= $this->lang->line('market_label_network');
				$this->validation->set_fields($fields);
		}
		function _everythingRulesWant($mode, $action)
		{
				$rules['title'] = 'trim|required|min_length[5]';
				$rules['description'] = 'trim|required|min_length[10]';
				//$rules['listnetworks']		= 'required';
				$this->validation->set_rules($rules);
				$fields['title'] = $this->lang->line('market_label_title');
				$fields['description'] = $this->lang->line('market_label_description');
				//$fields['listnetworks']		= $this->lang->line('market_label_network');
				$this->validation->set_fields($fields);
		}
		function _jobRulesWant($mode, $action)
		{
				$rules['title'] = 'trim|required|min_length[5]';
				$rules['description'] = 'trim|required|min_length[10]';
				//$rules['listnetworks']		= 'required';
				$this->validation->set_rules($rules);
				$fields['title'] = $this->lang->line('market_label_title');
				$fields['description'] = $this->lang->line('market_label_description');
				//$fields['listnetworks']		= $this->lang->line('market_label_network');
				$this->validation->set_fields($fields);
		}
		function _subletRulesWant($mode, $action)
		{
				$rules['title'] = 'trim|required|min_length[5]';
				$rules['description'] = 'trim|required|min_length[10]';
				$rules['postalCode'] = 'callback__isValidPostalCode';
				//$rules['listnetworks']		= 'required';
				$this->validation->set_rules($rules);
				$fields['title'] = $this->lang->line('market_label_title');
				$fields['description'] = $this->lang->line('market_label_description');
				//$fields['listnetworks']		= $this->lang->line('market_label_network');
				$this->validation->set_fields($fields);
		}
		function _rentalRulesWant($mode, $action)
		{
				$rules['title'] = 'trim|required|min_length[5]';
				$rules['description'] = 'trim|required|min_length[10]';
				$rules['postalCode'] = 'callback__isValidPostalCode';
				//$rules['listnetworks']		= 'required';
				$this->validation->set_rules($rules);
				$fields['title'] = $this->lang->line('market_label_title');
				$fields['description'] = $this->lang->line('market_label_description');
				//$fields['listnetworks']		= $this->lang->line('market_label_network');
				$this->validation->set_fields($fields);
		}
		function _realEstateRulesWant($mode, $action)
		{
				$rules['title'] = 'trim|required|min_length[5]';
				$rules['description'] = 'trim|required|min_length[10]';
				$rules['postalCode'] = 'callback__isValidPostalCode';
				//$rules['listnetworks']		= 'required';
				$this->validation->set_rules($rules);
				$fields['title'] = $this->lang->line('market_label_title');
				$fields['description'] = $this->lang->line('market_label_description');
				//$fields['listnetworks']		= $this->lang->line('market_label_network');
				$this->validation->set_fields($fields);
		}
		function _otherHousingRulesWant($mode, $action)
		{
				$rules['title'] = 'trim|required|min_length[5]';
				$rules['description'] = 'trim|required|min_length[10]';
				$rules['postalCode'] = 'callback__isValidPostalCode';
				//$rules['listnetworks']		= 'required';
				$this->validation->set_rules($rules);
				$fields['title'] = $this->lang->line('market_label_title');
				$fields['description'] = $this->lang->line('market_label_description');
				//$fields['listnetworks']		= $this->lang->line('market_label_network');
				$this->validation->set_fields($fields);
		}
		function _bookRulesWant($mode, $action)
		{
				$rules['title'] = 'trim|required|min_length[5]';
				$rules['description'] = 'trim|required|min_length[10]';
				$rules['isbn'] = 'callback__isValidISBN';
				////$rules['listnetworks']	= 'callback__checkNetwork';
				$this->validation->set_rules($rules);
				$fields['title'] = $this->lang->line('market_label_title');
				$fields['description'] = $this->lang->line('market_label_description');
				$fields['isbn'] = $this->lang->line('market_label_isbn');
				////$fields['listnetworks']		= $this->lang->line('market_label_network');
				$this->validation->set_fields($fields);
		}
		function _checkNetwork()
		{
				//echo 'kkkk';
				if (!$_POST) return true;
				$networkSelected = $this->input->post('listnetworks');
				//var_dump($networkSelected);
				if ($networkSelected == false || count($networkSelected) == 0)
				{
						//$this->validation->set_message('_checkNetwork', $this->lang->line('market_label_select').' %s ');
						return false;
				}
				else
				{
						return true;
				}
		}
		function _furnitureRulesWant($mode, $action)
		{
				$rules['title'] = 'trim|required|min_length[5]';
				$rules['description'] = 'trim|required|min_length[10]';
				//$rules['listnetworks']		= 'required';
				$this->validation->set_rules($rules);
				$fields['title'] = $this->lang->line('market_label_title');
				$fields['description'] = $this->lang->line('market_label_description');
				//$fields['listnetworks']		= $this->lang->line('market_label_network');
				$this->validation->set_fields($fields);
		}
		function _carRulesWant($mode, $action)
		{
				$rules['title'] = 'trim|required|min_length[5]';
				$rules['description'] = 'trim|required|min_length[10]';
				//$rules['listnetworks']		= 'required';
				$this->validation->set_rules($rules);
				$fields['title'] = $this->lang->line('market_label_title');
				$fields['description'] = $this->lang->line('market_label_description');
				//$fields['listnetworks']		= $this->lang->line('market_label_network');
				$this->validation->set_fields($fields);
		}
		function _ticketRulesWant($mode, $action)
		{
				$rules['title'] = 'trim|required|min_length[5]';
				$rules['description'] = 'trim|required|min_length[10]';
				//$rules['listnetworks']		= 'required';
				$this->validation->set_rules($rules);
				$fields['title'] = $this->lang->line('market_label_title');
				$fields['description'] = $this->lang->line('market_label_description');
				//$fields['listnetworks']		= $this->lang->line('market_label_network');
				$this->validation->set_fields($fields);
		}
		function _electronicRulesWant($mode, $action)
		{
				$rules['title'] = 'trim|required|min_length[5]';
				$rules['description'] = 'trim|required|min_length[10]';
				//$rules['listnetworks']		= 'required';
				$this->validation->set_rules($rules);
				$fields['title'] = $this->lang->line('market_label_title');
				$fields['description'] = $this->lang->line('market_label_description');
				//$fields['listnetworks']		= $this->lang->line('market_label_network');
				$this->validation->set_fields($fields);
		}
		function _otherSaleRulesWant($mode, $action)
		{
				$rules['title'] = 'trim|required|min_length[5]';
				$rules['description'] = 'trim|required|min_length[10]';
				//$rules['listnetworks']		= 'required';
				$this->validation->set_rules($rules);
				$fields['title'] = $this->lang->line('market_label_title');
				$fields['description'] = $this->lang->line('market_label_description');
				//$fields['listnetworks']		= $this->lang->line('market_label_network');
				$this->validation->set_fields($fields);
		}
		function _freeRulesWant($mode, $action)
		{
				$rules['title'] = 'trim|required|min_length[5]';
				$rules['description'] = 'trim|required|min_length[10]';
				//$rules['listnetworks']		= 'required';
				$this->validation->set_rules($rules);
				$fields['title'] = $this->lang->line('market_label_title');
				$fields['description'] = $this->lang->line('market_label_description');
				//$fields['listnetworks']		= $this->lang->line('market_label_network');
				$this->validation->set_fields($fields);
		}
		function _foundItemRules($mode, $action)
		{
				$rules['title'] = 'trim|required|min_length[5]';
				$rules['description'] = 'trim|required|min_length[10]';
				//$rules['listnetworks']		= 'required';
				$this->validation->set_rules($rules);
				$fields['title'] = $this->lang->line('market_label_title');
				$fields['description'] = $this->lang->line('market_label_description');
				//$fields['listnetworks']		= $this->lang->line('market_label_network');
				$this->validation->set_fields($fields);
		}
		function _everythingRules($mode, $action)
		{
				$rules['title'] = 'trim|required|min_length[5]';
				$rules['description'] = 'trim|required|min_length[10]';
				//$rules['listnetworks']		= 'required';
				$this->validation->set_rules($rules);
				$fields['title'] = $this->lang->line('market_label_title');
				$fields['description'] = $this->lang->line('market_label_description');
				//$fields['listnetworks']		= $this->lang->line('market_label_network');
				$this->validation->set_fields($fields);
		}
		function _jobRules($mode, $action)
		{
				$rules['title'] = 'trim|required|min_length[5]';
				$rules['description'] = 'trim|required|min_length[10]';
				$rules['amount'] = 'callback__isValidAmount';
				//$rules['listnetworks']		= 'required';
				$this->validation->set_rules($rules);
				$fields['title'] = $this->lang->line('market_label_title');
				$fields['description'] = $this->lang->line('market_label_description');
				//$fields['listnetworks']		= $this->lang->line('market_label_network');
				$fields['amount'] = $this->lang->line('market_label_amount');
				$this->validation->set_fields($fields);
		}
		function _subletRules($mode, $action)
		{
				$rules['title'] = 'trim|required|min_length[5]';
				$rules['description'] = 'trim|required|min_length[10]';
				$rules['amount'] = 'callback__isValidAmount';
				$rules['postalCode'] = 'callback__isValidPostalCode';
				$rules['squareFeet'] = 'callback__isValidFeet';
				//$rules['listnetworks']		= 'required';
				$this->validation->set_rules($rules);
				$fields['title'] = $this->lang->line('market_label_title');
				$fields['description'] = $this->lang->line('market_label_description');
				//$fields['listnetworks']		= $this->lang->line('market_label_network');
				$fields['squareFeet'] = $this->lang->line('market_label_square_feet');
				$fields['amount'] = $this->lang->line('market_label_amount');
				$this->validation->set_fields($fields);
		}
		function _rentalRules($mode, $action)
		{
				$rules['title'] = 'trim|required|min_length[5]';
				$rules['description'] = 'trim|required|min_length[10]';
				$rules['amount'] = 'callback__isValidAmount';
				$rules['postalCode'] = 'callback__isValidPostalCode';
				$rules['squareFeet'] = 'callback__isValidFeet';
				//$rules['listnetworks']		= 'required';
				$this->validation->set_rules($rules);
				$fields['title'] = $this->lang->line('market_label_title');
				$fields['description'] = $this->lang->line('market_label_description');
				//$fields['listnetworks']		= $this->lang->line('market_label_network');
				$fields['squareFeet'] = $this->lang->line('market_label_square_feet');
				$fields['amount'] = $this->lang->line('market_label_amount');
				$this->validation->set_fields($fields);
		}
		function _realEstateRules($mode, $action)
		{
				$rules['title'] = 'trim|required|min_length[5]';
				$rules['description'] = 'trim|required|min_length[10]';
				$rules['amount'] = 'callback__isValidAmount';
				$rules['postalCode'] = 'callback__isValidPostalCode';
				$rules['squareFeet'] = 'callback__isValidFeet';
				//$rules['listnetworks']		= 'required';
				$this->validation->set_rules($rules);
				$fields['title'] = $this->lang->line('market_label_title');
				$fields['description'] = $this->lang->line('market_label_description');
				//$fields['listnetworks']		= $this->lang->line('market_label_network');
				$fields['squareFeet'] = $this->lang->line('market_label_square_feet');
				$fields['amount'] = $this->lang->line('market_label_amount');
				$this->validation->set_fields($fields);
		}
		function _otherHousingRules($mode, $action)
		{
				$rules['title'] = 'trim|required|min_length[5]';
				$rules['description'] = 'trim|required|min_length[10]';
				$rules['postalCode'] = 'callback__isValidPostalCode';
				$rules['squareFeet'] = 'callback__isValidFeet';
				//$rules['listnetworks']		= 'required';
				$this->validation->set_rules($rules);
				$fields['title'] = $this->lang->line('market_label_title');
				$fields['description'] = $this->lang->line('market_label_description');
				//$fields['listnetworks']		= $this->lang->line('market_label_network');
				$fields['squareFeet'] = $this->lang->line('market_label_square_feet');
				$this->validation->set_fields($fields);
		}
		function _bookRules($mode, $action)
		{
				$rules['title'] = 'trim|required|min_length[5]';
				$rules['description'] = 'trim|required|min_length[10]';
				$rules['amount'] = 'callback__isValidAmount';
				$rules['isbn'] = 'callback__isValidISBN';
				//$rules['listnetworks']		= 'required';
				$this->validation->set_rules($rules);
				$fields['title'] = $this->lang->line('market_label_title');
				$fields['description'] = $this->lang->line('market_label_description');
				$fields['amount'] = $this->lang->line('market_label_price');
				$fields['isbn'] = $this->lang->line('market_label_isbn');
				//$fields['listnetworks']		= $this->lang->line('market_label_network');
				$this->validation->set_fields($fields);
		}
		function _furnitureRules($mode, $action)
		{
				$rules['title'] = 'trim|required|min_length[5]';
				$rules['description'] = 'trim|required|min_length[10]';
				$rules['amount'] = 'callback__isValidAmount';
				//$rules['listnetworks']		= 'required';
				$this->validation->set_rules($rules);
				$fields['title'] = $this->lang->line('market_label_title');
				$fields['description'] = $this->lang->line('market_label_description');
				//$fields['listnetworks']		= $this->lang->line('market_label_network');
				$this->validation->set_fields($fields);
		}
		function _carRules($mode, $action)
		{
				$rules['title'] = 'trim|required|min_length[5]';
				$rules['description'] = 'trim|required|min_length[10]';
				$rules['amount'] = 'callback__isValidAmount';
				//$rules['listnetworks']		= 'required';
				$this->validation->set_rules($rules);
				$fields['title'] = $this->lang->line('market_label_title');
				$fields['description'] = $this->lang->line('market_label_description');
				//$fields['listnetworks']		= $this->lang->line('market_label_network');
				$this->validation->set_fields($fields);
		}
		function _ticketRules($mode, $action)
		{
				$rules['title'] = 'trim|required|min_length[5]';
				$rules['description'] = 'trim|required|min_length[10]';
				$rules['amount'] = 'callback__isValidAmount';
				//$rules['listnetworks']		= 'required';
				$this->validation->set_rules($rules);
				$fields['title'] = $this->lang->line('market_label_title');
				$fields['description'] = $this->lang->line('market_label_description');
				//$fields['listnetworks']		= $this->lang->line('market_label_network');
				$this->validation->set_fields($fields);
		}
		function _electronicRules($mode, $action)
		{
				$rules['title'] = 'trim|required|min_length[5]';
				$rules['description'] = 'trim|required|min_length[10]';
				$rules['amount'] = 'callback__isValidAmount';
				//$rules['listnetworks']		= 'required';
				$this->validation->set_rules($rules);
				$fields['title'] = $this->lang->line('market_label_title');
				$fields['description'] = $this->lang->line('market_label_description');
				//$fields['listnetworks']		= $this->lang->line('market_label_network');
				$this->validation->set_fields($fields);
		}
		function _otherSaleRules($mode, $action)
		{
				$rules['title'] = 'trim|required|min_length[5]';
				$rules['description'] = 'trim|required|min_length[10]';
				$rules['amount'] = 'callback__isValidAmount';
				//$rules['listnetworks']		= 'required';
				$this->validation->set_rules($rules);
				$fields['title'] = $this->lang->line('market_label_title');
				$fields['description'] = $this->lang->line('market_label_description');
				//$fields['listnetworks']		= $this->lang->line('market_label_network');
				$this->validation->set_fields($fields);
		}
		function _freeRules($mode, $action)
		{
				$rules['title'] = 'trim|required|min_length[5]';
				$rules['description'] = 'trim|required|min_length[10]';
				//$rules['listnetworks']		= 'required';
				$this->validation->set_rules($rules);
				$fields['title'] = $this->lang->line('market_label_title');
				$fields['description'] = $this->lang->line('market_label_description');
				//$fields['listnetworks']		= $this->lang->line('market_label_network');
				$this->validation->set_fields($fields);
		}
		function _isValidAmount($amount)
		{
				if (trim($amount) != '')
				{
						if (!ereg("^[0-9]+(\.[0-9]+)?$", $amount))
						{
								$this->validation->set_message('_isValidAmount', $this->lang->line('market_label_the') . ' %s ' . $this->lang->line('market_label_entered_is_not_valid'));
								return false;
						}
						else
						{
								return true;
						}
				}
				else
				{
						return true;
				}
		}
		function _isValidISBN($isbn)
		{
				if (trim($isbn) != '')
				{
						if (!ereg("^[0-9]{10}|[0-9]{3}\-[0-9]{10}$", $isbn))
						{
								$this->validation->set_message('_isValidISBN', $this->lang->line('market_label_the') . ' %s ' . $this->lang->line('market_label_entered_is_not_valid'));
								return false;
						}
						else
						{
								return true;
						}
				}
				else
				{
						return true;
				}
		}
		function _isValidPostalCode($postalCode)
		{
				if (trim($postalCode) != '')
				{
						if (!ereg("^[0-9a-zA-Z][0-9a-zA-Z \-\*]{5,}$", $postalCode))
						{
								$this->validation->set_message('_isValidPostalCode', $this->lang->line('market_label_the') . ' %s ' . $this->lang->line('market_label_entered_is_not_valid'));
								return false;
						}
						else
						{
								return true;
						}
				}
				else
				{
						return true;
				}
		}
		function _isValidFeet($val)
		{
				if (trim($val) != '')
				{
						if (!ereg("^[123456789][0-9]*$", $val))
						{
								$this->validation->set_message('_isValidFeet', $this->lang->line('market_label_the') . ' %s ' . $this->lang->line('market_label_entered_is_not_valid'));
								return false;
						}
						else
						{
								return true;
						}
				}
				else
				{
						return true;
				}
		}
}
?>