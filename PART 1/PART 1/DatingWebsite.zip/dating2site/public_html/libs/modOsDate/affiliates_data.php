<?php

   class affiliatesData extends Data {

      var $table = AFFILIATES_TABLE;

      var $config = array (
  'table' => AFFILIATES_TABLE,
  'idField' => 'id',
  'addedMsg' => 'Osdate Affiliates %s Added',
  'added_err' => 'Can\\\'t Add Osdate Affiliates',
  'editMsg' => 'Osdate Affiliates %s Updated',
  'editErr' => 'Can\\\'t Update Osdate Affiliates',
  'delErr' => 'Can\\\'t Delete Osdate Affiliates',
  'delMsg' => 'Osdate Affiliates %s Deleted',
  'blankErr' => 'Osdate Affiliates Empty',
  'fields' => 
  array (
    'name' => 
    array (
      'name' => 'name',
      'description' => 'Name',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 255,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'email' => 
    array (
      'name' => 'email',
      'description' => 'Email',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 255,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'password' => 
    array (
      'name' => 'password',
      'description' => 'Password',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 32,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'status' => 
    array (
      'name' => 'status',
      'description' => 'Status',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 255,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'regdate' => 
    array (
      'name' => 'regdate',
      'description' => 'Regdate',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
  ),
);   

      function affiliatesData() {
      
         $this->Data($this->config);
      }
   }

?>
