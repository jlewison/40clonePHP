		<div id="soc">
			<a target="_blank" rel="nofollow" href="http://digg.com/submit?phase=2&url=http://<?php echo("$domainname");?>&title=<?php echo("$sitetitle");?>&bodytext=<?php echo $row_UPBID['descr1']; ?> <?php echo $row_UPBID['descr2']; ?>" title="Digg It!"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/diggIcon.gif" alt="Digg It!" border="0" /></a> <a target="_blank" rel="nofollow" href="http://del.icio.us/post?url=http://<?php echo("$domainname");?>&title=<?php echo("$sitetitle");?>&notes=<?php echo $row_UPBID['descr1']; ?> <?php echo $row_UPBID['descr2']; ?>"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/deliciousIcon.gif" alt="Del.icio.us" border="0" /></a> <a target="_blank" rel="nofollow" href="http://www.stumbleupon.com/submit?url=http://<?php echo("$domainname");?>&title=<?php echo("$sitetitle");?>"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/stumbleuponIcon.gif" alt="StumbleUpon" border="0" /></a> <a target="_blank" rel="nofollow" href="http://www.google.com/bookmarks/mark?op=edit&bkmk=http://<?php echo("$domainname");?>&title=<?php echo("$sitetitle");?>"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/googleIcon.gif" alt="Google Bookmarks" border="0" /></a> <a target="_blank" rel="nofollow" href="http://myweb2.search.yahoo.com/myresults/bookmarklet?u=http://<?php echo("$domainname");?>&t=<?php echo("$sitetitle");?>"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/yahooIcon.gif" alt="Yahoo! Bookmarklet" border="0" /></a> <a target="_blank" rel="nofollow" href="http://www.furl.net/storeIt.jsp?u=http://<?php echo("$domainname");?>&t=<?php echo("$sitetitle");?>"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/furlIcon.gif" alt="Furl" border="0" /></a> <a target="_blank" rel="nofollow" href="http://reddit.com/submit?url=http://<?php echo("$domainname");?>&title=<?php echo("$sitetitle");?>"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/redditIcon.gif" alt="reddit" border="0" /></a> <a target="_blank" rel="nofollow" href="http://technorati.com/cosmos/search.html?url=http://<?php echo("$domainname");?>"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/technoratiIcon.gif" alt="Technorati" border="0" /></a> <a target="_blank" rel="nofollow" href="http://www.blinklist.com/index.php?Action=Blink/addblink.php&Description=&Url=http://<?php echo("$domainname");?>&Title=<?php echo("$sitetitle");?>" title="Blink It!"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/blinklistIcon.gif" alt="Blink It!" border="0" /></a> <a target="_blank" rel="nofollow" href="http://www.plugim.com/submit?url=http://<?php echo("$domainname");?>&title=<?php echo("$sitetitle");?>&trackback=" title="PlugIm!"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/plugimIcon.gif" alt="PlugIm!" border="0" /></a> <a target="_blank" rel="nofollow" href="http://co.mments.com/track?url=http://<?php echo("$domainname");?>&title=<?php echo("$sitetitle");?>"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/commentsIcon.gif" alt="co.mments" border="0" /></a> <a target="_blank" rel="nofollow" href="http://www.newsvine.com/_tools/seed&save?u=http://<?php echo("$domainname");?>&h=<?php echo("$sitetitle");?>"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/newsvineIcon.gif" alt="Newsvine" border="0" /></a> <a target="_blank" rel="nofollow" href="http://www.netscape.com/submit/?U=http://<?php echo("$domainname");?>&T=<?php echo("$sitetitle");?>"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/netscapeIcon.gif" alt="Netscape" border="0" /></a> <a target="_blank" rel="nofollow" href="http://ma.gnolia.com/bookmarklet/add?url=http://<?php echo("$domainname");?>&title=<?php echo("$sitetitle");?>"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/magnoliaIcon.gif" alt="Ma.gnolia.com" border="0" /></a> <a target="_blank" rel="nofollow" href="http://www.simpy.com/simpy/LinkAdd.do?href=http://<?php echo("$domainname");?>&title=<?php echo("$sitetitle");?>" title="Simpify!"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/simpyIcon.gif" alt="Simpify!" border="0" /></a> <a target="_blank" rel="nofollow" href="http://www.spurl.net/spurl.php?url=http://<?php echo("$domainname");?>&title=<?php echo("$sitetitle");?>"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/spurlIcon.gif" alt="Spurl.net" border="0" /></a>
		</div>
	</div></div>
	<div id="sidebar">
		<div class="box">
			<h3><?php echo("$lang_17");?></h3>
			<a href="<?php echo $row_top_BID['site']; ?>" target="_blank" title="<?php echo $row_top_BID['title']; ?>"><img src="http://open.thumbshots.org/image.aspx?url=<?php echo $row_top_BID['site']; ?>" alt="<?php echo $row_top_BID['title']; ?>" style="height:90px; width:120px; border: none" /></a>
			<br/>
			<a href="<?php echo $row_top_BID['site']; ?>" target='_blank'><?php echo $row_top_BID['title']; ?></a>
		</div>
		<div class="box">
			<h3>Welcome to LBS powered website!</h3>
			The content of this site has been carefully reviewed by our editors and found to be of the highest quality possible before it was approved for listing on this site. You are also welcomed to suggest your site for listing in this LBS powered directory.
		</div>
		<div class="box">
			<h3>Categories</h3>
			<?php if($nocat <> 'Y') { include('template/GreenAndBlack/b_subcategory.php'); } else {} ?>
			<ul>   
			<?php do { ?>
				<li><a href="<?php echo("$path");?><?php echo $row_categRL['categseoname']; ?>/"><?php echo $row_categRL['categoryname']; ?></a></li>
			<?php
			$row_categRL = mysql_fetch_assoc($categRL);
			if (!isset($nested_categRL)) { $nested_categRL= 1; }
			} while ($row_categRL);
			?>
			<li><a href="<?php echo("$path");?>contact.php"><?php echo("$lang_21");?></a></li>
			</ul>
		</div>
		<div class="box">
			<h3>Advertisement</h3>
			<?php echo("$adsensecode");?>
		</div>
	</div>
</div>