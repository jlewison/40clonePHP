<?php
require_once ('../common/config.inc.php');
$CFG['lang']['include_files'][] = 'admin/includes/languages/%s/forums.php';
$CFG['lang']['include_files'][] = 'admin/includes/languages/%s/forumsSearch.php';
$CFG['html']['header'] = 'admin/includes/languages/%s/html_header.php';
$CFG['html']['footer'] = 'admin/includes/languages/%s/html_footer.php';
$CFG['lang']['include_files'][] = 'common/languages/%s/lists_array/months_list_array.inc.php';
$CFG['lang']['include_files'][] = 'common/configs/config_forums.inc.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['mods']['include_files'][] = 'common/classes/class_ListRecordsHandler.lib.php';
$CFG['db']['is_use_db'] = true;
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class ForumsFormHandler extends ListRecordsHandler
{
		public function buildConditionQuery($condition = '')
		{
				$this->sql_condition = $condition;
		}
		public function buildSortQuery()
		{
				$this->sql_sort = $this->fields_arr['orderby_field'] . ' ' . $this->fields_arr['orderby'];
		}
		public function activeForumTitles()
		{
				$forum_ids = $this->fields_arr['forum_ids'];
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['forums'] . ' SET forum_status = \'Yes\' ' . 'WHERE forum_id IN (' . $forum_ids . ') ';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return true;
		}
		public function inactiveForumTitles()
		{
				$forum_ids = $this->fields_arr['forum_ids'];
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['forums'] . ' SET forum_status = \'No\' ' . 'WHERE forum_id IN (' . $forum_ids . ') ';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return true;
		}
		public function deleteForumTitles()
		{
				$forum_ids = $this->fields_arr['forum_ids'];
				$this->deleteForumsTable($forum_ids);
		}
		public function deleteForumResponseTable($topic_ids)
		{
				$sql = 'DELETE FROM ' . $this->CFG['db']['tbl']['forum_response'] . ' ' . 'WHERE topic_id IN (' . $topic_ids . ') ';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return true;
		}
		public function deleteForumTopicsTable($forum_ids)
		{
				$sql = 'SELECT topic_id ' . 'FROM ' . $this->CFG['db']['tbl']['forum_topics'] . ' ' . 'WHERE forum_id IN (' . $forum_ids . ') ';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if (!$rs->FetchRow()) return true;
				$topic_ids = 0;
				while ($row = $rs->FetchRow())
				{
						($topic_ids) ? $topic_ids = $topic_ids . ', ' . $row['topic_id'] : $topic_ids = $row['topic_id'];
				}
				if ($topic_ids) $this->deleteForumResponseTable($topic_ids);
				$sql = 'DELETE FROM ' . $this->CFG['db']['tbl']['forum_topics'] . ' ' . 'WHERE forum_id IN (' . $forum_ids . ') ';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return true;
		}
		public function deleteForumsTable($forum_ids)
		{
				$this->deleteForumTopicsTable($forum_ids);
				$sql = 'DELETE FROM ' . $this->CFG['db']['tbl']['forums'] . ' ' . 'WHERE forum_id IN (' . $forum_ids . ') ';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return true;
		}
		public function getForumIds($column_name, $search_value)
		{
				$sql = 'SELECT DISTINCT(forum_id) FROM ' . $this->CFG['db']['tbl']['forum_topics'] . ' WHERE ';
				$condition = $column_name . ' LIKE \'%' . addslashes($search_value) . '%\'';
				if ($column_name == 'topic_id')
				{
						$condition = $column_name . ' IN (' . $search_value . ')';
				}
				$sql .= $condition;
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$forum_ids = 0;
				while ($row = $rs->FetchRow())
				{
						$forum_ids .= ', ' . $row['forum_id'];
				}
				return $forum_ids;
		}
		public function getTopicIds($search_value)
		{
				$sql = 'SELECT DISTINCT(topic_id) AS topic_id FROM ' . $this->CFG['db']['tbl']['forum_response'] . ' WHERE ' . 'forum_response LIKE \'%' . addslashes($search_value) . '%\' ';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$topic_ids = 0;
				while ($row = $rs->FetchRow())
				{
						$topic_ids .= ', ' . $row['topic_id'];
				}
				return $topic_ids;
		}
		public function showForumTitles()
		{
				if (!$this->isResultsFound())
				{
?>
					<div id="selMsgAlert">
						<p><?php echo $this->LANG['forums_no_titles']; ?></p>
						<p class="clsMsgAdditionalText"><?php echo $this->LANG['forums_click_create']; ?></p>
					</div>
				<?php
				}
?>
				<table border="1" cellspacing="0" summary="<?php echo $this->LANG['forums_tbl_summary']; ?>" class="clsForumTbl">
					<tr>
						<th>&nbsp;<input type="checkbox" class="clsCheckRadio" name="check_all" id="check_all" tabindex="<?php echo $this->getTabIndex(); ?>" onclick="CheckAll(document.selFormForums.name, document.selFormForums.check_all.name)"/></th>
						<th><?php echo $this->LANG['forums_title']; ?></th>
						<th>&nbsp;</th>
						<th><?php echo $this->LANG['forums_status']; ?></th>
						<th><?php echo $this->LANG['forums_date_created']; ?></th>
						<th><?php echo $this->LANG['forums_last_post']; ?></th>
						<th><?php echo $this->LANG['forums_manage']; ?></th>
					</tr>
				<?php
				while ($row = $this->fetchResultRecord())
				{
						$userDetails = $row;
						$userDetails['user_id'] = $row['last_post_user_id'];
?>
						<tr>
							<td class="clsAlignCenter"><input type="checkbox" class="clsCheckRadio" name="forum_ids[]" value="<?php echo $row['forum_id']; ?>" onClick="disableHeading('selFormForums');" tabindex="<?php echo $this->getTabIndex(); ?>" <?php if ((is_array($this->fields_arr['forum_ids'])) && (in_array($row['forum_id'], $this->fields_arr['forum_ids']))) echo "CHECKED"; ?>/></td>
							<td class="clsForumTitleDes">
								<h3><a href="forumsTopics.php?forum_id=<?php echo $row['forum_id']; ?>">
									<?php echo stripslashes($row['forum_title']); ?>
								</a></h3>
								<p>
									<?php echo nl2br(stripslashes($row['forum_description'])); ?>
								</p>
							</td>
							<td>
								<p><?php echo $this->LANG['forums_topics'] . ' ' . $row['total_topics']; ?></p>
								<p><?php echo $this->LANG['forums_responses'] . ' ' . $row['total_response']; ?></p>
							</td>
							<td>
								<p><?php echo $row['forum_status']; ?></p>
							</td>
							<td>
								<p><?php echo $row['date_added']; ?></p>
							</td><td>
								<?php if (chkUserImageAllowed())
						{ ?>
								<p id="selImageBorder"><?php displayForumUserSmallImage($userDetails, false); ?></p>
								<?php } ?>
								<p><?php echo $userDetails['name']; ?></p>
							</td>
							<td>
								<p class="clsEdit">
									<a href="forumsAddTitle.php?forum_id=<?php echo $row['forum_id']; ?>">
										<?php echo $this->LANG['forums_edit']; ?>
									</a>
								</p>
							</td>
						</tr>
					<?php
				}
				$anchor = 'dAltMlti';
?>
				<tr>
					<td colspan="7" class="<?php echo $this->getCSSFormFieldCellClass('action'); ?>">
						<a href="#" id="<?php echo $anchor; ?>"></a>
						<select name="action" id="action" tabindex="<?php echo $this->getTabIndex(); ?>">
							<option value=""><?php echo $this->LANG['forums_select']; ?></option>
							<option value="Active" <?php if ($this->fields_arr['action'] == 'active') echo 'SELECTED'; ?> ><?php echo $this->LANG['forums_active']; ?></option>
							<option value="Inactive" <?php if ($this->fields_arr['action'] == 'inactive') echo 'SELECTED'; ?> ><?php echo $this->LANG['forums_inactive']; ?></option>
							<option value="Delete" <?php if ($this->fields_arr['action'] == 'delete') echo 'SELECTED'; ?> ><?php echo $this->LANG['forums_delete']; ?></option>
						</select>
						&nbsp;&nbsp;
						<input type="button" class="clsSubmitButton" name="action_button" id="action_button" value="<?php echo $this->LANG['forums_action']; ?>" onClick="getMultiCheckBoxValue('selFormForums', 'check_all', '<?php echo $this->LANG['forums_err_tip_select_titles']; ?>', 'dAltMlti');if(multiCheckValue!=''){getAction()}" />
					</td>
				</tr>
				</table>
				<?php
		}
		public function populateConditionOperators($highlight_operator)
		{
?>
				<option value="equalto" <?php if ($highlight_operator == 'equalto') echo 'SELECTED'; ?>><?php echo $this->LANG['forumsearch_equal_to'] ?></option>
				<option value="greaterthan" <?php if ($highlight_operator == 'greaterthan') echo 'SELECTED'; ?>><?php echo $this->LANG['forumsearch_greater_than'] ?></option>
				<option value="greaterthanequal" <?php if ($highlight_operator == 'greaterthanequal') echo 'SELECTED'; ?>><?php echo $this->LANG['forumsearch_greater_than_equal'] ?></option>
				<option value="lessthan" <?php if ($highlight_operator == 'lessthan') echo 'SELECTED'; ?>><?php echo $this->LANG['forumsearch_less_than'] ?></option>
				<option value="lessthanequal" <?php if ($highlight_operator == 'lessthanequal') echo 'SELECTED'; ?>><?php echo $this->LANG['forumsearch_less_than_equal'] ?></option>
				<option value="notequal" <?php if ($highlight_operator == 'notequal') echo 'SELECTED'; ?>><?php echo $this->LANG['forumsearch_not_equal'] ?></option>
			<?php
		}
}
$forums = new ForumsFormHandler();
$forums->setPageBlockNames(array('msg_form_error', 'msg_form_success', 'form_show_forums', 'form_search', 'page_nav', 'form_confirm', 'form_search'));
$forums->setCSSAlternativeRowClasses($CFG['data_tbl']['css_alternative_row_classes']);
$forums->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$forums->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$forums->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$forums->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$forums->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$forums->setDBObject($db);
$forums->setCfgLangGlobal($CFG, $LANG);
$forums->setAllPageBlocksHide();
$forums->setFormField('forum_ids', array());
$forums->setFormField('srch', '');
$forums->setFormField('numpg', 0);
$forums->setFormField('start', 0);
$forums->setFormField('action', '');
$forums->setFormField('srch_title', '');
$forums->setFormField('srch_topic', '');
$forums->setFormField('srch_topic_cnt', '');
$forums->setFormField('topic_condition', '');
$forums->setFormField('srch_response', '');
$forums->setFormField('srch_response_cnt', '');
$forums->setFormField('response_condition', '');
$forums->setFormField('srch_uname', '');
$forums->setFormField('srch_status', '');
$forums->setFormField('status_active', '');
$forums->setFormField('status_inactive', '');
$forums->setFormField('srch_date_added', '');
$forums->setFormField('srch_date', '');
$forums->setFormField('srch_month', '');
$forums->setFormField('srch_year', '');
$condition_operators = array('equalto', 'greaterthan', 'greaterthanequal', 'lessthan', 'lessthanequal', 'notequal');
$operators_arr = array('equalto' => "=", 'greaterthan' => ">", 'greaterthanequal' => ">=", 'lessthan' => "<", 'lessthanequal' => "<=", 'notequal' => "!=");
$forums->setMonthsListArr($LANG_LIST_ARR['months']);
$forums->setFormField('orderby_field', '');
$forums->setFormField('orderby', '');
$condition = '';
$forums->numpg = $CFG['data_tbl']['numpg'];
$forums->setFormField('start', 0);
$forums->setFormField('numpg', $CFG['data_tbl']['numpg']);
$forums->setMinRecordSelectLimit($CFG['data_tbl']['min_record_select_limit']);
$forums->setMaxRecordSelectLimit($CFG['data_tbl']['max_record_select_limit']);
$forums->setNumPerPageListArr($CFG['data_tbl']['numperpage_list_arr']);
$forums->setTableNames(array());
$forums->setReturnColumns(array());
$forums->sanitizeFormInputs($_REQUEST);
if ($forums->isFormGETed($_REQUEST))
{
		$forums->getFormField('srch_topic_cnt') and $forums->chkIsNumeric('srch_topic_cnt', $LANG['forums_err_tip_enter_numbers']);
		$forums->getFormField('srch_response_cnt') and $forums->chkIsNumeric('srch_response_cnt', $LANG['forums_err_tip_enter_numbers']);
		if ($forums->getFormField('srch_date') || $forums->getFormField('srch_month') || $forums->getFormField('srch_year'))
		{
				$forums->chkIsCorrectDate($forums->getFormField('srch_date'), $forums->getFormField('srch_month'), $forums->getFormField('srch_year'), 'srch_date_added', $LANG['forums_err_tip_date_empty'], $LANG['forums_err_tip_date_invalid']);
		}
}
if ($forums->isFormPOSTed($_POST, 'confirm_action'))
{
		$forums->chkIsNotEmpty('forum_ids', $LANG['forums_err_tip_compulsory']) or $forums->setCommonErrorMsg($LANG['forums_err_tip_select_titles']);
		$forums->chkIsNotEmpty('action', $LANG['forums_err_tip_compulsory']) or $forums->setCommonErrorMsg($LANG['forums_err_tip_select_action']);
		if ($forums->isValidFormInputs())
		{
				switch ($forums->getFormField('action'))
				{
						case 'Delete':
								$forums->deleteForumTitles();
								$success_msg = $LANG['forums_success_delete_message'];
								break;
						case 'Active':
								$forums->activeForumTitles();
								$success_msg = $LANG['forums_success_active_message'];
								break;
						case 'Inactive':
								$forums->inactiveForumTitles();
								$success_msg = $LANG['forums_success_inactive_message'];
								break;
				}
				$forums->setFormField('forum_ids', array());
		}
		if ($forums->isValidFormInputs())
		{
				$forums->setPageBlockShow('msg_form_success');
		}
		else
		{
				$forums->setPageBlockShow('msg_form_error');
		}
} elseif ($forums->isFormPOSTed($_POST, 'forums_cancel'))
{
		$forums->setFormField('forum_ids', array());
}
$search_condition = '';
$searchArr = array();
$searchArr[] = 'srch';
$queryStr = '';
if ($forums->getFormField('srch_title'))
{
		$search_condition .= ' AND f.forum_title like \'%' . addslashes($forums->getFormField('srch_title')) . '%\'';
		$searchArr[] = 'srch_title';
		$queryStr .= '&srch_title=' . $forums->getFormField('srch_title');
}
if ($forums->getFormField('srch_topic'))
{
		$forum_ids = $forums->getForumIds('forum_topic', $forums->getFormField('srch_topic'));
		$search_condition .= ' AND f.forum_id IN (' . $forum_ids . ')';
		$searchArr[] = 'srch_topic';
		$queryStr .= '&srch_topic=' . $forums->getFormField('srch_topic');
}
if ($forums->getFormField('srch_response'))
{
		$topic_ids = $forums->getTopicIds($forums->getFormField('srch_response'));
		$forum_ids = $forums->getForumIds('topic_id', $topic_ids);
		$search_condition .= ' AND f.forum_id IN (' . $forum_ids . ')';
		$searchArr[] = 'srch_response';
		$queryStr .= '&srch_response=' . $forums->getFormField('srch_response');
}
if ($forums->getFormField('srch_topic_cnt'))
{
		$operator = '=';
		if (in_array($forums->getFormField('topic_condition'), $condition_operators)) $operator = $operators_arr[$forums->getFormField('topic_condition')];
		$search_condition .= ' AND f.total_topics ' . $operator . ' \'' . addslashes($forums->getFormField('srch_topic_cnt')) . '\'';
		$searchArr[] = 'srch_topic_cnt';
		$searchArr[] = 'topic_condition';
		$queryStr .= '&srch_topic_cnt=' . $forums->getFormField('srch_topic_cnt');
		$queryStr .= '&topic_condition=' . $forums->getFormField('topic_condition');
}
if ($forums->getFormField('srch_response_cnt'))
{
		$operator = '=';
		if (in_array($forums->getFormField('response_condition'), $condition_operators)) $operator = $operators_arr[$forums->getFormField('response_condition')];
		$search_condition .= ' AND f.total_response ' . $operator . ' \'' . addslashes($forums->getFormField('srch_response_cnt')) . '\'';
		$searchArr[] = 'srch_response_cnt';
		$searchArr[] = 'response_condition';
		$queryStr .= '&srch_response_cnt=' . $forums->getFormField('srch_response_cnt');
		$queryStr .= '&response_condition=' . $forums->getFormField('response_condition');
}
if ($forums->getFormField('srch_uname'))
{
		$search_condition .= ' AND u.' . $forums->getUserTableField('name') . ' like \'%' . addslashes($forums->getFormField('srch_uname')) . '%\'';
		$searchArr[] = 'srch_uname';
		$queryStr .= '&srch_uname=' . $forums->getFormField('srch_uname');
}
$forum_status = array();
if ($forums->getFormField('status_active'))
{
		$forum_status[] = '\'Yes\'';
		$searchArr[] = 'status_active';
		$queryStr .= '&status_active=' . $forums->getFormField('status_active');
}
if ($forums->getFormField('status_inactive'))
{
		$forum_status[] = '\'No\'';
		$searchArr[] = 'status_inactive';
		$queryStr .= '&status_inactive=' . $forums->getFormField('status_inactive');
}
if ($forum_status)
{
		$forum_statuses = implode(',', $forum_status);
		$search_condition .= ' AND f.forum_status IN (' . $forum_statuses . ')';
}
if ($forums->getFormField('srch_date_added'))
{
		$search_condition .= ' AND f.date_added >= \'' . $forums->getFormField('srch_date_added') . ' 00:00:00\'';
		$search_condition .= ' AND f.date_added <= DATE_ADD(\'' . $forums->getFormField('srch_date_added') . ' 00:00:00\', INTERVAL 1 DAY)';
		$searchArr[] = 'srch_date';
		$queryStr .= '&srch_date=' . $forums->getFormField('srch_date');
		$searchArr[] = 'srch_month';
		$queryStr .= '&srch_month=' . $forums->getFormField('srch_month');
		$searchArr[] = 'srch_year';
		$queryStr .= '&srch_year=' . $forums->getFormField('srch_year');
}
$forums->setFormField('queryStr', $queryStr);
$forums->setTableNames(array($CFG['db']['tbl']['forums'] . ' as f LEFT JOIN ' . $CFG['db']['tbl']['users'] . ' AS u on f.last_post_user_id = u.' . $forums->getUserTableField('user_id')));
$forums->setReturnColumns(array('f.forum_id', 'f.forum_title', 'f.forum_description', 'DATE_FORMAT(f.date_added, \'' . $forums->CFG['format']['date'] . '\') AS date_added', 'CASE WHEN f.forum_status = \'Yes\' THEN \'' . $LANG['forums_active'] . '\' ELSE \'' . $LANG['forums_inactive'] . '\' END AS forum_status', 'f.total_topics', 'f.total_response', 'f.last_post_date', 'f.last_post_user_id', $forums->getUserTableField('name') . ' as name', $forums->getUserTableField('image_path') . ' as image_path', $forums->getUserTableField('gender') . ' as gender', 'f.last_post_user_id AS img_user_id', $forums->getUserTableFields(array('t_height', 't_width', 's_height', 's_width', 'photo_server_url', 'photo_ext'))));
$condition = '1';
if ($search_condition)
{
		$condition .= $search_condition;
}
$forums->buildSelectQuery();
$forums->buildConditionQuery($condition);
$forums->buildSortQuery();
$defaultClass = $topicsClass = $responseClass = '';
if ($forums->getFormField('srch') == 'mosttopics')
{
		$forums->setFormField('orderby_field', 'f.total_topics');
		$forums->setFormField('orderby', 'DESC');
		$topicsClass = 'class="clsActivePhotoSubLink"';
} elseif ($forums->getFormField('srch') == 'mostresponses')
{
		$forums->setFormField('orderby_field', 'f.total_response');
		$forums->setFormField('orderby', 'DESC');
		$responseClass = 'class="clsActivePhotoSubLink"';
}
else
{
		$forums->setFormField('orderby_field', 'f.forum_title');
		$forums->setFormField('orderby', 'ASC');
		$defaultClass = 'class="clsActivePhotoSubLink"';
}
$forums->buildSortQuery();
$forums->buildQuery();
$forums->executeQuery();
$forums->setPageBlockShow('form_show_forums');
$forums->setPageBlockShow('form_search');
if ($forums->isResultsFound())
{
		$forums->setPageBlockShow('page_nav');
}




?>
<script language="javascript">
	var block_arr= new Array('selMsgConfirm');
	var replace_url = '<?php echo $CFG['site']['url']; ?>login.php';
	var please_select_action = '<?php echo $LANG['forums_err_tip_select_action']; ?>';
	var confirm_message = '';
	function getAction()
		{
			var act_value = document.selFormForums.action.value;
			if(act_value)
				{
					switch (act_value)
						{
							case 'Delete':
								confirm_message = '<?php echo $LANG['forums_delete_confirm_message']; ?>';
								break;
							case 'Active':
								confirm_message = '<?php echo $LANG['forums_active_confirm_message']; ?>';
								break;
							case 'Inactive':
								confirm_message = '<?php echo $LANG['forums_inactive_confirm_message']; ?>';
								break;
						}
					$('confirmMessage').innerHTML = confirm_message;
					document.msgConfirmform.action.value = act_value;
					Confirmation('dAltMlti', 'selMsgConfirm', 'msgConfirmform', Array('forum_ids'), Array(multiCheckValue), Array('value'), -25, -290, 'selFormForums');
				}
				else
					alert_manual(please_select_action, 'dAltMlti');
		}
</script>
<div id="selForums" class="clsForums">
	<h2 class="clsForumTitle"><?php echo $LANG['forums_title_index']; ?></h2>
	<div id="selMsgConfirm" class="clsPopupConfirmation" style="display:none;position:absolute;">
		<p id="confirmMessage"></p>
		<form name="msgConfirmform" id="msgConfirmform" method="post" action="<?php echo URL($_SERVER['PHP_SELF']); ?>">
			<table summary="<?php echo $LANG['forums_confirm_tbl_summary']; ?>">
				<tr>
					<td>
						<input type="submit" class="clsSubmitButton" name="confirm_action" id="confirm_action" tabindex="<?php echo $forums->getTabIndex(); ?>" value="<?php echo $LANG['forums_confirm']; ?>" />
						&nbsp;
						<input type="button" class="clsCancelButton" name="cancel" id="cancel" tabindex="<?php echo $forums->getTabIndex(); ?>" value="<?php echo $LANG['forums_cancel']; ?>"  onClick="return hideAllBlocks('selFormForums');" />
						<input type="hidden" name="forum_ids" id="forum_ids" />
						<input type="hidden" name="action" id="action" />
						<?php $forums->populateHidden(array('start', 'srch', 'srch_title', 'srch_topic', 'srch_topic_cnt', 'topic_condition', 'srch_response', 'srch_response_cnt', 'response_condition', 'srch_uname', 'status_active', 'status_inactive', 'srch_date', 'srch_month', 'srch_year', 'start', 'orderby_field', 'orderby')); ?>
					</td>
				</tr>
			</table>
		</form>
	</div>
    <div id="selLeftNavigation">
<?php
if ($forums->isShowPageBlock('msg_form_error'))
{
?>
		<div id="selMsgError">
			 <p><?php echo $LANG['msg_error_sorry']; ?> <?php echo $forums->getCommonErrorMsg(); ?></p>
		</div>
<?php
}
if ($forums->isShowPageBlock('msg_form_success'))
{
?>
		<div id="selMsgSuccess">
			<p><?php echo $success_msg; ?></p>
		</div>
<?php
}
if ($forums->isShowPageBlock('form_search'))
{
?>
	<div id="selShowSearchGroup">
	<form name="form_search" id="selFormSearch" method="post" action="<?php echo URL($_SERVER['PHP_SELF']); ?>" autocomplete="off">
		<table border="0" cellspacing="0" summary="<?php echo $LANG['forumsearch_tbl_summary']; ?>">
			<tr>
				<td class="<?php echo $forums->getCSSFormLabelCellClass('srch_title'); ?>"><label for="srch_title"><?php echo $LANG['forumsearch_search_title']; ?></label></td>
				<td class="<?php echo $forums->getCSSFormFieldCellClass('srch_title'); ?>"><?php echo $forums->getFormFieldErrorTip('srch_title'); ?><input type="text" class="clsTextBox" name="srch_title" id="srch_title" value="<?php echo $forums->getFormField('srch_title'); ?>" tabindex="<?php echo $forums->getTabIndex(); ?>"/></td>
			</tr>
			<tr>
				<td class="<?php echo $forums->getCSSFormLabelCellClass('srch_topic'); ?>"><label for="srch_topic"><?php echo $LANG['forumsearch_search_topics']; ?></label></td>
				<td class="<?php echo $forums->getCSSFormFieldCellClass('srch_topic'); ?>"><input type="text" class="clsTextBox" name="srch_topic" id="srch_topic" value="<?php echo $forums->getFormField('srch_topic'); ?>" tabindex="<?php echo $forums->getTabIndex(); ?>"/></td>
			</tr>
			<tr>
				<td class="<?php echo $forums->getCSSFormLabelCellClass('srch_topic_cnt'); ?>"><label for="srch_topic_cnt"><?php echo $LANG['forumsearch_search_topics_count']; ?></label></td>
				<td class="<?php echo $forums->getCSSFormFieldCellClass('srch_topic_cnt'); ?>">
					<select name="topic_condition" id="topic_condition" tabindex="<?php echo $forums->getTabIndex(); ?>" >
						<?php $forums->populateConditionOperators($forums->getFormField('topic_condition')); ?>
					</select>
					<?php echo $forums->getFormFieldErrorTip('srch_topic_cnt'); ?>
					<input type="text" class="clsTextBox clsMediumTextBox" name="srch_topic_cnt" id="srch_topic_cnt" value="<?php echo $forums->getFormField('srch_topic_cnt'); ?>" tabindex="<?php echo $forums->getTabIndex(); ?>"/>
				</td>
			</tr>
			<tr>
				<td class="<?php echo $forums->getCSSFormLabelCellClass('srch_response'); ?>"><label for="srch_response"><?php echo $LANG['forumsearch_search_response']; ?></label></td>
				<td class="<?php echo $forums->getCSSFormFieldCellClass('srch_response'); ?>"><input type="text" class="clsTextBox" name="srch_response" id="srch_response" value="<?php echo $forums->getFormField('srch_response'); ?>" tabindex="<?php echo $forums->getTabIndex(); ?>"/></td>
			</tr>
			<tr>
				<td class="<?php echo $forums->getCSSFormLabelCellClass('srch_response_cnt'); ?>"><label for="srch_response_cnt"><?php echo $LANG['forumsearch_search_response_count']; ?></label></td>
				<td class="<?php echo $forums->getCSSFormFieldCellClass('srch_response_cnt'); ?>">
					<select name="response_condition" id="response_condition" tabindex="<?php echo $forums->getTabIndex(); ?>" >
						<?php $forums->populateConditionOperators($forums->getFormField('response_condition')); ?>
					</select>
					<?php echo $forums->getFormFieldErrorTip('srch_response_cnt'); ?>
					<input type="text" class="clsTextBox clsMediumTextBox" name="srch_response_cnt" id="srch_response_cnt" value="<?php echo $forums->getFormField('srch_response_cnt'); ?>" tabindex="<?php echo $forums->getTabIndex(); ?>"/>
				</td>
			</tr>
			<tr>
				<td class="<?php echo $forums->getCSSFormLabelCellClass('srch_uname'); ?>"><label for="srch_uname"><?php echo $LANG['forumsearch_search_uname']; ?></label></td>
				<td class="<?php echo $forums->getCSSFormFieldCellClass('srch_uname'); ?>"><input type="text" class="clsTextBox" name="srch_uname" id="srch_uname" value="<?php echo $forums->getFormField('srch_uname'); ?>" tabindex="<?php echo $forums->getTabIndex(); ?>"/></td>
			</tr>
			<tr>
				<td class="<?php echo $forums->getCSSFormLabelCellClass('srch_status'); ?>"><label for="status_active"><?php echo $LANG['forumsearch_search_status']; ?></label></td>
				<td class="<?php echo $forums->getCSSFormFieldCellClass('srch_status'); ?>">
					<input type="checkbox" class="clsCheckRadio" name="status_active" id="status_active" <?php if ($forums->getFormField('status_active')) echo 'CHECKED'; ?> value="Active" tabindex="<?php echo $forums->getTabIndex(); ?>" />
					<label for="status_active"><?php echo $LANG['forumsearch_search_active']; ?></label>&nbsp;&nbsp;&nbsp;
					<input type="checkbox" class="clsCheckRadio" name="status_inactive" id="status_inactive" <?php if ($forums->getFormField('status_inactive')) echo 'CHECKED'; ?> value="Inactive" tabindex="<?php echo $forums->getTabIndex(); ?>" />
					<label for="status_inactive"><?php echo $LANG['forumsearch_search_inactive']; ?></label>&nbsp;&nbsp;&nbsp;
				</td>
			</tr>
			<tr>
				<td class="<?php echo $forums->getCSSFormLabelCellClass('srch_date_added'); ?>"><label for="srch_date"><?php echo $LANG['forumsearch_search_date_created']; ?></label></td>
				<td class="<?php echo $forums->getCSSFormFieldCellClass('srch_date_added'); ?>"><?php echo $forums->getFormFieldErrorTip('srch_date_added'); ?>
					<select name="srch_date" id="srch_date" tabindex="<?php echo $forums->getTabIndex(); ?>">
						<option value=""><?php echo $LANG['forumsearch_search_date']; ?></option>
						<?php $forums->populateBWNumbers(1, 31, $forums->getFormField('srch_date')); ?>
					</select>
					<select name="srch_month" id="srch_month" tabindex="<?php echo $forums->getTabIndex(); ?>">
						<option value=""><?php echo $LANG['forumsearch_search_month']; ?></option>
						<?php $forums->populateMonthsList($forums->getFormField('srch_month')); ?>
					</select>
					<select name="srch_year" id="srch_year" tabindex="<?php echo $forums->getTabIndex(); ?>">
						<option value=""><?php echo $LANG['forumsearch_search_year']; ?></option>
						<?php $forums->populateBWNumbers(1920, date("Y"), $forums->getFormField('srch_year')); ?>
					</select>
				</td>
			</tr>
			<tr>
            <td>&nbsp;</td>
				<td class="<?php echo $forums->getCSSFormFieldCellClass('forumsearch_search'); ?>"><input type="submit" class="clsSubmitButton" value="<?php echo $LANG['forumsearch_search']; ?>" id="forumsearch_search" name="forumsearch_search" tabindex="<?php echo $forums->getTabIndex(); ?>"/></td>
			</tr>
		</table>
		<?php $forums->populateHiddenFormFields(array('orderby_field', 'orderby')); ?>
		</form>
	</div>
<?php
}
?>
<form name="selFormForums" id="selFormForums" method="post" action="<?php echo URL($_SERVER['PHP_SELF']); ?>">
<?php
if ($forums->isShowPageBlock('page_nav') && $CFG['admin']['navigation']['top'])
{
		$forums->populatePageLinksPOST($forums->getFormField('start'), 'selFormForums');
}
if ($forums->isShowPageBlock('form_show_forums'))
{
?>
	<div id="selShowForumTitles">
<?php
		if ($forums->isResultsFound())
		{
				$forums->showForumTitles();
		}
		else
		{
?>
			<div id="selMsgAlert">
				<p><?php echo $LANG['no_records_found']; ?></p>
			</div>
<?php
		}
?>
	</div>
<?php
}
if ($forums->isShowPageBlock('page_nav') && $CFG['admin']['navigation']['bottom'])
{
		$forums->populatePageLinksPOST($forums->getFormField('start'), 'selFormForums');
}
$forums->populateHidden(array('start', 'srch', 'srch_title', 'srch_topic', 'srch_topic_cnt', 'topic_condition', 'srch_response', 'srch_response_cnt', 'response_condition', 'srch_uname', 'status_active', 'status_inactive', 'srch_date', 'srch_month', 'srch_year', 'orderby_field', 'orderby'));
?>
		</form>
	</div>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>