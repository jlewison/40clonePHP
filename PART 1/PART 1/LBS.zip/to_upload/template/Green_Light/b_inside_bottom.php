			<?php if($adsensecode != '') { ?>		
<div class="box" style="margin-bottom:10px; margin-top:10px; clear:both; display:none">
	<div class="box-cap-left">
		<div class="box-cap-right">
			<div class="box-cap"></div>
		</div>
	</div>
	<div class="box3-left">
		<div class="box-right" style="text-align:center;"><div class="adsense"><?php echo("$adsensecode");?></div></div>
	</div>
	<div class="box-bottom-left">
		<div class="box-bottom-right">
		</div>
	</div>
</div>
			<?php } else {} ?>
		</div>
		</td>
	  </tr>
	</table>	
	</div>
	<div class="header">
		<div class="header-left">
			<div class="date"><?php echo (date("l, F d, Y"));?></div>
			<div class="logo"><a href="<?php echo("$path");?>" title="Welcome to <?php echo("$sitetitle");?>!"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/images/logo.gif" alt="Welcome to <?php echo("$sitetitle");?>!" /></a></div>
		</div>
		<div class="header-right">
			<div class="top-menu-right">
				<div class="top-menu-left">
					<div class="top-menu"><a href="<?php echo("$path");?>terms.php">Terms</a> | <a href="<?php echo("$path");?>about.php">About</a> | <a href="<?php echo("$path");?>contact.php">Contact Us</a></div></div></div><?php include('template/Green_Light/navigation.php'); ?>
			<?php /*?><div class="top-rated"><?php include('template/Green_Light/top_bidder.php'); ?></div><?php */?>
				<div class="main-menu">
					<ul>
						<li><a href="<?php echo("$path");?>">Home Page</a></li>
						<li><a href="<?php echo("$path");?>new-links.php">New Links</a></li>
						<li><a href="<?php echo("$path");?>links.php">Top Links</a></li>																
						<li class="next"><a href="<?php echo("$path");?>submit.php">Submit Link</a></li>
					</ul>	
				</div>
		</div>
	</div>
</div>
