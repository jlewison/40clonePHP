<?php
$lang['editprofilepersonal_activities']	= 'Activities';
$lang['editprofilepersonal_interests']	= 'Interests';
$lang['editprofilepersonal_favorite_music']	= 'Favorite Music';
$lang['editprofilepersonal_favorite_tvshows']	= 'Favorite TV Shows';
$lang['editprofilepersonal_favorite_movies']	= 'Favorite Movies';
$lang['editprofilepersonal_favorite_books']	= 'Favorite Books';
$lang['editprofilepersonal_favorite_quotes']	= 'Favorite Quotes';
$lang['editprofilepersonal_about_me']	= 'About Me';
$lang['editprofilepersonal_success_msg']	= 'Personal profile details updated successfully!';
?>