<?php
/**
 * Group sub category Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 02/01/2008
 */
class GroupSubCategory extends controller
{
		function GroupSubCategory()
		{
				parent::controller();
				//check login
				if ($this->session->userdata('admin_logged_in') != 1 && $this->session->userdata('admin_id') == '') redirect('admin/login');
				//Load the language file
				$this->lang->load('admin/groupCategory', $this->config->item('language_code'));
				$this->load->model('groupsmodel');
		}
		function index()
		{
				$this->load->library('validation');
				$this->_eventCategoryFrm();
				$outputData['addGroupCategory'] = true;
				$outputData['editGroupCategory'] = false;
				$outputData['group_category_id'] = $this->uri->segment(3);
				$outputData['groupsList'] = $this->groupsmodel->getGroupsMainSubCategory($outputData['group_category_id'], $status = '');
				$outputData['mainGroupCategoryName'] = $this->groupsmodel->getGroupCategoryName($outputData['group_category_id']);
				if (!empty($outputData['groupsList'])) $outputData['groupsListArr'] = $outputData['groupsList'];
				else  $outputData['groupsListArr'] = false;
				if ($this->validation->run() == false) $outputData['validationError'] = $this->validation->error_string;
				else
				{
						if (isset($_POST['add_group_sub_category']))
						{
								$this->groupsmodel->insertGroupSubCategory($_POST, $outputData['group_category_id']);
								//Set the flash data
								$this->session->set_flashdata('successMsg', $this->lang->line('groupcategory_sub_add_success_msg'));
								redirect('admin/groupSubCategory/' . $outputData['group_category_id']);
						}
				}
				$this->smartyextended->view('../admin/groupSubCategory', $outputData);
		}
		function _eventCategoryFrm()
		{
				$rules['group_sub_category_name'] = 'trim|required|alphanumeric';
				$rules['group_sub_category_description'] = 'trim|required|alphanumeric';
				$fields['group_sub_category_name'] = $this->lang->line('eventcategory_sub_category_name');
				$fields['group_sub_category_description'] = $this->lang->line('eventcategory_sub_description');
				$this->validation->set_rules($rules);
				$this->validation->set_fields($fields);
		}
		#***************************************************************************
		#Method			: editEventCategory
		#Description	: updates Event Category
		#Author			
		#***************************************************************************
		function editGroupSubCategory()
		{
				$this->load->library('validation');
				$outputData['group_sub_category_id'] = $this->uri->segment(5);
				$outputData['group_category_id'] = $this->uri->segment(4);
				$outputData['addGroupCategory'] = false;
				$outputData['editGroupCategory'] = true;
				$outputData['groupsList'] = $this->groupsmodel->getGroupsMainSubCategory($outputData['group_category_id'], $status = '');
				if (!empty($outputData['groupsList'])) $outputData['groupsListArr'] = $outputData['groupsList'];
				else  $outputData['groupsListArr'] = false;
				$this->_eventCategoryFrm();
				if ($this->validation->run() == false) $outputData['validationError'] = $this->validation->error_string;
				else
				{
						if (isset($_POST['update_group_sub_category']))
						{
								$this->groupsmodel->updateGroupSubCategory($_POST);
								//Set the flash data
								$this->session->set_flashdata('successMsg', $this->lang->line('groupcategory_sub_update_success_msg'));
								redirect('admin/groupSubCategory/' . $_POST['group_category_id'] . '');
						}
				}
				$this->smartyextended->view('../admin/groupSubCategory', $outputData);
		}
}
?>