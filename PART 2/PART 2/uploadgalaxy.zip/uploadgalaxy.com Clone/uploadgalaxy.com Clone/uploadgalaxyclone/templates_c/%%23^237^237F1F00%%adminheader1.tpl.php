<?php /* Smarty version 2.6.6, created on 2006-02-01 09:56:17
         compiled from admin/adminheader1.tpl */ ?>
<table border="0" cellpadding="0" cellspacing="0" bordercolor="#111111" width="100">
          <tr>
            <td width="100" height="1" bgcolor="#003366">
            <img border="0" src="<?php echo $this->_tpl_vars['imgurl']; ?>
/line.JPG" width="100" height="1"></td>
          </tr>
          <tr>
            <td width="100" height="14" bgcolor="<?php if ($_REQUEST['change'] == 'Personal'): ?>#0077BB<?php else: ?>#003366<?php endif; ?>">
            <font size="1" face="Verdana">
            <a style="text-decoration: none" class="link" href="admin_index.php?change=Personal">
            <font color="<?php if ($_REQUEST['change'] == 'Personal'): ?>#ffffff<?php else: ?>#FFFFF<?php endif; ?>">&nbsp;&nbsp;Personal</font></a></font></td>
          </tr>
          <tr>
            <td width="100" height="14" bgcolor="<?php if ($_REQUEST['change'] == 'Config'): ?>#0077BB<?php else: ?>#003366<?php endif; ?>">
                       <font face="Verdana" size="1">
            <a style="text-decoration: none; hover:#00FF00" class="link" href="admin_index.php?change=Config">
            <font color="<?php if ($_REQUEST['change'] == 'Config'): ?>#ffffff<?php else: ?>#FFFFF<?php endif; ?>">&nbsp;&nbsp;Configuration</font></a></font>
           </td>
         </tr>
          <tr>
            <td width="100" height="14" bgcolor="<?php if ($_REQUEST['change'] == 'Packages'): ?>#0077BB<?php else: ?>#003366<?php endif; ?>">
            <font size="1" face="Verdana">
            <a style="text-decoration: none" class="link" href="admin_index.php?change=Packages">
            <font color="<?php if ($_REQUEST['change'] == 'Packages'): ?>#ffffff<?php else: ?>#FFFFF<?php endif; ?>">&nbsp;&nbsp;Packages</font></a></font></td>
          </tr>
          <tr>
            <td width="100" height="14" bgcolor="<?php if ($_REQUEST['change'] == 'Abuse'): ?>#0077BB<?php else: ?>#003366<?php endif; ?>">
            <a href="admin_index.php?change=Abuse" style="font-family: Verdana; font-size: 8pt;text-decoration: none">
            <font color="<?php if ($_REQUEST['change'] == 'Abuse'): ?>#ffffff<?php else: ?>#FFFFF<?php endif; ?>">&nbsp;&nbsp;Manage Abuse</font></a></td>
           </tr>
          <tr>
            <td width="100" height="14" bgcolor="<?php if ($_REQUEST['change'] == 'FInfo'): ?>#0077BB<?php else: ?>#003366<?php endif; ?>">
            <a href="admin_index.php?change=FInfo" style="font-family: Verdana; font-size: 8pt;text-decoration: none">
            <font color="<?php if ($_REQUEST['change'] == 'FInfo'): ?>#ffffff<?php else: ?>#FFFFFF<?php endif; ?>">&nbsp;&nbsp;File Info</font></a></td>
           </tr>
          <tr>
            <td width="100" height="14" bgcolor="#003366" style="color: #000000" bordercolor="#003366">
            <font face="Verdana" size="1" color="#FFFFFF">
            <a style="text-decoration: none" href="admin_logout.php">
            <font color="#ffffff">&nbsp;&nbsp;Log<?php if ($_COOKIE['admin_uid']): ?>out<?php else: ?>in<?php endif; ?></font></a></font></td>
          </tr>
        </table>