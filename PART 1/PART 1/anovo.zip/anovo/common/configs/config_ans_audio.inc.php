<?php
$CFG['admin']['ans_audios']['audio_folder'] = 'files/ans_audios/';
$CFG['admin']['ans_audios']['temp_folder'] = 'files/temp_files/ans_temp_audios/';
$CFG['admin']['ans_audios']['audio_auto_encode'] = true;
$CFG['admin']['ans_audios']['AutoPlay'] = true;
$CFG['admin']['ans_audios']['ToolTip'] = true;
$CFG['admin']['ans_audios']['SelectedSkin'] = 'liteBlue';

?>