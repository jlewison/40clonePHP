<?php

/**
 * Report Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 1/24/2008
 */
class report extends Controller
{
		//Constructor
		function report()
		{
				parent::Controller();
				//Load the language file
				$this->lang->load('report', $this->config->item('language_code'));
				//Load the report model
				$this->load->model('reportmodel');
		}
		//Default function
		function index()
		{
				redirect('home');
		}
		function submit()
		{
				$newReport['report_type_id'] = $this->input->post('report_type_id');
				$newReport['report_comment'] = $this->input->post('report_comment');
				$newReport['report_for'] = $this->input->post('report_for');
				$newReport['report_for_id'] = $this->input->post('report_for_id');
				$this->reportmodel->createReport($newReport);
				redirect($this->input->post('backToPage'));
		}
}

?>