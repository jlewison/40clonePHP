<?php //00461
// Copyright Notice
// Web Site URL:  http://www.zeeways.com
// Script Owner eMail: mail@zeeways.com
// Date: April, 2007
// Script Name: Zeeways Auction Website PHP Script
// Copyright Details: This script is not free.  Do not Remove this Copy Right notice.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the site administrator.');exit(199);
?>
4+oV55MUkfoaVX/JfIGllwXUWLh531fr28X5I8AiU3RvLtP6I9IyHYm6YXCjJtbFrs44S5TugXiY
Qd8YyPEv9w4HeNpZKQaUfGdvs3K1426CPv/OBO/dt240sRPRJPQtI9RaIplHY9VsmZe/MFeWact+
B+mkQyD6llZQ0qvrEuAGdyoG2lVAHuUTcwdBji7c4nDvOh796a3L0XMada57nE1+uIeYPO5vUcC0
6IP1OCtvX37hTLCEZcA2bgOq34npzoskINwscd0HW/zNMpf4/ANNQCsJQ9p9bGDOntt2LswV2I8Q
CmnKmlouy3EcCXA89BYpEwFSnNugAJilZ0SIyZkKxrd+gw7/1mwzphAXyk1lsf8pmf+mXYaEEV5P
RBHxOEMqCKXnXMqlkeqzoB1onPM6OKYQqkgzaDA3LWB1rkeUdna5wqrK5i4gYgcINJAeKUGb298D
YGq3f7qFuot06AkrgMVEOlIDHYFOJnBy82C4eok0yUIkFySAwrWoKZ4Xes8D9Xa003JmzW1zSfv3
So2lQ90lhiuz186FiGtCERukZqIYULrLEm==