<? include ("header1.php"); ?>








<table cellpadding="0" cellspacing="0" border="0" width="100%">
	<tr class="top4">
		<td>&nbsp;</td>
		<td width="778" valign="top">






    <FORM name=form action=reg.php method=post>









<table cellpadding="0" cellspacing="0" border="0" width="778" class="create_tbl">
	<tr>
		<td valign="top" colspan="5"><img src="fgi/b.gif" height="15"></td>
	</tr>
	<tr>
		<td width="25" rowspan="3"><img src="fgi/b.gif" width="25"></td>
		<td colspan="3"><img src="fgi/create_ttl.jpg"><br>If you do not have a Flash casino account, please create one below (All fields are required):</td>
		<td width="25" rowspan="3"><img src="fgi/b.gif" width="25"></td>
	</tr>
	<tr>
		<td colspan="3" class="fl_msg">&nbsp;</td>
	</tr>
	<tr>
		<td valign="top" width="341">
			<table cellpadding="0" cellspacing="0" border="0" width="100%">
				<tr>
					<td width="4"><img src="fgi/fl_tl.jpg"></td>
					<td class="flt"><img src="fgi/fl_t.jpg"></td>
					<td width="4"><img src="fgi/fl_tr.jpg"></td>
				</tr>
				<tr>
					<td class="fll"><img src="fgi/fl_l.jpg"></td>
					<td class="flc" height="240" valign="top">
<table cellpadding="0" cellspacing="3" border="0" width="100%" class="cr_form">
	<tr>
		<td>E-MAIL ADDRESS:</td>
		<td><input type="text" name="r_email" value="" maxlength="128" ID="Text3"></td>
	</tr>
	<tr>
		<td>ACCOUNT NAME:</td>
		<td><input type="text" name="r_login" value="" maxlength="128" ID="Text7"></td>
	</tr>
	<tr>
		<td>PASSWORD:</td>
		<td><input type="password" name="r_pass" value="" maxlength="128" ID="Text2"></td>
	</tr>
	<tr>
		<td>CONFIRM PASSWORD:</td>
		<td><input type="password" name="r_pass1" value="" maxlength="128" ID="Text1"></td>
	</tr>
	<tr>
		<td>FIRST NAME:</td>
		<td><input type="text" name="fname" value="" maxlength="128" ID="Text6"></td>
	</tr>
	<tr>
		<td>LAST NAME:</td>
		<td><input type="text" name="lname" value="" maxlength="128" ID="Text8"></td>
	</tr>
	<tr>
		<td>BIRTHDATE (mm/dd/yyyy):</td>
		<td><input type="text" name="ba" value="" maxlength="10" ID="Text5"></td>
	</tr>
	<tr>
		<td>&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
</table>
					</td>
					<td class="flr"><img src="fgi/fl_r.jpg"></td>
				</tr>
				<tr>
					<td><img src="fgi/fl_bl.jpg"></td>
					<td class="flb"><img src="fgi/fl_b.jpg"></td>
					<td><img src="fgi/fl_br.jpg"></td>
				</tr>
			</table>
		</td>
		<td width="15"><img src="fgi/b.gif" width="25"></td>
		<td valign="top" width="341">
			<table cellpadding="0" cellspacing="0" border="0" width="100%">
				<tr>
					<td width="4"><img src="fgi/fl_tl.jpg"></td>
					<td class="flt"><img src="fgi/fl_t.jpg"></td>
					<td width="4"><img src="fgi/fl_tr.jpg"></td>
				</tr>
				<tr>
					<td class="fll"><img src="fgi/fl_l.jpg"></td>
					<td class="flc" height="240" valign="top">
<table cellpadding="0" cellspacing="3" border="0" width="100%" class="cr_form">

	<tr>
		<td>ADDRESS :</td>
		<td><input type="text" name="addr1" value="" maxlength="128" ID="Text9"></td>
	</tr>

	<tr>
		<td>CITY:</td>
		<td><input type="text" name="city" value="" maxlength="128" ID="Text11"></td>
	</tr>
	<tr>
		<td>STATE/PROVINCE:</td>
		<td><input type="text" name="state" value="" maxlength="128" ID="Text12"></td>
	</tr>
	<tr>
		<td>ZIP/POSTAL CODE:</td>
		<td><input type="text" name="zip" value="" maxlength="128" ID="Text13"></td>
	</tr>
	<tr>
		<td>COUNTRY:</td>
		<td><select name="country" ID="Select1"><option value='AF'>Afghanistan</option><option value='AL'>Albania</option><option value='DZ'>Algeria</option><option value='AS'>American Samoa</option><option value='AD'>Andorra</option><option value='AO'>Angola</option><option value='AI'>Anguilla</option><option value='AQ'>Antarctica</option><option value='AG'>Antigua and Barbuda</option><option value='AR'>Argentina</option><option value='AM'>Armenia</option><option value='AW'>Aruba</option><option value='AU'>Australia</option><option value='AT'>Austria</option><option value='AZ'>Azerbaijan</option><option value='BS'>Bahamas</option><option value='BH'>Bahrain</option><option value='BD'>Bangladesh</option><option value='BB'>Barbados</option><option value='BY'>Belarus</option><option value='BE'>Belgium</option><option value='BZ'>Belize</option><option value='BJ'>Benin</option><option value='BM'>Bermuda</option><option value='BT'>Bhutan</option><option value='BO'>Bolivia</option><option value='BA'>Bosnia and Herzegovina</option><option value='BW'>Botswana</option><option value='BV'>Bouvet Island</option><option value='BR'>Brazil</option><option value='IO'>British Indian Ocean Territory</option><option value='VG'>British Virgin Islands</option><option value='BN'>Brunei Darissalem</option><option value='BG'>Bulgaria</option><option value='BF'>Burkina Faso</option><option value='BI'>Burundi</option><option value='KH'>Cambodia</option><option value='CM'>Cameroon</option><option value='CA'>Canada</option><option value='CV'>Cape Verde</option><option value='KY'>Cayman Islands</option><option value='CF'>Central African Republic</option><option value='TD'>Chad</option><option value='CL'>Chile</option><option value='CN'>China</option><option value='CX'>Christmas Island</option><option value='CC'>Cocos (Keeling) Island</option><option value='CO'>Colombia</option><option value='KM'>Comoros</option><option value='CG'>Congo</option><option value='CD'>Congo Democratic Republic</option><option value='CK'>Cook Islands</option><option value='CR'>Costa Rica</option><option value='CI'>Cote d�Ivoire</option><option value='HR'>Croatia</option><option value='CU'>Cuba</option><option value='CY'>Cyprus</option><option value='CT'>Cyprus, Northern</option><option value='CZ'>Czech Republic</option><option value='DK'>Denmark</option><option value='DJ'>Djibouti</option><option value='DM'>Dominica</option><option value='DO'>Dominican Republic</option><option value='TP'>East Timor</option><option value='EC'>Ecuador</option><option value='EG'>Egypt</option><option value='SV'>El Salvador</option><option value='GQ'>Equatorial Guinea</option><option value='ER'>Eritrea</option><option value='EE'>Estonia</option><option value='ET'>Ethiopia</option><option value='FK'>Falkland Islands (Malvinas)</option><option value='FO'>Faroe Islands</option><option value='FJ'>Fiji</option><option value='FI'>Finland</option><option value='FR'>France</option><option value='FX'>France, metropolitan</option><option value='GF'>French Guiana</option><option value='PF'>French Polynesia</option><option value='TF'>French Southern Territories</option><option value='GA'>Gabon</option><option value='GM'>Gambia</option><option value='GZ'>Gaza strip</option><option value='GE'>Georgia</option><option value='DE'>Germany</option><option value='GH'>Ghana</option><option value='GI'>Gibraltar</option><option value='GR'>Greece</option><option value='GL'>Greenland</option><option value='GD'>Grenada</option><option value='GP'>Guadeloupe</option><option value='GU'>Guam</option><option value='GT'>Guatemala</option><option value='GN'>Guinea</option><option value='GW'>Guinea Bissau</option><option value='GY'>Guyana</option><option value='HT'>Haiti</option><option value='HM'>Heard and McDonald Islands</option><option value='HN'>Honduras</option><option value='HK'>Hong Kong</option><option value='HU'>Hungary</option><option value='IS'>Iceland</option><option value='IN'>India</option><option value='ID'>Indonesia</option><option value='IR'>Iran</option><option value='IQ'>Iraq</option><option value='IE'>Ireland</option><option value='IM'>Isle of Man</option><option value='IL'>Israel</option><option value='IT'>Italy</option><option value='JM'>Jamaica</option><option value='JP'>Japan</option><option value='JO'>Jordan</option><option value='KZ'>Kazakhstan</option><option value='KE'>Kenya</option><option value='KI'>Kiribati</option><option value='KW'>Kuwait</option><option value='KG'>Kyrgyzstan</option><option value='LA'>Laos</option><option value='LV'>Latvia</option><option value='LB'>Lebanon</option><option value='LS'>Lesotho</option><option value='LR'>Liberia</option><option value='LY'>Libya</option><option value='LI'>Liechtenstein</option><option value='LT'>Lithuania</option><option value='LU'>Luxembourg</option><option value='MO'>Macau</option><option value='MK'>Macedonia</option><option value='MG'>Madagascar</option><option value='MW'>Malawi</option><option value='MY'>Malaysia</option><option value='MV'>Maldives</option><option value='ML'>Mali</option><option value='MT'>Malta</option><option value='MH'>Marshall Islands</option><option value='MQ'>Martinique</option><option value='MR'>Mauritania</option><option value='MU'>Mauritius</option><option value='YT'>Mayotte</option><option value='MX'>Mexico</option><option value='FM'>Micronesia</option><option value='MD'>Moldova</option><option value='MC'>Monaco</option><option value='MN'>Mongolia</option><option value='ME'>Montenegro</option><option value='MS'>Montserrat</option><option value='MA'>Morocco</option><option value='MZ'>Mozambique</option><option value='MM'>Myanmar (Burma)</option><option value='NA'>Namibia</option><option value='NR'>Nauru</option><option value='NP'>Nepal</option><option value='NL'>Netherlands</option><option value='AN'>Netherlands Antilles</option><option value='NC'>New Caledonia</option><option value='NZ'>New Zealand</option><option value='NI'>Nicaragua</option><option value='NE'>Niger</option><option value='NG'>Nigeria</option><option value='NU'>Niue</option><option value='NF'>Norfolk Island</option><option value='KP'>North Korea</option><option value='MP'>Northern Mariana Islands</option><option value='NO'>Norway</option><option value='OM'>Oman</option><option value='PK'>Pakistan</option><option value='PW'>Palau</option><option value='PA'>Panama</option><option value='PG'>Papua New Guinea</option><option value='PY'>Paraguay</option><option value='PE'>Peru</option><option value='PH'>Philippines</option><option value='PN'>Pitcairn Islands</option><option value='PL'>Poland</option><option value='PT'>Portugal</option><option value='PR'>Puerto Rico</option><option value='QA'>Qatar</option><option value='RE'>Reunion</option><option value='RO'>Romania</option><option value='RU'>Russian Federation</option><option value='RW'>Rwanda</option><option value='SH'>Saint Helena</option><option value='PM'>Saint Pierre and Miquelon</option><option value='SM'>San Marino</option><option value='ST'>Sao Tome and Principe</option><option value='SA'>Saudi Arabia</option><option value='SN'>Senegal</option><option value='RS'>Serbia</option><option value='SX'>Serbia and Montenegro</option><option value='SC'>Seychelles</option><option value='SL'>Sierra Leone</option><option value='SG'>Singapore</option><option value='SK'>Slovakia</option><option value='SI'>Slovenia</option><option value='SB'>Solomon Islands</option><option value='SO'>Somalia</option><option value='ZA'>South Africa</option><option value='GS'>South Georgia/South Sandwich</option><option value='KR'>South Korea</option><option value='ES'>Spain</option><option value='LK'>Sri Lanka</option><option value='KN'>St Kitts and Nevis</option><option value='LC'>St Lucia</option><option value='VC'>St Vincent and the Grenadines</option><option value='SD'>Sudan</option><option value='SR'>Suriname</option><option value='SJ'>Svalbard and Jan Mayen Islands</option><option value='SZ'>Swaziland</option><option value='SE'>Sweden</option><option value='CH'>Switzerland</option><option value='SY'>Syria</option><option value='TW'>Taiwan</option><option value='TJ'>Tajikistan</option><option value='TZ'>Tanzania</option><option value='TH'>Thailand</option><option value='TG'>Togo</option><option value='TK'>Tokelau</option><option value='TO'>Tonga</option><option value='TT'>Trinidad and Tobago</option><option value='TN'>Tunisia</option><option value='TR'>Turkey</option><option value='TM'>Turkmenistan</option><option value='TC'>Turks and Caicos Islands</option><option value='TV'>Tuvalu</option><option value='UG'>Uganda</option><option value='UA'>Ukraine</option><option value='AE'>United Arab Emirates</option><option value='GB'>United Kingdom</option><option value='US' SELECTED>United States</option><option value='UM'>United States Outlying Islands</option><option value='UY'>Uruguay</option><option value='VI'>US Virgin Islands</option><option value='UZ'>Uzbekistan</option><option value='VU'>Vanuatu</option><option value='VA'>Vatican (Holy See)</option><option value='VE'>Venezuela</option><option value='VN'>Vietnam</option><option value='WF'>Wallis and Futuna</option><option value='WB'>West Bank</option><option value='EH'>Western Sahara</option><option value='WS'>Western Samoa</option><option value='YE'>Yemen</option><option value='YU'>Yugoslavia</option><option value='ZR'>Zaire</option><option value='ZM'>Zambia</option><option value='ZW'>Zimbabwe</option></select></td>
	</tr>

	<tr>
		<td><b>I certify that major
</b></td> 
                                    
                                        <td><input name="ans" type="checkbox" id="anst" value="oui" ></td></tr>
                                   

<tr>
		<td><b>I accept Terms and Conditions 

</b></td>  
                                   
                                        <td><input name="reglement" type="checkbox" id="reglement" value="oui"  ></td></tr>
                                   




</table>
					</td>




                                    
<INPUT type=hidden value=<? echo $pus; ?> name=pus>




<INPUT type=hidden value=1 name=send>













					<td class="flr"><img src="fgi/fl_r.jpg"></td>
				</tr>
				<tr>
					<td><img src="fgi/fl_bl.jpg"></td>
					<td class="flb"><img src="fgi/fl_b.jpg"></td>
					<td><img src="fgi/fl_br.jpg"></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td colspan="5" align="center"><br><input type="image" src="fgi/openaccount.jpg" border="0"><br><br></td>
	</tr>
</table>
</form>

		</td>
		<td>&nbsp;</td>
	</tr>


<?


if($send=="1")






{

if ($r_login=="")
{
echo "<script> alert('Login !'); document.location.href='reg.php'; </script>";
exit;
}
if ($r_pass=="")
{
echo "<script> alert('Password !'); document.location.href='reg.php'; </script>";
exit;
}

if ($r_pass1 != $r_pass)
{
echo "<script> alert('Password 1!'); document.location.href='reg.php'; </script>";
exit;
}

if ($reglement != "oui")
{
echo "<script> alert('You must accept  Terms and Conditions!'); document.location.href='reg.php'; </script>";
exit;
}
if ($ans != "oui")
{
echo "<script> alert('You must be major!'); document.location.href='reg.php'; </script>";
exit;
}

if ($r_email=="")
{
echo "<script> alert(' E-mail!'); document.location.href='reg.php'; </script>";
exit;
}
if(!preg_match("/^([a-z,0-9])+\@([a-z,0-9])+(\.([a-z,0-9])+)+$/", $r_email))
{
echo "<script> alert('E-mail!'); document.location.href='reg.php'; </script>";
exit;
}
include ("setup.php");
$date=date("d.m.y");

$sqlr="select * from users where login='$r_login'";
$resultr=mysql_query($sqlr);
$rowr=mysql_fetch_array($resultr);

if ($r_login==$rowr[1])
{
echo "<script> alert('Login ever used!'); document.location.href='reg.php'; </script>";
exit;
}
$pus=$HTTP_COOKIE_VARS["par"];
$sqlru="select * from users where login='$pus'";
$resultru=mysql_query($sqlru);
$rowru=mysql_fetch_array($resultru);
if ($pus==$rowru[1] && $pus<>"")
{
$sqlp="INSERT INTO partner VALUES('$pus','$r_login','$date','0.00')";
mysql_query($sqlp);
}


$sqlr="INSERT INTO users VALUES(NULL,'$r_login','$r_pass','0.00','0.00','0.00','$r_email','$r_name','$r_fam','$date','0.00','$fname ','$lname ','$addr1 ','$zip ','$city ','$country ')";
mysql_query($sqlr);


include("mail/reg.php");
$to =$r_email;
$subject = $reg_reg_mail_subject;
$msg =$reg_reg_mail;
$mailheaders = "Content-Type: text/plain; charset=iso-8859-1\n";
$mailheaders .= "From: $con[2]\n";
mail($to, $subject, $msg, $mailheaders);

$con=mysql_fetch_array(mysql_query("select * from seting"));
if ($con[regmail]=="yes"){
include("mail/newreg.php");
$to =$con['adm_email'];
$subject = $reg_reg_mail_subject;
$msg =$reg_reg_mail;
$mailheaders = "Content-Type: text/plain; charset=iso-8859-1\n";
$mailheaders .= "From: $con[adm_email]\n";
mail($to, $subject, $msg, $mailheaders);
}

unset($pus);
session_destroy();
?>


<script> alert('Thank you for your account is open. Play and Win!'); document.location.href='system/login.php'; </script>




<?
}
?>






























	<?		include ("footer.php") ?>