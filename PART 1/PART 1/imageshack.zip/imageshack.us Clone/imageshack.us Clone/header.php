<a href="<? echo $domain; ?>"><img alt="ImageShack� Logo" src="ULOADED_elemei/imageshack.png" title=""></a></td><td align="left" valign="bottom">
<b><a href="<? echo $domain; ?>">ImageShack Clone &reg;</a>
 | <a href="content.php">Link-To-Us</a> | <a href="#">Link</a>
 | <a href="#">Link</a>
 | <a href="#">Link</a>
 | <a href="#">LINK</a> | <a href="#">Link</a> </b>