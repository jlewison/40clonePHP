<?php
class FtpHandler
{
		public $CONN_ID;
		public function FtpHandler($ftp_server, $user_name, $password)
		{
				$this->CONN_ID = @ftp_connect($ftp_server);
				$login_result = @ftp_login($this->CONN_ID, $user_name, $password);
				if ($this->CONN_ID and $login_result) return true;
				else  return false;
		}
		public function changeDirectory($dir)
		{
				if (@ftp_chdir($this->CONN_ID, $dir))
				{
						return true;
				}
				return false;
		}
		public function makeDirectory($dir, $mode = 0777)
		{
				$folder_arr = explode('/', $dir);
				$folderName = '';
				foreach ($folder_arr as $key => $value)
				{
						$folderName .= $value . '/';
						if ($value == '..' or $value == '.') continue;
						if (@ftp_mkdir($this->CONN_ID, $folderName))
						{
								@ftp_chmod($this->CONN_ID, $mode, $folderName);
						}
				}
		}
		public function moveTo($source_file, $destination_file, $mode = 0777)
		{
				if (@ftp_put($this->CONN_ID, $destination_file, $source_file, FTP_BINARY))
				{
						@ftp_chmod($this->CONN_ID, $mode, $destination_file);
						return true;
				}
				return false;
		}
		public function deleteFile($file)
		{
				if (@ftp_delete($this->CONN_ID, $file)) return true;
				else  return false;
		}
		public function ftpClose()
		{
				if (@ftp_close($this->CONN_ID)) return true;
				return false;
		}
		public function ftpGet($ftpfile, $downloadfile)
		{
				if (ftp_get($this->CONN_ID, $downloadfile, $ftpfile, FTP_BINARY)) return true;
				return false;
		}
}
?>