<?php
require_once ('../common/config.inc.php');
$CFG['lang']['include_files'][] = 'admin/includes/languages/%s/forumsResponseSearch.php';
$CFG['html']['header'] = 'admin/includes/languages/%s/html_header.php';
$CFG['html']['footer'] = 'admin/includes/languages/%s/html_footer.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['lang']['include_files'][] = 'common/configs/config_forums.inc.php';
$CFG['lang']['include_files'][] = 'common/languages/%s/lists_array/months_list_array.inc.php';
$CFG['db']['is_use_db'] = true;
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class ForumSearchFormHandler extends FormHandler
{
		public function isValidForumId($forum_id, $err_tip = '')
		{
				$sql = 'SELECT forum_id, forum_title, forum_description, forum_status ' . 'FROM ' . $this->CFG['db']['tbl']['forums'] . ' ' . 'WHERE forum_id = ' . $this->dbObj->Param($forum_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($forum_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($this->forum_details_arr = $rs->FetchRow())
				{
						return true;
				}
				$this->setCommonErrorMsg($err_tip);
				return false;
		}
		public function isValidForumTopicId($forum_id, $topic_id, $err_tip = '')
		{
				$sql = 'SELECT g.topic_id, g.forum_id, g.forum_topic, g.user_id, ' . 'DATE_FORMAT(g.date_added, \'' . $this->CFG['format']['date'] . '\') as date_added, u.user_name, u.last_name, u.first_name ' . 'FROM ' . $this->CFG['db']['tbl']['forum_topics'] . ' AS g, ' . $this->CFG['db']['tbl']['users'] . ' AS u ' . 'WHERE g.user_id = u.user_id ' . 'AND topic_id = ' . $this->dbObj->Param($topic_id) . ' ' . 'AND forum_id = ' . $this->dbObj->Param($forum_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($topic_id, $forum_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($this->forum_topic_details_arr = $rs->FetchRow())
				{
						return true;
				}
				$this->setCommonErrorMsg($err_tip);
				return false;
		}
		public function generateQueryString($search_fields_arr)
		{
				$this->queryStr = '';
				foreach ($search_fields_arr as $search_field)
				{
						if ($this->fields_arr[$search_field])
						{
								$this->queryStr .= '&' . $search_field . '=' . $this->fields_arr[$search_field];
								if ($search_field == 'srch_response_cnt')
								{
										$this->queryStr .= '&response_condition=' . $this->fields_arr['response_condition'];
								} elseif ($search_field == 'srch_views')
								{
										$this->queryStr .= '&views_condition=' . $this->fields_arr['views_condition'];
								}
						}
				}
		}
		public function populateConditionOperators($highlight_operator)
		{
?>
				<option value="equalto" <?php if ($highlight_operator == 'equalto') echo 'SELECTED'; ?>><?php echo $this->LANG['responsesearch_equal_to'] ?></option>
				<option value="greaterthan" <?php if ($highlight_operator == 'greaterthan') echo 'SELECTED'; ?>><?php echo $this->LANG['responsesearch_greater_than'] ?></option>
				<option value="greaterthanequal" <?php if ($highlight_operator == 'greaterthanequal') echo 'SELECTED'; ?>><?php echo $this->LANG['responsesearch_greater_than_equal'] ?></option>
				<option value="lessthan" <?php if ($highlight_operator == 'lessthan') echo 'SELECTED'; ?>><?php echo $this->LANG['responsesearch_less_than'] ?></option>
				<option value="lessthanequal" <?php if ($highlight_operator == 'lessthanequal') echo 'SELECTED'; ?>><?php echo $this->LANG['responsesearch_less_than_equal'] ?></option>
				<option value="notequal" <?php if ($highlight_operator == 'notequal') echo 'SELECTED'; ?>><?php echo $this->LANG['responsesearch_not_equal'] ?></option>
			<?php
		}
}
$forums = new ForumSearchFormHandler();
$forums->setPageBlockNames(array('msg_form_error', 'msg_form_success', 'form_search'));
$forums->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$forums->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$forums->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$forums->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$forums->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$forums->setDBObject($db);
$forums->setCfgLangGlobal($CFG, $LANG);
$forums->setAllPageBlocksHide();
$forums->setFormField('srch', '');
$forums->setFormField('numpg', 0);
$forums->setFormField('start', 0);
$forums->setFormField('forum_id', '');
$forums->setFormField('topic_id', '');
$forums->setFormField('srch_response', '');
$forums->setFormField('srch_uname', '');
$forums->setFormField('srch_date_from', '');
$from_date = getdate(mktime(0, 0, 0, date("m"), date("d") - $CFG['admin']['forums']['search_date_limit'], date("Y")));
$forums->setFormField('srch_date', $from_date['mday']);
$forums->setFormField('srch_month', $from_date['mon']);
$forums->setFormField('srch_year', $from_date['year']);
$forums->setFormField('srch_date_to', '');
$forums->setFormField('srch_todate', date('d'));
$forums->setFormField('srch_tomonth', date('m'));
$forums->setFormField('srch_toyear', date('Y'));
$forums->setMonthsListArr($LANG_LIST_ARR['months']);
$forums->sanitizeFormInputs($_REQUEST);
if ($forums->isFormGETed($_REQUEST, 'forum_id') && $forums->isFormGETed($_REQUEST, 'topic_id'))
{
		$forums->chkIsNotEmpty('forum_id', $LANG['responsesearch_err_tip_compulsory']) and $forums->chkIsNumeric('forum_id', $LANG['responsesearch_err_tip_compulsory']) and $forums->isValidForumId($forums->getFormField('forum_id'), $LANG['responsesearch_err_tip_invalid_forum_id']) and $forums->chkIsNotEmpty('topic_id', $LANG['responsesearch_err_tip_compulsory']) and $forums->chkIsNumeric('topic_id', $LANG['responsesearch_err_tip_compulsory']) and $forums->isValidForumTopicId($forums->getFormField('forum_id'), $forums->getFormField('topic_id'), $LANG['responsesearch_err_tip_invalid_forum_topic_id']);
}
else
{
		Redirect2URL('forums.php');
}
if ($forums->isValidFormInputs())
{
		if ($forums->isFormPOSTed($_POST, 'responsesearch_search'))
		{
				if ($forums->getFormField('srch_date') || $forums->getFormField('srch_month') || $forums->getFormField('srch_year'))
				{
						$forums->chkIsCorrectDate($forums->getFormField('srch_date'), $forums->getFormField('srch_month'), $forums->getFormField('srch_year'), 'srch_date_from', $LANG['responsesearch_err_tip_date_empty'], $LANG['responsesearch_err_tip_date_invalid']);
				}
				if ($forums->getFormField('srch_todate') || $forums->getFormField('srch_tomonth') || $forums->getFormField('srch_toyear'))
				{
						$forums->chkIsCorrectDate($forums->getFormField('srch_todate'), $forums->getFormField('srch_tomonth'), $forums->getFormField('srch_toyear'), 'srch_date_to', $LANG['responsesearch_err_tip_date_empty'], $LANG['responsesearch_err_tip_date_invalid']);
				}
				if (!$forums->getFormField('srch_date_from') || !$forums->getFormField('srch_date_to'))
				{
						$forums->setCommonErrorMsg($LANG['responsesearch_err_tip_specify_dates']);
						$forums->setPageBlockShow('msg_form_error');
				}
				if ($forums->getFormField('srch_date_from') && $forums->getFormField('srch_date_to'))
				{
						$from_date = explode('-', $forums->getFormField('srch_date_from'));
						$from_date = mktime(0, 0, 0, $from_date[1], $from_date[2], $from_date[0]);
						$to_date = explode('-', $forums->getFormField('srch_date_to'));
						$to_date = mktime(0, 0, 0, $to_date[1], $to_date[2], $to_date[0]);
						if ($to_date < $from_date)
						{
								$forums->setCommonErrorMsg($LANG['responsesearch_err_tip_enter_correct_dates']);
								$forums->setPageBlockShow('msg_form_error');
						}
				}
				$forums->setAllPageBlocksHide();
				if ($forums->isValidFormInputs())
				{
						$forums->generateQueryString(array('srch_topic', 'srch_response', 'srch_response_cnt', 'srch_views', 'srch_uname', 'srch_date', 'srch_month', 'srch_year', 'srch_todate', 'srch_tomonth', 'srch_toyear'));
						Redirect2URL('forumsResponses.php?forum_id=' . $forums->getFormField('forum_id') . '&topic_id=' . $forums->getFormField('topic_id') . $forums->queryStr);
				}
				else
				{
						$forums->setPageBlockShow('msg_form_error');
				}
		}
		if ($forums->isFormGETed($_GET))
		{
				$forums->setAllPageBlocksHide();
				if ($forums->getFormField('srch_date') || $forums->getFormField('srch_month') || $forums->getFormField('srch_year'))
				{
						$forums->chkIsCorrectDate($forums->getFormField('srch_date'), $forums->getFormField('srch_month'), $forums->getFormField('srch_year'), 'srch_date_from', $LANG['responsesearch_err_tip_date_empty'], $LANG['responsesearch_err_tip_date_invalid']);
				}
				if ($forums->getFormField('srch_todate') || $forums->getFormField('srch_tomonth') || $forums->getFormField('srch_toyear'))
				{
						$forums->chkIsCorrectDate($forums->getFormField('srch_todate'), $forums->getFormField('srch_tomonth'), $forums->getFormField('srch_toyear'), 'srch_date_to', $LANG['responsesearch_err_tip_date_empty'], $LANG['responsesearch_err_tip_date_invalid']);
				}
				if (!$forums->getFormField('srch_date_from') || !$forums->getFormField('srch_date_to'))
				{
						$forums->setCommonErrorMsg($LANG['responsesearch_err_tip_specify_dates']);
						$forums->setPageBlockShow('msg_form_error');
				}
				if ($forums->getFormField('srch_date_from') && $forums->getFormField('srch_date_to'))
				{
						$from_date = explode('-', $forums->getFormField('srch_date_from'));
						$from_date = mktime(0, 0, 0, $from_date[1], $from_date[2], $from_date[0]);
						$to_date = explode('-', $forums->getFormField('srch_date_to'));
						$to_date = mktime(0, 0, 0, $to_date[1], $to_date[2], $to_date[0]);
						if ($to_date < $from_date)
						{
								$forums->setCommonErrorMsg($LANG['responsesearch_err_tip_enter_correct_dates']);
								$forums->setPageBlockShow('msg_form_error');
						}
				}
				$forums->setAllPageBlocksHide();
				if (!$forums->isValidFormInputs())
				{
						$forums->setPageBlockShow('msg_form_error');
				}
		}
		$forums->setPageBlockShow('form_search');
}
else
{
		$forums->setPageBlockShow('msg_form_error');
		Redirect2URL('forums.php');
}




?>
<div id="selForumResponseSearch">
  <div>
    <h2><span>
		<a href="forums.php"><?php echo $LANG['forumlistall_title_index']; ?></a>
		&nbsp;-&nbsp;
		<a href="forumsTopics.php?forum_id=<?php echo $forums->getFormField('forum_id'); ?>">
			<?php echo $forums->forum_details_arr['forum_title']; ?></a>
		&nbsp;-&nbsp;
		<a href="forumsResponses.php?forum_id=<?php echo $forums->getFormField('forum_id'); ?>&topic_id=<?php echo $forums->getFormField('topic_id'); ?>">
		<?php echo html_entity_decode(stripslashes($forums->forum_topic_details_arr['forum_topic'])); ?></a>
		&nbsp;-&nbsp;
		<?php echo $LANG['forumlistall_title_search']; ?>
	</span></h2>
	<div id="selRightNavigation">
		<h3><a href="forums.php"><?php echo $LANG['forumslinks_header']; ?></a></h3>
         <ul>
		 	<li><a href="forumsResponses.php?forum_id=<?php echo $forums->forum_details_arr['forum_id']; ?>&topic_id=<?php echo $forums->getFormField('topic_id'); ?>"><?php echo $LANG['forumslinks_List_response']; ?></li>
            <li><a href="forumsResponseCreate.php?forum_id=<?php echo $forums->forum_details_arr['forum_id']; ?>&topic_id=<?php echo $forums->getFormField('topic_id'); ?>"><?php echo $LANG['forumslinks_post_response']; ?></a></li>
			<li class="clsActivePhotoSubLink"><a href="forumsResponseSearch.php?forum_id=<?php echo $forums->forum_details_arr['forum_id']; ?>&topic_id=<?php echo $forums->getFormField('topic_id'); ?>"><?php echo $LANG['forumslinks_search_response']; ?></a></li>
         </ul>
	</div>
    <div id="selLeftNavigation">
      <?php
if ($forums->isShowPageBlock('msg_form_error'))
{
?>
      <div id="selMsgError">
        <p><?php echo $LANG['msg_error_sorry']; ?> <?php echo $forums->getCommonErrorMsg(); ?></p>
      </div>
      <?php
}
if ($forums->isShowPageBlock('msg_form_success'))
{
?>
      <div id="selMsgSuccess">
        <p><?php echo $LANG['responsesearch_success_message']; ?></p>
      </div>
      <?php
}
?>
<form name="form_search" id="selFormSearch" method="post" action="<?php echo URL($_SERVER['PHP_SELF']); ?>" autocomplete="off">
<?php
if ($forums->isShowPageBlock('form_search'))
{
?>
		<div id="selShowSearch">
			<table border="1" cellspacing="0" summary="<?php echo $LANG['responsesearch_tbl_summary']; ?>">
				<tr>
					<td class="<?php echo $forums->getCSSFormLabelCellClass('srch_response'); ?>"><label for="srch_response"><?php echo $LANG['responsesearch_search_response']; ?></label></td>
					<td class="<?php echo $forums->getCSSFormFieldCellClass('srch_response'); ?>"><input type="text" class="clsTextBox" name="srch_response" id="srch_response" value="<?php echo $forums->getFormField('srch_response'); ?>" tabindex="<?php echo $forums->getTabIndex(); ?>"/></td>
				</tr>
				<tr>
					<td class="<?php echo $forums->getCSSFormLabelCellClass('srch_uname'); ?>"><label for="srch_uname"><?php echo $LANG['responsesearch_search_uname']; ?></label></td>
					<td class="<?php echo $forums->getCSSFormFieldCellClass('srch_uname'); ?>"><input type="text" class="clsTextBox" name="srch_uname" id="srch_uname" value="<?php echo $forums->getFormField('srch_uname'); ?>" tabindex="<?php echo $forums->getTabIndex(); ?>"/></td>
				</tr>
				<tr>
					<td class="<?php echo $forums->getCSSFormLabelCellClass('srch_date_from'); ?>"><label for="srch_date"><?php echo $LANG['responsesearch_search_date_created_from']; ?></label></td>
					<td class="<?php echo $forums->getCSSFormFieldCellClass('srch_date_from'); ?>"><?php echo $forums->getFormFieldErrorTip('srch_date_from'); ?>
						<select name="srch_date" id="srch_date" tabindex="<?php echo $forums->getTabIndex(); ?>">
							<option value=""><?php echo $LANG['responsesearch_search_date']; ?></option>
							<?php $forums->populateBWNumbers(1, 31, $forums->getFormField('srch_date')); ?>
						</select>
						<select name="srch_month" id="srch_month" tabindex="<?php echo $forums->getTabIndex(); ?>">
							<option value=""><?php echo $LANG['responsesearch_search_month']; ?></option>
							<?php $forums->populateMonthsList($forums->getFormField('srch_month')); ?>
						</select>
						<select name="srch_year" id="srch_year" tabindex="<?php echo $forums->getTabIndex(); ?>">
							<option value=""><?php echo $LANG['responsesearch_search_year']; ?></option>
							<?php $forums->populateBWNumbers(1920, date("Y"), $forums->getFormField('srch_year')); ?>
						</select>
					</td>
				</tr>
				<tr>
					<td class="<?php echo $forums->getCSSFormLabelCellClass('srch_date_to'); ?>"><label for="srch_date"><?php echo $LANG['responsesearch_search_date_created_to']; ?></label></td>
					<td class="<?php echo $forums->getCSSFormFieldCellClass('srch_date_to'); ?>"><?php echo $forums->getFormFieldErrorTip('srch_date_to'); ?>
						<select name="srch_todate" id="srch_todate" tabindex="<?php echo $forums->getTabIndex(); ?>">
							<option value=""><?php echo $LANG['responsesearch_search_date']; ?></option>
							<?php $forums->populateBWNumbers(1, 31, $forums->getFormField('srch_todate')); ?>
						</select>
						<select name="srch_tomonth" id="srch_tomonth" tabindex="<?php echo $forums->getTabIndex(); ?>">
							<option value=""><?php echo $LANG['responsesearch_search_month']; ?></option>
							<?php $forums->populateMonthsList($forums->getFormField('srch_tomonth')); ?>
						</select>
						<select name="srch_toyear" id="srch_toyear" tabindex="<?php echo $forums->getTabIndex(); ?>">
							<option value=""><?php echo $LANG['responsesearch_search_year']; ?></option>
							<?php $forums->populateBWNumbers(1920, date("Y"), $forums->getFormField('srch_toyear')); ?>
						</select>
					</td>
				</tr>
				<tr>
					<td class="<?php echo $forums->getCSSFormFieldCellClass('responsesearch_search'); ?>" colspan="2"><input type="submit" class="clsSubmitButton" value="<?php echo $LANG['responsesearch_search']; ?>" id="responsesearch_search" name="responsesearch_search" tabindex="<?php echo $forums->getTabIndex(); ?>"/></td>
				</tr>
			</table>
		</div>
      <?php
}
?>
		<input type="hidden" name="forum_id" value="<?php echo $forums->getFormField('forum_id'); ?>" />
		<input type="hidden" name="topic_id" value="<?php echo $forums->getFormField('topic_id'); ?>" />
	  </form>
    </div>
  </div>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>
