<?php //00461
// Copyright Notice
// Web Site URL:  http://www.zeeways.com
// Script Owner eMail: mail@zeeways.com
// Date: April, 2007
// Script Name: Zeeways Auction Website PHP Script
// Copyright Details: This script is not free.  Do not Remove this Copy Right notice.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the site administrator.');exit(199);
?>
4+oV5COh5LlF0kwSWf20UFBEA96Y9q3Vnjv6eDv+mX8gDgjT/FOsO66K3EUNBmuxEadu5BIpCgix
/tEIXXe+kmfNdkFoP/qn0W43E+pv2kuVzpsPOxoGAl3hDrCv1J7HCX9bE7DkzjNebo94SpMg2ykH
q14KS9M2hh3I6xHRcgmsMe6Zid3coPIkKuND6TRTmalMuhh8WrwPC+KHeYrdgUjlRUtPo5LdilgK
YhM7goEpWHbyLmhiOy5RUPQcD0nCS/Sjhab+jffm4OFOOsc9BIqUZe55Tu3yjG+2Qr0rngbuS1Wi
pfTDn3qf51hF56FVOuauVLzv9TkwNqaEK1OWUCFI1MZ7K7CPTlhegv9Aev7Ycj6sHgGgAKxEJrTD
6bYvI4fNmunrDFl+GGKQV8ktNAArtR34lOlUGbze+1GfYaiSPCYFxHtO5Vx47y4OmGigKGk97iN/
rtxJ4bY021AuK6CZor2jil2rdS9g0hhJ2Mbkz0fccP95LfM9dTnaqm2I5gUB2J9y53C3g94RylzC
Vc/4GBoThPjzzybUfwyGl5q6Ms79lTlvjDqgtdXr8Y1DU6Z4OskC0FwDtnu1hXt4vluVdB+P1hbg
A4qrs7cgX20ajo+Sc70BZO00lvs6/znfzySpQULyCyS8pKmqKd1LZhj0m4XLGkbqkgHhO6CTNRek
uDpolfdXjKQ04Dk0JgP5sPH7k0aJBXvw/JDgiOGq9XiPkbMc/LI1tJgJBRBPs9nIbExpEh7c0eGo
Z9exJegdSk55ATCnBB0LXQOcWvFXHfLXYetL/Upkkczue96fKISoX0u9Zn8rVVV2I9efIv899kZ5
kFnWIPQlVVzTLuVIMdonPh0ldLtNeBc3HsYUxSH48RxO3ywj6rLgRF0qnW56H7xux9UDaGKwcc31
PEDmkbyiKSS5TwQhr3HnGiWOWzwR8AjASP2AXJRme7JOI0NMRdKtHYE0IWe4z4XSQnGMY3RbmgCQ
u04dIqJVkc/1klg3jdcymz6e3RBVQLrDtiJg2sEFKcPS8+2RpBjTArYWh9SJxYu=