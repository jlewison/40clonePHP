<?php //00461
// Copyright Notice
// Web Site URL:  http://www.zeeways.com
// Script Owner eMail: mail@zeeways.com
// Date: April, 2007
// Script Name: Zeeways Auction Website PHP Script
// Copyright Details: This script is not free.  Do not Remove this Copy Right notice.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the site administrator.');exit(199);
?>
4+oV58fJ08Q7fVYfIkYLfG6vvBv3Ier4m1V51+8QTcFRYBjxmkw8OCa0Mi9rx4ww6kLG8R8rzOwg
aJurI6Aw+Rho8IIJ6D9dx63dwxwsrqsbEAR/A4jd7I1n6YhEw+lLayaHQ4WFOZh+FjM1/JVQQSpU
wOu1PjDHqqndVYmH7WngrtibHRP1ZEtKbFhWFsIqJ2HvN7aidK0qHlVRy4G/bNK7S0EHCGGaTI0d
njlczdDTggrxtLMMs8oVQ9QcD0nCS/Sjhab+jffm4OFMOuZdSrrhff7H9y9ifZNy28mvIPrQJk+M
Avm7y7IX5nUXRrzC5QlMfvbRnwvEAy3xHuOzzUmRKtOvrfq5dAniRGVEZuvemZJMGgnK2KPJzXhU
WE106ybsD3dBULZ1r6GF2DHNG+CVXufKzO1dKcw2GTOI/j+RQypG/vnoP5HPK89mGcMU+c7h2Iu7
1ctEY+syEkRr429GTR/5iiZPI8X2CXsiRm5M7Y9+x7SpdHlMTu0Ld729RAd41J7dw4BbH98Z0Hg/
ax+Pmp/g4Uv0wsbjSc3NI1MK3Dkq8amllu45OpalZpX4DquEPAAn9y3ITZ692en3UqK1GbvKPBjK
qWq0zZlQGnL2AWoUc2NmlzIx03MpsakftMvlIOiwIVJYb4xXidx8oxUElILS6NJ9Y8i1T+xgxBwS
h3swuHuAMjXJGGAFaBZZt+vPu3WVTGDJ7nsopQxgD3XYvvkxbS9qoVdKHREf8eEQP5LVMY3RtQ9j
A92QNUxIcGREXYXRSxBoEpD7abGBp9f9BLDPqIWaEgpl68cdXGKjr230mwOrQY1HCp6ql4hmx8c0
74FfCHrJuvZuyL+PR+yqcN0fO4beKAkIjWficvAOSMUbPT95wW==