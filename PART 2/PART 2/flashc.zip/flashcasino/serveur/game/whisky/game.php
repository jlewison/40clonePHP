<?
/*
$my_count = 0;
$max_part_of_bank_at_once = 3;
$get_more_than_bet_freq = 2;
$max_gain_at_once = 100;
$max_gain_in_double = 200;
$max_super_prize = 500;
*/

$cash_for_get_hat = 45; 


$gameid="1";

error_reporting(0);

unset($l); 
session_start();
session_register($l);
if(!isset($l)){ 
header("Location: ../../login.php"); 
exit; 
}

include ("../../setup.php");



$win_prizes=Array(
	array(0,0, 200,1000,5000),
	array(0,0,  30, 100, 500),
	array(0,0, 100, 500,2000),
	array(0,0,  20,  50, 200),
	array(0,0,  10,  30, 100),
	array(0,0,   3,   5,  20),
	array(0,0,   5,  10,  50),
	array(0,0,   2,   3,  10),
	array(0,0,   0,   0,   0)
);

$lines=array(
	"1"=>array(		
		// line 1
		"1" => array(
			array(0,1),
			array(1,1),
			array(2,1),
			array(3,1),
			array(4,1)
		)
	),	
	"3"=>array(		
		// line 2
		"2" => array(
			array(0,0),
			array(1,0),
			array(2,0),
			array(3,0),
			array(4,0)
		),
		// line 3
		"3" => array(
			array(0,2),
			array(1,2),
			array(2,2),
			array(3,2),
			array(4,2)
		)
	),
	"5"=>array(
		// line 4
		"4" => array(
			array(0,0),
			array(1,1),
			array(2,2),
			array(3,1),
			array(4,0)
		),
		// line 5
		"5" => array(
			array(0,2),
			array(1,1),
			array(2,0),
			array(3,1),
			array(4,2)
		)
	),
	"7"=>array(
		// line 6
		"6" => array(
			array(0,0),
			array(1,0),
			array(2,1),
			array(3,0),
			array(4,0)
		),
		// line 7
		"7" => array(
			array(0,2),
			array(1,2),
			array(2,1),
			array(3,2),
			array(4,2)
		)
	),
	"9"=>array(
		// line 8
		"8" => array(
			array(0,1),
			array(1,2),
			array(2,2),
			array(3,2),
			array(4,1)
		),
		// line 9
		"9" => array(
			array(0,1),
			array(1,0),
			array(2,0),
			array(3,0),
			array(4,1)
		)
	)	
);


$res=mysql_query("select * from crzsettings");
while ($row=mysql_fetch_array($res)) {	
	switch ($row["name"]) {		
		case 'get_more_than_bet_freq':		
			if (!isset($get_more_than_bet_freq)) $get_more_than_bet_freq=$row["value"];			
			break;
		case 'max_part_of_bank_at_once':		
			if (!isset($max_part_of_bank_at_once)) $max_part_of_bank_at_once=$row["value"];			
			break;
		case 'max_gain_at_once':		
			if (!isset($max_gain_at_once)) $max_gain_at_once=$row["value"];			
			break;
		case 'max_gain_in_double':		
			if (!isset($max_gain_in_double)) $max_gain_in_double=$row["value"];			
			break;
		case 'max_gain_on_rope':		
			if (!isset($max_gain_on_rope)) $max_gain_on_rope=$row["value"];			
			break;
		case 'max_super_prize':		
			if (!isset($max_super_prize)) $max_super_prize=$row["value"];			
			break;
		case 'bonus_freq':		
			if (!isset($bonus_freq)) $bonus_freq=$row["value"];			
			break;
		case 'banana_freq':
			if (!isset($banana_freq)) $banana_freq=$row["value"];
			break;
		case 'bonus_min':
			if (!isset($bonus_min)) $bonus_min=$row["value"];
			break;
		case 'bonus_max':
			if (!isset($bonus_max)) $bonus_max=$row["value"];
			break;
		case 'bonus2_50':
			if (!isset($bonus2_50)) $bonus2_50=$row["value"];
			break;
		case 'bonus2_100':
			if (!isset($bonus2_100)) $bonus2_100=$row["value"];
			break;
		case 'bonus2_150':
			if (!isset($bonus2_150)) $bonus2_150=$row["value"];
			break;
		case 'bonus2_200':
			if (!isset($bonus2_200)) $bonus2_200=$row["value"];
			break;
		case 'bonus2_250':
			if (!isset($bonus2_250)) $bonus2_250=$row["value"];
			break;
		default:
			$items=split(",",$row["name"]);			
			if ($items[0]=="wl") {
				if (isset($GLOBALS["wl".$items[1].$items[2]]))
					$wl[$items[1]][$items[2]]=$GLOBALS["wl".$items[1].$items[2]];
				else
					$wl[$items[1]][$items[2]]=$row["value"];
			}
			break;					
	}
}

if ((!empty($mon))&&($mon!=0)) {	
	$sql="SELECT * FROM `game_sessions` WHERE login='$l' AND gameid=$gameid AND active=1;";
	$res=mysql_query($sql) or die();
	if (mysql_num_rows($res)==0) {
		echo "&done=done&exit=2";		
		exit;
	}
	$srow=mysql_fetch_array($res);
	$sparams=$srow[state];
	$sparams_items=split(",",$sparams);	
}

$result=mysql_query("select * from users where login='$l'") or die();
$row=mysql_fetch_array($result);
$cash=$row[3];
$rowb=mysql_fetch_array(mysql_query("select * from game_bank where name='ttuz'"));
$caswin = $rowb['bank']/100*$rowb['proc'];


if ($bet_per_line<0.1 || $bet_per_line>25)
	$bet_per_line=0.1;
if ($line_play!=1 && $line_play!=3 && $line_play!=5 && $line_play!=7 && $line_play!=9)
	$line_play=1;
$cash2spin=$bet_per_line*$line_play;
if ($cash < $cash2spin) {
	$cash=0;
	echo "&done=done&exit=1";
	exit;
}

//for ($t = 0; $t<1000000; $t++) $t=$t;

//$mon==0 
if ($mon==0 || empty($mon)) {	
	
	$sql="UPDATE `game_sessions` SET active=0 WHERE login='$l';";
	$res=mysql_query($sql);// or die(); 
	echo mysql_error();
	
$sql="INSERT INTO `game_sessions` (login,state,cr_tstamp,cashin,cashchange,lastact_tstamp,gameid,active) VALUES ('$l','0',NOW(),$row[3],0,NOW(),$gameid,1);";
	$res=mysql_query($sql) or die();		
	echo "&cash=$row[3]&done=done";
}

//$mon==1 			
elseif ($mon==1) {
	$_cash=$row[3]-$cash2spin;
	mysql_query("update users set cash=cash-$cash2spin where login='$l'");

if ( $l != "demo" ) {
        mysql_query("update game_bank set bank=bank+$cash2spin where name='ttuz'");

}
	mysql_query("update `game_sessions` SET cashchange=cashchange-$cash2spin,lastact_tstamp=NOW() WHERE login='$l' AND gameid=$gameid AND active=1;");
	
//  echo "max_part_of_bank_at_once: $max_part_of_bank_at_once<br>";
//  echo "get_more_than_bet_freq: $get_more_than_bet_freq<br>";
//  echo "max_gain_at_once: $max_gain_at_once<br>";



  srand ((double) microtime()*1000000);
  if (rand(1,$bonus_freq)==1)
    $can_be_bonus_game=true;
  else
    $can_be_bonus_game=false;
  
  do { 

    if ($caswin <= 0) {
      $can_win = false;
      $can_win_more_than_bet=false;
    }
    else {
      $can_win = true;

      if (rand(1,$get_more_than_bet_freq)==1)
        $can_win_more_than_bet=true;
      else
        $can_win_more_than_bet=false;
    }

//    echo "can_win: $can_win<br>";
//    echo "can_win_more_than_bet: $can_win_more_than_bet<br>";

    do { 
      
      for ($x=0;$x<5;$x++) {			
        $sims[0][$x]=rand(1,9);			
        do {
          $sims[1][$x]=rand(1,9);
        } while ($sims[1][$x]==$sims[0][$x]);
        do {
          $sims[2][$x]=rand(1,9);
        } while (($sims[2][$x]==$sims[0][$x])||($sims[2][$x]==$sims[1][$x]));
      }

      $win=0;
      $win_lines="";
    
      for ($tline=1;$tline<=$line_play;$tline+=2) {		
  
        foreach ($lines[$tline] as $linen => $val) {

          $eq_item=0;
          $eq_count=0;
          $eq_prize=0;
          for ($i=0;$i<5;$i++) {				
            $cur_itemi=$sims[$val[$i][1]][$val[$i][0]];								
            $eq_counti=1;
            if ($cur_itemi==9) continue;
            for ($j=$i+1;$j<5;$j++) {					
              $cur_itemj=$sims[$val[$j][1]][$val[$j][0]];					
          
             
              if (($cur_itemi==3)&&($cur_itemj!=3)) {
                $eq_prizei=$win_prizes[$cur_itemi-1][$eq_counti-1];
           
                if ($eq_prizei>0) 
                  break;
                else
                 
                  $cur_itemi=$cur_itemj;
              }
           
              if (($cur_itemi==$cur_itemj)||($cur_itemj==3))
                $eq_counti++;
              else
                break;
            }

            $eq_prizei=$win_prizes[$cur_itemi-1][$eq_counti-1];
          
            if ($eq_prizei>$eq_prize) {
              $eq_item=$cur_itemi;
              $eq_count=$eq_counti;
              $eq_prize=$eq_prizei;
            }

            
          }

         
          if ($eq_prize>0) {
            $win+=$eq_prize*$bet_per_line;
            $win_lines.="&wl{$linen}=".($bet_per_line*$eq_prize);
          }

        } 
      } 

  
      $my_count++;
//      echo "count: $my_count; win: $win; caswin: $caswin<br>";

     
    } while (
      ($win > 0)&&(!$can_win)||
      (!$can_win_more_than_bet)&&($win > $cash2spin)||
      ($can_win_more_than_bet)&&(($win > $caswin/$max_part_of_bank_at_once)||($win > $max_gain_at_once)));

  	
    $monkeys_count=0;
    for ($y=0;$y<3;$y++) {
      for ($x=0;$x<5;$x++) {
        if ($sims[$y][$x]==9)
          ++$monkeys_count;			
      }
    }
//    echo "monkeys_count: $monkeys_count<br>";

    if (($monkeys_count>=3)&&($can_be_bonus_game)) {			
      $bonus_game=4;	
      $win=0;
    }
    else
      $bonus_game=0;

//    echo "can_be_bonus_game: $can_be_bonus_game; bonus: $bonus_game<br>";

  } while (!$can_be_bonus_game && ($monkeys_count>=3));
		
	
	if ($win>0) {
		mysql_query("update users set cash=cash+$win where login='$l'");


if ( $l != "demo" ) {
    mysql_query("update game_bank set bank=bank-$win where name='ttuz'");

}
}
$date=date("d.m.y");
$time=date("H:i:s");
$sqls="INSERT INTO stat_game VALUES('NULL','$date','$time','$l','$row[3]','$cash2spin','$win','luckydrink')";
mysql_query($sqls);
  //
	$hat=($cash2spin < $cash_for_get_hat)?"0":"1";
		
	if ($bonus_game!=0) {
		$cash_change=0;
		$session_state="3,$bet_per_line,0,0,0,0,0,0,0,$hat,$cash2spin";
	}
	elseif ($win>0) {
		$cash_change=$win;
		$session_state="5,$win,$cash2spin";		
	}
	else {
		$cash_change=0;
		$session_state="1,0,$cash2spin";		
	}
	$sql="UPDATE `game_sessions` SET state='$session_state', cashchange=cashchange+$cash_change, lastact_tstamp=NOW() WHERE login='$l' AND gameid=$gameid AND active=1";
	$res=mysql_query($sql) or die();		
	
	
	echo "&cash=$_cash&win=$win&bonus=$bonus_game&done=done{$win_lines}&bet_per_line=$bet_per_line"
  ."&sim00={$sims[0][0]}&sim01={$sims[0][1]}&sim02={$sims[0][2]}&sim03={$sims[0][3]}&sim04={$sims[0][4]}"
  ."&sim10={$sims[1][0]}&sim11={$sims[1][1]}&sim12={$sims[1][2]}&sim13={$sims[1][3]}&sim14={$sims[1][4]}"
  ."&sim20={$sims[2][0]}&sim21={$sims[2][1]}&sim22={$sims[2][2]}&sim23={$sims[2][3]}&sim24={$sims[2][4]}";

/*
  echo "&cash=$_cash&win=$win&bonus=4&done=done{$win_lines}&bet_per_line=$bet_per_line"
  ."&sim00=1&sim01=1&sim02=1&sim03=1&sim04=1"
  ."&sim10=10&sim11=10&sim12=10&sim13=10&sim14=10"
  ."&sim20=9&sim21=9&sim22=9&sim23=9&sim24=9";
*/
}


elseif ($mon==2) {
	$items=Array("2","3","4","5","6","7","8","9","10","�����","����","������","���");
	// ���� � double ���� ��� ��������� �� ��������
	if ($sparams_items[0]==7 || $sparams_items[0]==5 || $sparams_items[0]==11 || $sparams_items[0]==12 || $sparams_items[0]==8 || $sparams_items[0]==9 ) {				
		$dstage=($sparams_items[0]==7)?$sparams_items[3]:1;
		// ����� ����� ������
		if ($sparams_items[0]==5) {
			$_cash=$row[3]-$sparams_items[1];
			$_winvalue=0;
		}
		elseif ($sparams_items[0]==11 || $sparams_items[0]==12 || $sparams_items[0]==8 || $sparams_items[0]==9 ) {
			$_cash=$row[3]-$sparams_items[2];
			$_winvalue=0;
			$sparams_items[1]=$sparams_items[2];
		}
		else {
			$_cash=$row[3]-$sparams_items[1]-$sparams_items[2];			
			$_winvalue=$sparams_items[2];
		}		
		$_winprize=$sparams_items[1]*$dstage;		
		
    srand((double)microtime()*1000000);
		$card1=rand(0,12)+rand(0,3)*13+1;				
		$session_state="2,{$sparams_items[1]},$_winvalue,$dstage,$card1";		
		$sql="UPDATE `game_sessions` SET state='$session_state', lastact_tstamp=NOW() WHERE login='$l' AND gameid=$gameid AND active=1";
		$res=mysql_query($sql) or die();
		echo "&done=done&bonus=1&card1=$card1&card2=53&card3=53&card4=53&card5=53&cash=$_cash&stage=$dstage&win={$sparams_items[1]}&winprize=$_winprize";
	}
	else if ($sparams_items[0]==2) {
		$dstage=($sparams_items[0]==5)?1:$sparams_items[3];
		$win=$sparams_items[1];
   
		$dealer_card=$sparams_items[4];	
		$dealer_card_value=($dealer_card-1)%13;
    $card1 = $dealer_card;

		
		if ($card>3) $card=0;
		do {
			srand((double)microtime()*1000000);
      do {
  			$card2=rand(0,12)+rand(0,3)*13+1;
      } while ($card2 == $card1);
      do {
  			$card3=rand(0,12)+rand(0,3)*13+1;
      } while (($card3 == $card2)||($card3 == $card1));
      do {
  			$card4=rand(0,12)+rand(0,3)*13+1;
      } while (($card4 == $card3)||($card4 == $card2)||($card4 == $card1));
      do {
  			$card5=rand(0,12)+rand(0,3)*13+1;
      } while (($card5 == $card4)||($card5 == $card3)||($card5 == $card2)||($card5 == $card1));

			switch ($card) {
			case 0:
				$card_value=($card2-1)%13;
				break;			
			case 1:
				$card_value=($card3-1)%13;
				break;			
			case 2:
				$card_value=($card4-1)%13;
				break;			
			case 3:
				$card_value=($card5-1)%13;
				break;			
			}	
			if ($card_value>$dealer_card_value)
				$win_now=pow(2,$dstage-1)*$win;
			else
				$win_now=0;
 		} while (($win_now>$caswin/$max_part_of_bank_at_once)||($win_now > $max_gain_in_double));

    $win_now=0;

/*
    if ($dstage == 1)
      $card_value= $dealer_card_value+1;
    if ($dstage > 1)
      $card_value= $dealer_card_value;
*/

    if ($card_value>$dealer_card_value) {			
      // �������� ������ �����			
			$win_now=pow(2,$dstage-1)*$win;
			mysql_query("update users set cash=cash+$win_now where login='$l'");

if ( $l != "demo" ) {
      mysql_query("update game_bank set bank=bank-$win_now where name='ttuz'");

}
			$_cash=$row[3]-$sparams_items[2]-$win;
			$dstage++;

     
			srand((double)microtime()*1000000);
			$dealer_card=rand(0,12)+rand(0,3)*13+1;
			$winvalue=$win_now+$sparams_items[2];
			$winprize=$winvalue+$win;			
			$session_state="2,$win,$winvalue,$dstage,$dealer_card";
			$cash_change=$win;		
			$bonus=1;	
			$win=$sparams_items[1];
			$adv="&adv=$win_now";
		}		
		else {
      if ($card_value == $dealer_card_value) {
        //������� �� Double � ��� ��� ������������
        $winvalue=$win;
        $winprize=$winvalue;			
        $cash_change=0;
        $_cash=$row[3];
        $session_state="2";
        $bonus=2;	
        $win=$sparams_items[1];
        $adv="&adv=0";
      }
      else {
       
        $loss=$sparams_items[2]+$sparams_items[1];
        mysql_query("update users set cash=cash-$loss where login='$l'");

if ( $l != "demo" ) {
       mysql_query("update game_bank set bank=bank+$loss where name='ttuz'");

}	
        $_cash=$row[3]-$loss;
        $cash_change=-$loss;			
        $winvalue=0;
        $session_state="6";		
        $winprize=0;
        $bonus=3;
        $win=0;
        $adv="&loss=$win_now";
      }
		}
		
		$sql="UPDATE `game_sessions` SET state='$session_state', cashchange=cashchange+$cash_change, lastact_tstamp=NOW() WHERE login='$l' AND gameid=$gameid AND active=1";
		$res=mysql_query($sql) or die();
		echo "&done=done&bonus=$bonus&card1=$dealer_card&card2=$card2&card3=$card3&card4=$card4&card5=$card5&cash=$_cash&stage=$dstage&win=$win&scard=$card&winprize=$winprize$adv&dealervalue=$dealer_card_value&cardvalue=$card_value";
	}
	else {
		echo "&done=done&exit=3";	
		exit;	
	}
}

elseif ($mon==4) {
	if ($sparams_items[0]==3 || $sparams_items[0]==8) {
		// ���������� ����� �� ������������ ��� �������
		if ( $rope<0 || $rope>4 ) {
			echo "&done=done&exit=5";
			exit;
		}
		if ($sparams_items[$rope+4]!=0) {
			echo "&done=done&exit=6";
			exit;
		}

		$hat=$sparams_items[9];

		do {
			
			srand((double)microtime()*1000000);				
			if (rand(1,$banana_freq)==1) 
        $bitem=0; 
      else
        $bitem=rand(1,2); 

			$sparams_items[4+$rope]=1;
			$cash2spin=$sparams_items[10];
			$win=0;
			$_cash=$row[3]-$sparams_items[2];
			if ($bitem==0)
				$betswin=rand($bonus_min,$bonus_max);
			else
				$betswin=0;
			$win=$cash2spin*$betswin;
		} while (($win>$caswin/$max_part_of_bank_at_once)||($win > $max_gain_on_rope));
				
		if ($bitem==0) {
			// ��������� ������
			$winprize=$sparams_items[2]+$win;
			$session_state="8,{$sparams_items[1]},$winprize,$rope,{$sparams_items[4]},{$sparams_items[5]},{$sparams_items[6]},{$sparams_items[7]},{$sparams_items[8]},$hat,$cash2spin";
			$cash_change=$win;
			mysql_query("update users set cash=cash+$win where login='$l'");

if ( $l != "demo" ) {
    mysql_query("update game_bank set bank=bank-$win where name='ttuz'");

}
			$next=1;
		}
		else {
			if ($hat==1) {
				$hat=0;
				$winprize=$sparams_items[2];			
				$session_state="8,{$sparams_items[1]},$winprize,$rope,{$sparams_items[4]},{$sparams_items[5]},{$sparams_items[6]},{$sparams_items[7]},{$sparams_items[8]},$hat,$cash2spin";
				$cash_change=0;
				$next=1;
			}
			else {
				$winprize=$sparams_items[2];
				$cash_change=0;			
				$session_state="9,{$sparams_items[1]},$winprize,$rope,{$sparams_items[4]},{$sparams_items[5]},{$sparams_items[6]},{$sparams_items[7]},{$sparams_items[8]},$hat,$cash2spin";
				$next=0;
			}
		}
		
		if ($next==1) {				
			$bcount=0;
			for ($i=0;$i<5;$i++)
				if ($sparams_items[4+$i]!=0)
					++$bcount;
			if ($bcount==5) {
				$session_state="10,{$sparams_items[1]},$winprize,$rope,{$sparams_items[4]},{$sparams_items[5]},{$sparams_items[6]},{$sparams_items[7]},{$sparams_items[8]},$hat,$cash2spin";
				$bonus=5;
			}
			else
				$bonus=4;			
		}
		else
			$bonus=4;
		$sql="UPDATE `game_sessions` SET state='$session_state', cashchange=cashchange+$cash_change, lastact_tstamp=NOW() WHERE login='$l' AND gameid=$gameid AND active=1";
		$res=mysql_query($sql) or die();		
		echo "&done=done&hat=$hat&winnow=$betswin&bet_per_line=$sparams_items[1]&cash=$_cash&winprize=$winprize&bitem=$bitem&rope=$rope&bonus=$bonus&r0={$sparams_items[4]}&r1={$sparams_items[5]}&r2={$sparams_items[6]}&r3={$sparams_items[7]}&r4={$sparams_items[8]}&total_bet=$cash2spin";
	}
	else {
		echo "&done=done&exit=4";
		exit;
	}	
}
elseif ($mon=5) {
	if ($sparams_items[0]==10) {
		do {
			srand((double)microtime()*1000000);
			
      $winitem=rand(0,5)*50;		
			if (($winitem>0)&&(rand(1,$GLOBALS["bonus2_".($winitem*50)])==1))
				$iswin=1;
			else {
				$iswin=0;
				$winitem=0;
			}			
			$win=0;
			$_cash=$row[3]-$sparams_items[2];

      if ($iswin==1)
				$win=$winitem*$sparams_items[1];
			else
				$win=0;
 		} while (($win>$caswin/$max_part_of_bank_at_once)||($win > $max_super_prize));

		if ($iswin==1) {
			// ��������� ������			
			$winprize=$sparams_items[2]+$win;
			$session_state="11,{$sparams_items[1]},$winprize,$box";
			$cash_change=$win;
			mysql_query("update users set cash=cash+$win where login='$l'");

if ( $l != "demo" ) {
      mysql_query("update game_bank set bank=bank-$win where name='ttuz'");

}
		}
		else {
			$session_state="12,{$sparams_items[1]},$winprize";
			$winprize=$sparams_items[2];
			$cash_change=0;			
			$session_state="12,{$sparams_items[1]},$winprize,$box";
			$winitem=0;
			$win=0;
		}
		$sql="UPDATE `game_sessions` SET state='$session_state', cashchange=cashchange+$cash_change, lastact_tstamp=NOW() WHERE login='$l' AND gameid=$gameid AND active=1";
		$res=mysql_query($sql) or die();		
		echo "&done=done&winnow=$win&bet_per_line=$sparams_items[1]&cash=$_cash&winprize=$winprize&bonus=5&winitem=$winitem&box=$box";		
	}
	else {
		echo "&done=done&exit=7";
		exit;
	}	
}

?>