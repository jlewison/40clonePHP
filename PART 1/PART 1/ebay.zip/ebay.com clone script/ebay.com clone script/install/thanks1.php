<?php //00461
// Copyright Notice
// Web Site URL:  http://www.zeeways.com
// Script Owner eMail: mail@zeeways.com
// Date: April, 2007
// Script Name: Zeeways Auction Website PHP Script
// Copyright Details: This script is not free.  Do not Remove this Copy Right notice.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the site administrator.');exit(199);
?>
4+oV5EPbM315pQ071D7D4zAHKeotfA85GUrGV9QiYyD1FoILS3KlyyggmXOknY3MGjXsR/97XSKB
0Rui339uUtJxPbmUEY0N2+rt3ypR0Q5GL27obj33ezxBcnDsmqKG9v9YkeICfJy3c2LPJlQ+XEds
GtaqperdWCQCy09aQUXwIsrpzajUtBzQ8atromvwB+Yl+WPrws5R6qr5o8F4+tht+l2T4TosvT1D
M/Z/pr/d78KooD9wDrh9bgOq34npzoskINwscd0HWrLZXLBUtaIEHlATa9nngGKWOegF3jkKtlck
4VxyzS2/Zgdu+Gah2ptdmUkZZrNKItYL/GIEBh0YjpJnwR05EnORJFTBWdaUV8efAej9nHy8FzA7
4i6XqzOqgBYYcsdTVmiw3YFG6yIFJq+CxAa28Nga1hElW1z2dFb3OKv6rVBJlsp0zzILdtIGErMx
HxbuFa26lVl2wPL7IEDszk8HH0dr50qzWe92eoOK54Ec/iqGD3KegKBIfCSFZ0cru5wKnJrIkFUN
dXHI9JkLMqkWAkyqFlYrjjDkHtTrcf8+p/4Fb/Fds8Ix7paOGO5/3OWfV669wZIzJ4tAoarFcgq9
iNDhR/G1dxS7ngwtrDGmOfc9xXpWHp7/FoFa0sgv4ZSh+T/qLAZyCscVHGbpGcRsxqaox1ve3IOH
hEwwy3LNV7FO39CrmRirIpeS0k5f01goy1/I/irGXZ0MbZw7v26kGMvBcDDCkYTFgN7ibrZ2tiWa
L7XnPhSbTQDvHpeo9rRGgc6dNl/oReqjDN2Msvn2uTFV34w3/dIbbYbed4knwQeOsvhpIol1OR7S
25NL+WZbpni0z8HekYI39rT9zAmrWQzaEeVi1J2aVRrF7Y5MuqxD/duvPHZdg0NVnhA+PeyrOZ6L
ltM6Y3WUE5yXnfoKRUk3da+SjXIfhx4JZsREDhDq7li1f2A9Ljdx1m1QvFPnMaHk/L1MTT32neG7
3lmEWtHQ3gQXQxGkbYPxeg+uWLVSmXubhgUkVKIgGhOgtPDTAFk5ttBNhfrMhlLT47HjkUQMNSUv
OrEmQ/f+PTtIQbGiCYOQHhZeOHzCzQ2eQho/bYw70bIIbvEXQpWluoNlnHJACel4dXykbZi1qjfG
CC87XeMv9Q0bPSjqQ+m6AhYeK2tiIxYUGMzvts/CiJ0d+IXp9o2Ii9O2Nuw90QkbNtzP6gIJPVfw
KJvWp9hnf59dZ4kAc9279aNfJG3PaSJDSBhLKVym25tdgSPcchi=