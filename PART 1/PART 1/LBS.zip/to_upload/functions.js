function checkAll(field)
{
    for (i = 0; i < field.length; i++)
	field[i].checked = true ;
}

function uncheckAll(field)
{
    for (i = 0; i < field.length; i++)
	field[i].checked = false ;
}

function chHtml(oId, oHtml)
{
    if (document.getElementById || document.all)
    {
        var obj = document.getElementById? document.getElementById(oId): document.all[oId];
        if (obj && typeof obj.innerHTML != "undefined") obj.innerHTML = oHtml;
    }
}


/* Advanced Link Stats Functions */
function switchVis(obj) {
        
    myId = document.getElementById(obj).id;
    
    if (document.getElementById) { // DOM3 = IE5, NS6

        if(document.getElementById(obj).style.visibility == 'visible')
        {
            document.getElementById(obj).style.visibility = 'hidden';
            document.getElementById(obj).style.display = 'none';
        }
        else if(document.getElementById(obj).style.visibility == 'hidden')
        {
            document.getElementById(obj).style.visibility = 'visible';
            document.getElementById(obj).style.display = 'block';
        }
         else {
            document.getElementById(obj).style.visibility = 'visible';
            document.getElementById(obj).style.display = 'block';
        }
    } else {
        if (document.layers) { // Netscape 4
            if(document.obj.visibility == 'visible') {
                document.obj.visibility = 'hidden';
                document.obj.display = 'none';                
            } else if(document.obj.visibility == 'hidden') {
                document.obj.visibility = 'visible';
                document.obj.display = 'block';                
            } else {
                document.obj.visibility = 'hidden';
                document.obj.display = 'none';           
            }
        } else { // IE 4
            if(document.all.obj.style.visibility == 'visible') {
                document.all.obj.style.visibility = 'hidden';
                document.all.obj.style.display = 'none';                
            } else if(document.all.obj.style.visibility == 'hidden') {
                document.all.obj.style.visibility = 'visible';
                document.all.obj.style.display = 'block';                

            } else {
                document.all.obj.style.visibility = 'hidden';
                document.all.obj.style.display = 'none';                

            }
        }
    }
}
