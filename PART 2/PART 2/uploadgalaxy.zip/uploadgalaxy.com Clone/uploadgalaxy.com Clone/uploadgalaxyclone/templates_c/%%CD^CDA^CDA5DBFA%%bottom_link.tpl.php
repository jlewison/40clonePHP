<?php /* Smarty version 2.6.6, created on 2006-02-01 09:53:09
         compiled from bottom_link.tpl */ ?>
<TABLE width=600> 
<TBODY> 
<TR> 
<TD align=middle width="94">&nbsp;</TD> 
<TD width="8"><IMG height=13 src="images/menuborder.gif" width=4 border=0></TD> 
<TD align=middle width="97">
<a class="A" href="report.php">Report abuse</a>
</TD> 
<TD width="8"><IMG height=13 src="images/menuborder.gif" width=4 border=0></TD> 
<TD align=middle width="111">
<a target="_blank" class="A" href="policy.php">Privacy policy</a>
</TD> 
<TD width="8"><IMG height=13 src="images/menuborder.gif" width=4 border=0></TD> 
<TD align=middle width="123">
<A href="terms.php" target=_blank class="A">Terms of service</A>
</TD> 
<TD width="7"><IMG height=13 src="images/menuborder.gif" width=4 border=0></TD> 
<TD align=middle width="106">&nbsp;</TD>
</TR>
</TBODY>
</TABLE>