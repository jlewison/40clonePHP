<?php
$lang['page_title']	= 'Edit profile';
$lang['editprofilebasic_sex']					= 'Sex';
$lang['editprofilebasic_male']					= 'Male';
$lang['editprofilebasic_female']				= 'Female';
$lang['editprofilebasic_select_sex']			= 'Select Sex';
$lang['editprofilebasic_birthday']				= 'Birthday';
$lang['editprofilebasic_hometown']				= 'Hometown';
$lang['editprofilebasic_political_view']		= 'Political Views';
$lang['editprofilebasic_relegious_view']		= 'Religious Views';
$lang['editprofilebasic_interested_in']			= 'Interested in';
$lang['editprofilebasic_relationship_status']	= 'Relationship Status';
$lang['editprofilebasic_looking_for']			= 'Looking for';
$lang['editprofilebasic_success_msg']			= 'Basic profile details updated successfully!';
?>