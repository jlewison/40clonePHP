<?php
require_once ('../common/config.inc.php');
$CFG['lang']['include_files'][] = 'admin/includes/languages/%s/forumsResponses.php';
$CFG['lang']['include_files'][] = 'admin/includes/languages/%s/forumsResponseSearch.php';
$CFG['html']['header'] = 'admin/includes/languages/%s/html_header.php';
$CFG['html']['footer'] = 'admin/includes/languages/%s/html_footer.php';
$CFG['lang']['include_files'][] = 'common/configs/config_forums.inc.php';
$CFG['lang']['include_files'][] = 'common/languages/%s/lists_array/months_list_array.inc.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['mods']['include_files'][] = 'common/classes/class_ListRecordsHandler.lib.php';
$CFG['db']['is_use_db'] = true;
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class ForumResponseFormHandler extends ListRecordsHandler
{
		public $forum_details_arr;
		public $forum_topic_details_arr;
		public function buildConditionQuery($condition = '')
		{
				$this->sql_condition = $condition;
		}
		public function checkSortQuery($field, $sort = 'asc')
		{
				if (!($this->sql_sort))
				{
						$this->sql_sort = $field . ' ' . $sort;
				}
		}
		public function isValidForumId($forum_id, $err_tip = '')
		{
				$sql = 'SELECT forum_id, forum_title, forum_description, forum_status' . ' FROM ' . $this->CFG['db']['tbl']['forums'] . ' WHERE forum_id = ' . $this->dbObj->Param($forum_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($forum_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($this->forum_details_arr = $rs->FetchRow())
				{
						return true;
				}
				$this->setCommonErrorMsg($err_tip);
				return false;
		}
		public function isValidForumTopicId($forum_id, $topic_id, $err_tip = '')
		{
				$sql = 'SELECT g.topic_id, g.forum_id, g.forum_topic, g.user_id, DATE_FORMAT(g.date_added, \'' . $this->CFG['format']['date'] . '\') as date_added' . ', u.' . $this->getUserTableField('name') . ' AS name, u.' . $this->getUserTableField('image_path') . ' AS image_path, u.' . $this->getUserTableField('gender') . ' AS gender' . ' FROM ' . $this->CFG['db']['tbl']['forum_topics'] . ' AS g, ' . $this->CFG['db']['tbl']['users'] . ' AS u' . ' WHERE g.user_id = u.' . $this->getUserTableField('user_id') . ' AND topic_id = ' . $this->dbObj->Param($topic_id) . ' AND forum_id = ' . $this->dbObj->Param($forum_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($topic_id, $forum_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($this->forum_topic_details_arr = $rs->FetchRow())
				{
						return true;
				}
				$this->setCommonErrorMsg($err_tip);
				return false;
		}
		public function isValidForumResponseId($forums_response_table, $topic_id, $response_id, $err_tip = '')
		{
				$sql = 'SELECT response_id, topic_id, forum_response, response_user_id, response_status' . ' FROM ' . $this->CFG['db']['tbl']['forum_response'] . ' WHERE topic_id = ' . $this->dbObj->Param($topic_id) . ' AND response_id = ' . $this->dbObj->Param($response_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($topic_id, $response_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($row = $rs->FetchRow())
				{
						$this->setFormField('forum_response', $row['forum_response']);
						$this->setFormField('response_status', $row['response_status']);
						return true;
				}
				$this->setCommonErrorMsg($err_tip);
				return false;
		}
		public function activeResponse()
		{
				$response_ids = $this->fields_arr['response_ids'];
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['forum_response'] . ' SET response_status = \'Yes\'' . ' WHERE response_id IN (' . $response_ids . ')';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$this->updateTotalResponse();
				$this->updateForumsTable();
				return true;
		}
		public function inactiveResponse()
		{
				$response_ids = $this->fields_arr['response_ids'];
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['forum_response'] . ' SET response_status = \'No\'' . ' WHERE response_id IN (' . $response_ids . ') ';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$this->updateTotalResponse();
				$this->updateForumsTable();
				return true;
		}
		public function deleteResponse()
		{
				$response_ids = $this->fields_arr['response_ids'];
				$sql = 'DELETE FROM ' . $this->CFG['db']['tbl']['forum_response'] . ' WHERE response_id IN (' . $response_ids . ') ';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$this->updateTotalResponse();
				$this->updateForumsTable();
				return true;
		}
		public function updateTotalResponse()
		{
				$sql = 'SELECT count(response_id) AS total_response FROM ' . $this->CFG['db']['tbl']['forum_response'] . ' AS fr' . ' WHERE topic_id = ' . $this->dbObj->Param($this->fields_arr['topic_id']) . ' AND fr.response_status = \'Yes\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['topic_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = $rs->FetchRow();
				$total_response = $row['total_response'];
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['forum_topics'] . ' SET total_response = ' . $this->dbObj->Param($total_response) . ' WHERE topic_id = ' . $this->dbObj->Param($this->fields_arr['topic_id']);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($total_response, $this->fields_arr['topic_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return true;
		}
		public function updateForumsTable()
		{
				$sql = 'SELECT COUNT(topic_id) AS total_topic FROM ' . $this->CFG['db']['tbl']['forum_topics'] . ' WHERE forum_id = ' . $this->dbObj->Param($this->fields_arr['forum_id']) . ' AND topic_status = \'Yes\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['forum_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = $rs->FetchRow();
				$total_topic = $row['total_topic'];
				$sql = 'SELECT COUNT(response_id) AS total_response FROM ' . $this->CFG['db']['tbl']['forum_response'] . ' AS fr' . ', ' . $this->CFG['db']['tbl']['forum_topics'] . ' AS ft' . ' WHERE fr.topic_id = ft.topic_id AND forum_id = ' . $this->dbObj->Param($this->fields_arr['forum_id']) . ' AND topic_status = \'Yes\' AND fr.response_status = \'Yes\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['forum_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = $rs->FetchRow();
				$total_response = $row['total_response'];
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['forums'] . ' SET total_topics = ' . $this->dbObj->Param($total_topic) . ', total_response = ' . $this->dbObj->Param($total_response) . ' WHERE forum_id = ' . $this->dbObj->Param($this->fields_arr['forum_id']);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($total_topic, $total_response, $this->fields_arr['forum_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return true;
		}
		public function updateTotalResponseForums($forum_id)
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['forums'] . ' SET total_response = total_response - 1' . ' WHERE forum_id = ' . $this->dbObj->Param($forum_id) . ' AND total_response > 0';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($forum_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return true;
		}
		public function showForumDetails()
		{
?>
<div id="selShowGroupTitle">
	<h3>
		<a href="forumsTopics.php?forum_id=<?php echo $this->fields_arr['forum_id']; ?>"><?php echo $this->LANG['forums_back_topic']; ?></a>
	</h3>
	<p class="clsAlignRight" id="post"><a href="forumsResponseCreate.php?forum_id=<?php echo $this->fields_arr['forum_id']; ?>&topic_id=<?php echo $this->fields_arr['topic_id']; ?>"> <?php echo $this->LANG['forums_post_response']; ?> </a></p>
</div>
<?php
		}
		public function showForumResponse()
		{
				if ($this->forum_topic_details_arr)
				{
?>
				<tr>
				  <th colspan="5"> <!--<p> <?php echo wordWrapManual($this->forum_topic_details_arr['forum_topic'], 50); ?> </p>-->
				    <p><?php echo $this->LANG['forums_forum_topic_by'] . ' '; ?>
						<?php
						echo ($this->forum_topic_details_arr['name']);
?>
					<?php echo $this->LANG['forums_started_on'] . ' ' . $this->forum_topic_details_arr['date_added']; ?> </p></th>
				</tr>
				<tr>
					<th><input type="checkbox" class="clsCheckRadio" id="checkall" onclick="selectAll(this.form)" name="checkall" tabindex="<?php echo $this->getTabIndex(); ?>" /></th>
					<th><?php echo $this->LANG['forums_response_postedby']; ?></th>
					<th><?php echo $this->LANG['forums_response_date']; ?></th>
					<th><?php echo $this->LANG['forums_active']; ?></th>
					<th><?php echo $this->LANG['forums_edit']; ?></th>
				</tr>
				<?php
				}
				if (!$this->isResultsFound())
				{
?>
					<tr>
					  <td colspan="5">
					  	<div id="selMsgAlert">
							<?php echo $this->LANG['forums_no_responses']; ?>
						</div>
					  </td>
					</tr>
					<?php
						return;
				}
				while ($row = $this->fetchResultRecord())
				{
						$userDetails = $row;
						$userDetails['user_id'] = $row['response_user_id'];
?>
					<tr>
					 	<td class="clsAlignCenter"><input type="checkbox" class="clsCheckRadio" name="response_ids[]" onclick="disableHeading('selFormShowResponces');" value="<?php echo $row['response_id']; ?>" tabindex="<?php echo $this->getTabIndex(); ?>" <?php if ((is_array($this->fields_arr['response_ids'])) && (in_array($row['response_id'], $this->fields_arr['response_ids']))) echo "CHECKED"; ?>/></td>
					    <td>
					    	<?php if (chkUserImageAllowed())
						{ ?>
					    	<p id="selImageBorder">	<?php displayForumUserSmallImage($userDetails, false); ?></p>
					    	<?php } ?>
							<p><?php echo $userDetails['name']; ?></p>
						</td>
						<td>
							<?php echo $row['date_added']; ?>
						</td>
						<td>
							<?php echo $row['response_status']; ?>
						</td>
						<td class="clsLargeImage">
							<p>
						  	<?php
						$row['forum_response'] = str_replace('&lt;a href=&quot;', '&lt;a target=&quot;_blank&quot; href=&quot;', $row['forum_response']);
						echo nl2br(wordWrapManual($row['forum_response'], 50));
?>
							</p>
    						<p><a href="forumsResponseCreate.php?forum_id=<?php echo $this->fields_arr['forum_id']; ?>&topic_id=<?php echo $this->fields_arr['topic_id']; ?>&response_id=<?php echo $row['response_id']; ?>"><?php echo $this->LANG['forums_edit']; ?></a></p>
						</td>
					</tr>
					<?php
				}
				$anchor = 'dAltMlti';
?>
					<tr>
					<td colspan="5" class="<?php echo $this->getCSSFormFieldCellClass('action'); ?>">
						&nbsp;&nbsp;
						<select name="action" id="action" tabindex="<?php echo $this->getTabIndex(); ?>">
							<option value=""><?php echo $this->LANG['forums_select']; ?></option>
							<option value="Active" <?php if ($this->fields_arr['action'] == 'active') echo 'SELECTED'; ?> ><?php echo $this->LANG['forums_active']; ?></option>
							<option value="Inactive" <?php if ($this->fields_arr['action'] == 'inactive') echo 'SELECTED'; ?> ><?php echo $this->LANG['forums_inactive']; ?></option>
							<option value="Delete" <?php if ($this->fields_arr['action'] == 'delete') echo 'SELECTED'; ?> ><?php echo $this->LANG['forums_delete']; ?></option>
						</select>
						<a href="#" id="<?php echo $anchor; ?>"></a>
						<input type="button" class="clsSubmitButton" name="action_button" id="action_button" value="<?php echo $this->LANG['forums_action']; ?>" onClick="getMultiCheckBoxValue('selFormShowResponces', 'checkall', '<?php echo $this->LANG['forums_err_tip_select_responses']; ?>', 'dAltMlti');if(multiCheckValue!=''){getAction()}" />
						&nbsp;&nbsp;
					</td>
				</tr>
				<?php
		}
		public function updateGroupForumTopic($topic_id)
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['forum_topics'] . ' SET total_views = total_views + 1' . ' WHERE topic_id = ' . $this->dbObj->Param($topic_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($topic_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return true;
		}
		public function populateConditionOperators($highlight_operator)
		{
?>
				<option value="equalto" <?php if ($highlight_operator == 'equalto') echo 'SELECTED'; ?>><?php echo $this->LANG['responsesearch_equal_to'] ?></option>
				<option value="greaterthan" <?php if ($highlight_operator == 'greaterthan') echo 'SELECTED'; ?>><?php echo $this->LANG['responsesearch_greater_than'] ?></option>
				<option value="greaterthanequal" <?php if ($highlight_operator == 'greaterthanequal') echo 'SELECTED'; ?>><?php echo $this->LANG['responsesearch_greater_than_equal'] ?></option>
				<option value="lessthan" <?php if ($highlight_operator == 'lessthan') echo 'SELECTED'; ?>><?php echo $this->LANG['responsesearch_less_than'] ?></option>
				<option value="lessthanequal" <?php if ($highlight_operator == 'lessthanequal') echo 'SELECTED'; ?>><?php echo $this->LANG['responsesearch_less_than_equal'] ?></option>
				<option value="notequal" <?php if ($highlight_operator == 'notequal') echo 'SELECTED'; ?>><?php echo $this->LANG['responsesearch_not_equal'] ?></option>
			<?php
		}
		public function printQuery()
		{
				print 'Query:<br>' . $this->sql;
		}
}
$forums = new ForumResponseFormHandler();
$forums->setPageBlockNames(array('msg_form_error', 'msg_form_success', 'form_title', 'form_forum_title', 'form_search', 'form_show_responses', 'page_nav', 'form_confirm'));
$forums->setCSSAlternativeRowClasses($CFG['data_tbl']['css_alternative_row_classes']);
$forums->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$forums->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$forums->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$forums->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$forums->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$forums->setDBObject($db);
$forums->setCfgLangGlobal($CFG, $LANG);
$forums->setAllPageBlocksHide();
$forums->setFormField('id', '');
$forums->setFormField('forum_id', '');
$forums->setFormField('topic_id', '');
$forums->setFormField('response_id', '');
$forums->setFormField('response_ids', '');
$forums->setFormField('srch_response', '');
$forums->setFormField('srch_uname', '');
$forums->setFormField('srch_date_from', '');
$forums->setFormField('srch_date', '');
$forums->setFormField('srch_month', '');
$forums->setFormField('srch_year', '');
$forums->setFormField('srch_date_to', '');
$forums->setFormField('srch_todate', '');
$forums->setFormField('srch_tomonth', '');
$forums->setFormField('srch_toyear', '');
$forums->setFormField('action', '');
$forums->setFormField('queryStr', '');
$condition_operators = array('equalto', 'greaterthan', 'greaterthanequal', 'lessthan', 'lessthanequal', 'notequal');
$operators_arr = array('equalto' => "=", 'greaterthan' => ">", 'greaterthanequal' => ">=", 'lessthan' => "<", 'lessthanequal' => "<=", 'notequal' => "!=");
$forums->setMonthsListArr($LANG_LIST_ARR['months']);
$condition = '';
$forums->numpg = $CFG['data_tbl']['numpg'];
$forums->setFormField('start', 0);
$forums->setFormField('numpg', $CFG['data_tbl']['numpg']);
$forums->setMinRecordSelectLimit($CFG['data_tbl']['min_record_select_limit']);
$forums->setMaxRecordSelectLimit($CFG['data_tbl']['max_record_select_limit']);
$forums->setNumPerPageListArr($CFG['data_tbl']['numperpage_list_arr']);
$forums->setTableNames(array());
$forums->setReturnColumns(array());
$forums->sanitizeFormInputs($_REQUEST);
if ($forums->isFormGETed($_REQUEST, 'forum_id') && $forums->isFormGETed($_REQUEST, 'topic_id'))
{
		$forums->chkIsNotEmpty('forum_id', $LANG['forums_err_tip_compulsory']) and $forums->chkIsNumeric('forum_id', $LANG['forums_err_tip_compulsory']) and $forums->isValidForumId($forums->getFormField('forum_id'), $LANG['forums_err_tip_invalid_forum_id']) and $forums->chkIsNotEmpty('topic_id', $LANG['forums_err_tip_compulsory']) and $forums->chkIsNumeric('topic_id', $LANG['forums_err_tip_compulsory']) and $forums->isValidForumTopicId($forums->getFormField('forum_id'), $forums->getFormField('topic_id'), $LANG['forums_err_tip_invalid_forum_topic_id']);
}
else
{
		Redirect2URL('forums.php');
}
if ($forums->isValidFormInputs())
{
		if ($forums->isFormPOSTed($_POST, 'forums_confirm'))
		{
				$forums->chkIsNotEmpty('response_ids', $LANG['forums_err_tip_compulsory']) or $forums->setCommonErrorMsg($LANG['forums_err_tip_select_responses']);
				$forums->chkIsNotEmpty('action', $LANG['forums_err_tip_compulsory']) or $forums->setCommonErrorMsg($LANG['forums_err_tip_select_action']);
				if ($forums->isValidFormInputs())
				{
						switch ($forums->getFormField('action'))
						{
								case 'Delete':
										$forums->deleteResponse();
										$success_msg = $LANG['forums_success_delete_message'];
										break;
								case 'Active':
										$forums->activeResponse();
										$success_msg = $LANG['forums_success_active_message'];
										break;
								case 'Inactive':
										$forums->inactiveResponse();
										$success_msg = $LANG['forums_success_inactive_message'];
										break;
						}
						$forums->setFormField('response_ids', array());
				}
				if ($forums->isValidFormInputs())
				{
						$forums->setPageBlockShow('msg_form_success');
				}
				else
				{
						$forums->setPageBlockShow('msg_form_error');
				}
		}
		if ($forums->isFormPOSTed($_POST, 'forums_cancel'))
		{
				$forums->setFormField('response_ids', array());
		}
		if ($forums->getFormField('srch_date') || $forums->getFormField('srch_month') || $forums->getFormField('srch_year'))
		{
				$forums->chkIsCorrectDate($forums->getFormField('srch_date'), $forums->getFormField('srch_month'), $forums->getFormField('srch_year'), 'srch_date_from', $LANG['forums_err_tip_date_empty'], $LANG['forums_err_tip_date_invalid']);
		}
		if ($forums->getFormField('srch_todate') || $forums->getFormField('srch_tomonth') || $forums->getFormField('srch_toyear'))
		{
				$forums->chkIsCorrectDate($forums->getFormField('srch_todate'), $forums->getFormField('srch_tomonth'), $forums->getFormField('srch_toyear'), 'srch_date_to', $LANG['forums_err_tip_date_empty'], $LANG['forums_err_tip_date_invalid']);
		}
		if ($forums->getFormField('srch_date_from') && $forums->getFormField('srch_date_to'))
		{
				$from_date = explode('-', $forums->getFormField('srch_date_from'));
				$from_date = mktime(0, 0, 0, $from_date[1], $from_date[2], $from_date[0]);
				$to_date = explode('-', $forums->getFormField('srch_date_to'));
				$to_date = mktime(0, 0, 0, $to_date[1], $to_date[2], $to_date[0]);
				if ($to_date < $from_date)
				{
						$forums->setCommonErrorMsg($LANG['forums_err_tip_enter_correct_dates']);
						$forums->setPageBlockShow('msg_form_error');
				}
		}
		$search_condition = '';
		$searchArr = array();
		$searchArr[] = 'forum_id';
		$searchArr[] = 'topic_id';
		$queryStr = '';
		if ($forums->isValidFormInputs())
		{
				if ($forums->getFormField('srch_response'))
				{
						$search_condition .= ' gr.forum_response LIKE \'%' . addslashes($forums->getFormField('srch_response')) . '%\' AND ';
						$searchArr[] = 'srch_response';
						$queryStr .= '&srch_response=' . $forums->getFormField('srch_response');
				}
				if ($forums->getFormField('srch_uname'))
				{
						$search_condition .= 'u.' . $forums->getUserTableField('name') . ' like \'%' . addslashes($forums->getFormField('srch_uname')) . '%\' AND ';
						$searchArr[] = 'srch_uname';
						$queryStr .= '&srch_uname=' . $forums->getFormField('srch_uname');
				}
				if ($forums->getFormField('srch_date_from') && $forums->getFormField('srch_date_to'))
				{
						$search_condition .= ' gr.date_added BETWEEN \'' . $forums->getFormField('srch_date_from') . ' 00:00:00\' AND ';
						$search_condition .= ' \'' . $forums->getFormField('srch_date_to') . ' 23:59:59\' AND ';
						$searchArr[] = 'srch_date';
						$queryStr .= '&srch_date=' . $forums->getFormField('srch_date');
						$searchArr[] = 'srch_month';
						$queryStr .= '&srch_month=' . $forums->getFormField('srch_month');
						$searchArr[] = 'srch_year';
						$queryStr .= '&srch_year=' . $forums->getFormField('srch_year');
						$searchArr[] = 'srch_todate';
						$queryStr .= '&srch_todate=' . $forums->getFormField('srch_todate');
						$searchArr[] = 'srch_tomonth';
						$queryStr .= '&srch_tomonth=' . $forums->getFormField('srch_tomonth');
						$searchArr[] = 'srch_toyear';
						$queryStr .= '&srch_toyear=' . $forums->getFormField('srch_toyear');
				}
				$forums->setFormField('queryStr', $queryStr);
		}
		else
		{
				$forums->setPageBlockShow('msg_form_error');
		}
		$forums->updateGroupForumTopic($forums->getFormField('topic_id'));
		$forums->setTableNames(array($CFG['db']['tbl']['forum_response'] . ' as gr', $CFG['db']['tbl']['users'] . ' as u'));
		$forums->setReturnColumns(array('gr.response_id', 'gr.topic_id', 'gr.forum_response', 'gr.response_status', 'gr.response_user_id', 'DATE_FORMAT(gr.date_added, \'' . $CFG['format']['date'] . '\') as date_added', 'u.' . $forums->getUserTableField('name') . ' AS name', 'u.' . $forums->getUserTableField('image_path') . ' AS image_path', 'u.' . $forums->getUserTableField('gender') . ' AS gender', 'u.' . $forums->getUserTableField('user_id') . ' AS img_user_id', 'u.' . $forums->getUserTableField('t_height') . ' AS t_height', 'u.' . $forums->getUserTableField('t_width') . ' AS t_width', 'u.' . $forums->getUserTableField('s_height') . ' AS s_height', 'u.' . $forums->getUserTableField('s_width') . ' AS s_width', 'u.' . $forums->getUserTableField('photo_server_url') . ' AS photo_server_url', 'u.' . $forums->getUserTableField('photo_ext') . ' AS photo_ext'));
		$search_condition .= 'gr.response_user_id = u.' . $forums->getUserTableField('user_id') . ' AND gr.topic_id = \'' . $forums->getFormField('topic_id') . '\' AND ';
		if ($CFG['admin']['ignore_user'])
		{
				$search_condition .= ' NOT EXISTS (SELECT 1 FROM ' . $CFG['db']['tbl']['user_ignored'] . ' AS ui WHERE ui.user_id=' . $CFG['user']['user_id'] . ' AND ui.ignored_id=gr.response_user_id)';
		}
		$forums->buildSelectQuery();
		$forums->buildConditionQuery($search_condition);
		$forums->buildSortQuery();
		$forums->checkSortQuery('gr.date_added', 'DESC');
		$forums->buildQuery();
		$forums->executeQuery();
		$forums->setPageBlockShow('form_forum_title');
		$forums->setPageBlockShow('form_show_responses');
		$forums->setPageBlockShow('form_search');
		if ($forums->isResultsFound())
		{
				$forums->setPageBlockShow('page_nav');
		}
		if ($forums->getFormField('response_id'))
		{
				$forums->setPageBlockShow('form_confirm');
		}
}
else
{
		$forums->setPageBlockShow('msg_form_error');
		Redirect2URL('forums.php');
}




?>
<script language="javascript">
	var block_arr= new Array('selMsgConfirm');
	var replace_url = '<?php echo $CFG['site']['url']; ?>login.php';
	var please_select_action = '<?php echo $LANG['forums_err_tip_select_action']; ?>';
	var confirm_message = '';
	function getAction()
		{
			var act_value = document.selFormShowResponces.action.value;
			if(act_value)
				{
					switch (act_value)
						{
							case 'Delete':
								confirm_message = '<?php echo $LANG['forums_delete_confirm_message']; ?>';
								break;
							case 'Active':
								confirm_message = '<?php echo $LANG['forums_active_confirm_message']; ?>';
								break;
							case 'Inactive':
								confirm_message = '<?php echo $LANG['forums_inactive_confirm_message']; ?>';
								break;
						}
					$('confirmMessage').innerHTML = confirm_message;
					document.msgConfirmform.action.value = act_value;
					Confirmation('dAltMlti', 'selMsgConfirm', 'msgConfirmform', Array('response_ids'), Array(multiCheckValue), Array('value'), -25, -290, 'selFormShowResponces');
				}
				else
					alert_manual(please_select_action, 'dAltMlti');
		}
</script>
<div id="selForumResponseListAll" class="clsForums">
  <h2 class="clsForumResponseTitle"><span>
		<a href="forums.php"><?php echo $LANG['forums_title_index']; ?></a>
		&nbsp;-&nbsp;
		<a href="forumsTopics.php?forum_id=<?php echo $forums->getFormField('forum_id'); ?>">
			<?php echo $forums->forum_details_arr['forum_title']; ?></a>
		&nbsp;-&nbsp;
		<?php echo wordWrapManual($forums->forum_topic_details_arr['forum_topic'], 50); ?>
	</span></h2>
	<div id="selMsgConfirm" class="clsPopupConfirmation" style="display:none;position:absolute;">
		<p id="confirmMessage"></p>
		<form name="msgConfirmform" id="msgConfirmform" method="post" action="<?php echo URL($_SERVER['PHP_SELF']); ?>" autocomplete="off">
			<table summary="<?php echo $LANG['forums_confirm_tbl_summary']; ?>">
				<tr>
					<td>
						<?php $forums->populateHidden(array('start', 'forum_id', 'topic_id', 'response_id', 'srch_response', 'srch_uname', 'srch_date', 'srch_month', 'srch_year', 'srch_todate', 'srch_tomonth', 'srch_toyear')); ?>
						<input type="submit" class="clsSubmitButton" name="forums_confirm" id="forums_confirm" tabindex="<?php echo $forums->getTabIndex(); ?>" value="<?php echo $LANG['forums_confirm']; ?>" />
						&nbsp;
						<input type="button" class="clsCancelButton" name="forums_cancel" id="forums_cancel" tabindex="<?php echo $forums->getTabIndex(); ?>" value="<?php echo $LANG['forums_cancel']; ?>"  onClick="return hideAllBlocks('selFormShowResponces');" />
						<input type="hidden" name="response_ids" id="response_ids" />
						<input type="hidden" name="action" id="action" />
					</td>
				</tr>
			</table>
		</form>
  	</div>
    <div id="selLeftNavigation">
  <?php
if ($forums->isShowPageBlock('msg_form_error'))
{
?>
  <div id="selMsgError">
    <p><?php echo $LANG['msg_error_sorry']; ?> <?php echo $forums->getCommonErrorMsg(); ?></p>
  </div>
  <?php
}
if ($forums->isShowPageBlock('msg_form_success'))
{
?>
  <div id="selMsgSuccess">
    <p><?php echo $success_msg; ?></p>
  </div>
  <?php
}
if ($forums->isShowPageBlock('form_forum_title'))
{
}
if ($forums->isShowPageBlock('form_search'))
{
?>
		<div id="selShowSearch">
		<form name="form_search" id="selFormSearch" method="post" action="<?php echo URL($_SERVER['PHP_SELF']); ?>">
			<table cellspacing="0" summary="<?php echo $LANG['responsesearch_tbl_summary']; ?>">
				<tr>
					<td class="<?php echo $forums->getCSSFormLabelCellClass('srch_response'); ?>"><label for="srch_response"><?php echo $LANG['responsesearch_search_response']; ?></label></td>
					<td class="<?php echo $forums->getCSSFormFieldCellClass('srch_response'); ?>"><input type="text" class="clsTextBox" name="srch_response" id="srch_response" value="<?php echo $forums->getFormField('srch_response'); ?>" tabindex="<?php echo $forums->getTabIndex(); ?>"/></td>
				</tr>
				<tr>
					<td class="<?php echo $forums->getCSSFormLabelCellClass('srch_uname'); ?>"><label for="srch_uname"><?php echo $LANG['responsesearch_search_uname']; ?></label></td>
					<td class="<?php echo $forums->getCSSFormFieldCellClass('srch_uname'); ?>"><input type="text" class="clsTextBox" name="srch_uname" id="srch_uname" value="<?php echo $forums->getFormField('srch_uname'); ?>" tabindex="<?php echo $forums->getTabIndex(); ?>"/></td>
				</tr>
				<tr>
					<td class="<?php echo $forums->getCSSFormLabelCellClass('srch_date_from'); ?>"><label for="srch_date"><?php echo $LANG['responsesearch_search_date_created_from']; ?></label></td>
					<td class="<?php echo $forums->getCSSFormFieldCellClass('srch_date_from'); ?>"><?php echo $forums->getFormFieldErrorTip('srch_date_from'); ?>
						<select name="srch_date" id="srch_date" tabindex="<?php echo $forums->getTabIndex(); ?>">
							<option value=""><?php echo $LANG['responsesearch_search_date']; ?></option>
							<?php $forums->populateBWNumbers(1, 31, $forums->getFormField('srch_date')); ?>
						</select>
						<select name="srch_month" id="srch_month" tabindex="<?php echo $forums->getTabIndex(); ?>">
							<option value=""><?php echo $LANG['responsesearch_search_month']; ?></option>
							<?php $forums->populateMonthsList($forums->getFormField('srch_month')); ?>
						</select>
						<select name="srch_year" id="srch_year" tabindex="<?php echo $forums->getTabIndex(); ?>">
							<option value=""><?php echo $LANG['responsesearch_search_year']; ?></option>
							<?php $forums->populateBWNumbers(1920, date("Y"), $forums->getFormField('srch_year')); ?>
						</select>
					</td>
				</tr>
				<tr>
					<td class="<?php echo $forums->getCSSFormLabelCellClass('srch_date_to'); ?>"><label for="srch_date"><?php echo $LANG['responsesearch_search_date_created_to']; ?></label></td>
					<td class="<?php echo $forums->getCSSFormFieldCellClass('srch_date_to'); ?>"><?php echo $forums->getFormFieldErrorTip('srch_date_to'); ?>
						<select name="srch_todate" id="srch_todate" tabindex="<?php echo $forums->getTabIndex(); ?>">
							<option value=""><?php echo $LANG['responsesearch_search_date']; ?></option>
							<?php $forums->populateBWNumbers(1, 31, $forums->getFormField('srch_todate')); ?>
						</select>
						<select name="srch_tomonth" id="srch_tomonth" tabindex="<?php echo $forums->getTabIndex(); ?>">
							<option value=""><?php echo $LANG['responsesearch_search_month']; ?></option>
							<?php $forums->populateMonthsList($forums->getFormField('srch_tomonth')); ?>
						</select>
						<select name="srch_toyear" id="srch_toyear" tabindex="<?php echo $forums->getTabIndex(); ?>">
							<option value=""><?php echo $LANG['responsesearch_search_year']; ?></option>
							<?php $forums->populateBWNumbers(1920, date("Y"), $forums->getFormField('srch_toyear')); ?>
						</select>
					</td>
				</tr>
				<tr>
                <td>&nbsp;</td>
					<td class="<?php echo $forums->getCSSFormFieldCellClass('responsesearch_search'); ?>"><input type="submit" class="clsSubmitButton" value="<?php echo $LANG['responsesearch_search']; ?>" id="responsesearch_search" name="responsesearch_search" tabindex="<?php echo $forums->getTabIndex(); ?>"/></td>
				</tr>
			</table>
			<input type="hidden" name="forum_id" value="<?php echo $forums->getFormField('forum_id'); ?>" />
			<input type="hidden" name="topic_id" value="<?php echo $forums->getFormField('topic_id'); ?>" />
		  </form>
		</div>
      <?php
}
?>
  <form name="selFormShowResponces" id="selFormShowResponces" method="post" action="<?php echo URL($_SERVER['PHP_SELF']); ?>" autocomplete="off">
<?php
if ($forums->isShowPageBlock('page_nav') && $CFG['admin']['navigation']['top'])
{
		$forums->populatePageLinks($forums->getFormField('start'), $searchArr);
}
if ($forums->isShowPageBlock('form_show_responses'))
{
?>
    <table cellspacing="0" summary="<?php echo $LANG['forums_tbl_summary']; ?>" class="clsDataTable">
      <?php $forums->showForumResponse(); ?>
    </table>
  <?php
}
if ($forums->isShowPageBlock('page_nav') && $CFG['admin']['navigation']['bottom'])
{
		$forums->populatePageLinks($forums->getFormField('start'), $searchArr);
}
$forums->populateHidden(array('forum_id', 'topic_id', 'response_id', 'srch_response', 'srch_uname', 'srch_date', 'srch_month', 'srch_year', 'srch_todate', 'srch_tomonth', 'srch_toyear'));
?>
	</form>
  </div>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>
