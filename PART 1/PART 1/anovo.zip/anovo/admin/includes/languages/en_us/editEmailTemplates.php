<?php

$LANG['edit_email_templates_success_message'] = 'Updated sucessfully';
$LANG['edit_email_templates_tbl_summary'] = 'table to show the config values';
$LANG['edit_email_templates_submit'] = 'Update';
$LANG['edit_email_templates_title'] = 'Edit Email Templates';
$LANG['edit_email_templates_special_code_title'] = 'Special codes for email body';
?>