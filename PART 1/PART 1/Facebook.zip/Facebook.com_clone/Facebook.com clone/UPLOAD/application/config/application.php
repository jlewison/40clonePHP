<?php

/*
|--------------------------------------------------------------------------
| Default Language Code
|--------------------------------------------------------------------------
|
| This determines which set of language files should be used. Make sure
| there is an available translation if you intend to use something other
| than english.
|
*/
$config['language_code']	= "en";

/*
|--------------------------------------------------------------------------
| Layout
|--------------------------------------------------------------------------
| The place where we have to look up the template files.
|
*/
$config['layout'] 		= 'default';

/*
|--------------------------------------------------------------------------
| Date Format
|--------------------------------------------------------------------------
| The date format which has to be user throught the application.
|
*/
$config['date_format_short']	= 'F dS Y';			//December 9th 1998
$config['date_format_long']		= 'l, F d, Y';		//Wednesday, December 12, 2007
$config['date_format_medium']	= 'F d, Y';			//January 3, 1979
$config['date_format_full']		= 'g:i a F M j Y';	//11:32am Friday, Nov 16
$config['date_format_general']	= 'Y-m-d H:i:s';	//2007-12-17 12:16:23

/*
|--------------------------------------------------------------------------
| Date Format for database
|--------------------------------------------------------------------------
| The date format for database which has to be user throught the application.
|
*/
$config['db_date_format_short']		= '%M %D %Y';			//December 9th 1998
$config['db_date_format_long']		= '%W, %M %d, %Y';		//Wednesday, December 12, 2007
$config['db_date_format_medium']	= '%M %d, %Y';			//January 3, 1979
$config['db_date_format_full']		= '%r %W, %b %d %Y';	//11:32am Friday, Nov 16
$config['db_date_format_general']	= '%Y-%m-%d %H:%i:%s';	//2007-12-17 12:16:23

/*
|--------------------------------------------------------------------------
| Avatar property
|--------------------------------------------------------------------------
| The avatar image width and height settings
|
*/
$config['avatar_thumb_width']		= '50';
$config['avatar_thumb_height']		= '50';
$config['avatar_medium_width']		= '200';
$config['avatar_medium_height']		= '150';

?>