<?php //00461
// Copyright Notice
// Web Site URL:  http://www.zeeways.com
// Script Owner eMail: mail@zeeways.com
// Date: April, 2007
// Script Name: Zeeways Auction Website PHP Script
// Copyright Details: This script is not free.  Do not Remove this Copy Right notice.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the site administrator.');exit(199);
?>
4+oV58iVR36QvbG7Twlv4bEb1Eh+lE++q7yxOeciG1BA9i3is3ORsVO/E5CqkvyRzAkoMz6PJKd6
kYcblfEcDdHdB69jafT1g8o0g8a4RLFoGAsidlLZw4Fs/LTMKAgF5MX6Dxd4yEh0ao3QUvwwsJ10
wfm8FK6vlwXaiddGX1xLJenZomE3x7HVytOgbyygoUmHWUIwVkNs7Unc/+lE3n2zUVfmXQKk36eD
0W8v70866tB8QJkwwxiTbgOq34npzoskINwscd0HWpPaf02MfHHxhSpxgfov+/y+JcYsLbu5IYCH
PNS6uMacSbW9QOM2XRy1zS8PxjD7D38z+fw6i6PEFznQumgvl+0pyAC6KGJKc1LIhXvFl42TN0m+
mmapWQnwI6MKeP/8Qvvx4x2M0o1+xSSxjOXXS7sUdJ+D7KOHKML94F0cJiJ/bHakSfJTHS59zTi3
MCl3m+aTKYI8ftqkIHwqvxLtCmUbppvXOb5CFYM4EY7gepK4scvKalYSS2TBuRQsL8yoPkVmVYo5
afR4HNgfr1f0nfrfEQJ4LcIZ3jXEQqnfOFes+RS/1REJKAntlqBliTVG02ETo+GmBOa1WKMpDIGO
xS2Q6uMdCOkZ/IGbxeuLYmdeBhkOcKolikQFaSDevdkNZ9UXt+N1MEZeWLosaCQIYtJBH0ybeXv1
cFhHNhnKRDkZZtIbmie7sgm+svIdS1D2vPLEWrBAJ0O+R7kjGFxspAmVuFBNVtDC51QjrBDzW8OZ
B9qZfNmBPHwTP9+2WUeF3bxffvJoTYpOU7cMhdMYk5/CypH0L6a/qEv7JdDiEqc6May5/pJOtwWL
Oy4E8tpX2R9174xgmr3cGu1LzONBL0t9hlPeD8mEMpY25LHBRow9DxszZr2HRGSrN0YCpIBNmN9a
0sSL+uvZOA88tb2Ae8UykZi6bcNdoD3pVHPwr+bzRvj22mC6SS2B7XmIOzonQvBnCiXN+G5NaQcx
PHDC7Qr+DXZPCamIe5V+qmzdjxZDKCS0zKXWNptBMTZtPKUJ9Ii3xurrCoT/3FD7GJMnr1dMkL3F
XCPGHoqCxCvTL/VX6w9IwKNH0ZhDVQ53nYFRnQ1UMxaYrb7k8nkYGmS5YkocEARTTZ1suy8CVla9
f0CeM3HERNCvy5BozC7Lq4U8rWLmRcPFquMUzDOoLW6Y0aRKFItoqbym48PlO/nKq0XdjArExUH8
rELjuUsWRgeVKxSe