<?php

   class poll_questionData extends Data {

      var $table = POLL_QUESTION_TABLE;

      var $config = array (
  'table' => POLL_QUESTION_TABLE,
  'idField' => 'osdate_poll_question_id',
  'addedMsg' => 'Osdate Poll Question %s Added',
  'added_err' => 'Can\\\'t Add Osdate Poll Question',
  'editMsg' => 'Osdate Poll Question %s Updated',
  'editErr' => 'Can\\\'t Update Osdate Poll Question',
  'delErr' => 'Can\\\'t Delete Osdate Poll Question',
  'delMsg' => 'Osdate Poll Question %s Deleted',
  'blankErr' => 'Osdate Poll Question Empty',
  'fields' => 
  array (
    'id' => 
    array (
      'name' => 'id',
      'description' => 'Id',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'userid' => 
    array (
      'name' => 'userid',
      'description' => 'Userid',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'question' => 
    array (
      'name' => 'question',
      'description' => 'Question',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 255,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'active' => 
    array (
      'name' => 'active',
      'description' => 'Active',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 1,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
  ),
);   

      function poll_questionData() {
      
         $this->Data($this->config);
      }
   }

?>
