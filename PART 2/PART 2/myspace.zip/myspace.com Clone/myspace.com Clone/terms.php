<?
show_header(); 
global $site_name; 
$name2 = $site_name;
?>
<table width=100% class=body>
<tr><td class='lined padded-6'><b><span class="text1">Terms 
  of Service </span></b><br>
  <br>
  	<span class="text1">Edit this page with your favorite html editor by opening 
	up the file terms.php and enter in your terms of use. Save your changes and 
	upload it again over right this current file to display your changes 
	immediately.</span></td></table>
<? show_footer(); ?>