<?php
	$module_info['name'] = 'Captcha';
	$module_info['desc'] = 'Captcha system';
	$module_info['version'] = 0.7;
	//$module_info['db_add_field'][]=array(table_prefix . 'links', 'akismet', 'TINYINT',  3, "UNSIGNED", 0, '0');
?>

