<?php
/**
 * Change password Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 02/01/2008
 */
class ChangePassword extends Controller
{
		function ChangePassword()
		{
				parent::Controller();
				//check login
				if ($this->session->userdata('admin_logged_in') != 1 && $this->session->userdata('admin_id') == '') redirect('admin/login');
				//Load the language file
				$this->lang->load('admin/changePassword', $this->config->item('language_code'));
		}
		function index()
		{
				$this->load->model('usermodel');
				$this->load->library('validation');
				$this->changePasswordFrmRules();
				/* Validation */
				if ($this->validation->run() == false) $outputData['validationError'] = trim($this->validation->error_string);
				else
				{
						$new_password = $this->usermodel->chkAdminPassword($_POST['old_password']);
						if ($new_password)
						{
								$this->usermodel->updateAdminPassword($_POST['new_password']);
								//Set the flash data
								$this->session->set_flashdata('successMsg', $this->lang->line('changepassword_success_msg'));
								redirect('admin/changePassword');
						}
						else  $outputData['validationError'] = $this->lang->line('changepassword_error_msg');
				}
				$this->smartyextended->view('../admin/changePassword', $outputData);
		}
		function changePasswordFrmRules()
		{
				$rules['old_password'] = 'trim|required';
				$rules['new_password'] = 'trim|required|matches[confirm_password]';
				$rules['confirm_password'] = 'trim|required';
				$fields['old_password'] = $this->lang->line('changepassword_old_password');
				$fields['new_password'] = $this->lang->line('changepassword_new_password');
				$fields['confirm_password'] = $this->lang->line('changepassword_confirm_password');
				$this->validation->set_rules($rules);
				$this->validation->set_fields($fields);
		}
}
?>