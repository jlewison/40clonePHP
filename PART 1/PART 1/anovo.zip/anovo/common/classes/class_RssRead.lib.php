<?php
define("VERSION_MAJOR", 1);
define("VERSION_MINOR", 6);
class RSSread
{
		public $rssFeed = "http://roganty.jubiiblog.co.uk/syndication.php?action=article";
		public $numPosts = 3;
		public $whichOne = "s";
		public $numSentences = 3;
		public $numWords = 40;
		public $numChars = 200;
		public $stripLinks = false;
		public $postLinkTarget = "_blank";
		public $outputFormat = "<div id=\"selFeed\"><h4>[link,target=_blank][title][/link]</h4>\r\n[post]\r\n\r\n[postedAt] ([pubDate])</div><p>&nbsp;</p>";
		public $joinOutputBy = "";
		public $ScriptErrorCodes = array(1 => "Configuration of script output is unsupported", 2 => "Variable cannot be set", 4 => "A [post] tag has not been defined", 8 => "Unable to load RSS", 16 => "Not an RSS document", 32 => "RSS version not Supported", 64 => "RSS document does not contain a &lt;description /&gt; tag", 128 => "Unforseen option", 256 => "No headlines available");
		public $errCode = 0;
		public $RSSparser;
		public $rssVersion = 2.0;
		public $rssInfo = array();
		public $rssData = array();
		public $curID = -1;
		public $inChannel = false;
		public $inItem = false;
		public $isTitle = false;
		public $isLink = false;
		public $isDesc = false;
		public $isDate = false;
		public $display = true;
		public function RSSread($confOutput = false)
		{
				$this->confOutput = $confOutput;
				$this->RSSreadVersion = VERSION_MAJOR . "." . VERSION_MINOR;
		}
		public function ScriptConfig($RSSconf)
		{
				if ($this->confOutput)
				{
						$changeableVars = "rssFeed|numPosts|whichOne|numSentences|numWords|numChars|stripLinks|postLinkTarget|outputFormat|joinOutputBy";
						foreach ($RSSconf as $key => $val)
						{
								if ((strpos($changeableVars, $key)) === false)
								{
										$this->errError(2);
								}
								else  $this->$key = stripslashes($val);
						}
				}
				if (!$this->confOutput)
				{
						$this->confOutput = false;
						$this->errError(1);
				}
		}
		public function RSSoutput()
		{
				if ((strpos($this->outputFormat, "[post]")) === false) $this->errError(4);
				$this->rssData = array();
				$this->curID = -1;
				$gotPosts = $this->getPosts();
				if (!$gotPosts) $this->errError(128);
				if ($this->display)
				{
						$this->formatPosts();
						$outputPosts = $this->formatOutput($this->rssData);
						$outputString = implode($this->joinOutputBy . "\r\n", $outputPosts);
						return $outputString;
				}
				$this->display = true;
		}
		public function getPosts()
		{
				$numPosts = $this->numPosts;
				$this->loadXML();
				if (count($this->rssData) == 0) $this->errError(256);
				if ($numPosts == -1)
				{
						foreach ($this->rssData as $val)
								if (!isset($val["description"])) $val["description"] = '';
						return true;
				}
				else
				{
						$tmpArr = array();
						for ($i = 0; $i < $numPosts; $i++)
						{
								if (!isset($this->rssData[$i]["description"]))
								{
										$this->rssData[$i]["description"] = '';
								}
								$tmpArr[] = $this->rssData[$i];
						}
						$this->rssData = array();
						foreach ($tmpArr as $val) $this->rssData[] = $val;
						return true;
				}
				return false;
		}
		public function formatPosts()
		{
				$whichOne = $this->whichOne;
				switch ($whichOne)
				{
						case "s":
								$postLength = $this->numSentences;
								break;
						case "w":
								$postLength = $this->numWords;
								break;
						case "c":
								$postLength = $this->numChars;
								break;
						case "n":
								$postLength = -1;
								break;
				}
				$stripLinks = $this->stripLinks;
				$postLinkTarget = $this->postLinkTarget;
				$tmpPosts = array();
				foreach ($this->rssData as $val) $tmpPosts[] = isset($val["description"]) ? $val["description"] : '';
				$tmpPosts = str_replace("<li>", "\r\n* ", $tmpPosts);
				$tmpPosts = str_replace(array("<br>", "<br />", "<br/>"), "\r\n", $tmpPosts);
				$tmpPosts = str_replace("<p>", "\r\n\r\n", $tmpPosts);
				for ($i = 0; $i < count($tmpPosts); $i++) $tmpPosts[$i] = ($stripLinks) ? strip_tags($tmpPosts[$i]) : strip_tags($tmpPosts[$i], "<a>");
				if (!$stripLinks) $tmpPosts = $this->RemoveLinks($tmpPosts);
				if ($whichOne != "n")
						for ($i = 0; $i < count($tmpPosts); $i++) $tmpPosts[$i] = $this->shortenPost($tmpPosts[$i], $whichOne, $postLength);
				if (!$stripLinks) $tmpPosts = $this->AddLinks($tmpPosts);
				if ($postLength == 0)
						for ($i = 0; $i < count($tmpPosts); $i++) $this->rssData[$i]["description"] = '';
						else
								for ($i = 0; $i < count($tmpPosts); $i++) $this->rssData[$i]["description"] = $tmpPosts[$i];
				return true;
		}
		public function formatOutput($arrPosts)
		{
				$outputFormat = $this->outputFormat;
				preg_match_all("/\[(\/link|link|link\,(.*?))\]/i", $outputFormat, $link_matches, PREG_SET_ORDER | PREG_OFFSET_CAPTURE);
				$gotLinkMatches = (!empty($link_matches)) ? true : false;
				$outputPosts = array();
				if ($gotLinkMatches)
				{
						$linkStartTagLength = ($gotLinkMatches) ? strlen($link_matches[0][0][0]) : 0;
						$linkStartTagPos = ($gotLinkMatches) ? $link_matches[0][0][1] : 0;
						$linkEndTagLength = ($gotLinkMatches) ? strlen($link_matches[1][0][0]) : 0;
						$linkEndTagPos = ($gotLinkMatches) ? $link_matches[1][0][1] : 0;
						if (count($link_matches[0]) == 3)
						{
								list($null, $target) = explode("=", $link_matches[0][2][0]);
								$target = " target=\"" . $target . "\"";
						}
				}
				foreach ($arrPosts as $val)
				{
						$numPos2Rem = 0;
						$numPrevPos = 0;
						$tmpStr = $outputFormat;
						$tmpstrLen = strlen($outputFormat);
						$val_link = (isset($val["link"])) ? $val["link"] : $this->rssInfo["link"];
						$val_title = (isset($val["title"])) ? $val["title"] : $this->rssInfo["title"];
						if (!isset($val["pubDate"])) continue;
						$val_pubdate = (isset($val["pubDate"])) ? $val["pubDate"] : $this->rssInfo["pubDate"];
						if ($gotLinkMatches)
						{
								$strLinkStart = "<a href=\"" . $val_link . "\"";
								$strLinkStart .= (isset($target)) ? $target : "";
								$strLinkStart .= ">";
								$numPrevPos = ($linkStartTagPos - $numPos2Rem);
								$numPos2Rem += (strlen($strLinkStart) - $linkStartTagLength);
								$tmpStr = substr_replace($tmpStr, $strLinkStart, $linkStartTagPos, $linkStartTagLength);
								$strLinkEnd = "</a>";
								$numPrevPos = ($numPos2Rem + $linkEndTagPos);
								$numPos2Rem += (strlen($strLinkEnd) - $linkEndTagLength);
								$tmpStr = substr_replace($tmpStr, $strLinkEnd, $numPrevPos, $linkEndTagLength);
						}
						if (($pos = strpos($tmpStr, "[title]")) !== false)
						{
								$tit = substr($val_title, 0, strrpos($val_title, "("));
								$at = substr($val_title, strrpos($val_title, "(") + 1, (strrpos($val_title, ")") - strrpos($val_title, "(")) - 1);
								$tmpStr = substr_replace($tmpStr, $tit, $pos, 7);
								if (($pos = strpos($tmpStr, "[postedAt]")) !== false) $tmpStr = substr_replace($tmpStr, $at, $pos, 10);
						}
						if (($pos = strpos($tmpStr, "[pubDate]")) !== false) $tmpStr = substr_replace($tmpStr, $val_pubdate, $pos, 9);
						if (($pos = strpos($tmpStr, "[post]")) !== false)
						{
								$val["description"] = preg_replace("/(\r\n)/", "\\1<br />", $val["description"]);
								$tmpStr = substr_replace($tmpStr, $val["description"], $pos, 6);
								$outputPosts[] = $tmpStr;
						}
						else
						{
								$this->errError(4);
						}
				}
				return $outputPosts;
		}
		public function loadXML()
		{
				if ($fp = @fopen($this->rssFeed, "r"))
				{
						$this->RSSparser = xml_parser_create();
						xml_set_object($this->RSSparser, $this);
						xml_set_element_handler($this->RSSparser, array(&$this, "XMLstartElement"), array(&$this, "XMLendElement"));
						xml_set_character_data_handler($this->RSSparser, array(&$this, "XMLcharacterData"));
						while ($data = fread($fp, 4096))
								if (!xml_parse($this->RSSparser, $data, feof($fp))) die(sprintf("XML error: %s at line %d", xml_error_string(xml_get_error_code($this->RSSparser)), xml_get_current_line_number($this->RSSparser)));
						xml_parser_free($this->RSSparser);
				}
				else
				{
						$this->errError(8);
				}
		}
		public function RemoveLinks($arrPosts)
		{
				$this->postLinks = array();
				for ($i = 0; $i < count($arrPosts); $i++)
				{
						preg_match_all("/(<a.*?href=[\"|\'](.*?)[\"|\'][^>]*>)(.*?)(<\/a>)/i", $arrPosts[$i], $this->postLinks[$i], PREG_SET_ORDER | PREG_OFFSET_CAPTURE);
						$arrPosts[$i] = preg_replace("/<a.*?href=[\"|\'](.*?)[\"|\'][^>]*>(.*?)(<\/a>)/i", "\\2", $arrPosts[$i]);
				}
				return $arrPosts;
		}
		public function shortenPost($strPost, $shrtnHow, $shrtn2 = -1)
		{
				if ($shrtn2 == -1 || $shrtnHow == "n") return $strPost;
				$strPost = trim($strPost);
				$arrPost = preg_split("/\r\n|\n|\r/", $strPost);
				if ($shrtnHow == "c")
				{
						if (strlen($strPost) <= $shrtn2) return rtrim($strPost);
						else
						{
								$arrLength = array();
								$strLength = 0;
								for ($i = 0; $i < count($arrPost); $i++)
								{
										$arrLength[$i] = strlen($arrPost[$i]);
										$strLength += $arrLength[$i];
										if ($strLength >= $shrtn2) break;
								}
								if ($strLength <= $shrtn2)
								{
										$strPost = "";
										for ($j = 0; $j <= $i; $j++)
												if (empty($arrPost[$j])) $strPost .= "\r\n";
												else  $strPost .= $arrPost[$j] . "\r\n";
										return rtrim($strPost) . "...";
								}
								else
										if ($strLength > $shrtn2)
										{
												$num2Rem = $arrLength[$i] - ($strLength - $shrtn2);
												$arrPost[$i] = substr($arrPost[$i], 0, $num2Rem);
												$strPost = "";
												for ($j = 0; $j <= $i; $j++)
														if (empty($arrPost[$j])) $strPost .= "\r\n";
														else  $strPost .= rtrim($arrPost[$j]) . "\r\n";
												return rtrim($strPost) . "...";
										}
						}
				}
				else
						if ($shrtnHow == "w")
						{
								$arrLength = array();
								$strLength = 0;
								for ($i = 0; $i < count($arrPost); $i++)
								{
										if (empty($arrPost[$i]))
										{
												$arrLength[$i] = 0;
												continue;
										}
										$arrPost[$i] = preg_split("/\s+/", $arrPost[$i], -1, PREG_SPLIT_NO_EMPTY);
										$arrLength[$i] = count($arrPost[$i]);
										$strLength += $arrLength[$i];
										if ($strLength >= $shrtn2) break;
								}
								$joinHow = " ";
						}
						else
								if ($shrtnHow == "s")
								{
										$arrLength = array();
										$strLength = 0;
										for ($i = 0; $i < count($arrPost); $i++)
										{
												if (empty($arrPost[$i]))
												{
														$arrLength[$i] = 0;
														continue;
												}
												$arrPost[$i] = preg_split("/\.\s+/x", $arrPost[$i]);
												$arrLength[$i] = count($arrPost[$i]);
												$strLength += $arrLength[$i];
												if ($strLength >= $shrtn2) break;
										}
										$joinHow = ". ";
								}
				if ($shrtnHow == "w" || $shrtnHow == "s")
				{
						if ($strLength <= $shrtn2)
						{
								$i = ($i > (count($arrPost) - 1)) ? (count($arrPost) - 1) : $i;
								$strPost = "";
								for ($j = 0; $j <= $i; $j++)
										if (empty($arrPost[$j])) $strPost .= "\r\n";
										else  $strPost .= implode($joinHow, $arrPost[$j]) . "\r\n";
								if ($strLength < $shrtn2) return rtrim($strPost);
								return rtrim($strPost) . "...";
						}
						else
								if ($strLength > $shrtn2)
								{
										$strPost = "";
										for ($j = 0; $j < $i; $j++)
												if (empty($arrPost[$j])) $strPost .= "\r\n";
												else  $strPost .= implode($joinHow, $arrPost[$j]) . "\r\n";
										$num2Rem = $arrLength[$i] - ($strLength - $shrtn2);
										$strPost .= implode($joinHow, array_slice($arrPost[$i], 0, $num2Rem));
										return rtrim($strPost) . "...";
								}
				}
		}
		public function AddLinks($arrPosts)
		{
				$postLinkTarget = ($this->postLinkTarget == "" || $this->postLinkTarget == "_self") ? "" : " target=\"" . $this->postLinkTarget . "\"";
				$postLinks = $this->postLinks;
				for ($i = 0; $i < count($arrPosts); $i++)
				{
						if (empty($postLinks[$i])) continue;
						else
						{
								if ((strlen($arrPosts[$i]) - 3) < $postLinks[$i][0][0][1]) continue;
								else
								{
										$numPos2Rem = 0;
										for ($j = 0; $j < count($postLinks[$i]); $j++)
										{
												$strNewLink = "<a href=\"" . $postLinks[$i][$j][2][0] . "\"$postLinkTarget>";
												$numNewLength = strlen($strNewLink);
												$numOrigLength = strlen($postLinks[$i][$j][1][0]);
												$numOldStart = $postLinks[$i][$j][1][1];
												$numNewStart = ($numOldStart - $numPos2Rem);
												if ((strlen($arrPosts[$i]) - 3) <= $numNewStart) break;
												$numPos2Rem += ($numOrigLength - $numNewLength);
												$arrPosts[$i] = substr_replace($arrPosts[$i], $strNewLink, $numNewStart, 0);
												$numOldStart = $postLinks[$i][$j][4][1];
												$numNewStart = ($numOldStart - $numPos2Rem);
												if ($numNewStart >= (strlen($arrPosts[$i]) - 3)) $arrPosts[$i] = substr_replace($arrPosts[$i], ".</a>", -1);
												else  $arrPosts[$i] = substr_replace($arrPosts[$i], "</a>", $numNewStart, 0);
										}
								}
						}
				}
				return $arrPosts;
		}
		public function errError($errNum = 0)
		{
				if ($errNum == 0) return true;
				else
				{
						echo "\r\n<p>" . $this->ScriptErrorCodes[$errNum] . "\r\n</p>\r\n";
				}
				$this->display = false;
		}
		public function XMLstartElement($parser, $name, $attrs)
		{
				if ($name == "rss" || $name == "RSS") $this->isRSS = true;
				if (!$this->isRSS) $this->errError(16);
				switch ($name)
				{
						case "rss":
								$this->rssVersion = $attrs["version"];
								break;
						case "RSS":
								$this->rssVersion = $attrs["VERSION"];
								break;
						case "channel":
						case "CHANNEL":
								$this->inChannel = true;
								break;
						case "item":
						case "ITEM":
								$this->rssData[] = array();
								$this->curID++;
								$this->inItem = true;
								break;
						case "title":
						case "TITLE":
								$this->isTitle = true;
								break;
						case "link":
						case "LINK":
								$this->isLink = true;
								break;
						case "description":
						case "DESCRIPTION":
								$this->isDesc = true;
								break;
						case "pubDate":
						case "PUBDATE":
								$this->isDate = true;
								break;
				}
		}
		public function XMLendElement($parser, $name)
		{
				switch ($name)
				{
						case "channel":
						case "CHANNEL":
								$this->inChannel = false;
								break;
						case "item":
						case "ITEM":
								$this->inItem = false;
								break;
						case "title":
						case "TITLE":
								$this->isTitle = false;
								break;
						case "link":
						case "LINK":
								$this->isLink = false;
								break;
						case "description":
						case "DESCRIPTION":
								$this->isDesc = false;
								break;
						case "pubDate":
						case "PUBDATE":
								$this->isDate = false;
								break;
				}
		}
		public function XMLcharacterData($parser, $data)
		{
				if ($this->inChannel)
						if (!$this->inItem)
						{
								if ($this->isTitle)
								{
										if (!isset($this->rssInfo["title"])) $this->rssInfo["title"] = htmlentities($data);
										else  $this->rssInfo["title"] .= htmlentities($data);
								}
								if ($this->isLink)
								{
										if (!isset($this->rssInfo["link"])) $this->rssInfo["link"] = htmlentities($data);
										else  $this->rssInfo["link"] .= htmlentities($data);
								}
						}
						else
								if ($this->inItem)
								{
										$curID = $this->curID;
										if ($this->isTitle)
										{
												if (!isset($this->rssData[$curID]["title"])) $this->rssData[$curID]["title"] = htmlentities($data);
												else  $this->rssData[$curID]["title"] .= htmlentities($data);
										}
										if ($this->isLink)
										{
												if (!isset($this->rssData[$curID]["link"])) $this->rssData[$curID]["link"] = htmlentities($data);
												else  $this->rssData[$curID]["link"] .= htmlentities($data);
										}
										if ($this->isDesc)
										{
												if (!isset($this->rssData[$curID]["description"])) $this->rssData[$curID]["description"] = $data;
												else  $this->rssData[$curID]["description"] .= $data;
										}
										if ($this->isDate)
										{
												if (!isset($this->rssData[$curID]["pubDate"])) $this->rssData[$curID]["pubDate"] = date("jS M Y, g:i a", strtotime($data));
												else  $this->rssData[$curID]["pubDate"] .= date("jS M Y, g:i a", strtotime($data));
										}
								}
		}
		public function RSSv0_9()
		{
		}
		public function RSSv2_0()
		{
		}
}

?>