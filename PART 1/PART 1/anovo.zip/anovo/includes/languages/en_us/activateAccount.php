<?php

$LANG['err_tip_verified'] = 'Already verified';
$LANG['err_tip_invalid'] = 'Invalid';
$LANG['err_tip_locked'] = 'Account Locked';
$LANG['verified_successfully'] = 'Verified sucessfully';
$LANG['err_tip_compulsory'] = 'Compulsory';
$LANG['verifymail_title'] = 'Mail Verification';
$LANG['verifymail_tbl_summary'] = 'form for mail Verification';
$LANG['verifymail_submit'] = 'Submit';
$LANG['verifymail_password'] = 'Password';
$LANG['err_tip_invalid_link'] = 'Invalid activation code';
?>