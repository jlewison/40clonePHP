<?php
header("Location: http://imageshack.modthisname.spiderhost.hu/contect/".$_GET['page'].".php""); /* �tir�ny�t */
exit; /* Biztoss� teszi azt, hogy az k�vetkez� k�dr�sz nem fut le. */
?> 