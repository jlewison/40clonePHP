    <center>
    <font size="2" face="Verdana">
	<b><p><u>Host your files with Rapidsendit FOR FREE!</u><br>
    1. Select your file and press upload<br>
    2. Receive download-link and share it </p></b>
    </center>
	<br />
	<center>
	<form enctype="multipart/form-data" action="upload.php" id="form" method="post" onsubmit="a=document.getElementById('form').style;a.display='none';b=document.getElementById('part2').style;b.display='inline';" style="display: inline;">
	<strong>maximum filesize:</strong> <?php echo $maxfilesize; ?> MB<br />
	<input type="file" name="upfile" size="50" /><br />
	<?php if($emailoption) { ?>Email Address: <input type="text" name="myemail" size="30" /> <i>(Your links will be e-mailed to this address)</i><br /><?php } ?>
	By uploading your file, you agree to our <a href="?page=tos">terms of service</a>. <input type="submit" value="Upload!" id="upload" />
	</form>
	<div id="part2" style="display: none;">Upload in progress. Please Wait...<br>
	
	
	    <OBJECT classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"
      codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0"
      width=174 height=14> <PARAM NAME=movie VALUE="images/upload.swf"> <PARAM NAME=wmode VALUE=transparent>
      <PARAM NAME=quality VALUE=high> <PARAM NAME=bgcolor VALUE=#FFFFFF>
      <EMBED src="images/upload.swf" quality=high wmode=transparent
        bgcolor=#FFFFFF width=174 height=14 type="application/x-shockwave-flash"
        pluginspace="http://www.macromedia.com/go/getflashplayer">
      </EMBED>
    </OBJECT>
	
	</div>
	</center>


