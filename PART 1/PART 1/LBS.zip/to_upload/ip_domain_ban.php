<?php
$gep_neve = gethostbyaddr($_SERVER['REMOTE_ADDR']);
$ip = gethostbyname("$gep_neve");

require_once('Connections/apound.php');

mysql_select_db($database_apound, $apound);
	$query_IpBan = "SELECT * FROM ip_ban WHERE ip_ban.ip_ip = '$ip' AND ip_ban.ip_enable = 'N'";
	$IpBan = mysql_query($query_IpBan, $apound) or die(mysql_error());
	$row_IpBan = mysql_fetch_assoc($IpBan);
	$totalRows_IpBan = mysql_num_rows($IpBan);

$c_ip = $row_IpBan['ip_ip'];

mysql_select_db($database_apound, $apound);
	$query_DoBan = "SELECT * FROM do_ban WHERE do_ban.do_ban = '$gep_neve' AND do_ban.do_enable = 'N'";
	$DoBan = mysql_query($query_DoBan, $apound) or die(mysql_error());
	$row_DoBan = mysql_fetch_assoc($DoBan);
	$totalRows_DoBan = mysql_num_rows($DoBan);

$c_ip = $row_IpBan['ip_ip'];
$c_do = $row_DoBan['do_ban'];

if($ip == "$c_ip") { 
print"Your IP address:  $ip <br>
Banned IP address: $c_ip <br>
IP match <br><br>
<font color='Red'><h1>You not have permission to access this page!</h1></font>";
mysql_free_result($IpBan);
mysql_free_result($DoBan);
exit; }
else {}

if($gep_neve == "$c_do") {
print"Your hots/domain: $gep_neve<br>
Banned Domain/Host: $c_do<br>
Domain match <br><br>
<font color='Red'><h1>You not have permission to access this page!</h1></font>";
mysql_free_result($IpBan);
mysql_free_result($DoBan);
exit; }
else {}
?>