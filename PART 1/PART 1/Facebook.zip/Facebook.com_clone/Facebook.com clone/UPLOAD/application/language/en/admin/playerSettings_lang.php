<?php
/**
*
*
*
* @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
* @license
* @version SVN:$Id
* @since 2007-06-18
*/
$lang['playersettings_title'] 					= 'Player Settings';
$lang['playersettings_mencoder_path'] 			= 'Mencoder Path';
$lang['playersettings_mplayer_path'] 			= 'Mplayer path';
$lang['playersettings_webcam_capture_time'] 	= 'Webcam capture time limit';
$lang['playersettings_red5_path'] 				= 'Red5 path';
$lang['playersettings_recorder_path'] 			= 'Recorder path';
$lang['playersettings_red5_flv_path'] 			= 'Red5 Flv Stored Path';
$lang['playersettings_flvtool2_path'] 			= 'Flvtool2 Path';
$lang['playersettings_red5_server_path']		= 'Red5 Server Path';
$lang['playersettings_submit']					= 'Save changes';
$lang['playersettings_success_msg']				= 'Player settings updated successfully!';
?>