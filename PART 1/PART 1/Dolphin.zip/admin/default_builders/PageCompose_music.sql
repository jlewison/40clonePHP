INSERT INTO `PageCompose` VALUES(NULL, 'music', '960px', '', '_Music', 1, 0, 'ViewFile', '', 1, 50, 'non,memb', 380);
INSERT INTO `PageCompose` VALUES(NULL, 'music', '960px', '', '_Rate', 2, 1, 'Rate', '', 1, 50, 'non,memb', 0);
INSERT INTO `PageCompose` VALUES(NULL, 'music', '960px', '', '_Actions', 1, 1, 'ActionList', '', 1, 50, 'non,memb', 0);
INSERT INTO `PageCompose` VALUES(NULL, 'music', '960px', '', '_View Comments', 1, 2, 'ViewComments', '', 1, 50, 'non,memb', 0);
INSERT INTO `PageCompose` VALUES(NULL, 'music', '960px', '', '_Music File Info', 2, 0, 'FileInfo', '', 1, 50, 'non,memb', 0);
INSERT INTO `PageCompose` VALUES(NULL, 'music', '960px', '', '_Latest files from this user', 2, 2, 'LastFiles', '', 1, 50, 'non,memb', 0);
INSERT INTO `PageCompose` VALUES(NULL, 'music', '960px', '', '_BoonEx News', 0, 0, 'RSS', 'http://www.boonex.com/unity/blog/featured_posts/?rss=1#4', 1, 50, 'non,memb', 0);
