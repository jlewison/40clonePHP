<?
include("../include/config.php");
$uname=$_REQUEST['name'];
$upass=$_REQUEST['pass'];
$sql="select * from admin where uname='$uname' and pwd='$upass'";
$rs=$conn->execute($sql);
$n=$rs->recordcount();
if($n>0) 
        {
         setcookie('admin_uname',$uname);
         setcookie('admin_uid',$rs->fields['uid']);
         setcookie("msg","You are logged in now for 2 hours");
         header("location: admin_index.php");
        }

else 
        {
         setcookie("err","Incorrect Username/Password");
         header("location: index.php");
        }
?>
