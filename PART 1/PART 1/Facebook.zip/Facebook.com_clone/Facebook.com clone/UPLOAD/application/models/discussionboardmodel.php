<?php
/**
 * Discussion Board Model
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 12/24/2007
 * 
 * Tables: network_discussion_topic , network_discussion_post
 * 
 */
class Discussionboardmodel extends Model
{
		//Constructor
		function Discussionboardmodel()
		{
				parent::Model();
		}
		function isTopicExist($postedFor, $topicId, $createdBy = '')
		{
				$this->db->select('discussion_topic_id');
				$this->db->where('discussion_topic_id', $topicId);
				$this->db->where('posted_for', $postedFor);
				if (trim($createdBy) != '') $this->db->where('created_by', $createdBy);
				$this->db->limit(1, 0);
				$isExistQuery = $this->db->get('discussion_topic');
				if ($isExistQuery->num_rows() > 0) return true;
				else  return false;
		}
		function isPostExist($postedFor, $postId, $topicId = '', $postedBy = '')
		{
				$this->db->select('discussion_post_id');
				$this->db->where('discussion_post_id', $postId);
				$this->db->where('posted_for', $postedFor);
				if (trim($topicId) != '') $this->db->where('discussion_topic_id', $topicId);
				if (trim($postedBy) != '') $this->db->where('posted_by', $postedBy);
				$this->db->limit(1, 0);
				$isExistQuery = $this->db->get('discussion_post');
				if ($isExistQuery->num_rows() > 0) return true;
				else  return false;
		}
		function getDiscussionBoardTopic($postedFor, $postedForId, $topicId = '', $createdBy = '', $orderBy = 'date_added desc', $start = '', $limit = '')
		{
				if (trim($postedFor) == '' && trim($postedForId) == '') return false;
				$this->db->select('dt.discussion_topic_id, dt.discussion_topic, dt.created_by, u.username, u.avatar_ext, dt.date_added, dt.last_updated, count(dp.discussion_post_id) as postsCnt , count(DISTINCT(dp.posted_by)) as peoples');
				$this->db->from('discussion_topic as dt');
				$this->db->join('discussion_post as dp', 'dt.discussion_topic_id = dp.discussion_topic_id', 'INNER');
				$this->db->join('users as u', 'dt.created_by = u.user_id', 'INNER');
				$this->db->where('posted_for', $postedFor);
				$this->db->where('posted_for_id', $postedForId);
				if (trim($topicId) != '') $this->db->where('dt.discussion_topic_id', $topicId);
				if (trim($createdBy) != '') $this->db->where('dt.created_by', $createdBy);
				$this->db->group_by('dt.discussion_topic_id, dt.discussion_topic, dt.created_by, u.username, dt.date_added, dt.last_updated');
				if (trim($orderBy) != '') $this->db->order_by('dt.' . $orderBy);
				if (trim($limit) != '' && is_numeric($limit))
				{
						if (trim($start) != '' && is_numeric($start)) $this->db->limit($limit, $start);
						else  $this->db->limit($limit);
				}
				$discussionBoardQuery = $this->db->get();
				//echo $this->db->last_query();
				$discussionBoardTopics = array();
				if ($discussionBoardQuery->num_rows() > 0)
				{
						foreach ($discussionBoardQuery->result_array() as $discussionBoardRow)
						{
								$discussionBoardRow['avatar'] = getAvatar($discussionBoardRow['created_by'], $discussionBoardRow['avatar_ext']);
								$discussionBoardTopics[$discussionBoardRow['discussion_topic_id']] = $discussionBoardRow;
						}
				}
				return $discussionBoardTopics;
		}
		function getDiscussionBoardTopicCount($postedFor, $postedForId, $topicId = '', $createdBy = '')
		{
				$this->db->from('discussion_topic');
				$this->db->where('posted_for', $postedFor);
				$this->db->where('posted_for_id', $postedForId);
				if (trim($topicId) != '') $this->db->where('discussion_topic_id', $topicId);
				if (trim($createdBy) != '') $this->db->where('created_by', $createdBy);
				return $this->db->count_all_results();
		}
		function getDiscussionBoardPost($topicId, $postedBy = '', $orderBy = 'posted_date desc', $start = '', $limit = '')
		{
				$this->db->select('dp.discussion_post_id, dp.parent_discussion_post_id, dp.discussion_topic_id, dp.posted_by, u.username, u.avatar_ext, dp.posted_content, dp.posted_date');
				$this->db->where('dp.discussion_topic_id', $topicId);
				$this->db->from('discussion_post as dp');
				$this->db->join('users as u', 'dp.posted_by = u.user_id');
				if (trim($postedBy) != '') $this->db->where('posted_by', $postedBy);
				if (trim($orderBy) != '') $this->db->orderby($orderBy);
				if (trim($limit) != '' && is_numeric($limit))
				{
						if (trim($start) != '' && is_numeric($start)) $this->db->limit($limit, $start);
						else  $this->db->limit($limit);
				}
				$discussionBoardQuery = $this->db->get();
				//echo $this->db->last_query();
				$discussionBoardPosts = array();
				if ($discussionBoardQuery->num_rows() > 0)
				{
						foreach ($discussionBoardQuery->result_array() as $discussionBoardRow)
						{
								$discussionBoardRow['avatar'] = getAvatar($discussionBoardRow['posted_by'], $discussionBoardRow['avatar_ext']);
								$discussionBoardPosts[$discussionBoardRow['discussion_post_id']] = $discussionBoardRow;
						}
				}
				return $discussionBoardPosts;
		}
		function getDiscussionBoardPostCount($topicId, $postedBy = '')
		{
				$this->db->where('discussion_topic_id', $topicId);
				$this->db->from('discussion_post');
				if (trim($postedBy) != '') $this->db->where('posted_by', $postedBy);
				return $this->db->count_all_results();
		}
		function newDiscussionTopic($topicContent)
		{
				if (!isset($topicContent['discussion_topic']) || !isset($topicContent['posted_for']) || !isset($topicContent['posted_for_id']) || !isset($topicContent['posted_content'])) return false;
				if (!is_numeric($topicContent['posted_for_id'])) return false;
				$newTopic = array('discussion_topic' => $topicContent['discussion_topic'], 'created_by' => $this->session->userdata('user_id'), 'posted_for' => $topicContent['posted_for'], 'posted_for_id' => $topicContent['posted_for_id'], 'total_posts' => 1);
				$this->db->insert('discussion_topic', $newTopic);
				if ($this->db->affected_rows() == 1)
				{
						$newTopicId = $this->db->insert_id();
						$newPost = array('parent_discussion_post_id' => 0, 'discussion_topic_id' => $newTopicId, 'posted_by' => $this->session->userdata('user_id'), 'posted_content' => $topicContent['posted_content'], );
						$this->newDiscussionPost($newPost);
						return $newTopicId;
				}
				else  return false;
		}
		function newDiscussionPost($postContent)
		{
				if (!isset($postContent['discussion_topic_id']) || !isset($postContent['posted_content'])) return false;
				$newPost = array('parent_discussion_post_id' => (isset($postContent['parent_discussion_post_id']) && is_numeric($postContent['parent_discussion_post_id'])) ? $postContent['parent_discussion_post_id'] : 0, 'discussion_topic_id' => $postContent['discussion_topic_id'], 'posted_by' => $this->session->userdata('user_id'), 'posted_content' => $postContent['posted_content'], );
				$this->db->insert('discussion_post', $newPost);
				if ($this->db->affected_rows() == 1)
				{
						$newPostId = $this->db->insert_id();
						$this->db->query('UPDATE discussion_topic SET last_updated = NOW(), total_posts = total_posts + 1 WHERE discussion_topic_id = ' . $this->db->escape($postContent['discussion_topic_id']));
						return $newPostId;
				}
				else  return false;
		}
		function updateDiscussionTopic($in, $topicId, $topicTitle)
		{
				$updateDiscussionTopic = array('discussion_topic' => $topicTitle);
				$this->db->where('discussion_topic_id', $topicId);
				$this->db->update($in . '_discussion_topic', $updateDiscussionTopic);
		}
		function updateDiscussionPost($in, $postId, $postContent)
		{
				$updateDiscussionPost = array('posted_content' => $postContent);
				$this->db->where('discussion_post_id', $postId);
				$this->db->update($in . '_sdiscussion_post', $updateDiscussionPost);
		}
		function deleteDiscussionTopic($topicId)
		{
				$this->db->delete('discussion_topic', array('discussion_topic_id' => $topicId));
				$this->db->delete('discussion_post', array('discussion_topic_id' => $topicId));
		}
		function deleteDiscussionPost($postId)
		{
				$this->db->delete('discussion_post', array('discussion_post_id' => $postId));
				echo $this->db->last_query();
		}
		/// General Discussion board releated function
}
?>