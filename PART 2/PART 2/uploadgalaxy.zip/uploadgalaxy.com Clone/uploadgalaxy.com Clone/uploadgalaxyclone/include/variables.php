<?php
$user_login=array();
$user_login[0]="If you already have an account please sign in bellow.";
$user_login[1]="User name: ";
$user_login[2]="Password: ";
$user_login[3]="Submit";
$user_login[4]="Forget Your Password?";
$user_login[5]="We will send it to you.";
$user_login[6]="Not yet registered? Click to";
$user_login[7]="register";
$user_login[8]="Invalid Username and/or Password Provided";


$forgetpass[0]="Lost your password?";
$forgetpass[1]="If you are a registered Meet Me user,type in the email address associated with the account, and we will send your password to you.If you did not signup for Meet Me,please just create a new account.";
$forgetpass[2]="Your Email Address";
$forgetpass[3]="Change password";
$forgetpass[4]="Cancel";
$forgetpass[5]="No account associated with this email address.";



$user_register[1]="Submit a picture of yourself and find out!";
$user_register[2]="1.Username";
$user_register[3]="Click to see if this username is available ->";
$user_register[4]="Check";
$user_register[5]="2.Password";
$user_register[6]="Confirm password";
$user_register[7]="3.Some basic info";
$user_register[8]="4.Submit your photo";
$user_register[9]="5.That's it! Click the button to sign up";
$user_register[10]="Are you male or female?";
$user_register[11]="How old are you?";
$user_register[12]="Male";
$user_register[13]="Female";
$user_register[14]="(Upload a .jpg or .gif file from your computer (500000 bytes max):)";
$user_register[15]="Please keep your photos FUN, CLEAN and REAL. In other words, no porn, sexually suggestive poses, advertisements, copyrighted content, etc. Photos with URL's, email addresses, etc. written on them are NOT allowed. Also, if there are multiple people in the picture, make sure it's obvious which person is to be rated. You must be 18 to post your picture on HOT or NOT. More questions? Check";
$user_register[15]="I agree";





$left_head_body[0]="Rate people";
$left_head_body[1]="Your rating";
$left_head_body[2]="Share your rating";
$left_head_body[3]="Meet new people";
$left_head_body[4]="Your double-matches";
$left_head_body[5]="Share your double-matches";
$left_head_body[6]="Edit Meet Me profile";
$left_head_body[7]="Email settings";
$left_head_body[8]="Change/remove photo";
$left_head_body[9]="Change password";
$left_head_body[10]="Membership info";
$left_head_body[11]="Help";
$left_head_body[12]="FAQ";
$left_head_body[13]="Testimonials";



$rating[0]="Status: AWATING MODERATOR REVIEW";
$rating[1]="Please be patient, as it may take up a day for the moderator to review your picture.
                 Your photo will be posted for rating once as it has been approved.";
$rating[2]="Not enough votes yet to calculate your rating.";
$rating[3]="Want your friends to rate you? Send them this direct link:";
$rating[4]="Click here";
$rating[5]="If you DO NOT want your photo to be posted for rating";
$rating[6]="people have rated you";
$rating[7]="Not satisfied with your rating?";
$rating[8]="You can";
$rating[9]="submit a new photo";
$rating[10]="If you want your photo to be posted for rating";
$rating[11]="Your photo is currently posted for public rating.";
$rating[12]="Your photo is NOT currently posted for public rating.";
$rating[13]="(but your profile is still active in 'Meet Me')";
$rating[14]="(and also your profile is not active in 'Meet Me')";
$rating[15]="Your rating is";
$rating[16]="Not enough votes yet";
$rating[17]="to calculate your rating.";
$rating[18]="Status:You Are Not Excepted By Moderator!";







$share_rate[0]="The direct link for rating your photo is:";
$share_rate[1]="You can also put your rating on your homepage, journal or blog! Your rating will automatically update as you get votes. Just post one of the HTML stickers below.
                (Note: your site must allow JavaScript.)";
$share_rate[2]="Option 1: Just your picture";
$share_rate[3]="Rate Me";
$share_rate[4]="Option 2: Also include your score";
$share_rate[5]="Are you Hot or Not?";
$share_rate[6]="Option 2: Just your rating";
$share_rate[7]="in";
$share_rate[8]="Votes";






$meat_people[0]="Show me";
$meat_people[1]="location";
$meat_people[2]="keyword";
$meat_people[3]="from";
$meat_people[4]="by";
$meat_people[5]="he";
$meat_people[6]="she";
$meat_people[7]="is now added in your list of double matches";
$meat_people[8]="(You can also send";
$meat_people[9]="him";
$meat_people[10]="her";
$meat_people[11]="a gift)";
$meat_people[12]="If";
$meat_people[13]="also clicks 'YES' to you,";
$meat_people[14]="will appear";
$meat_people[15]="in your list of double matches";
$meat_people[16]="You already clicked yes to";
$meat_people[17]="Both of you are already Double matched !!!";
$meat_people[18]="click to send note";
$meat_people[19]="wants to meet you!";
$meat_people[20]="Click 'YES' to add";
$meat_people[21]="directly to your double-match list";
$meat_people[22]="Do you want to meet";
$meat_people[23]="Viewing people with keyword";




$double_matches[0]="Your profile is currently awaiting review by the moderators. You can stil click Yes to people you want to meet, but they and your double-matches will not be able to see your profile until after it has been approved.";
$double_matches[1]="Match info can not be shown because of invalid account";
$double_matches[2]="How \"MEET ME\" works";
$double_matches[3]="In the";
$double_matches[4]="Meet new people";
$double_matches[5]="section, click 'YES' on the people you would like to meet. They will be shown your profile the next time they login. If somebody also clicks 'YES' to you, he or she will appear in your double-match list.";
$double_matches[6]="Waiting for your approval";
$double_matches[7]="click to enlarge";
$double_matches[8]="Keywords :";
$double_matches[9]="Direct link :";
$double_matches[10]="Grant";
$double_matches[11]="YES";
$double_matches[12]="NO";
$double_matches[13]="You Wait for others approval";
$double_matches[14]="Status";
$double_matches[15]="pending";

$double_matches[16]="Your Matches";
$double_matches[17]="(They also clicked 'YES' to you)";
$double_matches[18]="  Delete selected matches  ";
$double_matches[19]="Warning! Once you delete a match, you will no longer be able to exchange notes or emails with that person.";




$share_dmatches[0]="Want to show your double-match list to friends and talk about your matches without having to send them each direct link, one by one? It's easy to do!";
$share_dmatches[1]="You can show friends your double-match list with this link";
$share_dmatches[2]="Or";
$share_dmatches[3]="Option 2: You can post your double-matches to your website, blog, or journal. (It must support JavaScript). Just cut and paste the code below:";
$share_dmatches[4]="hint: You can set the number of double-matches shown by changing the number after \"num=\"";
$share_dmatches[5]="Example of Option 2:";
$share_dmatches[6]="My Picture:";
$share_dmatches[7]="Click Here to Meet Me";
$share_dmatches[8]="Are you Hot or Not?";
$share_dmatches[9]="Option";




$meet_profile[0]="Status of your Meet Me profile";
$meet_profile[1]="Your profile is currently awaiting review by the moderators.";
$meet_profile[2]="You can go ahead and click on the people you want to meet, but you will not be shown to them until after your profile has been approved.";
$meet_profile[3]="Edit introduction";
$meet_profile[4]="Please keep your photos FUN, CLEAN and REAL. In other words, no porn, sexually suggestive poses, advertisements, copyrighted content, etc. Photos with URL's, email addresses, etc. written on them are NOT allowed. Also, if there are multiple people in the picture, make sure it's obvious which person is to be rated. You must be 18 to post your picture on HOT or NOT. More questions?";
$meet_profile[5]="Update Introduction";
$meet_profile[6]="Edit keywords";
$meet_profile[7]="Enter upto 50 keywords to describe yourself and your interests. Separate them with commas- for example: chocolate,sushi,asian,huphop,cristian,snowbording, hockey,swing dancing,astrology,photography,san fransisco,simpson.Please do not enter contact information,or your profile wo'nt be approved by the moderators. Do'nt worry if you can't think of everything right now-you will be able to edit your keywords later.";
$meet_profile[8]="Update keywords";
$meet_profile[9]="Your Personal info";
$meet_profile[10]="Age";
$meet_profile[11]="Sex";
$meet_profile[12]="Your sexual orientation?";
$meet_profile[13]="Country";
$meet_profile[14]="Update Personal info";
$meet_profile[15]="Email verification status";
$meet_profile[16]="Your mail has not been verified.";
$meet_profile[17]="Please visit the link contained in the confirmation letter.If you did not receive it,";
$meet_profile[18]="click here";
$meet_profile[19]="to have it sent again.";
$meet_profile[20]="-- ACTIVE --";
$meet_profile[21]="Your profile is being shown in Meet Me, and you can receive messages from your double-matches. If you don't want to participate in Meet Me, click below:";
$meet_profile[22]="You can view or share your Meet Me profile through this link:";
$meet_profile[23]="-- INACTIVE --";
$meet_profile[24]="Your profile is";
$meet_profile[25]="NOT";
$meet_profile[26]="being shown in Meet Me.";
$meet_profile[27]="You";
$meet_profile[28]="CANNOT";
$meet_profile[29]="receive messages from your double-matches.";
$meet_profile[30]="To reactivate your profile, click the button below:";
$meet_profile[31]="State";
$meet_profile[32]="Zipcode:";







$email_settings[0]="Change Email Address";
$email_settings[1]="Current address";
$email_settings[2]="New address";
$email_settings[3]="A confirmation letter will be sent to verify";
$email_settings[4]="Email notification preferences";
$email_settings[5]="Submit";
$email_settings[6]="Notify me when someone has clicked \"Yes\" to me.";
$email_settings[7]="Notify me when I have new matches.";
$email_settings[8]="Notify me when new people from my area join meet me.";
$email_settings[9]="I can receive HTML formated mail.";
$email_settings[10]="Save changes";
$email_settings[11]="Preferences updated successfully!";




$editphoto[0]="Change Photo";
$editphoto[1]="You can upload a file from your computer or from a URL.";
$editphoto[2]="Uploading a new photo will reset your rating.You will also have to wait for
                Your new photo to be approved by modarators. This may take up to several days.";
$editphoto[3]="(Upload a .jpg or .gif from your computer)";
$editphoto[4]="Replace";
$editphoto[5]="Submit a photo from URL";
$editphoto[6]="OR";
$editphoto[7]="Submit from URL";
$editphoto[8]="Remove photo";
$editphoto[9]="No photo is available.";




$changepass[0]="Change Password";
$changepass[1]="Old Password";
$changepass[2]="New Password";
$changepass[3]="Confirm Password";





$memhome[0]="You are a";
$memhome[1]="Member";
$memhome[2]="We hope you like HOTorNOT!";
$memhome[3]="As a Basic Member you can:";
$memhome[4]="Post your picture for rating 1-10.";
$memhome[5]="Post your profile in Meet Me.";
$memhome[6]="Browse through profiles and make double-matches";
$memhome[7]="Send and receive unlimited notes with all matches.";
$memhome[8]="Receive and reply to unlimited emails.";
$memhome[9]="Send unlimited emails to matches who are Star members.";
$memhome[10]="Upgrade your membership to get features like:";
$memhome[11]="Send and receive unlimited emails with ALL matches, including Basic Members";
$memhome[12]="Get notifications when your emails are received";
$memhome[13]="Get shown to potential matches before other members";
$memhome[14]="Get shown at the top of match lists.";
$memhome[15]="Attach your Official HOT or NOT Rating to emails.";
$memhome[16]="Click here to update";
$memhome[17]="Your current membership term ends in";
$memhome[18]="days.";
$memhome[19]="It will be automatically renewed at the end of the term.";
$memhome[20]="If you want to change the renewal policy, follow these";
$memhome[21]="instructions";
$memhome[22]="As a 3 Star Member you can:";
$memhome[23]="As a 5 Star Member you can:";









$help_var[0]="Here are the answers to our most frequently asked questions. Please read them carefully before sending us email. Emails that ask us a question that is answered below will be ignored.";
$help_var[1]="If you have questions about our \"Meet Me\" service,";
$help_var[2]="Why wasn't my picture approved? It doesn't fit the criteria you list!";
$help_var[3]="Click here";
$help_var[4]="How do I get my picture onto the site?";
$help_var[5]="When I try to submit a picture, I get a \"Page not found\" or \"Server not found\" error. What's wrong?";
$help_var[6]="Is this site really run out of the living room by two guys?";
$help_var[7]="Why wasn't my picture approved? It doesn't fit the criteria you list!";
$help_var[8]="The moderators decide which pictures are accepted into the system, not us. The criteria listed are merely guidelines. A common reason for a normal picture not being approved is that group photos are not allowed, unless the person being voted on is clearly marked on the picture. You should also try going to your direct link, HIT REFRESH/RELOAD, and see if you can still see your picture. Some sites block other sites (such as hotornot.com) from showing images hosted on their servers. If this is the case, you should look here. Also, another common cause is that your personal introduction for the meeting section. Make sure it does not contain anything lewd or any type of contact information (e.g. email address, webpage URL, ICQ, AIM screenname, Messenger, etc.) If you don't know why your profile was not approved and would like to ask why, click here. If you're convinced your picture should have made it through, you can try resubmitting it";
$help_var[9]="How do I get my picture onto the site?";
$help_var[10]="You can upload a picture directly from your computer, or from an URL. Do not send us photos via email asking us to post it for you";
$help_var[11]="When I try to submit a picture, I get a \"Page not found\" or \"Server not found\" error. What's wrong?";
$help_var[12]="This probably means that your picture is taking too long to upload. Your file might be too big, or if you're submitting an URL, the server your picture is hosted on is slow. You should make your file smaller or find another place to host your picture.";
$help_var[13]="Is this site really run out of the living room by two guys?";
$help_var[14]="YUP";







$faq_var[0]="Here are the answers to our most frequently asked questions. Please read them carefully before sending us email. Emails that ask us a question that is answered below will be ignored.";
$faq_var[1]="If you have questions about our \"Meet Me\" service,";
$faq_var[2]="Click here";
$faq_var[3]="Site Objectives?";
$faq_var[4]="How to signup?";
$faq_var[5]="rating,meeting etc.";
$faq_var[6]="From index page";





$testimonials[0]="Add your tesstimonial";




$addtestimonial[0]="Add Your Testimonial here (only about Meet Me)";
$addtestimonial[1]="Back";
$addtestimonial[2]="Add your testimonials2";




$index[0]=" :: Alert ::";
$index[1]="No one to rate with this settings.";
$index[2]="Please select a rating to see the next picture";
$index[3]="Show me";
$index[4]="Logged in as";




$logout[0]="You Have been Successfully logged out. You will be redirected to Main site in few seconds.";

















?>
