<?php
if ( !defined( 'SMARTY_DIR' ) ) {
	include_once( '../init.php' );
}

include ( 'sessioninc.php' );

define( 'PAGE_ID', 'mship_mgt' );

$lang['privileges'] = get_lang_values('privileges');

$lang['activedays_array'] = get_lang_values('activedays_array');

$t->assign('lang', $lang);
if ( !checkAdminPermission( PAGE_ID ) ) {

	header( 'location: not_authorize.php' );
	exit;
}

$t->assign('rendered_page', $t->fetch('admin/addmship.tpl'));

$t->display( 'admin/index.tpl' );

exit;

?>