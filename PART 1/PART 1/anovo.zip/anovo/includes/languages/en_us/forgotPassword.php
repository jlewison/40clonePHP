<?php

$LANG['forgot_title'] = 'Forgot Password';
$LANG['forgot_email'] = 'Email';
$LANG['forgot_user_name'] = 'Username';
$LANG['forgot_submit'] = 'Submit';
$LANG['forgot_summary'] = 'Forgot Password';
$LANG['forgot_err_tip_compulsory'] = 'Compulsory';
$LANG['forgot_err_tip_invalid_email'] = 'Invalid email address';
$LANG['forgot_err_tip_data_not_exists'] = ' Invalid details';
$LANG['forgot_failure_message'] = 'Mail sending error occurred';
$LANG['forgot_success'] = 'Change Password link has been sent. Please check your mail';
$LANG['forgot_activation_code_sent'] = 'Activation code has been sent to you';
$LANG['forgot_activation_code_not_sent'] = 'Problem in sending mail';
$LANG['forgot_subject'] = 'Forgot Password code';
$LANG['forgot_message'] = 'Hi {username},

Please click the following link to change your password: ';

?>