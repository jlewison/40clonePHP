<?php include('restrict.php'); include('../settings.php'); require_once('../Connections/apound.php'); ?>
<?php
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = (!get_magic_quotes_gpc()) ? addslashes($theValue) : $theValue;

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form1")) {
  $updateSQL = sprintf("UPDATE ig_admin SET name=%s, pass=%s, email=%s WHERE adid=%s",
                       GetSQLValueString($_POST['name'], "text"),
                       GetSQLValueString($_POST['pass'], "text"),
                       GetSQLValueString($_POST['email'], "text"),
                       GetSQLValueString($_POST['adid'], "int"));

  mysql_select_db($database_apound, $apound);
  $Result1 = mysql_query($updateSQL, $apound) or die(mysql_error());

  $updateGoTo = "admin_edit.php?upd=Y";
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $updateGoTo));
}

$colname_updADM = "1";
if (isset($_GET['id'])) {
  $colname_updADM = (get_magic_quotes_gpc()) ? $_GET['id'] : addslashes($_GET['id']);
}
mysql_select_db($database_apound, $apound);
$query_updADM = sprintf("SELECT * FROM ig_admin WHERE adid = %s", $colname_updADM);
$updADM = mysql_query($query_updADM, $apound) or die(mysql_error());
$row_updADM = mysql_fetch_assoc($updADM);
$totalRows_updADM = mysql_num_rows($updADM);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Manage Admin</title>
<link href="admin.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.style84 {font-family: Verdana, Arial, Helvetica, sans-serif}
.style85 {font-size: 13px}
-->
</style>
</head>

<body>
<?php include('header_tpl.php'); ?>
<h2>Edit Admin</h2>
<table width="770"  border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="770" bgcolor="#FFFFFF"><?php $x = getenv("HTTP_HOST").getenv("REQUEST_URI"); echo("<font color=white>$x</font>"); ?></td>
  </tr>
</table>
<table width="770"  border="0" align="center" cellpadding="3" cellspacing="1" bgcolor="#FFFFFF">
  <tr>
    <td width="770" valign="top"><form method="post" name="form1" action="<?php echo $editFormAction; ?>">
        <?php $upd = $_GET[upd]; if($upd == 'Y') { echo("<div align='center'><font color='red'><b>Update ... DONE</b></font></div>"); } else { } ?>
        <table align="center" cellpadding="6" cellspacing="1">
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">Adid:</td>
            <td class="style63"><?php echo $row_updADM['adid']; ?></td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">Name:</td>
            <td><input name="name" type="text" class="edtab" value="<?php echo $row_updADM['name']; ?>" size="32"></td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">Pass:</td>
            <td><input name="pass" type="password" class="edtab" value="<?php echo $row_updADM['pass']; ?>" size="32"></td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">Email:</td>
            <td><input name="email" type="text" class="edtab" value="<?php echo $row_updADM['email']; ?>" size="32"></td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">&nbsp;</td>
            <td><input type="submit" class="login-but" value="Update record"></td>
          </tr>
        </table>
        <input type="hidden" name="MM_update" value="form1">
        <input type="hidden" name="adid" value="<?php echo $row_updADM['adid']; ?>">
      </form>
    </td>
  </tr>
</table>
<?php include('footer_tpl.php'); ?>
</body>
</html>
<?php
mysql_free_result($updADM);
?>
