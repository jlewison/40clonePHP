<?php //00461
// Copyright Notice
// Web Site URL:  http://www.zeeways.com
// Script Owner eMail: mail@zeeways.com
// Date: April, 2007
// Script Name: Zeeways Auction Website PHP Script
// Copyright Details: This script is not free.  Do not Remove this Copy Right notice.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the site administrator.');exit(199);
?>
4+oV54GvcF+FYW1XCqUD3H+Cf0D1ANSWUTj9mhgiCuDPcTCKbpSAdhOlYTAV77sutTCFKhr4tAxo
r355pTmto17lCJik20iDlclhJ79uAhdIfHsAcrvfbHpdqm358c4evb2Nfq1nxnfvs+Z1trO0H7EZ
13CNo+CHTBXfWBJkb28eBJOAm3lg5vJbcDCtP7bBtsMKj7CAlaqr65V25iQWJzleQjMeNAgEAjKb
eNpLkKW46Jwwr/aXBR4FbgOq34npzoskINwscd0HWtzSG8u+CllMFv4N7vmf2lzZ3BSWZp3t/OAJ
ti/GC8EbEO58ce8m/vkybFgHlJy7kaNu5jCNBgSHXhWWrdyzZXKUdRg+74Hc6zGHm3eS1MBrfgN4
byyMkWIe80L/EN7QdvkIoo7V8nYdADopMvXfGmrlAnBIVfYtyon5zN77tZMztw+SmLeHJlEHxpsH
5jrfNwa+EDzglmpCcS8slpBVU7hc5IoPd5iiHnaRxjMw5X0UMeyiH/W6mijrl2JYh3LFICKdDkvB
mp1g2wdYM/1m3VqtXvARTI93n3qny3UZSPihN5Ufaiv6w93aLSyZrEqbUJ0GJYvPrDOdCh3rjrmh
KejLTBStLKYIKr4FMFVOVf5kG/+jOd4ZJD6V1s4/9XdbhpjIpBkCIxdQzRXceS2RpERUYjxTw9W6
iQ2DAH8NO8X5Q6b+zUPrMkirkcLu/bqXHi8W8araUPTkymSSWU1JDVOJ/hydYPy+Ye5wVZj2oZB0
ywVMG8z/v0QAPN96xfMOC/+SLCw6J2aS34tv57FfMk0MldxxanO0YPuxn4a2Ett3nzQVSNDtl2CW
qY/xFHlAyMGhpZsmeWca9AdtFuilYG9cIG58/bIYJ0cwSaguwm6/USedJ0ZWIxoy38oyql1gOskf
KXkdwBLZKqJHOyEvZV3bIsTyArxSaTMpgPhEBUSfNmYobEoEghGwVNOSq+/eCpJ5Xdv9TGS9EJd5
TWBh1vfyInv3g9CQYmJPRuWIg/y861JIBjTDK+U5hVg8AgQVvUgBjI/WZQLa3pCcCSngd9U4LYvl
uYyERiT/wMufukyr4kA7KW5bIn/0gL+7NEW6Iu7d2y+s8piHEwSYq5eDbgJZVLpNBG1Ut1DXNSTr
PRQiRoxygNgnEY6lCabiWMFl0eyFjaDiE487lMzeGogf9EdXrbGxpP+hxwee103lCP44pbdpye3q
RUlKzlmrXvXUSoKeM6MR/zkE+jcXY388tTZB657KFRullRdSpymRs9MptAXT/FBLubOxVMw5flbB
r5hhRFCg+KFA7s7grSLCewQ5Q6jC4RelPI4dWr3yrjbMgnIRY24tOMdFl8eQY/FNPQomAX1mqoCX
DvyrjUgQUIehfkjuQlztCE77Ea1zkjn2821fGNUQdzM1lyVeixz7ZNrqTq1kXTF2FdbQU6lMWsnn
zB/89FRWXPS5Krwsu1QLWlxL1pa8tesmfBXBz0==