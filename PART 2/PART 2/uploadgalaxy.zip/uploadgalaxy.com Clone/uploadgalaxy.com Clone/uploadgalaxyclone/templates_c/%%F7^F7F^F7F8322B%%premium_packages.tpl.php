<?php /* Smarty version 2.6.6, created on 2006-03-11 10:59:07
         compiled from premium_packages.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'cycle', 'premium_packages.tpl', 24, false),)), $this); ?>
<table border="0" width="100%" height="62" cellspacing="0" cellpadding="0">
  <tr>
    <td width="104%" colspan="4" height="31">
      <p align="left"><b><font size="2">Premium Membership Packages</font></b></p>
    </td>
  </tr>
  <tr bgcolor="#DDDDDD">
    <td width="25%" height=30>
      <p align="left"><font color="#003366"><b>&nbsp;Package</b></font></p>
    </td>
    <td width="25%">
      <p align="left"><font color="#003366"><b>Duration</b></font></p>
    </td>
    <td width="25%">
      <p align="left"><font color="#003366"><b>Price</b></font></p>
    </td>
    <td width="25%">
      <p align="left"><font color="#003366"><b>Buy Now</b></font></p>
    </td>
  </tr>
  <tr><td colspan=4 width=1 bgcolor="#BBBBBB"> </td> </tr>
<!---------------------------------------------------------------------------->  
<?php unset($this->_sections['i']);
$this->_sections['i']['name'] = 'i';
$this->_sections['i']['loop'] = is_array($_loop=$this->_tpl_vars['pac']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['i']['show'] = true;
$this->_sections['i']['max'] = $this->_sections['i']['loop'];
$this->_sections['i']['step'] = 1;
$this->_sections['i']['start'] = $this->_sections['i']['step'] > 0 ? 0 : $this->_sections['i']['loop']-1;
if ($this->_sections['i']['show']) {
    $this->_sections['i']['total'] = $this->_sections['i']['loop'];
    if ($this->_sections['i']['total'] == 0)
        $this->_sections['i']['show'] = false;
} else
    $this->_sections['i']['total'] = 0;
if ($this->_sections['i']['show']):

            for ($this->_sections['i']['index'] = $this->_sections['i']['start'], $this->_sections['i']['iteration'] = 1;
                 $this->_sections['i']['iteration'] <= $this->_sections['i']['total'];
                 $this->_sections['i']['index'] += $this->_sections['i']['step'], $this->_sections['i']['iteration']++):
$this->_sections['i']['rownum'] = $this->_sections['i']['iteration'];
$this->_sections['i']['index_prev'] = $this->_sections['i']['index'] - $this->_sections['i']['step'];
$this->_sections['i']['index_next'] = $this->_sections['i']['index'] + $this->_sections['i']['step'];
$this->_sections['i']['first']      = ($this->_sections['i']['iteration'] == 1);
$this->_sections['i']['last']       = ($this->_sections['i']['iteration'] == $this->_sections['i']['total']);
?>
  <tr bgcolor=<?php echo smarty_function_cycle(array('values' => "#EFEFEF,#DFDFDF"), $this);?>
>
    <td width="25%" valign=middle>
      <p align="left">&nbsp;<font color="#3366CC"><?php echo $this->_tpl_vars['pac'][$this->_sections['i']['index']]['pacname']; ?>
</font></p>
    </td>
    <?php if ($this->_tpl_vars['pac'][$this->_sections['i']['index']]['pactime']): ?>
    <td width="25%" valign=middle>
      <p align="left"><font color="#3366CC"><?php echo $this->_tpl_vars['pac'][$this->_sections['i']['index']]['pactime']; ?>
</font></p>
    </td>
    <?php else: ?>
    <td width="25%" valign=middle>
      <p align="left"><font color="#3366CC">Lifetime</font></p>
    </td>
    <?php endif; ?>
    <td width="25%" valign=middle>
      <p align="left"><font color="#3366CC"><?php echo $this->_tpl_vars['pac'][$this->_sections['i']['index']]['pacrate']; ?>
$</font></p>
    </td>    
    <!--------------------------------------------------->
    <td width="25%"  valign=middle>         
    <FORM name="_xclick" action=https://www.paypal.com/cgi-bin/webscr method=post target=_blank> 
      <input type="hidden" name="cmd" value="_xclick">
      <INPUT type="hidden" name="business" value="<?php echo $this->_tpl_vars['PAY_TO']; ?>
">  
      <INPUT type="hidden" name="item_name" value="<?php echo $this->_tpl_vars['pac'][$this->_sections['i']['index']]['pacname']; ?>
 premium membership">   
      <INPUT type="hidden" name="item_number" value=<?php echo $this->_tpl_vars['pac'][$this->_sections['i']['index']]['pid']; ?>
>  
      <INPUT type="hidden" name="amount" value=<?php echo $this->_tpl_vars['pac'][$this->_sections['i']['index']]['pacrate']; ?>
>  
      <INPUT type="hidden" name="no_note" value=1>  
      <INPUT type="hidden" name="no_shipping" value=1>   
      <INPUT type="hidden" name="currency_code" value="USD"> <!--  
      <INPUT type="hidden" name="return"  value="<?php echo $this->_tpl_vars['RET_PATH']; ?>
">
      <input type="hidden" name="cancel_return" value="<?php echo $this->_tpl_vars['CAN_RET_PATH']; ?>
"> -->
      <INPUT type="image" alt="Buy Now" src="https://www.sandbox.paypal.com/en_US/i/btn/x-click-but23.gif" border=0 name=submit style="float: left">   
    </FORM> 
	<!--------------------------------------------------->   
    </td>
  </tr>
  <tr><td colspan=4 width=1 bgcolor="#BBBBBB"> </td> </tr>
<?php endfor; endif; ?>  
<!---------------------------------------------------------------------------->    
</table>