<?PHP
/* This will analyze tables of osdate installation */

require_once('../init.php');

include_once('sessioninc.php');

$tables = array();

$result = $db->getAll( "show tables" );

foreach (array_values($result) as $table_exist) {
	foreach ($table_exist as $k => $tablename) {
		echo("Optimizing table ".$tablename."<br />"); flush();
		$db->query('analyze table '.$tablename);
	}
}
?>