<link href="<?php echo("$path");?>stat.css" rel="stylesheet" type="text/css" /> 

<div id="topA">
<div id="stats"><?php echo("$s_link $s_categ"); ?></div>

<a href="<?php echo("$path");?>"><?php echo("$lang_11");?></a>
<a href="<?php echo("$path");?>new-links.php"><?php echo("$lang_12");?></a>

<?php if($p_top == 'Y') { ?> 
	<a href="<?php echo("$path");?>links.php"><?php echo("$lang_13");?></a>
<?php } else {} ?>

<a href="<?php echo("$path");?>submit.php?su_categ=<?php echo("$su_categ");?>"><?php echo("$lang_14");?></a>
<a href="<?php echo("$path");?>contact.php"><?php echo("$lang_15");?></a>

<?php if($p_terms == 'Y') { ?> 
	<a href="<?php echo("$path");?>terms.php"><?php echo("$lang_16");?></a>
<?php } else {} ?>

<?php if($p_about == 'Y') { ?> 
	<a href="<?php echo("$path");?>about.php"><?php echo("$lang_80");?></a>
<?php } else {} ?>
<a href="<?php echo("$path");?>tags/"><?php echo("$lang_181");?></a>

</div>
<div id="top">
  <div id="tLeft"><a href="<?php echo $row_top_BID['site']; ?>" target="_blank" title="<?php echo $row_top_BID['title']; ?>"><img src="http://open.thumbshots.org/image.aspx?url=<?php echo $row_top_BID['site']; ?>" alt="<?php echo $row_top_BID['title']; ?>" border="0" style="height:90px; width:120px; margin:0 0 3px 0;" /></a><br />
    <strong><?php echo("$lang_17");?></strong> <br />
    <br />
    <a href="<?php echo $row_top_BID['site']; ?>" target='_blank'><?php echo $row_top_BID['title']; ?></a></div>
  <div id="m_top"> <!--<br /><br /> -->
<?php //echo("$cse_main");?>
    <div align="center"><br />
      <br />
      <div id="search2">
        <form name="form1sea" id="form1sea" method="post" action="<?php echo("$path");?>search.php">
          <input name="q" type="text" id="q" onfocus="this.value='';" value=" <?php echo("$lang_19");?>" size="40" />
          <input type="submit" name="button" id="button" value="<?php echo("$lang_20");?>" />
        </form>
      </div>
    <br /></div>
  </div>
<a href="<?php echo("$path");?>" title="Welcome to <?php echo("$sitetitle");?>!"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/lbs_logo.png" alt="Welcome to <?php echo("$sitetitle");?>!" border="0" /></a>
</div>
<div id="topB">
<?php
if($alphacat == 'Y') { ?>
<a href="<?php echo("$path");?>0-9.html">#</a><a href="<?php echo("$path");?>A.html">A</a><a href="<?php echo("$path");?>B.html">B</a><a href="<?php echo("$path");?>C.html">C</a><a href="<?php echo("$path");?>D.html">D</a><a href="<?php echo("$path");?>E.html">E</a><a href="<?php echo("$path");?>F.html">F</a><a href="<?php echo("$path");?>G.html">G</a><a href="<?php echo("$path");?>H.html">H</a><a href="<?php echo("$path");?>I.html">I</a><a href="<?php echo("$path");?>J.html">J</a><a href="<?php echo("$path");?>K.html">K</a><a href="<?php echo("$path");?>L.html">L</a><a href="<?php echo("$path");?>M.html">M</a><a href="<?php echo("$path");?>N.html">N</a><a href="<?php echo("$path");?>O.html">O</a><a href="<?php echo("$path");?>P.html">P</a><a href="<?php echo("$path");?>Q.html">Q</a><a href="<?php echo("$path");?>R.html">R</a><a href="<?php echo("$path");?>S.html">S</a><a href="<?php echo("$path");?>T.html">T</a><a href="<?php echo("$path");?>U.html">U</a><a href="<?php echo("$path");?>V.html">V</a><a href="<?php echo("$path");?>W.html">W</a><a href="<?php echo("$path");?>X.html">X</a><a href="<?php echo("$path");?>Y.html">Y</a><a href="<?php echo("$path");?>Z.html">Z</a>
<?php }
elseif($alphacat == 'N') { ?>
<?php }
else { ?>
<a href="<?php echo("$path");?>0-9.html">#</a><a href="<?php echo("$path");?>A.html">A</a><a href="<?php echo("$path");?>B.html">B</a><a href="<?php echo("$path");?>C.html">C</a><a href="<?php echo("$path");?>D.html">D</a><a href="<?php echo("$path");?>E.html">E</a><a href="<?php echo("$path");?>F.html">F</a><a href="<?php echo("$path");?>G.html">G</a><a href="<?php echo("$path");?>H.html">H</a><a href="<?php echo("$path");?>I.html">I</a><a href="<?php echo("$path");?>J.html">J</a><a href="<?php echo("$path");?>K.html">K</a><a href="<?php echo("$path");?>L.html">L</a><a href="<?php echo("$path");?>M.html">M</a><a href="<?php echo("$path");?>N.html">N</a><a href="<?php echo("$path");?>O.html">O</a><a href="<?php echo("$path");?>P.html">P</a><a href="<?php echo("$path");?>Q.html">Q</a><a href="<?php echo("$path");?>R.html">R</a><a href="<?php echo("$path");?>S.html">S</a><a href="<?php echo("$path");?>T.html">T</a><a href="<?php echo("$path");?>U.html">U</a><a href="<?php echo("$path");?>V.html">V</a><a href="<?php echo("$path");?>W.html">W</a><a href="<?php echo("$path");?>X.html">X</a><a href="<?php echo("$path");?>Y.html">Y</a><a href="<?php echo("$path");?>Z.html">Z</a>
<?php } ?>
</div>
<div id="middle">
  <div id="advert"><?php echo("$adsensecode");?></div>
  
<div id="Left">

  
  <div id="nav">
    <?php if($nocat <> 'Y') { include('template/lbs/b_subcategory.php'); } else {} ?>

<ul>   
	<?php do { ?>
		<li><a href="<?php echo("$path");?><?php echo $row_categRL['categseoname']; ?>/"><?php echo $row_categRL['categoryname']; ?></a></li>
	<?php
	$row_categRL = mysql_fetch_assoc($categRL);
	if (!isset($nested_categRL)) { $nested_categRL= 1; }
	} while ($row_categRL);
	?>

		<li><a href="<?php echo("$path");?>contact.php"><?php echo("$lang_21");?></a></li>
</ul>
</div>
</div>