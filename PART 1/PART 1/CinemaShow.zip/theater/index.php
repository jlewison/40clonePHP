<?php
define('MOVIE_PATH', dirname(realpath(__FILE__)) . DIRECTORY_SEPARATOR);
define('CACHE_PATH', MOVIE_PATH.'cache'.DIRECTORY_SEPARATOR);
require_once('includes/movies.inc.php');
require_once('libs/smarty/Smarty.class.php');

global $smarty;
$smarty = new Smarty();
$smarty->caching = 1;
$smarty->cache_lifetime = 21600; // 6hr
$smarty->configs_dir = MOVIE_PATH.'libs/Smarty/configs';
$smarty->template_dir = MOVIE_PATH.'templates';
$smarty->compile_dir = CACHE_PATH.'smarty_compiled';
$smarty->cache_dir = CACHE_PATH.'smarty_cached';

ini_set('session.save_path', CACHE_PATH.'sessions');

global $data;
if (isset($_REQUEST['date'])) {
	$date = $_REQUEST['date'];
} else {
	$date = date('Y-m-d');
}

if (isset($_REQUEST['location'])) {
	$location = $_REQUEST['location'];
	setcookie('stored_location', $location, time()+60*60*24*365);
} else if (isset($_COOKIE['stored_location'])) {
	$location = $_COOKIE['stored_location'];
} else {
	$location = 55555;
}
if (!$smarty->is_cached('index.tpl', "{$location}|{$date}")) {
	if (is_numeric($location)) {
		$data = PerformancesByPostalCodeSearch($location,$date);
	} else {
		list($city,$state) = explode(',',$location);
		$data = PerformancesByCityStateSearch(urlencode(trim($city)),strtoupper(trim($state)),$date);
	}
	
	if (!isset($data->theaters)) {
		$smarty->assign('notFound', true);
	}
	
	$smarty->assign('host', 'http://'.$_SERVER['HTTP_HOST']);
	$smarty->assign('data', $data);
	$smarty->assign('date', $date);
	$smarty->assign('dates', GetDates());
}
$smarty->display('index.tpl', "{$location}|{$date}");