<?php
/**
 * Edit Profile Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 02/01/2008
 */
class EditProfile extends Controller
{
		//Constructor
		function EditProfile()
		{
				parent::Controller();
				//check login
				if ($this->session->userdata('logged_in') != 1 && $this->session->userdata('user_id') == '') redirect('home');
				$this->load->model('usermodel');
		}
		function index()
		{
				if ($this->uri->segment(2) == '') redirect('editProfile/basic');
				$this->smartyextended->view('editProfile');
		}
		#***************************************************************************
		#Method			: basic
		#Description	: fetches basic profile details from profile_basic table.
		#				  Inserts and updates basic profile details into the table.
		#Author			
		#***************************************************************************
		function basic()
		{
				$outputData['editprofile_type'] = 1;
				$this->lang->load('editProfileBasic', $this->config->item('language_code'));
				$birthday_visibility = $this->usermodel->getBirthdayVisibility();
				$relegiousView = $this->usermodel->getReligiousViews();
				$relation = $this->usermodel->getRelationStatus();
				$looking_for = $this->usermodel->getLookingFor();
				$userDetails = $this->usermodel->getUserDetails($this->session->userdata('user_id'));
				$birthday = $userDetails[$this->session->userdata('user_id')]['birthday'];
				$political_views = $this->usermodel->getPoliticalViews();
				$outputData['insert'] = false;
				$outputData['successMsg'] = '';
				$basicProfile = $this->usermodel->getBasicProfile();
				if (isset($_POST) && $_POST)
				{
						$datecheck = $this->_dateCheck();
						if ($datecheck)
						{
								if (!isset($_POST['interested_in'])) $_POST['interested_in'] = 'none';
								if (!isset($_POST['looking_for_id'])) $_POST['looking_for_id'] = array();
								else  $_POST['looking_for_id'] = array_keys($_POST['looking_for_id']);
								if ($basicProfile != false) $basic_profile_id = $basicProfile[0]['basic_profile_id'];
								else  $basic_profile_id = '';
								if (isset($_POST['interested_in_male']) && isset($_POST['interested_in_female'])) $_POST['interested_in'] = 'both';
								else
										if (!isset($_POST['interested_in_male']) && isset($_POST['interested_in_female'])) $_POST['interested_in'] = 'female';
										else
												if (isset($_POST['interested_in_male']) && !isset($_POST['interested_in_female'])) $_POST['interested_in'] = 'male';
								$this->usermodel->updateLookingForMap($_POST['looking_for_id'], $basic_profile_id);
								if ($_POST['profile_type']) $personalProfile = $this->usermodel->insertBasicProfile($_POST);
								else  $personalProfile = $this->usermodel->updateBasicProfile($_POST);
								$this->usermodel->updateLastModified();
								//Set the flash data
								$this->session->set_flashdata('successMsg', $this->lang->line('editprofilebasic_success_msg'));
								redirect('editProfile/basic');
						}
						else  $outputData['validationError'] = 'The date selected is not valid';
				}
				$outputData['sex'] = 1;
				$outputData['basic_profile_id'] = '';
				$outputData['birthday'] = $birthday;
				$outputData['relation_id'] = 1;
				$outputData['birthday_visibility_id'] = 1;
				$outputData['hometown'] = '';
				$outputData['looking_for_id'] = '';
				$outputData['political_id'] = 1;
				$outputData['interested_in'] = '';
				$outputData['relegious_view'] = '';
				$outputData['stateStatus'] = false;
				if ($basicProfile != false)
				{
						$outputData['sex'] = $basicProfile[0]['sex'];
						$outputData['basic_profile_id'] = $basicProfile[0]['basic_profile_id'];
						$outputData['relation_id'] = $basicProfile[0]['relation_id'];
						$outputData['birthday_visibility_id'] = $basicProfile[0]['birthday_visibility_id'];
						$outputData['hometown'] = $basicProfile[0]['hometown'];
						$outputData['political_id'] = $basicProfile[0]['political_id'];
						$outputData['interested_in'] = $basicProfile[0]['interested_in'];
						$outputData['religious_view'] = $basicProfile[0]['religious_view'];
				}
				else  $outputData['insert'] = true;
				$looking_for_map = $this->usermodel->getLookingForMap($outputData['basic_profile_id']);
				$outputData['looking_for_map'] = $looking_for_map;
				$outputData['relation'] = $relation;
				$outputData['relegiousViews'] = $relegiousView;
				$outputData['looking_for'] = $looking_for;
				$outputData['birthday_visibility'] = $birthday_visibility;
				$outputData['political_views'] = $political_views;
				$outputData['sex_options'] = array('' => $this->lang->line('editprofilebasic_select_sex'), 'male' => $this->lang->line('editprofilebasic_male'), 'female' => $this->lang->line('editprofilebasic_female'));
				$this->smartyextended->view('editProfile', $outputData);
		}
		#***************************************************************************
		#Method			: contact
		#Description	: fetches contact profile details from profile_contact table.
		#				  Inserts and updates contact profile details into the table.
		#Author			
		#***************************************************************************
		function contact()
		{
				$this->load->library('validation');
				$outputData['editprofile_type'] = 2;
				$this->lang->load('editProfileContact', $this->config->item('language_code'));
				$outputData['insert'] = false;
				$outputData['successMsg'] = '';
				$states = array();
				$country = $this->usermodel->getCountry();
				$privacy = $this->usermodel->getPrivacy();
				$messengers = $this->usermodel->getMessengers();
				$this->contactFrm();
				$outputData['userMessengers'] = $this->usermodel->getUserMessengers();
				$outputData['userMessengersCount'] = count($outputData['userMessengers']);
				$outputData['screensCount'] = ($outputData['userMessengersCount'] == 0) ? 1 : $outputData['userMessengersCount'] + 1;
				$outputData['screensCounts'] = ($outputData['userMessengersCount'] == 0) ? 1 : $outputData['userMessengersCount'];
				$outputData['userNetworks'] = $this->usermodel->getUserNetworks();
				//	$outputData['country']					=  1;
				//	$outputData['states']					=  1;
				$contactProfile = $this->usermodel->getContactProfile();
				$outputData['email'] = $this->session->userdata('email');
				$outputData['mobile'] = '';
				$outputData['land_line'] = '';
				$outputData['address'] = '';
				$outputData['city'] = '';
				$outputData['state_province'] = 1;
				$outputData['country'] = 1;
				$outputData['zip_code'] = '';
				$outputData['website'] = '';
				if ($this->validation->run() == false)
				{
						$outputData['validationError'] = $this->validation->error_string;
				}
				else
				{
						if (isset($_POST) && $_POST)
						{
								//if (isset($_POST['mobile'])) {
								//}
								if (!isset($_POST['state'])) $_POST['state'] = '';
								if ($_POST['profile_type']) $contactProfile = $this->usermodel->insertContactProfile($_POST);
								else  $contactProfile = $this->usermodel->updateContactProfile($_POST);
								//checks for screens updation and deletion
								if (!empty($_POST['screenId_edit']))
								{
										$remove_screen_ids = array_diff(array_keys($_POST['screenId_edit']), array_keys($_POST['screen_name_edit']));
										if (!empty($remove_screen_ids)) $this->usermodel->deleteScreens($remove_screen_ids);
										$edit_screen_ids = array_keys($_POST['screen_name_edit']);
										if (!empty($edit_screen_ids)) $this->usermodel->updateScreens($edit_screen_ids, $_POST['screenId_edit'], $_POST['screen_name_edit'], $_POST['messenger_id_edit']);
								}
								//checks for adding screens
								if (!empty($_POST['screenId'])) $this->usermodel->insertScreens($_POST['screenId'], $_POST['screen_name'], $_POST['messenger_id']);
								$this->usermodel->updateLastModified();
								//Set the flash data
								$this->session->set_flashdata('successMsg', $this->lang->line('editprofilecontact_success_msg'));
								redirect('editProfile/contact');
						}
				}
				if ($contactProfile != false)
				{
						$outputData['mobile'] = $contactProfile[0]['mobile'];
						$outputData['land_line'] = $contactProfile[0]['land_line'];
						$outputData['address'] = $contactProfile[0]['address'];
						$outputData['city'] = $contactProfile[0]['city'];
						$outputData['state_province'] = $contactProfile[0]['state_province'];
						$outputData['country'] = $contactProfile[0]['country'];
						$outputData['zip_code'] = $contactProfile[0]['zip_code'];
						$outputData['website'] = $contactProfile[0]['website'];
						$states = $this->usermodel->getStateList($outputData['country']);
				}
				else  $outputData['insert'] = true;
				$outputData['countryList'] = $country;
				$outputData['state'] = $states;
				if (!empty($states)) $outputData['stateStatus'] = true;
				//print_r($states); exit();
				$outputData['privacy'] = $privacy;
				$outputData['messengers'] = $messengers;
				$this->smartyextended->view('editProfile', $outputData);
		}
		function contactFrm()
		{
				$rules['mobile'] = 'trim|numeric';
				$rules['land_line'] = 'trim|numeric';
				$rules['zip_code'] = 'trim|alphanumeric';
				$rules['website'] = 'trim|valid_url';
				$fields['mobile'] = 'Mobile';
				$fields['land_line'] = 'Land line';
				$fields['zip_code'] = 'Zip code';
				$fields['website'] = 'website';
				$this->validation->set_rules($rules);
				$this->validation->set_fields($fields);
		}
		#***************************************************************************
		#Method			: personal
		#Description	: fetches personal profile details from profile_personal table.
		#				  Inserts and updates personal profile details into the table.
		#Author			
		#***************************************************************************
		function personal()
		{
				$this->lang->load('editProfilePersonal', $this->config->item('language_code'));
				$this->load->library('validation');
				$outputData['insert'] = false;
				$outputData['successMsg'] = '';
				if (isset($_POST) && $_POST)
				{
						if ($_POST['profile_type']) $personalProfile = $this->usermodel->insertPersonalProfile($_POST);
						else  $personalProfile = $this->usermodel->updatePersonalProfile($_POST);
						$this->usermodel->updateLastModified();
						$outputData['successMsg'] = $this->lang->line('editprofilepersonal_success_msg');
				}
				$outputData['editprofile_type'] = 3;
				$personalProfile = $this->usermodel->getPersonalProfile();
				$outputData['activities'] = '';
				$outputData['interests'] = '';
				$outputData['favorite_music'] = '';
				$outputData['favorite_tv_shows'] = '';
				$outputData['favorite_movies'] = '';
				$outputData['favorite_books'] = '';
				$outputData['favorite_quotes'] = '';
				$outputData['about_me'] = '';
				if ($personalProfile != false)
				{
						$outputData['activities'] = $personalProfile[0]['activities'];
						$outputData['interests'] = $personalProfile[0]['interests'];
						$outputData['favorite_music'] = $personalProfile[0]['favorite_music'];
						$outputData['favorite_tv_shows'] = $personalProfile[0]['favorite_tv_shows'];
						$outputData['favorite_movies'] = $personalProfile[0]['favorite_movies'];
						$outputData['favorite_books'] = $personalProfile[0]['favorite_books'];
						$outputData['favorite_quotes'] = $personalProfile[0]['favorite_quotes'];
						$outputData['about_me'] = $personalProfile[0]['about_me'];
				}
				else  $outputData['insert'] = true;
				$this->smartyextended->view('editProfile', $outputData);
		}
		#***************************************************************************
		#Method			: education
		#Description	: fetches education profile details from profile_education table.
		#				  Inserts and updates education profile details into the table.
		#Author			
		#***************************************************************************
		function education()
		{
				$outputData['editprofile_type'] = 4;
				$this->lang->load('editProfileEducation', $this->config->item('language_code'));
				$outputData['educationProfile'] = $this->usermodel->getEducationProfile();
				$outputData['schoolProfile'] = $this->usermodel->getHighSchool();
				//print_r($outputData['educationProfile']); exit();
				$outputData['educationProfileCount'] = count($outputData['educationProfile']);
				$outputData['schoolProfileCount'] = 0;
				$outputData['successMsg'] = '';
				if ($outputData['schoolProfile'] != false)
				{
						$outputData['schoolProfileCount'] = 1;
						$outputData['high_school'] = $outputData['schoolProfile'];
				}
				$attended_for = array('' => '', 'college' => $this->lang->line('editprofileeducation_attended_college'), 'gradschool' => $this->lang->line('editprofileeducation_attended_graduate'));
				$outputData['attended_for'] = $attended_for;
				$current_year = date('Y');
				$year_range = range($current_year - 80, $current_year);
				foreach ($year_range as $key => $val) $years[$val] = $val;
				$outputData['years'] = $years;
				if (isset($_POST) && $_POST)
				{
						if (isset($_POST['high_school']) && $_POST['high_school'])
						{
								if ($outputData['schoolProfileCount']) $this->usermodel->updateHighSchool($_POST['high_school']);
								else  $this->usermodel->insertHighSchool($_POST['high_school']);
						}
						if (!empty($_POST['educationId']))
						{
								$this->usermodel->insertEducationProfile($_POST);
						}
						if (!empty($_POST['educationId_edit']))
						{
								if (isset($_POST['attended_for_edit']))
								{
										$remove_education_id = array_diff(array_keys($_POST['educationId_edit']), array_keys($_POST['attended_for_edit']));
										$update_education_id = array_keys($_POST['attended_for_edit']);
										if (!empty($update_education_id)) $this->usermodel->updateEducationProfile($update_education_id, $_POST);
								}
								else  $remove_education_id = array_keys($_POST['educationId_edit']);
								if (!empty($remove_education_id)) $this->usermodel->deleteEducationProfile($remove_education_id);
						}
						$this->usermodel->updateLastModified();
						//Set the flash data
						$this->session->set_flashdata('successMsg', $this->lang->line('editprofileeducation_success_msg'));
						redirect('editProfile/education');
				}
				$this->smartyextended->view('editProfile', $outputData);
		}
		#***************************************************************************
		#Method			: work
		#Description	: fetches work profile details from profile_work table.
		#				  Inserts and updates work profile details into the table.
		#Author			
		#***************************************************************************
		function work()
		{
				$this->lang->load('editProfileWork', $this->config->item('language_code'));
				$states = array();
				$country = $this->usermodel->getCountry();
				$outputData['successMsg'] = '';
				$outputData['editprofile_type'] = 5;
				$months = array('01' => 'January', '02' => 'February', '03' => 'March', '04' => 'April', '05' => 'May', '06' => 'June', '07' => 'July', '08' => 'August', '09' => 'September', '10' => 'October', '11' => 'November', '12' => 'December');
				$current_month = date('m');
				$current_year = date('Y');
				if (isset($_POST) && $_POST)
				{
						$dateCheck = array();
						$date_check = '';
						//checks for work profile updation and deletion
						if (!empty($_POST['workId_edit']))
						{
								$work = $_POST['workId_edit'];
								foreach ($work as $key => $val)
								{
										$start_month = isset($_POST['start_month_edit'][$key]) ? $_POST['start_month_edit'][$key] : '';
										$start_year = isset($_POST['start_year_edit'][$key]) ? $_POST['start_year_edit'][$key] : '';
										$end_month = isset($_POST['end_month_edit'][$key]) ? $_POST['end_month_edit'][$key] : '';
										$end_year = isset($_POST['end_year_edit'][$key]) ? $_POST['end_year_edit'][$key] : '';
										$month = date('m');
										$year = date('Y');
										if ($start_year == $year)
										{
												if ($start_month < $month)
												{
												}
												else  $dateCheck[] = 0;
										}
										if (!isset($_POST['current_job'][$key]))
										{
												if ($end_month && $end_year)
												{
														if ($start_year <= $end_year)
														{
																if ($start_year == $end_year)
																{
																		if ($start_month < $end_month && $start_month < $month && $end_month <= $month)
																		{
																		}
																		else  $dateCheck[] = 0;
																}
																if ($end_year == $year)
																{
																		if ($end_month <= $month)
																		{
																		}
																		else  $dateCheck[] = 0;
																}
														}
														else  $dateCheck[] = 0;
												}
										}
								}
								$date_check = in_array(0, $dateCheck);
								if ($date_check == false)
								{
										if (!empty($_POST['start_year_edit'])) $remove_work_ids = array_diff(array_keys($_POST['workId_edit']), array_keys($_POST['start_year_edit']));
										else  $remove_work_ids = array_keys($_POST['workId_edit']);
										if (!empty($remove_work_ids)) $this->usermodel->deleteWorkProfile($remove_work_ids);
										if (!empty($_POST['start_year_edit']))
										{
												$edit_work_ids = array_keys($_POST['start_year_edit']);
												if (!empty($edit_work_ids)) $this->usermodel->updateWorkProfile($edit_work_ids, $_POST, $current_month, $current_year);
										}
								}
								else
								{
										$this->session->set_flashdata('errorMsg', 'Invalid date range');
										redirect('editProfile/work');
								}
						}
						//checks for adding work profile
						if (!empty($_POST['workId']))
						{
								$work = $_POST['workId'];
								foreach ($work as $key => $val)
								{
										$start_month = isset($_POST['start_month'][$key]) ? $_POST['start_month'][$key] : '';
										$start_year = isset($_POST['start_year'][$key]) ? $_POST['start_year'][$key] : '';
										$end_month = isset($_POST['end_month'][$key]) ? $_POST['end_month'][$key] : '';
										$end_year = isset($_POST['end_year'][$key]) ? $_POST['end_year'][$key] : '';
										$month = date('m');
										$year = date('Y');
										if ($start_year == $year)
										{
												if ($start_month < $month)
												{
												}
												else  $dateCheck[] = 0;
										}
										if (!isset($_POST['current_job'][$key]))
										{
												if ($end_month && $end_year)
												{
														if ($start_year <= $end_year)
														{
																if ($start_year == $end_year)
																{
																		if ($start_month < $end_month && $start_month < $month && $end_month <= $month)
																		{
																		}
																		else  $dateCheck[] = 0;
																}
																if ($end_year == $year)
																{
																		if ($end_month <= $month)
																		{
																		}
																		else  $dateCheck[] = 0;
																}
														}
														else  $dateCheck[] = 0;
												}
										}
								}
								$date_check = in_array(0, $dateCheck);
								if ($date_check == false) $this->usermodel->insertWorkProfile($_POST, $current_month, $current_year);
						}
						if ($date_check == false)
						{
								$this->usermodel->updateLastModified();
								//Set the flash data
								$this->session->set_flashdata('successMsg', $this->lang->line('editprofilework_success_msg'));
						}
						else  $this->session->set_flashdata('errorMsg', 'Invalid date range');
						redirect('editProfile/work');
				}
				$year_range = range($current_year - 80, $current_year);
				$outputData['months'] = $months;
				foreach ($year_range as $key => $val) $years[$val] = $val;
				$outputData['years'] = $years;
				$outputData['workProfile'] = $this->usermodel->getWorkProfile($work_id = '', $user_id = '');
				$outputData['workProfileCount'] = count($outputData['workProfile']);
				$outputData['employer'] = '';
				$outputData['position'] = '';
				$outputData['description'] = '';
				$outputData['city'] = '';
				$outputData['country'] = 1;
				$outputData['state_province'] = 1;
				$outputData['current_job'] = '';
				$outputData['job_type'] = '';
				$outputData['start_month'] = '';
				$outputData['start_year'] = '';
				$outputData['end_month'] = '';
				$outputData['end_year'] = '';
				$outputData['insert'] = false;
				if ($outputData['workProfileCount'] > 0)
				{
				}
				else  $outputData['insert'] = true;
				$outputData['countryList'] = $country;
				$states = $this->usermodel->getStateList($outputData['country']);
				$outputData['state'] = $states;
				if (!empty($states)) $outputData['stateStatus'] = true;
				$this->smartyextended->view('editProfile', $outputData);
		}
		function _dateCheck()
		{
				if (checkdate($this->input->post('birthday_Month'), $this->input->post('birthday_Day'), $this->input->post('birthday_Year')) == true)
				{
						$date = date('d');
						$month = date('m');
						$year = date('Y');
						if ($this->input->post('birthday_Year') <= $year)
						{
								if ($this->input->post('birthday_Year') == $year)
								{
										if (($this->input->post('birthday_Month') <= $month))
										{
												if ($this->input->post('birthday_Month') == $month)
												{
														if ($this->input->post('birthday_Day') < $date) return true;
														else  return false;
												}
												else  return true;
										}
										else  return false;
								}
								else  return true;
						}
						else  return false;
				}
				else  return false;
		}
		#***************************************************************************
		#Method			: picture
		#Description	: fetches picture profile details from profile_picture table.
		#				  Inserts and updates picture profile details into the table.
		#Author			
		#***************************************************************************
		function picture()
		{
				//Load the ImageTransform class
				$this->load->library('ImageTransform');
				$this->lang->load('editProfilePicture', $this->config->item('language_code'));
				$user_id = $this->session->userdata('user_id');
				$outputData['picture_width'] = '';
				$outputData['picture_height'] = '';
				$outputData['editprofile_type'] = 6;
				$outputData['validationError'] = '';
				$userDetails = $this->usermodel->getUserDetails($user_id);
				$outputData['avatar_ext'] = $userDetails[$user_id]['avatar_ext'];
				$outputData['user_id'] = $user_id;
				$outputData['random_no'] = rand(100, 200);
				$outputData['remove_show'] = true;
				//print BASEPATH . 'content/profiles/' . $user_id .  $this->session->userdata('avatar_ext').''; exit();
				if (!file_exists(APPPATH . 'content/profiles/' . $user_id . '_medium' . $outputData['avatar_ext'])) $outputData['remove_show'] = false;
				else
				{
						$fileresolution = getimagesize(APPPATH . 'content/profiles/' . $user_id . '_medium' . $outputData['avatar_ext']);
						$outputData['picture_width'] = $fileresolution[0];
						$outputData['picture_height'] = $fileresolution[1];
				}
				if (isset($_POST) && $_POST)
				{
						if (isset($_POST['certify']))
						{
								//$imageSize = getimagesize($_FILES['avatar']['tmp_name']);
								if ($_FILES['avatar']['name'] != '' && $_FILES['avatar']['size'] > 0)
								{
										//if (($imageSize[0] >= 50) || ($imageSize[1] >= 50))
										//{
										$fileNameArr = explode('.', $_FILES['avatar']['name']);
										$file_extension = strtolower($fileNameArr[count($fileNameArr) - 1]);
										if ($file_extension == 'jpg' || $file_extension == 'gif' || $file_extension == 'png')
										{
												$destination_path = BASEPATH . '../application/content/profiles/';
												$destination_file = $destination_path . $user_id . '.' . $file_extension;
												$destination_medium_file = $destination_path . $user_id . '_medium.' . $file_extension;
												$destination_thumb_file = $destination_path . $user_id . '_thumb.' . $file_extension;
												$destination_picture_file = $destination_path . $user_id . '_profile.' . $file_extension;
												if (file_exists($destination_path . $user_id . $outputData['avatar_ext'])) unlink($destination_path . $user_id . $outputData['avatar_ext']);
												if (file_exists($destination_path . $user_id . '_medium' . $outputData['avatar_ext'])) unlink($destination_path . $user_id . '_medium' . $outputData['avatar_ext']);
												if (file_exists($destination_path . $user_id . '_thumb' . $outputData['avatar_ext'])) unlink($destination_path . $user_id . '_thumb' . $outputData['avatar_ext']);
												if (file_exists($destination_path . $user_id . '_profile' . $outputData['avatar_ext'])) unlink($destination_path . $user_id . '_profile' . $outputData['avatar_ext']);
												//original image creation process starts here
												if (move_uploaded_file($_FILES['avatar']['tmp_name'], $destination_file))
												{
														//original image creation process ends here
														//thumb image creation process starts here
														$this->imagetransform->sourceFile = $destination_file;
														$this->imagetransform->targetFile = $destination_path . $user_id . '_thumb.' . $file_extension;
														$this->imagetransform->resizeToWidth = $this->config->item('avatar_thumb_width');
														$this->imagetransform->resizeToHeight = $this->config->item('avatar_thumb_height');
														$this->imagetransform->resize();
														//thumb image creation process ends here
														//medium image creation process starts here
														$this->imagetransform->sourceFile = $destination_file;
														$this->imagetransform->targetFile = $destination_path . $user_id . '_medium.' . $file_extension;
														$this->imagetransform->resizeToWidth = $this->config->item('avatar_medium_width');
														$this->imagetransform->resizeToHeight = $this->config->item('avatar_medium_height');
														$this->imagetransform->resize();
														//medium image creation process ends here
														//profile image creation process starts here
														$this->imagetransform->sourceFile = $destination_file;
														$this->imagetransform->targetFile = $destination_path . $user_id . '_profile.' . $file_extension;
														$this->imagetransform->resizeToWidth = 178;
														$this->imagetransform->resizeToHeight = 180;
														$this->imagetransform->resize();
														//profile image creation process ends here
														$this->usermodel->updateAvatar('.' . $file_extension);
														$user_details = $this->usermodel->getUserDetails($user_id);
														$outputData['avatar_ext'] = $user_details[$user_id]['avatar_ext'];
														$this->usermodel->updateLastModified();
														//Set the flash data
														$this->session->set_flashdata('successMsg', $this->lang->line('editprofilepicture_success_msg'));
												}
												else  $this->session->set_flashdata('errorMsg', $this->lang->line('editprofilepicture_invalid_file'));
												redirect('editProfile/picture');
										}
										else  $outputData['validationError'] = $this->lang->line('editprofilepicture_upload_error');
										//}
										//else
										//	$outputData['validationError'] = $this->lang->line('editprofilepicture_upload_resolutionerror');
								}
								else  $outputData['validationError'] = $this->lang->line('editprofilepicture_upload_picture_error_msg');
						}
						else  $outputData['validationError'] = $this->lang->line('editprofilepicture_certify_error_msg');
				}
				$dir_path = BASEPATH . '../application/content/profiles/';
				$file_dir = $dir_path;
				$this->smartyextended->view('editProfile', $outputData);
		}
		#***************************************************************************
		#Method			: getState
		#Description	: fetches the state list for the corresponding country.
		#Author			
		#***************************************************************************
		function getState()
		{
				$countrySymbol = $this->input->post('countrysymbol');
				$work_id = $this->input->post('work_id');
				$stateList = array();
				$states = $this->usermodel->getStateList($countrySymbol);
				if (!empty($states)) $stateList = $states;
				$workProfile = $this->usermodel->getWorkProfile($workid = '', $user_id = '');
				if ($work_id) echo json_encode(array('states' => $stateList, 'stateProvince' => $workProfile[$work_id]['state_province']));
				else  echo json_encode(array('states' => $stateList));
		}
		#***************************************************************************
		#Method			: deleteAvatar
		#Description	: Delets the avatar image.
		#Author			
		#***************************************************************************
		function deleteAvatar()
		{
				$user_id = $this->session->userdata('user_id');
				$userDetails = $this->usermodel->getUserDetails($user_id);
				$file_extension = $userDetails[$user_id]['avatar_ext'];
				$destination_path = BASEPATH . '../application/content/profiles/';
				$destination_file = $destination_path . $user_id . $file_extension;
				$destination_medium_file = $destination_path . $user_id . '_medium' . $file_extension;
				$destination_thumb_file = $destination_path . $user_id . '_thumb' . $file_extension;
				$destination_profile_file = $destination_path . $user_id . '_profile' . $file_extension;
				unlink($destination_file);
				unlink($destination_medium_file);
				unlink($destination_thumb_file);
				unlink($destination_profile_file);
				redirect('editProfile/picture');
		}
		function getTemplate()
		{
				$outputData['template'] = $this->input->post('template');
				$outputData['addCount'] = $this->input->post('countno');
				if ($outputData['template'] == 'work')
				{
						$this->lang->load('editProfileWork', $this->config->item('language_code'));
						$months = array('01' => 'January', '02' => 'February', '03' => 'March', '04' => 'April', '05' => 'May', '06' => 'June', '07' => 'July', '08' => 'August', '09' => 'September', '10' => 'October', '11' => 'November', '12' => 'December');
						$current_month = date('m');
						$current_year = date('Y');
						$year_range = range($current_year - 80, $current_year);
						$outputData['months'] = $months;
						foreach ($year_range as $key => $val) $years[$val] = $val;
						$outputData['years'] = $years;
						$country = $this->usermodel->getCountry();
						$outputData['countryList'] = $country;
				}
				else
						if ($outputData['template'] == 'screen') $this->lang->load('editProfileContact', $this->config->item('language_code'));
						else
								if ($outputData['template'] == 'education')
								{
										$this->lang->load('editProfileEducation', $this->config->item('language_code'));
										$attended_for = array('' => '', 'college' => $this->lang->line('editprofileeducation_attended_college'), 'gradschool' => $this->lang->line('editprofileeducation_attended_graduate'));
										$outputData['attended_for'] = $attended_for;
										$current_year = date('Y');
										$year_range = range($current_year - 80, $current_year);
										foreach ($year_range as $key => $val) $years[$val] = $val;
										$outputData['years'] = $years;
								}
								else
										if ($outputData['template'] == 'concentration2') $this->lang->load('editProfileEducation', $this->config->item('language_code'));
										else
												if ($outputData['template'] == 'concentration3') $this->lang->load('editProfileEducation', $this->config->item('language_code'));
				$outputData['messengers'] = $this->usermodel->getMessengers();
				$templateContent = $this->smartyextended->view('editprofileajax', $outputData, true);
				echo json_encode(array('template' => $templateContent));
		}
}
?>