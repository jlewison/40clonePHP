<?php
require_once ('./common/config.inc.php');
$CFG['lang']['include_files'][] = 'includes/languages/' . $CFG['lang']['default'] . '/help.php';
$CFG['mods']['include_files'][] = 'common/languages/' . $CFG['lang']['default'] . '/help.inc.php';
$CFG['auth']['is_authenticate'] = false;
$CFG['html']['header'] = 'members/includes/languages/' . $CFG['lang']['default'] . '/html_header_popup.php';
$CFG['html']['footer'] = 'members/includes/languages/' . $CFG['lang']['default'] . '/html_footer_popup.php';
require ($CFG['site']['project_path'] . 'common/application_top.inc.php');
?>
<div id="selHelp">
	<h2><?php echo $LANG['help_title']; ?></h2>
	<dl>
<?php
while (list($tip_key, $help_arr) = each($LANG['help']))
{
?>
		<dt><a name="<?php echo $tip_key; ?>"><?php echo $help_arr['text']; ?></a></dt>
		<dd><?php echo htmlspecialchars($help_arr['desc']); ?></dd>
<?php
}
?>
	</dl>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>