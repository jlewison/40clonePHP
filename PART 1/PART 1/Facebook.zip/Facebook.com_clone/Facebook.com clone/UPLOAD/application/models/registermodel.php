<?php

/**
 * Models that is used in the register page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 2007-12-14
 */
class Registermodel extends Model
{
		function Registermodel()
		{
				// Call the Model constructor
				parent::Model();
		}
		function getLifeStage()
		{
				$lifeStageQuery = $this->db->query('SELECT lifestage_id, content FROM lifestage ORDER BY lifestage_id');
				$lifeStages = array();
				if ($lifeStageQuery->num_rows() > 0)
				{
						foreach ($lifeStageQuery->result_array() as $lifeStageRow)
						{
								$lifeStages[$lifeStageRow['lifestage_id']] = $lifeStageRow['content'];
						}
				}
				return $lifeStages;
		}
		function getSchoolStatus()
		{
				$schoolStatusQuery = $this->db->query('SELECT school_status_id, status FROM school_status ORDER BY school_status_id');
				$schoolStatus = array();
				if ($schoolStatusQuery->num_rows() > 0)
				{
						foreach ($schoolStatusQuery->result_array() as $schoolStatusRow)
						{
								$schoolStatus[$schoolStatusRow['school_status_id']] = $schoolStatusRow['status'];
						}
				}
				return $schoolStatus;
		}
}

?>