<?php
//1155
$lang['ENCODING'] = 'iso-8859-9';
$lang['DIRECTION'] = 'ltr';
$lang['LEFT'] = 'sol';
$lang['RIGHT'] = 'sa�';
$lang['DISPLAY_DATE_FORMAT'] =  'd M, Y';
$lang['DISPLAY_DATETIME_FORMAT'] = 'D M-d-Y H:i:s';
$lang['DB_ERROR'] = "�ste�iniz database taraf�ndan ger�ekle�tirilemedi..<br>L�tfen tekrar deneyin.";
$lang['main_menu'] = 'Ana Men�';
$lang['homepage'] = 'Ana Sayfa';
$lang['rate_photos'] = 'Resmi De�erlendir';
$lang['forum'] = 'Forum';
$lang['manageforum'] = 'Forum Y�netimi';
$lang['chat'] = 'Chat';
$lang['managechat'] = 'Chat Y�netimi';
$lang['member_login'] = '�ye Giri�';
$lang['featured_members'] = '�zel �yeler';
$lang['quick_search'] = 'H�zl� Ara';
$lang['my_searches'] = 'Aramalar�m';
$lang['affiliates'] = 'Yay�nc�';
$lang['already_affiliate'] = 'Yay�nc� m�s�n?';
$lang['referals'] = 'G�nderenler';
$lang['title_colon'] = 'Ba�l�k:';
$lang['comments_colon'] = 'Yorumlar:';
$lang['feedback'] = 'Geribesleme';
$lang['profiles'] = 'Profiller';
$lang['profile_s'] = '\' Profili';
$lang['total_amt'] = 'Toplam Miktar';
$lang['banner_link'] = 'Banner/link';
$lang['clicks'] = 'T�klamalar';
$lang['finance_calc'] = 'Mali Hesap Makinas�';
$lang['flash_chat_msg'] = 'FlashChat 4.1.0 ve �st� osDate i�indedir.';
$lang['flash_chat_admin_msg'] = 'FlashChat 4.1.0 ve �st� osDate i�indedir.';
$lang['affiliate_head_msg'] = 'Yay�nc�m�z Olun';
$lang['affiliate_head_msg2'] = 'Bize Ziyaret�i g�nderenlere komisyon veriyoruz.<br/>';
$lang['affiliate_success_msg1'] = 'Yay�nc� Hesap id\'niz:';
$lang['affiliate_success_msg2'] = 'Yay�nc� hesab�n�za girebilirsiniz. ';
$lang['affiliate_login_title'] = "Yay�nc� Giri�";
$lang['password_changed_successfully'] = '�ifre De�i�tirildi.';
$lang['affiliate_registration_success'] = 'Yay�nc� Kayd� Tamam';
$lang['login_now'] = 'Buradan Gir';
$lang['must_be_valid'] = 'Ge�erli Olmal�';
$lang['characters'] = 'karakter';
$lang['email'] = 'E-mail:';
$lang['age'] = 'Ya�';
$lang['years'] = 'Y�l';
$lang['all_states'] = 'B�t�n Eyaletler';
$lang['welcome'] = 'Ho� Geldiniz';
$lang['admin_welcome'] = 'Ho� Geldiniz. <br /> Arka�l�k ve Evlilik <br />' . stripslashes('SITENAME') . '<br /> �dareci Paneli';
$lang['title'] = 'Ho� Geldiniz. ' . 'SITENAME';
$lang['success_stories'] = 'Ba�ar� Hikayeleri';
$lang['members_login'] = '�ye Giri�';
$lang['poll'] = 'Anket';
$lang['news'] = 'Haberler';
$lang['articles'] = 'Yaz�lar';
$lang['poll_result'] = 'Anket Sonucu';
$lang['view_poll_archive'] = '�nceki Anket';
$lang['member_panel'] = '�ye Paneli';
$lang['poll_errmsg1'] = 'Oy Vermi�siniz.';
$lang['close'] = 'Kapat';
$lang['all_stories'] = 'Hikayeler';
$lang['all_news'] = 'B�t�n Haberler';
$lang['more'] = 'devam�';
$lang['by'] = 'taraf�ndan';
$lang['dont_stay_alone'] = 'Arkada��n Olabilir,';
$lang['join_now_for_free'] = '�imdi �cretsiz �ye Ol.';
$lang['special_offer'] = '�zel Teklif!';
$lang['welcome_to'] = 'Ho� Geldiniz ';
$lang['welcome_to_site'] = 'Ho� Geldiniz.  ';
$lang['offer_text'] = ' ' . 'SITENAME' . ' Yeni interaktif arkada�l�k siteniz!<br><br>�stelik Tertemiz Bir Ortam. Yalan �yelikler yok.<br>Sadece biz var�z.<br><br>�ye Olarak Neler Yapabilirsiniz?<br><br>---Profilinizi yarat�p d�zenleyebilir. Resminizi ekleyebilirsiniz<br>---Ba�kalar�n�n profillerini inceleyebilirsiniz.<br>---�stedi�iniz kisiye �zel mesaj g�nderebilirsiniz.<br>---�zel mesajlar�n�z� mesaj kutunuzu d�zenleyebilirsiniz.<br>---Favori listenizi ve arkada� listenizi olu�turabilirsiniz.<br>---�yelerin resim galerilerini gezebilirsiniz.<br>---Chat yapabilirsiniz.---Forumda tak�labilirsiniz.<br>---�stediginiz ki�iye E-Kart g�nderebilirsiniz. Ve daha bir�o�u...<br><br>Yani Buras� tamamen interaktif bir ortam.Sizin Ortam�n�z.<br>Neden daha fazla bekliyorsunuz.<br>Hemen �ye olun.<br>Daha sonra arkada�lar�n�z� davet edin.Onlarda davet etsinler.<br>Boylece �ok geni� bir insan a�� olal�m.B�y�yelim. Ama hi� yalan �yelikler olmas�n Ortam daha da g�zelle�sin...<br><br>' . 'SITENAME' . '.com Y�netimi.';
$lang['newest_profiles'] = 'Yeni Profiller';
$lang['edit_profile'] = 'Profil D�zenle';
$lang['total_profiles'] = 'B�t�n Profiller';
$lang['forgot'] = 'Kay�p �ifre?';
$lang['hide'] = 'Gizle';
$lang['show'] = 'G�ster';
$lang['sex'] = 'T�r:';
$lang['sex_without_colon'] = 'T�r';
$lang['pageno'] = 'Sayfa ';
$lang['page'] = 'Sayfa';
$lang['previous'] = '�nceki';
$lang['next'] = 'Sonraki';
$lang['time_col'] = 'Saat:';
$lang['save_search'] = 'Aramay� Kay�t Et.';
$lang['find_your_match'] = 'E�ini Bul';
$lang['extended_search'] = 'Detayl� Ara';
$lang['matches_found'] = 'Bu profilleri e� se�imlerime ekle.';
$lang['timezone'] = 'Saat Zaman�:';
$lang['next_section'] = 'Sonraki B�l�m';
$lang['sign_in'] = '�ye Giri�i';
$lang['member_panel'] = '�ye Paneli';
$lang['aff_panel'] = 'Yay�nc� Paneli';
$lang['login_title'] = '�ye Giri� Alan�';
$lang['sign_out'] = '��k��';
$lang['login_submit'] = 'Giri�';
$lang['change_password'] = '�ifre de�i�tir';
$lang['old_password'] = 'eski �ifre:';
$lang['new_password'] = 'yeni �ifre:';
$lang['confirm_password'] = 'yeni �ifre tekrarla:';
$lang['password_change_msg'] = '�ifreniz De�i�ti.';
$lang['section_signup_title'] = 'Kay�t Bilgileri';
$lang['signup'] = '�ye Kay�t';
$lang['section_basic_title'] = 'Temel bilgiler';
$lang['section_appearance_title'] = 'D�� G�r�n��';
$lang['section_interests_title'] = 'Hobilerim';
$lang['section_lifestyle_title'] = 'Hayat Tarz�';
$lang['signup_subtitle_login'] = 'Giri� Bilgileri';
$lang['signup_subtitle_profile'] = 'Profilim';
$lang['signup_subtitle_address'] = 'Adres';
$lang['signup_subtitle_appearacnce'] = 'D�� G�r�n��';
$lang['signup_subtitle_preference'] = 'Arama �zellikleri';
$lang['signup_username'] = 'Kullan�c� Ad�:';
$lang['signup_password'] = '�ifre:';
$lang['signup_confirm_password'] = '�ifreyi Tekrarla:';
$lang['signup_firstname'] = '�sim:';
$lang['signup_lastname'] = 'Soyad�:';
$lang['signup_email'] = 'E-mail adresi:';
$lang['section_mypicture'] = 'Resimlerim';
$lang['upload'] = 'Y�kle';
$lang['upload_pictures'] = 'Resimleri D�zenle';
$lang['upload_format_msgs'] = 'Sadece .jpg - .gif - .bmp - .png formatlar�.';
$lang['thumbnail'] = 'K���k Resim';
$lang['picture'] = 'Resim';
$lang['signup_picture'] = 'Resmim';
$lang['signup_picture2'] = 'Resmim 2:';
$lang['signup_picture3'] = 'Resmim 3:';
$lang['signup_picture4'] = 'Resmim 4:';
$lang['signup_picture5'] = 'Resmim 5:';
$lang['signup_gender'] = 'Ben bir';
$lang['signup_pref_age_range'] = '�stedi�im Ya�';
$lang['signup_year_old'] = 'ya��nda';
$lang['signup_birthday'] = 'Do�um G�n�:';
$lang['signup_country'] = '�lke:';
$lang['signup_state_province'] = 'Eyalet';
$lang['signup_zip'] = 'Zip / Posta Kodu:';
$lang['signup_city'] = '�ehir / Y�re: ';
$lang['signup_address1'] = 'Adres 1:';
$lang['signup_address2'] = 'Adres 2:';
$lang['signup_height'] = 'Boy: ';
$lang['signup_feet'] = 'ayak';
$lang['signup_meter_inches'] = 'in� [ Amerika D���-Metre ]';
$lang['signup_weight'] = 'Kilo:';
$lang['signup_pounds'] = 'pound [ Amerika D���- KG ]';
$lang['signup_where_should_we_look'] = 'Nereden Oldu�um?';
$lang['signup_view_online'] = "Sitedeyken di�er �yeler beni g�rs�n?";
$lang['seeking'] = 'Arad���m';
$lang['looking_for_a'] = 'arad���m bir';
$lang['looking_for'] = 'Arad���m';
$lang['of'] = ' nin ';
$lang['to'] = ' ile ';
$lang['from'] = ' den ';
$lang['for'] = ' i�in ';
$lang['yes'] = 'Evet';
$lang['no'] = 'Hay�r';
$lang['cancel'] = '�ptal';
$lang['change'] = 'De�i�tir';
$lang['reset'] = 'S�f�rla';
$lang['required_info_indication'] = 'Bo� B�rakmay�n�z';
$lang['required_info_indicator'] = '* ';
$lang['required_info_indicator_color'] = 'red';
$lang['click_here'] = 'Buraya T�klay�n';
$lang['datetime_dayval']['Sun'] = 'Pzr';
$lang['datetime_dayval']['Mon'] = 'Pzt';
$lang['datetime_dayval']['Tue'] = 'Sal';
$lang['datetime_dayval']['Wed'] = '�ar';
$lang['datetime_dayval']['Thu'] = 'Per';
$lang['datetime_dayval']['Fri'] = 'Cum';
$lang['datetime_dayval']['Sat'] = 'Cts';
$lang['error_msg_color'] = 'red';
$lang['success_message'] = "Girdi�iniz bilgi kay�t edildi.<br>5 saniye i�inde siteye y�nlendiriliyorsunuz. Siteye gitmek i�in burayada t�klayabilirsiniz.";
$lang['sendletter_success'] = 'Mektup G�nderildi.';
$lang['admin_login_title'] = 'SITENAME' . ' Y�netici Paneli';
$lang['home_title'] = 'SITENAME' . ' anasayfa';
$lang['admin_login_msg'] = 'Y�netici Giri�';
$lang['admin_title_msg'] = 'SITENAME' . ' �dareci Paneli';
$lang['admin_panel'] = '�dareci Paneli';
$lang['back'] = 'Geri';
$lang['insert_msg'] = 'Yeni Mesaj Koy';
$lang['question_mark'] = '?';
$lang['id'] = 'Id:';
$lang['name'] = '�sim:';
$lang['name_col'] = '�sim';
$lang['enabled'] = 'A��k:';
$lang['action'] = 'Eylem';
$lang['edit'] = 'D�zenle';
$lang['delete'] = 'Sil';
$lang['section'] = 'B�l�m:';
$lang['insert_section'] = 'Yeni B�l�m Koy';
$lang['modify_section'] = 'B�l�m� D�zenle';
$lang['modify_sections'] = 'B�l�mleri D�zenle';
$lang['delete_section'] = 'B�l�m Sil';
$lang['delete_sections'] = 'B�l�mleri Sil';
$lang['enable_selected'] = 'A�';
$lang['disable_selected'] = 'Kapat';
$lang['change_selected'] = 'De�i�tir';
$lang['delete_selected'] = 'Sil';
$lang['no_select_msg'] = "Herhangi bir tercih yapmad�n�z. Taray�c�n�z�n geri tu�una bas�p bir veya birden fazla se�ene�i i�aretleyiniz.";
$lang['delete_confirm_msg'] = 'B�l�m� silmek istedi�inden emin misin?';
$lang['delete_group_confirm_msg'] = 'B�l�mleri silmek istedi�inden emin misin? D�n��� Yoktur..';
$lang['admin_error_color'] = 'red';
$lang['col_head_srno'] = '#';
$lang['col_head_id'] = 'Id';
$lang['col_head_question'] = 'Soru';
$lang['col_head_enabled'] = 'A��k';
$lang['col_head_name'] = '�sim';
$lang['col_head_username'] = 'Kullan�c� ad�';
$lang['col_head_firstname'] = '�sim';
$lang['col_head_lastname'] = 'Soyad�';
$lang['col_head_fullname'] = 'Tam isim';
$lang['col_head_status'] = 'Durum';
$lang['col_head_gender'] = 'T�r';
$lang['col_head_email'] = 'E-mail';
$lang['col_head_country'] = '�lke';
$lang['col_head_city'] = '�ehir';
$lang['col_head_zip'] = 'Posta Kodu';
$lang['col_head_register_at'] = 'Kay�t Tarihi';
$lang['section_title'] = 'B�l�m Y�netimi';
$lang['total_sections'] = 'B�t�n B�l�mler:';
$lang['profile_title'] = 'Profil Y�netimi';
$lang['total_profiles_found'] = 'profiller bulundu:';
$lang['modify_profile'] = 'Profil D�zelt';
$lang['profile_signup_title'] = 'Kay�t Bilgileri';
$lang['profile_basic_title'] = 'Temel Bilgiler';
$lang['profile_appearance_title'] = 'D�� G�r�n��';
$lang['profile_interests_title'] = 'Hobiler';
$lang['profile_lifestyle_title'] = 'Hayat tarz�';
$lang['profile_subtitle_login'] = 'Giri� Bilgileri';
$lang['profile_subtitle_profile'] = 'Profil';
$lang['profile_subtitle_address'] = 'Adres';
$lang['profile_subtitle_appearacnce'] = 'D�� G�r�n��';
$lang['profile_subtitle_preference'] = '�zellikler';
$lang['profile_delete_confirm_msg'] = 'Profili silmek istiyor musunuz?';
$lang['delete_profile'] = 'Profili Sil';
$lang['profile_username'] = 'Kullan�c� Ad�:';
$lang['profile_firstname'] = '�sim:';
$lang['profile_lastname'] = 'Soyad�:';
$lang['profile_email'] = 'E-mail adresi:';
$lang['profile_gender'] = 'T�r:';
$lang['profile_birthday'] = 'Do�um Tarihi:';
$lang['profile_country'] = '�lke:';
$lang['profile_state_province'] = 'Eyalet';
$lang['profile_zip'] = 'Zip / Posta Kodu:';
$lang['profile_city'] = '�ehir / Nereden';
$lang['profile_address1'] = 'Adres 1:';
$lang['profile_address2'] = 'Adres 2:';
$lang['find'] = 'Bul';
$lang['search'] = 'Ara';
$lang['AND'] = 'VE';
$lang['OR'] = 'YA DA';
$lang['order_by'] = 'D�zenleme: ';
$lang['sort_by'] = 'S�ralama ';
$lang['search_results'] = 'Arama Sonu�lar�';
$lang['no_record_found'] = 'Kay�t Bulunamad�.';
$lang['search_options'] = 'Arama Se�enekleri';
$lang['search_simple'] = 'Ara';
$lang['search_advance'] = 'Detayl� Ara';
$lang['search_advance_results'] = 'Detayl� Ara Sonu�lar�';
$lang['search_country'] = '�lkeden Ara';
$lang['search_states'] = 'Eyaletten Ara';
$lang['search_zip'] = 'Zip Kodu ile Ara';
$lang['search_city'] = '�ehirle Ara';
$lang['search_wildcard_msg'] = 'B�t�n kay�tlar� aramak i�in * kullanabilirsiniz.';
$lang['search_location'] = '<b>B�lgeye G�re Ara:</b>';
$lang['select_state'] = 'Eyalet:';
$lang['enter_city'] = '�ehir:';
$lang['enter_zip'] = 'Zip:';
$lang['enter_username'] = 'Kullan�c� Ad�:';
$lang['results_per_page'] = 'Sonu� Adedi';
$lang['search_results_per_page'] = array( 5 => 5 , 10 => 10, 20 => 20, 50 => 50, 100 => 100 );
$lang['order'] = 'D�zen';
$lang['up'] = 'Yukar�';
$lang['down'] = 'A�a��';
$lang['question'] = 'Soru:';
$lang['maxlength'] = 'En �ok Uzunluk:';
$lang['description'] = 'Tan�mlama:';
$lang['mandatory'] = 'Zorunlu:';
$lang['guideline'] = 'Ana Noktalar:';
$lang['control_type'] = 'G�sterim Kontrol�:';
$lang['include_extsearch'] = 'Geli�mi� aramada i�er:';
$lang['head_extsearch'] = 'Geli�mi� arama ba�l���:';
$lang['delete_question'] = 'Soru Sil';
$lang['modify_question'] = 'Soru D�zenle';
$lang['questions_title'] = 'Soru Y�netimi';
$lang['total_options'] = 'B�t�n Se�enekler:';
$lang['insert_question'] = 'Soru Gir';
$lang['total_questions'] = 'B�t�n Sorular:';
$lang['delete_questions'] = 'Sorular� Sil';
$lang['delete_group_questions_confirm_msg'] = 'Sorular� silecek misin?';
$lang['option'] = 'Se�enek';
$lang['answer'] = 'Cevap';
$lang['options_title'] = 'Soru Se�ene�i';
$lang['col_head_answer'] = 'Cevap';
$lang['with_selected'] = '��aretlenmi�ler ile';
$lang['ranging'] = 'S�rala';
$lang['instant_messenger'] = 'H�zl� Mesaj Panosu';
$lang['instant_message'] = 'An�nda Mesaj';
$lang['im_from'] = 'Kimden:';
$lang['im_message'] = 'Mesaj:';
$lang['im_reply'] = 'Yan�tla';
$lang['close_window'] = 'Kapat';
$lang['my_matches'] = 'Bana Uyanlar';
$lang['i_am_a'] = 'Ben bir';
$lang['Between'] = 'aras�nda';
$lang['who_is_from'] = 'Ya� aral���';
$lang['showing'] = 'G�sterim';
$lang['your_search_preferences'] = 'Ge�erli arama ayarlar�:';
$lang['to_edit_search_preferences'] = 'Arama �zelli�i d�zenle';
$lang['unapproved_user'] = 'Onay bekleyen profil';
$lang['gbl_settings'] = 'Sitenin Genel ayarlar�';
$lang['configurations'] = 'D�zenlemeler';
$lang['col_head_variable'] = 'De�i�ken';
$lang['col_head_value'] = 'De�er';
$lang['affiliate_title'] = 'Yay�nc� Y�netimi';
$lang['col_head_counter'] = 'Saya�';
$lang['col_head_status'] = 'Durum';
$lang['tell_later'] = 'Daha Sonra Doldurulacak';
$lang['view_profile'] = 'Profil G�ster';
$lang['view_profile_errmsg1']  = 'Kendi �zelliklerinizi ayarlamam��s�n�z.<br />L�tfen �nce Kendi profil detaylar�n�z� girin.<br />.';
$lang['view_profile_errmsg2'] = '<br>�zelliklerini �imdi ayarla.';
$lang['view_profile_errmsg3'] = 'Kullan�c� detaylar�n� girmemi�.';
$lang['view_profile_restricted'] = 'Bu k�s�tl� kullan�c�, g�r�nt�lenemiyor.';
$lang['profile_notset'] = 'Kullan�c� profili bulunamad�.';
$lang['send_mail'] = 'Mesaj G�nder';
$lang['mail_messages'] = 'Mesajlar';
$lang['col_head_subject'] = 'Konu';
$lang['col_head_sendtime'] = 'Tarih';
$lang['inbox'] = 'Gelen Kutusu';
$lang['sent'] = 'G�nder';
$lang['trashcan'] = '��p Kutusu';
$lang['reply'] = 'Yan�tla';
$lang['read'] = 'Oku';
$lang['unread'] = 'Okunmad�';
$lang['restore'] = 'Yenile';
$lang['subject'] = 'Konu';
$lang['subject_colon'] = 'Konu:';
$lang['message'] = 'Mesaj';
$lang['send'] = 'G�nder';
$lang['send_letter'] = 'Mektup G�nder';
$lang['image_browser'] = 'Resim G�sterici';
$lang['upload_image'] = 'Resim Y�kle';
$lang['delete_image'] = 'Resim sil';
$lang['show_image'] = 'Resmi G�ster';
$lang['send_invite'] = 'Davet G�nder';
$lang['letter_title'] = 'Yeni Mektup';
$lang['from_email'] = 'G�nderen Email:';
$lang['from_name'] = 'G�nderen �sim:';
$lang['send_to'] = 'G�nder';
$lang['email_subject'] = 'Konu:';
$lang['save_as'] = 'Farkl� Kaydet';
$lang['no_message'] = 'Gelen Kutusunda Mesaj Yok.';
$lang['descrip'] = 'Tan�mlama';
$lang['forgotpass_msg1'] = "�ifre Hat�rlat�c�";
$lang['forgotpass_msg2'] = "�lk kay�t olurken kulland���n�z e-mail adresinizi giriniz.";
$lang['retreieve_info'] = 'G�nder';
$lang['forgotpass'] = 'Kay�p �ifre';
$lang['tellafriend'] = 'Arkada��n� davet et';
$lang['taf_msg1'] = 'Arkada��n� davet et ' . 'SITENAME';
$lang['taf_yourname'] = '�sminiz:';
$lang['taf_youremail'] = 'E-mailiniz:';
$lang['taf_friendemail'] = "Arkada��n�z�n e-maili:";
$lang['confirm_your_profile'] = 'Kayd�n�z� onaylay�n';
$lang['letter_not_avail'] = 'Mektup template yok';
$lang['confirm_letter_sent'] = 'E-mail adresinize kayd�n�z� onaylaman�z i�in mesaj g�nderildi.L�tfen e-mail kutunuzu kontrol edin.';
$lang['letter_not_sent'] = 'E-mail g�nderirken problem oldu. L�tfen idarecilerle ba�lant� kurun.';
$lang['or'] = 'ya da';
$lang['enter_confirm_code'] = 'E-Mail Adresine gelen Aktivasyon kodunu buraya girip kayd�n�z� tamamlay�n.';
$lang['aff_email_subject'] = 'Reklam (affilitie) �yeli�inizi Do�rulay�n';
$lang['aff_email_body'] = '' . 'SITENAME' . 'ile reklam (affiliate) �yeli�i yaratt���n�z i�in te�ekk�rler. L�tfen i�lemi tamamlamak i�in bu adresi browser�n�z�n adres bar�na yaz�n:<br><br>#ConfirmationLink#';
$lang['manage_pages'] = 'Sayfa Y�netimi';
$lang['pagetitle'] = 'Ba�l�k:';
$lang['pagetext'] = 'Metin:';
$lang['pagekey'] = 'Anahtar:';
$lang['addpage'] = 'Sayfa Yap';
$lang['page'] = 'Sayfa';
$lang['addnew'] = 'Yeni';
$lang['modpage'] = 'Sayfa D�zenle';
$lang['pagekey_help'] = 'www.' . 'SITENAME' . '.com/index.php?page=YOUR_KEY';
$lang['y_o'] = 'y/o';
$lang['lastlogged'] = 'Son giri�: ';
$lang['aff_stats'] = 'Yay�nc� �statistikleri';
$lang['total_referrals'] = 'B�t�n Havale Edenler';
$lang['regis_referals'] = 'Kay�tl� Havaleler';
$lang['globalconfigurations'] = 'Genel ayarlamalar';
$lang['send_message_to'] = '�u kullan�c�ya mesaj g�nder';
$lang['writing_message'] = '�u kullan�c�ya mesaj yaz�l�yor ';
$lang['search_at'] = '�urda ara ';
$lang['rate_profile'] = 'Profile Puan Ver';
$lang['worst'] = 'K�t�';
$lang['excellent'] = 'M�kemmel';
$lang['rating'] = 'Puanlama';
$lang['submitrating'] = 'Puanlama �ner';
$lang['mship_changed'] = '�ye seviyesi de�i�ti';
$lang['mship_changed_successfull'] = '�yelik seviyeniz bedava oldu.';
$lang['no_payment'] = '�deme Gerekmiyor (Bedava �yelik ��in)';
$lang['payment_modules'] = '�deme Modulleri';
$lang['payment_methods'] = '�deme Metodlar�';
$lang['business'] = '��:';
$lang['siteid'] = 'Site Id:';
$lang['undefined_quantity'] = 'Tan�mlanmayan �zellik:';
$lang['no_shipping'] = 'Sevkiyat yok:';
$lang['no_note'] = 'Not yok:';
$lang['on_off_values'] = array( 1 => 'Evet', 0 => 'Hay�r' );
$lang['edit_payment_modules'] = '�deme Mod�l�n� D�zenle';
$lang['trans_key'] = '��lem Anahtar�:';
$lang['trans_mode'] = '��lem Modu:';
$lang['trans_method'] = '��lem Metotu:';
$lang['username'] = 'Kullan�c� Ad�:';
$lang['username_without_colon'] = 'Kullan�c� Ad�';
$lang['country'] = '�lke';
$lang['country_colon'] = '�lke:';
$lang['state'] = 'Eyalet';
$lang['city'] = '�ehir';
$lang['location_col'] = '�lke:';
$lang['location_no_col'] = '�lke';
$lang['zip_code'] = 'Posta Kodu';
$lang['attached_files'] = 'Eklenmi� Dosyalar';
$lang['cc_owner'] = 'Kredi Kart� Sahibi';
$lang['cc_number'] = 'Kredi Kart� Numaras�:';
$lang['cc_type'] = 'Kredi Kart� T�r�:';
$lang['cc_exp_date'] = 'Kredi Kart� Son Kullanma Tar:';
$lang['cc_cvv_number'] = 'Kredi Kart� Onay No,su:';
$lang['cvv_help'] = '(Kredi Kart�n�z�n Arka Y�z�ndeki Son �� Rakam)';
$lang['continue'] = 'Devam';
$lang['cc_unknown'] = 'Kredi kart� �irketi bilinmiyor. L�tfen ge�erli bir kredi kart� ile tekrar deneyin.';
$lang['cc_invalid_date'] = 'Kredi kart� son kullanma tarihi yanl��. L�tfen ge�erli bir kredi kart� ile tekrar deneyin.';
$lang['cc_invalid_number'] = 'Kredi kart� numaras� yanl��. L�tfen ge�erli bir kredi kart� ile tekrar deneyin.';
$lang['amount'] = 'Tutar:';
$lang['confirmation'] = 'Onaylama';
$lang['confirm'] = 'Onayla';
$lang['upgrade_membership'] = '�yelik Durumu';
$lang['changeto'] = 'De�i�tir';
$lang['current_mship_level'] = '�imdiki �yelik Durumu:';
$lang['membership_status'] = '�yelik Durumu';
$lang['you_currently'] = '�yelik Durumunuz : ';
$lang['info_confirm'] = 'Bilgileri Kontrol et';
$lang['change_mship_to'] = '�yeli�imi Bu Seviyede De�i�tir  ';
$lang['permitmsg_1'] = '�zg�n�m, �yelik seviyeniz i�ermiyor.';
$lang['permitmsg_2'] = 'Kullanabilmek i�in �yelik seviyenizi y�kseltiniz ';
$lang['permitmsg_3'] = '�yelik Seviyesi De�i�tirme Paneli';
$lang['permitmsg_4'] = '�yelik seviyesi kar��la�t�rma grafi�ini gizle';
$lang['membership_packages'] = '�yelik paketleri';
$lang['membership_packages_compare'] = '�yelik paketleri kar��la�t�rmas�';
$lang['modify'] = 'De�i�likleri kaydet';
$lang['manage_membership'] = '�yelik Y�netimi';
$lang['privileges_msg'] = 'Ayr�cal�kl�';
$lang['price'] = 'Fiyat: ';
$lang['currency'] = 'Nakit: ';
$lang['choose_membership'] = '�yelik kategorisi se�:';
$lang['add_membership'] = 'Yeni �yelik kategorisi';
$lang['membership_types'] = '�yelik tipleri';
$lang['member'] = '�ye';
$lang['select_letter'] = 'Mektup se�:';
$lang['body'] = '��erik:';
$lang['module'] = 'Mod�l';
$lang['uninstall'] = 'Kald�r';
$lang['install'] = 'Y�kle';
$lang['modify_option'] = 'Se�enek d�zenle';
$lang['only_jpg'] = 'Sadece JPG - GIF - PNG - BMP formatlar� olmal�.';
$lang['upload_unsuccessful'] = 'Resim y�klenemedi.';
$lang['upload_successful'] = 'Resim Y�klendi.';
$lang['between1'] = 'Aras�nda';
$lang['and'] = 've';
$lang['profile_details'] = 'Profil Detay';
$lang['personal_details'] = 'Ki�isel Detay';
$lang['manage_banners'] = 'Banner Y�netimi';
$lang['add_banners'] = 'Banner Ekle';
$lang['edit_banners'] = 'Banner D�zenle';
$lang['size'] = 'Boyut';
$lang['size_px'] = 'Boyut (piksel)';
$lang['banner_linkurl'] = 'Banner / Link URL';
$lang['banner_sizes_name'] = array( 'yatay', 'dikey', 'kare' );
$lang['startdate'] = 'Ba�lang�� G�n�:';
$lang['enddate'] = 'Biti� G�n�:';
$lang['tooltip'] = 'Yard�mc� not:';
$lang['linkurl'] = 'Link Url:';
$lang['banner'] = 'Banner:';
$lang['total_banner'] = 'B�t�n Bannerlar:';
$lang['online_users'] = 'Online �yeler: ';
$lang['site_statistics'] = '�statistikler';
$lang['pending_profiles'] = 'Ask�daki Profiller';
$lang['active_profiles'] = 'Aktif Profiller';
$lang['online_profiles'] = 'Online Profiller';
$lang['pending_aff'] = 'Ask�daki Yay�nc�lar';
$lang['total_affiliates'] = 'B�t�n Yay�nc�lar';
$lang['active_aff'] = 'Aktif Yay�nc�lar';
$lang['no_rating'] = 'Puanlanmad�.';
$lang['seo'] = 'SEO Ayarlar�';
$lang['seo_head'] = 'Arama Motoru Optimizasyonu';
$lang['sef_msg'] = 'Arama Motoru Uyumlu Adresler';
$lang['seo_enable'] = 'mod_rewrite kullan�l�yorsa URL yeniden Yaz�labilsin';
$lang['yes_msg'] ='URL rewriting Sadece Apache Web Server kullan�l�yorsa ve mod_rewrite A��ksa �al���r.\nL�tfen Servisinizin bu arg�manlar� tan�d���ndan emin olun.\nL�tfen .htaccess.txt dosyas�n� .htaccess. olarak de�i�tirmeyi unutmay�n';
$lang['keywords'] = 'Keywordlar:';
$lang['page_tags_msg'] = 'Sayfa Ba�l��� & Meta Taglar';
$lang['max_255'] = 'Maksimum 255 karakter';
$lang['manage_news'] = 'Haber Y�netimi';
$lang['manage_story'] = 'Hikaye Y�netimi';
$lang['manage_article'] = 'Yaz� Y�netimi';
$lang['news_header'] = 'Header';
$lang['total_news'] = 'B�t�n Haberler:';
$lang['total_articles'] = 'B�t�n Yaz�lar:';
$lang['total_stories'] = 'B�t�n hikayeler:';
$lang['article_title'] = 'Ba�l�k';
$lang['story_sender'] = 'G�nderici';
$lang['story_sender_msg'] = 'Profil Id [Digit]';
$lang['modify_article'] = 'Yaz� d�zenle';
$lang['modify_news'] = 'Haber d�zenle';
$lang['modify_story'] = 'Hikaye d�zenle';
$lang['insert_article'] = 'Yaz� gir';
$lang['insert_story'] = 'Hikaye gir';
$lang['insert_news'] = 'Haber gir';
$lang['dat'] = 'Tarih:';
$lang['manage_polls'] = 'Anket Y�netimi';
$lang['modify_poll'] = 'Anket d�zenle';
$lang['total_polls'] = 'B�t�n Anketler';
$lang['poll'] = 'Anket';
$lang['add_polls'] = 'Anket Gir';
$lang['add_options'] = 'Se�enek Gir';
$lang['active'] = 'Aktif';
$lang['activate'] = 'Aktifle�tir';
$lang['option'] = 'Se�enek';
$lang['modify_options'] = 'Senenekleri d�zenle';
$lang['add_option_now'] = 'Se�enek gir.';
$lang['poll_options'] = 'Anket se�enekleri';
$lang['votes'] = 'Oy(lar)';
$lang['first'] = '�lk';
$lang['last'] = 'Son';
$lang['filter_records'] = 'Kay�tlar� Filtrele';
$lang['search_at'] = '�urda Ara ';
$lang['criteria'] = 'Kriterler';
$lang['manage_admins'] = '�dareci y�netimi';
$lang['total_admins'] = 'Toplam �dareci';
$lang['add_admin'] = '�dareci Ekle';
$lang['modify_admin'] = '�dareci D�zenle';
$lang['fullname'] = 'Tam Ad�';
$lang['please_be_sure'] = 'L�tfen Emin Olun';
$lang['change_your_admin_pwd'] = 'idareci �ifrenizi de�i�tirin.';
$lang['superuser'] = 'S�per kullan�c�';
$lang['no_admin_user_msg1'] = 'S�per idareci yok. �nce yarat.';
$lang['no_admin_user_msg2'] = 'S�per idareci yarat';
$lang['access_denied'] = 'Eri�im Engellendi';
$lang['not_authorize'] = 'Bu sayfaya eri�meye yetkiniz yok. S�per y�neticinizle temasa ge�in';
$lang['admin_permissions'] = '�dareci �zinleri';
$lang['manage_admin_permissions'] = '�dareci izinleri y�netimi';
$lang['admin_users'] = '�dareci �yeler';
$lang['permissions'] = 'Mod�ller';
$lang['superuser_noteditable'] = 'Not: S�per kullan�c�(lar) d�zenlenemez';
$lang['all'] = 'Hepsi';
$lang['selected'] = 'Selected';
$lang['selected_users'] = 'Se�ilen Kullan�c�lar';
$lang['separate_users_by_coma'] = 'Kullan�c� adlar�n� aralar�nda virg�l kullanarak yaz�n.';
$lang['cntry_mgt']	= '�lke/B�lge/�ehir D�zenle';
$lang['register_now'] = '�ye De�il misin? �ye Ol.';
$lang['addtobuddylist'] = 'Arkada� Listesine Ekle';
$lang['addtobanlist'] = 'Engelleme Listesine Ekle';
$lang['addtohotlist'] = 'S�cak Listeye Ekle';
$lang['buddylisthdr'] = 'Arkada� Listesi';
$lang['banlisthdr'] = 'Banned Listesi';
$lang['hotlisthdr'] = 'S�cak Liste';
$lang['username_hdr'] = 'Kullan�c� Ad�';
$lang['fullname_hdr'] = 'Tam �sim';
$lang['register'] = '�ye Olun';
$lang['featured_profiles'] = 'Ayr�cal�kl� Profil';
$lang['bigger_pic_size'] = 'Foto�raf boyutu izin verilenden fazla :  '.$config['upload_snap_maxsize'].' KB.';
$lang['snaps_require_approval'] = 'Foto�raflar� Onayla';
$lang['events_require_approval'] = 'Olay Onayla';
$lang['upload_picture_caption'] = 'Ana Foto�raf';
$lang['upload_thumbnail_caption'] = 'K���k G�r�n�m: ';
$lang['Approve'] = 'Onayla';
$lang['Remove'] = 'Kald�r';
$lang['userdetails'] = '�ye Bilgileri';
$lang['pict'] = 'Foto�raf';
$lang['tnail'] = 'K���k G�r�n�m';
$lang['reqact'] = 'Se�ilen Eylem';
$lang['newmemberlist'] = 'Yeni �yeler';
$lang['yearsold'] = 'ya��nda';
$lang['Male'] = 'Erkek';
$lang['Female'] = 'Kad�n';
$lang['showfulllist'] = 'B�t�n Listeyi G�ster';
$lang['featuredprofiles'] = 'Ayr�cal�kl� Profil';
$lang['featured_profiles_hdr'] = 'Ayr�cal�kl� �yelerin Profilleri';
$lang['nonfeatured_profiles_hdr'] = 'Normal �yeler';
$lang['level_hdr'] = 'Seviye';
$lang['date_from'] = 'Ba�lang�� G�n�';
$lang['date_upto'] = 'G�ncel';
$lang['must_show'] = 'G�sterilmek Zorunda';
$lang['reqd_exposures'] = 'Gerekli Yerler';
$lang['total_exposures'] = 'B�t�n Yerler';
$lang['add_featured'] = 'Profili Ayr�cal�kl�ya kaydet';
$lang['mod_featured'] = 'Profili ayr�cal�kl� listesinde d�zenle';
$lang['member_since'] = '�u tarihten beri �ye';
$lang['invalid_username'] = 'Ge�ersiz Kullan�c� Ad�';
$lang['weekcnt'] = 'Son �ye Olanlar:';
$lang['totalgents'] = 'Erkek �yeler:';
$lang['totalfemales'] = 'Kad�n �yeler:';
$lang['weeksnaps'] = 'Son Resimler:';
$lang['since_last_login'] = 'Son Giri�ten beri';
$lang['sincelastlogin_hdr'] ='Son Giri� Tarihi >';
$lang['newmessages'] = 'Yeni Gelen Mesajlar';
$lang['profileviewed'] = 'Profilinizin Bak�lma Say�s�:';
$lang['winks_received'] = 'Ald���n�z G�l�c�kler:';
$lang['send_wink'] = 'G�l�c�k G�nder';
$lang['listofviews'] = 'Profilinizi izleyen �yeler';
$lang['listofwinks'] = 'G�l�c�k g�nderen �yeler';
$lang['winkslist'] = 'G�l�c�k listesi';
$lang['viewslist'] = 'G�r�nt�lenme Listesi';
$lang['suggest_poll'] = 'Bir Anket �ner';
$lang['savepoll'] = 'Anket ��le';
$lang['moreoptions'] = 'Fazla Se�enek';
$lang['minimum_options'] = 'En az iki se�enek';
$lang['pollsuggested'] = 'Anket �neriniz site y�neticilerine g�nderildi..Te�ekk�r Ederiz.';
$lang['suggested_by'] = '�neren:';
$lang['any_where'] = 'Her yer';
$lang['memberpanel'] = "�ye Ana sayfas�";
$lang['feedback_thanks'] = 'Mesaj�n�z Site Y�neticilerine G�nderildi.';
$lang['cancel_hdr'] = '�yeli�i �ptal Et';
$lang['cancel_txt01'] = '�yelik �ptali �stediniz... <b>'.'SITENAME'.'</b>.<br /><br />�ptal Edelim mi? ';
$lang['cancel_opt01'] = 'Evet Edelim';
$lang['cancel_opt02'] = '�imdi �stemiyorum, Sonra..';
$lang['cancel_domsg'] = 'Sitemizi kulland���n�z i�in Te�ekk�rler... '.'SITENAME'.'. <br /><br /> Art�k birlikte olamayaca��z,istedi�iniz zaman yeniden �ye olabilirsiniz.';
$lang['cancel_nomsg'] = 'Sitemizi kulland���n�z i�in Te�ekk�rler... '.'SITENAME'.'. <br /><br /> Size �ok te�ekk�r ederiz.';
$lang['reject'] = 'Red Et';
$lang['unread'] = 'Okunmad�';
$lang['membership_hdr'] = '�yelik Seviyesi';
$lang['edit_pict'] = 'Ana Foto�raflar� D�zenle';
$lang['edit_thmpnail'] = 'K���k G�r�n�mleri D�zenle';
$lang['letter_options'] = 'Mektup Se�enekleri';
$lang['pic_gallery'] = 'Resim Galerisi';
$lang['reactivate'] = 'Yeniden Aktif Yap';
$lang['cancel_list'] = '�ptal edilen �ye Listesi';
$lang['cancel_date'] = '�ptal Tarihi';
$lang['language_opt'] = 'Diller' ;
$lang['change_language'] = 'De�i�tir';
$lang['with_photo'] = 'Sadece Resimliler';
$lang['logintime'] = 'Oturum Zaman�';
$lang['manage_country_states'] = '�lke Eyaletlerini D�zenle';
$lang['manage_countries'] = '�ehir D�zenle';
$lang['countries_count'] = '�lke Say�s�';
$lang['insert_country'] = 'Yeni �lke Ekle';
$lang['modify_country'] = '�lke D�zenle';
$lang['country_code'] = '�lke Kodu';
$lang['country_name'] = '�lke �smi';
$lang['manage_states'] = 'Eyalet Y�net';
$lang['states_count'] = 'Eyalet Say�s�';
$lang['insert_state'] = 'Yeni Eyalet Ekle';
$lang['modify_state'] = 'Eyalet D�zenle';
$lang['state_code'] = 'Eyalet Kodu';
$lang['state_name'] = 'Eyalet �smi';
$lang['totalcouples'] = 'Toplam �ift �yeler:';
$lang['active_days'] = 'Ka� G�n Ge�erli?';
$lang['activedays_array'] = array('1'=>'1','7'=>'7','30'=>'30','90'=>'90','180'=>'180','365'=>'365');
$lang['expired'] = '�ye s�reniz doldu. <br /><br /><a href="payment.php" class="errors">�yeli�inizi yenileyin</a> '. 'SITENAME';
$lang['compose'] = 'Yarat-Yaz';
$lang['logout_login']='Siteden ��k�n ve yeniden girin!!';
$lang['makefeatured'] = 'As�l listeye profil eklemek i�in t�klay�n';
$lang['col_head_gender_short'] = 'T�r';
$lang['no_subject'] = 'Konu Yok';
$lang['admin_col_head_fullname'] = $lang['col_head_fullname'];
$lang['select_from_list'] = '--Se�in--';
$lang['default_tz'] = '0.00';
$lang['manage_counties'] = '�lke';
$lang['counties_count'] = '�lkeler Say�s�';
$lang['insert_county'] = 'Yeni �lke ekle';
$lang['modify_county'] = '�lke �zerinde de�i�iklik yap';
$lang['county_code'] = '�lke kodu';
$lang['county_name'] = '�lke Ad�';
$lang['manage_cities'] = '�ehirler';
$lang['cities_count'] = ' �ehirler Say�s�';
$lang['insert_city'] = 'Yeni �ehir Ekle';
$lang['modify_city'] = '�ehir �zerinde de�i�iklik yap';
$lang['city_code'] = '�ehir Kodu';
$lang['city_name'] = '�ehir Ad�';
$lang['manage_zips'] = 'Posta Kodu';
$lang['zips_count'] = 'Posta Kodlar� Say�s�';
$lang['insert_zip'] = 'Yeni posta kodu ekle';
$lang['modify_zip'] = 'Posta kodu �zerinde de�i�iklik yap';
$lang['zip_code'] = 'Posta Kodu';
$lang['show_form'] = 'Formu G�ster:';
$lang['change_album'] = 'G�ncelle';
$lang['your_user_stats'] = 'Sizin Kullan�c� �statistikleriniz';
$lang['other_user_stats'] = 'Di�er Kullan�c� �statistikleri';
$lang['user_stats'] = 'Kullan�c� �statistikleri';
$lang['users_match_your_search'] = 'Kriterlerinize uyan kullan�c�lar';
$lang['in_your_country'] = 'Sizinle ayn� �lkede ya�ayan kullan�c�lar';
$lang['in_your_state'] = 'Sizinle ayn� eyalette ya�ayan kullan�c�lar';
$lang['in_your_county'] = 'Sizinle ayn� �ehirde ya�ayan kullan�c�lar';
$lang['in_your_city'] = 'Sizinle ayn� il�ede ya�ayan kullan�c�lar';
$lang['in_your_zip'] = 'Posta kodunuz ayn� olan kullan�c�lar';
$lang['in_same_gender'] = 'Hemcinsleriniz';
$lang['in_same_age'] = 'Ya��tlar�n�z';
$lang['above_lookagestart'] = 'Arad���n�z ya� aral���ndaki kullan�c�lar';
$lang['below_lookageend'] = 'Arad���n�z ya� aral���n�n �zerindeki kullan�c�lar';
$lang['your_lookgender'] = 'Arad���n�z T�rden kullan�c�lar(Kad�n-Erkek-Grup)';
$lang['in_look_country'] = 'Arad���n�z �ehirde ya�ayan kullan�c�lar';
$lang['in_look_state'] = 'Arad���n�z eyalette ya�ayan kullan�c�lar';
$lang['in_look_county'] = 'Arad���n�z �lkede ya�ayan kullan�c�lar';
$lang['in_look_city'] = 'Arad���n�z il�ede ya�ayan kullan�c�lar';
$lang['in_look_zip'] = 'Arad���n�z posta kodundaki kullan�c�lar';
$lang['in_same_timezone'] = 'Sizinle ayn� Zaman dilimindeki kullan�c�lar';
$lang['album_hdr'] = 'Alb�m';
$lang['public'] = 'Genel';
$lang['calendar_admin'] = 'Y�netici Takvimi';
$lang['mysettings'] = 'Tercihlerim';
$lang['user_lists'] = 'Klas�rler';
$lang['login_settings'] = 'Giri� Tercihlerim';
$lang['no_pics'] = 'Foto�raf yok';
$lang['my_page'] = 'Benim Sayfam';
$lang['write_new_msg'] = 'Yeni Mesaj Yaz';
$lang['view_winkslist'] = 'G�z k�rpmalar� g�ster';
$lang['manage_import'] = 'Veri Taban� Aktar';
$lang['manage_import_datingpro'] = 'DatingPro dan aktar';
$lang['manage_import_aedating'] = 'aeDating den aktar';
$lang['manage_import_section'] = 'Aktarma Mod�l�n� Se�in';
$lang['manage_import_select'] = 'Ne Aktar�lmas� Gerekiyorsa Se�in';
$lang['module'] = 'Mod�l';
$lang['imported'] = 'Aktar�ld�';
$lang['import'] = 'Aktar';
$lang['empty'] = 'Bo�';
$lang['select_section'] = 'Soru ��in B�l�m Se�in';
$lang['import_db_configuration'] = 'Kaynak Veritaban� Konfig�rasyonunu Se�';
$lang['db_name'] = 'VT Ad�:';
$lang['db_host'] = 'VT Hostu:';
$lang['db_user'] = 'VT Kullan�c� Ad�:';
$lang['db_pass'] = 'VT Sifre:';
$lang['db_prefix'] = 'Tablo Ad�:';
$lang['calendar_title'] = 'Ajanda Y�netimi';
$lang['total_calendars'] = 'Toplam Ajanda:';
$lang['modify_calendar'] = 'Ajanda D�zenle';
$lang['modify_calendars'] = 'Ajandalar� D�zenle';
$lang['delete_calendar'] = 'Ajanda Sil';
$lang['delete_calendars'] = 'Ajandalar� Sil';
$lang['events_title'] = 'Olay Y�neticisi';
$lang['insert_event'] = 'Olay Ekle';
$lang['modify_event'] = 'Olay D�zenle';
$lang['total_events'] = 'Se�ilmi� Olaylar';
$lang['event'] = 'Olaylar:';
$lang['calendar_field'] = 'Ajanda:';
$lang['private_to'] = 'Ki�iye �zel:';
$lang['date_from'] = 'Ba�lang�� G�n�';
$lang['date_to'] = 'Biti� Tarihi:';
$lang['col_head_calendar'] = 'Ajanda';
$lang['col_head_username'] = 'Kullan�c� ad�';
$lang['col_head_fullname'] = 'Tam isim';
$lang['col_head_event'] = 'Olay';
$lang['col_head_datefrom'] = 'Ba�lang�� Tarihi';
$lang['col_head_dateto'] = 'Biti� Tarihi';
$lang['col_head_date'] = 'Tarih';
$lang['col_head_description'] = 'A��klama';
$lang['calendar_title'] = 'Ajanda Y�netimi';
$lang['calendar'] = 'Ajanda:';
$lang['event_title'] = 'Olay';
$lang['add_event'] = 'Olay Ekle';
$lang['delete_calendar_group_confirm_msg'] = 'Bu Ajandalar� Silmek �stedi�inize Emin misiniz? Bu i�lem Geri Al�namaz.';
$lang['private_only'] = 'Sadece �zel';
$lang['public_only'] = 'Sadece Genel';
$lang['public_private'] = 'Genel Ve �zel';
$lang['total_events_found'] = 'Bulunan Olay Adeti:';
$lang['start_date'] = 'Bas. Tarih.:';
$lang['start_time'] = 'Ba�lang�� Saati';
$lang['end_date'] = 'Bit. Tarih.:';
$lang['end_time'] = 'Biti� Saati';
$lang['event_description'] = 'Olay A��klamas�';
$lang['more_events'] = 'daha fazla olay >>';
$lang['daily_events_list'] = "Olaylar�n Listesi ";
$lang['add_to_private'] = "�zel Liste Ekle";
$lang['close_window'] = 'Kapat';
$lang['main_window_closed'] = "�zg�n�m, Ana Penceriyi Kapatt�n�z.";
$lang['user_added1'] = "Kullan�c� ";
$lang['user_added2'] = " �zel Listeye Eklendi";
$lang['next_month'] = 'Gelecek Ay';
$lang['previous_month'] = '�nceki Ay';
$lang['next_week'] = 'Gelecek Hafta';
$lang['previous_week'] = '�nceki Hafta';
$lang['next_day'] = 'Gelecek G�n';
$lang['previous_day'] = '�nceki g�n';
$lang['view_day'] = 'G�nl�k G�r�n�m';
$lang['view_week'] = 'Haftal�k G�r�n�m';
$lang['view_month'] = 'Ayl�k G�r�n�m';
$lang['watched_events'] = '�zledi�iniz Olaylar';
$lang['event_notification'] = 'Olay Uyar�s�';
$lang['jump_to'] = '�uraya Atla';
$lang['ok'] = 'Tamam';
$lang['recurring'] = "Tekrarlama:";
$lang['recur_every'] = "her";
$lang['calendat_filter_dates_range'] = "Tarih Aral���n� Se�in";
$lang['calendat_filter_last_year'] = "Ge�en Sene";
$lang['calendat_filter_last_month'] = "Ge�en Ay";
$lang['calendat_filter_last_week'] = "Ge�en Hafta";
$lang['calendat_filter_yesterday'] = "D�n";
$lang['cannot_determine_membership'] = '�yelik Seviyeniz Belirlenemiyor';
$lang['no_previous_polls'] = 'Hen�z hi� Anket Yok';
$lang['no_event_for_the_day'] = "Bu Tarihte Bir Olay Kay�tl� Degil";
$lang['maxsize'] = 'En fazla �zin Verilen Boyut (KB)';
$lang['views'] = 'G�r�n�mler';
$lang['settings_saved'] = 'Ayarlar ba�ar�yla kaydedildi';
$lang['select_image_first'] = 'L�tfen �nce bir foto�raf se�in';
$lang['view_type'] = 'G�sterim Tipi';
$lang['remember_me'] = 'Beni Hat�rla';
$lang['review'] = 'G�zden Ge�ir';
$lang['spammers'] = 'Spamc�lar';
$lang['addquestion'] = 'Soru Ekle';
$lang['mainstats'] = 'Temel �statistikler';
$lang['osdate_version'] = 'osDate Version';
$lang['signonstats'] = 'Giri� Bilgileri';
$lang['usersinpastminute'] = 'Ge�en dakika i�indeki kullan�c�lar';
$lang['usersinpasthour'] = 'Ge�en saat i�indeki kullan�c�lar';
$lang['usersinpastday'] = 'Ge�en g�n i�indeki kullan�c�lar';
$lang['usersinpastweek'] = 'Ge�en hafta i�indeki kullan�c�lar';
$lang['usersinpastmonth'] = 'Ge�en ay i�indeki kullan�c�lar';
$lang['usersinpastyear'] = 'Ge�en sene i�indeki kullan�c�lar';
$lang['usersinpast2years'] = 'Ge�en 2 sene i�indeki kullan�c�lar';
$lang['usersinpast5years'] = 'Ge�en 5 sene i�indeki kullan�c�lar';
$lang['usersinpast10years'] = 'Ge�en 10 sene i�indeki kullan�c�lar';
$lang['userstats'] = 'Kullan�c� �statistikleri';
$lang['totalusers'] = 'Toplam Kullan�c�';
$lang['totalactiveusers'] = 'Toplam Aktif Kullan�c�';
$lang['totalpendingusers'] = 'Ask�daki Kullan�c�lar';
$lang['totalsuspendedusers'] = 'Ge�ici Olarak Engellenmi� Kullan�c�lar';
$lang['totalpictureusers'] = 'Foto�raf� Olan Kullan�c�lar';
$lang['totalonlineusers'] = 'Online Olan Kullan�c�lar';
$lang['visitorstats'] = 'Ziyaretci �statistikleri';
$lang['sitestats'] = 'Site �statistikleri';
$lang['visitorstosite'] = 'Site Ziyaretcileri';
$lang['mostactivepage'] = 'En �ok Aktif olan Sayfa';
$lang['timesfeedback'] = 'Ka� Kez �statistikleri';
$lang['timesim'] = 'An�nda Mesaj G�nderildi';
$lang['timeswink'] = 'G�z K�rp�ld�';
$lang['timesmessage'] = 'Mail Kutusunua Mesaj G�nderildi';
$lang['timesinvitefriend'] = 'Kullan�c� Davet Edildi';
$lang['timeshowprofile'] = 'Profil G�r�nt�lendi';
$lang['timesonlineusers'] = 'Online Kullan�c�lar T�kland�';
$lang['timesbanner'] = 'Bannerlar T�kland�';
$lang['timesnewmember'] = 'Yeni Kullan�c� Listesi T�kland�';
$lang['timespoll'] = 'Anket Kullan�ld�';
$lang['timesgallery'] = 'Foto�raf Galerisi Kullan�ld�';
$lang['timesaffiliates'] = 'Reklamlar T�kland�';
$lang['timessignup'] = '�yelik T�kland�';
$lang['timesnews'] = 'Haberler T�kland�';
$lang['timesstories'] = 'Hikayeler T�kland�';
$lang['timessearchmatch'] = 'Arama Kullan�ld�';
$lang['no_affiliates'] = 'Yay�n(affiliate) Say�s�';
$lang['no_affiliate_refs'] = 'Yay�nc� Say�s�';
$lang['no_pages_refs'] = 'Sayfa havaleleri';
$lang['no_polls'] = 'Anket Say�s�';
$lang['no_news'] = 'Haber Adetlerinin Say�s�';
$lang['no_stories'] = 'Hikayelerin Say�s�';
$lang['no_langs'] = 'Kullan�labilir Dillerin Say�s�';
$lang['glblgroups'] = 'Genel Ayar Grubu';
$lang['accept_tos'] = ' <a href="javascript:popUpScrollWindow('."'tos.php','center',650,600);".'">Kullan�m ko�ullar�n�</a> okudum ve kabul ettim';
$lang['tos_must'] = 'L�tfen Kay�t olmadan �nce kullan�m �artlar�n� okuyup kabul edin.';
$lang['private_event'] = 'Bu olay bilgisi Gizlidir.';
$lang['posted_by'] = 'G�nderen';
$lang['countries01']='�lkeler';
$lang['states01'] = 'Eyalet';
$lang['latitude'] = 'Enlem';
$lang['longitude'] = 'boylam';
$lang['search_within'] = '��inde ara';
$lang['miles'] = ' mil ';
$lang['kms'] = ' kilometre ';
$lang['no_search_results'] = '<font color=red><b>0 Sonu� Bulundu</b></font><br /><br />Arad���n�z kriterler i�erisinde sonu� yok. Daha geni� bir aral�k se�ip tekrar arayabilirsiniz. Kriterleri azaltmay� deneyin, �rnek olarak sa� ve g�z rengi yerine sadece g�z rengi se�in. Yada kriterleri geni� aral�kta tutun, �rnek olarak ya� aral���n� 40-50 se�mek yerine 30-60 se�in.<br /><br />';
$lang['expire_on'] = '�yelik Biti� Tarihi';
$lang['expire_in'] = '�yelik Bitimine Kalan G�n';
$lang['lang_to_load'] = 'Y�klenecek dil';
$lang['load_lang'] = 'Dili Y�kle';
$lang['manage_languages'] = 'Dilleri Y�net';
$lang['manage_zips'] = 'Posta kodlar�n� d�zenle';
$lang['zipfile'] = 'Posta Kodlar� ��in Dosya';
$lang['zip_loaded'] = 'Posta kodlar� �urdan y�klendi ';
$lang['file_not_found'] = 'Verilen dosya sistemde bulunamad�';
$lang['success_mship_change'] = '�yeli�iniz De�i�tirildi ,';
$lang['payment_cancel'] = '�deme iptal edildi';
$lang['checkout_cancel'] = '�ste�iniz �zerine �deme i�lemi iptal edildi.';
$lang['transactions_report'] = '�deme Hareket Raporu';
$lang['trans_count'] = '�deme Hareketi Adeti';
$lang['pay_no'] = '�deme No.';
$lang['ref_no'] = 'Ref. No.';
$lang['paid_thru'] = '�deme Arac�';
$lang['pay_status'] = '�deme Durumu';
$lang['trans_rep'] = '�deme Raporu';
$lang['expiry_hdr'] = '�yelik Zaman A��m� Hat�rlat�c� Mektup';
$lang['expiry_ltr'] = '�yelik Zaman A��m� Mektubu';
$lang['expiry_select'] = 'Aral�k Se�iniz';
$lang['expird'] = 'G�n� Ge�ti';
$lang['expiry_ltr_sent'] = 'Mektuplar G�nderildi';
$lang['searching_within'] = '�ununla aran�yor';
$lang['payment_failed'] = '�deme i�leminde sorun olu�tur. L�tfen �demeyi ger�ekle�tirin.';
$lang['payment_fail'] = '�deme i�leminde hata';
$lang['deactivate'] = 'Pasifle�tir';
$lang['open_search'] = 'Aramay� A�';
$lang['replace'] = 'De�i�tir';
$lang['new'] = 'Yeni';
$lang['no_save'] = 'Kaydetme';
$lang['modify_curr_search'] = 'Ge�erli Arama Kriterini D�zenle';
$lang['perform_search'] = 've aramaya ba�la';
$lang['start_new_search'] = 'Yeni bir arama ba�lat';
$lang['use_empty_form'] = 'bo� form kullan�l�yor';
$lang['of_zip_code'] = 'bu posta koduna ait';
$lang['profile_ratings'] = 'Profil Oylamas�';
$lang['total_ratings'] = 'Toplam oy';
$lang['delete_ratings'] = 'Oylar� sil';
$lang['delete_rating_group_confirm_msg'] = 'Bu oylar� silmek istedi�inizden emin misiniz? Bu i�lem geri al�namaz.';
$lang['delete_rating_confirm_msg'] = 'Bu oyu silmek istedi�inizden emin misiniz? Bu i�lem geri al�namaz.';
$lang['modify_rating'] = 'Oy De�i�tir';
$lang['modify_ratings'] = 'Oylar� De�i�tir';
$lang['glblsettings_groups']['50'] = 'Profil Oylar�';
$lang['mod_lowtohigh']['Low to High'] = 'Azdan �o�a';
$lang['mod_lowtohigh']['High to Low'] = '�oktantan aza';
$lang['admin_rights']['profile_ratings'] = 'Profil Oylar�';
$lang['custom_message'] = 'Ge�erli Mesaj';
$lang['notify_me'] = 'Mesaj�m okundu�unda beni bilgilendir.';
$lang['include_profile'] = 'Bu mesaj�m profilimi i�ersin.';
$lang['message_templates'] = 'Mesaj Taslaklar�';
$lang['my_templates'] = 'Benim Taslaklar�m';
$lang['template_select'] = 'L�tfen bir taslak se�in';
$lang['template_intro'] = 'E�er benzer mesaj� s�k s�k g�nderiyorsan�z, zaman kazanmak i�in bu mesaj� taslak olarak kaydedebilirsiniz. [kullan�c�ad�] ve [ilkisim], gibi taslak de�i�kenleri kullanarak tasla��n�z� daha da fazla ki�iselle�tirebilirsiniz.';
$lang['add_template'] = 'Taslak Ekle';
$lang['return_message'] = 'Mesaja D�n';
$lang['delete_template_confirm_msg'] = 'Bu tasla�� silmek istedi�inizden emin misiniz? Bu i�lem geri al�namaz.';
$lang['edit_template'] = 'Tasla�� D�zenle';
$lang['your_comment'] = 'Sizin Yorumlar�n�z';
$lang['your_reply'] = 'Cevaplar�n�z';
$lang['comment_note'] = '255 karakterden fazla olan mesajlar otomatik olarak k�salt�lacakt�r.';
$lang['chars_remaining'] = 'kal�c� karakterler';
$lang['delete_comment_confirm_msg'] = 'Bu yorumu silmek istedi�inizden emin misiniz? Bu i�lemler geri al�namaz.';
$lang['no_msg_templates'] = 'Hi� mesaj tasla�� bulunamad�.';
$lang['select'] = '- Se�in -';
$lang['select_country'] = '�lke:';
$lang['select_state'] = 'Eyalet:';
$lang['select_county'] = '�lke Se�in';
$lang['select_city'] = '�ehir Se�in';
$lang['confirm_success'] = 'Giri� i�in ana sayfaya d�n.';
$lang['signup_success_message'] = 'Tebrik Ederiz!<br>�u anda �yemizsiniz. ' . 'SITENAME';
$lang['noone_online'] = 'Online �ye Yok';
$lang['in_hot_list'] = 'S�cak Listedeki Kullan�c�lar';
$lang['in_buddy_list'] = 'Arkada� Listesindeki Kullan�c�lar';
$lang['in_ban_list'] = 'Engelleme Listesindeki Kullan�c�lar';
$lang['delete_search'] = 'Bu Aramay� Sil';
$lang['select_user_to_send_message'] = 'Mesaj g�ndermek i�in bir kullan�c� se�in';
$lang['no_im_msgs'] = 'Hi� An�nda mesaj yok';
$lang['public_event'] = 'Bu olay genel olarak g�r�lebilir.';
$lang['no_event_description'] = 'Hi� bir tan�mlama yok.';
$lang['signup_js_errors']['country_noblank'] = '�lke se�ilmelidir.';
$lang['msg_sent'] = 'Mesaj�n�z G�nderildi';
$lang['forgotpass_msg4'] = 'Giri� bilgilerinizi mi unuttunuz? E-mail adresinize Kullan�c� ad�n�z� ve yeni bir �ifre g�nderebiliriz. Daha �nceden kay�t oldu�unuz e-mail adresiniz g�nsteriniz.';
$lang['send_a_message'] = 'Mesaj G�nder';
$lang['flagged'] = '��aretli';
$lang['un_flagged'] = '��aretsiz';
$lang['unflagged_msg1'] = ' ';
$lang['unflagged_msg2'] = ' g�n� ge�mi� olan i�aretsiz mesajlar otomatik olarak silenecektir.';
$lang['no_messages_in_box'] = 'Bu Posta dizininde hi� posta yok';
$lang['no_flagged_messages_in_box'] = 'Bu posta dizininde hi� i�aretli posta yok';
$lang['no_unflagged_messages_in_box'] = 'Bu posta dizinide hi� i�aretsiz posta yok';
$lang['mark'] = '�mle';
$lang['flag'] = '��aret';
$lang['unflag'] = '��areti  Kald�r';
$lang['msg_flagged'] = 'Mesaj i�aretli';
$lang['msg_unflagged'] = 'Mesaj i�aretsiz';
$lang['msg_deleted'] = 'Mesaj silinci';
$lang['sel_msgs_flagged'] = 'Se�ilen mesajlar i�aretlendi.';
$lang['sel_msgs_unflagged'] = 'Se�ilen esajlar�n i�aretleri kald�r�ld�';
$lang['sel_msgs_deleted'] = 'Se�ilen Mesajlar Silindi';
$lang['sel_msgs_undeleted'] = 'Se�ilen Mesajlar Kurtar�ld�';
$lang['sel_msgs_read'] = 'Se�ilen Mesajlar \"Okundu\" olarak i�aretlendi';
$lang['sel_msgs_unread'] = 'Se�ilen Mesajlar \"Yeni\" olarak ��aretlendi';
$lang['FROM1'] = 'Kimden:';
$lang['no_thanks'] = '\"Hay�r Te�ekk�rler\" de';
$lang['reply'] = 'Yan�tla';
$lang['undelete'] = 'Kurtar';
$lang['back_to_messages'] = 'Mesajlara Geri D�n';
$lang['replied'] = 'Cevap G�nderildi';
$lang['no_thanks_subject'] = 'Te�ekk�rler, kabul edemem';
$lang['total'] = 'Toplam';
$lang['max_allowed'] = 'Maksimuma izin verildi';
$lang['im_msg_long'] = '�zin verilen boyuttan b�y�k mesaj ';
$lang['members'] = '�yeler';
$lang['To1'] = 'Kime';
$lang['change_email'] = 'E-mail Adresini De�i�tir';
$lang['loading'] = 'Y�kleniyor..';
$lang['ratings'] = 'Oylar';
$lang['comment'] = 'Yorum';
$lang['comments'] = 'Yorumlar';
$lang['loadaction'] = 'Yap�lacak eylem';
$lang['loadintodb'] = 'Veritaban�na y�kle';
$lang['createsql'] = 'SQL scripti olu�tur';
$lang['load_zips'] = 'Posta kodu Dosyas�n� ��le';
$lang['zip_ensure'] = '��leme ba�lamadan �nce /zipcodes dizinine dosyay� y�kleyin. <br /><br />Dosya  virg�llerle ayr�lm�� �ekilde �unlar� i�ermelidir. POSTAKODU, ENLEM, BOYLAM, EYALETKODU, �LKEKODU, �EH�RKODU (ayn� d�zende ve ba�l�ks�z)<br /><br /> Bir �lkeden posta kodunu  silmek i�in, �lkeyi se�in ve "Posta Kodlar�n� sil" butonuna bas�n';
$lang['submit'] = 'G�nder';
$lang['lang_ensure'] = '�ncelikle config.php i�ine yeni bir dil ekleyin ($language_options ve  $language_files definitions kullanarak). Daha sonra dil dosyalar�n� gerekli dizne y�kleyin ("/language/lang_xxxx/" xxxx dilin k���k karakterlerle yaz�lm�� ad�d�r. �rnek Olarak: ingilizce, almanca, vs.).<br /><br /><b>Bir dili d�zenlemek veya yeni bir �eyler eklemek i�in de�i�iklikleri yapt�ktan sonra dil dosyas�n� veri taban�na y�klemelisiniz</b><br /><br />Bir dili veritaban�ndan silmek i�in �nce listeden dili se�in ve "Veri taban�ndan kald�r" Butonuna bas�n.';
$lang['rate_carefully'] = 'Site y�neticilerinin oylara bir etkileri yoktur.<br />Oylar kullan�c�lar taraf�ndan g�nderilir ve y�neticiler m�dahale edemezler.';
$lang['alphanumeric'] = "0123456789.+-_#,/ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz ()_";
$lang['alphanum'] = "0123456789_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz ";
$lang['text'] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz '";
$lang['full_chars'] = "0123456789.+-_#,/ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz() _$+=;:?'";
$lang['save'] = 'Kaydet';
$lang['delete_zips'] = 'Posta kodlar�n� sil';
$lang['zipcodes_sql_created'] = 'Posta kodlar�n�n sql dosyas� olu�turuldu ';
$lang['zipcodes_loaded'] = 'Posta kodlar� y�klendi ';
$lang['delzips_msg'] = 'B�t�n Posta kodlar� silinecek';
$lang['delzips_succ'] = 'T�m Posta kodlar� silindi';
$lang['wrong_zipfile'] = 'Bu dosya #COUNTRY# �lkesi i�in de�il';
$lang['load_states'] = 'Eyalet Dosyas�n� ��le';
$lang['state_ensure'] = '��leme ba�lamadan �nce /states dizinine dosyay� y�kleyin. <br /><br />Dosya  virg�llerle ayr�lm�� �ekilde �unlar� i�ermelidir. EYALETKODU ve EYALETADI (ayn� d�zende ve ba�l�ks�z)<br /><br /> Bir eyaletin kodunu  silmek i�in, �lkeyi se�in ve "Eyalet Kodlar�n� sil" butonuna bas�n';
$lang['statefile'] = 'Eyalet Kodlar� ��in Dosya';
$lang['delete_states'] = 'Eyalet kodlar�n� sil';
$lang['delstates_msg'] = 'B�t�n eyalet kodlar� silinecek';
$lang['delstates_succ'] = 'T�m eyalet kodlar� silindi';
$lang['states_sql_created'] = 'Eyalet kodlar� i�in SQL dosyas� haz�rland�';
$lang['states_loaded'] = '�lke kodlar� �urdan y�klendi ';
$lang['delete_lang'] = 'Veri taban�ndan kald�r';
$lang['langfile_loaded'] = '#LANGUAGE# i�in dil dosyalar� �urdan y�klendi ';
$lang['lang_deleted'] = '#LANGUAGE# i�in dil modifiyeleri kald�r�ld�';
$lang['load_counties'] = '��ke Dosyas�n� ��le';
$lang['countyfile'] = '�lke Kodlar� ��in Dosya';
$lang['county_ensure'] = '��leme ba�lamadan �nce /countries dizinine dosyay� y�kleyin. <br /><br />Dosya  virg�llerle ayr�lm�� �ekilde �unlar� i�ermelidir. �LKEKODU, �LKEADI VE EYALETKODU (ayn� d�zende ve ba�l�ks�z)<br /><br /> Bir �lkenin kodunu  silmek i�in, �lkeyi se�in ve "�lke Kodlar�n� sil" butonuna bas�n';
$lang['delete_counties'] = '�lke kodlar�n� sil';
$lang['delcounties_msg'] = 'B�t�n �lke kodlar� silinecek';
$lang['delcounties_succ'] = 'T�m �lke kodlar� silindi';
$lang['counties_sql_created'] = '�lke kodlar� i�in SQL dosyas� haz�rland�';
$lang['counties_loaded'] = '�lke kodlar� �urdan y�klendi ';
$lang['load_cities'] = '�ehir Dosyas�n� ��le';
$lang['cityfile'] = '�ehir Kodlar� ��in Dosya';
$lang['city_ensure'] = '��leme ba�lamadan �nce /cities dizinine dosyay� y�kleyin. <br /><br />Dosya �unlar� virg�llerle ayr�lm�� �ekilde �unlar� i�ermelidir �EH�RKODU, �EH�R�SM�, �LKEKODU ve EYALETKODU.(ayn� d�zende ve ba�l�ks�z)<br /><br /> Bir �lkeden �ehir kodunu silmek i�in, �lkeyi se�in ve "�ehir Kodunu sil" butonuna bas�n';
$lang['delete_cities'] = '�ehir kodlar�n� sil';
$lang['delcities_msg'] = 'B�t�n �ehir kodlar� silinecek';
$lang['delcities_succ'] = '#COUNTRY# - T�m �ehir kodlar� silindi';
$lang['cities_sql_created'] = '�ehir kodlar� i�in SQL dosyas� haz�rland�';
$lang['cities_loaded'] = '�ehir kodlar� �urdan y�klendi ';
$lang['online'] = 'Online';
$lang['watchedprofiles_1'] = '�zlenen Profillere Ekle';
$lang['watchedprofiles'] = '�zlenen Profiller';
$lang['poll'] = 'Anket';
$lang['section_poll_title'] = 'Anket';
$lang['section_poll_list'] = 'Anket Listesi';
$lang['section_add_poll'] = 'Anket Olu�tur';
$lang['poll_subtitle_list'] = 'Anket Listesi';
$lang['poll_subtitle_add'] = 'Anket Olu�tur';
$lang['poll_subtitle_edit'] = 'Anketi D�zenle';
$lang['poll_number'] = 'Numara';
$lang['poll_active_hdr'] = 'Aktif';
$lang['poll_question_hdr'] = 'Sorular';
$lang['poll_responses_hdr'] = 'Cevaplar';
$lang['no_poll_found'] = 'Anket bulunamad�';
$lang['poll_question'] = 'Soru';
$lang['poll_options'] = 'Anket se�enekleri';
$lang['poll_active'] = 'Aktif';
$lang['poll_minimum_two'] = 'en az iki tane gereklidir.';
$lang['results_poll_title'] = 'sonu�lar';
$lang['poll_subtitle_results'] = 'anket sonu�lar�';
$lang['take_poll_title'] = 'anketi al';
$lang['poll_entries'] = 'Anket';
$lang['plugin'] = 'Eklenti';
$lang['plugin_access'] = 'Kullan�c�lar�n Eri�imi';
$lang['section_plugin_title'] = 'Eklentiler';
$lang['section_plugin_list'] = 'Eklenti Listesi';
$lang['section_add_plugin'] = 'Eklentileri Y�kle';
$lang['plugin_subtitle_list'] = 'Eklenti Listesi';
$lang['plugin_number'] = 'Numara';
$lang['plugin_name'] = 'Eklenti Ad�';
$lang['plugin_active'] = 'Aktif';
$lang['plugin_installed'] = 'Y�klenmi�';
$lang['plugin_install'] = 'Y�kle';
$lang['no_plugin_found'] = 'Eklenti Bulunamad�';
$lang['plugin_file'] = 'Eklenti Zip dosyas� G�nder';
$lang['plugin_subtitle_edit'] = 'Eklentileri D�zenle';
$lang['add_plugin_summary'] = 'Eklenti Yaratma Konusundaki D�k�manlar osDate Kurulumu �le Birlikte Gelir.';
$lang['blog']['hdr'] = 'Blog';
$lang['admin_blog'] = 'Site Blo�u';
$lang['blog_default_bad_words'] = 'hayvan|bok';
$lang['blog_bad_words'] = 'Yasak S�zc�kler';
$lang['blog_save_template'] = '�ablon olarak kaydet';
$lang['blog_load_template'] = '�ablon y�kle';
$lang['blog_bad_words_help'] = '(Her sat�ra bir c�mle)';
$lang['blog_search_results'] = 'Blog arama sonu�lar�';
$lang['section_blog_info'] = 'Blog ayarlar�';
$lang['section_blog_list'] = 'Blog i�eri�i';
$lang['section_blog_title'] = 'Blog';
$lang['blog_search_menu'] = 'Blog Arama';
$lang['blog_search_username'] = 'Kullan�c� ad�';
$lang['blog_search_title'] = 'Ba�l�k';
$lang['blog_search_body'] = 'Metin';
$lang['blog_search_Date'] = 'G�n';
$lang['blog_subtitle_list'] = 'Blog listesi';
$lang['blog_name'] = 'Blog ismi';
$lang['blog_description'] = 'Blog tan�m�';
$lang['blog_members_comment'] = '�ye yorumlar�';
$lang['blog_buddies_comment'] = 'Arkada� yorumlar�';
$lang['blog_members_vote'] = '�ye oylar�';
$lang['blog_gui_editor'] = 'WYSIWYG edit�r�';
$lang['blog_max_comments'] = 'Max yorum';
$lang['no_blog_found'] = 'Hi�bir i�erik bulunamad�';
$lang['section_add_blog'] = 'Blog i�eri�i yarat';
$lang['blog_subtitle_add'] = 'Blog i�eri�i yarat';
$lang['blog_subtitle_edit'] = 'Blo�u d�zenle';
$lang['blog_title'] = 'Ba�l�k';
$lang['blog_story'] = '��erik';
$lang['blog_posted_date'] = 'G�nderilme Tarihi';
$lang['blog_title_hdr'] = 'Ba�l�k';
$lang['blog_rating_list_hdr'] = 'Pop�larite';
$lang['blog_number'] = 'Numara';
$lang['blog_date_posted_hdr'] = 'Tarih';
$lang['blog_views_hdr'] = 'G�r�nt�lenme';
$lang['blog_votes_hdr'] = 'Oylar';
$lang['blog_votes1'] = 'oylar';
$lang['blog_rating_hdr'] = 'kurulmu�';
$lang['blog_submit_vote'] = 'oyla';
$lang['blog_add_vote'] = '�imdi oyla';
$lang['view_blog'] = 'Blo�u G�ster';
$lang['blog_entries'] = 'Blog:';
$lang['blog_creator'] = 'Yazar';
$lang['blog_comments'] = 'Yorumlar';
$lang['add_comment'] = 'Sizin yorumlar�n�z';
$lang['total_blogs_found'] = 'Bulunan toplam blog i�eri�i:';
$lang['spell_check'] = 'Yaz�m Yanl���';
$lang['manage_import_webdate'] = 'Webdate i�e aktar';
$lang['import_config'] = 'Ayar';
$lang['photos_url'] = 'Ana Sayfa URL:';
$lang['ftp_username'] = 'FTP Kullan�c� Ad�:';
$lang['ftp_password'] = 'FTP �ifre:';
$lang['ftp_hostname'] = 'FTP Host ad�:';
$lang['ftp_path'] = 'FTP aeDating Dizini:';
$lang['ftp_path_help'] = 'FTP ile Ba�land�ktan sonrak eaDating Dizini.  �rn. public_html/aeDating';
$lang['nopicsloaded'] = 'Foto�raf Yok';
$lang['loadedpicscnt'] = '#PICSCNT# Foto�raf� Var';
$lang['loadedpicscnt1'] = '#PICSCNT# Foto�raf� Var';
$lang['picsloaded'] = 'Foto�raflar Y�klendi';
$lang['since'] = 'Tarihinden �tibaren';
$lang['unknown'] = 'Bilinmeyen';
$lang['who_is_online'] = 'Sadece Online Olanlar';
$lang['search_with_photo'] = 'Sadece Foto�raf� Olanlar';
$lang['search_with_video'] = 'Sadece Videosu Olanlar';
$lang['expire_on_hdr'] = 'Biti� Tarihi';
$lang['expird'] = 'G�n� Ge�mi�';
$lang['pics'] = 'Foto�raflar';
$lang['pic_deleted'] = 'Se�ilen Foto�raf Silindi';
$lang['entrycode_chars'] = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
$lang['enter_spamcode'] = 'G�venlik Kodu';
$lang['newpic']['html'] = "Say�n Y�netici<br><br>Kullan�c� : #UserName# Yeni bir Foto�raf Y�kledi. <br><br>Kullan�c� Ad�: #UserName#.<br>Foto�raf Numaras�.: #PicNo#<br><br>#AdminName#<br>SITENAME";
$lang['newpic_sub'] = 'SITENAME Mesaj: Yeni foto�raf Y�klendi Kullan�c� : ';
$lang['newvideo']['html'] = "Say�n Y�netici<br><br>Kullan�c� : #UserName# Yeni Bir Video Y�kledi. <br><br>Kullan�c� Ad�: #UserName#.<br>Video Numaras�.: #PicNo#<br><br>#AdminName#<br>SITENAME";
$lang['newvideo_sub'] = 'SITENAME Mesaj: Yeni Video Y�klendi Kullan�c� : ';
$lang['payment_msg1'] = '�deme Se�enekleri.';
$lang['wrong_activationcode'] = 'Bu aktivasyon kodu yanl��.';
$lang['security_code_txt'] = 'A�a��daki resimde g�r���n�z yaz�y� sol taraf�ndaki metin kutusuna yaz�n�z. G�venlik nedenlerinden dolay� bunu yapmal�s�n�z.';
$lang['additional_pics'] = 'Eklenmi� Foto�raflar';
$lang['view_all_pics'] = 'B�t�n Foto�raflar� G�ster';
$lang['insufficientPrivileges'] = 'Bu se�enek i�in yeterli yetkiniz yok. L�tfen �yelik seviyenizi y�kseltin.';

$lang['featured_profiles_msg01'] = "G�sterilmek Zorunda: 'Evet' Bu profile nitelikli profiller listesinde g�r�nme hakk� verecek. 'Hay�r' Se�ilme �ans�n� azaltacak ";

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
$lang['featured_profiles_msg02'] = "Gerekli �f�a: Bu, if�alar�n biti� tarihininden �nce limiti a�mas� durumunda kald�r�lmas� i�in gerekli olan if�a limit rakam�d�r.";
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

$lang['lookup'] = 'Al';
$lang['sb_by'] = 'G�nderen:';
$lang['sb_hdr'] = 'At��kutusu';
$lang['sb_send'] = 'G�nder';
$lang['sb_error'] = 'Girilen metin izin verilenden uzun';
$lang['sb_msg_blank'] = 'At��kutusu mesaj� bo�?';
$lang['sb_show_all'] = 'Hepsini G�ster';
$lang['upload_videos'] = 'Videolar� y�kle';
$lang['videoupload_format_msgs'] = 'Sadece .swf ve .flv dosyalar� y�klenebilir.';
$lang['video'] = 'Video';
$lang['upload_videos_ext'] = 'flv, swf';
$lang['upload_video_caption'] = 'Video Y�kle';
$lang['video_file'] = 'Video dosyas�';
$lang['vds'] = 'Vds';
$lang['manage_videos'] = 'Videolar� D�zenle';
$lang['videos_loaded'] = 'Y�klenen Videolar�';
$lang['novideos_loaded'] = 'Y�kl� Video Yok';
$lang['loadedvdocnt'] = '#PICSCNT# video(lar)';
$lang['loadedvdocnt1'] = '#PICSCNT# video';
$lang['video_gallery'] = 'Video galerisi';
$lang['picture_gallery'] = 'Foto�raf Galerisi';
$lang['tz']['-25'] = '-- Se�iniz --';
$lang['tz']['-12.00'] = 'GMT - 12 Saat';
$lang['tz']['-11.00'] = 'GMT - 11 Saat';
$lang['tz']['-10.00'] = 'GMT - 10 Saat';
$lang['tz']['-9.00'] = 'GMT - 9 Saat';
$lang['tz']['-8.00'] = 'GMT - 8 Saat';
$lang['tz']['-7.00'] = 'GMT - 7 Saat';
$lang['tz']['-6.00'] = 'GMT - 6 Saat';
$lang['tz']['-5.00'] = 'GMT - 5 Saat';
$lang['tz']['-4.00'] = 'GMT - 4 Saat';
$lang['tz']['-3.5'] = 'GMT - 3.5 Saat';
$lang['tz']['-3.00'] = 'GMT - 3 Saat';
$lang['tz']['-2.00'] = 'GMT - 2 Saat';
$lang['tz']['-1.00'] = 'GMT - 1 Saat';
$lang['tz']['0.00'] = 'GMT';
$lang['tz']['1.00'] = 'GMT + 1 Saat';
$lang['tz']['2.00'] = 'GMT + 2 Saat';
$lang['tz']['3.00'] = 'GMT + 3 Saat';
$lang['tz']['3.5'] = 'GMT + 3.5 Saat';
$lang['tz']['4'] = 'GMT + 4 Saat';
$lang['tz']['4.5'] = 'GMT + 4.5 Saat';
$lang['tz']['5.00'] = 'GMT + 5 Saat';
$lang['tz']['5.5'] = 'GMT + 5.5 Saat';
$lang['tz']['6.00'] = 'GMT + 6 Saat';
$lang['tz']['6.5'] = 'GMT + 6.5 Saat';
$lang['tz']['7.00'] = 'T�rkiye Saati';
$lang['tz']['8.00'] = 'GMT + 8 Saat';
$lang['tz']['9'] = 'GMT + 9 Saat';
$lang['tz']['9.5'] = 'GMT + 9.5 Saat';
$lang['tz']['10.00'] = 'GMT + 10 Saat';
$lang['tz']['11.00'] = 'GMT + 11 Saat';
$lang['tz']['12.00'] = 'GMT + 12 Saat';
$lang['tz']['13.00'] = 'GMT + 13 Saat';
$lang['myprofile'] = 'Profilim';
$lang['myblog'] = 'Benim Blo�um';
$lang['profilesearch'] = 'Profil Arama';
$lang['mylists'] = 'Benim Listem';
$lang['bans'] = 'Engelliler';
$lang['mybuddies'] = 'Arkada�lar�m';
$lang['hotprofiles'] = 'S�cak Profiller';
$lang['winks'] = 'G�z K�rpmalar';
$lang['tools'] = 'Ara�lar';
$lang['picturegallery'] = 'Fotograf Galerim';
$lang['videogallery'] = 'Video Galerim';
$lang['membership'] = '�yelik Durumum';
$lang['adminhome'] = 'Y�netici Sayfas�';
$lang['membershdr'] = '�yeler';
$lang['memberprofiles'] = '�ye Profilleri';
$lang['membersearch'] = '�ye Arama';
$lang['blogs'] = 'Bloglar';
$lang['blogsearch'] = 'Bloglar� Ara';
$lang['affiliateshdr'] = 'Yay�mc�lar';
$lang['localities'] = 'B�lgesel';
$lang['contenthdr'] = '��erik';
$lang['financial'] = 'Finansal';
$lang['plugins_hlp'] = 'Admin Eklentileri Sadece Adminler Ve Moderatorler taraf�ndan kullan�labilir. Ve Ekran�n sol alt�nda g�r�n�rler. Kullan�c� eklentileri kullan�c� sayfas�nda g�r�n�rler';
$lang['no_thanks_message']['html'] = 'Merhaba #recipient_username#,<br><br>�lgin i�in te�ekk�rler, fakat kabul edemem. Umar�m arad���n� �urda bulabilirsin #site_name#.<br><br>En iyi dileklerime,<br><br>#sender_username#';
$lang['wink_received']['html'] = "Sevgili #FirstName#,<br><br> #siteName# Adresinden '#SenderName#' Kullan�c�s�ndan bir g�z k�rpmas� ald�n�z.<br><br>'#SenderName#' a mesaj g�ndermek veya kar��l�k vermek i�in t�klay�n <a href=\"#link#\">#siteName#</a>.<br><br>�yi �anslar!<br>#AdminName#";
$lang['letter_winkreceived_sub'] = '#SITENAME# - G�z k�rmas� ald�n�z';

$lang['mail']['hdr_text'] = '<font style="color:red; font-size: 9px;">Bu tip mesajlar almak istemiyorsan�z, <a href="#SiteUrl#">Giri� Yap�n</a> Kullan�c� men�s�nden e-mail ayarlar�n�z� de�i�tirin.<br>Bu mailleri almak i�in <a href="mailto:#AdminEmail#">#AdminEmail#</a> i Adres defterinize ekleyin.</font><br><br>';

$lang['mail']['hdr_html'] = '<table border=0 cellspacing=0 cellpadding=0 width="570"><tr><td style="padding: 5px;"><font style="color:red; font-size: 9px;">Bu tip mesajlar almak istemiyorsan�z, <a href="#SiteUrl#">Giri� Yap�n </a> Kullan�c� men�s�nden e-mail ayarlar�n�z� de�i�tirin.<br>Bu mailleri almak i�in ,<a href="mailto:#AdminEmail#">#AdminEmail#</a> i Adres defterinize ekleyin..</font></td></tr><tr><td height="6"></td></tr></table>';
$lang['letter_winkreceived_sub'] = 'SITENAME Mesaj: #SenderName# Size g�z k�rpt� ';
$lang['wink_received']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td width="77" height="25px">#email_hdr_left#</td><td width="493" class="module_head" >&nbsp;&nbsp;#SenderName# Size G�z K�rpt�! </td></tr><tr><td width="570" class="evenrow" colspan="2" style="padding: 5px;"><table border="0" cellspacing="2" cellpadding="2"><tr><td height="6"></td></tr><tr><td width="50%" valign="top">#smallProfile#</td><td width="50%" valign="top">#SenderName# Size G�zk�rpt�! Sizde G�z k�rparak, veya e-mail g�nderek fl�rt edebiliriniz.<br><br><a href="#SiteUrl#compose.php?recipient=#UserId#">E-mail #SenderName# �imdi</a><br><br><a href="#SiteUrl#sendwinks.php?ref_id=#UserId#&amp;rtnurl=showprofile.php">G�z k�rpmas�na geri d�n</a><br><br>
<b>�lgilenmiyormusunuz?</b><br>#SenderName#"a Onunla ilgilenmedi�inizi g�stermek i�in  "Hay�r Te�ekk�rler" mesaj� g�nderin<br><br><a href="#SiteUrl#compose.php?recipient=#UserId#&amp;reply=11">"No, thanks" de</a><br><br></td></tr></table></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['profile_confirmation_email_sub'] = 'SITENAME Mesaj: SITENAME! a kay�t oldu�unuz i�in te�ekk�rler.';
$lang['profile_confirmation_email']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td width="77" height="25" class="module_head">#email_hdr_left#</td><td width="493" class="module_head" >&nbsp;&nbsp;#Welcome#!</td></tr><tr><td width="570" class="evenrow" colspan="2" style="padding: 5px;">Sevgili #FirstName#,<br><br>#SiteName# a kay�t oldu�unuz i�in te�ekk�rler. En yeni �yemiz oldu�unuz i�in, servislerimizi incelemenizi tavsiye ederim.<br><br>Ayr�ca profilinizi onaylamak i�in, l�tfen a�a��daki linki t�klay�n. yada, link t�klanabilir de�ilse, linki kopyalay�p adres �ubu�una yap��t�r�n.<br><br><a href=\"#ConfirmationLink#=#ConfCode#\">#ConfirmationLink#=#ConfCode#</a><br><br>E�er Kay�t ekran�n�n son basama��nda iseniz Aktivasyon kodunu kopyalay�p yap��t�rarak �yeli�inizi tamamlayabilirsiniz.<br><br>Aktivasyon kodunuz: <b>#ConfCode#</b><br><br>A��a��daki Kay�t bilgilerini sizin i�in sakl�yoruz:<br><br>Kullan�c� Ad�: <b>#StrID#</b><br>�ifre: <b>#Password#</b><br>E-Mail: <b>#Email#</b><br><br>L�tfen bu bilgileri g�venli bir yerde saklay�n, ��nk� bu bilgile b�t�n servislerimize eri�im hakk� sa�layacaks�n�z. Baz� servisler y�ksek �yelik seviyelerinde �al���r, Burdan �yelik seviyenizi art�rabilirsiniz:<br><br><a href="#SiteUrl#payment.php">#Upgrade#</a><br><br>Servislerimizi kulland���n�z i�in tekrar te�ekk�r ederiz, ve umar�m e�inizi bulursunuz! <br><br>#AdminName#<br>#SiteName#</td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';


$lang['message_received']['html'] = "Sevgili #FirstName#,<br><br>#siteName# sitesinden '#SenderName#' kullan�c�s�ndan bir mesaj ald�n�z.<br><br>Mesaja cevap vermek i�in l�tfen t�klay�n <a href=\"#link#\">#siteName#</a><br><br>�yi �anslar!<br>#AdminName#";

$lang['message_received_sub'] = 'SITENAME Mesaj: RE: sadece...';

$lang['message_received']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td width="77" height="25">#email_hdr_left#</td><td width="493" class="module_head" >&nbsp;&nbsp;#SenderName# den yeni bir mesaj! </td></tr><tr><td width="570" class="evenrow" colspan="2" style="padding: 5px;"><table border="0" cellspacing="2" cellpadding="2"><tr><td height="6"></td></tr><tr><td width="50%" valign="top" class="evenrow">
<table width="100%" border=0 cellspacing=0 cellpadding=2><tr><td width="25%" class="newshead">#From#:</td><td width="75%">#SenderName#</td></tr><tr><td class="newshead" >#TO#:</td><td>#UserName#</td></tr><tr><td class="newshead" >#Date#:</td><td>#MESSAGE_DATE# </td></tr><tr><td class="newshead">#Subject#:</td><td>#MSG_SUBJECT#</td></tr><tr><td colspan="2" height="6"></td></tr><tr><td colspan=2>Dear #FirstName#,<br><br>#SenderName# dan yeni bir mesaj ald�n�z.<br><br>Mesaja cevap yazmak i�in l�tfen t�klay�n <a href=\"#link#\">SITENAME</a><br><br>�yi �anslar!<br>#AdminName#<br>SITENAME<br></td></tr></table></td><td width="50%" valign="top" class="oddrow">#smallProfile#</td></tr></table></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';
$lang['letter_featuredprofile_sub'] = '#SITENAME# - Ayr�cal�kl� profil listesi';
$lang['featured_profile_added']['html'] = "Sevgili #FirstName#,<br><br>bu link size ayr�cal�kl� profiller listesine eklenmenize imkan verekcetir. <a href=\"#link#\">#siteName#</a>.<br><br>Profilini #FromDate# - #UptoDate#. tarihleri aras�nda ayr�cal�kl� hale gelecektir.<br><br>Bu Profilinizin g�r�n�rl���n� art�racak ve daha �ok uygun e� bulman�za imkan sa�layacakt�r.<br><br>�yi �anslar!<br>#AdminName#";
$lang['letter_featuredprofile_sub'] = 'SITENAME Mesaj: Profiliniz daha sonra ayr�cal�kl� hale getirilecektir';
$lang['featured_profile_added']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td width="77" height="25" class="module_head">#email_hdr_left#</td><td width="493" class="module_head" >&nbsp;&nbsp;Profiliniz daha sonra ayr�cal�kl� hale getirilecektir! </td></tr><tr><td width="100%" class="evenrow" colspan="2" style="padding: 6px;"><table border="0" cellspacing="0" cellpadding="6"><tr><td height="6"></td></tr><tr><td width="100%" valign="top" class="evenrow">sevgili #FirstName#,<br><br>bu link size ayr�cal�kl� profiller listesine eklenmenize imkan verekcetir. <a href=\"#link#\">SITENAME</a>.<br><br>Profiliniz <b>#FromDate#</b> - <b>#UptoDate# tarihleri aras�nda ayr�cal�kl� olacakt�r</b>.<br><br>Bu Profilinizin g�r�n�rl���n� art�racak ve daha �ok uygun e� bulman�za imkan sa�layacakt�r.<br><br>iyi �anslar!<br>#AdminName# <br>SITENAME<br></td></tr></table></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';
$lang['profile_activated_sub'] = '#SITENAME# - Profiliniz Etkinle�tirildi';
$lang['profile_activated']['html'] = "Sevgili #FirstName#,<br><br>#siteName# deki profilinizin etkile�ti�ini g�stermek i�in haz�rlanm�� otomatik bir maildir. �yelik seviyeniz: #MembershipLevel#. Bizi ziyaret edin: <a href=\"#link#\">#siteName#</a>.<br><br>�yi �anslar!<br>#AdminName#";
$lang['profile_activated_sub'] = 'SITENAME Mesaj:  Profiliniz Etkinle�tirildi!';
$lang['profile_activated']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td width="77" height="25" class="module_head">#email_hdr_left#</td><td width="493" class="module_head" >&nbsp;&nbsp;Profiliniz Etkinle�tirildi! </td></tr><tr><td width="100%" class="evenrow" colspan="2" style="padding: 6px;"><table border="0" cellspacing="0" cellpadding="6"><tr><td height="6"></td></tr><tr><td width="100%" valign="top" class="evenrow">Sevgili #FirstName#,<br><br>Sitemize kay�t olman�zdan mutluluk duyar�z SITENAME. <br><br>Profiliniz Etkinle�tirildi.  �yelik seviyeniz:<b>#MembershipLevel#</b> #ValidDate# Tarihine kadar ge�erlidir.<br><br>Bizi ziyaret edin. <a href=\"#link#\">SITENAME</a>.<br><br>�yi �anslar!<br>#AdminName# <br>SITENAME<br></td></tr></table></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';
$lang['profile_reactivated_sub'] = '#SITENAME# - Profiliniz Tekrar aktifle�tirildi';
$lang['profile_reactivated']['html'] = "Sevgili #FirstName#,<br><br>#siteName# deki profilinizin etkile�ti�ini g�stermek i�in haz�rlanm�� otomatik bir maildir. Profiliniz #MembershipLevel# ile tekrar aktifle�tirildi. Bizi ziyaret edin <a href=\"#link#\">#siteName#</a>.<br><br>�yi �anslar!<br>#AdminName#";
$lang['profile_reactivated_sub'] = 'SITENAME Mesaj: Profiliniz Tekrar Aktifle�tirildi!';

///////////////////////////////////////////////////////////////////////////////////////////////////////////
$lang['profile_reactivated']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td width="77" height="25" class="module_head">#email_hdr_left#</td><td width="493" class="module_head" >&nbsp;&nbsp;Profiliniz Tekrar aktifle�tirildi! </td></tr><tr><td width="100%" class="evenrow" colspan="2" style="padding: 6px;"><table border="0" cellspacing="0" cellpadding="6"><tr><td height="6"></td></tr><tr><td width="100%" valign="top" class="evenrow">Sevgili #FirstName#,<br><br>�yelik Durumunuzun <b>#MembershipLevel#</b> "a y�klseltildi�ini s�ylemekten mutluluk duyar�z.�yeli�inizin biti� tarihi <b>#ValidDate#</b><br><br>Bizi ziyaret edin <a href=\"#link#\">SITENAME</a>.<br><br>�yi �anslar!<br>#AdminName# <br>SITENAME<br></td></tr></table></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';
$lang['added_banlist_sub'] = '#SITENAME# - Bilgi Mesaj�';
$lang['added_buddylist_sub'] = '#SITENAME# - Bilgi Mesaj�';
$lang['added_hotlist_sub'] = '#SITENAME# - Bilgi Mesaj�';
$lang['added_buddylist']['html'] = "Sevgili #FirstName#,<br><br>#SenderName# Sizi arkada� listesine ekledi.<br><br>Bu kullan�c�n�n profilini g�rmek i�in t�klay�n <a href=\"#link#\">#siteName#</a>.<br><br>�yi �anslar!<br>#AdminName#";
$lang['added_hotlist']['html'] = "Sevgili #FirstName#,<br><br>#SenderName# Sizi s�cak listesine ekledi.<br><br>Bu kullan�c�n�n profilini g�rmek i�in t�klay�n <a href=\"#link#\">#siteName#</a>.<br><br>�yi �anslar!<br>#AdminName#";
$lang['added_banlist']['html'] = "Sevgili #FirstName#,<br><br>#SenderName# sizi engelleme listesine ekledi.<br><br>Bu kullan�c�n�n profilini g�rmek i�in t�klay�n <a href=\"#link#\">#siteName#</a>.<br><br>#AdminName#";

$lang['added_list_sub'] = "SITENAME Mesaj: #SenderName# in #ListName# Listesine eklendiniz!";

$lang['added_list']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td width="77" height="25px" class="module_head">#email_hdr_left#</td><td width="493" class="module_head" >&nbsp;&nbsp;#SenderName# in #ListName# Listesine eklendiniz!</td></tr><tr><td width="100%" class="evenrow" colspan="2" style="padding: 6px;"><table border="0" cellspacing="0" cellpadding="6"><tr><td height="6"></td></tr><tr><td width="50%" valign="top" class="evenrow">Sevgili #FirstName#,<br><br><b>#SenderName#</b> sizi <b>#ListName#</b> listesine ekledi.<br><br>Bu kullan�c�n�n profilini g�rmek i�in t�klay�n <a href=\"#link#\">SITENAME</a>.<br><br>�yi �anslar!<br>#AdminName# <br>SITENAME<br></td><td valign="top">#smallProfile#</td></tr></table></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';
$lang['invite_a_friend_sub'] = 'Arkada��n� davet et';
$lang['invite_a_friend']['html'] = "Selam,<br><br>Webde gezerken �ok ho� bi arkada�l�k sitesi buldum: #Link#.<br>�lgilenece�ini d���nd�m.<br><br>#FromName#";
$lang['invite_a_friend_sub'] = "SITENAME Mesaj: #FromName# den Davet ";
$lang['invite_a_friend']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td width="77"  class="module_head" valign="top">#email_hdr_left#</td><td width="493" class="module_head" >&nbsp;&nbsp;#FromName# den davet! </td></tr><tr><td width="100%" class="evenrow" colspan="2" style="padding: 5px;"><table border="0" cellspacing="0" cellpadding="6" width="100%"><tr><td height="6"></td></tr><tr><td width="100%" valign="top" class="evenrow">Hi,<br><br>Webde gezerken �ok ho� bi arkada�l�k sitesi buldum: <a href=\"#SiteUrl#\"><b>SITENAME</b></a><br>�lgilenece�ini D���nd�m.<br><br>ziyaret etmek i�in t�kla <a href=\"#SiteUrl#\">SITENAME</a>.<br><br>�yi �anslar!<br>#FromName# <br><br></td></tr></table></td></tr><tr><td height="12" class="evenrow" colspan="2" ></td></tr></table>';
$lang['message_read_sub'] = '#SITENAME# - Bilgi Mesaj�';
$lang['message_read']['html'] = "Sevgili #FirstName#,<br><br> '#RecipientName#' g�nderdi�iniz mesaj� okudu.<br><br>�yi �anslar!<br>#AdminName#";
$lang['message_read_sub'] = 'SITENAME Mesaj: #RecipientName# g�nderdi�iniz mesaj� okudu!';
$lang['message_read']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td width="77" height="25" class="module_head">#email_hdr_left#</td><td width="493" class="module_head" >&nbsp;&nbsp;Your message to #RecipientName# is read! </td></tr><tr><td width="100%" class="evenrow" colspan="2" style="padding: 5px;"><table border="0" cellspacing="0" cellpadding="6"><tr><td height="6"></td></tr><tr><td width="50%" valign="top" class="evenrow">Sevgili #FirstName#,<br><br><b>#RecipientName#</b>  a g�nderi�iniz mesaj� okudu.<br><br>Bu kullan�c�n�n profilini g�rmek i�in t�klay�n. <a href=\"#link#\">SITENAME</a>.<br><br>�yi �anslar!<br>#AdminName# <br>SITENAME<br></td><td valign="top">#smallProfile#</td></tr></table></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';
/*
$lang['email_feedback_subject'] = 'Feedback from User of '.SITENAME;

$lang['feedback_email_to_admin']['html'] = 'Dear Site Administrator,<br><br>You have just received comments from a visitor to your dating site. The details are as follows:<br><br>Title: #txttitle#<br>Name: #txtname#<br>Email: #txtemail#<br>Country: #txtcountry#<br>Comments: #txtcomments#<br><br>Thanks,<br>#SITENAME# Daemon';
*/

$lang['email_feedback_subject'] = 'SITENAME Kullan�c�dan geri bildirim ';

$lang['feedback_email_to_admin']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td width="77" height="25" class="module_head">#email_hdr_left#</td><td width="493" class="module_head" >&nbsp;&nbsp;Kullan�c�dan geri bildirim</td></tr><tr><td width="100%" class="evenrow" colspan="2" style="padding: 5px;"><table border="0" cellspacing="0" cellpadding="0"><tr><td height="6"></td></tr><tr><td width="100%" valign="top" class="evenrow">Say�n site y�neticisi,<br><br>Site ziyaretcinizden bir e-mail ald�n�z. Detaylar a�a��da:<br><br><table cellspacing="4" cellpadding="2" border="0" width="100%"><tr><td width="20%"> Ba�l�k:</td><td width="80%">#txttitle# </td></tr><tr><td>�sim:</td> <td>#txtname#</td></tr><tr><td>Email:</td><td>#txtemail#</td></tr><tr><td>�lke:</td><td>#txtcountry#</td></tr><tr><td>Yorumlar:</td><td>#txtcomments#</td></tr></table><br>Te�ekk�rler,<br>SITENAME Daemon<br><br></td></tr></table></td></tr></table> ';
$lang['forgot_password_sub'] = '�ifre �ste�i';
$lang['forgot_password']['html'] = "Sevgili #Name#,<br><br>�yelik Numaran�z: #ID#<br>�ifreniz: #Password#<br><br>G�ri� ��in: #LoginLink#.<br><br>Servislerimizi kulland���n�z i�in te�ekk�rler!<br><br>#SiteTitle# mail iletim sistemi<br><Otomatik mesaj. L�tfen cevap yazmay�n.>";
$lang['forgot_password_sub'] = 'SITENAME Mesaj: �ifre s�f�rlama iste�i';
$lang['forgot_password']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td width="77" height="25" class="module_head">#email_hdr_left#</td><td width="493" class="module_head" >&nbsp;&nbsp;Your password reset request</td></tr><tr><td width="100%" class="evenrow" colspan="2" style="padding: 5px;"><table border="0" cellspacing="0" cellpadding="0"><tr><td height="6"></td></tr><tr><td width="100%" valign="top" class="evenrow">Sevgili #Name#,<br><br>Sitemize eri�ebilmeniz i�in iste�iniz �zerine �ifreniz s�f�rlanm��t�r.<br><br>�ye Numaran�z: <b>#ID#</b><br>Yeni �ifreniz: <b>#Password#</b><br><br>Giri� i�in: <a href=\"#LoginLink#\">SITENAME</a>.<br><br>
Servislerimizi kulland���n�z i�in te�ekk�rler!<br><br>#AdminName#<br>SITENAME<br></td></tr> </table></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';
$lang['expiry_ltr_sub'] = '�yelik S�reniz Doluyor';
$lang['mship_expired_note']['html'] = "Sevgili #FirstName#,<br><br> #siteName# deki �yelik seviyeniz  #MembershipLevel# �yelik, #ExpiryDate# tarihinde sona eriyor  .<br><br>L�tfen <a href=\"#link#\"> #siteName# e �yeli�iniz yenilemek i�in giri�inizi yap�n</a><br><br>�yi �anslar!<br>#AdminName#";
$lang['expiry_ltr_sub'] = 'SITENAME Mesaj: �yeli�inizin S�resi Doluyor';

$lang['mship_expired_note']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td width="77" height="25" class="module_head">#email_hdr_left#</td><td width="493" class="module_head" >&nbsp;&nbsp;�yelik S�reniz Doldu! </td></tr><tr><td width="100%" class="evenrow" colspan="2" style="padding: 5px;"><table border="0" cellspacing="0" cellpadding="6"><tr><td height="6"></td></tr><tr><td width="100%" valign="top" class="evenrow">Sevgili #FirstName#,<br><br>SITENAME u kulland���n�z i�in te�ekk�rler!<br><br> <b>#MembershipLevel#</b> �yeli�iniz <a href="\"#link#\"><b>SITENAME</b></a> <b>#ExpiryDate#</b> sona erdi .<br><br>L�tfen <a href=\"#link#\">SITENAME a Giri�inizi Yap�n</a>  ve �yelik s�renizi art�r�n.<br><br>�yi �anslar!<br>#AdminName# <br>SITENAME<br></td></tr></table></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';
$lang['mship_expiry_note']['html'] = 'Sevgili #FirstName#,<br><br>#siteName# deki �yeli�iniz #ExpiryDate# tarihinde sona erecek.<br><br>L�tfen <a href="#link#">  #siteName# a giri� yap�n</a> �yeli�inizi yenileyin.<br><br>�yi �anslar!<br>#AdminName#';


$lang['mship_expiry_note']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td width="77" height="25" class="module_head">#email_hdr_left#</td><td width="493" class="module_head" >&nbsp;&nbsp;�yeli�iniz Yak�nda sona erecek! </td></tr><tr><td width="100%" class="evenrow" colspan="2" style="padding: 5px;"><table border="0" cellspacing="0" cellpadding="6"><tr><td height="6"></td></tr><tr><td width="100%" valign="top" class="evenrow">Sevgili #FirstName#,<br><br>SITENAME u kulland���n�z i�in te�ekk�rler!<br><br> Bu mesaj  <a href="\"#link#\"><b>SITENAME</b></a> adresindeki <b>#MembershipLevel#</b> �yeli�inizin <b>#ExpiryDate#</b> tarihinde sona erece�ini hat�rlatmak i�in g�nderilmi�tir.<br><br>L�tfen <a href=\"#link#\">SITENAME a giri� yap�n</a> ve �yeli�inizi uzat�n.<br><br>�yi �anslar!<br>#AdminName# <br>SITENAME<br></td></tr></table></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';
$lang['profile_membership_changed_sub'] = 'SITENAME Mesaj:  �yelik seviyeniz de�i�ti!';
$lang['profile_membership_changed']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td width="77" height="25" class="module_head">#email_hdr_left#</td><td width="493" class="module_head" >&nbsp;&nbsp;�yelik Sevyeniz De�i�ti! </td></tr><tr><td width="100%" class="evenrow" colspan="2" style="padding: 5px;"><table border="0" cellspacing="0" cellpadding="3"><tr><td height="4"></td></tr><tr><td width="100%" valign="top" class="evenrow">Sevgili #FirstName#,<br><br>Ge�erli �yelik sevyeniz <b>#CurrentLevel#</b> den  <b>#NewLevel#</b> e de�i�tirildi. �yelik Biti� Tarihiniz :<b>#ValidDate#</b>.<br><br>Bizi ziyaret edin.<a href=\"#link#\">SITENAME</a>.<br><br>�yi �anslar!<br>#AdminName# <br>SITENAME<br></td></tr></table></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['comment_received_sub'] = 'SITENAME Mesaj: Blo�unuza yeni yorum eklendi';
$lang['comment_received']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td width="77" height="25" class="module_head">#email_hdr_left#</td><td width="493" class="module_head" >&nbsp;&nbsp;Bir kullan�c� Blo�unuza yeni yorum ekledi! </td></tr><tr><td width="100%" class="evenrow" colspan="2" style="padding: 5px;"><table border="0" cellspacing="0" cellpadding="6"><tr><td height="6"></td></tr><tr><td width="100%" valign="top" class="evenrow">Sevgili #FirstName#,<br><br>SITENAME kullan�c�s� <b>#SenderName#</b> dan yeni bir yorum ald�n�z.<br><br> G�rmek i�in l�tfen t�klay�n <a href=\"#link#\"><b>SITENAME</b></a> <b>#SenderName#</b>.<br><br>�yi �anslar!<br>#AdminName# <br>SITENAME<br></td></tr></table></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';
$lang['aff_added_sub'] = 'SITENAME Mesaj: Reklam(affiliate) olarak eklendiniz!';
$lang['aff_added']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td width="77" height="25" class="module_head">#email_hdr_left#</td><td width="493" class="module_head" >&nbsp;&nbsp;Affiliate olarak eklendiniz! </td></tr><tr><td width="100%" class="evenrow" colspan="2" style="padding: 5px;"><table border="0" cellspacing="0" cellpadding="6"><tr><td height="6"></td></tr><tr><td width="100%" valign="top" class="evenrow">Sevgili #Name#,<br><br> Affiliate olarak sitemimize kay�t olman�zdan mutluluk duyar�z. SITENAME.<br><br><b>ID: #Affid#</b><br><b>�ifreniz: #Password#</b><br><br>L�tfen T�klay�n <a href=\"#SiteUrl#\"><b>SITENAME</b></a> ve �ifrenizi en k�sa s�rede de�i�tirin.<br><br>�yi �anslar!<br>#AdminName# <br>SITENAME<br></td></tr></table></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';
$lang['aff_newpwd_sub'] = 'SITENAME Mesaj: Affiliate �yeli�iniz!';
$lang['aff_newpwd']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td width="77" height="25" class="module_head">#email_hdr_left#</td><td width="493" class="module_head" >&nbsp;&nbsp;Affiliate �yeli�iniz! </td></tr><tr><td width="100%" class="evenrow" colspan="2" style="padding: 5px;"><table border="0" cellspacing="0" cellpadding="6"><tr><td height="6"></td></tr><tr><td width="100%" valign="top" class="evenrow">Sevgili #Name#,<br><br>�ste�iniz �zerineSITENAME Sitesindeki affiliate �yeli�iniz i�in yeni �ifre olu�turuldu.<br><br><b>�ifreniz: #Password#</b><br><br>L�tfen T�klay�n <a href=\"#SiteUrl#\"><b>SITENAME</b></a> ve �ifrenizi en k�sa zamanda de�i�tirin.<br><br>�yi �anslar!<br>#AdminName# <br>SITENAME<br></td></tr></table></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';
$lang['add_affiliate'] = 'Reklam (Affiliate) Ekle';
$lang['mod_affiliate'] = 'Reklam (Affiliate) D�zenle';
$lang['aff_modified'] = 'Reklam (Affiliate) Bilgisi De�i�tirildi';
$lang['newuser']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td width="77" height="25" class="module_head">#email_hdr_left#</td><td width="493" class="module_head" >&nbsp;&nbsp;Yeni kullan�c� kay�t oldu!</td></tr><tr><td width="100%" class="evenrow" colspan="2" style="padding: 5px;"><table border="0" cellspacing="0" cellpadding="6"><tr><td height="6"></td></tr><tr><td width="100%" valign="top" class="evenrow">Say�n Site Y�neticisi,<br><br>Yeni kullan�c� kay�t oldu #SiteName#.<br><br>Username: #UserName#<br><br>#AdminName# <br>SITENAME<br></td></tr></table></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';
$lang['newuser_sub'] = 'Yeni Kullan�c� Kay�t Oldu';
$lang['mysettings_updated'] = 'Mail ayarlar�n�z� g�ncellendi';
$lang['mysettings_updated'] = 'Mail ayarlar�n�z� g�ncellendi';
$lang['resend_conflink_hdr'] = 'Onaylama mesaj�n� tekrar g�nder.';
$lang['resend_conflink_hdr1'] = 'Kay�ttan sonra gelen onaylama mesaj�n� almad�n�z veya kay�p m� ettiniz? Kay�t olurken kulland���n�z e-mail adresini a��a��ya yaz�p \"onaylama mesaj�n� tekrar g�nder\" butonuna bas�n.';
$lang['resend_conflink_msg'] = 'Onaylama maili tekrar g�nderildi';
$lang['resend_conflink_msg1'] = 'Kay�t i�in verdi�iniz mail adresini giriniz.';
$lang['resend_conflink_err1'] = 'Profili daha �nce onaylad�n�z. �ifrenizi unuttuysan�z<a href="forgotpass.php">�ifremi Unuttum</a> Linkinden yeni �ifrenizi al�n�z.';
$lang['about_me'] = 'Hakk�mda';
$lang['about_me_hlp'] = 'Bi ka� c�mle ile kendinizi anlat�n, di�erlerinin dikkatini �ekecek �eyler yaz�n.';
$lang['aff_forgot_pass'] = '�ifrenizimi Unuttunuz? E-Mail adresinizi girin ve "Yeni �ifre G�nder" butonuna bas�n:';
$lang['send_new_password'] = 'Yeni �ifre G�nder';
$lang['not_a_member'] = '�ye De�ilmisiniz?';
$lang['login_reminded'] = '�ifrenizi ve kullan�c� ad�n�z� ��renmek i�in t�kay�n.';
$lang['lost_confemail'] = 'Onaylama mesaj�n�z kay�p m�?';
$lang['couple_usernames'] = '�ift/Grup kullan�c� adlar�.';
$lang['couple_usernames_hlp'] = '�iftler ve gruplar iki veya daha fazla tekil ki�iyi kapsar. A��a��ya �ift veya grup i�indeki kullan�c�lar�n kullan�c� adlar�n� yaz�n. �rnek olarak: kullan�c�_1,kullan�c�_2,kullan�c�_3. Bu kullan�c�lar�n tekil kullan�c� profilleri daha �nceden kay�tl� olmal�d�r.';
$lang['blog']['del01'] = 'Bu yorumu silmek istedi�inizden emin misiniz?';
$lang['blog']['del02'] = 'Se�ileni silmek istedi�inizden emin misiniz? ';
$lang['feat_prof_del_msg'] = 'Bu profili ayr�cal�kl� profiller listesindek kald�rmak istiyor musunuz?';
$lang['feat_prof_deleted'] = 'Se�ilen profil ayr�cal�kl� profiller listesinden kald�r�ld�.';
$lang['mymatches_sub'] = 'SITENAME Mesaj: Size Uygun Profiller Maili!';
$lang['mymatches_body']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td width="77" height="25">#email_hdr_left#</td><td width="493" class="module_head" >&nbsp;&nbsp;Size Uygun Profiller Maili! </td></tr><tr><td width="570" class="evenrow" colspan="2" style="padding: 5px;"><table border="0" cellspacing="2" cellpadding="2"><tr><td height="6"></td></tr><tr><td class="evenrow">Sevgili #FirstName#,<br><br>A�a��daki profiller sizin kriterlerinize uyuyor.</td></tr><tr><td height="10" class="evenrow"> </td></tr><tr><td valign="top" class="evenrow">#matchedProfiles#</td></tr><tr><td height="10" class="evenrow"> </td></tr><tr><td class="evenrow">L�tfen Profilleri G�rmek i�in t�klay�n. <a href=\"#link#\">SITENAME</a><br><br>�yi �anslar!<br>#AdminName#<br>SITENAME<br></td></tr></table> </td></tr></table>';
$lang['on'] = ' a��k ';
$lang['use_seo_username'] = 'Kullan�c� Ad�n� URL de G�rmenizi Sa�lar.Bu Se�ene�i Kullan�d���n�zda adres bi�imi �u �ekilde olacakt�r "domain/username". Bu se�ene�i Kapatt���nda adres format� �u �ekilde olacakt�r. "domain/id.htm"';
$lang['leave_blank_no_change'] = '(de�i�iklik yoksa bo� b�rak�n)';
$lang['adminltr']['html']='<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td width="77" height="25" class="module_head">#email_hdr_left#</td><td width="493" class="module_head" >&nbsp;&nbsp;#Subject#</td></tr><tr><td width="100%" class="evenrow" colspan="2" style="padding: 5px;"><table border="0" cellspacing="0" cellpadding="6"><tr><td height="6"></td></tr><tr><td width="100%" valign="top" class="evenrow">#LetterContent#</td></tr></table></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';
$lang['adminltr']['text'] = '#LetterContent';

$lang['site_links'] = array(
	'home' => 'Ana Sayfa',
	'signup_now' => '�ye Olun',
	'chat' => 'Chat',
	'forum' => 'Forum',
	'login' => 'Giri�',
	'search' => 'Ara',
	'aboutus' => 'Hakk�m�zda',
	'forgot' => 'Kay�p �ifre?',
	'contactus' => '�leti�im',
	'privacy' => 'Gizlilik',
	'terms_of_use' => 'Kullanma Ko�ullar�',
	'services' => 'Servisler',
	'faq' => 'SSS\'ler',
	'articles' => 'Yaz�lar',
	'affliates' => 'Yay�nc�',
	'invite_a_friend' => 'Davet Et',
	'feedback' => 'Geri Bildirim'
	);


$lang['signup_gender_values'] = array(
	'M' => 'Erkek',
	'F' => 'Kad�n',
	'C' => '�ift',
	'G' => 'Grup'
	);

$lang['signup_gender_look'] = array(
	'M' => 'Erkek',
	'F' => 'Kad�n',
	'C' => '�ift',
	'G' => 'Grup',
	'B' => 'Kad�n yada Erkek',
	'A' => 'Hepsi'
	);

$lang['enabled_values'] = array(
	'Y' => 'Evet',
	'N' => 'Hay�r'
	);

$lang['display_control_type'] = array(
	'checkbox' => '�ek Kutusu',
	'radio' => 'Opsiyon Tu�u',
	'select' => 'A��l�r list men�s�',
	'textarea' => 'Giri� Kutusu'
	);


$lang['sort_types'] = array(
	'asc' => 'Y�ksek',
	'desc' => 'Al�ak'
	);

$lang['search_results_per_page'] = array( 5 => 5 , 10 => 10, 20 => 20, 50 => 50, 100 => 100 );
$lang['on_off_values'] = array( 1 => 'Evet', 0 => 'Hay�r' );

$lang['trans_method_vals'] = array(
	'CC' => 'Kredi Kart�',
	'ECHECK' => 'Elektronik Kontrol'
	);

$lang['trans_mode_vals'] = array(
	'AUTH_CAPTURE' => 'AUTH_CAPTURE',
	'AUTH_ONLY' => 'AUTH_ONLY',
	'CAPTURE_ONLY' => 'CAPTURE_ONLY',
	'CREDIT' => 'CREDIT',
	'VOID' => 'VOID',
	'PRIOR_AUTH_CAPTURE' => 'PRIOR_AUTH_CAPTURE'
 );

$lang['banner_sizes'] = array(
	'468X60' => '468 x 60',
	'100X500'=>'100 x 500',
	'120X120'=>'120 x 120'
);

$lang['banner_sizes_name'] = array( 'yatay', 'dikey', 'kare' );

$lang['filter_options'] = array(
	'id' => 'Id',
	'username' => 'Kullan�c� Ad�',
	'city' => '�ehir',
	'zip' => 'Posta Kodu',
	'status' => 'Durum'
	);

$lang['admin_rights'] = array(
		'site_stats' 				=> 'Site istatistikleri',
		'profie_approval'		 	=> 'Uygun Profiller',
		'profile_mgt' 				=> 'Profil Y�netimi',
		'section_mgt' 				=> 'B�l�m Y�netimi',
		'affiliate_mgt' 			=> 'Reklam (Affiliate) Program� Y�netimi',
		'affiliate_stats'		 	=> 'Reklam (Affiliate) �statistikleri',
		'news_mgt' 					=> 'Haber Y�netimi',
		'article_mgt' 				=> 'Makale Y�netimi',
		'story_mgt'					=> 'Hikaye Y�netimi',
		'poll_mgt'		 			=> 'Anket Y�netimi',
		'search' 					=> 'Arama',
		'ext_search'				=> 'Detayl� Arama',
		'send_letter' 				=> 'Mektup G�nder',
		'pages_mgt' 				=> 'Sayfa Y�netimi',
		'chat' 						=> 'Chat',
		'chat_mgt' 					=> 'Chat Y�netimi',
		'forum_mgt' 				=> 'Forum Y�netimi',
		'mship_mgt' 				=> '�yelik Y�netimi',
		'payment_mgt' 				=> '�deme Mod�l�',
		'banner_mgt' 				=> 'Banner Y�netimi',
		'seo_mgt' 					=> 'SEO Ayarlar�',
		'admin_mgt' 				=> 'Y�netici Ekle/Kald�r/D�zenle',
		'admin_permit_mgt'			=> 'Y�netici Haklar�',
		'global_mgt' 				=> 'Site\'nin Genel Ayarlar�',
		'change_pwd'				=> '�ifre De�i�tir',
		'cntry_mgt'					=> '�lke/B�lge/�ehir D�zenle',
		'snaps_require_approval'	=> 'Resim Onayla',
		'featured_profiles_mgt'		=> 'Ayr�cal�kl� Profil',
		'calendar_mgt'				=> 'Ajandalar',
		'event_mgt'					=> 'Olaylar� Onaylamak',
		'import_mgt'				=> 'Y�kleme',
	/* Added in 2.0 */
      	'plugin_mgt'            	=> 'Eklenti Y�netimi',
		'blog_mgt'					=> 'Blog Y�netimi',
		'profile_ratings'			=> 'Profil Pop�larite Y�netimi',
		);

$lang['extsearchhead'] = array(
	'Marital Status'		=> 'Evlilik Durumu',
	'Ethnicity'				=> 'Etnik',
	'Religion'				=> 'din',
	'Hobbies'				=> 'Hobiler',
	'Height'				=> 'Uzunluk',
	'Body Type'				=> 'V�cut Tipi',
	'Zodiac Sign'			=> 'Bur�',
	'Eye color'				=> 'G�z Rengi',
	'Hair color'			=> 'Sa� Rengi',
	'Body art'				=> 'V�cut Sanat� (D�vme-Piercing)',
	'Best feature'			=> 'En iyi �zelli�i',
	'Hot spots'				=> 'S�cak Noktalar',
	'Sports'				=> 'Ho�una gidenler',
	'Favorite things'  		=> 'Favoriler',
	'Last reading'			=> 'Son Okudu�u',
	'Common interests'		=> 'Genel �lgi Alanlar�',
	'Sense of humor'		=> 'Espri anlay���',
	'Exercise'				=> 'Egzersiz',
	'Daily diet'			=> 'G�nl�k Diyet',
	'Smoking'				=> 'Sigara',
	'Drinking'				=> '��ki',
	'Job schedule'			=> '�al��ma Program�',
	'Current annual income' => 'Gelir Durumu',
	'Living situation'		=> 'Hayat �zelli�i',
	'Kids'					=> '�ocuklar',
	'Want children'			=> '�ocuk �stiyor',
	'Weight'				=> 'Kilo',
	'Employment status'		=> '�� durumu',
	'Education'				=> '��renim',
	'Languages'				=> 'Diller',
	'Referred by'			=> 'Referans�',
);


$lang['recuring_labels'] = array(
	'0' => 'asla',
	'1' => 'g�n',
	'2' => 'hafta',
	'3' => 'ay',
	'4' => 'y�l'
	);

$lang['affiliates_error'] = array(
	18 =>'Ge�ersiz �ifre',
	20 =>'Doldurun.',
	21 =>'Doldurun.',
	25 =>'Bu e-mail kullan�lmakta,l�tfen ba�ka e-mail girin.'
);

$lang['admin_js_error_msgs'] = array(
	'',
	'�nce i�aretli kutu se�in.',
	'Bu silme i�lemine ba�lamak istiyor musun?',
	'Bu banner� silmek istiyor musun?'
	);

$lang['admin_js__delete_error_msgs'] = array('',
	1=> 'Bu B�l�m� Silmek �stedi�inizden Emin misiniz?\Bu ��lem Geri Al�namaz.',
	2=> 'Bu B�l�mden Bu Soruyu Silmek �stedi�inizden Emin misiniz?\nBu ��lem Geri Al�namaz.',
	3=> 'Bu Soru Se�eneklerini Silmek �stedi�inizden Emin misiniz?\nBu ��lem Geri Al�namaz.',
	4=> 'Bu Profili Silmek �stedi�inizden Emin misiniz?\nBu ��lem Geri Al�namaz.',
	5=> 'Bu Haberi Silmek �stedi�inizden Emin misiniz?\nBu ��lem Geri Al�namaz.',
	6=> 'Bu Hikayeyi Silmek �stedi�inizden Emin misiniz?\nBu ��lem Geri Al�namaz.',
	7=> 'Bu Makaleyi Silmek �stedi�inizden Emin misiniz?\nBu ��lem Geri Al�namaz.',
	8=> 'Bu Anketi Silmek �stedi�inizden Emin misiniz?\nBu ��lem Geri Al�namaz.',
	9=> 'Bu Anket Se�eneklerini Silmek �stedi�inizden Emin misiniz?\nBu ��lem Geri Al�namaz.',
	10=> 'Bu Banneri Silmek �stedi�inizden Emin misiniz?\nBu ��lem Geri Al�namaz.',
	11=> 'Bu Y�neticiyi Silmek �stedi�inizden Emin misiniz?\nBu ��lem Geri Al�namaz.',
/* Added in RC6 */
	12=>'Bu eyaletii silmek istiyor musun?',
	13=>'Bu �ehiri/y�reyi silmek istiyor musun',
	14=>'Bu �lkeyi silmek istiyor musun?',
	15=>'Bu k�saltmalar� silmek istiyor musun?',
	16=>'Geli�tirilmi� arama tepesi �a�r�ld���nda, geli�tirilmi� arama tepesi verilmelidir.',
	17 => 'Kullan�c� ad� aral��� se�ilidi�inde, kullan�c� ad� girilmedilidir.',
	18 => 'Bu profilleri silecek misin?\nBu ��lem Geri Al�namaz.',
	);

$lang['signup_js_errors'] = array(
	'username_noblank' => 'Kullan�c� ad� girin.' ,
	'password_noblank' => '�ifre girin.',
	'old_password_noblank' => 'eski �ifre ge�erli olmal�.',
	'new_password_noblank' => 'Yeni �ifre ge�erli olmal�..',
	'con_password_noblank' => 'Onay �ifresi ge�erli olmal�..',
	'firstname_noblank' => '�sminiz ge�erli olmal�..',
	'name_noblank' => '�sminizi girin.',
	'lastname_noblank' => 'Soyad�n�z ge�erli olmal�..',
	'email_noblank' => 'Email ge�erli olmal�..',
	'city_noblank' => '�ehir ge�erli olmal�..',
	'zip_noblank' => 'Posta kodu ge�erli olmal�..',
	'address1_noblank' => 'En az bir adres ge�erli olmal�..',
	'sectionname_noblank' => 'Bu b�l�m i�in isim verin.',
	'sendname_noblank' => 'L�tfen g�nderici\'ler ismi girin.',
	'comments_noblank' => 'Yorumunuzu girin.',
	'question_noblank' => 'Bir soru girin.',
	'extsearchhead_noblank' => 'L�tfen Detayl� Arama Ba�l���n� Girin',
	'username_charset' => 'Kullan�c� ad� i�in sadece harf ve numara ayr�ca bunu \'_\' yazabilirsiniz.',
	'password_charset' => 'Kullan�c� ad� i�in sadece harf ve numara ayr�ca bunu \'_\' yazabilirsiniz..',
	'firstname_charset' => '�sim i�in sadece harf kullanabilirsiniz.',
	'lastname_charset' => 'Soyad� i�in sadece harf kullanabilirsiniz.',
	'city_charset' => '�ehir ismi i�in sadece harf kullanabilirsiniz.',
	'zip_charset' => 'Zip kodu i�in sadece rakam kullanabilirsiniz.',
	'address_charset' => 'Ge�erli adres girin.',
	'sectionname_charset' => 'B�l�m ad� i�in sadece harf kullanabilirsiniz',
	'sendname_charset' => 'G�nderici ad� i�in sadece alfabetik karakter kullanabilirsiniz.',
	'name_charset' => '�sim i�in sadece harf kullanabilirsiniz',
	'maxlength_charset' => 'Maksimum uzunluk i�in bir tam say� girin.',
	'email_notvalid' => 'Email adresi ge�erli de�il.',
	'password_nomatch' => '�ifre ge�erli de�il.',
	'password_outrange' => '�ifre ge�erli izinler i�inde yaz�lmal�.',
	'username_outrange' => 'Kullan�c� ad�n�n uzunlu�u belirtilen aral�kta olmal�d�r.',
	'username_start_alpha' => 'Kullan�c� ad� harf ile ba�lamal�.',
	'ccowner_noblank' => 'Kredi kart� sahibi ge�erli olmal�.',
	'ccnumber_noblank' => 'Kredi kart� numaralar� ge�erli olmal�.',
	'cvvnumber_noblank' => 'Kredi kart� kontrol numaras�(3rakam) ge�erli olmal�.',
	'select_payment' => '�nce �deme �eklini se�iniz.',
	'stateprovince_noblank' => 'K�saltmalar ge�erli olmal�.',
	/* Added in RC6 */
	'subject_noblank'	=> 'Mektup konusu girilmi� olmal�',
	);

$lang['letter_errormsgs'] = array(
		0 => '�ifreniz e-mail adresinize g�nderildi. E-malinizi kontrol edin.',
		1 => 'L�tfen �lk Kay�t oldu�unuz e-mail adresini giriniz.',
		2 => '�ifre mektubu bulunamad�. �dareci ile ba�lant� kurun.',
		4 => 'E-mail g�nderirken hata olu�tu. �dareci ile ba�lant� kurun.',
		5 => 'Kay�tl� �yemiz de�ilsiniz-' . 'SITENAME' . '.<br/>L�tfen �lk Kay�t oldu�unuz e-mail adresini giriniz.'
	);

$lang['taf_errormsgs'] = array(
		0 => 'Davetiye G�nderildi.',
		'sendername_noblank' => '�sminiz.',
		'senderemail_noblank' => 'E-mailiniz.',
		'recipientemail_noblank' => 'Davetlinin E-maili.',
		'sendername_charset' => '�sim k�sm�na rakam yazmay�n�z.',
		'senderemail_charset' => 'Ge�erli e-mail giriniz.',
		'recipientemail_charset' => 'Davetli i�in ge�erli e-mail giriniz.',
		2 => 'Davetli mektubu bulunamad�..  �dareci ile ba�lant� kurun.',
		3 => 'Davet g�nderirken hata olu�tu.  �dareci ile ba�lant� kurun.',
	);

$lang['pages_errormsgs'] = array( '',
	1 => 'Sayfa ba�l��� yok.',
	2 => 'Sayfa anahtarlar� yok.',
	3 => 'Sayfa yaz�s� yok.',
	4 => 'Bu Sayfa anahtar� zaten mevcut. Ba�ka anahtar se�.',
	);

$lang['article_error'] = array(
	1 => 'Makale Ba�l��� Gerekli',
	2 => 'Makale ��eri�i Gerekli',
	3 => 'Makale Tarihi Gerekli'
);

$lang['story_error'] = array(
	1 => 'Hikaye ba�l��� ekle.',
	2 => 'Hikaye texti ekle.',
	3 => 'Hikaye tarihi ekle..',
	4 => 'Hikaye g�nderenin ismini ekle..'
);

$lang['news_error'] = array(
	1 => 'Haber ba�l��� ekle.',
	2 => 'Haber yaz�s� ekle.',
	3 => 'Hikaye tarihi  ekle..'
);


$lang['mship_errors'] = array (
	1 => '�sim gerekl.',
	2 => 'Fiyat gerekli.',
	3 => 'Ge�erlilik gerekli.',
	4 => '�cret gerekmez �deme bi�imi,sadece BEDAVA �yelikte ge�erlidir'
);
$lang['admin_error_msgs'] = array (
	'',
	'B�l�m gerekli.',
	'B�t�n gerekli yerleri doldurunuz'
	);
$lang['admin_error'] = array(
	'',
	1 => 'Admin kullan�c� ad�n� bo� b�rakmay�n�z.',
	2 => 'Admin �ifresini bo� b�rakmay�n�z.',
	3 => 'Admin ismini bo� b�rakmay�n�z.',
	4 => 'Eski �ifreyi bo� b�rakmay�n�z..',
	5 => 'Yeni �ifreyi bo� b�rakmay�n�z.',
	6 => 'Yeni kontrol �ifresini bo� b�rakmay�n�z.',
	7 => 'Yeni �ifre ve kontrol �ifresi ayn� olmal�',
	8 => 'Eski �ifreniz ge�ersiz. Yeniden deneyin.',
	9 => 'Bu kullan�c� ad� sistemde mevcut. Ba�ka kullan�c� ad� deneyin.'
);


$lang['banner_error_msgs'] = array( '',
	1 => 'Banner� bo� b�rakmay�n�z.',
	2 => 'Link URL yi bo� b�rakmay�n�z.',
	3 => 'Tooltip i bo� b�rakmay�n�z.',
	4 => 'Sadece JPG banner format� ge�erlidir'
);
$lang['poll_error'] = array(
	1 => 'Anketi bo� b�rakmay�n�z.',
	2 => 'Anket tarihini bo� b�rakmay�n�z.',
	3 => 'Se�enekleri bo� b�rakmay�n�z.',
	'txtpoll_noblank'  => 'bo� b�rakmay�n�z.',
	'txtpollopt_noblank'  => 'bo� b�rakmay�n�z.'
	);



$lang['datetime_month'] = array(
	1=>'Ocak',
	2=>'�ubat',
	3=>'Mart',
	4=>'Nisan',
	5=>'May�s',
	6=>'Haziran',
	7=>'Temmuz',
	8=>'A�ustos',
	9=>'Eyl�l',
	10=>'Ekim',
	11=>'Kas�m',
	12=>'Aral�k'
);

$lang['datetime_day'] = array(
	'sunday' => 'Pazar',
	'monday' => 'Pazartesi',
	'tuesday' => 'Sal�',
	'wednesday' => '�ar�amba',
	'thursday' => 'Per�embe',
	'friday' => 'Cuma',
	'saturday' => 'Cumartesi'
);

$lang['day_names'] = array(
	'Sun' => 'Pazar',
	'Mon' => 'Pazartesi',
	'Tue' => 'Sal�',
	'Wed' => '�ar�amba',
	'Thu' => 'Per�embe',
	'Fri' => 'Cuma',
	'Sat' => 'Cumartesi'
);

$lang['useronlinetext'] = array(
	'online_now'		=> 	'�u anda online',
	'active_24hours'	=> 	'Son 24 saat i�inde online oldu',
	'active_3days'		=>	'Son 3 g�n i�inde online oldu',
	'active_1week'		=>	'Son 1 hafta i�inde online oldu',
	'active_1month'		=>	'Son 1 ay i�inde online oldu',
	'notactive'			=>	'Son zamanlarda aktif olmad�'
);

$lang['useronlinecolor'] = array(
	'online_now'		=> 	'#FF0000',
	'active_24hours'	=> 	'#00AA00',
	'active_3days'		=>	'#AA00A0',
	'active_1week'		=>	'#0000AA',
	'active_1month'		=>	'#000000',
	'notactive'			=>	'#838383'
);

$lang['expiry_interval'] = array(
	'1'		=> '24 Saat',
	'3'		=>	'3 G�n',
	'7'		=>	'7 G�n',
	'15'	=>	'15 G�n',
	'30'	=>	'30 G�n',
	'0'		=>	'Zaman� Ge�mi�'
	);


$lang['support_currency'] = array(
		'USD' 	=> '$',
		'EUR'	=>'�',
		'INR'	=>'Rs.',
		'AUD'	=> 'AU$',
		'CD'	=> 'CAN$',
		'UKP'	=> chr(163)
		);
$lang['privileges'] = array (
	'chat' 				=> 'Chat\'e Kat�labilir',
	'blog'				=> 'Blo�\'a Kat�labilir',
	'poll'				=> 'Anket\'e Kat�labilir.',
	'forum'				=> 'Forum\'a Kat�labilir.',
	'includeinsearch' 	=> 'Arama Yapabilir',
	'message'			=> 'Posta G�nderebilir',
	/* Added in 1.1.0 */
	'message_keep_cnt'  => 'Saklayabilecegi Mesaj Say�s�',
	'message_keep_days' => 'Mesajlar�n� Saklayabilece�i G�n Say�s�',
	/* rel 2.0 */
	'messages_per_day' 	=> 'G�nl�k Mesaj G�nderme Limiti',
	/* Rel 1.0 added  */
	'allowim'			=> 'K�sa Mesaj G�nderebilir',
	'uploadpicture'		=> 'Foto�raf G�nderebilir',
	'uploadpicturecnt'	=> 'G�nderebilece�i Foto�raf Adeti',
	'allowalbum'		=> 'Gizli Alb�m Yaratabilir',
	'event_mgt'			=> 'Olay Y�netimi Yapabilir',
	/* Above is added in 1.0 */
	'seepictureprofile' => 'Profillere Bakabilir',
	'favouritelist'		=> 'buddy/ban/hot listesi Yapabilir.',
	'sendwinks'			=> 'G�z K�rpabilir.',
	/* rel 2.0 */
	'winks_per_day' 	=> 'G�nl�k G�z K�rmpa Limiti.',
	'extsearch'			=> 'Geli�mi� Arama Yapabilir.',
	'fullsignup' 		=> 'Tam Kay�t.',
	/* RC6 Patch */
	'activedays'		=> 'Ge�erlilik G�n�.',
	/* added in 2.0 */
	'saveprofiles'		=> 'Profilleri Kaydedebilir.',
	'saveprofilescnt'	=> 'Profil Kaydetme Limiti.',
	'allow_videos'		=> 'Video G�nderebilir.',
	'videoscnt'			=> 'Video G�nderme Limiti.',
	'allow_mysettings'	=> 'Kullan�c� �zelliklerini Ayarlayabilir.',
	'allow_php121'		=> 'php121 K�sa Mesajla�ma Kullanabilir.',
);


$lang['errormsgs']= array(
	00 => '',
	01 => 'Kullan�c� gir.',
	02 => '�ifre gir.',
	03 => '�ifreyi tekrar gir.',
	04 => 'ismini gir.',
	05 => 'Soyad�n� gir.',
	06 => 'Email adresini gir.',
	07 => '�ehir gir.',
	08 => 'Zip kod gir.',
	09 => 'Addres gir.',
	10 => 'Kullan�c� ad� 25 karakter.',
	11 => '�sminiz 50 karakter.',
	12 => 'Soyad�n�z 50 karakter.',
	13 => 'E-mail adresi 250 karakter.',
	14 => '�ehir 100 karakter.',
	15 => 'Adres 250 karakter.',
	16 => 'Kullan�c� ad� Harfle ba�lar.',
	17 => '�ifre Harfle ba�lar.',
	18 => '�ifreni bir daha yaz.',
	19 => 'Ge�erli e-mail adresi girin',
	20 => 'Gerekli bilgiler girilmeli .',
	21 => "Verdi�iniz bilgiler yeterli de�il. Giri� bilgilerinizi kontrol edip , girin.",
	22 => 'Bu isim var ,ba�ka isim se�in.',
	23 => 'Eski �ifreniz do�ru de�il. Do�ru �ifreyi girin.',
	25 => 'Bu email kullan�lmakta.' ,
	27 => 'Mesaj bulunamad�.',
	28 => 'L�tfen �nce dosya se�in.',
	29 => 'Bu format ge�mez,ba�ka format deneyin',
	30 => 'Soru halen en �stte.',
	31 => 'Soru halen en altta.',
	32 => 'Yorumunuz i�in te�ekk�rler. Yorumunuz i�lemdedir.',
	33 => 'Posta kodu belirtilen b�lge ile uyu�muyor.',
	34 => 'Posta kodu ge�erli de�il',
	36 => 'Hesab�n�z ask�da. �darecilerle ba�lant� kurun.',
	37 => 'Haklar�n�z Engellenmi� Durumda. Sistem Y�neticinizle Temasa Ge�in.',
	38 => 'Yanl�� bir do�um tarihi girdiniz.L�tfen kontrol edin ve tekrar deneyin.',
	39 => 'Eski �ifreniz ile yeni �ifreniz ayn� olamaz.',
	40 => '�lk se�ti�iniz ya� son se�ti�iniz ya�dan b�y�k olamaz',
	51 => 'Ba�lang�� tarihi biti� tarihinden �nce olmal�d�r.',
	52 => 'Bu �ye zaten listeye eklenmi� durumda',
	53 => 'Ge�ersiz Tarih',
	54 => 'Ge�ersiz Kullan�c� Ad� veya �ifre',
	55 => 'Mesaj g�nderebilmek i�in giri� yapmal�s�n�z',
	56 => $lang['bigger_pic_size'],
	57 => $lang['only_jpg'],
	58 => $lang['upload_unsuccessful'],
	59 => 'Bu profil listeye eklendi',
	60 => '�nizleme resmi �ok k���k minimum boyutlar: ('.$config['upload_snap_tnsize'].' X '.$config['upload_snap_tnsize'].')',
	61 => 'Yanl�� Aktivasyon Kodu',
	62 => 'Kullan�c� ad� listeden kald�r�ld�',
	63 => 'Bu kullan�c� arkada� listenize eklendi',
	64 => 'Bu kullan�c� engelleneler listenize eklendi',
	65 => 'Bu kullan�c� hot list\"inize eklendi',
	66 => 'G�z K�rpman�z G�nderildi',
	67 => $lang['upload_successful'],
	68 => 'Resim Onayland�.',
	69 => 'Resim Geri �evrildi.',
	70 => 'G�r�nt�lenme kay�tlar� silindi.',
	71 => 'G�zk�rpma kay�tlar� silindi.',
	/* Added in RC6  */
	72 => 'Kullan�c� hesab� tekrar aktifle�tirildi',
	73 => '�lke Eklendi',
	74 => '�lke Silindi',
	75 => '�lke ad� veya kodu zaten kullan�l�yor',
	76 => '�lke d�zenlendi',
	77 => 'Eyalet Eklendi',
	78 => 'Eyalet Silindi',
	79 => 'Eyalet Kodu veya Ad� Kullan�mda',
	80 => 'Eyalet D�zenlendi',
	81 => 'Eyalet Ad� Belirtilmek Zorunda',
	82 => 'Bu kullanc�c� hi� foto�raf y�klemedi ',
	83 => 'Profil Silindi',
	84 => 'Se�ilen Profiller Silindi',
	85 => 'Se�ilen Profiller Aktivite edildi.',
	86 => 'Se�ilen Profiller Rededildi.',
	87 => 'Se�ilen Profiller Beklemeye al�nd�.',

	26 => 'Profiliniz hen�z aktifle�tirilmedi. <a href=\'completereg.php\'>Hesab�n�z� aktifle�tirin</a> Do�rulama kodunu Girin veya e-mail adresinize gelen maildeki aktivasyon linkini t�klay�n.',

//	26 => 'Your affiliate account hasn\'t yet been activated by an administrator. Please wait for this activation before using your affiliate account.',

	35 => 'Profiliniz hen�z onaylanmad�.<br /> L�tfen bekleyin yada y�netici ile temasa ge�in',

/* Release 1.0 additions/modifications  */

	88 => '�lke eklendi',
	89 => '�lke silindi',
	90 => '�lke kodu zaten kullan�mda',
	91 => '�lke d�zenlendi',
	92 => '�ehir eklendi',
	93 => '�ehir silindi',
	94 => '�ehir kodu kullan�mda',
	95 => '�ehir bilgileri d�zenlendi',
	96 => 'Posta Kodu Eklendi',
	97 => 'Posta Kodu Silindi',
	98 => 'Posta Kodu Zaten Kullan�l�yor',
	99 => 'Posta Kodu De�i�tirildi',
	100 => '�ehir alan� bo� b�rak�lamaz',
	101 => 'Yanl�� �ifre',
	102 => 'Olay Onayland�',
	103 => 'Olay Rededildi',
	301 => 'Yanl�� B�lgesel Saat',
	302 => 'Alb�m G�ncellendi',
/* 1.1.0 additions */
	104 => 'Belirti�iniz Giri� Bulunamad�. Yazd�klar�n�z� kontrol edip tekrar deneyin, veya hat�rlatma fonksiyonunu kullan�n.',
	105 => 'Kullan�c� engellenler listesinde',
	/* Added in 2.0 */
	120	=>	'G�venlik Kodu Girilmelidir.',
	121 => 'Yanl�� G�venlik Kodu ',
	122 => 'Bu g�nk� mesaj kotan�z� doldurdunuz. L�tfen yar�n tekrar deneyin.',
	123 => 'Bu g�nl� g�z k�rpma kotan�z� doldurdunuz. L�tfen yar�n tekrar deneyin',
	124 => 'Video dosyas� y�klendi',
	125 => 'Video dosyas� y�klenirken hata.',
	126 => 'Kendiniz hakk�nda bilgiler girmelisiniz',
	128 => 'Kar�-koca �ift isimleride tekil isim gibi girilebilir.',
	129 => 'Kullan�c� adlar� kullan�mda olmal�d�r.',
	201 => '�zlenenler listesine izin verilenden fazla kullan�c� eklemeye �al���yorsunuz.',
	202 => 'Bu kullan�c� izlenen profiller listesine eklendi.',
	203 => 'Bu profil zaten izleme listesinde.',
	);

$lang['blog_errors'] = array(
   'nosetup' => 'Blog ayarlar� belirtilmelidir.' ,
   'name_noblank' => 'Blog ad� belirtilmelidir.' ,
   'description_noblank' => 'Blog tan�m� belirtilmelidir. ',
   'date_posted_noblank' => 'G�nderim tarihi belirtilmelidir.' ,
   'title_noblank' => 'Ba�l�k belirtilmelidir.' ,
   'story_noblank' => 'Bir hikaye belirtilmelidir.' ,
   'max_stories_warning' => 'Maksimum hikaye say�n�z� a�t�n�z. Yeni hikaye ekleyemezsiniz.' ,
   'comment_bad_word' => 'Yorumunuz Yasaklanm�� kelimeler i�eriyor %s' ,
);

$lang['forum_values'] = array(
   'None' => 'Yok',
   'phpBB' => 'phpBB',
   'vBulletin' => 'vBulletin',
   'myBB' => 'myBB',
   'Phorum' => 'Phorum',
   );

$lang['glblsettings_groups'] = array(
1	=>	'Site Bilgisi',
2	=> 	'Kullan�c� Kontrolleri',
3	=>	'Ajanda Kontrolleri',
4	=>	'Mail Ayarlar�',
5	=>	'Profil Resimleri ve K���k Resimler',
6	=>	'Sayfa ve Tablo yap�s�',
);


$lang['user_choices'] = array(
	'email_message_received' 	=> "Yeni mesaj al�n���nda E-mail G�nder",
	'email_wink_received'		=> "Biri bana g�z k�rpt���nda E-mail G�nder",
	'email_blog_commented'		=> "Biri Blo�uma yorum ekledi�inde E-mail G�nder",
	'email_mship_expiry'		=> "�yelik zamanlar� ge�iyorsa hat�rlatma E-maili G�nder",
	'email_message_read'		=> "G�nderdi�im mesajlar okunu�unda E-mail G�nder",
	'email_buddy_list'			=> "Biri beni arkada� listesine ekledi�inde E-mail G�nder",
	'email_ban_list'			=> "Biri beni engelleme listesine ekledi�inde E-mail G�nder",
	'email_hot_list'			=> "Biri beni s�cak listeye ekledi�inde E-mail G�nder",
	"allow_buddy_view_album"	=> "Arkada� listemdekiler gizli foto�raflar�m� g�rs�n",
	"allow_hotlist_view_album"	=> "S�cak listemdekiler gizli foto�raflar�m� g�rs�n",
	'email_match_mail_days'		=> "Bana Yak�n profillerin g�nderilme s�kl��� (G�n olarak), 0 Girerseniz Mail g�nderilmez",
	);

$lang['site_links'] = array(
	'home' => 'Ana Sayfa',
	'signup_now' => '�ye Olun',
	'chat' => 'Chat',
	'forum' => 'Forum',
	'login' => 'Giri�',
	'search' => 'Ara',
	'aboutus' => 'Hakk�m�zda',
	'forgot' => 'Kay�p �ifre?',
	'contactus' => '�leti�im',
	'privacy' => 'Gizlilik',
	'terms_of_use' => 'Kullanma Ko�ullar�',
	'services' => 'Servisler',
	'faq' => 'SSS\'ler',
	'articles' => 'Yaz�lar',
	'affliates' => 'Yay�nc�',
	'invite_a_friend' => 'Davet Et',
	'feedback' => 'Geri Bildirim'
	);

$lang['signup_gender_values'] = array(
	'M' => 'Erkek',
	'F' => 'Kad�n',
	'C' => '�ift',
	'G' => 'Grup'
	);

$lang['signup_gender_look'] = array(
	'M' => 'Erkek',
	'F' => 'Kad�n',
	'C' => '�ift',
	'G' => 'Grup',
	'B' => 'Kad�n yada Erkek',
	'A' => 'Hepsi'
	);

$lang['status_disp'] = array(
	'pending' => 'Ask�da',
	'active' => 'Aktif',
	'rejected' => 'Red Et',
	'suspended' => 'Ertele',
	);

$lang['status_enum'] = array(
	'approval' => 'Ask�da',
	'active' => 'Aktif',
	'rejected' => 'Reddet',
	'suspended' => 'Beklemede',
	);
$lang['status_act'] = array(
	'approval' => 'Ask�da',
	'active' => 'Aktif',
	'rejected' => 'Redet',
	'suspended' => 'Beklemede',
	/* added in 1.1.0 */
	'cancel' => '�ptal'
	);

?>