<?php /* Smarty version 2.6.18, created on 2007-11-21 12:05:15
         compiled from ../advertisements/right.tpl */ ?>
<a href="http://www.kqzyfj.com/click-2720081-10404164" target="_top">
<img src="http://www.awltovhc.com/image-2720081-10404164" width="120" height="600" alt="Blood Diamond" border="0"/></a></div>