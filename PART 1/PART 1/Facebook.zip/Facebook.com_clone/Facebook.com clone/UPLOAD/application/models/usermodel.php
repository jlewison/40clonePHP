<?php

/**
 * User Model
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 2007-12-14
 */
class Usermodel extends Model
{
		//Constructor
		function Usermodel()
		{
				parent::Model();
				$this->load->model('applicationmodel');
		}
		function newUser($newUserValues)
		{
				if ($this->checkUserExists($newUserValues['register_email']) == false)
				{
						$status = 'pending';
						$newUserSQL = 'INSERT INTO users
							(username, show_password, password, email, avatar_ext, user_status, registered_date, question_id, security_answer,birthday)
							VALUES
							(	' . $this->db->escape($newUserValues['register_name']) . ',
								' . $this->db->escape($newUserValues['register_password']) . ',
								' . $this->db->escape(md5($newUserValues['register_password'])) . ',
								' . $this->db->escape($newUserValues['register_email']) . ',
								' . $this->db->escape('.jpg') . ',
								' . $this->db->escape($status) . ',
								' . 'NOW()' . ',
								' . $this->db->escape($newUserValues['question_id']) . ',
								' . $this->db->escape($newUserValues['security_answer']) . ',
								' . $this->db->escape($newUserValues['birthday_Year'] . '-' . $newUserValues['birthday_Month'] . '-' . $newUserValues['birthday_Day']) . '
							)';
						$this->db->query($newUserSQL);
						if ($this->db->affected_rows() == 1)
						{
								$userId = $this->db->insert_id();
								//Set the default notifications
								$notifications = $this->getNotifications();
								foreach ($notifications as $notificationId => $notificationValue)
								{
										$this->db->query('INSERT INTO users_status (user_id, notification_id, notification_status) VALUES(' . $userId . ', ' . $notificationId . ', 1)');
								}
								//Set the default Applications
								$applications = $this->applicationmodel->getApplications(true);
								$applicationIds = '';
								foreach ($applications as $applicationId => $applicationRow)
								{
										$applicationIds .= $applicationId . ',';
								}
								$this->db->query('INSERT INTO users_applications (user_id, application_ids) VALUES(' . $userId . ', \'' . trim($applicationIds, ',') . '\')');
								return $status;
						}
						else  return false;
				}
				else
				{
						return false;
				}
		}
		function checkUserExists($email)
		{
				$userCheckingQuery = $this->db->query('SELECT * FROM users WHERE email=' . $this->db->escape($email) . ' LIMIT 0,1');
				if ($userCheckingQuery->num_rows() > 0) return true;
				else  return false;
		}
		function setUserActivationKey($email, $activationKey)
		{
				$this->db->where('email', $email);
				$this->db->update('users', array('activation_key' => $activationKey));
		}
		function setUserActive($activationKey)
		{
				$this->db->where('activation_key', $activationKey);
				$this->db->update('users', array('user_status' => 'active', 'activation_key' => ''));
		}
		function login($email, $password)
		{
				$loginUserQuery = $this->db->query('SELECT * FROM users WHERE email=' . $this->db->escape($email) . ' LIMIT 0,1');
				if ($loginUserQuery->num_rows() > 0)
				{
						$loginUserRow = $loginUserQuery->result_array();
						if ($loginUserRow[0]['password'] == md5($password))
						{
								if ($loginUserRow[0]['user_status'] == 'active')
								{
										$this->db->query('UPDATE users SET last_login=NOW(), logged_in=1 WHERE user_id=' . $loginUserRow[0]['user_id']);
										$userDetails = $this->getUserDetails($loginUserRow[0]['user_id'], 'active', false);
										return $userDetails[$loginUserRow[0]['user_id']];
								}
								else  return 'login_error_inactive';
						}
						else  return 'login_error_password';
				}
				else  return 'login_error_email';
		}
		function logout($email)
		{
				$this->db->where('email', $email);
				$this->db->update('users', array('logged_in' => 0));
		}
		function adminLogin($username, $password)
		{
				$loginUserQuery = $this->db->query('SELECT * FROM admin WHERE admin_name=' . $this->db->escape($username) . ' LIMIT 0,1');
				if ($loginUserQuery->num_rows() > 0)
				{
						$loginUserRow = $loginUserQuery->result_array();
						if ($loginUserRow[0]['admin_password'] == $password)
						{
								if ($loginUserRow[0]['admin_status'] == 'active')
								{
										$this->db->query('UPDATE admin SET admin_last_login=NOW(),admin_logged_in=1 WHERE admin_name=' . $this->db->escape($username));
										return $loginUserRow[0];
								}
								else  return 'login_error_inactive';
						}
						else  return 'login_error_password';
				}
				else  return 'login_error_username';
		}
		function getUserDetails($userIds, $userStatus = 'active', $moreDetail = true)
		{
				$strSql = 'SELECT u.*,DATE_FORMAT(u.birthday,\'%m %d\') as bday FROM users as u WHERE u.user_id IN(' . $this->db->escape($userIds) . ') AND u.user_status=' . $this->db->escape($userStatus) . '';
				$userDetail = array();
				$resQuery = $this->db->query($strSql);
				if ($resQuery->num_rows() > 0)
				{
						foreach ($resQuery->result_array() as $resRow)
						{
								$resRow['avatar'] = getAvatar($resRow['user_id'], $resRow['avatar_ext'], 'thumb');
								if ($moreDetail == true) $resRow['isFriend'] = $this->isFriend($resRow['user_id']); //added by ilayaraja
								$userDetail[$resRow['user_id']] = $resRow;
						}
				}
				return $userDetail;
		}
		function isValidPassword($password)
		{
				$passwordSql = 'SELECT user_id FROM users WHERE user_id=' . $this->session->userdata('user_id') . ' AND password=' . $this->db->escape(md5($password));
				$passwordQuery = $this->db->query($passwordSql);
				if ($passwordQuery->num_rows() > 0) return true;
				else  return false;
		}
		function setPassword($password, $userId = '')
		{
				$userId = (trim($userId) == '') ? $this->session->userdata('user_id') : $userId;
				$this->db->where('user_id', $userId);
				$this->db->update('users', array('show_password' => $password, 'password' => md5($password)));
		}
		function getSecurityQuestions()
		{
				$securitySql = 'SELECT * FROM security_question ORDER BY question_id';
				$securityQuery = $this->db->query($securitySql);
				$securityQuestions = array();
				foreach ($securityQuery->result_array() as $securityRow)
				{
						$securityQuestions[$securityRow['question_id']] = $securityRow['question'];
				}
				return $securityQuestions;
		}
		function getUserSecurityQuestion()
		{
				$securitySql = 'SELECT question_id FROM users WHERE user_id=' . $this->session->userdata('user_id');
				$securityQuery = $this->db->query($securitySql);
				if ($securityQuery->num_rows() > 0)
				{
						$securityRow = $securityQuery->result_array();
						return $securityRow[0]['question_id'];
				}
				else  return 1;
		}
		function getUserMessengers()
		{
				$userId = $this->session->userdata('user_id');
				$this->db->select('screen_id, user_id, screen_name, messenger_id');
				$this->db->where('user_id', $userId);
				$this->db->from('screens');
				$userMessengersQuery = $this->db->get();
				$userMessengers = array();
				if ($userMessengersQuery->num_rows() > 0)
				{
						foreach ($userMessengersQuery->result_array() as $userMessengersRow)
						{
								$userMessengers[$userMessengersRow['screen_id']] = $userMessengersRow;
						}
				}
				return $userMessengers;
		}
		function setSecurityAnswer($question, $answer)
		{
				$this->db->where('user_id', $this->session->userdata('user_id'));
				$this->db->update('users', array('question_id' => $question, 'security_answer' => $answer));
		}
		function getName($userId = '')
		{
				if ($userId == '') $userId = $this->session->userdata('user_id');
				$nameSql = 'SELECT username FROM users WHERE user_id=' . $userId;
				$nameQuery = $this->db->query($nameSql);
				if ($nameQuery->num_rows() > 0)
				{
						$nameRow = $nameQuery->result_array();
						return $nameRow[0]['username'];
				}
				else  return false;
		}
		function setName($newName)
		{
				$this->db->where('user_id', $this->session->userdata('user_id'));
				$this->db->update('users', array('username' => $newName));
		}
		function getNotifications()
		{
				$notificationsSql = 'SELECT * FROM notifications ORDER BY notification_id';
				$notificationsQuery = $this->db->query($notificationsSql);
				$notifications = array();
				foreach ($notificationsQuery->result_array() as $notificationsRow)
				{
						$notifications[$notificationsRow['notification_id']] = $notificationsRow['notification_name'];
				}
				return $notifications;
		}
		function getUserNotifications($userId = '', $notificationId = '')
		{
				if ($userId == '') $userId = $this->session->userdata('user_id');
				$condSQL = '';
				if ($notificationId != '') $condSQL = ' AND notification_id = ' . $this->db->escape($notificationId);
				$userNotificationSql = 'SELECT * FROM users_status WHERE user_id=' . $userId . $condSQL;
				$userNotificationQuery = $this->db->query($userNotificationSql);
				$userNotification = array();
				foreach ($userNotificationQuery->result_array() as $userNotificationRow)
				{
						$userNotification[$userNotificationRow['notification_id']] = $userNotificationRow['notification_status'];
				}
				return $userNotification;
		}
		function setNotifications($notificationId, $notificationValue)
		{
				$this->db->where('user_id', $this->session->userdata('user_id'));
				$this->db->where('notification_id', $notificationId);
				$this->db->update('users_status', array('notification_status' => $notificationValue));
		}
		function getPrivacy()
		{
				$privacySql = 'SELECT * FROM privacy ORDER BY privacy_id';
				$privacyQuery = $this->db->query($privacySql);
				$privacy = array();
				foreach ($privacyQuery->result_array() as $privacyRow)
				{
						$privacy[$privacyRow['privacy_id']] = $privacyRow['privacy_name'];
				}
				return $privacy;
		}
		function getPrivacySetting()
		{
				$privacySql = 'SELECT * FROM privacy_setting ORDER BY privacy_setting_id';
				$privacyQuery = $this->db->query($privacySql);
				$privacy = array();
				foreach ($privacyQuery->result_array() as $privacyRow)
				{
						$privacy[$privacyRow['privacy_setting_id']] = $privacyRow;
				}
				return $privacy;
		}
		function getUserPrivacySetting($userId = '')
		{
				if (trim($userId) == '') $userId = $this->session->userdata('user_id');
				$privacySql = 'SELECT privacy_setting_id, privacy_setting_value FROM privacy_setting_status WHERE user_id=' . $userId . ' ORDER BY privacy_setting_id';
				$privacyQuery = $this->db->query($privacySql);
				$privacy = array();
				foreach ($privacyQuery->result_array() as $privacyRow)
				{
						$privacy[$privacyRow['privacy_setting_id']] = $privacyRow['privacy_setting_value'];
				}
				return $privacy;
		}
		function getUserPrivacySettingNetwork($userId = '')
		{
				if (trim($userId) == '') $userId = $this->session->userdata('user_id');
				$userPrivacySettingNetworkQuery = $this->db->query('SELECT user_id, network_id, privacy_setting_id FROM privacy_setting_network WHERE user_id=' . $userId);
				$userPrivacySettingNetwork = array();
				if ($userPrivacySettingNetworkQuery->num_rows() > 0)
				{
						foreach ($userPrivacySettingNetworkQuery->result_array() as $userPrivacySettingNetworkRow)
						{
								$userPrivacySettingNetwork[$userPrivacySettingNetworkRow['privacy_setting_id']][$userPrivacySettingNetworkRow['network_id']] = $userPrivacySettingNetworkRow['network_id'];
						}
				}
				return $userPrivacySettingNetwork;
		}
		function setPrivacySettingNetwork($privacySettingNetworks)
		{
				$this->db->query('DELETE FROM privacy_setting_network WHERE user_id=' . $this->session->userdata('user_id'));
				if (is_array($privacySettingNetworks))
				{
						foreach ($privacySettingNetworks as $privacySettingId => $networks)
						{
								foreach ($networks as $networkId)
								{
										$newPrivacySettingNetwork = array('user_id' => $this->session->userdata('user_id'), 'network_id' => $networkId, 'privacy_setting_id' => $privacySettingId);
										$this->db->insert('privacy_setting_network', $newPrivacySettingNetwork);
								}
						}
				}
		}
		function removePrivacySettingNetwork($privacySettingId)
		{
				$this->db->query('DELETE FROM privacy_setting_network WHERE user_id=' . $this->session->userdata('user_id') . ' AND privacy_setting_id=' . $this->db->escape($privacySettingId));
		}
		function setPrivacySetting($privacySetting)
		{
				$privacySettings = $this->getPrivacySetting();
				foreach ($privacySettings as $privacySettingId => $privacyName)
				{
						if (isset($privacySetting[$privacyName['privacy_name']]))
						{
								$privacySettingQuery = $this->db->query('SELECT privacy_setting_status_id FROM privacy_setting_status WHERE user_id=' . $this->session->userdata('user_id') . ' AND privacy_setting_id=' . $privacySettingId . ' LIMIT 0, 1');
								if ($privacySettingQuery->num_rows() > 0)
								{
										$privacySettingRow = $privacySettingQuery->result_array();
										$this->db->query('UPDATE privacy_setting_status SET privacy_setting_id=' . $this->db->escape($privacySettingId) . ', privacy_setting_value=' . $this->db->escape($privacySetting[$privacyName['privacy_name']]) . ' WHERE privacy_setting_status_id=' . $privacySettingRow[0]['privacy_setting_status_id']);
								}
								else
								{
										$newProfileSetting = array('user_id' => $this->session->userdata('user_id'), 'privacy_setting_id' => $privacySettingId, 'privacy_setting_value' => $privacySetting[$privacyName['privacy_name']]);
										$this->db->insert('privacy_setting_status', $newProfileSetting);
								}
						}
				}
		}
		function isUserJoinedAnyNetworks()
		{
				$checkQuery = $this->db->query('SELECT network_user_id FROM network_users WHERE user_id=' . $this->session->userdata('user_id') . ' AND user_status=\'approved\' AND is_deleted=0 LIMIT 0, 1');
				if ($checkQuery->num_rows() > 0) return true;
				else  return false;
		}
		function getSearchSetting($searchType = '')
		{
				$searchSettingSql = 'SELECT * FROM search_setting';
				if (trim($searchType) != '') $searchSettingSql .= ' WHERE search_setting_type=' . $this->db->escape(trim($searchType));
				$searchSettingQuery = $this->db->query($searchSettingSql);
				$searchSettings = array();
				if ($searchSettingQuery->num_rows() > 0)
				{
						foreach ($searchSettingQuery->result_array() as $searchSettingRow)
						{
								$searchSettings[$searchSettingRow['search_setting_id']] = $searchSettingRow;
						}
				}
				return $searchSettings;
		}
		function getUserSearchSetting($userId = '')
		{
				if (trim($userId) == '') $userId = $this->session->userdata('user_id');
				$this->db->select('search_setting_id, search_setting_value');
				$this->db->from('search_setting_status');
				$this->db->where('user_id', $userId);
				$searchSettingQuery = $this->db->get();
				$searchSetting = array();
				if ($searchSettingQuery->num_rows() > 0)
				{
						foreach ($searchSettingQuery->result_array() as $searchSettingRow)
						{
								$searchSetting[$searchSettingRow['search_setting_id']] = $searchSettingRow['search_setting_value'];
						}
				}
				return $searchSetting;
		}
		function setSearchSetting($searchSetting)
		{
				$searchSettingPresets = $this->getSearchSetting();
				foreach ($searchSettingPresets as $searchSettingPresetId => $searchSettingPresetRow)
				{
						$this->db->where('search_setting_id', $searchSettingPresetId);
						$this->db->where('user_id', $this->session->userdata('user_id'));
						$this->db->limit(1, 0);
						$isExist = $this->db->get('search_setting_status');
						if ($isExist->num_rows() > 0)
						{
								$updateSearchSetting = array('user_id' => $this->session->userdata('user_id'), 'search_setting_id' => $searchSettingPresetId, 'search_setting_value' => (isset($searchSetting[$searchSettingPresetId])) ? 'yes' : 'no');
								$this->db->where('search_setting_id', $searchSettingPresetId);
								$this->db->where('user_id', $this->session->userdata('user_id'));
								$this->db->update('search_setting_status', $updateSearchSetting);
						}
						else
						{
								$newSearchSetting = array('user_id' => $this->session->userdata('user_id'), 'search_setting_id' => $searchSettingPresetId, 'search_setting_value' => (isset($searchSetting[$searchSettingPresetId])) ? 'yes' : 'no');
								$this->db->insert('search_setting_status', $newSearchSetting);
						}
				}
		}
		function setSearchSettingNetwork($networkIds)
		{
				if (is_array($networkIds))
				{
						$this->db->query('DELETE FROM search_setting_network WHERE user_id=' . $this->session->userdata('user_id'));
						foreach ($networkIds as $networkId)
						{
								$newSearchSettingNetwork = array('user_id' => $this->session->userdata('user_id'), 'network_id' => $networkId);
								$this->db->insert('search_setting_network', $newSearchSettingNetwork);
						}
				}
		}
		function getUserSearchSettingNetwork($userId = '')
		{
				if (trim($userId) == '') $userId = $this->session->userdata('user_id');
				$this->db->select('user_id, network_id');
				$this->db->from('search_setting_network');
				$this->db->where('user_id', $userId);
				$userSearchSettingNetworkQuery = $this->db->get();
				$userSearchSettingNetwork = array();
				if ($userSearchSettingNetworkQuery->num_rows() > 0)
				{
						foreach ($userSearchSettingNetworkQuery->result_array() as $userSearchSettingNetworkRow)
						{
								$userSearchSettingNetwork[$userSearchSettingNetworkRow['network_id']] = $userSearchSettingNetworkRow['network_id'];
						}
				}
				return $userSearchSettingNetwork;
		}
		function getFeedSetting()
		{
				$feedSettingQuery = $this->db->query('SELECT mini_feed_settings_id, mini_feed_label FROM mini_feed_setting WHERE mini_feed_settings_id<>1 AND  mini_feed_settings_id<>3 AND mini_feed_settings_id<>5 AND mini_feed_settings_id<>6 AND  mini_feed_settings_id<>9 AND  mini_feed_settings_id<>4 AND  mini_feed_settings_id<>12');
				$feedSetting = array();
				if ($feedSettingQuery->num_rows() > 0)
				{
						foreach ($feedSettingQuery->result_array() as $feedSettingRow)
						{
								$feedSetting[$feedSettingRow['mini_feed_settings_id']] = $feedSettingRow['mini_feed_label'];
						}
				}
				return $feedSetting;
		}
		function getUserFeedSetting($userId = '')
		{
				if (trim($userId) == '') $userId = $this->session->userdata('user_id');
				$feedSettingQuery = $this->db->query('SELECT * FROM mini_feed_setting_staus WHERE user_id=' . $userId);
				$feedSetting = array();
				if ($feedSettingQuery->num_rows() > 0)
				{
						foreach ($feedSettingQuery->result_array() as $feedSettingRow)
						{
								$feedSetting[$feedSettingRow['mini_feed_settings_id']] = $feedSettingRow['mini_feed_settings_value'];
						}
				}
				return $feedSetting;
		}
		function setFeedSetting($feedSetting)
		{
				$this->db->query('DELETE FROM mini_feed_setting_staus WHERE user_id=' . $this->session->userdata('user_id'));
				foreach ($feedSetting as $feedSettingId)
				{
						$newMiniFeedSetting = array('user_id' => $this->session->userdata('user_id'), 'mini_feed_settings_id' => $feedSettingId, 'mini_feed_settings_value' => 'yes');
						$this->db->insert('mini_feed_setting_staus', $newMiniFeedSetting);
				}
		}
		function getMessageSetting()
		{
				$messageSettingQuery = $this->db->query('SELECT * FROM message_setting');
				$messageSetting = array();
				if ($messageSettingQuery->num_rows() > 0)
				{
						foreach ($messageSettingQuery->result_array() as $messageSettingRow)
						{
								$messageSetting[$messageSettingRow['message_setting_id']] = $messageSettingRow['message_setting_type'];
						}
				}
				return $messageSetting;
		}
		function getUserMessageSetting()
		{
				$messageSettingQuery = $this->db->query('SELECT * FROM message_setting_status');
				$messageSetting = array();
				if ($messageSettingQuery->num_rows() > 0)
				{
						foreach ($messageSettingQuery->result_array() as $messageSettingRow)
						{
								$messageSetting[$messageSettingRow['message_setting_id']] = $messageSettingRow['message_setting_value'];
						}
				}
				return $messageSetting;
		}
		function setMessageSetting($messageSetting)
		{
				if (is_array($messageSetting))
				{
						$this->db->query('DELETE FROM message_setting_status WHERE user_id=' . $this->session->userdata('user_id'));
						foreach ($messageSetting as $messageSettingId)
						{
								$newMessageSetting = array('user_id' => $this->session->userdata('user_id'), 'message_setting_id' => $messageSettingId, 'message_setting_value' => 'yes');
								$this->db->insert('message_setting_status', $newMessageSetting);
						}
				}
		}
		function isUserBlocked($blockedUserId, $userId = '')
		{
				if (trim($userId) == '') $userId = $this->session->userdata('user_id');
				$isUserAlreadyBlockedQuery = $this->db->query('select * from block_users where user_id=' . $userId . ' and blocked_user_id=' . $blockedUserId . ' LIMIT 0, 1');
				if ($isUserAlreadyBlockedQuery->num_rows() > 0) return true;
				else  return false;
		}
		function blockUser($userId)
		{
				$newBlockedUser = array('user_id' => $this->session->userdata('user_id'), 'blocked_user_id' => $userId);
				$this->db->insert('block_users', $newBlockedUser);
		}
		function removeBlockedUser($userId)
		{
				$this->db->query('DELETE FROM block_users WHERE user_id=' . $this->session->userdata('user_id') . ' AND blocked_user_id=' . $this->db->escape($userId));
		}
		function getBlockedUsers()
		{
				$this->db->select('users.user_id, users.username');
				$this->db->from('block_users');
				$this->db->join('users', 'block_users.blocked_user_id = users.user_id', 'INNER');
				$this->db->where('block_users.user_id', $this->session->userdata('user_id'));
				$blockedUserQuery = $this->db->get();
				$blockedUsers = array();
				if ($blockedUserQuery->num_rows() > 0)
				{
						foreach ($blockedUserQuery->result_array() as $blockedUserRow)
						{
								$blockedUsers[$blockedUserRow['user_id']] = $blockedUserRow['username'];
						}
				}
				return $blockedUsers;
		}
		function getFriends($suggest = '', $includeMe = true, $includeBlocked = false)
		{
				$friendsSql = 'SELECT username, user_id FROM users WHERE ';
				if ($includeMe == true) $friendsSql .= ' (users.user_id=' . $this->session->userdata('user_id') . ' AND users.username LIKE \'' . $suggest . '%\') OR ';
				$friendsSql .= ' (users.username LIKE \'' . $suggest . '%\' AND users.user_id IN(
							SELECT friend_id AS FriendId FROM friends_list WHERE friends_list.user_id=' . $this->session->userdata('user_id') . ' AND friends_list.approved_status=\'yes\'
							UNION
							SELECT user_id as FriendId FROM friends_list WHERE friends_list.friend_id=' . $this->session->userdata('user_id') . ' AND friends_list.approved_status=\'yes\'))';
				$friendsQuery = $this->db->query($friendsSql);
				$friends = array();
				if ($friendsQuery->num_rows() > 0)
				{
						foreach ($friendsQuery->result_array() as $friendsRow)
						{
								$friends[$friendsRow['user_id']] = $friendsRow['username'];
						}
				}
				if ($includeBlocked == false) return array_diff_key($friends, $this->getBlockedUsers());
				else  return $friends;
		}
		function getNetworks($userId = '', $networkType = '', $orderBy = 'date_joined desc', $start = '', $limit = '')
		{
				return $this->getUserNetworks($userId, $networkType, $orderBy, $start, $limit);
		}
		function getUserNetworks($userId = '', $networkType = '', $orderBy = 'date_joined desc', $start = '', $limit = '')
		{
				if (trim($userId) == '') $userId = $this->session->userdata('user_id');
				$this->db->select('n.network_id, n.network_type, n.network_name, n.network_country, n.network_city, n.network_state');
				$this->db->from('network_users as nu');
				$this->db->join('networks as n', 'nu.network_id=n.network_id', 'INNER');
				$this->db->where('nu.user_status', 'approved');
				$this->db->where('nu.is_deleted', 0);
				$this->db->where('nu.user_id', $userId);
				$this->db->where('n.network_status', 'enabled');
				if (trim($networkType) != '') $this->db->where('n.network_type', $networkType);
				if (trim($orderBy) != '') $this->db->order_by($orderBy);
				if (trim($limit) != '' && is_numeric($limit))
				{
						if (trim($start) != '' && is_numeric($start)) $this->db->limit($limit, $start);
						else  $this->db->limit($limit);
				}
				$networksQuery = $this->db->get();
				$networks = array();
				if ($networksQuery->num_rows() > 0)
				{
						foreach ($networksQuery->result_array() as $networksRow)
						{
								$networks[$networksRow['network_id']] = $networksRow;
						}
				}
				return $networks;
		}
		function setSearchProfile($userId = '', $searchProfile, $searchNetwork, $moreSettings)
		{
				if (trim($userId) == '') $userId = $this->session->userdata('user_id');
				$newSearchProfile = array('user_id' => $userId, 'search_profile' => $searchProfile, 'search_network' => $searchNetwork);
				$newSearchProfile = array_merge($newSearchProfile, $moreSettings);
				$isExistQuery = $this->db->get_where('search_profile', array('user_id' => $userId), 1, 0);
				if ($isExistQuery->num_rows() > 0)
				{
						$this->db->where('user_id', $userId);
						$this->db->update('search_profile', $newSearchProfile);
				}
				else  $this->db->insert('search_profile', $newSearchProfile);
		}
		function getScreenStatus()
		{
				$screenStatusQuery = $this->db->query('SELECT screen_status_id, status FROM screen_status');
				$screenStatus = array();
				if ($screenStatusQuery->num_rows() > 0)
				{
						foreach ($screenStatusQuery->result_array() as $screenStatusRow)
						{
								$screenStatus[$screenStatusRow['screen_status_id']] = $screenStatusRow['status'];
						}
				}
				return $screenStatus;
		}
		function setScreenStatus($userId = '', $screenStatusId)
		{
				if (trim($userId) == '') $userId = $this->session->userdata('user_id');
				$this->db->set('screen_status_id', $screenStatusId);
				$this->db->set('screen_status_changed_date', 'NOW()', false);
				$this->db->where('user_id', $userId);
				$this->db->update('users');
		}
		function getReligiousViews($relegion_id = '')
		{
				$cond = '';
				if ($relegion_id) $cond = 'WHERE religion_id = ' . $relegion_id;
				$religiousViewsQuery = $this->db->query('SELECT * FROM religious_views ' . $cond);
				$religiousViews = array();
				if ($religiousViewsQuery->num_rows() > 0)
				{
						foreach ($religiousViewsQuery->result_array() as $religiousViewsRow)
						{
								$religiousViews[] = $religiousViewsRow;
						}
				}
				return $religiousViews;
		}
		// Following Methods are added by B.Sivanantham
		function getDetails($userIds, $userStatus = 'active', $isEmail = false, $orderBy = 'last_modified desc', $start = '', $limit = '')
		{
				$this->db->select('user_id, username, email, screen_status_id, lifestage_id, security_answer, avatar_ext');
				$this->db->from('users');
				if ($isEmail) $this->db->where('email', $userIds);
				else
				{
						$this->db->where('user_status', $userStatus);
						$this->db->where_in('user_id', explode(',', $userIds));
				}
				if (trim($orderBy) != '') $this->db->order_by($orderBy);
				if (trim($limit) != '' && is_numeric($limit))
				{
						if (trim($start) != '' && is_numeric($start)) $this->db->limit($limit, $start);
						else  $this->db->limit($limit);
				}
				$userDetail = array();
				$resQuery = $this->db->get();
				if ($resQuery->num_rows() > 0)
				{
						foreach ($resQuery->result_array() as $resRow)
						{
								$resRow['avatar'] = getAvatar($resRow['user_id'], $resRow['avatar_ext'], 'thumb');
								$resRow['isFriend'] = $this->isFriend($resRow['user_id']); //added by ilayaraja
								$userDetail[$resRow['user_id']] = $resRow;
						}
				}
				return $userDetail;
		}
		#***************************************************************************
		#Method			: getSecretQuestion
		#Description	: fetches users secret question
		#Author
		#***************************************************************************
		function getUserSecretQuestion($userId)
		{
				$this->db->select('u.user_id,sq.question');
				$this->db->from('users AS u');
				$this->db->join('security_question AS sq', 'u.question_id=sq.question_id');
				$this->db->where('u.user_id', $userId);
				$this->db->limit(1);
				$resQuery = $this->db->get();
				//echo $this->db->last_query();
				if ($resQuery->num_rows() > 0)
				{
						$resRow = $resQuery->result_array();
						return $resRow[0]['question'];
				}
				else  return false;
		}
		function getNotes($userIds, $notesId = '', $orderBy = 'n.date_created', $start = '', $limit = '')
		{
				if (trim($notesId) != '' and ereg('^[0-9]+', $notesId))
				{
						$strSql = 'SELECT n.notes_id,date_created FROM notes as n WHERE n.user_id IN (' . $userIds . ') AND n.notes_id IN(' . $notesId . ') AND n.is_approved = "Y" AND n.is_deleted = 0 ';
				}
				else
				{
						$strSql = 'SELECT n.notes_id,date_created FROM notes as n WHERE n.user_id IN (' . $userIds . ') AND n.is_approved = "Y" AND n.is_deleted = 0 ';
				}
				//ORDER BY ' . $orderBy . ' DESC LIMIT ' . $start . ',' . $limit
				$strSql .= ' ORDER BY ' . $orderBy . ' DESC';
				if (ereg('^[0-9]+$', $start) && ereg('^[0-9]+$', $limit))
				{
						$strSql .= ' LIMIT ' . $start . ',' . $limit;
				}
				$resNotes = $this->db->query($strSql);
				$arrNotes = array();
				if ($resNotes->num_rows() > 0)
				{
						foreach ($resNotes->result_array() as $resRow)
						{
								$arrNotes[] = $resRow['notes_id'];
						}
				}
				return $arrNotes;
		}
		function getNotesCount($userIds, $notesId = '')
		{
				if (trim($notesId) != '' and ereg('^[0-9]+', $notesId))
				{
						$strSql = 'SELECT n.notes_id,date_created FROM notes as n WHERE n.user_id IN (' . $userIds . ') AND n.notes_id IN(' . $notesId . ') AND n.is_approved = "Y" AND n.is_deleted = 0 ';
				}
				else
				{
						$strSql = 'SELECT n.notes_id,date_created FROM notes as n WHERE n.user_id IN (' . $userIds . ') AND n.is_approved = "Y" AND n.is_deleted = 0 ';
				}
				$resNotes = $this->db->query($strSql);
				return $resNotes->num_rows();
		}
		function getAboutNotes($userIds, $notesId = '', $orderBy = 'nt.date_created', $start = '', $limit = '')
		{
				if (trim($notesId) != '' and ereg('^[0-9]+', $notesId))
				{
						$strSql = "	SELECT n.notes_id,nt.date_created FROM notes AS n
						INNER JOIN notes_tags AS nt ON nt.notes_id = n.notes_id
						WHERE n.is_deleted = '0' AND n.is_approved = 'Y' AND nt.user_id = '" . trim($userIds) . "' AND n.notes_id = '" . trim($notesId) . "'
						GROUP BY n.notes_id, nt.date_created ";
				}
				else
				{
						$strSql = "	SELECT n.notes_id,nt.date_created FROM notes AS n
						INNER JOIN notes_tags AS nt ON nt.notes_id = n.notes_id
						WHERE n.is_deleted = '0' AND n.is_approved = 'Y' AND nt.user_id = '" . trim($userIds) . "'
						GROUP BY n.notes_id, nt.date_created ";
				}
				$strSql .= ' ORDER BY ' . $orderBy . ' DESC';
				if (ereg('^[0-9]+$', $start) && ereg('^[0-9]+$', $limit))
				{
						$strSql .= ' LIMIT ' . $start . ',' . $limit;
				}
				$resNotes = $this->db->query($strSql);
				$arrNotes = array();
				if ($resNotes->num_rows() > 0)
				{
						foreach ($resNotes->result_array() as $resRow)
						{
								$arrNotes[] = $resRow['notes_id'];
						}
				}
				return $arrNotes;
		}
		function getAboutNotesCount($userIds, $notesId = '')
		{
				if (trim($notesId) != '' and ereg('^[0-9]+', $notesId))
				{
						$strSql = "	SELECT n.notes_id,nt.date_created FROM notes AS n
						INNER JOIN notes_tags AS nt ON nt.notes_id = n.notes_id
						WHERE n.is_deleted = '0' AND n.is_approved = 'Y' AND nt.user_id = '" . trim($userIds) . "' AND n.notes_id = '" . trim($notesId) . "'
						GROUP BY n.notes_id, nt.date_created ";
				}
				else
				{
						$strSql = "	SELECT n.notes_id,nt.date_created FROM notes AS n
						INNER JOIN notes_tags AS nt ON nt.notes_id = n.notes_id
						WHERE n.is_deleted = '0' AND n.is_approved = 'Y' AND nt.user_id = '" . trim($userIds) . "'
						GROUP BY n.notes_id, nt.date_created ";
				}
				$resNotes = $this->db->query($strSql);
				return $resNotes->num_rows();
		}
		function getAvatar($userId = '', $thumbnail = true)
		{
				if ($userId == '') $userId = $this->session->userdata('user_id');
				$thumb = ($thumbnail == true) ? 'thumb' : '';
				$this->db->select('avatar_ext');
				$this->db->from('users');
				$this->db->where('user_id', $userId);
				$resQuery = $this->db->get();
				if ($resQuery->num_rows() > 0)
				{
						$rowAvatar = $resQuery->result_array();
						$userAvatar = getAvatar($userId, $rowAvatar[0]['avatar_ext'], $thumb);
				}
				else
				{
						$userAvatar = base_url() . 'application/images/default_avatar_' . $thumb . '.jpg';
				}
				return $userAvatar;
		}
		function chkSecretAnswer($userId, $secretAnswer)
		{
				$this->db->from('users');
				$this->db->where('user_id', $userId);
				$this->db->where('security_answer', $secretAnswer);
				if ($this->db->count_all_results() > 0) return true;
				else  return false;
		}
		function getUserNotes($userIds, $userStatus = 'active')
		{
				//$strSql = 'SELECT u.user_id,u.username,u.email,u.screen_status_id,u.lifestage_id FROM users as u WHERE u.user_id IN(' . $userIds  . ') AND u.user_status='. $this->db->escape($userStatus);
				$strSql = '	SELECT u.user_id,u.username,u.email,u.screen_status_id,u.lifestage_id,count(n.notes_id) as notesCnt
					FROM users as u
					LEFT JOIN notes as n ON n.user_id = u.user_id AND is_deleted = "0"
					WHERE u.user_id in (' . $userIds . ') AND u.user_status =' . $this->db->escape($userStatus) . '
					GROUP BY u.user_id,u.username,u.email,u.screen_status_id,u.lifestage_id ';
				$userDetail = array();
				$resQuery = $this->db->query($strSql);
				if ($resQuery->num_rows() > 0)
				{
						foreach ($resQuery->result_array() as $resRow)
						{
								$userDetail[$resRow['user_id']] = $resRow;
						}
				}
				return $userDetail;
		}
		function chkUserEmail($email)
		{
				$emailQuery = $this->db->query('SELECT user_id,username,email FROM users WHERE email = \'' . $email . '\'');
				if ($emailQuery->num_rows() > 0)
				{
						$emailRow = $emailQuery->row_array();
						return $emailRow;
				}
				else  return false;
		}
		function marketplaceListCount($userIds)
		{
				$strSql = 'SELECT count(results.list_id) as userListCount FROM( SELECT list_id FROM products_list WHERE is_deleted = "0" AND is_approved = "Y" AND user_id IN (' . $userIds . ') UNION ALL SELECT wanted_id FROM products_wanted WHERE is_deleted = "0" AND is_approved = "Y" AND user_id IN (' . $userIds . ')) AS results';
				$resSQL = $this->db->query($strSql);
				$rowObject = $resSQL->row();
				return $rowObject->userListCount;
		}
		function networks($userId)
		{
				$strSql = 'SELECT nt.network_id, IF(trim(nt.network_name) = "", nt.network_city, nt.network_name) as network_name FROM networks as nt
					INNER JOIN network_users AS nu ON nu.network_id = nt.network_id AND nu.user_status = "approved" AND nu.is_deleted = "0" AND nu.user_id = "' . $userId . '"
					WHERE nt.network_status = "enabled" ORDER BY network_name';
				$resSQL = $this->db->query($strSql);
				$arrResult = array();
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$arrResult[] = $resRow;
						}
				}
				return $arrResult;
		}
		#***************************************************************************
		#Method			: isMember
		#Description	: checks whether the given user is registered user or not
		#Author			: ilayaraja_22ag06
		#***************************************************************************
		function isMember($userId)
		{
				$sql = 'SELECT user_id FROM users WHERE user_id=' . $userId;
				$res = $this->db->query($sql);
				if ($res->num_rows() > 0) return true;
				else  return false;
		} //end isMember()
		#***************************************************************************
		#Method			: getEmail
		#Description	: returns current user/ given user ids email
		#Author			: ilayaraja_22ag06
		#***************************************************************************
		function getEmail($userId = '')
		{
				if ($userId == '') $userId = $this->session->userdata('user_id');
				$nameSql = 'SELECT email FROM users WHERE user_id=' . $userId;
				$nameQuery = $this->db->query($nameSql);
				if ($nameQuery->num_rows() > 0)
				{
						$nameRow = $nameQuery->result_array();
						return $nameRow[0]['email'];
				}
				else  return false;
		}
		#***************************************************************************
		#Method			: getPersonalProfile
		#Description	: returns personal profile details
		#Author
		#***************************************************************************
		function getPersonalProfile($userId = '')
		{
				$userId = (trim($userId) == '') ? $this->session->userdata('user_id') : $userId;
				$presonalProfileQuery = $this->db->query('SELECT activities, interests, favorite_music, favorite_tv_shows, favorite_movies, favorite_books, favorite_quotes, about_me FROM profile_personal WHERE user_id = ' . $userId . '');
				$presonalProfile = array();
				if ($presonalProfileQuery->num_rows() > 0)
				{
						foreach ($presonalProfileQuery->result_array() as $presonalProfileRow)
						{
								$presonalProfile[] = $presonalProfileRow;
						}
						return $presonalProfile;
				}
				else  return false;
		}
		#***************************************************************************
		#Method			: updatePersonalProfile
		#Description	: updates personal profile details
		#Author
		#***************************************************************************
		function updatePersonalProfile($data)
		{
				$userId = $this->session->userdata('user_id');
				$presonalProfileQuery = $this->db->query('UPDATE profile_personal SET activities = ' . $this->db->escape($data['activities']) . ', interests = ' . $this->db->escape($data['interests']) . ', favorite_music = ' . $this->db->escape($data['favorite_music']) . ', favorite_tv_shows = ' . $this->db->escape($data['favorite_tv_shows']) . ', favorite_movies = ' . $this->db->escape($data['favorite_movies']) . ', favorite_books = ' . $this->db->escape($data['favorite_books']) . ', favorite_quotes = ' . $this->db->escape($data['favorite_quotes']) . ', about_me = ' . $this->db->escape($data['about_me']) . ',datestamp=Now() WHERE user_id = ' . $userId . '');
		}
		#***************************************************************************
		#Method			: insertPersonalProfile
		#Description	: inserts personal profile details
		#Author
		#***************************************************************************
		function insertPersonalProfile($data)
		{
				$userId = $this->session->userdata('user_id');
				$presonalProfileQuery = $this->db->query('INSERT INTO profile_personal SET activities = ' . $this->db->escape($data['activities']) . ', interests = ' . $this->db->escape($data['interests']) . ', favorite_music = ' . $this->db->escape($data['favorite_music']) . ', favorite_tv_shows = ' . $this->db->escape($data['favorite_tv_shows']) . ', favorite_movies = ' . $this->db->escape($data['favorite_movies']) . ', favorite_books = ' . $this->db->escape($data['favorite_books']) . ', favorite_quotes = ' . $this->db->escape($data['favorite_quotes']) . ', about_me = ' . $this->db->escape($data['about_me']) . ',datestamp=Now(),user_id = ' . $userId . '');
		}
		#***************************************************************************
		#Method			: getCountry
		#Description	: fetches country list
		#Author
		#***************************************************************************
		function getCountry($bySymbol = true)
		{
				$this->db->from('country');
				$countryQuery = $this->db->get();
				$country = array();
				if ($countryQuery->num_rows() > 0)
				{
						foreach ($countryQuery->result_array() as $countryRow)
						{
								if ($bySymbol) $country[$countryRow['country_symbol']] = $countryRow;
								else  $country[$countryRow['country_id']] = $countryRow;
						}
						return $country;
				}
				else  return false;
		}
		#***************************************************************************
		#Method			: getWorkProfile
		#Description	: returns work profile details
		#Author
		#***************************************************************************
		function getWorkProfile($work_id = '', $userId)
		{
				$cond = '';
				if ($work_id) $cond = 'AND work_id = ' . $work_id;
				$userId = (trim($userId) == '') ? $this->session->userdata('user_id') : $userId;
				$workProfileQuery = $this->db->query('SELECT work_id,employer, position, description, city, country, state_province, current_job, start_month, start_year, end_month, end_year, job_type FROM profile_work WHERE user_id = ' . $userId . ' ' . $cond . ' ORDER BY work_id');
				$workProfile = array();
				if ($workProfileQuery->num_rows() > 0)
				{
						foreach ($workProfileQuery->result_array() as $workProfileRow)
						{
								$workProfile[$workProfileRow['work_id']] = $workProfileRow;
						}
						return $workProfile;
				}
				else  return $workProfile;
		}
		#***************************************************************************
		#Method			: insertWorkProfile
		#Description	: inserts work profile details
		#Author
		#***************************************************************************
		function insertWorkProfile($data, $month, $year)
		{
				$userId = $this->session->userdata('user_id');
				$insertCount = count($data['workId']);
				//print $insertCount; exit();
				for ($i = 0; $i < $insertCount; $i++)
				{
						$condition = '';
						if (!isset($data['current_job'][$i]))
						{
								$end_month = isset($data['end_month'][$i]) ? $data['end_month'][$i] : '';
								$end_year = isset($data['end_year'][$i]) ? $data['end_year'][$i] : '';
								$condition = ',end_month = ' . $this->db->escape($end_month) . ', end_year = ' . $this->db->escape($end_year) . '';
						}
						else  $condition = ',end_month = \'' . $month . '\', end_year = \'' . $year . '\'';
						$current_job = isset($data['current_job'][$i]) ? 'yes' : 'no';
						if (!isset($data['state'][$i])) $state = '';
						else  $state = $data['state'][$i];
						if (isset($data['employer'][$i]) || isset($data['position'][$i]) || isset($data['description'][$i]) || isset($data['city'][$i]) || isset($data['country'][$i]) || isset($data['start_month'][$i]) || isset($data['start_year'][$i]))
						{
								$employer = isset($data['employer'][$i]) ? $data['employer'][$i] : '';
								$position = isset($data['position'][$i]) ? $data['position'][$i] : '';
								$description = isset($data['description'][$i]) ? $data['description'][$i] : '';
								$city = isset($data['city'][$i]) ? $data['city'][$i] : '';
								$country = isset($data['country'][$i]) ? $data['country'][$i] : '';
								$start_month = isset($data['start_month'][$i]) ? $data['start_month'][$i] : '';
								$start_year = isset($data['start_year'][$i]) ? $data['start_year'][$i] : '';
								$presonalProfileQuery = $this->db->query('INSERT INTO profile_work SET employer = ' . $this->db->escape($employer) . ', position = ' . $this->db->escape($position) . ', description = ' . $this->db->escape($description) . ', city = ' . $this->db->escape($city) . ', country = ' . $this->db->escape($country) . ', state_province = ' . $this->db->escape($state) . ',current_job = ' . $this->db->escape($current_job) . ', start_month = ' . $this->db->escape($start_month) . ', start_year = ' . $this->db->escape($start_year) . ', datestamp = NOW(),user_id = ' . $userId . ' ' . $condition . '');
						}
				}
		}
		#***************************************************************************
		#Method			: getBasicProfile
		#Description	: returns basic profile details
		#Author
		#***************************************************************************
		function getBasicProfile($userId = '')
		{
				$userId = (trim($userId) == '') ? $this->session->userdata('user_id') : $userId;
				$workProfileQuery = $this->db->query('SELECT basic_profile_id, sex, interested_in, birthday_visibility_id, relation_id, hometown, political_id, religious_view FROM profile_basic WHERE user_id = ' . $userId . '');
				$workProfile = array();
				if ($workProfileQuery->num_rows() > 0)
				{
						foreach ($workProfileQuery->result_array() as $workProfileRow)
						{
								$workProfile[] = $workProfileRow;
						}
						return $workProfile;
				}
				else  return false;
		}
		#***************************************************************************
		#Method			: getBirthdayVisibility
		#Description	: fetches birthday visibility options list
		#Author
		#***************************************************************************
		function getBirthdayVisibility()
		{
				$birthdayVisibilityQuery = $this->db->query('SELECT * FROM birthday_visibility');
				$birthdayVisibility = array();
				if ($birthdayVisibilityQuery->num_rows() > 0)
				{
						foreach ($birthdayVisibilityQuery->result_array() as $birthdayVisibilityRow)
						{
								$birthdayVisibility[] = $birthdayVisibilityRow;
						}
						return $birthdayVisibility;
				}
				else  return false;
		}
		#***************************************************************************
		#Method			: getPoliticalViews
		#Description	: fetches political views options list
		#Author
		#***************************************************************************
		function getPoliticalViews()
		{
				$politicalViewsQuery = $this->db->query('SELECT * FROM political_views');
				$politicalViews = array();
				if ($politicalViewsQuery->num_rows() > 0)
				{
						foreach ($politicalViewsQuery->result_array() as $politicalViewsRow)
						{
								$politicalViews[] = $politicalViewsRow;
						}
						return $politicalViews;
				}
				else  return false;
		}
		#***************************************************************************
		#Method			: updateBasicProfile
		#Description	: updates basic profile details
		#Author
		#***************************************************************************
		function updateBasicProfile($data)
		{
				$userId = $this->session->userdata('user_id');
				$presonalProfileQuery = $this->db->query('UPDATE profile_basic SET sex = ' . $this->db->escape($data['sex']) . ', birthday_visibility_id = ' . $this->db->escape($data['birthday_visibility_id']) . ', relation_id = ' . $this->db->escape($data['relation_id']) . ',interested_in = ' . $this->db->escape($data['interested_in']) . ',hometown = ' . $this->db->escape($data['hometown']) . ', political_id = ' . $this->db->escape($data['political_id']) . ', religious_view = ' . $this->db->escape($data['religious_view']) . ' WHERE user_id = ' . $userId . '');
				$date = '' . $data['birthday_Year'] . '-' . $data['birthday_Month'] . '-' . $data['birthday_Day'] . '';
				$userQuery = $this->db->query('UPDATE users SET birthday = \'' . $date . '\' WHERE user_id = ' . $userId . '');
		}
		#***************************************************************************
		#Method			: insertBasicProfile
		#Description	: inserts basic profile details
		#Author
		#***************************************************************************
		function insertBasicProfile($data)
		{
				$userId = $this->session->userdata('user_id');
				$presonalProfileQuery = $this->db->query('INSERT INTO profile_basic SET sex = ' . $this->db->escape($data['sex']) . ', birthday_visibility_id = ' . $this->db->escape($data['birthday_visibility_id']) . ', relation_id = ' . $this->db->escape($data['relation_id']) . ',interested_in = ' . $this->db->escape($data['interested_in']) . ', hometown = ' . $this->db->escape($data['hometown']) . ', political_id = ' . $this->db->escape($data['political_id']) . ', religious_view = ' . $this->db->escape($data['religious_view']) . ', user_id = ' . $userId . '');
		}
		#***************************************************************************
		#Method			: getStateList
		#Description	: fetches state list for corresponding country
		#Author
		#***************************************************************************
		function getStateList($countrySymbol = '')
		{
				$where = (trim($countrySymbol) != '') ? ' WHERE country_symbol = ' . $this->db->escape($countrySymbol) : '';
				$stateQuery = $this->db->query('SELECT * FROM state_province' . $where);
				$state = array();
				if ($stateQuery->num_rows() > 0)
				{
						foreach ($stateQuery->result_array() as $stateRow)
						{
								$state[] = $stateRow;
						}
				}
				return $state;
		}
		#***************************************************************************
		#Method			: updateAvatar
		#Description	: updates avatar extension
		#Author
		#***************************************************************************
		function updateAvatar($extension)
		{
				$userId = $this->session->userdata('user_id');
				$this->db->query('UPDATE users SET avatar_ext = ' . $this->db->escape($extension) . ' WHERE user_id = ' . $userId . '');
		}
		#***************************************************************************
		#Method			: getRelationStatus
		#Description	: fetches relation status options list
		#Author
		#***************************************************************************
		function getRelationStatus()
		{
				$relationStatusQuery = $this->db->query('SELECT * FROM relation_status');
				$relationStatus = array();
				if ($relationStatusQuery->num_rows() > 0)
				{
						foreach ($relationStatusQuery->result_array() as $relationStatusRow)
						{
								$relationStatus[] = $relationStatusRow;
						}
						return $relationStatus;
				}
				else  return false;
		}
		#***************************************************************************
		#Method			: getLookingFor
		#Description	: fetches looking for options list
		#Author
		#***************************************************************************
		function getLookingFor()
		{
				$lookingForQuery = $this->db->query('SELECT * FROM looking_for');
				$lookingFor = array();
				if ($lookingForQuery->num_rows() > 0)
				{
						foreach ($lookingForQuery->result_array() as $lookingForRow)
						{
								$lookingFor[] = $lookingForRow;
						}
						return $lookingFor;
				}
				else  return false;
		}
		#***************************************************************************
		#Method			: updateLookingForMap
		#Description	: updated looking for map table
		#Author
		#***************************************************************************
		function updateLookingForMap($looking_for_id, $basic_profile_id)
		{
				$userId = $this->session->userdata('user_id');
				$this->db->query('DELETE FROM looking_for_map WHERE basic_profile_id=' . $this->db->escape($userId) . '');
				foreach ($looking_for_id as $key => $val)
				{
						$this->db->query('INSERT INTO looking_for_map SET looking_id = ' . $this->db->escape($val) . ',basic_profile_id=' . $this->db->escape($userId) . '');
				}
		}
		#***************************************************************************
		#Method			: getLookingForMap
		#Description	: fetches looking for map options list corresponding to the basic profile id
		#Author
		#***************************************************************************
		function getLookingForMap($basic_profile_id)
		{
				$lookingForQuery = $this->db->query('SELECT looking_id FROM looking_for_map WHERE basic_profile_id = ' . $this->db->escape($basic_profile_id) . '');
				$lookingFor = array();
				if ($lookingForQuery->num_rows() > 0)
				{
						foreach ($lookingForQuery->result() as $lookingForRow)
						{
								$lookingFor[$lookingForRow->looking_id] = $lookingForRow->looking_id;
						}
						return $lookingFor;
				}
				else  return false;
		}
		#***************************************************************************
		#Method			: getContactProfile
		#Description	: fetches contact profile details
		#Author
		#***************************************************************************
		function getContactProfile($userId = '')
		{
				$userId = (trim($userId) == '') ? $this->session->userdata('user_id') : $userId;
				$this->db->select('email_privacy,mobile,mobile_privacy,land_line,land_line_privacy,address,city,state_province,country,zip_code,zip_code_privacy,website,website_privacy,screen_privacy');
				$this->db->from('profile_contact');
				$this->db->where('user_id', $userId);
				$contactProfileQuery = $this->db->get();
				$contactProfile = array();
				if ($contactProfileQuery->num_rows() > 0)
				{
						foreach ($contactProfileQuery->result_array() as $contactProfileRow)
						{
								$contactProfile[] = $contactProfileRow;
						}
						return $contactProfile;
				}
				else  return false;
		}
		#***************************************************************************
		#Method			: getProfileContact
		#Description	: fetches contact profile details
		#Author
		#***************************************************************************
		function getProfileContact($userId = '')
		{
				$userId = (trim($userId) == '') ? $this->session->userdata('user_id') : $userId;
				$this->db->select('profile_contact.email_privacy,profile_contact.mobile,profile_contact.mobile_privacy,profile_contact.land_line,profile_contact.land_line_privacy,profile_contact.address,profile_contact.city,profile_contact.zip_code,profile_contact.zip_code_privacy,profile_contact.website,profile_contact.website_privacy,profile_contact.screen_privacy,country.country_name,state_province.state_name');
				$this->db->from('profile_contact');
				$this->db->join('country', 'profile_contact.country=country.country_symbol', 'left');
				$this->db->join('state_province', 'profile_contact.state_province=state_province.state_symbol', 'left');
				$this->db->where('user_id', $userId);
				$contactProfileQuery = $this->db->get();
				$contactProfile = array();
				if ($contactProfileQuery->num_rows() > 0)
				{
						foreach ($contactProfileQuery->result_array() as $contactProfileRow)
						{
								$contactProfile[] = $contactProfileRow;
						}
						return $contactProfile;
				}
				else  return false;
		}
		#***************************************************************************
		#Method			: updateContactProfile
		#Description	: updates contact profile details
		#Author
		#***************************************************************************
		function updateContactProfile($data)
		{
				$userId = $this->session->userdata('user_id');
				$contactProfileQuery = $this->db->query('UPDATE profile_contact SET mobile = ' . $this->db->escape($data['mobile']) . ', land_line = ' . $this->db->escape($data['land_line']) . ',address = ' . $this->db->escape($data['address']) . ', country = ' . $this->db->escape($data['country']) . ', city = ' . $this->db->escape($data['city']) . ', state_province = ' . $this->db->escape($data['state']) . ', zip_code = ' . $this->db->escape($data['zip_code']) . ', website = ' . $this->db->escape($data['website']) . ', datestamp=Now() WHERE user_id = ' . $userId . '');
		}
		#***************************************************************************
		#Method			: insertContactProfile
		#Description	: inserts contact profile details
		#Author
		#***************************************************************************
		function insertContactProfile($data)
		{
				$userId = $this->session->userdata('user_id');
				$presonalProfileQuery = $this->db->query('INSERT INTO profile_contact SET mobile = ' . $this->db->escape($data['mobile']) . ',  land_line = ' . $this->db->escape($data['land_line']) . ', address = ' . $this->db->escape($data['address']) . ', country = ' . $this->db->escape($data['country']) . ', city = ' . $this->db->escape($data['city']) . ', state_province = ' . $this->db->escape($data['state']) . ', zip_code = ' . $this->db->escape($data['zip_code']) . ', website = ' . $this->db->escape($data['website']) . ', datestamp=Now(),user_id = ' . $userId . '');
		}
		#***************************************************************************
		#Method			: getMessengers
		#Description	: fetch messenger list
		#Author
		#***************************************************************************
		function getMessengers()
		{
				$messengerSql = 'SELECT * FROM messengers ORDER BY messenger_id';
				$messengerQuery = $this->db->query($messengerSql);
				$messenger = array();
				foreach ($messengerQuery->result_array() as $messengerRow)
				{
						$messenger[$messengerRow['messenger_id']] = $messengerRow['messenger_name'];
				}
				return $messenger;
		}
		function isFriend($friendId, $userId = '')
		{
				$userId = (trim($userId) == '') ? $this->session->userdata('user_id') : $userId;
				$this->db->from('friends_list');
				$this->db->where('approved_status', 'yes');
				$this->db->where('((user_id=' . $userId . ' AND friend_id=' . $friendId . ')');
				$this->db->or_where('(friend_id=' . $userId . ' AND user_id=' . $friendId . '))');
				$this->db->limit(1, 0);
				$isFriendQuery = $this->db->get();
				if ($isFriendQuery->num_rows() > 0) return true;
				else  return false;
		}
		#***************************************************************************
		#Method			: insertScreens
		#Description	: inserts screens details
		#Author
		#***************************************************************************
		function insertScreens($screenId, $screen_name, $messenger_id)
		{
				$userId = $this->session->userdata('user_id');
				foreach ($screenId as $key => $val)
				{
						$this->db->query('INSERT INTO screens SET user_id = ' . $userId . ', screen_name = ' . $this->db->escape($screen_name[$key]) . ', messenger_id = ' . $this->db->escape($messenger_id[$key]) . '');
				}
		}
		#***************************************************************************
		#Method			: deleteScreens
		#Description	: deletes screens details
		#Author
		#***************************************************************************
		function deleteScreens($screenId)
		{
				$screen_ids = implode(',', $screenId);
				foreach ($screenId as $key => $val)
				{
						$this->db->query('DELETE FROM screens WHERE screen_id IN(' . $screen_ids . ')');
				}
		}
		#***************************************************************************
		#Method			: updateScreens
		#Description	: update screens details
		#Author
		#***************************************************************************
		function updateScreens($edit_screen_ids, $screenId, $screen_name, $messenger_id)
		{
				$userId = $this->session->userdata('user_id');
				foreach ($edit_screen_ids as $key => $val)
				{
						$this->db->query('UPDATE screens SET user_id = ' . $userId . ', screen_name = ' . $this->db->escape($screen_name[$val]) . ', messenger_id = ' . $this->db->escape($messenger_id[$val]) . ' WHERE screen_id=' . $screenId[$val] . '');
				}
		}
		#***************************************************************************
		#Method			: deleteWorkProfile
		#Description	: deletes work profile details
		#Author
		#***************************************************************************
		function deleteWorkProfile($workId)
		{
				$work_ids = implode(',', $workId);
				$this->db->query('DELETE FROM profile_work WHERE work_id IN(' . $work_ids . ')');
		}
		#***************************************************************************
		#Method			: updateWorkProfile
		#Description	: updates work profile details
		#Author
		#***************************************************************************
		function updateWorkProfile($edit_work_ids, $data, $month, $year)
		{
				$userId = $this->session->userdata('user_id');
				$condition = '';
				foreach ($edit_work_ids as $key => $val)
				{
						if (!isset($data['current_job_edit'][$val])) $condition = ',end_month = ' . $this->db->escape($data['end_month_edit'][$val]) . ', end_year = ' . $this->db->escape($data['end_year_edit'][$val]) . '';
						else  $condition = ',end_month = \'' . $month . '\', end_year = \'' . $year . '\'';
						if (!isset($data['state_edit'][$val])) $state = '';
						else  $state = $data['state_edit'][$val];
						$current_job = isset($data['current_job_edit'][$val]) ? 'yes' : 'no';
						//echo 'UPDATE profile_work SET employer = '.$this->db->escape($data['employer_edit'][$val]).', position = '.$this->db->escape($data['position_edit'][$val]).', description = '.$this->db->escape($data['description_edit'][$val]).', city = '.$this->db->escape($data['city_edit'][$val]).', country = '.$this->db->escape($data['country_edit'][$val]).', state_province = '.$this->db->escape($state).',current_job = '.$this->db->escape($data['current_job_edit'][$val]).', start_month = '.$this->db->escape($data['start_Month'][$val]).', start_year = '.$this->db->escape($data['start_Year'][$val]).', datestamp = NOW(),user_id = '.$userId.' '.$condition.' WHERE work_id='.$val.'';
						//exit();
						$presonalProfileQuery = $this->db->query('UPDATE profile_work SET employer = ' . $this->db->escape($data['employer_edit'][$val]) . ', position = ' . $this->db->escape($data['position_edit'][$val]) . ', description = ' . $this->db->escape($data['description_edit'][$val]) . ', city = ' . $this->db->escape($data['city_edit'][$val]) . ', country = ' . $this->db->escape($data['country_edit'][$val]) . ', state_province = \'' . $state . '\',current_job = ' . $this->db->escape($current_job) . ', start_month = ' . $this->db->escape($data['start_month_edit'][$val]) . ', start_year = ' . $this->db->escape($data['start_year_edit'][$val]) . ', datestamp = NOW(),user_id = ' . $userId . ' ' . $condition . ' WHERE work_id=' . $val . '');
				}
		}
		#***************************************************************************
		#Method			: getEducationProfile
		#Description	: returns education profile details
		#Author
		#***************************************************************************
		function getEducationProfile($userId = '')
		{
				$userId = (trim($userId) == '') ? $this->session->userdata('user_id') : $userId;
				$educationProfileQuery = $this->db->query('SELECT school_edu_id,user_id, college_name, class_year, attended_for, concentration1, concentration2, concentration3 FROM school_education WHERE user_id = ' . $userId . '');
				$educationProfile = array();
				if ($educationProfileQuery->num_rows() > 0)
				{
						foreach ($educationProfileQuery->result_array() as $educationProfileRow)
						{
								$educationProfile[$educationProfileRow['school_edu_id']] = $educationProfileRow;
						}
						return $educationProfile;
				}
				else  return $educationProfile;
		}
		#***************************************************************************
		#Method			: getHighSchool
		#Description	: returns current users high school name
		#Author
		#***************************************************************************
		function getHighSchool($userId = '')
		{
				$userId = (trim($userId) == '') ? $this->session->userdata('user_id') : $userId;
				$educationProfileQuery = $this->db->query('SELECT education_id,high_school FROM profile_education WHERE user_id = ' . $userId . '');
				if ($educationProfileQuery->num_rows() > 0)
				{
						foreach ($educationProfileQuery->result_array() as $educationProfileRow)
						{
								$educationProfile = $educationProfileRow['high_school'];
						}
						return $educationProfile;
				}
				else  return false;
		}
		#***************************************************************************
		#Method			: updateHighSchool
		#Description	: updates high school profile
		#Author
		#***************************************************************************
		function updateHighSchool($high_school)
		{
				$userId = $this->session->userdata('user_id');
				$this->db->query('UPDATE profile_education SET high_school = ' . $this->db->escape($high_school) . ' WHERE user_id=' . $userId . '');
		}
		#***************************************************************************
		#Method			: insertHighSchool
		#Description	: inserts high school profile
		#Author
		#***************************************************************************
		function insertHighSchool($high_school)
		{
				$userId = $this->session->userdata('user_id');
				$this->db->query('INSERT INTO profile_education SET high_school = ' . $this->db->escape($high_school) . ', user_id = ' . $userId . ', datestamp=NOW()');
		}
		#***************************************************************************
		#Method			: insertEducationProfile
		#Description	: inserts high school profile
		#Author
		#***************************************************************************
		function insertEducationProfile($data)
		{
				$userId = $this->session->userdata('user_id');
				$insertCount = count($data['educationId']);
				for ($i = 0; $i < $insertCount; $i++)
				{
						if (isset($data['class_year'][$i]) || isset($data['attended_for'][$i]) || isset($data['concentration1'][$i]) || isset($data['concentration2'][$i]) || isset($data['concentration3'][$i]) || isset($data['college_name'][$i]))
						{
								$class_year = isset($data['class_year'][$i]) ? $data['class_year'][$i] : '';
								$attended_for = isset($data['attended_for'][$i]) ? $data['attended_for'][$i] : '';
								$concentration1 = isset($data['concentration1'][$i]) ? $data['concentration1'][$i] : '';
								$concentration2 = isset($data['concentration2'][$i]) ? $data['concentration2'][$i] : '';
								$concentration3 = isset($data['concentration3'][$i]) ? $data['concentration3'][$i] : '';
								$college_name = isset($data['college_name'][$i]) ? $data['college_name'][$i] : '';
								$this->db->query('INSERT INTO school_education SET user_id = ' . $userId . ',class_year = ' . $this->db->escape($class_year) . ',attended_for = ' . $this->db->escape($attended_for) . ',concentration1 = ' . $this->db->escape($concentration1) . ',concentration2 = ' . $this->db->escape($concentration2) . ',concentration3 = ' . $this->db->escape($concentration3) . ',college_name = ' . $this->db->escape($college_name) . '');
						}
				}
		}
		#***************************************************************************
		#Method			: deleteEducationProfile
		#Description	: deletes education profile details
		#Author
		#***************************************************************************
		function deleteEducationProfile($educationId)
		{
				$educationIds = implode(',', $educationId);
				$this->db->query('DELETE FROM school_education WHERE school_edu_id IN(' . $educationIds . ')');
		}
		#***************************************************************************
		#Method			: updateEducationProfile
		#Description	: updates EDUCATION profile details
		#Author
		#***************************************************************************
		function updateEducationProfile($edit_education_ids, $data)
		{
				$userId = $this->session->userdata('user_id');
				foreach ($edit_education_ids as $key => $val)
				{
						$this->db->query('UPDATE school_education SET user_id = ' . $userId . ',class_year = ' . $this->db->escape($data['class_year_edit'][$val]) . ',attended_for = ' . $this->db->escape($data['attended_for_edit'][$val]) . ',concentration1 = ' . $this->db->escape($data['concentration1_edit'][$val]) . ',concentration2 = ' . $this->db->escape($data['concentration2_edit'][$val]) . ',concentration3 = ' . $this->db->escape($data['concentration3_edit'][$val]) . ',college_name = ' . $this->db->escape($data['college_name_edit'][$val]) . ' WHERE school_edu_id = ' . $val . '');
				}
		}
		#***************************************************************************
		#Method			: updateLastModified
		#Description	: updates users table last modified date field when user profile updated
		#Author
		#***************************************************************************
		function updateLastModified()
		{
				$userId = $this->session->userdata('user_id');
				$this->db->query('UPDATE users SET last_modified = NOW() WHERE user_id = ' . $userId . '');
		}
		#***************************************************************************
		#Method			: getNetworkUsers
		#Description	: fetches users related to network
		#Author
		#***************************************************************************
		function getNetworkUsers($network_ids)
		{
				$networkUsersQuery = $this->db->query('SELECT user_id FROM networks WHERE network_id IN(' . $network_ids . ')');
				if ($networkUsersQuery->num_rows() > 0)
				{
						foreach ($networkUsersQuery->result_array() as $row)
						{
								$user_id[] = $row['user_id'];
						}
						return $user_id;
				}
				else  return false;
		}
		#***************************************************************************
		#Method			: getUsersInNetworks
		#Description	: fetches users related to network
		#Author
		#***************************************************************************
		function getUsersInNetworks($network_ids)
		{
				$networkUsersQuery = $this->db->query('SELECT user_id FROM network_users WHERE network_id IN(' . $network_ids . ')');
				if ($networkUsersQuery->num_rows() > 0)
				{
						foreach ($networkUsersQuery->result_array() as $row)
						{
								$user_id[] = $row['user_id'];
						}
						return $user_id;
				}
				else  return false;
		}
		#***************************************************************************
		#Method			: getScreenMessengers
		#Description	: fetches screen and messenger details for the user
		#Author
		#***************************************************************************
		function getScreenMessengers($userId = '')
		{
				$userId = (trim($userId) == '') ? $this->session->userdata('user_id') : $userId;
				$screenMessengersQuery = $this->db->query('SELECT s.screen_id,s.screen_name,m.messenger_name FROM screens s,messengers m WHERE s.user_id =  ' . $userId . ' AND s.messenger_id = m.messenger_id');
				if ($screenMessengersQuery->num_rows() > 0)
				{
						foreach ($screenMessengersQuery->result_array() as $row)
						{
								$screenMessengers[$row['screen_id']] = $row;
						}
						return $screenMessengers;
				}
				else  return false;
		}
		function isUserInNetwork($networkType, $userId = '')
		{
				$userId = (trim($userId) == '') ? $this->session->userdata('user_id') : $userId;
				$this->db->select('network_users.network_id');
				$this->db->from('network_users');
				$this->db->join('networks', 'network_users.network_id=networks.network_id', 'INNER');
				$this->db->where('network_users.user_id', $userId);
				$this->db->limit(1);
				$isUserInNetworkQuery = $this->db->get();
				if ($isUserInNetworkQuery->num_rows() > 0) return true;
				else  return false;
		}
		#***************************************************************************
		#Method			: getUserCount
		#Description	: fetches total user count
		#Author
		#***************************************************************************
		function getUserCount($status = 'active')
		{
				$this->db->select('user_id');
				$this->db->from('users');
				$this->db->where('user_status', $status);
				return $this->db->count_all_results();
		}
		#***************************************************************************
		#Method			: chkAdminPassword
		#Description	: checks for admin password
		#Author
		#***************************************************************************
		function chkAdminPassword($password)
		{
				$userCheckingQuery = $this->db->query('SELECT * FROM admin WHERE admin_password=' . $this->db->escape($password) . ' LIMIT 0,1');
				if ($userCheckingQuery->num_rows() > 0) return true;
				else  return false;
		}
		#***************************************************************************
		#Method			: updateAdminPassword
		#Description	: updates admin password
		#Author
		#***************************************************************************
		function updateAdminPassword($password)
		{
				$admin = array('admin_password' => $password);
				$this->db->where('admin_id', 1);
				$this->db->update('admin', $admin);
		}
		#***************************************************************************
		#Method			: updateProfileStatus
		#Description	: updates profile status
		#Author
		#***************************************************************************
		function updateProfileStatus($block_id, $status)
		{
				$userStatus = array('user_status' => $status);
				$this->db->where('user_id', $block_id);
				$this->db->update('users', $userStatus);
		}
		#***************************************************************************
		#Method			: getMembers
		#Description	: fetches members
		#Author
		#***************************************************************************
		function getMembers($criteriaArray, $start = '', $limit = '')
		{
				$nameSQL = '';
				$emailSQL = '';
				$daySQL = '';
				$countrySQL = '';
				$statusSQL = '';
				if (isset($criteriaArray['username']) && TRIM($criteriaArray['username']) != '')
				{
						$nameSQL = ' AND u.username LIKE ' . $this->db->escape('%' . TRIM($criteriaArray['username']) . '%');
				}
				if (isset($criteriaArray['email']) && TRIM($criteriaArray['email']) != '')
				{
						$emailSQL = ' AND u.email LIKE ' . $this->db->escape('%' . TRIM($criteriaArray['email']) . '%');
				}
				if (isset($criteriaArray['startday']) && isset($criteriaArray['endday']) && TRIM($criteriaArray['startday']) != '' && TRIM($criteriaArray['endday']) != '')
				{
						$daySQL = " OR (UNIX_TIMESTAMP(DATE_FORMAT(u.registered_date,'%Y-%m-%d')) BETWEEN UNIX_TIMESTAMP(" . $this->db->escape($criteriaArray['startday']) . ") AND UNIX_TIMESTAMP(" . $this->db->escape($criteriaArray['endday']) . "))";
				}
				if (isset($criteriaArray['country']) && TRIM($criteriaArray['country']) != '')
				{
						$countrySQL = " AND TRIM(pb.country) = " . TRIM($this->db->escape($criteriaArray['country']));
				}
				if (isset($criteriaArray['status']) && TRIM($criteriaArray['status']) != '')
				{
						$statusSQL = " AND TRIM(u.user_status) = " . TRIM($this->db->escape($criteriaArray['status']));
				}
				$strSQL = 'SELECT u.username,  IF(UNIX_TIMESTAMP(birthday) <> 0 , (YEAR(CURDATE())-YEAR(birthday)) - (RIGHT(CURDATE(),5)<RIGHT(birthday,5)) ,"")  AS age  ,u.user_id, u.birthday, u.email, u.user_status, u.last_login, u.registered_date ,pb.country,pb.hometown, c.country_name FROM users AS u
					LEFT JOIN profile_basic AS pb ON pb.user_id = u.user_id ' . $countrySQL . ' LEFT JOIN country AS c ON pb.country = c.country_symbol WHERE 1 = 1 ' . $nameSQL . $emailSQL . $countrySQL . $statusSQL . $daySQL;
				//echo $strSQL;
				if (ereg('^[0-9]+$', $start) && ereg('^[0-9]+$', $limit))
				{
						$strSQL .= ' LIMIT ' . $start . ', ' . $limit;
				}
				$membersQuery = $this->db->query($strSQL);
				$members = array();
				//print $this->db->last_query(); exit();
				if ($membersQuery->num_rows() > 0)
				{
						foreach ($membersQuery->result_array() as $row)
						{
								$members[$row['user_id']] = $row;
								$members[$row['user_id']]['avatar'] = $this->getAvatar($row['user_id'], true);
						}
				}
				return $members;
		}
		function getMembersCount($criteriaArray)
		{
				$nameSQL = '';
				$strSQL = 'SELECT u.username, u.user_id, u.birthday, u.email, u.user_status, u.last_login, u.registered_date FROM users AS u WHERE 1 = 1 ' . $nameSQL;
				$membersQuery = $this->db->query($strSQL);
				//print $this->db->last_query(); exit();
				return $membersQuery->num_rows();
		}
		function getUserDetailAdmin($userId)
		{
				$strSQL = "SELECT u.user_id, u.username,u.birthday, UNIX_TIMESTAMP(u.birthday) AS birthstamp,  u.email, IFNULL(pb.country,'') AS country, IFNULL(pb.sex,'') AS sex, u.show_password, IFNULL(pb.hometown,'') AS city
						FROM users AS u
						LEFT JOIN profile_basic AS pb ON pb.user_id = u.user_id
						WHERE u.user_id = " . $this->db->escape($userId);
				$resSQL = $this->db->query($strSQL);
				$resArray = array();
				if ($resSQL->num_rows() > 0)
				{
						$rowArray = $resSQL->result_array();
						$resArray = $rowArray[0];
				}
				return $resArray;
		}
		function saveUserInfoAdmin($userId, $valuesArray)
		{
				$updateSQL = 'UPDATE users SET username = ' . $this->db->escape($valuesArray['username']) . ', birthday = ' . $this->db->escape($valuesArray['birthday']) . ', last_modified = CURRENT_TIMESTAMP WHERE user_id = ' . $this->db->escape($userId);
				$this->db->query($updateSQL);
				$userStatus = false;
				if ($this->db->affected_rows() > 0)
				{
						$userStatus = true;
				}
				$strSQLCheck = 'SELECT user_id FROM profile_basic WHERE user_id = ' . $this->db->escape($userId);
				$resSQL = $this->db->query($strSQLCheck);
				if ($resSQL->num_rows() == 0)
				{
						$insertSQL = 'INSERT INTO profile_basic SET user_id = ' . $this->db->escape($userId) . ', country = ' . $this->db->escape($valuesArray['country']) . ', hometown = ' . $this->db->escape($valuesArray['city']);
						$this->db->query($insertSQL);
				}
				else
				{
						$updateSQL = 'UPDATE profile_basic SET country = ' . $this->db->escape($valuesArray['country']) . ', hometown = ' . $this->db->escape($valuesArray['city']) . ' WHERE user_id = ' . $this->db->escape($userId);
						$this->db->query($updateSQL);
				}
				return $userStatus;
		}
		function getUserViewInfoAdmin($userId)
		{
				$strSQL = "SELECT 	u.username, u.email, u.user_id, IFNULL(ls.content,'') AS lifestage,u.lifestage_id,
						pb.relation_id,IFNULL(rs.relation,'') AS relation,
						pb.political_id,IFNULL(pv.political_view,'') AS political_view,
						IFNULL(pb.interested_in,'') AS intrested_id,IFNULL(rv.religion,'') AS religion,pb.religious_view,
						pb.hometown, IF(UNIX_TIMESTAMP(TRIM(u.birthday)) != 0 ,FROM_UNIXTIME(UNIX_TIMESTAMP(u.birthday),'%M %Y'),'') AS birthday,
						pb.country,c.country_name,IFNULL(pb.sex,'') AS sex,pc.mobile,pc.address,pc.website,IFNULL(pe.high_school,'') AS high_school
					FROM users AS u
					LEFT JOIN profile_basic AS pb ON pb.user_id = u.user_id
					LEFT JOIN profile_contact AS pc ON pc.user_id = u.user_id
					LEFT JOIN profile_education AS pe ON pe.user_id = u.user_id
					LEFT JOIN profile_personal AS pp ON pp.user_id = u.user_id
					LEFT JOIN lifestage AS ls ON u.lifestage_id = ls.lifestage_id
					LEFT JOIN relation_status AS rs ON pb.relation_id = rs.relation_id
					LEFT JOIN political_views AS pv ON pb.political_id = pv.political_id
					LEFT JOIN religious_views AS rv ON rv.religion_id = pb.religious_view
					LEFT JOIN country AS c ON c.country_symbol = pb.country
					WHERE u.user_id = " . $this->db->escape($userId);
				$resSQL = $this->db->query($strSQL);
				$resArray = array();
				if ($resSQL->num_rows() > 0)
				{
						$rowRes = $resSQL->result_array();
						$resArray = $rowRes[0];
				}
				return $resArray;
		}
		function getUserCollegesAdmin($userId)
		{
				$strSQL = 'SELECT college_name,class_year FROM school_education WHERE user_id = ' . $this->db->escape($userId);
				$resSQL = $this->db->query($strSQL);
				$resArray = array();
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[] = $resRow;
						}
				}
				return $resArray;
		}
		function getUserWorkInfoAdmin($userId)
		{
				$strSQL = "SELECT IFNULL(pw.employer,'') AS employer, IFNULL(pw.position,'') AS emp_position, IFNULL(pw.description,'') AS emp_description,
					IFNULL(wc.country_name,'') AS emp_country, IFNULL(pw.country,'') AS emp_country_code, IFNULL(pw.city,'') AS emp_city,
					pw.start_year,pw.start_month,pw.end_year,pw.end_month, MONTHNAME(CONCAT_WS('-',pw.end_year,pw.end_month,1)) AS end_month_name,
					MONTHNAME(CONCAT_WS('-',pw.start_year,pw.start_month,1)) AS start_month_name,pw.current_job
					FROM profile_work AS pw
					LEFT JOIN country AS wc ON wc.country_symbol = pw.country
					WHERE pw.user_id = " . $this->db->escape($userId) . " ORDER BY pw.start_year,pw.start_month DESC";
				$resSQL = $this->db->query($strSQL);
				$resArray = array();
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[] = $resRow;
						}
				}
				return $resArray;
		}
		function getUserLookingForAdmin($userId)
		{
				$strSQL = "SELECT lf.lookingfor FROM looking_for AS lf
					INNER JOIN looking_for_map AS lfm ON lfm.looking_id = lf.looking_id
					INNER JOIN profile_basic AS pb ON lfm.basic_profile_id = pb.basic_profile_id
					WHERE pb.user_id = " . $this->db->escape($userId);
				$resSQL = $this->db->query($strSQL);
				$resArray = array();
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[] = $resRow;
						}
				}
				return $resArray;
		}
		function updateUserStatusAdmin($userId, $status)
		{
				$updateSQL = 'UPDATE users SET user_status = ' . $this->db->escape($status) . ', activation_key = "",  last_modified = CURRENT_TIMESTAMP  WHERE user_id = ' . $this->db->escape($userId);
				$this->db->query($updateSQL);
				return $this->db->affected_rows();
		}
		function addUserInfoAdmin($valuesArray)
		{
				$strSQL = 'INSERT INTO users SET username = ' . $this->db->escape($valuesArray['username']) . ', email = ' . $this->db->escape($valuesArray['email']) . ', user_status = "pending" , registered_date = CURRENT_TIMESTAMP, show_password = ' . $this->db->escape($valuesArray['pwd']) . ', password = ' . $this->db->escape(md5($valuesArray['pwd'])) . ', birthday = ' . $this->db->escape($valuesArray['birthday']);
				$this->db->query($strSQL);
				$userId = $this->db->insert_id();
				$insertSQL = 'INSERT INTO profile_basic SET user_id = ' . $this->db->escape($userId) . ', country = ' . $this->db->escape($valuesArray['country']) . ', hometown = ' . $this->db->escape($valuesArray['city']);
				$this->db->query($insertSQL);
				return $userId;
		}
}
?>