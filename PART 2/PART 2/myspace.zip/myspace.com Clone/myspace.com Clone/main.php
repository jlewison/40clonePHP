<?
show_header();
?>
<table width=100% cellpadding=0 cellspacing=0>
<tr><td>
	<p align="left"><font size="2" color="#FF0000"><b>
	<a href="index.php?mode=login&act=form"><font color="#FF6600">Login</font></a><font color="#FF6600">&nbsp;
	<a href="index.php?mode=join"><font color="#FF6600">SignUp</font></a></font></b></font></td>
<tr><td class="lined" bordercolorlight="#000080" bordercolordark="#000080">
<table width=100% class="body" cellpadding=0 cellspacing=0>
<tr><td class="padded-6" valign=top width=65%>
<p align="left"><img border="0" src="images/friends_banner.jpg"> Why Join Our 
Site?<p align=left>&nbsp;It's simple. We offer you all the space you need and we 
offer you:
<p align="left"><font face="Verdana">&#9679;</font>Personal, <font face="Verdana">&#9679;</font>Private 
Chat, <font face="Verdana">&#9679;</font>Message Boards, <font face="Verdana">&#9679;</font>Photo 
Albums, <font face="Verdana">&#9679;</font>Private and Public Groups,
<font face="Verdana">&#9679;</font>Blogs, <font face="Verdana">&#9679;</font>Classifieds,
<font face="Verdana">&#9679;</font>Meet New People, <font face="Verdana">&#9679;</font>Reunite 
Old Friends, <font face="Verdana">&#9679;</font>Special Events, <font face="Verdana">&#9679;</font>Calendars,
<font face="Verdana">&#9679;</font>Forums, <font face="Verdana">&#9679;</font>Plus Much Much 
More!<p align="left"><font color="#FF6600">**</font>Start your FREE account today! There are others here waiting for 
you!<p align="left"><font size="2" color="#FF0000"><b><font color="#FF6600">
<a href="index.php?mode=join"><font color="#FF6600">SignUp</font></a></font></b></font>
</br></br>
</td>
<td class="td-shade padded-6" valign=top>
<p align="left">
</br>
</p>
            <p class="bodygray" align="left"><b><font color="#000080">Already a member? Sign in here:</font></b></p>
<table class="body" align="center">
<form action="index.php" method=post>
<input type="hidden" name="mode" value="login">
<tr><td>
	<p align="left"><font color="#000080">E-mail Address:</font></td><td>
	<p align="left"><input type="text" size=15 name="email"></td>
<tr><td>
	<p align="left"><font color="#000080">Password:</font></td><td>
	<p align="left"><input type="password" size=15 name="password"></td>
<tr><td>
	<p align="left"></td><td align=right class="action">
	<p align="left"><a href="index.php?mode=forgot">Forget your password?</a></td>
<tr><td>
	<p align="left"></td><td align=right>
	<p align="left"><input type="checkbox" name="remember" value="ON">Remember me</td>
<tr><td>
	<p align="left"></td><td align=right>
	<p align="left"><input type="submit" value="Sign In"></td>
</form>
</table>
&nbsp;</td>
</table>
</td>
<tr><td>
	<p align="center">&nbsp;</td>
</table>
<? show_footer(); ?>