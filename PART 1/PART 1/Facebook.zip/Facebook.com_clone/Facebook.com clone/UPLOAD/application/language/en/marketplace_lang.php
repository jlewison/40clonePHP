<?php

	$lang['page_title']	= 'Marketplace';

	$lang['market_list_delete_success_msg']			= 'Your Listing Deleted Successfully!';
	$lang['market_list_save_network_error_msg']		= 'Failed to save your listing networks..';
	$lang['market_list_upload_photo_error_msg']		= 'Failed to upload your listing photos..';
	$lang['market_list_save_error_msg']				= 'Failed to save your listing..';
	$lang['market_upload_file_error_msg']			= 'Failed to upload file';
	$lang['market_invalid_photo_format_msg']		= 'Invalid photo format, allowed formats are jpeg, gif, png and bmp';
	$lang['market_photo_size_limit_msg']			= 'Photo size must be less than 4MB';
	$lang['market_label_title']						= 'Title';
	$lang['market_label_description']				= 'Description';
	$lang['market_label_network']					= 'Network';
	$lang['market_label_isbn']						= 'ISBN';
	$lang['market_label_amount']					= 'Amount';
	$lang['market_label_square_feet']				= 'Square Feet';
	$lang['market_label_price']						= 'Price';
	$lang['market_label_the']						= 'The';
	$lang['market_label_entered_is_not_valid']		= 'Entered is Not valid';
	//template variables
	$lang['market_label_marketplace']		= 'Marketplace'; 
	$lang['market_label_home']				= 'Home';
	$lang['market_label_listing']			= 'Listing';
	$lang['market_label_listings']			= 'Listings'; 
	$lang['market_label_wanted']			= 'Wanted';
	$lang['market_label_my']				= 'My';
	$lang['market_label_friends']			= 'Friends';
	$lang['market_label_add_new_listing']	= 'Add New Listing';
	$lang['market_label_select_category']	= 'Select Category';
	$lang['market_label_other']				= 'Other';
	$lang['market_label_type_network_name']	= 'Type network name';
	$lang['market_label_no_network_msg']	= 'You are in no network, please(click here to) join a network to add your listings in marketplace';
	$lang['market_label_displaying']		= 'Displaying';
	$lang['market_label_of']				= 'of';
	$lang['market_label_please_wait']		= 'please wait';
	$lang['market_label_by']				= 'By';
	$lang['market_label_listed']			= 'Listed'; 
	$lang['market_label_you']				= 'You';
	$lang['market_label_edit']				= 'Edit'; 
	$lang['market_label_remove']			= 'Remove'; 
	$lang['market_label_on']				= 'on'; 
	$lang['market_label_in']				= 'in';
	$lang['market_label_nothing_here']		= 'nothing here';
	$lang['market_label_required']			= 'Required';
	$lang['market_label_job_type']			= 'Job Type';
	$lang['market_label_compensation']		= 'Compensation';
	$lang['market_label_bed_rooms']			= 'Bed Rooms';
	$lang['market_label_bath_rooms']		= 'Bath Rooms';
	$lang['market_label_condition']			= 'Condition';
	$lang['market_label_rent']				= 'Rent';
	$lang['market_label_street']			= 'Street';
	$lang['market_label_cross_street']		= 'Cross Street';
	$lang['market_label_postal_code']		= 'Postal Code';
	$lang['market_label_square_footage']	= 'Square Footage';
	$lang['market_label_allowed']			= 'Allowed';
	$lang['market_label_profile_list']		= 'Profile List';
	$lang['market_label_add_this_listing_to_my_profile']		= 'Add this listing to my profile';
	$lang['market_label_photos']			= 'Photo(s)';
	$lang['market_label_file_upload_hint']	= 'Allowed formats jpeg, gif, png and bmp - max file size is 4MB';
	$lang['market_label_hours']				= 'Hours';
	$lang['market_label_full_time']			= 'Full-Time';
	$lang['market_label_part_time']			= 'Part-Time';
	$lang['market_label_stuff']				= 'Stuff';
	$lang['market_label_starting']			= 'Starting';
	$lang['market_label_at']				= 'at'; 
	$lang['market_label_where']				= 'List Where';
	$lang['market_label_privacy']			= 'Privacy';
	$lang['market_label_privacy_hint']		= 'Let people outside of the selected networks above view this listing';
	$lang['market_delete_list_confirm']		= 'Are you sure to delete this listing';
	$lang['market_list_suggestion']			= 'Did this listing result in a success';
	$lang['market_label_yes']				= 'Yes';
	$lang['market_label_no']				= 'No';
	
	$lang['market_label_cost']				= 'Cost';
	$lang['market_label_min']				= 'Min';
	$lang['market_label_max']				= 'Max';
	$lang['market_label_select_condition']	= 'Select Condition';
	$lang['market_label_select']			= 'Select'; 
	$lang['market_label_networks_list']		= 'Networks(s)';
	$lang['market_username_quote']			= '\'s'; 
	
		  
?>