<div class="outer" style="border-top:1px solid #870f0f;">
	<div id="header">
		<a href="<?php echo("$path");?>" title="Welcome to <?php echo("$sitetitle");?>!"><img class="hLogo" src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/logo.gif" alt="Welcome to <?php echo("$sitetitle");?>!" /></a>
		<div class="search">
			<form name="form1sea" id="form1sea" method="post" action="<?php echo("$path");?>search.php">
				<input name="q" type="text" class="searchInput" onfocus="this.value='';" value=" <?php echo("$lang_19");?>" size="40" />
				<input type="submit" name="button" class="searchBtn" value="<?php echo("$lang_20");?>" />
			</form>
		</div>
		<div class="navL">
<?php
if($alphacat == 'Y') { ?>
<a href="<?php echo("$path");?>0-9.html">#</a><a href="<?php echo("$path");?>A.html">A</a><a href="<?php echo("$path");?>B.html">B</a><a href="<?php echo("$path");?>C.html">C</a><a href="<?php echo("$path");?>D.html">D</a><a href="<?php echo("$path");?>E.html">E</a><a href="<?php echo("$path");?>F.html">F</a><a href="<?php echo("$path");?>G.html">G</a><a href="<?php echo("$path");?>H.html">H</a><a href="<?php echo("$path");?>I.html">I</a><a href="<?php echo("$path");?>J.html">J</a><a href="<?php echo("$path");?>K.html">K</a><a href="<?php echo("$path");?>L.html">L</a><a href="<?php echo("$path");?>M.html">M</a><a href="<?php echo("$path");?>N.html">N</a><a href="<?php echo("$path");?>O.html">O</a><a href="<?php echo("$path");?>P.html">P</a><a href="<?php echo("$path");?>Q.html">Q</a><a href="<?php echo("$path");?>R.html">R</a><a href="<?php echo("$path");?>S.html">S</a><a href="<?php echo("$path");?>T.html">T</a><a href="<?php echo("$path");?>U.html">U</a><a href="<?php echo("$path");?>V.html">V</a><a href="<?php echo("$path");?>W.html">W</a><a href="<?php echo("$path");?>X.html">X</a><a href="<?php echo("$path");?>Y.html">Y</a><a href="<?php echo("$path");?>Z.html">Z</a>
<?php }
elseif($alphacat == 'N') { ?>
<?php }
else { ?>
<a href="<?php echo("$path");?>0-9.html">#</a><a href="<?php echo("$path");?>A.html">A</a><a href="<?php echo("$path");?>B.html">B</a><a href="<?php echo("$path");?>C.html">C</a><a href="<?php echo("$path");?>D.html">D</a><a href="<?php echo("$path");?>E.html">E</a><a href="<?php echo("$path");?>F.html">F</a><a href="<?php echo("$path");?>G.html">G</a><a href="<?php echo("$path");?>H.html">H</a><a href="<?php echo("$path");?>I.html">I</a><a href="<?php echo("$path");?>J.html">J</a><a href="<?php echo("$path");?>K.html">K</a><a href="<?php echo("$path");?>L.html">L</a><a href="<?php echo("$path");?>M.html">M</a><a href="<?php echo("$path");?>N.html">N</a><a href="<?php echo("$path");?>O.html">O</a><a href="<?php echo("$path");?>P.html">P</a><a href="<?php echo("$path");?>Q.html">Q</a><a href="<?php echo("$path");?>R.html">R</a><a href="<?php echo("$path");?>S.html">S</a><a href="<?php echo("$path");?>T.html">T</a><a href="<?php echo("$path");?>U.html">U</a><a href="<?php echo("$path");?>V.html">V</a><a href="<?php echo("$path");?>W.html">W</a><a href="<?php echo("$path");?>X.html">X</a><a href="<?php echo("$path");?>Y.html">Y</a><a href="<?php echo("$path");?>Z.html">Z</a>
<?php } ?>
		</div>
	</div>
	<div class="nav">
		<a href="<?php echo("$path");?>"><?php echo("$lang_11");?></a><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/navDiv.gif" alt="menu divider" />
		<a href="<?php echo("$path");?>new-links.php"><?php echo("$lang_12");?></a><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/navDiv.gif" alt="menu divider" />
		<?php if($p_top == 'Y') { ?><a href="<?php echo("$path");?>links.php"><?php echo("$lang_13");?></a><?php } else {} ?><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/navDiv.gif" alt="menu divider" />
		<a href="<?php echo("$path");?>submit.php?su_categ=<?php echo("$su_categ");?>"><?php echo("$lang_14");?></a><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/navDiv.gif" alt="menu divider" />
		<a href="<?php echo("$path");?>contact.php"><?php echo("$lang_15");?></a><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/navDiv.gif" alt="menu divider" />
		<?php if($p_terms == 'Y') { ?><a href="<?php echo("$path");?>terms.php"><?php echo("$lang_16");?></a><?php } else {} ?><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/navDiv.gif" alt="menu divider" />
		<?php if($p_about == 'Y') { ?><a href="<?php echo("$path");?>about.php"><?php echo("$lang_80");?></a><?php } else {} ?><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/navDiv.gif" alt="menu divider" />
<a href="<?php echo("$path");?>tags/"><?php echo("$lang_181");?></a><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/navDiv.gif" alt="menu divider" />
	</div>
</div>
<div class="outer2">
	<div class="main">
		<div class="leftContainer">
			<div class="sideBox">
				<h2>Categories</h2>
                <?php if($nocat <> 'Y') { include('template/redtheme/b_subcategory.php'); } else {} ?>
				<ul>
					<?php do { ?><li><a href="<?php echo("$path");?><?php echo $row_categRL['categseoname']; ?>/"><?php echo $row_categRL['categoryname']; ?></a></li><?php
					$row_categRL = mysql_fetch_assoc($categRL);
					if (!isset($nested_categRL)) { $nested_categRL= 1; }
					} while ($row_categRL);
					?><li><a style="font-weight:bold;" href="<?php echo("$path");?>contact.php"><?php echo("$lang_21");?></a></li>
				</ul>
			</div>
			<p><link href="<?php echo("$path");?>stat.css" rel="stylesheet" type="text/css" /></p>
		</div>
		<div class="centerContainer">
			<div class="centerContent">