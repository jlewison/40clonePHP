<?php /* Smarty version 2.6.6, created on 2006-03-11 09:13:57
         compiled from premium.tpl */ ?>
<html>

<head>
<title><?php echo $this->_tpl_vars['page']; ?>
</title>
<!--<?php echo '-->
<link href="templates/style.css" rel="stylesheet" type="text/css">
<!--'; ?>
-->

</head>

<body>
<p align=center>
<table border="0" width="600" height="129" cellspacing="0" cellpadding="0">
  <tr>
    <td width="600" height="250" valign="top">
      <div align="center">
        <center>
      <table border="0" width="100%" cellspacing="0" cellpadding="0" height="314">
        <tr>
          <td width="100%" height="29">
<!---------------------------------------------------------------->          
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "header.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<!---------------------------------------------------------------->
          </td>
        </tr>
        <tr>
          <td width="100%" height="29">
          <p align="left">
          <font face="Verdana" size="2" color="#7777D2"><b>Premium Member</b></font>
          </p>
          </td>
        </tr>
        <tr>
          <td width="100%" height="49" bgcolor="#F2F2FF">
            <p align="right"><b><font size="2" color="#000080">Login</font></b></p>
          </td>
        </tr>
        
        
        <tr>
          <td width="100%" height="18" align="center">
          <?php if ($this->_tpl_vars['error']): ?>
          <font color=red><b><?php echo $this->_tpl_vars['error']; ?>
</b></font>
          <?php endif; ?>
          </td>
        </tr>
        
        
        <tr>
          <td width="100%" height="127" valign="top">
           <form method="POST" action="validate.php">
            <table border="0" width="100%" cellspacing="0" cellpadding="0" height="202">
              <tr>
                <td width="40%" align="right" height="37">
                  <p align="right"><b>Username</b></td>
                <td width="4%" height="37">
                </td>
                <td width="56" height="37">
                  <p align="left"><input type="text" name="name" size="15" class="txtbx"></td>
              </tr>
              <tr>
                <td width="40%" align="right" height="36">
                  <p align="right"><b>Password</b> </td>
                <td width="4%" height="36">
                </td>
                <td width="56" height="36">
                  <p align="left">
                <input type="password" name="pass" size="15" class="txtbx"></td>
              </tr>
              <tr>
                <td width="40%" align="right" height="36">
                </td>
                <td width="4%" height="36">
                </td>
                <td width="56" height="36">
                  <p align="left">
                  <input type="submit" value="Login" name="req" class="btn"></td>
              </tr>
              <tr>
                <td width="40%" align="right" height="35">
                  <p align="right">No account yet?</td>
                <td width="4%" height="35">
                </td>
                <td width="56" height="35">
                  <p align="left"><a href="reg_premium.php" class="A">Signup</a>
                </td>
              </tr>
              <tr>
                <td width="40%" align="right" height="31">
                </td>
                <td width="4%" height="31">
                </td>
                <td width="56" height="31">
                  <p align="left"></td>
              </tr>
              <tr>
                <td width="40%" align="right" height="27">&nbsp;</td>
                <td width="4%" height="27">
                </td>
                <td width="56" height="27">
                  <p align="left"></td>
              </tr>
            </table>
            </form>
          </td>
        </tr>
        <tr>
          <td width="100%" height="18">
          
          
          </td>
        </tr>
        <tr>
          <td width="100%" height="48" bgcolor="#F7F3FF"></td>
        </tr>
        <tr>
<!--------------------------------------------------------------------------------------------------------->        
   <td width="100%" height="25">
 <p align="center"><?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "bottom_link.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
          
          </td>
<!--------------------------------------------------------------------------------------------------------->                  
        </tr>
      </table>
        </center>
      </div>
    </td>
  </tr>
  <tr>
    <td width="600" height="25"><img border="0" src="images/bottomLine.gif" width="600" height="18">      
    </td>
  </tr>
  <tr>
    <td width="600" height="109" valign="top" align="center">
      <p>&nbsp;</p>
      <p><b><font color="#FF0000">Important Service Announcement:</font><br>
      <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "msg1title.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
      </b></p>
      <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "msg1.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>      
      </td>
  </tr>
  <tr>
    <td width="600" height="15" valign="top">
    <p align="center"><?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
      </td>
  </tr>
</table>
</body>

</html>