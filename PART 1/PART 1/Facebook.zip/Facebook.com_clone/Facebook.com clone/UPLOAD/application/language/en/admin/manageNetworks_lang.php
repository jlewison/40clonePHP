<?php

	$lang['page_title']	= 'Manage Networks';
	
	$lang['amn_show']			= 'Show';
	$lang['amn_network_name']	= 'Network Name';
	$lang['amn_network_type']	= 'Network Type';
	$lang['amn_network_domain']	= 'Network Domain';
	$lang['amn_network_email']	= 'Network Email';
	$lang['amn_suggested_by']	= 'Suggested By';
	$lang['amn_action']			= 'Action';
	$lang['amn_select_all']		= 'Select All';
	$lang['amn_go']				= 'Go';
	$lang['amn_delete']			= 'Delete';
	$lang['amn_delete_all']		= 'Delete All'; 
	$lang['amn_confirm_all']	= 'Confirm All';
	
	
?>