****************************************************  GETTING STARTED WITH GETMYCONTACTS ********************************


Installing the script is easy, simply upload the entire unzipped folder "importer" into anywhere you like in your hosting account.


> CHMOD ALL the cookie.txt (e.g. the hotmailcookie.txt file)  file to 777 ( the script will not work if this is not done)

> CHMOD "upload" folder to 777 (this only applies if you bought complete set or the Outlook importer)

 
> The script will then be accessible from             [  e.g http://www.mydomain.com/importer ]


> You will only need to edit one file and thats that "postage.php" this file has instruction inside it.
  So open it with notepad or similar editor.




You can contact us for help at getmycontacts@gmail.com


Thank you for your purchase.











