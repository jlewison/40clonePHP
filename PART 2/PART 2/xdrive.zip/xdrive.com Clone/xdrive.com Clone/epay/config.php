<?

// SITE
$sitename = "Your Site Name";
$siteurl = "";
$adminemail = "";
$replymail = "YourSiteName@donotreply.com";
$superpass = "";
$att_path = "./files/";
$bkp_path = "./backup/";
$useturingnumber = 1;
$suspend_days = 30;
$suspend_notice = 5;
$allow_same_ip = 1;
$securelogin = 1;

// EMAIL
$emailtop = "";
$emailbottom = "";

?>