<tr>
	<td align=right>Username:</td>
	<td><input type=text name=susername size=25 maxlength=15></td>
</tr>
<tr>
	<td align=right>First Name:</td>
	<td><input type=text name=sfirst_name size=25 maxlength=20 value='<?=$sfirst_name?>'></td>
</tr>
<tr>
	<td align=right>Last Name:</td>
	<td><input type=text name=slast_name size=25 maxlength=30 value='<?=$slast_name?>'></td>
</tr>
<tr>
	<td align=right>Street:</td>
	<td><input type=text name=sstreet size=25 maxlength=50 value='<?=$sstreet?>'></td>
</tr>
<tr>
	<td align=right>City:</td>
	<td><input type=text name=scity size=25 maxlength=30 value='<?=$scity?>'></td>
</tr>
<tr>
	<td align=right>State/Province:</td>
	<td><input type=text name=sstate size=25 maxlength=30 value='<?=$sstate?>'></td>
</tr>
<tr>
	<td align=right>Zip/Postal Code:</td>
	<td><input type=text name=szip size=25 maxlength=10 value='<?=$szip?>'></td>
</tr>
<tr>
	<td align=right>Country:</td>
	<td><input type=text name=scountry size=25 maxlength=30 value='<?=$scountry?>'></td>
</tr>
<tr>
	<td align=right valign=top>Your Email:</td>
	<td><input type=text name=semail size=25 maxlength=75 value='<?=$semail?>'></td>
</tr>
<tr>
	<td align=right>Telephone:</td>
	<td><input type=text name=stelephone size=25 maxlength=12 value='<?=$stelephone?>'></td>
</tr>
<tr>
	<td></td>
	<td><input type=submit name=submit3 value='Signup'></td>
</tr>
