<?php
require_once ('common/config.inc.php');
$CFG['lang']['include_files'][] = 'includes/languages/%s/forgotPassword.php';
$CFG['html']['header'] = 'members/includes/languages/%s/html_header.php';
$CFG['html']['footer'] = 'members/includes/languages/%s/html_footer.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['lang']['include_files'][] = 'common/languages/%s/help.inc.php';
if ($_POST) $CFG['mods']['include_files'][] = 'common/classes/phpmailer/class_PHPMailer.lib.php';
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class ForgotpasswordFormHandler extends FormHandler
{
		public function chkIsValidUser($email)
		{
				$sql = 'SELECT user_id, name FROM ' . $this->CFG['db']['tbl']['users'] . ' WHERE email = ' . $this->dbObj->Param($this->fields_arr[$email]);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr[$email]));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount())
				{
						$row = $rs->FetchRow();
						return $row;
				}
				return false;
		}
		public function sendActivationCode($field_user_id, $field_email, $activation_subj, $activation_msg, $return_url, $sender_name, $sender_email)
		{
				$act_code = substr(md5($this->fields_arr[$field_user_id]), 0, 8);
				$activation_link = $activation_msg . URL($return_url . urlencode($act_code));
				$is_ok = $this->_sendMail($this->fields_arr[$field_email], $activation_subj, $activation_link, $sender_name, $sender_email);
				return $is_ok;
		}
		private function _sendMail($to_email, $subject, $body, $sender_name, $sender_email)
		{
				$mail = new PHPMailer();
				$mail->AddAddress($to_email);
				$mail->FromName = $sender_name;
				$mail->From = $mail->Sender = $sender_email;
				$mail->Subject = $subject;
				$mail->Body = $body;
				$mail->IsMail();
				$mail->IsHTML(false);
				return ($mail->Send());
		}
}
$forgotpasswordfrm = new ForgotpasswordFormHandler();
$forgotpasswordfrm->setCfgLangGlobal($CFG, $LANG);
$forgotpasswordfrm->setPageBlockNames(array('msg_form_error', 'msg_form_success', 'form_Forgotpassword'));
$forgotpasswordfrm->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$forgotpasswordfrm->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$forgotpasswordfrm->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$forgotpasswordfrm->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$forgotpasswordfrm->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$forgotpasswordfrm->setFormField('email', '');
$forgotpasswordfrm->setFormField('user_id', '');
$forgotpasswordfrm->setAllPageBlocksHide();
$forgotpasswordfrm->setPageBlockShow('form_Forgotpassword');
if ($forgotpasswordfrm->isFormPOSTed($_POST, 'forgot_submit'))
{
		$forgotpasswordfrm->sanitizeFormInputs($_POST);
		$forgotpasswordfrm->setDBObject($db);
		$forgotpasswordfrm->chkIsNotEmpty('email', $LANG['forgot_err_tip_compulsory']) and $forgotpasswordfrm->chkIsValidEmail('email', $LANG['forgot_err_tip_invalid_email']);
		if ($forgotpasswordfrm->isValidFormInputs())
		{
				if ($user_details = $forgotpasswordfrm->chkIsValidUser('email'))
				{
						$forgotpasswordfrm->setIndirectFormField('user_id', $user_details['user_id']);
						$message = str_replace('{username}', $user_details['name'], $LANG['forgot_message']);
						if ($forgotpasswordfrm->sendActivationCode('user_id', 'email', $LANG['forgot_subject'], $message, getUrl($CFG['site']['url'] . 'verifyMail.php?code=', $CFG['site']['url'] . 'changepassword/?code=', false), $CFG['site']['noreply_name'], $CFG['site']['noreply_email'])) $forgotpasswordfrm->setDisplayVar('mail_status', $LANG['forgot_activation_code_sent']);
						else  $forgotpasswordfrm->setDisplayVar('mail_status', $LANG['forgot_activation_code_not_sent']);
						$forgotpasswordfrm->setAllPageBlocksHide();
						$forgotpasswordfrm->setPageBlockShow('msg_form_success');
				}
				else
				{
						$forgotpasswordfrm->setAllPageBlocksHide();
						$forgotpasswordfrm->setPageBlockShow('msg_form_error');
						$forgotpasswordfrm->setCommonErrorMsg($LANG['forgot_err_tip_data_not_exists']);
						$forgotpasswordfrm->setPageBlockShow('form_Forgotpassword');
				}
		}
		else
		{
				$forgotpasswordfrm->setAllPageBlocksHide();
				$forgotpasswordfrm->setPageBlockShow('msg_form_error');
				$forgotpasswordfrm->setPageBlockShow('form_Forgotpassword');
		}
}



?>
<div id="selForgotPassword">
	<h2><?php echo $LANG['forgot_title']; ?></h2>
<?php
if ($forgotpasswordfrm->isShowPageBlock('msg_form_error'))
{
?>
	<div id="selMsgError">
 		<p><?php echo $LANG['msg_error_sorry'] . ' ' . $forgotpasswordfrm->getCommonErrorMsg(); ?></p>
	</div>
<?php
}
if ($forgotpasswordfrm->isShowPageBlock('msg_form_success'))
{
?>
	<div id="selMsgSuccess">
 		 <p><?php echo $forgotpasswordfrm->getDisplayVar('mail_status'); ?></p>
 	</div>
<?php
}
if ($forgotpasswordfrm->isShowPageBlock('form_Forgotpassword'))
{
?>
	<form name="form_Forgotpassword" id="selFormForgotpassword"  method="post" action="<?php echo URL($_SERVER['PHP_SELF']); ?>" autocomplete="off">
		<table summary="<?php echo $LANG['forgot_summary']; ?>">
		     <tr>
			      <td class="<?php echo $forgotpasswordfrm->getCSSFormLabelCellClass('email'); ?>"><?php ShowHelpTip('email'); ?><label for="email"><?php echo $LANG['forgot_email']; ?></label></td>
         	      <td class="<?php echo $forgotpasswordfrm->getCSSFormFieldCellClass('email') ?>"><?php echo $forgotpasswordfrm->getFormFieldErrorTip('email') ?><input type="text" name="email" id="email" tabindex="1000" value="<?php echo $forgotpasswordfrm->getFormField('email'); ?>" /></td>
		     </tr>
			 <tr>
			   	 <td class="<?php echo $forgotpasswordfrm->getCSSFormFieldCellClass('forgot_submit'); ?>" colspan="2"><input type="submit" name="forgot_submit" id="forgot_submit" tabindex="1010" value="<?php echo $LANG['forgot_submit'] ?>" /></td>
		     </tr>
			</table>
	  </form>
<?php
}
?>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>