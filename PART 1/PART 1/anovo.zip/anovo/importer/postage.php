<?php
error_reporting(0);
$sendersemail = $_POST['sendersemail'];
//***********************************************************************************************************************************
//
//                                                 INSTRUCTION 1
//
//   IMPORTANT -- DO NOT DELETE  <<<EOF  and EOF;   only edit the message in the middle. You can use HTML or plain text
//
//
//**********************************************************************************************************************************
$message = <<< EOF


Hello

Your friend $sendersemail has invited you to join them at greatsite.com

I hope to see you there soon!!

GREATSITE.COM 



EOF;
//********************************************************************************************************************************
//
//
//                                          INSTRUCTION 2
//
//                       CHANGE THE SUBJECT LINE BELOW TO YOUR OWN SUBJECT FOR THE EMAIL
//
//
//********************************************************************************************************************************
$subject = "You've got mail!";
//****************************************************************************************************************************************************
//
//
//                                          INSTRUCTION 3
//
// CHANGE EMAIL BELOW TO YOUR EMAIL ADDRESS --- IMPORTANT.. if you do not use your real domain nane in this email address, hotmail, yahoo etc WILL block it.
//
//
//
//****************************************************************************************************************************************************
$from = "info@domain.tld";
//********************************* DO NOT EDIT AFTER THIS LINE ****************************
foreach ($_POST['list'] as $to)
{
		mail($to, $subject, $message, "From: $from");
}
echo "Messages have been sent";
?>