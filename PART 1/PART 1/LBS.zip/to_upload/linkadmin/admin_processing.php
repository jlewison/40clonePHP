<?php include('restrict.php'); include('../settings.php'); ?>
<?php
$selectc = $_POST[selectc];
$email = $_POST[email];
$keyword = $_POST[keyword];
$url = $_POST[url];
$descr1 = $_POST[descr1];
$descr2 = $_POST[descr2];
$mdesc = $_POST[mdesc];
$mword = $_POST[mword];
$deeptf = $_POST[deeptf];
$dfurl = $_POST[dfurl];
$deepts = $_POST[deepts];
$dsurl = $_POST[dsurl];
$deeptt = $_POST[deeptt];
$dturl = $_POST[dturl];
$bid = $_POST[bid];
$gm_str = $_POST[gm_str];
$gm_str_nr = $_POST[gm_str_nr];
$gm_city = $_POST[gm_city];
$gm_county = $_POST[gm_county];
$gm_country = $_POST[gm_country];
$categ = $_POST[categ];
$str = "$keyword";
$resu = ord($str);
if($resu == '97') { $fres = "A"; }
elseif($resu == '98') { $fres = "B"; }
elseif($resu == '99') { $fres = "C"; }
elseif($resu == '100') { $fres = "D"; }
elseif($resu == '101') { $fres = "E"; }
elseif($resu == '102') { $fres = "F"; }
elseif($resu == '103') { $fres = "G"; }
elseif($resu == '104') { $fres = "H"; }
elseif($resu == '105') { $fres = "I"; }
elseif($resu == '106') { $fres = "J"; }
elseif($resu == '107') { $fres = "K"; }
elseif($resu == '108') { $fres = "L"; }
elseif($resu == '109') { $fres = "M"; }
elseif($resu == '110') { $fres = "N"; }
elseif($resu == '111') { $fres = "O"; }
elseif($resu == '112') { $fres = "P"; }
elseif($resu == '113') { $fres = "Q"; }
elseif($resu == '114') { $fres = "R"; }
elseif($resu == '115') { $fres = "S"; }
elseif($resu == '116') { $fres = "T"; }
elseif($resu == '117') { $fres = "U"; }
elseif($resu == '118') { $fres = "V"; }
elseif($resu == '119') { $fres = "W"; }
elseif($resu == '120') { $fres = "X"; }
elseif($resu == '121') { $fres = "Y"; }
elseif($resu == '122') { $fres = "Z"; }
elseif($resu == '65') { $fres = "A"; }
elseif($resu == '66') { $fres = "B"; }
elseif($resu == '67') { $fres = "C"; }
elseif($resu == '68') { $fres = "D"; }
elseif($resu == '69') { $fres = "E"; }
elseif($resu == '70') { $fres = "F"; }
elseif($resu == '71') { $fres = "G"; }
elseif($resu == '72') { $fres = "H"; }
elseif($resu == '73') { $fres = "I"; }
elseif($resu == '74') { $fres = "J"; }
elseif($resu == '75') { $fres = "K"; }
elseif($resu == '76') { $fres = "L"; }
elseif($resu == '77') { $fres = "M"; }
elseif($resu == '78') { $fres = "N"; }
elseif($resu == '79') { $fres = "O"; }
elseif($resu == '80') { $fres = "P"; }
elseif($resu == '81') { $fres = "Q"; }
elseif($resu == '82') { $fres = "R"; }
elseif($resu == '83') { $fres = "S"; }
elseif($resu == '84') { $fres = "T"; }
elseif($resu == '85') { $fres = "U"; }
elseif($resu == '86') { $fres = "V"; }
elseif($resu == '87') { $fres = "W"; }
elseif($resu == '88') { $fres = "X"; }
elseif($resu == '89') { $fres = "Y"; }
elseif($resu == '90') { $fres = "Z"; }
elseif($resu == '48') { $fres = "0"; }
elseif($resu == '49') { $fres = "1"; }
elseif($resu == '50') { $fres = "2"; }
elseif($resu == '51') { $fres = "3"; }
elseif($resu == '52') { $fres = "4"; }
elseif($resu == '53') { $fres = "5"; }
elseif($resu == '54') { $fres = "6"; }
elseif($resu == '55') { $fres = "7"; }
elseif($resu == '56') { $fres = "8"; }
elseif($resu == '57') { $fres = "9"; }
else { $resu = ""; }
$categ = "$fres";

require_once('../Connections/apound.php'); 

$avail = $_POST[avail];
$paid = $_POST[paid];
$one = date("Y")+10; $two = date("m-d"); $mydate = "$one-$two";

mysql_select_db($database_apound, $apound);
$result = mysql_query ("INSERT INTO main (categ, email, site, title, descr1, descr2, mword, mdesc, deeptf, dfurl, deepts, dsurl, deeptt, dturl, bid, stad, stup, stod, avail, paid, maincategory, gm_str, gm_str_nr, gm_city, gm_county, gm_country) VALUES('$categ', '$email', '$url', '$keyword', '$descr1', '$descr2', '$mword', '$mdesc', '$deeptf', '$dfurl', '$deepts', '$dsurl', '$deeptt', '$dturl', '$bid', NOW(), NOW(), '$mydate', '$avail', '$paid', '$selectc', '$gm_str', '$gm_str_nr', '$gm_city', '$gm_county', '$gm_country')");

mysql_select_db($database_apound, $apound);
$query_CKNID = "SELECT * FROM main WHERE categ = '$categ' AND email = '$email' AND site = '$url' AND title = '$keyword' AND bid = '$bid'";
$CKNID = mysql_query($query_CKNID, $apound) or die(mysql_error());
$row_CKNID = mysql_fetch_assoc($CKNID);
$totalRows_CKNID = mysql_num_rows($CKNID);
$linkid = $row_CKNID['dtu'];
header("Location: manage_link.php?upd=Y");
?>