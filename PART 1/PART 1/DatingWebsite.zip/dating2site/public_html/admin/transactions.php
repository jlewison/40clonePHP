<?php
if ( !defined( 'SMARTY_DIR' ) ) {
	include_once( '../init.php' );
}

include ( 'sessioninc.php' );

define( 'PAGE_ID', 'payment_mgt' );

if ( !checkAdminPermission( PAGE_ID ) ) {

	header( 'location: not_authorize.php' );
	exit;
}


$data=array();

$mships = $db->getAll('select roleid, activedays, name from ! order by roleid',array( MEMBERSHIP_TABLE) );

$memberships = array();

foreach ($mships as  $val) {

	$memberships[$val['roleid']] = array(
		'activedays' => $val['activedays'],
		'name'		 => $val['name']
		);
}


$sql = 'select trans.*, user.username, user.status as userstatus, user.levelend   from ! as trans, ! as user where user.id = trans.user_id order by txn_date desc';

$rs = $db->getAll( $sql, array( TRANSACTIONS_TABLE, USER_TABLE) );

$reccount = count($rs);

$t->assign ( 'total_recs',  $reccount );

$t->assign( 'lang', $lang );

foreach ( $rs as $row ) {

	$row['mship_from_name'] = $memberships[$row['from_membership']]['name'];

	$row['mship_to_name'] 	= $memberships[$row['to_membership']]['name'];

	$row['trans_dt'] = strftime(get_lang('DATE_FORMAT'),strtotime($row['txn_date']));

	$data[]=$row;
}

$t->assign( 'data', $data );

$t->assign('rendered_page', $t->fetch('admin/transactions.tpl'));

$t->display( 'admin/index.tpl' );

?>