<?php //00461
// Copyright Notice
// Web Site URL:  http://www.zeeways.com
// Script Owner eMail: mail@zeeways.com
// Date: April, 2007
// Script Name: Zeeways Auction Website PHP Script
// Copyright Details: This script is not free.  Do not Remove this Copy Right notice.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the site administrator.');exit(199);
?>
4+oV55ZwkMoGN093UK4iJ/uVCYb8iQu5sPDgRxsiiCk0Qn3e7nq0yS+kxbGcBHXyO1rM9rP3bxKO
0SHYeKtZix72eXESBOJQUB9PUvKGx47igLoB9HIQvLZFt5B46wI1iq5UZBIwR4x7TVrlSBp9xNWb
2XoEK3d/nluY52UX2UnXr3fczHFIRGwG5ND/12TNek5Z6I+beAC92+yjty20HQkMXehvOL6zDvsE
Rg8qyLNRQn6dK4wQX643bgOq34npzoskINwscd0HWpTTPZ3FRt6S5DA7vcpk5FmIOaKfPKc9OVyZ
jT6XyUipUuhLvuUryVIi3lmjUvFL5UHwk8gv39MhW1Fbul/o9UQxlnmdp0h4zs1/xOm4wIk4Omwq
xFizhdTssowUiyz2LjKue00m0zb6Z0WYb0p88CqAHkhOaXHpd1G8/PBm3uPM0yYoa+ep7mSMpomL
oyBMiAK1iDIo7udXfpq7ofn+sZ1faiUF+wsrS2pWIdLiqx2vZ/8GiSiR5QWFM13GVmeBjOSXH1EV
TgRbNdhx9hn3n2qGYSEKWI1j3pPs+bLVoRa9n+p9ZaoBUudOwP8gn3YsDtKFxioy7nMZxNyjn4cy
XRD8jyGNGtlzRqIkGQLVU81WBrmdHHN/ZEsCv6QvZ7pPAxKgiMqfdHZetM+6CH9rX4MPxA7fAwzC
Oiy62xpi/b7XGbHG2Eco9hLQHF0DSTNZJoOzjPPvOCiA9RCGtUBCBwqM+UV/wIzipBcM8ytFg8xK
kTv23Pyu0bXsGpAHy2OuM8rTQA3kt6zmxMZ36hvmlBTKuot0fFk9HSHEhjZoQCsO36wj9OriiogQ
XTIibaDJojLurXUkd/nbP7UmZiPeZcB5N0Nw+OkFK4L/tU7zdBgn0WDK7UDMxhOwQjcsCZZqZ9oM
eZhaWYkRCMK96pjxhXV4baX/mTAipwnBDy0+Y9UJA5Ly8B0RpUAP4A2r0p+PTQdYwjoTGPD/KlQu
9aOLXdWikxbghqmwicpuFQe14d0fEubPM4PRzf00kV/yvVMafR19N7lA1TumKvNsRTyaUnrIrDek
jpwzSKuSMNGWgxvcgL93kkoHvLfYzN5W9zbBAa66LvaSZwLSRFhQfUAI8+45W6QfGnJhsuLY5WJU
3bD8g+3GMG0M5T1um+Rf/XYKcfm3we01E7F9d4UXTL864G==