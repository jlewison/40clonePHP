<?
include("../include/config.php");
if(!isset($_COOKIE['admin_uname'])||count($_REQUEST)==0) header("location: index.php");

switch($_REQUEST['change'])
{
case "Personal":
$auid=$_COOKIE['admin_uid'];
$qry="select * from admin where uid=$auid";
$rs=$conn->execute($qry);
STemplate::assign("aname",$rs->fields['uname']);
STemplate::assign("aemail",$rs->fields['email']);
break;
case "Config":
$auid=$_COOKIE['admin_uid'];
$qry="select * from admin where uid=$auid";
$rs=$conn->execute($qry);
STemplate::assign("aname",$rs->fields['uname']);
STemplate::assign("aemail",$rs->fields['email']);
break;
case "Abuse":
$pg=$_REQUEST['page']*10+1;
if($pg==1) $pg=0;
$qry="select * from abuse_reported_files";
$rs=$conn->execute($qry);
$pgs=$rs->recordcount();
$pgs=floor($pgs/10);
if($pg>$pgs) $pg=$pgs;
$qry="select * from abuse_reported_files LIMIT $pg,10";
$rs=$conn->execute($qry);
STemplate::assign("abuse",$rs->getarray());
STemplate::assign("mxpg",$pgs);
break;
case "FInfo":
$pg=$_REQUEST['page']*10+1;
if($pg==1) $pg=0;
$qry="select * from fileinfo";
$rs=$conn->execute($qry);
$pgs=$rs->recordcount();
$pgs=floor($pgs/10);

$qry="select * from fileinfo LIMIT $pg,10";
$rs=$conn->execute($qry);
STemplate::assign("file",$rs->getarray());
STemplate::assign("mxpg",$pgs);
break;
case "Server":
$qry="select * from server";
if($_REQUEST['sort']!="") $qry="select * from server ORDER by ".$_REQUEST['sort'];
$rs=$conn->execute($qry);
STemplate::assign("server",$rs->getarray());
break;

}
//-------------------------------------------------------------------
switch($_REQUEST['type'])
{
case "Personal":
$auid=$_COOKIE['admin_uid'];
$name=$_REQUEST['name'];
$pass=$_REQUEST['pass'];
$npass=$_REQUEST['npass'];
$email=$_REQUEST['email'];
$qry="select * from admin where uid=$auid and pwd='$pass'";
$rs=$conn->execute($qry);
if($rs->recordcount()>0)
{
$qry="update admin set uname='$name',pwd='$npass',email='$email' where uid=$auid";
$conn->execute($qry);
setcookie('msg','Personal Information Changed Successfully');
}
else STemplate::assign("err","Error: Wrong password");
break;
case "Config":
$rs=$conn->execute("select conf_name from configuration");
while(!$rs->EOF)
{
 $cname=$rs->fields['conf_name'];
 $cvalue=$_REQUEST[$cname];
 $conn->execute("update configuration set conf_value='$cvalue' where conf_name='$cname'");
// echo "update configuration set conf_value='$cvalue' where conf_name='$cname'";
 $rs->movenext();
}
setcookie('msg',"Configuration Saved Successfully");
break;
default:
break;
}

$qry="select * from premium_package";
$rs=$conn->execute($qry);
STemplate::assign("msg",$_COOKIE['msg']);
setcookie("msg","");
STemplate::assign('pac',$rs->getarray());
STemplate::display("admin/Admin_index.tpl");
?>
