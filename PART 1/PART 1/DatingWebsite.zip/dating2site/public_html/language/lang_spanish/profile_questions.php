<?php

$profile_questions['1']['question'] = '�Cu�l es tu estado civil?';

$profile_questions['1']['description'] = '';

$profile_questions['1']['guideline'] = '';

$profile_questions['1']['extsearchhead'] = 'Estado Civil';

$profile_questions['1']['1'] = 'Soltero/a';

$profile_questions['1']['2'] = 'Casado/a';

$profile_questions['1']['3'] = 'Viudo/a';

$profile_questions['1']['67'] = 'Encari�ado';

$profile_questions['1']['68'] = 'Separado/a';

$profile_questions['1']['69'] = 'Divorciado/a';

$profile_questions['2']['question'] = '�Cu�l es tu origen �tnico?';

$profile_questions['2']['description'] = '';

$profile_questions['2']['guideline'] = '';

$profile_questions['2']['extsearchhead'] = 'Origen �tnico';

$profile_questions['2']['80'] = 'Africano-Americano';

$profile_questions['2']['10018'] = 'Asi�tico';

$profile_questions['2']['10019'] = 'Negro / Africano';

$profile_questions['2']['10020'] = 'Cauc�sico (blanco)';

$profile_questions['2']['10021'] = 'Indias Orientales';

$profile_questions['2']['10022'] = 'Hisp�nico / Latino';

$profile_questions['2']['10023'] = 'Interracial';

$profile_questions['2']['10024'] = 'Oriente Medio';

$profile_questions['2']['10025'] = 'Ind�gena';

$profile_questions['2']['10026'] = 'Isle�os del Pacifico';

$profile_questions['2']['10027'] = 'Otros';

$profile_questions['3']['question'] = '�Cu�l es tu credo?';

$profile_questions['3']['description'] = '';

$profile_questions['3']['guideline'] = '';

$profile_questions['3']['extsearchhead'] = 'Religi�n';

$profile_questions['3']['10001'] = 'Cristiano';

$profile_questions['3']['10002'] = 'Cristiano / Cat�lico';

$profile_questions['3']['10003'] = 'Cristiano / Mormones';

$profile_questions['3']['10004'] = 'Cristiano / Protestante';

$profile_questions['3']['10005'] = 'Cristiano / Otro';

$profile_questions['3']['10006'] = 'Budista / Taoista';

$profile_questions['3']['10007'] = 'Hind�';

$profile_questions['3']['10008'] = 'Isl�mico';

$profile_questions['3']['10009'] = 'Jud�o';

$profile_questions['3']['10010'] = 'Pagano';

$profile_questions['3']['10011'] = 'Ate�sta';

$profile_questions['3']['10012'] = 'Ninguno / Agn�stico';

$profile_questions['3']['10014'] = 'Cienciolog�a';

$profile_questions['3']['10015'] = 'Espiritual pero no religioso';

$profile_questions['3']['10016'] = 'Otro';

$profile_questions['4']['question'] = '�Qu� haces para divertirte?';

$profile_questions['4']['description'] = 'Aqu� puedes describir tus actividades detalladamente. Si te gustan los deportes, �Eres miembro de alguna liga? Si te gustan las pel�culas, �Qu� g�nero te gusta m�s?';

$profile_questions['4']['guideline'] = '';

$profile_questions['4']['extsearchhead'] = 'Hobbis';

$profile_questions['5']['question'] = '�Cu�l es tu altura?';

$profile_questions['5']['description'] = '';

$profile_questions['5']['guideline'] = '';

$profile_questions['5']['extsearchhead'] = 'Altura';

$profile_questions['5']['152'] = '4\' 7\" (140 cm) o m�s bajo';

$profile_questions['5']['153'] = '4\' 8\" (142 cm)';

$profile_questions['5']['154'] = '4\' 9\" (145 cm)';

$profile_questions['5']['155'] = '4\' 10\" (147 cm)';

$profile_questions['5']['156'] = '4\' 11\" (150 cm)';

$profile_questions['5']['157'] = '5\'  0\" (152 cm)';

$profile_questions['5']['158'] = '5\' 1\" (155 cm)';

$profile_questions['5']['160'] = '5\' 2\" (157 cm)';

$profile_questions['5']['161'] = '5\' 3\" (160 cm)';

$profile_questions['5']['162'] = '5\' 4\" (162 cm)';

$profile_questions['5']['163'] = '5\' 5\" (165 cm)';

$profile_questions['5']['164'] = '5\' 6\" (167 cm)';

$profile_questions['5']['165'] = '5\' 7\" (170 cm)';

$profile_questions['5']['166'] = '5\' 8\" (173 cm)';

$profile_questions['5']['167'] = '5\' 9\" (175 cm)';

$profile_questions['5']['168'] = '5\' 10\" (178 cm)';

$profile_questions['5']['169'] = '5\' 11\" (180 cm)';

$profile_questions['5']['170'] = '6\' 0\" (183 cm)';

$profile_questions['5']['171'] = '6\' 1\" (185 cm)';

$profile_questions['5']['172'] = '6\' 2\" (188 cm)';

$profile_questions['5']['173'] = '6\' 3\" (190 cm)';

$profile_questions['5']['174'] = '6\' 4\" (193 cm)';

$profile_questions['5']['175'] = '6\' 5\" (196 cm)';

$profile_questions['5']['176'] = '6\' 6\" (198 cm)';

$profile_questions['5']['177'] = '6\' 7\" (201 cm)';

$profile_questions['5']['178'] = '6\' 8\" (203 cm)';

$profile_questions['5']['179'] = '6\' 9\" (206 cm)';

$profile_questions['5']['180'] = '6\' 10\" (208 cm)';

$profile_questions['5']['181'] = '6\' 11\" (211 cm)';

$profile_questions['5']['182'] = '7\' 0\" (213 cm)';

$profile_questions['5']['183'] = '7\' 1\" (216 cm)';

$profile_questions['5']['184'] = '7\' 2\" (218 cm)';

$profile_questions['5']['185'] = '7\' 3\" (221 cm)';

$profile_questions['5']['186'] = '7\' 4\" (224 cm)';

$profile_questions['5']['187'] = '7\' 5\" (226 cm)';

$profile_questions['5']['188'] = '7\' 6\" (229 cm)';

$profile_questions['5']['189'] = '7\' 7\" (231 cm)';

$profile_questions['5']['190'] = '7\' 8\" (234 cm)';

$profile_questions['5']['191'] = '7\' 9\" (236 cm)';

$profile_questions['5']['192'] = '7\' 10\"\' (239 cm) o mayor';

$profile_questions['6']['question'] = '�Como describes tu cuerpo?';

$profile_questions['6']['description'] = '';

$profile_questions['6']['guideline'] = '';

$profile_questions['6']['extsearchhead'] = 'Com�n';

$profile_questions['6']['10028'] = 'Delgado';

$profile_questions['6']['10029'] = 'Esbelto';

$profile_questions['6']['10030'] = 'Promedio';

$profile_questions['6']['10031'] = 'En forma';

$profile_questions['6']['10032'] = 'Elegante';

$profile_questions['6']['10033'] = 'Atl�tico';

$profile_questions['6']['10034'] = 'Musculoso/a';

$profile_questions['6']['10035'] = 'Unos kilitos de m�s';

$profile_questions['6']['10036'] = 'Gordo';

$profile_questions['6']['10037'] = 'Gordinfl�n/a';

$profile_questions['6']['10039'] = 'Voluptuoso/a';

$profile_questions['6']['10040'] = 'Grande';

$profile_questions['7']['question'] = '�C�al es tu signo?';

$profile_questions['7']['description'] = '';

$profile_questions['7']['guideline'] = '';

$profile_questions['7']['extsearchhead'] = 'Signo del Zod�aco';

$profile_questions['7']['211'] = 'Aries';

$profile_questions['7']['212'] = 'Tauro';

$profile_questions['7']['213'] = 'G�minis';

$profile_questions['7']['214'] = 'Cancer';

$profile_questions['7']['215'] = 'Leo';

$profile_questions['7']['216'] = 'Virgo';

$profile_questions['7']['217'] = 'Libra';

$profile_questions['7']['218'] = 'Escorpio';

$profile_questions['7']['219'] = 'Sagitario';

$profile_questions['7']['220'] = 'Capricornio';

$profile_questions['7']['221'] = 'Acuario';

$profile_questions['7']['222'] = 'Piscis';

$profile_questions['8']['question'] = '�Cu�l es el color de tus ojos?';

$profile_questions['8']['description'] = '';

$profile_questions['8']['guideline'] = '';

$profile_questions['8']['extsearchhead'] = 'Color de ojos';

$profile_questions['8']['23'] = 'Negro';

$profile_questions['8']['24'] = 'Azul';

$profile_questions['8']['25'] = 'Marr�n';

$profile_questions['8']['93'] = 'Gris';

$profile_questions['8']['94'] = 'Verde';

$profile_questions['8']['95'] = 'Avellana';

$profile_questions['9']['question'] = '�Cu�l es el color de tu cabello?';

$profile_questions['9']['description'] = '';

$profile_questions['9']['guideline'] = '';

$profile_questions['9']['extsearchhead'] = 'Color de cabello';

$profile_questions['9']['26'] = 'Negro';

$profile_questions['9']['27'] = 'Marr�n';

$profile_questions['9']['28'] = 'Marr�n oscuro';

$profile_questions['9']['96'] = 'Casta�o';

$profile_questions['9']['97'] = 'Rubio';

$profile_questions['9']['98'] = 'Caf� claro';

$profile_questions['9']['99'] = 'Caf� oscuro';

$profile_questions['9']['100'] = 'Rojo';

$profile_questions['9']['101'] = 'Blanco/gris';

$profile_questions['9']['102'] = 'Calvo';

$profile_questions['9']['103'] = 'Un poco canoso';

$profile_questions['10']['question'] = '�Tienes arte corporal?';

$profile_questions['10']['description'] = '';

$profile_questions['10']['guideline'] = '';

$profile_questions['10']['extsearchhead'] = 'Arte corporal';

$profile_questions['10']['29'] = 'Tatuaje ubicado estrat�gicamente';

$profile_questions['10']['30'] = 'Tatuaje visible';

$profile_questions['10']['31'] = 'Colmillo';

$profile_questions['10']['223'] = 'Marcado';

$profile_questions['10']['224'] = 'Lleno de tinta';

$profile_questions['10']['225'] = 'Cicatriz';

$profile_questions['10']['226'] = 'Piercing...pero en oreja(s)';

$profile_questions['10']['227'] = 'Ni siquiera pensar�a en hacerlo';

$profile_questions['10']['228'] = 'En anillo en ombligo';

$profile_questions['10']['229'] = 'Piercings que te gustar�an';

$profile_questions['11']['question'] = 'Fanfarronea un poco: �Cu�l es tu mejor caracter�stica?';

$profile_questions['11']['description'] = '';

$profile_questions['11']['guideline'] = '';

$profile_questions['11']['extsearchhead'] = 'Mejor caracter�stica';

$profile_questions['11']['10068'] = 'Brazos';

$profile_questions['11']['10069'] = 'Espalda';

$profile_questions['11']['10070'] = 'Barriga';

$profile_questions['11']['10071'] = 'Trasero';

$profile_questions['11']['10072'] = 'Pecho';

$profile_questions['11']['10073'] = 'Aspecto';

$profile_questions['11']['10074'] = 'Orejas';

$profile_questions['11']['10075'] = 'Ojos';

$profile_questions['11']['10076'] = 'Pies';

$profile_questions['11']['10077'] = 'Cabello';

$profile_questions['11']['10078'] = 'Manos';

$profile_questions['11']['10079'] = 'Caderas';

$profile_questions['11']['10080'] = 'Piernas';

$profile_questions['11']['10081'] = 'Labios';

$profile_questions['11']['10082'] = 'Nariz';

$profile_questions['11']['10083'] = 'Hombro';

$profile_questions['11']['10084'] = 'Muslos';

$profile_questions['11']['10085'] = 'Otro';

$profile_questions['12']['question'] = 'Lugares favoritos o destinos de viajes?';

$profile_questions['12']['description'] = 'Una vez que encuentres a alguien, �Te gustar�a llevarlo all�? �Cu�l es tu lugar favorito para comer?';

$profile_questions['12']['guideline'] = '';

$profile_questions['12']['extsearchhead'] = 'Lugares favoritos';

$profile_questions['13']['question'] = '�Qu� deportes y ejercicios te gustan?';

$profile_questions['13']['description'] = '';

$profile_questions['13']['guideline'] = '';

$profile_questions['13']['extsearchhead'] = 'Deportes';

$profile_questions['13']['34'] = 'Aerobic';

$profile_questions['13']['35'] = 'Carreras de Coches / Motocross';

$profile_questions['13']['36'] = 'B�isbol';

$profile_questions['13']['37'] = 'Baloncesto';

$profile_questions['13']['372'] = 'Billar / Pool';

$profile_questions['13']['373'] = 'Bowling';

$profile_questions['13']['374'] = 'Ciclismo';

$profile_questions['13']['375'] = 'Danza';

$profile_questions['13']['376'] = 'F�tbol Americano';

$profile_questions['13']['377'] = 'Golf';

$profile_questions['13']['378'] = 'Artes Marciales';

$profile_questions['13']['379'] = 'Correr';

$profile_questions['13']['380'] = 'Esqu�';

$profile_questions['13']['381'] = 'F�tbol';

$profile_questions['13']['382'] = 'Nado';

$profile_questions['13']['383'] = 'Tennis / Deportes con Raqueta';

$profile_questions['13']['384'] = 'Voley';

$profile_questions['13']['385'] = 'Caminata / Excursionismo';

$profile_questions['13']['386'] = 'Pesas / Aparatos';

$profile_questions['13']['387'] = 'Yoga';

$profile_questions['14']['question'] = '�Cosas Favoritas?';

$profile_questions['14']['description'] = 'Todos tienen cosas favoritas. �Cu�l es tu comida favorita? �Tu color favorito?';

$profile_questions['14']['guideline'] = 'Estas son las pautas';

$profile_questions['14']['extsearchhead'] = 'Cosas Favoritas';

$profile_questions['15']['question'] = '�Cu�l es lo �ltimo que le�ste?';

$profile_questions['15']['description'] = 'Sea una novela o el peri�dico, una revista o un cart�n de leche, dinos sobre tu �ltima aventura literaria.';

$profile_questions['15']['guideline'] = '';

$profile_questions['15']['extsearchhead'] = '�ltima Lectura';

$profile_questions['16']['question'] = '�Qu� intereses en com�n quieres compartir con otros miembros?';

$profile_questions['16']['description'] = '';

$profile_questions['16']['guideline'] = '';

$profile_questions['16']['extsearchhead'] = 'Intereses Comunes';

$profile_questions['16']['38'] = 'Ex-compa�eros ';

$profile_questions['16']['39'] = 'Club nocturno/Bailar';

$profile_questions['16']['40'] = 'Campamento';

$profile_questions['16']['41'] = 'Cocina';

$profile_questions['16']['388'] = 'Interconexi�n de Negocios';

$profile_questions['16']['389'] = 'Club de Lectura / Debates';

$profile_questions['16']['390'] = 'Caf� y charlas';

$profile_questions['16']['391'] = 'Cenar afuera';

$profile_questions['16']['392'] = 'Pesca / Caza';

$profile_questions['16']['393'] = 'Jardiner�a / Paisajismo';

$profile_questions['16']['394'] = 'Hobbis y artesan�as';

$profile_questions['16']['395'] = 'Pel�culas / Videos';

$profile_questions['16']['396'] = 'Museos y arte';

$profile_questions['16']['397'] = 'M�sica y conciertos';

$profile_questions['16']['398'] = 'Artes esc�nicas';

$profile_questions['16']['399'] = 'Jugar naipes';

$profile_questions['16']['400'] = 'Practicar deportes';

$profile_questions['16']['401'] = 'Intereses pol�ticos';

$profile_questions['16']['402'] = 'Religi�n / Espiritual';

$profile_questions['16']['403'] = 'Compras / Antig�edades';

$profile_questions['17']['question'] = '�C�mo describir�as tu sentido de humor?';

$profile_questions['17']['description'] = '';

$profile_questions['17']['guideline'] = '';

$profile_questions['17']['extsearchhead'] = 'Sentido de humor';

$profile_questions['17']['42'] = 'Extravagante: Lo m�s cursi posible';

$profile_questions['17']['43'] = 'Bobo: Todav�a r�o con los dibujos animados';

$profile_questions['17']['367'] = 'Inteligente: nada mejor como una aparicion aguda';

$profile_questions['17']['368'] = 'Oscuro: suelo ser el �nico que se rie';

$profile_questions['17']['369'] = 'Agudo/Sarc�stico: No soy m�s rencoroso porque soy soltero. Lo opuesto';

$profile_questions['17']['370'] = 'Payasadas: Preg�ntame por mi episodio favorito de \'Amo a Lucy\'';

$profile_questions['17']['371'] = 'Amistoso: Me r�o de todo';

$profile_questions['18']['question'] = '�Cada cuanto te ejercitas?';

$profile_questions['18']['description'] = '';

$profile_questions['18']['guideline'] = '';

$profile_questions['18']['extsearchhead'] = 'Ejercicio';

$profile_questions['18']['10086'] = 'Dos veces/d�a';

$profile_questions['18']['10087'] = 'Diario';

$profile_questions['18']['10088'] = 'Un d�a s� y otro no';

$profile_questions['18']['10089'] = 'Semanalmente';

$profile_questions['18']['10090'] = 'En semanas alternas';

$profile_questions['18']['10091'] = 'Mensualmente';

$profile_questions['18']['10092'] = 'Inconsistente';

$profile_questions['18']['10093'] = 'Nunca';

$profile_questions['19']['question'] = '�C�mo se describe tu dieta?';

$profile_questions['19']['description'] = '';

$profile_questions['19']['guideline'] = '';

$profile_questions['19']['extsearchhead'] = 'Diariamente';

$profile_questions['19']['10094'] = 'Carne y papas/patatas';

$profile_questions['19']['10095'] = 'Comida Chatarra';

$profile_questions['19']['10096'] = 'Comida R�pida';

$profile_questions['19']['10097'] = 'Mantenerse Sano';

$profile_questions['19']['10098'] = 'Especial / M�dico';

$profile_questions['19']['10099'] = 'Vegetariano/a';

$profile_questions['19']['10100'] = 'Vegetariano, ni huevos ni productos l�cteos';

$profile_questions['20']['question'] = '�Fumas?';

$profile_questions['20']['description'] = '';

$profile_questions['20']['guideline'] = '';

$profile_questions['20']['extsearchhead'] = 'Fumar';

$profile_questions['20']['50'] = 'Nunca';

$profile_questions['20']['51'] = 'En el pasado';

$profile_questions['20']['10711'] = 'Intento dejar';

$profile_questions['20']['10712'] = 'Ocasionalmente';

$profile_questions['20']['10713'] = 'Con regularidad';

$profile_questions['21']['question'] = '�Cada cu�nto bebes alcohol?';

$profile_questions['21']['description'] = '';

$profile_questions['21']['guideline'] = '';

$profile_questions['21']['extsearchhead'] = 'Bebo';

$profile_questions['21']['52'] = 'Nunca';

$profile_questions['21']['53'] = 'Ocasionalmente';

$profile_questions['21']['54'] = 'Con Frecuencia';

$profile_questions['22']['question'] = '�Horario de oficina? �Tu propio jefe? �Qu� tipo de trabajos tienes?';

$profile_questions['22']['description'] = '';

$profile_questions['22']['guideline'] = '';

$profile_questions['22']['extsearchhead'] = 'Horario';

$profile_questions['22']['10102'] = 'Horario completo de 9 a 5';

$profile_questions['22']['10103'] = 'Horario completo, pero otras horas';

$profile_questions['22']['10104'] = 'Media jornada';

$profile_questions['22']['10105'] = 'Cuarto de jornada';

$profile_questions['22']['10106'] = 'Mi propio jefe';

$profile_questions['22']['10107'] = 'Busco Empleo';

$profile_questions['22']['10108'] = 'Permiso Temporal';

$profile_questions['22']['10109'] = 'Retirado';

$profile_questions['22']['10110'] = 'Amo/a de casa';

$profile_questions['23']['question'] = 'Ingreso anual?';

$profile_questions['23']['description'] = '';

$profile_questions['23']['guideline'] = '';

$profile_questions['23']['extsearchhead'] = 'Ingreso anual actual';

$profile_questions['23']['56'] = 'Menos de $25,000';

$profile_questions['23']['57'] = '$25,001 a $50,000';

$profile_questions['23']['58'] = '$50,001 to $75,000';

$profile_questions['23']['59'] = '$75,001 a $100,000';

$profile_questions['23']['70'] = '$100,001 a $125,000';

$profile_questions['23']['71'] = '$125,001 a $150,000';

$profile_questions['23']['72'] = '$150,001 a $175,000';

$profile_questions['23']['10101'] = 'M�s de $175,000';

$profile_questions['23']['10716'] = 'Luego te digo';

$profile_questions['24']['question'] = '�Vives solo/a?';

$profile_questions['24']['description'] = '';

$profile_questions['24']['guideline'] = '';

$profile_questions['24']['extsearchhead'] = 'Con qu�en vives';

$profile_questions['24']['60'] = 'Vives solo/a';

$profile_questions['24']['61'] = 'Con ni�os';

$profile_questions['24']['62'] = 'Con padres';

$profile_questions['24']['10714'] = 'Vivo con compa�ero';

$profile_questions['24']['10715'] = 'Vivo con familia';

$profile_questions['25']['question'] = '�Tienes ni�os?';

$profile_questions['25']['description'] = '';

$profile_questions['25']['guideline'] = '';

$profile_questions['25']['extsearchhead'] = 'Tengo ni�os';

$profile_questions['25']['63'] = 'No';

$profile_questions['25']['64'] = 'Si - tiempo completo';

$profile_questions['25']['230'] = 'Si - en casa parcialemente';

$profile_questions['25']['231'] = 'Si - pero no en casa';

$profile_questions['26']['question'] = '�Quieres tener ni�os?';

$profile_questions['26']['description'] = '';

$profile_questions['26']['guideline'] = '';

$profile_questions['26']['extsearchhead'] = 'Quiero ni�os';

$profile_questions['26']['65'] = 'Si';

$profile_questions['26']['66'] = 'No';

$profile_questions['26']['232'] = 'Inseguro/a';

$profile_questions['27']['question'] = 'Tu peso';

$profile_questions['27']['description'] = '';

$profile_questions['27']['guideline'] = '';

$profile_questions['27']['extsearchhead'] = 'Peso';

$profile_questions['27']['243'] = 'Debajo a 78 lbs (35.4 Kg)';

$profile_questions['27']['244'] = '78 lbs (35.4 Kg)';

$profile_questions['27']['245'] = '79 lbs (35.8 Kg)';

$profile_questions['27']['246'] = '80 lbs (36.3 Kg)';

$profile_questions['27']['247'] = '81 lbs (36.7 Kg)';

$profile_questions['27']['248'] = '82 lbs (37.2 Kg)';

$profile_questions['27']['249'] = '83 lbs (37.6 Kg)';

$profile_questions['27']['250'] = '84 lbs (38.1 Kg)';

$profile_questions['27']['251'] = '85 lbs (38.6 Kg)';

$profile_questions['27']['252'] = '86 lbs (39 Kg)';

$profile_questions['27']['253'] = '87 lbs (39.5 Kg)';

$profile_questions['27']['254'] = '88 lbs (39.9 Kg)';

$profile_questions['27']['255'] = '89 lbs (40.4 Kg)';

$profile_questions['27']['256'] = '90 lbs (40.8 Kg)';

$profile_questions['27']['257'] = '91 lbs (41.3 Kg)';

$profile_questions['27']['258'] = '92 lbs (41.7 Kg)';

$profile_questions['27']['259'] = '93 lbs (42.2 Kg)';

$profile_questions['27']['260'] = '94 lbs (42.6 Kg)';

$profile_questions['27']['261'] = '95 lbs (43.1 Kg)';

$profile_questions['27']['262'] = '96 lbs (43.5 Kg)';

$profile_questions['27']['263'] = '97 lbs (44 Kg)';

$profile_questions['27']['264'] = '98 lbs (44.5 Kg)';

$profile_questions['27']['265'] = '99 lbs (44.9 Kg)';

$profile_questions['27']['266'] = '100 lbs (45.4 Kg)';

$profile_questions['27']['267'] = '101 lbs (45.8 Kg)';

$profile_questions['27']['268'] = '102 lbs (46.3 Kg)';

$profile_questions['27']['269'] = '103 lbs (46.7 Kg)';

$profile_questions['27']['270'] = '104 lbs (47.2 Kg)';

$profile_questions['27']['271'] = '105 lbs (47.6 Kg)';

$profile_questions['27']['272'] = '106 lbs (48.1 Kg)';

$profile_questions['27']['273'] = '107 lbs (48.5 Kg)';

$profile_questions['27']['274'] = '108 lbs (49 Kg)';

$profile_questions['27']['275'] = '109 lbs (49.4 Kg)';

$profile_questions['27']['276'] = '110 lbs (49.9 Kg)';

$profile_questions['27']['277'] = '111 lbs (50.3 Kg)';

$profile_questions['27']['278'] = '112 lbs (50.8 Kg)';

$profile_questions['27']['279'] = '113 lbs (51.3 Kg)';

$profile_questions['27']['280'] = '114 lbs (51.7 Kg)';

$profile_questions['27']['281'] = '115 lbs (52.2 Kg)';

$profile_questions['27']['282'] = '116 lbs (52.6 Kg)';

$profile_questions['27']['283'] = '117 lbs (53.1 Kg)';

$profile_questions['27']['284'] = '118 lbs (53.5 Kg)';

$profile_questions['27']['285'] = '119 lbs (54 Kg)';

$profile_questions['27']['286'] = '120 lbs (54.4 Kg)';

$profile_questions['27']['287'] = '121 lbs (54.9 Kg)';

$profile_questions['27']['288'] = '122 lbs (55.3 Kg)';

$profile_questions['27']['289'] = '123 lbs (55.8 Kg)';

$profile_questions['27']['290'] = '124 lbs (56.2 Kg)';

$profile_questions['27']['291'] = '125 lbs (56.7 Kg)';

$profile_questions['27']['292'] = '126 lbs (57.2 Kg)';

$profile_questions['27']['293'] = '127 lbs (57.6 Kg)';

$profile_questions['27']['294'] = '128 lbs (58.1 Kg)';

$profile_questions['27']['295'] = '129 lbs (58.5 Kg)';

$profile_questions['27']['296'] = '130 lbs (59 Kg)';

$profile_questions['27']['297'] = '131 lbs (59.4 Kg)';

$profile_questions['27']['298'] = '132 lbs (59.9 Kg)';

$profile_questions['27']['299'] = '133 lbs (60.3 Kg)';

$profile_questions['27']['300'] = '134 lbs (60.8 Kg)';

$profile_questions['27']['301'] = '135 lbs (61.2 Kg)';

$profile_questions['27']['302'] = '136 lbs (61.7 Kg)';

$profile_questions['27']['303'] = '137 lbs (62.1 Kg)';

$profile_questions['27']['304'] = '138 lbs (62.6 Kg)';

$profile_questions['27']['305'] = '139 lbs (63.1 Kg)';

$profile_questions['27']['306'] = '140 lbs (63.5 Kg)';

$profile_questions['27']['307'] = '141 lbs (64 Kg)';

$profile_questions['27']['308'] = '142 lbs (64.4 Kg)';

$profile_questions['27']['309'] = '143 lbs (64.9 Kg)';

$profile_questions['27']['310'] = '144 lbs (65.3 Kg)';

$profile_questions['27']['311'] = '145 lbs (65.8 Kg)';

$profile_questions['27']['312'] = '146 lbs (66.2 Kg)';

$profile_questions['27']['313'] = '147 lbs (66.7 Kg)';

$profile_questions['27']['314'] = '148 lbs (67.1 Kg)';

$profile_questions['27']['315'] = '149 lbs (67.6 Kg)';

$profile_questions['27']['316'] = '150 lbs (68 Kg)';

$profile_questions['27']['317'] = '151 lbs (68.5 Kg)';

$profile_questions['27']['318'] = '152 lbs (68.9 Kg)';

$profile_questions['27']['319'] = '153 lbs (69.4 Kg)';

$profile_questions['27']['320'] = '154 lbs (69.9 Kg)';

$profile_questions['27']['321'] = '155 lbs (70.3 Kg)';

$profile_questions['27']['322'] = '156 lbs (70.8 Kg)';

$profile_questions['27']['323'] = '157 lbs (71.2 Kg)';

$profile_questions['27']['324'] = '158 lbs (71.7 Kg)';

$profile_questions['27']['325'] = '159 lbs (72.1 Kg)';

$profile_questions['27']['326'] = '160 lbs (72.6 Kg)';

$profile_questions['27']['327'] = '161 lbs (73 Kg)';

$profile_questions['27']['328'] = '162 lbs (73.5 Kg)';

$profile_questions['27']['329'] = '163 lbs (73.9 Kg)';

$profile_questions['27']['330'] = '164 lbs (74.4 Kg)';

$profile_questions['27']['331'] = '165 lbs (74.8 Kg)';

$profile_questions['27']['332'] = '166 lbs (75.3 Kg)';

$profile_questions['27']['333'] = '167 lbs (75.8 Kg)';

$profile_questions['27']['334'] = '168 lbs (76.2 Kg)';

$profile_questions['27']['335'] = '169 lbs (76.7 Kg)';

$profile_questions['27']['336'] = '170 lbs (77.1 Kg)';

$profile_questions['27']['337'] = '171 lbs (77.6 Kg)';

$profile_questions['27']['338'] = '172 lbs (78 Kg)';

$profile_questions['27']['339'] = '173 lbs (78.5 Kg)';

$profile_questions['27']['340'] = '174 lbs (78.9 Kg)';

$profile_questions['27']['341'] = '175 lbs (79.4 Kg)';

$profile_questions['27']['342'] = '176 lbs (79.8 Kg)';

$profile_questions['27']['343'] = '177 lbs (80.3 Kg)';

$profile_questions['27']['344'] = '178 lbs (80.7 Kg)';

$profile_questions['27']['345'] = '179 lbs (81.2 Kg)';

$profile_questions['27']['346'] = '180 lbs (81.6 Kg)';

$profile_questions['27']['347'] = '181 lbs (82.1 Kg)';

$profile_questions['27']['348'] = '182 lbs (82.6 Kg)';

$profile_questions['27']['349'] = '183 lbs (83 Kg)';

$profile_questions['27']['350'] = '184 lbs (83.5 Kg)';

$profile_questions['27']['351'] = '185 lbs (83.9 Kg)';

$profile_questions['27']['352'] = '186 lbs (84.4 Kg)';

$profile_questions['27']['353'] = '187 lbs (84.8 Kg)';

$profile_questions['27']['354'] = '188 lbs (85.3 Kg)';

$profile_questions['27']['355'] = '189 lbs (85.7 Kg)';

$profile_questions['27']['356'] = '190 lbs (86.2 Kg)';

$profile_questions['27']['357'] = '191 lbs (86.6 Kg)';

$profile_questions['27']['358'] = '192 lbs (87.1 Kg)';

$profile_questions['27']['359'] = '193 lbs (87.5 Kg)';

$profile_questions['27']['360'] = '194 lbs (88 Kg)';

$profile_questions['27']['361'] = '195 lbs (88.5 Kg)';

$profile_questions['27']['362'] = '196 lbs (88.9 Kg)';

$profile_questions['27']['363'] = '197 lbs (89.4 Kg)';

$profile_questions['27']['364'] = '198 lbs (89.8 Kg)';

$profile_questions['27']['365'] = '199 lbs (90.3 Kg)';

$profile_questions['27']['366'] = '200 lbs (90.7 Kg)';

$profile_questions['27']['10111'] = '201 lbs (91.2 Kg)';

$profile_questions['27']['10112'] = '202 lbs (91.6 Kg)';

$profile_questions['27']['10113'] = '203 lbs (92.1 Kg)';

$profile_questions['27']['10114'] = '204 lbs (92.5 Kg)';

$profile_questions['27']['10115'] = '205 lbs (93 Kg)';

$profile_questions['27']['10116'] = '206 lbs (93.4 Kg)';

$profile_questions['27']['10117'] = '207 lbs (93.9 Kg)';

$profile_questions['27']['10118'] = '208 lbs (94.3 Kg)';

$profile_questions['27']['10119'] = '209 lbs (94.8 Kg)';

$profile_questions['27']['10120'] = '210 lbs (95.2 Kg)';

$profile_questions['27']['10121'] = '211 lbs (95.7 Kg)';

$profile_questions['27']['10122'] = '212 lbs (96.1 Kg)';

$profile_questions['27']['10123'] = '213 lbs (96.6 Kg)';

$profile_questions['27']['10124'] = '214 lbs (97 Kg)';

$profile_questions['27']['10125'] = '215 lbs (97.5 Kg)';

$profile_questions['27']['10126'] = '216 lbs (97.9 Kg)';

$profile_questions['27']['10127'] = '217 lbs (98.3 Kg)';

$profile_questions['27']['10128'] = '218 lbs (98.8 Kg)';

$profile_questions['27']['10129'] = '219 lbs (99.2 Kg)';

$profile_questions['27']['10130'] = '220 lbs (99.7 Kg)';

$profile_questions['27']['10131'] = '221 lbs (100.2 Kg)';

$profile_questions['27']['10132'] = '222 lbs (100.6 Kg)';

$profile_questions['27']['10133'] = '223 lbs (101 Kg)';

$profile_questions['27']['10134'] = '224 lbs (101.5 Kg)';

$profile_questions['27']['10135'] = '225 lbs (101.9 Kg)';

$profile_questions['27']['10136'] = '226 lbs (102.3 Kg)';

$profile_questions['27']['10137'] = '227 lbs (102.8 Kg)';

$profile_questions['27']['10138'] = '228 lbs (103.2 Kg)';

$profile_questions['27']['10139'] = '229 lbs (103.7 Kg)';

$profile_questions['27']['10140'] = '230 lbs (104.1 Kg)';

$profile_questions['27']['10141'] = '231 lbs (104,6 Kg)';

$profile_questions['27']['10142'] = '232 lbs (105 Kg)';

$profile_questions['27']['10143'] = '233 lbs (105.5 Kg)';

$profile_questions['27']['10144'] = '234 lbs (105.9 Kg)';

$profile_questions['27']['10145'] = '235 lbs (106.4 Kg)';

$profile_questions['27']['10146'] = '236 lbs (106.8 Kg)';

$profile_questions['27']['10147'] = '237 lbs (107.3 Kg)';

$profile_questions['27']['10148'] = '238 lbs (107.7 Kg)';

$profile_questions['27']['10149'] = '239 lbs (108.2 Kg)';

$profile_questions['27']['10150'] = '240 lbs (108.6 Kg)';

$profile_questions['27']['10151'] = '241 lbs (109.1 Kg)';

$profile_questions['27']['10152'] = '242 lbs (109.5 Kg)';

$profile_questions['27']['10153'] = '243 lbs (110 Kg)';

$profile_questions['27']['10154'] = '244 lbs (110.4 Kg)';

$profile_questions['27']['10155'] = '245 lbs (110.9 Kg)';

$profile_questions['27']['10156'] = '246 lbs (111.3 Kg)';

$profile_questions['27']['10157'] = '247 lbs (111.8 Kg)';

$profile_questions['27']['10158'] = '248 lbs (112.2 Kg)';

$profile_questions['27']['10159'] = '249 lbs (112.7 Kg)';

$profile_questions['27']['10160'] = '250 lbs (113.1 Kg)';

$profile_questions['27']['10161'] = '251 lbs (113,6 Kg)';

$profile_questions['27']['10162'] = '252 lbs (114 Kg)';

$profile_questions['27']['10163'] = '253 lbs (114.5 Kg)';

$profile_questions['27']['10164'] = '254 lbs (114.9 Kg)';

$profile_questions['27']['10165'] = '255 lbs (115.3 Kg)';

$profile_questions['27']['10166'] = '256 lbs (115.8 Kg)';

$profile_questions['27']['10167'] = '257 lbs (116.2 Kg)';

$profile_questions['27']['10168'] = '258 lbs (116.7 Kg)';

$profile_questions['27']['10169'] = '259 lbs (117.1 Kg)';

$profile_questions['27']['10170'] = '260 lbs (117.6 Kg)';

$profile_questions['27']['10171'] = '261 lbs (118 Kg)';

$profile_questions['27']['10172'] = '262 lbs (118.5 Kg)';

$profile_questions['27']['10173'] = '263 lbs (118.9 Kg)';

$profile_questions['27']['10174'] = '264 lbs (119.4 Kg)';

$profile_questions['27']['10175'] = '265 lbs (119.8 Kg)';

$profile_questions['27']['10176'] = '266 lbs (120.3 Kg)';

$profile_questions['27']['10177'] = '267 lbs (120.7 Kg)';

$profile_questions['27']['10178'] = '268 lbs (121.1 Kg)';

$profile_questions['27']['10179'] = '269 lbs (121.6 Kg)';

$profile_questions['27']['10180'] = '270 lbs (122 Kg)';

$profile_questions['27']['10181'] = '271 lbs (122.5 Kg)';

$profile_questions['27']['10182'] = '272 lbs (122.9 Kg)';

$profile_questions['27']['10183'] = '273 lbs (123.3 Kg)';

$profile_questions['27']['10184'] = '274 lbs (123.8 Kg)';

$profile_questions['27']['10185'] = '275 lbs (124.2 Kg)';

$profile_questions['27']['10186'] = '276 lbs (124.7 Kg)';

$profile_questions['27']['10187'] = '277 lbs (125.1 Kg)';

$profile_questions['27']['10188'] = '278 lbs (125.5 Kg)';

$profile_questions['27']['10189'] = '279 lbs (126 Kg)';

$profile_questions['27']['10190'] = '280 lbs (126.4 Kg)';

$profile_questions['27']['10191'] = '281 lbs (126.9 Kg)';

$profile_questions['27']['10192'] = '282 lbs (127.3 Kg)';

$profile_questions['27']['10193'] = '283 lbs (127.8 Kg)';

$profile_questions['27']['10194'] = '284 lbs (128.2 Kg)';

$profile_questions['27']['10195'] = '285 lbs (128.7 Kg)';

$profile_questions['27']['10196'] = '286 lbs (129.1 Kg)';

$profile_questions['27']['10197'] = '287 lbs (129.6 Kg)';

$profile_questions['27']['10198'] = '288 lbs (130 Kg)';

$profile_questions['27']['10199'] = '289 lbs (130.5 Kg)';

$profile_questions['27']['10200'] = '290 lbs (130.9 Kg)';

$profile_questions['27']['10201'] = '291 lbs (131.3 Kg)';

$profile_questions['27']['10202'] = '292 lbs (131.8 Kg)';

$profile_questions['27']['10203'] = '293 lbs (132.2 Kg)';

$profile_questions['27']['10204'] = '294 lbs (132.7 Kg)';

$profile_questions['27']['10205'] = '295 lbs (133.1 Kg)';

$profile_questions['27']['10206'] = '296 lbs (133.6 Kg)';

$profile_questions['27']['10207'] = '297 lbs (134 Kg)';

$profile_questions['27']['10208'] = '298 lbs (134.5 Kg)';

$profile_questions['27']['10209'] = '299 lbs (134.9 Kg)';

$profile_questions['27']['10210'] = '300 lbs (135.3 Kg)';

$profile_questions['27']['10211'] = '301 lbs (135.8 Kg)';

$profile_questions['27']['10212'] = '302 lbs (136.2 Kg)';

$profile_questions['27']['10213'] = '303 lbs (136.7 Kg)';

$profile_questions['27']['10214'] = '304 lbs (137.1 Kg)';

$profile_questions['27']['10215'] = '305 lbs (137.6 Kg)';

$profile_questions['27']['10216'] = '306 lbs (138 Kg)';

$profile_questions['27']['10217'] = '307 lbs (138.5 Kg)';

$profile_questions['27']['10218'] = '308 lbs (138.9 Kg)';

$profile_questions['27']['10219'] = '309 lbs (139.4 Kg)';

$profile_questions['27']['10220'] = '310 lbs (139.8 Kg)';

$profile_questions['27']['10221'] = '311 lbs (140.3 Kg)';

$profile_questions['27']['10222'] = '312 lbs (140.7 Kg)';

$profile_questions['27']['10223'] = '313 lbs (141.1 Kg)';

$profile_questions['27']['10224'] = '314 lbs (141.6 Kg)';

$profile_questions['27']['10225'] = '315 lbs (142 Kg)';

$profile_questions['27']['10226'] = '316 lbs (142.5 Kg)';

$profile_questions['27']['10227'] = '317 lbs (142.9 Kg)';

$profile_questions['27']['10228'] = '318 lbs (143.4 Kg)';

$profile_questions['27']['10229'] = '319 lbs (143.8 Kg)';

$profile_questions['27']['10230'] = '320 lbs (144.3 Kg)';

$profile_questions['27']['10231'] = '321 lbs (144.7 Kg)';

$profile_questions['27']['10232'] = '322 lbs (145.2 Kg)';

$profile_questions['27']['10233'] = '323 lbs (145.6 Kg)';

$profile_questions['27']['10234'] = '324 lbs (146.1 Kg)';

$profile_questions['27']['10235'] = '325 lbs (146.6 Kg)';

$profile_questions['27']['10236'] = '326 lbs (147 Kg)';

$profile_questions['27']['10237'] = '327 lbs (147.5 Kg)';

$profile_questions['27']['10238'] = '328 lbs (147.9 Kg)';

$profile_questions['27']['10239'] = '329 lbs (148.4 Kg)';

$profile_questions['27']['10240'] = '330 lbs (148.8 Kg)';

$profile_questions['27']['10241'] = '331 lbs (149.3 Kg)';

$profile_questions['27']['10242'] = '332 lbs (149.7 Kg)';

$profile_questions['27']['10243'] = '333 lbs (150.2 Kg)';

$profile_questions['27']['10244'] = '334 lbs (150.6 Kg)';

$profile_questions['27']['10245'] = '335 lbs (151.1 Kg)';

$profile_questions['27']['10246'] = '336 lbs (151.6 Kg)';

$profile_questions['27']['10247'] = '337 lbs (152 Kg)';

$profile_questions['27']['10248'] = '338 lbs (152.5 Kg)';

$profile_questions['27']['10249'] = '339 lbs (152.9 Kg)';

$profile_questions['27']['10250'] = '340 lbs (153.3 Kg)';

$profile_questions['27']['10251'] = '341 lbs (153.8 Kg)';

$profile_questions['27']['10252'] = '342 lbs (154.2 Kg)';

$profile_questions['27']['10253'] = '343 lbs (154.7 Kg)';

$profile_questions['27']['10254'] = '344 lbs (155.1 Kg)';

$profile_questions['27']['10255'] = '345 lbs (155.6 Kg)';

$profile_questions['27']['10256'] = '346 lbs (156 Kg)';

$profile_questions['27']['10257'] = '347 lbs (156.5 Kg)';

$profile_questions['27']['10258'] = '348 lbs (156.9 Kg)';

$profile_questions['27']['10259'] = '349 lbs (157.4 Kg)';

$profile_questions['27']['10260'] = '350 lbs (157.8 Kg)';

$profile_questions['27']['10261'] = 'Over 350 lbs (157.8 Kg)';

$profile_questions['28']['question'] = 'Condici�n de Empleo';

$profile_questions['28']['description'] = '';

$profile_questions['28']['guideline'] = '';

$profile_questions['28']['extsearchhead'] = 'Estado de Empleo';

$profile_questions['28']['233'] = 'Tiempo Completo';

$profile_questions['28']['234'] = 'Tiempo Parcial';

$profile_questions['28']['235'] = 'Amo/a de Casa';

$profile_questions['28']['236'] = 'Retirado';

$profile_questions['28']['237'] = 'Independiente';

$profile_questions['28']['238'] = 'Aut�nomo';

$profile_questions['28']['239'] = 'Desempleado';

$profile_questions['28']['240'] = 'Trabajo en casa';

$profile_questions['29']['question'] = '�C�mo describes tu educaci�n?';

$profile_questions['29']['description'] = '';

$profile_questions['29']['guideline'] = '';

$profile_questions['29']['extsearchhead'] = 'Educaci�n';

$profile_questions['29']['194'] = 'Colegio Secundario';

$profile_questions['29']['195'] = 'Algo de universidad';

$profile_questions['29']['196'] = 'Grado de Asociado';

$profile_questions['29']['197'] = 'Licenciatura';

$profile_questions['29']['198'] = 'Postgrado';

$profile_questions['29']['199'] = 'Doctorado / Post Doctorado';

$profile_questions['29']['200'] = 'Escuela de la vida';

$profile_questions['29']['201'] = 'No responde';

$profile_questions['30']['question'] = '�Qu� idiomas hablas?';

$profile_questions['30']['description'] = '';

$profile_questions['30']['guideline'] = '';

$profile_questions['30']['extsearchhead'] = 'Idiomas';

$profile_questions['30']['10050'] = '�rabe';

$profile_questions['30']['10051'] = 'Camboyano';

$profile_questions['30']['10052'] = 'Chino';

$profile_questions['30']['10053'] = 'Holand�s';

$profile_questions['30']['10054'] = 'Ingl�s';

$profile_questions['30']['10055'] = 'Franc�s';

$profile_questions['30']['10056'] = 'Alem�n';

$profile_questions['30']['10058'] = 'Hebreo';

$profile_questions['30']['10059'] = 'Hindi';

$profile_questions['30']['10060'] = 'Italiano';

$profile_questions['30']['10061'] = 'Portugu�s';

$profile_questions['30']['10062'] = 'Rumano';

$profile_questions['30']['10063'] = 'Ruso';

$profile_questions['30']['10064'] = 'Espa�ol';

$profile_questions['30']['10065'] = 'Tailand�s';

$profile_questions['30']['10066'] = 'Turco';

$profile_questions['30']['10067'] = 'Vietnamita';

$profile_questions['30']['10717'] = 'Otro';

$profile_questions['37']['question'] = '�Como supiste de nosotros?';

$profile_questions['37']['description'] = '�En d�nde escuchaste sobre nosotros.';

$profile_questions['37']['guideline'] = '';

$profile_questions['37']['extsearchhead'] = 'Referido por';

$profile_questions['37']['10041'] = 'Mensaje de Correo electr�nico';

$profile_questions['37']['10042'] = 'Per�odico o Aviso Impreso';

$profile_questions['37']['10043'] = 'Banner En l�nea';

$profile_questions['37']['10044'] = 'Publicidad por Radio';

$profile_questions['37']['10045'] = 'Referido por amigo';

$profile_questions['37']['10046'] = 'Publicidad por Television';

$profile_questions['37']['10047'] = 'Motor de b�squeda';

$profile_questions['37']['10048'] = 'Viva de voz';

$profile_questions['37']['10049'] = 'Otros';

?>