<?php

class paginationmodel extends Model
{
		//Constructor
		function paginationmodel()
		{
				parent::Model();
		}
		function getPerPage($page, $default = 10)
		{
				$this->db->select('page_max');
				$this->db->from('pagination');
				$this->db->where('page', $page);
				$paginationQuery = $this->db->get();
				if ($paginationQuery->num_rows() > 0)
				{
						$paginationRow = $paginationQuery->result_array();
						return $paginationRow[0]['page_max'];
				}
				else  return $default;
		}
}

?>