<?php

	$lang['pagination_first']	= 'First';
	$lang['pagination_prev']	= 'Previous';
	$lang['pagination_next']	= 'Next';
	$lang['pagination_last']	= 'Last';

?>