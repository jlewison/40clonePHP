<?php
require_once ('./common/config.inc.php');
echo 'Session Expired. <a href="' . $CFG['auth']['login_url'] . '">Login to continue..!</a>';
?>