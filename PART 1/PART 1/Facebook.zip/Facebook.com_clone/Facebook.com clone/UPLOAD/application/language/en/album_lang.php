<?php

$lang['page_title']	= 'Album';

?>