<?php
/* This will upload number of pictures and videos loaded by the user to user table for control purposes. */

include_once('../init.php');

$pics = $db->getAll('select userid, count(*) as cnt from ! group by userid', array(USER_SNAP_TABLE));

foreach ($pics as $pic) {
	$db->query('update ! set pictures_cnt=? where id=?', array(USER_TABLE, $pic['cnt'], $pic['userid']));

}

$videos = $db->getAll('select userid, count(*) as cnt from ! group by userid', array(USER_VIDEOS_TABLE));

foreach ($videos as $video) {
	$db->query('update ! set videos_cnt=? where id=?', array(USER_TABLE, $video['cnt'], $video['userid']));

}

?>