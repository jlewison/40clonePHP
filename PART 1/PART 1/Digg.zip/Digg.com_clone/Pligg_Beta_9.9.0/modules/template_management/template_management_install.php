<?php
	$module_info['name'] = 'Template Management';
	$module_info['desc'] = 'Allows you to change the default template.';
	$module_info['version'] = 0.12;
?>
