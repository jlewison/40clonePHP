<?php
/**
 * Other settings Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 02/01/2008
 */
class OtherSettings extends controller
{
		function OtherSettings()
		{
				parent::controller();
				//check login
				if ($this->session->userdata('admin_logged_in') != 1 && $this->session->userdata('admin_id') == '') redirect('admin/login');
				//Load the language file
				$this->lang->load('admin/otherSettings', $this->config->item('language_code'));
		}
		function index()
		{
				$this->load->model('settingsmodel');
				$this->load->library('validation');
				$this->_otherSettingsFrm();
				if (!isset($_POST['other_settings']))
				{
						$outputData['settings'] = $this->settingsmodel->readAllSetting();
						if ($outputData['settings'] != false) $outputData['settingsArr'] = $outputData['settings'];
				}
				if ($this->validation->run() == false) $outputData['validationError'] = $this->validation->error_string;
				else
				{
						if (isset($_POST['other_settings']))
						{
								$this->settingsmodel->updateOtherSettings($_POST);
								//Set the flash data
								$this->session->set_flashdata('successMsg', $this->lang->line('othersettings_success_msg'));
								redirect('admin/otherSettings');
						}
				}
				$this->smartyextended->view('../admin/otherSettings', $outputData);
		}
		function _otherSettingsFrm()
		{
				$rules['total_albums_per_user'] = 'trim|required|numeric';
				$rules['total_photos_per_album'] = 'trim|required|numeric';
				$rules['total_groups_user_create'] = 'trim|required|numeric';
				$rules['total_groups_user_join'] = 'trim|required|numeric';
				$rules['total_events_user_create'] = 'trim|required|numeric';
				$rules['total_events_user_join'] = 'trim|required|numeric';
				$fields['total_albums_per_user'] = $this->lang->line('othersettings_total_albums');
				$fields['total_photos_per_album'] = $this->lang->line('othersettings_total_photos');
				$fields['total_groups_user_create'] = $this->lang->line('othersettings_total_groups');
				$fields['total_groups_user_join'] = $this->lang->line('othersettings_total_groups_user_join');
				$fields['total_events_user_create'] = $this->lang->line('othersettings_total_events');
				$fields['total_events_user_join'] = $this->lang->line('othersettings_total_events_user_join');
				$this->validation->set_rules($rules);
				$this->validation->set_fields($fields);
		}
}
?>