<?php
session_start();
$baseURL = 'http://' . $_SERVER['SERVER_NAME'] . str_replace('\\', '/', $_SERVER['PHP_SELF']);
$length = strlen($baseURL) - strlen('application/install/install.php');
$baseURL = substr($baseURL, 0, $length);
$mysqlHost = '';
$mysqlUname = '';
$mysqlPass = '';
$mysqlDB = '';
if ($_POST['submit'] == 'Submit' && trim($_POST['base_url']) != '' && trim($_POST['mysql_host']) != '' && trim($_POST['mysql_uname']) != '' && trim($_POST['mysql_db']) != '')
{
		$error = '';
		$link = @mysql_connect(trim($_POST['mysql_host']), trim($_POST['mysql_uname']), trim($_POST['mysql_password']));
		if (!$link)
		{
				$error = 'Could not connect to the host specified. Error: ' . mysql_error();
		}
		else
		{
				//Connected successfully
				$db_selected = @mysql_select_db(trim($_POST['mysql_db']), $link);
				if (!$db_selected)
				{
						$error = $error . '<BR>Can\'t use the database specified. Error: ' . mysql_error();
				}
				mysql_close($link);
		}
		$baseURL = trim($_POST['base_url']);
		$mysqlHost = trim($_POST['mysql_host']);
		$mysqlUname = trim($_POST['mysql_uname']);
		$mysqlPass = trim($_POST['mysql_password']);
		$mysqlDB = trim($_POST['mysql_db']);
		if ($error == '')
		{
				$basePath = dirname(__file__);
				/* Create the config file */
				$file1 = file_get_contents($basePath . '/temp/config1.cfg');
				$file2 = trim($_POST['base_url']);
				$file3 = file_get_contents($basePath . '/temp/config2.cfg');
				$configFile = $file1 . $file2 . $file3;
				$handle = fopen('config.php', 'w+');
				if ($handle)
				{
						fwrite($handle, $configFile);
						fclose($handle);
				}
				/* Create the config file */
				/* Create the database file */
				$file4 = file_get_contents($basePath . '/temp/database1.cfg');
				$file5 = file_get_contents($basePath . '/temp/database2.cfg');
				$databaseFile = $file4 . '$db[\'default\'][\'hostname\'] = "' . trim($_POST['mysql_host']) . '";
$db[\'default\'][\'username\'] = "' . trim($_POST['mysql_uname']) . '";
$db[\'default\'][\'password\'] = "' . trim($_POST['mysql_password']) . '";
$db[\'default\'][\'database\'] = "' . trim($_POST['mysql_db']) . '";
' . $file5;
				$handle = fopen('database.php', 'w+');
				if ($handle)
				{
						fwrite($handle, $databaseFile);
						fclose($handle);
				}
				/* Create the database file */
				//Copy the config file
				if (file_exists($basePath . '../config/config.php'))
				{
						if (file_exists($basePath . '../config/config.php.bak')) @unlink($basePath . '../config/config.php.bak');
						@rename($basePath . '../config/config.php', $basePath . '../config/config.php.bak');
				}
				copy($basePath . '/config.php', $basePath . '/../config/config.php');
				//Copy the database file
				if (file_exists($basePath . '../config/database.php'))
				{
						if (file_exists($basePath . '../config/database.php.bak')) @unlink($basePath . '../config/database.php.bak');
						@rename($basePath . '../config/database.php', $basePath . '../config/database.php.bak');
				}
				copy($basePath . '/database.php', $basePath . '/../config/database.php');
				//rename the index.php file
				@rename($basePath . '/../../index.php', $basePath . '/../../index.php.install');
				@rename($basePath . '/../../index.php.old', $basePath . '/../../index.php');
				$_SESSION['baseurl'] = trim($_POST['base_url']);
				header('Location: complete.php');
		}
}
elseif ($_POST['submit'] == 'Submit')
{
		$baseURL = trim($_POST['base_url']);
		$mysqlHost = trim($_POST['mysql_host']);
		$mysqlUname = trim($_POST['mysql_uname']);
		$mysqlPass = trim($_POST['mysql_password']);
		$mysqlDB = trim($_POST['mysql_db']);
		$error = 'All the fields are required';
}
?>
<html>
<head>
<link href="css/install.css" rel="stylesheet" type="text/css" />
<title>Installation of Kootali [x-MoBiLe] Nulled</title>
</head>

	<h1>Installation of Kootali [x-MoBiLe] Nulled</h1>
    
	<div id="sys_req">
    <br />
	<?php
// PHP5?
if (!version_compare(phpversion(), '5.0', '>='))
{
		echo 'OOps!! <strong>Installation error:</strong> in order to run Kootali you need PHP5. Your current PHP version is: ' . phpversion();
}
else
{
		echo '<div id="error" class="error">' . $error . '</div><BR>';
?> 
    <fieldset>
		<legend>Install Settings</legend>
		<br><br>
		<form name="installFrm" method="post" action="">
		<fieldset>
			<legend>General Settings</legend>
				<table width="50%" cellpadding="5" cellspacing="0" border="0">
					<tr>
						<td width="25%">Base URL:</td>
						<td><input type="text" name="base_url" size="50" value="<?php echo $baseURL; ?>" />&nbsp;*</td>
					</tr>
				</table>             
		</fieldset>
		<br><br>
		<fieldset>
			<legend>MySQL Settings</legend>
				<table width="50%" cellpadding="5" cellspacing="0" border="0">
					<tr>
						<td width="25%">Host Name:</td>
						<td><input type="text" name="mysql_host" size="35" value="<?php echo $mysqlHost; ?>" />&nbsp;*</td>
					</tr>
					<tr>
						<td width="25%">User Name:</td>
						<td><input type="text" name="mysql_uname" size="35" value="<?php echo $mysqlUname; ?>" />&nbsp;*</td>
					</tr>
					<tr>
						<td width="25%">Password:</td>
						<td><input type="text" name="mysql_password" size="35" value="<?php echo $mysqlPass; ?>" /></td>
					</tr>
					<tr>
						<td width="25%">Database Name:</td>
						<td><input type="text" name="mysql_db" size="35" value="<?php echo $mysqlDB; ?>" />&nbsp;*</td>
					</tr>
				</table>             
		</fieldset>	
		<br><br>
		<table width="50%" cellpadding="5" cellspacing="0" border="0">
			<tr>
				<td width="25%">* = required</td>
				<td>&nbsp;&nbsp;<input type="submit" name="submit" value="Submit"></td>
			</tr>
		</table>
	</fieldset>
	</form>
	<?php
} // End of else

?>
    </div>
<body>
</body>
</html>
