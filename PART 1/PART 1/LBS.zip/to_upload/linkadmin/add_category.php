<?php include('restrict.php'); include('../settings.php'); ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>Add New Listing - Link Bid Script Admin Panel</title>
<link rel="shortcut icon" href="img/favicon.ico" />
<link rel="stylesheet" type="text/css" href="admin.css" />

<SCRIPT language=javascript>
function gurl(l){ 
	document.location.href='/'+l+'/';
}

function dodiv() { 
	var frm = document.pgfrm; 
	var tt=frm.keyword.value; 
	var dd1=frm.descr1.value; 
	var dd2=frm.descr2.value; 
	var dd3=frm.url.value; 
	var bbd=frm.bid.value; 
	
	if (tt) { document.getElementById('kw').innerHTML=tt; } 
	else {  document.getElementById('kw').innerHTML="Example Title"; } 
	
	if (dd1) { document.getElementById('d1').innerHTML=dd1; } 
	else {  document.getElementById('d1').innerHTML="Description line 1 sample"; } 
	
	if (dd3) { document.getElementById('d3').innerHTML=dd3; } 
	
	else {  document.getElementById('d3').innerHTML="http://your_site.com/"; } 
	
	if (bbd) { document.getElementById('bidd').innerHTML=bbd; } 
	else {  document.getElementById('bidd').innerHTML="<?php echo("$minbid");?>"; }
} 
	
function chknum(evt) { 
	var charCode = (evt.which) ? evt.which : event.keyCode; 
	
	if (charCode > 31 && (charCode < 48 || charCode > 57)) return false; return true;
} 
	
function chkfrm() { 
	var frm = document.pgfrm; 
	if (!frm.selectc.value.replace(/^\s*|\s*$/g,"")) { alert("Please selest category for your listing"); frm.selectc.focus(); return false; } 
	if (!frm.email.value.replace(/^\s*|\s*$/g,"")) { alert("You must provide an e-mail address."); frm.email.focus(); return false; } 
	if (!frm.url.value.replace(/^\s*|\s*$/g,"") || frm.url.value.replace(/^\s*|\s*$/g,"") == "http://") { alert("You must provide a website URL."); frm.url.focus(); return false; } 
	if (!frm.keyword.value.replace(/^\s*|\s*$/g,"")) { alert("Please enter the title for your listing"); frm.keyword.focus(); return false; } 
	if (!frm.descr1.value.replace(/^\s*|\s*$/g,"")) { alert("You must provide a brief description."); frm.descr1.focus(); return false; } 
	if (!frm.descr2.value.replace(/^\s*|\s*$/g,"")) { alert("You must provide an extended description."); frm.descr2.focus(); return false; } 
	if (!frm.bid.value.replace(/^\s*|\s*$/g,"")) { alert("You must provide a bid amount."); frm.bid.focus(); return false; } 
	if (frm.bid.value.replace(/^\s*|\s*$/g,"") < <?php echo("$minbid");?>) { alert("Your initial contribution must be at least <?php echo("$currency");?><?php echo("$minbid");?>"); frm.bid.focus(); return false; }
} 
</SCRIPT>
</head>

<body>
<?php $x = getenv("HTTP_HOST").getenv("REQUEST_URI"); ?>
<?php include('header_tpl.php'); ?>

<?php
mysql_select_db($database_apound, $apound);
$query_LboxCAT = "SELECT * FROM categorylisting ORDER BY categorylisting.categoryname ASC";
$LboxCAT = mysql_query($query_LboxCAT, $apound) or die(mysql_error());
$row_LboxCAT = mysql_fetch_assoc($LboxCAT);
$totalRows_LboxCAT = mysql_num_rows($LboxCAT);
?>
<h2>Add New Listing</h2>
<table width="100%"  border="0" cellspacing="10" cellpadding="10">
  <tr>
    <td><form action="admin_processing.php" method="post">

Category:
<select name="selectc" id="selectc">
<option value="" selected>Please select the category</option>
<?php do { ?>
<option value="<?php echo $row_LboxCAT['catlistid']?>"><?php echo $row_LboxCAT['categoryname']?></option>
<?php } while ($row_LboxCAT = mysql_fetch_assoc($LboxCAT)); $rows = mysql_num_rows($LboxCAT); if($rows > 0) { mysql_data_seek($LboxCAT, 0); $row_LboxCAT = mysql_fetch_assoc($LboxCAT); } ?>
</select>

E-mail Address:
<input name="email" type="text"><br>

    
Website Title:
<input name="keyword" type="text"><br>

Website URL:
<input name="url" type="text" value="http://"><br>

Brief Description
<textarea name="descr1"></textarea><br>

Extended Description:
<textarea name="descr2"></textarea><br>

Meta Description:
<textarea name="mdesc"></textarea><br>

Meta Keywords:
<input name="mword" type="text"><br>

<?php if($deepenable == 'Y') { ?>

Deep Title 1:
<input name="deeptf" type="text"><br>

Deep URL 1:
<input name="dfurl" type="text" value="http://"><br>

Deep Title 2:
<input name="deepts" type="text"><br>

Deep URL 2:
<input name="dsurl" type="text" value="http://"><br>

Deep Title 3:
<input name="deeptt" type="text"><br>

Deep URL 3:
<input name="dturl" type="text" value="http://"><br>


<?php } else {} ?>

Contribution:
<?php echo("$currency");?><br>
<input name="bid" value="<?php echo("$minbid");?>">.00<br>
<br>
<input type="hidden" value="1" name="categ">
<input type="submit" value="Add Listing">
</form></td>
  </tr>
</table>


<?php include('footer_tpl.php'); ?>
</body>
</html>