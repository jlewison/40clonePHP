<?php
require_once ('./common/config.inc.php');
$CFG['lang']['include_files'][] = 'includes/languages/%s/signup.php';
$CFG['html']['header'] = 'members/includes/languages/%s/html_header.php';
$CFG['html']['footer'] = 'members/includes/languages/%s/html_footer.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['lang']['include_files'][] = 'common/email_templates/languages/%s/email_notify.inc.php';
$CFG['lang']['include_files'][] = 'common/languages/%s/help.inc.php';
if ($_POST) $CFG['mods']['include_files'][] = 'common/classes/phpmailer/class_PHPMailer.lib.php';
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class SignUpFormHandler extends FormHandler
{
		public function insertFormFieldsInUserTable($user_table_name, $fields_to_insert_arr = array())
		{
				$field_names_separated_by_comma = 'doj, ';
				$parameters_separated_by_comma = $this->dbObj->SQLDate('Y-m-d H:i:s') . ', ';
				$field_values_arr = array();
				$f_count = 0;
				foreach ($fields_to_insert_arr as $field_name)
						if (isset($this->fields_arr[$field_name]))
						{
								$con_field_name = $this->getUserTableField($field_name);
								$field_names_separated_by_comma .= $con_field_name . ', ';
								$parameters_separated_by_comma .= $this->dbObj->Param($con_field_name) . ', ';
								$field_values_arr[] = $this->fields_arr[$field_name];
						}
				$field_names_separated_by_comma = substr($field_names_separated_by_comma, 0, strrpos($field_names_separated_by_comma, ','));
				$parameters_separated_by_comma = substr($parameters_separated_by_comma, 0, strrpos($parameters_separated_by_comma, ','));
				$sql = 'INSERT INTO ' . $user_table_name . ' ( ' . $field_names_separated_by_comma . ') ' . ' VALUES (' . $parameters_separated_by_comma . ')';
				$stmt = $this->dbObj->Prepare($sql);
				$result = $this->dbObj->Execute($stmt, $field_values_arr);
				if (!$result) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return $this->dbObj->Insert_ID();
		}
		public function insertAdvancedSearchTable($user_id)
		{
				$sql = 'INSERT INTO ' . $this->CFG['db']['tbl']['advanced_search'] . ' SET' . ' user_id=' . $this->dbObj->Param('user_id');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($user_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function insertUsersAnsLogTable($user_id)
		{
				$sql = 'INSERT INTO ' . $this->CFG['db']['tbl']['users_ans_log'] . ' SET' . ' user_id=' . $this->dbObj->Param('user_id');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($user_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function chkIsNotDuplicateEmail($table_name, $field_name, $err_tip = '')
		{
				$sql = 'SELECT ' . $this->getUserTableField('user_id') . ' FROM ' . $table_name . ' WHERE ' . $this->getUserTableField('email') . ' =' . $this->dbObj->Param($field_name);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr[$field_name]));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$numrows = $rs->PO_RecordCount();
				$is_ok = ($numrows == 0);
				if (!$is_ok) $this->fields_err_tip_arr[$field_name] = $err_tip;
				return $is_ok;
		}
		public function chkIsNotDuplicateName($table_name, $field_name, $err_tip = '')
		{
				$sql = 'SELECT ' . $this->getUserTableField('user_id') . ' FROM ' . $table_name . ' WHERE ' . $this->getUserTableField('name') . ' =' . $this->dbObj->Param($field_name);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr[$field_name]));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$numrows = $rs->PO_RecordCount();
				$is_ok = ($numrows == 0);
				if (!$is_ok) $this->fields_err_tip_arr[$field_name] = $err_tip;
				return $is_ok;
		}
		public function chkIsSamePasswords($field_name1, $field_name2, $err_tip = '')
		{
				$is_ok = ($this->fields_arr[$field_name1] == $this->fields_arr[$field_name2]);
				if (!$is_ok) $this->fields_err_tip_arr[$field_name1] = $this->fields_err_tip_arr[$field_name2] = $err_tip;
				return $is_ok;
		}
		public function sendActivationEmail()
		{
				$activation_link = getUrl('activateAccount.php', 'activate/') . '?code=' . urlencode($this->getActivationCode($this->fields_arr['user_id']));
				if ($this->CFG['admin']['signup_auto_activate']) Redirect2URL($activation_link);
				$activation_link = '<a href="' . $activation_link . '">' . $activation_link . '</a>';
				$activation_subject = str_replace('{site_name}', $this->CFG['site']['name'], $this->LANG['activation_subject']);
				$link = '<a href="' . $this->CFG['site']['url'] . '">' . $this->CFG['site']['url'] . '</a>';
				$activation_message = str_replace('{site_name}', $this->CFG['site']['name'], $this->LANG['activation_message']);
				$activation_message = str_replace('{user_name}', $this->fields_arr['name'], $activation_message);
				$activation_message = str_replace('{link}', $link, $activation_message);
				$activation_message = str_replace('{activation_link}', $activation_link, $activation_message);
				$activation_message = nl2br($activation_message);
				$is_ok = $this->_sendMail($this->fields_arr['email'], $activation_subject, $activation_message, $this->CFG['site']['noreply_name'], $this->CFG['site']['noreply_email']);
				if ($is_ok) $this->setDisplayVar('mail_status', $this->LANG['signup_activation_code_sent']);
				else  $this->setDisplayVar('mail_status', $this->LANG['signup_activation_code_not_sent']);
		}
		private function _sendMail($to_email, $subject, $body, $sender_name, $sender_email)
		{
				$mail = new PHPMailer();
				$mail->AddAddress($to_email);
				$mail->FromName = $sender_name;
				$mail->From = $mail->Sender = $sender_email;
				$mail->Subject = $subject;
				$mail->Body = $body;
				$mail->IsMail();
				$mail->IsHTML(true);
				return ($mail->Send());
		}
		public function chkIsPasswordAndUserNameAreSame($err_tip = '')
		{
				if ($this->fields_arr['name'] and $this->fields_arr['password'])
				{
						if ($this->fields_arr['name'] == $this->fields_arr['password'])
						{
								$this->fields_err_tip_arr['password'] = $err_tip;
								return false;
						}
				}
				return true;
		}
		public function chkIsValidSize($field_name, $min, $max, $err_tip = '')
		{
				if ((strlen($this->fields_arr[$field_name]) < $min) or (strlen($this->fields_arr[$field_name]) > $max))
				{
						$this->fields_err_tip_arr[$field_name] = $err_tip;
						return false;
				}
				return true;
		}
		public function chkIsAllowedUserName($err_tip = '')
		{
				$user_name = strtolower($this->fields_arr['name']);
				if (in_array($user_name, $this->CFG['admin']['not_allowed_usernames']))
				{
						$this->fields_err_tip_arr['name'] = $err_tip;
						return false;
				}
				return true;
		}
		public function chkIsValidCaptcha($field_name, $err_tip = '')
		{
				$is_ok = (isset($_SESSION['signup_captcha']) and ($_SESSION['signup_captcha'] == $this->fields_arr[$field_name]));
				if (!$is_ok) $this->fields_err_tip_arr[$field_name] = $err_tip;
				return $is_ok;
		}
}
$sgnfrm = new SignUpFormHandler();
if (!chkAllowedModule(array('registration'))) Redirect2URL($CFG['redirect']['dsabled_module_url']);
$sgnfrm->makeGlobalize($CFG, $LANG);
$sgnfrm->setPageBlockNames(array('msg_form_error', 'msg_form_success', 'form_signup'));
$sgnfrm->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$sgnfrm->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$sgnfrm->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$sgnfrm->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$sgnfrm->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$sgnfrm->setFormField('name', '');
$sgnfrm->setFormField('password', '');
$sgnfrm->setFormField('confirm_password', '');
$sgnfrm->setFormField('email', '');
$sgnfrm->setFormField('gender', 'Male');
$sgnfrm->setFormField('bio', '');
$sgnfrm->setFormField('captcha', '');
$sgnfrm->setFormField('terms', '');
$sgnfrm->setAllPageBlocksHide();
$sgnfrm->setPageBlockShow('form_signup');
$LANG['signup_name'] = str_replace('{min_count}', $CFG['admin']['username_min_size'], $LANG['signup_name']);
$LANG['signup_name'] = str_replace('{max_count}', $CFG['admin']['username_max_size'], $LANG['signup_name']);
$LANG['signup_password'] = str_replace('{min_count}', $CFG['admin']['password_min_size'], $LANG['signup_password']);
$LANG['signup_password'] = str_replace('{max_count}', $CFG['admin']['password_max_size'], $LANG['signup_password']);
if ($sgnfrm->isFormPOSTed($_POST, 'index_submit')) $sgnfrm->sanitizeFormInputs($_POST);
if ($sgnfrm->isFormPOSTed($_POST, 'signup_submit'))
{
		$sgnfrm->sanitizeFormInputs($_POST);
		$sgnfrm->setDBObject($db);
		$sgnfrm->chkIsNotEmpty('email', $LANG['signup_err_tip_compulsory']) and $sgnfrm->chkIsValidEmail('email', $LANG['signup_err_tip_invalid_email']) and ($sgnfrm->chkIsNotDuplicateEmail($CFG['db']['tbl']['users'], 'email', $LANG['signup_err_tip_email_already_exists']) or $sgnfrm->setCommonErrorMsg($LANG['signup_err_tip_email_already_exists']));
		$sgnfrm->chkIsNotEmpty('name', $LANG['signup_err_tip_compulsory']) and $sgnfrm->chkIsAlphaNumeric('name', $LANG['signup_err_tip_invalid_username']) and $sgnfrm->chkIsValidSize('name', $CFG['admin']['username_min_size'], $CFG['admin']['username_max_size'], $LANG['signup_err_tip_invalid_size']) and $sgnfrm->chkIsAllowedUserName($LANG['not_allowed_username']) and $sgnfrm->chkIsNotDuplicateName($CFG['db']['tbl']['users'], 'name', $LANG['signup_err_tip_name_already_exists']);
		$sgnfrm->chkIsNotEmpty('password', $LANG['signup_err_tip_compulsory']) and $sgnfrm->chkIsValidSize('password', $CFG['admin']['password_min_size'], $CFG['admin']['password_max_size'], $LANG['signup_err_tip_invalid_size']);
		$sgnfrm->chkIsNotEmpty('confirm_password', $LANG['signup_err_tip_compulsory']) and $sgnfrm->chkIsSamePasswords('password', 'confirm_password', $LANG['signup_err_tip_same_password']);
		$sgnfrm->chkIsPasswordAndUserNameAreSame($LANG['password_user_name']);
		if ($sgnfrm->isValidFormInputs() and $CFG['signup']['captcha'])
		{
				$sgnfrm->chkIsNotEmpty('captcha', $LANG['signup_err_tip_compulsory']) and $sgnfrm->chkIsValidCaptcha('captcha', $LANG['signup_err_tip_invalid']);
		}
		$sgnfrm->chkIsNotEmpty('terms', $LANG['signup_err_tip_compulsory']);
		if ($sgnfrm->isValidFormInputs())
		{
				$bio = html_entity_decode($sgnfrm->getFormField('bio'));
				$bio = strip_tags($bio, $CFG['html']['allowed_tags']);
				$sgnfrm->setFormField('bio', $bio);
				$sgnfrm->setFormField('password', md5($sgnfrm->getFormField('password')));
				$sgnfrm->setFormField('name', strtolower($sgnfrm->getFormField('name')));
				$user_id = $sgnfrm->insertFormFieldsInUserTable($CFG['db']['tbl']['users'], array('password', 'gender', 'bio', 'name', 'email'));
				$sgnfrm->setIndirectFormField('user_id', $user_id);
				$sgnfrm->insertAdvancedSearchTable($user_id);
				$sgnfrm->insertUsersAnsLogTable($user_id);
				$sgnfrm->sendActivationEmail();
				$sgnfrm->setAllPageBlocksHide();
				$sgnfrm->setPageBlockShow('msg_form_success');
		}
		else
		{
				$sgnfrm->setAllPageBlocksHide();
				$sgnfrm->setPageBlockShow('msg_form_error');
				$sgnfrm->setPageBlockShow('form_signup');
		}
		$sgnfrm->setFormField('captcha', '');
		$sgnfrm->setFormField('password', '');
		$sgnfrm->setFormField('confirm_password', '');
}



?>
<?php if ($CFG['signup']['captcha'])
{ ?>
<script language="javascript">
	var img_count=1;
	function changeCaptchaImage(){
		document.getElementById('captchaImage').src = '<?php echo $CFG['site']['url']; ?>captchaSignup.php?img_count='+img_count;
		img_count++;
		return false;
	}
</script>
<?php } ?>
<div id="selSignUp">
  <h2><?php echo $LANG['signup_title']; ?></h2>
  <?php
if ($sgnfrm->isShowPageBlock('msg_form_error'))
{
?>
  <div id="selMsgError">
    <p><?php echo $LANG['msg_error_sorry'] . ' ' . $sgnfrm->getCommonErrorMsg(); ?></p>
  </div>
  <?php
}
if ($sgnfrm->isShowPageBlock('msg_form_success'))
{
?>
  <div id="selMsgSuccess">
    <p><?php echo $LANG['signup_success']; ?></p>
    <p class="clsMsgAdditionalText"><?php echo $sgnfrm->getDisplayVar('mail_status'); ?></p>
  </div>
  <?php
}
if ($sgnfrm->isShowPageBlock('form_signup'))
{
?>
  <form name="form_signup" id="selFormSignup" method="post" action="<?php echo URL(getUrl($CFG['site']['relative_url'] . 'signup.php', $CFG['site']['relative_url'] . 'register/', false)); ?>" autocomplete="off">
    <div class="clsSignupContent">
      <div class="clsSignupAccount">
        <p class="clsCompulsoryNote"><span id="selCompulsoryField">*</span> <?php echo $LANG['signup_err_tip_compulsory']; ?> </p>
        <table class="clsCommonTable" summary="<?php echo $LANG['signup_tbl_summary']; ?>">
          <tr>
            <th colspan="2"><?php echo $LANG['signup_personal']; ?></th>
          </tr>
          <tr>
            <td class="<?php echo $sgnfrm->getCSSFormLabelCellClass('name'); ?>"><?php ShowHelpTip('name'); ?>
              <label for="name"><?php echo $LANG['signup_name']; ?></label>
              <span id="selCompulsoryField">*</span></td>
            <td class="<?php echo $sgnfrm->getCSSFormFieldCellClass('name'); ?>"><?php echo $sgnfrm->getFormFieldErrorTip('name'); ?>
              <input type="text" class="clsTextBox help" name="name" id="name" maxlength="<?php echo $CFG['admin']['username_max_size']; ?>" title="<?php ShowToolTip('name'); ?>" tabindex="<?php echo $sgnfrm->getTabIndex(); ?>" value="<?php echo $sgnfrm->getFormField('name'); ?>" /></td>
          </tr>
          <tr>
            <td class="<?php echo $sgnfrm->getCSSFormLabelCellClass('email'); ?>"><label for="email">
              <?php ShowHelpTip('email'); ?>
              <?php echo $LANG['signup_email']; ?></label>
              <span id="selCompulsoryField">*</span></td>
            <td class="<?php echo $sgnfrm->getCSSFormFieldCellClass('email'); ?>"><?php echo $sgnfrm->getFormFieldErrorTip('email'); ?>
              <input type="text" class="clsTextBox help" name="email" id="email" title="<?php ShowToolTip('email'); ?>" tabindex="<?php echo $sgnfrm->getTabIndex(); ?>" value="<?php echo $sgnfrm->getFormField('email'); ?>" /></td>
          </tr>
          <tr>
            <td class="<?php echo $sgnfrm->getCSSFormLabelCellClass('password'); ?>"><?php ShowHelpTip('password'); ?>
              <label for="password"><?php echo $LANG['signup_password']; ?></label>
              <span id="selCompulsoryField">*</span></td>
            <td class="<?php echo $sgnfrm->getCSSFormFieldCellClass('password'); ?>"><?php echo $sgnfrm->getFormFieldErrorTip('password'); ?>
              <input type="password" class="clsTextBox help" name="password" id="password" title="<?php ShowToolTip('password'); ?>" tabindex="<?php echo $sgnfrm->getTabIndex(); ?>" value="<?php echo $sgnfrm->getFormField('password'); ?>" /></td>
          </tr>
          <tr>
            <td class="<?php echo $sgnfrm->getCSSFormLabelCellClass('confirm_password'); ?>"><?php ShowHelpTip('confirmpassword'); ?>
              <label for="confirm_password"><?php echo $LANG['signup_confirm_password']; ?></label>
              <span id="selCompulsoryField">*</span></td>
            <td class="<?php echo $sgnfrm->getCSSFormFieldCellClass('confirm_password'); ?>"><?php echo $sgnfrm->getFormFieldErrorTip('confirm_password'); ?>
              <input type="password" class="clsTextBox help" name="confirm_password" id="confirm_password" title="<?php ShowToolTip('confirmpassword'); ?>" tabindex="<?php echo $sgnfrm->getTabIndex(); ?>" value="<?php echo $sgnfrm->getFormField('confirm_password'); ?>" /></td>
          </tr>
          <tr>
            <td class="<?php echo $sgnfrm->getCSSFormLabelCellClass('gender'); ?>"><?php ShowHelpTip('gender'); ?>
              <label for="sex_male"><?php echo $LANG['signup_sex']; ?></label></td>
            <td class="<?php echo $sgnfrm->getCSSFormFieldCellClass('gender'); ?>"><?php echo $sgnfrm->getFormFieldErrorTip('gender'); ?>
              <input type="radio" name="gender" id="sex_male" value="Male" tabindex="<?php echo $sgnfrm->getTabIndex(); ?>" <?php if ($sgnfrm->getFormField('gender') == 'Male') echo 'CHECKED'; ?> />
              <?php echo $LANG['signup_sex_male']; ?>
              <input type="radio" name="gender" id="sex_female" value="Female" tabindex="<?php echo $sgnfrm->getTabIndex(); ?>" <?php if ($sgnfrm->getFormField('gender') == 'Female') echo 'CHECKED'; ?> />
              <?php echo $LANG['signup_sex_female']; ?></td>
          </tr>
          <tr>
            <td class="<?php echo $sgnfrm->getCSSFormLabelCellClass('bio'); ?>"><label for="bio">
              <?php ShowHelpTip('bio'); ?>
              <?php echo $LANG['signup_bio']; ?></label></td>
            <td class="<?php echo $sgnfrm->getCSSFormFieldCellClass('bio'); ?>"><?php echo $sgnfrm->getFormFieldErrorTip('bio'); ?>
              <p><?php echo $LANG['stock_allowed_htmltags']; ?> <?php echo htmlspecialchars($CFG['html']['allowed_tags']); ?></p>
              <textarea name="bio" id="bio" tabindex="<?php echo $sgnfrm->getTabIndex(); ?>" maxlength="<?php echo $CFG['admin']['bio_count']; ?>" tabindex="<?php echo $sgnfrm->getTabIndex(); ?>" onFocus="updatelength(this);" onKeyUp="updatelength(this);"><?php echo $sgnfrm->getFormField('bio'); ?></textarea>
          	  <div><?php echo $LANG['signup_total_charaters_entered']; ?> <span id="ss">0  (Limit <?php echo $CFG['admin']['bio_count']; ?>)</span></div>
		  	</td>
		  </tr>
<?php
		if ($CFG['signup']['captcha'])
		{
?>
			<tr>
				<td class="<?php echo $sgnfrm->getCSSFormLabelCellClass('captcha'); ?>"><label for="captcha"><?php ShowHelpTip('captcha'); ?><?php echo $LANG['signup_captcha']; ?></label><span id="selCompulsoryField">*</span></td>
				<td class="clsSignupImage <?php echo $sgnfrm->getCSSFormFieldCellClass('captcha'); ?>"><?php echo $sgnfrm->getFormFieldErrorTip('captcha'); ?>
					<input type="text" class="clsTextBox" name="captcha" id="captcha" tabindex="<?php echo $sgnfrm->getTabIndex(); ?>" value="<?php echo $sgnfrm->getFormField('captcha'); ?>" /><br/><img id="captchaImage" src="<?php echo $CFG['site']['url']; ?>captchaSignup.php" alt="<?php echo $LANG['signup_captcha_alt']; ?>" title="<?php echo $LANG['signup_captcha_title']; ?>" />
					<p><a href="#" onClick="return changeCaptchaImage()"><?php echo $LANG['new_code']; ?></a></p>
				</td>
			</tr>
<?php
		}
?>
          <tr>
            <td class="<?php echo $sgnfrm->getCSSFormLabelCellClass('terms'); ?>"><label for="terms"><a target="_blank" href="<? echo getUrl($CFG['site']['relative_url'] . 'staticPage.php?pg=terms', $CFG['site']['relative_url'] . 'terms/', false); ?>"><?php echo $LANG['agree_terms_service']; ?></a></label></td>
            <td class="<?php echo $sgnfrm->getCSSFormFieldCellClass('terms'); ?>"><?php echo $sgnfrm->getFormFieldErrorTip('terms'); ?>
              <input type="checkBox" class="clsCheckRadio help" name="terms" id="terms" title="<?php ShowToolTip(); ?>" tabindex="<?php echo $sgnfrm->getTabIndex(); ?>"<?php echo ($sgnfrm->getFormField('terms') != '') ? ' checked' : ''; ?> /></td>
          </tr>
          <tr>
            <td class="clsFormFieldCellDefault">&nbsp;</td>
            <td class="<?php echo $sgnfrm->getCSSFormFieldCellClass('submit'); ?>"><p class="clsSubmitTextBox clsSignupSubmitTextBox">
                <input type="submit" class="clsSubmitButton" name="signup_submit" id="signup_submit" tabindex="<?php echo $sgnfrm->getTabIndex(); ?>" value="<?php echo $LANG['signup_submit']; ?>" />
              </p></td>
          </tr>
        </table>
      </div>
    </div>
  </form>
  <div class="clsSignup">
    <p class="clsForgot"><a href="<?php echo getUrl($CFG['site']['relative_url'] . 'forgotPassword.php', $CFG['site']['relative_url'] . 'forgotpassword/', false); ?>"><?php echo $LANG['forgot_password']; ?></a></p>
    <p class="clsAlreadyMember"><a href="<?php echo getUrl($CFG['site']['relative_url'] . 'login.php', $CFG['site']['relative_url'] . 'login/', false); ?>"><?php echo $LANG['already_member']; ?></a></p>
  </div>
  <?php
}
?>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>
