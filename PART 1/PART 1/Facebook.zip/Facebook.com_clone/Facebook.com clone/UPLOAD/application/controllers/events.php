<?php
/**
 * Events Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 01/14/2008
 */
class Events extends Controller
{
		//Constructor
		var $userId, $notificationId;
		function Events()
		{
				parent::Controller();
				//Asia/Calcutta
				loginRequired();
				//echo date_default_timezone_get();
				$this->notificationId = 4;
				$this->load->model('eventsModel');
				$this->userId = $this->session->userdata('user_id');
				//Load the language file
				$this->lang->load('posted', $this->config->item('language_code'));
				$this->lang->load('wall', $this->config->item('language_code'));
				$this->lang->load('events', $this->config->item('language_code'));
		}
		//Default function
		function index()
		{
				$this->home();
		}
		function home($user = '')
		{
				$data = array();
				$user = (!ereg('^[0-9]+$', $user)) ? $this->userId : $user;
				//Load the pagination model
				$this->load->model('paginationmodel');
				//Load the pagination language file
				$this->lang->load('pagination', $this->config->item('language_code'));
				$perPage = $this->paginationmodel->getPerPage('events');
				$start = (trim($this->uri->segment(4)) != '' && is_numeric($this->uri->segment(4)) && $this->uri->segment(4) > 0) ? $this->uri->segment(4) : 1;
				$start = ($start - 1) * $perPage;
				$searchText = ($this->input->post('searchtext') == false) ? '' : $this->input->post('searchtext');
				$eventsResult = $this->eventsModel->getUserEvents($user, $searchText, true, $start, $perPage);
				foreach ($eventsResult as $key => $valArr)
				{
						$eventsResult[$key]['memberscount'] = count($this->eventsModel->geteventMembers($valArr['event_id'], 'attending'));
						$eventsResult[$key]['event_image'] = $this->eventsModel->geteventImage($valArr['event_id'], true);
				}
				$data['eventsresult'] = $eventsResult;
				$data['resultcount'] = count($eventsResult);
				$data['resultTotal'] = $this->eventsModel->getUserEventsCount($user, $searchText, true);
				$data['currentPage'] = (trim($this->uri->segment(4)) != '' && is_numeric($this->uri->segment(4))) ? $this->uri->segment(4) : 1;
				$data['totalPages'] = ($data['resultTotal'] > $perPage) ? ceil(($data['resultTotal'] / $perPage)) : 0;
				$data['pageUrl'] = base_url() . 'events/home/' . $user . '/';
				$this->smartyextended->view('events', $data);
		}
		function leave()
		{
				$eventId = $this->input->post('event_id');
				$receiverId = $this->userId;
				$data = array();
				$data['message'] = '';
				if ($eventId != false && $receiverId != false)
				{
						$this->eventsModel->leaveevent($eventId, $receiverId);
						$isadmin = $this->eventsModel->isAdmin($eventId, $receiverId);
						if ($isadmin == 1) $this->eventsModel->removeevent($eventId);
						$data['message'] = $this->lang->line('events_msg_remove_success');
				}
				echo json_encode($data);
		}
		function past($user = '')
		{
				$data = array();
				$user = (!ereg('^[0-9]+$', $user)) ? $this->userId : $user;
				//Load the pagination model
				$this->load->model('paginationmodel');
				//Load the pagination language file
				$this->lang->load('pagination', $this->config->item('language_code'));
				$perPage = $this->paginationmodel->getPerPage('events');
				$start = (trim($this->uri->segment(4)) != '' && is_numeric($this->uri->segment(4)) && $this->uri->segment(4) > 0) ? $this->uri->segment(4) : 1;
				$start = ($start - 1) * $perPage;
				$upComingFlag = false;
				$searchText = ($this->input->post('searchtext') == false) ? '' : $this->input->post('searchtext');
				$eventsResult = $this->eventsModel->getUserEvents($user, $searchText, $upComingFlag, $start, $perPage);
				foreach ($eventsResult as $key => $valArr)
				{
						$eventsResult[$key]['memberscount'] = count($this->eventsModel->geteventMembers($valArr['event_id'], 'attending'));
						$eventsResult[$key]['event_image'] = $this->eventsModel->geteventImage($valArr['event_id'], true);
				}
				$data['eventsresult'] = $eventsResult;
				$data['resultcount'] = count($eventsResult);
				$data['resultTotal'] = $this->eventsModel->getUserEventsCount($user, $searchText, $upComingFlag);
				$data['currentPage'] = (trim($this->uri->segment(4)) != '' && is_numeric($this->uri->segment(4))) ? $this->uri->segment(4) : 1;
				$data['totalPages'] = ($data['resultTotal'] > $perPage) ? ceil(($data['resultTotal'] / $perPage)) : 0;
				$data['pageUrl'] = base_url() . 'events/past/' . $user . '/';
				$this->smartyextended->view('events_past', $data);
		}
		function friends($user = '')
		{
				$data = array();
				$user = (!ereg('^[0-9]+$', $user)) ? $this->userId : $user;
				$this->load->model('friendsmodel');
				$friends = $this->friendsmodel->getFriends($user);
				$friendsCount = count($friends);
				$eventsResult = array();
				if ($friendsCount > 0)
				{
						//Load the pagination model
						$this->load->model('paginationmodel');
						//Load the pagination language file
						$this->lang->load('pagination', $this->config->item('language_code'));
						$perPage = $this->paginationmodel->getPerPage('events');
						$start = (trim($this->uri->segment(4)) != '' && is_numeric($this->uri->segment(4)) && $this->uri->segment(4) > 0) ? $this->uri->segment(4) : 1;
						$start = ($start - 1) * $perPage;
						$upComingFlag = true;
						$friendsIds = implode(',', $friends);
						$searchText = ($this->input->post('searchtext') == false) ? '' : $this->input->post('searchtext');
						$eventsResult = $this->eventsModel->getUserEvents($friendsIds, $searchText, $upComingFlag, $start, $perPage);
						foreach ($eventsResult as $key => $valArr)
						{
								$eventsResult[$key]['memberscount'] = count($this->eventsModel->geteventMembers($valArr['event_id'], 'attending'));
								$eventsResult[$key]['event_image'] = $this->eventsModel->geteventImage($valArr['event_id'], true);
								$eventsResult[$key]['member_flag'] = $this->eventsModel->iseventMember($valArr['event_id'], $user);
						}
						$data['resultTotal'] = $this->eventsModel->getUserEventsCount($friendsIds, $searchText, $upComingFlag);
						$data['currentPage'] = (trim($this->uri->segment(4)) != '' && is_numeric($this->uri->segment(4))) ? $this->uri->segment(4) : 1;
						$data['totalPages'] = ($data['resultTotal'] > $perPage) ? ceil(($data['resultTotal'] / $perPage)) : 0;
						$data['pageUrl'] = base_url() . 'events/friends/' . $user . '/';
				}
				$data['friendscount'] = $friendsCount;
				$data['eventsresult'] = $eventsResult;
				$data['resultcount'] = count($eventsResult);
				$this->smartyextended->view('events_friends_list', $data);
		}
		function join()
		{
				$eventId = $this->input->post('event_id');
				$receiverId = $this->userId;
				$data = array();
				$data['message'] = '';
				if ($eventId != false && $receiverId != false)
				{
						$adminDetail = $this->eventsModel->geteventMembers($eventId, 'attending', 'Y');
						$adminRow = current($adminDetail);
						$adminId = $adminRow['sender_id'];
						$sender = $adminId;
						$receiver = $receiverId;
						$this->eventsModel->joinevent($eventId, $sender, $receiver);
						$data['message'] = $this->lang->line('events_msg_join_success');
				}
				echo json_encode($data);
		}
		function browse($netId = '', $catId = '', $subCatId = '', $stamp = '')
		{
				$data = array();
				$this->load->model('userModel');
				if (!ereg('^[0-9]+$', $netId))
				{
						$netId = '';
				}
				if (!ereg('^[0-9]+$', $catId))
				{
						$catId = '';
				}
				if (!ereg('^[0-9]+$', $subCatId))
				{
						$subCatId = '';
				}
				$arreventType = $this->eventsModel->geteventCategory();
				$arrNetworks = $this->userModel->networks($this->userId);
				$data['networkscount'] = count($arrNetworks);
				$data['usernetworks'] = $arrNetworks;
				if ($netId == '')
				{
						$networkId = 0;
				}
				else
				{
						$networkId = $netId;
				}
				if ($catId == '')
				{
						$catId = 0;
				}
				else
				{
						$mainCatId = $catId;
				}
				if ($subCatId == '')
				{
						$subCatId = 0;
				}
				else
				{
						$subCatId = $subCatId;
				}
				$networkId = ($this->input->post('network') == false) ? $networkId : $this->input->post('network');
				$catId = ($this->input->post('event_category') == false) ? $catId : $this->input->post('event_category');
				$subCatId = ($this->input->post('hdnSubCategory') == false) ? $subCatId : $this->input->post('hdnSubCategory');
				if ($stamp !== '')
				{
						$timestamp = $stamp;
				}
				else
				{
						$timestamp = "stamp";
						$day = $this->input->post('eventDay');
						$month = $this->input->post('eventMonth');
						$year = $this->input->post('eventYear');
						if ($day !== false && $month !== false && $year !== false)
						{
								$timestamp = mktime(0, 0, 0, $month, $day, $year);
						}
				}
				//getBrowseEventsCount($userId,$networkId = '', $catId = '', $subCatId = '', $timestamp = '')
				$this->load->model('paginationmodel');
				//Load the pagination language file
				$this->lang->load('pagination', $this->config->item('language_code'));
				$perPage = $this->paginationmodel->getPerPage('events');
				$start = (trim($this->uri->segment(7)) != '' && is_numeric($this->uri->segment(7)) && $this->uri->segment(7) > 0) ? $this->uri->segment(7) : 1;
				$start = ($start - 1) * $perPage;
				$eventResult = $this->eventsModel->getevents($this->userId, $networkId, $catId, $subCatId, $timestamp, $start, $perPage);
				if ($catId > 0) $data['sub_categories'] = $this->eventsModel->getSubcategories($catId);
				else  $data['sub_categories'] = array();
				$this->load->model('networkmodel');
				foreach ($eventResult as $key => $valArr)
				{
						$eventResult[$key]['event_image'] = $this->eventsModel->geteventImage($key, true);
						$eventResult[$key]['member_flag'] = $this->eventsModel->iseventMember($key, $this->userId);
						if ($eventResult[$key]['network_id'] > 0)
						{
								if ($this->networkmodel->isUserExist($eventResult[$key]['network_id'], $this->userId) == true) $eventResult[$key]['network_flag'] = 1;
								else  $eventResult[$key]['network_flag'] = 0;
						}
						else
						{
								$eventResult[$key]['network_flag'] = 1;
						}
				}
				$data['resultTotal'] = $this->eventsModel->getBrowseEventsCount($this->userId, $networkId, $catId, $subCatId, $timestamp);
				$data['eventsresult'] = $eventResult;
				$data['resultcounts'] = count($data['eventsresult']);
				$data['totalPages'] = ($data['resultTotal'] > $perPage) ? ceil(($data['resultTotal'] / $perPage)) : 0;
				$data['pageUrl'] = base_url() . 'events/browse/' . $networkId . '/' . $catId . '/' . $subCatId . '/' . $timestamp . '/';
				$data['currentPage'] = (trim($this->uri->segment(7)) != '' && is_numeric($this->uri->segment(7))) ? $this->uri->segment(7) : 1;
				$data['eventcat'] = $arreventType;
				$data['sub_cat_id'] = $subCatId;
				$this->smartyextended->view('events_browse', $data);
		}
		function manageevents($eventId = '', $action = 'new')
		{
				$userId = $this->userId;
				$this->load->model('userModel');
				$this->load->library('validation');
				if ($eventId !== '')
				{
						if (!ereg('^[0-9]+$', $eventId)) redirect('events/home/');
				}
				$eventCount = $this->eventsModel->getUserEventCount();
				$adminSettingsCount = $this->eventsModel->getAdminSettingsEventCount();
				/*
				$strMsg =  $this->lang->line('events_msg_creation') . ' (' . $eventCount . ') ' .  $this->lang->line('events_count_label');
				$this->session->set_flashdata('flash_msg',$strMsg);
				redirect('events/');
				*/
				if ($adminSettingsCount > 0)
				{
						if ($eventCount >= $adminSettingsCount && $action == 'new' && $eventId == '')
						{
								$strMsg = $this->lang->line('events_msg_creation') . ' (' . $eventCount . ') ' . $this->lang->line('events_count_label');
								$this->session->set_flashdata('flash_msg', $strMsg);
								redirect('events/');
						}
				}
				if ($eventId !== '')
				{
						$eventInfo = $this->eventsModel->getInfo($eventId);
						if (count($eventInfo) == 0) redirect('events/home/');
				}
				$isadmin = 0;
				if ($eventId != '') $isadmin = $this->eventsModel->isAdmin($eventId, $this->userId);
				if ($eventId !== '')
				{
						if ($isadmin != 1 && $eventId != '') redirect('events/home/');
				}
				$this->load->model('settingsModel');
				$settings = $this->settingsmodel->readSetting('admin_email, admin_name, site_name, site_title');
				$sitetitle = $settings['site_title'];
				$data = array();
				if ($eventId != '')
				{
						if ($isadmin == 1 && count($eventInfo) > 0)
						{
								$action = 'edit';
								$data['event_name'] = $eventInfo['event_name'];
								$data['event_desc'] = $eventInfo['event_description'];
								$data['event_tags'] = $eventInfo['event_tags'];
								$data['lstGroups'] = $eventInfo['event_host_group'];
								$data['event_host'] = $eventInfo['event_host'];
								$data['event_category'] = $eventInfo['event_category_id'];
								$data['event_sub_category'] = $eventInfo['event_sub_category_id'];
								$data['event_location'] = $eventInfo['event_location'];
								$data['event_email'] = $eventInfo['event_email'];
								$data['event_phone'] = $eventInfo['event_phone'];
								$data['event_street'] = $eventInfo['event_street'];
								$data['event_city'] = $eventInfo['event_city'];
								$data['event_country'] = $eventInfo['event_country'];
								$data['show_wall'] = $eventInfo['event_wall'];
								$data['show_photos'] = $eventInfo['event_photos'];
								$data['upload_access'] = $eventInfo['event_upload_permission'];
								$data['privacy_type'] = $eventInfo['event_type'];
								$data['portal_publisize'] = $eventInfo['event_publicize'];
								$data['network'] = $eventInfo['network_id'];
								$data['sub_categories'] = $this->eventsModel->getSubcategories($data['event_category']);
								$data['host_type'] = $eventInfo['host_type'];
								$data['guest_events'] = $eventInfo['event_bring_friends'];
								$data['show_guest_list'] = $eventInfo['event_show_guest'];
								$data['event_start_unix_stamp'] = $eventInfo['event_start_unix_stamp'];
								$data['event_end_unix_stamp'] = $eventInfo['event_end_unix_stamp'];
						}
						else
						{
								redirect('events/home');
						}
				}
				$arrNetworks = $this->userModel->networks($userId);
				$arreventType = $this->eventsModel->geteventCategory();
				$arrCountry = $this->eventsModel->getCountry();
				$this->_formRules();
				if ($this->validation->run() == false)
				{
						//Oops! validation Error.
						$data['validationError'] = $this->validation->error_string;
						if ($action != 'edit') $data['sub_categories'] = ($this->input->post('event_category') !== false && $this->input->post('event_category') > 0) ? $this->eventsModel->getSubcategories($this->input->post('event_category')) : array();
				}
				else
				{
						$s_day = $this->input->post('StartDay');
						$s_mon = $this->input->post('StartMonth');
						$s_year = $this->input->post('StartYear');
						$e_day = $this->input->post('EndDay');
						$e_mon = $this->input->post('EndMonth');
						$e_year = $this->input->post('EndYear');
						$s_hour = $this->input->post('StartHour');
						$s_min = $this->input->post('StartMinute');
						$e_hour = $this->input->post('EndHour');
						$e_min = $this->input->post('EndMinute');
						$s_meridian = $this->input->post('StartMeridian');
						$e_meridian = $this->input->post('EndMeridian');
						$startTimestamp = mktime($s_hour, $s_min, 0, $s_mon, $s_day, $s_year);
						$endTimestamp = mktime($e_hour, $e_min, 0, $e_mon, $e_day, $e_year);
						if ($s_meridian == 'pm') $startTimestamp = $startTimestamp + (12 * 60 * 60);
						if ($e_meridian == 'pm') $endTimestamp = $endTimestamp + (12 * 60 * 60);
						/*
						print '<br>'. $startTimestamp;
						print '<br>'. $endTimestamp;
						print '<br>';
						echo date('g:i a F M j Y',$startTimestamp);
						print '<br>';
						echo date('g:i a F M j Y',$endTimestamp);
						print '<br>';
						exit;
						*/
						$action = $this->input->post('hdnAction');
						$eventId = ($this->input->post('hdnEventId') != false) ? $this->input->post('hdnEventId') : '';
						$eventValues = array('event_name' => $this->db->escape($this->input->post('event_name')), 'network_id' => ($this->input->post('network') != false) ? $this->db->escape($this->input->post('network')) : '0', 'event_description' => $this->db->escape($this->input->post('event_desc')), 'event_category_id' => $this->db->escape($this->input->post('event_category')), 'event_sub_category_id' => $this->db->escape($this->input->post('event_sub_category')), 'event_tags' => $this->db->escape($this->input->post('event_tags')), 'event_host' => $this->db->escape($this->input->post('event_host')), 'event_host_group' => $this->db->escape($this->input->post('lstGroups')), 'event_location' => $this->db->escape($this->input->post('event_location')), 'event_start_unix_stamp' => $startTimestamp, 'event_end_unix_stamp' => $endTimestamp, 'event_email' => $this->db->escape($this->input->post('event_email')), 'event_street' => $this->db->escape($this->input->post('event_street')), 'event_city' => $this->db->
								escape($this->input->post('event_city')), 'event_country' => $this->db->escape($this->input->post('event_country')), 'event_phone' => $this->db->escape($this->input->post('event_phone')), 'event_bring_friends' => $this->db->escape(($this->input->post('guest_events') == false) ? 'no' : 'yes'), 'event_show_guest' => $this->db->escape(($this->input->post('show_guest_list') == false) ? 'no' : 'yes'), 'event_wall' => $this->db->escape(($this->input->post('show_wall') == false) ? 'no' : 'yes'), 'event_photos' => $this->db->escape(($this->input->post('show_photos') == false) ? 'no' : 'yes'), 'event_type' => $this->db->escape($this->input->post('privacy_type')), 'event_publicize' => $this->db->escape(($this->input->post('portal_publisize') == false) ? 'no' : 'yes'), 'user_id' => $this->userId, 'event_upload_permission' => ($this->input->post('upload_access') != false) ? $this->db->escape($this->input->post('upload_access')) : $this->db->escape('members'), );
						$eventId = $this->eventsModel->saveEventInfo($eventValues, $eventId, $action);
						if ($eventId > 0)
						{
								if ($action != 'edit')
								{
										$userFeedSettings = $this->userModel->getUserFeedSetting();
										if (isset($userFeedSettings[16]) && $userFeedSettings[16] == 'yes')
										{
												//Load the minifeed model
												$this->load->model('minifeedmodel');
												$splVars = array('~~postedBy~~' => $this->session->userdata('username'), '~~eventName~~' => $this->input->post('event_name'));
												$this->minifeedmodel->postMiniFeed('CREATE_EVENT', $splVars, array(base_url() . 'events/view/' . $eventId . '/'));
										}
								}
								$outputData = array();
								$outputData['eventimage'] = $this->eventsModel->geteventImage($eventId);
								$outputData['event_id'] = $eventId;
								if ($action != 'edit') $outputData['successmsg'] = $this->lang->line('events_msg_event_create_success');
								else  $outputData['successmsg'] = $this->lang->line('events_msg_event_save_success');
								$this->smartyextended->view('events_picture', $outputData);
								exit;
						}
						else
						{
								$data['validationError'] = $this->lang->line('events_msg_event_save_fail');
						}
				}
				$year = date('Y', time());
				$data['usergroups'] = $this->eventsModel->userGroups($this->userId);
				$data['timestampval1'] = strtotime("now");
				$data['timestampval2'] = strtotime("+3 hours");
				$data['startyear'] = $year;
				$data['endyear'] = $year++;
				$data['action'] = $action;
				$data['event_id'] = $eventId;
				$data['networkscount'] = count($arrNetworks);
				$data['arrCountry'] = $arrCountry;
				$data['eventcat'] = $arreventType;
				$data['usernetworks'] = $arrNetworks;
				$data['sitetitle'] = $sitetitle;
				if ($adminSettingsCount > 0) $data['eventadminmsg'] = $this->lang->line('events_msg_max') . ' (' . $adminSettingsCount . ') ' . $this->lang->line('events_count_label');
				$this->smartyextended->view('manageevents', $data);
		}
		function addmembers()
		{
				$userid = $this->input->post('userid');
				$eventId = $this->input->post('event_id');
				if ($userid !== false && $eventId !== false)
				{
						$res = $this->eventsModel->addMembers($eventId, $userid, $this->userId);
						$eventFriends = $this->eventsModel->getFriendsInvitees($eventId, $this->userId);
						$data['eventsfriends'] = $eventFriends;
						$data['friendscount'] = count($eventFriends);
						$data['event_id'] = $eventId;
						$data['errmsg'] = '';
						$data['content'] = $this->smartyextended->view('events_friends', $data, true);
						$data['invitees'] = $this->eventsModel->getMembers($eventId);
						$data['inviteescount'] = count($data['invitees']);
						$data['event_id'] = $eventId;
						$data['inviteids'] = implode(',', array_keys($data['invitees']));
						$data['invitationcontent'] = $this->smartyextended->view('events_invitation', $data, true);
						echo json_encode($data);
				}
				else
				{
						echo json_encode('none');
				}
		}
		function blockmember()
		{
				$userId = $this->input->post('user_id');
				$eventId = $this->input->post('event_id');
				$status = $this->input->post('status');
				$this->eventsModel->blockeventMember($userId, $eventId);
				$eventFriends = $this->eventsModel->getFriendsInvitees($eventId, $this->userId);
				$data['eventsfriends'] = $eventFriends;
				$data['friendscount'] = count($eventFriends);
				$data['event_id'] = $eventId;
				$data['errmsg'] = '';
				$data['invitees'] = $this->eventsModel->getMembers($eventId);
				$data['inviteids'] = implode(',', array_keys($data['invitees']));
				$data['content'] = $this->smartyextended->view('events_friends', $data, true);
				if ($status == 'sent') $data['members'] = $this->eventsModel->getMembers($eventId, $status);
				else  $data['members'] = $this->eventsModel->geteventMembers($eventId, $status);
				//$data['members']		=	$this->eventsModel->getMembers($eventId);
				$data['status'] = ($this->input->post('status') == false) ? 'accepted' : $this->input->post('status');
				$data['membercount'] = count($data['members']);
				$data['memlist'] = $this->smartyextended->view('events_memlist', $data, true);
				echo json_encode($data);
		}
		function removemember()
		{
				$userId = $this->input->post('user_id');
				$eventId = $this->input->post('event_id');
				$status = $this->input->post('status');
				if ($status == 'sent')
				{
						$this->eventsModel->removeInvitation($userId, $eventId);
				}
				else
				{
						if ($status == 'attending' || $status == 'blocked') $this->eventsModel->removeeventMember($userId, $eventId);
				}
				$eventFriends = $this->eventsModel->getFriendsInvitees($eventId, $this->userId);
				$data['eventsfriends'] = $eventFriends;
				$data['friendscount'] = count($eventFriends);
				$data['event_id'] = $eventId;
				$data['errmsg'] = '';
				$data['invitees'] = $this->eventsModel->getMembers($eventId);
				$data['inviteids'] = implode(',', array_keys($data['invitees']));
				$data['content'] = $this->smartyextended->view('events_friends', $data, true);
				if ($status == 'sent') $data['members'] = $this->eventsModel->getMembers($eventId, $status);
				else  $data['members'] = $this->eventsModel->geteventMembers($eventId, $status);
				//$data['members']		=	$this->eventsModel->getMembers($eventId);
				$data['status'] = ($this->input->post('status') == false) ? 'accepted' : $this->input->post('status');
				$data['membercount'] = count($data['members']);
				$data['memlist'] = $this->smartyextended->view('events_memlist', $data, true);
				echo json_encode($data);
		}
		function unblockmember()
		{
				$userId = $this->input->post('user_id');
				$eventId = $this->input->post('event_id');
				$status = $this->input->post('status');
				$this->eventsModel->unblockeventMember($userId, $eventId);
				$eventFriends = $this->eventsModel->getFriendsInvitees($eventId, $this->userId);
				$data['eventsfriends'] = $eventFriends;
				$data['friendscount'] = count($eventFriends);
				$data['event_id'] = $eventId;
				$data['errmsg'] = '';
				$data['invitees'] = $this->eventsModel->getMembers($eventId);
				$data['inviteids'] = implode(',', array_keys($data['invitees']));
				$data['content'] = $this->smartyextended->view('events_friends', $data, true);
				if ($status == 'sent') $data['members'] = $this->eventsModel->getMembers($eventId, $status);
				else  $data['members'] = $this->eventsModel->geteventMembers($eventId, $status);
				//$data['members']		=	$this->eventsModel->getMembers($eventId);
				$data['status'] = ($this->input->post('status') == false) ? 'accepted' : $this->input->post('status');
				$data['membercount'] = count($data['members']);
				$data['memlist'] = $this->smartyextended->view('events_memlist', $data, true);
				echo json_encode($data);
		}
		function invite()
		{
				$ids = $this->input->post('ids');
				$eventId = $this->input->post('event_id');
				$message = $this->input->post('message');
				$msg = '';
				if ($ids !== false && $eventId !== false && $message !== false)
				{
						if ($message != '')
						{
								$usernames = $this->sendInvitations($ids, $eventId, $message);
								$msg = $this->lang->line('events_msg_invite_sent_people');
								$msg = $msg . $usernames;
						}
				}
				$data['event_id'] = $eventId;
				$data['errmsg'] = $msg;
				$data['invitees'] = $this->eventsModel->getMembers($eventId);
				$data['inviteescount'] = count($data['invitees']);
				$data['inviteids'] = implode(',', array_keys($data['invitees']));
				$data['content'] = $this->smartyextended->view('events_invitation', $data, true);
				echo json_encode($data);
		}
		function sendInvitations($ids, $eventId, $message = '')
		{
				$this->load->model('userModel');
				$this->eventsModel->updateInvitations($ids, $eventId, 'sent', $message);
				$userdetail = $this->eventsModel->getReceiverDetails($ids);
				// Here we need to write email code to send event invitation
				$username = '';
				foreach ($userdetail as $key => $valArr)
				{
						$uname = $valArr['username'];
						if ($valArr['username'] == '')
						{
								$uname = $valArr['receiver_email'];
						}
						$username .= '<br>' . $uname;
						// Here mail code need to be implemented
						$userDetails = array();
						$userDetails['inv_id'] = $valArr['event_invitation_id'];
						$userDetails['name'] = $username;
						$userDetails['user_id'] = $valArr['user_id'];
						$userDetails['email'] = ($valArr['username'] !== '') ? $valArr['email'] : $valArr['receiver_email'];
						$userDetails['type'] = ($valArr['username'] !== '') ? 'member' : 'non_member';
						$this->_sendNotification($userDetails, $eventId, $message);
						//
				}
				return $username;
		}
		function _sendNotification($userDetail, $eventId, $message = '')
		{
				$this->load->model('settingsModel');
				$this->load->model('emailTemplateModel');
				$this->load->library('email');
				$this->load->model('userModel');
				$this->load->model('messageModel');
				$emailTemplate = $this->emailTemplateModel->readEmailTemplate('event_invitation');
				$settings = $this->settingsmodel->readSetting('admin_email, admin_name, site_name, site_title');
				$adminEmail = $settings['admin_email'];
				$adminName = $settings['admin_name'];
				$eventInfo = $this->eventsModel->geteventInfo($eventId);
				$eventName = $eventInfo['event_name'];
				$attachUrl = base_url() . 'events/view/' . $eventId . '/' . $userDetail['inv_id'] . '/';
				$splVars = array("~~senderName~~" => ucfirst($this->session->userdata('username')), "~~eventName~~" => $eventName, "~~message~~" => ($message == '') ? 'This is a request to you join this event.. ' : $message, "~~siteName~~" => $settings['site_title'], "~~attachURL~~" => $attachUrl, "~~adminEmail~~" => $adminEmail, "~~adminName~~" => $adminName);
				$subject = strtr($emailTemplate['template_subject'], $splVars);
				$message = strtr($emailTemplate['template_content'], $splVars);
				$email = $userDetail['email'];
				$notificationStaus = 1;
				if ($userDetail['type'] == 'member')
				{
						$msgConfig['to_id'] = $userDetail['user_id'];
						$msgConfig['subject'] = $subject;
						$msgConfig['message'] = $message;
						$this->messageModel->sendMessage($msgConfig);
						$arrNotifications = $this->userModel->getUserNotifications($userDetail['user_id'], $this->notificationId);
						if (count($arrNotifications) > 0)
						{
								$notificationStaus = $arrNotifications[$this->notificationId];
						}
				}
				if ($notificationStaus == 0)
				{
						return;
				}
				$this->email->from($adminEmail, $adminName);
				$this->email->to($email);
				$this->email->subject($subject);
				$this->email->message(nl2br($message));
				$this->email->send();
		}
		function removeInvitation()
		{
				$userId = $this->input->post('user_id');
				$eventId = $this->input->post('event_id');
				$invitationId = $this->input->post('invitation_id');
				$this->eventsModel->removeInvitation($userId, $eventId, $invitationId);
				// For Invitaion List
				$data['invitees'] = $this->eventsModel->getMembers($eventId);
				$data['inviteescount'] = count($data['invitees']);
				$data['inviteids'] = implode(',', array_keys($data['invitees']));
				// For Friends List
				$eventFriends = $this->eventsModel->getFriendsInvitees($eventId, $this->userId);
				$data['eventsfriends'] = $eventFriends;
				$data['friendscount'] = count($eventFriends);
				$data['errmsg'] = '';
				$data['event_id'] = $eventId;
				$data['content'] = $this->smartyextended->view('events_invitation', $data, true);
				$data['friendslist'] = $this->smartyextended->view('events_friends', $data, true);
				echo json_encode($data);
		}
		function addedMembers()
		{
				$eventId = $this->input->post('event_id');
				$data['invitees'] = $this->eventsModel->getMembers($eventId);
				$data['inviteescount'] = count($data['invitees']);
				$data['event_id'] = $eventId;
				$data['inviteids'] = implode(',', array_keys($data['invitees']));
				$data['content'] = $this->smartyextended->view('events_invitation', $data, true);
				echo json_encode($data);
		}
		function viewmembers($eventId)
		{
				if (!ereg('^[0-9]+$', $eventId)) redirect('events/home/');
				//geteventMembers($eventId, $status = '',$adminFlag = '', $start = '', $limit = '')
				//Load the pagination model
				$this->load->model('paginationmodel');
				//Load the pagination language file
				$this->lang->load('pagination', $this->config->item('language_code'));
				$perPage = $this->paginationmodel->getPerPage('events');
				$start = (trim($this->uri->segment(6)) != '' && is_numeric($this->uri->segment(6)) && $this->uri->segment(6) > 0) ? $this->uri->segment(6) : 1;
				$start = ($start - 1) * $perPage;
				$status = 'attending';
				$adminFlag = 'no';
				$eventMembers = $this->eventsModel->geteventMembers($eventId, $status, $adminFlag, $start, $perPage);
				if (count($eventMembers) > 0)
				{
						$this->load->model('networkmodel');
						$this->load->model('usermodel');
						$eventInfo = $this->eventsModel->getInfo($eventId);
						$eventName = '';
						if (count($eventInfo) > 0)
						{
								$eventName = $eventInfo['event_name'];
						}
						else
						{
								redirect('events/home/');
						}
						foreach ($eventMembers as $key => $valArr)
						{
								$result = $this->networkmodel->getUserNetwork($valArr['receiver_id'], 'region');
								if (count($result) > 0)
								{
										$result = current($result);
										$network = $result['network_name'];
								}
								else  $network = 'No network';
								$eventMembers[$key]['network'] = $network;
								$eventMembers[$key]['avatar'] = $this->usermodel->getAvatar($valArr['receiver_id'], true);
						}
				}
				$data['resultTotal'] = $this->eventsModel->geteventMembersCount($eventId, $status, $adminFlag);
				$data['currentPage'] = (trim($this->uri->segment(6)) != '' && is_numeric($this->uri->segment(6))) ? $this->uri->segment(6) : 1;
				$data['totalPages'] = ($data['resultTotal'] > $perPage) ? ceil(($data['resultTotal'] / $perPage)) : 0;
				$data['pageUrl'] = base_url() . 'events/viewmembers/' . $eventId . '/' . $status . '/' . $adminFlag . '/';
				$data['members_list_count'] = count($eventMembers);
				$data['eventMembers'] = $eventMembers;
				$data['event_name'] = $eventName;
				$data['event_id'] = $eventId;
				$this->smartyextended->view('events_list_members', $data);
		}
		function view($eventId, $invid = '')
		{
				if ($eventId == '') redirect('events/home');
				if (!ereg('^[0-9]+$', $eventId)) redirect('events/home');
				$data = array();
				$data['invitation_id'] = '';
				$eventInfo = $this->eventsModel->getInfo($eventId);
				if (count($eventInfo) == 0)
				{
						redirect('events/home/');
				}
				$isadmin = $this->eventsModel->isAdmin($eventId, $this->userId);
				$isMember = $this->eventsModel->iseventMember($eventId, $this->userId);
				/*
				if($eventInfo['event_type'] != 'open')
				{
				if($isadmin == 0 && $isMember == 0)
				{
				redirect('events/home');
				}
				}
				*/
				if ($isadmin == 0 && $isMember == 0)
				{
						if ((integer)$eventInfo['network_id'] > 0)
						{
								$this->load->model('networkmodel');
								if (!$this->networkmodel->isUserExist($eventInfo['network_id'], $this->userId)) redirect('events/home/');
						}
				}
				if (count($eventInfo) == 0) redirect('events/home');
				$currentstamp = time();
				$timeflag = 0;
				/*
				if($currentstamp < $eventInfo['event_start_unix_stamp'])
				{
				$timeflag = 1;
				}
				*/
				if (($currentstamp <= $eventInfo['event_start_unix_stamp']) || $currentstamp >= $eventInfo['event_start_unix_stamp'] && $currentstamp <= $eventInfo['event_end_unix_stamp'])
				{
						$timeflag = 1;
				}
				// To find past or upcoming event
				$eventInfo['time_flag'] = $timeflag;
				/*
				echo '<br><br>Current : ' . $currentstamp;
				echo '<br><br>Start : ' . $eventInfo['event_start_unix_stamp'];
				echo '<br><br>End : ' . $eventInfo['event_end_unix_stamp'];
				*/
				$this->load->model('userModel');
				$eventMembers = $this->eventsModel->geteventMembers($eventId);
				$eventAdminId = $this->eventsModel->getAdmin($eventId);
				$isadmin = $this->eventsModel->isAdmin($eventId, $this->userId);
				$isMember = $this->eventsModel->iseventMember($eventId, $this->userId);
				if ($isadmin != 1 && $isMember != 1)
				{
						if ($invid != '')
						{
								if (!ereg('^[0-9]+$', $invid))
								{
										redirect('events/home');
								}
								else
								{
										$invtationInfo = $this->eventsModel->getInvitationInfo($eventId, $this->userId, $invid);
										if (!$invtationInfo && $eventInfo['event_type'] != 'open') redirect('events/home');
										if ($invtationInfo)
										{
												$data['invitation_id'] = $invtationInfo['event_invitation_id'];
												$data['sender_id'] = $invtationInfo['sender_id'];
												$data['receiver_id'] = $invtationInfo['receiver_id'];
										}
										else
										{
												$data['invitation_id'] = '';
												$data['sender_id'] = ($eventAdminId === false) ? '' : $eventAdminId;
												$data['receiver_id'] = $this->userId;
										}
								}
						}
						else
						{
								$invtationInfo = $this->eventsModel->getInvitationInfo($eventId, $this->userId);
								if ($invtationInfo)
								{
										$data['invitation_id'] = $invtationInfo['event_invitation_id'];
										$data['sender_id'] = $invtationInfo['sender_id'];
										$data['receiver_id'] = $invtationInfo['receiver_id'];
								}
						}
				}
				if ($eventInfo['event_type'] == 'secret')
				{
						if ($isadmin == 0 && $isMember == 0 && trim($data['invitation_id']) == '')
						{
								redirect('events/home/');
						}
				}
				//$action 	= 	$this->input->post('hdnAction');
				$action = '';
				$leave = $this->input->post('leaveBtn_x');
				$join = $this->input->post('joinBtn_x');
				if ($leave !== false)
				{
						$action = 'leave';
				} elseif ($join !== false)
				{
						$action = 'join';
				}
				$eventType = $this->input->post('hdnType');
				if ($action !== '' && $eventType != false)
				{
						if ($eventType == 'open')
						{
								if ($action == 'join')
								{
										$invid = $this->input->post('hdnInvId');
										$sender = ($this->input->post('hdnSender') == '' or $this->input->post('hdnSender') == false) ? $eventAdminId : $this->input->post('hdnSender');
										$receiver = ($this->input->post('hdnReceiver') == '' or $this->input->post('hdnReceiver') == false) ? $this->userId : $this->input->post('hdnReceiver');
										$this->eventsModel->removeInvitation($receiver, $eventId);
										$this->eventsModel->joinevent($eventId, $sender, $receiver);
								} elseif ($action == 'leave')
								{
										$this->eventsModel->leaveevent($eventId, $this->userId);
										if ($isadmin == 1)
										{
												$this->eventsModel->removeevent($eventId);
												redirect('events/home');
										}
								}
						} elseif ($eventType == 'closed')
						{
								if ($action == 'join')
								{
										$sender = ($this->input->post('hdnSender') == '' or $this->input->post('hdnSender') == false) ? $eventAdminId : $this->input->post('hdnSender');
										$receiver = ($this->input->post('hdnReceiver') == '' or $this->input->post('hdnReceiver') == false) ? $this->userId : $this->input->post('hdnReceiver');
										$invid = $this->input->post('hdnInvId');
										$this->eventsModel->addMembers($eventId, $receiver, $sender, 'requested');
										$this->session->set_flashdata('flash_msg', $this->lang->line('events_closed_request_msg_success'));
								} elseif ($action == 'leave')
								{
										$this->eventsModel->leaveevent($eventId, $this->userId);
										if ($isadmin == 1)
										{
												$this->eventsModel->removeevent($eventId);
												redirect('events/home');
										}
								}
						} elseif ($eventType == 'secret')
						{
								if ($action == 'join')
								{
										$sender = ($this->input->post('hdnSender') == '' or $this->input->post('hdnSender') == false) ? $eventAdminId : $this->input->post('hdnSender');
										$receiver = ($this->input->post('hdnReceiver') == '' or $this->input->post('hdnReceiver') == false) ? $this->userId : $this->input->post('hdnReceiver');
										$invid = $this->input->post('hdnInvId');
										$this->eventsModel->addMembers($eventId, $receiver, $sender, 'requested');
								} elseif ($action == 'leave')
								{
										$this->eventsModel->leaveevent($eventId, $this->userId);
										if ($isadmin == 1)
										{
												$this->eventsModel->removeevent($eventId);
												redirect('events/home');
										}
								}
						}
						redirect('events/view/' . $eventId . '/');
				}
				foreach ($eventMembers as $id => $userArray)
				{
						$eventMembers[$id]['avatar'] = $this->userModel->getAvatar($userArray['receiver_id'], true);
				}
				// Requested users List
				$requestedMembers = array();
				$requestcount = 0;
				if (($eventInfo['event_type'] == 'closed' || $eventInfo['event_type'] == 'secret') && $isadmin == 1)
				{
						$requestedMembers = $this->eventsModel->getRequests($eventId);
						$requestcount = count($requestedMembers);
				}
				// For RSVP
				$rsvpDetail = $this->eventsModel->getEventMemberStaus($eventId, $this->userId);
				$data['time_flag'] = $eventInfo['time_flag'];
				$data['closedrequest'] = $requestedMembers;
				$data['requestcount'] = $requestcount;
				$data['eventinfo'] = $eventInfo;
				$data['members'] = $eventMembers;
				$data['memberscount'] = count($eventMembers);
				$data['isadmin'] = $isadmin;
				$data['ismember'] = $isMember;
				$data['event_id'] = $eventId;
				$data['event_image'] = $this->eventsModel->geteventImage($eventId);
				$data['event_type'] = $eventInfo['event_type'];
				$data['rsvpinfo'] = $rsvpDetail;
				$data['rsvp'] = $this->smartyextended->view('events_rsvp', $data, true);
				$this->load->model('wallmodel');
				//For wall
				$data['wall'] = $this->wallmodel->getWall('event', $eventId, 'wall_date desc', 0, 10);
				$data['wallCount'] = count($data['wall']);
				$data['wallTotal'] = count($this->wallmodel->getWall('event', $eventId));
				$this->smartyextended->view('events_view', $data);
		}
		function saversvp()
		{
				//'event_id='+eventid+'&status='+status,
				$eventId = $this->input->post('event_id');
				$status = $this->input->post('status');
				$data = array();
				$resultArr = array();
				$resultArr['result'] = 'none';
				if ($eventId != false && $status != false)
				{
						$eventInfo = $this->eventsModel->getInfo($eventId);
						$currentstamp = time();
						$timeflag = 0;
						if (($currentstamp < $eventInfo['event_start_unix_stamp']) || ($currentstamp >= $eventInfo['event_start_unix_stamp'] && $currentstamp <= $eventInfo['event_end_unix_stamp']))
						{
								$timeflag = 1;
						}
						// To find past or upcoming event
						$data['time_flag'] = $timeflag;
						$receiver = $this->userId;
						$this->eventsModel->saveRSVP($eventId, $receiver, $status);
						$rsvpDetail = $this->eventsModel->getEventMemberStaus($eventId, $receiver);
						$data['result'] = $this->lang->line('events_rsvp_save_success');
						$data['rsvpinfo'] = $rsvpDetail;
						$resultArr['result'] = $this->lang->line('events_rsvp_save_success');
						$resultArr['content'] = $this->smartyextended->view('events_rsvp', $data, true);
				}
				echo json_encode($resultArr);
		}
		function requests($eventId)
		{
				if (!ereg('^[0-9]+$', $eventId)) redirect('events/home/');
				$data = array();
				$eventInfo = $this->eventsModel->geteventInfo($eventId);
				if (count($eventInfo) == 0) redirect('events/home/');
				if ($eventInfo['event_flag'] == 'past') redirect('events/home/');
				$isadmin = $this->eventsModel->isAdmin($eventId, $this->userId);
				if ($isadmin == 0) redirect('events/home/');
				$action = $this->input->post('hdnAction');
				if ($action !== false)
				{
						$receiver = $this->input->post('hdnId');
						$requests = $this->eventsModel->getRequests($eventId);
						$sender = $this->userId;
						if ($action == 'approve')
						{
								if ($receiver == 'all')
								{
										foreach ($requests as $key => $valarr)
										{
												if (intval($valarr['receiver_id']) != 0)
												{
														$this->eventsModel->joinevent($eventId, $sender, $valarr['receiver_id']);
														$this->eventsModel->removeInvitation($valarr['receiver_id'], $eventId);
												}
										}
								}
								else
								{
										$this->eventsModel->joinevent($eventId, $sender, $receiver);
										$this->eventsModel->removeInvitation($receiver, $eventId);
										$this->session->set_flashdata('flash_msg', $this->lang->line('events_msg_approve_success'));
								}
						}
						else
						{
								if ($receiver == 'all')
								{
										$this->eventsModel->removeAllInvitations($eventId);
								}
								else
								{
										$this->eventsModel->removeInvitation($receiver, $eventId);
										$this->session->set_flashdata('flash_msg', $this->lang->line('events_msg_reject_success'));
								}
						}
				}
				$this->load->model('paginationmodel');
				//Load the pagination language file
				$this->lang->load('pagination', $this->config->item('language_code'));
				$perPage = $this->paginationmodel->getPerPage('events');
				$start = (trim($this->uri->segment(4)) != '' && is_numeric($this->uri->segment(4)) && $this->uri->segment(4) > 0) ? $this->uri->segment(4) : 1;
				$start = ($start - 1) * $perPage;
				$requestedMembers = $this->eventsModel->getRequests($eventId, 'requested', $start, $perPage);
				$this->load->model('usermodel');
				foreach ($requestedMembers as $key => $valArr)
				{
						$requestedMembers[$key]['avatar'] = $this->usermodel->getAvatar($valArr['receiver_id'], true);
				}
				$requestcount = count($requestedMembers);
				if ($requestcount > 0)
				{
						$data['resultTotal'] = $this->eventsModel->getRequestsCount($eventId, 'requested');
						$data['currentPage'] = (trim($this->uri->segment(4)) != '' && is_numeric($this->uri->segment(4))) ? $this->uri->segment(4) : 1;
						$data['totalPages'] = ($data['resultTotal'] > $perPage) ? ceil(($data['resultTotal'] / $perPage)) : 0;
						$data['pageUrl'] = base_url() . 'events/requests/' . $eventId . '/';
				}
				$data['event_name'] = $eventInfo['event_name'];
				$data['event_id'] = $eventId;
				$data['event_type'] = $eventInfo['event_type'];
				$data['closedrequest'] = $requestedMembers;
				$data['requestcount'] = $requestcount;
				$this->smartyextended->view('events_requests', $data);
		}
		function members($eventId = '')
		{
				$this->load->model('userModel');
				$eventInfo = $this->eventsModel->geteventInfo($eventId);
				if (count($eventInfo) == 0) redirect('events/manageevents/');
				$isadmin = $this->eventsModel->isAdmin($eventId, $this->userId);
				if ($eventInfo['event_type'] !== 'open')
				{
						if ($isadmin !== 1) redirect('events/manageevents/');
				}
				else
				{
						$isMember = $this->eventsModel->iseventMember($eventId, $this->userId);
						if ($isMember == 0) redirect('events/manageevents/');
				}
				// Inviting peoples with mail ids who may be registered or non registered - Begin
				$invalidMails = array();
				$validMails = array();
				$email = $this->input->post('mails');
				if ($email != false && $email != '')
				{
						$emailArr = split(',', $email);
						$this->load->helper('validation');
						$this->load->model('userModel');
						foreach ($emailArr as $key => $mail)
						{
								if (isValidEmail($mail))
								{
										$mailResult = $this->userModel->chkUserEmail(trim($mail));
										if ($mailResult)
										{
												$validMails[] = array('registered' => 1, 'user_id' => $mailResult['user_id'], 'name' => $mailResult['username'], 'email' => $mail, 'flag' => 0);
										}
										else
										{
												$validMails[] = array('registered' => 0, 'name' => $mail, 'email' => $mail, 'flag' => 0);
										}
								}
								else
								{
										$invalidMails[] = $mail;
								}
						}
						if (count($validMails) > 0)
						{
								foreach ($validMails as $key => $valArr)
								{
										if ($valArr['registered'] == 1)
										{
												$receiver = $valArr['user_id'];
												$sender = $this->userId;
												$receiveremail = $valArr['email'];
												$isMember = $this->eventsModel->iseventMember($eventId, $receiver);
												//$validMails[$key]['flag']	= 	($isMember == 0) ? $this->eventsModel->addMembers($eventId,$receiver,$sender,'requested',TRUE,$receiveremail) : 2 ;
												$validMails[$key]['flag'] = ($isMember == 0) ? $this->eventsModel->addMembers($eventId, $receiver, $sender, 'not sent', true, $receiveremail) : 2;
										}
										else
										{
												$receiver = 0;
												$sender = $this->userId;
												$receiveremail = $valArr['email'];
												//$validMails[$key]['flag']	=	$this->eventsModel->addMembers($eventId,$receiver,$sender,'requested',FALSE,$receiveremail);
												$validMails[$key]['flag'] = $this->eventsModel->addMembers($eventId, $receiver, $sender, 'not sent', false, $receiveremail);
										}
								}
						}
				}
				// End
				$data = array();
				$data['isadmin'] = $isadmin;
				$eventFriends = $this->eventsModel->getFriendsInvitees($eventId, $this->userId);
				$data['eventsfriends'] = $eventFriends;
				$data['friendscount'] = count($eventFriends);
				$data['event_id'] = $eventId;
				$data['status'] = ($this->input->post('hdnStatus') == false) ? 'attending' : $this->input->post('hdnStatus');
				$data['errmsg'] = '';
				$data['invitees'] = $this->eventsModel->getMembers($eventId);
				$data['inviteescount'] = count($data['invitees']);
				$data['inviteids'] = implode(',', array_keys($data['invitees']));
				$statusFilter = ($this->input->post('viewfilter') != false && $this->input->post('viewfilter') !== '') ? $this->input->post('viewfilter') : 'attending';
				if ($statusFilter == 'sent') $data['members'] = $this->eventsModel->getMembers($eventId, $statusFilter);
				else  $data['members'] = $this->eventsModel->geteventMembers($eventId, $statusFilter);
				$data['friendslist'] = $this->smartyextended->view('events_friends', $data, true);
				$data['content'] = $this->smartyextended->view('events_invitation', $data, true);
				$data['membercount'] = count($data['members']);
				$data['memlist'] = $this->smartyextended->view('events_memlist', $data, true);
				$data['invalidmails'] = $invalidMails;
				$data['validmails'] = $validMails;
				$this->smartyextended->view('events_members', $data);
		}
		function removephoto($eventId)
		{
				if (ereg('^[0-9]+$', $eventId))
				{
						$eventInfo = $this->eventsModel->geteventInfo($eventId);
						if (count($eventInfo) == 0) redirect('events/picture/' . $eventId . '/');
						$eventPath = APPPATH . 'content/events/' . $eventId . '.' . $eventInfo['event_photo_path'];
						@unlink($eventPath);
						$eventThumbPath = APPPATH . 'content/events/' . $eventId . '_thumb.' . $eventInfo['event_photo_path'];
						@unlink($eventThumbPath);
						$this->eventsModel->storePhotos($eventId, '');
						redirect('events/picture/' . $eventId . '/');
				}
				else
				{
						redirect('events/picture/' . $eventId . '/');
				}
		}
		function picture($eventId = '')
		{
				$data = array();
				$this->load->library('validation');
				$this->_photoRules();
				$msg = '';
				if (!ereg('^[0-9]+$', $eventId)) redirect('events/manageevents/');
				if ($this->validation->run() == false)
				{
						//Oops! validation Error.
						$data['validationError'] = $this->validation->error_string;
				}
				else
				{
						if ($_FILES)
						{
								$msg = $this->storePhotos($eventId);
						}
						if ($msg !== '')
						{
								$outputData = array();
								$outputData['validationError'] = $msg;
								$outputData['event_id'] = $eventId;
								$outputData['eventimage'] = $this->eventsModel->geteventImage($eventId);
								$this->smartyextended->view('events_picture', $outputData);
								exit;
								//redirect('events/members/'.$eventId.'/');
								//exit;
						}
						else
						{
								$this->session->set_flashdata('flash_msg', $this->lang->line('events_upload_picture_sucess'));
								redirect('events/members/' . $eventId . '/');
								exit;
						}
				}
				if ($eventId != '' && ereg('^[0-9]+$', $eventId))
				{
						$eventInfo = $this->eventsModel->geteventInfo($eventId);
						if (count($eventInfo) == 0)
						{
								redirect('events/manageevents/');
						}
						else
						{
								$isadmin = $this->eventsModel->isAdmin($eventId, $this->userId);
								if ($isadmin == 1) $data['eventimage'] = $this->eventsModel->geteventImage($eventId);
								else  redirect('events/manageevents/');
						}
				}
				if (trim($eventId) == '') $data['eventimage'] = $this->eventsmodel->geteventImage(0);
				$data['event_id'] = $eventId;
				$data['successmsg'] = $msg;
				$this->smartyextended->view('events_picture', $data);
		}
		function _resizeImage($imgFile, $width, $height)
		{
				$this->load->library('image_lib');
				//$config['image_library'] 	= 'GD2';
				$config['source_image'] = $imgFile;
				$config['create_thumb'] = true;
				$config['maintain_ratio'] = true;
				$config['width'] = $width;
				$config['height'] = $height;
				$config['allowed_types'] = 'jpg|jpeg|bmp|gif|png';
				$this->image_lib->initialize($config);
				if (!$this->image_lib->resize())
				{
						return $this->image_lib->display_errors('', '');
				}
				/*
				else
				return TRUE;
				*/
		}
		function storePhotos($eventId)
		{
				$tmpName = $_FILES['userfile']['tmp_name'];
				$fileName = $_FILES['userfile']['name'];
				$error = $_FILES['userfile']['error'];
				$size = $_FILES['userfile']['size'];
				$msg = '';
				if (@$_FILES['userfile']['name'] == '')
				{
						$msg = $this->lang->line('events_validation_file_select_msg');
						return $msg;
				}
				if (!($_FILES['userfile']['type'] == 'image/jpeg' || $_FILES['userfile']['type'] == 'image/pjpeg' || $_FILES['userfile']['type'] == 'image/x-png' || $_FILES['userfile']['type'] == 'image/gif' || $_FILES['userfile']['type'] == 'image/png'))
				{
						$msg .= $_FILES['userfile']['name'] . $this->lang->line('events_validation_file_type_msg') . "<br>";
						return $msg;
				}
				if (intval($_FILES['userfile']['size']) > 4194304)
				{
						$msg .= $_FILES['userfile']['name'] . $this->lang->line('events_validation_file_size_msg') . "<br>";
						return $msg;
				}
				if (trim($fileName) != '' and $error === 0 and $size > 0)
				{
						$arrSplitedName = split("\.", $fileName);
						$extension = trim($arrSplitedName[count($arrSplitedName) - 1]);
						$newFileName = trim($eventId) . '.' . $extension;
						$pathToUpload = APPPATH . 'content/events/';
						$path = $pathToUpload . $newFileName;
						$this->eventsModel->storePhotos($eventId, $extension);
						$msg = '';
						if (!move_uploaded_file($tmpName, $path))
						{
								$msg = 'Failed to upload your photo';
						}
						else
						{
								$imgFile = APPPATH . 'content/events/' . $newFileName;
								$width = '50';
								$height = '50';
								$msg = $this->_resizeImage($imgFile, $width, $height);
						}
				}
				else
				{
						$msg = $this->lang->line('events_validation_file_select_msg');
				}
				return $msg;
		}
		function _photoRules()
		{
				$rules['agree'] = 'required|callback_validateTerms';
				$rules['userfile'] = 'callback_validateFiles';
				$this->validation->set_rules($rules);
				$fields['userfile'] = $this->lang->line('events_validation_photo');
				$fields['agree'] = $this->lang->line('events_validation_terms_condition');
				$this->validation->set_fields($fields);
		}
		function validateTerms()
		{
				if ($this->input->post('agree') == false)
				{
						$this->validation->set_message('validateTerms', $this->lang->line('events_validation_terms_agree'));
						return false;
				}
				else
				{
						return true;
				}
		}
		function validateFiles()
		{
				$msg = "";
				if ($_FILES['userfile']['name'] == '')
				{
						return $msg;
				}
				if ($_FILES['userfile']['error'] == 0 && $_FILES['userfile']['error'] != 4 && trim($_FILES['userfile']['name']) != '')
				{
						//if(!($_FILES['file'.$i]['type'] == 'image/jpeg' || $_FILES['file'.$i]['type'] == 'image/pjpeg' || $_FILES['file'.$i]['type'] == 'image/x-png' || $_FILES['file'.$i]['type'] == 'image/gif' || $_FILES['file'.$i]['type'] == 'image/png' || $_FILES['file'.$i]['type'] == 'image/bmp'))
						if (!($_FILES['userfile']['type'] == 'image/jpeg' || $_FILES['userfile']['type'] == 'image/pjpeg' || $_FILES['userfile']['type'] == 'image/x-png' || $_FILES['userfile']['type'] == 'image/gif' || $_FILES['userfile']['type'] == 'image/png'))
						{
								$msg .= $_FILES['userfile']['name'] . $this->lang->line('events_validation_file_type_msg') . "<br>";
						}
						if (intval($_FILES['userfile']['size']) > 4194304)
						{
								$msg .= $_FILES['userfile']['name'] . $this->lang->line('events_validation_file_size_msg') . "<br>";
						}
				}
				else
				{
						$msg = $this->lang->line('events_validation_file_select_msg');
				}
				if (trim($msg) != '')
				{
						$msg = "<br>" . $msg;
						$this->validation->set_message('validateFiles', $msg);
						return false;
				}
				else
				{
						return true;
				}
		}
		function getSubcategory()
		{
				$mainCatId = $this->input->post('cat_id');
				$subcatArray = array();
				if ($mainCatId != false)
				{
						$subcatArray = $this->eventsModel->getSubcategories($mainCatId);
				}
				echo (json_encode($subcatArray));
		}
		function _formRules()
		{
				$rules['event_name'] = 'trim|required|min_length[5]';
				$rules['event_tags'] = 'trim|required|min_length[5]';
				$rules['event_host'] = 'callback__checkHost';
				$rules['lstGroups'] = 'callback__checkHost';
				if ($this->input->post('cntNetworks') != false) $rules['network'] = 'callback__checkNetwork';
				$rules['event_desc'] = 'trim|required|min_length[10]';
				$rules['event_category'] = 'callback__isValidCategory';
				$rules['event_sub_category'] = 'callback__isValidSubCategory';
				$rules['event_location'] = 'trim|required';
				$rules['StartDay'] = 'callback__isValidInterval';
				$rules['event_website'] = 'callback__isURL';
				$rules['event_email'] = 'callback__isMail';
				$this->validation->set_rules($rules);
				$fields['lstGroups'] = $this->lang->line('events_form_host');
				$fields['event_host'] = $this->lang->line('events_form_host');
				$fields['event_name'] = $this->lang->line('events_form_name');
				$fields['event_desc'] = $this->lang->line('events_form_description');
				if ($this->input->post('cntNetworks') != false) $fields['network'] = $this->lang->line('events_form_network');
				$fields['StartDay'] = $this->lang->line('events_validation_event_duration');
				$fields['event_category'] = $this->lang->line('events_validation_event_cat');
				$fields['event_sub_category'] = $this->lang->line('events_validation_event_sub_cat');
				$fields['event_location'] = 'trim|required|min_length[3]';
				$fields['event_website'] = $this->lang->line('events_validation_url');
				$fields['event_email'] = $this->lang->line('events_form_email');
				$fields['event_tags'] = $this->lang->line('events_form_tag_line');
				$fields['event_location'] = $this->lang->line('events_form_location');
				$this->validation->set_fields($fields);
		}
		function _isValidInterval($StartDay)
		{
				$s_day = $this->input->post('StartDay');
				$s_mon = $this->input->post('StartMonth');
				$s_year = $this->input->post('StartYear');
				$e_day = $this->input->post('EndDay');
				$e_mon = $this->input->post('EndMonth');
				$e_year = $this->input->post('EndYear');
				$s_hour = $this->input->post('StartHour');
				$s_min = $this->input->post('StartMinute');
				$e_hour = $this->input->post('EndHour');
				$e_min = $this->input->post('EndMinute');
				$s_meridian = $this->input->post('StartMeridian');
				$e_meridian = $this->input->post('EndMeridian');
				$startTimestamp = mktime($s_hour, $s_min, 0, $s_mon, $s_day, $s_year);
				$endTimestamp = mktime($e_hour, $e_min, 0, $e_mon, $e_day, $e_year);
				if ($s_meridian == 'pm') $startTimestamp = $startTimestamp + (12 * 60 * 60);
				if ($e_meridian == 'pm') $endTimestamp = $endTimestamp + (12 * 60 * 60);
				if ($startTimestamp >= $endTimestamp)
				{
						$this->validation->set_message('_isValidInterval', '%s ' . $this->lang->line('events_validation_improper'));
						return false;
				}
				else
				{
						return true;
				}
		}
		function _checkNetwork($network)
		{
				if (trim($network) != '-1')
				{
						return true;
				}
				else
				{
						$this->validation->set_message('_checkNetwork', $this->lang->line('events_validation_select') . ' %s ');
						return false;
				}
		}
		function _checkHost()
		{
				if (TRIM($this->input->post('lstGroups')) == '0' and TRIM($this->input->post('event_host')) == '')
				{
						$this->validation->set_message('_checkHost', $this->lang->line('events_validation_select') . ' %s ');
						return false;
				}
				else
				{
						return true;
				}
		}
		function _isURL($event_website)
		{
				$pattern = "^(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?$";
				if (trim($event_website) != '')
				{
						if (!ereg($pattern, $event_website))
						{
								$this->validation->set_message('_isURL', $this->lang->line('events_validation_the') . ' %s ' . $this->lang->line('events_validation_not_valid'));
								return false;
						}
						else
						{
								return true;
						}
				}
				else
				{
						return true;
				}
		}
		function _isMail($event_email)
		{
				$pattern = "^[a-zA-Z0-9]([a-zA-Z0-9]*\_[a-zA-Z0-9]+)*([a-zA-Z0-9\-]*\.[a-zA-Z0-9\-]+)*[a-zA-Z0-9]*@[a-zA-Z0-9]{2,}\.[a-zA-Z0-9]{2,}(\.[a-zA-Z0-9]{2,})?$";
				if (trim($event_email) != '')
				{
						if (!ereg($pattern, $event_email))
						{
								$this->validation->set_message('_isMail', $this->lang->line('events_validation_the') . ' %s ' . $this->lang->line('events_validation_not_valid'));
								return false;
						}
						else
						{
								return true;
						}
				}
				else
				{
						return true;
				}
		}
		function _isValidCategory($event_category)
		{
				if (trim($event_category) == '0')
				{
						$this->validation->set_message('_isValidCategory', $this->lang->line('events_validation_select') . ' %s ');
						return false;
				}
				else
				{
						return true;
				}
		}
		function _isValidSubCategory($event_sub_category)
		{
				if (trim($event_sub_category) == '0')
				{
						$this->validation->set_message('_isValidSubCategory', $this->lang->line('events_validation_select') . ' %s ');
						return false;
				}
				else
				{
						return true;
				}
		}
}
?>