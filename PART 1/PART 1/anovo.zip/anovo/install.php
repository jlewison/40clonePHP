<?php
if ((int)phpversion() < 5)
{
		$host = '';
		if (isset($_SERVER['HTTP_HOST'])) $host = $_SERVER['HTTP_HOST'];
		else
				if (isset($_SERVER['SERVER_NAME'])) $host = $_SERVER['SERVER_NAME'];
		$CFG['site']['url'] = (!empty($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . $host . str_replace(array('common/', 'members/', 'admin/', 'cron/', 'rss/'), '', substr($_SERVER['SCRIPT_NAME'], 0, strrpos($_SERVER['SCRIPT_NAME'], '/') + 1));
}
else  require_once ('./common/config.inc.php');
require_once ('./common/classes/phpmailer/class_PHPMailer.lib.php');
$page_blocks = $show_block = $san_arr = array();
$err_msg = '';
echo '<?xml version="1.0"?>' . "\n"; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html lang="en-US" dir="ltr" xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="application/xhtml+xml; charset=UTF-8" />
<meta http-equiv="content-Language" content="en-US" />
<meta name="keywords" content="Answers, Questions, Video Answers, Video Questions, Audio Answers, Audio Questions, Blogs, Forums" />
<meta name="description" content="Visual Answers site is the place where you can post your questions of any type (Text, Video and Audio) and get them clarified. You can also reply to the Questions of any type (Text, Video and Audio) in any formats (Text, Video and Audio). You can also share the views through Blogs and Forums" />
<?php
if ($CFG['html']['meta']['MSSmartTagsPreventParsing'])
{
?>
<!-- Disable MSSmartTags -->
<meta name="MSSmartTagsPreventParsing" content="true" />
<?php
}
if (!$CFG['html']['meta']['imagetoolbar'])
{
?>
<!-- Disable IE6 image toolbar -->
<meta http-equiv="imagetoolbar" content="no" />
<?php
}
?>
<link rel="stylesheet" type="text/css" href="<?php echo $CFG['site']['url']; ?>members/css/<?php echo $CFG['html']['stylesheet']['screen']['default']; ?>.css" media="screen" title="Default" />
<link rel="stylesheet" type="text/css" href="<?php echo $CFG['site']['url']; ?>css/print.css" media="print" />
<link rel="shortcut icon" href="<?php echo $CFG['site']['url']; ?>favicon.ico" type="image/x-icon" />
<!-- for link bar -->
<link rel="Home"     href="<?php echo URL($CFG['site']['url']); ?>" title="Home page" />
<link rel="Index"    href="<?php echo URL($CFG['site']['url']); ?>" title="Index" />
<link rel="search"   href="#" title="Search this site" />

<link rel="contents" href="#" title="Site map" />
<title>Anova - More Scripts: MegaUnionWareZ.cOm</title>
</head>
<body>

<div id="<?php echo $CFG['html']['page_id']; ?>" class="clsBodyContent">
  <div id="hideScreen" style="z-index: 100; display: none;" class="VeilStyle1c">&nbsp;</div>
  <a href="#" id="alertHyperLink"></a>

  <!-- Accessibility Links -->
  <div id="top">
    <ul>
      <li><a href="#main">Skip to main content</a></li>
      <li><a href="#selSubHeader">Skip to Navigation Links</a></li>
      <li><a href="#footer">Skip to Footer</a></li>
    </ul>

  </div>
  <!-- Header -->
  <div id="header">
 <div class="clsTopHeader" style="margin:0; padding:0">   <h1 style="margin:1em 0 0 0; padding:0"><a href="<?php echo $_SERVER['PHP_SELF']; ?>" title="Browse to homepage">Anova</a></h1></div>
  </div>
  <!--SIDEBAR-->
  <div id="sideBar">
    <!--SIDEBAR1-->
    <!--end of SIDEBAR1-->
           <!--sideBar2-->
           <!--end of SIDEBAR2-->
</div>
  <!--end of SIDEBAR-->
  <!-- Main -->

  <div id="main" class="clsMain">




<?php
function URL($url)
{
		return $url;
}
function chkIsWritableAll($folder_name = '', $all = false, $all_display = false)
{
		global $err_msg;
		$val = 0;
		if ($all && is_dir($folder_name))
		{
				if ($handle = opendir($folder_name))
				{
						if ($all_display)
						{
								while (false !== ($file = readdir($handle)))
								{
										if ($file == '.' or $file == '..') continue;
?>
										<tr>
											<td><?php echo $folder_name . $file; ?></td>
											<td><?php echo (is_dir($folder_name . $file) ? 'Folder' : 'File'); ?></td>
											<td>
<?php
										if (!is_writable($folder_name . $file))
										{
												echo 'Error';
												$val++;
										}
										else  echo 'Ok';
?>
											</td>
										</tr>
<?php
								}
						}
						else
						{
								while (false !== ($file = readdir($handle)))
								{
										if ($file == '.' or $file == '..') continue;
										if (!is_writable($folder_name . $file)) $val++;
								}
?>
								<tr>
									<td><?php echo $folder_name; ?></td>
									<td>Folder</td>
									<td><?php echo ($val == 0) ? 'Ok' : 'Error - files'; ?></td>
								</tr>
<?php
						}
						closedir($handle);
				}
		}
		else
				if (is_dir($folder_name) && !$all)
				{
?>
						<tr>
							<td><?php echo $folder_name; ?></td>
							<td>Folder</td>
							<td><?php echo (is_writable($folder_name)) ? 'Ok' : 'Error'; ?></td>
						</tr>
<?php
				}
				else
						if (!is_dir($folder_name))
						{
?>
						<tr>
							<td><?php echo $folder_name; ?></td>
							<td>File</td>
							<td><?php echo (is_writable($folder_name) ? 'Ok' : 'Error'); ?></td>
						</tr>
<?php
						}
		if ($val > 0) $err_msg .= 'Error found! Write permission missing for some files/folders';
}
function setCommonErrorMessage()
{
		$this->setCommonErrorMsg($this->file_err_msg);
}
function connectDB()
{
		global $err_msg, $san_arr;
		if ($rs = @mysql_connect($san_arr['dbhost'], $san_arr['dbuser'], $san_arr['dbpass'])) return $rs;
		$err_msg .= '<li>Could not connect</li>';
		return false;
}
function chkIsDBExists()
{
		global $err_msg, $san_arr;
		if (isset($san_arr['drp']) and mysql_select_db($san_arr['dbname'])) mysql_query('DROP DATABASE ' . $san_arr['dbname']);
		if (mysql_select_db($san_arr['dbname']))
		{
				$err_msg .= '<li>DB Already exists, if you want to drop the existing db press \'DROP AND CREATE\', otherwise change the data base name and press \'Next\' ';
				$err_msg .= '<form name="form_db_exists" id="selFormDbExists" method="post" action="' . $_SERVER['PHP_SELF'] . '" autocomplete="off">
			<input type="hidden" name="drp" id="drp" value="ok" />
			<input type="hidden" name="dbhost" id="dbhostdrp" value="' . $san_arr['dbhost'] . '" />
			<input type="hidden" name="dbuser" id="dbuserdrp" value="' . $san_arr['dbuser'] . '" />
			<input type="hidden" name="dbpass" id="dbpassdrp" value="' . $san_arr['dbpass'] . '" />
			<input type="hidden" name="dbname" id="dbnamedrp" value="' . $san_arr['dbname'] . '" />
			<input type="submit" name="submit_db" id="submit_db_drp" value="DROP AND CREATE" />
		</form>';
				$err_msg .= '</li>';
				return true;
		}
		return false;
}
function queryDB($sql)
{
		global $err_msg, $san_arr;
		if (mysql_query($sql)) return true;
		$err_msg .= '<li>Could not Create DB</li>';
		return false;
}
function setAllPageBlocksHide()
{
		global $page_blocks, $show_block;
		foreach ($page_blocks as $val) $show_block[$val] = false;
}
function setPageBlockShow($val)
{
		global $show_block;
		$show_block[$val] = true;
}
function sanitizeFormInputs($request_arr)
{
		global $san_arr;
		foreach ($request_arr as $key => $val) $san_arr[$key] = htmlspecialchars(trim($request_arr[$key]));
}
function getFormField($key)
{
		global $san_arr;
		return (isset($san_arr[$key])) ? $san_arr[$key] : '';
}
function chkIsNotEmpty($field_name, $err_tip = '')
{
		global $san_arr, $err_msg;
		$is_ok = (is_string($san_arr[$field_name])) ? ($san_arr[$field_name] != '') : (!empty($san_arr[$field_name]));
		if (!$is_ok) $err_msg .= "<li>" . $err_tip . "</li>";
		return $is_ok;
}
function sendMail()
{
		global $CFG;
		$mail = new PHPMailer();
		$to_email = 'webmaster@localhost';
		$sender_name = 'Anova Webmaster';
		$sender_email = 'webmaster@localhost';
		$subject = 'Anova installed sucessfully in ' . $CFG['site']['url'];
		$body = 'Hi Anova admin,

				Anova installed successfully in ' . $CFG['site']['url'] . ' on ' . date("F j, Y, g:i a") . '

				Ip address of the site:' . $CFG['remote_client']['ip'] . '

				Check the site <a href="' . $CFG['site']['url'] . '">' . $CFG['site']['url'] . '</a>

				Regards,
				Anova Webmaster.
				';
		$mail->AddAddress($to_email);
		$mail->FromName = $sender_name;
		$mail->From = $mail->Sender = $sender_email;
		$mail->Subject = $subject;
		$mail->Body = nl2br($body);
		$mail->IsMail();
		$mail->IsHTML(true);
		return ($mail->Send());
}
function parse_mysql_dump($url, $ignoreerrors = false)
{
		global $san_arr, $err_msg;
		if (!mysql_select_db($san_arr['dbname']))
		{
				$err_msg .= '<li>Database not created, please create the database and press "Next"...</li>';
				return false;
		}
		$file_content = file($url);
		$query = "";
		foreach ($file_content as $sql_line)
		{
				$tsl = trim($sql_line);
				if (($sql_line != "") && (substr($tsl, 0, 2) != "--") && (substr($tsl, 0, 1) != "#"))
				{
						$query .= $sql_line;
						if (preg_match("/;\s*$/", $sql_line))
						{
								$result = mysql_query($query);
								if (!$result && !$ignoreerrors) die(mysql_error());
								$query = "";
						}
				}
		}
}
function writeDBConfig()
{
		global $san_arr, $err_msg;
		if (is_writable('./common/configs/config_db.inc.php'))
		{
				if ($handle = fopen('./common/configs/config_db.inc.php', 'w'))
				{
						$str = <<< CONT
<?php
\$CFG['db']['hostname'] = '{$san_arr['dbhost']}';
\$CFG['db']['name'] = '{$san_arr['dbname']}';
\$CFG['db']['username'] = '{$san_arr['dbuser']}';
\$CFG['db']['password'] = '{$san_arr['dbpass']}';
?>
CONT;
						fwrite($handle, $str);
						fclose($handle);
				}
		}
}
$page_blocks = array('msg_form_error', 'form_index', 'form_access', 'form_access_err', 'form_db_setup', 'msg_form_success');
$show_block = array();
setAllPageBlocksHide();
setPageBlockShow('form_index');
if (isset($_POST['submit_req']) && $_POST['submit_req'])
{
		sanitizeFormInputs($_POST);
		setAllPageBlocksHide();
		setPageBlockShow('form_access');
}
else
		if (isset($_POST['submit_index']) && $_POST['submit_index'])
		{
				sanitizeFormInputs($_POST);
				if (is_writable('./common/configs/config_db.inc.php'))
				{
						setAllPageBlocksHide();
						setPageBlockShow('form_db_setup');
				}
				else
				{
						setAllPageBlocksHide();
						$err_msg = 'Error found! To continue set write permission atleast for "./common/configs/config_db.inc.php"';
						setPageBlockShow('msg_form_error');
						setPageBlockShow('form_access');
				}
		}
if (isset($_POST['submit_db']) && $_POST['submit_db'])
{
		$san_arr = array();
		sanitizeFormInputs($_POST);
		$sql = 'Create database ' . $san_arr['dbname'];
		chkIsNotEmpty('dbname', 'Database Name Empty');
		chkIsNotEmpty('dbhost', 'Host Name Empty');
		chkIsNotEmpty('dbuser', 'Database User Name Empty') and ($rs = connectDB()) and parse_mysql_dump('./install/anova.sql');
		if ($err_msg == '')
		{
				setAllPageBlocksHide();
				writeDBConfig();
				sendMail();
				$err_msg = 'Anova installed successfully!!! Delete the install.php file...';
				setPageBlockShow('msg_form_success');
		}
		else
		{
				setAllPageBlocksHide();
				setPageBlockShow('msg_error');
				setPageBlockShow('form_db_setup');
		}
}



?>

<div id="selLogin">
<h2>Anova Installation</h2>
  <?php
if ($show_block['msg_form_error'])
{
?>
  <div id="selMsgError">
    <p><?php echo $err_msg; ?></p>
  </div>
  <?php
}
if ($show_block['msg_form_success'])
{
?>
  <div id="selMsgSuccess">
    <p><?php echo $err_msg; ?></p>
  </div>
  <?php
}

?>
  <div class="clsLoginSignup">
    <?php
if ($show_block['form_index'])
{
?>
    <div>
		<div>
			<table>
				<tr>
					<th>Anova requirements</th>
					<th>You have</th>
					<th>Status</th>
				</tr>
				<tr>
					<td>PHP ver 5</td>
					<td>PHP ver <?php echo $phpversion = phpversion(); ?></td>
					<td>
<?php
		if ((int)$phpversion < 5)
		{
				echo 'Error';
				$err_msg = 'Error found! Anova requirement missing.';
		}
		else  echo 'Ok';
?>
					</td>
				</tr>
				<tr>
					<td>GD</td>
					<td>
<?php
		if (function_exists("imagecreatetruecolor")) echo 'GD2';
		elseif (function_exists("imagecreate")) echo 'GD';
		else
		{
				echo 'Not installed';
				$gd_err = 'Error';
		}
?>
					</td>
					<td>
<?php
		if (isset($gd_err) && $gd_err != '')
		{
				echo 'Error';
				$err_msg = 'Error found! Anova requirement missing.';
		}
		else  echo 'Ok';
?>
					</td>
				</tr>
			</table>
		</div>
<?php
		if ($err_msg == '')
		{
?>
		<form name="form_index" id="selFormIndex" method="post" action="<?php echo ($_SERVER['PHP_SELF']); ?>" autocomplete="off">
			<input type="submit" name="submit_req" id="submit_req" value="Next" />
		</form>
<?php
		}
		else
		{
?>
		<div>
			You can't continue with the installation ...
		</div>
<?php
		}
?>
    </div>
<?php
}
if ($show_block['form_access'])
{
?>
	<div>
		<h3>Write permission</h3>
		<div>
			<table>
				<tr>
					<th>Name</th><th>File/Folder</th><th>Status</th>
				</tr>
<?php
		chkIsWritableAll('./common/config.inc.php');
		chkIsWritableAll('./common/configs/', true);
		chkIsWritableAll('./files/');
		chkIsWritableAll('./includes/', true);
		chkIsWritableAll('./members/includes/', true);
		chkIsWritableAll('./admin/includes/', true);
?>
			</table>
		</div>
		<form name="form_index" id="selFormIndex" method="post" action="<?php echo ($_SERVER['PHP_SELF']); ?>" autocomplete="off">
			<input type="submit" name="submit_index" id="submit_index" value="Next" />
		</form>
	</div>
<?php
}
if ($show_block['form_access_err'])
{
?>
    <div>
      <h2>Anova Installation - Write permission</h2>
      <form name="form_index" id="selFormIndex" method="post" action="<?php echo ($_SERVER['PHP_SELF']); ?>" autocomplete="off">
		<div>
			<ul>
			<?php echo $loginfrm->file_err_msg; ?>
			</ul>
		</div>
		<div>
			<input type="submit" name="submit_index" id="submit_index" value="Next" />
		</div>
	  </form>

    </div>
    <?php
}
if ($show_block['form_db_setup'])
{
?>
    <div>
<?php
		if (isset($show_block['msg_error']) && $show_block['msg_error'])
		{
?>
			  <div>
			    	<ul>
						<?php echo $err_msg; ?>
					</ul>
			  </div>
<?php
		}
?>
      <form name="form_dbSetup" id="selFormdbSetup" method="post" action="<?php echo ($_SERVER['PHP_SELF']); ?>" autocomplete="off">
		<table>
			<tr>
				<td class="form_label_cell_default"><label for="dbhost"><?php echo 'Database Host'; ?></label></td>
				<td class="form_field_cell_default"><input type="text" name="dbhost" id="dbhost" tabindex="1000" value="<?php echo getFormField('dbhost'); ?>" /></td>
			</tr>
			<tr>
				<td class="form_label_cell_default"><label for="dbuser"><?php echo 'Database User name'; ?></label></td>
				<td class="form_field_cell_default"><input type="text" name="dbuser" id="dbuser" tabindex="1005" value="<?php echo getFormField('dbuser'); ?>" /></td>
			</tr>
			<tr>
				<td class="form_label_cell_default"><label for="dbpass"><?php echo 'Database Password'; ?></label></td>
				<td class="form_field_cell_default"><input type="text" name="dbpass" id="dbpass" tabindex="1010" value="<?php echo getFormField('dbpass'); ?>" /></td>
			</tr>
			<tr>
				<td class="form_label_cell_default"><label for="dbname"><?php echo 'Database name'; ?></label></td>
				<td class="form_field_cell_default"><input type="text" name="dbname" id="dbname" tabindex="1015" value="<?php echo getFormField('dbname'); ?>" /></td>
			</tr>
		</table>
		<div>
			<input type="submit" name="submit_db" id="submit_db" value="Next" />
		</div>
	  </form>

    </div>
    <?php
}
?>
	</div>
</div>

  </div>

  <!-- Footer -->
  <div id="footer">
        <div id="subFooter">
          <p>&copy; 2008. All rights reserved.</p>
    </div>
  </div>
    <p class="clsPoweredByAgriya"><span class="clsPoweredText">Powered By <a href="<?php echo $CFG['dev']['url']; ?>"><?php echo $CFG['dev']['name']; ?></a> [iAG] Nulled</span></p>

</div>
</body>
</html>