<? include ("header.php"); ?>



<table cellpadding="0" cellspacing="0" border="0" width="100%">
	<tr class="top3">
		<td colspan="3"><img src="template/v3/i/b.gif" border="0" height="15" width="1"></td>
	</tr>
	<tr class="top4">
		<td>&nbsp;</td>
		<td align="center">
			<table cellpadding="0" cellspacing="0" border="0" width="778">
				<tr>
					<td valign="top" height="109"><object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" width="257" height="109" id="logo" align="middle"><param name="movie" value="flash/logo.swf" /><param name="quality" value="high" /><param name="wmode" value="transparent" /><param name="bgcolor" value="#ffffff" /><embed src="flash/logo.swf" quality="high" wmode="transparent" bgcolor="#ffffff" width="257" height="109" name="rotator" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /></object></td>
					<td valign="top" height="109"><img src="template/v3/i/content12.jpg" border="0"></td>
					<td rowspan="3" valign="top" class="box_right"><object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" width="204" height="128" id="innerstar" align="middle"><param name="allowScriptAccess" value="sameDomain" /><param name="movie" value="flash/innerstar.swf" /><param name="quality" value="high" /><param name="wmode" value="transparent" /><param name="bgcolor" value="#ffffff" /><embed src="flash/innerstar.swf" quality="high" wmode="transparent" bgcolor="#ffffff" width="204" height="128" name="innerstar" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /></object><a href="promotions.php"><img src="template/v3/i/innerstar-1b2.gif" border="0"></a>
						












<? include ("mg.php"); ?>
				<tr>
					<td class="subtitle_path" colspan="2" valign="top" height="35"><div><a href="index.php"><img src="template/v3/i/home_ico.jpg" border="0" vspace="0" style="margin-left: 36px;margin-right: 27px" align="left"></a></div>Fair Gaming</td>
				</tr>
				<tr>
					<td colspan="2" class="content" valign="top"><img src="template/v3/i/b.gif" width="1" height="500" border="0" align="left">Casino is one of the most respectable, online casinos on the Web. Our expertise and professionalism is based on knowing the importance of establishing a fair gaming environment for our guests. <b>Casino</b> maintains a true, fair, transparent, and secure environment as we build long-lasting relationships with our players.<br>
<br>
Further examples of our transparency are the unique, built-in game and financial history features. Players can review every wager they have ever placed, including the exact date and time, amount wagered, winnings, and detailed game results. Financial transaction histories display all deposits and withdrawals from the player's casino account. Both of these features can be accessed online at any time.<br>
<br>
The <b>Casino</b> software platform and systems have also been tested and approved after by RTG (Real Time Gaming) by testing millions of game rounds, random results, and continues to periodically test our systems to ensure their ongoing accuracy.<br>
<br>
The <b>Casino</b> average payout percentage, which is the percentage of total winnings out of the total wagered amounts, is often better than those in Las Vegas or Atlantic City.<br>
<br>
<b>Casino</b> is powered by a hi- tech computer at RTG. To ensure that the performance of this computer is truly random, a sophisticated RNG (Random Number Generator) is utilized.</td>
				</tr>
				<tr>
					<td colspan="2" valign="bottom" class="content_bot"><img src="template/v3/i/content_bot.jpg" border="0"></td>
					<td class="box_right" valign="bottom"><img src="template/v3/i/box_right_bot.jpg" border="0"></td>
				</tr>
			</table>
		</td>
		<td>&nbsp;</td>
	</tr>
		<?		include ("footer.php") ?>	
<? include ("header.php"); ?>
