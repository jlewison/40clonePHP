function createRequestObject() {
    var ro;
    var browser = navigator.appName;
    if(browser == "Microsoft Internet Explorer"){
        ro = new ActiveXObject("Microsoft.XMLHTTP");
    }else{
        ro = new XMLHttpRequest();
    }
    return ro;
}

var http = createRequestObject();

function cascadeCountry(value) {
    http.open('get', 'cascade_admin.php?a=country&v=' + value );
	document.getElementById('txtstateprovince').innerHTML="&nbsp;&nbsp;"+loadingTag;
    http.onreadystatechange = handleResponse;
    http.send(null);
}

function cascadeState(value,v1) {
    http.open('get', 'cascade_admin.php?a=state&v=' + value  + '&v1=' + v1);
	document.getElementById('txtcounty').innerHTML="&nbsp;&nbsp;"+loadingTag;

    http.onreadystatechange = handleResponse;
    http.send(null);
}

function cascadeCounty(value,v1,v2) {
    http.open('get', 'cascade_admin.php?a=county&v=' + value
					+ '&v1=' + v1 + '&v2=' + v2);
		document.getElementById('txtcity').innerHTML="&nbsp;&nbsp;"+loadingTag;

    http.onreadystatechange = handleResponse;
    http.send(null);
}

function cascadeCity(value,v1,v2,v3) {
    http.open('get', 'cascade_admin.php?a=city&v=' + value
					+ '&v1=' + v1 + '&v2=' + v2 + '&v3=' + v3);
		document.getElementById('txtzip').innerHTML="&nbsp;&nbsp;"+loadingTag;

    http.onreadystatechange = handleResponse;
    http.send(null);
}

function handleResponse() {
    if(http.readyState == 4){
        var response = http.responseText;
        var update = new Array();
		var up2 = new Array();

        if(response.indexOf('|||' != -1)) {
            update = response.split('|||');

			for (var i = 0; i<update.length; i++) {
				up2 = update[i].split('|:|');
            	document.getElementById(up2[0]).innerHTML=up2[1];
			}
        }
    }
}
