<? 
include "header.php"; 

?>
<center>
<h4><font color=#7C87C2>news envoy�es</font></h4>

<br><br>


<? include "footer.php"; ?>