<?php
////////////////////////////////////////////////////////////// 
// Rapidsendit Clone V.1.1  Purchased from Rapidsendit.com ///
// flatFileHost lives on! Credits To Jim For The Foundtion ///
//////////////////////////////////////////////////////////////

extract ($_REQUEST);
extract($_POST);
extract($_GET);

$scripturl = "http://www.yourdomin.com/";
//// the URL to this script with a trailing slash

$maxfilesize = 1;
//// the maximum file size allowed to be uploaded (in megabytes)

$downloadtimelimit = 2;
//// time users must wait before downloading another file (in minutes)

$uploadtimelimit = 2;
//// time users must wait before uploading another file (in minutes)

$nolimitsize = 1;
//// if a file is under this many megabytes, there is no time limit

$deleteafter = 7;
//// delete files if not downloaded after this many days

$downloadtimer = 10;
//// length of the timer on the download page (in seconds)

$enable_filelist = true;
//// allows users to see a list of uploaded files. set to false to disable

//$allowedtypes = array("txt","gif","jpg","jpeg");
//// remove the //'s from the above line to enable file extention blocking
//// only file extentions that are noted in the above array will be allowed

$emailoption = false;
//// set this to true to allow users to email themselves the download links
?>