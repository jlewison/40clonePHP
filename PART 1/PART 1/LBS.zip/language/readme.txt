1. Login to the admin section and click to 'Language management'
 
2. On the opened page type the language file name to the 'Add language' input field and click to the insert button.
   (type the name of the language file without .php extension ex: lang_english )
 
3. Now from the admin home area click to the 'Site Configuration' and at the bottom of the list select the preferred language using the 'Select language' option and click to update.
 
4. Upload the language file to the lbs installation root folder, with the same name what you added above on the item 2 .
 
A. I've attached the default English language file: lang_english.php and also the Romanian lang_romania.php file.
 
B. Create language file tip:
- open the file lang_english.php and save as to lang_hungarian.php
- translate all the text and upload the file lang_hungarian.php
- login to the admin panel and make the settings described above.
 
C. The script possible to run with unlimited language files, just need to setup the used language form the admin section.