<?php
require_once ('../common/config.inc.php');
$CFG['lang']['include_files'][] = 'members/includes/languages/%s/blogs.php';
$CFG['html']['header'] = 'members/includes/languages/%s/html_header.php';
$CFG['html']['footer'] = 'members/includes/languages/%s/html_footer.php';
$CFG['lang']['include_files'][] = 'common/languages/%s/lists_array/months_list_array.inc.php';
$CFG['lang']['include_files'][] = 'common/languages/%s/help.inc.php';
$CFG['lang']['include_files'][] = 'common/configs/config_article.inc.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['mods']['include_files'][] = 'common/classes/class_ListRecordsHandler.lib.php';
require ($CFG['site']['project_path'] . 'common/application_top.inc.php');
require_once ('../general/blogs.php');
?>