<?
include "../setup.php";
include("auth.php");
$date=date("d.m.y");
$data=date("d.m.y");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>admin</title>
<link href="images/default.css" rel="stylesheet" type="text/css" media="screen">
</head>

<body>
<table border="0" align="center" cellpadding="2" cellspacing="0">
<tr>
<td class="bborder">
<table border="0" cellpadding="0" cellspacing="0" width="900">
<tr>
<td align="center" height="24" class="main">
<table border="0" cellspacing="0" cellpadding="5">
<tr>
<td><td><a class="nav" href="index.php">home</a>
<td>|
<td><a class="nav" href="userlist.php">User list</a>
<td>|
<td><a class="nav" href="part.php">Affiliate</a>
<td>|


<td><a class="nav" href="statjeu.php">Stat game</a>
<td>|



<td><a class="nav" href="zakazlist.php">Withdraw Funds 
</a>
<td>|
<td><a class="nav" href="userpay.php">Users pay</a>
<td>|
<td><a class="nav" href="config.php">Setting</a>
<td>|
<td><a class="nav" href="bank.php">Option</a>
<td>|
<td><a class="nav" href="jackpot.php">Jackpot</a>
<td>|

<td><a class="nav" href="?event=exit">sortie</a><tr id="options-submenu" style="display: none;">
<td colspan="7">
</table>
<tr>
<td height="19">
<table border="0" cellpading="0"cellspacing="15" width="100%" height="100%">
<tr>
<td><div><img border="0" src="images/user2.gif" align="absmiddle">&nbsp;&nbsp;&nbsp;
<?
$strok=mysql_query("SELECT * FROM users");
$strokinbase = mysql_num_rows($strok);
$strok=mysql_query("SELECT * FROM zakaz WHERE 1 AND flag=1");
$strokinbase2 = mysql_num_rows($strok);
$resultg=mysql_query("select * from game_bank where name='ttuz'");
$rog=mysql_fetch_array($resultg);



$requete=mysql_query("SELECT SUM(cashin) FROM users");


$donnee = mysql_fetch_array($requete);
$so=$donnee['SUM(cashin)'];






?>
Nb total playeurs: <? echo $strokinbase; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<font color="red">Withdraw Funds 
: <? echo $strokinbase2; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font>
bank : <? echo $rog[1]; ?> <div>
<tr>
<td width="100%" height="100%">
<table border="0" cellpading="0" cellspacing="0" width="654">
 <tr>
  <td width="650" colspan="5" height="1">&nbsp;
<tr>
 <td>