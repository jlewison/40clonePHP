<?php //00461
// Copyright Notice
// Web Site URL:  http://www.zeeways.com
// Script Owner eMail: mail@zeeways.com
// Date: April, 2007
// Script Name: Zeeways Auction Website PHP Script
// Copyright Details: This script is not free.  Do not Remove this Copy Right notice.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the site administrator.');exit(199);
?>
4+oV5Fejl7yD20Lmt9OfNArOtxNfhYnixYqVqkqRmcoFmsIyPZxDNDE7hXnP9N78lrVTbdA9WbFM
i915pXgfmH1nblONIqF1U58GCwiCRxiM+yOmdOEOD7D7vxUsZfrE0rGWffIWCx3zz3b9k4BsigAH
zTtiBIjhHgw07qtekS6VDerCmftdsG1i66YJM+5pTE+D/H50L8Oa9RiB9xK3AsqxYmQC4v03WA0n
ZxJ/PKpdn8tRLBlbpsNtlPQcD0nCS/Sjhab+jffm4OCgO/JjSlgl7nqs1jAiyO85E5zXzMEZ6wcr
fIYhTeXWpvHFydGafH+et4BWBb7hUvBy4KNsM8rudTyVCCzbbLZBYwAi7h4R8An8kzTPv2WMh7Uy
H8fzMAtpdY570cu0OCUc/zEhYNZxjVcYXsPQGV2JiPZeFvyGqGi5mnYoZWYnthqtZbYuelF1PjRx
vyiK0WRPy8FQvNNKXK3+8vdMRR3WMcZAhTfcOZhE21hThXw2hKvadSHQlMoSaibsGEuFoAZ2mv5m
rXwJXXCQ/9AjRWZYhMZjpRBCvbt1FIQm0n9mCHrtPmWHT8qAvVEAjznzhYPy7G7YAc1NFVplrSuY
98z8GlCB+iRSJp/9036O7FhNC4pkdWPEEnkI8++QFyMgXiUqHn69ZuPBe4sxspzD2d+oAsJZb/kL
Bu2ojIn+imi9GhLulyRC0++yxWn5aKb316QgZhj35AFi37hOjuLU7Ub4tn1o8413nJ0xWqfthgUs
8Hf93iYm7z0XpG+D7nVejw3hn5tKY4Rk2W3+txNXISE0qRmQRP7lEp9KAzHwIC5UUxgL4r+dT/P0
lofE9JttHFHNUoKxBMDsr/A+6JRE2hdyJefsGV1E+TqCX7+KTSxfFWjmuWtirwoxCvbKKCjFRQxc
4pDpgvNMPa7TYvKJqj4uvYXB3dclw7ZHGcYmmhClxYRmc9+2CwXB8M8brINIov7MPa1PfGjmODjj
9t65uz34+or/ctw0HufkctK+iuuRbZEtxJ8aYeX98N6KWuzYCUTJPIZssqcJ+jjmpZlDqgkf0fVK
Zu4BmOpEnDtdf7YzJwYzh23MJn42YEJBnfsHCWKqZoI2xEvdDSTV+MuZslpqW0qTfFF399jQMsgO
mzCmgGzCdQ41L+vEUWMMWvgPPT/zNhygJsp6