<?php
$LANG['page_title'] = 'My Subscribed User';
$LANG['page_title_user_name'] = '{user_name}\'s Subscribed User';
$LANG['no_tags_subscribed'] = 'No User Subscribed';
$LANG['invalid_user'] = 'Invalid User';
$LANG['back_to_user_profile'] = 'Back to my profile';
$LANG['back_to_user_profile_user'] = 'Back to {user_name}\'s profile';
?>