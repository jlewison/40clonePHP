<?php //00461
// Copyright Notice
// Web Site URL:  http://www.zeeways.com
// Script Owner eMail: mail@zeeways.com
// Date: April, 2007
// Script Name: Zeeways Auction Website PHP Script
// Copyright Details: This script is not free.  Do not Remove this Copy Right notice.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the site administrator.');exit(199);
?>
4+oV51A/yb2eXyTdeGjdS/NJYxXrE2YCZhF2mTINSTl6Osf5vlfzVzR149bb06o4GLLdeBpixAnA
JF6FUtp03/J8zxn0K4SJtKRkOByToMIe7nAdB4YKmt+9aTKGEDCM35/Nl4OxPT744w12COsAodZg
em8MrEDevSSzWsAGn34K1BBzjGJFS6zQntLqRAaHmCaeiKsvzGl8tUf+FnOuS+PzmkQa7pYeZ5OD
HPFMTetW+glG4Q8KJdNkavQcD0nCS/Sjhab+jffm4ODbPl7UcwwMSAeEAEYScRK3HV+U3G53g7jr
AwCss8wqkkSl3jN+aHHuurqffwI1V4Mh2PU+IeRpsa3WSy28RavvpwUzr7VeMKqINBWm0dMeMKuX
f4DWMq1UdoZtL56iWueBnQ5pl1zLusaqDqWhHK57394fD//+ZWvie20WkAOYC6005JtX8jXimGla
eADu6B8ijfkMNwsvSV4npC9478lxGi/uTrtaOTrRbuaR2rY1NeFdx2ddPhp92vW8jH+BaPgSTSve
Z4sXClIFOIpEWD3gaKOnchtzxoYU9+Vb6P53YiCARrhfJ742wLF770h4wD3wGXLLZcnvqdZNSjaJ
0jdyl8aHwR5KD1yJpCkLEgzEEFDKY6Er7GB7A+39zsvKDc43Q24Wr13I5lh+3u9JDs6FH1SLyDDm
siUBAm8+xep+CE0072ThKRLbCXbvZUwJdsBqh+C1MQ9epdDFbwznzdE6jZQzHcwlCmoiKIf3sTnr
LrASuY2XhOQ09CuDNHHdeQtyfzO51PPPcQRz+C0jbhwvhg1fuGVIIAXOo9oKCpaVUMYlFbuNvXYz
1n4E4FgoN3u9OeS8+7PGeyZX8c3ptPb9K5PnY0x/HUnVTbKQHima3px7DYIJs6g/4VbfklvdoH+w
BjVzi0UIVvmeVz95FkPbGg3pVBzKFT1hS1h4olhjXPegRihtYmrb3ODzcGxuPcCGZy43GUxaVt3z
FOIGTtSbQUJ/V+RYd5QCyQC6QuCDgno+nh/NnAPbkWl+QSbEZAFLacnwdyezMIoTTPOwsv9+Mnzp
GFtdObRsu2/NSPybtEYst3BcRgldQasMk/iUkgXRHVgSp/mWNQpeBcnkwXYPYxtpiM5jLNApjZ8K
5Xvjby0RG/XgnfmFj+m+iydnjwJb/Q0FEBvTdQdpFVQpzF6+v749q7Ys7Ukmr16I702Fd3FLaWTP
us9CSw7YxjIb+bW+MP0N1tSQzlHAZ30xw/GPdedoC2v+fuBl7SzHpSK+eai9zf68uQL+KsuShe78
sABRqSQX+kJGxkBwlnmILvNvE+JIFYk79AnqYn7j