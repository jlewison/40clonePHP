<?php
mysql_select_db($database_apound, $apound);
$query_AUPC = "SELECT * FROM about";
$AUPC = mysql_query($query_AUPC, $apound) or die(mysql_error());
$row_AUPC = mysql_fetch_assoc($AUPC);
$totalRows_AUPC = mysql_num_rows($AUPC);
?>
<?php include('template/lbs/b_inside_top.php');?>

<!--
###################################################################################
#######################                                     #######################
#######################   M A I N   S E C T I O N   Start   #######################
#######################                                     #######################
###################################################################################
-->
<div id="central">
<h1><?php echo("$lang_80");?></h1>
<?php echo $row_AUPC['abcontent']; ?>
</div>
<!--
###################################################################################
#######################                                     #######################
#######################    M A I N   S E C T I O N   End    #######################
#######################                                     #######################
###################################################################################
-->
<?php include('template/lbs/b_inside_bottom.php');?>
<?php include('template/lbs/b_footer_tpl.php'); ?>
<?php
mysql_free_result($AUPC);
?>
