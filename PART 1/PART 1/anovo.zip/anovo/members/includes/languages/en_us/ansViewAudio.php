<?php
$LANG['pg_title'] = '';
$LANG['error_audio'] = 'Invalid Audio';
$LANG['close'] = 'Close';
?>