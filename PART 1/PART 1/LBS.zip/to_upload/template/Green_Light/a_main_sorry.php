<?php include('template/Green_Light/b_inside_top.php');?>
<td valign="top">
<!--
###################################################################################
#######################                                     #######################
#######################   M A I N   S E C T I O N   Start   #######################
#######################                                     #######################
###################################################################################
-->
<div class="page-header"><h1>Sorry</h1></div>

		<div style="margin-left:30px; margin-right:30px">
			<p>Sorry you were not able to complete your order<br />
          <br />
            <span class="style4">If you have any issues you would like to raise please <a href="<?php echo("$path");?>contact.php" class="style28">contact us</a>.</span><br />
        </p>
		</div>
<!--
###################################################################################
#######################                                     #######################
#######################    M A I N   S E C T I O N   End    #######################
#######################                                     #######################
###################################################################################
-->

<?php include('template/Green_Light/b_footer_tpl.php'); ?>