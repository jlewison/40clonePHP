<?php include('restrict.php'); include('../settings.php'); require_once('../Connections/apound.php'); ?>
<?php
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = (!get_magic_quotes_gpc()) ? addslashes($theValue) : $theValue;

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form1")) {
  $updateSQL = sprintf("UPDATE google_cse SET cse_main=%s, cse_on=%s WHERE cse_id=%s",
                       GetSQLValueString($_POST['cse_main'], "text"),
                       GetSQLValueString($_POST['cse_on'], "text"),
                       GetSQLValueString($_POST['cse_id'], "int"));

  mysql_select_db($database_apound, $apound);
  $Result1 = mysql_query($updateSQL, $apound) or die(mysql_error());
}

mysql_select_db($database_apound, $apound);
$query_gCSE = "SELECT * FROM google_cse";
$gCSE = mysql_query($query_gCSE, $apound) or die(mysql_error());
$row_gCSE = mysql_fetch_assoc($gCSE);
$totalRows_gCSE = mysql_num_rows($gCSE);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>Google Search Box - Link Bid Script Admin Panel</title>
<link rel="shortcut icon" href="img/favicon.ico" />
<link rel="stylesheet" type="text/css" href="admin.css" />
</head>

<body>
<?php $x = getenv("HTTP_HOST").getenv("REQUEST_URI"); ?>
<?php include('header_tpl.php'); ?>
<h2>Google Search Box Management</h2>
<table width="100%"  border="0" cellspacing="8" cellpadding="8">
  <tr>
    <td><form method="post" name="form1" action="<?php echo $editFormAction; ?>">
  <table align="center">
    <tr valign="baseline">
        <td nowrap class="style82 style67"><strong>Google CSE code: (<em>AJAX</em>)</strong></td>
    </tr>
    <tr valign="baseline">
      <td><textarea name="cse_main" cols="80" rows="20"><?php echo $row_gCSE['cse_main']; ?></textarea></td>
    </tr>
    <tr valign="baseline">
      <td align="left" valign="middle" nowrap><table>
          <tr>
            <td><strong>On/Off:</strong> </td>
			<td><input type="radio" name="cse_on" value="Y" <?php if (!(strcmp($row_gCSE['cse_on'],"Y"))) {echo "CHECKED";} ?>>
              Enable
                <input type="radio" name="cse_on" value="N" <?php if (!(strcmp($row_gCSE['cse_on'],"N"))) {echo "CHECKED";} ?>>
              Disable</td>
            </tr>
        </table>
		</td>
    </tr>
    <tr valign="baseline">
      <td><input type="submit" class="login-but" value="Update record"></td>
    </tr>
  </table>
  <input type="hidden" name="MM_update" value="form1">
  <input type="hidden" name="cse_id" value="<?php echo $row_gCSE['cse_id']; ?>">
</form></td>
  </tr>
</table>

<?php include('footer_tpl.php'); ?>
</body>
</html>
<?php
mysql_free_result($gCSE);
?>
