<?php

   class pluginConfigData extends Data {

      var $table = PLUGIN_CONFIG_TABLE;

      var $config = array (
  'table' => PLUGIN_CONFIG_TABLE,
  'idField' => 'id',
  );   

      function pluginConfigData() {
      
         $this->Data($this->config);
      }
   }

?>
