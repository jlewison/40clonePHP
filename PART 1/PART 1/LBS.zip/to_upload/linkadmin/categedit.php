<?php include('restrict.php'); include('../settings.php'); require_once('../Connections/apound.php'); ?>
<?php
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = (!get_magic_quotes_gpc()) ? addslashes($theValue) : $theValue;

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form1")) {
  $updateSQL = sprintf("UPDATE categorylisting SET categoryname=%s, categtitle=%s, categdescription=%s, categkeyword=%s, categenable=%s, categseoname=%s WHERE catlistid=%s",
                       GetSQLValueString($_POST['categoryname'], "text"),
                       GetSQLValueString($_POST['categtitle'], "text"),
                       GetSQLValueString($_POST['categdescription'], "text"),
                       GetSQLValueString($_POST['categkeyword'], "text"),
                       GetSQLValueString($_POST['categenable'], "text"),
                       GetSQLValueString($_POST['categseoname'], "text"),
                       GetSQLValueString($_POST['catlistid'], "int"));

  mysql_select_db($database_apound, $apound);
  $Result1 = mysql_query($updateSQL, $apound) or die(mysql_error());

  $updateGoTo = "manage_category.php?upd=Y";
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $updateGoTo));
}

$colname_Recordset1 = "1";
if (isset($_GET['id'])) {
  $colname_Recordset1 = (get_magic_quotes_gpc()) ? $_GET['id'] : addslashes($_GET['id']);
}
mysql_select_db($database_apound, $apound);
$query_Recordset1 = sprintf("SELECT * FROM categorylisting WHERE catlistid = %s", $colname_Recordset1);
$Recordset1 = mysql_query($query_Recordset1, $apound) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Edit Category - Link Bid Script Admin Panel</title>
<link rel="shortcut icon" href="img/favicon.ico" />
<link rel="stylesheet" type="text/css" href="admin.css" />
<style type="text/css">
<!--
.style84 {font-family: Verdana, Arial, Helvetica, sans-serif}
.style85 {font-size: 12px}
-->
</style>
</head>

<body>
<?php include('header_tpl.php'); ?>
<h2>Edit Category</h2>
<table width="770"  border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
  <tr>
    <td width="770"><?php $x = getenv("HTTP_HOST").getenv("REQUEST_URI"); echo("<font color=white>$x</font>"); ?></td>
  </tr>
</table>
<table width="770"  border="0" align="center" cellpadding="3" cellspacing="1" bgcolor="#FFFFFF">
  <tr>
    <td width="760" valign="top">
	
<?php $Xalready = $_GET[already]; if($Xalready == 'Y') { ?>
<div align="center" style="color:#FF0000"><br>CATEGORY NAME OR SUBCATEGORY SEO NAME ALREADY EXIST! The record not added, please select another SEO Name<br></div>
<?php } else {} ?>
      <form method="post" name="form1" action="<?php echo $editFormAction; ?>">
        <table align="center" cellpadding="3" cellspacing="1">
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">Category list ID:</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td class="style74"><?php echo $row_Recordset1['catlistid']; ?></td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">Category name:</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td><input name="categoryname" type="text" class="edtab" value="<?php echo $row_Recordset1['categoryname']; ?>" size="32"></td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">Category title:</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td><input name="categtitle" type="text" class="edtab" value="<?php echo $row_Recordset1['categtitle']; ?>" size="32"></td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">Category description:</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td><input name="categdescription" type="text" class="edtab" value="<?php echo $row_Recordset1['categdescription']; ?>" size="32"></td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">Category keyword:</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td><input name="categkeyword" type="text" class="edtab" value="<?php echo $row_Recordset1['categkeyword']; ?>" size="32"></td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">Category enable:</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td><select name="categenable" class="edtab">
                <option value="Y" <?php if (!(strcmp("Y", $row_Recordset1['categenable']))) {echo "SELECTED";} ?>>Enable</option>
                <option value="N" <?php if (!(strcmp("N", $row_Recordset1['categenable']))) {echo "SELECTED";} ?>>Disable</option>
              </select>
            </td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">Category SEO name:</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td><input name="categseoname" type="text" class="edtab" value="<?php echo $row_Recordset1['categseoname']; ?>" size="32"></td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td><input type="submit" class="login-but" value="Update record"></td>
          </tr>
        </table>
        <input type="hidden" name="MM_update" value="form1">
        <input type="hidden" name="catlistid" value="<?php echo $row_Recordset1['catlistid']; ?>">
      </form>
    </td>
  </tr>
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td colspan="3">&nbsp;</td>
    </tr>
</table>



<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td colspan="3" style="padding:10px;">

<?php
$whatcat = $row_Recordset1['catlistid'];
mysql_select_db($database_apound, $apound);
$query_Recordset1 = "SELECT * FROM categorylisting WHERE categorylisting.parentid = '$whatcat'";
$Recordset1 = mysql_query($query_Recordset1, $apound) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?>

<table width="100%" border="0" cellpadding="3" cellspacing="3">
        <tr bgcolor="#FFFFFF" class="style80">
          <td colspan="8"><a href="../linkadmin/sub_category_add.php?bascat=<?php echo("$whatcat"); ?>" class="style82">add new sub category</a> </td>
        </tr>
        <tr bgcolor="#FFFF00" class="style80">
          <td width="16%">ID</td>
          <td width="21%">category name</td>
          <td width="21%">SEO name</td>
          <td width="9%" align="center">Active?</td>
          <td width="8%" align="center">Edit</td>
          <td width="8%" align="center">Enable</td>
          <td width="8%" align="center">Disable</td>
          <td width="9%" align="center">Delete</td>
          </tr>
        <?php do { ?>
        <tr class="style70">
          <td><?php echo $row_Recordset1['catlistid']; ?></td>
          <td><?php echo $row_Recordset1['categoryname']; ?></td>
          <td><?php echo $row_Recordset1['categseoname']; ?></td>
          <td align="center"><?php $enabled = $row_Recordset1['categenable']; if($enabled == 'Y') { print'<img src="img/ico-live.gif" alt="Active" />'; } else { print'<img src="img/ico-pending.gif" alt="Pending" />'; }?></td>
          <td align="center"><a href="categedit.php?id=<?php echo $row_Recordset1['catlistid'];?>"><img src="img/ico-edit.gif" alt="Edit" /></a></td>
          <td align="center"><a href="categenable.php?id=<?php echo $row_Recordset1['catlistid'];?>"><?php if($enabled == 'Y') { print''; } else { print'<img src="img/ico-activate.png" alt="Activate" />'; }?></a></td>
          <td align="center"><a href="categdisable.php?id=<?php echo $row_Recordset1['catlistid'];?>"><?php if($enabled == 'Y') { print'<img src="img/ico-suspend.gif" alt="Suspend" />'; } else { print''; }?></a></td>
          <td align="center"><a href="categdelete.php?id=<?php echo $row_Recordset1['catlistid'];?>"><img src="img/ico-delete.gif" alt="Delete" /></a></td>
          </tr>
        <tr bgcolor="#CCCCCC" class="style70">
          <td height="1" colspan="8"></td>
        </tr>
        <?php } while ($row_Recordset1 = mysql_fetch_assoc($Recordset1)); ?>
</table>



	</td>
  </tr>
</table>




<?php include('footer_tpl.php'); ?>
</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
