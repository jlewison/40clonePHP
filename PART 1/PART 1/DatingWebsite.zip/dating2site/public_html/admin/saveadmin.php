<?php
if ( !defined( 'SMARTY_DIR' ) ) {
	include_once( '../init.php' );
}

include ( 'sessioninc.php' );

define( 'PAGE_ID', 'admin_mgt' );

if ( !checkAdminPermission( PAGE_ID ) ) {

	header( 'location: not_authorize.php' );
	exit;
}

$_SESSION['txtuname'] = $name = $_POST['txtuname'];

$pwd = $_POST['txtpassword'];

$_SESSION['txtfullname'] = $fullname = $_POST['txtfullname'];

$superuser = $_POST['txtsuperuser'];

$enabled = $_POST['txtenabled'];

$confpassword = $_POST['txtconfpassword'];
$err = 0 ;

if ( $name == '' ) {

	$err = USERNAME_BLANK;

} elseif ( $pwd == '' ) {

	$err = PASSWORD_BLANK;

} elseif ( $fullname == '' ) {

	$err = FULLNAME_BLANK;

} elseif ($pwd != $confpassword) {

	$err=18;

}

if ( $err > 0 ) {

	header( 'location: adminins.php?errid=' . $err );
	exit;

}

$sql = 'SELECT id FROM ! WHERE username = ? ';

$rid = $db->getOne( $sql, array( ADMIN_TABLE, $name ) );

$sqlc = 'SELECT count(*) as aacount from ! where username = ?';

$rowc = $db->getOne( $sqlc, array( USER_TABLE, $name, ) );

//$rowf = $db->getOne( $sqlc, array( 'phpbb_users', $name, ) );

if ( $rid > 0 or $rowc > 0  ) {

	header( 'location: adminins.php?errid='.ALREADY_EXISTS );
	exit;
}

$pwd = md5( $pwd );

$sql = 'INSERT INTO ! ( username, password, fullname, super_user, enabled ) VALUES ( ?, ?, ?, ?, ? )';

$db->query( $sql, array(ADMIN_TABLE, $name, $pwd, $fullname, $superuser, $enabled ) );

$lastid = $db->getOne('select id from ! where username = ?',array(ADMIN_TABLE, $name)) ;

$sql = "INSERT INTO ! (  adminid,  profie_approval, profile_mgt, change_pwd ) VALUES (  ?, ?, ?, ? )";

$db->query( $sql, array( ADMIN_RIGHTS_TABLE, $lastid, '1', '1', '1' ) );

if ($superuser == 'Y') {

	$admin_rights = $db->getRow('select * from ! where id = ?', array(ADMIN_RIGHTS_TABLE, 1));
	foreach ($admin_rights as $k => $vl) {
		if ($k != 'id' && $k != 'adminid') {
			$db->query('update ! set !=? where adminid=?',array(ADMIN_RIGHTS_TABLE, $k, $vl, $lastid));
		}
	}
}

$userlevel=2;

if ($superuser == 'Y') { $userlevel = 1; }
if ($config['forum_installed'] != '' && $config['forum_installed'] != 'None') {
	forum_saveadmin($name, $_POST['txtpassword'], $userlevel);
}
header( 'location: manageadmin.php' );

exit;

?>