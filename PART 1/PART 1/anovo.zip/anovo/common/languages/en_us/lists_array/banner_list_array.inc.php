<?php
$LANG_LIST_ARR['banner_list'] = array(
						'top_banner1' => 'Top Banner',
						'side_bar1' => 'Sidebar Banner 1',
						'side_bar2' => 'Sidebar Banner 2',
						'footer_banner1' => 'Footer Banner 1',
						'footer_banner2' => 'Footer Banner 2'
						);
?>