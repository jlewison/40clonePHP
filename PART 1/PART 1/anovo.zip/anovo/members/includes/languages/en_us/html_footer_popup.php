<!-- Footer begins -->
</div>
<!-- Footer -->

<div id="footer">
  <div id="subFooter">
    <h2>Miscellaneous Navigational Links</h2>
    <ul>
      <li class="rssfeeds"><a href="<? echo getUrl($CFG['site']['relative_url'] . 'rssFeeds.php', $CFG['site']['relative_url'] . 'rssfeeds/', false); ?>">RSS</a></li>
      <li class="faq"><a href="<? echo getUrl($CFG['site']['relative_url'] . 'staticPage.php?pg=faq', $CFG['site']['relative_url'] . 'faq/', false); ?>">Faq</a></li>
      <li class="privacy"><a href="<? echo getUrl($CFG['site']['relative_url'] . 'staticPage.php?pg=privacy', $CFG['site']['relative_url'] . 'privacy/', false); ?>">Privacy</a></li>
      <li class="terms"><a href="<? echo getUrl($CFG['site']['relative_url'] . 'staticPage.php?pg=terms', $CFG['site']['relative_url'] . 'terms/', false); ?>">Terms</a></li>
    </ul>
  </div>
  <p>&copy; 2008 <?php echo $CFG['site']['name']; ?>. All rights reserved.</p>
</div>
</div>
