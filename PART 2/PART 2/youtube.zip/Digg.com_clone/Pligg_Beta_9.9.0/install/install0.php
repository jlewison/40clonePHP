<?php
include('class_HTTPRequest.php');

if($_REQUEST['language'] == ''){
	header('Content-type: text/html; charset=UTF-8');
	$url = 'http://www.pligg.com/languages/getLanguageList.php?version=B990';
	$r = new CD_HTTPRequest($url);
	$data = $r->DownloadToString();
	if(strpos($data, '!--Pligg Language Select-->') > 0){
		echo $data;
	} else {
		echo 'We just tried to connect to Pligg.com to get a list of available languages but there was a problem.<br /><br /><a href = "install.php?language=local">Click to Continue in English</a>';
	}

	die();

} else {

	$language = $_REQUEST['language'];

	if($language != 'local'){
		$url = 'http://www.pligg.com/languages/getLanguageFile.php?type=installer&version=B990&language=' . $language;

		$r = new CD_HTTPRequest($url);
		$data = $r->DownloadToString();

		$filename = '../languages/installer_lang.php';

		$fh=fopen($filename,"w");

		if (fwrite($fh, $data)) {
			fclose($fh);
		} else {
			$url = 'http://www.pligg.com/languages/chmod_' . $language . '.php';
			$r = new CD_HTTPRequest($url);
			echo $r->DownloadToString();
			die();
		}
	}	

	$step = 1;

}
?>


