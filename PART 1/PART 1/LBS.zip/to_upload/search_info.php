<?php
if (isset($_POST['q'])) {
$q = mysql_real_escape_string($_POST[q]);
}
else {
$q = mysql_real_escape_string($_GET[q]);
}

//$q = mysql_real_escape_string($_POST[q]);
$currentPage = $_SERVER["PHP_SELF"];

require_once('Connections/apound.php');

$maxRows_SEARlista = 10;
$pageNum_SEARlista = 0;

if (isset($_GET['pageNum_SEARlista'])) {
  $pageNum_SEARlista = $_GET['pageNum_SEARlista'];
}

$startRow_SEARlista = $pageNum_SEARlista * $maxRows_SEARlista;

mysql_select_db($database_apound, $apound);
if($lexv == 'LIMITED') {
$query_SEARlista = "SELECT * FROM main WHERE (main.title LIKE '%$q%' OR main.descr1 LIKE '%$q%' OR main.descr2 LIKE '%$q%' OR main.tag1 LIKE '%$q%' OR main.tag2 LIKE '%$q%' OR main.tag3 LIKE '%$q%' OR main.tag4 LIKE '%$q%' OR main.tag5 LIKE '%$q%' OR main.tag6 LIKE '%$q%') AND TO_DAYS(NOW()) < TO_DAYS(stod) AND main.avail = 'Y' AND main.paid = 'Y' ORDER BY main.bid DESC";
}
else {
$query_SEARlista = "SELECT * FROM main WHERE (main.title LIKE '%$q%' OR main.descr1 LIKE '%$q%' OR main.descr2 LIKE '%$q%' OR main.tag1 LIKE '%$q%' OR main.tag2 LIKE '%$q%' OR main.tag3 LIKE '%$q%' OR main.tag4 LIKE '%$q%' OR main.tag5 LIKE '%$q%' OR main.tag6 LIKE '%$q%') AND main.avail = 'Y' AND main.paid = 'Y' ORDER BY main.bid DESC";
}
$query_limit_SEARlista = sprintf("%s LIMIT %d, %d", $query_SEARlista, $startRow_SEARlista, $maxRows_SEARlista);
$SEARlista = mysql_query($query_limit_SEARlista, $apound) or die(mysql_error());
$row_SEARlista = mysql_fetch_assoc($SEARlista);

if (isset($_GET['totalRows_SEARlista'])) {
  $totalRows_SEARlista = $_GET['totalRows_SEARlista'];
} else {
  $all_SEARlista = mysql_query($query_SEARlista);
  $totalRows_SEARlista = mysql_num_rows($all_SEARlista);
}

$totalPages_SEARlista = ceil($totalRows_SEARlista/$maxRows_SEARlista)-1;

$queryString_SEARlista = "";

if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_SEARlista") == false && 
        stristr($param, "totalRows_SEARlista") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_SEARlista = "&" . htmlentities(implode("&", $newParams));
  }
}

$queryString_SEARlista = sprintf("&totalRows_SEARlista=%d%s", $totalRows_SEARlista, $queryString_SEARlista);
$srf = "/";

$SEARcategory = $row_lista['maincategory'];

	mysql_select_db($database_apound, $apound);
		$query_LdetCAT = "SELECT * FROM categorylisting WHERE catlistid = '$SEARcategory'";
		$LdetCAT = mysql_query($query_LdetCAT, $apound) or die(mysql_error());
		$row_LdetCAT = mysql_fetch_assoc($LdetCAT);
		$totalRows_LdetCAT = mysql_num_rows($LdetCAT);
?>