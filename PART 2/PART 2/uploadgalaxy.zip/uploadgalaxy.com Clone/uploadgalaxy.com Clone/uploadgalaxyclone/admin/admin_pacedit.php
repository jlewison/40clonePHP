<?
include("../include/config.php");
if(!isset($_COOKIE['admin_uid'])) header("location: admin_index.php");
$action=$_REQUEST['action'];
switch($action)
{
case "del":
$pid=$_REQUEST['pacid'];
$qry="delete from premium_package where pid=$pid";
$conn->execute($qry);
break;
case "Update":
$pid=$_REQUEST['pacid'];
$pn=$_REQUEST['n'];
$pd=$_REQUEST['d'];
$pp=number_format($_REQUEST['p'],2,'.','');
$qry="update premium_package set pacname='$pn',pactime=$pd,pacrate=$pp where pid=$pid";
//echo $qry;
$conn->execute($qry);
break;
case "Include":
$pid=$_REQUEST['pacid'];
$pn=$_REQUEST['n'];
$pd=$_REQUEST['d'];
$pp=$_REQUEST['p'];
$qry="insert into premium_package set pacname='$pn',pactime=$pd,pacrate=$pp";
$conn->execute($qry);
break;
default:
break;
}
header("location: admin_index.php?change=Packages");
?>
