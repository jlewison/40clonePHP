<?
include "config.php";
?>
<html>
<head>
<title>Felhaszn�l�si Felt�telek</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel='shortcut icon' href='favicon.ico'>
<link href="Style2.css" rel="stylesheet" type="text/css">
</head>
<center>
<body bgcolor='#000000'>
<br>
<table align='center' border='2' cellpadding='2' cellspacing='2' width='740' bgcolor='F2F2F3'>
<tr><td><div align="center"><img src="logo.png" height="123" width="358" alt=" ">
      <center>
    <body bgcolor='F2F2F3'>
      <br>
    <br>
        </div>
</div>
  <p align="center">
&nbsp;&nbsp;<OBJECT ID=metal-1-layer-modern-color classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"
codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0"
WIDTH=300 HEIGHT=22 STYLE="">
<PARAM NAME="flashvars" value="ModThisName">
<PARAM NAME="movie" VALUE="a.swf">
<PARAM NAME="menu" VALUE="false">
<PARAM NAME="quality" VALUE="best">
<PARAM NAME="scale" VALUE="noscale">
<PARAM NAME="salign" VALUE="LT">
<PARAM NAME="wmode" VALUE="transparent">
<param name="bgcolor" value="#F2F2F3">
<EMBED src="a.swf" menu="false" quality="best" scale="noscale" salign="LT"
 WIDTH=300 HEIGHT=22 bgcolor="#000000" wmode="transparent"  TYPE="application/x-shockwave-flash" PLUGINSPAGE="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash"></EMBED>
</OBJECT><br>
<br>
Haszn&aacute;lati Felt&eacute;telek<br>
<hr>
<div align="center"><b></b>
  
  <center><br>
  Miel&#337;tt k&eacute;pet t&ouml;ltesz fel... <br>
  <table width="600" height="282" border="1">
    <tr>
      <th height="74" scope="col"><div align="center"><strong>Lehet&#337;leg a legkisebb f&aacute;jlm&eacute;ret&#369; k&eacute;pet t&ouml;lts fel, hogy ne foglalja le feleslegesen a szervet. (pl.: ha BMP-be mented, akkor 1MB, de ha PNG-be mented akkor 200KB) </strong></div></th>
    </tr>
    <tr>
      <td height="52"><div align="center"><strong>B&aacute;rmilyen k&eacute;pet felt&ouml;lthetsz, legyen az Porn&oacute;, J&aacute;t&eacute;kb&oacute;l k&eacute;p, magadr&oacute;l egy Fot&oacute;... </strong></div></td>
    </tr>
    <tr>
      <td height="54"><div align="center"><strong>Korl&aacute;tlan sz&aacute;m&uacute; k&eacute;pet t&ouml;lthetsz fel. az adatforgalmat neked kell kifizetned. </strong></div></td>
    </tr>
    <tr>
      <td height="69"><div align="center"><strong>Ha valaki &iacute;zl&eacute;stelen, &eacute;s m&aacute;sokat s&eacute;rt&#337; k&eacute;pet tal&aacute;l, az k&uuml;ldje el e-mailben a linkj&eacute;t:<br>
        hlfan@citromail.hu
</strong></div></td>
    </tr>
  </table>
  <p><a href="mailto:gabiking@gmail.com">ModThisName</a><br>
       <span class="asd">(c) 2006 <a href='http://www.modthisname.spiderhost.hu/forum'>ModThisName - BlackTorrent</a></p>
</div></td></tr></table>
