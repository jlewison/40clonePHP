<?
	include("include/common.php");
	include("include/header.php");
?>
	<table width="85%" border="0" align="center" cellpadding="0" cellspacing="0">
	<tr>
		<td>
		</td>
	</tr>
	<tr>
		<td>
			<b>Rules for <?=$sitename?></b><br><br>
			<p>
				<?=$sitename?> reserves the right to remove any file for any reason whatsoever.
				Specifically, any file uploaded that is pornographic in nature, infringes upon
				copyrights not held by the uploader, is illegal or violates any laws, will be
				immediately deleted and the IP address of the uploaded reported to authorities.
				Violating these terms will result result in termination of your ability to 
				upload further.
			</p>
			<p>
				Do not link or embed images or files hosted on this service into a large-scale, non-
				forum website. You may link or embed images or files hosted on this service in 
				personal sites, message boards, and individual online auctions.
			</p>
			<p>
				We reserve the right to ban any 
				individual uploader or website domain
				from using our servies for any reason.
			</p>
			<p>
				All files uploaded are copyright &copy; their respective owners
			</p>
		</td>
	</tr>
	</table>
<?
	include("include/footer.php");
?>