<?php
$LANG['forum_title'] = 'Add New Forum Title';
$LANG['forumslinks_header'] = 'Forums';
$LANG['forumslinks_list_forums'] = 'List Forums';
$LANG['forumslinks_add_title'] = 'Add Forum Title';
$LANG['forumslinks_most_topics'] = 'Most Topics';
$LANG['forumslinks_most_responses'] = 'Most Responses';
$LANG['forumslinks_search_forums'] = 'Search Forums';
$LANG['forum_back_index'] = 'Back to Forum Index';
$LANG['forum_title_add'] = 'Forum Title';
$LANG['forum_status'] = 'Forum Status';
$LANG['forum_status_information'] = 'Note: select Inactive if you want to delete an existing category';
$LANG['forum_description'] = 'Description';
$LANG['forum_create_title'] = 'Add New Title';
$LANG['forum_edit_title'] = 'Update';
$LANG['forum_cancel'] = 'Cancel';
$LANG['forum_active'] = 'Active';
$LANG['forum_inactive'] = 'Inactive';
$LANG['forum_success'] = 'Updated Successfully';
$LANG['forum_err_tip_compulsory'] = 'Compulsory';
$LANG['forum_err_tip_characters'] = 'Characters Only';
$LANG['forum_err_tip_forum_title_exists'] = 'Forum title already exists.';
$LANG['forum_err_tip_invalid_forum_id'] = 'Invalid Forum ID.';
$LANG['forum_tbl_summary'] = 'Container to create fourm title';
?>