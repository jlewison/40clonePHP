<?php

   class mailboxData extends Data {

      var $table = MAILBOX_TABLE;

      var $config = array (
  'table' => MAILBOX_TABLE,
  'idField' => 'id',
  'addedMsg' => 'Osdate Mailbox %s Added',
  'added_err' => 'Can\\\'t Add Osdate Mailbox',
  'editMsg' => 'Osdate Mailbox %s Updated',
  'editErr' => 'Can\\\'t Update Osdate Mailbox',
  'delErr' => 'Can\\\'t Delete Osdate Mailbox',
  'delMsg' => 'Osdate Mailbox %s Deleted',
  'blankErr' => 'Osdate Mailbox Empty',
  'fields' => 
  array (
    'owner' => 
    array (
      'name' => 'owner',
      'description' => 'Owner',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'senderid' => 
    array (
      'name' => 'senderid',
      'description' => 'Senderid',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'recipientid' => 
    array (
      'name' => 'recipientid',
      'description' => 'Recipientid',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'subject' => 
    array (
      'name' => 'subject',
      'description' => 'Subject',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 254,
      'blank_ok' => 1,
      'duplicate_ok' => 1,
    ),
    'message' => 
    array (
      'name' => 'message',
      'description' => 'Message',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 65535,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'flag' => 
    array (
      'name' => 'flag',
      'description' => 'Flag',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 1,
      'blank_ok' => 1,
      'duplicate_ok' => 1,
    ),
    'flagread' => 
    array (
      'name' => 'flagread',
      'description' => 'Flagread',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 1,
      'blank_ok' => 1,
      'duplicate_ok' => 1,
    ),
    'sendtime' => 
    array (
      'name' => 'sendtime',
      'description' => 'Sendtime',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 1,
      'duplicate_ok' => 1,
    ),
    'flagdelete' => 
    array (
      'name' => 'flagdelete',
      'description' => 'Flagdelete',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 1,
      'blank_ok' => 1,
      'duplicate_ok' => 1,
    ),
    'replied' => 
    array (
      'name' => 'replied',
      'description' => 'Replied',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 1,
      'blank_ok' => 1,
      'duplicate_ok' => 1,
    ),
    'folder' => 
    array (
      'name' => 'folder',
      'description' => 'Folder',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 10,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'notifysender' => 
    array (
      'name' => 'notifysender',
      'description' => 'Notifysender',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 1,
      'blank_ok' => 1,
      'duplicate_ok' => 1,
    ),
  ),
);   

      function mailboxData() {
      
         $this->Data($this->config);
      }
   }

?>
