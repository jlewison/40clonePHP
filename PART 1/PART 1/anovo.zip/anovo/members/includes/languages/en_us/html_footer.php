<!-- Footer begins -->
</div></div>
<!-- Footer -->
<div id="footer">
<div class="clsFooterBanner">  <p><?php echo getAdvertisement('footer_banner1'); ?></p>
  <p><?php echo getAdvertisement('footer_banner2'); ?></p></div>
  <div id="subFooter">
    <h2>Miscellaneous Navigational Links</h2>
    <ul>
      <li class="rssfeeds"><a href="<? echo getUrl($CFG['site']['relative_url'] . 'rssFeeds.php', $CFG['site']['relative_url'] . 'rssfeeds/', false); ?>">RSS</a></li>
      <li class="faq"><a href="<? echo getUrl($CFG['site']['relative_url'] . 'staticPage.php?pg=faq', $CFG['site']['relative_url'] . 'faq/', false); ?>">Faq</a></li>
      <li class="privacy"><a href="<? echo getUrl($CFG['site']['relative_url'] . 'staticPage.php?pg=privacy', $CFG['site']['relative_url'] . 'privacy/', false); ?>">Privacy</a></li>
      <li class="terms"><a href="<? echo getUrl($CFG['site']['relative_url'] . 'staticPage.php?pg=terms', $CFG['site']['relative_url'] . 'terms/', false); ?>">Terms</a></li>
    </ul>
  </div>
  <p>&copy; 2008 <?php echo $CFG['site']['name']; ?>. All rights reserved.</p>
  <p><?php echo $CFG['site']['name']; ?>! does not evaluate or guarantee the accuracy of any <?php echo $CFG['site']['name']; ?>! content. <a href="<? echo getUrl($CFG['site']['relative_url'] . 'staticPage.php?pg=terms', $CFG['site']['relative_url'] . 'terms/', false); ?>">Click here</a> for the Full Disclaimer.</p>
</div>
</div>
</body>
<script language="javascript" type="text/javascript">
	var toggleNavBar = function(){
		var heightVal = document.getElementById("main").offsetHeight;
		heightVal = heightVal+'';
		if (obj = document.getElementById('selLinkShow')){
			obj.style.height = heightVal+"px";
		}
		if (obj = document.getElementById('selLinkHide')){
			obj.style.height = heightVal+"px";
		}
	}
    toggleNavBar();
</script>
<?php
if (chkToolTipAllowed())
{
?>
<script language="javascript" type="text/javascript">
/*-------------------Top tip ---------------------------*/
	$$("form input.help").each( function(input) {
		new Tooltip(input, {backgroundColor: "#FC9", borderColor: "#C96",
		textColor: "#000", textShadowColor: "#FFF"});
	});
</script>
<?php
}
?>
