<?
include("include/config.php");
$item_name=$_COOKIE['item_name'];
$date=$_COOKIE['date'];
STemplate::assign("date",$date);
STemplate::display("payok.tpl");
?>
