<?php echo("
function gurl(l){ 
	document.location.href='/'+l+'/';
}

function dodiv() { 
	var frm = document.pgfrm; 
	var tt=frm.keyword.value; 
	var dd1=frm.descr1.value; 
	var dd2=frm.descr2.value; 
	var dd3=frm.url.value; 
	var bbd=frm.bid.value; 
	
	if (tt) { document.getElementById('kw').innerHTML=tt; } 
	else {  document.getElementById('kw').innerHTML=");?><?php echo('"Example Title"; } 
	
	if (dd1) { document.getElementById(');?><?php echo("'d1').innerHTML=dd1; } 
	else {  document.getElementById(");?><?php echo("'d1').innerHTML=");?><?php echo('"Description line 1 sample"; } 
	
	if (dd3) { document.getElementById(');?><?php echo("'d3').innerHTML=dd3; } 
	
	else {  document.getElementById('d3').innerHTML=");?><?php echo('"http://your_site.com/"; } 
	
	if (bbd) { document.getElementById(');?><?php echo("'bidd').innerHTML=bbd; } 
	else {  document.getElementById('bidd').innerHTML=");?><?php echo('"');?><?php echo("$minbid");?><?php echo('"; }
} 
	
function chknum(evt) { 
	var charCode = (evt.which) ? evt.which : event.keyCode; 
	
	if (charCode > 31 && (charCode < 48 || charCode > 57)) return false; return true;
} 
	
function chkfrm() { 
	var frm = document.pgfrm; 
	
	if (!frm.selectc.value.replace(/^\s*|\s*$/g,"")) { alert("Please selest category for your listing"); frm.selectc.focus(); return false; } 
	
	if (!frm.email.value.replace(/^\s*|\s*$/g,"")) { alert("You must provide an e-mail address."); frm.email.focus(); return false; } 
	
	if (!frm.url.value.replace(/^\s*|\s*$/g,"") || frm.url.value.replace(/^\s*|\s*$/g,"") == "http://") { alert("You must provide a website URL."); frm.url.focus(); return false; } 
	
	if (!frm.keyword.value.replace(/^\s*|\s*$/g,"")) { alert("Please enter the title for your listing"); frm.keyword.focus(); return false; } 
	
	if (!frm.descr1.value.replace(/^\s*|\s*$/g,"")) { alert("You must provide a brief description."); frm.descr1.focus(); return false; } 
	
	if (!frm.descr2.value.replace(/^\s*|\s*$/g,"")) { alert("You must provide an extended description."); frm.descr2.focus(); return false; } 
	
	if (!frm.bid.value.replace(/^\s*|\s*$/g,"")) { alert("You must provide a bid amount."); frm.bid.focus(); return false; } 
	
	if (frm.bid.value.replace(/^\s*|\s*$/g,"") < ');?><?php echo("$minbid");?><?php echo(') { alert("Your initial contribution must be at least')?> <?php echo("$currency");?><?php echo("$minbid");?><?php echo('"); frm.bid.focus(); return false; }
	
	if (!frm.gm_str.value.replace(/^\s*|\s*$/g,"")) { alert("You must provide a street name."); frm.gm_str.focus(); return false; } 
	if (!frm.gm_str_nr.value.replace(/^\s*|\s*$/g,"")) { alert("You must provide a street number."); frm.gm_str_nr.focus(); return false; } 
	if (!frm.gm_city.value.replace(/^\s*|\s*$/g,"")) { alert("You must provide a city."); frm.gm_city.focus(); return false; } 
	if (!frm.gm_county.value.replace(/^\s*|\s*$/g,"")) { alert("You must provide a county."); frm.gm_county.focus(); return false; } 
	if (!frm.gm_country.value.replace(/^\s*|\s*$/g,"")) { alert("You must provide a country."); frm.gm_country.focus(); return false; } 
}');?>