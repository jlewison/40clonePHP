<?php include('restrict.php');
require_once('../Connections/apound.php');
$id = $_GET[id];
$categenable = "N";
$link = mysql_pconnect($hostname_apound,$username_apound,$password_apound);
mysql_select_db($database_apound);
mysql_query("UPDATE categorylisting SET categenable='$categenable' WHERE catlistid='$id'");
header("Location: manage_category.php");?>