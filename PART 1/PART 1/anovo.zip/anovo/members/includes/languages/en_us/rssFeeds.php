<?php
$LANG['feed_title'] = 'RSS feeds';
$LANG['feed_tbl'] = 'Rss Feed list table';
$LANG['feed_recent_questions'] = 'Recent Questions';
$LANG['feed_popular_questions'] = 'Popular Questions';
$LANG['feed_recent_forums'] = 'Recent Forums';
$LANG['feed_recent_blogs'] = 'Recent Blogs';
?>