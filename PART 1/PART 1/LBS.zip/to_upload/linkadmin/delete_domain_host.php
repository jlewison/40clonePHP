<?php
include('restrict.php');
require_once('../Connections/apound.php');

$do_do = $_GET[do_do];

	$link = mysql_pconnect($hostname_apound,$username_apound,$password_apound);
		mysql_select_db($database_apound);
			mysql_query("DELETE FROM do_ban WHERE do_do='$do_do'");

header("Location: domain_host_ban.php?upd=Y");
?>