<?php

$profile_questions['1']['question'] = 'Quel est votre statut civil ?';

$profile_questions['1']['description'] = '';

$profile_questions['1']['guideline'] = '';

$profile_questions['1']['extsearchhead'] = 'Statut civil';

$profile_questions['1']['1'] = 'C�libataire';

$profile_questions['1']['2'] = 'Marri�';

$profile_questions['1']['3'] = 'Veuf';

$profile_questions['1']['67'] = 'En couple';

$profile_questions['1']['68'] = 'S�par�';

$profile_questions['1']['69'] = 'Divorc�';

$profile_questions['2']['question'] = 'Quelle ethnie vous d�crit le mieux ?';

$profile_questions['2']['description'] = '';

$profile_questions['2']['guideline'] = '';

$profile_questions['2']['extsearchhead'] = 'Ethnie';

$profile_questions['2']['80'] = 'Africain Am�ricain';

$profile_questions['2']['10018'] = 'Asiatique';

$profile_questions['2']['10019'] = 'Noir / Africain';

$profile_questions['2']['10020'] = 'Caucasian (blanc)';

$profile_questions['2']['10021'] = 'Est Indien';

$profile_questions['2']['10022'] = 'Hispanique / Latino';

$profile_questions['2']['10023'] = 'Inter-racial';

$profile_questions['2']['10024'] = 'Moyen-Orient';

$profile_questions['2']['10025'] = 'Natif Am�ricain';

$profile_questions['2']['10026'] = 'Iles du pacifique';

$profile_questions['2']['10027'] = 'Autre';

$profile_questions['3']['question'] = 'Quelles sont vos croyances ?';

$profile_questions['3']['description'] = '';

$profile_questions['3']['guideline'] = '';

$profile_questions['3']['extsearchhead'] = 'Religion';

$profile_questions['3']['10001'] = 'Christianisme';

$profile_questions['3']['10002'] = 'Christianisme / Catholique';

$profile_questions['3']['10003'] = 'Christianisme / LDS';

$profile_questions['3']['10004'] = 'Christianisme / Protestant';

$profile_questions['3']['10005'] = 'Christianisme / Autre';

$profile_questions['3']['10006'] = 'Boudhiste / Taoiste';

$profile_questions['3']['10007'] = 'Indou';

$profile_questions['3']['10008'] = 'Islam';

$profile_questions['3']['10009'] = 'Juif';

$profile_questions['3']['10010'] = 'Pagan';

$profile_questions['3']['10011'] = 'Ath�isme';

$profile_questions['3']['10012'] = 'Aucune / Agnostique';

$profile_questions['3']['10014'] = 'Scientologie';

$profile_questions['3']['10015'] = 'Spirituel mais pas religieux';

$profile_questions['3']['10016'] = 'Autre';

$profile_questions['4']['question'] = 'Quels sont vos loisirs ?';

$profile_questions['4']['description'] = 'Ici vous pouvez d�crire vos activit�s plus en profondeur. Si vous aimez le sport, �tes-vous membre dans une ligue ? Si vous aimez le cin�ma, quel genre appr�ciez-vous?.';

$profile_questions['4']['guideline'] = '';

$profile_questions['4']['extsearchhead'] = 'Passe temps';

$profile_questions['5']['question'] = 'Quelle est votre grandeur ?';

$profile_questions['5']['description'] = '';

$profile_questions['5']['guideline'] = '';

$profile_questions['5']['extsearchhead'] = 'Grandeur';

$profile_questions['5']['152'] = '4\' 7\" (140 cm) ou moins';

$profile_questions['5']['153'] = '4\' 8\" (142 cm)';

$profile_questions['5']['154'] = '4\' 9\" (145 cm)';

$profile_questions['5']['155'] = '4\' 10\" (147 cm)';

$profile_questions['5']['156'] = '4\' 11\" (150 cm)';

$profile_questions['5']['157'] = '5\'  0\" (152 cm)';

$profile_questions['5']['158'] = '5\' 1\" (155 cm)';

$profile_questions['5']['160'] = '5\' 2\" (157 cm)';

$profile_questions['5']['161'] = '5\' 3\" (160 cm)';

$profile_questions['5']['162'] = '5\' 4\" (162 cm)';

$profile_questions['5']['163'] = '5\' 5\" (165 cm)';

$profile_questions['5']['164'] = '5\' 6\" (167 cm)';

$profile_questions['5']['165'] = '5\' 7\" (170 cm)';

$profile_questions['5']['166'] = '5\' 8\" (173 cm)';

$profile_questions['5']['167'] = '5\' 9\" (175 cm)';

$profile_questions['5']['168'] = '5\' 10\" (178 cm)';

$profile_questions['5']['169'] = '5\' 11\" (180 cm)';

$profile_questions['5']['170'] = '6\' 0\" (183 cm)';

$profile_questions['5']['171'] = '6\' 1\" (185 cm)';

$profile_questions['5']['172'] = '6\' 2\" (188 cm)';

$profile_questions['5']['173'] = '6\' 3\" (190 cm)';

$profile_questions['5']['174'] = '6\' 4\" (193 cm)';

$profile_questions['5']['175'] = '6\' 5\" (196 cm)';

$profile_questions['5']['176'] = '6\' 6\" (198 cm)';

$profile_questions['5']['177'] = '6\' 7\" (201 cm)';

$profile_questions['5']['178'] = '6\' 8\" (203 cm)';

$profile_questions['5']['179'] = '6\' 9\" (206 cm)';

$profile_questions['5']['180'] = '6\' 10\" (208 cm)';

$profile_questions['5']['181'] = '6\' 11\" (211 cm)';

$profile_questions['5']['182'] = '7\' 0\" (213 cm)';

$profile_questions['5']['183'] = '7\' 1\" (216 cm)';

$profile_questions['5']['184'] = '7\' 2\" (218 cm)';

$profile_questions['5']['185'] = '7\' 3\" (221 cm)';

$profile_questions['5']['186'] = '7\' 4\" (224 cm)';

$profile_questions['5']['187'] = '7\' 5\" (226 cm)';

$profile_questions['5']['188'] = '7\' 6\" (229 cm)';

$profile_questions['5']['189'] = '7\' 7\" (231 cm)';

$profile_questions['5']['190'] = '7\' 8\" (234 cm)';

$profile_questions['5']['191'] = '7\' 9\" (236 cm)';

$profile_questions['5']['192'] = '7\' 10\"\' (239 cm) ou plus';

$profile_questions['6']['question'] = 'Quest-ce qui d�crit le mieux votre apparence physique ?';

$profile_questions['6']['description'] = '';

$profile_questions['6']['guideline'] = '';

$profile_questions['6']['extsearchhead'] = 'Apparence physique';

$profile_questions['6']['10028'] = 'Mince';

$profile_questions['6']['10029'] = 'D�licat';

$profile_questions['6']['10030'] = 'Moyen';

$profile_questions['6']['10031'] = 'Juste parfait';

$profile_questions['6']['10032'] = 'Bien dans ma peau';

$profile_questions['6']['10033'] = 'Athl�tique';

$profile_questions['6']['10034'] = 'Muscl�';

$profile_questions['6']['10035'] = 'Quelques livres en trop';

$profile_questions['6']['10036'] = 'Envelopp�';

$profile_questions['6']['10037'] = 'Gras';

$profile_questions['6']['10039'] = 'Taille forte';

$profile_questions['6']['10040'] = 'Ob�se';

$profile_questions['7']['question'] = 'Quel est votre signe ?';

$profile_questions['7']['description'] = '';

$profile_questions['7']['guideline'] = '';

$profile_questions['7']['extsearchhead'] = 'Signe zodiaque';

$profile_questions['7']['211'] = 'Verseau';

$profile_questions['7']['212'] = 'Tauraux';

$profile_questions['7']['213'] = 'Gemaux';

$profile_questions['7']['214'] = 'Cancer';

$profile_questions['7']['215'] = 'Lion';

$profile_questions['7']['216'] = 'Vierge';

$profile_questions['7']['217'] = 'Balance';

$profile_questions['7']['218'] = 'Scorpion';

$profile_questions['7']['219'] = 'Sagittaire';

$profile_questions['7']['220'] = 'Capricorne';

$profile_questions['7']['221'] = 'Poisson';

$profile_questions['7']['222'] = 'B�lier';

$profile_questions['8']['question'] = 'Ce qui d�crit le mieux la couleur de vos yeux ?';

$profile_questions['8']['description'] = '';

$profile_questions['8']['guideline'] = '';

$profile_questions['8']['extsearchhead'] = 'Couleur des yeux';

$profile_questions['8']['23'] = 'Noir';

$profile_questions['8']['24'] = 'Bleu';

$profile_questions['8']['25'] = 'Brun';

$profile_questions['8']['93'] = 'Gris';

$profile_questions['8']['94'] = 'Vert';

$profile_questions['8']['95'] = 'Chataigne';

$profile_questions['9']['question'] = 'Quelle est la couleur de vos cheveux ?';

$profile_questions['9']['description'] = '';

$profile_questions['9']['guideline'] = '';

$profile_questions['9']['extsearchhead'] = 'Couleur des cheveux';

$profile_questions['9']['26'] = 'Noir';

$profile_questions['9']['27'] = 'Brun';

$profile_questions['9']['28'] = 'Brun noir';

$profile_questions['9']['96'] = 'Brun roux';

$profile_questions['9']['97'] = 'Blond';

$profile_questions['9']['98'] = 'Brun p�le';

$profile_questions['9']['99'] = 'Brun fonc�';

$profile_questions['9']['100'] = 'Roux';

$profile_questions['9']['101'] = 'Blanc/Gris';

$profile_questions['9']['102'] = 'Chauve';

$profile_questions['9']['103'] = 'Grisonnant';

$profile_questions['10']['question'] = 'Avez-vous des arts corporels ?';

$profile_questions['10']['description'] = '';

$profile_questions['10']['guideline'] = '';

$profile_questions['10']['extsearchhead'] = 'Art corporel';

$profile_questions['10']['29'] = 'Tattoo strat�giquement plac�';

$profile_questions['10']['30'] = 'Tattoo visible';

$profile_questions['10']['31'] = '"Dents pointues';

$profile_questions['10']['223'] = 'Marqu�';

$profile_questions['10']['224'] = 'Tattou� au complet';

$profile_questions['10']['225'] = 'Cicatrices';

$profile_questions['10']['226'] = 'Perc� mais seulement les oreilles';

$profile_questions['10']['227'] = 'Je n\y penserais m�me pas';

$profile_questions['10']['228'] = 'Boucle au nombril';

$profile_questions['10']['229'] = 'Piercings vous saurez si vous le m�ritez';

$profile_questions['11']['question'] = 'Quest-ce qui vous d�crit le mieux ?';

$profile_questions['11']['description'] = '';

$profile_questions['11']['guideline'] = '';

$profile_questions['11']['extsearchhead'] = 'Points forts';

$profile_questions['11']['10068'] = 'Bras';

$profile_questions['11']['10069'] = 'Dos';

$profile_questions['11']['10070'] = 'Nombril';

$profile_questions['11']['10071'] = 'Fesses';

$profile_questions['11']['10072'] = 'Torse';

$profile_questions['11']['10073'] = 'Posture';

$profile_questions['11']['10074'] = 'Oreilles';

$profile_questions['11']['10075'] = 'Yeux';

$profile_questions['11']['10076'] = 'Pieds';

$profile_questions['11']['10077'] = 'Cheveux';

$profile_questions['11']['10078'] = 'Mains';

$profile_questions['11']['10079'] = '�paules';

$profile_questions['11']['10080'] = 'Jambes';

$profile_questions['11']['10081'] = 'L�vres';

$profile_questions['11']['10082'] = 'Nez';

$profile_questions['11']['10083'] = 'Cuisses';

$profile_questions['11']['10084'] = 'Hanches';

$profile_questions['11']['10085'] = 'Autre';

$profile_questions['12']['question'] = 'Endroits favoris de votre secteur ou destinations voyages ?';

$profile_questions['12']['description'] = 'Une fois votre partenaire trouv�, Ou aimeriez-vous aller avec cette personne ? Quel est votre endroit pr�f�r� pour aller manger ?';

$profile_questions['12']['guideline'] = '';

$profile_questions['12']['extsearchhead'] = 'Endroits favoris';

$profile_questions['13']['question'] = 'Quels sont vos sports et exercices favoris ?';

$profile_questions['13']['description'] = '';

$profile_questions['13']['guideline'] = '';

$profile_questions['13']['extsearchhead'] = 'Sports';

$profile_questions['13']['34'] = 'A�robie';

$profile_questions['13']['35'] = 'Course automobile / Motorcross';

$profile_questions['13']['36'] = 'Baseball';

$profile_questions['13']['37'] = 'Basketball';

$profile_questions['13']['372'] = 'Billiard / Pool';

$profile_questions['13']['373'] = 'Bowling';

$profile_questions['13']['374'] = 'V�lo';

$profile_questions['13']['375'] = 'Danse';

$profile_questions['13']['376'] = 'Football';

$profile_questions['13']['377'] = 'Golf';

$profile_questions['13']['378'] = 'Arts martiaux';

$profile_questions['13']['379'] = 'Course � pieds';

$profile_questions['13']['380'] = 'Ski';

$profile_questions['13']['381'] = 'Football';

$profile_questions['13']['382'] = 'Nage';

$profile_questions['13']['383'] = 'Tennis / Sports de raquettes';

$profile_questions['13']['384'] = 'Volleyball';

$profile_questions['13']['385'] = 'Marche / Randonn�e';

$profile_questions['13']['386'] = 'Musculation';

$profile_questions['13']['387'] = 'Yoga';

$profile_questions['14']['question'] = 'Favoris ?';

$profile_questions['14']['description'] = 'Tout le monde a des favoris. Quel est votre repas  pr�f�r� ? Votre couleur pr�f�r�e ?';

$profile_questions['14']['guideline'] = 'r�pondez selon cette direction';

$profile_questions['14']['extsearchhead'] = 'Favoris';

$profile_questions['15']['question'] = 'Quelle est la derni�re chose que vous avez lu ?';

$profile_questions['15']['description'] = 'Soit un journal, un roman, un magazine ou une painte de lait, parlez-nous de votre derni�re d�couverte litt�raire.';

$profile_questions['15']['guideline'] = '';

$profile_questions['15']['extsearchhead'] = 'Derni�re lecture';

$profile_questions['16']['question'] = 'Quels sont les int�r�ts communs que vous aimeriez partager avec les autres usagers ?';

$profile_questions['16']['description'] = '';

$profile_questions['16']['guideline'] = '';

$profile_questions['16']['extsearchhead'] = 'Int�r�ts communs';

$profile_questions['16']['38'] = 'Avoir des papillons';

$profile_questions['16']['39'] = 'Bo�te de nuits';

$profile_questions['16']['40'] = 'Camping';

$profile_questions['16']['41'] = 'Cuisine';

$profile_questions['16']['388'] = 'Relations d\'affaires';

$profile_questions['16']['389'] = 'Groupe de lecture / Discussion';

$profile_questions['16']['390'] = 'Caf� et conversations';

$profile_questions['16']['391'] = 'Aller souper';

$profile_questions['16']['392'] = 'P�che / Chasse';

$profile_questions['16']['393'] = 'Jardinage / Entretien paysager';

$profile_questions['16']['394'] = 'Passes temps et artisanat';

$profile_questions['16']['395'] = 'Filmes / Vid�os';

$profile_questions['16']['396'] = 'Art et mus�s';

$profile_questions['16']['397'] = 'Musique et concerts';

$profile_questions['16']['398'] = 'Art cr�atif';

$profile_questions['16']['399'] = 'Jouer aux cartes';

$profile_questions['16']['400'] = 'Pratiquer des sports';

$profile_questions['16']['401'] = 'Int�r�ts politiques';

$profile_questions['16']['402'] = 'Religion / Spiritualit�';

$profile_questions['16']['403'] = 'Magasinage / Antiquit�s';

$profile_questions['17']['question'] = 'Comment d�cririez-vous votre sens de l\'humour ?';

$profile_questions['17']['description'] = '';

$profile_questions['17']['guideline'] = '';

$profile_questions['17']['extsearchhead'] = 'Sens de l\'humour';

$profile_questions['17']['42'] = 'Je n\'ai aucun sens de l\'humour';

$profile_questions['17']['43'] = 'Je ris quand c\'est vraiment dr�le';

$profile_questions['17']['367'] = 'J\'aime bien taquiner';

$profile_questions['17']['368'] = 'Je ris souvent int�rieurement';

$profile_questions['17']['369'] = 'Sarcastique';

$profile_questions['17']['370'] = 'Je suis celui qui met de l\'action partout ou je passe';

$profile_questions['17']['371'] = 'Amical, je souris toujours';

$profile_questions['18']['question'] = 'Vos fr�quences d\'exercices ?';

$profile_questions['18']['description'] = '';

$profile_questions['18']['guideline'] = '';

$profile_questions['18']['extsearchhead'] = 'Exercice';

$profile_questions['18']['10086'] = '2 fois par jour';

$profile_questions['18']['10087'] = 'Chaque jours';

$profile_questions['18']['10088'] = 'Quelques fois par semaine';

$profile_questions['18']['10089'] = 'Hebdomadairement';

$profile_questions['18']['10090'] = 'Quelques fois par mois';

$profile_questions['18']['10091'] = 'Mensuellement';

$profile_questions['18']['10092'] = 'Sans horraire pr�cis';

$profile_questions['18']['10093'] = 'Jamais';

$profile_questions['19']['question'] = 'Quest-ce qui d�crit le mieux votre alimentation ?';

$profile_questions['19']['description'] = '';

$profile_questions['19']['guideline'] = '';

$profile_questions['19']['extsearchhead'] = 'Alimentation';

$profile_questions['19']['10094'] = 'Viande et patates';

$profile_questions['19']['10095'] = '"Junk" Food';

$profile_questions['19']['10096'] = 'Fast Food';

$profile_questions['19']['10097'] = 'Sant�';

$profile_questions['19']['10098'] = 'Di�te m�dicale';

$profile_questions['19']['10099'] = 'V�g�tarien';

$profile_questions['19']['10100'] = 'Autre';

$profile_questions['20']['question'] = 'Fumez-vous ?';

$profile_questions['20']['description'] = '';

$profile_questions['20']['guideline'] = '';

$profile_questions['20']['extsearchhead'] = 'Cigarette';

$profile_questions['20']['50'] = 'Non, jamais';

$profile_questions['20']['51'] = 'Non, mais je fumais dans le pass�';

$profile_questions['20']['10711'] = 'Oui, mais j\'essai d\'arr�ter';

$profile_questions['20']['10712'] = 'Oui, occasionnellement';

$profile_questions['20']['10713'] = 'Oui, r�guli�rement';

$profile_questions['21']['question'] = 'Consommation d\'alcool ?';

$profile_questions['21']['description'] = '';

$profile_questions['21']['guideline'] = '';

$profile_questions['21']['extsearchhead'] = 'Alcool';

$profile_questions['21']['52'] = 'jamais';

$profile_questions['21']['53'] = 'Socialement';

$profile_questions['21']['54'] = 'Fr�quemment';

$profile_questions['22']['question'] = 'Travaillez-vous de 9 � 5 ? Votre propre patron ? Quelle sorte d\'emploi occupez-vous ?';

$profile_questions['22']['description'] = '';

$profile_questions['22']['guideline'] = '';

$profile_questions['22']['extsearchhead'] = 'Horraire de travail';

$profile_questions['22']['10102'] = 'Plein temps 9 � 5';

$profile_questions['22']['10103'] = 'Plein temps heures variables';

$profile_questions['22']['10104'] = 'Demi-temps';

$profile_questions['22']['10105'] = 'Temps partiel';

$profile_questions['22']['10106'] = 'Mon propre patron';

$profile_questions['22']['10107'] = 'Cherche un emploi';

$profile_questions['22']['10108'] = 'Retrait temporaire';

$profile_questions['22']['10109'] = 'Retrait�';

$profile_questions['22']['10110'] = 'Je choisis mes horraires';

$profile_questions['23']['question'] = 'Revenu annuel ?';

$profile_questions['23']['description'] = '';

$profile_questions['23']['guideline'] = '';

$profile_questions['23']['extsearchhead'] = 'Revenu annuel';

$profile_questions['23']['56'] = 'Moins de $25,000';

$profile_questions['23']['57'] = '$25,001 � $50,000';

$profile_questions['23']['58'] = '$50,001 � $75,000';

$profile_questions['23']['59'] = '$75,001 � $100,000';

$profile_questions['23']['70'] = '$100,001 � $125,000';

$profile_questions['23']['71'] = '$125,001 � $150,000';

$profile_questions['23']['72'] = '$150,001 � $175,000';

$profile_questions['23']['10101'] = 'Plus de $175,000';

$profile_questions['23']['10716'] = 'Je vous le dirai plus tard';

$profile_questions['24']['question'] = 'Demeurez-vous seul ?';

$profile_questions['24']['description'] = '';

$profile_questions['24']['guideline'] = '';

$profile_questions['24']['extsearchhead'] = 'Situation r�sidentielle';

$profile_questions['24']['60'] = 'Demeure seul';

$profile_questions['24']['61'] = 'Demeure avec enfants';

$profile_questions['24']['62'] = 'Demeure avec mes parents';

$profile_questions['24']['10714'] = 'Demeure avec colocataire/s';

$profile_questions['24']['10715'] = 'Demeure avec un membre de ma famille';

$profile_questions['25']['question'] = 'Avez-vous des enfants ?';

$profile_questions['25']['description'] = '';

$profile_questions['25']['guideline'] = '';

$profile_questions['25']['extsearchhead'] = 'Enfants';

$profile_questions['25']['63'] = 'Non';

$profile_questions['25']['64'] = 'Oui - � la maison Plein temps';

$profile_questions['25']['230'] = 'Oui - � la maison garde partag�e';

$profile_questions['25']['231'] = 'Oui - mais partis de la maison';

$profile_questions['26']['question'] = 'Voulez-vous des enfants ?';

$profile_questions['26']['description'] = '';

$profile_questions['26']['guideline'] = '';

$profile_questions['26']['extsearchhead'] = 'Veux des enfants';

$profile_questions['26']['65'] = 'Oui';

$profile_questions['26']['66'] = 'Non';

$profile_questions['26']['232'] = 'Incertain';

$profile_questions['27']['question'] = 'Votre poids';

$profile_questions['27']['description'] = '';

$profile_questions['27']['guideline'] = '';

$profile_questions['27']['extsearchhead'] = 'Poids';

$profile_questions['27']['243'] = 'Moins de 78 lbs (35.4 Kg)';

$profile_questions['27']['244'] = '78 lbs (35.4 Kg)';

$profile_questions['27']['245'] = '79 lbs (35.8 Kg)';

$profile_questions['27']['246'] = '80 lbs (36.3 Kg)';

$profile_questions['27']['247'] = '81 lbs (36.7 Kg)';

$profile_questions['27']['248'] = '82 lbs (37.2 Kg)';

$profile_questions['27']['249'] = '83 lbs (37.6 Kg)';

$profile_questions['27']['250'] = '84 lbs (38.1 Kg)';

$profile_questions['27']['251'] = '85 lbs (38.6 Kg)';

$profile_questions['27']['252'] = '86 lbs (39 Kg)';

$profile_questions['27']['253'] = '87 lbs (39.5 Kg)';

$profile_questions['27']['254'] = '88 lbs (39.9 Kg)';

$profile_questions['27']['255'] = '89 lbs (40.4 Kg)';

$profile_questions['27']['256'] = '90 lbs (40.8 Kg)';

$profile_questions['27']['257'] = '91 lbs (41.3 Kg)';

$profile_questions['27']['258'] = '92 lbs (41.7 Kg)';

$profile_questions['27']['259'] = '93 lbs (42.2 Kg)';

$profile_questions['27']['260'] = '94 lbs (42.6 Kg)';

$profile_questions['27']['261'] = '95 lbs (43.1 Kg)';

$profile_questions['27']['262'] = '96 lbs (43.5 Kg)';

$profile_questions['27']['263'] = '97 lbs (44 Kg)';

$profile_questions['27']['264'] = '98 lbs (44.5 Kg)';

$profile_questions['27']['265'] = '99 lbs (44.9 Kg)';

$profile_questions['27']['266'] = '100 lbs (45.4 Kg)';

$profile_questions['27']['267'] = '101 lbs (45.8 Kg)';

$profile_questions['27']['268'] = '102 lbs (46.3 Kg)';

$profile_questions['27']['269'] = '103 lbs (46.7 Kg)';

$profile_questions['27']['270'] = '104 lbs (47.2 Kg)';

$profile_questions['27']['271'] = '105 lbs (47.6 Kg)';

$profile_questions['27']['272'] = '106 lbs (48.1 Kg)';

$profile_questions['27']['273'] = '107 lbs (48.5 Kg)';

$profile_questions['27']['274'] = '108 lbs (49 Kg)';

$profile_questions['27']['275'] = '109 lbs (49.4 Kg)';

$profile_questions['27']['276'] = '110 lbs (49.9 Kg)';

$profile_questions['27']['277'] = '111 lbs (50.3 Kg)';

$profile_questions['27']['278'] = '112 lbs (50.8 Kg)';

$profile_questions['27']['279'] = '113 lbs (51.3 Kg)';

$profile_questions['27']['280'] = '114 lbs (51.7 Kg)';

$profile_questions['27']['281'] = '115 lbs (52.2 Kg)';

$profile_questions['27']['282'] = '116 lbs (52.6 Kg)';

$profile_questions['27']['283'] = '117 lbs (53.1 Kg)';

$profile_questions['27']['284'] = '118 lbs (53.5 Kg)';

$profile_questions['27']['285'] = '119 lbs (54 Kg)';

$profile_questions['27']['286'] = '120 lbs (54.4 Kg)';

$profile_questions['27']['287'] = '121 lbs (54.9 Kg)';

$profile_questions['27']['288'] = '122 lbs (55.3 Kg)';

$profile_questions['27']['289'] = '123 lbs (55.8 Kg)';

$profile_questions['27']['290'] = '124 lbs (56.2 Kg)';

$profile_questions['27']['291'] = '125 lbs (56.7 Kg)';

$profile_questions['27']['292'] = '126 lbs (57.2 Kg)';

$profile_questions['27']['293'] = '127 lbs (57.6 Kg)';

$profile_questions['27']['294'] = '128 lbs (58.1 Kg)';

$profile_questions['27']['295'] = '129 lbs (58.5 Kg)';

$profile_questions['27']['296'] = '130 lbs (59 Kg)';

$profile_questions['27']['297'] = '131 lbs (59.4 Kg)';

$profile_questions['27']['298'] = '132 lbs (59.9 Kg)';

$profile_questions['27']['299'] = '133 lbs (60.3 Kg)';

$profile_questions['27']['300'] = '134 lbs (60.8 Kg)';

$profile_questions['27']['301'] = '135 lbs (61.2 Kg)';

$profile_questions['27']['302'] = '136 lbs (61.7 Kg)';

$profile_questions['27']['303'] = '137 lbs (62.1 Kg)';

$profile_questions['27']['304'] = '138 lbs (62.6 Kg)';

$profile_questions['27']['305'] = '139 lbs (63.1 Kg)';

$profile_questions['27']['306'] = '140 lbs (63.5 Kg)';

$profile_questions['27']['307'] = '141 lbs (64 Kg)';

$profile_questions['27']['308'] = '142 lbs (64.4 Kg)';

$profile_questions['27']['309'] = '143 lbs (64.9 Kg)';

$profile_questions['27']['310'] = '144 lbs (65.3 Kg)';

$profile_questions['27']['311'] = '145 lbs (65.8 Kg)';

$profile_questions['27']['312'] = '146 lbs (66.2 Kg)';

$profile_questions['27']['313'] = '147 lbs (66.7 Kg)';

$profile_questions['27']['314'] = '148 lbs (67.1 Kg)';

$profile_questions['27']['315'] = '149 lbs (67.6 Kg)';

$profile_questions['27']['316'] = '150 lbs (68 Kg)';

$profile_questions['27']['317'] = '151 lbs (68.5 Kg)';

$profile_questions['27']['318'] = '152 lbs (68.9 Kg)';

$profile_questions['27']['319'] = '153 lbs (69.4 Kg)';

$profile_questions['27']['320'] = '154 lbs (69.9 Kg)';

$profile_questions['27']['321'] = '155 lbs (70.3 Kg)';

$profile_questions['27']['322'] = '156 lbs (70.8 Kg)';

$profile_questions['27']['323'] = '157 lbs (71.2 Kg)';

$profile_questions['27']['324'] = '158 lbs (71.7 Kg)';

$profile_questions['27']['325'] = '159 lbs (72.1 Kg)';

$profile_questions['27']['326'] = '160 lbs (72.6 Kg)';

$profile_questions['27']['327'] = '161 lbs (73 Kg)';

$profile_questions['27']['328'] = '162 lbs (73.5 Kg)';

$profile_questions['27']['329'] = '163 lbs (73.9 Kg)';

$profile_questions['27']['330'] = '164 lbs (74.4 Kg)';

$profile_questions['27']['331'] = '165 lbs (74.8 Kg)';

$profile_questions['27']['332'] = '166 lbs (75.3 Kg)';

$profile_questions['27']['333'] = '167 lbs (75.8 Kg)';

$profile_questions['27']['334'] = '168 lbs (76.2 Kg)';

$profile_questions['27']['335'] = '169 lbs (76.7 Kg)';

$profile_questions['27']['336'] = '170 lbs (77.1 Kg)';

$profile_questions['27']['337'] = '171 lbs (77.6 Kg)';

$profile_questions['27']['338'] = '172 lbs (78 Kg)';

$profile_questions['27']['339'] = '173 lbs (78.5 Kg)';

$profile_questions['27']['340'] = '174 lbs (78.9 Kg)';

$profile_questions['27']['341'] = '175 lbs (79.4 Kg)';

$profile_questions['27']['342'] = '176 lbs (79.8 Kg)';

$profile_questions['27']['343'] = '177 lbs (80.3 Kg)';

$profile_questions['27']['344'] = '178 lbs (80.7 Kg)';

$profile_questions['27']['345'] = '179 lbs (81.2 Kg)';

$profile_questions['27']['346'] = '180 lbs (81.6 Kg)';

$profile_questions['27']['347'] = '181 lbs (82.1 Kg)';

$profile_questions['27']['348'] = '182 lbs (82.6 Kg)';

$profile_questions['27']['349'] = '183 lbs (83 Kg)';

$profile_questions['27']['350'] = '184 lbs (83.5 Kg)';

$profile_questions['27']['351'] = '185 lbs (83.9 Kg)';

$profile_questions['27']['352'] = '186 lbs (84.4 Kg)';

$profile_questions['27']['353'] = '187 lbs (84.8 Kg)';

$profile_questions['27']['354'] = '188 lbs (85.3 Kg)';

$profile_questions['27']['355'] = '189 lbs (85.7 Kg)';

$profile_questions['27']['356'] = '190 lbs (86.2 Kg)';

$profile_questions['27']['357'] = '191 lbs (86.6 Kg)';

$profile_questions['27']['358'] = '192 lbs (87.1 Kg)';

$profile_questions['27']['359'] = '193 lbs (87.5 Kg)';

$profile_questions['27']['360'] = '194 lbs (88 Kg)';

$profile_questions['27']['361'] = '195 lbs (88.5 Kg)';

$profile_questions['27']['362'] = '196 lbs (88.9 Kg)';

$profile_questions['27']['363'] = '197 lbs (89.4 Kg)';

$profile_questions['27']['364'] = '198 lbs (89.8 Kg)';

$profile_questions['27']['365'] = '199 lbs (90.3 Kg)';

$profile_questions['27']['366'] = '200 lbs (90.7 Kg)';

$profile_questions['27']['10111'] = '201 lbs (91.2 Kg)';

$profile_questions['27']['10112'] = '202 lbs (91.6 Kg)';

$profile_questions['27']['10113'] = '203 lbs (92.1 Kg)';

$profile_questions['27']['10114'] = '204 lbs (92.5 Kg)';

$profile_questions['27']['10115'] = '205 lbs (93 Kg)';

$profile_questions['27']['10116'] = '206 lbs (93.4 Kg)';

$profile_questions['27']['10117'] = '207 lbs (93.9 Kg)';

$profile_questions['27']['10118'] = '208 lbs (94.3 Kg)';

$profile_questions['27']['10119'] = '209 lbs (94.8 Kg)';

$profile_questions['27']['10120'] = '210 lbs (95.2 Kg)';

$profile_questions['27']['10121'] = '211 lbs (95.7 Kg)';

$profile_questions['27']['10122'] = '212 lbs (96.1 Kg)';

$profile_questions['27']['10123'] = '213 lbs (96.6 Kg)';

$profile_questions['27']['10124'] = '214 lbs (97 Kg)';

$profile_questions['27']['10125'] = '215 lbs (97.5 Kg)';

$profile_questions['27']['10126'] = '216 lbs (97.9 Kg)';

$profile_questions['27']['10127'] = '217 lbs (98.3 Kg)';

$profile_questions['27']['10128'] = '218 lbs (98.8 Kg)';

$profile_questions['27']['10129'] = '219 lbs (99.2 Kg)';

$profile_questions['27']['10130'] = '220 lbs (99.7 Kg)';

$profile_questions['27']['10131'] = '221 lbs (100.2 Kg)';

$profile_questions['27']['10132'] = '222 lbs (100.6 Kg)';

$profile_questions['27']['10133'] = '223 lbs (101 Kg)';

$profile_questions['27']['10134'] = '224 lbs (101.5 Kg)';

$profile_questions['27']['10135'] = '225 lbs (101.9 Kg)';

$profile_questions['27']['10136'] = '226 lbs (102.3 Kg)';

$profile_questions['27']['10137'] = '227 lbs (102.8 Kg)';

$profile_questions['27']['10138'] = '228 lbs (103.2 Kg)';

$profile_questions['27']['10139'] = '229 lbs (103.7 Kg)';

$profile_questions['27']['10140'] = '230 lbs (104.1 Kg)';

$profile_questions['27']['10141'] = '231 lbs (104,6 Kg)';

$profile_questions['27']['10142'] = '232 lbs (105 Kg)';

$profile_questions['27']['10143'] = '233 lbs (105.5 Kg)';

$profile_questions['27']['10144'] = '234 lbs (105.9 Kg)';

$profile_questions['27']['10145'] = '235 lbs (106.4 Kg)';

$profile_questions['27']['10146'] = '236 lbs (106.8 Kg)';

$profile_questions['27']['10147'] = '237 lbs (107.3 Kg)';

$profile_questions['27']['10148'] = '238 lbs (107.7 Kg)';

$profile_questions['27']['10149'] = '239 lbs (108.2 Kg)';

$profile_questions['27']['10150'] = '240 lbs (108.6 Kg)';

$profile_questions['27']['10151'] = '241 lbs (109.1 Kg)';

$profile_questions['27']['10152'] = '242 lbs (109.5 Kg)';

$profile_questions['27']['10153'] = '243 lbs (110 Kg)';

$profile_questions['27']['10154'] = '244 lbs (110.4 Kg)';

$profile_questions['27']['10155'] = '245 lbs (110.9 Kg)';

$profile_questions['27']['10156'] = '246 lbs (111.3 Kg)';

$profile_questions['27']['10157'] = '247 lbs (111.8 Kg)';

$profile_questions['27']['10158'] = '248 lbs (112.2 Kg)';

$profile_questions['27']['10159'] = '249 lbs (112.7 Kg)';

$profile_questions['27']['10160'] = '250 lbs (113.1 Kg)';

$profile_questions['27']['10161'] = '251 lbs (113,6 Kg)';

$profile_questions['27']['10162'] = '252 lbs (114 Kg)';

$profile_questions['27']['10163'] = '253 lbs (114.5 Kg)';

$profile_questions['27']['10164'] = '254 lbs (114.9 Kg)';

$profile_questions['27']['10165'] = '255 lbs (115.3 Kg)';

$profile_questions['27']['10166'] = '256 lbs (115.8 Kg)';

$profile_questions['27']['10167'] = '257 lbs (116.2 Kg)';

$profile_questions['27']['10168'] = '258 lbs (116.7 Kg)';

$profile_questions['27']['10169'] = '259 lbs (117.1 Kg)';

$profile_questions['27']['10170'] = '260 lbs (117.6 Kg)';

$profile_questions['27']['10171'] = '261 lbs (118 Kg)';

$profile_questions['27']['10172'] = '262 lbs (118.5 Kg)';

$profile_questions['27']['10173'] = '263 lbs (118.9 Kg)';

$profile_questions['27']['10174'] = '264 lbs (119.4 Kg)';

$profile_questions['27']['10175'] = '265 lbs (119.8 Kg)';

$profile_questions['27']['10176'] = '266 lbs (120.3 Kg)';

$profile_questions['27']['10177'] = '267 lbs (120.7 Kg)';

$profile_questions['27']['10178'] = '268 lbs (121.1 Kg)';

$profile_questions['27']['10179'] = '269 lbs (121.6 Kg)';

$profile_questions['27']['10180'] = '270 lbs (122 Kg)';

$profile_questions['27']['10181'] = '271 lbs (122.5 Kg)';

$profile_questions['27']['10182'] = '272 lbs (122.9 Kg)';

$profile_questions['27']['10183'] = '273 lbs (123.3 Kg)';

$profile_questions['27']['10184'] = '274 lbs (123.8 Kg)';

$profile_questions['27']['10185'] = '275 lbs (124.2 Kg)';

$profile_questions['27']['10186'] = '276 lbs (124.7 Kg)';

$profile_questions['27']['10187'] = '277 lbs (125.1 Kg)';

$profile_questions['27']['10188'] = '278 lbs (125.5 Kg)';

$profile_questions['27']['10189'] = '279 lbs (126 Kg)';

$profile_questions['27']['10190'] = '280 lbs (126.4 Kg)';

$profile_questions['27']['10191'] = '281 lbs (126.9 Kg)';

$profile_questions['27']['10192'] = '282 lbs (127.3 Kg)';

$profile_questions['27']['10193'] = '283 lbs (127.8 Kg)';

$profile_questions['27']['10194'] = '284 lbs (128.2 Kg)';

$profile_questions['27']['10195'] = '285 lbs (128.7 Kg)';

$profile_questions['27']['10196'] = '286 lbs (129.1 Kg)';

$profile_questions['27']['10197'] = '287 lbs (129.6 Kg)';

$profile_questions['27']['10198'] = '288 lbs (130 Kg)';

$profile_questions['27']['10199'] = '289 lbs (130.5 Kg)';

$profile_questions['27']['10200'] = '290 lbs (130.9 Kg)';

$profile_questions['27']['10201'] = '291 lbs (131.3 Kg)';

$profile_questions['27']['10202'] = '292 lbs (131.8 Kg)';

$profile_questions['27']['10203'] = '293 lbs (132.2 Kg)';

$profile_questions['27']['10204'] = '294 lbs (132.7 Kg)';

$profile_questions['27']['10205'] = '295 lbs (133.1 Kg)';

$profile_questions['27']['10206'] = '296 lbs (133.6 Kg)';

$profile_questions['27']['10207'] = '297 lbs (134 Kg)';

$profile_questions['27']['10208'] = '298 lbs (134.5 Kg)';

$profile_questions['27']['10209'] = '299 lbs (134.9 Kg)';

$profile_questions['27']['10210'] = '300 lbs (135.3 Kg)';

$profile_questions['27']['10211'] = '301 lbs (135.8 Kg)';

$profile_questions['27']['10212'] = '302 lbs (136.2 Kg)';

$profile_questions['27']['10213'] = '303 lbs (136.7 Kg)';

$profile_questions['27']['10214'] = '304 lbs (137.1 Kg)';

$profile_questions['27']['10215'] = '305 lbs (137.6 Kg)';

$profile_questions['27']['10216'] = '306 lbs (138 Kg)';

$profile_questions['27']['10217'] = '307 lbs (138.5 Kg)';

$profile_questions['27']['10218'] = '308 lbs (138.9 Kg)';

$profile_questions['27']['10219'] = '309 lbs (139.4 Kg)';

$profile_questions['27']['10220'] = '310 lbs (139.8 Kg)';

$profile_questions['27']['10221'] = '311 lbs (140.3 Kg)';

$profile_questions['27']['10222'] = '312 lbs (140.7 Kg)';

$profile_questions['27']['10223'] = '313 lbs (141.1 Kg)';

$profile_questions['27']['10224'] = '314 lbs (141.6 Kg)';

$profile_questions['27']['10225'] = '315 lbs (142 Kg)';

$profile_questions['27']['10226'] = '316 lbs (142.5 Kg)';

$profile_questions['27']['10227'] = '317 lbs (142.9 Kg)';

$profile_questions['27']['10228'] = '318 lbs (143.4 Kg)';

$profile_questions['27']['10229'] = '319 lbs (143.8 Kg)';

$profile_questions['27']['10230'] = '320 lbs (144.3 Kg)';

$profile_questions['27']['10231'] = '321 lbs (144.7 Kg)';

$profile_questions['27']['10232'] = '322 lbs (145.2 Kg)';

$profile_questions['27']['10233'] = '323 lbs (145.6 Kg)';

$profile_questions['27']['10234'] = '324 lbs (146.1 Kg)';

$profile_questions['27']['10235'] = '325 lbs (146.6 Kg)';

$profile_questions['27']['10236'] = '326 lbs (147 Kg)';

$profile_questions['27']['10237'] = '327 lbs (147.5 Kg)';

$profile_questions['27']['10238'] = '328 lbs (147.9 Kg)';

$profile_questions['27']['10239'] = '329 lbs (148.4 Kg)';

$profile_questions['27']['10240'] = '330 lbs (148.8 Kg)';

$profile_questions['27']['10241'] = '331 lbs (149.3 Kg)';

$profile_questions['27']['10242'] = '332 lbs (149.7 Kg)';

$profile_questions['27']['10243'] = '333 lbs (150.2 Kg)';

$profile_questions['27']['10244'] = '334 lbs (150.6 Kg)';

$profile_questions['27']['10245'] = '335 lbs (151.1 Kg)';

$profile_questions['27']['10246'] = '336 lbs (151.6 Kg)';

$profile_questions['27']['10247'] = '337 lbs (152 Kg)';

$profile_questions['27']['10248'] = '338 lbs (152.5 Kg)';

$profile_questions['27']['10249'] = '339 lbs (152.9 Kg)';

$profile_questions['27']['10250'] = '340 lbs (153.3 Kg)';

$profile_questions['27']['10251'] = '341 lbs (153.8 Kg)';

$profile_questions['27']['10252'] = '342 lbs (154.2 Kg)';

$profile_questions['27']['10253'] = '343 lbs (154.7 Kg)';

$profile_questions['27']['10254'] = '344 lbs (155.1 Kg)';

$profile_questions['27']['10255'] = '345 lbs (155.6 Kg)';

$profile_questions['27']['10256'] = '346 lbs (156 Kg)';

$profile_questions['27']['10257'] = '347 lbs (156.5 Kg)';

$profile_questions['27']['10258'] = '348 lbs (156.9 Kg)';

$profile_questions['27']['10259'] = '349 lbs (157.4 Kg)';

$profile_questions['27']['10260'] = '350 lbs (157.8 Kg)';

$profile_questions['27']['10261'] = 'Plus de 350 lbs (157.8 Kg)';

$profile_questions['28']['question'] = 'Statut d\'emploi';

$profile_questions['28']['description'] = '';

$profile_questions['28']['guideline'] = '';

$profile_questions['28']['extsearchhead'] = 'Statut d\'emploi';

$profile_questions['28']['233'] = 'Plein temps';

$profile_questions['28']['234'] = 'Temps partiel';

$profile_questions['28']['235'] = 'Femme/homme au foyer';

$profile_questions['28']['236'] = 'Retrait�';

$profile_questions['28']['237'] = 'Travailleur autonome';

$profile_questions['28']['238'] = '�tudiant';

$profile_questions['28']['239'] = 'Sans emploi';

$profile_questions['28']['240'] = 'Travail � la maison';

$profile_questions['29']['question'] = 'Votre �ducation ?';

$profile_questions['29']['description'] = '';

$profile_questions['29']['guideline'] = '';

$profile_questions['29']['extsearchhead'] = 'Education';

$profile_questions['29']['194'] = 'Secondaire';

$profile_questions['29']['195'] = 'Coll�ge';

$profile_questions['29']['196'] = 'Professionnel';

$profile_questions['29']['197'] = 'Bac';

$profile_questions['29']['198'] = 'Universit�';

$profile_questions['29']['199'] = 'PhD';

$profile_questions['29']['200'] = '�cole de la vie';

$profile_questions['29']['201'] = 'Aucune r�ponse';

$profile_questions['30']['question'] = 'Quelle langue parlez-vous ?';

$profile_questions['30']['description'] = '';

$profile_questions['30']['guideline'] = '';

$profile_questions['30']['extsearchhead'] = 'Langue';

$profile_questions['30']['10050'] = 'Arabe';

$profile_questions['30']['10051'] = 'Cambodgien';

$profile_questions['30']['10052'] = 'Chinois';

$profile_questions['30']['10053'] = 'Hollandais';

$profile_questions['30']['10054'] = 'Anglais';

$profile_questions['30']['10055'] = 'Fran�ais';

$profile_questions['30']['10056'] = 'Allemand';

$profile_questions['30']['10058'] = 'Hebreux';

$profile_questions['30']['10059'] = 'Hindi';

$profile_questions['30']['10060'] = 'Italien';

$profile_questions['30']['10061'] = 'Portugais';

$profile_questions['30']['10062'] = 'Romain';

$profile_questions['30']['10063'] = 'Russe';

$profile_questions['30']['10064'] = 'Espagnol';

$profile_questions['30']['10065'] = 'Thai';

$profile_questions['30']['10066'] = 'Turque';

$profile_questions['30']['10067'] = 'Vietnamien';

$profile_questions['30']['10717'] = 'Autre';

$profile_questions['37']['question'] = 'Comment avez-vous trouv� ce site ?';

$profile_questions['37']['description'] = 'Veuillez mentionnez comment vous avez pris connaissance de notre site..';

$profile_questions['37']['guideline'] = '';

$profile_questions['37']['extsearchhead'] = 'R�f�r� par';

$profile_questions['37']['10041'] = 'Message e-mail';

$profile_questions['37']['10042'] = 'Journal ou d�pliant';

$profile_questions['37']['10043'] = 'Banni�re web';

$profile_questions['37']['10044'] = 'Annonce radio';

$profile_questions['37']['10045'] = 'R�f�r� par un ami';

$profile_questions['37']['10046'] = 'Annonce t�l�';

$profile_questions['37']['10047'] = 'Moteur de recherche web';

$profile_questions['37']['10048'] = 'Bouche � oreille';

$profile_questions['37']['10049'] = 'Autre';

?>