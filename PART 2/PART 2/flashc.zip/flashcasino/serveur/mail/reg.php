<?
$reg_reg_mail_subject="Incription overcasino";

$reg_reg_mail="bienvenue, $r_login,
-----------------------------:
$con[3]/system/


Login: $r_login
Mot de passe: $r_pass






---------------------
 $con[4]";
?>