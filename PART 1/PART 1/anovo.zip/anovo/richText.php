<?php
session_start();
header("Pragma: no-cache");
header("Cache-Control: no-cache, must-revalidate");
header("Expires: 0");
header("Content-type: text/html; charset=iso-8859-1");
$useHtmSpChars = $_REQUEST['htmSpChar'];
$source = $_SESSION[$_REQUEST['source']];
$source = urldecode($source);
if ($useHtmSpChars)
{
		echo $source;
}
else
{
		echo html_entity_decode($source);
}
?>