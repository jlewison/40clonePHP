<? include "header.php"; ?>

<center><h4><font color=#7C87C2>Stat of game</font></h4></center>
<table border style="BORDER-COLLAPSE: collapse" cellspacing=0 cellpadding=3>








<tr><td class=text1><b>Game</b></td><td class=text1><b>lose</b></td><td class=text1><b>win</b></td><td class=text1><b>Profit</b></td></tr>




<?

$a1="0";
$a11="0";
$strok=mysql_query("SELECT * FROM stat_game WHERE game='blackjack' ");
while($row=mysql_fetch_array($strok))
{
$a1=$a1+$row[5];
$a11=$a11+$row[6];
}

$a12 = $a1 - $a11;
?>

<tr><td class=text1><b>Blackjack</b></td><td class=text1><b><? echo $a1; ?></b></td><td class=text1><b><? echo $a11; ?></b></td><td class=text1><b><? echo $a12; ?></b></td></tr>



<?

$a1="0";
$a11="0";
$strok=mysql_query("SELECT * FROM stat_game WHERE game='baccarat' ");
while($row=mysql_fetch_array($strok))
{
$a1=$a1+$row[5];
$a11=$a11+$row[6];
}

$a12 = $a1 - $a11;
?>

<tr><td class=text1><b>baccarat</b></td><td class=text1><b><? echo $a1; ?></b></td><td class=text1><b><? echo $a11; ?></b></td><td class=text1><b><? echo $a12; ?></b></td></tr>



<?

$a1="0";
$a11="0";
$strok=mysql_query("SELECT * FROM stat_game WHERE game='cyberstud' ");
while($row=mysql_fetch_array($strok))
{
$a1=$a1+$row[5];
$a11=$a11+$row[6];
}

$a12 = $a1 - $a11;
?>

<tr><td class=text1><b>cyberstud</b></td><td class=text1><b><? echo $a1; ?></b></td><td class=text1><b><? echo $a11; ?></b></td><td class=text1><b><? echo $a12; ?></b></td></tr>


<?

$a1="0";
$a11="0";
$strok=mysql_query("SELECT * FROM stat_game WHERE game='Roulette' ");
while($row=mysql_fetch_array($strok))
{
$a1=$a1+$row[5];
$a11=$a11+$row[6];
}

$a12 = $a1 - $a11;
?>

<tr><td class=text1><b>Roulette</b></td><td class=text1><b><? echo $a1; ?></b></td><td class=text1><b><? echo $a11; ?></b></td><td class=text1><b><? echo $a12; ?></b></td></tr>


<?

$a1="0";
$a11="0";
$strok=mysql_query("SELECT * FROM stat_game WHERE game='pooloffortune' ");
while($row=mysql_fetch_array($strok))
{
$a1=$a1+$row[5];
$a11=$a11+$row[6];
}

$a12 = $a1 - $a11;
?>

<tr><td class=text1><b>pooloffortune</b></td><td class=text1><b><? echo $a1; ?></b></td><td class=text1><b><? echo $a11; ?></b></td><td class=text1><b><? echo $a12; ?></b></td></tr>


<?

$a1="0";
$a11="0";
$strok=mysql_query("SELECT * FROM stat_game WHERE game='pharaon' ");
while($row=mysql_fetch_array($strok))
{
$a1=$a1+$row[5];
$a11=$a11+$row[6];
}

$a12 = $a1 - $a11;
?>

<tr><td class=text1><b>pharaon</b></td><td class=text1><b><? echo $a1; ?></b></td><td class=text1><b><? echo $a11; ?></b></td><td class=text1><b><? echo $a12; ?></b></td></tr>


<?

$a1="0";
$a11="0";
$strok=mysql_query("SELECT * FROM stat_game WHERE game='cheekymonkey' ");
while($row=mysql_fetch_array($strok))
{
$a1=$a1+$row[5];
$a11=$a11+$row[6];
}

$a12 = $a1 - $a11;
?>

<tr><td class=text1><b>cheekymonkey</b></td><td class=text1><b><? echo $a1; ?></b></td><td class=text1><b><? echo $a11; ?></b></td><td class=text1><b><? echo $a12; ?></b></td></tr>



<?

$a1="0";
$a11="0";
$strok=mysql_query("SELECT * FROM stat_game WHERE game='Dragonpoker' ");
while($row=mysql_fetch_array($strok))
{
$a1=$a1+$row[5];
$a11=$a11+$row[6];
}

$a12 = $a1 - $a11;
?>

<tr><td class=text1><b>Dragonpoker</b></td><td class=text1><b><? echo $a1; ?></b></td><td class=text1><b><? echo $a11; ?></b></td><td class=text1><b><? echo $a12; ?></b></td></tr>



<?

$a1="0";
$a11="0";
$strok=mysql_query("SELECT * FROM stat_game WHERE game='jacksorbetter' ");
while($row=mysql_fetch_array($strok))
{
$a1=$a1+$row[5];
$a11=$a11+$row[6];
}

$a12 = $a1 - $a11;
?>

<tr><td class=text1><b>jacksorbetter</b></td><td class=text1><b><? echo $a1; ?></b></td><td class=text1><b><? echo $a11; ?></b></td><td class=text1><b><? echo $a12; ?></b></td></tr>


<?

$a1="0";
$a11="0";
$strok=mysql_query("SELECT * FROM stat_game WHERE game='tensorbetter' ");
while($row=mysql_fetch_array($strok))
{
$a1=$a1+$row[5];
$a11=$a11+$row[6];
}

$a12 = $a1 - $a11;
?>

<tr><td class=text1><b>tensorbetter</b></td><td class=text1><b><? echo $a1; ?></b></td><td class=text1><b><? echo $a11; ?></b></td><td class=text1><b><? echo $a12; ?></b></td></tr>


<?

$a1="0";
$a11="0";
$strok=mysql_query("SELECT * FROM stat_game WHERE game='acesfaces' ");
while($row=mysql_fetch_array($strok))
{
$a1=$a1+$row[5];
$a11=$a11+$row[6];
}

$a12 = $a1 - $a11;
?>

<tr><td class=text1><b>acesfaces</b></td><td class=text1><b><? echo $a1; ?></b></td><td class=text1><b><? echo $a11; ?></b></td><td class=text1><b><? echo $a12; ?></b></td></tr>


<?

$a1="0";
$a11="0";
$strok=mysql_query("SELECT * FROM stat_game WHERE game='astro' ");
while($row=mysql_fetch_array($strok))
{
$a1=$a1+$row[5];
$a11=$a11+$row[6];
}

$a12 = $a1 - $a11;
?>

<tr><td class=text1><b>astro</b></td><td class=text1><b><? echo $a1; ?></b></td><td class=text1><b><? echo $a11; ?></b></td><td class=text1><b><? echo $a12; ?></b></td></tr>



<?

$a1="0";
$a11="0";
$strok=mysql_query("SELECT * FROM stat_game WHERE game='birds' ");
while($row=mysql_fetch_array($strok))
{
$a1=$a1+$row[5];
$a11=$a11+$row[6];
}

$a12 = $a1 - $a11;
?>

<tr><td class=text1><b>birds</b></td><td class=text1><b><? echo $a1; ?></b></td><td class=text1><b><? echo $a11; ?></b></td><td class=text1><b><? echo $a12; ?></b></td></tr>


<?

$a1="0";
$a11="0";
$strok=mysql_query("SELECT * FROM stat_game WHERE game='fairy' ");
while($row=mysql_fetch_array($strok))
{
$a1=$a1+$row[5];
$a11=$a11+$row[6];
}

$a12 = $a1 - $a11;
?>

<tr><td class=text1><b>fairy</b></td><td class=text1><b><? echo $a1; ?></b></td><td class=text1><b><? echo $a11; ?></b></td><td class=text1><b><? echo $a12; ?></b></td></tr>



<?

$a1="0";
$a11="0";
$strok=mysql_query("SELECT * FROM stat_game WHERE game='farwest' ");
while($row=mysql_fetch_array($strok))
{
$a1=$a1+$row[5];
$a11=$a11+$row[6];
}

$a12 = $a1 - $a11;
?>

<tr><td class=text1><b>farwest</b></td><td class=text1><b><? echo $a1; ?></b></td><td class=text1><b><? echo $a11; ?></b></td><td class=text1><b><? echo $a12; ?></b></td></tr>



<?

$a1="0";
$a11="0";
$strok=mysql_query("SELECT * FROM stat_game WHERE game='fruit' ");
while($row=mysql_fetch_array($strok))
{
$a1=$a1+$row[5];
$a11=$a11+$row[6];
}

$a12 = $a1 - $a11;
?>

<tr><td class=text1><b>fruit</b></td><td class=text1><b><? echo $a1; ?></b></td><td class=text1><b><? echo $a11; ?></b></td><td class=text1><b><? echo $a12; ?></b></td></tr>



<?

$a1="0";
$a11="0";
$strok=mysql_query("SELECT * FROM stat_game WHERE game='pirate' ");
while($row=mysql_fetch_array($strok))
{
$a1=$a1+$row[5];
$a11=$a11+$row[6];
}

$a12 = $a1 - $a11;
?>

<tr><td class=text1><b>pirate</b></td><td class=text1><b><? echo $a1; ?></b></td><td class=text1><b><? echo $a11; ?></b></td><td class=text1><b><? echo $a12; ?></b></td></tr>


<?

$a1="0";
$a11="0";
$strok=mysql_query("SELECT * FROM stat_game WHERE game='sea' ");
while($row=mysql_fetch_array($strok))
{
$a1=$a1+$row[5];
$a11=$a11+$row[6];
}

$a12 = $a1 - $a11;
?>

<tr><td class=text1><b>sea</b></td><td class=text1><b><? echo $a1; ?></b></td><td class=text1><b><? echo $a11; ?></b></td><td class=text1><b><? echo $a12; ?></b></td></tr>



<?

$a1="0";
$a11="0";
$strok=mysql_query("SELECT * FROM stat_game WHERE game='shuki' ");
while($row=mysql_fetch_array($strok))
{
$a1=$a1+$row[5];
$a11=$a11+$row[6];
}

$a12 = $a1 - $a11;
?>

<tr><td class=text1><b>shuki</b></td><td class=text1><b><? echo $a1; ?></b></td><td class=text1><b><? echo $a11; ?></b></td><td class=text1><b><? echo $a12; ?></b></td></tr>



<?

$a1="0";
$a11="0";
$strok=mysql_query("SELECT * FROM stat_game WHERE game='magicien' ");
while($row=mysql_fetch_array($strok))
{
$a1=$a1+$row[5];
$a11=$a11+$row[6];
}

$a12 = $a1 - $a11;
?>

<tr><td class=text1><b>magicien</b></td><td class=text1><b><? echo $a1; ?></b></td><td class=text1><b><? echo $a11; ?></b></td><td class=text1><b><? echo $a12; ?></b></td></tr>



<?

$a1="0";
$a11="0";
$strok=mysql_query("SELECT * FROM stat_game WHERE game='tomraider' ");
while($row=mysql_fetch_array($strok))
{
$a1=$a1+$row[5];
$a11=$a11+$row[6];
}

$a12 = $a1 - $a11;
?>

<tr><td class=text1><b>tomraider</b></td><td class=text1><b><? echo $a1; ?></b></td><td class=text1><b><? echo $a11; ?></b></td><td class=text1><b><? echo $a12; ?></b></td></tr>




<?

$a1="0";
$a11="0";
$strok=mysql_query("SELECT * FROM stat_game WHERE game='skull' ");
while($row=mysql_fetch_array($strok))
{
$a1=$a1+$row[5];
$a11=$a11+$row[6];
}

$a12 = $a1 - $a11;
?>

<tr><td class=text1><b>skull</b></td><td class=text1><b><? echo $a1; ?></b></td><td class=text1><b><? echo $a11; ?></b></td><td class=text1><b><? echo $a12; ?></b></td></tr>


<?

$a1="0";
$a11="0";
$strok=mysql_query("SELECT * FROM stat_game WHERE game='cocktailbar' ");
while($row=mysql_fetch_array($strok))
{
$a1=$a1+$row[5];
$a11=$a11+$row[6];
}

$a12 = $a1 - $a11;
?>

<tr><td class=text1><b>cocktailbar</b></td><td class=text1><b><? echo $a1; ?></b></td><td class=text1><b><? echo $a11; ?></b></td><td class=text1><b><? echo $a12; ?></b></td></tr>



<?

$a1="0";
$a11="0";
$strok=mysql_query("SELECT * FROM stat_game WHERE game='magicforest' ");
while($row=mysql_fetch_array($strok))
{
$a1=$a1+$row[5];
$a11=$a11+$row[6];
}

$a12 = $a1 - $a11;
?>

<tr><td class=text1><b>magicforest</b></td><td class=text1><b><? echo $a1; ?></b></td><td class=text1><b><? echo $a11; ?></b></td><td class=text1><b><? echo $a12; ?></b></td></tr>




<?

$a1="0";
$a11="0";
$strok=mysql_query("SELECT * FROM stat_game WHERE game='hauntedcastle' ");
while($row=mysql_fetch_array($strok))
{
$a1=$a1+$row[5];
$a11=$a11+$row[6];
}

$a12 = $a1 - $a11;
?>

<tr><td class=text1><b>hauntedcastle</b></td><td class=text1><b><? echo $a1; ?></b></td><td class=text1><b><? echo $a11; ?></b></td><td class=text1><b><? echo $a12; ?></b></td></tr>



<?

$a1="0";
$a11="0";
$strok=mysql_query("SELECT * FROM stat_game WHERE game='iceage' ");
while($row=mysql_fetch_array($strok))
{
$a1=$a1+$row[5];
$a11=$a11+$row[6];
}

$a12 = $a1 - $a11;
?>

<tr><td class=text1><b>iceage</b></td><td class=text1><b><? echo $a1; ?></b></td><td class=text1><b><? echo $a11; ?></b></td><td class=text1><b><? echo $a12; ?></b></td></tr>


<?

$a1="0";
$a11="0";
$strok=mysql_query("SELECT * FROM stat_game WHERE game='classic' ");
while($row=mysql_fetch_array($strok))
{
$a1=$a1+$row[5];
$a11=$a11+$row[6];
}

$a12 = $a1 - $a11;
?>

<tr><td class=text1><b>classic</b></td><td class=text1><b><? echo $a1; ?></b></td><td class=text1><b><? echo $a11; ?></b></td><td class=text1><b><? echo $a12; ?></b></td></tr>





<?

$a1="0";
$a11="0";
$strok=mysql_query("SELECT * FROM stat_game WHERE game='neptunesworld' ");
while($row=mysql_fetch_array($strok))
{
$a1=$a1+$row[5];
$a11=$a11+$row[6];
}

$a12 = $a1 - $a11;
?>

<tr><td class=text1><b>neptunesworld</b></td><td class=text1><b><? echo $a1; ?></b></td><td class=text1><b><? echo $a11; ?></b></td><td class=text1><b><? echo $a12; ?></b></td></tr>




<?

$a1="0";
$a11="0";
$strok=mysql_query("SELECT * FROM stat_game WHERE game='luckydrink' ");
while($row=mysql_fetch_array($strok))
{
$a1=$a1+$row[5];
$a11=$a11+$row[6];
}

$a12 = $a1 - $a11;
?>

<tr><td class=text1><b>luckydrink</b></td><td class=text1><b><? echo $a1; ?></b></td><td class=text1><b><? echo $a11; ?></b></td><td class=text1><b><? echo $a12; ?></b></td></tr>



<?

$a1="0";
$a11="0";
$strok=mysql_query("SELECT * FROM stat_game WHERE game='crazymonkey' ");
while($row=mysql_fetch_array($strok))
{
$a1=$a1+$row[5];
$a11=$a11+$row[6];
}

$a12 = $a1 - $a11;
?>

<tr><td class=text1><b>crazymonkey</b></td><td class=text1><b><? echo $a1; ?></b></td><td class=text1><b><? echo $a11; ?></b></td><td class=text1><b><? echo $a12; ?></b></td></tr>



<?

$a1="0";
$a11="0";
$strok=mysql_query("SELECT * FROM stat_game  ");
while($row=mysql_fetch_array($strok))
{
$a1=$a1+$row[5];
$a11=$a11+$row[6];
}

$a12 = $a1 - $a11;
?>

<tr><td class=text1><b>TOTAL</b></td><td class=text1><b><? echo $a1; ?></b></td><td class=text1><b><? echo $a11; ?></b></td><td class=text1><b><? echo $a12; ?></b></td></tr>















</table>

<? include "footer.php"; ?>

