<?php

	$lang['page_title']	= 'Wall';
	
	$lang['wall_your']				= 'Your ';
	$lang['wall_delete_success']	= 'wall has been deleted Successfully';
	$lang['wall_create_success']	= 'Wall has been posted successfully';
	$lang['wall_enter_comment']		= 'Enter a comment';
	
	$lang['wall_wall_title']		= 'Wall';
	$lang['wall_wrote']				= 'wrote';
	$lang['wall_at']				= 'at';
	$lang['wall_write_on']			= 'Write on';
	$lang['wall_my']				= 'my';
	$lang['wall_wall']				= 'Wall';
	$lang['wall_delete']			= 'Delete';
	$lang['wall_delete_question']	= 'Are you sure, you want to delete the wall';
	$lang['wall_comment']			= 'Comment';
	$lang['wall_s']					= 's';
	$lang['wall_delete_title']		= 'Delete wall confirmation';

?>