<?php
require_once ('../common/config.inc.php');
$CFG['lang']['include_files'][] = 'members/includes/languages/%s/answer.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['db']['is_use_db'] = true;
$CFG['html']['is_use_header'] = false;
$CFG['html']['is_use_footer'] = false;
$CFG['http_headers']['is_cache'] = false;
$CFG['http_headers']['is_use_if_modified_since'] = false;
$CFG['is']['ajax_page'] = true;
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class AnswerRatingHandler extends FormHandler
{
		public function updateFavoriteContent()
		{
				$table_name = $this->CFG['db']['tbl']['user_bookmarked'];
				switch ($this->fields_arr['ctype'])
				{
						case 'Question':
								$add_text = $this->LANG['answers_add_to_favorites'];
								$remove_text = $this->LANG['answers_remove_favorites'];
								break;
						case 'Forum':
								$add_text = $this->LANG['forum_add_to_favorites'];
								$remove_text = $this->LANG['forum_remove_favorites'];
								break;
						case 'User';
								$add_text = $this->LANG['user_add_to_favorites'];
								$remove_text = $this->LANG['user_remove_favorites'];
								break;
				}
				$sql = 'SELECT bookmark_id FROM ' . $table_name . ' WHERE content_id = ' . $this->dbObj->Param('content_id') . ' AND' . ' content_type = ' . $this->dbObj->Param('content_type') . ' AND' . ' user_id = ' . $this->dbObj->Param('user_id');
				$stmt = $this->dbObj->Prepare($sql);
				$result = $this->dbObj->Execute($stmt, array($this->fields_arr['cid'], $this->fields_arr['ctype'], $this->CFG['user']['user_id']));
				if (!$result) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($result->PO_RecordCount())
				{
						$sql = 'DELETE FROM ' . $table_name . ' WHERE content_id=' . $this->dbObj->Param('content_id') . ' AND' . ' content_type = ' . $this->dbObj->Param('content_type') . ' AND' . ' user_id=' . $this->dbObj->Param('uid');
						$field_values_arr = array($this->fields_arr['cid'], $this->fields_arr['ctype'], $this->CFG['user']['user_id']);
						$favorite_text = $add_text;
				}
				else
				{
						$sql = 'INSERT INTO ' . $table_name . ' SET date_added=NOW()' . ', content_id=' . $this->dbObj->Param('content_id') . ', content_type=' . $this->dbObj->Param('content_type') . ', user_id=' . $this->dbObj->Param('user_id');
						$field_values_arr = array($this->fields_arr['cid'], $this->fields_arr['ctype'], $this->CFG['user']['user_id']);
						$favorite_text = $remove_text;
				}
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, $field_values_arr);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($this->fields_arr['ctype'] == 'Forum')
				{
?>
<span class="clsForumLinkMiddle"><a href="#" onClick="toggleFavorites('<?php echo $this->CFG['site']['relative_url']; ?>favoriteAnswers.php', 'cid=<?php echo $this->fields_arr['cid']; ?>&ctype=<?php echo $this->fields_arr['ctype']; ?>', 'selShowFavoriteText_<?php echo $this->fields_arr['ctype']; ?>_<?php echo $this->fields_arr['cid']; ?>'); return false;"><?php echo $favorite_text; ?></a></span>
<?php
				}
				else
				{
?>
<a class="clsFavourite" href="#" onClick="toggleFavorites('<?php echo $this->CFG['site']['relative_url']; ?>favoriteAnswers.php', 'cid=<?php echo $this->fields_arr['cid']; ?>&ctype=<?php echo $this->fields_arr['ctype']; ?>', 'selShowFavoriteText_<?php echo $this->fields_arr['ctype']; ?>_<?php echo $this->fields_arr['cid']; ?>'); return false;"><?php echo $favorite_text; ?></a>
<?php
				}
		}
		public function updateIgnoreUser()
		{
				$uid = $this->CFG['user']['user_id'];
				$ignore_id = $this->fields_arr['ignore_id'];
				$sql = 'SELECT 1 FROM ' . $this->CFG['db']['tbl']['user_ignored'] . ' WHERE user_id = ' . $this->dbObj->Param($uid) . ' AND ignored_id = ' . $this->dbObj->Param($ignore_id);
				$stmt = $this->dbObj->Prepare($sql);
				$result = $this->dbObj->Execute($stmt, array($uid, $ignore_id));
				if (!$result) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($result->PO_RecordCount())
				{
						$sql = 'DELETE FROM ' . $this->CFG['db']['tbl']['user_ignored'] . ' WHERE user_id = ' . $this->dbObj->Param($uid) . ' AND ignored_id = ' . $this->dbObj->Param($ignore_id);
						$field_values_arr = array($uid, $ignore_id);
						$favorite_text = $this->LANG['myanswers_ignore_user'];
				}
				else
				{
						$sql = 'INSERT INTO ' . $this->CFG['db']['tbl']['user_ignored'] . ' SET user_id = ' . $this->dbObj->Param($uid) . ', ignored_id = ' . $this->dbObj->Param($ignore_id);
						$field_values_arr = array($uid, $ignore_id);
						$favorite_text = $this->LANG['myanswers_unignore_user'];
				}
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, $field_values_arr);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
?>
<a href="#" onClick="toggleFavorites('<?php echo $this->CFG['site']['relative_url']; ?>favoriteAnswers.php', 'ignore_id=<?php echo $this->fields_arr['ignore_id']; ?>', 'selShowIgnoreUser'); return false;"><?php echo $favorite_text; ?></a>
<?php
		}
}
$answerRating = new AnswerRatingHandler();
$answerRating->setDBObject($db);
$answerRating->makeGlobalize($CFG, $LANG);
$answerRating->setHeaderStart();
$answerRating->setFormField('cid', '');
$answerRating->setFormField('ignore_id', '');
$answerRating->setFormField('ctype', '');
$answerRating->sanitizeFormInputs($_REQUEST);
if ($answerRating->isFormGETed($_GET, 'cid'))
{
		$answerRating->updateFavoriteContent();
} elseif ($answerRating->isFormGETed($_GET, 'ignore_id'))
{
		$answerRating->updateIgnoreUser();
}
$answerRating->setHeaderEnd();
die();
require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>
