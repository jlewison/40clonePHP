<?php

class videomodel extends Model
{
		//Constructor
		function videomodel()
		{
				parent::Model();
				$this->load->model('usermodel');
		}
		function newVideo($videoDetails)
		{
				if (isset($videoDetails['video_type']) && trim($videoDetails['video_type']) != '')
				{
						$newVideoSQL = 'INSERT INTO videos
								(user_id, video_status, video_type, created_on, updated_on)
								VALUES
								(	' . $this->db->escape($this->session->userdata('user_id')) . ',
									' . $this->db->escape($videoDetails['video_status']) . ',
									' . $this->db->escape($videoDetails['video_type']) . ',
									NOW()' . ',
									NOW()' . '
								)';
						$this->db->query($newVideoSQL);
						if ($this->db->affected_rows() == 1)
						{
								return $this->db->insert_id();
						}
						else  return false;
				}
				else  return false;
		}
		function editVideoInfo($videoDetails)
		{
				if (isset($videoDetails['video_title']) && trim($videoDetails['video_title']) != '')
				{
						$this->db->where('video_id', $videoDetails['video_id']);
						$this->db->limit(1);
						$this->db->update('videos', array('video_title' => $videoDetails['video_title'], 'video_tags' => $videoDetails['video_tags'], 'video_description' => $videoDetails['video_description'], 'video_visibility_code' => $videoDetails['create_video_privacy']));
						return true;
				}
				else  return false;
		}
		###################################################################################################
		#Method			: video_to_frame()
		#Type			: sub
		#Description	: making video frames, from the video file
		#Arguments		: $video, $videoId
		#Arg.Expl.		: $video is the video path, $videoId is used to create thumb image
		##################################################################################################
		function video_to_frame($video, $videoId)
		{
				$this->load->library('image_lib');
				$userId = $this->session->userdata('user_id');
				//$mencoder		= $this->mencoder;
				$mplayer = '/usr/bin/mplayer';
				$videoDir = APPPATH . 'content/videos/user_' . $userId; //upload path
				$tempVideoPath = APPPATH . 'content/videos/user_' . $userId . '/temp'; //uploaded video full path
				$this->recursive_remove_directory($tempVideoPath, true);
				$cmd = $mplayer . " " . $video . " -ss 00:00:03 -nosound -vo jpeg:outdir=" . $tempVideoPath . " -frames 2";
				exec($cmd);
				$ff = $tempVideoPath . "/00000002.jpg";
				if (!file_exists($ff)) $ff = $tempVideoPath . "/00000001.jpg";
				if (!file_exists($ff)) $ff = APPPATH . "images/default_avatar.jpg";
				$thumbPath = $videoDir . '/video_' . $videoId . '_thumb.jpg';
				//Thumb creation
				if ($this->resizeImage($ff, 100, 75, $thumbPath)) return true;
				else  return false;
		} //end video_to_frame()
		// recursive_remove_directory( directory to delete, empty )
		// expects path to directory and optional TRUE / FALSE to empty
		// of course PHP has to have the rights to delete the directory
		// you specify and all files and folders inside the directory
		// ------------------------------------------------------------
		// to use this function to totally remove a directory, write:
		// recursive_remove_directory('path/to/directory/to/delete');
		// to use this function to empty a directory, write:
		// recursive_remove_directory('path/to/full_directory',TRUE);
		function recursive_remove_directory($directory, $empty = false)
		{
				// if the path has a slash at the end we remove it here
				if (substr($directory, -1) == '/')
				{
						$directory = substr($directory, 0, -1);
				}
				// if the path is not valid or is not a directory ...
				if (!file_exists($directory) || !is_dir($directory))
				{
						// ... we return false and exit the function
						return false;
						// ... if the path is not readable
				} elseif (!is_readable($directory))
				{
						// ... we return false and exit the function
						return false;
						// ... else if the path is readable
				}
				else
				{
						// we open the directory
						$handle = opendir($directory);
						// and scan through the items inside
						while (false !== ($item = readdir($handle)))
						{
								// if the filepointer is not the current directory
								// or the parent directory
								if ($item != '.' && $item != '..')
								{
										// we build the new path to delete
										$path = $directory . '/' . $item;
										// if the new path is a directory
										if (is_dir($path))
										{
												// we call this function with the new path
												recursive_remove_directory($path);
												// if the new path is a file
										}
										else
										{
												// we remove the file
												unlink($path);
										}
								}
						}
						// close the directory
						closedir($handle);
						// if the option to empty is not set to true
						if ($empty == false)
						{
								// try to delete the now empty directory
								if (!rmdir($directory))
								{
										// return false if not possible
										return false;
								}
						}
						// return success
						return true;
				}
		}
		function getVideoVisibilitySettings()
		{
				$res = $this->db->query('SELECT * FROM videos_visibility ORDER BY video_visibility_id');
				$visibilitySettings = array();
				if ($res->num_rows() > 0)
				{
						foreach ($res->result_array() as $row) $visibilitySettings[$row['video_visibility_code']] = $row['video_visibility_label'];
				}
				return $visibilitySettings;
		}
		#***************************************************************************
		#Method			: getVideos($userId)
		#Description	: returns video records for the given user
		#***************************************************************************
		function getVideoByUser($userId = '', $isMultiple = false)
		{
				$videos = array();
				if (($isMultiple and !empty($userId)) or $userId > 0 or $userId == '')
				{
						$this->db->select('user_id, video_id, video_title');
						$this->db->from('videos');
						//$this->db->join('users as u', 'nu.user_id = u.user_id', 'inner');
						if ($isMultiple) $this->db->where_in('user_id', $userId);
						elseif ($userId > 0) $this->db->where('user_id', $userId);
						$this->db->where('video_status', 'active');
						$this->db->order_by('updated_on', 'desc');
						$query = $this->db->get();
						$videos = array();
						if ($query->num_rows() > 0)
						{
								foreach ($query->result_array() as $row)
								{
										$videos[$row['video_id']] = $row;
										$videos[$row['video_id']]['created_by'] = $this->usermodel->getName($row['user_id']);
								}
						}
				}
				return $videos;
		} //end getVideos()
		#***************************************************************************
		#Method			: getVideo($userId)
		#Description	: returns video records for the given user
		#***************************************************************************
		function getVideo($videoId)
		{
				$this->db->select('user_id, video_id, video_title, video_tags, video_description, views, rate_count, rate_value, rate_avg, created_on, updated_on, video_visibility_code');
				$this->db->from('videos');
				//$this->db->join('users as u', 'nu.user_id = u.user_id', 'inner');
				$this->db->where('video_id', $videoId);
				$this->db->where('video_status', 'active');
				$this->db->limit(1, 0);
				$query = $this->db->get();
				$videos = array();
				if ($query->num_rows() > 0)
				{
						$videos = $query->row_array();
				}
				return $videos;
		} //end getVideos()
		function updateTable($table, $fieldArray, $conditionArray)
		{
				if (trim($table) != '' and !empty($fieldArray) and !empty($conditionArray))
				{
						foreach ($conditionArray as $key => $value) $this->db->where($key, $value);
						$this->db->limit(1);
						$this->db->update(trim($table), $fieldArray);
						return true;
				}
				else  return false;
		}
		function isRated($videoId)
		{
				$strSql = 'SELECT video_rate_id FROM videos_rate WHERE video_id=\'' . trim($videoId) . '\' AND user_id=\'' . trim($this->session->userdata('user_id')) . '\'';
				$resSQL = $this->db->query($strSql);
				if ($resSQL->num_rows() > 0) return true;
				else  return false;
		}
		function newRate($videoId, $rateValue)
		{
				$newVideoSQL = 'INSERT INTO videos_rate
							(user_id, video_id, rate_value, datestamp)
							VALUES
							(	' . $this->db->escape($this->session->userdata('user_id')) . ',
								' . $this->db->escape($videoId) . ',
								' . $this->db->escape($rateValue) . ',
								NOW()' . '
							)';
				$this->db->query($newVideoSQL);
				if ($this->db->affected_rows() == 1) return $this->db->insert_id();
				else  return false;
		}
		//function to find ratingAvg
		//accept ratecount and sum of ratevalue and
		//returns the corresponding rating image
		function getRatingImg($count, $rateSum)
		{
				//calculate rating average if content is rated,
				//atleast one time
				if ($rateSum > 0 and $count > 0)
				{
						$ratingAvg = round(($rateSum / $count), 1);
						//give rating image path depends on the
						//rating average
						if ($ratingAvg > 0 and $ratingAvg < 1)
								if ($ratingAvg >= 0.5) $rateImg = 'r0_half.gif';
								else  $rateImg = 'images/r0.gif';
						elseif ($ratingAvg >= 1 and $ratingAvg < 2)
								if ($ratingAvg >= 1.5) $rateImg = 'r1_half.gif';
								else  $rateImg = 'images/r1.gif';
						elseif ($ratingAvg >= 2 and $ratingAvg < 3)
								if ($ratingAvg >= 2.5) $rateImg = 'r2_half.gif';
								else  $rateImg = 'r2.gif';
						elseif ($ratingAvg >= 3 and $ratingAvg < 4)
								if ($ratingAvg >= 3.5) $rateImg = 'r3_half.gif';
								else  $rateImg = 'r3.gif';
						elseif ($ratingAvg >= 4 and $ratingAvg <= 5)
								if ($ratingAvg >= 4.5) $rateImg = 'r4_half.gif';
								else  $rateImg = 'r4.gif';
						elseif ($ratingAvg >= 5) $rateImg = 'r5.gif';
				}
				else  $rateImg = 'r0.gif';
				return $rateImg;
		}
		function getRateValues($videoId)
		{
				$this->db->select('COUNT(video_id) AS rate_count, SUM(rate_value) AS rate_sum');
				$this->db->from('videos_rate');
				//$this->db->join('users as u', 'nu.user_id = u.user_id', 'inner');
				$this->db->where('video_id', $videoId);
				$this->db->limit(1, 0);
				$query = $this->db->get();
				$rate = array();
				if ($query->num_rows() > 0)
				{
						$rate = $query->row_array();
				}
				return $rate;
		} //end getVideos()
		function isVideoOwner($videoId)
		{
				$strSql = 'SELECT video_id FROM videos WHERE video_id=\'' . trim($videoId) . '\' AND user_id=\'' . trim($this->session->userdata('user_id')) . '\'';
				$resSQL = $this->db->query($strSql);
				if ($resSQL->num_rows() > 0) return true;
				else  return false;
		}
		function deleteVideo($videoId)
		{
				$strSql = 'DELETE FROM videos WHERE video_id=\'' . trim($videoId) . '\'';
				$this->db->query($strSql);
				if ($this->db->affected_rows() > 0) return true;
				else  return false;
		}
		function resizeImage($imgFile, $width, $height, $thumbPath = '')
		{
				$config['image_library'] = 'GD2';
				$config['source_image'] = $imgFile;
				$config['create_thumb'] = false;
				$config['maintain_ratio'] = true;
				$config['width'] = $width;
				$config['height'] = $height;
				if ($thumbPath != '') $config['new_image'] = $thumbPath;
				$this->image_lib->initialize($config);
				if (!$this->image_lib->resize())
				{
						return $this->image_lib->display_errors('', '');
				}
				else  return true;
		}
		#***************************************************************************
		#Method			: isExist
		#Description	: checks whether the given video_id exist or not
		#Author			: ilayaraja_22ag06
		#***************************************************************************
		function isExist($videoId)
		{
				$sql = 'SELECT video_id FROM videos WHERE video_id=' . $videoId . ' AND video_status=\'active\'';
				$res = $this->db->query($sql);
				if ($res->num_rows() > 0) return true;
				else  return false;
		} //end isMember()
}

?>