<?php

/**
 * Terms Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 1/2/2008
 */
class Terms extends Controller
{
		//Constructor
		function Terms()
		{
				parent::Controller();
				//Load the language file
				$this->lang->load('login', $this->config->item('language_code'));
				$this->lang->load('terms', $this->config->item('language_code'));
		}
		//Default function
		function index()
		{
				$this->smartyextended->view('terms');
		}
}

?>