<?php
require_once ('../common/config.inc.php');
$CFG['lang']['include_files'][] = 'admin/includes/languages/%s/questionCategory.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['mods']['include_files'][] = 'common/classes/class_ListRecordsHandler.lib.php';
$CFG['html']['header'] = 'admin/includes/languages/%s/html_header.php';
$CFG['html']['footer'] = 'admin/includes/languages/%s/html_footer.php';
$CFG['db']['is_use_db'] = true;
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class QuestionCategoryFormHandler extends ListRecordsHandler
{
		public function buildConditionQuery()
		{
				$this->sql_condition = 'parent_id=0';
		}
		public function ConditionQuery()
		{
				$this->sql_condition = 'parent_id=\'' . addslashes($this->fields_arr['cat_id']) . '\'';
		}
		public function buildSortQuery()
		{
				$this->sql_sort = 'qc.cat_name ';
		}
		public function showCategory()
		{
				if (!$this->isResultsFound())
				{
?>
						<div id="selMsgAlert">
							<p><?php echo $this->LANG['no_records_found']; ?></p>
						</div>
					<?php
						return false;
				}
				if ($this->CFG['admin']['navigation']['top']) $this->populatePageLinks($this->getFormField('start'));
?>
				<table class="clsCommonTable" cellpadding="0" summary="<?php $this->LANG['category_view_tbl_summary']; ?>">
					<tr>
						<th>&nbsp;<input type="checkbox" name="checkall" id="checkall" tabindex="<?php echo $this->getTabIndex(); ?>" onclick="selectAll(this.form)"/></th>
						<th><?php echo $this->LANG['category_name']; ?></th>
						<th><?php echo $this->LANG['category_sub_category_count']; ?></th>
						<th><?php echo $this->LANG['category_question_count']; ?></th>
						<th><?php echo $this->LANG['category_status']; ?></th>
						<th><?php echo $this->LANG['category_date']; ?></th>
						<th></th>
					</tr>
				<?php
				$found = false;
				while ($row = $this->fetchResultRecord())
				{
?>
						<tr>
							<td>
								<input type="checkbox" name="cat_ids[]" value="<?php echo $row['cat_id'] ?>" onClick="disableHeading('formViewCategory');" tabindex="<?php echo $this->getTabIndex(); ?>" />
							</td>
							<td><?php echo $row['cat_name']; ?></td>
							<td><a href="questionCategory.php?mode=viewsubcategory&cat_id=<?php echo $row['cat_id']; ?>"><?php echo $this->countSubCategory($row['cat_id']); ?></a></td>
							<td><?php echo $row['total_questions']; ?></td>
							<td><?php echo $row['status']; ?></td>
							<td><?php echo $row['date_added']; ?></td>
							<td class="clsEditGroupLinks"><a class="clsEditGroupLink" href="questionCategory.php?cat_id=<?php echo $row['cat_id']; ?>&start=<?php echo $this->fields_arr['start']; ?>&mode=edit"><?php echo $this->LANG['category_edit']; ?></a></td>
						</tr>
					<?php
				}
?>
					<tr>
						<td colspan="7"  class="<?php echo $this->getCSSFormFieldCellClass('action'); ?>">
							<select name="action" id="action" tabindex="<?php echo $this->getTabIndex(); ?>" ><?php $this->populateFilterList($this->action_arr, $this->fields_arr['action']); ?></select>
							<a href="#" id="dAltMlti"></a>
							<input type="button" class="clsSubmitButton" name="category_action" id="category_action" onclick="getMultiCheckBoxValue('formViewCategory', 'checkall', '<?php echo $this->LANG['category_err_tip_select_category']; ?>', 'dAltMlti');if(multiCheckValue!=''){getAction()}" value="<?php echo $this->LANG['category_action']; ?>" tabindex="<?php echo $this->getTabIndex(); ?>" />
						</td>
					</tr>
				</table>
				<?php
				if ($this->CFG['admin']['navigation']['bottom']) $this->populatePageLinks($this->getFormField('start'));
		}
		public function showCategoryName($cat_id)
		{
				$sql = 'SELECT cat_name, cat_id FROM ' . $this->CFG['db']['tbl']['questions_category'] . ' WHERE cat_id=' . $this->dbObj->Param('cat_id');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($cat_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount())
				{
						$row = $rs->FetchRow();
						echo $row['cat_name'];
				}
		}
		public function showSubCategory()
		{
?>
				<h3><?php echo $this->LANG['category_name']; ?> : <?php echo $this->showCategoryName($this->fields_arr['cat_id']); ?></h3>
				<?php
				if (!$this->isResultsFound())
				{
?>
						<div id="selMsgAlert">
							<p><?php echo $this->LANG['no_records_found']; ?></p>
						</div>
					<?php
						return false;
				}
				if ($this->CFG['admin']['navigation']['top']) $this->populatePageLinks($this->getFormField('start'));
?>
				<table cellpadding="0" summary="<?php $this->LANG['category_view_tbl_summary']; ?>">
					<tr>
						<th>&nbsp;<input type="checkbox" name="checkall" id="checkall" tabindex="<?php echo $this->getTabIndex(); ?>" onclick="selectAll(this.form)"/></th>
						<th><?php echo $this->LANG['category_sub_name']; ?></th>
						<th><?php echo $this->LANG['category_question_count']; ?></th>
						<th><?php echo $this->LANG['category_status']; ?></th>
						<th><?php echo $this->LANG['category_date']; ?></th>
						<th></th>
					</tr>
				<?php
				$found = false;
				while ($row = $this->fetchResultRecord())
				{
?>
						<tr>
							<td>
								<input type="checkbox" name="cat_ids[]" value="<?php echo $row['cat_id'] ?>" onClick="disableHeading('formViewCategory');" tabindex="<?php echo $this->getTabIndex(); ?>" />
							</td>
							<td><?php echo $row['cat_name']; ?></td>
							<td><?php echo $row['total_questions']; ?></td>
							<td><?php echo $row['status']; ?></td>
							<td><?php echo $row['date_added']; ?></td>
							<td class="clsEditGroupLinks"><a class="clsEditGroupLink" href="questionCategory.php?sub_cat_id=<?php echo $row['cat_id']; ?>&start=<?php echo $this->fields_arr['start']; ?>&mode=editsubcategory"><?php echo $this->LANG['category_edit']; ?></a></td>
						</tr>
					<?php
				}
?>
					<tr>
						<td colspan="6"  class="<?php echo $this->getCSSFormFieldCellClass('action'); ?>">
							<select name="action" id="action" tabindex="<?php echo $this->getTabIndex(); ?>" ><?php $this->populateFilterList($this->action_arr, $this->fields_arr['action']); ?></select>
							<a href="#" id="dAltMlti"></a>
							<input type="button" name="category_action" id="category_action" onclick="if(getMultiCheckBoxValue('formViewCategory', 'checkall', '<?php echo $this->LANG['category_err_tip_select_category']; ?>')){getAction()}" value="<?php echo $this->LANG['category_action']; ?>" tabindex="<?php echo $this->getTabIndex(); ?>" />
						</td>
					</tr>
				</table>
				<?php
				if ($this->CFG['admin']['navigation']['bottom']) $this->populatePageLinks($this->getFormField('start'));
		}
		public function populateFilterList($array_to_expand, $highlight)
		{
				foreach ($array_to_expand as $key => $value)
				{
?>
		<option value="<?php echo $key; ?>" <?php echo ($key == $highlight) ? 'selected="selected"' : '' ?>><?php echo $value; ?></option>
<?php
				}
		}
		public function chkCategoryExists($err_tip = '')
		{
				$sql = 'SELECT COUNT(cat_id) AS count FROM ' . $this->CFG['db']['tbl']['questions_category'] . ' WHERE' . ' cat_name=' . $this->dbObj->Param($this->fields_arr['category']);
				$fields_value_array[] = $this->fields_arr['category'];
				if ($this->fields_arr['cat_id'])
				{
						$sql .= ' AND cat_id!=' . $this->dbObj->Param($this->fields_arr['cat_id']);
						$fields_value_array[] = $this->fields_arr['cat_id'];
				}
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, $fields_value_array);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = $rs->FetchRow();
				if ($row['count'])
				{
						$this->setCommonErrorMsg($err_tip);
						return false;
				}
				return true;
		}
		public function chkSubCategoryExists($err_tip = '')
		{
				$sql = 'SELECT COUNT(cat_id) AS count FROM ' . $this->CFG['db']['tbl']['questions_category'] . ' WHERE' . ' cat_name=' . $this->dbObj->Param($this->fields_arr['category']) . ' AND parent_id=' . $this->dbObj->Param($this->fields_arr['parent_id']);
				$fields_value_array[] = $this->fields_arr['category'];
				$fields_value_array[] = $this->fields_arr['parent_id'];
				if ($this->fields_arr['sub_cat_id'])
				{
						$sql .= ' AND cat_id!=' . $this->dbObj->Param($this->fields_arr['sub_cat_id']);
						$fields_value_array[] = $this->fields_arr['sub_cat_id'];
				}
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, $fields_value_array);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = $rs->FetchRow();
				if ($row['count'])
				{
						$this->setCommonErrorMsg($err_tip);
						return false;
				}
				return true;
		}
		public function isValidCategoryId($cat_id, $err_tip = '')
		{
				$sql = 'SELECT cat_name, parent_id, status FROM ' . $this->CFG['db']['tbl']['questions_category'] . ' WHERE cat_id=\'' . addslashes($this->fields_arr[$cat_id]) . '\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = array();
				if (!$rs->PO_RecordCount())
				{
						$this->setCommonErrorMsg($err_tip);
						return false;
				}
				$this->link_details_arr = $rs->FetchRow();
		}
		public function countSubCategory($cat_id)
		{
				$sql = 'SELECT COUNT(cat_id) as question_count FROM ' . $this->CFG['db']['tbl']['questions_category'] . ' WHERE parent_id =\'' . $cat_id . '\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = $rs->FetchRow();
				return $row['question_count'];
		}
		public function countQuestion($cat_id, $parent_id = 0)
		{
				if ($parent_id == 0) $cat_id = 'SELECT cat_id FROM ' . $this->CFG['db']['tbl']['questions_category'] . ' WHERE parent_id=\'' . addslashes($cat_id) . '\'';
				else  $cat_id = addslashes($cat_id);
				$sql = 'SELECT COUNT(ques_id) as question_count FROM ' . $this->CFG['db']['tbl']['questions'] . ' ' . 'WHERE cat_id IN (' . $cat_id . ')';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = $rs->FetchRow();
				return $row['question_count'];
		}
		public function insertCategory()
		{
				$sql = 'INSERT INTO ' . $this->CFG['db']['tbl']['questions_category'] . ' SET' . ' cat_name=\'' . addslashes($this->fields_arr['category']) . '\',' . ' parent_id=\'' . addslashes($this->fields_arr['parent_id']) . '\',' . ' status=\'' . addslashes($this->fields_arr['status']) . '\',' . ' date_added=NOW()';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return true;
		}
		public function updateCategory($cat_field)
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['questions_category'] . ' SET' . ' cat_name=\'' . addslashes($this->fields_arr['category']) . '\',' . ' parent_id=\'' . addslashes($this->fields_arr['parent_id']) . '\',' . ' status=\'' . addslashes($this->fields_arr['status']) . '\'' . ' WHERE cat_id = \'' . addslashes($this->fields_arr[$cat_field]) . '\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return true;
		}
		public function updateAction($fieldToUpdate, $fieldValue)
		{
				$cat_ids = $this->fields_arr['cat_ids'];
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['questions_category'] . ' SET ' . $fieldToUpdate . '=\'' . $fieldValue . '\' ' . ' WHERE cat_id IN (' . $cat_ids . ')';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return true;
		}
		public function populateCategories($parent_id)
		{
				$sql = 'SELECT cat_name, cat_id FROM ' . $this->CFG['db']['tbl']['questions_category'] . ' WHERE parent_id=0 ORDER BY cat_name';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount())
				{
						while ($row = $rs->FetchRow())
						{
?>
						<option value="<?php echo $row['cat_id']; ?>" <?php echo ($row['cat_id'] == $parent_id) ? 'selected' : ''; ?>><?php echo $row['cat_name']; ?></option>
						<?php
						}
				}
		}
		public function updateHasChild()
		{
				$cat_id = $this->fields_arr['cat_id'];
				$sql = 'SELECT 1 FROM ' . $this->CFG['db']['tbl']['questions_category'] . ' WHERE parent_id=' . $this->dbObj->Param($cat_id) . ' AND status=\'1\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($cat_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$has_child = '0';
				if ($rs->PO_RecordCount()) $has_child = '1';
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['questions_category'] . ' SET has_child=' . $this->dbObj->Param($has_child) . ' WHERE cat_id=' . $this->dbObj->Param($cat_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($has_child, $cat_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
}
$categoryfrm = new QuestionCategoryFormHandler();
$categoryfrm->setPageBlockNames(array('msg_form_error', 'msg_form_success', 'form_add_category', 'form_view_category', 'form_link_add_category', 'form_view_sub_category', 'form_link_add_sub_category', 'form_add_sub_category', 'form_link_view_category'));
$categoryfrm->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$categoryfrm->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$categoryfrm->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$categoryfrm->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$categoryfrm->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$categoryfrm->setDBObject($db);
$categoryfrm->setCfgLangGlobal($CFG, $LANG);
$categoryfrm->setFormField('user_id', '');
$categoryfrm->setFormField('category', '');
$categoryfrm->setFormField('parent_id', 0);
$categoryfrm->setFormField('status', 1);
$categoryfrm->setFormField('cat_id', '');
$categoryfrm->setFormField('sub_cat_id', '');
$categoryfrm->setFormField('cat_ids', array());
$categoryfrm->setFormField('sub_cat_ids', array());
$categoryfrm->setFormField('action', '');
$categoryfrm->setFormField('mode', '');
$action_arr = array('' => $LANG['category_select_action'], 'Active' => $LANG['category_activate'], 'Inactive' => $LANG['category_inactivate'], );
$categoryfrm->action_arr = $action_arr;
$categoryfrm->setAllPageBlocksHide();
$categoryfrm->setFormField('start', '0');
$categoryfrm->setFormField('numpg', $CFG['data_tbl']['numpg']);
$categoryfrm->setCSSColumnHeaderCellAscSortClasses(array('clsColumnHeaderCellAscSort1', 'clsColumnHeaderCellAscSort2', 'clsColumnHeaderCellAscSort3', 'clsColumnHeaderCellAscSort4', 'clsColumnHeaderCellAscSort5'));
$categoryfrm->setCSSColumnHeaderCellDefaultClass('clsColumnHeaderCellDefault');
$categoryfrm->setCSSColumnHeaderCellDescSortClasses(array('clsColumnHeaderCellDscSort1', 'clsColumnHeaderCellDscSort2', 'clsColumnHeaderCellDscSort3', 'clsColumnHeaderCellDscSort4', 'clsColumnHeaderCellDscSort5'));
$categoryfrm->setMinRecordSelectLimit(2);
$categoryfrm->setMaxRecordSelectLimit($CFG['data_tbl']['max_record_select_limit']);
$categoryfrm->setNumPerPageListArr($CFG['data_tbl']['numperpage_list_arr']);
$categoryfrm->setTableNames(array($CFG['db']['tbl']['questions_category'] . ' AS qc'));
$categoryfrm->setReturnColumns(array('qc.cat_id', 'qc.cat_name', 'qc.total_questions', 'CASE WHEN qc.status=1 THEN \'' . $LANG['category_status_active'] . '\' ELSE \'' . $LANG['category_status_inactive'] . '\' END AS status', 'qc.date_added'));
$categoryfrm->sanitizeFormInputs($_REQUEST);
$categoryfrm->setPageBlockShow('form_view_category');
$categoryfrm->setPageBlockShow('form_link_add_category');
$categoryfrm->setPageBlockShow('form_link_view_category');
if ($categoryfrm->isFormPOSTed($_POST, 'add_category'))
{
		$categoryfrm->chkIsNotEmpty('status', $LANG['category_err_tip_compulsory']);
		$categoryfrm->chkIsNotEmpty('category', $LANG['category_err_tip_compulsory']) and $categoryfrm->chkCategoryExists($LANG['category_err_tip_category_exists']);
		if ($categoryfrm->isValidFormInputs())
		{
				if ($categoryfrm->getFormField('cat_id'))
				{
						$categoryfrm->updateCategory('cat_id');
						$success_message = $LANG['category_success_update_message'];
				}
				else
				{
						$categoryfrm->insertCategory();
						$success_message = $LANG['category_success_message'];
				}
				$categoryfrm->setAllPageBlocksHide();
				$categoryfrm->setPageBlockShow('msg_form_success');
				$categoryfrm->setPageBlockShow('form_view_category');
				$categoryfrm->setPageBlockShow('form_link_add_category');
				$categoryfrm->setFormField('status', '');
				$categoryfrm->setFormField('category', '');
				$categoryfrm->setFormField('cat_id', '');
				$categoryfrm->setFormField('mode', '');
		}
		else
		{
				$categoryfrm->setAllPageBlocksHide();
				$categoryfrm->setPageBlockShow('form_link_add_category');
				$categoryfrm->setPageBlockShow('form_link_view_category');
				$categoryfrm->setPageBlockShow('form_add_category');
				$categoryfrm->setPageBlockShow('msg_form_error');
		}
} elseif ($categoryfrm->isFormPOSTed($_POST, 'add_sub_category'))
{
		$categoryfrm->chkIsNotEmpty('parent_id', $LANG['category_err_tip_compulsory']);
		$categoryfrm->chkIsNotEmpty('status', $LANG['category_err_tip_compulsory']);
		$categoryfrm->chkIsNotEmpty('category', $LANG['category_err_tip_compulsory']) and $categoryfrm->chkSubCategoryExists($LANG['category_err_tip_sub_category_exists']);
		if ($categoryfrm->isValidFormInputs())
		{
				if ($categoryfrm->getFormField('sub_cat_id'))
				{
						$categoryfrm->updateCategory('sub_cat_id');
						$success_message = $LANG['category_success_update_message'];
				}
				else
				{
						$categoryfrm->insertCategory();
						$success_message = $LANG['category_success_message'];
				}
				$categoryfrm->setAllPageBlocksHide();
				$categoryfrm->setPageBlockShow('msg_form_success');
				$categoryfrm->setPageBlockShow('form_view_sub_category');
				$categoryfrm->setPageBlockShow('form_link_add_category');
				$categoryfrm->setPageBlockShow('form_link_view_category');
				$categoryfrm->setPageBlockShow('form_link_add_sub_category');
				$categoryfrm->setFormField('cat_id', $categoryfrm->getFormField('parent_id'));
				$categoryfrm->setFormField('mode', '');
				$categoryfrm->updateHasChild();
		}
		else
		{
				$categoryfrm->setAllPageBlocksHide();
				$categoryfrm->setPageBlockShow('msg_form_error');
				$categoryfrm->setPageBlockShow('form_link_add_category');
				$categoryfrm->setPageBlockShow('form_link_view_category');
				$categoryfrm->setPageBlockShow('form_link_add_sub_category');
				$categoryfrm->setPageBlockShow('form_add_sub_category');
		}
} elseif ($categoryfrm->isFormPOSTed($_POST, 'confirm_action'))
{
		$categoryfrm->chkIsNotEmpty('cat_ids', $LANG['category_err_tip_compulsory']) or $categoryfrm->setCommonErrorMsg($LANG['category_err_tip_select_category']);
		$categoryfrm->chkIsNotEmpty('action', $LANG['category_err_tip_compulsory']) or $categoryfrm->setCommonErrorMsg($LANG['category_err_tip_select_action']);
		if ($categoryfrm->isValidFormInputs())
		{
				$categoryfrm->setAllPageBlocksHide();
				$categoryfrm->setPageBlockShow('msg_form_success');
				switch ($categoryfrm->getFormField('action'))
				{
						case 'Active':
								$categoryfrm->updateAction('status', '1');
								$success_message = $LANG['category_success_activate'];
								break;
						case 'Inactive':
								$categoryfrm->updateAction('status', '0');
								$success_message = $LANG['category_success_inactivate'];
								break;
				}
				if ($categoryfrm->getFormField('cat_id'))
				{
						$categoryfrm->setPageBlockShow('form_view_sub_category');
						$categoryfrm->setPageBlockShow('form_link_add_sub_category');
						$categoryfrm->updateHasChild();
				}
				else
				{
						$categoryfrm->setPageBlockShow('form_view_category');
				}
				$categoryfrm->setPageBlockShow('form_link_add_category');
				$categoryfrm->setPageBlockShow('form_link_view_category');
		}
		else
		{
				$categoryfrm->setAllPageBlocksHide();
				$categoryfrm->setPageBlockShow('msg_form_error');
		}
} elseif ($categoryfrm->isFormGETed($_GET, 'cat_id'))
{
		$categoryfrm->chkIsNotEmpty('cat_id', $LANG['category_err_tip_compulsory']) and $categoryfrm->isValidCategoryId('cat_id', $LANG['category_err_tip_invalid_id']);
		if ($categoryfrm->isValidFormInputs())
		{
				$categoryfrm->setFormField('category', $categoryfrm->link_details_arr['cat_name']);
				$categoryfrm->setFormField('status', $categoryfrm->link_details_arr['status']);
		}
		else
		{
				$categoryfrm->setAllPageBlocksHide();
				$categoryfrm->setPageBlockShow('msg_form_error');
		}
} elseif ($categoryfrm->isFormGETed($_GET, 'sub_cat_id'))
{
		$categoryfrm->chkIsNotEmpty('sub_cat_id', $LANG['category_err_tip_compulsory']) and $categoryfrm->isValidCategoryId('sub_cat_id', $LANG['category_err_tip_invalid_id']);
		if ($categoryfrm->isValidFormInputs())
		{
				$categoryfrm->setFormField('category', $categoryfrm->link_details_arr['cat_name']);
				$categoryfrm->setFormField('parent_id', $categoryfrm->link_details_arr['parent_id']);
				$categoryfrm->setFormField('status', $categoryfrm->link_details_arr['status']);
		}
		else
		{
				$categoryfrm->setAllPageBlocksHide();
				$categoryfrm->setPageBlockShow('msg_form_error');
		}
} elseif ($categoryfrm->isFormPOSTed($_POST, 'cancel'))
{
		$mode = $categoryfrm->getFormField('mode');
		$catId = $categoryfrm->getFormField('cat_id');
		if ($catId and strcmp($mode, 'editsubcategory') == 0) Redirect2URL($CFG['site']['relative_url'] . 'questionCategory.php?mode=viewsubcategory&cat_id=' . $catId);
		Redirect2URL($CFG['site']['relative_url'] . 'questionCategory.php');
}
if ($categoryfrm->isPageGETed($_GET, 'mode') && $categoryfrm->isValidFormInputs())
{
		$mode = $categoryfrm->getFormField('mode');
		$catId = $categoryfrm->getFormField('cat_id');
		$subCatId = $categoryfrm->getFormField('sub_cat_id');
		if ($catId and strcmp($mode, 'edit') == 0)
		{
				$categoryfrm->setAllPageBlocksHide();
				$categoryfrm->setPageBlockShow('form_link_add_category');
				$categoryfrm->setPageBlockShow('form_link_view_category');
				$categoryfrm->setPageBlockShow('form_add_category');
		} elseif ($subCatId and strcmp($mode, 'editsubcategory') == 0)
		{
				$categoryfrm->setAllPageBlocksHide();
				$categoryfrm->setPageBlockShow('form_link_add_category');
				$categoryfrm->setPageBlockShow('form_link_view_category');
				$categoryfrm->setPageBlockShow('form_link_add_sub_category');
				$categoryfrm->setPageBlockShow('form_add_sub_category');
		} elseif ($catId and strcmp($mode, 'viewsubcategory') == 0 and $categoryfrm->isValidFormInputs())
		{
				$categoryfrm->setAllPageBlocksHide();
				$categoryfrm->setPageBlockShow('form_view_sub_category');
				$categoryfrm->setPageBlockShow('form_link_add_category');
				$categoryfrm->setPageBlockShow('form_link_view_category');
				$categoryfrm->setPageBlockShow('form_link_add_sub_category');
		}
		else
				if (strcmp($mode, 'add') == 0)
				{
						$categoryfrm->setAllPageBlocksHide();
						$categoryfrm->setPageBlockShow('form_link_add_category');
						$categoryfrm->setPageBlockShow('form_link_view_category');
						$categoryfrm->setPageBlockShow('form_add_category');
				}
				else
						if (strcmp($mode, 'addsubcategory') == 0)
						{
								$categoryfrm->setAllPageBlocksHide();
								$categoryfrm->setPageBlockShow('form_link_add_category');
								$categoryfrm->setPageBlockShow('form_link_view_category');
								$categoryfrm->setPageBlockShow('form_link_add_sub_category');
								$categoryfrm->setPageBlockShow('form_add_sub_category');
						}
}




?>
<script type="text/javascript" language="javascript">
	var block_arr= new Array('selMsgConfirm');
	var replace_url = '<?php echo $CFG['site']['url']; ?>login.php';
	var please_select_action = '<?php echo $LANG['category_err_tip_select_action']; ?>';
	var confirm_message = '';
	function getAction()
		{
			var act_value = document.formViewCategory.action.value;
			if(act_value)
				{
					switch (act_value)
						{
							case 'Active':
								confirm_message = '<?php echo $LANG['category_activage_msg']; ?>';
								break;
							case 'Inactive':
								confirm_message = '<?php echo $LANG['category_inactivage_msg']; ?>';
								break;
						}
					$('confirmMessage').innerHTML = confirm_message;
					document.formConfirm.action.value = act_value;
					Confirmation('dAltMlti', 'selMsgConfirm', 'formConfirm', Array('cat_ids'), Array(multiCheckValue), Array('value'), -25, -290, 'formViewCategory');
				}
				else
					alert_manual(please_select_action, 'dAltMlti');
		}
</script>
<div id="selEditLinks">
	<h2 class="clsQuestionCategory"><?php echo $LANG['category_title']; ?></h2>
<div class="clsSubLink"><?php
if ($categoryfrm->isShowPageBlock('form_link_view_category'))
{
?>
		 <p><a href="questionCategory.php"><?php echo $LANG['list_categories']; ?></a></p>
<?php
}
if ($categoryfrm->isShowPageBlock('form_link_add_category'))
{
?>
		 <p><a href="questionCategory.php?mode=add"><?php echo $LANG['category_link_add_category']; ?></a></p>
<?php
}
if ($categoryfrm->isShowPageBlock('form_link_add_sub_category'))
{
?>
		 <p><a href="questionCategory.php?mode=addsubcategory"><?php echo $LANG['category_link_add_sub_category']; ?></a></p>
<?php
} ?></div><?php

if ($categoryfrm->isShowPageBlock('msg_form_error'))
{
?>
	<div id="selMsgError">
		 <p><?php echo $LANG['msg_error_sorry'] . ' ' . $categoryfrm->getCommonErrorMsg(); ?></p>
	</div>
<?php
}
if ($categoryfrm->isShowPageBlock('msg_form_success'))
{
?>
	<div id="selMsgSuccess">
		<p><?php echo $success_message; ?></p>
	</div>
<?php
}
if ($categoryfrm->isShowPageBlock('form_add_category'))
{
		$subTitle = $LANG['category_subtitle_add_category'];
		$borderColor = 'white';
		$catId = $categoryfrm->getFormField('cat_id');
		if ($catId)
		{
				$subTitle = $LANG['category_subtitle_edit_category'];
				$borderColor = '#A8CFA8';
		}

?>
	<div id="selEditLinks" style="border:1px solid <?php echo $borderColor; ?>;padding:1em;margin:1em">
	<h2 class="clsNewCategoryTitle"><?php echo $subTitle; ?></h2>
		<form name="formAddCategory" id="formAddCategory" method="post" action="<?php echo URL($_SERVER['REQUEST_URI']); ?>" autocomplete="off">
		<table class="clsCommonTable" summary="<?php echo $LANG['category_add_tbl_summary']; ?>">
		   <tr>
				<td class="<?php echo $categoryfrm->getCSSFormLabelCellClass('category'); ?>"><label for="category"><?php echo $LANG['category_name']; ?></label></td>
				<td class="<?php echo $categoryfrm->getCSSFormFieldCellClass('category'); ?>"><?php echo $categoryfrm->getFormFieldErrorTip('category'); ?><input type="text" class="clsTextBox" name="category" id="category" tabindex="<?php echo $categoryfrm->getTabIndex(); ?>" value="<?php echo $categoryfrm->getFormField('category'); ?>" maxlength="100" /></td>
		   </tr>
		   <tr>
				<td class="<?php echo $categoryfrm->getCSSFormLabelCellClass('status'); ?>"><label for="status_active"><?php echo $LANG['category_status']; ?></label></td>
				<td class="<?php echo $categoryfrm->getCSSFormFieldCellClass('status'); ?>"><?php echo $categoryfrm->getFormFieldErrorTip('status'); ?>
					<input type="radio" name="status" id="status_active" value="1" tabindex="<?php echo $categoryfrm->getTabIndex(); ?>" <?php if ($categoryfrm->getFormField('status') == '1') echo 'CHECKED'; ?> />&nbsp;<label for="status_active"><?php echo $LANG['category_status_active']; ?></label>
					&nbsp;&nbsp;
					<input type="radio" name="status" id="status_inactive" value="0" tabindex="<?php echo $categoryfrm->getTabIndex(); ?>" <?php if ($categoryfrm->getFormField('status') == '0') echo 'CHECKED'; ?> />&nbsp;<label for="status_inactive"><?php echo $LANG['category_status_inactive']; ?></label>
				</td>
		   </tr>
		   <tr>
           <td>&nbsp;</td>
				<td class="<?php echo $categoryfrm->getCSSFormFieldCellClass('submit'); ?>">
					<input type="submit" class="clsSubmitButton clsMediumSubmitButton" name="add_category" id="add_category" tabindex="<?php echo $categoryfrm->getTabIndex(); ?>" value="<?php if ($categoryfrm->getFormField('cat_id'))
		{
				echo $LANG['category_update'];
		}
		else
		{
				echo $LANG['category_add'];
		} ?>" />&nbsp;
					<?php if ($categoryfrm->getFormField('cat_id'))
		{ ?>
						<input type="submit" class="clsSubmitButton" name="cancel" id="cancel" tabindex="<?php echo $categoryfrm->getTabIndex(); ?>" value="<?php echo $LANG['category_cancel']; ?>" />
					<?php } ?>
				</td>
		   </tr>
		</table>
		<?php $categoryfrm->populateHiddenFormFields(array('start')); ?>
		</form>
	</div>
<?php
}
if ($categoryfrm->isShowPageBlock('form_add_sub_category'))
{
		$subTitle = $LANG['category_subtitle_add_sub_category'];
		$borderColor = 'white';
		$subCatId = $categoryfrm->getFormField('sub_cat_id');
		if ($subCatId)
		{
				$subTitle = $LANG['category_subtitle_edit_sub_category'];
				$borderColor = '#A8CFA8';
		}

?>
	<div id="selEditLinks" style="border:1px solid <?php echo $borderColor; ?>;padding:1em;margin:1em">
	<h2><?php echo $subTitle; ?></h2>
		<form name="formAddCategory" id="formAddCategory" method="post" action="<?php echo URL($_SERVER['REQUEST_URI']); ?>" autocomplete="off">
		<table class="clsCommonTable" summary="<?php echo $LANG['category_add_tbl_summary']; ?>">
		   <tr>
				<td class="<?php echo $categoryfrm->getCSSFormLabelCellClass('parent_id'); ?>"><label for="parent_id"><?php echo $LANG['category_name']; ?></label></td>
				<td class="<?php echo $categoryfrm->getCSSFormFieldCellClass('parent_id'); ?>"><?php echo $categoryfrm->getFormFieldErrorTip('parent_id'); ?><select name="parent_id" id="parent_id" tabindex="<?php echo $categoryfrm->getTabIndex(); ?>"><option value="">Choose...</option><?php $categoryfrm->populateCategories($categoryfrm->getFormField('parent_id')); ?></select></td>
		   </tr>
		   <tr>
				<td class="<?php echo $categoryfrm->getCSSFormLabelCellClass('category'); ?>"><label for="category"><?php echo $LANG['category_sub_name']; ?></label></td>
				<td class="<?php echo $categoryfrm->getCSSFormFieldCellClass('category'); ?>"><?php echo $categoryfrm->getFormFieldErrorTip('category'); ?><input type="text" class="clsTextBox" name="category" id="category" tabindex="<?php echo $categoryfrm->getTabIndex(); ?>" value="<?php echo $categoryfrm->getFormField('category'); ?>" maxlength="100" /></td>
		   </tr>
		   <tr>
				<td class="<?php echo $categoryfrm->getCSSFormLabelCellClass('status'); ?>"><label for="status_active"><?php echo $LANG['category_status']; ?></label></td>
				<td class="<?php echo $categoryfrm->getCSSFormFieldCellClass('status'); ?>"><?php echo $categoryfrm->getFormFieldErrorTip('status'); ?>
					<input type="radio" name="status" id="status_active" value="1" tabindex="<?php echo $categoryfrm->getTabIndex(); ?>" <?php if ($categoryfrm->getFormField('status') == '1') echo 'CHECKED'; ?> />&nbsp;<label for="status_active"><?php echo $LANG['category_status_active']; ?></label>
					&nbsp;&nbsp;
					<input type="radio" name="status" id="status_inactive" value="0" tabindex="<?php echo $categoryfrm->getTabIndex(); ?>" <?php if ($categoryfrm->getFormField('status') == '0') echo 'CHECKED'; ?> />&nbsp;<label for="status_inactive"><?php echo $LANG['category_status_inactive']; ?></label>
				</td>
		   </tr>
		   <tr>
				<td class="<?php echo $categoryfrm->getCSSFormFieldCellClass('submit'); ?>" colspan="2">
					<input type="submit" class="clsSubmitButton clsMediumSubmitButton" name="add_sub_category" id="add_sub_category" tabindex="<?php echo $categoryfrm->getTabIndex(); ?>" value="<?php if ($categoryfrm->getFormField('sub_cat_id'))
		{
				echo $LANG['category_update_sub'];
		}
		else
		{
				echo $LANG['category_add_sub'];
		} ?>" />&nbsp;
					<?php if ($categoryfrm->getFormField('sub_cat_id'))
		{ ?>
						<input type="submit" class="clsSubmitButton" name="cancel" id="cancel" tabindex="<?php echo $categoryfrm->getTabIndex(); ?>" value="<?php echo $LANG['category_cancel']; ?>" />
					<?php } ?>
				</td>
		   </tr>
		</table>
		<?php $categoryfrm->populateHiddenFormFields(array('start')); ?>
		</form>
	</div>
<?php
}
if ($categoryfrm->isShowPageBlock('form_view_category'))
{
		$categoryfrm->buildSelectQuery();
		$categoryfrm->buildConditionQuery();
		$categoryfrm->buildSortQuery();
		$categoryfrm->buildQuery();
		$categoryfrm->executeQuery();
?>
	<!-- Confirmation Div -->
	<div id="selMsgConfirm" class="selMsgConfirm" style="display:none;position:absolute;">
		<form name="formConfirm" id="formConfirm" method="post" action="questionCategory.php" autocomplete="off">
		<p id="confirmMessage"></p>
		<table class="clsCommonTable" summary="<?php echo $LANG['category_confirm_tbl_summary']; ?>">
			<tr>
		      	<td>
				  	<input type="submit" class="clsSubmitButton" name="confirm_action" id="confirm_action" value="<?php echo $LANG['category_confirm']; ?>" tabindex="<?php echo $categoryfrm->getTabIndex(); ?>" /> &nbsp;
		          	<input type="button" class="clsSubmitButton" name="cancel" id="cancel" value="<?php echo $LANG['category_cancel']; ?>" tabindex="<?php echo $categoryfrm->getTabIndex(); ?>" onClick="return hideAllBlocks('formViewCategory');" />
		          	<input type="hidden" name="cat_ids" />
		          	<input type="hidden" name="action" />
				</td>
	  		</tr>
		</table>
		<?php $categoryfrm->populateHiddenFormFields(array('start')); ?>
		</form>
	</div>

	<div id="selViewLinks">
		<form name="formViewCategory" id="formViewCategory" method="post" action="<?php echo URL($_SERVER['REQUEST_URI']); ?>" autocomplete="off">
			<?php $categoryfrm->showCategory(); ?>
		</form>
	</div>
<?php
}
if ($categoryfrm->isShowPageBlock('form_view_sub_category'))
{
		$categoryfrm->buildSelectQuery();
		$categoryfrm->ConditionQuery();
		$categoryfrm->buildSortQuery();
		$categoryfrm->buildQuery();
		$categoryfrm->executeQuery();
?>
	<!-- Confirmation Div -->
	<div id="selMsgConfirm" class="selMsgConfirm" style="display:none;position:absolute;">
		<form name="formConfirm" id="formConfirm" method="post" action="questionCategory.php?cat_id=<?php echo $categoryfrm->getFormField('cat_id'); ?>" autocomplete="off">
		<p id="confirmMessage"></p>
		<table class="clsCommonTable" summary="<?php echo $LANG['category_confirm_tbl_summary']; ?>">
			<tr>
		      	<td>
				  	<input type="submit" class="clsSubmitButton" name="confirm_action" id="confirm_action" value="<?php echo $LANG['category_confirm']; ?>" tabindex="<?php echo $categoryfrm->getTabIndex(); ?>" /> &nbsp;
		          	<input type="button" class="clsSubmitButton" name="cancel" id="cancel" value="<?php echo $LANG['category_cancel']; ?>" tabindex="<?php echo $categoryfrm->getTabIndex(); ?>" onClick="return hideAllBlocks('formViewCategory');" />
		          	<input type="hidden" name="cat_ids" />
		          	<input type="hidden" name="action" />
				</td>
	  		</tr>
		</table>
		<?php $categoryfrm->populateHiddenFormFields(array('start')); ?>
		</form>
	</div>

	<div id="selViewLinks">
		<form name="formViewCategory" id="formViewCategory" method="post" action="<?php echo URL($_SERVER['SCRIPT_NAME']); ?>" autocomplete="off">
			<?php $categoryfrm->showSubCategory(); ?>
		</form>
	</div>
<?php
}

?>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>