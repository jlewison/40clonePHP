<?php
$REDIRECT_URL = '';
$folder_name = substr($_SERVER['SCRIPT_NAME'], 0, strrpos($_SERVER['SCRIPT_NAME'], '/') + 1);
if (isset($_SESSION['user']['is_logged_in']) and !strstr($CFG['site']['current_url'], 'members/') and !strstr($CFG['site']['current_url'], 'admin/'))
{
		$CFG['site']['current_url'] = str_replace($CFG['site']['url'], $CFG['site']['url'] . 'members/', $CFG['site']['current_url']);
		$CFG['site']['relative_url'] = $CFG['site']['url'] . 'members/';
		$folder_name = substr($_SERVER['SCRIPT_NAME'], 0, strrpos($_SERVER['SCRIPT_NAME'], '/') + 1) . 'members/';
		Redirect2URL($CFG['site']['current_url']);
}
if (isset($_SESSION['user']['is_logged_in']) and (substr_count($CFG['site']['current_url'], $CFG['site']['url'] . 'members/') == 0)) $REDIRECT_URL = str_replace($CFG['site']['url'], $CFG['site']['url'] . 'members/', $CFG['site']['current_url']);
if ($CFG['license'])
		if (isset($_SESSION['user']['is_logged_in']) and (substr_count($CFG['site']['current_url'], $CFG['site']['url'] . 'admin/') != 0))
		{
				require_once ($CFG['site']['project_path'] . 'common/license/validate_license.php');
		}
if ((is_string($CFG['auth']['no_authenticate_folders']) && $CFG['auth']['no_authenticate_folders'] == '*') || (is_array($CFG['auth']['no_authenticate_folders']) && in_array($folder_name, $CFG['auth']['no_authenticate_folders'])))
{
		if (!isset($_SESSION['user']['is_admin']))
		{
				if ((ini_get('session.use_only_cookies') && isset($_COOKIE[session_name()])) or isset($_GET[session_name()]))
				{
						$_SESSION = array();
						$_SESSION['login_error'] = 'login_err_session_expired';
						$_SESSION['url'] = urlencode($CFG['site']['script_name']);
						Redirect2URL(RedirectAjaxPage());
				}
				$_SESSION = array();
				$_SESSION['login_error'] = 'login_err_authorization_required';
				$_SESSION['url'] = urlencode($CFG['site']['script_name']);
				Redirect2URL(RedirectAjaxPage());
		}
		else
		{
				if ($CFG['auth']['session']['strict']['is_check'])
				{
						$sql = 'SELECT ' . $CFG['users']['ip'] . ' AS ip, ' . $CFG['users']['session'] . ' AS session, ' . $CFG['users']['usr_status'] . ' FROM ' . $CFG['db']['tbl']['users'] . ' WHERE ' . $CFG['users']['user_id'] . '=' . $db->Param('user_id');
						$stmt = $db->Prepare($sql);
						$rs = $db->Execute($stmt, array($_SESSION['user']['user_id']));
						if (!$rs) trigger_error($db->ErrorNo() . ' ' . $db->ErrorMsg(), E_USER_ERROR);
						if ($rs->PO_RecordCount() == 0)
						{
								$_SESSION = array();
								$_SESSION['login_error'] = 'login_err_invalid_user_session';
								$_SESSION['url'] = urlencode($CFG['site']['script_name']);
								Redirect2URL(RedirectAjaxPage());
						}
						$row = $rs->FetchRow();
						if ($CFG['auth']['session']['strict']['is_check_session_spoof'] && session_id() != $row['session'])
						{
								$_SESSION = array();
								$_SESSION['login_error'] = 'login_err_invalid_session';
								$_SESSION['url'] = urlencode($CFG['site']['script_name']);
								Redirect2URL(RedirectAjaxPage());
						}
						if ($CFG['auth']['session']['strict']['is_check_ip_diff'] && $CFG['remote_client']['ip'] != $row['ip'])
						{
								$_SESSION = array();
								$_SESSION['login_error'] = 'login_err_wrong_ip';
								$_SESSION['url'] = urlencode($CFG['site']['script_name']);
								Redirect2URL(RedirectAjaxPage());
						}
				}
				else
				{
						if ($CFG['auth']['session']['is_check_useragent_diff'] && md5($_SERVER['HTTP_USER_AGENT']) != $_SESSION['user']['useragent_hash'])
						{
								$_SESSION = array();
								$_SESSION['login_error'] = 'login_err_wrong_user_agent';
								$_SESSION['url'] = urlencode($CFG['site']['script_name']);
								Redirect2URL(RedirectAjaxPage());
						}
				}
				$CFG['user']['user_id'] = $_SESSION['user']['user_id'];
				$CFG['user']['name'] = $_SESSION['user']['name'];
				$CFG['user']['email'] = $_SESSION['user']['email'];
				$CFG['user']['time_zone'] = $_SESSION['user']['time_zone'];
				$CFG['user']['pref_lang'] = $_SESSION['user']['pref_lang'];
				$CFG['user']['is_logged_in'] = $_SESSION['user']['is_logged_in'];
				if (isset($_SESSION['user']['is_admin'])) $CFG['user']['is_admin'] = $_SESSION['user']['is_admin'];
				if (isset($_SESSION['url']) and $_SESSION['url'])
				{
						$url = $_SESSION['url'];
						$_SESSION['url'] = '';
						Redirect2URL($CFG['site']['url'] . '' . urldecode($url));
				}
		}
}
else
		if ((is_string($CFG['auth']['protected_folders']) && $CFG['auth']['protected_folders'] == '*') || (is_array($CFG['auth']['protected_folders']) && in_array($folder_name, $CFG['auth']['protected_folders'])))
		{
				if (!isset($_SESSION['user']['is_logged_in']))
				{
						if (isset($REDIRECT_URL) and $REDIRECT_URL != '') Redirect2URL($REDIRECT_URL);
						if ((ini_get('session.use_only_cookies') && isset($_COOKIE[session_name()])) or isset($_GET[session_name()]))
						{
								$_SESSION = array();
								$_SESSION['login_error'] = 'login_err_session_expired';
								$_SESSION['url'] = urlencode($CFG['site']['script_name']);
								Redirect2URL(RedirectAjaxPage());
						}
						$_SESSION = array();
						$_SESSION['login_error'] = 'login_err_authorization_required';
						$_SESSION['url'] = urlencode($CFG['site']['script_name']);
						Redirect2URL(RedirectAjaxPage());
				}
				else
				{
						if ($CFG['auth']['session']['strict']['is_check'])
						{
								$sql = 'SELECT ' . $CFG['users']['ip'] . ' AS ip, ' . $CFG['users']['session'] . ' AS session, ' . $CFG['users']['usr_status'] . ' FROM ' . $CFG['db']['tbl']['users'] . ' WHERE ' . $CFG['users']['user_id'] . '=' . $db->Param('user_id');
								$stmt = $db->Prepare($sql);
								$rs = $db->Execute($stmt, array($_SESSION['user']['user_id']));
								if (!$rs) trigger_error($db->ErrorNo() . ' ' . $db->ErrorMsg(), E_USER_ERROR);
								if ($rs->PO_RecordCount() == 0)
								{
										$_SESSION = array();
										$_SESSION['login_error'] = 'login_err_invalid_user_session';
										$_SESSION['url'] = urlencode($CFG['site']['script_name']);
										Redirect2URL(RedirectAjaxPage());
								}
								$row = $rs->FetchRow();
								if ($CFG['auth']['session']['strict']['is_check_session_spoof'] && session_id() != $row['session'])
								{
										$_SESSION = array();
										$_SESSION['login_error'] = 'login_err_invalid_session';
										$_SESSION['url'] = urlencode($CFG['site']['script_name']);
										Redirect2URL(RedirectAjaxPage());
								}
								if ($CFG['auth']['session']['strict']['is_check_ip_diff'] && $CFG['remote_client']['ip'] != $row['ip'])
								{
										$_SESSION = array();
										$_SESSION['login_error'] = 'login_err_wrong_ip';
										$_SESSION['url'] = urlencode($CFG['site']['script_name']);
										Redirect2URL(RedirectAjaxPage());
								}
						}
						else
						{
								if ($CFG['auth']['session']['is_check_useragent_diff'] && md5($_SERVER['HTTP_USER_AGENT']) != $_SESSION['user']['useragent_hash'])
								{
										$_SESSION = array();
										$_SESSION['login_error'] = 'login_err_wrong_user_agent';
										$_SESSION['url'] = urlencode($CFG['site']['script_name']);
										Redirect2URL(RedirectAjaxPage());
								}
						}
						$CFG['user']['user_id'] = $_SESSION['user']['user_id'];
						$CFG['user']['name'] = $_SESSION['user']['name'];
						$CFG['user']['email'] = $_SESSION['user']['email'];
						$CFG['user']['time_zone'] = $_SESSION['user']['time_zone'];
						$CFG['user']['pref_lang'] = $_SESSION['user']['pref_lang'];
						$CFG['user']['is_logged_in'] = $_SESSION['user']['is_logged_in'];
						if (isset($_SESSION['user']['is_admin'])) $CFG['user']['is_admin'] = $_SESSION['user']['is_admin'];
						if (isset($_SESSION['url']) and strpos(urldecode($_SESSION['url']), 'dmin/') >= 1 and !$CFG['user']['is_admin'])
						{
								$url = $_SESSION['url'];
								$_SESSION['url'] = '';
								Redirect2URL($CFG['auth']['members_url']);
						}
						if (isset($_SESSION['url']) and $_SESSION['url'])
						{
								$url = $_SESSION['url'];
								$_SESSION['url'] = '';
								Redirect2URL($CFG['site']['url'] . '' . urldecode($url));
						}
				}
		}
		else
		{
				if (isset($REDIRECT_URL) and $REDIRECT_URL != '') Redirect2URL($REDIRECT_URL);
				if (isset($_SESSION['user']['is_logged_in']) && $_SESSION['user']['is_logged_in'] && !$_SESSION['user']['is_admin'])
				{
						Redirect2URL($CFG['auth']['members_url']);
				}
				else
						if (isset($_COOKIE[$CFG['cookie']['name'] . '_login']) and $_COOKIE[$CFG['cookie']['name'] . '_login'])
						{
								if (!stripos($_SERVER['SCRIPT_NAME'], 'logout.php') and !stripos($_SERVER['SCRIPT_NAME'], 'login.php') and !stripos($_SERVER['SCRIPT_NAME'], 'devlogin.php')) Redirect2URL($CFG['auth']['login_url']);
						}
		}
?>
