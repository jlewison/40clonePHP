<?php include('restrict.php'); include('../settings.php'); require_once('../Connections/apound.php'); ?>
<?php
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = (!get_magic_quotes_gpc()) ? addslashes($theValue) : $theValue;

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form1")) {
  $updateSQL = sprintf("UPDATE confset SET `path`=%s, paypal=%s, paypalcurrency=%s, contactmail=%s, adminmail=%s, currency=%s, currencymail=%s, pathmail=%s, frommail=%s, contactmailsubject=%s, domainname=%s, sitetitle=%s, custom=%s, lbdtemplate=%s, alphacat=%s, prenabled=%s, screenshot=%s, pstats=%s, overbid=%s, HP_ordby_F=%s, HP_ordby_O=%s, TL_ordby_F=%s, TL_ordby_O=%s, CL_ordby_F=%s, CL_ordby_O=%s, AL_ordby_F=%s, AL_ordby_O=%s, onoff=%s, htL=%s, google_m=%s, google_m_k=%s, lexv=%s, fremode=%s, fmwb=%s, fmau=%s, langu_id=%s, p_about=%s, p_terms=%s, p_top=%s, asubm=%s, linkbacka=%s WHERE indc=%s",
                       GetSQLValueString($_POST['path'], "text"),
                       GetSQLValueString($_POST['paypal'], "text"),
                       GetSQLValueString($_POST['paypalcurrency'], "text"),
                       GetSQLValueString($_POST['contactmail'], "text"),
                       GetSQLValueString($_POST['adminmail'], "text"),
                       GetSQLValueString($_POST['currency'], "text"),
                       GetSQLValueString($_POST['currencymail'], "text"),
                       GetSQLValueString($_POST['pathmail'], "text"),
                       GetSQLValueString($_POST['frommail'], "text"),
                       GetSQLValueString($_POST['contactmailsubject'], "text"),
                       GetSQLValueString($_POST['domainname'], "text"),
                       GetSQLValueString($_POST['sitetitle'], "text"),
                       GetSQLValueString($_POST['custom'], "text"),
                       GetSQLValueString($_POST['lbdtemplate'], "text"),
                       GetSQLValueString($_POST['alphacat'], "text"),
                       GetSQLValueString($_POST['prenabled'], "text"),
                       GetSQLValueString($_POST['screenshot'], "text"),
					   GetSQLValueString($_POST['pstats'], "text"),
					   GetSQLValueString($_POST['overbid'], "text"),
					   GetSQLValueString($_POST['HP_ordby_F'], "text"),
					   GetSQLValueString($_POST['HP_ordby_O'], "text"),
					   GetSQLValueString($_POST['TL_ordby_F'], "text"),
					   GetSQLValueString($_POST['TL_ordby_O'], "text"),
					   GetSQLValueString($_POST['CL_ordby_F'], "text"),
					   GetSQLValueString($_POST['CL_ordby_O'], "text"),
					   GetSQLValueString($_POST['AL_ordby_F'], "text"),
					   GetSQLValueString($_POST['AL_ordby_O'], "text"),
					   GetSQLValueString($_POST['onoff'], "text"),
					   GetSQLValueString($_POST['htL'], "text"),
					   GetSQLValueString($_POST['google_m'], "text"),
					   GetSQLValueString($_POST['google_m_k'], "text"),
					   GetSQLValueString($_POST['lexv'], "text"),
					   GetSQLValueString($_POST['fremode'], "text"),
					   GetSQLValueString($_POST['fmwb'], "text"),
					   GetSQLValueString($_POST['fmau'], "text"),
					   GetSQLValueString($_POST['langu_id'], "text"),
					   GetSQLValueString($_POST['p_about'], "text"),
					   GetSQLValueString($_POST['p_terms'], "text"),
					   GetSQLValueString($_POST['p_top'], "text"),
					   GetSQLValueString($_POST['asubm'], "text"),
					   GetSQLValueString($_POST['linkbacka'], "text"),
					   GetSQLValueString($_POST['indc'], "int"));

  mysql_select_db($database_apound, $apound);
  $Result1 = mysql_query($updateSQL, $apound) or die(mysql_error());

  $updateGoTo = "setup.php?upd=Y";
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $updateGoTo));
}

mysql_select_db($database_apound, $apound);
$query_STP = "SELECT * FROM confset";
$STP = mysql_query($query_STP, $apound) or die(mysql_error());
$row_STP = mysql_fetch_assoc($STP);
$totalRows_STP = mysql_num_rows($STP);

mysql_select_db($database_apound, $apound);
$query_TMS = "SELECT * FROM template";
$TMS = mysql_query($query_TMS, $apound) or die(mysql_error());
$row_TMS = mysql_fetch_assoc($TMS);
$totalRows_TMS = mysql_num_rows($TMS);

mysql_select_db($database_apound, $apound);
$query_curEN = "SELECT * FROM currency";
$curEN = mysql_query($query_curEN, $apound) or die(mysql_error());
$row_curEN = mysql_fetch_assoc($curEN);
$totalRows_curEN = mysql_num_rows($curEN);

mysql_select_db($database_apound, $apound);
$query_curENA = "SELECT * FROM currency";
$curENA = mysql_query($query_curENA, $apound) or die(mysql_error());
$row_curENA = mysql_fetch_assoc($curENA);
$totalRows_curENA = mysql_num_rows($curENA);

mysql_select_db($database_apound, $apound);
$query_LANL = "SELECT * FROM `language`";
$LANL = mysql_query($query_LANL, $apound) or die(mysql_error());
$row_LANL = mysql_fetch_assoc($LANL);
$totalRows_LANL = mysql_num_rows($LANL);
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>General Directory Setup - Link Bid Script Admin Panel</title>
<link rel="shortcut icon" href="img/favicon.ico" />
<link rel="stylesheet" type="text/css" href="admin.css" />
<style type="text/css">
<!--
.style84 {font-family: Verdana, Arial, Helvetica, sans-serif}
.style85 {font-size: 12px}
-->
</style>
</head>

<body>
<?php include('header_tpl.php'); ?>
<h2>General Directory Setup</h2>
<table width="770"  border="0" align="center" cellpadding="3" cellspacing="1" bgcolor="#FFFFFF">
  <tr>
    <td width="760" valign="top"><form method="post" name="form1" action="<?php echo $editFormAction; ?>">
        <?php $upd = $_GET[upd]; if($upd == 'Y') { echo("<div align='center'><font color='red'><b>Update ... DONE</b></font></div>"); } else { } ?>
        <table align="center" cellpadding="3" cellspacing="1">
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">Indc:</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td class="style74"><?php echo $row_STP['indc']; ?></td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">Path:</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td><input name="path" type="text" class="edtab" value="<?php echo $row_STP['path']; ?>" size="32"></td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">PayPal ID:</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td><input name="paypal" type="text" class="edtab" value="<?php echo $row_STP['paypal']; ?>" size="32"></td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">Paypal currency:</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td><input name="paypalcurrency" type="text" class="edtab" value="<?php echo $row_STP['paypalcurrency']; ?>" size="32"></td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">Contact email:</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td><input name="contactmail" type="text" class="edtab" value="<?php echo $row_STP['contactmail']; ?>" size="32"></td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">Admin email:</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td><input name="adminmail" type="text" class="edtab" value="<?php echo $row_STP['adminmail']; ?>" size="32"></td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">Currency:</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td><select name="currency" class="edtab">
              <?php 
do {  
?>
              <option value="<?php echo $row_curEN['curid']?>" <?php if (!(strcmp($row_curEN['curid'], $row_STP['currency']))) {echo "SELECTED";} ?>><?php echo $row_curEN['cursign']?></option>
              <?php
} while ($row_curEN = mysql_fetch_assoc($curEN));
?>
            </select>
            <!-- <input name="currency" type="text" class="edtab" value="<?php //echo $row_STP['currency']; ?>" size="32"> --></td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">Currency used on emails:</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td><select name="currencymail" class="edtab">
              <?php 
do {  
?>
              <option value="<?php echo $row_curENA['curid']?>" <?php if (!(strcmp($row_curENA['curid'], $row_STP['currencymail']))) {echo "SELECTED";} ?>><?php echo $row_curENA['cursign']?></option>
              <?php
} while ($row_curENA = mysql_fetch_assoc($curENA));
?>
            </select>
            <!-- <input name="currencymail" type="text" class="edtab" value="<?php //echo $row_STP['currencymail']; ?>" size="32"> --></td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">Path mail:</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td><input name="pathmail" type="text" class="edtab" value="<?php echo $row_STP['pathmail']; ?>" size="32"></td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">From mail:</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td><input name="frommail" type="text" class="edtab" value="<?php echo $row_STP['frommail']; ?>" size="32"></td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">Contact mail subject:</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td><input name="contactmailsubject" type="text" class="edtab" value="<?php echo $row_STP['contactmailsubject']; ?>" size="32"></td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">Domain name:</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td><input name="domainname" type="text" class="edtab" value="<?php echo $row_STP['domainname']; ?>" size="32"></td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">Site title:</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td><input name="sitetitle" type="text" class="edtab" value="<?php echo $row_STP['sitetitle']; ?>" size="32"></td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85"><input type="hidden" name="custom" value="1">
            Template:</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td><select name="lbdtemplate" class="edtab">
                <?php 
do {  
?>
                <option value="<?php echo $row_TMS['template']?>" <?php if (!(strcmp($row_TMS['template'], $row_STP['lbdtemplate']))) {echo "SELECTED";} ?>><?php echo $row_TMS['template']?></option>
                <?php
} while ($row_TMS = mysql_fetch_assoc($TMS));
?>
              </select>            </td>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">Navigation:</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td><select name="alphacat" class="edtab">
                <option value="Y" <?php if (!(strcmp("Y", $row_STP['alphacat']))) {echo "SELECTED";} ?>>Alphabet</option>
                <option value="N" <?php if (!(strcmp("N", $row_STP['alphacat']))) {echo "SELECTED";} ?>>Category</option>
                <option value="C" <?php if (!(strcmp("C", $row_STP['alphacat']))) {echo "SELECTED";} ?>>Both</option>
              </select>            </td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">PR &amp; Baclinks Info:</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td><select name="prenabled" class="edtab">
                <option value="Y" <?php if (!(strcmp("Y", $row_STP['prenabled']))) {echo "SELECTED";} ?>>Enable</option>
                <option value="N" <?php if (!(strcmp("N", $row_STP['prenabled']))) {echo "SELECTED";} ?>>Disable</option>
              </select>            </td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">Screenshot:</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td><select name="screenshot" class="edtab">
                <option value="Y" <?php if (!(strcmp("Y", $row_STP['screenshot']))) {echo "SELECTED";} ?>>Enable</option>
                <option value="N" <?php if (!(strcmp("N", $row_STP['screenshot']))) {echo "SELECTED";} ?>>Disable</option>
              </select>            </td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">Public Stats: </td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>
<select name="pstats" class="edtab">
<option value="Y" <?php if (!(strcmp("Y", $row_STP['pstats']))) {echo "SELECTED";} ?>>Enable</option>
<option value="N" <?php if (!(strcmp("N", $row_STP['pstats']))) {echo "SELECTED";} ?>>Disable</option>
</select>            </td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">Outbid email:</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>
<select name="overbid" class="edtab">
<option value="Y" <?php if (!(strcmp("Y", $row_STP['overbid']))) {echo "SELECTED";} ?>>Enable</option>
<option value="N" <?php if (!(strcmp("N", $row_STP['overbid']))) {echo "SELECTED";} ?>>Disable</option>
</select>            </td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">Home links  order by:</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>
<select name="HP_ordby_F" class="edtab">
<option value="bid" <?php if (!(strcmp("bid", $row_STP['HP_ordby_F']))) {echo "SELECTED";} ?>>Bid</option>
<option value="title" <?php if (!(strcmp("title", $row_STP['HP_ordby_F']))) {echo "SELECTED";} ?>>Title</option>
<option value="stad" <?php if (!(strcmp("stad", $row_STP['HP_ordby_F']))) {echo "SELECTED";} ?>>Date</option>
</select>

<select name="HP_ordby_O" class="edtab">
<option value="ASC" <?php if (!(strcmp("ASC", $row_STP['HP_ordby_O']))) {echo "SELECTED";} ?>>Ascending</option>
<option value="DESC" <?php if (!(strcmp("DESC", $row_STP['HP_ordby_O']))) {echo "SELECTED";} ?>>Descending</option>
</select>            </td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">Top links  order by:</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>
<select name="TL_ordby_F" class="edtab">
<option value="bid" <?php if (!(strcmp("bid", $row_STP['TL_ordby_F']))) {echo "SELECTED";} ?>>Bid</option>
<option value="title" <?php if (!(strcmp("title", $row_STP['TL_ordby_F']))) {echo "SELECTED";} ?>>Title</option>
<option value="stad" <?php if (!(strcmp("stad", $row_STP['TL_ordby_F']))) {echo "SELECTED";} ?>>Date</option>
</select>

<select name="TL_ordby_O" class="edtab">
<option value="ASC" <?php if (!(strcmp("ASC", $row_STP['TL_ordby_O']))) {echo "SELECTED";} ?>>Ascending</option>
<option value="DESC" <?php if (!(strcmp("DESC", $row_STP['TL_ordby_O']))) {echo "SELECTED";} ?>>Descending</option>
</select>            </td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">Category links order by:</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>
<select name="CL_ordby_F" class="edtab">
<option value="bid" <?php if (!(strcmp("bid", $row_STP['CL_ordby_F']))) {echo "SELECTED";} ?>>Bid</option>
<option value="title" <?php if (!(strcmp("title", $row_STP['CL_ordby_F']))) {echo "SELECTED";} ?>>Title</option>
<option value="stad" <?php if (!(strcmp("stad", $row_STP['CL_ordby_F']))) {echo "SELECTED";} ?>>Date</option>
</select>

<select name="CL_ordby_O" class="edtab">
<option value="ASC" <?php if (!(strcmp("ASC", $row_STP['CL_ordby_O']))) {echo "SELECTED";} ?>>Ascending</option>
<option value="DESC" <?php if (!(strcmp("DESC", $row_STP['CL_ordby_O']))) {echo "SELECTED";} ?>>Descending</option>
</select>            </td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">Alphabetic links ordered by:</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>
<select name="AL_ordby_F" class="edtab">
<option value="bid" <?php if (!(strcmp("bid", $row_STP['AL_ordby_F']))) {echo "SELECTED";} ?>>Bid</option>
<option value="title" <?php if (!(strcmp("title", $row_STP['AL_ordby_F']))) {echo "SELECTED";} ?>>Title</option>
<option value="stad" <?php if (!(strcmp("stad", $row_STP['AL_ordby_F']))) {echo "SELECTED";} ?>>Date</option>
</select>

<select name="AL_ordby_O" class="edtab">
<option value="ASC" <?php if (!(strcmp("ASC", $row_STP['AL_ordby_O']))) {echo "SELECTED";} ?>>Ascending</option>
<option value="DESC" <?php if (!(strcmp("DESC", $row_STP['AL_ordby_O']))) {echo "SELECTED";} ?>>Descending</option>
</select>            </td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">Site On/Off:</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>
<select name="onoff" class="edtab">
<option value="Y" <?php if (!(strcmp("Y", $row_STP['onoff']))) {echo "SELECTED";} ?>>Enable</option>
<option value="N" <?php if (!(strcmp("N", $row_STP['onoff']))) {echo "SELECTED";} ?>>Disable</option>
</select>            </td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">Home page links On/Off:</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>
<select name="htL" class="edtab">
<option value="Y" <?php if (!(strcmp("Y", $row_STP['htL']))) {echo "SELECTED";} ?>>Enable</option>
<option value="N" <?php if (!(strcmp("N", $row_STP['htL']))) {echo "SELECTED";} ?>>Disable</option>
</select>            </td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">Google Map On/Off:</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>
<select name="google_m" class="edtab">
<option value="Y" <?php if (!(strcmp("Y", $row_STP['google_m']))) {echo "SELECTED";} ?>>Enable</option>
<option value="N" <?php if (!(strcmp("N", $row_STP['google_m']))) {echo "SELECTED";} ?>>Disable</option>
</select>            </td>
          </tr>
          <tr valign="baseline">
            <td align="right" valign="top" nowrap class="style82 style84 style85">Google Map API Key:</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td><label>
              <textarea name="google_m_k" id="google_m_k" cols="45" rows="5"><?php echo $row_STP['google_m_k']; ?></textarea>
            </label></td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">Listing expiry mode:</td>
            <td valign="baseline">&nbsp;</td>
            <td valign="baseline">&nbsp;</td>
<td valign="baseline">
<select name="lexv" class="edtab">
<option value="LIMITED" <?php if (!(strcmp("LIMITED", $row_STP['lexv']))) {echo "SELECTED";} ?>>Expire in 365 days</option>
<option value="30" <?php if (!(strcmp("30", $row_STP['lexv']))) {echo "SELECTED";} ?>>Expire in 30 days</option>
<option value="60" <?php if (!(strcmp("60", $row_STP['lexv']))) {echo "SELECTED";} ?>>Expire in 60 days</option>
<option value="90" <?php if (!(strcmp("90", $row_STP['lexv']))) {echo "SELECTED";} ?>>Expire in 90 days</option>
<option value="UNLIMITED" <?php if (!(strcmp("UNLIMITED", $row_STP['lexv']))) {echo "SELECTED";} ?>>Never Expire</option>
</select></td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">LBS FREE mode:</td>
            <td valign="baseline">&nbsp;</td>
            <td valign="baseline">&nbsp;</td>
            <td valign="baseline"><label>
<select name="fremode" class="edtab">
<option value="Y" <?php if (!(strcmp("Y", $row_STP['fremode']))) {echo "SELECTED";} ?>>Enable</option>
<option value="N" <?php if (!(strcmp("N", $row_STP['fremode']))) {echo "SELECTED";} ?>>Disable</option>
</select>
            </label></td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">Free mode with Link Back mode:</td>
            <td valign="baseline">&nbsp;</td>
            <td valign="baseline">&nbsp;</td>
            <td valign="baseline"><select name="fmwb" class="edtab">
              <option value="Y" <?php if (!(strcmp("Y", $row_STP['fmwb']))) {echo "SELECTED";} ?>>Yes</option>
              <option value="N" <?php if (!(strcmp("N", $row_STP['fmwb']))) {echo "SELECTED";} ?>>No</option>
            </select></td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">Free mode auto approve:</td>
            <td valign="baseline">&nbsp;</td>
            <td valign="baseline">&nbsp;</td>
            <td valign="baseline">
<select name="fmau" class="edtab">
<option value="Y" <?php if (!(strcmp("Y", $row_STP['fmau']))) {echo "SELECTED";} ?>>Yes</option>
<option value="N" <?php if (!(strcmp("N", $row_STP['fmau']))) {echo "SELECTED";} ?>>No</option>
</select>
            </td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">Select language:</td>
            <td valign="baseline">&nbsp;</td>
            <td valign="baseline">&nbsp;</td>
            <td valign="baseline">
<select name="langu_id" id="langu_id">
  <?php
do {  
?>
  <option value="<?php echo $row_LANL['langu_id']?>"<?php if (!(strcmp($row_LANL['langu_id'], $row_STP['langu_id']))) {echo "selected=\"selected\"";} ?>><?php echo $row_LANL['langu_name']?></option>
  <?php
} while ($row_LANL = mysql_fetch_assoc($LANL));
  $rows = mysql_num_rows($LANL);
  if($rows > 0) {
      mysql_data_seek($LANL, 0);
	  $row_LANL = mysql_fetch_assoc($LANL);
  }
?>
</select>            </td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">Page About Us:</td>
            <td valign="baseline">&nbsp;</td>
            <td valign="baseline">&nbsp;</td>
            <td valign="baseline">
<select name="p_about" class="edtab">
<option value="Y" <?php if (!(strcmp("Y", $row_STP['p_about']))) {echo "SELECTED";} ?>>Enable</option>
<option value="N" <?php if (!(strcmp("N", $row_STP['p_about']))) {echo "SELECTED";} ?>>Disable</option>
</select>            </td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">Page Terms:</td>
            <td valign="baseline">&nbsp;</td>
            <td valign="baseline">&nbsp;</td>
            <td valign="baseline">
<select name="p_terms" class="edtab">
<option value="Y" <?php if (!(strcmp("Y", $row_STP['p_terms']))) {echo "SELECTED";} ?>>Enable</option>
<option value="N" <?php if (!(strcmp("N", $row_STP['p_terms']))) {echo "SELECTED";} ?>>Disable</option>
</select>            </td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">Page Top Links:</td>
            <td valign="baseline">&nbsp;</td>
            <td valign="baseline">&nbsp;</td>
            <td valign="baseline">
<select name="p_top" class="edtab">
<option value="Y" <?php if (!(strcmp("Y", $row_STP['p_top']))) {echo "SELECTED";} ?>>Enable</option>
<option value="N" <?php if (!(strcmp("N", $row_STP['p_top']))) {echo "SELECTED";} ?>>Disable</option>
</select>            </td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">Address Submission</td>
            <td valign="baseline">&nbsp;</td>
            <td valign="baseline">&nbsp;</td>
            <td valign="baseline">
<select name="asubm" class="edtab">
<option value="Y" <?php if (!(strcmp("Y", $row_STP['asubm']))) {echo "SELECTED";} ?>>Enable</option>
<option value="N" <?php if (!(strcmp("N", $row_STP['asubm']))) {echo "SELECTED";} ?>>Disable</option>
</select>
            </td>
          </tr>
          <tr valign="baseline">
            <td align="right" valign="top" nowrap class="style82 style84 style85">Back link URL:<br>
              (3 way link exchange)</td>
            <td valign="baseline">&nbsp;</td>
            <td valign="baseline">&nbsp;</td>
            <td valign="baseline"><label>
              <textarea name="linkbacka" id="linkbacka" cols="45" rows="5"><?php echo $row_STP['linkbacka']; ?></textarea>
            </label></td>
          </tr>
          <tr valign="baseline">
            <td nowrap align="right">&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td><input type="submit" class="login-but" value="Update record"></td>
          </tr>
        </table>
        <input type="hidden" name="MM_update" value="form1">
        <input type="hidden" name="indc" value="<?php echo $row_STP['indc']; ?>">
      </form>
    </td>
  </tr>
</table>
<?php include('footer_tpl.php'); ?>
</body>
</html>
<?php
mysql_free_result($STP);
mysql_free_result($TMS);

mysql_free_result($curEN);
?>
