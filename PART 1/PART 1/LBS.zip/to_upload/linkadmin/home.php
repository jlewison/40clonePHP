<?php include('restrict.php');
include('../settings.php');
require_once('../Connections/apound.php'); ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Link Bid Script - Admin Control Panel</title>
<link rel="shortcut icon" href="img/favicon.ico" />
<link rel="stylesheet" type="text/css" href="admin.css" />
<style type="text/css">
<!--
.style84 {color: #FF0000}
#admnav li {
	padding-top: 0px;
	padding-bottom: 0px;
	margin-top: 0px;
	margin-bottom: 0px;
}
#admnav ul {
	padding-top: 0px;
	padding-bottom: 0px;
	margin-top: 0px;
	margin-bottom: 0px;
}
.style86 {
	color: #CC0000;
	text-decoration: none;
}
#stats {
	font-weight: normal;
	font-size: 11px;
}
-->
</style>
</head>

<body>
<?php include('header_tpl.php'); ?>

<table width="770"  border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="770" bgcolor="#FFFFFF"><?php $x = getenv("HTTP_HOST").getenv("REQUEST_URI"); echo("<font color=white>$x</font>"); ?></td>
  </tr>
</table>
<table width="770"  border="0" align="center" cellpadding="3" cellspacing="1" bgcolor="#FFFFFF">
  <tr>
    <td width="484" valign="top" bgcolor="#FFFFFF"><div class="loginbut_D">Welcome to Bid Link Script. You can use the navigation links at the top or the links below to mange your sites configuration and your bidding control.</div>
        <p class="style67"><strong> Site Management </strong></p>
        <span class="style67"><strong> </strong></span>
        <table  border="0" cellpadding="0" cellspacing="0" id="admnav" width="100%">
          <tr>
            <td width="50%" valign="top"><ul>
                <li class="style63"><a href="../linkadmin/setup.php" class="style63 style66"> Site Configuration</a></li>
            </ul></td>
            <td width="50%" valign="top"><ul>
                <li class="style63"><a href="emailtemplates.php" class="style63 style66">Email Templates</a> </li>
            </ul></td>
          </tr>
          <tr>
            <td valign="top"><ul>
                <li class="style63"><a href="manage_admin.php" class="style63 style66">Manage Admin</a> </li>
            </ul></td>
            <td valign="top"><ul>
              <li class="style63"><a href="adsense.php" class="style66">Google Adsense</a> </li>
            </ul></td>
          </tr>
          <tr>
            <td valign="top"><ul>
                <li class="style63"><a href="template_add.php" class="style63 style66">Add Template</a> </li>
            </ul></td>
            <td valign="top"><ul>
              <li class="style63"><a href="manage_terms.php" class="style66">Manage Terms </a> </li>
            </ul></td>
          </tr>
          <tr>
            <td valign="top"><ul>
              <li class="style63"><a href="lnpp.php" class="style66">Link Number</a> </li>
            </ul></td>
            <td valign="top"><ul>
              <li class="style63"><a href="manage_fields.php" class="style66">Manage Link Fields</a> </li>
            </ul></td>
          </tr>
          <tr>
            <td valign="top"><ul>
              <li class="style63"><a href="badword.php" class="style66">Bad Word Filter</a> </li>
              <li class="style63"><a href="about.php" class="style66">About Us page management</a> </li>
            </ul></td>
            <td valign="top"><ul>
              <li class="style63"><a href="/sitemap.php" target="_blank" class="style66">Preview Google/Yahoo/MSN site map</a> </li>
            </ul></td>
          </tr>
          <tr>
            <td><ul>
              <li class="style63"><a href="welcome.php" class="style66">Welcome text management</a> </li>
            </ul></td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td><ul>
              <li class="style63"><a href="lang.php" class="style66">Language management</a> </li>
            </ul></td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td><ul class="style84"><li><a href="ip_ban.php" class="style86">IP Ban</a></li>
            </ul></td>
            <td><ul class="style84">
              <li><a href="pr_management.php" class="style86">SE Stats Management</a></li>
            </ul>            </td>
          </tr>
          <tr>
            <td><ul class="style84"><li><a href="domain_host_ban.php" class="style86">Domain/Host Ban</a></li>
            </ul></td>
            <td><ul class="style84">
              <li><a href="mysqldump.php" class="style86">MySQL Management</a></li>
            </ul></td>
          </tr>
          <tr>
            <td><ul class="style84">
              <li><a href="meta.php" class="style86">Meta Management</a></li>
            </ul></td>
            <td><ul class="style84">
              <li><a href="contactus.php" class="style86">CAPTCHA Configuration</a></li>
            </ul></td>
          </tr>
          <tr>
            <td><ul class="style84">
              <li><a href="add_listing.php" class="style86">Add link</a></li>
            </ul></td>
            <td><ul class="style84">
              <li><a href="captcha.php" class="style86">Advanced CAPTCHA settings</a></li>
            </ul></td>
          </tr>
          <tr>
            <td><!--<ul class="style84">
              <li><a href="googlecse.php" class="style86">Google CooP CSE</a></li>
            </ul> --></td>
            <td>&nbsp;</td>
          </tr>
        </table>
		  <table cellpadding="0" cellspacing="0" width="100%" style="margin-top:20px">
		  	<tr>
				<td align="left" valign="top" width="50%">
				  <p><span class="style67"><strong>Auction Management</strong>
					 </span>
				  </p>
				  <ul><li class="style63"> <a href="../linkadmin/manage_link.php" class="style63 style66">Link Management</a></li>
					 <li class="style63"> <a href="../linkadmin/manage_bid.php" class="style63 style66">Bid Management</a></li>
					 <li class="style63"> <a href="../linkadmin/manage_category.php" class="style63 style66">Category Management</a></li>
				  <li class="style63"> <a href="../linkadmin/manage_auction.php" class="style63 style66">Bid Settings</a></li>
				  </ul>
				</td>
				<td align="left" valign="top"><p><span class="style67"><strong> HELP! </strong></span></p>
        <ul>
         <li class="style63"> <a href="http://forums.linkbidscript.com/" target="_blank" class="style63 style66">Support Forum</a></li>
         <li class="style63"><a href="http://wiki.linkbidscript.com/"  class="style63 style66" target="_blank">Wiki</a></li>
        </ul>
			  </td>
			</tr>
		  </table>
	</td>
    <td width="281" valign="top" class="td_left"> 
	<table cellpadding="0" cellspacing="0" width="100%" class="shame">
		<tr>
			<td><table width="272" border="0" cellpadding="3" cellspacing="0" id="stats">
                <tr>
                  <td colspan="2" bgcolor="#E6FF6B"><strong>Your directory statistics:</strong></td>
                  </tr>
                <tr>
                  <td width="136" align="right">Total Links:</td>
                  <td width="136"><?php echo("$adm_link_f");?></td>
                </tr>
                <tr>
                  <td align="right">Active Links:</td>
                  <td><?php echo("$adm_link_a");?></td>
                </tr>
                <tr>
                  <td align="right">Pending Links:</td>
                  <td><?php echo("$adm_link_p");?></td>
                </tr>
                <tr>
                  <td align="right">Total Categories:</td>
                  <td><?php echo("$a_categ_a");?></td>
                </tr>
              </table>
			  </td>
		</tr>
		<tr height="30">
			<td align="center" ><a href="http://www.haabaa.com/" target="_blank">Haabaa Web Directory</a></td>
		</tr>
		<tr height="30">
			<td align="center"><a href="http://www.the-web-directory.co.uk/" target="_blank">The Web Directory</a></td>
		</tr>
		<tr height="30">
			<td align="center"><a href="http://www.webmasterserve.com/" target="_blank">UK Webmaster Forums</a></td>
		</tr>
		<tr height="30">
			<td align="center"></td>
		</tr>
	</table>			
	<table cellpadding="5" cellspacing="0" width="100%" id="contributors">
		<tr>
			<td colspan="2" style="font-size:12px; font-weight:bold; color:#026602">LBS Developers and Contributors</td>
		</tr>
		<tr bgcolor="#EEFDEE">
			<td width="54%" align="right">Link Bid Script Developed by:</td>
			<td width="46%">Temi Odurinde</td>
		</tr>
		<tr bgcolor="#DEFADE">
			<td align="right">LBS Main Programmer:</td>
			<td>Mihai Popa</td>
		</tr>
		<tr bgcolor="#EEFDEE">
			<td align="right">Special thanks to:</td>
			<td><a href="http://www.devhunters.com/" target="_blank">GH</a> and <a href="http://www.rswr.net/" target="_blank">Gorkfu</a></td>
		</tr>
		<tr bgcolor="#EEFDEE">
			<td align="right">User Documentation:</td>
			<td><a href="http://www.the-web-directory.co.uk/" target="_blank">GKD UK</a></td>
		</tr>
	</table>
	<div style="margin-top:15px;">Link Bid Script Copyright &copy;2006-<?php echo date("Y");?>, <a href="http://www.temi.co.uk/" target="_blank" style="color:#103210">Temi Odurinde</a></div>
	
	 </td>
  </tr>
</table>





<?php include('footer_tpl.php'); ?>
</body>
</html>