<?php include('template/redtheme/top_side.php');?>

<!--
###################################################################################
#######################                                     #######################
#######################   M A I N   S E C T I O N   Start   #######################
#######################                                     #######################
###################################################################################
-->
<div id="central">
  <h1><?php echo("$lang_134");?></h1>

  <table border="0" cellpadding="3" cellspacing="2" id="details">
 <tr>
  <td valign="top">
	<a href="<?php echo $row_UPBID['site']; ?>" target="_blank"><img src="http://open.thumbshots.org/image.aspx?url=<?php echo $row_UPBID['site']; ?>" alt="<?php echo $row_UPBID['title']; ?>" border="0" /></a><br />
	<?php echo("$lang_135");?> <?php echo $row_UPBID['bid']; ?> <?php echo("$lang_29");?>
  </td>
  <td valign="top">
	<a href="<?php echo $row_UPBID['site']; ?>" target="_blank"><?php echo $row_UPBID['title']; ?></a><br />
	<?php echo $row_UPBID['descr2']; ?><br />
	<br />
	<a href="<?php echo $row_UPBID['site']; ?>" target="_blank"><?php echo $row_UPBID['site']; ?></a>
  </td>
 </tr>
 <tr>
  <td valign="top"><strong><?php echo("$lang_95");?>:</strong></td>
  <td valign="top">
    <a href="<?php echo("$path");?><?php echo $row_LdetCAT['categseoname']; ?>/"><?php echo $row_LdetCAT['categoryname'] ?></a>
  </td>
 </tr>

		<?php if($prenabled == 'Y') { ?>

 <tr>
  <td valign="top"><strong><?php echo("$lang_100");?></strong></td>
  <td valign="top">

  		<?php
			$sitewww = $row_UPBID['site'];
			$sitewwwA = str_replace("http://", "", $sitewww);
			$googlepagerankA = "$sitewwwA";
			
			$sitewwwB = str_replace("/", "", $googlepagerankA);
			$googlepagerankB = "$sitewwwB";
		?>

        <img src="http://services.velnetweb.co.uk/gpr/gpr.php?sitepr=<?php echo("$sitewww");?>" border="0">
  </td>

 </tr>

		<?php } else {} ?>

 <tr>
  <td valign="top"><strong><?php echo("$lang_96");?></strong></td>
  <td valign="top"><?php echo $row_UPBID['stad']; ?></td>
 </tr>
 <tr>
  <td valign="top"><strong><?php echo("$lang_97");?></strong></td>
  <td valign="top"><?php echo $row_UPBID['stup']; ?></td>
 </tr>
</table>

<hr />

<div id="gene"><strong><?php echo("$lang_136");?> <?php echo $row_UPBID['bid']; ?> <?php echo("$lang_29");?></strong>

<hr />


  
  <form action="<?php echo("$path");?>upgrade.php" method="post" name="form1" onsubmit="return chkfrm();">
  <?php echo("$lang_137");?>  <?php echo("$currency");?> 
    <input name="newbid" type="text" id="newbid" value="<?php echo("$minup");?>" size="6" maxlength="6"  onchange="dodiv();" onkeypress="return chknum(event)" onkeyup="dodiv();" /> .00
    
    
<br /><br />

<?php echo("$lang_138");?> 
<?php echo("$currency");?>
<?php echo("$lang_139");?><br />
<?php echo("$lang_140");?> 
<?php echo("$currency");?><?php echo("$minup");?> 
<?php echo("$lang_141");?><br>
<br>
<?php echo("$lang_142");?> 
<input name="number" type="text" id=\&quot;number\&quot; /> 
<?php echo("$lang_143");?> 
<strong><font color="#FF0000">
<?php echo("$lang_144");?>
</font></strong> 
<?php echo("$lang_145");?><br>
<img src="<?php echo("$path");?>random_image.php">
    
    <input name="oldbid" type="hidden" id="oldbid" value="<?php echo $row_UPBID['bid']; ?>">
    <input name="bidid" type="hidden" value="<?php echo $row_UPBID['dtu']; ?>">
    <input name="url" type="hidden" id="url" value="<?php echo $row_UPBID['site']; ?>">
    <input name="keyword" type="hidden" id="keyword" value="<?php echo $row_UPBID['title']; ?>">
    <input name="email" type="hidden" id="email" value="<?php echo $row_UPBID['email']; ?>">
    <input name="submit" type="submit" value="Continue >>">
    </form>
</div>
</div>
<!--
###################################################################################
#######################                                     #######################
#######################    M A I N   S E C T I O N   End    #######################
#######################                                     #######################
###################################################################################
-->

<?php include('template/redtheme/bottom_side.php');?>
<?php include('template/redtheme/footer.php'); ?>