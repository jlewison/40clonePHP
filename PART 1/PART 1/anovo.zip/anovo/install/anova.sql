DROP TABLE IF EXISTS `abuse_answers`;
CREATE TABLE `abuse_answers` (
  `abuse_id` bigint(20) NOT NULL auto_increment,
  `ques_id` bigint(20) NOT NULL,
  `ans_id` bigint(20) NOT NULL,
  `reported_by` bigint(20) NOT NULL,
  `reason` varchar(250) collate latin1_general_ci NOT NULL,
  `date_abused` datetime NOT NULL,
  PRIMARY KEY  (`abuse_id`),
  KEY `ans_id` (`ans_id`,`reported_by`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

-- 
-- Table structure for table `abuse_blog`
-- 

DROP TABLE IF EXISTS `abuse_blog`;
CREATE TABLE `abuse_blog` (
  `abuse_id` bigint(20) NOT NULL auto_increment,
  `blog_id` bigint(20) NOT NULL,
  `reported_by` bigint(20) NOT NULL,
  `reason` varchar(250) collate latin1_general_ci NOT NULL,
  `date_abused` datetime NOT NULL,
  PRIMARY KEY  (`abuse_id`),
  KEY `blog_id` (`blog_id`,`reported_by`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

-- 
-- Table structure for table `abuse_forum`
-- 

DROP TABLE IF EXISTS `abuse_forum`;
CREATE TABLE `abuse_forum` (
  `abuse_id` bigint(20) NOT NULL auto_increment,
  `topic_id` bigint(20) NOT NULL,
  `reported_by` bigint(20) NOT NULL,
  `reason` varchar(250) collate latin1_general_ci NOT NULL,
  `date_abused` datetime NOT NULL,
  PRIMARY KEY  (`abuse_id`),
  KEY `topic_id` (`topic_id`,`reported_by`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

-- 
-- Table structure for table `abuse_questions`
-- 

DROP TABLE IF EXISTS `abuse_questions`;
CREATE TABLE `abuse_questions` (
  `abuse_id` bigint(20) NOT NULL auto_increment,
  `ques_id` bigint(20) NOT NULL,
  `reported_by` bigint(20) NOT NULL,
  `reason` varchar(250) collate latin1_general_ci NOT NULL,
  `date_abused` datetime NOT NULL,
  PRIMARY KEY  (`abuse_id`),
  KEY `ques_id` (`ques_id`,`reported_by`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

-- 
-- Table structure for table `advanced_search`
-- 

DROP TABLE IF EXISTS `advanced_search`;
CREATE TABLE `advanced_search` (
  `advanced_search_id` bigint(20) NOT NULL auto_increment,
  `user_id` bigint(20) NOT NULL,
  `answer` text collate latin1_general_ci NOT NULL,
  `forum` text collate latin1_general_ci NOT NULL,
  `blog` text collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`advanced_search_id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

-- 
-- Table structure for table `advertisement`
-- 

DROP TABLE IF EXISTS `advertisement`;
CREATE TABLE `advertisement` (
  `add_id` int(10) unsigned NOT NULL auto_increment,
  `user_id` bigint(20) NOT NULL default '0',
  `post_from` enum('User','Admin') collate latin1_general_ci NOT NULL default 'Admin',
  `block` varchar(100) collate latin1_general_ci NOT NULL default '',
  `about` text collate latin1_general_ci NOT NULL,
  `source` longtext collate latin1_general_ci NOT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `allowed_impressions` bigint(20) NOT NULL default '0',
  `completed_impressions` bigint(20) NOT NULL default '0',
  `add_type` enum('Porn','General') collate latin1_general_ci NOT NULL default 'General',
  `status` enum('activate','toactivate') collate latin1_general_ci NOT NULL default 'toactivate',
  `date_added` datetime NOT NULL,
  PRIMARY KEY  (`add_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

-- 
-- Table structure for table `ans_audio`
-- 

DROP TABLE IF EXISTS `ans_audio`;
CREATE TABLE `ans_audio` (
  `audio_id` bigint(20) NOT NULL auto_increment,
  `content_id` bigint(20) default NULL,
  `user_id` bigint(20) NOT NULL default '0',
  `audio_for` enum('Question','Answer') collate latin1_general_ci NOT NULL default 'Question',
  `audio_ext` varchar(5) collate latin1_general_ci NOT NULL,
  `audio_size` double NOT NULL,
  `playing_time` varchar(25) collate latin1_general_ci NOT NULL,
  `date_added` datetime default NULL,
  `audio_server_url` varchar(100) collate latin1_general_ci default NULL,
  `audio_status` enum('Ok','Deleted') collate latin1_general_ci NOT NULL default 'Ok',
  `audio_encoded_status` enum('No','Partial','Yes') collate latin1_general_ci NOT NULL default 'No',
  PRIMARY KEY  (`audio_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

-- 
-- Table structure for table `ans_video`
-- 

DROP TABLE IF EXISTS `ans_video`;
CREATE TABLE `ans_video` (
  `video_id` bigint(20) NOT NULL auto_increment,
  `content_id` bigint(20) default NULL,
  `user_id` bigint(20) NOT NULL default '0',
  `video_for` enum('Question','Answer') collate latin1_general_ci NOT NULL default 'Question',
  `video_ext` varchar(5) collate latin1_general_ci NOT NULL,
  `video_size` double NOT NULL,
  `playing_time` varchar(25) collate latin1_general_ci NOT NULL,
  `date_added` datetime default NULL,
  `t_width` int(11) default '0',
  `t_height` int(11) default '0',
  `video_server_url` varchar(100) collate latin1_general_ci default NULL,
  `video_status` enum('Ok','Deleted') collate latin1_general_ci NOT NULL default 'Ok',
  `video_encoded_status` enum('No','Partial','Yes') collate latin1_general_ci NOT NULL default 'No',
  PRIMARY KEY  (`video_id`),
  KEY `content_id` (`content_id`),
  KEY `video_for` (`video_for`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

-- 
-- Table structure for table `ans_video_advertisement`
-- 

DROP TABLE IF EXISTS `ans_video_advertisement`;
CREATE TABLE `ans_video_advertisement` (
  `advertisement_id` int(11) NOT NULL auto_increment,
  `user_id` bigint(20) NOT NULL,
  `advertisement_name` varchar(100) collate latin1_general_ci NOT NULL,
  `advertisement_description` text collate latin1_general_ci NOT NULL,
  `advertisement_url` varchar(500) collate latin1_general_ci NOT NULL,
  `advertisement_duration` int(11) NOT NULL,
  `advertisement_expiry_date` datetime NOT NULL,
  `advertisement_impressions` int(11) NOT NULL,
  `advertisement_channel` text collate latin1_general_ci NOT NULL,
  `advertisement_image` varchar(100) collate latin1_general_ci NOT NULL,
  `advertisement_ext` varchar(10) collate latin1_general_ci NOT NULL,
  `advertisement_show_at` enum('Begining','Ending','Both') collate latin1_general_ci NOT NULL default 'Begining',
  `advertisement_status` enum('Activate','Inactive') collate latin1_general_ci NOT NULL default 'Inactive',
  `date_added` datetime NOT NULL,
  `advertisement_current_impressions` int(11) NOT NULL,
  `views_revenue` double NOT NULL default '0',
  `clicks_revenue` double NOT NULL default '0',
  `total_views` bigint(20) NOT NULL default '0',
  `total_clicks` bigint(20) NOT NULL default '0',
  `site_earnings` double NOT NULL default '0',
  `members_earnings` double NOT NULL default '0',
  `add_type` enum('Porn','General') collate latin1_general_ci NOT NULL default 'General',
  PRIMARY KEY  (`advertisement_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

-- 
-- Table structure for table `ans_video_logo`
-- 

DROP TABLE IF EXISTS `ans_video_logo`;
CREATE TABLE `ans_video_logo` (
  `logo_id` tinyint(4) NOT NULL auto_increment,
  `logo_name` varchar(100) collate latin1_general_ci NOT NULL,
  `logo_description` text collate latin1_general_ci NOT NULL,
  `logo_url` varchar(500) collate latin1_general_ci NOT NULL,
  `logo_position` enum('Left_bottom','Left_top','Right_bottom','Right_top') collate latin1_general_ci NOT NULL default 'Left_bottom',
  `logo_transparency` int(11) NOT NULL,
  `logo_rollover_transparency` int(11) NOT NULL,
  `animated_logo` enum('yes','no') collate latin1_general_ci NOT NULL default 'no',
  `logo_image` varchar(100) collate latin1_general_ci NOT NULL,
  `logo_ext` varchar(10) collate latin1_general_ci NOT NULL,
  `mini_logo_image` varchar(100) collate latin1_general_ci NOT NULL,
  `mini_logo` enum('1','0') collate latin1_general_ci NOT NULL default '1',
  `mini_logo_ext` varchar(10) collate latin1_general_ci NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY  (`logo_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

-- 
-- Table structure for table `ans_video_player_settings`
-- 

DROP TABLE IF EXISTS `ans_video_player_settings`;
CREATE TABLE `ans_video_player_settings` (
  `player_settings_id` int(11) NOT NULL auto_increment,
  `play_settings` enum('1','0') collate latin1_general_ci NOT NULL default '1',
  `title` enum('1','0') collate latin1_general_ci NOT NULL default '0',
  `share_link` enum('1','0') collate latin1_general_ci NOT NULL default '0',
  `repeat_link` enum('1','0') collate latin1_general_ci NOT NULL default '1',
  `skin` varchar(50) collate latin1_general_ci NOT NULL,
  `play_list_settings` enum('1','0') collate latin1_general_ci NOT NULL default '1',
  `show_play_list_by` enum('tags','channel','random') collate latin1_general_ci NOT NULL default 'tags',
  `date_added` datetime NOT NULL,
  PRIMARY KEY  (`player_settings_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

-- 
-- Table structure for table `answers`
-- 

DROP TABLE IF EXISTS `answers`;
CREATE TABLE `answers` (
  `ans_id` bigint(20) NOT NULL auto_increment,
  `ques_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `video_id` bigint(20) default '0',
  `audio_id` bigint(20) default '0',
  `answer` text collate latin1_general_ci NOT NULL,
  `source` text collate latin1_general_ci NOT NULL,
  `total_stars` float(5,2) NOT NULL,
  `abuse_count` int(11) default '0',
  `date_answered` datetime NOT NULL,
  PRIMARY KEY  (`ans_id`),
  KEY `ques_id` (`ques_id`,`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

-- 
-- Table structure for table `blog_category`
-- 

DROP TABLE IF EXISTS `blog_category`;
CREATE TABLE `blog_category` (
  `blog_category_id` bigint(20) NOT NULL auto_increment,
  `blog_category_name` varchar(200) collate latin1_general_ci default NULL,
  `blog_category_description` text collate latin1_general_ci NOT NULL,
  `blog_category_status` enum('Yes','No') collate latin1_general_ci default 'Yes',
  `date_added` datetime default NULL,
  PRIMARY KEY  (`blog_category_id`),
  KEY `ind_catstatus_catid` (`blog_category_status`,`blog_category_id`),
  KEY `ind_catstatus_catname` (`blog_category_status`,`blog_category_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

-- 
-- Table structure for table `blog_comment`
-- 

DROP TABLE IF EXISTS `blog_comment`;
CREATE TABLE `blog_comment` (
  `comment_id` int(10) unsigned NOT NULL auto_increment,
  `blog_id` int(11) NOT NULL default '0',
  `user_id` int(11) NOT NULL default '0',
  `comment` text collate latin1_general_ci,
  `date_added` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`comment_id`),
  KEY `blog_id` (`blog_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

-- 
-- Table structure for table `blogs`
-- 

DROP TABLE IF EXISTS `blogs`;
CREATE TABLE `blogs` (
  `blog_id` int(10) unsigned NOT NULL auto_increment,
  `subject` varchar(100) collate latin1_general_ci default NULL,
  `message` text collate latin1_general_ci,
  `accept_comments` enum('Yes','No') collate latin1_general_ci NOT NULL default 'Yes',
  `user_id` bigint(11) NOT NULL default '0',
  `total_comments` int(11) NOT NULL default '0',
  `total_views` int(11) NOT NULL default '0',
  `total_stars` float(5,2) NOT NULL default '0.00',
  `status` enum('Toactivate','Active') collate latin1_general_ci NOT NULL default 'Active',
  `blog_category_id` bigint(20) NOT NULL default '0',
  `abuse_count` bigint(20) NOT NULL default '0',
  `date_added` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`blog_id`),
  KEY `user_blog_id` (`user_id`,`blog_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

-- 
-- Table structure for table `cron_master`
-- 

DROP TABLE IF EXISTS `cron_master`;
CREATE TABLE `cron_master` (
  `cron_id` bigint(20) NOT NULL auto_increment,
  `upto_id` bigint(20) default '0',
  `total` bigint(20) default '0',
  `start_time` datetime default NULL,
  `tot_finished_crons` bigint(20) default '0',
  `status` enum('Started','Finished') collate latin1_general_ci default 'Started',
  `cron_for` enum('Question','Message') collate latin1_general_ci default 'Question',
  PRIMARY KEY  (`cron_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

-- 
-- Table structure for table `forum_response`
-- 

DROP TABLE IF EXISTS `forum_response`;
CREATE TABLE `forum_response` (
  `response_id` bigint(20) NOT NULL auto_increment,
  `topic_id` bigint(20) default NULL,
  `forum_response` text collate latin1_general_ci,
  `response_user_id` bigint(20) default NULL,
  `response_status` enum('No','Yes') collate latin1_general_ci NOT NULL default 'Yes',
  `date_added` datetime default NULL,
  PRIMARY KEY  (`response_id`),
  KEY `ind_staus_date` (`response_status`,`date_added`),
  KEY `response_user_id` (`response_user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

-- 
-- Table structure for table `forum_topics`
-- 

DROP TABLE IF EXISTS `forum_topics`;
CREATE TABLE `forum_topics` (
  `topic_id` bigint(20) NOT NULL auto_increment,
  `forum_id` bigint(20) default NULL,
  `forum_topic` varchar(200) collate latin1_general_ci default NULL,
  `user_id` bigint(20) default NULL,
  `total_response` bigint(20) default NULL,
  `total_views` bigint(20) default NULL,
  `last_post_user_id` bigint(20) default NULL,
  `last_post_date` datetime default NULL,
  `rating_total` bigint(20) default '0',
  `rating_count` bigint(20) default '0',
  `topic_status` enum('Yes','No') collate latin1_general_ci default 'Yes',
  `abuse_count` bigint(20) NOT NULL default '0',
  `date_added` datetime default NULL,
  PRIMARY KEY  (`topic_id`),
  KEY `ind_status_forumid` (`topic_status`,`forum_id`),
  KEY `user_id` (`user_id`),
  KEY `last_post_user_id` (`last_post_user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

-- 
-- Table structure for table `forums`
-- 

DROP TABLE IF EXISTS `forums`;
CREATE TABLE `forums` (
  `forum_id` bigint(20) NOT NULL auto_increment,
  `forum_title` varchar(200) collate latin1_general_ci default NULL,
  `forum_description` text collate latin1_general_ci,
  `total_topics` bigint(20) default '0',
  `total_response` bigint(20) default '0',
  `last_post_user_id` bigint(20) default NULL,
  `last_post_date` datetime default NULL,
  `forum_status` enum('Yes','No') collate latin1_general_ci default 'Yes',
  `date_added` datetime default NULL,
  PRIMARY KEY  (`forum_id`),
  KEY `ind_status_title` (`forum_status`,`forum_title`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

-- 
-- Table structure for table `messages`
-- 

DROP TABLE IF EXISTS `messages`;
CREATE TABLE `messages` (
  `message_id` bigint(20) NOT NULL auto_increment,
  `subject` varchar(255) collate latin1_general_ci NOT NULL,
  `message` text collate latin1_general_ci NOT NULL,
  `mess_date` datetime NOT NULL,
  PRIMARY KEY  (`message_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

-- 
-- Table structure for table `messages_info`
-- 

DROP TABLE IF EXISTS `messages_info`;
CREATE TABLE `messages_info` (
  `info_id` bigint(20) NOT NULL auto_increment,
  `message_id` bigint(20) NOT NULL default '0',
  `to_id` bigint(20) NOT NULL default '0',
  `from_id` bigint(20) NOT NULL default '0',
  `to_viewed` enum('No','Yes') collate latin1_general_ci NOT NULL default 'No',
  `to_answer` enum('No','Reply','Forward') collate latin1_general_ci NOT NULL default 'No',
  `to_stored` enum('No','Yes') collate latin1_general_ci NOT NULL default 'No',
  `to_notify` enum('No','Yes') collate latin1_general_ci default 'No',
  `from_viewed` enum('No','Yes') collate latin1_general_ci NOT NULL default 'No',
  `from_answer` enum('No','Reply','Forward') collate latin1_general_ci NOT NULL default 'No',
  `from_stored` enum('No','Yes') collate latin1_general_ci NOT NULL default 'No',
  `to_delete` enum('No','Yes','Trash') collate latin1_general_ci NOT NULL default 'No',
  `from_delete` enum('No','Yes','Trash') collate latin1_general_ci NOT NULL default 'No',
  `email_status` enum('Normal','Alert') collate latin1_general_ci NOT NULL default 'Normal',
  `video_id` bigint(20) default NULL,
  `attachment` enum('No','Yes') collate latin1_general_ci NOT NULL default 'No',
  PRIMARY KEY  (`info_id`),
  KEY `message_id` (`message_id`,`to_id`),
  KEY `message_id_2` (`message_id`,`from_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

-- 
-- Table structure for table `news_letter`
-- 

DROP TABLE IF EXISTS `news_letter`;
CREATE TABLE `news_letter` (
  `news_letter_id` bigint(20) NOT NULL auto_increment,
  `subject` varchar(200) collate latin1_general_ci default NULL,
  `body` text collate latin1_general_ci,
  `date_added` datetime default NULL,
  `upto_user_id` bigint(20) default '0',
  `total_sent` bigint(20) default '0',
  `status` enum('Pending','Started','Finished') collate latin1_general_ci default 'Pending',
  `based_user_settings` enum('Yes','No') collate latin1_general_ci default 'Yes',
  `sql_condition` text collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`news_letter_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

-- 
-- Table structure for table `questions`
-- 

DROP TABLE IF EXISTS `questions`;
CREATE TABLE `questions` (
  `ques_id` bigint(20) NOT NULL auto_increment,
  `user_id` bigint(20) NOT NULL,
  `question` varchar(255) collate latin1_general_ci NOT NULL,
  `description` text collate latin1_general_ci NOT NULL,
  `video_id` bigint(20) default '0',
  `audio_id` bigint(20) default '0',
  `tags` varchar(255) collate latin1_general_ci NOT NULL,
  `pcat_id` int(11) NOT NULL,
  `cat_id` bigint(20) NOT NULL default '0',
  `total_answer` int(11) NOT NULL default '0',
  `total_videos` bigint(20) default '0',
  `total_audios` bigint(20) default '0',
  `total_stars` float(5,2) NOT NULL default '0.00',
  `total_views` int(11) NOT NULL default '0',
  `best_ans_id` bigint(20) NOT NULL default '0',
  `status` enum('Open','Resolved','Blocked','Deleted') collate latin1_general_ci NOT NULL default 'Open',
  `email_sent` enum('Yes','No') collate latin1_general_ci NOT NULL default 'No',
  `abuse_count` int(11) default '0',
  `date_answered` datetime NOT NULL,
  `date_asked` datetime NOT NULL,
  `date_closed` datetime NOT NULL,
  PRIMARY KEY  (`ques_id`),
  KEY `best_ans_id` (`best_ans_id`),
  KEY `status` (`status`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

-- 
-- Table structure for table `questions_category`
-- 

DROP TABLE IF EXISTS `questions_category`;
CREATE TABLE `questions_category` (
  `cat_id` bigint(20) NOT NULL auto_increment,
  `cat_name` varchar(100) collate latin1_general_ci NOT NULL,
  `parent_id` int(11) NOT NULL default '0',
  `has_child` enum('1','0') collate latin1_general_ci NOT NULL default '0',
  `status` enum('1','0') collate latin1_general_ci NOT NULL default '1',
  `total_questions` bigint(20) NOT NULL default '0',
  `date_added` datetime NOT NULL,
  PRIMARY KEY  (`cat_id`),
  KEY `parent_id` (`parent_id`),
  KEY `total_questions` (`total_questions`),
  KEY `status` (`status`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

-- 
-- Table structure for table `server_settings`
-- 

DROP TABLE IF EXISTS `server_settings`;
CREATE TABLE `server_settings` (
  `server_id` bigint(20) NOT NULL auto_increment,
  `server_url` varchar(100) collate latin1_general_ci default NULL,
  `server_for` enum('Ans_video','Ans_audio','Ans_photo') collate latin1_general_ci default NULL,
  `category` int(11) NOT NULL default '0',
  `server_status` enum('Yes','No') collate latin1_general_ci default 'No',
  `ftp_server` varchar(200) collate latin1_general_ci default NULL,
  `ftp_folder` varchar(50) collate latin1_general_ci NOT NULL,
  `ftp_usrename` varchar(100) collate latin1_general_ci default NULL,
  `ftp_password` varchar(100) collate latin1_general_ci default NULL,
  `date_added` datetime default NULL,
  PRIMARY KEY  (`server_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

-- 
-- Table structure for table `static_pages`
-- 

DROP TABLE IF EXISTS `static_pages`;
CREATE TABLE `static_pages` (
  `page_id` bigint(20) NOT NULL auto_increment,
  `page_title` varchar(50) collate latin1_general_ci NOT NULL,
  `page_display_title` varchar(255) collate latin1_general_ci NOT NULL,
  `page_content` text collate latin1_general_ci NOT NULL,
  `page_status` enum('Yes','No') collate latin1_general_ci NOT NULL default 'Yes',
  `page_added_date` datetime NOT NULL,
  PRIMARY KEY  (`page_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

-- 
-- Table structure for table `tags`
-- 

DROP TABLE IF EXISTS `tags`;
CREATE TABLE `tags` (
  `tag_id` bigint(20) NOT NULL auto_increment,
  `tag_name` varchar(255) collate latin1_general_ci NOT NULL,
  `search_count` bigint(20) NOT NULL default '0',
  `total_count` bigint(20) NOT NULL default '0',
  `last_searched` datetime NOT NULL,
  PRIMARY KEY  (`tag_id`),
  UNIQUE KEY `tag_name` (`tag_name`),
  KEY `total_count` (`total_count`),
  KEY `search_count` (`search_count`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

-- 
-- Table structure for table `user_bookmarked`
-- 

DROP TABLE IF EXISTS `user_bookmarked`;
CREATE TABLE `user_bookmarked` (
  `bookmark_id` bigint(20) NOT NULL auto_increment,
  `user_id` bigint(20) NOT NULL,
  `content_id` bigint(20) NOT NULL,
  `content_type` enum('Question','Forum','User') collate latin1_general_ci NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY  (`bookmark_id`),
  KEY `user_content_type` (`user_id`,`content_id`,`content_type`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

-- 
-- Table structure for table `user_ignored`
-- 

DROP TABLE IF EXISTS `user_ignored`;
CREATE TABLE `user_ignored` (
  `id` bigint(20) NOT NULL auto_increment,
  `user_id` bigint(20) NOT NULL default '0',
  `ignored_id` bigint(20) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `user_id` (`user_id`),
  KEY `ignored_id` (`ignored_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

-- 
-- Table structure for table `users`
-- 

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `user_id` bigint(20) NOT NULL auto_increment,
  `name` varchar(80) collate latin1_general_ci NOT NULL default '',
  `password` varchar(40) collate latin1_general_ci NOT NULL default '',
  `email` varchar(80) collate latin1_general_ci NOT NULL default '',
  `bio` text collate latin1_general_ci NOT NULL,
  `sex` enum('Male','Female') collate latin1_general_ci default 'Male',
  `img_path` text collate latin1_general_ci NOT NULL,
  `user_access` enum('User','Admin') collate latin1_general_ci default 'User',
  `usr_status` enum('Ok','ToActivate','Locked','Deleted') collate latin1_general_ci NOT NULL default 'ToActivate',
  `doj` datetime NOT NULL default '0000-00-00 00:00:00',
  `last_logged` datetime default NULL,
  `num_visits` int(11) NOT NULL default '0',
  `cookie` varchar(32) character set latin1 collate latin1_bin NOT NULL default '',
  `session` varchar(32) character set latin1 collate latin1_bin NOT NULL default '',
  `ip` varchar(15) character set latin1 collate latin1_bin NOT NULL default '',
  `signup_ip` varchar(15) character set latin1 collate latin1_bin NOT NULL default '',
  `time_zone` tinyint(4) NOT NULL default '0',
  `pref_lang` varchar(10) collate latin1_general_ci NOT NULL default '',
  `t_width` int(11) NOT NULL,
  `photo_server_url` varchar(255) collate latin1_general_ci NOT NULL,
  `t_height` int(11) NOT NULL,
  `s_height` int(11) NOT NULL,
  `s_width` int(11) NOT NULL,
  `l_width` int(11) NOT NULL default '0',
  `l_height` int(11) NOT NULL default '0',
  `photo_ext` varchar(255) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`user_id`),
  KEY `email` (`email`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci COMMENT='Prime table about user';

-- --------------------------------------------------------

-- 
-- Table structure for table `users_ans_log`
-- 

DROP TABLE IF EXISTS `users_ans_log`;
CREATE TABLE `users_ans_log` (
  `log_id` bigint(20) NOT NULL auto_increment,
  `user_id` bigint(20) NOT NULL,
  `total_ques` int(11) NOT NULL default '0',
  `total_ans` int(11) NOT NULL default '0',
  `total_points` int(11) NOT NULL default '0',
  `total_posts` int(11) default '0',
  `subscribe_keywords` text collate latin1_general_ci NOT NULL,
  `keyword_mail` enum('Yes','No') collate latin1_general_ci NOT NULL default 'Yes',
  `reply_mail` enum('Yes','No') collate latin1_general_ci NOT NULL default 'Yes',
  `favorite_mail` enum('Yes','No') collate latin1_general_ci NOT NULL default 'Yes',
  `best_ans_mail` enum('Yes','No') collate latin1_general_ci NOT NULL default 'Yes',
  `abuse_mail` enum('Yes','No') collate latin1_general_ci NOT NULL default 'Yes',
  `internal_mail` enum('Yes','No') collate latin1_general_ci NOT NULL default 'Yes',
  `news_letter` enum('Yes','No') collate latin1_general_ci NOT NULL default 'Yes',
  `index_block` text collate latin1_general_ci NOT NULL,
  `is_blocked` enum('Yes','No') collate latin1_general_ci NOT NULL default 'No',
  `style` char(15) collate latin1_general_ci NOT NULL default 'Default',
  `date_viewed` datetime NOT NULL,
  `date_updated` datetime NOT NULL,
  PRIMARY KEY  (`log_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

-- 
-- Table structure for table `users_stared_answer`
-- 

DROP TABLE IF EXISTS `users_stared_answer`;
CREATE TABLE `users_stared_answer` (
  `star_id` bigint(20) NOT NULL auto_increment,
  `user_id` bigint(20) NOT NULL,
  `ans_id` bigint(20) NOT NULL,
  `rating` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`star_id`),
  KEY `user_id` (`user_id`,`ans_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

-- 
-- Table structure for table `users_stared_blogs`
-- 

DROP TABLE IF EXISTS `users_stared_blogs`;
CREATE TABLE `users_stared_blogs` (
  `star_id` bigint(20) NOT NULL auto_increment,
  `user_id` bigint(20) NOT NULL,
  `blog_id` bigint(20) NOT NULL,
  `rating` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`star_id`),
  KEY `user_id` (`user_id`,`blog_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

-- 
-- Table structure for table `users_stared_question`
-- 

DROP TABLE IF EXISTS `users_stared_question`;
CREATE TABLE `users_stared_question` (
  `star_id` bigint(20) NOT NULL auto_increment,
  `user_id` bigint(20) NOT NULL,
  `ques_id` bigint(20) NOT NULL,
  `rating` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`star_id`),
  KEY `user_id` (`user_id`,`ques_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

-- 
-- Table structure for table `widget_log`
-- 

DROP TABLE IF EXISTS `widget_log`;
CREATE TABLE `widget_log` (
  `widget_id` int(11) NOT NULL auto_increment,
  `widget_name` varchar(255) collate latin1_general_ci NOT NULL,
  `id_1` bigint(20) NOT NULL default '0',
  `id_2` bigint(20) NOT NULL default '0',
  `id_3` bigint(20) NOT NULL default '0',
  `id_4` bigint(20) NOT NULL default '0',
  `id_5` bigint(20) NOT NULL default '0',
  `id_6` bigint(20) NOT NULL default '0',
  `id_7` bigint(20) NOT NULL default '0',
  `id_8` bigint(20) NOT NULL default '0',
  `id_9` bigint(20) NOT NULL default '0',
  `id_10` bigint(20) NOT NULL default '0',
  `date_updated` datetime NOT NULL,
  PRIMARY KEY  (`widget_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;


--
-- Dumping data for table `questions_category`
--

INSERT INTO `questions_category` (`cat_id`, `cat_name`, `parent_id`, `status`, `date_added`) VALUES (1, 'Arts &amp; Humanities', 0, '1', '2007-04-09 17:37:55');
INSERT INTO `questions_category` (`cat_id`, `cat_name`, `parent_id`, `status`, `date_added`) VALUES (2, 'Beauty &amp; Style', 0, '1', '2007-04-09 17:48:40');
INSERT INTO `questions_category` (`cat_id`, `cat_name`, `parent_id`, `status`, `date_added`) VALUES (3, 'Business &amp; Finance', 0, '1', '2007-04-09 17:48:48');
INSERT INTO `questions_category` (`cat_id`, `cat_name`, `parent_id`, `status`, `date_added`) VALUES (4, 'Cars &amp; Transportation', 0, '1', '2007-04-09 17:48:57');
INSERT INTO `questions_category` (`cat_id`, `cat_name`, `parent_id`, `status`, `date_added`) VALUES (5, 'Computers &amp; Internet', 0, '1', '2007-04-09 17:49:06');
INSERT INTO `questions_category` (`cat_id`, `cat_name`, `parent_id`, `status`, `date_added`) VALUES (6, 'Dining Out', 0, '1', '2007-04-09 17:49:14');
INSERT INTO `questions_category` (`cat_id`, `cat_name`, `parent_id`, `status`, `date_added`) VALUES (7, 'Entertainment &amp; Music', 0, '1', '2007-04-10 11:30:59');
INSERT INTO `questions_category` (`cat_id`, `cat_name`, `parent_id`, `status`, `date_added`) VALUES (8, 'Books &amp; Authors', 1, '1', '2007-04-10 11:34:12');
INSERT INTO `questions_category` (`cat_id`, `cat_name`, `parent_id`, `status`, `date_added`) VALUES (9, 'Family &amp; Relations', 0, '1', '2007-04-10 11:43:05');
INSERT INTO `questions_category` (`cat_id`, `cat_name`, `parent_id`, `status`, `date_added`) VALUES (10, 'Sports', 0, '1', '2007-04-10 11:43:48');

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `name`, `password`, `email`, `bio`, `sex`, `img_path`, `user_access`, `usr_status`, `doj`, `last_logged`, `num_visits`, `cookie`, `session`, `ip`, `signup_ip`, `time_zone`, `pref_lang`, `t_width`, `photo_server_url`, `t_height`, `s_height`, `s_width`, `l_width`, `l_height`, `photo_ext`) VALUES (1, 'webmaster', '50a9c7dbf0fa09e8969978317dca12e8', 'email@domain.tld', 'This is admin account', 'Male', '', 'Admin', 'Ok', '2008-02-22 00:00:00', '2008-02-22 13:51:29', 1, '', 0x3863643262666333653935316233663533633464366364663363353731653764, 0x3139322e3136382e312e3839, '', 0, '', 0, '', 0, 0, 0, 0, 0, '');
INSERT INTO `users` (`user_id`, `name`, `password`, `email`, `bio`, `sex`, `img_path`, `user_access`, `usr_status`, `doj`, `last_logged`, `num_visits`, `cookie`, `session`, `ip`, `signup_ip`, `time_zone`, `pref_lang`, `t_width`, `photo_server_url`, `t_height`, `s_height`, `s_width`, `l_width`, `l_height`, `photo_ext`) VALUES (2, 'demo', 'fe01ce2a7fbac8fafaed7c982a04e229', 'email@domain.tld', 'This is demo user account', 'Male', '', 'User', 'Ok', '2008-02-22 00:00:00', '2008-02-22 13:56:58', 1, '', 0x6465653231393434396264346638353439323864383338323635356431643435, 0x3139322e3136382e312e3839, '', 0, '', 0, '', 0, 0, 0, 0, 0, '');


-- 
-- Dumping data for table `users_ans_log`
-- 

INSERT INTO `users_ans_log` (`log_id`, `user_id`, `total_ques`, `total_ans`, `total_points`, `total_posts`, `subscribe_keywords`, `keyword_mail`, `reply_mail`, `favorite_mail`, `best_ans_mail`, `abuse_mail`, `internal_mail`, `news_letter`, `index_block`, `is_blocked`, `style`, `date_viewed`, `date_updated`) VALUES (1, 1, 0, 0, 0, 0, '', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', '', 'No', 'Default', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `users_ans_log` (`log_id`, `user_id`, `total_ques`, `total_ans`, `total_points`, `total_posts`, `subscribe_keywords`, `keyword_mail`, `reply_mail`, `favorite_mail`, `best_ans_mail`, `abuse_mail`, `internal_mail`, `news_letter`, `index_block`, `is_blocked`, `style`, `date_viewed`, `date_updated`) VALUES (2, 2, 0, 0, 0, 0, '', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', '', 'No', 'Default', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- 
-- Dumping data for table `advanced_search`
-- 

INSERT INTO `advanced_search` (`advanced_search_id`, `user_id`, `answer`, `forum`, `blog`) VALUES (1, 1, '', '', '');
INSERT INTO `advanced_search` (`advanced_search_id`, `user_id`, `answer`, `forum`, `blog`) VALUES (2, 2, '', '', '');

--
-- Dumping data for table `blog_category`
--

INSERT INTO `blog_category` SET `blog_category_name`='Arts &amp; Humanities', `date_added`=NOW();

--
-- Dumping data for table `forums`
--

INSERT INTO `forums` ( `forum_id` , `forum_title` , `forum_description` , `total_topics` , `total_response` , `last_post_user_id` , `last_post_date` , `forum_status` , `date_added` ) VALUES ( '', 'General Discussion', 'General Discussion', '0', '0', NULL , NULL , 'Yes', NOW( ) );

--
-- Dumping data for table `static_pages`
--

INSERT INTO `static_pages` (`page_title`, `page_content`, `page_added_date`) VALUES ('faq', '<div>\r\n faq contents, faq contents, faq contents, faq contents,  \r\n</div>', NOW());
INSERT INTO `static_pages` (`page_title`, `page_content`, `page_added_date`) VALUES ('privacy', '<div>\r\n privacy contents, privacy contents, privacy contents, privacy contents,  \r\n</div>', NOW());
INSERT INTO `static_pages` (`page_title`, `page_content`, `page_added_date`) VALUES ('terms', '<div>\r\n terms contents, terms contents, termscontents, terms contents,  \r\n</div>', NOW());

--
-- Dumping data for table `cron_master`
--

INSERT INTO `cron_master` (`cron_id`, `upto_id`, `total`, `start_time`, `tot_finished_crons`, `status`, `cron_for`) VALUES (1, 0, 0, NOW(), 0, 'Started', 'Question');
INSERT INTO `cron_master` (`cron_id`, `upto_id`, `total`, `start_time`, `tot_finished_crons`, `status`, `cron_for`) VALUES (2, 0, 0, NOW(), 0, 'Started', 'Message');
INSERT INTO `cron_master` (`cron_id`, `upto_id`, `total`, `start_time`, `tot_finished_crons`, `status`, `cron_for`) VALUES (3, 0, 0, NOW(), 0, 'Started', 'favorite');
INSERT INTO `cron_master` (`cron_id`, `upto_id`, `total`, `start_time`, `tot_finished_crons`, `status`, `cron_for`) VALUES (4, 0, 0, NOW(), 0, 'Started', 'forums');
INSERT INTO `cron_master` (`cron_id`, `upto_id`, `total`, `start_time`, `tot_finished_crons`, `status`, `cron_for`) VALUES (5, 0, 0, NOW(), 0, 'Started', 'blogs');

--
-- Dumping data for table `ans_video_player_settings`
--

INSERT INTO `ans_video_player_settings` (`player_settings_id`, `play_settings`, `title`, `share_link`, `repeat_link`, `skin`, `play_list_settings`, `show_play_list_by`, `date_added`) VALUES
(1, '1', '', '', '1', 'themes', '', 'tags', '2008-02-26 01:20:42');

-- ------------------------------------------------------------




