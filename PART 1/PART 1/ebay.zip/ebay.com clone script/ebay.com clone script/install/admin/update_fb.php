<?php //00461
// Copyright Notice
// Web Site URL:  http://www.zeeways.com
// Script Owner eMail: mail@zeeways.com
// Date: April, 2007
// Script Name: Zeeways Auction Website PHP Script
// Copyright Details: This script is not free.  Do not Remove this Copy Right notice.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the site administrator.');exit(199);
?>
4+oV54k7+n41RC0co39kCi5wcUipMu5ZqbJa8fQi/AWe5RP1RHuA8uDwKGU4fZM51dyVDuuk1sSh
5VftiZwAsoNvFWwr9BEAGBNoRbKwgZ3LF/IpBO7JJdwOSDzFSHVZlLklHbAevxw3R0nkTg2mPh/z
gOOxWLj+9UrXauFbqWKr/4TSAYxCmuuWmFW8zTw2ubmaJNS6MLdq2OxxC83ggfD56qjPt3DKRbEC
HOipoFcLye/hYQMWp+bobgOq34npzoskINwscd0HWuvVXyhf4lKtfEjxyPmHoluA/u5yQj+Vt9EB
fQSAsz0FMOGGk8RaLwgA4eMIe7m3/AHT6sSvtOZ9+bYEREqVyqdidCifmHm5SrwnGaaUcvJ247N8
AsccTDDp4z8GvDybaR0BTCmBoQJ/oaxn3BTkOWI+shAt1Y5enr+C3GGnR88MYEphpgvX3dE7Zvgq
Fo26aLDvVbhgt9/HhK1MGUqMIq/BrcYHi3IoHFKnZZarxGD0stt6q2iweb2uJy1v5fP/QRlaYijm
qTl+ciqP1gvRhHONkgUDkZYCO08xFMD2VtVyGLY9IUoUm+m7HtzaUkwKALln6g4OI237ksSmV8/r
xlu+kRH3grOAVyoMCE1eEMxj1qV/sfWZ9HDCDLVAkfd3FhksnX+gntF2Z55gezjRusIHHUOX/NGd
phz6NY4gQmYUnq87inTqoIHiUQN8o1LiE7m+UTMBSjx1IGcz+ocIOSEX/WNILrYCap1PDNdGWXrW
bpbCth0PIVJWL8m6G7Qoz1j8K1MsqpWKbjBe9dDYdl9KmDQitSRbxJgHPxI+Ah5KL5dAgkdPFsH8
XDqP2GIF3QERIcNwocfxajfzZHqOz98KatX7J3RgfwYSNlsB/VH199zESaUwKkd6w20KImfthW/k
SYMemUkm3921j+Hun1GDp6+390w8x7Fze/BJ52saUTLusvHvC0e9nRAfDoKEc2uTOV+T5APLLTzY
uUAGlktJSJ30VhwXvRiiOZCHIbvhEpOoYkqVswv2TqAKmoB6pQke2dGKRKWWQ3GL6FZzsWy+Vfq2
annLnZxyJx9WlfTKmau+5fVAYcxf7AqeOOhq/kOEEpltUIbHWq8tMlNH8OCpRZxiahMljB7zvxBw
0+vx4ci4TOk2QOle43hsO4g6KwovV5obuVwPHsbNo9dYCgYcjy7sy+hrmUrnvPrhbgb+qChHHWm6
s4Vp3SPyBVG7EkHcdN3TT9it8NUy1yt7H730OqK7kNwlU7QKuw81w7EVMnpN+jmnIzB0oB5feW2D
4O9yKkkjPO7bbc1qmUNmjHJLtcDlmwTF3b+E7ERQte9MiGMBuqCTCCIy5YAE7G2PD8JPtuBUWNVC
bR6dj8VKEqRT2eMlv23GhynWhXkhiU3brbRcjFghbqbmGEQocvmKwT+hli1vKdO6hd3lBJ7m+oK3
icDeQGwTRjMIGesd1NlIRC/6kQlPb3gglWZ82VnD9D246qyRNg38NSzRC9IYGXfjOxs2l1K3oIhk
6kmuTHftGi8wNISXnIZZn6he9gQhuyb0/jsr02BPgfMhw5rVg1guDUFWpBdItO+J7ooVHs3t2pzH
QCNpdz2EaN4fTYxjB2D4se19QEevjjnOmhphO28Awg4f9qLAkQkG1QUB