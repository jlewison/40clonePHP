<?php /* Smarty version 2.6.6, created on 2006-03-11 11:53:38
         compiled from admin/admin_file.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'cycle', 'admin/admin_file.tpl', 88, false),)), $this); ?>


<?php echo '
<style>
input{
font: Verdana;
font-size: 8pt;
}
txt{
font: Verdana;
font-size: 6pt;
}
a{
        text-decoration: none;
        color: #2F4F4F;
}
a:hover{
color: #FF4500;
}
th{
font-family: Verdana;
font-size: 8pt;
}
td{
font-family: Verdana;
font-size: 7pt;
}
</style>

<script language=javascript>
function Goto()
{
 var pg=document.getElementById("page").value-1;
 var mxpg=document.getElementById("mxpg").value+1;
 if(pg>mxpg||pg<0)
  {
   alert("Invalid Page Number");
   document.getElementById("page").value="";
   return;
  }
 document.location.href("admin_index.php?change=FInfo&page="+pg);
}
function CheckAll()
{
 n=document.getElementById("loop").value;
 x=document.getElementById("ckall").checked;
 for(i=0;i<n;i++)
   {
     if(x)
        document.getElementById(""+i).checked=true; 
     else
        document.getElementById(""+i).checked=false; 
   }
}
function UCheck()
{ 
 n=document.getElementById("loop").value;
 x=true;
 for(i=0;i<n;i++)
   {
     if(document.getElementById(""+i).checked==false) x=false;      
   }
 document.getElementById("ckall").checked=x;

}
</script>
'; ?>


<form method="POST" name=FRM action="admin_act_file.php">
  <table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr bgcolor=#FFFFFF>
    <th width="5%" align=center><input type="checkbox" name="ckall" onclick="CheckAll();" value="ckall"></th>
    <th width="15%" align=left>&nbsp;Name</th>
    <th width="12%" align=left>&nbsp;Recipient</th>
    <th width="10%" align=left>&nbsp;Size</th>
    <th width="12%" align=left>&nbsp;Server</th>
    <th width="10%" align=left>&nbsp;Link</th>
    <th width="7%" align=left>&nbsp;No. D/L</th>
    <th width="7%" align=left>&nbsp;Max D/L</th>
    <th width="12%" align=left>&nbsp;Sender</th>
    <th width="10%" align=left>&nbsp;Expire</th>
  </tr>
  <tr>
  <td colspan=12 height=1 bgcolor="#003366"></td>
  </tr>
  
  <?php unset($this->_sections['i']);
$this->_sections['i']['name'] = 'i';
$this->_sections['i']['loop'] = is_array($_loop=$this->_tpl_vars['file']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['i']['show'] = true;
$this->_sections['i']['max'] = $this->_sections['i']['loop'];
$this->_sections['i']['step'] = 1;
$this->_sections['i']['start'] = $this->_sections['i']['step'] > 0 ? 0 : $this->_sections['i']['loop']-1;
if ($this->_sections['i']['show']) {
    $this->_sections['i']['total'] = $this->_sections['i']['loop'];
    if ($this->_sections['i']['total'] == 0)
        $this->_sections['i']['show'] = false;
} else
    $this->_sections['i']['total'] = 0;
if ($this->_sections['i']['show']):

            for ($this->_sections['i']['index'] = $this->_sections['i']['start'], $this->_sections['i']['iteration'] = 1;
                 $this->_sections['i']['iteration'] <= $this->_sections['i']['total'];
                 $this->_sections['i']['index'] += $this->_sections['i']['step'], $this->_sections['i']['iteration']++):
$this->_sections['i']['rownum'] = $this->_sections['i']['iteration'];
$this->_sections['i']['index_prev'] = $this->_sections['i']['index'] - $this->_sections['i']['step'];
$this->_sections['i']['index_next'] = $this->_sections['i']['index'] + $this->_sections['i']['step'];
$this->_sections['i']['first']      = ($this->_sections['i']['iteration'] == 1);
$this->_sections['i']['last']       = ($this->_sections['i']['iteration'] == $this->_sections['i']['total']);
?>
  <tr bgcolor=<?php echo smarty_function_cycle(array('values' => "#EFEFEF,#DFDFDF"), $this);?>
>
    <td align=center><input type="checkbox" name="dlt[]" id="<?php echo $this->_sections['i']['index']; ?>
" onclick="UCheck();" value="<?php echo $this->_tpl_vars['file'][$this->_sections['i']['index']]['dir']; ?>
"></td>
    <td>&nbsp; <?php echo $this->_tpl_vars['file'][$this->_sections['i']['index']]['file_name']; ?>
</td>
    <td>&nbsp; <?php echo $this->_tpl_vars['file'][$this->_sections['i']['index']]['recipient']; ?>
</td>
    <td>&nbsp; <?php echo $this->_tpl_vars['file'][$this->_sections['i']['index']]['size']; ?>
</td>
    <td>&nbsp; <?php echo $this->_tpl_vars['file'][$this->_sections['i']['index']]['server']; ?>
</td>
    <td>&nbsp; <?php if ($this->_tpl_vars['file'][$this->_sections['i']['index']]['link_status'] == 0): ?><font color=#ff0000>Deleted</font><?php else: ?><font color=#008000>Exist</font><?php endif; ?> </td>
    <td>&nbsp; <?php echo $this->_tpl_vars['file'][$this->_sections['i']['index']]['no_of_dwnld']; ?>
</td>
    <td>&nbsp; <?php echo $this->_tpl_vars['file'][$this->_sections['i']['index']]['max_dwnld']; ?>
</td>
    <td>&nbsp; <?php echo $this->_tpl_vars['file'][$this->_sections['i']['index']]['sender']; ?>
</td>
    <td>&nbsp; <?php echo $this->_tpl_vars['file'][$this->_sections['i']['index']]['expire_time']; ?>
</td>
  </tr>
    <tr><td colspan=11 width=1 bgcolor="#BBBBBB"> </td> </tr>
  <?php endfor; endif; ?>
  <?php if ($this->_sections['i']['loop'] == 0): ?>
  <tr><td colspan=8 bgcolor="#003366" align=center><font color=white>L i s t  E m p t y</font></td></tr>
  <?php endif; ?>
<tr><td colspan=12 height=1 bgcolor="#003366"></td></tr>
  <tr>
  <td colspan=4 valign=top>
     &nbsp;Page:<input type=text id=page name=page size=3><input type=button value="Go" onclick="javascript:Goto()">
     &nbsp;|&nbsp;
     <?php if ($_REQUEST['page'] > 0): ?>
     <a href="admin_index.php?change=FInfo&page=<?php echo $_REQUEST['page']-1; ?>
" class="lnk">&lt;&lt;</a>&nbsp;|&nbsp;
     <?php endif; ?>
     <?php if ($_REQUEST['page'] < $this->_tpl_vars['mxpg']): ?>
     <a href="admin_index.php?change=FInfo&page=<?php echo $_REQUEST['page']+1; ?>
" class="lnk">&gt;&gt;</a>&nbsp;|&nbsp;
     <?php endif; ?>
     Pages: [<?php echo $_REQUEST['page']+1; ?>
/<?php echo $this->_tpl_vars['mxpg']+1; ?>
]
     </td>
     <td colspan=8>
     <input type="submit" value="Delete Selected Files" name="req">  <input type="submit" class="txt" value="Delete Selected Entry" name="req"></p>
  </td>  
</tr>
</table>
<input type="hidden" value="<?php echo $this->_tpl_vars['mxpg']; ?>
" name="mxpg" id="mxpg">
<input type="hidden" value="<?php echo $this->_sections['i']['loop']; ?>
" name="loop" id="loop">
</form>