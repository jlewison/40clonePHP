<?php
if (!$step) { header('Location: ./install.php'); die(); }

$file='../config.php';
if (!file_exists($file)) { $errors[]="'$file' was not found! This is a fatal error."; }
elseif (filesize($file) <= 0) { $errors[]="'$file' is 0 bytes! This is a fatal error."; }

$file='../settings.php';
if (!file_exists($file)) { $errors[]="'$file' was not found! Try renaming 'settings.php.default' to 'settings.php'"; }
elseif (filesize($file) <= 0) { $errors[]="'$file' is 0 bytes!"; }
elseif (!is_writable($file)) { $errors[]="'$file' is not writable! Please chmod this file to 777 while editing."; }

define("mnminclude", dirname(__FILE__).'/../libs/');
include_once mnminclude.'db.php';

if (!$errors) {
	$dbuser = EZSQL_DB_USER;
	$dbpass = EZSQL_DB_PASSWORD;
	$dbname = EZSQL_DB_NAME;
	$dbhost = EZSQL_DB_HOST;

	if($conn = @mysql_connect($dbhost,$dbuser,$dbpass))
	 {
		$db_selected = mysql_select_db($dbname, $conn);
		if (!$db_selected) { die ('Error: '.$dbname.' : '.mysql_error()); }
		define('table_prefix', $_POST['tableprefix']);

		include_once '../libs/define_tables.php';

		//time to create the tables
		echo '<p>' . $lang['CreatingTables'] . '</p>';
		include_once ('../libs/db.php');
		include_once("installtables.php");
		if (pligg_createtables($conn) == 1) { echo "<p>" . $lang['TablesGood'] . "</p>"; }
		else { $errors[] = $lang['Error3-1']; }
	}
	else { $errors[] = $lang['Error3-2']; }
}

if (!$errors) {
	// refresh / recreate settings
	// this is needed to update it with table_prefix if it has been changed from "pligg_"
	include_once( '../config.php' );
	include(mnminclude.'admin_config.php');
	$config = new pliggconfig;
	$config->create_file('../settings.php');

	$my_base_url = "http://" . $_SERVER["HTTP_HOST"];
	$my_pligg_base=dirname($_SERVER["PHP_SELF"]); $my_pligg_base=str_replace("/".substr(strrchr($my_pligg_base, '/'), 1),'',$my_pligg_base);

	$sql = "Update " . table_config . " set `var_value` = '" . $my_base_url . "' where `var_name` = '" . '$my_base_url' . "';";
	mysql_query( $sql, $conn );

	$sql = "Update " . table_config . " set `var_value` = '" . $my_pligg_base . "' where `var_name` = '" . '$my_pligg_base' . "';";
	mysql_query( $sql, $conn );

	$config = new pliggconfig;
	$config->create_file('../settings.php');

	//done
	$output='<p><a href="../">Pligg</a> appears to have installed successfully!</p>
	<p>Things to do next:</p>
	<ul>
	<li>chmod "../libs/dbconnect.php" back to 644, we will not need to change this file again.</li>
	<li>DELETE the "./install" directory from your server once you have successfully installed Pligg.</li>
	<li>Login to the <a href="../admin_index.php">admin area</a> (default username: god; default password: 12345)</li>
	<li>Change your password from the default password.</li>
	<li>Configure your installation using the admin area.</li>
	<li>Visit the <a href="http://www.pligg.com/forum/">Pligg Forums</a> if you have any questions.</li>
	</ul>';
}

if (isset($errors)) {
	$output=DisplayErrors($errors);
	$output.='<p>' . $lang['Errors'] . '</p>';
}

if(function_exists("gd_info")) {}
else {
$config = new pliggconfig;
$config->var_id = 60;
$config->var_value = "false";
$config->store();
$config->var_id = 69;
$config->var_value = "false";
$config->store();
}

echo $output;

?>
