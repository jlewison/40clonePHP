<?php

$CFG['admin']['forums']['topic']['max_allowed'] = 50;
$CFG['admin']['forums']['search_date_limit'] = 30;


?>