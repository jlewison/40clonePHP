<?php
session_start();
session_register("adminid");
session_register("name");
//session_register("ID");
//session_register("ID");
?>
