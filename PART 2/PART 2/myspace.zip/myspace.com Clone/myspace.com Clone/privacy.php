<?
show_header(); 
?>
<table width=100% class=body>
<tr><td class='lined padded-6'><!--StartFragment -->
<b>
	<span class="text1">Our Privacy Policy:</span></b><p><span class="text1">
	Edit this text to reflect your privacy policy. Open the file privacy.php and 
	edit this text then copy/paste the changes back into this file to display 
	your changes immediately.</span></p><p></br></td></table>
<? show_footer(); ?>