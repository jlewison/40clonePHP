<?php
require_once ('../common/config.inc.php');
require_once ('../common/configs/config_ans_photo.inc.php');
require_once ('../common/configs/config_index.inc.php');
$CFG['lang']['include_files'][] = 'members/includes/languages/%s/manageSettings.php';
$CFG['html']['header'] = 'members/includes/languages/%s/html_header.php';
$CFG['html']['footer'] = 'members/includes/languages/%s/html_footer.php';
$CFG['mods']['include_files'][] = 'common/classes/class_Image.lib.php';
$CFG['mods']['include_files'][] = 'common/classes/class_ftp.lib.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['lang']['include_files'][] = 'common/email_templates/languages/%s/email_notify.inc.php';
$CFG['lang']['include_files'][] = 'common/languages/%s/help.inc.php';
$CFG['db']['is_use_db'] = true;
if ($_POST) $CFG['mods']['include_files'][] = 'common/classes/phpmailer/class_PHPMailer.lib.php';
$CFG['mods']['is_include_only']['non_html_header_files'] = true;
require ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class ManageSettingsFormHandler extends FormHandler
{
		public function updateFormFieldsInTable($table_name, $user_id, $fields_to_insert_arr = array())
		{
				$this->fields_arr['subscribe_keywords'] = $this->removeDuplicateKeywords($this->fields_arr['subscribe_keywords']);
				$field_names_separated_by_comma = '';
				$parameters_separated_by_comma = '';
				$field_values_arr = array();
				foreach ($fields_to_insert_arr as $field_name)
						if (isset($this->fields_arr[$field_name]))
						{
								$field_names_separated_by_comma .= $field_name . '=' . $this->dbObj->Param($field_name) . ', ';
								$field_values_arr[] = $this->fields_arr[$field_name];
						}
				$field_names_separated_by_comma = substr($field_names_separated_by_comma, 0, strrpos($field_names_separated_by_comma, ','));
				$sql = 'UPDATE ' . $table_name . ' SET ' . $field_names_separated_by_comma;
				$sql .= ' WHERE user_id =' . $this->dbObj->Param($user_id);
				$field_values_arr[] = $user_id;
				$stmt = $this->dbObj->Prepare($sql);
				$result = $this->dbObj->Execute($stmt, $field_values_arr);
				if (!$result) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function updateUserImagePath()
		{
				$image_path = $this->fields_arr['image_path'];
				$user_id = $this->CFG['user']['user_id'];
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['users'] . ' SET ' . $this->getUserTableField('image_path') . '=' . $this->dbObj->Param($image_path) . ' WHERE ' . $this->getUserTableField('user_id') . '=' . $this->dbObj->Param($user_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($image_path, $user_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function getUserDetailsArrFromDB($table_name, $fields_arr = array(), $user_id)
		{
				$sql = 'SELECT ';
				foreach ($fields_arr as $field_name) $sql .= $field_name . ', ';
				$sql = substr($sql, 0, strrpos($sql, ','));
				$sql .= ' FROM ' . $table_name . ' WHERE user_id=' . $this->dbObj->Param($user_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($user_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = array();
				if ($rs->PO_RecordCount()) $row = $rs->FetchRow();
				$ret_fields_arr = array();
				foreach ($fields_arr as $field_name) $ret_fields_arr[$field_name] = isset($row[$field_name]) ? $row[$field_name] : '';
				return $ret_fields_arr;
		}
		public function setIHObject($imObj)
		{
				$this->imageObj = $imObj;
		}
		public function chkValidFileType($field_name, $err_tip = '')
		{
				$this->EXTERN = strtolower(substr($_FILES[$field_name]['name'], strrpos($_FILES[$field_name]['name'], '.') + 1));
				if (!in_array($this->EXTERN, $this->CFG['admin']['ans_photos']['format_arr']))
				{
						$this->fields_err_tip_arr[$field_name] = $err_tip;
						return false;
				}
				return true;
		}
		public function chkValideFileSize($field_name, $err_tip = '')
		{
				$max_size = $this->CFG['admin']['ans_photos']['max_size'] * 1024;
				if ($_FILES[$field_name]['size'] == 0)
				{
						$this->fields_err_tip_arr[$field_name] = $this->LANG['err_tip_invalid_file'];
						return false;
				}
				if ($_FILES[$field_name]['size'] > $max_size)
				{
						$this->fields_err_tip_arr[$field_name] = $err_tip;
						return false;
				}
				return true;
		}
		public function chkErrorInFile($field_name, $err_tip = '')
		{
				if ($_FILES[$field_name]['error'])
				{
						$this->fields_err_tip_arr[$field_name] = $err_tip;
						return false;
				}
				return true;
		}
		public function getServerDetails()
		{
				$sql = 'SELECT server_url, ftp_server, ftp_usrename, ftp_password' . ' FROM ' . $this->CFG['db']['tbl']['server_settings'] . ' WHERE server_for=\'Ans_photo\' AND server_status=\'Yes\' LIMIT 0,1';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = array();
				if ($rs->PO_RecordCount())
				{
						$row = $rs->FetchRow();
						$this->fields_arr['ftp_server'] = $row['ftp_server'];
						$this->fields_arr['ftp_usrename'] = $row['ftp_usrename'];
						$this->fields_arr['ftp_password'] = $row['ftp_password'];
						$this->fields_arr['server_url'] = $row['server_url'];
						return true;
				}
				return false;
		}
		public function storeImagesTempServer($uploadUrl, $extern)
		{
				if ($this->CFG['admin']['ans_photos']['large_name'] == 'L')
				{
						if ($this->CFG['admin']['ans_photos']['large_height'] or $this->CFG['admin']['ans_photos']['large_width'])
						{
								$this->imageObj->resize($this->CFG['admin']['ans_photos']['large_width'], $this->CFG['admin']['ans_photos']['large_height'], '-');
								$this->imageObj->output_resized($uploadUrl . 'L.' . $extern, strtoupper($extern));
								$image_info = getImageSize($uploadUrl . 'L.' . $extern);
								$this->L_WIDTH = $image_info[0];
								$this->L_HEIGHT = $image_info[1];
						}
						else
						{
								$this->imageObj->output_original($uploadUrl . 'L.' . $extern, strtoupper($extern));
								$image_info = getImageSize($uploadUrl . 'L.' . $extern);
								$this->L_WIDTH = $image_info[0];
								$this->L_HEIGHT = $image_info[1];
						}
				}
				if ($this->CFG['admin']['ans_photos']['thumb_name'] == 'T')
				{
						$this->imageObj->resize($this->CFG['admin']['ans_photos']['thumb_width'], $this->CFG['admin']['ans_photos']['thumb_height'], '-');
						$this->imageObj->output_resized($uploadUrl . 'T.' . $extern, strtoupper($extern));
						$image_info = getImageSize($uploadUrl . 'T.' . $extern);
						$this->T_WIDTH = $image_info[0];
						$this->T_HEIGHT = $image_info[1];
				}
				if ($this->CFG['admin']['ans_photos']['small_name'] == 'S')
				{
						$this->imageObj->resize($this->CFG['admin']['ans_photos']['small_width'], $this->CFG['admin']['ans_photos']['small_height'], '-');
						$this->imageObj->output_resized($uploadUrl . 'S.' . $extern, strtoupper($extern));
						$image_info = getImageSize($uploadUrl . 'S.' . $extern);
						$this->S_WIDTH = $image_info[0];
						$this->S_HEIGHT = $image_info[1];
				}
				$wname = $this->CFG['admin']['ans_photos']['large_name'] . '_WIDTH';
				$hname = $this->CFG['admin']['ans_photos']['large_name'] . '_HEIGHT';
				$this->L_WIDTH = $this->$wname;
				$this->L_HEIGHT = $this->$hname;
				$wname = $this->CFG['admin']['ans_photos']['thumb_name'] . '_WIDTH';
				$hname = $this->CFG['admin']['ans_photos']['thumb_name'] . '_HEIGHT';
				$this->T_WIDTH = $this->$wname;
				$this->T_HEIGHT = $this->$hname;
				$wname = $this->CFG['admin']['ans_photos']['small_name'] . '_WIDTH';
				$hname = $this->CFG['admin']['ans_photos']['small_name'] . '_HEIGHT';
				$this->S_WIDTH = $this->$wname;
				$this->S_HEIGHT = $this->$hname;
		}
		public function photoUpload()
		{
				$extern = strtolower(substr($_FILES['photo']['name'], strrpos($_FILES['photo']['name'], '.') + 1));
				$this->setFormField('user_id', $this->CFG['user']['user_id']);
				$this->setFormField('photo_ext', $extern);
				$image_name = getImageName($this->CFG['user']['user_id']);
				$imageObj = new ImageHandler($_FILES['photo']['tmp_name']);
				$this->setIHObject($imageObj);
				$temp_dir = '../' . $this->CFG['admin']['ans_photos']['temp_folder'];
				$this->chkAndCreateFolder($temp_dir);
				$temp_file = $temp_dir . $image_name;
				$this->storeImagesTempServer($temp_file, $extern);
				$dir = $this->CFG['admin']['ans_photos']['folder'];
				$local_upload = true;
				if ($this->getServerDetails())
				{
						if ($FtpObj = new FtpHandler($this->getFormField('ftp_server'), $this->getFormField('ftp_usrename'), $this->getFormField('ftp_password')))
						{
								$FtpObj->makeDirectory($dir);
								$FtpObj->changeDirectory($dir);
								$FtpObj->moveTo($temp_file . '.' . $extern, $dir . $image_name . '.' . $extern);
								unlink($temp_file . '.' . $extern);
								if ($this->CFG['admin']['ans_photos']['large_name'] == 'L')
								{
										$FtpObj->moveTo($temp_file . 'L.' . $extern, $dir . $image_name . 'L.' . $extern);
										unlink($temp_file . 'L.' . $extern);
								}
								if ($this->CFG['admin']['ans_photos']['thumb_name'] == 'T')
								{
										$FtpObj->moveTo($temp_file . 'T.' . $extern, $dir . $image_name . 'T.' . $extern);
										unlink($temp_file . 'T.' . $extern);
								}
								if ($this->CFG['admin']['ans_photos']['small_name'] == 'S')
								{
										$FtpObj->moveTo($temp_file . 'S.' . $extern, $dir . $image_name . 'S.' . $extern);
										unlink($temp_file . 'S.' . $extern);
								}
								$this->setFormField('server_url', $this->getFormField('server_url'));
								$local_upload = false;
								return;
						}
				}
				if ($local_upload)
				{
						$dir = '../' . $this->CFG['admin']['ans_photos']['folder'];
						$this->chkAndCreateFolder($dir);
						$uploadUrl = $dir . $image_name;
						if ($this->CFG['admin']['ans_photos']['large_name'] == 'L')
						{
								copy($temp_file . 'L.' . $extern, $uploadUrl . 'L.' . $extern);
								unlink($temp_file . 'L.' . $extern);
						}
						if ($this->CFG['admin']['ans_photos']['thumb_name'] == 'T')
						{
								copy($temp_file . 'T.' . $extern, $uploadUrl . 'T.' . $extern);
								unlink($temp_file . 'T.' . $extern);
						}
						if ($this->CFG['admin']['ans_photos']['small_name'] == 'S')
						{
								copy($temp_file . 'S.' . $extern, $uploadUrl . 'S.' . $extern);
								unlink($temp_file . 'S.' . $extern);
						}
						$this->setFormField('server_url', $this->CFG['site']['url']);
				}
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['users'] . ' SET' . ' ' . $this->CFG['users']['t_width'] . '=\'' . $this->T_WIDTH . '\',' . ' ' . $this->CFG['users']['t_height'] . '=' . '\'' . $this->T_HEIGHT . '\',' . ' ' . $this->CFG['users']['l_width'] . '=\'' . $this->L_WIDTH . '\',' . ' ' . $this->CFG['users']['l_height'] . '=' . '\'' . $this->L_HEIGHT . '\',' . ' ' . $this->CFG['users']['s_width'] . '=' . '\'' . $this->S_HEIGHT . '\',' . ' ' . $this->CFG['users']['s_height'] . '=' . '\'' . $this->S_HEIGHT . '\',' . ' ' . $this->CFG['users']['photo_ext'] . '=' . '\'' . $extern . '\',' . ' ' . $this->CFG['users']['image_path'] . '=\'\',' . ' ' . $this->CFG['users']['photo_server_url'] . '=\'' . $this->fields_arr['server_url'] . '\'' . ' WHERE ' . $this->CFG['users']['user_id'] . '=\'' . $this->CFG['user']['user_id'] . '\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function setIndexBlockFormField($index_block_arr)
		{
				foreach ($index_block_arr as $value)
				{
						$this->setFormField($value, $this->CFG['admin']['index'][$value]);
				}
		}
		public function populateIndexBlockValues($index_block_value)
		{
				$index_block_value_arr = unserialize($index_block_value);
				if (!is_array($index_block_value_arr)) return;
				foreach ($index_block_value_arr as $key => $value)
				{
						if (!($this->fields_arr[$key] == 'compulsory' or $value == 'compulsory')) $this->fields_arr[$key] = $value;
						else  $this->fields_arr[$key] = $this->CFG['admin']['index'][$key];
				}
		}
		public function populateIndexPageFields($index_block_arr)
		{
				$headings_count = 0;
				foreach ($index_block_arr as $value)
				{
						$label = $this->LANG[$value];
						if ($headings_count == 0 and $this->CFG['admin']['index'][$value] == 'yes')
						{
								$headings_count++;
?>
<tr>
   	<td class="clsAllEmail"><label for="all_home_settings"><?php echo $this->LANG['index_block_settings']; ?></label></td>
   	<td class="clsAllEmail"><p class="clsBgCheckBox"><input type="checkbox" name="all_home_settings" id="all_home_settings" onClick="checkAllSettings(this.form, '_home');" tabindex="<?php echo $this->getTabIndex(); ?>"  /></p></td>
</tr>
<?php
						}
						if (!$this->isShowIndexBlock($this->CFG['admin']['index'][$value])) continue;
?>
<tr>
	<td class="<?php echo $this->getCSSFormLabelCellClass($value); ?>"><?php ShowHelpTip($value); ?><label for="<?php echo $value; ?>"><?php echo $label; ?></label></td>
	<td class="<?php echo $this->getCSSFormFieldCellClass($value); ?>"><?php echo $this->getFormFieldErrorTip($value); ?>
		<input type="radio" name="<?php echo $value; ?>" id="<?php echo $value; ?>_yes" tabindex="<?php echo $this->getTabIndex(); ?>" value="yes"<?php echo ($this->getFormField($value) == 'yes') ? ' checked' : ''; ?> /><label for="<?php echo $value; ?>_yes"><?php echo $this->LANG['managesettings_yes']; ?></label>
		<input type="radio" name="<?php echo $value; ?>" id="<?php echo $value; ?>_no" tabindex="<?php echo $this->getTabIndex(); ?>"  value="no"<?php echo ($this->getFormField($value) == 'no') ? ' checked' : ''; ?> /><label for="<?php echo $value; ?>_no"><?php echo $this->LANG['managesettings_no']; ?></label>
	</td>
</tr>
<?php
				}
		}
		public function serializeIndexBlockValues($index_block_arr)
		{
				$array = array();
				foreach ($index_block_arr as $value)
				{
						$array[$value] = $this->fields_arr[$value];
				}
				$this->fields_arr['index_block'] = serialize($array);
		}
		public function chkIsPasswordAndUserNameAreSame($err_tip = '')
		{
				if ($this->fields_arr['name'] and $this->fields_arr['password'])
				{
						if ($this->fields_arr['name'] == $this->fields_arr['password'])
						{
								$this->fields_err_tip_arr['password'] = $err_tip;
								return false;
						}
				} elseif ($this->CFG['user']['name'] and $this->fields_arr['password'])
				{
						if ($this->CFG['user']['name'] == $this->fields_arr['password'])
						{
								$this->fields_err_tip_arr['password'] = $err_tip;
								return false;
						}
				}
				return true;
		}
		public function chkIsSamePasswords($field_name1, $field_name2, $err_tip = '')
		{
				$is_ok = ($this->fields_arr[$field_name1] == $this->fields_arr[$field_name2]);
				if (!$is_ok) $this->fields_err_tip_arr[$field_name1] = $this->fields_err_tip_arr[$field_name2] = $err_tip;
				return $is_ok;
		}
		public function chkIsValidSize($field_name, $min, $max, $err_tip = '')
		{
				if ((strlen($this->fields_arr[$field_name]) < $min) or (strlen($this->fields_arr[$field_name]) > $max))
				{
						$this->fields_err_tip_arr[$field_name] = $err_tip;
						return false;
				}
				return true;
		}
		public function chkIsAllowedUserName($err_tip = '')
		{
				$user_name = strtolower($this->fields_arr['name']);
				if (in_array($user_name, $this->CFG['admin']['not_allowed_usernames']))
				{
						$this->fields_err_tip_arr['name'] = $err_tip;
						return false;
				}
				return true;
		}
		public function chkIsNotDuplicateName($table_name, $field_name, $err_tip = '')
		{
				$sql = 'SELECT ' . $this->getUserTableField('user_id') . ' FROM ' . $table_name . ' WHERE ' . $this->getUserTableField('name') . ' =' . $this->dbObj->Param($field_name);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr[$field_name]));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$numrows = $rs->PO_RecordCount();
				$is_ok = ($numrows == 0);
				if (!$is_ok) $this->fields_err_tip_arr[$field_name] = $err_tip;
				return $is_ok;
		}
		public function chkIsNotDuplicateEmail($table_name, $field_name, $err_tip = '')
		{
				$sql = 'SELECT ' . $this->getUserTableField('user_id') . ' FROM ' . $table_name . ' WHERE ' . $this->getUserTableField('email') . ' =' . $this->dbObj->Param($field_name);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['new_mail']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$numrows = $rs->PO_RecordCount();
				$is_ok = ($numrows == 0);
				if (!$is_ok) $this->fields_err_tip_arr[$field_name] = $err_tip;
				return $is_ok;
		}
		public function sendActivationForMail($mailto, $name, $code)
		{
				$mcode = $name . $code;
				$activation_link = getUrl($this->CFG['site']['url'] . 'activateMailAccount.php', $this->CFG['site']['url'] . 'activatemail/', false) . '?code=' . urlencode($mcode);
				$activation_link = '<a href="' . $activation_link . '">' . $activation_link . '</a>';
				$activation_subject = str_replace('{site_name}', $this->CFG['site']['name'], $this->LANG['mailactivation_subject']);
				$link = '<a href="' . $this->CFG['site']['url'] . '">' . $this->CFG['site']['url'] . '</a>';
				$activation_message = str_replace('{site_name}', $this->CFG['site']['name'], $this->LANG['mailactivation_message']);
				$activation_message = str_replace('{user_name}', $this->CFG['user']['name'], $activation_message);
				$activation_message = str_replace('{link}', $link, $activation_message);
				$activation_message = str_replace('{activation_link}', $activation_link, $activation_message);
				$activation_message = nl2br($activation_message);
				$is_ok = $this->_sendMail($mailto, $activation_subject, $activation_message, $this->CFG['site']['noreply_name'], $this->CFG['site']['noreply_email']);
				if ($is_ok) $this->setDisplayVar('mail_status', $this->LANG['managesettings_activation_code_sent']);
				else  $this->setDisplayVar('mail_status', $this->LANG['managesettings_activation_code_not_sent']);
		}
		private function _sendMail($to_email, $subject, $body, $sender_name, $sender_email)
		{
				$mail = new PHPMailer();
				$mail->AddAddress($to_email);
				$mail->FromName = $sender_name;
				$mail->From = $mail->Sender = $sender_email;
				$mail->Subject = $subject;
				$mail->Body = $body;
				$mail->IsMail();
				$mail->IsHTML(true);
				return ($mail->Send());
		}
}
$managefrm = new ManageSettingsFormHandler();
$managefrm->makeGlobalize($CFG, $LANG);
$index_block_arr = array('recent_questions', 'popular_questions', 'questions_with_videos', 'questions_with_audios', 'best_of_answer', 'recent_forums', 'forums_with_most_replies', 'recent_blogs', 'blogs_with_most_comment', 'top_analyst', 'featured_analyst');
$managefrm->setPageBlockNames(array('form_search', 'form_settings', 'msg_form_error', 'msg_form_success'));
$managefrm->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$managefrm->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$managefrm->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$managefrm->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$managefrm->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$managefrm->setDBObject($db);
$managefrm->setFormField('subscribe_keywords', '');
$managefrm->setFormField('keyword_mail', '');
$managefrm->setFormField('reply_mail', '');
$managefrm->setFormField('favorite_mail', '');
$managefrm->setFormField('best_ans_mail', '');
$managefrm->setFormField('abuse_mail', '');
$managefrm->setFormField('internal_mail', '');
$managefrm->setFormField('all_email_notification', '');
$managefrm->setFormField('new_mail', '');
$managefrm->setFormField('search_question', '');
$managefrm->setFormField('image_path', '');
$managefrm->setFormField('msg', '');
$managefrm->setFormField('photo', '');
$managefrm->setFormField('photo_ext', '');
$managefrm->setFormField('photo_server_url', '');
$managefrm->setFormField('index_block', '');
$managefrm->setFormField('bio', '');
$managefrm->setFormField('password', '');
$managefrm->setFormField('confirm_password', '');
$managefrm->setFormField('name', '');
$managefrm->setFormField('sex', '');
$managefrm->setFormField('avatar', '');
$managefrm->setIndexBlockFormField($index_block_arr);
$pagename = 'Manage Settings';
$managefrm->sanitizeFormInputs($_REQUEST);
$managefrm->setAllPageBlocksHide();
$managefrm->setPageBlockShow('form_search');
$managefrm->setPageBlockShow('form_settings');
$title = $LANG['managesettings_title'];
if ($managefrm->isFormPOSTed($_POST, 'managesettings_submit'))
{
		$user_details_arr = $managefrm->getUserDetailsFromUsersTable($CFG['db']['tbl']['users'], $CFG['user']['user_id']);
		$managefrm->sanitizeFormInputs($_POST);
		if (!$CFG['admin']['use_profile_external_image'])
		{
				if (isset($_FILES['photo']) and $_FILES['photo']['tmp_name'])
				{
						$managefrm->chkValidFileType('photo', $LANG['err_tip_invalid_file_type']) and $managefrm->chkValideFileSize('photo', $LANG['err_tip_invalid_file_size']) and $managefrm->chkErrorInFile('photo', $LANG['err_tip_invalid_file']);
				}
		}
		$update_users_fields = array();
		$update_users_fields[] = 'bio';
		if ($managefrm->getFormField('bio'))
		{
				$bio = html_entity_decode($managefrm->getFormField('bio'));
				$bio = strip_tags($bio, $CFG['html']['allowed_tags']);
				$managefrm->setFormField('bio', $bio);
		}
		if ($managefrm->getFormField('name'))
		{
				$managefrm->chkIsNotEmpty('name', $LANG['managesettings_err_tip_compulsory']) and $managefrm->chkIsAlphaNumeric('name', $LANG['managesettings_err_tip_invalid_username']) and $managefrm->chkIsValidSize('name', $CFG['admin']['username_min_size'], $CFG['admin']['username_max_size'], $LANG['managesettings_err_tip_invalid_size']) and $managefrm->chkIsAllowedUserName($LANG['not_allowed_username']) and $managefrm->chkIsNotDuplicateName($CFG['db']['tbl']['users'], 'name', $LANG['managesettings_err_tip_name_already_exists']);
				$update_users_fields[] = 'name';
				$managefrm->setFormField('name', $managefrm->getFormField('name'));
		}
		if ($managefrm->getFormField('new_mail'))
		{
				$managefrm->chkIsNotEmpty('new_mail', $LANG['managesettings_err_tip_compulsory']) and $managefrm->chkIsValidEmail('new_mail', $LANG['managesettings_err_tip_invalid_email']) and ($managefrm->chkIsNotDuplicateEmail($CFG['db']['tbl']['users'], 'new_email', $LANG['managesettings_err_tip_email_already_exists']) or $managefrm->setCommonErrorMsg($LANG['managesettings_err_tip_email_already_exists']));
		}
		if ($managefrm->getFormField('password'))
		{
				$managefrm->chkIsValidSize('password', $CFG['admin']['password_min_size'], $CFG['admin']['password_max_size'], $LANG['managesettings_err_tip_invalid_size']);
				$managefrm->chkIsNotEmpty('confirm_password', $LANG['managesettings_err_tip_compulsory']) and $managefrm->chkIsSamePasswords('password', 'confirm_password', $LANG['managesettings_err_tip_same_password']);
				$managefrm->chkIsPasswordAndUserNameAreSame($LANG['password_user_name']);
				if ($managefrm->isValidFormInputs())
				{
						$update_users_fields[] = 'password';
						$managefrm->setFormField('password', md5($managefrm->getFormField('password')));
				}
		}
		if ($managefrm->getFormField('sex'))
		{
				$update_users_fields[] = 'sex';
				$managefrm->setFormField('sex', $managefrm->getFormField('sex'));
		}
		if ($managefrm->isValidFormInputs())
		{
				if ($managefrm->getFormField('new_mail'))
				{
						$nameCode = substr(md5($CFG['user']['name']), 0, 8);
						$mailCode = substr(md5($managefrm->getFormField('new_mail')), 0, 8);
						$mailto = $managefrm->getFormField('new_mail');
						$managefrm->sendActivationForMail($mailto, $nameCode, $mailCode);
				}
				$managefrm->serializeIndexBlockValues($index_block_arr);
				$insert_arr = array();
				$get_insert_arr = array('subscribe_keywords', 'keyword_mail', 'reply_mail', 'favorite_mail', 'best_ans_mail', 'abuse_mail', 'internal_mail', 'index_block');
				foreach ($get_insert_arr as $insert_value)
				{
						if ($managefrm->getFormField($insert_value) != '') array_push($insert_arr, $insert_value);
				}
				$managefrm->updateFormFieldsInTable($CFG['db']['tbl']['users_ans_log'], $CFG['user']['user_id'], $insert_arr);
				$managefrm->updateFormFieldsInTable($CFG['db']['tbl']['users'], $CFG['user']['user_id'], $update_users_fields);
				if ($managefrm->getFormField('name')) $_SESSION['user']['name'] = $managefrm->getFormField('name');
				if ($CFG['admin']['use_profile_external_image'])
				{
						$managefrm->updateUserImagePath();
				}
				else
						if (isset($_FILES['photo']) and $_FILES['photo']['tmp_name'])
						{
								$managefrm->photoUpload();
						}
						else
								if ($managefrm->getFormField('avatar'))
								{
										$avatarImagePath = $CFG['site']['url'] . $CFG['admin']['avatar_path'] . $managefrm->getFormField('avatar');
										$managefrm->setFormField('image_path', $avatarImagePath);
										$managefrm->updateUserImagePath();
								}
				$managefrm->setFormField('password', '');
				$managefrm->setPageBlockShow('msg_form_success');
				$managefrm->setCommonErrorMsg($LANG['managesettings_updated_successfully']);
				Redirect2URL(getUrl('manageSettings.php?msg=1', 'my/settings/?msg=1'));
		}
		else
		{
				$managefrm->setPageBlockShow('msg_form_error');
				$managefrm->setPageBlockShow('form_editprofile');
		}
} elseif ($managefrm->isFormPOSTed($_POST, 'managesettings_cancel'))
{
		Redirect2URL(getUrl($CFG['site']['relative_url'] . 'myanswers.php', $CFG['site']['relative_url'] . 'my/answers/', false));
}
else
{
		$user_settings_arr = $managefrm->getUserDetailsArrFromDB($CFG['db']['tbl']['users_ans_log'], array('subscribe_keywords', 'keyword_mail', 'reply_mail', 'favorite_mail', 'best_ans_mail', 'abuse_mail', 'internal_mail', 'index_block'), $CFG['user']['user_id']);
		$managefrm->populateIndexBlockValues($user_settings_arr['index_block']);
		$managefrm->setFormField('subscribe_keywords', $user_settings_arr['subscribe_keywords']);
		$managefrm->setFormField('keyword_mail', $user_settings_arr['keyword_mail']);
		$managefrm->setFormField('reply_mail', $user_settings_arr['reply_mail']);
		$managefrm->setFormField('favorite_mail', $user_settings_arr['favorite_mail']);
		$managefrm->setFormField('best_ans_mail', $user_settings_arr['best_ans_mail']);
		$managefrm->setFormField('abuse_mail', $user_settings_arr['abuse_mail']);
		$managefrm->setFormField('internal_mail', $user_settings_arr['internal_mail']);
		$user_details_arr = $managefrm->getUserDetailsFromUsersTable($CFG['db']['tbl']['users'], $CFG['user']['user_id']);
		$managefrm->setFormField('image_path', $user_details_arr['image_path']);
		$managefrm->setFormField('bio', $user_details_arr['bio']);
		$managefrm->setFormField('sex', $user_details_arr['gender']);
}
if ($managefrm->isFormPOSTed($_GET, 'msg'))
{
		$managefrm->setPageBlockShow('msg_form_success');
		$managefrm->setCommonErrorMsg($LANG['managesettings_updated_successfully']);
}
$CFG['mods']['is_include_only']['non_html_header_files'] = false;
$CFG['mods']['is_include_only']['html_header'] = true;
require ($CFG['site']['project_path'] . 'common/application_top.inc.php');
?>
<div id="selListAll">
	<h2><?php echo $title; ?></h2>
<?php
$managefrm->displayAnswersTopLinks();
if ($managefrm->isShowPageBlock('msg_form_error'))
{
?>
    	<div id="selMsgError">
      		<p>
<?php
		echo $LANG['managesettings_err_sorry'] . ' ' . $managefrm->getCommonErrorMsg();
?>
      		</p>
    	</div>
<?php
}
if ($managefrm->isShowPageBlock('msg_form_success'))
{
?>
	    <div id="selMsgSuccess">
	      	<p>
<?php
		echo $managefrm->getCommonErrorMsg();
?>
	      	</p>
	    </div>
    <?php
}
if ($managefrm->isShowPageBlock('form_settings'))
{
		$LANG['tag_size'] = str_replace('{min_size}', $CFG['admin']['tag_min_size'], $LANG['tag_size']);
		$LANG['tag_size'] = str_replace('{max_size}', $CFG['admin']['tag_max_size'], $LANG['tag_size']);
?>
	<form name="form_edit_settings" id="form_edit_settings" enctype="multipart/form-data" method="post" action="<?php echo URL(getUrl($CFG['site']['relative_url'] . 'manageSettings.php', $CFG['site']['relative_url'] . 'my/settings/', false)); ?>">
		<table summary="<?php echo $LANG['managesettings_tbl_summary']; ?>" class="clsManageSettings">
		   <?php if ($managefrm->CFG['admin']['subscribe']['tags'])
		{ ?>
		   <tr>
				<td class="<?php echo $managefrm->getCSSFormLabelCellClass('subscribe_keywords'); ?>"><?php ShowHelpTip('subscribe_keywords'); ?><label for="subscribe_keywords"><?php echo $LANG['managesettings_subscribe_keywords']; ?></label></td>
				<td class="<?php echo $managefrm->getCSSFormFieldCellClass('subscribe_keywords'); ?>"><?php echo $managefrm->getFormFieldErrorTip('subscribe_keywords'); ?>
					<input type="text" class="clsTextBox" name="subscribe_keywords" id="subscribe_keywords" maxlength="250" tabindex="<?php echo $managefrm->getTabIndex(); ?>" value="<?php echo $managefrm->getFormField('subscribe_keywords'); ?>" />
					<p><?php echo $LANG['managesettings_subscribe_keywords_info'] . ' ' . $LANG['tag_size'] . ' ' . $LANG['managesettings_subscribe_keywords_invalid']; ?></p>
				</td>
		   </tr>
		   <?php } ?>
		   <tr>
				<td class="<?php echo $managefrm->getCSSFormLabelCellClass('bio'); ?>"><?php ShowHelpTip('bio'); ?><label for="bio"><?php echo 'Bio'; ?></label></td>
				<td class="<?php echo $managefrm->getCSSFormFieldCellClass('bio'); ?>"><?php echo $managefrm->getFormFieldErrorTip('bio'); ?>
					<p><?php echo $LANG['allowed_htmltags']; ?> <?php echo htmlspecialchars($CFG['html']['allowed_tags']); ?></p>
					<textarea name="bio" id="bio" tabindex="<?php echo $managefrm->getTabIndex(); ?>" maxlength="<?php echo $CFG['admin']['bio_count']; ?>" tabindex="<?php echo $managefrm->getTabIndex(); ?>" onFocus="updatelength(this);" onKeyUp="updatelength(this);"><?php echo $managefrm->getFormField('bio'); ?></textarea>
					<div><?php echo $LANG['managesettings_total_charaters_entered']; ?> <span id="ss">0  (Limit <?php echo $CFG['admin']['bio_count']; ?>)</span></div>
				</td>
		   </tr>
			<!--<tr>
            <td class="<?php echo $managefrm->getCSSFormLabelCellClass('name'); ?>"><?php ShowHelpTip('username'); ?>
              <label for="username"><?php echo $LANG['managesettings_username']; ?></label>
            </td>
            <td class="<?php echo $managefrm->getCSSFormFieldCellClass('username'); ?>"><?php echo $managefrm->getFormFieldErrorTip('name'); ?>
              <input type="text" class="clsTextBox help" name="name" id="name" title="<?php ShowToolTip('username'); ?>" tabindex="<?php echo $managefrm->getTabIndex(); ?>" value="<?php echo $managefrm->getFormField('name'); ?>" /></td>
          </tr>-->
          <tr>
            <td class="<?php echo $managefrm->getCSSFormLabelCellClass('new_mail'); ?>"><?php ShowHelpTip('new_mail'); ?>
              <label for="new_mail"><?php echo $LANG['managesettings_newmail']; ?></label>
            </td>
            <td class="<?php echo $managefrm->getCSSFormFieldCellClass('new_mail'); ?>"><?php echo $managefrm->getFormFieldErrorTip('new_mail'); ?>
              <input type="text" class="clsTextBox help" name="new_mail" id="new_mail" title="<?php ShowToolTip('new_mail'); ?>" tabindex="<?php echo $managefrm->getTabIndex(); ?>" value="<?php echo $managefrm->getFormField('new_mail'); ?>" /></td>
          </tr>
		  <tr>
            <td class="<?php echo $managefrm->getCSSFormLabelCellClass('password'); ?>"><?php ShowHelpTip('password'); ?>
              <label for="password"><?php echo $LANG['managesettings_password']; ?></label>
            </td>
            <td class="<?php echo $managefrm->getCSSFormFieldCellClass('password'); ?>"><?php echo $managefrm->getFormFieldErrorTip('password'); ?>
              <input type="password" class="clsTextBox help" name="password" id="password" title="<?php ShowToolTip('password'); ?>" tabindex="<?php echo $managefrm->getTabIndex(); ?>" value="<?php echo $managefrm->getFormField('password'); ?>" /></td>
          </tr>
          <tr>
            <td class="<?php echo $managefrm->getCSSFormLabelCellClass('confirm_password'); ?>"><?php ShowHelpTip('confirmpassword'); ?>
              <label for="confirm_password"><?php echo $LANG['managesettings_confirm_password']; ?></label>
            </td>
            <td class="<?php echo $managefrm->getCSSFormFieldCellClass('confirm_password'); ?>"><?php echo $managefrm->getFormFieldErrorTip('confirm_password'); ?>
              <input type="password" class="clsTextBox help" name="confirm_password" id="confirm_password" title="<?php ShowToolTip('confirmpassword'); ?>" tabindex="<?php echo $managefrm->getTabIndex(); ?>" value="<?php echo $managefrm->getFormField('confirm_password'); ?>" /></td>
          </tr>
          <tr>
				<td class="<?php echo $managefrm->getCSSFormLabelCellClass('gender'); ?>"><?php ShowHelpTip('gender'); ?><label for="gender"><?php echo $LANG['managesettings_gender']; ?></label></td>
				<td class="<?php echo $managefrm->getCSSFormFieldCellClass('gender'); ?>"><?php echo $managefrm->getFormFieldErrorTip('gender'); ?>
					<input type="radio" name="sex" id="male" tabindex="<?php echo $managefrm->getTabIndex(); ?>" value="Male"<?php echo ($managefrm->getFormField('sex') == 'Male') ? ' checked' : ''; ?> /><label for="gender_male"><?php echo $LANG['managesettings_male']; ?></label>
					<input type="radio" name="sex" id="female" tabindex="<?php echo $managefrm->getTabIndex(); ?>" value="Female"<?php echo ($managefrm->getFormField('sex') == 'Female') ? ' checked' : ''; ?> /><label for="gender_female"><?php echo $LANG['managesettings_female']; ?></label>
				</td>
		   </tr>
<?php
		if (chkUserImageAllowed())
		{
?>
			<tr>
				<td class="clsFormFieldCellDefault"></td>
				<td class="clsFormFieldCellDefault">
					<div id="selUserImage">
					<?php
				if (($user_details_arr['photo_server_url'] and $user_details_arr['photo_ext']) or $user_details_arr['image_path'])
				{
?>
						<p id="selImageBorder"><?php displayUserImage($user_details_arr, 'thumb', false); ?></p>
					<?php
				}
?>
					</div>
				</td>
			</tr>

		   <tr>
<?php
				if ($CFG['admin']['use_profile_external_image'])
				{
?>
				<td class="<?php echo $managefrm->getCSSFormLabelCellClass('image_path'); ?>"><?php ShowHelpTip('image_path'); ?><label for="image_path"><?php echo $LANG['managesettings_image_path']; ?></label></td>
				<td class="<?php echo $managefrm->getCSSFormFieldCellClass('image_path'); ?>"><?php echo $managefrm->getFormFieldErrorTip('image_path'); ?>
					<p><input type="text" class="clsTextBox" name="image_path" id="image_path" tabindex="<?php echo $managefrm->getTabIndex(); ?>" value="<?php echo $managefrm->getFormField('image_path'); ?>" /></p>
					<p><?php echo $LANG['managesettings_image_path_info']; ?></p>
				</td>
<?php
				}
				else
				{
?>
				<td class="<?php echo $managefrm->getCSSFormLabelCellClass('photo'); ?>"><?php ShowHelpTip('upload_avatar_image'); ?><label for="photo"><?php echo $LANG['upload_photo']; ?></label></td>
				<td class="<?php echo $managefrm->getCSSFormFieldCellClass('photo'); ?>"><?php echo $managefrm->getFormFieldErrorTip('photo'); ?>
					<input type="file" class="clsFileBox" name="photo" id="photo" tabindex="<?php echo $managefrm->getTabIndex(); ?>" />
					<p><?php echo str_replace('{size}', $CFG['admin']['ans_photos']['max_size'], $LANG['photo_allowed_size']); ?></p>
					<p><?php echo $LANG['photo_allowed_image_type'] . ': ' . implode(', ', $CFG['admin']['ans_photos']['format_arr']); ?></p>
				</td>
<?php
				}
?>
		   </tr>
		   <tr>
				<td colspan="2" class="clsVerticalAlign <?php echo $managefrm->getCSSFormLabelCellClass('avatar'); ?>"><?php ShowHelpTip('select_avatar_image'); ?><?php echo $LANG['select_avartar']; ?></td>

		   </tr>
		   <tr>
				<td colspan="2" class="<?php echo $managefrm->getCSSFormFieldCellClass('avatar'); ?>"><div id="selShowAvatarImages"></div></td>
		   </tr>
<?php
		}
?>
		   <tr>
		   		<td class="clsAllEmail"><label for="all_email_notification"><?php echo $LANG['managesettings_all_email_notification']; ?></label></td>
		   		<td class="clsAllEmail"><p class="clsBgCheckBox"><input type="checkbox" name="all_email_notification" id="all_email_notification" onClick="checkAllMail(this.form);" tabindex="<?php echo $managefrm->getTabIndex(); ?>"  /></p></td>
		   </tr>
		   <?php if ($managefrm->CFG['admin']['subscribe']['tags'])
		{ ?>
		   <tr>
				<td class="<?php echo $managefrm->getCSSFormLabelCellClass('keyword_mail'); ?>"><?php ShowHelpTip('keyword_mail'); ?><label for="keyword_mail_yes"><?php echo $LANG['managesettings_keyword_mail']; ?></label></td>
				<td class="<?php echo $managefrm->getCSSFormFieldCellClass('keyword_mail'); ?>"><?php echo $managefrm->getFormFieldErrorTip('keyword_mail'); ?>
					<input type="radio" name="keyword_mail" id="keyword_mail_yes" tabindex="<?php echo $managefrm->getTabIndex(); ?>" value="Yes"<?php echo ($managefrm->getFormField('keyword_mail') == 'Yes') ? ' checked' : ''; ?> /><label for="keyword_mail_yes"><?php echo $LANG['managesettings_yes']; ?></label>
					<input type="radio" name="keyword_mail" id="keyword_mail_no" tabindex="<?php echo $managefrm->getTabIndex(); ?>" value="No"<?php echo ($managefrm->getFormField('keyword_mail') == 'No') ? ' checked' : ''; ?> /><label for="keyword_mail_no"><?php echo $LANG['managesettings_no']; ?></label>
				</td>
		   </tr>
		   <?php } ?>
		   <tr>
				<td class="<?php echo $managefrm->getCSSFormLabelCellClass('reply_mail'); ?>"><?php ShowHelpTip('reply_mail'); ?><label for="reply_mail_yes"><?php echo $LANG['managesettings_reply_mail']; ?></label></td>
				<td class="<?php echo $managefrm->getCSSFormFieldCellClass('reply_mail'); ?>"><?php echo $managefrm->getFormFieldErrorTip('reply_mail'); ?>
					<input type="radio" name="reply_mail" id="reply_mail_yes" tabindex="<?php echo $managefrm->getTabIndex(); ?>" value="Yes"<?php echo ($managefrm->getFormField('reply_mail') == 'Yes') ? ' checked' : ''; ?> /><label for="reply_mail_yes"><?php echo $LANG['managesettings_yes']; ?></label>
					<input type="radio" name="reply_mail" id="reply_mail_no" tabindex="<?php echo $managefrm->getTabIndex(); ?>" value="No"<?php echo ($managefrm->getFormField('reply_mail') == 'No') ? ' checked' : ''; ?> /><label for="reply_mail_no"><?php echo $LANG['managesettings_no']; ?></label>
				</td>
		   </tr>
		   <?php if ($managefrm->CFG['admin']['favorite']['allowed'])
		{ ?>
		   <tr>
				<td class="<?php echo $managefrm->getCSSFormLabelCellClass('favorite_mail'); ?>"><?php ShowHelpTip('favorite_mail'); ?><label for="favorite_mail_yes"><?php echo $LANG['managesettings_favorite_mail']; ?></label></td>
				<td class="<?php echo $managefrm->getCSSFormFieldCellClass('favorite_mail'); ?>"><?php echo $managefrm->getFormFieldErrorTip('favorite_mail'); ?>
					<input type="radio" name="favorite_mail" id="favorite_mail_yes" tabindex="<?php echo $managefrm->getTabIndex(); ?>" value="Yes"<?php echo ($managefrm->getFormField('favorite_mail') == 'Yes') ? ' checked' : ''; ?> /><label for="favorite_mail_yes"><?php echo $LANG['managesettings_yes']; ?></label>
					<input type="radio" name="favorite_mail" id="favorite_mail_no" tabindex="<?php echo $managefrm->getTabIndex(); ?>"  value="No"<?php echo ($managefrm->getFormField('favorite_mail') == 'No') ? ' checked' : ''; ?> /><label for="favorite_mail_no"><?php echo $LANG['managesettings_no']; ?></label>
				</td>
		   </tr>
		   <?php } ?>
		   <?php if ($managefrm->CFG['admin']['best_answers']['allowed'])
		{ ?>
		   <tr>
				<td class="<?php echo $managefrm->getCSSFormLabelCellClass('best_ans_mail'); ?>"><?php ShowHelpTip('best_ans_mail'); ?><label for="best_ans_mail_yes"><?php echo $LANG['managesettings_best_answer_mail']; ?></label></td>
				<td class="<?php echo $managefrm->getCSSFormFieldCellClass('best_ans_mail'); ?>"><?php echo $managefrm->getFormFieldErrorTip('best_ans_mail'); ?>
					<input type="radio" name="best_ans_mail" id="best_ans_mail_yes" tabindex="<?php echo $managefrm->getTabIndex(); ?>" value="Yes"<?php echo ($managefrm->getFormField('best_ans_mail') == 'Yes') ? ' checked' : ''; ?> /><label for="best_ans_mail_yes"><?php echo $LANG['managesettings_yes']; ?></label>
					<input type="radio" name="best_ans_mail" id="best_ans_mail_no" tabindex="<?php echo $managefrm->getTabIndex(); ?>" value="No"<?php echo ($managefrm->getFormField('best_ans_mail') == 'No') ? ' checked' : ''; ?> /><label for="best_ans_mail_no"><?php echo $LANG['managesettings_no']; ?></label>
				</td>
		   </tr>
		   <?php } ?>
		   <?php if ($managefrm->CFG['admin']['abuse_questions']['allowed'])
		{ ?>
		   <tr>
				<td class="<?php echo $managefrm->getCSSFormLabelCellClass('abuse_mail'); ?>"><?php ShowHelpTip('abuse_mail'); ?><label for="abuse_mail_yes"><?php echo $LANG['managesettings_abuse_mail']; ?></label></td>
				<td class="<?php echo $managefrm->getCSSFormFieldCellClass('abuse_mail'); ?>"><?php echo $managefrm->getFormFieldErrorTip('abuse_mail'); ?>
					<input type="radio" name="abuse_mail" id="abuse_mail_yes" tabindex="<?php echo $managefrm->getTabIndex(); ?>" value="Yes"<?php echo ($managefrm->getFormField('abuse_mail') == 'Yes') ? ' checked' : ''; ?> /><label for="abuse_mail_yes"><?php echo $LANG['managesettings_yes']; ?></label>
					<input type="radio" name="abuse_mail" id="abuse_mail_no" tabindex="<?php echo $managefrm->getTabIndex(); ?>" value="No"<?php echo ($managefrm->getFormField('abuse_mail') == 'No') ? ' checked' : ''; ?> /><label for="abuse_mail_no"><?php echo $LANG['managesettings_no']; ?></label>
				</td>
		   </tr>
		   <?php } ?>
		   <?php if ($managefrm->CFG['admin']['module']['mail'])
		{ ?>
		   <tr>
				<td class="<?php echo $managefrm->getCSSFormLabelCellClass('internal_mail'); ?>"><?php ShowHelpTip('internal_mail'); ?><label for="internal_mail_yes"><?php echo $LANG['managesettings_internal_mail']; ?></label></td>
				<td class="<?php echo $managefrm->getCSSFormFieldCellClass('internal_mail'); ?>"><?php echo $managefrm->getFormFieldErrorTip('internal_mail'); ?>
					<input type="radio" name="internal_mail" id="internal_mail_yes" tabindex="<?php echo $managefrm->getTabIndex(); ?>" value="Yes"<?php echo ($managefrm->getFormField('internal_mail') == 'Yes') ? ' checked' : ''; ?> /><label for="internal_mail_yes"><?php echo $LANG['managesettings_yes']; ?></label>
					<input type="radio" name="internal_mail" id="internal_mail_no" tabindex="<?php echo $managefrm->getTabIndex(); ?>" value="No"<?php echo ($managefrm->getFormField('internal_mail') == 'No') ? ' checked' : ''; ?> /><label for="internal_mail_no"><?php echo $LANG['managesettings_no']; ?></label>
				</td>
		   </tr>
		   <?php } ?>
		   		   <?php $managefrm->populateIndexPageFields($index_block_arr); ?>
		   <tr>
		   		<td class="clsFormFieldCellDefault">&nbsp;</td>
				<td class="<?php echo $managefrm->getCSSFormFieldCellClass('submit'); ?>">
					<input type="submit" class="clsSubmitButton" name="managesettings_submit" id="managesettings_submit" tabindex="<?php echo $managefrm->getTabIndex(); ?>" value="<?php echo $LANG['managesettings_submit']; ?>" />
					&nbsp;&nbsp;
					<input type="submit" class="clsCancelButton" name="managesettings_cancel" id="managesettings_cancel" tabindex="<?php echo $managefrm->getTabIndex(); ?>" value="<?php echo $LANG['managesettings_cancel']; ?>" />
				</td>
		   </tr>
		</table>
		<input type="hidden" name="avatar" value="<?php echo $managefrm->getFormField('avatar'); ?>" />
	</form>
<?php
}
?>
</div>
<script language="javascript" type="text/javascript">
function checkAllMail(frm)
	{
		var frmLength = frm.elements.length;
		var rdId = '';
		var rdVal = '_no';
		if (($('all_email_notification').checked))
			rdVal = '_yes';
		for ( var i=0; i<frmLength; i++)
			{
				if ((frm.elements[i].name.indexOf('_mail')!=-1) && (frm.elements[i].type == 'radio')){
					rdId = frm.elements[i].name + rdVal;
					$(rdId).checked = true;
				}
			}
	}
function checkAllSettings(frm)
	{
		var frmLength = frm.elements.length;
		var rdId = '';
		var rdVal = '_no';
		if (($('all_home_settings').checked))
			rdVal = '_yes';
		for ( var i=0; i<frmLength; i++)
			{
				if ((frm.elements[i].name.indexOf('_mail')==-1) && (frm.elements[i].type == 'radio') && (frm.elements[i].name.indexOf('sex')==-1)){
					rdId = frm.elements[i].name + rdVal;
					//alert(rdId);
					$(rdId).checked = true;
				}
			}
	}
</script>
<?php
if (chkUserImageAllowed())
{
?>
<script language="javascript" type="text/javascript">
ajaxUpdateDiv('<?php echo $CFG['site']['relative_url'] ?>avatars.php', '', 'selShowAvatarImages');
</script>
<?php
}
require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>