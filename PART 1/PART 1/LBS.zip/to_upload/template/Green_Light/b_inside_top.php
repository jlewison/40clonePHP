<link href="<?php echo("$path");?>stat.css" rel="stylesheet" type="text/css" />
<!--PAGE START -->

<div class="page">
  <!-- HEADER START -->
  <div class="header">
    <div class="header-left">
      <div class="date"><?php echo date('l d F Y');?></div>
      <div class="logo"><a href="<?php echo("$path");?>" title="Welcome to <?php echo("$sitetitle");?>!"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/images/logo.gif" alt="Welcome to <?php echo("$sitetitle");?>!" border="0" /></a></div>
    </div>
    <div class="header-right">
      <div class="top-menu-right">
        <div class="top-menu-left">
          <div class="top-menu"><?php if($p_terms == 'Y') { ?> <a href="<?php echo("$path");?>terms.php"><?php echo("$lang_16 |");?></a><?php } else {} ?> <?php if($p_about == 'Y') { ?> <a href="<?php echo("$path");?>about.php"><?php echo("$lang_80 |");?></a><?php } else {} ?> <a href="<?php echo("$path");?>contact.php"><?php echo("$lang_15");?></a> | <a href="<?php echo("$path");?>tags/"><?php echo("$lang_181");?></a></div>
        </div>
      </div>

<!--TOP ALPHABET NAV START -->
<?php
if($alphacat == 'Y') { ?>
<div class="alphabet">
<ul>
<li class="next"><a href="<?php echo("$path");?>0-9.html">#</a></li>
<li class="next"><a href="<?php echo("$path");?>A.html">A</a></li>
<li class="next"><a href="<?php echo("$path");?>B.html">B</a></li>
<li class="next"><a href="<?php echo("$path");?>C.html">C</a></li>
<li class="next"><a href="<?php echo("$path");?>D.html">D</a></li>
<li class="next"><a href="<?php echo("$path");?>E.html">E</a></li>
<li class="next"><a href="<?php echo("$path");?>F.html">F</a></li>
<li class="next"><a href="<?php echo("$path");?>G.html">G</a></li>
<li class="next"><a href="<?php echo("$path");?>H.html">H</a></li>
<li class="next"><a href="<?php echo("$path");?>I.html">I</a></li>
<li class="next"><a href="<?php echo("$path");?>J.html">J</a></li>
<li class="next"><a href="<?php echo("$path");?>K.html">K</a></li>
<li class="next"><a href="<?php echo("$path");?>L.html">L</a></li>
<li class="next"><a href="<?php echo("$path");?>M.html">M</a></li>
<li class="next"><a href="<?php echo("$path");?>N.html">N</a></li>
<li class="next"><a href="<?php echo("$path");?>O.html">O</a></li>
<li class="next"><a href="<?php echo("$path");?>P.html">P</a></li>
<li class="next"><a href="<?php echo("$path");?>Q.html">Q</a></li>
<li class="next"><a href="<?php echo("$path");?>R.html">R</a></li>
<li class="next"><a href="<?php echo("$path");?>S.html">S</a></li>
<li class="next"><a href="<?php echo("$path");?>T.html">T</a></li>
<li class="next"><a href="<?php echo("$path");?>U.html">U</a></li>
<li class="next"><a href="<?php echo("$path");?>V.html">V</a></li>
<li class="next"><a href="<?php echo("$path");?>W.html">W</a></li>
<li class="next"><a href="<?php echo("$path");?>X.html">X</a></li>
<li class="next"><a href="<?php echo("$path");?>Y.html">Y</a></li>
<li class="next"><a href="<?php echo("$path");?>Z.html">Z</a></li>
</ul>
</div>
<?php }
elseif($alphacat == 'N') { ?>
<?php }
else { ?>
<div class="alphabet">
<ul>
<li class="next"><a href="<?php echo("$path");?>0-9.html">#</a></li>
<li class="next"><a href="<?php echo("$path");?>A.html">A</a></li>
<li class="next"><a href="<?php echo("$path");?>B.html">B</a></li>
<li class="next"><a href="<?php echo("$path");?>C.html">C</a></li>
<li class="next"><a href="<?php echo("$path");?>D.html">D</a></li>
<li class="next"><a href="<?php echo("$path");?>E.html">E</a></li>
<li class="next"><a href="<?php echo("$path");?>F.html">F</a></li>
<li class="next"><a href="<?php echo("$path");?>G.html">G</a></li>
<li class="next"><a href="<?php echo("$path");?>H.html">H</a></li>
<li class="next"><a href="<?php echo("$path");?>I.html">I</a></li>
<li class="next"><a href="<?php echo("$path");?>J.html">J</a></li>
<li class="next"><a href="<?php echo("$path");?>K.html">K</a></li>
<li class="next"><a href="<?php echo("$path");?>L.html">L</a></li>
<li class="next"><a href="<?php echo("$path");?>M.html">M</a></li>
<li class="next"><a href="<?php echo("$path");?>N.html">N</a></li>
<li class="next"><a href="<?php echo("$path");?>O.html">O</a></li>
<li class="next"><a href="<?php echo("$path");?>P.html">P</a></li>
<li class="next"><a href="<?php echo("$path");?>Q.html">Q</a></li>
<li class="next"><a href="<?php echo("$path");?>R.html">R</a></li>
<li class="next"><a href="<?php echo("$path");?>S.html">S</a></li>
<li class="next"><a href="<?php echo("$path");?>T.html">T</a></li>
<li class="next"><a href="<?php echo("$path");?>U.html">U</a></li>
<li class="next"><a href="<?php echo("$path");?>V.html">V</a></li>
<li class="next"><a href="<?php echo("$path");?>W.html">W</a></li>
<li class="next"><a href="<?php echo("$path");?>X.html">X</a></li>
<li class="next"><a href="<?php echo("$path");?>Y.html">Y</a></li>
<li class="next"><a href="<?php echo("$path");?>Z.html">Z</a></li>
</ul>
</div>
<?php } ?>
<!--TOP ALPHABET NAV END -->

      <!--TOP MENU START -->
      <div class="main-menu">
        <ul>
          <li><a href="<?php echo("$path");?>"><?php echo("$lang_11");?></a></li>
          <li><a href="<?php echo("$path");?>new-links.php"><?php echo("$lang_12");?></a></li>
          <?php if($p_top == 'Y') { ?><li><a href="<?php echo("$path");?>links.php"><?php echo("$lang_13");?></a></li><?php } else {} ?>
          <li><a href="<?php echo("$path");?>submit.php?su_categ=<?php echo("$su_categ");?>"><?php echo("$lang_14");?></a></li>
        </ul>
      </div>
      <!--TOP MENU END -->
    </div>
  </div>
  <!-- HEADER END -->
  
    <!-- MIDDLE SECTION START -->
  <div class="main-content">
    <table cellspacing="0" cellpadding="0" class="main-tbl">
      <tr>
        <td valign="top" class="side-bar"><div class="main-left">

<!--SEARCH BOX START -->
          <div class="search-box">
            <form name="form1sea" method="post" action="<?php echo("$path");?>search.php">
              <input name="q" type="text" id="q" class="search_input" onFocus="this.value='';" value=" <?php echo("$lang_19");?>" />
              <input type="image" class="search-btn" src="<?php echo("$path");?>template/Green_Light/img/images/search-button.gif" name="Submit" value="<?php echo("$lang_20");?>" />
            </form>
          </div>
<!--SEARCH BOX START -->

<!--WELCOME TEXT START -->
          <div class="box" style="margin-bottom:15px;">
            <div class="box-cap-left">
              <div class="box-cap-right">
                <div class="box-cap"></div>
              </div>
            </div>
            <div class="box2-left">
              <div class="box-right">
                <div class="intro" style="font-size:11px;"><?php echo("$welcometext");?></div>
              </div>
            </div>
            <div class="box-bottom-left">
              <div class="box-bottom-right"></div>
            </div>
          </div>
<!--WELCOME TEXT END -->
          
<!--LEFT CATEGORIES START -->
          <div class="box">
            <div class="box-cap-right">
              <div class="box-cap"></div>
            </div>
            
<!--CATEGORY HEADER START -->
            <div class="cat-heads">
              <div class="cat-heads-right">
                <div class="cat-heads-left">categories</div>
              </div>
            </div>
<!--CATEGORY HEADER END -->
            
<!--CATEGORY LINK CONTAINER START -->
            <div class="box2-left">
              <div class="box-right">

<!--SUBCATEGORY START -->
<?php if($nocat <> 'Y') { include('template/Green_Light/b_subcategory.php'); } else {} ?>
<!--SUBCATEGORY END -->

                <ul class="cats-list">
<!--CATEGORY LINK START -->
<?php do { ?><li><a href="<?php echo("$path");?><?php echo $row_categRL['categseoname']; ?>/"><?php echo $row_categRL['categoryname']; ?></a></li><?php $row_categRL = mysql_fetch_assoc($categRL); if (!isset($nested_categRL)) { $nested_categRL= 1; } } while ($row_categRL); ?>
<!--CATEGORY LINK START -->
                  </ul>

              </div>
            </div>
<!--CATEGORY LINK CONTAINER END -->
            
            <div class="box-bottom-left">
              <div class="box-bottom-right"> </div>
            </div>
          </div>
<!--LEFT CATEGORIES END -->          
          
          </td>