<?php
/**
*
*
*
* @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
* @license
* @version SVN:$Id
* @since 2007-06-18
*/
$lang['addlanguage_title'] 					= 'Add Language';
$lang['addlanguage_lang_code'] 				= 'Language Code';
$lang['addlanguage_lang_name'] 				= 'Language Name';
$lang['addlanguage_delete'] 				= 'Delete';
$lang['addlanguage_action'] 				= 'Action';
$lang['addlanguage_no_record'] 				= 'No languages found!';
$lang['addlanguage_add_success_msg'] 		= 'Language added successfully!';
$lang['addlanguage_delete_success_msg'] 	= 'Language deleted successfully!';
$lang['addlanguage_error'] 					= 'Sorry language id missing!';
?>