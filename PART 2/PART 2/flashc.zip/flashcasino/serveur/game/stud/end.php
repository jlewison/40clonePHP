<?
error_reporting(0);
unset($l); 
session_start();
session_register($l);
if(!isset($l)){ 
header("Location: ../../login.php"); 
exit; 
}

include ("../../../setup.php");








if ($win_field>0){
mysql_query("update users set cash=cash+'$win_field' where login='$l'");


if ( $l != "demo" ) {

mysql_query("update game_bank set bank=bank-'$win_field' where name='ttuz'");
}

}

$result=mysql_query("select * from users where login='$l'");
$row=mysql_fetch_array($result);


$date=date("d.m.y");
$time=date("H:i:s");
$sqls="INSERT INTO stat_game VALUES('NULL','$date','$time','$l','$row[3]','$bet','$win_field','cyberstud')";
mysql_query($sqls);


for ($i = 1; $i<=300000; $i++)
{
$marat=$marat+10;
}


$result=mysql_query("select * from users where login='$l'");
$row=mysql_fetch_array($result);

echo "&Error=0&";



















?>