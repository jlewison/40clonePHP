<?php

/**
 * User Model
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 1/2/2008
 */
class Applicationmodel extends Model
{
		//Constructor
		function Applicationmodel()
		{
				parent::Model();
		}
		function getApplications($onlyBasic = false)
		{
				if ($onlyBasic == true) $appQuery = $this->db->query('SELECT * FROM applications WHERE user_id=0');
				else  $appQuery = $this->db->query('SELECT * FROM applications');
				if ($appQuery->num_rows() > 0)
				{
						$applications = array();
						foreach ($appQuery->result_array() as $appRow)
						{
								$applications[$appRow['application_id']] = $appRow;
						}
						return $applications;
				}
				else  return false;
		}
		function getUserApplications()
		{
				$this->db->select('application_ids');
				$this->db->where('user_id', $this->session->userdata('user_id'));
				$this->db->limit(1, 0);
				$userAppQuery = $this->db->get('users_applications');
				if ($userAppQuery->num_rows() > 0)
				{
						$userAppRow = $userAppQuery->result_array();
						$appQuery = $this->db->query('SELECT * FROM applications WHERE application_id IN (' . $userAppRow[0]['application_ids'] . ')');
						if ($appQuery->num_rows() > 0)
						{
								$applications = array();
								foreach ($appQuery->result_array() as $appRow)
								{
										$applications[$appRow['application_id']] = $appRow;
								}
								return $applications;
						}
						else  return false;
				}
				else  return false;
		}
		function isApplication($appName)
		{
				$this->db->where('application_name', $appName);
				$this->db->limit(1, 0);
				$appQuery = $this->db->get('applications');
				if ($appQuery->num_rows() > 0)
				{
						$appRow = $appQuery->result_array();
						return $appRow[0]['application_id'];
				}
				else  return false;
		}
		function isUserCanAccessTheApplication($applicationId)
		{
				$this->db->select('application_ids');
				$this->db->where('user_id', $this->session->userdata('user_id'));
				$this->db->limit(1, 0);
				$userAppQuery = $this->db->get('users_applications');
				if ($userAppQuery->num_rows() > 0)
				{
						$userAppRow = $userAppQuery->result_array();
						$userAppArray = explode(',', $userAppRow[0]['application_ids']);
						if (array_search($applicationId, $userAppArray) === false) return false;
						else  return true;
				}
				else  return false;
		}
		function getLanguages()
		{
				$this->db->select('lang_code, lang_name');
				$this->db->from('languages');
				$langQuery = $this->db->get();
				$languages = array();
				if ($langQuery->num_rows() > 0)
				{
						foreach ($langQuery->result_array() as $langRow)
						{
								$languages[] = $langRow;
						}
				}
				return $languages;
		}
}

?>