<?php
require_once ('../common/config.inc.php');
$CFG['lang']['include_files'][] = 'admin/includes/languages/%s/forumsTopics.php';
$CFG['lang']['include_files'][] = 'admin/includes/languages/%s/forumsTopicSearch.php';
$CFG['html']['header'] = 'admin/includes/languages/%s/html_header.php';
$CFG['html']['footer'] = 'admin/includes/languages/%s/html_footer.php';
$CFG['lang']['include_files'][] = 'common/languages/%s/lists_array/months_list_array.inc.php';
$CFG['lang']['include_files'][] = 'common/configs/config_forums.inc.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['mods']['include_files'][] = 'common/classes/class_ListRecordsHandler.lib.php';
$CFG['db']['is_use_db'] = true;
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class ForumsTopicFormHandler extends ListRecordsHandler
{
		public $forum_details_arr;
		public function buildConditionQuery($condition = '')
		{
				$this->sql_condition = $condition;
		}
		public function buildSortQuery()
		{
				$this->sql_sort = $this->fields_arr['orderby_field'] . ' ' . $this->fields_arr['orderby'];
		}
		public function isValidForumId($forum_id, $err_tip = '')
		{
				$sql = 'SELECT forum_id, forum_title, forum_description, forum_status ' . 'FROM ' . $this->CFG['db']['tbl']['forums'] . ' ' . 'WHERE forum_id = ' . $this->dbObj->Param($forum_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($forum_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($this->forum_details_arr = $rs->FetchRow())
				{
						return true;
				}
				$this->setCommonErrorMsg($err_tip);
				return false;
		}
		public function getTopicIds($search_value)
		{
				$sql = 'SELECT DISTINCT(topic_id) AS topic_id FROM ' . $this->CFG['db']['tbl']['forum_response'] . ' WHERE forum_response LIKE \'%' . addslashes($search_value) . '%\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$topic_ids = 0;
				while ($row = $rs->FetchRow())
				{
						$topic_ids .= ', ' . $row['topic_id'];
				}
				return $topic_ids;
		}
		public function showForumDetails()
		{
?>
 <div id="selShowGroupTitle">
  <h3>
  	<a href="forums.php"> <?php echo $this->LANG['forums_back_index']; ?></a>
  </h3>
  <p class="clsAlignRight" id="post"><a href="forumsTopicCreate.php?forum_id=<?php echo $this->forum_details_arr['forum_id']; ?>"> <?php echo $this->LANG['forums_post_topic']; ?> </a> </p>
</div>
<?php
		}
		public function populateRatingImages($rating = 0)
		{
				$rating_total = 10;
				for ($i = 1; $i <= $rating; $i++)
				{
?>
						<img src="<?php echo $this->CFG['site']['url']; ?>images/icon-ratehover.gif" />
<?php
				}
				for ($i = $rating; $i < $rating_total; $i++)
				{
?>
						<img src="<?php echo $this->CFG['site']['url']; ?>images/icon-rate.gif" />
<?php
				}
		}
		public function activeForumTopics()
		{
				$topic_ids = $this->fields_arr['topic_ids'];
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['forum_topics'] . ' SET topic_status = \'Yes\' ' . 'WHERE topic_id IN (' . $topic_ids . ') ';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$this->updateForumsTable($topic_ids);
				return true;
		}
		public function inactiveForumTopics()
		{
				$topic_ids = $this->fields_arr['topic_ids'];
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['forum_topics'] . ' SET topic_status = \'No\' ' . 'WHERE topic_id IN (' . $topic_ids . ') ';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$this->updateForumsTable($topic_ids);
				return true;
		}
		public function updateForumsTable($topic_ids)
		{
				$sql = 'SELECT count(topic_id) AS total_topic FROM ' . $this->CFG['db']['tbl']['forum_topics'] . ' WHERE forum_id = ' . $this->dbObj->Param($this->fields_arr['forum_id']) . ' AND topic_status = \'Yes\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['forum_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = $rs->FetchRow();
				$total_topic = $row['total_topic'];
				$sql = 'SELECT count(response_id) AS total_response FROM ' . $this->CFG['db']['tbl']['forum_response'] . ' AS fr ' . ', ' . $this->CFG['db']['tbl']['forum_topics'] . ' AS ft WHERE ' . 'fr.topic_id = ft.topic_id AND forum_id = ' . $this->dbObj->Param($this->fields_arr['forum_id']) . ' AND topic_status = \'Yes\' AND response_status = \'Yes\' ';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['forum_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = $rs->FetchRow();
				$total_response = $row['total_response'];
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['forums'] . ' SET ' . 'total_topics = ' . $this->dbObj->Param($total_topic) . ', total_response = ' . $this->dbObj->Param($total_response) . ' ' . 'WHERE forum_id = ' . $this->dbObj->Param($this->fields_arr['forum_id']);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($total_topic, $total_response, $this->fields_arr['forum_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return true;
		}
		public function deleteForumTopics()
		{
				$topic_ids = $this->fields_arr['topic_ids'];
				$this->deleteGroupForumTopicsTable($topic_ids);
				$this->updateForumsTable($topic_ids);
		}
		public function deleteGroupForumResponseTable($topic_ids)
		{
				$sql = 'DELETE FROM ' . $this->CFG['db']['tbl']['forum_response'] . ' ' . 'WHERE topic_id IN (' . $topic_ids . ') ';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return true;
		}
		public function deleteGroupForumTopicsTable($topic_ids)
		{
				$this->deleteGroupForumResponseTable($topic_ids);
				$sql = 'DELETE FROM ' . $this->CFG['db']['tbl']['forum_topics'] . ' ' . 'WHERE topic_id IN (' . $topic_ids . ') ';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return true;
		}
		public function updateForums($column_name, $affected_rows)
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['forums'] . ' SET ' . '' . $column_name . ' = ' . $column_name . ' - ' . $affected_rows . ' ' . 'WHERE forum_id = ' . $this->dbObj->Param($this->fields_arr['forum_id']) . ' ' . 'AND ' . $column_name . ' > 0';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['forum_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return true;
		}
		public function showForumTopics()
		{
				if (!$this->isResultsFound())
				{
?>
				<div id="selMsgAlert">
					<p><?php echo $this->LANG['forums_no_topics']; ?></p>
					<p class="clsMsgAdditionalText"><?php echo $this->LANG['forums_click_topic']; ?></p>
				</div>
				<?php
						return;
				}

?>
					<table border="1" cellspacing="0" summary="<?php echo $this->LANG['forums_tbl_summary']; ?>">
				      <tr>
					  	<th>&nbsp;<input type="checkbox" class="clsCheckRadio" name="checkall" id="checkall" tabindex="<?php echo $this->getTabIndex(); ?>" onclick="selectAll(this.form);"/></th>
				        <th<?php echo $this->getOrderCss('topic_user_name'); ?>><a href="" onClick="return changeOrderbyElements('selFormShowTopics','topic_user_name')"><?php echo $this->LANG['forums_topic_created']; ?></th>
				        <th<?php echo $this->getOrderCss('forum_topic'); ?>><a href="" onClick="return changeOrderbyElements('selFormShowTopics','forum_topic')"><?php echo $this->LANG['forums_topic']; ?></th>
				        <th>&nbsp;</th>
						<th<?php echo $this->getOrderCss('status'); ?>><a href="" onClick="return changeOrderbyElements('selFormShowTopics','status')"><?php echo $this->LANG['forums_status']; ?></th>
						<th<?php echo $this->getOrderCss('abuse_count'); ?>><a href="" onClick="return changeOrderbyElements('selFormShowTopics','abuse_count')"><?php echo $this->LANG['forums_abuse_count']; ?></th>
				        <th<?php echo $this->getOrderCss('last_user_name'); ?>><a href="" onClick="return changeOrderbyElements('selFormShowTopics','last_user_name')"><?php echo $this->LANG['forums_last_responsed']; ?></th>
						<th><?php echo $this->LANG['forums_manage']; ?></th>
				      </tr>
				<?php
				while ($row = $this->fetchResultRecord())
				{
						$topicUserDetails['user_id'] = $row['topic_user_id'];
						$topicUserDetails['name'] = $row['topic_user_name'];
						$topicUserDetails['image_path'] = $row['topic_user_image_path'];
						$topicUserDetails['gender'] = $row['topic_user_gender'];
						$topicUserDetails['img_user_id'] = $row['topic_img_user_id'];
						$topicUserDetails['t_width'] = $row['topic_t_width'];
						$topicUserDetails['t_height'] = $row['topic_t_height'];
						$topicUserDetails['s_width'] = $row['topic_s_width'];
						$topicUserDetails['s_height'] = $row['topic_s_height'];
						$topicUserDetails['photo_server_url'] = $row['topic_photo_server_url'];
						$topicUserDetails['photo_ext'] = $row['topic_photo_ext'];
						$lastPostUserDetails['user_id'] = $row['last_user_id'];
						$lastPostUserDetails['name'] = $row['last_user_name'];
						$lastPostUserDetails['image_path'] = $row['last_user_image_path'];
						$lastPostUserDetails['gender'] = $row['last_user_gender'];
						$lastPostUserDetails['img_user_id'] = $row['last_img_user_id'];
						$lastPostUserDetails['t_width'] = $row['last_t_width'];
						$lastPostUserDetails['t_height'] = $row['last_t_height'];
						$lastPostUserDetails['s_width'] = $row['last_s_width'];
						$lastPostUserDetails['s_height'] = $row['last_s_height'];
						$lastPostUserDetails['photo_server_url'] = $row['last_photo_server_url'];
						$lastPostUserDetails['photo_ext'] = $row['last_photo_ext'];
?>
					<tr>
  						<td class="clsAlignCenter"><input type="checkbox" class="clsCheckRadio" name="topic_ids[]" onclick="disableHeading('selFormShowTopics');" value="<?php echo $row['topic_id']; ?>" tabindex="<?php echo $this->getTabIndex(); ?>" <?php if ((is_array($this->fields_arr['topic_ids'])) && (in_array($row['topic_id'], $this->fields_arr['topic_ids']))) echo "CHECKED"; ?>/></td>
						<td>
							<?php if (chkUserImageAllowed())
						{ ?>
							<p id="selImageBorder"><?php displayForumUserSmallImage($topicUserDetails, false); ?></p>
							<?php } ?>
							<p><?php echo $topicUserDetails['name']; ?></p>
						</td>
						<td><p><a href="forumsResponses.php?forum_id=<?php echo $this->forum_details_arr['forum_id']; ?>&topic_id=<?php echo $row['topic_id']; ?>"> <?php echo wordWrapManual($row['forum_topic'], 50); ?></a></p>
    					<p> <?php echo $row['date_added'] ?> </p>
						<p>
							<?php
						if ($row['rating_count'] && $row['rating_total'])
						{
								$average_rating = round($row['rating_total'] / $row['rating_count']);
								$this->populateRatingImages($average_rating);
						}
?>
						</p>
  						</td>
						<td>
							<p><?php echo $this->LANG['forums_responses'] . ' ' . $row['total_response']; ?></p>
						   	<p><?php echo $this->LANG['forums_views'] . ' ' . $row['total_views']; ?></p>
						</td>
						<td><?php echo $row['topic_status']; ?></td>
						<td><?php echo $row['abuse_count']; ?></td>
						<td>
							<?php if (chkUserImageAllowed())
						{ ?>
	      					<p id="selImageBorder"><?php displayForumUserSmallImage($lastPostUserDetails, false); ?></p>
	      					<?php } ?>
							<p><?php echo $lastPostUserDetails['name']; ?></p>
	    				</td>
						<td><p><a href="forumsTopicCreate.php?forum_id=<?php echo $this->forum_details_arr['forum_id']; ?>&topic_id=<?php echo $row['topic_id']; ?>"><?php echo $this->LANG['forums_edit']; ?></a></p></td>
					</tr>
<?php
				}
				$anchor = 'dAltMlti';
?>
				<tr>
					<td colspan="8" class="<?php echo $this->getCSSFormFieldCellClass('action'); ?>">
						<a href="#" id="<?php echo $anchor; ?>"></a>
						<select name="action" id="action" tabindex="<?php echo $this->getTabIndex(); ?>">
							<option value=""><?php echo $this->LANG['forums_select']; ?></option>
							<option value="Active" <?php if ($this->fields_arr['action'] == 'active') echo 'SELECTED'; ?> ><?php echo $this->LANG['forums_active']; ?></option>
							<option value="Inactive" <?php if ($this->fields_arr['action'] == 'inactive') echo 'SELECTED'; ?> ><?php echo $this->LANG['forums_inactive']; ?></option>
							<option value="Delete" <?php if ($this->fields_arr['action'] == 'delete') echo 'SELECTED'; ?> ><?php echo $this->LANG['forums_delete']; ?></option>
						</select>
						&nbsp;&nbsp;
						<input type="button" class="clsSubmitButton" name="action_button" id="action_button" value="<?php echo $this->LANG['forums_action']; ?>" onClick="getMultiCheckBoxValue('selFormShowTopics', 'checkall', '<?php echo $this->LANG['forums_err_tip_select_topics']; ?>', 'dAltMlti');if(multiCheckValue!=''){getAction()}" />
					</td>
				</tr>
			</table>
			<?php
		}
		public function populateConditionOperators($highlight_operator)
		{
?>
				<option value="equalto" <?php if ($highlight_operator == 'equalto') echo 'SELECTED'; ?>><?php echo $this->LANG['topicsearch_equal_to'] ?></option>
				<option value="greaterthan" <?php if ($highlight_operator == 'greaterthan') echo 'SELECTED'; ?>><?php echo $this->LANG['topicsearch_greater_than'] ?></option>
				<option value="greaterthanequal" <?php if ($highlight_operator == 'greaterthanequal') echo 'SELECTED'; ?>><?php echo $this->LANG['topicsearch_greater_than_equal'] ?></option>
				<option value="lessthan" <?php if ($highlight_operator == 'lessthan') echo 'SELECTED'; ?>><?php echo $this->LANG['topicsearch_less_than'] ?></option>
				<option value="lessthanequal" <?php if ($highlight_operator == 'lessthanequal') echo 'SELECTED'; ?>><?php echo $this->LANG['topicsearch_less_than_equal'] ?></option>
				<option value="notequal" <?php if ($highlight_operator == 'notequal') echo 'SELECTED'; ?>><?php echo $this->LANG['topicsearch_not_equal'] ?></option>
			<?php
		}
}
$forums = new ForumsTopicFormHandler();
$forums->setPageBlockNames(array('msg_form_error', 'msg_form_success', 'form_forum_title', 'form_show_topics', 'form_search', 'page_nav', 'form_confirm'));
$forums->setCSSAlternativeRowClasses($CFG['data_tbl']['css_alternative_row_classes']);
$forums->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$forums->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$forums->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$forums->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$forums->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$forums->setDBObject($db);
$forums->setCfgLangGlobal($CFG, $LANG);
$forums->setAllPageBlocksHide();
$forums->setFormField('forum_id', '');
$forums->setFormField('topic_ids', array());
$forums->setFormField('srch', '');
$forums->setFormField('action', '');
$forums->setFormField('srch_topic', '');
$forums->setFormField('srch_response', '');
$forums->setFormField('srch_response_cnt', '');
$forums->setFormField('response_condition', '');
$forums->setFormField('srch_views', '');
$forums->setFormField('views_condition', '');
$forums->setFormField('srch_uname', '');
$forums->setFormField('srch_date_from', '');
$forums->setFormField('srch_date', '');
$forums->setFormField('srch_month', '');
$forums->setFormField('srch_year', '');
$forums->setFormField('srch_date_to', '');
$forums->setFormField('srch_todate', '');
$forums->setFormField('srch_tomonth', '');
$forums->setFormField('srch_toyear', '');
$forums->setFormField('topic_status', '');
$condition_operators = array('equalto', 'greaterthan', 'greaterthanequal', 'lessthan', 'lessthanequal', 'notequal');
$operators_arr = array('equalto' => "=", 'greaterthan' => ">", 'greaterthanequal' => ">=", 'lessthan' => "<", 'lessthanequal' => "<=", 'notequal' => "!=");
$forums->setMonthsListArr($LANG_LIST_ARR['months']);
$forums->setFormField('orderby_field', 'ft.forum_topic');
$forums->setFormField('orderby', 'DESC');
$condition = '';
$forums->numpg = $CFG['data_tbl']['numpg'];
$forums->setFormField('start', 0);
$forums->setFormField('numpg', $CFG['data_tbl']['numpg']);
$forums->setMinRecordSelectLimit($CFG['data_tbl']['min_record_select_limit']);
$forums->setMaxRecordSelectLimit($CFG['data_tbl']['max_record_select_limit']);
$forums->setNumPerPageListArr($CFG['data_tbl']['numperpage_list_arr']);
$forums->setTableNames(array());
$forums->setReturnColumns(array());
$forums->sanitizeFormInputs($_REQUEST);
if ($forums->isFormGETed($_REQUEST, 'forum_id'))
{
		$forums->chkIsNotEmpty('forum_id', $LANG['forums_err_tip_compulsory']) and $forums->chkIsNumeric('forum_id', $LANG['forums_err_tip_compulsory']) and $forums->isValidForumId($forums->getFormField('forum_id'), $LANG['forums_err_tip_invalid_forum_id']);
}
else
{
		Redirect2URL('forums.php');
}
if ($forums->isValidFormInputs())
{
		$forums->setAllPageBlocksHide();
		if ($forums->isFormPOSTed($_POST, 'confirm_action'))
		{
				$forums->chkIsNotEmpty('topic_ids', $LANG['forums_err_tip_compulsory']) or $forums->setCommonErrorMsg($LANG['forums_err_tip_select_topics']);
				$forums->chkIsNotEmpty('action', $LANG['forums_err_tip_compulsory']) or $forums->setCommonErrorMsg($LANG['forums_err_tip_select_action']);
				if ($forums->isValidFormInputs())
				{
						switch ($forums->getFormField('action'))
						{
								case 'Delete':
										$forums->deleteForumTopics();
										$success_msg = $LANG['forums_success_delete_message'];
										break;
								case 'Active':
										$forums->activeForumTopics();
										$success_msg = $LANG['forums_success_active_message'];
										break;
								case 'Inactive':
										$forums->inactiveForumTopics();
										$success_msg = $LANG['forums_success_inactive_message'];
										break;
						}
						$forums->setFormField('topic_ids', array());
				}
				if ($forums->isValidFormInputs())
				{
						$forums->setPageBlockShow('msg_form_success');
				}
				else
				{
						$forums->setPageBlockShow('msg_form_error');
				}
		}
		if ($forums->isFormPOSTed($_POST, 'forums_cancel'))
		{
				$forums->setFormField('topic_ids', array());
		}
		$forums->getFormField('srch_response_cnt') and $forums->chkIsNumeric('srch_response_cnt', $LANG['forums_err_tip_enter_numbers']);
		$forums->getFormField('srch_views') and $forums->chkIsNumeric('srch_views', $LANG['forums_err_tip_enter_numbers']);
		if ($forums->getFormField('srch_date') || $forums->getFormField('srch_month') || $forums->getFormField('srch_year'))
		{
				$forums->chkIsCorrectDate($forums->getFormField('srch_date'), $forums->getFormField('srch_month'), $forums->getFormField('srch_year'), 'srch_date_from', $LANG['forums_err_tip_date_empty'], $LANG['forums_err_tip_date_invalid']);
		}
		if ($forums->getFormField('srch_todate') || $forums->getFormField('srch_tomonth') || $forums->getFormField('srch_toyear'))
		{
				$forums->chkIsCorrectDate($forums->getFormField('srch_todate'), $forums->getFormField('srch_tomonth'), $forums->getFormField('srch_toyear'), 'srch_date_to', $LANG['forums_err_tip_date_empty'], $LANG['forums_err_tip_date_invalid']);
		}
		if ($forums->getFormField('srch_date_from') && $forums->getFormField('srch_date_to'))
		{
				$from_date = explode('-', $forums->getFormField('srch_date_from'));
				$from_date = mktime(0, 0, 0, $from_date[1], $from_date[2], $from_date[0]);
				$to_date = explode('-', $forums->getFormField('srch_date_to'));
				$to_date = mktime(0, 0, 0, $to_date[1], $to_date[2], $to_date[0]);
				if ($to_date < $from_date)
				{
						$forums->setCommonErrorMsg($LANG['forums_err_tip_date_invalid']);
						$forums->setPageBlockShow('msg_form_error');
				}
		}
		$search_condition = '';
		$searchArr = array();
		$searchArr[] = 'forum_id';
		$queryStr = '';
		if ($forums->isValidFormInputs())
		{
				if ($forums->getFormField('srch_topic'))
				{
						$search_condition .= ' AND ft.forum_topic like \'%' . $forums->getFormField('srch_topic') . '%\'';
						$searchArr[] = 'srch_topic';
						$queryStr .= '&srch_topic=' . $forums->getFormField('srch_topic');
				}
				if ($forums->getFormField('srch_response'))
				{
						$topic_ids = $forums->getTopicIds($forums->getFormField('srch_response'));
						$search_condition .= ' AND ft.topic_id IN (' . $topic_ids . ')';
						$searchArr[] = 'srch_response';
						$queryStr .= '&srch_response=' . $forums->getFormField('srch_response');
				}
				if ($forums->getFormField('topic_status'))
				{
						$search_condition .= ' AND ft.topic_status = \'' . $forums->getFormField('topic_status') . '\'';
						$searchArr[] = 'topic_status';
						$queryStr .= '&topic_status=' . $forums->getFormField('topic_status');
				}
				if ($forums->getFormField('srch_response_cnt'))
				{
						$operator = '=';
						if (in_array($forums->getFormField('response_condition'), $condition_operators)) $operator = $operators_arr[$forums->getFormField('response_condition')];
						$search_condition .= ' AND ft.total_response ' . $operator . ' \'' . addslashes($forums->getFormField('srch_response_cnt')) . '\'';
						$searchArr[] = 'srch_response_cnt';
						$searchArr[] = 'response_condition';
						$queryStr .= '&srch_response_cnt=' . $forums->getFormField('srch_response_cnt');
						$queryStr .= '&response_condition=' . $forums->getFormField('response_condition');
				}
				if ($forums->getFormField('srch_views'))
				{
						$operator = '=';
						if (in_array($forums->getFormField('views_condition'), $condition_operators)) $operator = $operators_arr[$forums->getFormField('views_condition')];
						$search_condition .= ' AND ft.total_views ' . $operator . ' \'' . addslashes($forums->getFormField('srch_views')) . '\'';
						$searchArr[] = 'srch_response_cnt';
						$searchArr[] = 'views_condition';
						$queryStr .= '&srch_views=' . $forums->getFormField('srch_views');
						$queryStr .= '&views_condition=' . $forums->getFormField('views_condition');
				}
				if ($forums->getFormField('srch_uname'))
				{
						$search_condition .= ' AND u.' . $forums->getUserTableField('name') . ' like \'%' . addslashes($forums->getFormField('srch_uname')) . '%\'';
						$searchArr[] = 'srch_uname';
						$queryStr .= '&srch_uname=' . $forums->getFormField('srch_uname');
				}
				if ($forums->getFormField('srch_date_from') && $forums->getFormField('srch_date_to'))
				{
						$search_condition .= ' AND ft.date_added BETWEEN \'' . $forums->getFormField('srch_date_from') . ' 00:00:00\'';
						$search_condition .= ' AND \'' . $forums->getFormField('srch_date_to') . ' 23:59:59\'';
						$searchArr[] = 'srch_date';
						$queryStr .= '&srch_date=' . $forums->getFormField('srch_date');
						$searchArr[] = 'srch_month';
						$queryStr .= '&srch_month=' . $forums->getFormField('srch_month');
						$searchArr[] = 'srch_year';
						$queryStr .= '&srch_year=' . $forums->getFormField('srch_year');
						$searchArr[] = 'srch_todate';
						$queryStr .= '&srch_todate=' . $forums->getFormField('srch_todate');
						$searchArr[] = 'srch_tomonth';
						$queryStr .= '&srch_tomonth=' . $forums->getFormField('srch_tomonth');
						$searchArr[] = 'srch_toyear';
						$queryStr .= '&srch_toyear=' . $forums->getFormField('srch_toyear');
				}
		}
		else
		{
				$forums->setPageBlockShow('msg_form_error');
		}
		$forums->setFormField('queryStr', $queryStr);
		$forums->setTableNames(array($CFG['db']['tbl']['forum_topics'] . ' as ft LEFT JOIN ' . $CFG['db']['tbl']['users'] . ' AS u1 ON ft.last_post_user_id = u1.' . $forums->getUserTableField('user_id'), $CFG['db']['tbl']['users'] . ' as u'));
		$forums->setReturnColumns(array('ft.forum_id', 'ft.abuse_count', 'ft.topic_id', 'ft.forum_topic', 'ft.user_id', 'CASE WHEN ft.topic_status = \'Yes\' THEN \'' . $LANG['forums_active'] . '\' ELSE \'' . $LANG['forums_inactive'] . '\' END AS topic_status', 'ft.total_response', 'ft.total_views', 'ft.last_post_user_id', 'ft.last_post_date', 'ft.rating_total', 'ft.rating_count', 'DATE_FORMAT(ft.date_added, \'' . $CFG['format']['date'] . '\') AS date_added', 'u.' . $forums->getUserTableField('user_id') . ' AS topic_user_id', 'u.' . $forums->getUserTableField('name') . ' AS topic_user_name', 'u.' . $forums->getUserTableField('image_path') . ' AS topic_user_image_path', 'u.' . $forums->getUserTableField('gender') . ' AS topic_user_gender', 'u.' . $forums->getUserTableField('user_id') . ' AS topic_img_user_id', 'u.' . $forums->getUserTableField('t_height') . ' AS topic_t_height', 'u.' . $forums->getUserTableField('t_width') . ' AS topic_t_width', 'u.' . $forums->getUserTableField('s_height') .
				' AS topic_s_height', 'u.' . $forums->getUserTableField('s_width') . ' AS topic_s_width', 'u.' . $forums->getUserTableField('photo_server_url') . ' AS topic_photo_server_url', 'u.' . $forums->getUserTableField('photo_ext') . ' AS topic_photo_ext', 'u1.' . $forums->getUserTableField('user_id') . ' AS last_user_id', 'u1.' . $forums->getUserTableField('name') . ' AS last_user_name', 'u1.' . $forums->getUserTableField('image_path') . ' AS last_user_image_path', 'u1.' . $forums->getUserTableField('gender') . ' AS last_user_gender', 'u1.' . $forums->getUserTableField('user_id') . ' AS last_img_user_id', 'u1.' . $forums->getUserTableField('t_height') . ' AS last_t_height', 'u1.' . $forums->getUserTableField('t_width') . ' AS last_t_width', 'u1.' . $forums->getUserTableField('s_height') . ' AS last_s_height', 'u1.' . $forums->getUserTableField('s_width') . ' AS last_s_width', 'u1.' . $forums->getUserTableField('photo_server_url') . ' AS last_photo_server_url', 'u1.' . $forums->
				getUserTableField('photo_ext') . ' AS last_photo_ext'));
		$condition = 'ft.user_id = u.' . $forums->getUserTableField('user_id') . ' AND u.' . $forums->getUserTableField('usr_status') . ' = \'Ok\' AND ft.forum_id = \'' . $forums->getFormField('forum_id') . '\'';
		if ($search_condition)
		{
				$condition .= $search_condition;
		}
		$forums->buildSelectQuery();
		$forums->buildConditionQuery($condition);
		$responseClass = $viewClass = $defaultClass = '';
		if ($forums->getFormField('srch') == 'mostresponse')
		{
				$forums->setFormField('orderby_field', 'ft.total_response');
				$forums->setFormField('orderby', 'DESC');
				$searchArr[] = 'srch';
				$responseClass = 'class="clsActivePhotoSubLink"';
		} elseif ($forums->getFormField('srch') == 'mostviews')
		{
				$forums->setFormField('orderby_field', 'ft.total_views');
				$forums->setFormField('orderby', 'DESC');
				$searchArr[] = 'srch';
				$viewClass = 'class="clsActivePhotoSubLink"';
		}
		else
		{
				$defaultClass = 'class="clsActivePhotoSubLink"';
		}
		$forums->buildSortQuery();
		$forums->buildQuery();
		$forums->executeQuery();
		$forums->setPageBlockShow('form_forum_title');
		$forums->setPageBlockShow('form_show_topics');
		$forums->setPageBlockShow('form_search');
		if ($forums->isResultsFound())
		{
				$forums->setPageBlockShow('page_nav');
		}
}
else
{
		$forums->setPageBlockShow('msg_form_error');
		Redirect2URL('forums.php');
}




?>
<script language="javascript">
	var block_arr= new Array('selMsgConfirm');
	var replace_url = '<?php echo $CFG['site']['url']; ?>login.php';
	var please_select_action = '<?php echo $LANG['forums_err_tip_select_action']; ?>';
	var confirm_message = '';
	function getAction()
		{
			var act_value = document.selFormShowTopics.action.value;
			if(act_value)
				{
					switch (act_value)
						{
							case 'Delete':
								confirm_message = '<?php echo $LANG['forums_delete_confirm_message']; ?>';
								break;
							case 'Active':
								confirm_message = '<?php echo $LANG['forums_active_confirm_message']; ?>';
								break;
							case 'Inactive':
								confirm_message = '<?php echo $LANG['forums_inactive_confirm_message']; ?>';
								break;
						}
					$('confirmMessage').innerHTML = confirm_message;
					document.msgConfirmform.action.value = act_value;
					Confirmation('dAltMlti', 'selMsgConfirm', 'msgConfirmform', Array('topic_ids'), Array(multiCheckValue), Array('value'), -25, -290, 'selFormShowTopics');
				}
				else
					alert_manual(please_select_action, 'dAltMlti');
		}
</script>
<div id="selForumsTopicListAll" class="clsForums">
  <h2 class="clsForumTopic"><span>
  <a href="forums.php"><?php echo $LANG['forums_title_index']; ?></a>
  &nbsp;-&nbsp;
  <?php echo $forums->forum_details_arr['forum_title']; ?>
  </span></h2>
  <div id="selMsgConfirm" class="clsPopupConfirmation" style="display:none;position:absolute;">
		<p id="confirmMessage"></p>
		<form name="msgConfirmform" id="msgConfirmform" method="post" action="<?php echo URL($_SERVER['PHP_SELF']); ?>">
			<table summary="<?php echo $LANG['forums_confirm_tbl_summary']; ?>">
				<tr>
					<td>
						<input type="submit" class="clsSubmitButton" name="confirm_action" id="confirm_action" tabindex="<?php echo $forums->getTabIndex(); ?>" value="<?php echo $LANG['forums_confirm']; ?>" />
						&nbsp;
						<input type="button" class="clsCancelButton" name="cancel" id="cancel" tabindex="<?php echo $forums->getTabIndex(); ?>" value="<?php echo $LANG['forums_cancel']; ?>"  onClick="return hideAllBlocks('selFormShowTopics');" />
						<input type="hidden" name="topic_ids" id="topic_ids" />
						<input type="hidden" name="action" id="action" />
						<?php $forums->populateHidden(array('srch', 'start', 'forum_id', 'srch_topic', 'srch_response', 'srch_response_cnt', 'response_condition', 'srch_views', 'views_condition', 'srch_uname', 'srch_date', 'srch_month', 'srch_year', 'srch_todate', 'srch_tomonth', 'srch_toyear', 'topic_status', 'orderby_field', 'orderby')); ?>
					</td>
				</tr>
			</table>
		</form>
	</div>
    <div id="selLeftNavigation">
  <?php
if ($forums->isShowPageBlock('msg_form_error'))
{
?>
  <div id="selMsgError">
    <p><?php echo $LANG['msg_error_sorry']; ?> <?php echo $forums->getCommonErrorMsg(); ?></p>
  </div>
  <?php
}
if ($forums->isShowPageBlock('msg_form_success'))
{
?>
  <div id="selMsgSuccess">
    <p><?php echo $success_msg; ?></p>
  </div>
  <?php
}
if ($forums->isShowPageBlock('form_forum_title'))
{
}
if ($forums->isShowPageBlock('form_search'))
{
?>
		<div id="selShowSearchGroup">
		<form name="form_search" id="selFormSearch" method="post" action="<?php echo URL($_SERVER['PHP_SELF']); ?>">
			<table cellspacing="0" summary="<?php echo $LANG['topicsearch_tbl_summary']; ?>">
				<tr>
					<td class="<?php echo $forums->getCSSFormLabelCellClass('srch_topic'); ?>"><label for="srch_topic"><?php echo $LANG['topicsearch_search_topics']; ?></label></td>
					<td class="<?php echo $forums->getCSSFormFieldCellClass('srch_topic'); ?>"><input type="text" class="clsTextBox" name="srch_topic" id="srch_topic" value="<?php echo $forums->getFormField('srch_topic'); ?>" tabindex="<?php echo $forums->getTabIndex(); ?>"/></td>
				</tr>
				<tr>
					<td class="<?php echo $forums->getCSSFormLabelCellClass('srch_response'); ?>"><label for="srch_response"><?php echo $LANG['topicsearch_search_response']; ?></label></td>
					<td class="<?php echo $forums->getCSSFormFieldCellClass('srch_response'); ?>"><input type="text" class="clsTextBox" name="srch_response" id="srch_response" value="<?php echo $forums->getFormField('srch_response'); ?>" tabindex="<?php echo $forums->getTabIndex(); ?>"/></td>
				</tr>
				<tr>
					<td class="<?php echo $forums->getCSSFormLabelCellClass('srch_response_cnt'); ?>"><label for="srch_response_cnt"><?php echo $LANG['topicsearch_search_response_count']; ?></label></td>
					<td class="<?php echo $forums->getCSSFormFieldCellClass('srch_response_cnt'); ?>">
						<select name="response_condition" id="response_condition" tabindex="<?php echo $forums->getTabIndex(); ?>" >
							<?php $forums->populateConditionOperators($forums->getFormField('response_condition')); ?>
						</select>
						<input type="text" class="clsTextBox" name="srch_response_cnt" id="srch_response_cnt" value="<?php echo $forums->getFormField('srch_response_cnt'); ?>" tabindex="<?php echo $forums->getTabIndex(); ?>"/>
					</td>
				</tr>
				<tr>
					<td class="<?php echo $forums->getCSSFormLabelCellClass('srch_views'); ?>"><label for="srch_views"><?php echo $LANG['topicsearch_search_views']; ?></label></td>
					<td class="<?php echo $forums->getCSSFormFieldCellClass('srch_views'); ?>">
						<select name="views_condition" id="views_condition" tabindex="<?php echo $forums->getTabIndex(); ?>" >
							<?php $forums->populateConditionOperators($forums->getFormField('views_condition')); ?>
						</select>
						<input type="text" class="clsTextBox" name="srch_views" id="srch_views" value="<?php echo $forums->getFormField('srch_views'); ?>" tabindex="<?php echo $forums->getTabIndex(); ?>"/>
					</td>
				</tr>
				<tr>
					<td class="<?php echo $forums->getCSSFormLabelCellClass('srch_uname'); ?>"><label for="srch_uname"><?php echo $LANG['topicsearch_search_uname']; ?></label></td>
					<td class="<?php echo $forums->getCSSFormFieldCellClass('srch_uname'); ?>"><input type="text" class="clsTextBox" name="srch_uname" id="srch_uname" value="<?php echo $forums->getFormField('srch_uname'); ?>" tabindex="<?php echo $forums->getTabIndex(); ?>"/></td>
				</tr>
				<tr>
					<td class="<?php echo $forums->getCSSFormLabelCellClass('srch_date_from'); ?>"><label for="srch_date"><?php echo $LANG['topicsearch_search_date_created_from']; ?></label></td>
					<td class="<?php echo $forums->getCSSFormFieldCellClass('srch_date_from'); ?>"><?php echo $forums->getFormFieldErrorTip('srch_date_from'); ?>
						<select name="srch_date" id="srch_date" tabindex="<?php echo $forums->getTabIndex(); ?>">
							<option value=""><?php echo $LANG['topicsearch_search_date']; ?></option>
							<?php $forums->populateBWNumbers(1, 31, $forums->getFormField('srch_date')); ?>
						</select>
						<select name="srch_month" id="srch_month" tabindex="<?php echo $forums->getTabIndex(); ?>">
							<option value=""><?php echo $LANG['topicsearch_search_month']; ?></option>
							<?php $forums->populateMonthsList($forums->getFormField('srch_month')); ?>
						</select>
						<select name="srch_year" id="srch_year" tabindex="<?php echo $forums->getTabIndex(); ?>">
							<option value=""><?php echo $LANG['topicsearch_search_year']; ?></option>
							<?php $forums->populateBWNumbers(1920, date("Y"), $forums->getFormField('srch_year')); ?>
						</select>
					</td>
				</tr>
				<tr>
					<td class="<?php echo $forums->getCSSFormLabelCellClass('srch_date_to'); ?>"><label for="srch_todate"><?php echo $LANG['topicsearch_search_date_created_to']; ?></label></td>
					<td class="<?php echo $forums->getCSSFormFieldCellClass('srch_date_to'); ?>"><?php echo $forums->getFormFieldErrorTip('srch_date_to'); ?>
						<select name="srch_todate" id="srch_todate" tabindex="<?php echo $forums->getTabIndex(); ?>">
							<option value=""><?php echo $LANG['topicsearch_search_date']; ?></option>
							<?php $forums->populateBWNumbers(1, 31, $forums->getFormField('srch_todate')); ?>
						</select>
						<select name="srch_tomonth" id="srch_tomonth" tabindex="<?php echo $forums->getTabIndex(); ?>">
							<option value=""><?php echo $LANG['topicsearch_search_month']; ?></option>
							<?php $forums->populateMonthsList($forums->getFormField('srch_tomonth')); ?>
						</select>
						<select name="srch_toyear" id="srch_toyear" tabindex="<?php echo $forums->getTabIndex(); ?>">
							<option value=""><?php echo $LANG['topicsearch_search_year']; ?></option>
							<?php $forums->populateBWNumbers(1920, date("Y"), $forums->getFormField('srch_toyear')); ?>
						</select>
					</td>
				</tr>
				<tr>
                <td>&nbsp;</td>
					<td class="<?php echo $forums->getCSSFormFieldCellClass('topicsearch_search'); ?>"><input type="submit" class="clsSubmitButton" value="<?php echo $LANG['topicsearch_search']; ?>" id="topicsearch_search" name="topicsearch_search" tabindex="<?php echo $forums->getTabIndex(); ?>"/></td>
				</tr>
			</table>
			<input type="hidden" name="forum_id" value="<?php echo $forums->getFormField('forum_id'); ?>" />
			</form>
		</div>
      <?php
}
?>
  <form name="selFormShowTopics" id="selFormShowTopics" method="post" action="<?php echo URL($_SERVER['PHP_SELF']); ?>" autocomplete="off">
<?php
if ($forums->isShowPageBlock('page_nav') && $CFG['admin']['navigation']['top'])
{
		$forums->populatePageLinksPOST($forums->getFormField('start'), 'selFormShowTopics');
}
if ($forums->isShowPageBlock('form_show_topics'))
{
?>
    <div id="selShowForumTopics">
<?php
		if ($forums->isResultsFound())
		{
?>
          <?php $forums->showForumTopics(); ?>
<?php
		}
		else
		{
?>
			<div id="selMsgAlert">
				<p><?php echo $LANG['no_records_found']; ?></p>
			</div>
<?php
		}
?>
	</div>
  <?php
}
if ($forums->isShowPageBlock('page_nav') && $CFG['admin']['navigation']['bottom'])
{
		$forums->populatePageLinksPOST($forums->getFormField('start'), 'selFormShowTopics');
}
$forums->populateHidden(array('srch', 'start', 'forum_id', 'srch_topic', 'srch_response', 'srch_response_cnt', 'response_condition', 'srch_views', 'views_condition', 'srch_uname', 'srch_date', 'srch_month', 'srch_year', 'srch_todate', 'srch_tomonth', 'srch_toyear', 'topic_status', 'orderby_field', 'orderby'));
?>
		</form>
	</div>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>
