<?php
$LANG['header_mail'] = 'Mail';
$LANG['header_inbox'] = 'Inbox';
$LANG['header_sent'] = 'Sent';
$LANG['header_saved'] = 'Saved';
$LANG['header_requests'] = 'Requests';
$LANG['header_video_mail'] = 'Video Mail';
$LANG['header_trash'] = 'Trash';
$LANG['header_compose'] = 'Compose';
$LANG['header_history'] = 'History';
$LANG['mail_title_inbox'] = 'Inbox';
$LANG['mail_title_request'] = 'Requests';
$LANG['mail_title_saved'] = 'Saved Mails';
$LANG['mail_title_sent'] = 'Sent Mails';
$LANG['mail_title_trash'] = 'Trashed Mails';
$LANG['mail_title_video'] = 'Video Mail';
$LANG['mail_invalid_folder'] = 'Invalid Folder';
?>