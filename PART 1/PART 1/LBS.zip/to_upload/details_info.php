<?php
require_once('Connections/apound.php');

$colname_UPBID = "1";

if (isset($_GET['ucat'])) {
	$colname_UPBID = (get_magic_quotes_gpc()) ? $_GET['ucat'] : addslashes($_GET['ucat']);
}

	mysql_select_db($database_apound, $apound);
		$query_UPBID = sprintf("SELECT * FROM main WHERE dtu = %s", $colname_UPBID);
		$UPBID = mysql_query($query_UPBID, $apound) or die(mysql_error());
		$row_UPBID = mysql_fetch_assoc($UPBID);
		$totalRows_UPBID = mysql_num_rows($UPBID);

$UPBIDcategory = $row_UPBID['maincategory'];			
	mysql_select_db($database_apound, $apound);
		$query_LdetCAT = "SELECT * FROM categorylisting WHERE catlistid = '$UPBIDcategory'";
		$LdetCAT = mysql_query($query_LdetCAT, $apound) or die(mysql_error());
		$row_LdetCAT = mysql_fetch_assoc($LdetCAT);
		$totalRows_LdetCAT = mysql_num_rows($LdetCAT);
?>