<?php
/**
*
*
*
* @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
* @license
* @version SVN:$Id
* @since 2007-06-18
*/
$lang['sitesettings_title'] 					= 'Site Settings';
$lang['sitesettings_general_settings'] 			= 'General Settings';
$lang['sitesettings_record_listing_settings'] 	= 'Records List Settings';
$lang['sitesettings_admin_name'] 				= 'Sender name';
$lang['sitesettings_admin_email'] 				= 'Sender email id';
$lang['sitesettings_site_name'] 				= 'Your site name';
$lang['sitesettings_site_title'] 				= 'Your site title';
$lang['sitesettings_records_per_page'] 			= 'Records per page';
$lang['sitesettings_albums_on_profile'] 		= 'Total albums on profile page';
$lang['sitesettings_posts_on_profile']			= 'Total posts on profile page';
$lang['sitesettings_posts_common']				= 'Total posts on groups and events home page';
$lang['sitesettings_list_on_home']				= 'Total networks, friends on home page';
$lang['sitesettings_submit']					= 'Save changes';
$lang['sitesettings_success_msg']				= 'Site settings updated successfully!';
?>