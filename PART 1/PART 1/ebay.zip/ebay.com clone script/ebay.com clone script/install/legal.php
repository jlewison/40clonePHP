<?php //00461
// Copyright Notice
// Web Site URL:  http://www.zeeways.com
// Script Owner eMail: mail@zeeways.com
// Date: April, 2007
// Script Name: Zeeways Auction Website PHP Script
// Copyright Details: This script is not free.  Do not Remove this Copy Right notice.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the site administrator.');exit(199);
?>
4+oV54jlRMjCjrLD7TluI7/7O8qAdfeT2ILksv+idXtDxYB2t9mSGx3UqwoXLJGCy+6HZrGoK8US
0cdPl6lRJOiRThZ30UHY/c6xOSvqewT43Olmb2pIWCVL3p+IR4KfXwHnYbkyiOog6c+WFwsWS/wK
N7uIEtR53LNM0QPBrh4OZH7nWb7JGx3kSFDCUSnWEjiwKZWJgNtwWp1KoETUszcTZnSYhO1k8MdS
MzboEi8Q1D0ubGFi7vTBbgOq34npzoskINwscd0HWmDX33wER9qwyhd1Q9pnS00R/w5gigxiBCkc
QVPPJS9/SJPTyjBu3719koRu1dZHeSqxjcnfx3aJjZyeMV7AnOa6kCX+ILFUhEScQ8pjUZKEPUjp
zoOwebhaf1+y4WdDNi2ZvgZBfvEnbRAuWD+WAHiuMu/VL+bbG3YXHBNgKd+fFOpJ0rV0skluypBJ
ZpT5qcTL9y+2PCbB9qCYouQHEyhyd361Xy3wpWC0n9j5mtbuNvQQaSKhAGnb/4uDtjFf1loYlt03
+O6yP/Upj9TEClHV3leT2hKqJ2hMs7Ex/FuVOtcPciq3jF28W8v7xwjCv3b9sjU2z7/FCB5d/t0J
lRYzD1uGX221W6282AYQ0vtT6XR/UGQ/E86i1txWmVdHqLR9cThs02ILN9z7cSrOo6mpbUQqPx6X
/6pPneKhzc9/yJYiGMQdJv9r0l3rFjCLu5c3UPR2xTQtCyGffPbO4u2LA6kmS39nDH0emVgjl2X5
8KdLZWrSSEzm5/P/P9Z/LkbszBMLSRUWGc8/lFedw6RrfJkt+BDO65EAA7BIFQKnRrB55AV+yYBg
V+fT37/3PY9rtFq6hUc231mrvynQFz/wksmR2lmfJAbzXiKc7yTDBDlonu37B8igvKfHoeVEC11U
SbOCrlISM2Z9drwbq7+lWurWaCCYmu5wIoc82/lwDzdDzE6zvhrsCtqTzjQcKuRaAK1WeVqG3SiW
g5XF/GEntbhqtNL3w1xVlIrHQrdNbZ1YYxltVSHjbj2YUV1RV0kmr0p6Dg1JkZripIFO9UodXjeG
YOHmXKsmMpA+OnIyj1YlACME7PfGGrkijynH4DJGlzb8cDTFf7hL2D9BZL3V9f/q8zNbLjXsXsk6
tSBIhvC/d026BmQf+TNJmP2nGhsbMP96EqpN2FUnCWItv/QXtVpExplHwqVS1uVqk6Q3Unu27WRo
4eI+mzVa9ttxeQABbt1YVlzTMbzmp3AG2KuukYk35KHLNa+Nb2UV+BDnMn8rxAVCE+iTLbU8N31G
n2oAzwaozxsvRnBF7AlhwojVUlehzjnBVAT95pBoXD6PBmr2WH4TlUlbSraZE09jzYZ/hJ6Z/zcJ
