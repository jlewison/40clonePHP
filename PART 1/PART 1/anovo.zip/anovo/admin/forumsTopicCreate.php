<?php
require_once ('../common/config.inc.php');
$CFG['lang']['include_files'][] = 'admin/includes/languages/%s/forumsTopicCreate.php';
$CFG['html']['header'] = 'admin/includes/languages/%s/html_header.php';
$CFG['html']['footer'] = 'admin/includes/languages/%s/html_footer.php';
$CFG['lang']['include_files'][] = 'common/languages/%s/help.inc.php';
$CFG['lang']['include_files'][] = 'common/configs/config_forums.inc.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['db']['is_use_db'] = true;
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class ForumTopicFormHandler extends FormHandler
{
		public $forum_details_arr;
		public $forum_topic_details_arr;
		public function chkLength($field_name, $err_tip = '')
		{
				$url_len = strlen($this->fields_arr[$field_name]);
				if ($url_len < 3 || $url_len > 20)
				{
						$this->fields_err_tip_arr[$field_name] = $err_tip;
						return false;
				}
				return true;
		}
		public function isValidForumId($forum_id, $err_tip = '')
		{
				$sql = 'SELECT forum_id, forum_title, forum_description, forum_status ' . 'FROM ' . $this->CFG['db']['tbl']['forums'] . ' ' . 'WHERE forum_id = ' . $this->dbObj->Param($forum_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($forum_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($this->forum_details_arr = $rs->FetchRow())
				{
						return true;
				}
				$this->setCommonErrorMsg($err_tip);
				return false;
		}
		public function isValidForumTopicId($forum_id, $topic_id, $err_tip = '')
		{
				$sql = 'SELECT fr.response_id, g.topic_id, g.forum_id, g.forum_topic, g.topic_status, g.user_id, DATE_FORMAT(g.date_added, \'' . $this->CFG['format']['date'] . '\') as date_added, fr.forum_response' . ', u.' . $this->getUserTableField('name') . ' AS name, u.' . $this->getUserTableField('image_path') . ' AS image_path, u.' . $this->getUserTableField('gender') . ' AS gender' . ' FROM ' . $this->CFG['db']['tbl']['users'] . ' AS u, ' . $this->CFG['db']['tbl']['forum_topics'] . ' AS g' . ' LEFT JOIN ' . $this->CFG['db']['tbl']['forum_response'] . ' AS fr' . ' ON g.topic_id = fr.topic_id' . ' WHERE g.user_id = u.' . $this->getUserTableField('user_id') . ' AND g.topic_id = ' . $this->dbObj->Param($topic_id) . ' AND g.forum_id = ' . $this->dbObj->Param($forum_id) . ' ORDER BY fr.response_id LIMIT 1';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($topic_id, $forum_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($this->forum_topic_details_arr = $rs->FetchRow())
				{
						return true;
				}
				$this->setCommonErrorMsg($err_tip);
				return false;
		}
		public function chkIsNotExists($forum_topic, $forum_id, $err_tip = '')
		{
				$sql = 'SELECT COUNT(topic_id) AS cnt' . ' FROM ' . $this->CFG['db']['tbl']['forum_topics'] . ' WHERE forum_id = ' . $this->dbObj->Param($forum_id) . ' AND forum_topic = ' . $this->dbObj->Param($forum_topic);
				$fields_value_arr = array($forum_id, $forum_topic);
				if ($this->fields_arr['topic_id'])
				{
						$sql .= ' AND topic_id != ' . $this->dbObj->Param($this->fields_arr['topic_id']);
						$fields_value_arr[] = $this->fields_arr['topic_id'];
				}
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, $fields_value_arr);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = $rs->FetchRow();
				if ($row['cnt'])
				{
						$this->fields_err_tip_arr['forum_topic'] = $err_tip;
						return false;
				}
				return true;
		}
		public function createForumTopic()
		{
				if ($this->fields_arr['topic_id'])
				{
						$this->updateForumTopic($this->fields_arr['topic_id']);
						$this->updateForumResponse($this->fields_arr['topic_id']);
				}
				else
				{
						$topic_id = $this->insertForumTopic();
						if ($topic_id)
						{
								$this->insertForumResponse($topic_id);
								$this->updateUsers();
						}
				}
				$this->updateForumsTable();
		}
		public function updateForumsTable()
		{
				$sql = 'SELECT COUNT(topic_id) AS total_topic FROM ' . $this->CFG['db']['tbl']['forum_topics'] . ' WHERE forum_id = ' . $this->dbObj->Param($this->fields_arr['forum_id']) . ' AND topic_status = \'Yes\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['forum_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = $rs->FetchRow();
				$total_topic = $row['total_topic'];
				$sql = 'SELECT COUNT(response_id) AS total_response FROM ' . $this->CFG['db']['tbl']['forum_response'] . ' AS fr' . ', ' . $this->CFG['db']['tbl']['forum_topics'] . ' AS ft' . ' WHERE fr.topic_id = ft.topic_id AND forum_id = ' . $this->dbObj->Param($this->fields_arr['forum_id']) . ' AND topic_status = \'Yes\' AND fr.response_status = \'Yes\' ';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['forum_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = $rs->FetchRow();
				$total_response = $row['total_response'];
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['forums'] . ' SET total_topics = ' . $this->dbObj->Param($total_topic) . ', total_response = ' . $this->dbObj->Param($total_response) . ' WHERE forum_id = ' . $this->dbObj->Param($this->fields_arr['forum_id']);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($total_topic, $total_response, $this->fields_arr['forum_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return true;
		}
		public function updateUsers()
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['users_ans_log'] . ' SET total_posts = total_posts + 1';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return true;
		}
		public function updateForums($forum_id)
		{
				$user_id = $this->CFG['user']['user_id'];
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['forums'] . ' SET last_post_user_id = ' . $this->dbObj->Param($user_id) . ', last_post_date = now()' . ', total_topics = total_topics + 1' . ', total_response = total_response + 1' . ' WHERE forum_id = ' . $this->dbObj->Param($forum_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($user_id, $forum_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return true;
		}
		public function insertForumResponse($topic_id)
		{
				$sql = 'INSERT INTO ' . $this->CFG['db']['tbl']['forum_response'] . ' SET topic_id = ' . $this->dbObj->Param($topic_id) . ', forum_response = ' . $this->dbObj->Param($this->fields_arr['forum_response']) . ', response_user_id = ' . $this->dbObj->Param($this->CFG['user']['user_id']) . ', date_added = NOW()';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($topic_id, html_entity_decode($this->fields_arr['forum_response'], ENT_QUOTES, $this->CFG['site']['charset']), $this->CFG['user']['user_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return true;
		}
		public function updateForumResponse($topic_id)
		{
				if ($this->fields_arr['response_id'])
				{
						$sql = 'UPDATE ' . $this->CFG['db']['tbl']['forum_response'] . ' SET forum_response = ' . $this->dbObj->Param($this->fields_arr['forum_response']) . ' WHERE topic_id = ' . $this->dbObj->Param($topic_id) . ' AND response_id = ' . $this->dbObj->Param($this->fields_arr['response_id']);
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array(html_entity_decode($this->fields_arr['forum_response'], ENT_QUOTES, $this->CFG['site']['charset']), $topic_id, $this->fields_arr['response_id']));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				}
				else
				{
						$this->insertForumResponse($topic_id);
						$user_id = $this->CFG['user']['user_id'];
						$sql = 'UPDATE ' . $this->CFG['db']['tbl']['forums'] . ' SET last_post_user_id = ' . $this->dbObj->Param($user_id) . ', last_post_date = NOW()' . ', total_response = total_response + 1' . ' WHERE forum_id = ' . $this->dbObj->Param($this->fields_arr['forum_id']);
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($user_id, $this->fields_arr['forum_id']));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
						$sql = 'UPDATE ' . $this->CFG['db']['tbl']['forum_topics'] . ' SET total_response = 1' . ' WHERE topic_id = ' . $this->dbObj->Param($topic_id);
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($topic_id));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				}
				return true;
		}
		public function insertForumTopic()
		{
				$sql = 'INSERT INTO ' . $this->CFG['db']['tbl']['forum_topics'] . ' SET forum_id = ' . $this->dbObj->Param($this->fields_arr['forum_id']) . ', forum_topic = ' . $this->dbObj->Param($this->fields_arr['forum_topic']) . ', user_id = ' . $this->dbObj->Param($this->CFG['user']['user_id']) . ', topic_status = ' . $this->dbObj->Param($this->fields_arr['topic_status']) . ', total_response = 1, total_views = 1' . ', last_post_user_id = ' . $this->dbObj->Param($this->CFG['user']['user_id']) . ', last_post_date = NOW()' . ', date_added = NOW()';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['forum_id'], $this->fields_arr['forum_topic'], $this->CFG['user']['user_id'], $this->fields_arr['topic_status'], $this->CFG['user']['user_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return $this->dbObj->Insert_ID();
		}
		public function updateForumTopic($topic_id)
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['forum_topics'] . ' SET forum_topic = ' . $this->dbObj->Param($this->fields_arr['forum_topic']) . ', topic_status = ' . $this->dbObj->Param($this->fields_arr['topic_status']) . ' WHERE topic_id = ' . $this->dbObj->Param($topic_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['forum_topic'], $this->fields_arr['topic_status'], $topic_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return true;
		}
		public function setError($field_name, $err_tip = '')
		{
				$this->fields_err_tip_arr[$field_name] = $err_tip;
		}
}
$forumstopic = new ForumTopicFormHandler();
$forumstopic->setPageBlockNames(array('msg_form_error', 'msg_form_success', 'form_create_topic'));
$forumstopic->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$forumstopic->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$forumstopic->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$forumstopic->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$forumstopic->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$forumstopic->setDBObject($db);
$forumstopic->setCfgLangGlobal($CFG, $LANG);
$forumstopic->setFormField('forum_id', '');
$forumstopic->setFormField('topic_id', '');
$forumstopic->setFormField('response_id', '');
$forumstopic->setFormField('forum_topic', '');
$forumstopic->setFormField('forum_response', '');
$forumstopic->setFormField('topic_status', 'Yes');
$forumstopic->setAllPageBlocksHide();
if ($forumstopic->isFormGETed($_GET, 'forum_id'))
{
		$forumstopic->sanitizeFormInputs($_GET);
		$forumstopic->chkIsNotEmpty('forum_id', $LANG['forumstopic_err_tip_compulsory']) and $forumstopic->chkIsNumeric('forum_id', $LANG['forumstopic_err_tip_compulsory']) and $forumstopic->isValidForumId($forumstopic->getFormField('forum_id'), $LANG['forumstopic_err_tip_invalid_forum_id']);
		$forumstopic->getFormField('topic_id') and $forumstopic->chkIsNotEmpty('topic_id', $LANG['forumstopic_err_tip_compulsory']) and $forumstopic->chkIsNumeric('topic_id', $LANG['forumstopic_err_tip_compulsory']) and $forumstopic->isValidForumTopicId($forumstopic->getFormField('forum_id'), $forumstopic->getFormField('topic_id'), $LANG['forumstopic_err_tip_invalid_forum_topic_id']);
		if ($forumstopic->isValidFormInputs())
		{
				if ($forumstopic->getFormField('topic_id'))
				{
						$forumstopic->setFormField('forum_topic', $forumstopic->forum_topic_details_arr['forum_topic']);
						$forumstopic->setFormField('forum_response', $forumstopic->forum_topic_details_arr['forum_response']);
						$forumstopic->setFormField('response_id', $forumstopic->forum_topic_details_arr['response_id']);
						$forumstopic->setFormField('topic_status', $forumstopic->forum_topic_details_arr['topic_status']);
				}
				$forumstopic->setPageBlockShow('form_create_topic');
		}
		else
		{
				$forumstopic->setPageBlockShow('msg_form_error');
		}
} elseif ($forumstopic->isFormPOSTed($_POST, 'forumstopic_submit'))
{
		$forumstopic->sanitizeFormInputs($_POST);
		$forumstopic->chkIsNotEmpty('forum_id', $LANG['forumstopic_err_tip_compulsory']) and $forumstopic->chkIsNumeric('forum_id', $LANG['forumstopic_err_tip_compulsory']) and $forumstopic->isValidForumId($forumstopic->getFormField('forum_id'), $LANG['forumstopic_err_tip_invalid_forum_id']);
		$forumstopic->chkIsNotEmpty('forum_topic', $LANG['forumstopic_err_tip_compulsory']) and $forumstopic->chkIsNotExists($forumstopic->getFormField('forum_topic'), $forumstopic->getFormField('forum_id'), $CFG['db']['tbl']['forum_topics'], $LANG['forumstopic_err_tip_topic_exists']);
		$forumstopic->chkIsNotEmpty('forum_response', $LANG['forumstopic_err_tip_compulsory']);
		$forumstopic->chkIsNotEmpty('topic_status', $LANG['forumstopic_err_tip_compulsory']);
		$forumstopic->isValidFormInputs() and $forumstopic->createForumTopic();
		if ($forumstopic->isValidFormInputs())
		{
				$forumstopic->setAllPageBlocksHide();
				$forumstopic->setPageBlockShow('form_create_topic');
				Redirect2URL('forumsTopics.php?forum_id=' . $forumstopic->getFormField('forum_id'));
		}
		else
		{
				$forumstopic->setAllPageBlocksHide();
				$forumstopic->setPageBlockShow('msg_form_error');
				$forumstopic->setPageBlockShow('form_create_topic');
		}
} elseif ($forumstopic->isFormPOSTed($_POST, 'forumstopic_cancel'))
{
		$forumstopic->sanitizeFormInputs($_POST);
		Redirect2URL('forumsTopics.php?forum_id=' . $forumstopic->getFormField('forum_id'));
}
else
{
		$forumstopic->setAllPageBlocksHide();
		$forumstopic->setPageBlockShow('msg_form_error');
}




?>
<script type="text/javascript" language="javascript">
	var palette_url = '<?php echo $CFG['site']['url'] . 'admin/palette.htm'; ?>';
	var block_arr= new Array('selMsgConfirm');
</script>
<div id="selForumTopicCreate">
	<h2 class="clsForumTopicCreateTitle"><span>
		<a href="forums.php"><?php echo $LANG['forumlistall_title_index']; ?></a>
		&nbsp;-&nbsp;
		<a href="forumsTopics.php?forum_id=<?php echo $forumstopic->getFormField('forum_id'); ?>">
			<?php echo $forumstopic->forum_details_arr['forum_title']; ?></a>
		&nbsp;-&nbsp;
		<?php echo $LANG['forumstopic_topic_start']; ?>
	</span></h2>
    <div id="selLeftNavigation">
<?php
if ($forumstopic->isShowPageBlock('msg_form_error'))
{
?>
<div id="selMsgError">
	 <p><?php echo $LANG['msg_error_sorry'] . ' ' . $forumstopic->getCommonErrorMsg(); ?></p>
</div>
<?php
}
if ($forumstopic->isShowPageBlock('msg_form_success'))
{
?>
<div id="selMsgSuccess">
 	<p><?php echo $LANG['forumstopic_success']; ?></p>
</div>
<?php
}
if ($forumstopic->isShowPageBlock('form_create_topic'))
{
?>
<div id="selShowCreateForum">
	<form name="selFormCreateForum" id="selFormCreateForum" method="post" action="<?php echo URL($_SERVER['PHP_SELF']); ?>" autocomplete="off" onsubmit="return getHTMLSource('rte1', 'selFormCreateForum', 'forum_response');">
		<table summary="<?php echo $LANG['forumstopic_tbl_summary']; ?>" class="clsRichTextTable">
		   	<tr>
				<td class="<?php echo $forumstopic->getCSSFormLabelCellClass('forum_topic'); ?>"><?php ShowHelpTip('forum_topic_subject'); ?><label for="forum_topic"><?php echo $LANG['forumstopic_subject']; ?></label></td>
				<td class="<?php echo $forumstopic->getCSSFormFieldCellClass('forum_topic'); ?>"><?php echo $forumstopic->getFormFieldErrorTip('forum_topic'); ?>
					<input type="text" class="clsTextBox" name="forum_topic" id="forum_topic" maxlength="200" tabindex="<?php echo $forumstopic->getTabIndex(); ?>" value="<?php echo $forumstopic->getFormField('forum_topic'); ?>" />
				</td>
		   	</tr>
		    <?php if (strchr(strtolower($_SERVER['HTTP_USER_AGENT']), "opera") == '')
		{ ?>
			<tr>
				<td class="<?php echo $forumstopic->getCSSFormLabelCellClass('forum_response'); ?>"><?php ShowHelpTip('forum_topic_response'); ?><label for="response"><?php echo $LANG['forumstopic_response']; ?></label></td>
				<td class="<?php echo $forumstopic->getCSSFormFieldCellClass('forum_response'); ?>"><?php echo $forumstopic->getFormFieldErrorTip('forum_response'); ?>
					<?php populateRichTextEdit('forum_response', $forumstopic->getFormField('forum_response'), $forumstopic->isValidFormInputs()); ?>
				</td>
		    </tr>
			<?php }
		else
		{ ?>
			<tr>
				<td class="<?php echo $forumstopic->getCSSFormFieldCellClass('forum_response'); ?>">
					<p><label for="response"><?php echo $LANG['forumstopic_response']; ?></label><?php ShowHelpTip('forum_topic_response'); ?></p></td>
				<td>	<p>
						<?php echo $forumstopic->getFormFieldErrorTip('forum_response'); ?>
						<textarea class="clsCommonTextArea" name="forum_response" id="forum_response" cols="100" rows="7"><?php echo $forumstopic->getFormField('forum_response'); ?></textarea>
					</p>
				</td>
		    </tr>
			<?php } ?>
			<tr>
				<td colspan="2" class="<?php echo $forumstopic->getCSSFormFieldCellClass('topic_status'); ?>">
					<input type="radio" class="clsCheckRadio" name="topic_status" id="status_yes" value="Yes" <?php if ($forumstopic->getFormField('topic_status') == 'Yes') echo 'CHECKED'; ?> tabindex="<?php echo $forumstopic->getTabIndex(); ?>"  />
					<label for="status_yes"><?php echo $LANG['forumstopic_active']; ?></label>
					<input type="radio" class="clsCheckRadio" name="topic_status" id="status_no" value="No" <?php if ($forumstopic->getFormField('topic_status') == 'No') echo 'CHECKED'; ?> tabindex="<?php echo $forumstopic->getTabIndex(); ?>"  />
					<label for="status_no"><?php echo $LANG['forumstopic_inactive']; ?></label>
				</td>
			</tr>
			<tr>
				<td class="<?php echo $forumstopic->getCSSFormFieldCellClass('submit'); ?>" colspan="2">
					<input type="submit" class="clsSubmitButton" name="forumstopic_submit" id="forumstopic_submit" tabindex="<?php echo $forumstopic->getTabIndex(); ?>" value="<?php echo $LANG['forumstopic_submit']; ?>" />
					&nbsp;&nbsp;
					<input type="submit" class="clsCancelButton" name="forumstopic_cancel" id="forumstopic_cancel" tabindex="<?php echo $forumstopic->getTabIndex(); ?>" value="<?php echo $LANG['forumstopic_cancel']; ?>" />
				</td>
			</tr>
		</table>
		<input type="hidden" name="forum_id" id="forum_id" value="<?php echo $forumstopic->getFormField('forum_id'); ?>" />
		<input type="hidden" name="topic_id" id="topic_id" value="<?php echo $forumstopic->getFormField('topic_id'); ?>" />
		<input type="hidden" name="response_id" id="response_id" value="<?php echo $forumstopic->getFormField('response_id'); ?>" />
	</form>
</div>
<?php
}
?>
	</div>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>
