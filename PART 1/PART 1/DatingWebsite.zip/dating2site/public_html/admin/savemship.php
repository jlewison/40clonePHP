<?php
if ( !defined( 'SMARTY_DIR' ) )

	include_once( '../init.php' );

include ( 'sessioninc.php' );

define( 'PAGE_ID', 'mship_mgt' );

if ( !checkAdminPermission( PAGE_ID ) ) {

	header( 'location: not_authorize.php' );
	exit;
}

$vchat 					= $_POST['chat'] == 'on' ? 1 : 0;

$vforum 				= $_POST['forum'] == 'on' ? 1 : 0;

$vblog 				= $_POST['blog'] == 'on' ? 1 : 0;

$vpoll 				= $_POST['poll'] == 'on' ? 1 : 0;

$vincludeinsearch 		= $_POST['includeinsearch'] == 'on' ? 1 : 0;

$vmessage 				= $_POST['message'] == 'on' ? 1 : 0;

$allow_videos 				= $_POST['allow_videos'] == 'on' ? 1 : 0;

$vuploadpicture 		= $_POST['uploadpicture'] == 'on' ? 1 : 0;

$vallowalbum 		= $_POST['allowalbum'] == 'on' ? 1 : 0;

$vallowim = $_POST['allowim'] == 'on' ? 1 : 0;

$vuploadpicturecnt = $_POST['uploadpicturecnt'];

if ($vuploadpicturecnt == '') $vuploadpicturecnt=0;

$vmessage_keep_cnt = $_POST['message_keep_cnt'];

$vmessage_keep_days = $_POST['message_keep_days'];

if ($vmessage_keep_cnt == '') $vmessage_keep_cnt = 0;

if ($vmessage_keep_days == '') $vmessage_keep_days = 0;

$messages_per_day = $_POST['messages_per_day'];

if ($messages_per_day == '') $messages_per_day = 0;

$winks_per_day = $_POST['winks_per_day'];

if ($winks_per_day == '') $winks_per_day = 0;

$videoscnt = $_POST['videoscnt'];

if ($videoscnt == '') $videoscnt = 0;

$vseepictureprofile 	= $_POST['seepictureprofile'] == 'on' ? 1 : 0;

$vfavouritelist 	= $_POST['favouritelist'] == 'on' ? 1 : 0;

$vsendwinks 	= $_POST['sendwinks'] == 'on' ? 1 : 0;

$vextsearch 	= $_POST['extsearch'] == 'on' ? 1 : 0;

$vevent_mgt 	= $_POST['event_mgt'] == 'on' ? 1 : 0;

$vactivedays = $_POST['activedays'];

$vfullsignup 			= $_POST['fullsignup'] == 'on' ? 1 : 0;

$vprice					= trim( $_POST['txtprice'] );

$vcurrency				= trim( $_POST['txtcurrency'] );

$vname					= trim( $_POST['txtname'] );

$saveprofiles 		= $_POST['saveprofiles'] == 'on' ? 1: 0;

$saveprofilescnt = isset($_POST['saveprofilescnt'])?$_POST['saveprofilescnt']:0;

if ($saveprofilescnt == '') $saveprofilescnt = 0;

$allow_mysettings = $_POST['allow_mysettings'] == 'on' ? 1: 0;

if( $vname == '' ) {

	$err = NO_NAME;

} elseif( $vprice == '' ) {

	$err = NO_PRICE;

} elseif( $vcurrency == '' ) {

	$err = NO_CURRENCY;

}

if ( $err != 0 ) {

	header( 'location: addmship.php?errid=' . $err );
	exit;

}


$sql = 'INSERT INTO ! ' .
" ( name, chat, forum, blog, includeinsearch, message, message_keep_cnt, message_keep_days, allowim, favouritelist, sendwinks, extsearch, event_mgt,  uploadpicture, seepictureprofile, uploadpicturecnt, allowalbum, fullsignup, price,currency, activedays , messages_per_day, winks_per_day, allow_videos, videoscnt,poll, saveprofiles,saveprofilescnt, allow_mysettings)
 VALUES (  '$vname', '$vchat', '$vforum', '$vblog', '$vincludeinsearch', '$vmessage', '$vmessage_keep_cnt', '$vmessage_keep_days', '$vallowim', '$vfavouritelist', '$vsendwinks', '$vextsearch', '$vevent_mgt',  '$vuploadpicture', '$vseepictureprofile', '$vuploadpicturecnt', '$vallowalbum', '$vfullsignup', '$vprice', '$vcurrency', '$vactivedays', '$messages_per_day', '$winks_per_day', '$allow_videos','$videoscnt' ,'$vpoll','$saveprofiles','$saveprofilescnt','$allow_mysettings')";

$db->query( $sql, array( MEMBERSHIP_TABLE ) );

$id = $db->getOne('select id from ! where name = ?', array( MEMBERSHIP_TABLE, $vname) );

$sql = 'UPDATE ! SET roleid = ? WHERE id = ?';

$db->query( $sql, array( MEMBERSHIP_TABLE, $id, $id ) );

header( 'location: membership.php' );
?>