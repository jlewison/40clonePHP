<?php

	$lang['page_title']	= 'About';
?>