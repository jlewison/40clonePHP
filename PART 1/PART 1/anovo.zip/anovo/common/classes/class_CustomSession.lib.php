<?php





class CustomSession
{
		private $db;
		private $table_name;
		private $sess_gc_maxlifetime;
		private $num_online_visitors;
		private $num_online_guests;
		private $num_online_members;
		public function CustomSession($db_link, $session_table_name = 'sessions')
		{
				$this->db = $db_link;
				$this->table_name = $session_table_name;
				$this->_setINI();
				$this->sess_gc_maxlifetime = ini_get('session.gc_maxlifetime');
				session_set_save_handler(array(&$this, '_sess_open'), array(&$this, '_sess_close'), array(&$this, '_sess_read'), array(&$this, '_sess_write'), array(&$this, '_sess_destroy'), array(&$this, '_sess_gc'));
				session_start();
				$this->_updateOnlineUsersCount();
		}
		private function _setINI()
		{
				ini_set('session.save_handler', 'user');
		}
		private function _sess_open($dummy_save_path, $dummy_session_name)
		{
				return (true);
		}
		private function _sess_close()
		{
				return (true);
		}
		private function _sess_read($session_id)
		{
				$sql = 'SELECT data FROM ' . $this->table_name . ' WHERE ' . 'session_id=\'' . $session_id . '\' AND expires>=UNIX_TIMESTAMP()';
				$result = mysql_query($sql, $this->db);
				if (mysql_num_rows($result) > 0)
				{
						$row = mysql_fetch_assoc($result);
						$ret_val = $row['data'];
				}
				else
				{
						$sql = 'DELETE FROM ' . $this->table_name . ' WHERE expires<UNIX_TIMESTAMP()';
						$result = mysql_query($sql, $this->db);
						$ret_val = '';
				}
				return ($ret_val);
		}
		private function _sess_write($session_id, $data)
		{
				$data = addslashes($data);
				$sql = 'REPLACE INTO ' . $this->table_name . ' SET ' . 'session_id=\'' . $session_id . '\', ' . 'expires=UNIX_TIMESTAMP()+' . $this->sess_gc_maxlifetime . ', ' . 'data=\'' . $data . '\'';
				return (mysql_query($sql, $this->db));
		}
		private function _sess_destroy($session_id)
		{
				$sql = 'DELETE FROM ' . $this->table_name . ' WHERE session_id=\'' . $session_id . '\'';
				return (mysql_query($sql, $this->db));
		}
		private function _sess_gc($dummy_gc_maxlifetime)
		{
				$sql = 'DELETE FROM ' . $this->table_name . ' WHERE expires<UNIX_TIMESTAMP()';
				return (mysql_query($sql, $this->db));
		}
		private function _updateOnlineUsersCount()
		{
				$sql = 'SELECT COUNT(*) FROM ' . $this->table_name;
				$result = mysql_query($sql, $this->db);
				$this->num_online_visitors = mysql_result($result, 0);
				$sql = 'SELECT COUNT(*) FROM ' . $this->table_name . ' WHERE INSTR(data, \'sn_logged\')';
				$result = mysql_query($sql, $this->db);
				$this->num_online_members = mysql_result($result, 0);
				$this->num_online_guests = $this->num_online_visitors - $this->num_online_members;
		}
		public function getNumOnlineVisitors()
		{
				return ($this->num_online_visitors);
		}
		public function getNumOnlineMembers()
		{
				return ($this->num_online_members);
		}
		public function getNumOnlineGuests()
		{
				return ($this->num_online_guests);
		}
		public function isSessionActive($session_id)
		{
				$sql = 'SELECT COUNT(*) FROM ' . $this->table_name . ' WHERE session_id=\'' . $session_id . '\'';
				$result = mysql_query($sql, $this->db);
				$num_sessions = mysql_result($result, 0);
				return ($num_sessions != 0);
		}
}
?>