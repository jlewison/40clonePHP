<?php mysql_select_db($database_apound, $apound); $query_AUPC = "SELECT * FROM about"; $AUPC = mysql_query($query_AUPC, $apound) or die(mysql_error()); $row_AUPC = mysql_fetch_assoc($AUPC); $totalRows_AUPC = mysql_num_rows($AUPC); ?>

<?php include('template/Green_Light/b_inside_top.php');?>

<td valign="top">

<div class="page-header"><h1><?php echo("$lang_80");?></h1></div>
<div class="box" style="margin-left:10px">
	<div class="box-cap-left">
		<div class="box-cap-right">
			<div class="box-cap"></div>
		</div>
	</div>
	<div class="box-left">
		<div class="box-right">
<?php echo $row_AUPC['abcontent']; ?>
		</div>
	</div>
	<div class="box-bottom-left">
		<div class="box-bottom-right">
		</div>
	</div>
</div>		

<?php include('template/Green_Light/b_footer_tpl.php'); ?>