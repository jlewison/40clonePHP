<?php
require_once ('common/config.inc.php');
require_once ('common/configs/config_encoder.inc.php');
require_once ('common/configs/config_ans_video.inc.php');
require_once ('common/configs/config_ans_video_player.inc.php');
$CFG['lang']['include_files'][] = 'admin/includes/languages/%s/ansVideoConfiguration.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['mods']['is_include_only']['non_html_header_files'] = true;
$CFG['auth']['is_authenticate'] = false;
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class XmlCode extends FormHandler
{
		public function setHeaderStart()
		{
				ob_start();
				header("Pragma: no-cache");
				header("Cache-Control: no-cache, must-revalidate");
				header("Expires: 0");
				header("Content-type: text/xml; charset=iso-8859-1");
		}
		public function populateVideoDetails($status)
		{
				$cond = $status ? 'video_status=\'Ok\' AND video_encoded_status=\'Yes\'' : 'video_status!=\'Ok\'';
				$sql = 'SELECT video_server_url FROM ' . $this->CFG['db']['tbl']['ans_video'] . ' WHERE ' . $cond . ' AND video_id=' . $this->dbObj->Param('video_id') . ' LIMIT 0,1';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['vid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($row = $rs->FetchRow())
				{
						$this->fields_arr['video_server_url'] = $row['video_server_url'];
						return true;
				}
				return false;
		}
		public function changeConfigBooleanValues()
		{
				$array = array('AutoPlay', 'Header', 'TooltipEnabled', 'ShowShareButton', 'ShowMiniLogo', 'Logo', 'TopUrl', 'TailUrl', 'ShowMiniShareButton', 'ShowReplyButton', 'FullScreenControls');
				foreach ($array as $key => $value)
				{
						if ($this->CFG['admin']['ans_videos'][$value]) $this->CFG['admin']['ans_videos'][$value] = 'true';
						else  $this->CFG['admin']['ans_videos'][$value] = 'false';
				}
				$this->CFG['admin']['ans_videos']['SelectedSkin'] = $this->CFG['admin']['ans_videos']['SelectedSkin'] . '.swf';
		}
		public function selectVideoPlayerSettings()
		{
				$sql = 'SELECT play_settings, title, skin, play_list_settings,repeat_link,' . ' show_play_list_by, skin FROM ' . $this->CFG['db']['tbl']['ans_video_player_settings'];
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($row = $rs->FetchRow())
				{
						$this->CFG['admin']['ans_videos']['AutoPlay'] = $row['play_settings'];
						$this->CFG['admin']['ans_videos']['Header'] = $row['title'];
						$this->CFG['admin']['ans_videos']['SelectedThemes'] = $row['skin'] . '.xml';
						$this->CFG['admin']['ans_videos']['play_list_settings'] = $row['play_list_settings'];
						$this->CFG['admin']['ans_videos']['show_play_list_by'] = $row['show_play_list_by'];
						$this->CFG['admin']['ans_videos']['ShowReplyButton'] = $row['repeat_link'];
				}
		}
		public function selectVideoAddSettings()
		{
				$jpg = 'img';
				$flv = 'flv';
				$swf = 'img';
				$add_fields = 'advertisement_id, advertisement_url, advertisement_duration, advertisement_channel, advertisement_image,' . ' advertisement_ext, advertisement_show_at';
				$default_cond = ' advertisement_image!=\'\' AND advertisement_ext!=\'\'' . ' AND advertisement_status=\'Activate\' AND ';
				$sql = 'SELECT ' . $add_fields . ' FROM ' . $this->CFG['db']['tbl']['ans_video_advertisement'] . ' WHERE' . $default_cond . '(advertisement_show_at=\'Begining\' OR advertisement_show_at=\'Both\')';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$total_records = $rs->PO_RecordCount();
				if ($total_records)
				{
						$selected = rand(1, $total_records);
						$i = 1;
						while ($row = $rs->FetchRow())
						{
								if ($i != $selected)
								{
										$i++;
										continue;
								}
								$this->CFG['admin']['ans_videos']['TopUrlUrl'] = $this->CFG['site']['url'] . $this->CFG['admin']['ans_videos']['advertisement_folder'] . $row['advertisement_image'] . '.' . $row['advertisement_ext'];
								$this->CFG['admin']['ans_videos']['TopUrlTargetUrl'] = $row['advertisement_url'];
								$this->CFG['admin']['ans_videos']['TopUrl'] = true;
								$this->CFG['admin']['ans_videos']['TopUrlType'] = isset($$row['advertisement_ext']) ? $$row['advertisement_ext'] : $row['advertisement_ext'];
								$this->CFG['admin']['ans_videos']['TopUrlDuration'] = $row['advertisement_duration'];
								break;
						}
				}
				$sql = 'SELECT ' . $add_fields . ' FROM ' . $this->CFG['db']['tbl']['ans_video_advertisement'] . ' WHERE' . $default_cond . '(advertisement_show_at=\'Ending\' OR advertisement_show_at=\'Both\')';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$total_records = $rs->PO_RecordCount();
				if ($total_records)
				{
						$selected = rand(1, $total_records);
						$i = 1;
						while ($row = $rs->FetchRow())
						{
								if ($i != $selected)
								{
										$i++;
										continue;
								}
								$this->CFG['admin']['ans_videos']['TailUrlUrl'] = $this->CFG['site']['url'] . $this->CFG['admin']['ans_videos']['advertisement_folder'] . $row['advertisement_image'] . '.' . $row['advertisement_ext'];
								$this->CFG['admin']['ans_videos']['TailUrlTargetUrl'] = $row['advertisement_url'];
								$this->CFG['admin']['ans_videos']['TailUrl'] = true;
								$this->CFG['admin']['ans_videos']['TailUrlType'] = $$row['advertisement_ext'];
								$this->CFG['admin']['ans_videos']['TailUrlDuration'] = $row['advertisement_duration'];
								break;
						}
				}
		}
		public function selectLogoSettings()
		{
				$this->CFG['admin']['ans_videos']['LogoTransparency'] = 10;
				$this->CFG['admin']['ans_videos']['LogoRollOverTransparency'] = 10;
				$this->CFG['admin']['ans_videos']['LogoPosition'] = 'LB';
				$this->CFG['admin']['ans_videos']['MiniLogoUrl'] = '';
				$this->CFG['admin']['ans_videos']['InnerScripts'] = 'no';
				$sql = 'SELECT logo_url, logo_position, logo_transparency, logo_rollover_transparency,' . ' logo_image, logo_ext, mini_logo_image, mini_logo_ext, mini_logo, animated_logo' . ' FROM ' . $this->CFG['db']['tbl']['ans_video_logo'];
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$logo_position_arr = array('Left_bottom' => 'LB', 'Left_top' => 'LT', 'Right_bottom' => 'RB', 'Right_top' => 'RT');
				if ($row = $rs->FetchRow())
				{
						if ($row['logo_image'] and $row['logo_ext'])
						{
								$this->CFG['admin']['ans_videos']['Logo'] = true;
								$this->CFG['admin']['ans_videos']['LogoUrl'] = $this->CFG['site']['url'] . $this->CFG['admin']['ans_videos']['logo_folder'] . $row['logo_image'] . '.' . $row['logo_ext'];
								;
								$this->CFG['admin']['ans_videos']['LogoTargetUrl'] = $row['logo_url'];
								$this->CFG['admin']['ans_videos']['LogoTransparency'] = $row['logo_transparency'];
								$this->CFG['admin']['ans_videos']['LogoRollOverTransparency'] = $row['logo_rollover_transparency'];
								$this->CFG['admin']['ans_videos']['LogoPosition'] = $logo_position_arr[$row['logo_position']];
								$this->CFG['admin']['ans_videos']['InnerScripts'] = $row['animated_logo'];
						}
						if ($row['mini_logo_image'] and $row['mini_logo_ext'])
						{
								$this->CFG['admin']['ans_videos']['ShowMiniLogo'] = true;
								$this->CFG['admin']['ans_videos']['MiniLogoUrl'] = $this->CFG['site']['url'] . $this->CFG['admin']['ans_videos']['logo_folder'] . $row['mini_logo_image'] . '.' . $row['mini_logo_ext'];
								if ($row['mini_logo'])
								{
										$this->CFG['admin']['ans_videos']['FullScreenControls'] = false;
										$this->CFG['admin']['ans_videos']['ShowMiniShareButton'] = false;
								}
						}
				}
		}
		public function getXmlCode()
		{
				$fields = explode('_', $this->fields_arr['pg']);
				$this->fields_arr['pg'] = $fields[0];
				$this->fields_arr['vid'] = $fields[1];
				if (!($this->fields_arr['pg'] and $this->fields_arr['vid']))
				{
						return;
				}
				$sharing_url = '';
				$full_screen_url = '';
				$configPlayListXmlcode_url = '';
				$end_list = $next_list = 0;
				$this->selectVideoPlayerSettings();
				$thumbnail = '';
				switch ($this->fields_arr['pg'])
				{
						case 'video':
								if (!$this->populateVideoDetails(true)) return;
								$video_folder = $this->CFG['admin']['ans_videos']['video_folder'] . '/';
								$video_url = $this->fields_arr['video_server_url'] . $video_folder . getImageName($this->fields_arr['vid']) . '.flv?v=' . time();
								$thumbnail = $this->fields_arr['video_server_url'] . $this->CFG['admin']['ans_videos']['thumbnail_folder'] . '/' . getImageName($this->fields_arr['vid']) . 'T.' . $this->CFG['video']['image']['extensions'];
								$this->selectVideoAddSettings();
								$this->selectLogoSettings();
								break;
						case 'smallvideo':
								if (!$this->populateVideoDetails(true)) return;
								$video_folder = $this->CFG['admin']['ans_videos']['video_folder'] . '/';
								$video_url = $this->fields_arr['video_server_url'] . $video_folder . getImageName($this->fields_arr['vid']) . '.flv?v=' . time();
								$thumbnail = $this->fields_arr['video_server_url'] . $this->CFG['admin']['ans_videos']['thumbnail_folder'] . '/' . getImageName($this->fields_arr['vid']) . 'T.' . $this->CFG['video']['image']['extensions'];
								$this->CFG['admin']['ans_videos']['SelectedSkin'] = 'mini_skin';
								$this->CFG['admin']['ans_videos']['FullScreenControls'] = false;
								$this->CFG['admin']['ans_videos']['ShowMiniShareButton'] = false;
								$this->CFG['admin']['ans_videos']['AutoPlay'] = false;
								$this->selectVideoAddSettings();
								$this->selectLogoSettings();
								break;
						case 'previewvideo':
								$temp_dir = $this->CFG['site']['url'] . $this->CFG['admin']['ans_videos']['temp_folder'];
								$video_url = $temp_dir . $this->fields_arr['vid'] . '.flv?v=' . time();
								$thumbnail = $this->CFG['site']['url'] . 'images/preview_video.jpg';
								$this->selectVideoAddSettings();
								$this->selectLogoSettings();
								break;
				}
				$this->changeConfigBooleanValues();
?>
<CONFIG>
	<SETTINGS>
		<PLAYER_SETTINGS Name="SelectedSkin" Value="<?php echo $this->CFG['site']['url'] . $this->CFG['admin']['flv']['skin_path'] . $this->CFG['admin']['ans_videos']['SelectedSkin']; ?>"/>
		<PLAYER_SETTINGS Name="SelectedLoader" Value="<?php echo $this->CFG['site']['url'] . $this->CFG['admin']['flv']['skin_path'] . $this->CFG['admin']['ans_videos']['SelectedLoader']; ?>"/>
		<PLAYER_SETTINGS Name="Protocol" Type="http" Value="pathwillcome" />
		<PLAYER_SETTINGS Name="FLVPath" Value="<?php echo $video_url; ?>"/>
		<PLAYER_SETTINGS Name="PlayList" Value="<?php echo $configPlayListXmlcode_url; ?>" EndList="<?php echo $end_list; ?>" NextList="<?php echo $next_list; ?>" MaximumLists="3" />
		<PLAYER_SETTINGS Name="Themes" Value="<?php echo $this->CFG['site']['url'] . $this->CFG['admin']['flv']['skin_path'] . $this->CFG['admin']['ans_videos']['SelectedThemes']; ?>"/>

		<PLAYER_SETTINGS Name="LockAllControls" Value="<?php echo $this->CFG['admin']['ans_videos']['LockAllControls']; ?>"/>
		<PLAYER_SETTINGS Name="ShowShareButton" Value="false"/>
		<PLAYER_SETTINGS Name="ShowReplyButton" Value="<?php echo $this->CFG['admin']['ans_videos']['ShowReplyButton']; ?>"/>
		<PLAYER_SETTINGS Name="InitVolume" Value="<?php echo $this->CFG['admin']['ans_videos']['InitVolume']; ?>"/>
		<PLAYER_SETTINGS Name="AutoPlay" Value="<?php echo $this->CFG['admin']['ans_videos']['AutoPlay']; ?>"/>
		<PLAYER_SETTINGS Name="FirstFrameAs" Value="<?php echo $this->CFG['admin']['ans_videos']['FirstFrameAsValue']; ?>" FrameAt="<?php echo $this->CFG['admin']['ans_videos']['FirstFrameAsFrameAt']; ?>" Url="<?php echo $thumbnail; ?>" Align="stretch"/>
		<PLAYER_SETTINGS Name="FirstVidSize" Value="max" KeepAspectRatio="true"/>
		<PLAYER_SETTINGS Name="FullScreenControls" Value="<?php echo $this->CFG['admin']['ans_videos']['FullScreenControls']; ?>"/>
		<PLAYER_SETTINGS Name="ShowMiniShareButton" Value="<?php echo $this->CFG['admin']['ans_videos']['ShowMiniShareButton']; ?>"/>
		<PLAYER_SETTINGS Name="TooltipEnabled" Value="true"/>
		<PLAYER_SETTINGS Name="ShareVidzLink" Value="<?php echo $sharing_url; ?>" args="" />
		<!-- args will passed separately with & symbol to the given php file -->
		<PLAYER_SETTINGS Name="FullScreenLink" Function="" args="this"/>
		<PLAYER_SETTINGS Name="BufferTime" Value="4"/>
		<PLAYER_SETTINGS Name="Logo" Value="<?php echo $this->CFG['admin']['ans_videos']['Logo']; ?>" Url="<?php echo $this->CFG['admin']['ans_videos']['LogoUrl']; ?>" Transparency="<?php echo $this->CFG['admin']['ans_videos']['LogoTransparency']; ?>" RollOverTransparency="<?php echo $this->CFG['admin']['ans_videos']['LogoRollOverTransparency']; ?>" LogoPosition="<?php echo $this->CFG['admin']['ans_videos']['LogoPosition']; ?>" hspace="10" vspace="10" TargetUrl="<?php echo $this->CFG['admin']['ans_videos']['LogoTargetUrl']; ?>" Target="_blank" InnerScripts="<?php echo $this->CFG['admin']['ans_videos']['InnerScripts']; ?>"/>
		<PLAYER_SETTINGS Name="External" Value="no" Url="http://macromedia.com"  Target="_blank" />

		<PLAYER_SETTINGS Name="TopUrl" Url="<?php echo $this->CFG['admin']['ans_videos']['TopUrlUrl']; ?>" TargetUrl="<?php echo $this->CFG['admin']['ans_videos']['TopUrlTargetUrl']; ?>" TargetWindow="_blank" Duration="<?php echo $this->CFG['admin']['ans_videos']['TopUrlDuration']; ?>" Value="<?php echo $this->CFG['admin']['ans_videos']['TopUrl']; ?>" Type="<?php echo $this->CFG['admin']['ans_videos']['TopUrlType']; ?>" ImpressionUrl="" ClickCountUrl=""/>
		<PLAYER_SETTINGS Name="TailUrl" Url="<?php echo $this->CFG['admin']['ans_videos']['TailUrlUrl']; ?>" TargetUrl="<?php echo $this->CFG['admin']['ans_videos']['TailUrlTargetUrl']; ?>" TargetWindow="_blank" Duration="<?php echo $this->CFG['admin']['ans_videos']['TailUrlDuration']; ?>" Value="<?php echo $this->CFG['admin']['ans_videos']['TailUrl']; ?>" Type="<?php echo $this->CFG['admin']['ans_videos']['TailUrlType']; ?>" ImpressionUrl="" ClickCountUrl=""/>
	</SETTINGS>
	<LABELS>
		<TEXT Name="Header" Value="--" Enable="<?php echo $this->CFG['admin']['ans_videos']['Header']; ?>" ShowAlways="true" Url="" TargetWindow="" HeaderScroll="true" ScrollSpeed="1"/>
		<TEXT Name="Share" Value="<?php echo $this->LANG['ShareToolTip']; ?>"/>
		<TEXT Name="Reply" Value="<?php echo $this->LANG['ReplyToolTip']; ?>"/>
		<TEXT Name="Buffer" Value="<?php echo $this->LANG['BufferToolTip']; ?>"/>
		<TEXT Name="Loading" Value="<?php echo $this->LANG['LoadingToolTip']; ?>"/>
		<TEXT Name="NextText" Value="<?php echo $this->LANG['NextTextToolTip']; ?>" Enable="false"/>
		<TEXT Name="ListAlign" Value="RTL" Enable="false"/>
	</LABELS>
	<TOOLTIP>
		<TOOL Name="PlayButton" Value="<?php echo $this->LANG['PlayButtonToolTip']; ?>"/>
		<TOOL Name="PauseButton" Value="<?php echo $this->LANG['PauseButtonToolTip']; ?>"/>
		<TOOL Name="VolumeButton" Value="<?php echo $this->LANG['VolumeButtonToolTip']; ?>"/>
		<TOOL Name="ShareVidz" Value="<?php echo $this->LANG['ShareVidzToolTip']; ?>"/>
		<TOOL Name="ReplyVideo" Value ="<?php echo $this->LANG['ReplyVideoToolTip']; ?>"/>
		<TOOL Name="RewindButton" Value="<?php echo $this->LANG['RewindButtonToolTip']; ?>"/>
		<TOOL Name="MuteButton" Value ="<?php echo $this->LANG['MuteButtonToolTip']; ?>"/>
		<TOOL Name="FullScreen" Value="<?php echo $this->LANG['FullScreenToolTip']; ?>"/>
		<TOOL Name="UnMuteButton" Value="<?php echo $this->LANG['UnMuteButtonToolTip']; ?>"/>
		<TOOL Name="VideoSize" Value="<?php echo $this->LANG['VideoSizeToolTip']; ?>"/>
	</TOOLTIP>
	<MSG>
	 <ERROR Name="SelectedSkin" Value="<?php echo $this->LANG['SelectedSkinErrorMsg']; ?>"/>
	 <ERROR Name="PlayList" Value="<?php echo $this->LANG['PlayListErrorMsg']; ?>"/>
	 <ERROR Name="FlvPath" Value="<?php echo $this->LANG['FlvPathErrorMsg']; ?>"/>
	 <ERROR Name="FlvPathFile" Value="<?php echo $this->LANG['FlvPathFileErrorMsg']; ?>"/>
	</MSG>
</CONFIG>
<?php
		}
}
$XmlCode = new XmlCode();
$XmlCode->setHeaderStart();
$XmlCode->setDBObject($db);
$CFG['user']['user_id'] = isset($_SESSION['user']['user_id']) ? $_SESSION['user']['user_id'] : '0';
$CFG['admin']['is_logged_in'] = isset($_SESSION['admin']['is_logged_in']) ? $_SESSION['admin']['is_logged_in'] : '0';
$XmlCode->makeGlobalize($CFG, $LANG);
$XmlCode->setPageBlockNames(array('get_code_form'));
$XmlCode->setFormField('vid', '');
$XmlCode->setFormField('pg', '');
$XmlCode->setPageBlockShow('get_code_form');
$XmlCode->sanitizeFormInputs($_GET);
if ($XmlCode->isShowPageBlock('get_code_form'))
{
		$XmlCode->getXmlCode();
}
$XmlCode->setHeaderEnd();


?>