<?php

/**
 * minifeedmodel Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 1/28/2008
 */
class minifeedmodel extends Model
{
		//Constructor
		function minifeedmodel()
		{
				parent::Model();
		}
		function _readMiniFeedTemplate($templateKey, $languageCode = '')
		{
				if (trim($languageCode) == '') $languageCode = $this->config->item('language_code');
				$templateQuery = $this->db->query('SELECT * FROM mini_feed_templates WHERE mini_feed_key=' . $this->db->escape($templateKey) . ' AND template_language=' . $this->db->escape($languageCode) . ' LIMIT 0,1');
				$templateRow = array();
				if ($templateQuery->num_rows() > 0)
				{
						$templateRow = $templateQuery->result_array();
						return $templateRow[0];
				}
				else  return false;
		}
		function postMiniFeed($feedCode, $specialVars, $additionalLinks = '', $userId = '')
		{
				if (trim($userId) == '') $userId = $this->session->userdata('user_id');
				$templateArray = $this->_readMiniFeedTemplate($feedCode);
				$templateContent = strtr($templateArray['template_content'], $specialVars);
				$newMiniFeedLog = array('log_content' => $templateContent, 'user_id' => $userId);
				$this->db->set($newMiniFeedLog);
				$this->db->set('datestamp', 'NOW()', false);
				if (isset($additionalLinks[0]) && trim($additionalLinks[0]) != '') $this->db->set('link1', trim($additionalLinks[0]));
				if (isset($additionalLinks[1]) && trim($additionalLinks[1]) != '') $this->db->set('link2', trim($additionalLinks[1]));
				if (isset($additionalLinks[2]) && trim($additionalLinks[2]) != '') $this->db->set('link3', trim($additionalLinks[2]));
				if (isset($additionalLinks[3]) && trim($additionalLinks[3]) != '') $this->db->set('link4', trim($additionalLinks[3]));
				$this->db->insert('mini_feed_log');
		}
		function getMiniFeed($userId = '', $orderBy = 'datestamp desc', $start = '', $limit = '')
		{
				if (trim($userId) == '') $userId = $this->session->userdata('user_id');
				$this->db->select('mini_feed_log.*, users.avatar_ext');
				$this->db->from('mini_feed_log');
				$this->db->join('users', 'mini_feed_log.user_id=users.user_id', 'INNER');
				$this->db->where('mini_feed_log.user_id', $userId);
				if (trim($orderBy) != '') $this->db->order_by($orderBy);
				if (trim($limit) != '' && is_numeric($limit))
				{
						if (trim($start) != '' && is_numeric($start)) $this->db->limit($limit, $start);
						else  $this->db->limit($limit);
				}
				$minifeedQuery = $this->db->get();
				$minifeed = array();
				if ($minifeedQuery->num_rows() > 0)
				{
						foreach ($minifeedQuery->result_array() as $minifeedRow)
						{
								$minifeedRow['log_content'] = explode('~~link~~', $minifeedRow['log_content']);
								$minifeedRow['avatar'] = getAvatar($minifeedRow['user_id'], $minifeedRow['avatar_ext']);
								$minifeed[$minifeedRow['mini_feed_log_id']] = $minifeedRow;
						}
				}
				return $minifeed;
		}
		function getMiniFeedCount($userId = '')
		{
				if (trim($userId) == '') $userId = $this->session->userdata('user_id');
				$this->db->where('user_id', $userId);
				$this->db->from('mini_feed_log');
				return $this->db->count_all_results();
		}
		function deleteById($minifeedId)
		{
				$this->db->where('mini_feed_log_id', $minifeedId);
				$this->db->delete('mini_feed_log');
				return true;
		}
}

?>