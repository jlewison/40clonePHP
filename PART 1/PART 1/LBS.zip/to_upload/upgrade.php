<?php session_start(); include('ip_domain_ban.php'); include('settings.php'); if($onoff == 'N') { include('disabled.php'); exit; } else { } include('upgrade_info.php'); ?>

<?php 
$submit = $_POST[submit];
$number = $_POST['number'];
$mynumber = $_SESSION['image_value'];
if($submit == 'Continue >>' and md5($number) == "$mynumber") {
//include('update_info_v.php');
require_once('Connections/apound.php'); 
$avail = "N";
$paid = "N";
$upbid = $oldbid + $newbid;
$link = mysql_pconnect($hostname_apound,$username_apound,$password_apound);
mysql_select_db($database_apound);
mysql_query("UPDATE main SET ujbid='$upbid' WHERE dtu='$bidid'");
$kinek  = "$adminmail" . ", " ;
$kinek .= "$email";
$targy = "$bidmailsubject";
$uzenet = "Your Listing ID: $bidid\n
Your Listing Title: $keyword\n
Your Listing URL: $url\n
View details or upgrade your listing: http://$domainname$pathmail/upgrade.php?ucat=$bidid
--------------------------------------------------------------------------
$bidmailmessage
--------------------------------------------------------------------------
Contact and Support: http://$domainname$pathmail/contact.php";
$fejlec = "From: $sitetitle <$frommail>\r\n";
mail($kinek, $targy, $uzenet, $fejlec);
// send mail when upgrade
$url = urlencode($url);
echo("<meta http-equiv='refresh' content='0;URL=update.php?newbid=$newbid&oldbid=$oldbid&bidid=$bidid&url=$url&keyword=$keyword&email=$email'>");
exit;}
//header("Location: contact_sent.php"); 
elseif($submit == 'Continue >>' and md5($number) <> "$mynumber") {
echo '<div align="center" class="style19" id="wrong">Validation code is not correct! Please try again!</div>';
}
else {}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<?php echo("$lang_0");?>
<?php echo("$lang_01");?>
<title><?php echo $row_UPBID['title']; ?> - <?php echo("$upgrade_title");?> - <?php echo("$sitetitle");?></title>
<link rel="shortcut icon" href="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/img/favicon.ico" />
<link href="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/style.css" rel="stylesheet" type="text/css" />
<meta name="description" content="<?php echo("$upgrade_description");?>">
<meta name="keywords" content="<?php echo("$upgrade_keyword");?>">

<SCRIPT language=javascript> 
function chkfrm() { 
	var frm = document.form1;
	if (!frm.newbid.value.replace(/^\s*|\s*$/g,"")) { alert("You must provide a contribution amount."); frm.newbid.focus(); return false; }
	if (frm.newbid.value.replace(/^\s*|\s*$/g,"") < <?php echo("$minup");?>) { alert("Minimum contribution of <?php echo("$currency");?><?php echo("$minup");?> is required for the upgrade."); frm.newbid.focus(); return false; }
}
</SCRIPT>
</head>

<body>

<?php if($screenshot == 'Y') { ?> <SCRIPT language=javascript src="<?php echo("$path");?>screenshots.htm" type=text/javascript></SCRIPT> <?php } else { } ?>
<?php include("template/$lbdtemplate/a_main_upgrade.php"); ?>

</body>
</html>