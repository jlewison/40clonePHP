<?php
mysql_select_db($database_apound, $apound);
$query_LboxCAT = "SELECT * FROM categorylisting ORDER BY categorylisting.categoryname ASC";
$LboxCAT = mysql_query($query_LboxCAT, $apound) or die(mysql_error());
$row_LboxCAT = mysql_fetch_assoc($LboxCAT);
$totalRows_LboxCAT = mysql_num_rows($LboxCAT);
?>
<form name="pgfrm" onsubmit="return chkfrm();" action="<?php echo("$path");?>submit.php" method="post">
  <table border="0" align="center" cellpadding="3" cellspacing="1">
<?php
if($alphacat <> 'Y') { ?>

    <tr>
      <td><strong>Category:</strong></td>
      <td>&nbsp;</td>
      <td>
			<select name="selectc" id="selectc">
				<option value="" selected>Please select the category</option>
				<?php
			do {  
			?>
				<option value="<?php echo $row_LboxCAT['catlistid']?>"><?php echo $row_LboxCAT['categoryname']?></option>
				<?php
			} while ($row_LboxCAT = mysql_fetch_assoc($LboxCAT));
			  $rows = mysql_num_rows($LboxCAT);
			  if($rows > 0) {
				  mysql_data_seek($LboxCAT, 0);
				  $row_LboxCAT = mysql_fetch_assoc($LboxCAT);
			  }
			?>
		</select>	  </td>
    </tr>
<?php } 
else { }
?>

    <tr>
      <td><strong>E-mail Address:</strong></td>
      <td>&nbsp;</td>
      <td><input name="email" type="text" class="buyforminp1" maxLength=50 /></td>
    </tr>
    <tr>
      <td><strong>Website Title:</strong> (<?php echo("$maxtitle");?> chars max)</td>
      <td>&nbsp;</td>
      <td><input name="keyword" type="text" class="buyforminp1" onchange=dodiv(); onkeyup=dodiv(); maxLength=<?php echo("$maxtitle");?> /></td>
    </tr>
    <tr>
      <td><strong>Website URL:</strong></td>
      <td>&nbsp;</td>
      <td><input name="url" type="text" class="buyforminp1" onchange=dodiv(); onkeyup=dodiv(); value="http://" /></td>
    </tr>
    <tr>
      <td valign="top"><strong>Brief Description:</strong><br />(<?php echo("$maxdesc");?> chars max)<br /><span class="style33">Will be shown on list pages</span></td>
      <td>&nbsp;</td>
      <td><textarea name="descr1" class="buyforminp22" onchange=dodiv(); onkeyup=dodiv(); maxLength=<?php echo("$maxdesc");?>; onKeyDown="textCounter(document.pgfrm.descr1,document.pgfrm.dlength,<?php echo("$maxdesc");?>)" onKeyUp="textCounter(document.pgfrm.descr1,document.pgfrm.dlength,<?php echo("$maxdesc");?>)"></textarea><br /><input type="text" name="dlength" class="buyforminp4" size="3" maxlength="3" value="<?php echo("$maxdesc");?>" readonly /> characters left</td>
    </tr>
    <tr>
      <td valign="top"><strong>Extended Description:</strong><br />(<?php echo("$maxexdesc");?> chars max)<br /><span class="style33">Will be shown on Link Details page</span></td>
      <td>&nbsp;</td>
      <td><textarea name="descr2" class="buyforminp2" maxLength=<?php echo("$maxexdesc");?> onKeyDown="textCounter(document.pgfrm.descr2,document.pgfrm.length,<?php echo("$maxexdesc");?>)" onKeyUp="textCounter(document.pgfrm.descr2,document.pgfrm.length,<?php echo("$maxexdesc");?>)"></textarea><br /><input type="text" name="length" class="buyforminp4" size="3" maxlength="3" value="<?php echo("$maxexdesc");?>" readonly /> characters left</td>
    </tr>
    <tr>
      <td valign="top"><strong>Meta Description:</strong><br />(<?php echo("$maxmdesc");?> chars max)</td>
      <td>&nbsp;</td>
      <td><textarea name="mdesc" class="buyforminp22" maxLength=<?php echo("$maxmdesc");?> onKeyDown="textCounter(document.pgfrm.mdesc,document.pgfrm.mlength,<?php echo("$maxmdesc");?>)" onKeyUp="textCounter(document.pgfrm.mdesc,document.pgfrm.mlength,<?php echo("$maxmdesc");?>)"></textarea><br /><input type="text" name="mlength" class="buyforminp4" size="3" maxlength="3" value="<?php echo("$maxmdesc");?>" readonly /> characters left</td>
    </tr>
    <tr>
      <td><strong>Meta Keywords:</strong><br />(<?php echo("$maxkword");?> chars max)</td>
      <td>&nbsp;</td>
      <td><input name="mword" type="text" class="buyforminp1" maxLength=<?php echo("$maxkword");?> /></td>
    </tr>
<?php if($deepenable == 'Y') { ?>
    <tr>
      <td><strong>Deep Title 1:</strong> (<?php echo("$maxtitle");?> chars max)</td>
      <td>&nbsp;</td>
      <td><input name="deeptf" type="text" class="buyforminp1" maxLength=<?php echo("$maxtitle");?> /></td>
    </tr>
    <tr>
      <td><strong>Deep URL 1:</strong></td>
      <td>&nbsp;</td>
      <td><input name="dfurl" type="text" class="buyforminp1" value="http://" /></td>
    </tr>
    <tr>
      <td><strong>Deep Title 2:</strong> (<?php echo("$maxtitle");?> chars max)</td>
      <td>&nbsp;</td>
      <td><input name="deepts" type="text" class="buyforminp1" maxLength=<?php echo("$maxtitle");?> /></td>
    </tr>
    <tr>
      <td><strong>Deep URL 2:</strong></td>
      <td>&nbsp;</td>
      <td><input name="dsurl" type="text" class="buyforminp1" value="http://" /></td>
    </tr>
    <tr>
      <td><strong>Deep Title 3:</strong> (<?php echo("$maxtitle");?> chars max)</td>
      <td>&nbsp;</td>
      <td><input name="deeptt" type="text" class="buyforminp1" maxLength=<?php echo("$maxtitle");?> /></td>
    </tr>
    <tr>
      <td><strong>Deep URL 3:</strong></td>
      <td>&nbsp;</td>
      <td><input name="dturl" type="text" class="buyforminp1" value="http://" /></td>
    </tr>
<?php } else {} ?>
    <tr>
      <td><strong>Contribution:</strong></td>
      <td><?php echo("$currency");?></td>
      <td><input name="bid" class="buyforminp3" value="<?php echo("$minbid");?>" onchange=dodiv(); onkeypress="return chknum(event)" onkeyup=dodiv(); />.00</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td><div class="attn">Minimum <?php echo("$currency");?><?php echo("$minbid");?> review fee is required.</div></td>
    </tr>
    <tr>
      <td><strong>Validation code:</strong></td>
      <td>&nbsp;</td>
      <td><input name="number" type="text" id="\&quot;number\&quot;" />
        (Type  just with <strong><font color="#FF0000">CAPITAL</font></strong> letters) </td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td><img src="random_image.php" alt="" /></td>
    </tr>
  </table>
  
<div class="box" style="margin-right:10px;">
	<div class="box-cap-left">
		<div class="box-cap-right">
			<div class="box-cap"></div>
		</div>
	</div>
	<div class="box2-left">
		<div class="box2-right" style="min-height:70px;">
		<div class="rate" id="bidd"><?php echo("$currency");?><?php echo("$minbid");?></div>
			<div class="listing-descr">
				<div class="bid-title" id="kw">Example Title</div>
				<div class="bid-descr" id="d1">Brief description of your site that will be shown on the category listings, alphabetic list,  new listings, and top listings pages.</div>
				<div class="bid-url"><span style="color:#3a6e2f; font-style:italic;" id="d3">http://your_site.com/</span> :: Added <?php echo (date("Y-m-d"));?></div>
			</div>
		</div>
	</div>
	<div class="box-bottom-left">
		<div class="box-bottom-right">
		</div>
	</div>
</div>
	<div align="right" style="margin:10px;">
		<input type="hidden" value="1" name="categ">
		<input type="submit" name="submit" value="Next Step >>">
	</div>
</form>

<script type="text/javascript">
function textCounter(field,cntfield,maxlimit, len_name)
{
	if (field.value.length > maxlimit)
		field.value = field.value.substring(0, maxlimit);
	else
		cntfield.value = maxlimit - field.value.length;
}
</script>