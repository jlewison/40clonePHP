<?php include('restrict.php'); include('../settings.php'); require_once('../Connections/apound.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form1")) {
  $updateSQL = sprintf("UPDATE captcha SET chp_onoff=%s, chp_distors=%s, chp_leng=%s, chp_typ=%s, chp_simp=%s WHERE chp_id=%s",
                       GetSQLValueString($_POST['chp_onoff'], "text"),
                       GetSQLValueString($_POST['chp_distors'], "text"),
                       GetSQLValueString($_POST['chp_leng'], "text"),
                       GetSQLValueString($_POST['chp_typ'], "text"),
                       GetSQLValueString($_POST['chp_simp'], "text"),
                       GetSQLValueString($_POST['chp_id'], "int"));

  mysql_select_db($database_apound, $apound);
  $Result1 = mysql_query($updateSQL, $apound) or die(mysql_error());
  $done = "<div align='center'><font color='red'><b>Update ... DONE</b></font></div>";
}

mysql_select_db($database_apound, $apound);
$query_CVRS = "SELECT * FROM captcha";
$CVRS = mysql_query($query_CVRS, $apound) or die(mysql_error());
$row_CVRS = mysql_fetch_assoc($CVRS);
$totalRows_CVRS = mysql_num_rows($CVRS);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Link Bid Script - Admin Control Panel</title>
<link rel="shortcut icon" href="img/favicon.ico" />
<link rel="stylesheet" type="text/css" href="admin.css" />
<style type="text/css">
<!--
#admnav li {
	padding-top: 0px;
	padding-bottom: 0px;
	margin-top: 0px;
	margin-bottom: 0px;
}
#admnav ul {
	padding-top: 0px;
	padding-bottom: 0px;
	margin-top: 0px;
	margin-bottom: 0px;
}
#stats {
	font-weight: normal;
	font-size: 11px;
}
-->
</style>
</head>

<body>
<?php include('header_tpl.php'); ?>
      <h2 class="style67">CAPTCHA Settings</h2>
      <?php echo("$done");?>
      <table width="760" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td width="760">
<form action="<?php echo $editFormAction; ?>" method="post" name="form1" id="form1">
  <table align="center" cellpadding="3" cellspacing="3">
    <tr valign="baseline">
      <td align="right" nowrap="nowrap"><input name="chp_onoff" id="chp_onoff" type="hidden" value="Y" />
        Visual confirmation distort   level:</td>
      <td><select name="chp_distors">
        <option value="1" <?php if (!(strcmp(1, htmlentities($row_CVRS['chp_distors'], ENT_COMPAT, 'utf-8')))) {echo "SELECTED";} ?>>no distorsion</option>
        <option value="2" <?php if (!(strcmp(2, htmlentities($row_CVRS['chp_distors'], ENT_COMPAT, 'utf-8')))) {echo "SELECTED";} ?>>low distorsion</option>
        <option value="3" <?php if (!(strcmp(3, htmlentities($row_CVRS['chp_distors'], ENT_COMPAT, 'utf-8')))) {echo "SELECTED";} ?>>medium distorsion</option>
        <option value="4" <?php if (!(strcmp(4, htmlentities($row_CVRS['chp_distors'], ENT_COMPAT, 'utf-8')))) {echo "SELECTED";} ?>>heavy distorsion</option>
        <option value="5" <?php if (!(strcmp(5, htmlentities($row_CVRS['chp_distors'], ENT_COMPAT, 'utf-8')))) {echo "SELECTED";} ?>>extreme distorsion</option>
      </select>      </td>
    </tr>
    <tr valign="baseline">
      <td align="right" nowrap="nowrap">Visual confirmation phrase length:</td>
      <td><select name="chp_leng">
        <option value="4" <?php if (!(strcmp(4, htmlentities($row_CVRS['chp_leng'], ENT_COMPAT, 'utf-8')))) {echo "SELECTED";} ?>>4</option>
        <option value="5" <?php if (!(strcmp(5, htmlentities($row_CVRS['chp_leng'], ENT_COMPAT, 'utf-8')))) {echo "SELECTED";} ?>>5</option>
        <option value="6" <?php if (!(strcmp(6, htmlentities($row_CVRS['chp_leng'], ENT_COMPAT, 'utf-8')))) {echo "SELECTED";} ?>>6</option>
        <option value="7" <?php if (!(strcmp(7, htmlentities($row_CVRS['chp_leng'], ENT_COMPAT, 'utf-8')))) {echo "SELECTED";} ?>>7</option>
      </select>      </td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Visual confirmation phrase type:</td>
      <td><select name="chp_typ">
        <option value="A" <?php if (!(strcmp("A", htmlentities($row_CVRS['chp_typ'], ENT_COMPAT, 'utf-8')))) {echo "SELECTED";} ?>>Alphabetical</option>
        <option value="N" <?php if (!(strcmp("N", htmlentities($row_CVRS['chp_typ'], ENT_COMPAT, 'utf-8')))) {echo "SELECTED";} ?>>Numeric</option>
        <option value="B" <?php if (!(strcmp("B", htmlentities($row_CVRS['chp_typ'], ENT_COMPAT, 'utf-8')))) {echo "SELECTED";} ?>>Alphanumeric</option>
      </select>      </td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Visual confirmation phrase angle:</td>
      <td><select name="chp_simp">
        <option value="0" <?php if (!(strcmp("0", htmlentities($row_CVRS['chp_simp'], ENT_COMPAT, 'utf-8')))) {echo "SELECTED";} ?>>0</option>
        <option value="10" <?php if (!(strcmp("10", htmlentities($row_CVRS['chp_simp'], ENT_COMPAT, 'utf-8')))) {echo "SELECTED";} ?>>10</option>
        <option value="20" <?php if (!(strcmp("20", htmlentities($row_CVRS['chp_simp'], ENT_COMPAT, 'utf-8')))) {echo "SELECTED";} ?>>20</option>
        <option value="30" <?php if (!(strcmp("30", htmlentities($row_CVRS['chp_simp'], ENT_COMPAT, 'utf-8')))) {echo "SELECTED";} ?>>30</option>
      </select>      </td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">&nbsp;</td>
      <td>
<?php
if($chp_onoff == 'Y') { ?>
<img src="../random_image.php" />
<?php } else { ?> No Image Verification <?php } ?></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">&nbsp;</td>
      <td><input type="submit" value="Update record" /></td>
    </tr>
  </table>
  <input type="hidden" name="MM_update" value="form1" />
  <input type="hidden" name="chp_id" value="<?php echo $row_CVRS['chp_id']; ?>" />
</form>
          </td>
        </tr>
      </table>
      
<?php include('footer_tpl.php'); ?>
</body>
</html>
<?php
mysql_free_result($CVRS);
?>
