<? include ("header.php"); ?>




<table cellpadding="0" cellspacing="0" border="0" width="100%">
	<tr class="top3">
		<td colspan="3"><img src="template/v3/i/b.gif" border="0" height="15" width="1"></td>
	</tr>
	<tr class="top4">
		<td>&nbsp;</td>
		<td align="center">
			<table cellpadding="0" cellspacing="0" border="0" width="778">
				<tr>
					<td valign="top" height="109"><object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" width="257" height="109" id="logo" align="middle"><param name="movie" value="flash/logo.swf" /><param name="quality" value="high" /><param name="wmode" value="transparent" /><param name="bgcolor" value="#ffffff" /><embed src="flash/logo.swf" quality="high" wmode="transparent" bgcolor="#ffffff" width="257" height="109" name="rotator" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /></object></td>
					<td valign="top" height="109"><img src="template/v3/i/content12.jpg" border="0"></td>
					<td rowspan="3" valign="top" class="box_right"><object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" width="204" height="128" id="innerstar" align="middle"><param name="allowScriptAccess" value="sameDomain" /><param name="movie" value="flash/innerstar.swf" /><param name="quality" value="high" /><param name="wmode" value="transparent" /><param name="bgcolor" value="#ffffff" /><embed src="flash/innerstar.swf" quality="high" wmode="transparent" bgcolor="#ffffff" width="204" height="128" name="innerstar" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /></object><a href="promotions.php"><img src="template/v3/i/innerstar-1b2.gif" border="0"></a>
						




<? include ("mg.php"); ?>


 <form name="form" method="post" action="" onSubmit="return formCheck(this)">



	<tr>
					<td class="subtitle_path" colspan="2" valign="top" height="35"><div><a href="index.php"><img src="template/v3/i/home_ico.jpg" border="0" vspace="0" style="margin-left: 36px;margin-right: 27px" align="left"></a></div>Support</td>
				</tr>
				<tr>
					<td colspan="2" class="content" valign="top"><img src="template/v3/i/b.gif" width="1" height="500" border="0" align="left">
<table cellspacing=2 cellpadding=2 border=0>
		<tr>
			<td><b><font face="trebuchet ms" color=white size=2>Your Name</b><br><input name="txtName" type="text" class="box" id="txtName" size=25></td>
			<td><b><font face="trebuchet ms" color=white size=2>Your Email</b><br><input name="email" type="text" class="box" id="txtEmail" size=25></td>
		</tr>
		<tr>
			<td><b><font face="trebuchet ms" color=white size=2>Country</b><br><select name="txtCountry" class="box"><option value="Albania">Albania</option><option value="Algeria">Algeria</option><option value="American Samoa">American Samoa</option><option value="Andorra">Andorra</option><option value="Angola">Angola</option><option value="Anguilla">Anguilla</option><option value="Antigua & Barbuda">Antigua & Barbuda</option><option value="Argentina">Argentina</option><option value="Armenia">Armenia</option><option value="Aruba">Aruba</option><option value="Australia">Australia</option><option value="Austria">Austria</option><option value="Azerbaijan">Azerbaijan</option><option value="Bahamas">Bahamas</option><option value="Bahrain">Bahrain</option><option value="Bangladesh">Bangladesh</option><option value="Barbados">Barbados</option><option value="Belarus">Belarus</option><option value="Belgium">Belgium</option><option value="Belize">Belize</option><option value="Benin">Benin</option><option value="Bermuda">Bermuda</option><option value="Bhutan">Bhutan</option><option value="Bolivia">Bolivia</option><option value="Bosnia">Bosnia</option><option value="Botswana">Botswana</option><option value="Brazil">Brazil</option><option value="British Virgin Isles">British Virgin Isles</option><option value="Brunei">Brunei</option><option value="Bulgaria">Bulgaria</option><option value="Burkina Faso">Burkina Faso</option><option value="Burundi">Burundi</option><option value="Cambodia">Cambodia</option><option value="Cameroon">Cameroon</option><option value="CANADA">CANADA</option><option value="Canary Islands">Canary Islands</option><option value="Cape Verde">Cape Verde</option><option value="Cayman Islands">Cayman Islands</option><option value="Central African Republic">Central African Republic</option><option value="Chad">Chad</option><option value="Chile">Chile</option><option value="China">China</option><option value="Colombia">Colombia</option><option value="Congo">Congo</option><option value="Cook Islands">Cook Islands</option><option value="Costa Rica">Costa Rica</option><option value="Croatia">Croatia</option><option value="Cyprus">Cyprus</option><option value="Czech Republic">Czech Republic</option><option value="Denmark">Denmark</option><option value="Djibouti">Djibouti</option><option value="Dominica">Dominica</option><option value="Dominican Republic">Dominican Republic</option><option value="Ecuador">Ecuador</option><option value="Egypt">Egypt</option><option value="El Salvador">El Salvador</option><option value="Equatorial Guinea">Equatorial Guinea</option><option value="Eritrea">Eritrea</option><option value="Estonia">Estonia</option><option value="Ethiopia">Ethiopia</option><option value="Faeroe Islands">Faeroe Islands</option><option value="Fiji">Fiji</option><option value="Finland">Finland</option><option value="France">France</option><option value="French Guiana">French Guiana</option><option value="French Polynesia">French Polynesia</option><option value="Gabon">Gabon</option><option value="Gambia">Gambia</option><option value="Georgia">Georgia</option><option value="Germany">Germany</option><option value="Ghana">Ghana</option><option value="Gibraltar">Gibraltar</option><option value="Greece">Greece</option><option value="Greenland">Greenland</option><option value="Grenada">Grenada</option><option value="Guadeloupe">Guadeloupe</option><option value="Guam">Guam</option><option value="Guatemala">Guatemala</option><option value="Guinea">Guinea</option><option value="Guinea-Bissau">Guinea-Bissau</option><option value="Guyana">Guyana</option><option value="Haiti">Haiti</option><option value="Honduras">Honduras</option><option value="Hong Kong">Hong Kong</option><option value="Hungary">Hungary</option><option value="Iceland">Iceland</option><option value="India">India</option><option value="Indonesia">Indonesia</option><option value="Iraq">Iraq</option><option value="Ireland">Ireland</option><option value="Israel">Israel</option><option value="Italy">Italy</option><option value="Ivory Coast">Ivory Coast</option><option value="Jamaica">Jamaica</option><option value="Japan">Japan</option><option value="Jordan">Jordan</option><option value="Kazakhstan">Kazakhstan</option><option value="Kenya">Kenya</option><option value="Kiribati">Kiribati</option><option value="Kuwait">Kuwait</option><option value="Kyrgyzstan">Kyrgyzstan</option><option value="Laos">Laos</option><option value="Latvia">Latvia</option><option value="Lebanon">Lebanon</option><option value="Lesotho">Lesotho</option><option value="Liberia">Liberia</option><option value="Liechtenstein">Liechtenstein</option><option value="Lithuania">Lithuania</option><option value="Luxembourg">Luxembourg</option><option value="Macau">Macau</option><option value="Macedonia">Macedonia</option><option value="Madagascar">Madagascar</option><option value="Malawi">Malawi</option><option value="Malaysia">Malaysia</option><option value="Maldives">Maldives</option><option value="Mali">Mali</option><option value="Malta">Malta</option><option value="Marshall Islands">Marshall Islands</option><option value="Martinique">Martinique</option><option value="Mauritania">Mauritania</option><option value="Mauritius">Mauritius</option><option value="Mexico">Mexico</option><option value="Micronesia">Micronesia</option><option value="Moldova">Moldova</option><option value="Monaco">Monaco</option><option value="Mongolia">Mongolia</option><option value="Montserrat">Montserrat</option><option value="Morocco">Morocco</option><option value="Mozambique">Mozambique</option><option value="N. Mariana Islands">N. Mariana Islands</option><option value="Namibia">Namibia</option><option value="Nepal">Nepal</option><option value="Netherlands">Netherlands</option><option value="Netherlands Antilles">Netherlands Antilles</option><option value="New Caledonia">New Caledonia</option><option value="New Zealand">New Zealand</option><option value="Nicaragua">Nicaragua</option><option value="Niger">Niger</option><option value="Nigeria">Nigeria</option><option value="Norfolk Island">Norfolk Island</option><option value="Norway">Norway</option><option value="Oman">Oman</option><option value="Pakistan">Pakistan</option><option value="Palau">Palau</option><option value="Panama">Panama</option><option value="Papua New Guinea">Papua New Guinea</option><option value="Paraguay">Paraguay</option><option value="Peru">Peru</option><option value="Philippines">Philippines</option><option value="Poland">Poland</option><option value="Portugal">Portugal</option><option value="Puerto Rico">Puerto Rico</option><option value="Qatar">Qatar</option><option value="Reunion">Reunion</option><option value="Romania">Romania</option><option value="Russia">Russia</option><option value="Rwanda">Rwanda</option><option value="San Marino">San Marino</option><option value="Saudi Arabia">Saudi Arabia</option><option value="Senegal">Senegal</option><option value="Serbia And Montenegro">Serbia And Montenegro</option><option value="Seychelles">Seychelles</option><option value="Sierra Leone">Sierra Leone</option><option value="Singapore">Singapore</option><option value="Slovakia">Slovakia</option><option value="Slovenia">Slovenia</option><option value="Solomon Islands">Solomon Islands</option><option value="South Africa">South Africa</option><option value="South Korea">South Korea</option><option value="Spain">Spain</option><option value="Sri Lanka">Sri Lanka</option><option value="St. Kitts & Nevis">St. Kitts & Nevis</option><option value="St. Lucia">St. Lucia</option><option value="St. Vincent & Grenadines">St. Vincent & Grenadines</option><option value="Suriname">Suriname</option><option value="Swaziland">Swaziland</option><option value="Sweden">Sweden</option><option value="Switzerland">Switzerland</option><option value="Syria">Syria</option><option value="Taiwan">Taiwan</option><option value="Tajikistan">Tajikistan</option><option value="Tanzania">Tanzania</option><option value="Thailand">Thailand</option><option value="Togo">Togo</option><option value="Tonga">Tonga</option><option value="Trinidad & Tobago">Trinidad & Tobago</option><option value="Tunisia">Tunisia</option><option value="Turkey">Turkey</option><option value="Turkmenistan">Turkmenistan</option><option value="Turks & Caicos Islands">Turks & Caicos Islands</option><option value="Tuvalu">Tuvalu</option><option value="Uganda">Uganda</option><option value="Ukraine">Ukraine</option><option value="United Arab Emirates">United Arab Emirates</option><option value="United Kingdom">United Kingdom</option><option value="United States">United States</option><option value="Uruguay">Uruguay</option><option value="Us Virgin Islands">Us Virgin Islands</option><option value="Uzbekistan">Uzbekistan</option><option value="Vanuatu">Vanuatu</option><option value="Venezuela">Venezuela</option><option value="Vietnam">Vietnam</option><option value="Wallis & Futuna Islands">Wallis & Futuna Islands</option><option value="Western Samoa">Western Samoa</option><option value="Yemen">Yemen</option><option value="Yugoslavia">Yugoslavia</option><option value="Zambia">Zambia</option><option value="Zimbabwe">Zimbabwe</option></select></td>
			<td><b><font face="trebuchet ms" color=white size=2>Currency</b><br><select name="txtCurrency" class="box"><option value="USD">USD</option><option value="EUR">EUR</option><option value="GBP">GBP</option></select></td>
		</tr>
		<tr>
			<td colspan=2><b><font face="trebuchet ms" color=white size=2>Subject</b><br><input name="txtSubject" type="text" class="box" id="txtSubject" size=65></td>
		</tr>
		<tr>
			<td colspan=2><b><font face="trebuchet ms" color=white size=2>Message</b><br><textarea name="mess" cols="50" rows="10" class="box" id="txtMsg"></textarea>
		    	



 <input type="hidden" name="send" value="1"></td>
		</tr>	
		<tr>
			











<td colspan=2>Send<input type="image" value="Login" ID="submit" src="images/ar-org-s.gif"></td>
		</tr>		
	</table><br>
* If you are an existing player and have not been receiving operational, payout related or promotional email from the flash casino, it is possible that you have not added us to your address book or safe list. For instructions on how to do this, please contact our <a href="javascript: popup('');">support staff</a>.</td>
				</tr>
				<tr>
					<td colspan="2" valign="bottom" class="content_bot"><img src="template/v3/i/content_bot.jpg" border="0"></td>
					<td class="box_right" valign="bottom"><img src="template/v3/i/box_right_bot.jpg" border="0"></td>
				</tr>
			</table></form>
		</td>
		<td>&nbsp;</td>
	</tr>




<?
if ($send=="1"){
if ($email == "") {print "<script> alert(' E-mail empty !'); </script>"; exit;}
if ($mess == "") {print "<script> alert('message !'); </script>"; exit;}
$dopmess="\n\n\n==========\mail: ".$l."\nIP: ".$REMOTE_ADDR;
$to = $con[2];
$subject = $txtSubject;
$msg =$txtCountry.$txtName.$mess.$dopmess;
$mailheaders = "Content-Type: text/plain; charset=iso-8859-1\n";
$mailheaders .= "From:$email\n";
mail($to, $subject, $msg, $mailheaders);
echo "<script> alert('Message envoy�'); document.location.href='index.php'; </script>";
}
?>
















		<?		include ("footer.php") ?>	
