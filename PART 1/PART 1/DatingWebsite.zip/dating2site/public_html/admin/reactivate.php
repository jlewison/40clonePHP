<?php

/*
*	This program will manage the featured profiles list
*
*/

if ( !defined( 'SMARTY_DIR' ) ) {

	include_once( '../init.php' );

}

include ( 'sessioninc.php' );

define( 'PAGE_ID', 'profile_mgt' );

if ( !checkAdminPermission( PAGE_ID ) ) {

	header( 'location: not_authorize.php' );
	exit;
}

if ($_GET['id']) {

/* Need to reactivate this userid */
	$sql = 'update ! set active = ?, regdate = ?, status = ? where id = ?';

	$db->query($sql, array( USER_TABLE, '1', time(), 'active', $_GET['id'] ) );

	$usr = $db->getRow('select username, firstname, lastname, email, level, levelend  from ! where id = ?',array(USER_TABLE, $_GET['id'] ) );

	if ($config['forum_installed'] != 'None' && $config['forum_installed'] != '') {
		forum_reactivate($usr['username']);
	}

	if ($config['letter_profilereactivated'] == 'Y') {
	/* Send email to the user */

		include (PEAR_DIR.'Mail/mime.php');

		$membershiplevel = $db->getOne('select name from ! where roleid=?', array(MEMBERSHIP_TABLE, $usr['level']) );

		$siteurl = HTTP_METHOD . $_SERVER['SERVER_NAME'] . DOC_ROOT ;

		$Subject = get_lang('profile_reactivated_sub') ;

		$From = $config['admin_email'];

		$To = $usr['email'];

		$message = get_lang('profile_reactivated', MAIL_FORMAT);

		$message = str_replace('#FirstName#', $usr['firstname'] ,$message);

		$message = str_replace('#ValidDate#',date(get_lang('DISPLAY_DATETIME_FORMAT'), $usr['levelend']), $message);

		$message = str_replace('#MembershipLevel#', $membershiplevel,$message);

		$success = mailSender($From, $To, $usr['email'], $Subject, $message);

	}

	$t->assign('errmsg' ,USER_REACTIVATED);

}

$sort = findSortBy('username');

$sql = 'select id, username, firstname, lastname, regdate from ! where status in (?,?) order by ! ';

$t->assign('cancel_list', $db->getAll($sql, array( USER_TABLE,  get_lang('status_act','cancel'), 'cancel', $sort ) ) );

$t->assign('lang', $lang);

$t->assign( 'sort_type', checkSortType( $_GET['type'] ) );

$t->assign('rendered_page', $t->fetch('admin/reactivate.tpl'));

$t->display('admin/index.tpl');

?>