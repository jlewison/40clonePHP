<?php include('template/Green_Light/b_inside_top.php');?>
<td valign="top">
<!--
###################################################################################
#######################                                     #######################
#######################   M A I N   S E C T I O N   Start   #######################
#######################                                     #######################
###################################################################################
-->
<div class="page-header"><h1>Thank You</h1></div>

		<div style="margin-left:30px; margin-right:30px">
			<p>You have just made a sucessful payment, thank you.<br />
          <br />
            <span class="style4">Please <a href="<?php echo("$path");?>" class="style28">click here</a> to return to our homepage</span><br /></p>
		</div>
<!--
###################################################################################
#######################                                     #######################
#######################    M A I N   S E C T I O N   End    #######################
#######################                                     #######################
###################################################################################
-->
</div>

<?php include('template/Green_Light/b_footer_tpl.php'); ?>