<? include ("header.php"); ?>

<? include ("menugame.php"); ?>



                
                
<TD class=flash_td>


<TABLE class=fgi_chips cellSpacing=0 cellPadding=0 width="100%" 
            border=0>
              <TBODY>
              <TR>
                <TD class=t><IMG 
                  src="fgi/chips_tl.jpg"></TD>
                <TD class=t align=right><IMG 
                  src="fgi/chips_tr.jpg"></TD></TR>
              <TR>
                <TD class=fgd colSpan=3><center><H3>Cheeky Monkey Keno</H3></center></TD>
                <TD class=l></TD></TR>
              <TR>
                <TD class=b><IMG 
                  src="fgi/chips_bl.jpg"></TD>
                <TD class=b align=right><IMG 
                  src="fgi/chips_br.jpg"></TD></TR></TBODY></TABLE>


<IMG style="border-color:#3366FF"
                  src="game/cheeky/img.jpg"  height="150" width="250" border="2">


</TD>
                <TD class=fgcr><IMG 
                  src="fgi/c_r.jpg"></TD></TR>
              <TR>
                <TD class=fgcl><IMG 
                  src="fgi/c_l.jpg"></TD>
                <TD class=flash_td><IMG height=10 
                  src="fgi/b.gif"></TD>
                <TD class=fgcr><IMG 
                  src="fgi/c_r.jpg"></TD></TR>
              <TR>
                <TD class=fgcl><IMG 
                  src="fgi/c_l.jpg"></TD>
                











<TD class=denom><center>  


<A 
                  href="game/cheeky/index.php">PLAY</A>

<A href='javascript:OuvrirPop("<? echo $rog[3]; ?>/system/game/cheeky/cheeky/freegames/istruzioni/ENG/cheeky.html","fencent",10,10,650,550,"menubar=no,scrollbars=yes,statusbar=no")'>HELP</A>

</center></TD>
                














<TD class=fgcr><IMG 
                  src="fgi/c_r.jpg"></TD></TR>
              <TR>
                <TD width=10><IMG 
                  src="fgi/c_bl.jpg"></TD>
                <TD class=fgcb><IMG 
                  src="fgi/c_b.jpg"></TD>
                <TD width=10><IMG 
                  src="fgi/c_br.jpg"></TD></TR></TBODY></TABLE><BR>
           
            
             
              



</TD></TR></TBODY></TABLE></TD>
    <TD>&nbsp;</TD></TR>






  




<? include ("footer.php"); ?>





