<?php
/**
 * Groups Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 12/26/2007
 */
class Groups extends Controller
{
		//Constructor
		var $userId, $notificationId;
		function Groups()
		{
				parent::Controller();
				loginRequired();
				$this->load->model('groupsModel');
				$this->lang->load('posted', $this->config->item('language_code'));
				$this->userId = $this->session->userdata('user_id');
				$this->lang->load('wall', $this->config->item('language_code'));
				$this->notificationId = 3;
				//Load the language file
				$this->lang->load('groups', $this->config->item('language_code'));
		}
		//Default function
		function index()
		{
				$this->home();
		}
		function home()
		{
				$data = array();
				$this->load->model('friendsmodel');
				$user = $this->userId;
				$friendsArray = $this->friendsmodel->getFriends($user);
				$friendsCount = count($friendsArray);
				$friendsGroups = array();
				$search = ($this->input->post('searchtext') == false) ? '' : $this->input->post('searchtext');
				if ($friendsCount > 0)
				{
						$friendsIds = implode(',', $friendsArray);
						$friendsGroups = $this->groupsModel->getFriendsGroups($friendsIds, $user, $search, 0, 5);
						foreach ($friendsGroups as $key => $valArr)
						{
								$friendsGroups[$key]['group_avatar'] = $this->groupsModel->getGroupImage($valArr['group_id'], true);
								$friendsGroups[$key]['group_members'] = count($this->groupsModel->getGroupMembers($valArr['group_id'], 'accepted'));
						}
				}
				$data['friendsCount'] = $friendsCount;
				$data['friendsGroupsCount'] = count($friendsGroups);
				$data['friendsGroups'] = $friendsGroups;
				$ownGroupsFlag = 'N';
				$userGroups = $this->groupsModel->getUserGroups($user, $search, $ownGroupsFlag, 0, 5);
				foreach ($userGroups as $key => $valArr)
				{
						$userGroups[$key]['group_avatar'] = $this->groupsModel->getGroupImage($valArr['group_id'], true);
						$userGroups[$key]['group_members'] = count($this->groupsModel->getGroupMembers($valArr['group_id'], 'accepted'));
						$userGroups[$key]['new_members'] = count($this->groupsModel->getGroupApplicants($valArr['group_id']));
				}
				$data['userGroupsCount'] = count($userGroups);
				$data['userGroups'] = $userGroups;
				$this->smartyextended->view('groups', $data);
		}
		function recentfriends($user = '')
		{
				$data = array();
				$this->load->model('friendsmodel');
				$userId = $user;
				if ($userId != '' && !ereg('^[0-9]+$', $userId)) redirect('groups/mygroups');
				else  $userId = $this->userId;
				$friendsArray = $this->friendsmodel->getFriends($userId);
				$friendsCount = count($friendsArray);
				$friendsGroups = array();
				$search = '';
				//Load the pagination model
				$this->load->model('paginationmodel');
				//Load the pagination language file
				$this->lang->load('pagination', $this->config->item('language_code'));
				$perPage = $this->paginationmodel->getPerPage('groups');
				$start = (trim($this->uri->segment(4)) != '' && is_numeric($this->uri->segment(4)) && $this->uri->segment(4) > 0) ? $this->uri->segment(4) : 1;
				$start = ($start - 1) * $perPage;
				if ($friendsCount > 0)
				{
						$friendsIds = implode(',', $friendsArray);
						$friendsGroups = $this->groupsModel->getFriendsGroups($friendsIds, $user, $search, $start, $perPage);
						foreach ($friendsGroups as $key => $valArr)
						{
								$friendsGroups[$key]['group_avatar'] = $this->groupsModel->getGroupImage($valArr['group_id'], true);
								$friendsGroups[$key]['group_members'] = count($this->groupsModel->getGroupMembers($valArr['group_id'], 'accepted'));
						}
						$data['friendsGroupsCount'] = count($friendsGroups);
						$data['friendsGroups'] = $friendsGroups;
						$data['resultTotal'] = $this->groupsModel->getFriendsGroupsCount($friendsIds, $user, $search);
						$data['currentPage'] = (trim($this->uri->segment(4)) != '' && is_numeric($this->uri->segment(4))) ? $this->uri->segment(4) : 1;
						$data['totalPages'] = ($data['resultTotal'] > $perPage) ? ceil(($data['resultTotal'] / $perPage)) : 0;
						$data['pageUrl'] = base_url() . 'groups/recentfriends/' . $userId . '/';
				}
				$data['username'] = $this->usermodel->getName($userId);
				$data['user'] = $userId;
				$data['friendsCount'] = $friendsCount;
				$this->smartyextended->view('groups_recent_friends_list', $data);
		}
		function viewmembers($groupId)
		{
				if (!ereg('^[0-9]+$', $groupId)) redirect('groups/mygroups/');
				//Load the pagination model
				$this->load->model('paginationmodel');
				//Load the pagination language file
				$this->lang->load('pagination', $this->config->item('language_code'));
				$perPage = $this->paginationmodel->getPerPage('groups');
				$start = (trim($this->uri->segment(6)) != '' && is_numeric($this->uri->segment(6)) && $this->uri->segment(6) > 0) ? $this->uri->segment(6) : 1;
				$start = ($start - 1) * $perPage;
				$adminFlag = 'no';
				$status = 'accepted';
				$groupMembers = $this->groupsModel->getGroupMembers($groupId, $status, $adminFlag, $start, $perPage);
				if (count($groupMembers) > 0)
				{
						$this->load->model('networkmodel');
						$this->load->model('usermodel');
						$groupInfo = $this->groupsModel->getInfo($groupId);
						$groupName = '';
						if (count($groupInfo) > 0)
						{
								$groupName = $groupInfo['group_name'];
						}
						else
						{
								redirect('groups/mygroups/');
						}
						foreach ($groupMembers as $key => $valArr)
						{
								$result = $this->networkmodel->getUserNetwork($valArr['receiver_id'], 'region');
								if (count($result) > 0)
								{
										$result = current($result);
										$network = $result['network_name'];
								}
								else  $network = 'No network';
								$groupMembers[$key]['network'] = $network;
								$groupMembers[$key]['avatar'] = $this->usermodel->getAvatar($valArr['receiver_id'], true);
						}
				}
				$data['members_list_count'] = count($groupMembers);
				$data['resultTotal'] = $this->groupsModel->getGroupMembersCount($groupId, $status, $adminFlag);
				$data['currentPage'] = (trim($this->uri->segment(6)) != '' && is_numeric($this->uri->segment(6))) ? $this->uri->segment(6) : 1;
				$data['totalPages'] = ($data['resultTotal'] > $perPage) ? ceil(($data['resultTotal'] / $perPage)) : 0;
				$data['pageUrl'] = base_url() . 'groups/viewmembers/' . $groupId . '/' . $status . '/' . $adminFlag . '/';
				$data['groupMembers'] = $groupMembers;
				$data['group_name'] = $groupName;
				$data['group_id'] = $groupId;
				$this->smartyextended->view('groups_list_members', $data);
		}
		function mygroups($userId = '')
		{
				$data = array();
				if ($userId != '' && !ereg('^[0-9]+$', $userId)) redirect('groups/mygroups');
				else  $userId = $this->userId;
				$this->load->model('usermodel');
				//Load the pagination model
				$this->load->model('paginationmodel');
				//Load the pagination language file
				$this->lang->load('pagination', $this->config->item('language_code'));
				$perPage = $this->paginationmodel->getPerPage('groups');
				$start = (trim($this->uri->segment(4)) != '' && is_numeric($this->uri->segment(4)) && $this->uri->segment(4) > 0) ? $this->uri->segment(4) : 1;
				$start = ($start - 1) * $perPage;
				$search = '';
				$ownGroupsFlag = 'Y';
				$groupsResult = $this->groupsModel->getUserGroups($userId, $search, $ownGroupsFlag, $start, $perPage);
				foreach ($groupsResult as $key => $valArr)
				{
						$groupsResult[$key]['members'] = count($this->groupsModel->getGroupMembers($valArr['group_id']));
						$groupsResult[$key]['group_image'] = $this->groupsModel->getGroupImage($valArr['group_id'], true);
						$groupsResult[$key]['memberflag'] = $this->groupsModel->isGroupMember($valArr['group_id'], $userId);
						$groupsResult[$key]['adminflag'] = $this->groupsModel->isAdmin($valArr['group_id'], $userId);
				}
				$data['recentflag'] = 0;
				$data['user'] = $userId;
				$data['username'] = $this->usermodel->getName($userId);
				$data['groupresult'] = $groupsResult;
				$data['resultcount'] = count($groupsResult);
				$data['resultTotal'] = $this->groupsModel->getUserGroupsCount($userId, $search, $ownGroupsFlag);
				$data['currentPage'] = (trim($this->uri->segment(4)) != '' && is_numeric($this->uri->segment(4))) ? $this->uri->segment(4) : 1;
				$data['totalPages'] = ($data['resultTotal'] > $perPage) ? ceil(($data['resultTotal'] / $perPage)) : 0;
				$data['pageUrl'] = base_url() . 'groups/mygroups/' . $userId . '/';
				$this->smartyextended->view('groups_list', $data);
		}
		function recentgroups($userId = '')
		{
				$data = array();
				if ($userId != '' && !ereg('^[0-9]+$', $userId)) redirect('groups/mygroups');
				else  $userId = $this->userId;
				$this->load->model('usermodel');
				//Load the pagination model
				$this->load->model('paginationmodel');
				//Load the pagination language file
				$this->lang->load('pagination', $this->config->item('language_code'));
				$perPage = $this->paginationmodel->getPerPage('groups');
				$start = (trim($this->uri->segment(4)) != '' && is_numeric($this->uri->segment(4)) && $this->uri->segment(4) > 0) ? $this->uri->segment(4) : 1;
				$start = ($start - 1) * $perPage;
				$search = '';
				$ownGroupsFlag = 'N';
				$groupsResult = $this->groupsModel->getUserGroups($userId, $search, $ownGroupsFlag, $start, $perPage);
				foreach ($groupsResult as $key => $valArr)
				{
						$groupsResult[$key]['members'] = count($this->groupsModel->getGroupMembers($valArr['group_id']));
						$groupsResult[$key]['group_image'] = $this->groupsModel->getGroupImage($valArr['group_id'], true);
						$groupsResult[$key]['memberflag'] = $this->groupsModel->isGroupMember($valArr['group_id'], $userId);
						$groupsResult[$key]['adminflag'] = $this->groupsModel->isAdmin($valArr['group_id'], $userId);
				}
				$data['recentflag'] = 1;
				$data['user'] = $userId;
				$data['username'] = $this->usermodel->getName($userId);
				$data['groupresult'] = $groupsResult;
				$data['resultcount'] = count($groupsResult);
				$data['resultTotal'] = $this->groupsModel->getUserGroupsCount($userId, $search, $ownGroupsFlag);
				$data['currentPage'] = (trim($this->uri->segment(4)) != '' && is_numeric($this->uri->segment(4))) ? $this->uri->segment(4) : 1;
				$data['totalPages'] = ($data['resultTotal'] > $perPage) ? ceil(($data['resultTotal'] / $perPage)) : 0;
				$data['pageUrl'] = base_url() . 'groups/recentgroups/' . $userId . '/';
				$this->smartyextended->view('groups_list', $data);
		}
		function managegroups($groupId = '', $action = 'new')
		{
				$userId = $this->userId;
				$this->load->library('validation');
				$this->load->model('userModel');
				$arrCountry = $this->groupsModel->getCountry();
				$groupCount = $this->groupsModel->getUserGroupCount();
				$adminSettingsCount = $this->groupsModel->getAdminSettingsGroupCount();
				if ($adminSettingsCount > 0)
				{
						if ($groupCount >= $adminSettingsCount && $action == 'new' && $groupId == '')
						{
								$strMsg = $this->lang->line('groups_msg_creation') . ' (' . $groupCount . ') ' . $this->lang->line('groups_count_label');
								$this->session->set_flashdata('flash_msg', $strMsg);
								redirect('groups/');
						}
				}
				/*
				$this->session->set_flashdata('flash_msg', 'You cannot create groups');
				redirect('groups/');
				*/
				if ($groupId !== '')
				{
						if (!ereg('^[0-9]+$', $groupId)) redirect('groups/mygroups/');
				}
				if ($groupId !== '')
				{
						$groupInfo = $this->groupsModel->getGroupInfo($groupId);
						if (count($groupInfo) == 0) redirect('groups/mygroups/');
				}
				$isadmin = 0;
				if ($groupId != '') $isadmin = $this->groupsModel->isAdmin($groupId, $this->userId);
				if ($groupId !== '')
				{
						if ($isadmin != 1 && $groupId != '') redirect('groups/mygroups/');
				}
				$data = array();
				if ($groupId != '')
				{
						if ($isadmin == 1 && count($groupInfo) > 0)
						{
								$action = 'edit';
								$data['group_name'] = $groupInfo['group_name'];
								$data['group_desc'] = $groupInfo['group_description'];
								$data['group_category'] = $groupInfo['group_category_id'];
								$data['group_sub_category'] = $groupInfo['group_sub_category_id'];
								$data['group_news'] = $groupInfo['group_recentnews'];
								$data['group_office'] = $groupInfo['group_office'];
								$data['group_website'] = $groupInfo['group_url'];
								$data['group_email'] = $groupInfo['group_email'];
								$data['group_street'] = $groupInfo['group_street'];
								$data['group_city'] = $groupInfo['group_city'];
								$data['group_state'] = $groupInfo['group_state'];
								$data['group_country'] = $groupInfo['group_country'];
								$data['show_related_groups'] = $groupInfo['group_related'];
								$data['show_message_board'] = $groupInfo['group_discussionboard'];
								$data['show_wall'] = $groupInfo['group_wall'];
								$data['show_photos'] = $groupInfo['group_photos'];
								$data['upload_access'] = $groupInfo['group_upload_permission'];
								$data['show_videos'] = $groupInfo['group_videos'];
								$data['video_access'] = $groupInfo['group_videos_permission'];
								$data['show_posted'] = $groupInfo['group_posted'];
								$data['posted_access'] = $groupInfo['group_posted_permission'];
								$data['privacy_type'] = $groupInfo['group_type'];
								$data['portal_publisize'] = $groupInfo['group_publicize'];
								$data['network'] = $groupInfo['network_id'];
								$data['sub_categories'] = $this->groupsModel->getSubcategories($data['group_category']);
						}
						else
						{
								redirect('groups/mygroups');
						}
				}
				$arrNetworks = $this->userModel->networks($userId);
				$arrGroupType = $this->groupsModel->getGroupCategory();
				$arrCountry = $this->groupsModel->getCountry();
				$this->_formRules();
				if ($this->validation->run() == false)
				{
						//Oops! validation Error.
						$data['validationError'] = $this->validation->error_string;
						if ($action != 'edit') $data['sub_categories'] = ($this->input->post('group_category') !== false && $this->input->post('group_category') > 0) ? $this->groupsModel->getSubcategories($this->input->post('group_category')) : array();
				}
				else
				{
						$action = $this->input->post('hdnAction');
						$groupId = ($this->input->post('hdnGroupId') != false) ? $this->input->post('hdnGroupId') : '';
						$groupValues = array('group_name' => $this->db->escape($this->input->post('group_name')), 'network_id' => ($this->input->post('network') != false) ? $this->db->escape($this->input->post('network')) : '0', 'group_description' => $this->db->escape($this->input->post('group_desc')), 'group_category_id' => $this->db->escape($this->input->post('group_category')), 'group_sub_category_id' => $this->db->escape($this->input->post('group_sub_category')), 'group_recentnews' => $this->db->escape($this->input->post('group_news')), 'group_office' => $this->db->escape($this->input->post('group_office')), 'group_url' => $this->db->escape($this->input->post('group_website')), 'group_email' => $this->db->escape($this->input->post('group_email')), 'group_street' => $this->db->escape($this->input->post('group_street')), 'group_city' => $this->db->escape($this->input->post('group_city')), 'group_country' => $this->db->escape($this->input->post('group_country')), 'group_related' => $this->db->escape(($this->
								input->post('show_related_groups') == false) ? 'no' : 'yes'), 'group_discussionboard' => $this->db->escape(($this->input->post('show_message_board') == false) ? 'no' : 'yes'), 'group_wall' => $this->db->escape(($this->input->post('show_wall') == false) ? 'no' : 'yes'), 'group_photos' => $this->db->escape(($this->input->post('show_photos') == false) ? 'no' : 'yes'), 'group_type' => $this->db->escape($this->input->post('privacy_type')), 'group_publicize' => $this->db->escape(($this->input->post('portal_publisize') == false) ? 'no' : 'yes'), 'user_id' => $this->userId, 'group_upload_permission' => ($this->input->post('upload_access') != false) ? $this->db->escape($this->input->post('upload_access')) : $this->db->escape('members'), );
						$groupId = $this->groupsModel->saveGroupInfo($groupValues, $groupId, $action);
						if ($groupId > 0)
						{
								//redirect('groups/picture/'.$groupId.'/');
								// Here Minifeed
								if ($action != 'edit')
								{
										$userFeedSettings = $this->userModel->getUserFeedSetting();
										if (isset($userFeedSettings[14]) && $userFeedSettings[14] == 'yes')
										{
												//Load the minifeed model
												$this->load->model('minifeedmodel');
												$splVars = array('~~postedBy~~' => $this->session->userdata('username'), '~~groupName~~' => $this->input->post('group_name'));
												$this->minifeedmodel->postMiniFeed('CREATE_GROUP', $splVars, array(base_url() . 'groups/view/' . $groupId . '/'));
										}
								}
								//
								$outputData = array();
								$outputData['groupimage'] = $this->groupsModel->getGroupImage($groupId);
								$outputData['group_id'] = $groupId;
								if ($action != 'edit') $outputData['successmsg'] = $this->lang->line('groups_msg_group_create_success');
								else  $outputData['successmsg'] = $this->lang->line('groups_msg_group_save_success');
								$this->smartyextended->view('groups_picture', $outputData);
								exit;
						}
						else
						{
								$data['validationError'] = $this->lang->line('groups_msg_group_save_fail');
						}
				}
				$this->load->model('settingsModel');
				$settings = $this->settingsmodel->readSetting('admin_email, admin_name, site_name, site_title');
				$sitetitle = $settings['site_title'];
				$data['arrCountry'] = $arrCountry;
				$data['action'] = $action;
				$data['group_id'] = $groupId;
				$data['networkscount'] = count($arrNetworks);
				$data['arrCountry'] = $arrCountry;
				$data['groupcat'] = $arrGroupType;
				$data['usernetworks'] = $arrNetworks;
				$data['sitetitle'] = $sitetitle;
				if ($adminSettingsCount > 0) $data['groupadminmsg'] = $this->lang->line('groups_msg_max') . ' (' . $adminSettingsCount . ') ' . $this->lang->line('groups_count_label');
				$this->smartyextended->view('managegroups', $data);
		}
		function addmembers()
		{
				$userid = $this->input->post('userid');
				$groupId = $this->input->post('group_id');
				if ($userid !== false && $groupId !== false)
				{
						$res = $this->groupsModel->addMembers($groupId, $userid, $this->userId);
						$groupFriends = $this->groupsModel->getFriendsInvitees($groupId, $this->userId);
						$data['groupsfriends'] = $groupFriends;
						$data['friendscount'] = count($groupFriends);
						$data['group_id'] = $groupId;
						$data['errmsg'] = '';
						$data['content'] = $this->smartyextended->view('groups_friends', $data, true);
						$data['invitees'] = $this->groupsModel->getMembers($groupId);
						$data['inviteescount'] = count($data['invitees']);
						$data['group_id'] = $groupId;
						$data['inviteids'] = implode(',', array_keys($data['invitees']));
						$data['invitationcontent'] = $this->smartyextended->view('groups_invitation', $data, true);
						echo json_encode($data);
				}
				else
				{
						echo json_encode('none');
				}
		}
		function blockmember()
		{
				$userId = $this->input->post('user_id');
				$groupId = $this->input->post('group_id');
				$status = $this->input->post('status');
				$this->groupsModel->blockGroupMember($userId, $groupId);
				$groupFriends = $this->groupsModel->getFriendsInvitees($groupId, $this->userId);
				$data['groupsfriends'] = $groupFriends;
				$data['friendscount'] = count($groupFriends);
				$data['group_id'] = $groupId;
				$data['errmsg'] = '';
				$data['invitees'] = $this->groupsModel->getMembers($groupId);
				$data['inviteids'] = implode(',', array_keys($data['invitees']));
				$data['content'] = $this->smartyextended->view('groups_friends', $data, true);
				if ($status == 'sent') $data['members'] = $this->groupsModel->getMembers($groupId, $status);
				else  $data['members'] = $this->groupsModel->getGroupMembers($groupId, $status);
				//$data['members']		=	$this->groupsModel->getMembers($groupId);
				$data['status'] = ($this->input->post('status') == false) ? 'accepted' : $this->input->post('status');
				$data['membercount'] = count($data['members']);
				$data['memlist'] = $this->smartyextended->view('groups_memlist', $data, true);
				echo json_encode($data);
		}
		function unblockmember()
		{
				$userId = $this->input->post('user_id');
				$groupId = $this->input->post('group_id');
				$status = $this->input->post('status');
				$this->groupsModel->unblockGroupMember($userId, $groupId);
				$groupFriends = $this->groupsModel->getFriendsInvitees($groupId, $this->userId);
				$data['groupsfriends'] = $groupFriends;
				$data['friendscount'] = count($groupFriends);
				$data['group_id'] = $groupId;
				$data['errmsg'] = '';
				$data['invitees'] = $this->groupsModel->getMembers($groupId);
				$data['inviteids'] = implode(',', array_keys($data['invitees']));
				$data['content'] = $this->smartyextended->view('groups_friends', $data, true);
				if ($status == 'sent') $data['members'] = $this->groupsModel->getMembers($groupId, $status);
				else  $data['members'] = $this->groupsModel->getGroupMembers($groupId, $status);
				//$data['members']		=	$this->groupsModel->getMembers($groupId);
				$data['status'] = ($this->input->post('status') == false) ? 'accepted' : $this->input->post('status');
				$data['membercount'] = count($data['members']);
				$data['memlist'] = $this->smartyextended->view('groups_memlist', $data, true);
				echo json_encode($data);
		}
		function removemember()
		{
				$userId = $this->input->post('user_id');
				$groupId = $this->input->post('group_id');
				$status = $this->input->post('status');
				if ($status == 'sent')
				{
						$this->groupsModel->removeInvitation($userId, $groupId);
				}
				else
				{
						if ($status == 'accepted' || $status == 'blocked') $this->groupsModel->removeGroupMember($userId, $groupId);
				}
				$groupFriends = $this->groupsModel->getFriendsInvitees($groupId, $this->userId);
				$data['groupsfriends'] = $groupFriends;
				$data['friendscount'] = count($groupFriends);
				$data['group_id'] = $groupId;
				$data['errmsg'] = '';
				$data['invitees'] = $this->groupsModel->getMembers($groupId);
				$data['inviteids'] = implode(',', array_keys($data['invitees']));
				$data['content'] = $this->smartyextended->view('groups_friends', $data, true);
				if ($status == 'sent') $data['members'] = $this->groupsModel->getMembers($groupId, $status);
				else  $data['members'] = $this->groupsModel->getGroupMembers($groupId, $status);
				//$data['members']		=	$this->groupsModel->getMembers($groupId);
				$data['status'] = ($this->input->post('status') == false) ? 'accepted' : $this->input->post('status');
				$data['membercount'] = count($data['members']);
				$data['memlist'] = $this->smartyextended->view('groups_memlist', $data, true);
				echo json_encode($data);
		}
		function invite()
		{
				$ids = $this->input->post('ids');
				$groupId = $this->input->post('group_id');
				$message = $this->input->post('message');
				$msg = '';
				if ($ids !== false && $groupId !== false && $message !== false)
				{
						if ($message != '')
						{
								$usernames = $this->sendInvitations($ids, $groupId, $message);
								$msg = $this->lang->line('groups_msg_invite_sent_people');
								$msg = $msg . $usernames;
						}
				}
				$data['group_id'] = $groupId;
				$data['errmsg'] = $msg;
				$data['invitees'] = $this->groupsModel->getMembers($groupId);
				$data['inviteescount'] = count($data['invitees']);
				$data['inviteids'] = implode(',', array_keys($data['invitees']));
				$data['content'] = $this->smartyextended->view('groups_invitation', $data, true);
				echo json_encode($data);
		}
		function sendInvitations($ids, $groupId, $message = '')
		{
				$this->load->model('userModel');
				$this->groupsModel->updateInvitations($ids, $groupId, 'sent', $message);
				$userdetail = $this->groupsModel->getReceiverDetails($ids);
				// Here we need to write email code to send group invitation
				$username = '';
				foreach ($userdetail as $key => $valArr)
				{
						$uname = $valArr['username'];
						if ($valArr['username'] == '')
						{
								$uname = $valArr['receiver_email'];
						}
						$username .= '<br>' . $uname;
						// Here mail code need to be implemented
						$userDetails = array();
						$userDetails['name'] = $username;
						$userDetails['inv_id'] = $valArr['group_invitation_id'];
						$userDetails['user_id'] = $valArr['user_id'];
						$userDetails['email'] = ($valArr['username'] != '') ? $valArr['email'] : $valArr['receiver_email'];
						$userDetails['type'] = ($valArr['username'] != '') ? 'member' : 'non_member';
						$this->_sendNotification($userDetails, $groupId, $message);
						//
				}
				return $username;
		}
		function _sendNotification($userDetail, $groupId, $message = '', $member = true)
		{
				$this->load->model('settingsModel');
				$this->load->model('emailTemplateModel');
				$this->load->library('email');
				$this->load->model('userModel');
				$this->load->model('messageModel');
				$emailTemplate = $this->emailTemplateModel->readEmailTemplate('group_invitation');
				$settings = $this->settingsmodel->readSetting('admin_email, admin_name, site_name, site_title');
				$adminEmail = $settings['admin_email'];
				$adminName = $settings['admin_name'];
				$groupInfo = $this->groupsModel->getGroupInfo($groupId);
				$groupName = $groupInfo['group_name'];
				$attachUrl = base_url() . 'groups/view/' . $groupId . '/' . $userDetail['inv_id'] . '/';
				$splVars = array("~~senderName~~" => ucfirst($this->session->userdata('username')), "~~groupName~~" => $groupName, "~~message~~" => ($message == '') ? 'This is a request to you join this group.. ' : $message, "~~siteName~~" => $settings['site_title'], "~~attachURL~~" => $attachUrl, "~~adminEmail~~" => $adminEmail, "~~adminName~~" => $adminName);
				$subject = strtr($emailTemplate['template_subject'], $splVars);
				$message = strtr($emailTemplate['template_content'], $splVars);
				$email = $userDetail['email'];
				/*
				$fp = fopen('invite.txt','ab+');
				fwrite($fp, $email);
				fwrite($fp, $subject);
				fwrite($fp, $message);
				fclose($fp);
				*/
				$notificationStaus = 1;
				if ($userDetail['type'] == 'member')
				{
						$msgConfig['to_id'] = $userDetail['user_id'];
						$msgConfig['subject'] = $subject;
						$msgConfig['message'] = $message;
						$this->messageModel->sendMessage($msgConfig);
						$arrNotifications = $this->userModel->getUserNotifications($userDetail['user_id'], $this->notificationId);
						if (count($arrNotifications) > 0)
						{
								$notificationStaus = $arrNotifications[$this->notificationId];
						}
				}
				if ($notificationStaus == 0)
				{
						return;
				}
				$this->email->from($adminEmail, $adminName);
				$this->email->to($email);
				$this->email->subject($subject);
				$this->email->message(nl2br($message));
				$this->email->send();
		}
		function removeInvitation()
		{
				$userId = $this->input->post('user_id');
				$groupId = $this->input->post('group_id');
				$invitationId = $this->input->post('invitation_id');
				$this->groupsModel->removeInvitation($userId, $groupId, $invitationId);
				// For Invitaion List
				$data['invitees'] = $this->groupsModel->getMembers($groupId);
				$data['inviteescount'] = count($data['invitees']);
				$data['inviteids'] = implode(',', array_keys($data['invitees']));
				// For Friends List
				$groupFriends = $this->groupsModel->getFriendsInvitees($groupId, $this->userId);
				$data['groupsfriends'] = $groupFriends;
				$data['friendscount'] = count($groupFriends);
				$data['errmsg'] = '';
				$data['group_id'] = $groupId;
				$data['content'] = $this->smartyextended->view('groups_invitation', $data, true);
				$data['friendslist'] = $this->smartyextended->view('groups_friends', $data, true);
				echo json_encode($data);
		}
		function addedMembers()
		{
				$groupId = $this->input->post('group_id');
				$data['invitees'] = $this->groupsModel->getMembers($groupId);
				$data['inviteescount'] = count($data['invitees']);
				$data['group_id'] = $groupId;
				$data['inviteids'] = implode(',', array_keys($data['invitees']));
				$data['content'] = $this->smartyextended->view('groups_invitation', $data, true);
				echo json_encode($data);
		}
		function view($groupId, $invid = '')
		{
				if ($groupId == '') redirect('groups/mygroups');
				if (!ereg('^[0-9]+$', $groupId)) redirect('groups/mygroups');
				$data = array();
				$data['invitation_id'] = '';
				$groupInfo = $this->groupsModel->getInfo($groupId);
				if (count($groupInfo) == 0) redirect('groups/mygroups');
				$isadmin = $this->groupsModel->isAdmin($groupId, $this->userId);
				$isMember = $this->groupsModel->isGroupMember($groupId, $this->userId);
				/*
				if($groupInfo['group_type'] != 'open')
				{
				if($isadmin == 0 && $isMember == 0)
				{
				redirect('groups/mygroups');
				}
				}
				*/
				if ($isadmin == 0 && $isMember == 0)
				{
						if ((integer)$groupInfo['network_id'] > 0)
						{
								$this->load->model('networkmodel');
								if (!$this->networkmodel->isUserExist($groupInfo['network_id'], $this->userId))
								{
										$networkName = $this->networkmodel->getName($groupInfo['network_id']);
										$networkDetail = current($networkName);
										$networkNameStr = (strlen($networkDetail['network_name']) > 10) ? substr($networkDetail['network_name'], 0, 10) . '...' : $networkDetail['network_name'];
										$groupNameStr = (strlen($groupInfo['group_name']) > 15) ? substr($groupInfo['group_name'], 0, 15) . '...' : $groupInfo['group_name'];
										$this->session->set_flashdata('flash_msg', $this->lang->line('groups_not_in_network') . ' (' . $networkNameStr . ') ' . $this->lang->line('groups_not_in_network_view') . ' (' . $groupNameStr . ')');
										redirect('groups/mygroups/');
								}
						}
				}
				$this->load->model('userModel');
				$groupMembers = $this->groupsModel->getGroupMembers($groupId);
				$groupAdminId = $this->groupsModel->getAdmin($groupId);
				if ($isadmin != 1 && $isMember != 1)
				{
						if ($invid != '')
						{
								if (!ereg('^[0-9]+$', $invid))
								{
										redirect('groups/mygroups');
								}
								else
								{
										$invtationInfo = $this->groupsModel->getInvitationInfo($groupId, $this->userId, $invid);
										if (!$invtationInfo && $groupInfo['group_type'] != 'open') redirect('groups/mygroups');
										if ($invtationInfo)
										{
												$data['invitation_id'] = $invtationInfo['group_invitation_id'];
												$data['sender_id'] = $invtationInfo['sender_id'];
												$data['receiver_id'] = $invtationInfo['receiver_id'];
										}
										else
										{
												$data['invitation_id'] = '';
												$data['sender_id'] = ($groupAdminId === false) ? '' : $groupAdminId;
												$data['receiver_id'] = $this->userId;
										}
								}
						}
						else
						{
								$invtationInfo = $this->groupsModel->getInvitationInfo($groupId, $this->userId);
								if ($invtationInfo)
								{
										$data['invitation_id'] = $invtationInfo['group_invitation_id'];
										$data['sender_id'] = $invtationInfo['sender_id'];
										$data['receiver_id'] = $invtationInfo['receiver_id'];
								}
						}
				}
				if ($groupInfo['group_type'] == 'secret')
				{
						if ($isadmin == 0 && $isMember == 0 && trim($data['invitation_id']) == '')
						{
								$this->session->set_flashdata('flash_msg', $this->lang->line('groups_msg_non_member') . ' (' . $groupInfo['group_name'] . ')');
								redirect('groups/mygroups/');
						}
				}
				/*
				if($_POST)
				{
				print "<pre>";
				print_r($_POST);
				print "</pre>";
				}
				*/
				//$action 	= 	$this->input->post('hdnAction');
				$action = '';
				$leave = $this->input->post('leaveBtn_x');
				$join = $this->input->post('joinBtn_x');
				if ($leave !== false)
				{
						$action = 'leave';
				} elseif ($join !== false)
				{
						$action = 'join';
				}
				$groupType = $this->input->post('hdnType');
				if ($action !== '' && $groupType != false)
				{
						if ($action == 'leave')
						{
								$this->load->model('userModel');
								$userFeedSettings = $this->userModel->getUserFeedSetting();
								if (isset($userFeedSettings[10]) && $userFeedSettings[10] == 'yes')
								{
										//Load the minifeed model
										$this->load->model('minifeedmodel');
										$splVars = array('~~postedBy~~' => $this->session->userdata('username'), '~~groupName~~' => $groupInfo['group_name']);
										$this->minifeedmodel->postMiniFeed('LEAVE_GROUP', $splVars, array(base_url() . 'groups/view/' . $groupId . '/'));
								}
						}
						if ($groupType == 'open')
						{
								if ($action == 'join')
								{
										$invid = $this->input->post('hdnInvId');
										$sender = ($this->input->post('hdnSender') == '' or $this->input->post('hdnSender') == false) ? $groupAdminId : $this->input->post('hdnSender');
										$receiver = ($this->input->post('hdnReceiver') == '' or $this->input->post('hdnReceiver') == false) ? $this->userId : $this->input->post('hdnReceiver');
										$this->groupsModel->removeInvitation($receiver, $groupId);
										$this->groupsModel->joinGroup($groupId, $sender, $receiver);
										$this->session->set_flashdata('flash_msg', $this->lang->line('groups_msg_join_success'));
								} elseif ($action == 'leave')
								{
										$this->groupsModel->leaveGroup($groupId, $this->userId);
										$this->session->set_flashdata('flash_msg', $this->lang->line('groups_msg_remove_success'));
										if ($isadmin == 1)
										{
												$this->groupsModel->removeGroup($groupId);
												redirect('groups/mygroups');
										}
								}
						} elseif ($groupType == 'closed')
						{
								if ($action == 'join')
								{
										$sender = ($this->input->post('hdnSender') == '' or $this->input->post('hdnSender') == false) ? $groupAdminId : $this->input->post('hdnSender');
										$receiver = ($this->input->post('hdnReceiver') == '' or $this->input->post('hdnReceiver') == false) ? $this->userId : $this->input->post('hdnReceiver');
										$invid = $this->input->post('hdnInvId');
										$this->groupsModel->addMembers($groupId, $receiver, $sender, 'requested');
										$this->session->set_flashdata('flash_msg', $this->lang->line('groups_closed_request_msg_success'));
										/*
										if($invid != FALSE && ereg('^[0-9]+$',$invid))
										{
										$this->session->set_flashdata('flash_msg', $this->lang->line('groups_closed_request_msg_success'));
										}
										else
										{
										$this->session->set_flashdata('flash_msg', $this->lang->line('groups_closed_request_msg_success'));
										}
										*/
								} elseif ($action == 'leave')
								{
										$this->groupsModel->leaveGroup($groupId, $this->userId);
										$this->session->set_flashdata('flash_msg', 'Successfully leaved from this group...');
										if ($isadmin == 1)
										{
												$this->groupsModel->removeGroup($groupId);
												redirect('groups/mygroups');
										}
								}
						} elseif ($groupType == 'secret')
						{
								if ($action == 'join')
								{
										$sender = ($this->input->post('hdnSender') == '' or $this->input->post('hdnSender') == false) ? $groupAdminId : $this->input->post('hdnSender');
										$receiver = ($this->input->post('hdnReceiver') == '' or $this->input->post('hdnReceiver') == false) ? $this->userId : $this->input->post('hdnReceiver');
										$invid = $this->input->post('hdnInvId');
										$this->groupsModel->addMembers($groupId, $receiver, $sender, 'requested');
								} elseif ($action == 'leave')
								{
										$this->groupsModel->leaveGroup($groupId, $this->userId);
										$this->session->set_flashdata('flash_msg', $this->lang->line('groups_msg_remove_success'));
										if ($isadmin == 1)
										{
												$this->groupsModel->removeGroup($groupId);
												redirect('groups/mygroups');
										}
								}
						}
						// For Minifeed
						redirect('groups/view/' . $groupId . '/');
				}
				foreach ($groupMembers as $id => $userArray)
				{
						$groupMembers[$id]['avatar'] = $this->userModel->getAvatar($userArray['receiver_id'], true);
				}
				// Requested users List
				$requestedMembers = array();
				$requestcount = 0;
				if (($groupInfo['group_type'] == 'closed' || $groupInfo['group_type'] == 'secret') && $isadmin == 1)
				{
						$requestedMembers = $this->groupsModel->getRequests($groupId);
						$requestcount = count($requestedMembers);
				}
				$data['closedrequest'] = $requestedMembers;
				$data['requestcount'] = $requestcount;
				$data['groupinfo'] = $groupInfo;
				$data['members'] = $groupMembers;
				$data['memberscount'] = count($groupMembers);
				$data['isadmin'] = $isadmin;
				$data['ismember'] = $isMember;
				$data['group_id'] = $groupId;
				$data['group_image'] = $this->groupsModel->getGroupImage($groupId);
				$data['group_type'] = $groupInfo['group_type'];
				//Load the discussion board model
				$this->load->model('discussionboardmodel');
				//For discussion topic
				$data['discussionTopics'] = $this->discussionboardmodel->getDiscussionBoardTopic('group', $groupId, '', '', 'date_added', 0, 5);
				$data['discussionTopicsCount'] = count($data['discussionTopics']);
				$data['discussionTopicsTotal'] = $this->discussionboardmodel->getDiscussionBoardTopicCount('group', $groupId, '', '', 'date_added');
				//Load the wall model
				$this->load->model('wallmodel');
				//For wall
				$data['wall'] = $this->wallmodel->getWall('group', $groupId, 'wall_date desc', 0, 10);
				$data['wallCount'] = count($data['wall']);
				$data['wallTotal'] = count($this->wallmodel->getWall('group', $groupId));
				$this->smartyextended->view('groups_view', $data);
		}
		function requests($groupId)
		{
				if (!ereg('^[0-9]+$', $groupId)) redirect('groups/mygroups/');
				$data = array();
				$groupInfo = $this->groupsModel->getGroupInfo($groupId);
				if (count($groupInfo) == 0) redirect('groups/mygroups/');
				$isadmin = $this->groupsModel->isAdmin($groupId, $this->userId);
				if ($isadmin == 0) redirect('groups/mygroups/');
				$data['successMsg'] = '';
				$action = $this->input->post('hdnAction');
				if ($action !== false)
				{
						$receiver = $this->input->post('hdnId');
						$requests = $this->groupsModel->getRequests($groupId);
						$sender = $this->userId;
						if ($action == 'approve')
						{
								if ($receiver == 'all')
								{
										foreach ($requests as $key => $valarr)
										{
												if (intval($valarr['receiver_id']) != 0)
												{
														$this->groupsModel->joinGroup($groupId, $sender, $valarr['receiver_id']);
														$this->groupsModel->removeInvitation($valarr['receiver_id'], $groupId);
												}
										}
								}
								else
								{
										$this->groupsModel->joinGroup($groupId, $sender, $receiver);
										$this->groupsModel->removeInvitation($receiver, $groupId);
										$this->session->set_flashdata('flash_msg', $this->lang->line('groups_msg_approve_success'));
										$data['successMsg'] = $this->lang->line('groups_msg_approve_success');
								}
						}
						else
						{
								if ($receiver == 'all')
								{
										$this->groupsModel->removeAllInvitations($groupId);
								}
								else
								{
										$this->groupsModel->removeInvitation($receiver, $groupId);
										$this->session->set_flashdata('flash_msg', $this->lang->line('groups_msg_reject_success'));
										$data['successMsg'] = $this->lang->line('groups_msg_reject_success');
								}
						}
						redirect('groups/requests/' . $groupId . '/');
				}
				//Load the pagination model
				$this->load->model('paginationmodel');
				//Load the pagination language file
				$this->lang->load('pagination', $this->config->item('language_code'));
				$perPage = $this->paginationmodel->getPerPage('groups');
				$start = (trim($this->uri->segment(4)) != '' && is_numeric($this->uri->segment(4)) && $this->uri->segment(4) > 0) ? $this->uri->segment(4) : 1;
				$start = ($start - 1) * $perPage;
				$requestedMembers = $this->groupsModel->getRequests($groupId, 'requested', $start, $perPage);
				$this->load->model('usermodel');
				foreach ($requestedMembers as $key => $valArr)
				{
						$requestedMembers[$key]['avatar'] = $this->usermodel->getAvatar($valArr['receiver_id'], true);
				}
				$requestcount = count($requestedMembers);
				if ($requestcount > 0)
				{
						$data['resultTotal'] = $this->groupsModel->getRequestsCount($groupId, 'requested');
						$data['currentPage'] = (trim($this->uri->segment(4)) != '' && is_numeric($this->uri->segment(4))) ? $this->uri->segment(4) : 1;
						$data['totalPages'] = ($data['resultTotal'] > $perPage) ? ceil(($data['resultTotal'] / $perPage)) : 0;
						$data['pageUrl'] = base_url() . 'groups/requests/' . $groupId . '/';
				}
				$data['group_name'] = $groupInfo['group_name'];
				$data['group_id'] = $groupId;
				$data['group_type'] = $groupInfo['group_type'];
				$data['closedrequest'] = $requestedMembers;
				$data['requestcount'] = $requestcount;
				$this->smartyextended->view('groups_requests', $data);
		}
		function members($groupId = '')
		{
				$this->load->model('userModel');
				$groupInfo = $this->groupsModel->getGroupInfo($groupId);
				if (count($groupInfo) == 0) redirect('groups/mygroups/');
				$isadmin = $this->groupsModel->isAdmin($groupId, $this->userId);
				if ($groupInfo['group_type'] !== 'open')
				{
						if ($isadmin !== 1) redirect('groups/mygroups/');
				}
				else
				{
						$isMember = $this->groupsModel->isGroupMember($groupId, $this->userId);
						if ($isMember == 0) redirect('groups/mygroups/');
				}
				// Inviting peoples with mail ids who may be registered or non registered - Begin
				$invalidMails = array();
				$validMails = array();
				$email = $this->input->post('mails');
				if ($email != false && $email != '')
				{
						$emailArr = split(',', $email);
						$this->load->helper('validation');
						$this->load->model('userModel');
						foreach ($emailArr as $key => $mail)
						{
								if (isValidEmail($mail))
								{
										$mailResult = $this->userModel->chkUserEmail($mail);
										if ($mailResult)
										{
												$validMails[] = array('registered' => 1, 'user_id' => $mailResult['user_id'], 'name' => $mailResult['username'], 'email' => $mail);
										}
										else
										{
												$validMails[] = array('registered' => 0, 'name' => $mail, 'email' => $mail);
										}
								}
								else
								{
										$invalidMails[] = $mail;
								}
						}
						if (count($validMails) > 0)
						{
								foreach ($validMails as $key => $valArr)
								{
										if ($valArr['registered'] == 1)
										{
												$receiver = $valArr['user_id'];
												$sender = $this->userId;
												$receiveremail = $valArr['email'];
												$isMember = $this->groupsModel->isGroupMember($groupId, $receiver);
												//$flag						=	$this->groupsModel->addMembers($groupId,$receiver,$sender,'requested',TRUE,$receiveremail);
												//$validMails[$key]['flag']	= 	($isMember == 0) ? $this->groupsModel->addMembers($groupId,$receiver,$sender,'requested',TRUE,$receiveremail) : 2 ;
												$validMails[$key]['flag'] = ($isMember == 0) ? $this->groupsModel->addMembers($groupId, $receiver, $sender, 'not sent', true, $receiveremail) : 2;
												//echo '<br>', $flag , '--' , $valArr['email'];
										}
										else
										{
												$receiver = 0;
												$sender = $this->userId;
												$receiveremail = $valArr['email'];
												//$flag						=	$this->groupsModel->addMembers($groupId,$receiver,$sender,'requested',FALSE,$receiveremail);
												$flag = $this->groupsModel->addMembers($groupId, $receiver, $sender, 'not sent', false, $receiveremail);
												//echo '<br>', $flag , '--' , $valArr['email'];
												$validMails[$key]['flag'] = $flag;
										}
								}
						}
				}
				// End
				$data = array();
				$data['isadmin'] = $isadmin;
				$groupFriends = $this->groupsModel->getFriendsInvitees($groupId, $this->userId);
				$data['groupsfriends'] = $groupFriends;
				$data['friendscount'] = count($groupFriends);
				$data['group_id'] = $groupId;
				$data['status'] = ($this->input->post('hdnStatus') == false) ? 'accepted' : $this->input->post('hdnStatus');
				$data['errmsg'] = '';
				$data['invitees'] = $this->groupsModel->getMembers($groupId);
				$data['inviteescount'] = count($data['invitees']);
				$data['inviteids'] = implode(',', array_keys($data['invitees']));
				$data['friendslist'] = $this->smartyextended->view('groups_friends', $data, true);
				$data['content'] = $this->smartyextended->view('groups_invitation', $data, true);
				$statusFilter = ($this->input->post('viewfilter') != false && $this->input->post('viewfilter') !== '') ? $this->input->post('viewfilter') : 'accepted';
				if ($statusFilter == 'sent') $data['members'] = $this->groupsModel->getMembers($groupId, $statusFilter);
				else  $data['members'] = $this->groupsModel->getGroupMembers($groupId, $statusFilter);
				$data['membercount'] = count($data['members']);
				$data['memlist'] = $this->smartyextended->view('groups_memlist', $data, true);
				$data['invalidmails'] = $invalidMails;
				$data['validmails'] = $validMails;
				$this->smartyextended->view('groups_members', $data);
		}
		function removephoto($groupId)
		{
				if (ereg('^[0-9]+$', $groupId))
				{
						$groupInfo = $this->groupsModel->getGroupInfo($groupId);
						if (count($groupInfo) == 0) redirect('groups/picture/' . $groupId . '/');
						$groupPath = APPPATH . 'content/groups/' . $groupId . '.' . $groupInfo['group_photo_path'];
						@unlink($groupPath);
						$groupThumbPath = APPPATH . 'content/groups/' . $groupId . '_thumb.' . $groupInfo['group_photo_path'];
						@unlink($groupThumbPath);
						$groupViewPath = APPPATH . 'content/groups/' . $groupId . '_view.' . $groupInfo['group_photo_path'];
						@unlink($groupViewPath);
						$this->groupsModel->storePhotos($groupId, '');
						redirect('groups/picture/' . $groupId . '/');
				}
				else
				{
						redirect('groups/mygroups/');
				}
		}
		function browse($netId = '', $catId = '', $subCatId = '')
		{
				$data = array();
				$this->load->model('userModel');
				if (!ereg('^[0-9]+$', $netId))
				{
						$netId = '';
				}
				if (!ereg('^[0-9]+$', $catId))
				{
						$catId = '';
				}
				if (!ereg('^[0-9]+$', $subCatId))
				{
						$subCatId = '';
				}
				$arrGroupType = $this->groupsModel->getGroupCategory();
				$arrNetworks = $this->userModel->networks($this->userId);
				$data['networkscount'] = count($arrNetworks);
				$data['usernetworks'] = $arrNetworks;
				if ($netId == '')
				{
						$networkId = 0;
				}
				else
				{
						$networkId = $netId;
				}
				if ($catId == '')
				{
						$catId = 0;
				}
				else
				{
						$mainCatId = $catId;
				}
				if ($subCatId == '')
				{
						$subCatId = 0;
				}
				else
				{
						$subCatId = $subCatId;
				}
				$networkId = ($this->input->post('network') == false) ? $networkId : $this->input->post('network');
				$catId = ($this->input->post('group_category') == false) ? $catId : $this->input->post('group_category');
				$subCatId = ($this->input->post('hdnSubCategory') == false) ? $subCatId : $this->input->post('hdnSubCategory');
				if ($catId > 0) $data['sub_categories'] = $this->groupsModel->getSubcategories($catId);
				else  $data['sub_categories'] = array();
				$this->load->model('paginationmodel');
				//Load the pagination language file
				$this->lang->load('pagination', $this->config->item('language_code'));
				$perPage = $this->paginationmodel->getPerPage('groups');
				$start = (trim($this->uri->segment(6)) != '' && is_numeric($this->uri->segment(6)) && $this->uri->segment(6) > 0) ? $this->uri->segment(6) : 1;
				$start = ($start - 1) * $perPage;
				$groupResult = $this->groupsModel->getGroups($this->userId, $networkId, $catId, $subCatId, $start, $perPage);
				if (count($groupResult) > 0)
				{
						$this->load->model('networkmodel');
						foreach ($groupResult as $key => $valArr)
						{
								$groupResult[$key]['group_image'] = $this->groupsModel->getGroupImage($key, true);
								$groupResult[$key]['member_flag'] = $this->groupsModel->isGroupMember($key, $this->userId);
								if ($groupResult[$key]['network_id'] > 0)
								{
										if ($this->networkmodel->isUserExist($groupResult[$key]['network_id'], $this->userId) == true) $groupResult[$key]['network_flag'] = 1;
										else  $groupResult[$key]['network_flag'] = 0;
								}
								else
								{
										$groupResult[$key]['network_flag'] = 1;
								}
						}
				}
				$data['resultTotal'] = $this->groupsModel->getGroupsCount($this->userId, $networkId, $catId, $subCatId);
				/*
				if($networkId == 0)
				{
				$data['currentPage']		= 	(trim($this->uri->segment(4)) != '' && is_numeric($this->uri->segment(4))) ? $this->uri->segment(4) : 1;
				if($catId == 0)
				{

				$data['currentPage']		= 	(trim($this->uri->segment(4)) != '' && is_numeric($this->uri->segment(4))) ? $this->uri->segment(4) : 1;
				}
				else
				{
				$data['currentPage']		= 	(trim($this->uri->segment(4)) != '' && is_numeric($this->uri->segment(4))) ? $this->uri->segment(4) : 1;
				}
				}
				else
				{

				}

				*/
				$data['totalPages'] = ($data['resultTotal'] > $perPage) ? ceil(($data['resultTotal'] / $perPage)) : 0;
				$data['pageUrl'] = base_url() . 'groups/browse/' . $networkId . '/' . $catId . '/' . $subCatId . '/';
				$data['currentPage'] = (trim($this->uri->segment(6)) != '' && is_numeric($this->uri->segment(6))) ? $this->uri->segment(6) : 1;
				$data['groupsresult'] = $groupResult;
				$data['resultcounts'] = count($data['groupsresult']);
				$data['groupcat'] = $arrGroupType;
				$data['sub_cat_id'] = $subCatId;
				$this->smartyextended->view('groups_browse', $data);
		}
		function join()
		{
				$groupId = $this->input->post('group_id');
				$receiverId = $this->input->post('user_id');
				$data = array();
				$data['message'] = '';
				if ($groupId != false && $receiverId != false)
				{
						$adminDetail = $this->groupsModel->getGroupMembers($groupId, 'accepted', 'Y');
						$adminRow = current($adminDetail);
						$adminId = $adminRow['sender_id'];
						$sender = $adminId;
						$receiver = $receiverId;
						$this->groupsModel->joinGroup($groupId, $sender, $receiver);
						$data['message'] = 'Successfully joined the group....';
				}
				echo json_encode($data);
		}
		function leave()
		{
				$groupId = $this->input->post('group_id');
				$receiverId = $this->input->post('user_id');
				$data = array();
				$data['message'] = '';
				$groupInfo = $this->groupsModel->getInfo($groupId);
				if ($groupId != false && $receiverId != false && count($groupInfo) > 0)
				{
						$this->groupsModel->leaveGroup($groupId, $receiverId);
						$data['message'] = $this->lang->line('groups_msg_remove_success');
						$isadmin = $this->groupsModel->isAdmin($groupId, $receiverId);
						if ($isadmin == 1)
						{
								$this->groupsModel->removeGroup($groupId);
								$data['message'] = $this->lang->line('groups_msg_delete_success');
						}
						$this->load->model('userModel');
						$userFeedSettings = $this->userModel->getUserFeedSetting();
						if (isset($userFeedSettings[10]) && $userFeedSettings[10] == 'yes')
						{
								//Load the minifeed model
								$this->load->model('minifeedmodel');
								$splVars = array('~~postedBy~~' => $this->session->userdata('username'), '~~groupName~~' => $groupInfo['group_name']);
								$this->minifeedmodel->postMiniFeed('LEAVE_GROUP', $splVars, array(base_url() . 'groups/view/' . $groupId . '/'));
						}
				}
				echo json_encode($data);
		}
		function picture($groupId = '')
		{
				$data = array();
				$this->load->library('validation');
				$this->_photoRules();
				if (!ereg('^[0-9]+$', $groupId)) redirect('groups/managegroups/');
				$msg = '';
				if ($this->validation->run() == false)
				{
						//Oops! validation Error.
						$data['validationError'] = $this->validation->error_string;
				}
				else
				{
						if ($_FILES)
						{
								$msg = $this->storePhotos($groupId);
						}
						if ($msg == '')
						{
								$this->session->set_flashdata('flash_msg', $this->lang->line('groups_upload_picture_sucess'));
								redirect('groups/members/' . $groupId . '/');
								exit;
						}
						else
						{
								$outputData = array();
								$outputData['validationError'] = $msg;
								$outputData['group_id'] = $groupId;
								$outputData['groupimage'] = $this->groupsModel->getGroupImage($groupId, false);
								$this->smartyextended->view('groups_picture', $outputData);
								exit;
						}
				}
				if ($groupId != '' && ereg('^[0-9]+$', $groupId))
				{
						$groupInfo = $this->groupsModel->getGroupInfo($groupId);
						if (count($groupInfo) == 0)
						{
								redirect('groups/managegroups/');
						}
						else
						{
								$isadmin = $this->groupsModel->isAdmin($groupId, $this->userId);
								if ($isadmin == 1) $data['groupimage'] = $this->groupsModel->getGroupImage($groupId, false);
								else  redirect('groups/managegroups/');
						}
				}
				if (trim($groupId) == '') $data['groupimage'] = $this->groupsModel->getGroupImage(0, false);
				$data['group_id'] = $groupId;
				$data['successmsg'] = $msg;
				$this->smartyextended->view('groups_picture', $data);
		}
		function _resizeImage($imgFile, $width, $height)
		{
				$this->load->library('image_lib');
				//$config['image_library'] 	= 'GD2';
				$config['source_image'] = $imgFile;
				$config['create_thumb'] = true;
				$config['maintain_ratio'] = true;
				$config['width'] = $width;
				$config['height'] = $height;
				$config['allowed_types'] = 'jpg|jpeg|bmp|gif|png';
				$this->image_lib->initialize($config);
				if (!$this->image_lib->resize())
				{
						return $this->image_lib->display_errors('', '');
				}
				/*
				else
				return TRUE;
				*/
		}
		function storePhotos($groupId)
		{
				$tmpName = $_FILES['userfile']['tmp_name'];
				$fileName = $_FILES['userfile']['name'];
				$error = $_FILES['userfile']['error'];
				$size = $_FILES['userfile']['size'];
				$msg = '';
				$this->load->library('ImageTransform');
				if (@$_FILES['userfile']['name'] == '')
				{
						$msg = $this->lang->line('groups_validation_file_select_msg');
						return $msg;
				}
				if (!($_FILES['userfile']['type'] == 'image/jpeg' || $_FILES['userfile']['type'] == 'image/pjpeg' || $_FILES['userfile']['type'] == 'image/x-png' || $_FILES['userfile']['type'] == 'image/gif' || $_FILES['userfile']['type'] == 'image/png'))
				{
						$msg .= $_FILES['userfile']['name'] . $this->lang->line('groups_validation_file_type_msg') . "<br>";
						return $msg;
				}
				if (intval($_FILES['userfile']['size']) > 4194304)
				{
						$msg .= $_FILES['userfile']['name'] . $this->lang->line('groups_validation_file_size_msg') . "<br>";
						return $msg;
				}
				if (trim($fileName) != '' and $error === 0 and $size > 0)
				{
						$arrSplitedName = split("\.", $fileName);
						$extension = trim($arrSplitedName[count($arrSplitedName) - 1]);
						$newFileName = trim($groupId) . '.' . $extension;
						$pathToUpload = APPPATH . 'content/groups/';
						$path = $pathToUpload . $newFileName;
						$this->groupsModel->storePhotos($groupId, $extension);
						$msg = '';
						if (!move_uploaded_file($tmpName, $path))
						{
								$msg = $this->lang->line('groups_msg_upload_fail');
						}
						else
						{
								$imgFile = APPPATH . 'content/groups/' . $newFileName;
								$width = '50';
								$height = '50';
								//$msg 	= $this->_resizeImage($imgFile, $width, $height);
								$destination_path = BASEPATH . '../application/content/groups/';
								$destination_file = $path;
								$destination_thumb_file = $pathToUpload . trim($groupId) . '_thumb.' . $extension;
								$this->imagetransform->sourceFile = $destination_file;
								$this->imagetransform->targetFile = $pathToUpload . trim($groupId) . '_thumb.' . $extension;
								$this->imagetransform->resizeToWidth = $this->config->item('avatar_thumb_width');
								$this->imagetransform->resizeToHeight = $this->config->item('avatar_thumb_height');
								$this->imagetransform->resize();
								$this->imagetransform->sourceFile = $destination_file;
								$this->imagetransform->targetFile = $pathToUpload . trim($groupId) . '_view.' . $extension;
								$this->imagetransform->resizeToWidth = 180;
								$this->imagetransform->resizeToHeight = 180;
								$this->imagetransform->resize();
						}
				}
				else
				{
						$msg = $this->lang->line('groups_validation_file_select_msg');
				}
				return $msg;
		}
		function _photoRules()
		{
				$rules['agree'] = 'required|callback_validateTerms';
				$rules['userfile'] = 'callback_validateFiles';
				$this->validation->set_rules($rules);
				$fields['userfile'] = 'Photo';
				$fields['agree'] = ' Terms and Conditions ';
				$this->validation->set_fields($fields);
		}
		function validateTerms()
		{
				if ($this->input->post('agree') == false)
				{
						$this->validation->set_message('validateTerms', $this->lang->line('groups_validation_terms_agree'));
						return false;
				}
				else
				{
						return true;
				}
		}
		function validateFiles()
		{
				$msg = "";
				if ($_FILES['userfile']['error'] == 0 && $_FILES['userfile']['error'] != 4 && trim($_FILES['userfile']['name']) != '')
				{
						//if(!($_FILES['file'.$i]['type'] == 'image/jpeg' || $_FILES['file'.$i]['type'] == 'image/pjpeg' || $_FILES['file'.$i]['type'] == 'image/x-png' || $_FILES['file'.$i]['type'] == 'image/gif' || $_FILES['file'.$i]['type'] == 'image/png' || $_FILES['file'.$i]['type'] == 'image/bmp'))
						if (!($_FILES['userfile']['type'] == 'image/jpeg' || $_FILES['userfile']['type'] == 'image/pjpeg' || $_FILES['userfile']['type'] == 'image/x-png' || $_FILES['file' . $i]['type'] == 'image/gif' || $_FILES['userfile']['type'] == 'image/png'))
						{
								$msg .= $_FILES['userfile']['name'] . $this->lang->line('groups_validation_file_type_msg') . "<br>";
						}
						if (intval($_FILES['userfile']['size']) > 4194304)
						{
								$msg .= $_FILES['userfile']['name'] . $this->lang->line('groups_validation_file_size_msg') . "<br>";
						}
				}
				else
				{
						$msg = $this->lang->line('groups_validation_file_select_msg');
				}
				if (trim($msg) != '')
				{
						$msg = "<br>" . $msg;
						$this->validation->set_message('validateFiles', $msg);
						return false;
				}
				else
				{
						return true;
				}
		}
		function getSubcategory()
		{
				$mainCatId = $this->input->post('cat_id');
				$subcatArray = array();
				if ($mainCatId != false)
				{
						$subcatArray = $this->groupsModel->getSubcategories($mainCatId);
				}
				echo (json_encode($subcatArray));
		}
		function _formRules()
		{
				$rules['group_name'] = 'trim|required|min_length[5]';
				$rules['group_desc'] = 'trim|required|min_length[10]';
				if ($this->input->post('cntNetworks') != false) $rules['network'] = 'callback__checkNetwork';
				$rules['group_category'] = 'callback__isValidCategory';
				$rules['group_sub_category'] = 'callback__isValidSubCategory';
				$rules['group_office'] = 'callback__isValidOfficeNo';
				$rules['group_website'] = 'callback__isURL';
				$rules['group_email'] = 'callback__isMail';
				$this->validation->set_rules($rules);
				$fields['group_name'] = $this->lang->line('group_group_name');
				$fields['group_desc'] = $this->lang->line('group_description');
				if ($this->input->post('cntNetworks') != false) $fields['network'] = $this->lang->line('group_network');
				$fields['group_category'] = $this->lang->line('groups_validation_group_cat');
				$fields['group_sub_category'] = $this->lang->line('groups_validation_group_sub_cat');
				$fields['group_office'] = $this->lang->line('groups_office_no');
				$fields['group_website'] = $this->lang->line('groups_validation_url');
				$fields['group_email'] = $this->lang->line('group_email');
				$this->validation->set_fields($fields);
		}
		function _checkNetwork($network)
		{
				if (trim($network) != '-1')
				{
						return true;
				}
				else
				{
						$this->validation->set_message('_checkNetwork', $this->lang->line('groups_validation_select') . ' %s ');
						return false;
				}
		}
		function _isValidOfficeNo($group_office)
		{
				if (trim($group_office) != '')
				{
						if (!ereg("^[0-9]+$", $group_office))
						{
								$this->validation->set_message('_isValidOfficeNo', $this->lang->line('groups_validation_the') . ' %s ' . $this->lang->line('groups_validation_not_valid'));
								return false;
						}
						else  return true;
				}
				else  return true;
		}
		function _isURL($group_website)
		{
				$pattern = "^(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?$";
				$pattern = "^(http[s]?:\/\/|http:\/\/www.|https:\/\/www.|ftp:\/\/www.|www.){1}([a-zA-Z0-9\-]+)(\.[a-zA-Z\/\?]+){1,2}(a-zA-Z\.\/\?\&\#=)*";
				if (trim($group_website) != '')
				{
						if (!ereg($pattern, $group_website))
						{
								$this->validation->set_message('_isURL', $this->lang->line('groups_validation_the') . ' %s ' . $this->lang->line('groups_validation_not_valid'));
								return false;
						}
						else
						{
								return true;
						}
				}
				else
				{
						return true;
				}
		}
		function _isMail($group_email)
		{
				$pattern = "^[a-zA-Z0-9]([a-zA-Z0-9]*\_[a-zA-Z0-9]+)*([a-zA-Z0-9\-]*\.[a-zA-Z0-9\-]+)*[a-zA-Z0-9]*@[a-zA-Z0-9]{2,}\.[a-zA-Z0-9]{2,}(\.[a-zA-Z0-9]{2,})?$";
				if (trim($group_email) != '')
				{
						if (!ereg($pattern, $group_email))
						{
								$this->validation->set_message('_isMail', $this->lang->line('groups_validation_the') . ' %s ' . $this->lang->line('groups_validation_not_valid'));
								return false;
						}
						else
						{
								return true;
						}
				}
				else
				{
						return true;
				}
		}
		function _isValidCategory($group_category)
		{
				if (trim($group_category) == '0')
				{
						$this->validation->set_message('_isValidCategory', $this->lang->line('groups_validation_select') . ' %s ');
						return false;
				}
				else
				{
						return true;
				}
		}
		function _isValidSubCategory($group_sub_category)
		{
				if (trim($group_sub_category) == '0')
				{
						$this->validation->set_message('_isValidSubCategory', $this->lang->line('groups_validation_select') . ' %s ');
						return false;
				}
				else
				{
						return true;
				}
		}
}
?>