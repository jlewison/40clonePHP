<?php include('restrict.php'); include('../settings.php'); require_once('../Connections/apound.php'); ?>
<?php
$currentPage = $_SERVER["PHP_SELF"];

$maxRows_BIDLIST = 10;
$pageNum_BIDLIST = 0;
if (isset($_GET['pageNum_BIDLIST'])) {
  $pageNum_BIDLIST = $_GET['pageNum_BIDLIST'];
}
$startRow_BIDLIST = $pageNum_BIDLIST * $maxRows_BIDLIST;

mysql_select_db($database_apound, $apound);
$query_BIDLIST = "SELECT * FROM main WHERE main.site <> '' ORDER BY dtu ASC";
$query_limit_BIDLIST = sprintf("%s LIMIT %d, %d", $query_BIDLIST, $startRow_BIDLIST, $maxRows_BIDLIST);
$BIDLIST = mysql_query($query_limit_BIDLIST, $apound) or die(mysql_error());
$row_BIDLIST = mysql_fetch_assoc($BIDLIST);

if (isset($_GET['totalRows_BIDLIST'])) {
  $totalRows_BIDLIST = $_GET['totalRows_BIDLIST'];
} else {
  $all_BIDLIST = mysql_query($query_BIDLIST);
  $totalRows_BIDLIST = mysql_num_rows($all_BIDLIST);
}
$totalPages_BIDLIST = ceil($totalRows_BIDLIST/$maxRows_BIDLIST)-1;

$queryString_BIDLIST = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_BIDLIST") == false && 
        stristr($param, "totalRows_BIDLIST") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_BIDLIST = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_BIDLIST = sprintf("&totalRows_BIDLIST=%d%s", $totalRows_BIDLIST, $queryString_BIDLIST);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Manage Listings - Link Bid Script Admin Panel</title>
<script type="text/javascript">
<!--
function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}
//-->
</script>
<link rel="shortcut icon" href="img/favicon.ico" />
<link rel="stylesheet" type="text/css" href="admin.css" />
<style type="text/css">
<!--
.style86 {
	font-size: 9px;
	color: #666666;
}
.style87 {color: #FFFFFF}
.style88 {
	font-size: 10px;
	font-family: Arial, Helvetica, sans-serif;
	font-weight: bold;
}
-->
</style>
</head>

<body>
<?php include('header_tpl.php'); ?>
<h2>Manage Listings</h2>
      <table width="770"  border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr>
          <td width="770"><?php $x = getenv("HTTP_HOST").getenv("REQUEST_URI"); echo("<font color=white>$x</font>"); ?></td>
        </tr>
      </table>
      <table width="770"  border="0" align="center" cellpadding="3" cellspacing="1" bgcolor="#FFFFFF">
        <tr>
          <td width="760" valign="top"><table width="760" border="0" align="center" cellpadding="6" cellspacing="1" id="main">
              <tr align="center">
                <td colspan="11">
                <?php $upd = $_GET[upd]; if($upd == 'Y') { echo("<div align='center'><font color='red'><b>Update ... DONE</b></font></div>"); } else { } ?>
                <form action="search.php" method="post" name="form1" class="style63">
                    <strong>Search:</strong>
                    <input name="id" type="text" id="id" size="30" maxlength="6">
                    <input type="submit" name="Submit" class="login-but" value="Search">
              please insert <strong>BID ID</strong>
                </form></td>
              </tr>
			  <tr bgcolor="#FFFFFF" class="style80">
          		<td colspan="8"><a href="add_listing.php" class="style82">add new listing</a> </td>
			  </tr>
              <tr bgcolor="#FFFF00">
                <td><span class="style80">ID </span></td>
                <td><span class="style80">Letter</span></td>
                <td class="style80">Category</td>
                <td><span class="style80">Site</span></td>
                <td><span class="style80">Title</span></td>
                <!-- <td><span class="style18">Description 1 </span></td> -->
                <!-- <td><span class="style18">Description 2 </span></td> -->
                <td><span class="style80">Bid</span></td>
                <td><span class="style80">Live?</span></td>
                <!-- <td><span class="style18">Paid?</span></td> -->
                <td><span class="style80">Edit</span></td>
                <td><span class="style80">Suspend</span></td>
                <td><span class="style80"> Activate</span></td>
                <td><span class="style80">Delete</span></td>
              </tr>
              <?php do { ?>
              <tr class="tr_bottom">
                <td class="tr_bottom"><span class="style76"><?php echo $row_BIDLIST['dtu']; ?></span></td>
                <td><span class="style76"><?php echo $row_BIDLIST['categ']; ?></span></td>
                <td><?php $necatg = $row_BIDLIST['maincategory']; ?>
                    <?php
mysql_select_db($database_apound, $apound);
$query_CKNID = "SELECT * FROM categorylisting WHERE catlistid = '$necatg'";
$CKNID = mysql_query($query_CKNID, $apound) or die(mysql_error());
$row_CKNID = mysql_fetch_assoc($CKNID);
$totalRows_CKNID = mysql_num_rows($CKNID);
?>
                    <span class="style76"><?php echo $row_CKNID['categoryname'];?></span> </td>
                <td width="100">
<a href="<?php echo $row_BIDLIST['site']; ?>" title="Click to visit the site <?php echo $row_BIDLIST['site']; ?>" target="_blank" >
<?php
/* $text = $row_BIDLIST['site'];
$newtext = wordwrap($text, 8, "\n", 1);
echo $newtext; */
$text = $row_BIDLIST['site'];
echo substr("$text", 0, 30);
?>
</a>
				<?php
                $fip = $row_BIDLIST['gep_ip'];
				if($fip <> '') { ?>
                <br><span class="style86">from<span class="style87">_</span>IP:<?php echo $row_BIDLIST['gep_ip']; ?> </span>
				<?php }
				else {}
				?>                </td>
                <td><span class="style76"><?php echo $row_BIDLIST['title']; ?></span></td>
                <!-- <td><span class="style12"><?php echo $row_BIDLIST['descr1']; ?></span></td> -->
                <!-- <td><span class="style12"><?php echo $row_BIDLIST['descr2']; ?></span></td> -->
                <td><span class="style76"><?php echo $row_BIDLIST['bid']; ?></span></td>
                <td><span class="style76">
                  <?php $live = $row_BIDLIST['avail']; if($live =='Y') { print'<img src="img/ico-live.gif" alt="Active" />'; } else { print'<img src="img/ico-pending.gif" alt="Pending" />'; } ?>
                </span></td>
                <!-- <td><span class="style12"><?php echo $row_BIDLIST['paid']; ?></span></td> -->
                <td align="center"><a href="<?php echo("$path");?>linkadmin/edit.php?id=<?php echo $row_BIDLIST['dtu'];?>" title="Click here to Edit"><img src="img/ico-edit.gif" alt="Edit" /></a></td>
                <td align="center"><a href="<?php echo("$path");?>linkadmin/suspend.php?id=<?php echo $row_BIDLIST['dtu'];?>&x=<?php echo("$x");?>" title="Click here to Suspend">
                  <?php if($live =='Y') { print'<img src="img/ico-suspend.gif" alt="Suspend" />'; } else { print''; } ?>
                </a></td>
                <td align="center"><a href="<?php echo("$path");?>linkadmin/activate.php?id=<?php echo $row_BIDLIST['dtu'];?>&x=<?php echo("$x");?>" title="Click here to Activate">
                  <?php if($live =='N') { print'<img src="img/ico-activate.png" alt="Activate" />'; } else { print''; } ?>
                </a><br>
<?php
$BLID = $row_BIDLIST['dtu'];

if($live =='N' and $fmwb == 'Y' and $fremode == 'Y') { ?> <a href="#" onclick="MM_openBrWindow('cbl.php?BLID=<?php echo("$BLID");?>','checkbacklink','width=500,height=100')">Check Back Link</a> <?php } else { } ?>


</td>
                <td align="center"><a href="<?php echo("$path");?>linkadmin/delete.php?id=<?php echo $row_BIDLIST['dtu'];?>&x=<?php echo("$x");?>" title="Click here to Delete"><img src="img/ico-delete.gif" alt="Delete" /></a></td>
              </tr>
              <tr bgcolor="#CCCCCC">
                <td height="1" colspan="11"></td>
              </tr>
              <?php } while ($row_BIDLIST = mysql_fetch_assoc($BIDLIST)); ?>
            </table>
              <table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0">
                <tr>
                  <td>&nbsp;</td>
                </tr>
              </table>
              <table border="0" align="center" id="main">
                <tr>
                  <td align="center"><?php if ($pageNum_BIDLIST > 0) { // Show if not first page ?>
                      <span class="style81"><a href="<?php printf("%s?pageNum_BIDLIST=%d%s", $currentPage, 0, $queryString_BIDLIST); ?>" class="style81">First</a>&nbsp;&nbsp;
                      <?php } // Show if not first page ?>
                    </span></td>
                  <td align="center"><?php if ($pageNum_BIDLIST > 0) { // Show if not first page ?>
                      <span class="style81"><a href="<?php printf("%s?pageNum_BIDLIST=%d%s", $currentPage, max(0, $pageNum_BIDLIST - 1), $queryString_BIDLIST); ?>" class="style81">Previous</a>
                      <?php } // Show if not first page ?>
&nbsp;&nbsp; </span></td>
                  <td align="center"><?php if ($pageNum_BIDLIST < $totalPages_BIDLIST) { // Show if not last page ?>
                      <span class="style81"><a href="<?php printf("%s?pageNum_BIDLIST=%d%s", $currentPage, min($totalPages_BIDLIST, $pageNum_BIDLIST + 1), $queryString_BIDLIST); ?>" class="style81">Next</a>
                      <?php } // Show if not last page ?>
&nbsp;&nbsp; </span></td>
                  <td align="center"><?php if ($pageNum_BIDLIST < $totalPages_BIDLIST) { // Show if not last page ?>
                      <span class="style81"><a href="<?php printf("%s?pageNum_BIDLIST=%d%s", $currentPage, $totalPages_BIDLIST, $queryString_BIDLIST); ?>" class="style81">Last</a>
                      <?php } // Show if not last page ?>
&nbsp;&nbsp; </span></td>
                </tr>
            </table></td>
        </tr>
      </table>
<?php include('footer_tpl.php'); ?>
</body>
</html>
<?php
mysql_free_result($BIDLIST);
?>
