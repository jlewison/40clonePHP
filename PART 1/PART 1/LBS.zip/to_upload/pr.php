<?php
/* function get_alexa($url){ 
    $site = fopen('http://services.velnetweb.co.uk/backlinks/alexa.php?url='.urlencode($url),'r'); 
    while($cont = fread($site,1024657)){ 
        $total .= $cont; 
    } 
    fclose($site); 
    $match_expression = '/(.*)/'; 
    preg_match($match_expression,$total,$matches); 
    return $matches[0]; 
} */

function get_alexa($url){ 
$ch = curl_init();
$timeout = 0;
curl_setopt($ch, CURLOPT_USERAGENT, "User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0)");
curl_setopt ($ch, CURLOPT_URL, "http://services.velnetweb.co.uk/backlinks/alexa.php?url=$url");
curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
$file_contents = curl_exec($ch);
curl_close($ch);

$out = "";

$match_expression = "/(.*)/";

preg_match($match_expression,$file_contents,$out); 
return $out[0]; 
}

/* function google_backs($url){ 
    $site = fopen('http://services.velnetweb.co.uk/backlinks/google.php?url='.urlencode($url),'r'); 
    while($cont = fread($site,1024)){ 
        $total .= $cont; 
    } 
    fclose($site); 
    $match_expression = '/(.*)/'; 
    preg_match($match_expression,$total,$matches); 
    return $matches[1]; 
} */

function google_backs($url){ 
$ch = curl_init();
$timeout = 0;
curl_setopt($ch, CURLOPT_USERAGENT, "User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0)");
curl_setopt ($ch, CURLOPT_URL, "http://services.velnetweb.co.uk/backlinks/google.php?url=$url");
curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
$file_contents = curl_exec($ch);
curl_close($ch);

$out = "";

$match_expression = "/(.*)/";

preg_match($match_expression,$file_contents,$out); 
return $out[0]; 
}

/* function msn_backs($url){ 
    $site = fopen('http://services.velnetweb.co.uk/backlinks/msn.php?url='.urlencode($url).'&go=Search&form=QBRE','r'); 
    while($cont = fread($site,1024657)){ 
        $total .= $cont; 
    } 
    fclose($site); 
    $match_expression = '/(.*)/'; 
    preg_match($match_expression,$total,$matches); 
    return $matches[1]; 
} */

function msn_backs($url){ 
$ch = curl_init();
$timeout = 0;
curl_setopt($ch, CURLOPT_USERAGENT, "User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0)");
curl_setopt ($ch, CURLOPT_URL, "http://services.velnetweb.co.uk/backlinks/msn.php?url=$url");
curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
$file_contents = curl_exec($ch);
curl_close($ch);

$out = "";

$match_expression = "/(.*)/";

preg_match($match_expression,$file_contents,$out); 
return $out[0]; 
}

/* function yahoo_backs($url){ 
    $site = fopen('http://services.velnetweb.co.uk/backlinks/yahoo.php?url='.urlencode($url).'&bwm=i&bwmf=a&bwms=p','r'); 
    while($cont = fread($site,1024)){ 
        $total .= $cont; 
    } 
    fclose($site); 
    $match_expression = '/(.*)/'; 
    preg_match($match_expression,$total,$matches); 
    return $matches[1];
} */

function yahoo_backs($url){ 
$ch = curl_init();
$timeout = 0;
curl_setopt($ch, CURLOPT_USERAGENT, "User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0)");
curl_setopt ($ch, CURLOPT_URL, "http://services.velnetweb.co.uk/backlinks/yahoo.php?url=$url");
curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
$file_contents = curl_exec($ch);
curl_close($ch);

$out = "";

$match_expression = "/(.*)/";

preg_match($match_expression,$file_contents,$out); 
return $out[0]; 
}
?>