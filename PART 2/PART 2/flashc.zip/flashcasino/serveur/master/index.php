<? include "header.php";


$strok=mysql_query("SELECT * FROM users");
$strokinbase = mysql_num_rows($strok);

$strok=mysql_query("SELECT * FROM users WHERE date='$date'");
$strokinbase2 = mysql_num_rows($strok);

$aaa="0";
$strok=mysql_query("SELECT * FROM stat_pay ");
while($row=mysql_fetch_array($strok))
{
$aaa=$aaa+$row[3];
}

$aa="0";
$strok=mysql_query("SELECT * FROM stat_pay WHERE data='$data' ");
while($row=mysql_fetch_array($strok))
{
$aa=$aa+$row[3];
}

$bbb="0";
$strok=mysql_query("SELECT * FROM stat_pay ");
while($row=mysql_fetch_array($strok))
{
$bbb=$bbb+$row[4];
}

$bb="0";
$strok=mysql_query("SELECT * FROM stat_pay WHERE data='$data' ");
while($row=mysql_fetch_array($strok))
{
$bb=$bb+$row[4];
}



echo "<center><h4><font color=#7C87C2>Stat    $date</font></h4></center>";

echo "

Nb playeurs : $strokinbase<BR>
today  : $strokinbase2<BR>
<br>
Playeurs credit  : $aaa <BR>
today  : $aa <BR>
<br>
Withdraw Funds 
 : $bbb <br>
today : $bb <br>
";

include "footer.php"; ?>