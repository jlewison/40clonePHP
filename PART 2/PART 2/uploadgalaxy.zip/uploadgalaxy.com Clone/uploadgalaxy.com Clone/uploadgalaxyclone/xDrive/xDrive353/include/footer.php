<td><div align="center">&nbsp;</div><div align="center">&nbsp;</div><div align="center">&nbsp;</div><div align="center">&nbsp;</div><div align="center">&nbsp;</div><div align="center">&nbsp;</div><div align="center">&nbsp;</div><div align="center">&nbsp;</div><div align="center">&nbsp;</div><div align="center">&nbsp;</div><div align="center">&nbsp;</div><div align="center">
<font size="2">Content Copyright � 2005 
          <?=$sitename?>
          | The Files Hosted on this server are copyrighted by their respective owners. 
</font> </div><font size="2"></td>
    </tr>
  </table>
</div>
</body>
</font>
<p align="center"><font size="2">Script CopyRight: </font>
<a href="http://popscript.com/"><font size="2">PopScript.com</font></a></p>

</html>