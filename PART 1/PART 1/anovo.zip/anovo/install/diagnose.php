<?php
session_start();
if (!isset($_SESSION['check']) or !$_SESSION['check']) header('Location: auth.php');
if (ini_get('default_mimetype') != 'text/html') echo 'INI screwed up. Fix via http_headers.inc.php!';
if (ini_get('session.auto_start')) echo 'INI screwed up. Auto start enabled. Turn it off or fix application_top.inc.php';
if (ini_get('register_globals')) echo 'INI screwed up. Turn off register_globals for performance and security';


?>