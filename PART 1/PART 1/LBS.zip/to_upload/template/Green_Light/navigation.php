
<?php
if($alphacat == 'Y') { ?>
<div class="alphabet">
  <ul>
    <li class="next"><a href="<?php echo("$path");?>A.html">A</a></li>
    <li class="next"><a href="<?php echo("$path");?>B.html">B</a></li>
    <li class="next"><a href="<?php echo("$path");?>C.html">C</a></li>
    <li class="next"><a href="<?php echo("$path");?>D.html">D</a></li>
    <li class="next"><a href="<?php echo("$path");?>E.html">E</a></li>
    <li class="next"><a href="<?php echo("$path");?>F.html">F</a></li>
    <li class="next"><a href="<?php echo("$path");?>G.html">G</a></li>
    <li class="next"><a href="<?php echo("$path");?>H.html">H</a></li>
    <li class="next"><a href="<?php echo("$path");?>I.html">I</a></li>
    <li class="next"><a href="<?php echo("$path");?>J.html">J</a></li>
    <li class="next"><a href="<?php echo("$path");?>K.html">K</a></li>
    <li class="next"><a href="<?php echo("$path");?>L.html">L</a></li>
    <li class="next"><a href="<?php echo("$path");?>M.html">M</a></li>
    <li class="next"><a href="<?php echo("$path");?>N.html">N</a></li>
    <li class="next"><a href="<?php echo("$path");?>O.html">O</a></li>
    <li class="next"><a href="<?php echo("$path");?>P.html">P</a></li>
    <li class="next"><a href="<?php echo("$path");?>Q.html">Q</a></li>
    <li class="next"><a href="<?php echo("$path");?>R.html">R</a></li>
    <li class="next"><a href="<?php echo("$path");?>S.html">S</a></li>
    <li class="next"><a href="<?php echo("$path");?>T.html">T</a></li>
    <li class="next"><a href="<?php echo("$path");?>U.html">U</a></li>
    <li class="next"><a href="<?php echo("$path");?>V.html">V</a></li>
    <li class="next"><a href="<?php echo("$path");?>W.html">W</a></li>
    <li class="next"><a href="<?php echo("$path");?>X.html">X</a></li>
    <li class="next"><a href="<?php echo("$path");?>Y.html">Y</a></li>
    <li class="next"><a href="<?php echo("$path");?>Z.html">Z</a></li>
    <li><a href="<?php echo("$path");?>0-9.html">#</a></li>
  </ul>
</div>
<?php }
elseif($alphacat == 'N') { ?>

<?php }
else { ?>
<div class="alphabet">
  <ul>
    <li class="next"><a href="<?php echo("$path");?>A.html">A</a></li>
    <li class="next"><a href="<?php echo("$path");?>B.html">B</a></li>
    <li class="next"><a href="<?php echo("$path");?>C.html">C</a></li>
    <li class="next"><a href="<?php echo("$path");?>D.html">D</a></li>
    <li class="next"><a href="<?php echo("$path");?>E.html">E</a></li>
    <li class="next"><a href="<?php echo("$path");?>F.html">F</a></li>
    <li class="next"><a href="<?php echo("$path");?>G.html">G</a></li>
    <li class="next"><a href="<?php echo("$path");?>H.html">H</a></li>
    <li class="next"><a href="<?php echo("$path");?>I.html">I</a></li>
    <li class="next"><a href="<?php echo("$path");?>J.html">J</a></li>
    <li class="next"><a href="<?php echo("$path");?>K.html">K</a></li>
    <li class="next"><a href="<?php echo("$path");?>L.html">L</a></li>
    <li class="next"><a href="<?php echo("$path");?>M.html">M</a></li>
    <li class="next"><a href="<?php echo("$path");?>N.html">N</a></li>
    <li class="next"><a href="<?php echo("$path");?>O.html">O</a></li>
    <li class="next"><a href="<?php echo("$path");?>P.html">P</a></li>
    <li class="next"><a href="<?php echo("$path");?>Q.html">Q</a></li>
    <li class="next"><a href="<?php echo("$path");?>R.html">R</a></li>
    <li class="next"><a href="<?php echo("$path");?>S.html">S</a></li>
    <li class="next"><a href="<?php echo("$path");?>T.html">T</a></li>
    <li class="next"><a href="<?php echo("$path");?>U.html">U</a></li>
    <li class="next"><a href="<?php echo("$path");?>V.html">V</a></li>
    <li class="next"><a href="<?php echo("$path");?>W.html">W</a></li>
    <li class="next"><a href="<?php echo("$path");?>X.html">X</a></li>
    <li class="next"><a href="<?php echo("$path");?>Y.html">Y</a></li>
    <li class="next"><a href="<?php echo("$path");?>Z.html">Z</a></li>
    <li><a href="<?php echo("$path");?>0-9.html">#</a></li>
  </ul>
</div>
<?php } ?>