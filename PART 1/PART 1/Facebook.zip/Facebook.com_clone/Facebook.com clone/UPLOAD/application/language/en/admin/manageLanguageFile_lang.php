<?php
/**
*
*
*
* @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
* @license
* @version SVN:$Id
* @since 2007-06-18
*/
$lang['managelanguagefile_title'] = 'Manage Language File';
$lang['managelanguagefile_directory'] = 'Directory';
$lang['managelanguagefile_file'] = 'File';
$lang['managelanguagefile_variable_names'] = 'Variable names';
$lang['managelanguagefile_phrase'] = 'Phrase';
$lang['managelanguagefile_submit'] = 'Submit';
$lang['managelanguagefile_edit_submit'] = 'Update';
$lang['managelanguagefile_error'] = 'Folder does not exists';
$lang['managelanguagefile_add'] = 'Add Language';
?>