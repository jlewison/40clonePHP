<?php

   class logData extends Data {

      var $table = LOG_TABLE;

      var $config = array (
  'table' => LOG_TABLE,
  'idField' => 'osdate_log_id',
  'addedMsg' => 'Osdate Log %s Added',
  'added_err' => 'Can\\\'t Add Osdate Log',
  'editMsg' => 'Osdate Log %s Updated',
  'editErr' => 'Can\\\'t Update Osdate Log',
  'delErr' => 'Can\\\'t Delete Osdate Log',
  'delMsg' => 'Osdate Log %s Deleted',
  'blankErr' => 'Osdate Log Empty',
  'fields' => 
  array (
    'id' => 
    array (
      'name' => 'id',
      'description' => 'Id',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'page' => 
    array (
      'name' => 'page',
      'description' => 'Page',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 20,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'visits' => 
    array (
      'name' => 'visits',
      'description' => 'Visits',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
  ),
);   

      function logData() {
      
         $this->Data($this->config);
      }
   }

?>
