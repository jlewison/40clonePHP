<?php /* Smarty version 2.6.6, created on 2006-02-01 11:05:16
         compiled from admin/admin_login.tpl */ ?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<link REL="SHORTCUT ICON" href="favicon.ico">
<title>.:: UploadGalaxy Control Panel ::.</title>
</head>
<body>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" height="565">
  <tr>
    <td width="20%" height="563" bordercolor="#E7EFEF" bgcolor="#FFFFFF" rowspan="2">&nbsp;</td>
    <td width="60%" height="549" valign="top" bgcolor="#F5F5F5">
    <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" height="247">
      <tr>
        <td width="100%" height="68" bgcolor="#F1F1FA">
        <p align="center"><b><font size="5" face="Verdana">.:: Control Panel 
        ::.<br>
        </font></b><font size="1" face="Verdana" color="#0000FF">.:: <?php echo $this->_tpl_vars['site_name']; ?>
 
         
        ::.</font></td>
      </tr>
      <tr>
        <td width="100%" height="77" valign="top">
        <p align="center"><?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/adminheader.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
        </td>
      </tr>
      <tr>
        <td width="100%" height="101">
		<form method="POST" action="admin_validate.php">
          <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse; font-family: Verdana; font-size: 10pt; font-weight:bold" bordercolor="#111111" width="100%" height="78">
            <tr>
              <td width="150%" align="right" height="20" colspan="3">
              <p align="center"><b>
        <font face="Verdana" size="2" color="#FF0000"><?php echo $this->_tpl_vars['err']; ?>
</font></b></td>
            </tr>
            <tr>
              <td width="42%" align="right" height="32">Name</td>
              <td width="2%" height="32">&nbsp;</td>
              <td width="106%" align="left" height="32">
              <input type="text" name="name" size="14" style="font-family: Verdana; font-size: 8pt"></td>
            </tr>
            <tr>
              <td width="42%" align="right" height="32">Password</td>
              <td width="2%" height="32">&nbsp;</td>
              <td width="106%" align="left" height="32">
              <input type="password" name="pass" size="14" style="font-family: Verdana; font-size: 8pt"></td>
            </tr>
            <tr>
              <td width="42%" align="right" height="26">&nbsp;</td>
              <td width="2%" height="26">&nbsp;</td>
              <td width="106%" align="left" height="26">
              <input type="submit" value="Submit" name="B1" style="font-family: Verdana; font-size: 8pt"></td>
            </tr>
          </table>
        </form>
        </td>
      </tr>
    </table>
    <p>&nbsp;</td>
    <td width="20%" height="563" bgcolor="#FFFFFF" rowspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td width="60%" height="14" valign="top" bgcolor="#003366">
    <p align="center"><font color="#FFFFFF" face="Verdana" size="1">Developed 
    and maintained by <b>Shaon</b></font></td>
  </tr>
</table>

</body>

</html>