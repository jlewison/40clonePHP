<?php

header( 'location: ../admin/chatadmin.php' );

?>
