<?php /* Smarty version 2.6.6, created on 2006-03-11 11:05:42
         compiled from index.tpl */ ?>
<html>

<head>
<title>Welcome to <?php echo $this->_tpl_vars['site_name']; ?>
</title>
<!--<?php echo '-->
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link REL="SHORTCUT ICON" href="MYSOFT.JPG">
<link href="style.css" rel="stylesheet" type="text/css">
<!--'; ?>
-->

</head>
<body>
<?php echo '
<script language=javascript>
function VarifyFileSize()
{
// document.getElementById(\'prog\').innerHTML="Please wait while verifying file size...<br><img src=\'images/sending_progress.gif\'></img>";
 //document.getElementById(\'srq\').disabled=true;
 //document.getElementById(\'prog\').innerHTML=;
}

function Wait()
{
 document.getElementById(\'prog\').innerHTML="<p align=left>Please Wait...<br><img src=';  echo $this->_tpl_vars['imgurl'];  echo '/cline.gif height=3 width=200></img></p>"
}
function ValidateSubmit()
{
 var s=document.getElementById(\'remail\').value;
 if(s==""||s.indexOf(\'@\')<0||s.indexOf(\'.\')<0||s.indexOf(\'@\')>s.indexOf(\'.\')) 
  {
   alert("Invalid E-mail Address");
   document.getElementById(\'remail\').focus();
   return false;
  } 
 if(document.getElementById(\'eula\').checked==false) 
  {
    alert("You cann\'t upload file without accepting the term of service.");
    return false;
  }
 Wait(); 
 return true; 
}
</script>

<script type="text/javascript" src="cpaint/cpaint2.inc.compressed.js"></script>
<script type="text/javascript">
        var cp = new cpaint();
        cp.set_transfer_mode(\'get\');
  cp.set_response_type(\'text\');
  cp.set_debug(true);
  
        function addNumbers() {
                //var fileToUse = document.getElementById(\'version\').value;
                alert("OK");
                cp.call("calculator.php", \'add\', response, document.getElementById(\'file\').value);
        }        
        
        function response(result) {
                //document.getElementById(\'result\').value = result.getElementsByTagName(\'ajaxResponse\').item(0).firstChild.data;
                alert(response);
        }

</script>

'; ?>

<p align=center>
<table border="0" width="600" height="129" cellspacing="0" cellpadding="0">
  <tr>
    <td width="600" height="250" valign="top">
      <table border="0" width="100%" cellspacing="0" cellpadding="0" height="314">
        <tr>
          <td width="100%" height="29" colspan="2">
<!---------------------------------------------------------------->          
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "header.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<!---------------------------------------------------------------->
          </td>
        </tr>
        <tr>
          <td width="100%" height="29" colspan="2">
<!--------------------------------------------------------------------------->          
          <?php if ($this->_tpl_vars['premium'] == 'yes'): ?>
                <p align="left">
          <font face="Verdana" size="2" color="#7777D2"><b>Premium Members Area</b></font>
          </p>
          <?php endif; ?>
<!--------------------------------------------------------------------------->          
          </td>
        </tr>
        <tr>
          <td width="100%" colspan="2" height="49" bgcolor="#F2F2FF">
            <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%">
              <tr>
                <td width="80%"> 
               <p align="left">&nbsp;
<!--------------------------------------------------------->
               <div id="prog" name="prog">
               <p align=left>               
              <?php unset($this->_sections['i']);
$this->_sections['i']['name'] = 'i';
$this->_sections['i']['loop'] = is_array($_loop=$this->_tpl_vars['err']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['i']['show'] = true;
$this->_sections['i']['max'] = $this->_sections['i']['loop'];
$this->_sections['i']['step'] = 1;
$this->_sections['i']['start'] = $this->_sections['i']['step'] > 0 ? 0 : $this->_sections['i']['loop']-1;
if ($this->_sections['i']['show']) {
    $this->_sections['i']['total'] = $this->_sections['i']['loop'];
    if ($this->_sections['i']['total'] == 0)
        $this->_sections['i']['show'] = false;
} else
    $this->_sections['i']['total'] = 0;
if ($this->_sections['i']['show']):

            for ($this->_sections['i']['index'] = $this->_sections['i']['start'], $this->_sections['i']['iteration'] = 1;
                 $this->_sections['i']['iteration'] <= $this->_sections['i']['total'];
                 $this->_sections['i']['index'] += $this->_sections['i']['step'], $this->_sections['i']['iteration']++):
$this->_sections['i']['rownum'] = $this->_sections['i']['iteration'];
$this->_sections['i']['index_prev'] = $this->_sections['i']['index'] - $this->_sections['i']['step'];
$this->_sections['i']['index_next'] = $this->_sections['i']['index'] + $this->_sections['i']['step'];
$this->_sections['i']['first']      = ($this->_sections['i']['iteration'] == 1);
$this->_sections['i']['last']       = ($this->_sections['i']['iteration'] == $this->_sections['i']['total']);
?>
              <?php echo $this->_tpl_vars['err'][$this->_sections['i']['index']]; ?>
 
              <?php endfor; endif; ?>
              </p>
              </div>
<!--------------------------------------------------------->                        
            </p></td>
                <td width="15%">
                <?php if ($this->_tpl_vars['premium'] == 'yes'): ?>
                 <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%">
                  <tr>
                    <td width="179%" align=right>
                    <p>
                    <a class="link" href="upload.php">Upload</a></p></td>
                  </tr>
                  <tr>
                    <td width="179%" align=right>
                    <p>
                    <a class="link" title="Go to my  file manager..." href="welcome_premium.php">
                    File Manager</a></p></td>
                  </tr>
                  <tr>
                    <td width="179%" align=right>
                    <a class="link1" title="Log out" href="logout.php">Logout</a></td>
                  </tr>
                  </table>
                 <?php endif; ?>
                </td>
              </tr>
            </table>
           
          </td>
        </tr>
        
        
        <tr>
          <td width="51%" height="18"></td>
          <td width="49%" height="18" align=right valign="middle">            
          </td>
        </tr>
        
        
        <tr>
          <td width="100%" colspan="2" height="127" valign="top"><!-- <?php echo $this->_tpl_vars['server_id']; ?>
.uploadgalaxy.com -->
           <form name=frm method="POST" action="index.php" onsubmit="return ValidateSubmit();" enctype="multipart/form-data">
            <table border="0" width="100%" cellspacing="0" cellpadding="0" height="202">
              <tr>
                <td width="40%" align="right" height="37">                  
                  <p align="right"><b>
            Select a file to upload<br>
                  </b><font size="1" face="Verdana">(max
            size <?php echo $this->_tpl_vars['ALW_SIZE']/1024; ?>
 MB)</font></td>
                <td width="4%" height="37">
                </td>
                <td width="56" height="37">
                  <p align="left">
                  <input name="media" type="hidden" id="media" value="ufile">                  
                  <!--<input type="hidden" name="MAX_FILE_SIZE" value="<?php echo $this->_tpl_vars['ALW_SIZE']*1024; ?>
">-->                  
                  <input type="file" id="file" name="ufile" size=30 class="txtbx1"></td>
              </tr>
              <tr>
                <td width="40%" align="right" height="36">
                  <p align="right"><b>Recipients E-mail</b> </td>
                <td width="4%" height="36">
                </td>
                <td width="56" height="36">
                  <p align="left">
                <input type="text" name="reml" size="30" id="remail" class="txtbx1"></td>
              </tr>
              <tr>
                <td width="40%" align="right" height="36">
                  <p align="right"><b>Your E-mail</b> (optional)</td>
                <td width="4%" height="36">
                </td>
                <td width="56" height="36">
                  <p align="left">
                  <input type="text" name="yeml" size="30" id="yemail" value="<?php echo $_COOKIE['email']; ?>
" class="txtbx1"></td>
              </tr>
              <tr>
                <td width="40%" align="right" height="35">
                  <p align="right"><b> Message to Recipient </b>(Optional)</td>
                <td width="4%" height="35">
                </td>
                <td width="56" height="35">
                  <p align="left">
                  <input type="text" name="mdes" size="30" class="txtbx1">
                </td>
              </tr>
              <tr>
                <td width="40%" align="right" height="31">
                  <p align="right">&nbsp;<b>I accept</b> the agreement</p>
                </td>
                <td width="4%" height="31">
                </td>
                <td width="56" height="31">
                  <p align="left"><input type="checkbox" name="trm" value="ON" style="float: left" id="eula">
                </td>
              </tr>
              <tr>
                <td width="40%" align="right" height="27">&nbsp;</td>
                <td width="4%" height="27">
                </td>
                <td width="56" height="27">
                  <p align="left">
                  <input type="submit" value="Send" id="srq" name="req" class="btn"></td>
              </tr>
            </table>
            </form>
          </td>
        </tr>
        <tr>
          <td width="100%" colspan="2" height="18">
          
          
          </td>
        </tr>
        <tr>
          <td width="100%" colspan="2" height="48" bgcolor="#F7F3FF"></td>
        </tr>
        <tr>
<!--------------------------------------------------------------------------------------------------------->        
   <td width="100%" colspan="2" height="25">
        <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "bottom_link.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
  </td>
<!--------------------------------------------------------------------------------------------------------->                  
        </tr>
      </table>
    </td>
  </tr>
  <tr>
    <td width="600" height="25"><img border="0" src="images/bottomLine.gif" width="600" height="18">      
    </td>
  </tr>
  <tr>
    <td width="600" height="109" valign="top" align="center">
      <p>&nbsp;</p>
      <p><b><font color="#FF0000">Important Service Announcement:</font><br>
      <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "msg1title.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
      </b></p>
      <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "msg1.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>      
      </td>
  </tr>
  <tr>
    <td width="600" height="15" valign="top">
    <p align="center">
<!--------------------------------------------------------------->    
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<!--------------------------------------------------------------->   
      </td>
  </tr>
</table>
</body>

</html>