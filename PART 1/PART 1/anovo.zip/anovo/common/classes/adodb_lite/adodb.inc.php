<?php

if (!defined('_ADODB_LAYER')) define('_ADODB_LAYER', 1);
if (!defined('ADODB_DIR')) define('ADODB_DIR', dirname(__file__));
$ADODB_vers = 'V1.42 ADOdb Lite 11 January 2007  (c) 2005-2007 Mark Dickenson. All rights reserved. Released LGPL.';
define('ADODB_FETCH_DEFAULT', 0);
define('ADODB_FETCH_NUM', 1);
define('ADODB_FETCH_ASSOC', 2);
define('ADODB_FETCH_BOTH', 3);
global $ADODB_FETCH_MODE;
$ADODB_FETCH_MODE = ADODB_FETCH_DEFAULT;
function &ADONewConnection($dbtype = 'mysql', $modules = '')
{
		global $ADODB_FETCH_MODE;
		$false = false;
		@include (ADODB_DIR . '/adodb.config.php');
		if (strpos($dbtype, '://'))
		{
				$dsn_array = @parse_url(rawurldecode($dbtype));
				if (!$dsn_array || !$dsn_array['scheme']) return $false;
				$dbtype = $dsn_array['scheme'];
				$modules = (!empty($dsn_array['fragment'])) ? $dsn_array['fragment'] : $modules;
		}
		else  $dsn_array = array('scheme' => '');
		$dbtype = strtolower($dbtype);
		include_once ADODB_DIR . '/adodbSQL_drivers/' . $dbtype . '/' . $dbtype . '_driver.inc';
		$last_module = $dbtype . '_' . 'driver';
		if (!empty($modules))
		{
				$module_list = explode(":", strtolower($modules));
				$generic_modules = array();
				foreach ($module_list as $mod)
				{
						$mod = trim($mod);
						if (is_file(ADODB_DIR . '/generic_modules/' . $mod . '_module.inc'))
						{
								$generic_modules[] = $mod;
						}
						else
						{
								include_once ADODB_DIR . '/adodbSQL_drivers/' . $dbtype . '/' . $dbtype . '_' . $mod . '_module.inc';
								$last_module = $dbtype . '_' . $mod;
						}
				}
				if (count($generic_modules))
				{
						foreach ($generic_modules as $mod)
						{
								include_once ADODB_DIR . '/generic_modules/' . $mod . '_module.inc';
								$last_module = $mod;
						}
				}
		}
		$extention = $last_module . '_ADOConnection';
		$object = new $extention();
		$object->last_module_name = $last_module;
		$object->raiseErrorFn = (defined('ADODB_ERROR_HANDLER')) ? ADODB_ERROR_HANDLER : false;
		$object->query_count = 0;
		$object->query_time_total = 0;
		if (!empty($dsn_array['scheme']))
		{
				if (isset($dsn_array['port'])) $object->port = $dsn_array['port'];
				$persistent = false;
				$forcenew = false;
				if (isset($dsn_array['query']))
				{
						$option_array = explode('&', $dsn_array['query']);
						foreach ($option_array as $element => $value)
						{
								$array = explode('=', $value);
								$data = isset($array[1]) ? $array[1] : 1;
								switch (strtolower($array[0]))
								{
										case 'persist':
										case 'persistent':
												$persistent = $data;
												break;
										case 'debug':
												$object->debug = (integer)$data;
												break;
										case 'fetchmode':
												$ADODB_FETCH_MODE = constant($data);
												break;
										case 'clientflags':
												$object->clientFlags = $data;
												break;
										case 'port':
												$object->port = $data;
												break;
										case 'socket':
												$object->socket = $data;
												break;
										case 'forcenew':
												$forcenew = $data;
												break;
								}
						}
				}
				$dsn_array['host'] = isset($dsn_array['host']) ? $dsn_array['host'] : '';
				$dsn_array['user'] = isset($dsn_array['user']) ? $dsn_array['user'] : '';
				$dsn_array['pass'] = isset($dsn_array['pass']) ? $dsn_array['pass'] : '';
				$dsn_array['path'] = isset($dsn_array['path']) ? substr($dsn_array['path'], 1) : '';
				$result = $object->_connect($dsn_array['host'], $dsn_array['user'], $dsn_array['pass'], $dsn_array['path'], $persistent, $forcenew);
				if (!$result) return $false;
		}
		return $object;
}
function &NewADOConnection($dbtype = '', $module = '')
{
		$tmp = &ADONewConnection($dbtype, $module);
		return $tmp;
}
function &NewDataDictionary(&$connection, $dbtype = false)
{
		if (!$dbtype) $dbtype = $connection->dbtype;
		include_once ADODB_DIR . '/adodb-datadict.inc.php';
		include_once ADODB_DIR . '/adodbSQL_drivers/' . $dbtype . '/' . $dbtype . '_datadict.inc';
		$class = "ADODB2_$dbtype";
		$dict = new $class();
		$dict->connection = &$connection;
		$dict->upperName = strtoupper($dbtype);
		$dict->quote = $connection->nameQuote;
		$dict->debug_echo = $connection->debug_echo;
		return $dict;
}
function &NewPerfMonitor(&$connection, $dbtype = false)
{
		return $connection;
}
class ADOConnection
{
		public $connectionId = false;
		public $record_set = false;
		public $database;
		public $dbtype;
		public $dataProvider;
		public $host;
		public $open;
		public $password;
		public $username;
		public $persistent;
		public $debug = false;
		public $debug_console = false;
		public $debug_echo = true;
		public $debug_output;
		public $forcenewconnection = false;
		public $createdatabase = false;
		public $last_module_name;
		public $socket = false;
		public $port = false;
		public $clientFlags = 0;
		public $nameQuote = '"';
		public $sysDate = false;
		public $sysTimeStamp = false;
		public $sql;
		public $raiseErrorFn = false;
		public $query_count = 0;
		public $query_time_total = 0;
		public $query_list = array();
		public $query_list_time = array();
		public $query_list_errors = array();
		public $_logsql = false;
		function ADOConnection()
		{
		}
		function Version()
		{
				global $ADODB_vers;
				return (float)substr($ADODB_vers, 1);
		}
		function IsConnected()
		{
				if ($this->connectionId === false || $this->connectionId == false) return false;
				else  return true;
		}
		function Connect($host = "", $username = "", $password = "", $database = "", $forcenew = false)
		{
				return $this->_connect($host, $username, $password, $database, false, $forcenew);
		}
		function PConnect($host = "", $username = "", $password = "", $database = "")
		{
				return $this->_connect($host, $username, $password, $database, true, false);
		}
		function NConnect($host = "", $username = "", $password = "", $database = "")
		{
				return $this->_connect($host, $username, $password, $database, false, true);
		}
		function SQLDate($fmt, $col = false)
		{
				if (!$col) $col = $this->sysDate;
				return $col;
		}
		function &Execute($sql, $inputarr = false)
		{
				if ($this->_logsql === true)
				{
						$ret = &adodb_log_sql($this, $sql, $inputarr);
						if (isset($ret)) return $ret;
				}
				$rs = &$this->do_query($sql, -1, -1, $inputarr);
				return $rs;
		}
		function &SelectLimit($sql, $nrows = -1, $offset = -1, $inputarr = false, $secs2cache = 0)
		{
				$rs = &$this->do_query($sql, $offset, $nrows, $inputarr);
				return $rs;
		}
		function outp($text, $newline = true)
		{
				global $ADODB_OUTP;
				$this->debug_output = "<br>\n(" . $this->dbtype . "): " . htmlspecialchars($text) . "<br>\n Error (" . $this->ErrorNo() . '): ' . $this->ErrorMsg() . "<br>\n";
				if (defined('ADODB_OUTP'))
				{
						$fn = ADODB_OUTP;
				}
				else
						if (isset($ADODB_OUTP))
						{
								$fn = $ADODB_OUTP;
						}
				if (defined('ADODB_OUTP') || isset($ADODB_OUTP))
				{
						$fn($this->debug_output, $newline);
						return;
				}
				if ($this->debug_echo) echo $this->debug_output;
		}
		function Param($name, $type = 'C')
		{
				return '?';
		}
		function Prepare($sql)
		{
				return $sql;
		}
}
class ADORecordSet_empty
{
		public $fields = false;
		public $EOF = true;
		function MoveNext()
		{
				return;
		}
		function RecordCount()
		{
				return 0;
		}
		function FieldCount()
		{
				return 0;
		}
		function EOF()
		{
				return true;
		}
		function Close()
		{
				return true;
		}
}
class ADOFieldObject
{
		public $name = '';
		public $max_length = 0;
		public $type = "";
}

?>