<?php

/**
 * About Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 1/2/2008
 */
class About extends Controller
{
		//Constructor
		function About()
		{
				parent::Controller();
				//Load the language file
				$this->lang->load('login', $this->config->item('language_code'));
				$this->lang->load('about', $this->config->item('language_code'));
		}
		//Default function
		function index()
		{
				$this->smartyextended->view('about');
		}
}

?>