<?php include('restrict.php');
require_once('../Connections/apound.php');
$id = $_GET[id];
$x = $_GET[x];
$link = mysql_pconnect($hostname_apound,$username_apound,$password_apound);
mysql_select_db($database_apound);
mysql_query("DELETE FROM main WHERE dtu='$id'");
header("Location: http://$x?upd=Y");?>