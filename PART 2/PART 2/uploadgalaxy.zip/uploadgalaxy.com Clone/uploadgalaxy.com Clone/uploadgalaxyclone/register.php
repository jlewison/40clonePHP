<?
include("include/config.php");
$sql="insert into premium_user set uname='$_REQUEST[username]',
	fname='$_REQUEST[fname]',
	lname='$_REQUEST[fname]',
	adrs1='$_REQUEST[address1]',
	adrs2='$_REQUEST[address2]',
	city='$_REQUEST[city]',
	country='$_REQUEST[country]',
	email='$_REQUEST[email]',
	paypal='$_REQUEST[paypal]',
	pass='$_REQUEST[pass]',
	website='$_REQUEST[website]'";
$conn->execute($sql);

STemplate::assign("puinf",$_REQUEST);
STemplate::Display("reg_pre_thank.tpl");

?>