<?php
require_once ('common/config.inc.php');
require_once ('common/configs/config_encoder.inc.php');
require_once ('common/configs/config_ans_audio.inc.php');
$CFG['lang']['include_files'][] = 'admin/includes/languages/%s/ansVideoConfiguration.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['mods']['is_include_only']['non_html_header_files'] = true;
$CFG['auth']['is_authenticate'] = false;
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class XmlCode extends FormHandler
{
		public $audio_details;
		public function setHeaderStart()
		{
				ob_start();
				header("Pragma: no-cache");
				header("Cache-Control: no-cache, must-revalidate");
				header("Expires: 0");
				header("Content-type: text/xml; charset=iso-8859-1");
		}
		public function populateMusicDetails()
		{
				$sql = 'SELECT audio_id, content_id, user_id, audio_ext, audio_size,' . ' playing_time, date_added, audio_server_url' . ' FROM ' . $this->CFG['db']['tbl']['ans_audio'] . ' WHERE' . ' audio_id=' . $this->dbObj->Param('audio_id') . ' AND' . ' audio_status=\'Ok\' AND' . ' audio_encoded_status=\'Yes\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['aid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($this->audio_details = $rs->FetchRow()) return true;
				return false;
		}
		public function getXmlCode()
		{
				$fields = explode('_', $this->fields_arr['pg']);
				$this->fields_arr['pg'] = $fields[0];
				$this->fields_arr['aid'] = $fields[1];
				if (!($this->fields_arr['pg'] and $this->fields_arr['aid']))
				{
						return;
				}
				switch ($this->fields_arr['pg'])
				{
						case 'music':
								$this->populateMusicDetails();
								$music_folder = $this->CFG['admin']['ans_audios']['audio_folder'];
								$music_url = $this->audio_details['audio_server_url'] . $music_folder . getImageName($this->fields_arr['aid']) . '.' . $this->audio_details['audio_ext'];
								break;
						case 'previewmusic':
								$temp_dir = $this->CFG['site']['url'] . $this->CFG['admin']['ans_audios']['temp_folder'];
								$music_url = $temp_dir . $this->fields_arr['aid'] . 'AUD.flv';
								break;
						case 'smallmusic':
								break;
						case 'musicactivate':
								break;
				}
?>
<PATH>
	<SONGS>
		<SONG Path="<?php echo $music_url; ?>"  Title="" Plays = "100"  BuyUrl="http://url1.com" LyricsUrl = "http://gmail1.com"  Rate="http://rateUrl.com" Comments="http://comments.h" ImageUrl="images/image1.jpg" TargetUrl = "http://google.com" Target="_blank" Type="<?php echo $this->audio_details['audio_ext']; ?>" />
	</SONGS>
</PATH>
<?php
		}
}
$XmlCode = new XmlCode();
$XmlCode->setHeaderStart();
$XmlCode->setDBObject($db);
$CFG['user']['user_id'] = isset($_SESSION['user']['user_id']) ? $_SESSION['user']['user_id'] : '0';
$XmlCode->makeGlobalize($CFG, $LANG);
$XmlCode->setPageBlockNames(array('get_code_form'));
$XmlCode->setFormField('aid', '');
$XmlCode->setFormField('pg', '');
$XmlCode->setFormField('full', false);
$XmlCode->setPageBlockShow('get_code_form');
$XmlCode->sanitizeFormInputs($_GET);
if ($XmlCode->isShowPageBlock('get_code_form'))
{
		$XmlCode->getXmlCode();
}
$XmlCode->setHeaderEnd();


?>