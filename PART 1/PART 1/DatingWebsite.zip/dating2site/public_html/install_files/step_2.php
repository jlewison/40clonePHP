<?php

global $t;


/* This step will check for new installation or upgrade */

/* First check if config.php is available */

$configAvailable = $_SESSION['configAvailable'];


$t->assign('dispstep', $dispstep+1);

$t->assign('configAvailable', $configAvailable);

if ($configAvailable == 'N') {
	$t->assign('config_opt','N');
	$t->assign('dbhost','localhost');
	$t->assign('prefix','osdate');
	$t->display('install/install_step3.tpl');
} else {
	$t->display('install/install_step2.tpl');
}

include('footer.tpl');

exit;
?>
