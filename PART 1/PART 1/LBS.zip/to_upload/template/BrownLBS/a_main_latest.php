<?php include('template/BrownLBS/top_side.php');?>

<!--
###################################################################################
#######################                                     #######################
#######################   M A I N   S E C T I O N   Start   #######################
#######################                                     #######################
###################################################################################
-->

<h1><?php echo("$lang_39");?></h1>

<div class="content">

<div id="stop"><a href="<?php echo("$path");?>newlinksxml.php" target="_blank"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/xml.gif" alt="RSS Feed" border="0" /></a>
  <?php echo("$lang_25");?> <?php echo ($startRow_NLlista + 1) ?> <?php echo("$lang_26");?> <?php echo min($startRow_NLlista + $maxRows_NLlista, $totalRows_NLlista) ?> <?php echo("$lang_27");?> <?php echo $totalRows_NLlista ?> <?php echo("$lang_28");?>
</div>
<br />

<?php do { ?>

<div class="listing2">	
	<img class="listingPrev" src="http://open.thumbshots.org/image.aspx?url=<?php echo $row_NLlista['site']; ?>" alt="<?php 
echo $row_top_BID['title']; ?>" height="68" width="84" />
      <?php $wsn = $row_NLlista['title']; 
      $step8 = str_replace(" ", "-", $wsn); 
      $wsseoname = "$step8"; ?>
      <h3><a href="<?php echo $row_NLlista['site']; ?>" target="_blank"><?php echo $row_NLlista['title']; ?></a></h3>
      
      <?php echo $row_NLlista['descr1']; ?>
<div class="listingD">
<?php $NLcategory = $row_NLlista['maincategory'];
mysql_select_db($database_apound, $apound);
$query_LdetCAT = "SELECT * FROM categorylisting WHERE catlistid = '$NLcategory'";
$LdetCAT = mysql_query($query_LdetCAT, $apound) or die(mysql_error());
$row_LdetCAT = mysql_fetch_assoc($LdetCAT);
$totalRows_LdetCAT = mysql_num_rows($LdetCAT); ?>
	<?php echo $row_NLlista['site']; ?> :: <?php echo("$lang_5");?> <?php echo $row_NLlista['stad']; ?> <?php if($fremode == 'N') { ?> :: <?php echo $row_NLlista['bid']; ?> <?php echo("$lang_29");?> <?php } else { } ?><br />
	  Listed in: <a href="<?php echo("$path");?><?php echo $row_LdetCAT['categseoname']; ?>/"><?php echo $row_LdetCAT['categoryname'] ?></a> | 

	  <a href="<?php echo("$path");?><?php echo $row_NLlista['dtu'];?>/<?php echo("$wsseoname"); ?>.html"><?php echo("$lang_7");?></a> | 
	  <?php if($fremode == 'N') { ?> <a href="<?php echo("$path");?>upgrade.php?ucat=<?php echo $row_NLlista['dtu']; ?>"><?php echo("$lang_8");?></a> <?php } else { } ?>
    </div>

<div class="linkStats">

<?php if($prenabled == 'Y' and $enb_latest == 'Y') { ?>

	<?php include('pr_latest.php');?>
<div>
<a target="_blank" rel="nofollow" href="http://digg.com/submit?phase=2&url=<?php echo $row_lista['site']; ?>&title=Air 
Tickets&bodytext= "><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/diggIcon.gif" alt="Digg It!" 
border="0px" /></a> 
<a target="_blank" rel="nofollow" href="http://www.google.com/bookmarks/mark?op=edit&bkmk=<?php echo $row_lista['site']; 
?>&title=Air Tickets"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/googleIcon.gif" alt="Google 
Bookmarks" border="0px" /></a> 
<a target="_blank" rel="nofollow" href="http://co.mments.com/track?url=<?php echo $row_lista['site']; ?>&title=Air Tickets"><img 
src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/commentsIcon.gif" alt="co.mments" border="0px" /></a>   
             
<a target="_blank" rel="nofollow" href="http://ma.gnolia.com/bookmarklet/add?url=<?php echo $row_lista['site']; ?>&title=Air 
Tickets"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/magnoliaIcon.gif" alt="Ma.gnolia.com" 
border="0px" /></a>                
<a target="_blank" rel="nofollow" href="http://www.spurl.net/spurl.php?url=<?php echo $row_lista['site']; ?>&title=Air 
Tickets"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/spurlIcon.gif" alt="Spurl.net" 
border="0px" /></a>                
<a target="_blank" rel="nofollow" href="http://technorati.com/cosmos/search.html?url=<?php echo $row_lista['site']; ?>"><img 
src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/technoratiIcon.gif" alt="Technorati" border="0px" 
/></a> 
<a target="_blank" rel="nofollow" href="http://reddit.com/submit?url=<?php echo $row_lista['site']; ?>&title=Air Tickets"><img 
src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/redditIcon.gif" alt="reddit" border="0px" /></a> 
<a target="_blank" rel="nofollow" href="http://www.stumbleupon.com/submit?url=<?php echo $row_lista['site']; ?>&title=Air 
Tickets"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/stumbleuponIcon.gif" alt="StumbleUpon" 
border="0px" /></a> 
<a target="_blank" rel="nofollow" href="http://www.furl.net/storeIt.jsp?u=<?php echo $row_lista['site']; ?>&t=Air Tickets"><img 
src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/furlIcon.gif" alt="Furl" border="0px" /></a> 
<a target="_blank" rel="nofollow" href="http://del.icio.us/post?url=<?php echo $row_lista['site']; ?>&title=Air Tickets&notes= 
"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/deliciousIcon.gif" alt="Del.icio.us" 
border="0px" /></a>
<a target="_blank" rel="nofollow" href="http://www.netscape.com/submit/?U=<?php echo $row_lista['site']; ?>&T=Air Tickets"><img 
src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/netscapeIcon.gif" alt="Netscape" border="0px" /></a> 
<a target="_blank" rel="nofollow" href="http://myweb2.search.yahoo.com/myresults/bookmarklet?u=<?php echo $row_lista['site']; 
?>&t=Air Tickets"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/yahooIcon.gif" alt="Yahoo! 
Bookmarklet" border="0px" /></a>
</div>
    </div>

<div class="line2"></div>

<?php } else {} ?>

</div>

<?php } while ($row_NLlista = mysql_fetch_assoc($NLlista)); ?>

<div class="sumitlink"><a href="<?php echo("$path");?>submit.php"><?php echo("$lang_31");?></a></div>

<table  border="0" align="right" cellpadding="0" cellspacing="1">
  <tr>
    <td>
	
<?php if ($pageNum_NLlista > 0) { // Show if not first page ?>
<a href="<?php echo("$path");?><?php echo("0");?>/<?php echo("$totalRows_NLlista");?>/<?php echo("links");?>.html">&lt;&lt; First</a>
<?php } // Show if not first page ?>

<?php if ($pageNum_NLlista > 0) { // Show if not first page ?>
<a href="<?php echo("$path");?><?php $mb = max(0, $pageNum_NLlista - 1); echo("$mb");?>/<?php echo("$totalRows_NLlista");?>/<?php echo("links");?>.html">&lt; Previous</a>
<?php } // Show if not first page ?>

<?php if ($pageNum_NLlista < $totalPages_NLlista) { // Show if not last page ?>
<a href="<?php echo("$path");?><?php $mb = min($totalPages_NLlista, $pageNum_NLlista + 1); echo("$mb");?>/<?php echo("$totalRows_NLlista");?>/<?php echo("links");?>.html">Next &gt;</a>
<?php } // Show if not last page ?>

<?php if ($pageNum_NLlista < $totalPages_NLlista) { // Show if not last page ?>
<a href="<?php echo("$path");?><?php $mb = min($totalPages_NLlista, $pageNum_NLlista + 1); echo("$totalPages_NLlista");?>/<?php echo("$totalRows_NLlista");?>/<?php echo("links");?>.html">Last &gt;</a>
<?php } // Show if not last page ?>

    </td>
  </tr>
</table>

</div>
<!--
###################################################################################
#######################                                     #######################
#######################    M A I N   S E C T I O N   End    #######################
#######################                                     #######################
###################################################################################
-->

<?php include('template/BrownLBS/bottom_side.php');?>
<?php include('template/BrownLBS/footer.php'); ?>