<?php
////////////////////////////////////////////////////////////// 
// Rapidsendit Clone V.1.1  Purchased from Rapidsendit.com ///
// flatFileHost lives on! Credits To Jim For The Foundtion ///
//////////////////////////////////////////////////////////////

include("./config.php");
include("./header.php");

//delete old files
//$deleteseconds = time() - ($deleteafter * 24 * 60 * 60);
//
//$fc=file("./files.txt");
//$f=fopen("./files.txt","w");
//foreach($fc as $line)
//{
//  $thisline = explode('|', $line);
//  if ($thisline[4] > $deleteseconds)
//    fputs($f,$line);
//  else
//    unlink("./storage/".$thisline[0]);
//}
//fclose($f);
//done deleting old files

if(isset($_GET['page']))
  $p = $_GET['page'];
else
  $p = "0";

switch($p) {
case "tos": include("./pages/tos.php"); break;
case "faq": include("./pages/faq.php"); break;
default: include("./pages/upload.php"); break;
}

include("./footer.php");
?>