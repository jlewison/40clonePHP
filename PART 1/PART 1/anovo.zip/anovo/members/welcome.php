<?php
require_once ('../common/config.inc.php');
$CFG['lang']['include_files'][] = 'members/includes/languages/%s/welcome.php';
$CFG['html']['header'] = 'members/includes/languages/%s/html_header.php';
$CFG['html']['footer'] = 'members/includes/languages/%s/html_footer.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['lang']['include_files'][] = 'common/languages/%s/help.inc.php';
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class WelcomeFormHandler extends FormHandler
{
		public function getWelcomeContent($content, $fieldsArr)
		{
				$content = nl2br($content);
				$chkArray = array('guidelines', 'term of service');
				foreach ($chkArray as $value)
				{
						$toReplace = '{' . $value . '}';
						if (array_key_exists($value, $fieldsArr)) $content = str_replace($toReplace, $fieldsArr[$value], $content);
						else  $content = str_replace($toReplace, '', $content);
				}
				return $content;
		}
}
$welcomefrm = new WelcomeFormHandler();
$welcomefrm->setCfgLangGlobal($CFG, $LANG);
$welcomefrm->setPageBlockNames(array('msg_form_error', 'msg_form_success', 'form_welcome'));
$welcomefrm->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$welcomefrm->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$welcomefrm->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$welcomefrm->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$welcomefrm->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$welcomefrm->setFormField('url', '');
$welcomefrm->setFormField('guide', '');
$welcomefrm->setFormField('terms', '');
if (isset($_SERVER['HTTP_REFERER'])) $welcomefrm->setFormField('url', $_SERVER['HTTP_REFERER']);
$welcomefrm->setAllPageBlocksHide();
$welcomefrm->sanitizeFormInputs($_REQUEST);
if (strpos($welcomefrm->getFormField('url'), 'activateAccount.php'))
{
		$guide = '<a href="' . $CFG['site']['relative_url'] . 'staticPage.php?pg=privacy' . '" target="_blank">Guidelines</a>';
		$terms = '<a href="' . $CFG['site']['relative_url'] . 'staticPage.php?pg=terms' . '" target="_blank">Terms of Service</a>';
		$welcomefrm->setFormField('guide', $guide);
		$welcomefrm->setFormField('terms', $terms);
		$welcomefrm->sanitizeFormInputs($_REQUEST);
		$welcomefrm->setPageBlockShow('form_welcome');
}
else
{
		$welcomefrm->setAllPageBlocksHide();
		Redirect2URL($CFG['site']['relative_url']);
}



?>
<div id="selWelcome">
	<h2><?php echo $LANG['welcome_title']; ?></h2>
<?php
if ($welcomefrm->isShowPageBlock('msg_form_error'))
{
?>
	<div id="selMsgError">
 		<p><?php echo $LANG['welcome_errors']; ?></p>
	</div>
<?php
}
if ($welcomefrm->isShowPageBlock('form_welcome'))
{
?>
		   <div class="clsWelcomeContent">
    <h3>Welcome <?php echo $CFG['user']['name']; ?>, you have been registered successfully.</h3>
		<div class="clsSignupContent">
      	   	<p>
      		<?php
		$content = $welcomefrm->getWelcomeContent($LANG['welcome_content'], array('guidelines' => $welcomefrm->getFormField('guide'), 'term of service' => $welcomefrm->getFormField('terms')));
		echo nl2br($content);
?>
		  	</p>
            <h4 class="clsCenter"> <?php echo $LANG['welcome_enjoy'] ?></h4>
      	  	<p class="clsContinueRight">
		  		<a href="<?php echo $CFG['auth']['members_url']; ?>" class="clsContinue"><?php echo $LANG['welcome_continue'] ?></a>
    	  	</p>
		</div>
        </div>
<?php
}
?>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>