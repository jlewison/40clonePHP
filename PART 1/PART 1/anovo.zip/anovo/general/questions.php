<?php
class QuestionFormHandler extends VideoUploadLib
{
		public $question_details = array();
		public $user_details = array();
		public $sql_condition;
		public function storeSearchFields()
		{
				$allowed_fields_arr = array('more_questions' => $this->fields_arr['more_questions'], 'type' => $this->fields_arr['type'], 'uname' => $this->fields_arr['uname'], 'tags' => $this->fields_arr['tags'], 'cat_id' => $this->fields_arr['cat_id'], 'cid' => $this->fields_arr['cid'], 'video' => $this->fields_arr['video'], 'audio' => $this->fields_arr['audio'], 'total_answer_from' => $this->fields_arr['total_answer_from'], 'total_answer_to' => $this->fields_arr['total_answer_to'], 'date_added_from_day' => $this->fields_arr['date_added_from_day'], 'date_added_from_month' => $this->fields_arr['date_added_from_month'], 'date_added_from_year' => $this->fields_arr['date_added_from_year'], 'date_added_to_day' => $this->fields_arr['date_added_to_day'], 'date_added_to_month' => $this->fields_arr['date_added_to_month'], 'date_added_to_year' => $this->fields_arr['date_added_to_year']);
				$allowed_fields_arr = serialize($allowed_fields_arr);
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['advanced_search'] . ' SET' . ' answer = ' . $this->dbObj->Param('answer') . ' WHERE' . ' user_id = ' . $this->dbObj->Param('user_id');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($allowed_fields_arr, $this->CFG['user']['user_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function populateSearchFields()
		{
				if ($this->fields_arr['so'] == 'adv')
				{
						$sql = 'SELECT answer FROM ' . $this->CFG['db']['tbl']['advanced_search'] . ' WHERE user_id=' . $this->dbObj->Param('user_id');
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($this->CFG['user']['user_id']));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
						if ($row = $rs->FetchRow())
						{
								if ($row['answer'])
								{
										$search_fields_arr = unserialize($row['answer']);
										$this->fields_arr = array_merge($this->fields_arr, $search_fields_arr);
								}
						}
				}
		}
		public function buildConditionQuery()
		{
				if ($this->sql_condition) return $this->sql_condition;
				$this->sql_condition = 'q.user_id=u.' . $this->getUserTableField('user_id') . ' AND u.' . $this->getUserTableField('usr_status') . '=\'Ok\'';
				if ($this->CFG['admin']['ignore_user'])
				{
						$this->sql_condition .= ' AND NOT EXISTS (SELECT 1 FROM ' . $this->CFG['db']['tbl']['user_ignored'] . ' AS ui WHERE ui.user_id=' . $this->CFG['user']['user_id'] . ' AND ui.ignored_id=q.user_id)';
				}
				$condition = ' AND (q.status = \'Open\' AND q.date_closed>=NOW())';
				if ($this->fields_arr['view'] == 'resolved') $condition = ' AND (q.status = \'Resolved\' OR q.date_closed<NOW())';
				if ($this->fields_arr['cid'])
				{
						$condition = $this->getCatIds($this->fields_arr['cid']);
						if ($this->fields_arr['view'] == 'open') $condition .= ' AND (q.status = \'Open\' AND q.date_closed>=NOW())';
						if ($this->fields_arr['view'] == 'resolved') $condition .= ' AND (q.status = \'Resolved\' OR q.date_closed<NOW())';
				}
				if ($this->fields_arr['al'])
				{
						$case = strtolower($this->fields_arr['al']);
						switch ($case)
						{
								case '1':
										$condition .= ' AND (question REGEXP \'^[^a-z]\')';
										break;
								case 'all':
										break;
								default:
										$condition .= ' AND (question REGEXP \'^' . $case . '\')';
						}
				}
				$search_conditon = '';
				if ($this->fields_arr['search_question'] && ($this->fields_arr['search_question'] != $this->LANG['search_for_questions'])) $search_conditon .= ' AND ' . getSearchRegularExpressionQuery($this->fields_arr['search_question'], 'question');
				if ($this->fields_arr['more_questions']) $search_conditon .= ' AND ' . getSearchRegularExpressionQuery($this->fields_arr['more_questions'], 'question');
				if ($this->fields_arr['uname']) $search_conditon .= ' AND ' . $this->getUserTableField('name') . ' LIKE \'' . addslashes($this->fields_arr['uname']) . '%\'';
				if ($this->fields_arr['tags']) $search_conditon .= ' AND ' . getSearchRegularExpressionQuery($this->fields_arr['tags'], 'tags');
				if ($this->fields_arr['cat_id']) $search_conditon .= ' AND (pcat_id=\'' . addslashes($this->fields_arr['cat_id']) . '\' OR cat_id=\'' . addslashes($this->fields_arr['cat_id']) . '\')';
				if ($this->fields_arr['total_answer_from']) $search_conditon .= ' AND total_answer>=\'' . addslashes($this->fields_arr['total_answer_from']) . '\'';
				if ($this->fields_arr['total_answer_to']) $search_conditon .= ' AND total_answer<=\'' . addslashes($this->fields_arr['total_answer_to']) . '\'';
				if ($this->fields_arr['date_added_from_day']) $search_conditon .= ' AND date_asked>=\'' . addslashes($this->fields_arr['date_added_from_year'] . '-' . $this->fields_arr['date_added_from_month'] . '-' . $this->fields_arr['date_added_from_day']) . '\'';
				if ($this->fields_arr['date_added_to_day']) $search_conditon .= ' AND date_asked<=\'' . addslashes($this->fields_arr['date_added_to_year'] . '-' . $this->fields_arr['date_added_to_month'] . '-' . $this->fields_arr['date_added_to_day']) . '\'';
				if ($this->fields_arr['video']) $search_conditon .= ' AND video_id!=\'0\'';
				if ($this->fields_arr['audio']) $search_conditon .= ' AND audio_id!=\'0\'';
				if ($this->fields_arr['type'])
				{
						switch ($this->fields_arr['type'])
						{
								case 'Open':
										$search_conditon .= ' AND (q.status = \'Open\' AND q.date_closed>=NOW())';
										break;
								case 'Resolved':
										$search_conditon .= ' AND (q.status = \'Resolved\' OR q.date_closed<NOW())';
										break;
								default:
										$search_conditon .= ' AND q.status IN (\'Open\', \'Resolved\')';
						}
				}
				if ($search_conditon) $this->sql_condition .= $search_conditon;
				else  $this->sql_condition .= $condition;
		}
		public function getCatIds($cid)
		{
				$sql = 'SELECT cat_id, cat_name, parent_id FROM ' . $this->CFG['db']['tbl']['questions_category'] . ' WHERE cat_id=' . $this->dbObj->Param('cid') . ' AND status=\'1\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['cid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$sub_qry = '';
				if ($rs->PO_RecordCount())
				{
						$row = $rs->FetchRow();
						if (!$row['parent_id']) $sub_qry = ' AND (q.pcat_id=' . $row['cat_id'] . ' OR q.cat_id IN ( SELECT cat_id FROM ' . $this->CFG['db']['tbl']['questions_category'] . ' WHERE parent_id=' . $row['cat_id'] . '))';
						else  $sub_qry = ' AND q.cat_id=' . $row['cat_id'];
				}
				return $sub_qry;
		}
		public function buildSortQuery()
		{
				$this->sql_sort = $this->fields_arr['orderby_field'] . ' ' . $this->fields_arr['orderby'];
		}
		public function displayCategoryName()
		{
				if ($this->fields_arr['cid'])
				{
						$sql = 'SELECT cat_name FROM ' . $this->CFG['db']['tbl']['questions_category'] . ' WHERE cat_id=' . $this->dbObj->Param('cid');
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['cid']));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
						if ($rs->PO_RecordCount())
						{
								$row = $rs->FetchRow();
								return $row['cat_name'];
						}
				}
		}
		public function chkIsValidQuestion()
		{
				$this->chkIsNotEmpty('qid', $this->LANG['questions_err_tip_compulsory']);
				if (!$this->isValidFormInputs())
				{
						$this->setCommonErrorMsg($this->LANG['questions_err_invalid_question']);
						return false;
				}
				$sql = 'SELECT q.ques_id, q.total_answer, q.pcat_id, q.cat_id, q.video_id, q.audio_id, q.best_ans_id, q.description, q.total_stars' . ', q.question, TIMEDIFF(NOW(), date_asked) as date_asked, q.status, q.user_id, q.tags, q.total_videos, q.total_audios' . ', IF(status=\'Open\' AND date_closed>=NOW(), 1, 0) is_open' . ' FROM ' . $this->CFG['db']['tbl']['questions'] . ' AS q' . ' WHERE q.status IN (\'Open\', \'Resolved\')' . ' AND q.ques_id=' . $this->dbObj->Param('qid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['qid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if (!$rs->PO_RecordCount())
				{
						$this->setCommonErrorMsg($this->LANG['questions_err_invalid_question']);
						return false;
				}
				$this->question_details = $rs->FetchRow();
				if (!$this->question_details['is_open'])
				{
						$this->setCommonErrorMsg($this->LANG['questions_err_not_open_question']);
						return false;
				}
				return true;
		}
		public function displayOpenAndResolvedLinks()
		{
?>

<div id="selQuickLinks">
  <?php
				$cidQryN = $cidQryH = '';
				if ($this->fields_arr['video'])
				{
						$cidQryN .= 'video=1&';
						$cidQryH .= 'video=1&';
				}
				if ($this->fields_arr['audio'])
				{
						$cidQryN .= 'audio=1&';
						$cidQryH .= 'audio=1&';
				}
				if ($this->fields_arr['cid'])
				{
						$cidQryN .= 'cid=' . $this->fields_arr['cid'] . '&';
						$cidQryH .= 'cid=' . $this->fields_arr['cid'] . '&';
				}
				if ($this->fields_arr['al'])
				{
						$cidQryN .= 'al=' . $this->fields_arr['al'] . '&';
						$cidQryH .= 'al=' . $this->fields_arr['al'] . '&';
				}
				if ($cidQryH) $cidQryH = '?' . $cidQryH;
				if ($cidQryN) $cidQryN = '&' . $cidQryN;
				$openQuestionsLI = $resolvedQuestionsLI = '';
				$openQuestionsSPAN = $resolvedQuestionsSPAN = '';
				$openQuestionsA = $resolvedQuestionsA = '';
				$clsActiveForumLinksLeft = 'clsActiveForumLinksLeft';
				$clsActiveForumLinksRight = 'clsActiveForumLinksRight';
				$clsActiveForumLinksMiddle = 'clsActiveForumLinksMiddle';
				if ($this->fields_arr['view'] == 'open')
				{
						$openQuestionsLI = $clsActiveForumLinksLeft;
						$openQuestionsSPAN = $clsActiveForumLinksRight;
						$openQuestionsA = $clsActiveForumLinksMiddle;
				} elseif ($this->fields_arr['view'] == 'resolved')
				{
						$resolvedQuestionsLI = $clsActiveForumLinksLeft;
						$resolvedQuestionsSPAN = $clsActiveForumLinksRight;
						$resolvedQuestionsA = $clsActiveForumLinksMiddle;
				}
?>
  <ul class="clsForumLinks">
    <li class="<?php echo $openQuestionsLI; ?>"><span class="<?php echo $openQuestionsSPAN; ?>"><a class="<?php echo $openQuestionsA; ?>" href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'questions.php?view=open' . $cidQryN, $this->CFG['site']['relative_url'] . 'answers/open/' . $cidQryH, false); ?>"><?php echo $this->LANG['questions_open']; ?></a></span></li>
    <li class="<?php echo $resolvedQuestionsLI; ?>"><span class="<?php echo $resolvedQuestionsSPAN; ?>"><a class="<?php echo $resolvedQuestionsA; ?>" href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'questions.php?view=resolved' . $cidQryN, $this->CFG['site']['relative_url'] . 'answers/resolved/' . $cidQryH, false); ?>"><?php echo $this->LANG['questions_resolved']; ?></a></span></li>
  </ul>
</div>
<?php
		}
		public function displayRecentAndPopularLinks()
		{
				$recentQuestionsLI = $popularQuestionsLI = '';
				$recentQuestionsSPAN = $popularQuestionsSPAN = '';
				$recentQuestionsA = $popularQuestionsA = '';
				$clsActiveForumLinksLeft = 'clsActiveForumLinksLeft';
				$clsActiveForumLinksRight = 'clsActiveForumLinksRight';
				$clsActiveForumLinksMiddle = 'clsActiveForumLinksMiddle';
				if ($this->fields_arr['view'] == 'recent')
				{
						$recentQuestionsLI = $clsActiveForumLinksLeft;
						$recentQuestionsSPAN = $clsActiveForumLinksRight;
						$recentQuestionsA = $clsActiveForumLinksMiddle;
				} elseif ($this->fields_arr['view'] == 'popular')
				{
						$popularQuestionsLI = $clsActiveForumLinksLeft;
						$popularQuestionsSPAN = $clsActiveForumLinksRight;
						$popularQuestionsA = $clsActiveForumLinksMiddle;
				}
?>
<div id="selQuickLinks">
  <ul class="clsForumLinks">
    <li class="<?php echo $recentQuestionsLI; ?>"><span class="<?php echo $recentQuestionsSPAN; ?>"><a class="<?php echo $recentQuestionsA; ?>" href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'questions.php?view=recent', $this->CFG['site']['relative_url'] . 'answers/recent/', false); ?>"><?php echo $this->LANG['questions_recent']; ?></a></span></li>
    <li class="<?php echo $popularQuestionsLI; ?>"><span class="<?php echo $popularQuestionsSPAN; ?>"><a class="<?php echo $popularQuestionsA; ?>" href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'questions.php?view=popular', $this->CFG['site']['relative_url'] . 'answers/popular/', false); ?>"><?php echo $this->LANG['questions_popular']; ?></a></span></li>
  </ul>
</div>
<?php
		}
		public function populateQuestionType($highlight_type = '')
		{
				$type_array = array('All', 'Open', 'Resolved');
				foreach ($type_array as $eachType)
				{
						$selected = ($eachType == $highlight_type) ? 'SELECTED' : '';
?>
<option value="<?php echo $eachType; ?>" <?php echo $selected; ?>><?php echo $eachType; ?></option>
<?php
				}
		}
		public function displayRecentAndPopularQuestions()
		{
				$this->displayRecentAndPopularLinks();
				$limit = $this->CFG['admin']['recent']['limit'];
				$sql = 'SELECT q.ques_id, q.total_answer, q.pcat_id, q.cat_id, q.status, q.total_stars, q.question, TIMEDIFF(NOW(), date_asked) as date_asked' . ', u.' . $this->getUserTableField('name') . ' as asked_by, u.' . $this->getUserTableField('user_id') . ' as img_user_id, ' . $this->getUserTableFields(array('image_path', 'gender', 't_height', 't_width', 's_height', 's_width', 'photo_server_url', 'photo_ext'), false) . ' q.user_id' . ', video_id, audio_id, IF(status=\'Open\' AND date_closed>=NOW(), 1, 0) is_open, TIMEDIFF(date_closed, NOW()) as date_closed' . ', q.total_videos, q.total_audios FROM ' . $this->CFG['db']['tbl']['questions'] . ' AS q, ' . $this->CFG['db']['tbl']['users'] . ' AS u' . ' WHERE q.user_id=u.' . $this->getUserTableField('user_id') . ' AND q.status IN (\'Open\', \'Resolved\')' . ' AND u.' . $this->getUserTableField('usr_status') . '=\'Ok\'';
				if ($this->CFG['admin']['ignore_user'])
				{
						$sql .= ' AND NOT EXISTS (SELECT 1 FROM ' . $this->CFG['db']['tbl']['user_ignored'] . ' AS ui WHERE ui.user_id=' . $this->CFG['user']['user_id'] . ' AND ui.ignored_id=q.user_id)';
				}
				if ($this->fields_arr['view'] == 'popular') $sql .= ' AND total_views > 0 ORDER BY total_views DESC LIMIT 0,' . ($limit + 1);
				else  $sql .= ' ORDER BY ques_id DESC LIMIT 0,' . ($limit + 1);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if (!$rs->PO_RecordCount())
				{
?>
<div id="selMsgAlert">
  <p><?php echo $this->LANG['questions_no_records']; ?></p>
</div>
<?php
						return;
				}
				$i = 0;
				while ($row = $rs->FetchRow())
				{
						$i++;
						$clsOddOrEvenQuestion = 'clsEvenQuestion';
						if ($i % 2) $clsOddOrEvenQuestion = 'clsOddQuestion';
						$boldClass = ' class="clsNormal"';
						if ($this->display_bold < ($i + 1)) $boldClass = ' class="clsBold"';
						$iconClass = '';
						$audio_class = 'clsNoBorder';
						$video_class = '';
						if ($row['total_videos'] != 0 && chkVideoAllowed('answer') && $row['total_audios'] != 0 && chkAudioAllowed('answer')) $iconClass = 'clsVideoAudioIcon ';
						elseif (chkVideoAllowed('answer') && $row['total_videos']) $iconClass = 'clsVideoIcon ';
						elseif (chkAudioAllowed('answer') && $row['total_audios']) $iconClass = 'clsAudioIcon ';
						if ($row['video_id']) $video_class = 'clsNoBorder';
						if ($row['audio_id']) $video_class = '';
?>
<div class="<?php echo $clsOddOrEvenQuestion; ?> clsUsersQuestion">
	<div class="clsUserThumbDetails">
		<?php if ($iconClass)
						{ ?>
		<a class="<?php echo $iconClass; ?>" href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'answer.php?qid=' . $row['ques_id'], $this->CFG['site']['relative_url'] . 'view/answers/' . $row['ques_id'] . '/', false); ?>">video/audio</a>
    	<?php } ?>
		<?php if (chkUserImageAllowed())
						{ ?>
		<div class="clsUserThumb">
            <?php displayUserImage($row, 'small'); ?>
        </div>
        <?php } ?>
        <div class="clsUserDetails">
        <p <?php echo $boldClass; ?>>
			<span class="clsQuestionLink clsNoBorder"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'answer.php?qid=' . $row['ques_id'], $this->CFG['site']['relative_url'] . 'view/answers/' . $row['ques_id'] . '/', false); ?>"><?php echo wordWrapManual($row['question'], $this->CFG['admin']['question']['line_length'], $this->CFG['admin']['question']['short_length']); ?></a></span>
		</p>
        <p>
        	<?php if (chkVideoAllowed('question') and $row['video_id'])
						{ ?>
            <span class="<?php echo $video_class; ?>"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'answer.php?qid=' . $row['ques_id'], $this->CFG['site']['relative_url'] . 'view/answers/' . $row['ques_id'] . '/', false); ?>"><img src="<?php echo $this->CFG['site']['url'] . 'images/icon-video.png' ?>" alt="<?php echo $this->LANG['questions_video_available']; ?>" /></a></span>
            <?php } ?>
            <?php if (chkAudioAllowed('question') and $row['audio_id'])
						{ ?>
            <span class="<?php echo $audio_class; ?>"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'answer.php?qid=' . $row['ques_id'], $this->CFG['site']['relative_url'] . 'view/answers/' . $row['ques_id'] . '/', false); ?>"><img src="<?php echo $this->CFG['site']['url'] . 'images/icon-audio.png' ?>" alt="<?php echo $this->LANG['questions_audio_available']; ?>" /></a></span>
            <?php } ?>
        </p>
        <p>    <?php
						$cat_id = $row['cat_id'];
						if (!$cat_id) $cat_id = $row['pcat_id'];
						$this->showCategoryName($cat_id);
						$video_plural = '';
						$audio_plural = '';
						$answer_plural = '';
						if ($row['total_videos'] != 1) $video_plural = 's';
						if ($row['total_audios'] != 1) $audio_plural = 's';
						if ($row['total_answer'] != 1) $answer_plural = 's';
						$video_audio_count = '';
						$video_audio_count .= chkVideoAllowed('answer') ? $row['total_videos'] . ' ' . $this->LANG['question_total_videos'] . $video_plural . ' | ' : '';
						$video_audio_count .= chkAudioAllowed('answer') ? $row['total_audios'] . ' ' . $this->LANG['question_total_audios'] . $audio_plural . ' | ' : '';
						$video_audio_count = substr($video_audio_count, 0, strrpos($video_audio_count, '|'));
						$video_audio_count = trim($video_audio_count);
						$video_audio_count = $video_audio_count ? '(' . $video_audio_count . ')' : '';
?>
            <span class="clsNoBorder clsForumAuthor"><?php echo $this->LANG['question_asked_by']; ?> <a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'myanswers.php?uid=' . $row['user_id'], $this->CFG['site']['relative_url'] . 'my/answers/' . $row['user_id'] . '/', false); ?>"><?php echo stripString($row['asked_by'], $this->CFG['username']['short_length']); ?></a></span></p>
            <?php if ($row['total_answer'])
						{ ?>
            <p class="clsTotalAnswer"><span class="clsNoBorder"><?php echo $row['total_answer']; ?>&nbsp;<?php echo $this->LANG['question_total_answer'] . $answer_plural; ?> <?php echo $video_audio_count; ?></span></p>
            <?php } elseif ($row['is_open'])
						{ ?>
            <p><span class="clsFirstOne clsNoBorder"><a href="<?php echo getUrl($this->CFG['site']['url'] . 'members/answer.php?qid=' . $row['ques_id'], $this->CFG['site']['url'] . 'members/view/answers/' . $row['ques_id'] . '/', false); ?>"><?php echo $this->LANG['be_the_first_to_answer']; ?></a></span></p>
            <?php } ?>
            <p> <span><?php echo getTimeDiffernceFormat($row['date_asked']); ?></span>
              <?php if ($row['is_open'])
						{ ?>
              <span class="clsNoBorder"><?php echo getTimeToGoFormat($row['date_closed']); ?></span>
              <?php }
						else
						{ ?>
              <span class="clsResolved clsNoBorder"><?php echo $this->LANG['question_resolved']; ?></span>
              <?php } ?>
            </p>
        </div>
    </div>
</div>
<?php
						if ($i >= $limit) break;
				}
				if ($rs->PO_RecordCount() > $limit)
				{
?>
<div id="selMoreQuestions">
  <p class="clsMoreLink"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'questions.php?view=open', $this->CFG['site']['relative_url'] . 'answers/open/', false); ?>"><?php echo $this->LANG['more']; ?></a></p>
</div>
<?php
				}
		}
		public function displayAllQuestions()
		{
				if (!$this->isShowPageBlock('form_search_results') and $this->isResultsFound()) $this->displayOpenAndResolvedLinks();
				$pagingArr = array();
				if (!$this->CFG['url']['rewrite']) $pagingArr[] = 'view';
				if ($this->getFormField('cid')) $pagingArr[] = 'cid';
				if ($this->getFormField('sort')) $pagingArr[] = 'sort';
				if ($this->getFormField('order')) $pagingArr[] = 'order';
				$sortQry = '';
				$search_options = array('search_question', 'so', 'adv_search', 'more_questions', 'type', 'uname', 'tags', 'cat_id', 'cid', 'video', 'audio', 'total_answer_from', 'total_answer_to', 'date_added_from_day', 'date_added_from_month', 'date_added_from_year', 'date_added_to_day', 'date_added_to_month', 'date_added_to_year', 'al', 'opt');
				foreach ($search_options as $eachOption)
				{
						if ($this->fields_arr[$eachOption])
						{
								if ($eachOption == 'more_questions' || $eachOption == 'search_question') $this->setFormField($eachOption, ereg_replace('[?]', '', $this->fields_arr[$eachOption]));
								$pagingArr[] = $eachOption;
								$sortQry .= '&' . $eachOption . '=' . $this->fields_arr[$eachOption];
						}
				}
				$view = $this->fields_arr['view'];
				$sort = $this->fields_arr['sort'];
				$order = $this->fields_arr['order'];
				$dateOrder = $ansOrder = 'd';
				$clsDate = $clsAnswer = '';
				if (!$this->isShowPageBlock('form_search_results') and $this->isResultsFound())
				{
						$reverseOrder = ($order == 'd') ? 'a' : 'd';
						$dateOrder = $ansOrder = 'd';
						$ansOrderClass = $dateOrderClass = '';
						$orderByClass = ($order == 'a') ? 'clsAsc' : 'clsDsc';
						if ($sort == 'date')
						{
								$dateOrder = $reverseOrder;
								$clsDate = 'clsActiveViewByLink';
								$dateOrderClass = $orderByClass;
						} elseif ($sort == 'ans')
						{
								$ansOrder = $reverseOrder;
								$clsAnswer = 'clsActiveViewByLink';
								$ansOrderClass = $orderByClass;
						}
?>
<div class="clsViewBy">
 <div class="clsViewHeading"> <h3><?php echo $this->LANG['questions_view_by']; ?> :</h3></div>
  <ul>
    <li class="<?php echo $dateOrderClass ?>"><a class="<?php echo $clsDate; ?>" href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'questions.php?view=' . $view . '&sort=date&order=' . $dateOrder . $sortQry, $this->CFG['site']['relative_url'] . 'answers/' . $view . '/?sort=date&order=' . $dateOrder . $sortQry, false); ?>"><?php echo $this->LANG['questions_view_by_date']; ?></a></li>
    <li class="<?php echo $ansOrderClass ?> clsNoBorder"><a class="<?php echo $clsAnswer; ?>" href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'questions.php?view=' . $view . '&sort=ans&order=' . $ansOrder . $sortQry, $this->CFG['site']['relative_url'] . 'answers/' . $view . '/?sort=ans&order=' . $ansOrder . $sortQry, false); ?>"><?php echo $this->LANG['questions_view_by_answers']; ?></a></li>
  </ul>
</div>
<?php
				}
				if ($this->CFG['admin']['navigation']['top']) $this->populatePageLinks($this->getFormField('start'), $pagingArr);
				if (!$this->isResultsFound())
				{
?>
<div id="selMsgAlert">
  <?php
						if ($this->isShowPageBlock('form_users_questions'))
						{
?>
  <p><?php echo $this->LANG['questions_no_records']; ?></p>
<?php
						}
						else
								if ($this->isShowPageBlock('form_search_results'))
								{
?>
  <p><?php echo $this->LANG['question_no_search_results']; ?></p>
  <p class="clsMsgAdditionalText"><?php echo $this->LANG['question_check_your_spelling']; ?></p>
  <p class="clsMsgAdditionalText"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'questions.php?view=ask', $this->CFG['site']['relative_url'] . 'answers/ask/', false); ?>"><?php echo $this->LANG['questions_search_ask']; ?></a> <?php echo $this->LANG['question_the_user_off']; ?> <?php echo $this->CFG['site']['name']; ?>!</p>
  <?php
								}
								else
								{
?>
  <p><?php echo $this->LANG['questions_no_records']; ?></p>
<?php
								}
?>
</div>
<?php
								return;
				}
				if ($this->fields_arr['tags'])
				{
						$this->updateSearchCount($this->fields_arr['tags']);
				}
				$i = 0;
				while ($row = $this->fetchResultRecord())
				{
						$i++;
						$clsOddOrEvenQuestion = 'clsEvenQuestion';
						if ($i % 2) $clsOddOrEvenQuestion = 'clsOddQuestion';
						$boldClass = ' class="clsNormal"';
						if ($this->display_bold < ($i + 1)) $boldClass = ' class="clsBold"';
						$iconClass = '';
						$audio_class = 'clsNoBorder';
						$video_class = '';
						if ($row['total_videos'] != 0 && chkVideoAllowed('answer') && $row['total_audios'] != 0 && chkAudioAllowed('answer')) $iconClass = 'clsVideoAudioIcon ';
						elseif (chkVideoAllowed('answer') && $row['total_videos']) $iconClass = 'clsVideoIcon ';
						elseif (chkAudioAllowed('answer') && $row['total_audios']) $iconClass = 'clsAudioIcon ';
						if ($row['video_id']) $video_class = 'clsNoBorder';
						if ($row['audio_id']) $video_class = '';
?>
<div class="<?php echo $clsOddOrEvenQuestion; ?> clsUsersQuestion">
    <div class="clsUserThumbDetails">
		<?php if ($iconClass)
						{ ?>
		<a class="<?php echo $iconClass; ?>" href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'answer.php?qid=' . $row['ques_id'], $this->CFG['site']['relative_url'] . 'view/answers/' . $row['ques_id'] . '/', false); ?>">video/audio</a>
    	<?php } ?>
		<?php if (chkUserImageAllowed())
						{ ?>
		<div class="clsUserThumb">
            <?php displayUserImage($row, 'small'); ?>
        </div>
        <?php } ?>
        <div class="clsUserDetails">
        	<p <?php echo $boldClass; ?>> <span class="clsQuestionLink clsNoBorder"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'answer.php?qid=' . $row['ques_id'], $this->CFG['site']['relative_url'] . 'view/answers/' . $row['ques_id'] . '/', false); ?>"><?php echo wordWrapManual($row['question'], $this->CFG['admin']['question']['line_length'], $this->CFG['admin']['question']['short_length']); ?></a></span></p>
            <p>
			<?php if (chkVideoAllowed('question') and $row['video_id'])
						{ ?>
            <span class="<?php echo $video_class; ?>"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'answer.php?qid=' . $row['ques_id'], $this->CFG['site']['relative_url'] . 'view/answers/' . $row['ques_id'] . '/', false); ?>"><img src="<?php echo $this->CFG['site']['url'] . 'images/icon-video.png' ?>" alt="<?php echo $this->LANG['questions_video_available']; ?>" /></a></span>
            <?php } ?>
            <?php if (chkAudioAllowed('question') and $row['audio_id'])
						{ ?>
            <span class="<?php echo $audio_class; ?>"><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'answer.php?qid=' . $row['ques_id'], $this->CFG['site']['relative_url'] . 'view/answers/' . $row['ques_id'] . '/', false); ?>"><img src="<?php echo $this->CFG['site']['url'] . 'images/icon-audio.png' ?>" alt="<?php echo $this->LANG['questions_audio_available']; ?>" /></a></span>
            <?php } ?>
        	</p>
            <p>
<?php

						$cat_id = $row['cat_id'];
						if (!$cat_id) $cat_id = $row['pcat_id'];
						$this->showCategoryName($cat_id);
						$video_plural = '';
						$audio_plural = '';
						$answer_plural = '';
						if ($row['total_videos'] != 1) $video_plural = 's';
						if ($row['total_audios'] != 1) $audio_plural = 's';
						if ($row['total_answer'] != 1) $answer_plural = 's';
						$video_audio_count = '';
						$video_audio_count .= chkVideoAllowed('answer') ? $row['total_videos'] . ' ' . $this->LANG['question_total_videos'] . $video_plural . ' | ' : '';
						$video_audio_count .= chkAudioAllowed('answer') ? $row['total_audios'] . ' ' . $this->LANG['question_total_audios'] . $audio_plural . ' | ' : '';
						$video_audio_count = substr($video_audio_count, 0, strrpos($video_audio_count, '|'));
						$video_audio_count = trim($video_audio_count);
						$video_audio_count = $video_audio_count ? '(' . $video_audio_count . ')' : '';
?>
			    <span class="clsNoBorder clsForumAuthor"><?php echo $this->LANG['question_asked_by']; ?> <a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'myanswers.php?uid=' . $row['user_id'], $this->CFG['site']['relative_url'] . 'my/answers/' . $row['user_id'] . '/', false); ?>"><?php echo stripString($row['asked_by'], $this->CFG['username']['short_length']); ?></a></span></p>
			    <?php if ($row['total_answer'])
						{ ?>
			    <p class="clsTotalAnswer"><span class="clsNoBorder"><?php echo $row['total_answer']; ?>&nbsp;<?php echo $this->LANG['question_total_answer'] . $answer_plural; ?> <?php echo $video_audio_count; ?></span></p>
	            <?php } elseif ($row['is_open'])
						{ ?>
	            <p> <span class="clsFirstOne clsNoBorder"><a href="<?php echo getUrl($this->CFG['site']['url'] . 'members/answer.php?qid=' . $row['ques_id'], $this->CFG['site']['url'] . 'members/view/answers/' . $row['ques_id'] . '/', false); ?>"><?php echo $this->LANG['be_the_first_to_answer']; ?></a></span></p>
	            <?php } ?>
	            <p><span><?php echo getTimeDiffernceFormat($row['date_asked']); ?></span>
	              <?php if ($row['is_open'])
						{ ?>
	              <span class="clsNoBorder"><?php echo getTimeToGoFormat($row['date_closed']); ?></span>
	              <?php }
						else
						{ ?>
	              <span class="clsResolved clsNoBorder"><?php echo $this->LANG['question_resolved']; ?></span>
	              <?php } ?>
	            </p>
          </div>
    </div>
</div>
<?php
				}
				if ($this->CFG['admin']['navigation']['bottom']) $this->populatePageLinks($this->getFormField('start'), $pagingArr);
		}
		public function askQuestions()
		{
				$style_add_video = '';
				$style_delete_video = 'style="display:none"';
				$style_preview_video = 'style="display:none"';
				$video_preview_url = getUrl('ansPreviewVideo.php', 'ansPreviewVideo.php') . '?pg=Question_' . $this->getFormField('rid');
?>
<script language="javascript" type="text/javascript">
var videoPreviewUrl = '<?php echo $video_preview_url; ?>';
</script>
<?php
				if ($this->fields_arr['video'] or $this->fields_arr['video_id'])
				{
						$style_delete_video = '';
						$style_preview_video = '';
						$style_add_video = 'style="display:none"';
						if ($this->fields_arr['video_id']) $video_preview_url = getUrl('ansViewVideo.php', 'ansViewVideo.php') . '?pg=Question_' . $this->getFormField('video_id');
						if ($this->fields_arr['video']) $video_preview_url = getUrl('ansPreviewVideo.php', 'ansPreviewVideo.php') . '?pg=Question_' . $this->getFormField('video');
				}
				$style_add_audio = '';
				$style_delete_audio = 'style="display:none"';
				$style_preview_audio = 'style="display:none"';
				$audio_preview_url = getUrl('ansPreviewAudio.php', 'ansPreviewAudio.php') . '?pg=Question_' . $this->getFormField('rid');
?>
<script language="javascript" type="text/javascript">
var audioPreviewUrl = '<?php echo $audio_preview_url; ?>';
</script>
<?php
				if ($this->fields_arr['audio'] or $this->fields_arr['audio_id'])
				{
						$style_delete_audio = '';
						$style_preview_audio = '';
						$style_add_audio = 'style="display:none"';
						if ($this->fields_arr['audio_id']) $audio_preview_url = getUrl('ansViewAudio.php', 'ansViewAudio.php') . '?pg=Question_' . $this->getFormField('audio_id');
						if ($this->fields_arr['audio']) $audio_preview_url = getUrl('ansPreviewAudio.php', 'ansPreviewAudio.php') . '?pg=Question_' . $this->getFormField('audio');
				}
				$this->LANG['tag_size'] = str_replace('{min_size}', $this->CFG['admin']['tag_min_size'], $this->LANG['tag_size']);
				$this->LANG['tag_size'] = str_replace('{max_size}', $this->CFG['admin']['tag_max_size'], $this->LANG['tag_size']);
?>
<form name="selFormAskQuestion" id="selFormAskQuestion" method="post" action="<?php echo URL($_SERVER['REQUEST_URI']); ?>" autocomplete="off">
  <?php $this->populateHidden(array('rid', 'video', 'audio', 'video_id', 'audio_id')); ?>
  <table class="clsAskQuestion" summary="<?php echo $this->LANG['questions_port_your']; ?>">
    <tr>
      <td class="<?php echo $this->getCSSFormLabelCellClass('question'); ?>"><?php ShowHelpTip('question'); ?><?php if ($this->fields_arr['qid'])
				{ ?>
        <?php echo $this->LANG['questions_your_question'] ?>
        <?php }
				else
				{ ?>
        <label for="question"><?php echo $this->LANG['questions_enter_question'] ?></label>
        <?php } ?>
      </td>
      <td class="<?php echo $this->getCSSFormFieldCellClass('question'); ?>"><?php echo $this->getFormFieldErrorTip('question'); ?>
        <?php if ($this->fields_arr['qid'])
				{ ?>
        <strong><?php echo wordWrapManual($this->getFormField('question'), 40); ?></strong>
        <?php }
				else
				{ ?>
        <input type="text" class="clsTextBox help" name="question" id="question" title="<?php ShowToolTip('question'); ?>" maxlength="250" tabindex="<?php echo $this->getTabIndex(); ?>" value="<?php echo $this->getFormField('question'); ?>" />
        <?php } ?>
      </td>
    </tr>
    <tr>
      <td class="<?php echo $this->getCSSFormLabelCellClass('description'); ?>"><?php ShowHelpTip('question_details'); ?><label for="description"><?php echo $this->LANG['questions_add_details']; ?></label></td>
      <td class="<?php echo $this->getCSSFormFieldCellClass('description'); ?>"><?php echo $this->getFormFieldErrorTip('description'); ?>
        <textarea name="description" id="description" cols="70" rows="5" <?php if ($this->CFG['admin']['description']['mandatory']) ShowToolTip('question_details'); ?> maxlength="<?php echo $this->CFG['admin']['description']['limit']; ?>" tabindex="<?php echo $this->getTabIndex(); ?>" onFocus="updatelength(this);" onKeyUp="updatelength(this);"><?php echo stripslashes($this->getFormField('description')); ?></textarea>
        <div><?php echo $this->LANG['questions_total_charaters_entered']; ?> <span id="ss">0  (Limit <?php echo $this->CFG['admin']['description']['limit']; ?>)</span></div></td>
    </tr>
    <?php if (chkVideoAllowed('question'))
				{ ?>
    <tr>
      <td class="<?php echo $this->getCSSFormLabelCellClass('video'); ?>"><?php ShowHelpTip('question_video'); ?><label for="video"><?php echo $this->LANG['questions_add_video_details']; ?></label></td>
      <td class="<?php echo $this->getCSSFormFieldCellClass('video'); ?>"><?php echo $this->getFormFieldErrorTip('video'); ?> <a <?php echo $style_add_video; ?> id="video_add" href="<?php echo getUrl('videoUpload.php', 'videoupload/') . '?rid=' . $this->fields_arr['rid']; ?>" onClick="return openAjaxWindow('video_add', -50, -200);"><?php echo $this->LANG['add_video']; ?></a> <a <?php echo $style_delete_video; ?> id="video_delete" href="<?php echo $_SERVER['REQUEST_URI']; ?>" onClick="return confrimRemove('video', 'video_delete', '<?php echo $this->LANG['are_you_sure_to_delete'] ?>', -100, -500);"><?php echo $this->LANG['delete_video']; ?></a> <a <?php echo $style_preview_video; ?> id="video_preview" href="<?php echo $video_preview_url; ?>" onClick="return openAjaxWindow('video_preview', -65, -200);"><?php echo $this->LANG['preview_video']; ?></a></td>
    </tr>
    <?php } ?>
    <?php if (chkAudioAllowed('question'))
				{ ?>
    <tr>
      <td class="<?php echo $this->getCSSFormLabelCellClass('audio'); ?>"><?php ShowHelpTip('question_audio'); ?><label for="audio"><?php echo $this->LANG['questions_add_audio_details']; ?></label></td>
      <td class="<?php echo $this->getCSSFormFieldCellClass('audio'); ?>"><?php echo $this->getFormFieldErrorTip('audio'); ?> <a <?php echo $style_add_audio; ?> id="audio_add" href="<?php echo getUrl('audioUpload.php', 'audioupload/') . '?rid=' . $this->fields_arr['rid'] . 'AUD'; ?>" onClick="return openAjaxWindow('audio_add', -50, -200);"><?php echo $this->LANG['add_audio']; ?></a> <a <?php echo $style_delete_audio; ?> id="audio_delete" href="<?php echo $_SERVER['REQUEST_URI']; ?>" onClick="return confrimRemove('audio', 'audio_delete', '<?php echo $this->LANG['are_you_sure_to_delete'] ?>', -100, -500);"><?php echo $this->LANG['delete_audio']; ?></a> <a <?php echo $style_preview_audio; ?> id="audio_preview" href="<?php echo $audio_preview_url; ?>"  onClick="return openAjaxWindow('audio_preview', -65, -100);"><?php echo $this->LANG['preview_audio']; ?></a></td>
    </tr>
    <?php } ?>
    <?php
				$cat_tab_index = $this->getTabIndex();
				$sub_cat_tab_index = $this->getTabIndex();
?>
    <tr>
      <td class="<?php echo $this->getCSSFormLabelCellClass('category'); ?>"><?php ShowHelpTip('question_category'); ?><label for="category"><?php echo $this->LANG['questions_select_category']; ?></label></td>
      <td class="<?php echo $this->getCSSFormFieldCellClass('category'); ?>"><?php echo $this->getFormFieldErrorTip('category'); ?>
        <select name="category" id="category" tabindex="<?php echo $cat_tab_index; ?>" onchange="return call_ajax_populate_sub_categories('<?php echo $this->CFG['site']['url'] . 'members/'; ?>questions_ajax.php', 't=<?php echo $sub_cat_tab_index; ?>','subCatDiv');">
          <?php echo $this->LANG['questions_chose_category']; ?>
          </option>
          <?php $this->populateCategories($this->getFormField('category')); ?>
        </select>
      </td>
    </tr>
    <tr>
      <td class="<?php echo $this->getCSSFormLabelCellClass('sub_category'); ?>"><?php ShowHelpTip('question_subcategory'); ?><label for="sub_category"><?php echo $this->LANG['questions_select_sub_category']; ?></label></td>
      <td class="<?php echo $this->getCSSFormFieldCellClass('sub_category'); ?>" id="subCatDiv"><?php echo $this->getFormFieldErrorTip('sub_category'); ?>
        <select name="sub_category" id="sub_category" tabindex="<?php echo $sub_cat_tab_index; ?>">
          <option value=""><?php echo $this->LANG['questions_chose_category']; ?></option>
          <?php $this->populateSubCategories($this->getFormField('category'), $this->getFormField('sub_category')); ?>
        </select>
      </td>
    </tr>
    <tr>
      <td class="<?php echo $this->getCSSFormLabelCellClass('tags'); ?>"><?php ShowHelpTip('question_tag'); ?><label for="tags"><?php echo $this->LANG['questions_enter_tags']; ?></label></td>
      <td class="<?php echo $this->getCSSFormFieldCellClass('tags'); ?>"><?php echo $this->getFormFieldErrorTip('tags'); ?>
        <input type="text" class="clsTextBox" name="tags" id="tags" maxlength="250" tabindex="<?php echo $this->getTabIndex(); ?>" value="<?php echo $this->getFormField('tags'); ?>" />
        <p><?php echo $this->LANG['questions_subscribe_keywords_info'] . ' ' . $this->LANG['tag_size'] . ' ' . $this->LANG['questions_subscribe_keywords_invalid']; ?></p>
      </td>
    </tr>
    <tr>
      <td class="clsRight <?php echo $this->getCSSFormFieldCellClass('submit'); ?>" colspan="2"><?php if ($this->fields_arr['qid'])
				{ ?>
        <input type="submit" class="clsSubmitButton clsMediumSubmitButton" name="update_question" id="update_question" tabindex="<?php echo $this->getTabIndex(); ?>" value="<?php echo $this->LANG['questions_update_button']; ?>" />
        <input type="hidden" name="qid" id="qid" value="<?php echo $this->fields_arr['qid']; ?>" />
        <?php }
				else
				{ ?>
        <input type="submit" class="clsSubmitButton clsMediumSubmitButton" name="submit" id="submit" tabindex="<?php echo $this->getTabIndex(); ?>" value="<?php echo $this->LANG['questions_ask_button']; ?>" />
        <?php } ?>
        &nbsp;&nbsp;
        <input type="submit" class="clsCancelButton" name="cancel" id="cancel" tabindex="<?php echo $this->getTabIndex(); ?>" value="<?php echo $this->LANG['cancel']; ?>" />
      </td>
    </tr>
  </table>
</form>
<?php
		}
		public function populateCategories($cid)
		{
				$sql = 'SELECT cat_id, cat_name FROM ' . $this->CFG['db']['tbl']['questions_category'] . ' WHERE parent_id=0 AND status=\'1\' ORDER BY cat_name';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount())
				{
						while ($row = $rs->FetchRow())
						{
?>
<option value="<?php echo $row['cat_id']; ?>" <?php echo ($row['cat_id'] == $cid) ? 'selected' : ''; ?>><?php echo $row['cat_name']; ?></option>
<?php
						}
				}
		}
		public function populateSubCategories($cid, $scid)
		{
				if (!$cid) return;
				$sql = 'SELECT cat_id, cat_name FROM ' . $this->CFG['db']['tbl']['questions_category'] . ' WHERE parent_id=' . $this->dbObj->Param('cid') . ' AND status=\'1\' ORDER BY cat_name';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($cid));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount())
				{
						while ($row = $rs->FetchRow())
						{
?>
<option value="<?php echo $row['cat_id']; ?>" <?php echo ($row['cat_id'] == $scid) ? 'selected' : ''; ?>><?php echo $row['cat_name']; ?></option>
<?php
						}
				}
		}
		public function chkIsQuestionExists($field, $err_tip = '')
		{
				$sql = 'SELECT ques_id FROM ' . $this->CFG['db']['tbl']['questions'] . ' WHERE question LIKE ' . $this->dbObj->Param('question');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr[$field]));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if (!$rs->PO_RecordCount()) return true;
				$this->setCommonErrorMsg($err_tip);
				return false;
		}
		public function insertAnsVideoTable()
		{
				$sql = 'INSERT INTO ' . $this->CFG['db']['tbl']['ans_video'] . ' SET' . ' content_id=' . $this->dbObj->Param('content_id') . ',' . ' user_id=' . $this->dbObj->Param('user_id') . ',' . ' video_for=\'Question\',' . ' video_ext=\'flv\',' . ' date_added=NOW(),' . ' video_encoded_status=\'Partial\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['content_id'], $this->CFG['user']['user_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return $this->dbObj->Insert_ID();
		}
		public function insertAnsAudioTable()
		{
				$sql = 'INSERT INTO ' . $this->CFG['db']['tbl']['ans_audio'] . ' SET' . ' content_id=' . $this->dbObj->Param('content_id') . ',' . ' user_id=' . $this->dbObj->Param('user_id') . ',' . ' audio_for=\'Question\',' . ' audio_ext=\'flv\',' . ' date_added=NOW(),' . ' audio_encoded_status=\'Partial\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['content_id'], $this->CFG['user']['user_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return $this->dbObj->Insert_ID();
		}
		public function changeAnsVideoStatus($video_id, $status)
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['ans_video'] . ' SET' . ' video_encoded_status=' . $this->dbObj->Param('video_encoded_status') . ' WHERE video_id=' . $this->dbObj->Param('video_id');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($status, $video_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function changeAnsAudioStatus($audio_id, $status)
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['ans_audio'] . ' SET' . ' audio_encoded_status=' . $this->dbObj->Param('audio_encoded_status') . ' WHERE audio_id=' . $this->dbObj->Param('audio_id');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($status, $audio_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function addQuestion()
		{
				$this->fields_arr['content_id'] = $this->insertQuestion();
				$this->updateUserAnswerLog();
				$this->addNewVideo();
				$this->addNewAudio();
				$this->updateTags();
				$this->updateCategoryQuestionCount($this->fields_arr['category']);
				if ($this->fields_arr['sub_category']) $this->updateCategoryQuestionCount($this->fields_arr['sub_category']);
		}
		public function updateCategoryQuestionCount($cat_id)
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['questions_category'] . ' SET total_questions=total_questions+1' . ' WHERE cat_id=' . $this->dbObj->Param($cat_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($cat_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function decreaseCategoryQuestionCount($cat_id)
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['questions_category'] . ' SET total_questions=total_questions-1' . ' WHERE cat_id=' . $this->dbObj->Param($cat_id) . ' AND total_questions>0';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($cat_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function addNewVideo()
		{
				if ($this->fields_arr['video'])
				{
						$this->fields_arr['video_id'] = $this->insertAnsVideoTable();
						if ($this->fp)
						{
								$log_str = 'Video Record created : ' . $this->fields_arr['video_id'] . "\r\n";
								$this->writetoTempFile($log_str);
						}
						$video_name = getImageName($this->fields_arr['video_id']);
						$temp_dir = '../' . $this->CFG['admin']['ans_videos']['temp_folder'];
						$this->chkAndCreateFolder($temp_dir);
						$temp_file = $temp_dir . $video_name . '.flv';
						$file_name = $this->CFG['admin']['video']['red5_flv_path'] . $this->fields_arr['rid'] . '.flv';
						copy($file_name, $temp_file);
						unlink($file_name);
						if ($this->fp)
						{
								$log_str = 'Video stored in temp server : ' . $temp_file . "\r\n";
								$this->writetoTempFile($log_str);
						}
						$this->changeAnsVideoStatus($this->fields_arr['video_id'], 'No');
						if ($this->CFG['admin']['ans_videos']['video_auto_encode'])
						{
								if ($this->fp)
								{
										$log_str = 'Calling Video Encode \r\n';
										$this->writetoTempFile($log_str);
								}
								$this->videoEncode($this->fields_arr['video_id']);
						}
						$temp_dir = '../' . $this->CFG['admin']['ans_videos']['temp_folder'];
						$temp_file = $temp_dir . $this->fields_arr['rid'] . '.flv';
						if (file_exists($temp_file)) unlink($temp_file);
				}
		}
		public function addNewAudio()
		{
				if ($this->fields_arr['audio'])
				{
						$this->fields_arr['audio_id'] = $this->insertAnsAudioTable();
						if ($this->fp)
						{
								$log_str = 'Audio Record created : ' . $this->fields_arr['audio_id'] . "\r\n";
								$this->writetoTempFile($log_str);
						}
						$audio_name = getImageName($this->fields_arr['audio_id']);
						$temp_dir = '../' . $this->CFG['admin']['ans_audios']['temp_folder'];
						$this->chkAndCreateFolder($temp_dir);
						$temp_file = $temp_dir . $audio_name . '.flv';
						$file_name = $this->CFG['admin']['video']['red5_flv_path'] . $this->fields_arr['rid'] . 'AUD.flv';
						copy($file_name, $temp_file);
						unlink($file_name);
						if ($this->fp)
						{
								$log_str = 'Audio stored in temp server : ' . $temp_file . "\r\n";
								$this->writetoTempFile($log_str);
						}
						$this->changeAnsAudioStatus($this->fields_arr['audio_id'], 'No');
						if ($this->CFG['admin']['ans_audios']['audio_auto_encode'])
						{
								if ($this->fp)
								{
										$log_str = 'Calling Audio Encode \r\n';
										$this->writetoTempFile($log_str);
								}
								$this->audioEncode($this->fields_arr['audio_id']);
						}
						$temp_dir = '../' . $this->CFG['admin']['ans_audios']['temp_folder'];
						$temp_file = $temp_dir . $this->fields_arr['rid'] . 'AUD.flv';
						if (file_exists($temp_file)) unlink($temp_file);
				}
		}
		public function updateTags()
		{
				$tags = explode(' ', $this->fields_arr['tags']);
				foreach ($tags as $eachTag)
				{
						if (trim($eachTag) == '') continue;
						if ($this->isTagExists($eachTag)) $this->updateTagCount($eachTag);
						else  $this->insertTagCount($eachTag);
				}
		}
		public function isTagExists($tagname)
		{
				$sql = 'SELECT 1 FROM ' . $this->CFG['db']['tbl']['tags'] . ' WHERE tag_name=' . $this->dbObj->Param($tagname);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($tagname));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$ok = false;
				if ($rs->PO_RecordCount()) $ok = true;
				return $ok;
		}
		public function updateTagCount($tagname)
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['tags'] . ' SET total_count=total_count+1' . ' WHERE tag_name=' . $this->dbObj->Param($tagname);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($tagname));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function updateSearchCount($tags)
		{
				$tags = trim($tags);
				while (strpos($tags, '  '))
				{
						$tags = str_replace('  ', ' ', $tags);
				}
				$tags = addslashes($tags);
				$tags_arr = explode(' ', $tags);
				foreach ($tags_arr as $tagname)
				{
						$sql = 'UPDATE ' . $this->CFG['db']['tbl']['tags'] . ' SET search_count=search_count+1' . ' WHERE tag_name=' . $this->dbObj->Param($tagname);
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($tagname));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				}
		}
		public function insertTagCount($tagname)
		{
				$sql = 'INSERT INTO ' . $this->CFG['db']['tbl']['tags'] . ' SET tag_name=' . $this->dbObj->Param($tagname) . ', total_count=1';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($tagname));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function updateQuestion()
		{
				$this->fields_arr['tags'] = $this->removeDuplicateKeywords($this->fields_arr['tags']);
				$this->decreaseCategoryQuestionCount($this->question_details['pcat_id']);
				if ($this->question_details['cat_id']) $this->decreaseCategoryQuestionCount($this->question_details['cat_id']);
				$cat_id = $this->fields_arr['category'];
				if ($this->fields_arr['sub_category']) $cat_id = $this->fields_arr['sub_category'];
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['questions'] . ' SET description=' . $this->dbObj->Param('description') . ', tags=' . $this->dbObj->Param('tags') . ', pcat_id=' . $this->dbObj->Param('pcat_id') . ', cat_id=' . $this->dbObj->Param('cat_id') . ', video_id=' . $this->dbObj->Param('video_id') . ', audio_id=' . $this->dbObj->Param('audio_id') . ' WHERE ques_id=' . $this->dbObj->Param('qid') . ' AND user_id=' . $this->dbObj->Param('uid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['description'], $this->fields_arr['tags'], $this->fields_arr['category'], $this->fields_arr['sub_category'], $this->fields_arr['video_id'], $this->fields_arr['audio_id'], $this->fields_arr['qid'], $this->CFG['user']['user_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($this->fields_arr['video'] or ($this->fields_arr['video_id'] == 0))
				{
						$sql = 'UPDATE ' . $this->CFG['db']['tbl']['ans_video'] . ' SET' . ' video_status=\'Deleted\' WHERE' . ' content_id=' . $this->dbObj->Param('content_id') . ' AND' . ' video_for=\'Question\'';
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['qid']));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
						$this->fields_arr['content_id'] = $this->fields_arr['qid'];
						if ($this->fields_arr['video']) $this->addNewVideo();
				}
				if ($this->fields_arr['audio'] or ($this->fields_arr['audio_id'] == 0))
				{
						$sql = 'UPDATE ' . $this->CFG['db']['tbl']['ans_audio'] . ' SET' . ' audio_status=\'Deleted\' WHERE' . ' content_id=' . $this->dbObj->Param('content_id') . ' AND' . ' audio_for=\'Question\'';
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['qid']));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
						$this->fields_arr['content_id'] = $this->fields_arr['qid'];
						if ($this->fields_arr['audio']) $this->addNewAudio();
				}
				$this->updateCategoryQuestionCount($this->fields_arr['category']);
				if ($this->fields_arr['sub_category']) $this->updateCategoryQuestionCount($this->fields_arr['sub_category']);
				return;
		}
		public function insertQuestion()
		{
				$this->fields_arr['tags'] = $this->removeDuplicateKeywords($this->fields_arr['tags']);
				$sql = 'INSERT INTO ' . $this->CFG['db']['tbl']['questions'] . ' SET user_id=' . $this->dbObj->Param('uid') . ', question=' . $this->dbObj->Param('question') . ', description=' . $this->dbObj->Param('description') . ', tags=' . $this->dbObj->Param('tags') . ', pcat_id=' . $this->dbObj->Param('pcat_id') . ', cat_id=' . $this->dbObj->Param('cat_id') . ', date_asked=NOW(), date_answered=NOW()' . ', date_closed=DATE_ADD(NOW(), INTERVAL ' . $this->CFG['admin']['question']['open_days'] . ' DAY)';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->CFG['user']['user_id'], $this->fields_arr['question'], $this->fields_arr['description'], $this->fields_arr['tags'], $this->fields_arr['category'], $this->fields_arr['sub_category']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return $this->dbObj->Insert_ID();
		}
		public function updateUserAnswerLog()
		{
				if (!$this->CFG['admin']['ask_answers']['allowed']) return;
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['users_ans_log'] . ' SET total_ques=total_ques+1' . ', total_points=total_points+' . $this->CFG['admin']['ask_answers']['points'] . ', date_updated=NOW()' . ' WHERE user_id=' . $this->dbObj->Param('uid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->CFG['user']['user_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function chkIsValidCaptureVideoFile()
		{
				if (0)
				{
						$temp_file = '../files/cgi-php-out.flv';
						$file_name = $this->CFG['admin']['video']['red5_flv_path'] . $this->fields_arr['rid'] . '.flv';
						copy($temp_file, $file_name);
				}
				$file_name = $this->CFG['admin']['video']['red5_flv_path'] . $this->fields_arr['rid'] . '.flv';
				if ($this->fields_arr['video'] == $this->fields_arr['rid'])
				{
						if (is_file($file_name)) return true;
						$this->fields_arr['video'] = '';
						return false;
				}
				if (is_file($file_name)) unlink($file_name);
		}
		public function chkIsValidCaptureAudioFile()
		{
				if (0)
				{
						$temp_file = '../files/cgi-php-out.flv';
						$file_name = $this->CFG['admin']['video']['red5_flv_path'] . $this->fields_arr['rid'] . 'AUD.flv';
						copy($temp_file, $file_name);
				}
				$file_name = $this->CFG['admin']['video']['red5_flv_path'] . $this->fields_arr['rid'] . 'AUD.flv';
				if ($this->fields_arr['audio'] == $this->fields_arr['rid'])
				{
						if (is_file($file_name))
						{
								return true;
						}
						$this->fields_arr['audio'] = '';
						return false;
				}
				if (is_file($file_name)) unlink($file_name);
		}
		public function generateRandomId()
		{
				$time = time();
				$this->fields_arr['rid'] = md5($time);
		}
		public function populateUserDetailsArr()
		{
				$sql = 'SELECT ' . $this->getUserTableFields(array('name', 'user_id')) . ' FROM ' . $this->CFG['db']['tbl']['users'] . ' WHERE ' . $this->getUserTableField('name') . ' = ' . $this->dbObj->Param('name') . ' AND ' . $this->getUserTableField('usr_status') . '=\'OK\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['uname']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($row = $rs->FetchRow())
				{
						$this->user_details = $row;
						return true;
				}
				return false;
		}
}
$questions = new QuestionFormHandler();
$questions->setCfgLangGlobal($CFG, $LANG);
$questions->setPageBlockNames(array('form_search_results', 'form_advanced_search', 'form_add', 'form_popular', 'form_recent', 'form_open', 'form_resolved', 'msg_form_error', 'msg_form_success', 'form_information', 'form_users_questions'));
$questions->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$questions->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$questions->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$questions->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$questions->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$questions->setFormField('question', '');
$questions->setFormField('description', '');
$questions->setFormField('search_question', '');
$questions->setFormField('tags', '');
$questions->setFormField('view', '');
$questions->setFormField('orderby_field', '');
$questions->setFormField('orderby', '');
$questions->setFormField('str', '');
$questions->setFormField('msg', '');
$questions->setFormField('cid', '');
$questions->setFormField('qid', '');
$questions->setFormField('category', '1');
$questions->setFormField('sub_category', '');
$questions->setFormField('video', '');
$questions->setFormField('video_id', '');
$questions->setFormField('audio', '');
$questions->setFormField('audio_id', '');
$questions->setFormField('rid', '');
$questions->setFormField('sort', 'date');
$questions->setFormField('order', '');
$questions->setFormField('uname', '');
$questions->setFormField('tags', '');
$questions->setFormField('with', '');
$questions->setFormField('type', '');
$questions->setFormField('more_questions', '');
$questions->setFormField('so', 'min');
$questions->setFormField('cat_id', '');
$questions->setFormField('video', '');
$questions->setFormField('audio', '');
$questions->setFormField('total_answer_from', '');
$questions->setFormField('total_answer_to', '');
$questions->setFormField('date_added_from', '');
$questions->setFormField('date_added_from_day', '');
$questions->setFormField('date_added_from_month', '');
$questions->setFormField('date_added_from_year', '');
$questions->setFormField('date_added_to', '');
$questions->setFormField('date_added_to_day', '');
$questions->setFormField('date_added_to_month', '');
$questions->setFormField('date_added_to_year', '');
$questions->setFormField('adv_search', '');
$questions->setFormField('opt', '');
$questions->setFormField('al', 'All');
$questions->setMonthsListArr($LANG_LIST_ARR['months']);
$pagename = 'Answers';
$questions->display_bold = 3;
$title = 'Recent Questions';
$questions->setDBObject($db);
$questions->numpg = $CFG['data_tbl']['numpg'];
$questions->setFormField('start', 0);
$questions->setFormField('numpg', $CFG['data_tbl']['numpg']);
$questions->setMinRecordSelectLimit($CFG['data_tbl']['min_record_select_limit']);
$questions->setMaxRecordSelectLimit($CFG['data_tbl']['max_record_select_limit']);
$questions->setNumPerPageListArr($CFG['data_tbl']['numperpage_list_arr']);
$questions->setTableNames(array());
$questions->setReturnColumns(array());
$questions->setFormField('orderby_field', '');
$questions->setFormField('orderby', '');
$questions->sanitizeFormInputs($_REQUEST);
$questions->setAllPageBlocksHide();
if (!$questions->getFormField('rid')) $questions->generateRandomId();
switch ($questions->getFormField('view'))
{
		case 'ask':
				if (!isset($CFG['user']['user_id']) or empty($CFG['user']['user_id']))
				{
						$_SESSION['url'] = getUrl('questions.php?view=ask', 'answers/ask/', false);
						Redirect2URL(getUrl($CFG['site']['url'] . 'login.php', $CFG['site']['url'] . 'login/', false));
				}
				if ($questions->isAllowedToAsk()) $questions->setPageBlockShow('form_add');
				else
				{
						$questions->setPageBlockShow('form_information');
						$questions->setCommonErrorMsg($LANG['info_not_allowed_to_ask']);
				}
				$title = 'Ask Questions?';
				break;
		case 'search':
				$questions->setPageBlockShow('form_search_results');
				$title = 'Search Results';
				$search_home = '<a href="' . getUrl($CFG['site']['url'] . 'questions.php', $CFG['site']['url'] . 'answers/', false) . '">Home</a> > ' . $title;
				$uname = $questions->getFormField('uname');
				$opt = $questions->getFormField('opt');
				if ($uname and $opt)
				{
						switch ($opt)
						{
								case 'ans':
										$search_home = '<a href="' . getUrl($CFG['site']['url'] . 'questions.php', $CFG['site']['url'] . 'answers/', false) . '">Home</a> > ' . $uname . ' > ' . $LANG['answered_questions'];
										$users_no_records = $LANG['questions_no_answered_questions'];
										break;
								case 'ques':
										$search_home = '<a href="' . getUrl($CFG['site']['url'] . 'questions.php', $CFG['site']['url'] . 'answers/', false) . '">Home</a> > ' . $uname . ' > ' . $LANG['asked_questions'];
										$users_no_records = $LANG['questions_no_asked_questions'];
										break;
								case 'resolve':
										$search_home = '<a href="' . getUrl($CFG['site']['url'] . 'questions.php', $CFG['site']['url'] . 'answers/', false) . '">Home</a> > ' . $uname . ' > ' . $LANG['resolved_questions'];
										$users_no_records = $LANG['questions_no_resolved_questions'];
										break;
								case 'fav':
										$search_home = '<a href="' . getUrl($CFG['site']['url'] . 'questions.php', $CFG['site']['url'] . 'answers/', false) . '">Home</a> > ' . $uname . ' > ' . $LANG['favorite_questions'];
										$users_no_records = $LANG['questions_no_favorite_questions'];
										break;
						}
						$LANG['questions_no_records'] = $users_no_records;
						$questions->setPageBlockShow('form_users_questions');
				}
				break;
		case 'popular':
				$questions->setPageBlockShow('form_popular');
				$title = 'Popular Questions';
				break;
		case 'open':
				$questions->setPageBlockShow('form_open');
				$title = 'Open Questions';
				break;
		case 'resolved':
				$questions->setPageBlockShow('form_resolved');
				$title = 'Resolved Questions';
				break;
		default:
				$questions->setPageBlockShow('form_recent');
				$title = 'Recent Questions';
				$questions->setFormField('view', 'recent');
				break;
}
if ($questions->getFormField('al') != '1' and $questions->getFormField('al') != 'All') $title .= ' starts with "' . $questions->getFormField('al') . '"';
elseif ($questions->getFormField('al') == '1') $title .= ' starts with "Non Alphabets"';
if ($questions->getFormField('so') == 'adv' and !$questions->isFormGETed($_GET, 'adv_search') and !$questions->isFormGETed($_POST, 'adv_search')) $search_home = '<a href="' . getUrl($CFG['site']['url'] . 'questions.php', $CFG['site']['url'] . 'answers/', false) . '">Home</a> > Advance Search';
if ($questions->isFormPOSTed($_POST, 'submit'))
{
		$questions->chkIsNotEmpty('question', $LANG['questions_err_tip_compulsory']) and $questions->chkIsQuestionExists('question', $LANG['questions_err_exists_already']);
		if ($CFG['admin']['category']['mandatory']) $questions->chkIsNotEmpty('category', $LANG['questions_err_tip_compulsory']);
		if ($CFG['admin']['description']['mandatory']) $questions->chkIsNotEmpty('description', $LANG['questions_err_tip_compulsory']);
		if (!$questions->isAllowedToAsk()) $questions->setCommonErrorMsg($LANG['info_not_allowed_to_ask']);
		$questions->chkIsValidCaptureVideoFile();
		$questions->chkIsValidCaptureAudioFile();
		if ($questions->isValidFormInputs())
		{
				if ($CFG['debug']['store_log'])
				{
						$questions->createErrorLogFile('question');
				}
				$questions->addQuestion();
				if ($CFG['debug']['store_log'])
				{
						$questions->closeErrorLogFile();
				}
				$questions->setCommonSuccessMsg($LANG['questions_added_successfully']);
				$questions->setPageBlockShow('msg_form_success');
				Redirect2URL(getUrl($CFG['site']['relative_url'] . 'questions.php?view=open&msg=1', $CFG['site']['relative_url'] . 'answers/open/?msg=1', false));
		}
		else
		{
				$questions->setPageBlockShow('msg_form_error');
		}
}
else
		if ($questions->isFormPOSTed($_POST, 'update_question'))
		{
				$questions->chkIsValidQuestion();
				if ($CFG['admin']['category']['mandatory']) $questions->chkIsNotEmpty('category', $LANG['questions_err_tip_compulsory']);
				if ($CFG['admin']['description']['mandatory']) $questions->chkIsNotEmpty('description', $LANG['questions_err_tip_compulsory']);
				$questions->chkIsValidCaptureVideoFile();
				$questions->chkIsValidCaptureAudioFile();
				if ($questions->isValidFormInputs())
				{
						if ($CFG['debug']['store_log'])
						{
								$questions->createErrorLogFile('question');
						}
						$questions->updateQuestion();
						if ($CFG['debug']['store_log'])
						{
								$questions->closeErrorLogFile();
						}
						$questions->setCommonSuccessMsg($LANG['questions_updated_successfully']);
						$questions->setPageBlockShow('msg_form_success');
						Redirect2URL(getUrl($CFG['site']['relative_url'] . 'answer.php?qid=' . $questions->getFormField('qid') . '&msg=5', $CFG['site']['relative_url'] . 'view/answers/' . $questions->getFormField('qid') . '/?msg=5', false));
				}
				else
				{
						$questions->setPageBlockShow('msg_form_error');
				}
		}
		else
				if ($questions->isFormGETed($_GET, 'cid'))
				{
						$questions->setAllPageBlocksHide();
						if ($questions->getFormField('view') == 'ask')
						{
								$questions->setFormField('qid', $questions->getFormField('cid'));
								$questions->chkIsValidQuestion();
								if ($questions->isValidFormInputs())
								{
										$questions->setPageBlockShow('form_add');
										$questions->setFormField('question', $questions->question_details['question']);
										$questions->setFormField('video_id', $questions->question_details['video_id']);
										$questions->setFormField('audio_id', $questions->question_details['audio_id']);
										$questions->setFormField('description', $questions->question_details['description']);
										$questions->setFormField('tags', $questions->question_details['tags']);
										$questions->setFormField('category', $questions->question_details['pcat_id']);
										$questions->setFormField('sub_category', $questions->question_details['cat_id']);
										$cat_id = $questions->question_details['cat_id'];
										if (!$cat_id) $cat_id = $questions->question_details['pcat_id'];
								}
								else
								{
										$questions->setPageBlockShow('msg_form_error');
								}
						}
						else
						{
								$questions->setPageBlockShow('form_open');
								$title = $questions->displayCategoryName();
								if ($questions->getFormField('view') == 'open') $title .= ' - Open Questions';
								elseif ($questions->getFormField('view') == 'resolved') $title .= ' - Resolved Questions';
								else  $title .= ' - All Questions';
						}
				}
if ($questions->isFormPOSTed($_POST, 'cancel'))
{
		if ($questions->getFormField('qid')) Redirect2URL(getUrl($CFG['site']['relative_url'] . 'answer.php?qid=' . $questions->getFormField('qid'), $CFG['site']['relative_url'] . 'view/answers/' . $questions->getFormField('qid') . '/', false));
		else  Redirect2Url(getUrl($CFG['site']['relative_url'] . 'questions.php', $CFG['site']['relative_url'] . 'answers/', false));
}
if ($questions->isFormGETed($_GET, 'msg'))
{
		switch ($questions->getFormField('msg'))
		{
				case '1':
						$questions->setCommonSuccessMsg($LANG['questions_added_successfully']);
						break;
				case '2':
						$questions->setCommonSuccessMsg($LANG['questions_updated_successfully']);
						break;
				case '3':
						$questions->setCommonSuccessMsg($LANG['questions_deleted_successfully']);
						break;
		}
		$questions->setPageBlockShow('msg_form_success');
}
$questions->setFormField('orderby_field', 'ques_id');
$questions->setFormField('orderby', 'DESC');
if ($questions->getFormField('sort') == 'ans')
{
		$questions->setFormField('orderby_field', 'total_answer');
}
if ($questions->getFormField('order') == 'a')
{
		$questions->setFormField('orderby', 'ASC');
}
if ($questions->getFormField('so') == 'adv' and !$questions->isFormPOSTed($_REQUEST, 'adv_search'))
{
		$questions->populateSearchFields();
		$questions->setPageBlockHide('form_search_results');
		$questions->setAllPageBlocksHide();
		$questions->setPageBlockShow('form_advanced_search');
}
if ($questions->isFormGETed($_GET, 'adv_search'))
{
		$questions->populateSearchFields();
		$questions->setAllPageBlocksHide();
		$questions->setPageBlockShow('form_search_results');
}
if ($questions->isFormPOSTed($_POST, 'adv_search'))
{
		$from_date = $questions->getFormField('date_added_from_day') . "-" . $questions->getFormField('date_added_from_month') . "-" . $questions->getFormField('date_added_from_year');
		$to_date = $questions->getFormField('date_added_to_day') . "-" . $questions->getFormField('date_added_to_month') . "-" . $questions->getFormField('date_added_to_year');
		$questions->setFormField('date_added_from', $from_date);
		$questions->setFormField('date_added_to', $to_date);
		$questions->getFormField('total_answer_from') and $questions->chkIsNumeric('total_answer_from', $LANG['err_tip_numeric']);
		$questions->getFormField('total_answer_to') and $questions->chkIsNumeric('total_answer_to', $LANG['err_tip_numeric']);
		$questions->checkIsValidDate('date_added_from_day', 'date_added_from_month', 'date_added_from_year', 'date_added_from', $LANG['invalid_date']);
		$questions->checkIsValidDate('date_added_to_day', 'date_added_to_month', 'date_added_to_year', 'date_added_to', $LANG['invalid_date']);
		if ($questions->isValidFormInputs())
		{
				$questions->setAllPageBlocksHide();
				$questions->storeSearchFields();
				$questions->setPageBlockShow('form_search_results');
		}
		else
		{
				$questions->setAllPageBlocksHide();
				$questions->setPageBlockShow('form_advanced_search');
				$questions->setPageBlockShow('msg_form_error');
				$questions->setCommonErrorMsg($LANG['err_msg_invalid_search_option']);
		}
}
if ($questions->isFormPOSTed($_REQUEST, 'opt'))
{
		if ($questions->populateUserDetailsArr())
		{
				switch ($questions->getFormField('opt'))
				{
						case 'ans':
								$questions->setTableNames(array($CFG['db']['tbl']['questions'] . ' as q', $CFG['db']['tbl']['users'] . ' as u'));
								$questions->setReturnColumns(array('ques_id', 'q.cat_id', 'q.total_answer', 'q.status', 'q.user_id', 'u.' . $questions->getUserTableField('user_id') . ' as img_user_id', $questions->getUserTableField('name') . ' as asked_by', $questions->getUserTableFields(array('image_path', 'gender', 't_height', 't_width', 'photo_server_url', 'photo_ext'), false) . 'question', 'total_stars', 'TIMEDIFF(NOW(), date_asked) as date_asked', 'video_id', 'audio_id', 'IF(status=\'Open\' AND date_closed>=NOW(), 1, 0) is_open', 'TIMEDIFF(date_closed, NOW()) as date_closed'));
								$questions->setFormField('orderby_field', 'q.ques_id');
								$questions->setFormField('orderby', 'DESC');
								$questions->sql_condition = 'q.user_id=u.' . $questions->getUserTableField('user_id') . ' AND q.status IN (\'Open\', \'Resolved\') AND u.' . $questions->getUserTableField('usr_status') . '=\'Ok\'';
								$questions->sql_condition .= ' AND EXISTS (SELECT ques_id FROM ' . $CFG['db']['tbl']['answers'] . ' AS a WHERE a.user_id=\'' . addslashes($questions->user_details['user_id']) . '\' AND q.ques_id = a.ques_id)';
								break;
						case 'fav':
								$questions->setTableNames(array($CFG['db']['tbl']['questions'] . ' as q', $CFG['db']['tbl']['users'] . ' as u'));
								$questions->setReturnColumns(array('ques_id', 'q.cat_id', 'q.total_answer', 'q.status', 'q.user_id', $questions->getUserTableField('name') . ' as asked_by', 'u.' . $questions->getUserTableField('user_id') . ' as img_user_id', $questions->getUserTableFields(array('image_path', 'gender', 't_height', 't_width', 'photo_server_url', 'photo_ext'), false) . 'question', 'total_stars', 'TIMEDIFF(NOW(), date_asked) as date_asked', 'video_id', 'audio_id', 'IF(status=\'Open\' AND date_closed>=NOW(), 1, 0) is_open', 'TIMEDIFF(date_closed, NOW()) as date_closed'));
								$questions->setFormField('orderby_field', 'q.ques_id');
								$questions->setFormField('orderby', 'DESC');
								$questions->sql_condition = 'q.user_id=u.' . $questions->getUserTableField('user_id') . ' AND q.status IN (\'Open\', \'Resolved\') AND u.' . $questions->getUserTableField('usr_status') . '=\'Ok\'';
								$questions->sql_condition .= ' AND EXISTS (SELECT content_id FROM ' . $CFG['db']['tbl']['user_bookmarked'] . ' AS uf WHERE uf.user_id=\'' . addslashes($questions->user_details['user_id']) . '\' AND q.ques_id = uf.content_id AND uf.content_type=\'Question\')';
								break;
						case 'resolve':
								$questions->setTableNames(array($CFG['db']['tbl']['questions'] . ' as q', $CFG['db']['tbl']['users'] . ' as u'));
								$questions->setReturnColumns(array('ques_id', 'q.cat_id', 'q.total_answer', 'q.status', 'q.user_id', $questions->getUserTableField('name') . ' as asked_by', 'u.' . $questions->getUserTableField('user_id') . ' as img_user_id', $questions->getUserTableFields(array('image_path', 'gender', 't_height', 't_width', 'photo_server_url', 'photo_ext'), false) . 'question', 'total_stars', 'TIMEDIFF(NOW(), date_asked) as date_asked', 'video_id', 'audio_id', 'IF(status=\'Open\' AND date_closed>=NOW(), 1, 0) is_open', 'TIMEDIFF(date_closed, NOW()) as date_closed'));
								$questions->setFormField('orderby_field', 'q.ques_id');
								$questions->setFormField('orderby', 'DESC');
								$questions->sql_condition = 'q.user_id=u.' . $questions->getUserTableField('user_id') . ' AND q.status=\'Resolved\' AND u.' . $questions->getUserTableField('usr_status') . '=\'Ok\'';
								$questions->sql_condition .= ' AND q.user_id=\'' . addslashes($questions->user_details['user_id']) . '\'';
								break;
				}
		}
		$questions->setAllPageBlocksHide();
		$questions->setPageBlockShow('form_search_results');
		$questions->setPageBlockShow('form_users_questions');
}
$CFG['html']['page_id'] .= $questions->getFormField('view');
$CFG['mods']['is_include_only']['non_html_header_files'] = false;
$CFG['mods']['is_include_only']['html_header'] = true;
$CFG['site']['title'] = $CFG['site']['title'] . ' - ' . $title;
require ($CFG['site']['project_path'] . 'common/application_top.inc.php');
?>
<script language="javascript" type="text/javascript">
var block_arr= new Array('selMsgConfirm');
</script>
<div id="selListAll" class="clsAskQuestionPopup">
  <h2><?php echo ($questions->getFormField('view') == 'search') ? $search_home : $title; ?></h2>
  <?php
if ($questions->getFormField('view') != 'search') $questions->displayAnswersTopLinks();
if ($questions->isShowPageBlock('msg_form_error'))
{
?>
  <div id="selMsgError">
    <p>
      <?php
		echo $LANG['questions_err_sorry'] . ' ' . $questions->getCommonErrorMsg();
?>
    </p>
  </div>
  <?php
}
if ($questions->isShowPageBlock('msg_form_success'))
{
?>
  <div id="selMsgSuccess">
    <p>
      <?php
		echo $questions->getCommonSuccessMsg();
?>
    </p>
  </div>
  <?php
}
if ($questions->isShowPageBlock('form_information'))
{
?>
  <div id="selMsgAlert">
    <p><?php echo $questions->getCommonErrorMsg(); ?></p>
  </div>
  <?php
}

?>
  <!-- Confirmation Div -->
  <div id="selMsgConfirm" class="selMsgConfirm" style="display:none;position:absolute;">
    <form name="formConfirm" id="formConfirm" method="post" action="<?php echo URL($_SERVER['REQUEST_URI']); ?>">
      <p id="confirmMessage"></p>
      <table summary="<?php echo $LANG['container_to_get_confirmation']; ?>">
        <tr>
          <td><input type="button" class="clsSubmitButton" name="confirm_action" id="confirm_action" value="<?php echo $LANG['yes']; ?>" tabindex="<?php echo $questions->getTabIndex(); ?>" onClick="hideAllBlocks(); doRemoveAction();"/>
            &nbsp;
            <input type="button" class="clsCancelButton" name="cancel" id="cancel" value="<?php echo $LANG['no']; ?>" tabindex="<?php echo $questions->getTabIndex(); ?>" onClick="return hideAllBlocks();" />
          </td>
        </tr>
      </table>
      <input type="hidden" name="action" />
    </form>
  </div>

  <div id="selShowQuestions">
    <?php
if ($questions->isShowPageBlock('form_recent') or $questions->isShowPageBlock('form_popular')) $questions->displayRecentAndPopularQuestions();
if ($questions->isShowPageBlock('form_advanced_search'))
{
?>
    <form name="formAdvanceSearch" id="formAdvanceSearch" method="post" action="<?php echo URL(getUrl($CFG['site']['relative_url'] . 'questions.php?so=adv', $CFG['site']['relative_url'] . 'answers/search/?so=adv', false)); ?>">
      <div id="moreSearchOptions">
        <table summary="Displaying more search options">
          <tr>
            <td class="<?php echo $questions->getCSSFormLabelCellClass('more_questions'); ?>"><label for="more_questions"><?php echo $LANG['questions_search_question']; ?></label>
            </td>
            <td class="<?php echo $questions->getCSSFormFieldCellClass('more_questions'); ?>"><?php echo $questions->getFormFieldErrorTip('more_questions'); ?>
              <input type="text" class="clsCommonTextBox" name="more_questions" id="more_questions" value="<?php echo $questions->getFormField('more_questions'); ?>" tabindex="<?php echo $questions->getTabIndex(); ?>" />
            </td>
        </tr>
        <tr>
            <td class="<?php echo $questions->getCSSFormLabelCellClass('uname'); ?>"><label for="uname"><?php echo $LANG['questions_search_username']; ?></label>
            </td>
            <td class="<?php echo $questions->getCSSFormFieldCellClass('uname'); ?>"><?php echo $questions->getFormFieldErrorTip('uname'); ?>
              <p>
                <input type="text" class="clsCommonTextBox" name="uname" id="uname" value="<?php echo $questions->getFormField('uname'); ?>" tabindex="<?php echo $questions->getTabIndex(); ?>" />
              </p></td>
          </tr>
          <tr>
            <td class="<?php echo $questions->getCSSFormLabelCellClass('tags'); ?>"><label for="tags"><?php echo $LANG['questions_search_tags']; ?></label>
            </td>
            <td class="<?php echo $questions->getCSSFormFieldCellClass('tags'); ?>"><?php echo $questions->getFormFieldErrorTip('tags'); ?>
              <input type="text" class="clsCommonTextBox" name="tags" id="tags" value="<?php echo $questions->getFormField('tags'); ?>" tabindex="<?php echo $questions->getTabIndex(); ?>" />
            </td>
          </tr>
          <tr>
            <td class="<?php echo $questions->getCSSFormLabelCellClass('type'); ?>"><label for="type"><?php echo $LANG['questions_search_type']; ?></label>
            </td>
            <td class="<?php echo $questions->getCSSFormFieldCellClass('type'); ?>"><?php echo $questions->getFormFieldErrorTip('type'); ?>
              <select name="type" id="type" tabindex="<?php echo $questions->getTabIndex(); ?>">
                <?php echo $questions->populateQuestionType($questions->getFormField('type')); ?>
              </select>
            </td>
          </tr>
          <tr>
            <td class="<?php echo $questions->getCSSFormLabelCellClass('cat_id'); ?>"><label for="category"><?php echo $LANG['questions_select_category']; ?></label></td>
            <td class="<?php echo $questions->getCSSFormFieldCellClass('cat_id'); ?>"><?php echo $questions->getFormFieldErrorTip('cat_id'); ?>
              <select class="clsCommonListBox" name="cat_id" id="cat_id" tabindex="<?php echo $questions->getTabIndex(); ?>">
                <option value=""><?php echo $LANG['questions_chose_category']; ?></option>
                <?php $questions->populateCategories($questions->getFormField('cat_id')); ?>
              </select>
            </td>
        </tr>
        <tr>
            <?php
		if (chkVideoAllowed('question') or chkAudioAllowed('question'))
		{
?>
            <td class="<?php echo $questions->getCSSFormLabelCellClass('video'); ?>"><label for="video"><?php echo $LANG['questions_with']; ?></label>
            </td>
            <td class="<?php echo $questions->getCSSFormFieldCellClass('video'); ?>"><?php echo $questions->getFormFieldErrorTip('video'); ?>
              <?php if (chkVideoAllowed('question'))
				{ ?>
              <input type="checkbox" name="video" id="video" tabindex="<?php echo $questions->getTabIndex(); ?>" <?php echo $questions->isCheckedCheckBox('video'); ?> />
              <label for="video"><?php echo $LANG['video']; ?></label>
              <?php } ?>
              <?php if (chkAudioAllowed('question'))
				{ ?>
              <input type="checkbox" name="audio" id="audio" tabindex="<?php echo $questions->getTabIndex(); ?>" <?php echo $questions->isCheckedCheckBox('audio'); ?> />
              <label for="audio"><?php echo $LANG['audio']; ?></label>
              <?php } ?>
            </td>
            <?php
		}
		else
		{
?>
            <td colspan="2" class="<?php echo $questions->getCSSFormLabelCellClass('video'); ?>"></td>
            <?php
		}
?>
          </tr>
          <tr>
            <td class="<?php echo $questions->getCSSFormLabelCellClass('total_answer_from'); ?>"><label for="total_answer_from"><?php echo $LANG['total_answer_from']; ?></label>
            </td>
            <td class="<?php echo $questions->getCSSFormFieldCellClass('total_answer_from'); ?>"><?php echo $questions->getFormFieldErrorTip('total_answer_from'); ?>
              <p>
                <input type="text" class="clsCommonTextBox" name="total_answer_from" id="total_answer_from" value="<?php echo $questions->getFormField('total_answer_from'); ?>" tabindex="<?php echo $questions->getTabIndex(); ?>" />
              </p></td>
          </tr>
          <tr>
            <td class="<?php echo $questions->getCSSFormLabelCellClass('total_answer_to'); ?>"><label for="total_answer_to"><?php echo $LANG['to']; ?></label>
            </td>
            <td class="<?php echo $questions->getCSSFormFieldCellClass('total_answer_to'); ?>"><?php echo $questions->getFormFieldErrorTip('total_answer_to'); ?>
              <p>
                <input type="text" class="clsCommonTextBox" name="total_answer_to" id="total_answer_to" value="<?php echo $questions->getFormField('total_answer_to'); ?>" tabindex="<?php echo $questions->getTabIndex(); ?>" />
              </p></td>
          </tr>
          <tr>
            <td class="<?php echo $questions->getCSSFormLabelCellClass('date_added_from'); ?>"><label for="srch_date"><?php echo $LANG['date_added_from_day']; ?></label></td>
            <td class="<?php echo $questions->getCSSFormFieldCellClass('date_added_from'); ?>"><?php echo $questions->getFormFieldErrorTip('date_added_from'); ?>
			<select name="date_added_from_day" id="date_added_from_day" tabindex="<?php echo $questions->getTabIndex(); ?>">
					<option value=""><?php echo 'Date'; ?></option>
					<?php $questions->populateBWNumbers(1, 31, $questions->getFormField('date_added_from_day')); ?>
			</select>
			<select name="date_added_from_month" id="date_added_from_month" tabindex="<?php echo $questions->getTabIndex(); ?>">
					<option value=""><?php echo 'Month'; ?></option>
					<?php $questions->populateMonthsList($questions->getFormField('date_added_from_month')); ?>
			</select>
			<select name="date_added_from_year" id="date_added_from_year" tabindex="<?php echo $questions->getTabIndex(); ?>">
					<option value=""><?php echo 'Year'; ?></option>
					<?php $questions->populateBWNumbers(1988, date("Y"), $questions->getFormField('date_added_from_year')); ?>
			</select>
			<input type="hidden" name="date_added_from" id="date_added_from" value="<?php echo $questions->getFormField('date_added_from'); ?>">
			<input type="hidden" name="date_added_to" id="date_added_to" value="<?php echo $questions->getFormField('date_added_to'); ?>">
			<?php
?>
            </td>
         </tr>
          <tr>
            <td class="<?php echo $questions->getCSSFormLabelCellClass('date_added_to'); ?>"><label for="srch_date"><?php echo $LANG['to']; ?></label></td>
            <td class="<?php echo $questions->getCSSFormFieldCellClass('date_added_to'); ?>"><?php echo $questions->getFormFieldErrorTip('date_added_to'); ?>
			<select name="date_added_to_day" id="date_added_to_day" tabindex="<?php echo $questions->getTabIndex(); ?>">
					<option value=""><?php echo 'Date'; ?></option>
					<?php $questions->populateBWNumbers(1, 31, $questions->getFormField('date_added_to_day')); ?>
			</select>
			<select name="date_added_to_month" id="date_added_to_month" tabindex="<?php echo $questions->getTabIndex(); ?>">
					<option value=""><?php echo 'Month'; ?></option>
					<?php $questions->populateMonthsList($questions->getFormField('date_added_to_month')); ?>
			</select>
			<select name="date_added_to_year" id="date_added_to_year" tabindex="<?php echo $questions->getTabIndex(); ?>">
					<option value=""><?php echo 'Year'; ?></option>
					<?php $questions->populateBWNumbers(2028, date("Y"), $questions->getFormField('date_added_to_year')); ?>
			</select>
			<?php
?>
            </td>
          </tr>
        </table>
      </div>
      <div id="submitsearch"> <span>
        <input type="submit" class="clsSubmitButton" name="adv_search" id="adv_search" value="<?php echo $LANG['questions_search_submit'];
		; ?>" tabindex="<?php echo $questions->getTabIndex(); ?>" />
        </span> </div>
    </form>
    <?php
}
if ($questions->isShowPageBlock('form_open') or $questions->isShowPageBlock('form_resolved') or $questions->isShowPageBlock('form_search_results'))
{
		$questions->setTableNames(array($CFG['db']['tbl']['questions'] . ' as q', $CFG['db']['tbl']['users'] . ' as u'));
		$questions->setReturnColumns(array('ques_id', 'q.total_answer', 'q.total_videos', 'q.total_audios', 'q.pcat_id', 'q.cat_id', 'q.status', 'q.user_id', $questions->getUserTableField('name') . ' as asked_by', 'u.' . $questions->getUserTableField('user_id') . ' as img_user_id', $questions->getUserTableFields(array('image_path', 'gender', 't_height', 't_width', 's_height', 's_width', 'photo_server_url', 'photo_ext'), false) . 'question', 'total_stars', 'TIMEDIFF(NOW(), date_asked) as date_asked', 'TIMEDIFF(date_closed, NOW()) as date_closed', 'IF(status=\'Open\' AND date_closed>=NOW(), 1, 0) is_open', 'video_id', 'audio_id'));
		$questions->buildSelectQuery();
		$questions->buildConditionQuery();
		$questions->buildSortQuery();
		$questions->buildQuery();
		$questions->executeQuery();
		$questions->displayAllQuestions();
}
?>
  </div>
  <?php
if ($questions->isShowPageBlock('form_add')) $questions->askQuestions();
?>
</div>
<script language="javascript">
	var saveVideo = function(){
		$('video_add').style.display = 'none';
		$('video_delete').style.display = '';
		if (($('video_preview'))) {
			$('video_preview').style.display = '';
			$('video_preview').href = videoPreviewUrl;
		}
		$('video').value = $('rid').value;
		hideAllBlocks();
	}
	var removeVideo = function(){
		alert_manual('<?php echo $LANG['successfully_video_deleted']; ?>', 'video_delete', -50, -100);
		$('video_delete').style.display = 'none';
		if (($('video_preview'))) $('video_preview').style.display = 'none';
		$('video_add').style.display = '';
		$('video').value = '';
		$('video_id').value = '0';
		return false;
	}
	var confrimRemove = function(){
		var act_value = arguments[0];
		var anchorLink = arguments[1];
		var msg_confirm = arguments[2];

		var add_left_position = 0
		var add_top_position = 0;
		if(arguments.length>=4)
			add_top_position = arguments[4];
		if(arguments.length>=6)
			add_left_position = arguments[5];

		var confirm_message = msg_confirm;

		$('confirmMessage').innerHTML = confirm_message;
		document.formConfirm.action.value = act_value;
		Confirmation(anchorLink, 'selMsgConfirm', 'formConfirm', Array(), Array(), Array(), add_left_position, add_top_position);

		return false;
	}
	var doRemoveAction = function(){
		if (document.formConfirm.action.value == 'video')
			removeVideo();
		else
			removeAudio();
	}
	var deleteVideo = function(){
		hideAllBlocks();
	}
	var saveAudio = function(){
		$('audio_add').style.display = 'none';
		$('audio_delete').style.display = '';
		if (($('audio_preview'))) {
			$('audio_preview').style.display = '';
			$('audio_preview').href = audioPreviewUrl;
		}
		$('audio').value = $('rid').value;
		hideAllBlocks();
	}
	var removeAudio = function(){
		alert_manual('<?php echo $LANG['successfully_audio_deleted']; ?>', 'audio_delete', -65, -100);
		$('audio_delete').style.display = 'none';
		if (($('audio_preview'))) $('audio_preview').style.display = 'none';
		$('audio_add').style.display = '';
		$('audio').value = '';
		$('audio_id').value = '0';
		return false;
	}
	var deleteAudio = function(){
		hideAllBlocks();
	}
</script>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>
