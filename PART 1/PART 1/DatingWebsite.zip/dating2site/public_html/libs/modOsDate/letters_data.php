<?php

   class lettersData extends Data {

      var $table = LETTERS_TABLE;

      var $config = array (
  'table' => LETTERS_TABLE,
  'idField' => 'osdate_letters_id',
  'addedMsg' => 'Osdate Letters %s Added',
  'added_err' => 'Can\\\'t Add Osdate Letters',
  'editMsg' => 'Osdate Letters %s Updated',
  'editErr' => 'Can\\\'t Update Osdate Letters',
  'delErr' => 'Can\\\'t Delete Osdate Letters',
  'delMsg' => 'Osdate Letters %s Deleted',
  'blankErr' => 'Osdate Letters Empty',
  'fields' => 
  array (
    'id' => 
    array (
      'name' => 'id',
      'description' => 'Id',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 8,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'title' => 
    array (
      'name' => 'title',
      'description' => 'Title',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 100,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'subject' => 
    array (
      'name' => 'subject',
      'description' => 'Subject',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 254,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'MODIFY' => 
    array (
      'name' => 'MODIFY',
      'description' => 'MODIFY',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 8,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'bodytext' => 
    array (
      'name' => 'bodytext',
      'description' => 'Bodytext',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 65535,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'autosendsignup' => 
    array (
      'name' => 'autosendsignup',
      'description' => 'Autosendsignup',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 1,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
  ),
);   

      function lettersData() {
      
         $this->Data($this->config);
      }
   }

?>
