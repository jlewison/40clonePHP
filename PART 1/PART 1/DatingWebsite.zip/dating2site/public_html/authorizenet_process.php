<?php
if ( !defined( 'SMARTY_DIR' ) ) {
	include_once( 'init.php' );
}

include ( 'sessioninc.php' );
include ("authorizenet_aim.php");

$trans_mode=false;
if(isset($_POST['x_trans_mode']))
{
	$trans_mode=strtolower($_POST['x_trans_mode'])=='test'?true:false;
}
else {
	$trans_mode=false;
}

$auto=new _authorizenet(true,$trans_mode);

$resp=$auto->post($_POST['x_login'],$_POST['x_trans_key'],$_POST['x_amount'],$_POST['x_card_num'],$_POST['x_exp_date']);

$params = array();

$response = explode('|',$resp);

$response_code=$response[0];

if ($response_code == '1') {
	$params['payment_status'] = 'Completed';
} elseif ($response_code == '2') {
	$params['payment_status'] = 'Declined';
} else {$params['payment_status'] = 'Error'; }

$params['txn_id'] = $response[6].' - '.$response[4];
$params['valid'] = true;
$params['pay_txn_id'] = $_POST['pay_txn_id'];
$params['paid_thru'] = 'authorizenet';
$params['amount'] = $respose[9];
$params['vars'] = $resp;
$params['email'] = 'Credit Card';

$level_name = process_payment_info($params);

header('location: checkout_process.php?paid_thru=authorizenet&amp;pay_txn_id='.$pay_txn_id);

?>