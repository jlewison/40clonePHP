<?php

	$lang['page_title']	= 'Help';

?>