<?php include('template/Green_Light/b_inside_top.php');?>

<td valign="top">

<div id="central">
<div class="page-header"><h1>Search results</h1></div>
<?php if($totalRows_SEARlista <> '') { ?>
<div class="listing-count">
	Showing listings <?php echo ($startRow_SEARlista + 1) ?> to <?php echo min($startRow_SEARlista + $maxRows_SEARlista, $totalRows_SEARlista) ?> from a total of <?php echo $totalRows_SEARlista ?> result(s)
</div>


<?php do { ?>
<?php $wsn = $row_SEARlista['title']; $step8 = str_replace(" ", "-", $wsn); $wsseoname = "$step8"; ?>
<div class="box">
	<div class="dbox_top"></div>
	<div class="dbox_middle">
	<div class="box2-left">
		<div class="box2-right">
		<?php if($fremode == 'N') { ?><div class="rate"><?php echo("$currency");?><?php echo $row_SEARlista['bid']; ?></div><?php } else {}?>
			<div class="listing-descr">
				<div class="bid-title"><a href="<?php echo $row_SEARlista['site']; ?>" target="_blank"><?php echo $row_SEARlista['title']; ?></a></div>
				<div class="bid-descr"><?php echo $row_SEARlista['descr1']; ?></div>
				<div class="bid-url"><span style="color:#3a6e2f; font-style:italic;"><?php echo $row_SEARlista['site']; ?></span> :: <?php echo("$lang_5");?> <?php echo $row_SEARlista['stad']; ?></div>
			</div>
			<div class="listing-stats"><?php echo("$lang_30");?> <a href="<?php echo("$path");?><?php echo $row_LdetCAT['categseoname']; ?>/"><?php echo $row_LdetCAT['categoryname'] ?></a></div>
		</div>
	</div>
	</div>
	<div class="dbox_bottom">
		<div style="padding:8px 15px 0 0">
			<?php if($fremode == 'N') { ?> <?php echo $row_SEARlista['bid']; ?> <?php echo("$lang_29");?> :: <?php } else { } ?>  <a href="<?php echo("$path");?><?php echo $row_SEARlista['dtu'];?>/<?php echo("$wsseoname"); ?>.html"><?php echo("$lang_7");?></a> <?php if($fremode == 'N') { ?> :: <a href="<?php echo("$path");?>upgrade.php?ucat=<?php echo $row_SEARlista['dtu']; ?>"><?php echo("$lang_8");?></a> <?php } else { } ?>
		</div>
	</div>
</div>

<?php } while ($row_SEARlista = mysql_fetch_assoc($SEARlista)); ?>
  
<div class="subnl"><a href="<?php echo("$path");?>submit.php">Submit New Listing</a></div>

<?php } else { ?> 
<div class="box">
	<div class="box-cap-left">
		<div class="box-cap-right">
			<div class="box-cap"></div>
		</div>
	</div>
	<div class="box-left">
		<div class="box-right">
<div class="message-no" style="padding:50px; text-align:center;">
	<p>Sorry, no active listings found for this term.</p>
</div>		
		</div>
	</div>
	<div class="box-bottom-left">
		<div class="box-bottom-right">
		</div>
	</div>
</div>	


<?php } ?>
<table  border="0" cellpadding="0" cellspacing="1">
  <tr>
    <td>
	
<?php if ($pageNum_SEARlista > 0) { // Show if not first page ?>
<a href="<?php echo("$path");?><?php echo("0");?>/<?php echo("$totalRows_SEARlista");?>/search.html">&lt;&lt; <?php echo("$lang_35");?></a>
<?php } // Show if not first page ?>

<?php if ($pageNum_SEARlista > 0) { // Show if not first page ?>
<a href="<?php echo("$path");?><?php $mb = max(0, $pageNum_SEARlista - 1); echo("$mb");?>/<?php echo("$totalRows_SEARlista");?>/search.html">&lt; <?php echo("$lang_36");?></a>
<?php } // Show if not first page ?>

<?php if ($pageNum_SEARlista < $totalPages_SEARlista) { // Show if not last page ?>
<a href="<?php echo("$path");?><?php $mb = min($totalPages_SEARlista, $pageNum_SEARlista + 1); echo("$mb");?>/<?php echo("$totalRows_SEARlista");?>/search.html"><?php echo("$lang_37");?> &gt;</a>
<?php } // Show if not last page ?>

<?php if ($pageNum_SEARlista < $totalPages_SEARlista) { // Show if not last page ?>
<a href="<?php echo("$path");?><?php $mb = min($totalPages_SEARlista, $pageNum_SEARlista + 1); echo("$totalPages_SEARlista");?>/<?php echo("$totalRows_SEARlista");?>/search.html"><?php echo("$lang_38");?> &gt;&gt;</a>
<?php } // Show if not last page ?>
    
    </td>
  </tr>
</table>

</div>

<?php include('template/Green_Light/b_footer_tpl.php'); ?>