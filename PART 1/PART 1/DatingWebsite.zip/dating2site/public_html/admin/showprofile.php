<?php
if ( !defined( 'SMARTY_DIR' ) ) {
	include_once( dirname(__FILE__).'/../init.php' );
}


if( $_GET['username'] != '') {
	$userid = $db->getOne( 'SELECT id FROM ! WHERE username = ? ', array( USER_TABLE, $_GET['username'] ) );
	$_REQUEST['id'] = $userid;
}


if( $_REQUEST['id'] != '' && (int)$_REQUEST['id'] == -1 ){

	$t->assign( 'err', RESTRICTED_PROFILE );

	$t->display( 'admin/profileview.tpl' );

	exit;

} elseif( $_REQUEST['id'] != '' && (int)$_REQUEST['id'] != 0 ){

	$sql = 'SELECT id, username , level, country , firstname , lastname, gender , lookgender, state_province , lastvisit, about_me, couple_usernames,
		picture , city , floor((to_days(curdate())-to_days(birth_date))/365.25)   as age
		FROM ! WHERE id = ? ';

     $user=$db->getRow( $sql ,array( USER_TABLE, $_REQUEST['id'] ));

	/* Get countryname and statename */
	$countryname = $db->getOne('select name from ! where code = ?', array(COUNTRIES_TABLE, $user['country'] ) );

	$statename = $db->getOne('select name from ! where code = ? and countrycode = ?', array(STATES_TABLE, $user['state_province'], $user['country'] ) );

	$user['countryname'] = $countryname;

	$user['statename'] = ($statename != '') ? $statename : $user['state_province'];

	$user['m_status'] = checkOnlineStats( $user['id']  );

	$user['pub_pics'] = $db->getAll('select picno from ! where userid=? and (album_id is null or album_id = 0) order by picno', array(USER_SNAP_TABLE, $user['id']) );

	$sqlSections = 'SELECT * FROM ! WHERE enabled = ? ORDER BY displayorder';

	$dataSections = $db->getAll( $sqlSections, array( SECTIONS_TABLE, 'Y'  ) );

	$found = false;

	foreach( $dataSections as $section ){

		$prefs = array();

		$sqlpref = 'SELECT DISTINCT q.id, q.question, q.extsearchhead,
			q.control_type as type FROM ! pref INNER JOIN ! q ON pref.questionid = q.id WHERE pref.userid = ? AND q.section = ? ORDER BY q.displayorder ';

          $rsPref = $db->getAll( $sqlpref,array( USER_PREFERENCE_TABLE, QUESTIONS_TABLE, $_REQUEST['id'], $section['id'] ) );

		foreach( $rsPref as $row ){
			if ($_SESSION['opt_lang'] != 'english') {
			/* THis is made to adjust for multi-language */
				$lang_question = $_SESSION['profile_questions'][$row['id']]['question'];
				$lang_extsearchhead = $_SESSION['profile_questions'][$row['id']]['extsearchhead'];
				if ($lang_question != '') {
					$row['question'] = $lang_question;
					$row['extsearchhead'] = $lang_extsearchhead;
				}
			}


			if ($row['type'] != 'textarea') {

				$sqlopt = 'SELECT distinct pref.answer as answer, opt.answer as anstxt from ! pref left join ! opt on pref.questionid = opt.questionid and opt.id = pref.answer where pref.userid = ? and opt.questionid = ? order by opt.questionid, opt.displayorder';

                    $rsOptions = $db->getAll( $sqlopt, array( USER_PREFERENCE_TABLE, OPTIONS_TABLE, $_REQUEST['id'], $row['id'] ) );

			} else {

				$sqlopt = 'select distinct pref.answer as answer, pref.answer as anstxt from ! pref where pref.userid = ? and pref.questionid = ?';

                    $rsOptions = $db->getAll( $sqlopt, array( USER_PREFERENCE_TABLE, $_REQUEST['id'], $row['id'] ) );
			}

			$opts = array();

			foreach( $rsOptions as $key=>$opt ){
				if ($_SESSION['opt_lang'] != 'english') {
				/* THis is made to adjust for multi-language */
					$lang_ansopt = $_SESSION['profile_questions'][$row['id']][$opt['answer']];
					if ($lang_ansopt != '') {$opts[] = $lang_ansopt;
					}else{ $opts[] = $opt['anstxt'];}
				} else {
					$opts[] = $opt['anstxt'];
				}
			}

			if (count($opts)>0) {
				$optsPhr = implode( ', ', $opts);
			} else {
				$optsPhr = "";
			}

			$row['options'] = $optsPhr;

			$prefs[] = $row;

			$found = true;
		}

		if( count($prefs) > 0 ){

			$pref[] = array( 'SectionName' => get_lang('sections',$section['id']), 'preferences' => $prefs );
		}
	}


	/* Get snaps count */
     $snaps_cnt = $db->getOne('select count(*) from ! where userid = ?', array( USER_SNAP_TABLE, $_REQUEST['id'] ) );

	$t->assign('snaps_cnt', $snaps_cnt);

     $videos_cnt = $db->getOne('select count(*) from ! where userid = ?', array( USER_VIDEOS_TABLE, $_REQUEST['id'] ) );

	 $t->assign('videos_cnt', $videos_cnt);


	hasRight('');
	$cplusers = array();

	if ($user['couple_usernames'] != '' && $user['gender'] == 'C') {

		foreach (explode(',',$user['couple_usernames']) as $cpl) {
			$refuid = $db->getOne('select id from ! where username = ?', array(USER_TABLE, trim($cpl)));

			$cplusers[]=array('username' => trim($cpl),
								'uid' => $refuid) ;
		}

		$user['cplusers'] = $cplusers;
	}

	$t->assign( 'user', $user );

	$t->assign('title',str_replace('USERNAME', $user['username'], get_lang('profile_s')));

	$arr = array();

	for( $i=-5; $i<=5; $i++ ) {
		$arr[$i] = $i;
	}

	$t->assign ( 'rate_values', $arr );

	/* MOD START */

	// remove comment //

	if ($_GET["action"] == "removecomment") {

		$sql = 'UPDATE ! SET reply = ? WHERE id = ?';

		$db->query( $sql, array( USER_RATING_TABLE, '', substr($_GET["commentid"],0,250) ) );


	}
	// get ratings //

     $t->assign( 'profileid', $_REQUEST['id'] );

	$t->assign( 'ratingid', $_GET['ratingid'] );

	$sqlrating = 'SELECT id, rating, displayorder, enabled, description from ! where enabled = ? order by displayorder asc ';;

	$data = $db->getAll( $sqlrating, array(RATINGS_TABLE, 'Y') );

	$newdata = array();

	$total_ratingscnt = 0;

	foreach ($data as $item) {

		// comment count //

		$futuredate1 = date("Y/m/d", mktime(0,0,0,date("m"),(date("d") - $config['mod_rating_rem_com']),date("Y")));

		$sqlrate = 'SELECT count(id) as commentcount FROM ! WHERE profileid = ?  and ratingid = ? and comment <> ? and comment_date >= ?';

          $commentcount = $db->getOne($sqlrate, array( USER_RATING_TABLE, $_REQUEST['id'], $item["id"], '', $futuredate1 ) );

		$item["commentcount"] = $commentcount;

		// rating count //

		$futuredate2 = date("Y/m/d", mktime(0,0,0,date("m"),(date("d") - $config['mod_rating_rem_rat']),date("Y")));

		$sqlrate = 'SELECT count(id) as ratingcount FROM ! WHERE profileid = ? and ratingid = ? and rating > ? and rating_date >= ?';

          $ratingcount = $db->getOne($sqlrate, array( USER_RATING_TABLE, $_REQUEST['id'], $item["id"], '0', $futuredate2 ) );

		$item["ratingcount"] = $ratingcount;

		$total_ratingscnt += $ratingcount;


		// rating value //

		$sqlrate = 'SELECT count(rating) as tv , sum(rating) as sm FROM ! WHERE profileid = ? and ratingid = ? and rating > ? and rating_date >= ?';

          $rowrate = $db->getRow($sqlrate, array( USER_RATING_TABLE, $_REQUEST['id'], $item["id"], '0', $futuredate2 ) );

		$tv = $rowrate['tv'];

		$sm = $rowrate['sm'];

		if ( $tv == 0 ) {

			$ratingvalue = 0;

		} else {

			$tv = ($tv == 0) ? 1 : $tv;

			$ratingvalue = round( $sm / $tv );

		}

		$item["ratingvalue"] = $ratingvalue;

		// check user has already rated //

		$has_rated = 1;

//		if ( $_SESSION['UserId'] and $_SESSION['UserId'] != $_GET["id"] ) {

			$sqlcrate = 'SELECT count(*) as c  FROM !  WHERE  profileid = ? and ratingid = ? and rating > ?';

			$rowcrate = $db->getRow(  $sqlcrate, array( USER_RATING_TABLE, $_REQUEST['id'], $item['id'], '0' ));

			$c = $rowcrate['c'];

			if ( $c == 0 ) {
				$has_rated = 0;
			}else {
				$has_rated = 1;
			}

//		}

		$item["has_rated"] = $has_rated;

		// check if user has already commented //

		$has_commented = 1;

//		if ( $_SESSION['UserId'] and $_SESSION['UserId'] != $_GET["id"] ) {

			$sqlcrate = 'SELECT count(*) as c  FROM !  WHERE  profileid = ? and ratingid = ? and comment <> ?';

			$rowcrate = $db->getRow(  $sqlcrate, array( USER_RATING_TABLE, $_GET['id'], $item["id"], '' ));

			$c = $rowcrate['c'];

			if ( $c == 0 ) {
				$has_commented = 0;
			}else {
				$has_commented = 1;
			}

//		}

		$item["has_commented"] = $has_commented;

		array_push($newdata, $item);

	}

	$t->assign('total_ratingscnt', $total_ratingscnt);

	$t->assign( 'ratings', $newdata );

	// get options //

	$optionlist = array();
	$optionlist_note = array();

	$div = $config['mod_rating_inc'] - 1;

	for($i=$config['mod_rating_min']; $i<=$config['mod_rating_max']; $i++) {

		$div++;

		if ($i == $config['mod_rating_min']) {

			$thename = get_lang('worst1');

		} else if ($i == $config['mod_rating_max']) {

			$thename = get_lang('best1');

		} else {

			$thename = "";

		}

		if ($div == $config['mod_rating_inc']) {

		$temparray = array();

		$temparray["name"] = $i . $thename;
		$temparray["value"] = $i;

		array_push($optionlist, $temparray);

		$div = 0;

		}

	}

	if ($config['mod_rating_inc_order'] == "High to Low") {

		$optionlist = array_reverse($optionlist);

	}

	$t->assign( 'ratingoptions', $optionlist );

	// get comments //

	$sqlrate = 'SELECT distinct rat.id, rat.comment, rat.reply, rat.userid, usr.username FROM ! as rat, ! as usr WHERE rat.profileid = ? and rat.ratingid = ? and rat.comment <> ? and rat.comment_date >= ? and usr.id = rat.userid';

     $comments = $db->getAll($sqlrate, array( USER_RATING_TABLE, USER_TABLE, $_REQUEST['id'], $_GET['ratingid'], '', $futuredate1 ) );


	$t->assign( 'comments', $comments );

	/* MOD END */

	if( $found ){

		$t->assign ( 'found', 1);

		$t->assign( 'pref', $pref);

	}

	$sql = 'select count(*) from ! where userid = ? and act = ?';
     $t->assign('profile_views', $db->getOne($sql, array( VIEWS_WINKS_TABLE, $_REQUEST['id'], 'V' ) ) );

	/* Now add this view to profile_views table, if no user logged, make it -1  */

	$sql = 'insert into ! (userid, ref_userid, act_time, act) values (?, ?, ?, ?)';

	$byuser = ($_SESSION['UserId']>0)?$_SESSION['UserId']:-1;

     if ($_REQUEST['id'] != $_SESSION['UserId'] && !isset($_REQUEST['ratingid']) ) {

          $db->query($sql, array( VIEWS_WINKS_TABLE, $_REQUEST['id'], $byuser, time(), 'V' ) );

	}

	$t->assign('errid', $_GET['errid']);
	$t->assign('lang',$lang);


//	$t->display( 'profileview.tpl' );

		$t->assign('lang',$lang);

	$config['use_profilepopups'] = "Y";
	$t->assign('config',$config);

//	if ( $config['use_profilepopups'] == 'Y' ) {
		$t->display( 'admin/nickpage.tpl' );
/*	}
	else {
		$t->assign('rendered_page', $t->fetch('nickpage.tpl') );
		$t->display ( 'index.tpl' );
	} */
}
?>
