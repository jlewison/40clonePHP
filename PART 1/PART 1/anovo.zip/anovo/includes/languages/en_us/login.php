<?php
$LANG['login_title'] = 'Login';
$LANG['login_error'] = 'Error in login!';
$LANG['login_user_name'] = 'Username';
$LANG['login_password'] = 'Password';
$LANG['login_remember'] = 'Remember login?';
$LANG['login_submit'] = 'Submit';
$LANG['login_tbl_summary'] = 'Container for login form';
$LANG['login_err_tip_compulsory'] = 'Required';
$LANG['login_err_tip_invalid'] = 'Invalid username or password';
$LANG['login_err_cookies_not_set'] = 'Need to enable cookies to login.';
$LANG['login_err_invalid_login'] = 'Invalid login details provided. Invalid username or password. Reason not displayed for security reasons.';
$LANG['login_err_sorry'] = 'Sorry, errors detected!';
$LANG['login_err_authorization_required'] = 'Authorization required.';
$LANG['login_err_session_expired'] = 'Session expired.';
$LANG['login_err_invalid_user_session'] = 'Invalid user session.';
$LANG['login_err_invalid_session'] = 'Invalid session.';
$LANG['login_err_wrong_ip'] = 'Change in IP detected.';
$LANG['login_err_wrong_user_agent'] = 'Change in IP detected.';
$LANG['forget_password'] = 'Forgot Password?';
$LANG['new_user_signup_here'] = 'New User Sign up here';
?>