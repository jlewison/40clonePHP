<?php include('template/GreenAndBlack/b_inside_top.php');?>

<!--
###################################################################################
#######################                                     #######################
#######################   M A I N   S E C T I O N   Start   #######################
#######################                                     #######################
###################################################################################
-->

<div id="central">

<?php
if($fremode == 'Y') { ?>
<h1><?php echo("$lang_102");?></h1>
<?php echo("$lang_103");?>
<?php } else { ?> 
<h1><?php echo("$lang_104");?></h1>

<table border="0" align="center" cellpadding="3" cellspacing="1" id="listingdt">
  <tr>
    <td align="right" bgcolor="#F4F4F4"><?php echo("$lang_105");?></td>
    <td valign="middle" bgcolor="#FFFFCC"><span class="style1 style1x"><?php echo("$currency");?><?php echo("$bid");?>.00</span></td>
  </tr>
  <tr>
    <td align="right" bgcolor="#F4F4F4"><?php echo("$lang_106");?></td>
    <td valign="middle" bgcolor="#FFFFCC"><a href="<?php echo("$url");?>" target="_blank" class="style1 style1x"><?php echo("$keyword");?></a></td>
  </tr>
  <tr>
    <td align="right" bgcolor="#F4F4F4"><?php echo("$lang_107");?> </td>
    <td valign="middle" bgcolor="#FFFFCC"><span class="style1 style1x"><?php echo("$descr1");?></span></td>
  </tr>
  <tr>
    <td align="right" bgcolor="#F4F4F4"><?php echo("$lang_108");?> </td>
    <td valign="middle" bgcolor="#FFFFCC"><span class="style1 style1x"><?php echo("$descr2");?></span></td>
  </tr>
  <tr>
    <td align="right" bgcolor="#F4F4F4"><?php echo("$lang_109");?></td>
    <td valign="middle" bgcolor="#FFFFCC"><span class="style1x"><?php echo("$url");?></span></td>
  </tr>
  <tr>
    <td align="right" bgcolor="#F4F4F4"><?php echo("$lang_110");?></td>
    <td valign="middle" bgcolor="#FFFFCC"><span class="style1 style1x">
      <?php $today = date("F j, Y, g:i a"); echo("$today");?>
    </span></td>
  </tr>
  <tr>
    <td align="right" bgcolor="#F4F4F4"><?php echo("$lang_111");?></td>
    <td valign="middle" bgcolor="#FFFFCC"><span class="style1 style1x"> <?php echo("$lang_93");?><?php echo("$lang_121");?></span></td>
  </tr>
  <tr>
    <td align="right" bgcolor="#F4F4F4"><?php echo("$lang_112");?></td>
    <td valign="middle" bgcolor="#FFFFCC"><span class="style1 style1x"><?php echo("$bid");?> <?php echo("$lang_93");?><?php echo("$lang_29");?></span></td>
  </tr>
</table>


<hr />


<table border="0" align="center" cellpadding="3" cellspacing="1">
<tr>
<td>

<div id="TabbedPanels1" class="TabbedPanels">

<ul class="TabbedPanelsTabGroup">
    <li class="TabbedPanelsTabB" tabindex="0"><?php echo("$lang_114");?></li>
    <li class="TabbedPanelsTab" tabindex="0"><?php echo("$lang_115");?></li>
    <li class="TabbedPanelsTabA" tabindex="0"><?php echo("$lang_116");?></li>
</ul>

	  <div class="TabbedPanelsContentGroup">
    	<div><?php echo("$termsdetails");?></div>
	    <div class="TabbedPanelsContent">
	      <div align="center"><?php echo("$lang_117");?>
    	      <br />  
	          <br />

<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
    <input type="hidden" name="cmd" value="_xclick">
    <input type="hidden" name="business" value="<?php echo("$paypal");?>">
    <input type="hidden" name="item_name" value="Payment for Bid ID <?php echo("$linkid");?> for link <?php echo("$url");?>">
    <input type="hidden" name="item_number" value="<?php echo("$linkid");?>">
    <input type="hidden" name="amount" value="<?php echo("$bid");?>">
    <input type="hidden" name="no_shipping" value="2">
    <input type="hidden" name="no_note" value="1">
    <input type="hidden" name="currency_code" value="<?php echo("$paypalcurrency");?>">
	<input type="hidden" name="return" value="http://<?php echo("$domainname");?><?php echo("$pathmail");?>/thankyou.php">
	<input type="hidden" name="cancel_return" value="http://<?php echo("$domainname");?><?php echo("$pathmail");?>/sorry.php">
    <input type="hidden" name="bn" value="PP-BuyNowBF">
    <input name="submit" type="image" src="img/paypal.gif" alt="Make payments with PayPal - it's fast, free and secure!" width="150" height="140" border="0">
</form>

          </div>
        </div>

<div><?php echo("$lang_118");?> <a href="/"><?php echo("$lang_120");?></a> <?php echo("$lang_119");?></div>

     </div>
</div>

</td>
</tr>
</table>

<script type="text/javascript">
<!--
var TabbedPanels1 = new Spry.Widget.TabbedPanels("TabbedPanels1");
//-->
</script>
<hr />
<?php } ?>

</div>
<!--
###################################################################################
#######################                                     #######################
#######################    M A I N   S E C T I O N   End    #######################
#######################                                     #######################
###################################################################################
-->

<?php include('template/GreenAndBlack/b_inside_bottom.php');?>
<?php include('template/GreenAndBlack/b_footer_tpl.php'); ?>