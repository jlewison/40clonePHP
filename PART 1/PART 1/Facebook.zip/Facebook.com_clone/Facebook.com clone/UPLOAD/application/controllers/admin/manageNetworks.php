<?php

/**
 * ManageNetworks Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 2/5/2008
 */
class ManageNetworks extends Controller
{
		//Constructor
		function ManageNetworks()
		{
				parent::Controller();
				//check login
				if ($this->session->userdata('admin_logged_in') != 1 && $this->session->userdata('admin_id') == '') redirect('admin/login');
				//Load the language file
				$this->lang->load('admin/manageNetworks', $this->config->item('language_code'));
		}
		//Default function
		function index()
		{
				$outputData = array();
				$this->load->model('networkmodel');
				if ($_POST && is_array($_POST) && count($_POST) > 0)
				{
						$suggest = $this->input->post('networkName');
						$type = $this->input->post('networkType');
						$status = $this->input->post('networkStatus');
						$domain = $this->input->post('networkDomain');
						$outputData['networks'] = $this->networkmodel->searchNetworks($suggest, $type, $status, $domain);
				}
				else  $outputData['networks'] = $this->networkmodel->searchNetworks();
				$outputData['networksCnt'] = count($outputData['networks']);
				$this->smartyextended->view('../admin/manageNetworks', $outputData);
		}
		function editNetwork()
		{
				$networkId = $this->uri->segment(4);
				$this->load->model('networkmodel');
				if ($this->networkmodel->isExist($networkId, ''))
				{
						$outputData = array();
						if ($_POST && is_array($_POST) && count($_POST) > 0)
						{
								$updateNetwork = $_POST;
								unset($updateNetwork['submit']);
								unset($updateNetwork['submit_x']);
								unset($updateNetwork['submit_y']);
								$this->networkmodel->updateNetworkDetails($networkId, $updateNetwork);
								$outputData['successMsg'] = 'Network details updated successfully';
						}
						else  $outputData['networkDetails'] = $this->networkmodel->getNetworkDetails($networkId);
						$this->smartyextended->view('../admin/editNetworks', $outputData);
				}
				else  redirect('admin/manageNetworks');
		}
		function viewNetwork()
		{
				$networkId = $this->uri->segment(4);
				$this->load->model('networkmodel');
				if ($this->networkmodel->isExist($networkId, ''))
				{
						$outputData['networkDetails'] = $this->networkmodel->getNetworkDetails($networkId);
						$this->smartyextended->view('../admin/viewNetworks', $outputData);
				}
				else  redirect('admin/manageNetworks');
		}
		//approve given network
		function approveNetwork()
		{
				$networkId = $this->uri->segment(4);
				$this->load->model('networkmodel');
				if ($this->networkmodel->isExist($networkId, 'confirmed')) //allow only if it is confirmed network

				{
						$updateNetwork = array("network_status" => 'enabled');
						if ($this->networkmodel->updateNetworkByAdmin($networkId, $updateNetwork)) //Set the flash data
 										$this->session->set_flashdata('flash_msg', 'Network has been approved successfully');
						else //Set the flash data
 										$this->session->set_flashdata('flash_msg', 'Sorry! Network has not been approved');
				}
				redirect('admin/manageNetworks');
		}
		//dis approve given network
		function disapproveNetwork()
		{
				$networkId = $this->uri->segment(4);
				$this->load->model('networkmodel');
				if ($this->networkmodel->isExist($networkId, 'confirmed'))
				{
						$updateNetwork = array("network_status" => 'disabled');
						if ($this->networkmodel->updateNetworkByAdmin($networkId, $updateNetwork)) //Set the flash data
 										$this->session->set_flashdata('flash_msg', 'Network has been dis-approved successfully');
						else //Set the flash data
 										$this->session->set_flashdata('flash_msg', 'Sorry! Network has not been dis-approved');
				}
				redirect('admin/manageNetworks');
		}
		//send confirmation mail for suggested network
		function sendConfirmation()
		{
				$networkId = $this->uri->segment(4);
				$this->load->model('networkmodel');
				if ($this->networkmodel->isExist($networkId, 'suggested'))
				{
						$this->load->library('encrypt');
						$networkDetails = $this->networkmodel->getNetworkDetails($networkId);
						$confirmKey = $this->encrypt->sha1($networkDetails['network_name']);
						$updateNetwork = array("confirmation_key" => $confirmKey, "network_status" => 'nonconfirmed');
						if ($this->_sendConfirmationMail($networkId, $confirmKey))
						{
								if ($this->networkmodel->updateNetworkByAdmin($networkId, $updateNetwork)) //Set the flash data
 												$this->session->set_flashdata('flash_msg', 'Confirmation mail has been sent successfully');
								else //Set the flash data
 												$this->session->set_flashdata('flash_msg', 'Confirmation mail has not been sent');
						}
				}
				redirect('admin/manageNetworks');
		}
		function _sendConfirmationMail($networkId, $confirmKey)
		{
				$this->load->model('settingsModel');
				$this->load->model('emailTemplateModel');
				$this->load->library('email');
				$this->load->model('userModel');
				$this->load->model('messageModel');
				$networkDetails = $this->networkmodel->getNetworkDetails($networkId);
				$userDetails = $this->usermodel->getUserDetails($networkDetails['user_id']);
				//		echo '<pre>';
				//		print_r($networkDetails);
				//		echo '</pre>';
				//reads common site settings
				$settings = $this->settingsmodel->readSetting('admin_email, admin_name, site_name, site_title');
				$adminEmail = $settings['admin_email'];
				$adminName = $settings['admin_name'];
				$siteName = $settings['site_title'];
				$toEmail = $userDetails[$networkDetails['user_id']]['email'];
				$receiverName = ucfirst($this->userModel->getName($networkDetails['user_id']));
				$attachUrl = base_url() . 'network/confirmsuggest/' . $networkId . '/' . $confirmKey;
				$emailTemplate = $this->emailTemplateModel->readEmailTemplate('admin_approve_network'); //reads mail templates
				//send external mail
				$splVars = array("~~receiverName~~" => $receiverName, "~~siteName~~" => $siteName, "~~attachUrl~~" => $attachUrl, "~~adminEmail~~" => $adminEmail, "~~adminName~~" => $adminName, "~~networkName~~" => $networkDetails['network_name']);
				$subject = strtr($emailTemplate['template_subject'], $splVars);
				$message = strtr($emailTemplate['template_content'], $splVars);
				$this->email->from($adminEmail, $adminName);
				$this->email->to($toEmail);
				$this->email->subject($subject);
				$this->email->message($message);
				//$this->email->send();
				$msgConfig = array("to_id" => $networkDetails['user_id'], "subject" => $subject, "message" => $message);
				if ($this->messageModel->sendMessage($msgConfig, true)) return true;
				else  return false;
		} //end _sendConfirmationMail()
}

?>