<?php
if ( !defined( 'SMARTY_DIR' ) ) {
	include_once( '../init.php' );
}

import_request_variables('pg');

if (!isset($cnt)) $cnt = 1;

/* Loads zip codes from files which are split in step 1 */
if ( $cntry != '' ) {

	$filename = $_SESSION['cntry_'.$cntry]['files'][$cnt - 1];
	$fname=$_SESSION['cntry_'.$cntry]['filesdir'].$filename;

	$handle = fopen($fname,'r');
	if ($cntry == 'GB') {
	/* UK Zip Codes */
		$sql = 'insert into ! (code, countrycode, latitude, longitude) values (?,?,?,?)';
		while (!feof($handle) ) {
			$zipdata = explode(",",fgets($handle));
			if ($zipdata[0] != '' && trim($zipdata[1]) != '' && trim($zipdata[2]) != ''){
					$db->query($sql, array(ZIPCODES_TABLE, $zipdata[0], $cntry, trim($zipdata[1]), trim($zipdata[2])) );
			}

		}
	} elseif ($cntry == 'US') {
	/* US zip codes */
		$sql = 'insert into ! (code, countrycode, statecode, latitude, longitude) values (lpad(?,5,"0"),?,?,?,?)';
		while(!feof($handle) ) {
			$zipdata = explode(",",fgets($handle));
			if ($zipdata[0] != '' && trim($zipdata[1]) != '' && trim($zipdata[2]) != '') {
				$db->query($sql, array(ZIPCODES_TABLE, $zipdata[0], $cntry, $zipdata[3],trim($zipdata[1]), trim($zipdata[2])) );
			}
		}
	} elseif ($cntry == 'CA') {
	/* Canada Zip Codes */
		$sql = 'insert into ! (code, countrycode, statecode, latitude, longitude) values (?,?,?,?,?)';

		while(!feof($handle) ) {
			$zipdata = explode(",",fgets($handle));
			if ($zipdata[0] != '' && trim($zipdata[1]) != '' && trim($zipdata[2]) != '') {
				$db->query($sql, array(ZIPCODES_TABLE, $zipdata[0], $cntry, $zipdata[3], trim($zipdata[1]), trim($zipdata[2]) ) );
			}
		}
	} else {
	/* Contente of the file should be
		COUNTRYCODE, ZIPCODE, STATECODE, LATITUDE, LONGITUDE  */

		$sql = 'insert into ! (countrycode, code, latitude, longitude, statecode) values (?,?,?,?, ?)';
		while (!feof($handle) ) {
			$zipdata = explode(",",str_replace('\n\r','',fgets($handle)));
			if ($zipdata[0] != '' && trim($zipdata[1]) != '' && trim($zipdata[2]) != '') {
				$db->query($sql, array(ZIPCODES_TABLE, $cntry, $zipdata[0], $zipdata[1], trim($zipdata[2]), trim($zipdata[3])) );
			}
		}
	}
	fclose($handle);
}

$cnt++;

$t->assign('cnt', $cnt);
$t->assign('cntry', $cntry);
$t->assign('loadedfiles',$_SESSION['cntry_'.$cntry]['files']);
$t->assign('lang',$lang);
$t->assign('config', $config);

$t->assign('loadedcnt', $cnt - 1);

if ($cnt > count($_SESSION['cntry_'.$cntry]['files']) ) {
	unset ($_SESSION['cntry_'.$cntry]);
	$cntryname = $lang['countries'][$cntry];
	$msg = "<br />".str_replace('#COUNTRY#',$cntryname,get_lang('zip_load_over'));
	$t->assign('dispmsg',$msg);
}

$t->display('admin/load_zips_split.tpl');

if ($cnt <= count($_SESSION['cntry_'.$cntry]['files']) ) {

	echo('<meta http-equiv=refresh content=0;url='.DOC_ROOT.'admin/load_zips_split.php?cntry='.$cntry.'&amp;cnt='.$cnt.'>');
	flush();
}
?>