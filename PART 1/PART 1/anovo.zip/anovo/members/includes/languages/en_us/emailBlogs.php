<?php
$LANG['title'] = 'Email this Blog';
$LANG['tbl_summary'] = 'Email this Blog';
$LANG['user_email'] = 'Your Email';
$LANG['user_name'] = 'Your Name';
$LANG['to_emails'] = 'Friends email ids';
$LANG['to_emails_msg'] = 'To enter multiple recipients, separate addresses with a comma.';
$LANG['subject'] = 'Subject ';
$LANG['message'] = 'Message ';
$LANG['submit'] = 'Submit';
$LANG['err_tip_compulsory'] = 'Required';
$LANG['err_tip_id_compulsory'] = 'Invalid Topic ID';
$LANG['contactuserr_tip_invalid_email'] = 'invalid email';
$LANG['contactuserr_tip_invalid_email_ids'] = 'One or more emails are invalid';
$LANG['contactuserr_tip_enter_valid_email_ids'] = 'Enter valid email ids';
$LANG['success'] = 'Email sent successfully';
$LANG['failure'] = 'Problem in sending mail';
$LANG['failure_message'] = 'The fields should not be empty';
$LANG['import_contacts'] = 'Import Contacts';
?>