<?php
class ListRecordsHandler extends FormHandler
{
		protected $dbObj = null;
		protected $table_names_arr = array();
		protected $field_aliases_arr = null;
		protected $table_aliases_arr = array();
		protected $ret_columns = null;
		protected $sql = '';
		protected $sql_condition = '';
		protected $sql_sort = '';
		protected $sql_count = '';
		protected $search_result_query_id = null;
		protected $records_arr;
		protected $column_sort_url = '';
		protected $dsc_sort_columns_arr = array();
		protected $asc_sort_columns_arr = array();
		protected $css_class_arr = array();
		protected $css_class_alternative_row_arr = array();
		protected $results_tot_pages_num = 3;
		protected $results_tot_num = 253;
		protected $results_start_num = 50;
		protected $results_end_num = 58;
		protected $results_num_per_page = 10;
		protected $is_search = false;
		protected $is_colorize_search_results = false;
		protected $is_use_stemming = false;
		protected $is_fulltext_search = false;
		protected $is_highlight_search_results = false;
		protected $field_name_dsc_sort = 'dsc';
		protected $field_name_asc_sort = 'asc';
		protected $field_name_search = 'q';
		protected $field_name_numpg = 'numpg';
		protected $field_name_start = 'start';
		protected $num_per_page_list_arr = array();
		protected $record_select_limit_min = 1;
		protected $record_select_limit_max = 50;
		protected $lang = array('sort_ascending' => 'Sort Ascending', 'sort_descending' => 'Sort Descending');
		protected $rs = '';
		public function __construct()
		{
		}
		public function setDBObject($dbObj)
		{
				$this->dbObj = $dbObj;
		}
		public function setLang($lang_arr)
		{
				$this->lang = $lang_arr;
		}
		public function setSearchFormFieldNames($start = 'start', $numpg = 'numpg', $dsc = 'dsc', $asc = 'asc', $search = 'q')
		{
				$this->field_name_start = $start;
				$this->field_name_numpg = $numpg;
				$this->field_name_dsc_sort = $dsc;
				$this->field_name_asc_sort = $asc;
				$this->field_name_search = $search;
		}
		public function setReturnColumns($ret_columns)
		{
				$this->ret_columns = $ret_columns;
		}
		public function setCSSColumnHeaderCellDefaultClass($class_name)
		{
				$this->css_class_arr['column_header_cell_default'] = $class_name;
		}
		public function setCSSColumnHeaderCellDescSortClasses($class_names_arr = array())
		{
				$this->css_class_arr['column_header_cell_dsc_sort'] = $class_names_arr;
		}
		public function setCSSColumnHeaderCellAscSortClasses($class_names_arr = array())
		{
				$this->css_class_arr['column_header_cell_asc_sort'] = $class_names_arr;
		}
		public function setCSSAlternativeRowClasses($class_names_arr = array())
		{
				$this->css_class_alternative_row_arr = $class_names_arr;
		}
		public function getCSSColumnHeaderCellClass($column_name)
		{
				$class_name = $this->css_class_arr['column_header_cell_default'];
				if (($key = array_search($column_name, $this->asc_sort_columns_arr)) !== false)
				{
						$tmp_max_css = count($this->css_class_arr['column_header_cell_asc_sort']) - 1;
						if ($key > $tmp_max_css) $key = $tmp_max_css;
						$class_name = $this->css_class_arr['column_header_cell_asc_sort'][$key];
				}
				else
						if (($key = array_search($column_name, $this->dsc_sort_columns_arr)) !== false)
						{
								$tmp_max_css = count($this->css_class_arr['column_header_cell_dsc_sort']) - 1;
								if ($key > $tmp_max_css) $key = $tmp_max_css;
								$class_name = $this->css_class_arr['column_header_cell_dsc_sort'][$key];
						}
				return $class_name;
		}
		public function getCSSRowClass()
		{
				$class = current($this->css_class_alternative_row_arr) and next($this->css_class_alternative_row_arr) or reset($this->css_class_alternative_row_arr);
				return $class;
		}
		public function setFormField($field_name, $field_value, $validation_scheme = null, $custom_validation_fun_name = null)
		{
				parent::setFormField($field_name, $field_value);
				if ($field_name == $this->field_name_numpg) $this->results_num_per_page = $field_value;
				else
						if ($field_name == $this->field_name_start) $this->results_start_num = $field_value;
		}
		public function sanitizeFormInputs($request_arr)
		{
				parent::sanitizeFormInputs($request_arr);
				if (isset($this->fields_arr[$this->field_name_dsc_sort])) $this->dsc_sort_columns_arr = (array )$this->fields_arr[$this->field_name_dsc_sort];
				if (isset($this->fields_arr[$this->field_name_asc_sort])) $this->asc_sort_columns_arr = (array )$this->fields_arr[$this->field_name_asc_sort];
				$this->dsc_sort_columns_arr = array_diff($this->dsc_sort_columns_arr, array_intersect($this->dsc_sort_columns_arr, $this->asc_sort_columns_arr));
				$this->dsc_sort_columns_arr = array_intersect($this->dsc_sort_columns_arr, $this->ret_columns);
				$this->asc_sort_columns_arr = array_intersect($this->asc_sort_columns_arr, $this->ret_columns);
				$this->results_num_per_page = $this->fields_arr[$this->field_name_numpg];
				if ($this->results_num_per_page < $this->record_select_limit_min) $this->results_num_per_page = $this->record_select_limit_min;
				else
						if ($this->results_num_per_page > $this->record_select_limit_max) $this->results_num_per_page = $this->record_select_limit_max;
				$this->fields_arr[$this->field_name_numpg] = $this->results_num_per_page;
				$this->fields_arr[$this->field_name_start] = intval($this->fields_arr[$this->field_name_start]);
				$this->results_start_num = $this->fields_arr[$this->field_name_start];
		}
		public function setMinRecordSelectLimit($min_limit)
		{
				$this->record_select_limit_min = $min_limit;
		}
		public function setMaxRecordSelectLimit($max_limit)
		{
				$this->record_select_limit_max = $max_limit;
		}
		public function getColumnValue($column_name)
		{
				return $this->records_arr[$column_name];
		}
		public function setColumnSortUrl($url)
		{
				$this->column_sort_url = $url;
		}
		public function getColumnHeaderAHref($column_name)
		{
				$href = '';
				foreach ($this->fields_arr as $field_name => $field_value)
				{
						if ((is_array($field_value)))
						{
								$sub_fields_arr = $field_value;
								if ($field_name != $this->field_name_dsc_sort && $field_name != $this->field_name_asc_sort)
								{
										foreach ($sub_fields_arr as $sub_key => $sub_value) $href .= $field_name . '[]=' . urlencode($sub_value) . '&amp;';
								}
						}
						else  $href .= $field_name . '=' . urlencode($field_value) . '&amp;';
				}
				$tmp_dsc_sort_columns_arr = $this->dsc_sort_columns_arr;
				$tmp_asc_sort_columns_arr = $this->asc_sort_columns_arr;
				if (in_array($column_name, $this->dsc_sort_columns_arr))
				{
						unset($tmp_dsc_sort_columns_arr[array_search($column_name, $tmp_dsc_sort_columns_arr)]);
						$tmp_asc_sort_columns_arr[] = $column_name;
				}
				else
						if (in_array($column_name, $this->asc_sort_columns_arr))
						{
								unset($tmp_asc_sort_columns_arr[array_search($column_name, $tmp_asc_sort_columns_arr)]);
								$tmp_dsc_sort_columns_arr[] = $column_name;
						}
						else  $tmp_asc_sort_columns_arr[] = $column_name;
				foreach ($tmp_asc_sort_columns_arr as $asc_col_name) $href .= $this->field_name_asc_sort . '[]=' . urlencode($asc_col_name) . '&amp;';
				foreach ($tmp_dsc_sort_columns_arr as $dsc_col_name) $href .= $this->field_name_dsc_sort . '[]=' . urlencode($dsc_col_name) . '&amp;';
				$href = substr($href, 0, strrpos($href, '&amp;'));
				return $this->column_sort_url . '?' . $href;
		}
		public function getColumnHeaderATitle($column_name)
		{
				if (in_array($column_name, $this->dsc_sort_columns_arr)) $title = $this->lang['sort_ascending'];
				else
						if (in_array($column_name, $this->asc_sort_columns_arr)) $title = $this->lang['sort_descending'];
						else  $title = $this->lang['sort_ascending'];
				return $title;
		}
		public function setReturnColumnsAliases($field_aliases_arr)
		{
				$this->field_aliases_arr = $field_aliases_arr;
		}
		public function setTableNames($table_names_arr)
		{
				$this->table_names_arr = $table_names_arr;
		}
		public function setTableNameAliases($table_aliases_arr)
		{
				$this->table_aliases_arr = $table_aliases_arr;
		}
		public function buildSelectQuery()
		{
				$this->sql = 'SELECT ';
				if (is_string($this->ret_columns) && $this->ret_columns == '*') $this->sql .= '*';
				else
						if (is_array($this->ret_columns))
						{
								foreach ($this->ret_columns as $ret_column)
								{
										if (isset($this->field_aliases_arr[$ret_column])) $this->sql .= $this->field_aliases_arr[$ret_column] . ' AS ' . $ret_column . ', ';
										else  $this->sql .= $ret_column . ', ';
								}
						}
				$this->sql = substr($this->sql, 0, strrpos($this->sql, ', '));
				$this->sql .= ' FROM ';
				foreach ($this->table_names_arr as $table_name)
				{
						if (isset($this->table_aliases_arr[$table_name]))
						{
								if (is_string($this->table_aliases_arr[$table_name])) $this->sql .= $table_name . ' AS ' . $this->table_aliases_arr[$table_name] . ', ';
								else
										if (is_array($this->table_aliases_arr[$table_name]))
												foreach ($this->table_aliases_arr[$table_name] as $sub_alias) $this->sql .= $table_name . ' AS ' . $sub_alias . ', ';
						}
						else  $this->sql .= $table_name . ', ';
				}
				$this->sql = substr($this->sql, 0, strrpos($this->sql, ', '));
		}
		public function setRecordSelectConditionSQL($sql_condition)
		{
				$this->sql_condition = $sql_condition;
		}
		public function buildConditionQuery()
		{
				$this->sql_condition = '';
		}
		public function buildSortQuery()
		{
				$tmp_dsc_sort_columns_arr = $this->dsc_sort_columns_arr;
				$tmp_asc_sort_columns_arr = $this->asc_sort_columns_arr;
				if (is_array($this->field_aliases_arr))
				{
						foreach ($this->field_aliases_arr as $alias => $original)
						{
								if (($key = array_search($alias, $this->dsc_sort_columns_arr)) !== false) $tmp_dsc_sort_columns_arr[$key] = $original;
								if (($key = array_search($alias, $this->asc_sort_columns_arr)) !== false) $tmp_asc_sort_columns_arr[$key] = $original;
						}
				}
				if ($tmp_asc_sort_columns_arr)
						while (list(, $asc_field) = each($tmp_asc_sort_columns_arr)) $this->sql_sort .= $asc_field . ' ASC, ';
				if ($tmp_dsc_sort_columns_arr)
						while (list(, $dsc_field) = each($tmp_dsc_sort_columns_arr)) $this->sql_sort .= $dsc_field . ' DESC, ';
				$this->sql_sort = substr($this->sql_sort, 0, strrpos($this->sql_sort, ', '));
		}
		public function setRecordSelectSQL($sql)
		{
				$this->sql = $sql;
		}
		public function buildQuery()
		{
				$this->sql_count = 'SELECT COUNT(*) AS count FROM ';
				foreach ($this->table_names_arr as $table_name)
				{
						if (isset($this->table_aliases_arr[$table_name]))
						{
								if (is_string($this->table_aliases_arr[$table_name])) $this->sql_count .= $table_name . ' AS ' . $this->table_aliases_arr[$table_name] . ', ';
								else
										if (is_array($this->table_aliases_arr[$table_name]))
												foreach ($this->table_aliases_arr[$table_name] as $sub_alias) $this->sql_count .= $table_name . ' AS ' . $sub_alias . ', ';
						}
						else  $this->sql_count .= $table_name . ', ';
				}
				$this->sql_count = substr($this->sql_count, 0, strrpos($this->sql_count, ','));
				if ($this->sql_condition) $this->sql_count .= ' WHERE ' . $this->sql_condition;
				if ($this->sql_condition) $this->sql .= ' WHERE ' . $this->sql_condition;
				if ($this->sql_sort) $this->sql .= ' ORDER BY ' . $this->sql_sort;
				$this->sql .= ' LIMIT ' . $this->results_start_num . ',' . $this->results_num_per_page;
		}
		public function executeQuery()
		{
				$stmt = $this->dbObj->Prepare($this->sql_count);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = $rs->fetchRow();
				$this->results_tot_num = $row['count'];
				$this->results_end_num = $this->results_tot_pages_num = 0;
				if ($this->results_tot_num)
				{
						$this->results_tot_pages_num = ceil($this->results_tot_num / $this->results_num_per_page);
						$stmt = $this->dbObj->Prepare($this->sql);
						$this->rs = $this->dbObj->Execute($stmt);
						if (!$this->rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
						$this->results_end_num = $this->results_start_num + $this->rs->PO_RecordCount();
				}
		}
		public function isResultsFound()
		{
				return $this->results_tot_num;
		}
		public function fetchResultRecord()
		{
				return ($this->rs) ? ($this->records_arr = $this->rs->FetchRow()) : '';
		}
		public function getResultsStartNum()
		{
				return $this->results_start_num;
		}
		public function getResultsEndNum()
		{
				return $this->results_end_num;
		}
		public function getResultsTotalNum()
		{
				return $this->results_tot_num;
		}
		public function getResultsTotPagesNum()
		{
				return $this->results_tot_pages_num;
		}
		public function populatePageNumbersList($highlight_start)
		{
				$is_selected = false;
				for ($pg = 1, $start = 0; $pg <= $this->results_tot_pages_num; ++$pg, $start += $this->results_num_per_page)
				{
?>
	<option value="<?php echo $start; ?>"<?php echo (!$is_selected && $start >= $highlight_start) ? ' selected="selected"' : ''; ?>><?php echo $pg; ?></option>
<?php
						$is_selected = ($start >= $highlight_start);
				}
		}
		public function setNumPerPageListArr($num_per_page_list_arr)
		{
				$this->num_per_page_list_arr = $num_per_page_list_arr;
		}
		public function populateNumPerPageList($highlight_numpg)
		{
				foreach ($this->num_per_page_list_arr as $num_per_page)
				{
?>
	<option value="<?php echo $num_per_page; ?>"<?php echo ($highlight_numpg == $num_per_page) ? ' selected="selected"' : ''; ?>><?php echo $num_per_page; ?></option>
<?php
				}
		}
		public function populateHiddenFormFields($field_names_arr = array())
		{
				foreach ($field_names_arr as $field_name)
				{
						if (is_array($this->fields_arr[$field_name]))
						{
								foreach ($this->fields_arr[$field_name] as $sub_field_value)
								{
?>
	<input type="hidden" name="<?php echo $field_name; ?>[]" value="<?php echo $sub_field_value; ?>" />
<?php
								}
						}
						else
						{
?>
	<input type="hidden" name="<?php echo $field_name; ?>" value="<?php echo $this->fields_arr[$field_name]; ?>" />
<?php
						}
				}
		}
		public function setIsSearch($is_search)
		{
				$this->is_search = $is_search;
		}
		public function setIsFullTextSearch($is_fulltext_search)
		{
		}
		public function setIsUseStemming($is_use)
		{
				$this->is_use_stemming = $is_use;
		}
		public function setIsHighlightSearchResults($is_highlight)
		{
				$this->is_highlight_search_results = $is_highlight;
		}
		private function _tokenizeSearchString($input)
		{
				$regexp = '/\s*(.*?)\s*"\s*([^"]*?)\s*"\s*(.*)/s';
				$tokens = array();
				while (preg_match($regexp, $input, $result_arr))
				{
						if ($result_arr[1]) $tokens = array_merge($tokens, explode(' ', $result_arr[1]));
						$tokens[] = $result_arr[2];
						$input = $result_arr[3];
				}
				if ($input) $tokens = array_merge($tokens, explode(' ', $input));
				return $tokens;
		}
		public function setSearchString($search_str)
		{
				$tokens_arr = $this->_tokenizeSearchString($search_str);
				foreach ($tokens_arr as $key => $keyword)
				{
						if (substr($keyword, 0, 1) == '-' && strlen($keyword) > 1) $this->search_exclude[] = substr($keyword, 1);
						else  $this->search_include[] = $keyword;
				}
		}
		public function setSearchFieldNames()
		{
				if (is_string())
				{
				}
				else
						if (is_array())
						{
						}
		}
		public function populatePageLinks($highlight_start = '0', $field_names_arr = array())
		{
				$html_url = substr($_SERVER['REQUEST_URI'], 0, strrpos($_SERVER['REQUEST_URI'], '?'));
				if ($highlight_start >= $this->results_tot_num) return false;
				$query_str = '';
				$highlight_start = floor($highlight_start / $this->results_num_per_page) * $this->results_num_per_page;
				foreach ($field_names_arr as $field_name)
				{
						if (is_array($this->fields_arr[$field_name]))
						{
								foreach ($this->fields_arr[$field_name] as $sub_field_value) $query_str .= "&amp;" . $field_name . "[]=$sub_field_value";
						}
						else
								if ($this->fields_arr[$field_name] != '') $query_str .= "&amp;$field_name=" . $this->fields_arr[$field_name];
				}
				$is_selected = false;
				$num_pages = 5;
				$num_expect = 10;
				$res = "<div class=\"clsPagingList\"><div class=\"clsPagingListLeft\"><ul>";
				$tot_page_num = (($num_pages + floor($highlight_start / $this->results_num_per_page)) < $this->results_tot_pages_num) ? ($num_pages + floor($highlight_start / $this->results_num_per_page)) : $this->results_tot_pages_num;
				$start_al = $highlight_start - ($num_pages * $this->results_num_per_page);
				$pg_al = $highlight_start / $this->results_num_per_page - ($num_pages - 1);
				if (ceil($highlight_start / $this->results_num_per_page) <= $num_pages)
				{
						$tot_page_num = (($num_pages + floor($highlight_start / $this->results_num_per_page)) < $this->results_tot_pages_num) ? ($num_pages + floor($highlight_start / $this->results_num_per_page)) : $this->results_tot_pages_num;
						$start_al = 0;
						$pg_al = 1;
				}
				$tot_page_num_for = $tot_page_num < $num_expect ? ($num_expect) : $tot_page_num;
				$tot_page_num = ($tot_page_num_for * $this->results_num_per_page) > $this->results_tot_num ? ceil($this->results_tot_num / $this->results_num_per_page) : $tot_page_num_for;
				$pg_al_for = ($tot_page_num - $pg_al) < $num_expect ? ($tot_page_num - $num_expect + 1) : $pg_al;
				$pg_al = $pg_al_for < 1 ? 1 : $pg_al_for;
				$start_al = $pg_al * $this->results_num_per_page - $this->results_num_per_page;
				if ($highlight_start > 1)
				{
						$res .= "<li class=\"clsPreviousPage clsCommonPaging\"><a href=\"" . URL($html_url) . "?start=" . ($highlight_start - $this->results_num_per_page) . "$query_str\">Previous</a></li>";
						if ($pg_al > 1)
						{
								$res .= "<li><a href=\"" . URL($html_url) . "?start=1" . "$query_str\">1</a></li>";
								$res .= "<li class=\"clsSpace\">..</li>";
						}
				}
				else
				{
						$res .= "<li class=\"clsPreviousPage clsCommonPaging clsInActivePage\"><span>Previous</span></li>";
						if ($pg_al > 1)
						{
								$res .= "<li class=\"clsCurrPage\">1</li>";
								$res .= "<li class=\"clsSpace\">..</li>";
						}
				}
				for ($pg = $pg_al, $start = $start_al; $pg <= $tot_page_num; ++$pg, $start += $this->results_num_per_page)
				{
						$res .= (!$is_selected && $start >= $highlight_start) ? "<li class=\"clsCurrPage\"><span>" . $pg . "</span></li>" : " <li><a href=\"" . URL($html_url) . "?start=$start$query_str\">" . $pg . "</a></li>";
						$is_selected = ($start >= $highlight_start);
				}
				$next = $highlight_start + $this->results_num_per_page;
				$last = (ceil($this->results_tot_num / $this->results_num_per_page) * $this->results_num_per_page) - $this->results_num_per_page;
				$last = $last < $next ? $next : $last;
				$last_text = ceil($this->results_tot_num / $this->results_num_per_page);
				if ($this->results_tot_num > $highlight_start + $this->results_num_per_page)
				{
						if ((($pg - 1) * $this->results_num_per_page) <= $last)
						{
								$res .= "<li class=\"clsSpace\">..</li>";
								$res .= "<li class=\"clsCommonPaging\"><a href=\"" . URL($html_url) . "?start=" . $last . "$query_str\">$last_text</a></li>";
						}
						$res .= "<li class=\"clsNextPage clsCommonPaging\"><a href=\"" . URL($html_url) . "?start=" . $next . "$query_str\">Next</a></li>";
				}
				else
				{
						if ((($pg - 1) * $this->results_num_per_page) < $last)
						{
								$res .= "<li class=\"clsSpace\">..</li>";
								$res .= "<li class=\"clsLastPage clsInActivePage\">$last_text</li>";
						}
						$res .= "<li class=\"clsNextPage clsCommonPaging clsInActivePage\"><span>Next</span></li>";
				}
				echo $res . '</ul></div></div>';
		}
		public function populatePageLinksGET($highlight_start = '0', $relative_url, $field_names_arr = array())
		{
				$html_url = substr($_SERVER['REQUEST_URI'], 0, strrpos($_SERVER['REQUEST_URI'], '?'));
				$html_url = $relative_url;
				if ($highlight_start >= $this->results_tot_num) return false;
				$query_str = '';
				$highlight_start = floor($highlight_start / $this->results_num_per_page) * $this->results_num_per_page;
				foreach ($field_names_arr as $field_name)
				{
						if (is_array($this->fields_arr[$field_name]))
						{
								foreach ($this->fields_arr[$field_name] as $sub_field_value) $query_str .= "&amp;" . $field_name . "[]=$sub_field_value";
						}
						else
								if ($this->fields_arr[$field_name] != '') $query_str .= "&amp;$field_name=" . $this->fields_arr[$field_name];
				}
				$is_selected = false;
				$num_pages = 5;
				$num_expect = 10;
				$res = "<div class=\"clsPagingList\"><div class=\"clsPagingListLeft\"><ul>";
				$tot_page_num = (($num_pages + floor($highlight_start / $this->results_num_per_page)) < $this->results_tot_pages_num) ? ($num_pages + floor($highlight_start / $this->results_num_per_page)) : $this->results_tot_pages_num;
				$start_al = $highlight_start - ($num_pages * $this->results_num_per_page);
				$pg_al = $highlight_start / $this->results_num_per_page - ($num_pages - 1);
				if ($highlight_start > 1)
				{
						$res .= "<li class=\"clsFirstPage clsCommonPaging\"><a href=\"" . URL($html_url) . "?start=1" . "$query_str\">First</a></li>";
						$res .= "<li class=\"clsPreviousPage\"><a href=\"" . URL($html_url) . "?start=" . ($highlight_start - $this->results_num_per_page) . "$query_str\" >Previous</a></li>";
				}
				else
				{
						$res .= "<li class=\"clsFirstPage clsInActivePage\">First</li>";
						$res .= "<li class=\"clsPreviousPage clsInActivePage\"><span>Previous</span></li>";
				}
				if (ceil($highlight_start / $this->results_num_per_page) <= $num_pages)
				{
						$tot_page_num = (($num_pages + floor($highlight_start / $this->results_num_per_page)) < $this->results_tot_pages_num) ? ($num_pages + floor($highlight_start / $this->results_num_per_page)) : $this->results_tot_pages_num;
						$start_al = 0;
						$pg_al = 1;
				}
				$tot_page_num_for = $tot_page_num < $num_expect ? ($num_expect) : $tot_page_num;
				$tot_page_num = ($tot_page_num_for * $this->results_num_per_page) > $this->results_tot_num ? ceil($this->results_tot_num / $this->results_num_per_page) : $tot_page_num_for;
				$pg_al_for = ($tot_page_num - $pg_al) < $num_expect ? ($tot_page_num - $num_expect + 1) : $pg_al;
				$pg_al = $pg_al_for < 1 ? 1 : $pg_al_for;
				$start_al = $pg_al * $this->results_num_per_page - $this->results_num_per_page;
				if ($this->results_tot_num > $highlight_start + $this->results_num_per_page)
				{
						$next = $highlight_start + $this->results_num_per_page;
						$last = (ceil($this->results_tot_num / $this->results_num_per_page) * $this->results_num_per_page) - $this->results_num_per_page;
						$last = $last < $next ? $next : $last;
						$res .= "<li class=\"clsNextPage clsCommonPaging\"><a href=\"" . URL($html_url) . "?start=" . $next . "$query_str\">Next</a></li>";
						$res .= "<li class=\"clsLastPage\"><a href=\"" . URL($html_url) . "?start=" . $last . "$query_str\">Last</a></li>";
				}
				else
				{
						$res .= "<li class=\"clsNextPage clsCommonPaging clsInActivePage\"><span>Next</span></li>";
						$res .= "<li class=\"clsLastPage clsInActivePage\">Last</li>";
				}
				echo $res . '</ul></div></div>';
		}
		public function getOrderCss($field)
		{
				if ($this->fields_arr['orderby_field'] == $field)
				{
						if ($this->fields_arr['orderby'] == 'desc') return ' class="clsDesc"';
						else  return ' class="clsAsc"';
				}
				else  return;
		}
		public function populatePageLinksPOST($highlight_start = '0', $form_name = '')
		{
				$href_url = $_SERVER['REQUEST_URI'];
				if ($highlight_start >= $this->results_tot_num) return false;
				$query_str = '';
				$highlight_start = floor($highlight_start / $this->results_num_per_page) * $this->results_num_per_page;
				$is_selected = false;
				$num_pages = 5;
				$num_expect = 10;
				$res = "<div class=\"clsPagingList\"><div class=\"clsPagingListLeft\"><ul>";
				$tot_page_num = (($num_pages + floor($highlight_start / $this->results_num_per_page)) < $this->results_tot_pages_num) ? ($num_pages + floor($highlight_start / $this->results_num_per_page)) : $this->results_tot_pages_num;
				$start_al = $highlight_start - ($num_pages * $this->results_num_per_page);
				$pg_al = $highlight_start / $this->results_num_per_page - ($num_pages - 1);
				if ($highlight_start > 1)
				{
						$res .= "<li class=\"clsPreviousPage clsCommonPaging\"><a href=\"" . $href_url . "\" onClick=\"return pagingSubmit('" . $form_name . "','" . ($highlight_start - $this->results_num_per_page) . "')\">Previous</a></li>";
						$res .= "<li class=\"clsFirstPage\"><a href=\"" . $href_url . "\" onClick=\"return pagingSubmit('" . $form_name . "','1')\">First</a></li>";
				}
				else
				{
						$res .= "<li class=\"clsPreviousPage clsCommonPaging clsInActivePage\"><span>Previous</span></li>";
						$res .= "<li class=\"clsFirstPage clsInActivePage\">First</li>";
				}
				if (ceil($highlight_start / $this->results_num_per_page) <= $num_pages)
				{
						$tot_page_num = (($num_pages + floor($highlight_start / $this->results_num_per_page)) < $this->results_tot_pages_num) ? ($num_pages + floor($highlight_start / $this->results_num_per_page)) : $this->results_tot_pages_num;
						$start_al = 0;
						$pg_al = 1;
				}
				$tot_page_num_for = $tot_page_num < $num_expect ? ($num_expect) : $tot_page_num;
				$tot_page_num = ($tot_page_num_for * $this->results_num_per_page) > $this->results_tot_num ? ceil($this->results_tot_num / $this->results_num_per_page) : $tot_page_num_for;
				$pg_al_for = ($tot_page_num - $pg_al) < $num_expect ? ($tot_page_num - $num_expect + 1) : $pg_al;
				$pg_al = $pg_al_for < 1 ? 1 : $pg_al_for;
				$start_al = $pg_al * $this->results_num_per_page - $this->results_num_per_page;
				for ($pg = $pg_al, $start = $start_al; $pg <= $tot_page_num; ++$pg, $start += $this->results_num_per_page)
				{
						$res .= (!$is_selected && $start >= $highlight_start) ? "<li class=\"clsCurrPage\"><span>" . $pg . "</span></li>" : " <li><a href=\"" . $href_url . "\" onClick=\"return pagingSubmit('" . $form_name . "','" . $start . "')\">" . $pg . "</a></li>";
						$is_selected = ($start >= $highlight_start);
				}
				if ($this->results_tot_num > $highlight_start + $this->results_num_per_page)
				{
						$next = $highlight_start + $this->results_num_per_page;
						$last = (ceil($this->results_tot_num / $this->results_num_per_page) * $this->results_num_per_page) - $this->results_num_per_page;
						$last = $last < $next ? $next : $last;
						$res .= "<li class=\"clsLastPage\"><a href=\"" . $href_url . "\" onClick=\"return pagingSubmit('" . $form_name . "','" . $last . "')\">Last</a></li>";
						$res .= "<li class=\"clsNextPage clsCommonPaging\"><a href=\"" . $href_url . "\" onClick=\"return pagingSubmit('" . $form_name . "','" . $next . "')\">Next</a></li>";
				}
				else
				{
						$res .= "<li class=\"clsLastPage clsInActivePage\">Last</li>";
						$res .= "<li class=\"clsNextPage clsCommonPaging clsInActivePage\"><span>Next</span></li>";
				}
				echo $res . '</ul></div></div>';
		}
}
?>