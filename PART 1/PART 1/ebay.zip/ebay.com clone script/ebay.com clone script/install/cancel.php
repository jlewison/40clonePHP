<?php //00461
// Copyright Notice
// Web Site URL:  http://www.zeeways.com
// Script Owner eMail: mail@zeeways.com
// Date: April, 2007
// Script Name: Zeeways Auction Website PHP Script
// Copyright Details: This script is not free.  Do not Remove this Copy Right notice.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the site administrator.');exit(199);
?>
4+oV57SIViDAvKBr1wdhu7zgOQCw5U0SxaeohTf/MIoYSxHTokTj9udf15/CD/cCLzmIBrumoA6l
RVqetMcPWJUxVHLtsummpjwXe6DBpgN1JSP2Fax8PquQsIrMBcsYukZJUSfRN9b8Hz7DMhj+HiK8
jIZQSilVaVia+7zNhEF+pOVk4YuSb8nrS7ZoOxVhanVTq669q3rLC6ZhoAyiIbY1ytm6kFXB+WPD
H+e3z4PUVAbNp9X3BYwwlPQcD0nCS/Sjhab+jffm4OErPiLgGfT/ZN1qgq6ScLA38HAsepNtPASP
QUHKDZTnrBE5AOU12WzjVuEaT9gspgQGmqziu0w2cO90J5mYye9V3Ql7v4VRak8D5etYZRgTU/Uh
L0dcj/zrRcnUT8w8TsoRVBAEkn6Q6MDsjgoHpl2bqbm8FQ0BaQwqWtDDgrRZS+gIYprTCj246nDX
XaImib6jLIS8+uyhGHlbm7XIp8ljWwxr2q6ozNoqiPg+09XNXQa2ar61BH9YQdIl6UXSXuAvmfZk
GiWnqlaRBz1PPbozIGhAZbHaUSQ6Gg5vGUTwf5nSLExsXfBod6yKxPJ2L4ttt4bsrDsnedrendkG
5u2oInCLpyYoXCdFLtvhydZXd72qnpEyo91hRMfa/raAXzYohlRHItor08xXHpJcFaWOHM3BV5oB
eYlGYoUwNtnhnw9ooCsZ5WPGlRtgbz/jcrqMphbgKlaZQqbCyTpFr6xgkOEsJy2CtWZgg60SQ/6f
XBE3Y7ou/KqSfJzN6NNQEtLG8lgcLuz9Gie1U8jBNsK2GzsboCzbVAUxdk8FccIgPA6QY+83FI1F
/fhgpzTKsy3vs6IHL61B7A94zWaGchEnv65NT4Sz7K9raBNeSpi9LPf1DCVmZrOHPJqIt/fhO7ij
FQniF+MCk0rIdbRFWGzw2li6m1o6c6a2wkf4NpX1IpEu5Wq6Tx3+xHqbBcT592jVSNfGBh/haDVv
8smxS9bAcV6663ywa/87XTOuNwaF+aX/jG1fd6xwehQG93/7z16mn0mKTnSBKFl3jmkugt3IoOwf
fp8trzAoBIQQZm==