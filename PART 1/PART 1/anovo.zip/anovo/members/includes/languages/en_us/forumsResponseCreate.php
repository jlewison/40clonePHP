<?php
$LANG['forumlistall_title_index'] = 'Forum Index';
$LANG['forumsresponse_post_response'] = 'Post Response';
$LANG['forumlistall_back_responses'] = 'Back to Forum Responses';
$LANG['forumsresponse_forum_title'] = 'Forum Title : ';
$LANG['forumsresponse_topic'] = 'Topic: ';
$LANG['forumsresponse_subject'] = 'Subject:';
$LANG['forumsresponse_body'] = 'Body:';
$LANG['forumsresponse_response'] = 'Your Response';
$LANG['forumsresponse_ratings'] = 'Rate This Topic (optional)';
$LANG['forumsresponse_ratings_information'] = '( 1 = lowest   and 10 = highest )';
$LANG['forumsresponse_submit'] = 'Submit';
$LANG['forumsresponse_cancel'] = 'Cancel';
$LANG['forumsresponse_forum_title_description'] = 'Description:';
$LANG['forumsresponse_err_tip_compulsory'] = 'Compulsory';
$LANG['forumsresponse_err_tip_topic_exists'] = 'Topic already exists.';
$LANG['forumsresponse_err_tip_invalid_forum_id'] = 'Invalid Forum ID.';
$LANG['forumsresponse_err_tip_invalid_forum_topic_id'] = 'InvalidForum Topic ID.';
$LANG['forumsresponse_err_tip_invalid_forum_response_id'] = 'InvalidForum Response ID';
$LANG['forumsresponse_err_tip_cannot_create_forum_topic'] = 'You have already created XCOUNTX topics in this XFORUMX. You can\'t create any topic in this XFORUMX';
$LANG['forumsresponse_tbl_summary'] = 'Container to create topic';
$LANG['info_not_allowed_to_post'] = 'You are not allowed to post a response as you are abused by most of the users';
?>