<?php //00461
// Copyright Notice
// Web Site URL:  http://www.zeeways.com
// Script Owner eMail: mail@zeeways.com
// Date: April, 2007
// Script Name: Zeeways Auction Website PHP Script
// Copyright Details: This script is not free.  Do not Remove this Copy Right notice.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the site administrator.');exit(199);
?>
4+oV55AjC9sCYudINHQbljB9eE1YwBPjSMec+PgiHZKeqhhHpZAog14G9dOgIwe5X7Ztkt1W133h
1k2hbAzyLCp1k5QLw3jY5CvwJFo2nT0kFutpIs9vkkB9CK8SpM/tWHUSk2d07mQ1baaYZBF7Ja/F
id8GYHqOFxdXtnnM9GQBgQBH3WUr61USQPkWsl+73FsSskW5hqJcOiAtTkhA99gDd9fpHU1ZYKdd
0SYUdthXt9Fs9nJvi3s5bgOq34npzoskINwscd0HWvjapZTmgO/zIjlPecpEYlvR/uTzgNJSAk0N
eUaPfmzbDi4E1HNMNIOavKgovP9Y9JioBKg8bGWtLelz5KEUZYtayTsXWx3d8pN9r4Jvm9OWy6tS
D8vZpP4nxBVMDWnRIhIJbefU1qTqCY/JODw8LSt+qvvg7Ope5UZegKjTmDu9AsQqjbmxj05Ws0/3
W7ZUZ5+ibXsxu43qRQ+oJgoRsI7QcjNE+14CyMGDnd2Vw9rHZHyB7soX37A2RMtO6U+Rc3yZh/Gu
j9AumugusMCFbL8pcyBC1aWZ6OkHLIzw5BWVj850IUaBUmDND0R/jPduk8in7glmr4SjI/ielOjr
uOmExB3NdcIXo8nK8OyivOr2MYd/LgHHgzv6he/5fWbNTdyBBejDJmU1LRSm/FDvRiG+VtlXoKCY
127B2t1MFkwlutUuu2FMNBp8mro598cdshZBYpZACoXYKNt4+PzoTM7SXiOn8n0kCzJz4a7fEuGb
syDbeSHeH3fme1rMXwIfsDQGEuVRVF412q8TBcRD62cVxBRMXznp30fbbPR05xuMhliN/Dw6OXC9
zf635NzfEEYIcemOpivZXMK8oLtu2o0USC973GL0EeMB4dJPRoGSZT2AmsEKGD0OghfVEHdwPV+u
8FhYODrI9M1DCA0rjZFJKy9dGRzen9uoy3yi2vkuZI0o3oPbW9hMMBcKIPh/WNFMGsYh7F81zrUR
QUtpGb+yYQKOM/Pgx8eO14Do5DesEZCry0SFVMb+NT7QV7cDAiwFCwVDNARAX3ytvX79tiZPo4Fa
KqRvLzcdmMs2zBkI6jj4lK9nzsDiQpKccyEIw9GHjUfW3TJMl80U7RFNCVvp