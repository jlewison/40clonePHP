<?php 
	// after your Pligg is installed, change this to false
	$do_check = true;

	if($do_check == true){
		if (strpos($_SERVER['SCRIPT_NAME'], "install.php") == 0){
			$file = dirname(__FILE__) . '/../settings.php';
			if (!file_exists($file)) { $errors[]="'$file' was not found! Try renaming 'settings.php.default' to 'settings.php'"; }
			elseif (filesize($file) <= 0) { $errors[]="'$file' is 0 bytes!"; }
	
			$file = dirname(__FILE__) . '/../libs/dbconnect.php';
			if (!file_exists($file)) { $errors[]="'$file' was not found! Try renaming 'dbconnect.php.default' to 'dbconnect.php'"; }
	
			$file= dirname(__FILE__) . '/../templates_c';
			if (!file_exists($file)) { $errors[]="'$file' was not found! Create a directory called templates_c in your root directory."; }
			elseif (!is_writable($file)) { $errors[]="'$file' is not writable! Please chmod this directory to 777"; }
	
			$file= dirname(__FILE__) . '/../cache';
			if (!file_exists($file)) { $errors[]="'$file' was not found! Create a directory called cache in your root directory."; }
			elseif (!is_writable($file)) { $errors[]="'$file' is not writable! Please chmod this directory to 777"; }
	
			if (isset($errors)) {
				foreach ($errors as $error) {
					$output.="<p><b>Error:</b> $error</p>\n";
					$output.='<p>Please fix the above error(s), install halted!</p>';
				}
				die($output);
			}
		}
	}
?>
