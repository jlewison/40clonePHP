	<table width="610">
	<u><font face="Verdana" size="3"><b>You agree to not use Rapidsendit's Service to:</b></font></u><br><br>
		<div style="text-align: justify;">
		<font face="Verdana" size="2">
		<b>a.</b> upload, post, e-mail, transmit or otherwise make available any Content that spreads messages of terror or depicts torture or death-gui; if serious enough, the content will be reported to the appropriate legal authority and/or the member's ISP will be contacted;</div>
		<br><br>

		<b>b.</b> harm minors in any way, this includes any form of child pornography; if serious enough, the content will be reported to the appropriate legal authority and/or the member's ISP will be contacted;		<br><br>

		<b>c.</b> upload, post, e-mail, transmit or otherwise make available any Content that infringes any patent, trademark, trade secret, copyright or other proprietary rights of any party.		<br><br>
</font>
		<br>		
		

		<u><font face="Verdana" size="3"><b>Copyright or Trademark Infringement</b></font></u><br>
		<div style="text-align: justify;"><font face="Verdana" size="2">
		Rapidsendit Services may be used only for lawful purposes. Transmission, distribution or storage of any material in violation of any applicable law or regulation, including export control laws, is prohibited. This includes, without limitation, material protected by patent, copyright, trademark, service mark, trade secret or other intellectual property rights. If you use another party's material, you must obtain prior authorization. By using the Services, you represent and warrant that you are the author and copyright owner and/or proper licensee with respect to any hosted content and you further represent and warrant that no content violates the trademark or rights of any third party. Rapidsendit reserves the right to suspend or terminate a Customer's transmission(s) that, in Rapidsendit's discretion, violates these policies or violates any law or regulation.</div>
</font>
		<br><br>

	</table>	