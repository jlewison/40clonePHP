<?php
class VideoUpload extends FormHandler
{
		public $video_details;
		public function populateVideoDetails()
		{
				$param_arr = explode('_', $this->fields_arr['pg']);
				$this->fields_arr['video_for'] = $param_arr[0];
				$this->fields_arr['vid'] = $param_arr[1];
				$sql = 'SELECT video_id, content_id, user_id, video_ext, video_size,' . ' playing_time, date_added, t_width, t_height, video_server_url' . ' FROM ' . $this->CFG['db']['tbl']['ans_video'] . ' WHERE' . ' video_id=' . $this->dbObj->Param('video_id') . ' AND' . ' video_status=\'Ok\' AND' . ' video_encoded_status=\'Yes\' AND' . ' video_for=' . $this->dbObj->Param('video_for');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['vid'], $this->fields_arr['video_for']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($this->video_details = $rs->FetchRow()) return true;
				return false;
		}
		public function resetFieldsArray()
		{
				$this->setFormField('pg', '');
		}
}
$VideoUpload = new VideoUpload();
$VideoUpload->setDBObject($db);
$VideoUpload->makeGlobalize($CFG, $LANG);
if (!isAjax()) Redirect2URL($CFG['site']['url']);
$VideoUpload->setHeaderStart();
$VideoUpload->setPageBlockNames(array('msg_form_error', 'msg_form_success', 'video_display'));
$VideoUpload->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$VideoUpload->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$VideoUpload->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$VideoUpload->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$VideoUpload->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$VideoUpload->resetFieldsArray();
$VideoUpload->setAllPageBlocksHide();
$VideoUpload->sanitizeFormInputs($_REQUEST);
if ($VideoUpload->isFormGETed($_REQUEST, 'pg'))
{
		if (!$VideoUpload->populateVideoDetails())
		{
				$VideoUpload->setAllPageBlocksHide();
				$VideoUpload->setCommonErrorMsg($LANG['error_video']);
				$VideoUpload->setPageBlockShow('msg_form_error');
		}
		else
		{
				$VideoUpload->setPageBlockShow('video_display');
		}
}



?>
<div id="selVideoUpload" class="">
	<p class="clsPopupClose"><a href="#" onClick="return closLightWindow()"><?php echo $LANG['close']; ?></a></p>
	<div id="selLeftNavigation">
<?php
if ($VideoUpload->isShowPageBlock('msg_form_error'))
{
?>
		  <div id="selMsgError">
		    <p><?php echo $VideoUpload->getCommonErrorMsg(); ?></p>
		  </div>
<?php
}
if ($VideoUpload->isShowPageBlock('video_display'))
{
		$videos_folder = $CFG['admin']['ans_videos']['folder'];
		$flv_player_url = $CFG['site']['url'] . 'files/flash/flv_player/flvplayer.swf';
		$arguments_play = 'pg=video_' . $VideoUpload->getFormField('vid');
		$configXmlcode_url = $CFG['site']['url'] . 'ansVideoConfigXmlCode.php?';
		echo '<embed src="' . $flv_player_url . '" FlashVars="config=' . $configXmlcode_url . $arguments_play . '" quality="high" allowFullScreen="true" bgcolor="#000000" width="450" height="370" name="flvplayer" align="middle" allowScriptAccess="always" type="application/x-shockwave-flash" wmode="' . $CFG['admin']['wmode_value'] . '" pluginspage="http://www.macromedia.com/go/getflashplayer" />';
}
?>
	</div>
</div>
<?php


$VideoUpload->setHeaderEnd();
?>