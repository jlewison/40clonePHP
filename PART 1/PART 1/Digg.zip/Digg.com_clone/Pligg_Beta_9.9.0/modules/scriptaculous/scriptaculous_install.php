<?php
	$module_info['name'] = 'Javascript Effects Pack';
	$module_info['desc'] = 'scriptaculous, editinplace, prototype';
	$module_info['version'] = 0.1;
?>