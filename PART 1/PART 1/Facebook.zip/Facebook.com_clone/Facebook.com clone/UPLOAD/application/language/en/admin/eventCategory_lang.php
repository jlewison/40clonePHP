<?php
/**
*
*
*
* @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
* @license
* @version SVN:$Id
* @since 2007-06-18
*/
$lang['eventcategory_title'] 					= 'Manage Event Category';
$lang['eventcategory_category_name'] 			= 'Category Name';
$lang['eventcategory_description'] 				= 'Description';
$lang['eventcategory_status'] 					= 'Status';
$lang['eventcategory_sub_category_name'] 		= 'Sub Category Name';
$lang['eventcategory_sub_description'] 			= 'Sub Category Description';
$lang['eventcategory_sub_status'] 				= 'Sub Category Status';
$lang['eventcategory_category_note'] 			= '(Category name should not exceed 25 chars)';
$lang['eventcategory_description_note'] 		= '(Description should not exceed 50 chars)';
$lang['eventcategory_enabled'] 					= 'Enabled';
$lang['eventcategory_disabled'] 				= 'Disabled';
$lang['eventcategory_submit'] 					= 'Submit';
$lang['eventcategory_select_all'] 				= 'Select All';
$lang['eventcategory_delete_selected'] 			= 'Delete Selected';
$lang['eventcategory_category'] 				= 'Category';
$lang['eventcategory_sub_category'] 			= 'Sub Category';
$lang['eventcategory_description'] 				= 'Description';
$lang['eventcategory_status'] 					= 'Status';
$lang['eventcategory_date_added'] 				= 'Date Added';
$lang['eventcategory_action'] 					= 'Action';
$lang['eventcategory_delete'] 					= 'Delete';
$lang['eventcategory_edit'] 					= 'Edit';
$lang['eventcategory_base_category'] 			= 'Base Category';
$lang['eventcategory_no_records'] 				= 'No event category found';
$lang['eventcategory_sub_no_records'] 			= 'No event sub category found';
$lang['eventcategory_add_success_msg'] 			= 'Event category added successfully';
$lang['eventcategory_update_success_msg'] 		= 'Event category updated successfully';
$lang['eventcategory_sub_add_success_msg'] 		= 'Event sub category added successfully';
$lang['eventcategory_sub_update_success_msg'] 	= 'Event sub category updated successfully';
?>