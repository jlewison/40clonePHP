<?php
	$module_info['name'] = 'Page Statistics';
	$module_info['desc'] = 'Page Statistics gives a detailed information on pageviews of each stories in your Pligg site';
	$module_info['version'] = 0.2;
?>