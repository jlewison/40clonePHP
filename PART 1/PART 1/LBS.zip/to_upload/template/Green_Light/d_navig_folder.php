<?php require_once('Connections/apound.php'); ?>
<?php
mysql_select_db($database_apound, $apound);
$query_categRL = "SELECT categoryname, categseoname FROM categorylisting WHERE categorylisting.categenable = 'Y'  ORDER BY categorylisting.categoryname ASC";
$categRL = mysql_query($query_categRL, $apound) or die(mysql_error());
$row_categRL = mysql_fetch_assoc($categRL);
$totalRows_categRL = mysql_num_rows($categRL);
?>

<div class="box">
	<div class="box-cap-right"><div class="box-cap"></div></div>
	<div class="cat-heads"><div class="cat-heads-right"><div class="cat-heads-left">categories</div></div></div>
	<div class="box2-left">
		<div class="box-right">
	<ul class="cats-list">   
    <?php do { ?>
    <li><a href="<?php echo("$path");?><?php echo $row_categRL['categseoname']; ?>/"><?php echo $row_categRL['categoryname']; ?></a></li>
    <?php
		$row_categRL = mysql_fetch_assoc($categRL);
		if (!isset($nested_categRL)) {
		$nested_categRL= 1;
		}
		} while ($row_categRL);
		?>
		<li><a href="<?php echo("$path");?>contact.php">Suggest Category</a></li>
	</ul>
		</div>
	</div>
	<div class="box-bottom-left">
		<div class="box-bottom-right">
		</div>
	</div>