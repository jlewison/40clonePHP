<?php

class ForumsFormHandler extends ListRecordsHandler
{
		public function buildConditionQuery($condition = '')
		{
				$this->sql_condition = $condition;
		}
		public function checkSortQuery($field, $sort = 'asc')
		{
				if (!($this->sql_sort))
				{
						$this->sql_sort = $field . ' ' . $sort;
				}
		}
		public function showForumTitles()
		{
				if (!$this->isResultsFound())
				{
?>
					<div id="selMsgAlert">
						<p><?php echo $this->LANG['forums_no_titles']; ?></p>
					</div>
				<?php
						return;
				}
?>
				<table summary="<?php echo $this->LANG['forums_tbl_summary']; ?>">
					<tr>
						<th><?php echo $this->LANG['forums_title']; ?></th>
						<th><?php echo $this->LANG['forums_posts']; ?></th>
                       <th><?php echo $this->LANG['forums_responses']; ?></th>
						<th><?php echo $this->LANG['forums_last_post']; ?></th>
					</tr>
				<?php
				while ($row = $this->fetchResultRecord())
				{
						$userDetails = $row;
						$userDetails['user_id'] = $row['last_post_user_id'];
?>
						<tr>
							<td id="selForumTopicList">
								<h3><a href="<?php echo getUrl('forumsTopics.php?forum_id=' . $row['forum_id'], 'forum/' . $row['forum_id'] . '/'); ?>">
									<?php echo stripslashes($row['forum_title']); ?>
								</a></h3>
								<p><?php echo nl2br(stripslashes($row['forum_description'])); ?></p>
							</td>
							<td class="clsTopicRes clsCenter">
								<p><?php echo $row['total_topics']; ?></p>
                              </td>
                            <td class="clsTopicRes clsCenter">
								<p><?php echo $row['total_response']; ?></p>
							</td>
							<td>
								<?php if (chkUserImageAllowed())
						{ ?>
								<p id="selImageBorder"><?php displayForumUserSmallImage($userDetails, true, true); ?></p>
								<?php } ?>
								<p><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'myanswers.php?uid=' . $userDetails['user_id'], $this->CFG['site']['relative_url'] . 'my/answers/' . $userDetails['user_id'] . '/', false); ?>"><?php echo stripString($userDetails['name'], $this->CFG['username']['short_length']); ?></a></p>
							</td>
						</tr>
					<?php
				}
?>
				</table>
			<?php
		}
}
$forums = new ForumsFormHandler();
if (!chkAllowedModule(array('forums'))) Redirect2URL($CFG['redirect']['dsabled_module_url']);
$forums->setPageBlockNames(array('msg_form_error', 'msg_form_success', 'form_show_forums', 'page_nav', 'form_confirm'));
$forums->setCSSAlternativeRowClasses($CFG['data_tbl']['css_alternative_row_classes']);
$forums->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$forums->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$forums->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$forums->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$forums->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$forums->setDBObject($db);
$forums->setCfgLangGlobal($CFG, $LANG);
$forums->setAllPageBlocksHide();
$forums->setFormField('numpg', 0);
$forums->setFormField('start', 0);
$forums->setFormField('prev_numpg', 0);
$forums->setFormField('asc', 'f.forum_title');
$forums->setFormField('dsc', '');
$condition = '';
$forums->numpg = $CFG['data_tbl']['numpg'];
$forums->setFormField('start', 0);
$forums->setFormField('numpg', $CFG['data_tbl']['numpg']);
$forums->setMinRecordSelectLimit($CFG['data_tbl']['min_record_select_limit']);
$forums->setMaxRecordSelectLimit($CFG['data_tbl']['max_record_select_limit']);
$forums->setNumPerPageListArr($CFG['data_tbl']['numperpage_list_arr']);
$forums->setTableNames(array());
$forums->setReturnColumns(array());
$forums->setTableNames(array($CFG['db']['tbl']['forums'] . ' as f LEFT JOIN ' . $CFG['db']['tbl']['users'] . ' AS u on f.last_post_user_id = u.' . $CFG['users']['user_id']));
$forums->setReturnColumns(array('f.forum_id', 'f.forum_title', 'f.forum_description', 'f.forum_status', 'f.total_topics', 'f.total_response', 'f.last_post_date', 'f.last_post_user_id', $forums->getUserTableField('name') . ' as name', $forums->getUserTableField('image_path') . ' as image_path', $forums->getUserTableField('gender') . ' as gender', 'f.last_post_user_id AS img_user_id', $forums->getUserTableFields(array('t_height', 't_width', 's_height', 's_width', 'photo_server_url', 'photo_ext'))));
$condition = 'forum_status = \'Yes\'';
$forums->sanitizeFormInputs($_REQUEST);
$forums->buildSelectQuery();
$forums->buildConditionQuery($condition);
$forums->buildSortQuery();
$forums->checkSortQuery('f.forum_id', 'DESC');
$forums->buildQuery();
$forums->executeQuery();
$forums->setPageBlockShow('form_show_forums');
if ($forums->isResultsFound())
{
		$forums->setPageBlockShow('page_nav');
}



?>
<div id="selForums" class="clsForums">
	<h2><span><?php echo $LANG['forums_title_index']; ?></span></h2>
<?php
if ($forums->isShowPageBlock('msg_form_error'))
{
?>
		<div id="selMsgError">
			 <p><?php echo $LANG['msg_error_sorry']; ?> <?php echo $forums->getCommonErrorMsg(); ?></p>
		</div>
<?php
}
if ($forums->isShowPageBlock('msg_form_success'))
{
?>
		<div id="selMsgSuccess">
			<p><?php echo $LANG['forums_success_message']; ?></p>
		</div>
<?php
}
if ($forums->isShowPageBlock('page_nav') && $CFG['admin']['navigation']['top'])
{
		$forums->populatePageLinks($forums->getFormField('start'));
}
if ($forums->isShowPageBlock('form_show_forums'))
{
?>
	<form name="selForums" id="selForums" method="post" action="<?php echo $_SERVER['REQUEST_URI']; ?>">
		<?php $forums->showForumTitles(); ?>
	</form>
<?php
}
if ($forums->isShowPageBlock('page_nav') && $CFG['admin']['navigation']['bottom'])
{
		$forums->populatePageLinks($forums->getFormField('start'));
}
?>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>