<?php
/**
*
*
*
* @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
* @license
* @version SVN:$Id
* @since 2007-06-18
*/
$lang['managereports_title'] 					= 'Manage Reports';
$lang['managereports_report'] 					= 'Report';
$lang['managereports_block'] 					= 'Block';
$lang['managereports_show_reports'] 			= 'Show reports for';
$lang['managereports_groups'] 					= 'Groups';
$lang['managereports_event'] 					= 'Event';
$lang['managereports_photo'] 					= 'Photo';
$lang['managereports_network'] 					= 'Network';
$lang['managereports_posted_item'] 				= 'Posted Item';
$lang['managereports_profile'] 					= 'profile';
$lang['managereports_select_all'] 				= 'Select All';
$lang['managereports_report_type'] 				= 'Report Type';
$lang['managereports_reported_for'] 			= 'Reported for';
$lang['managereports_reported_by'] 				= 'Reported By';
$lang['managereports_action'] 					= 'Action';
$lang['managereports_delete_selected'] 			= 'Delete Selected';
$lang['managereports_report_delete_success'] 	= 'Report deleted successfully';
$lang['managereports_group_block_success'] 		= 'Groups Blocked successfully';
$lang['managereports_event_block_success'] 		= 'Event Blocked successfully';
$lang['managereports_photo_block_success'] 		= 'Photo Blocked successfully';
$lang['managereports_network_block_success'] 	= 'Network Blocked successfully';
$lang['managereports_posted_item_block_success']= 'Posted Item Blocked successfully';
$lang['managereports_profile_block_success'] 	= 'profile Blocked successfully';
$lang['managereports_go'] 						= 'Go';
$lang['managereports_delete'] 					= 'Delete';
$lang['managereports_view'] 					= 'View';
$lang['managereports_group_no_records'] 		= 'No group records found!';
$lang['managereports_event_no_records'] 		= 'No event records found!';
$lang['managereports_photo_no_records'] 		= 'No photo records found!';
$lang['managereports_network_no_records'] 		= 'No network records found!';
$lang['managereports_posted_item_no_records'] 	= 'No posted item records found!';
$lang['managereports_profile_no_records'] 		= 'No profile records found!';
?>