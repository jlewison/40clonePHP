<?php
if ( !defined( 'SMARTY_DIR' ) ) {
	include_once( '../init.php' );
}

include( 'sessioninc.php' );

include(LIB_DIR . 'plugin_class.php');

$plugin = new Plugin();


// Edit the preferences if save button pressed
//
if ( $_POST['action'] == 'edit_plugin' ) {

      $plugin->editPlugin($_POST['name']);

      if ( $plugin->getErrorMessage() ) {

          $t->assign ( 'error_message', $plugin->getErrorMessage() );
          $data = $_POST;
      }
      else {

          header( 'location: pluginlist.php' );
          exit;
      }
}
// Get the plugin info if just clicked a edit link
else {

    $data = $plugin->getPlugin($_REQUEST['name']);

}

$name = $_REQUEST['name'];

include_once(PLUGIN_DIR . $name . '/libs/'. $name . '.php');

$pluginobject = new $name();

$data['display_name']=$pluginobject->display_name;

$t->assign( 'data',  $data);

$t->assign( 'access',  $plugin->getPluginAccess($data['id']));
$t->assign( 'pluginconfig',  $plugin->getPluginConfig($data['id']));


// Make the page
//
$t->assign('rendered_page', $t->fetch('admin/editplugin.tpl') );

$t->display( 'admin/index.tpl' );

exit;

?>