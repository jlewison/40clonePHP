<?php //00461
// Copyright Notice
// Web Site URL:  http://www.zeeways.com
// Script Owner eMail: mail@zeeways.com
// Date: April, 2007
// Script Name: Zeeways Auction Website PHP Script
// Copyright Details: This script is not free.  Do not Remove this Copy Right notice.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the site administrator.');exit(199);
?>
4+oV59BZQZZJIcymlbZ/5nktiKk1h8bnlpzZK9YijndKOlaSv+td2l3Qvao7GvHSiu76LbnIlb9U
Bzv6HYgOlPKmrxV22zcRAPR27fyXjv6KNuSUo3DfTbMAKTIwISr1+wBAB5sG5F5ehDDVGK7Ky8w2
STlW0x0vO71OraSPf8A2wB7TA0+LKijvtHfOwgOe23gs6UG3WzoozvrDyB8+HDUrCaK3Ll54QyEK
u2BcDdbaKJJ+KH1HqpJAbgOq34npzoskINwscd0HWtvZe7OTukszDX9HJcoM6e5/TVZau3/t4Dy+
0Z7awKT9XaH9pEB6ZAdtPN4UjRhJ+tGJcO1ZsG83Q91PjuGJbB9+o4UWZM0QcSYZhQWPWw6NCDID
WCZ7zVe4yXKZ/rjOZjrddrfcOQfIKi2EBSGfxZ1f8+VBPCS02jOsRng9/Npc2stlK2P4xv/73uaU
Qjvv8VbhQxTLralyl/80gMv/G5exPIbHwC8Kl7P69cQIvykYXtJ1+OCfyFNJ6X1gvd3cchO4QiCv
jsyzf6Dg+lGjm/UytnA9m/RyhXIIweS47T48i8zmjnq+So7qIHB0N+S7PLCrXRJqklOxEae/H+yK
mXLo4r9/Dp2HX+nZ7dW13sdrADOYeL//EiGu4vVyEsOgF+2/OoA4gOzbJ19Nvp41mOxyVOdNewQ2
6CFQCe/XolgGdiAzIAQ6DrS6GRYSMqkxo8uCU2Yjg9/hiJ1DwilRMYeS07EWebvKdJ1CL4L7geoE
8oXymobPtP0q757SYHdp3kk8cIefrJSSKkzzKbZKUlzBFia9mlepMbwYKXlIticBgFFSXAyFm/7R
7Jjx5rgAhgni10EG/UICl7Hm1FSPKQ8lAVWV7lrqIlz/KATF46M2xlc+SQd5scFUzJWklcIHa1mq
HN0A2FfZc/kSdgnJ2YpwPxq7exyBUpGM76PktCmhM1rsgxbvTXnkFsRALzJMhSRGWlTgP4sDAfid
ZNJLrhkh+HDL9QrSTfySq0p7uUHe+LxmSfodTp4lDGDgYTtsZNKiQAyFrNfbDJFP4L4lcxx4RRnE
nVVVudNEolw9DLoSBPgAbOGf63LdphgMvaP8cywGMJLSL3f0Qvq3AiAKjTuLIBfppYrDMGAW/1we
/m3sXQPUcO911wDA+Hew0B1KHRQo