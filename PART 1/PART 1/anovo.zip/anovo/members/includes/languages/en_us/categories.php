<?php
$LANG['page_title'] = 'Categories';
$LANG['sub_category_title'] = 'Sub Category';
$LANG['no_category_found'] = 'No category found!';
$LANG['category_frequency'] = 'Questions';
$LANG['category_alphabetically'] = 'Alphabetically';
$LANG['category_click_for_subcategory'] = 'Click here for sub categories';
?>