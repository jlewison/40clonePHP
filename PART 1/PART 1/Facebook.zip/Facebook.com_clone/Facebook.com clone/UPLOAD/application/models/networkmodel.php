<?php

/**
 * networkModel Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 12/17/2007
 *
 * Tables: network_type, networks
 *
 */
class Networkmodel extends Model
{
		//Constructor
		function Networkmodel()
		{
				parent::Model();
				$this->load->model('usermodel');
		}
		function getNetwork($networkType = 'region', $country = '', $orderBy = '', $start = '', $limit = '', $getDisabled = false)
		{
				$this->db->select('network_id, user_id, network_type, network_status, network_name, network_email, network_country, country.country_name, country.country_symbol, network_city, network_state, state_province.state_name, state_province.state_symbol, contact_email, network_website, datestamp');
				$this->db->from('networks');
				$this->db->join('country', 'networks.network_country = country.country_id', 'inner');
				$this->db->join('state_province', 'networks.network_state = state_province.state_id', 'left');
				$this->db->where('network_type', $networkType);
				$this->db->where('network_type !=', '');
				$this->db->where('network_country !=', 0);
				$this->db->where('network_city !=', '');
				if (trim($country) != '') $this->db->where('country.country_symbol', $country);
				if ($getDisabled == false) $this->db->where('network_status', 'enabled');
				if (trim($orderBy) != '') $this->db->orderby($orderBy);
				else  $this->db->order_by('country.country_name ASC, state_province.state_name ASC, network_city ASC, network_name ASC');
				if (trim($limit) != '' && is_numeric($limit))
				{
						if (trim($start) != '' && is_numeric($start)) $this->db->limit($limit, $start);
						else  $this->db->limit($limit);
				}
				$networkQuery = $this->db->get();
				//echo $this->db->last_query();
				$networkTypes = array();
				if ($networkQuery->num_rows() > 0)
				{
						foreach ($networkQuery->result_array() as $networkRow)
						{
								$networkTypes[$networkRow['country_symbol']][$networkRow['state_name']][$networkRow['network_city']]['network_id'] = $networkRow['network_id'];
								$networkTypes[$networkRow['country_symbol']][$networkRow['state_name']][$networkRow['network_city']]['network_name'] = $networkRow['network_name'];
								$networkTypes[$networkRow['country_symbol']][$networkRow['state_name']][$networkRow['network_city']]['country_name'] = $networkRow['country_name'];
								$networkTypes[$networkRow['country_symbol']][$networkRow['state_name']][$networkRow['network_city']]['state_name'] = $networkRow['state_name'];
						}
				}
				return $networkTypes;
		}
		function isExist($networkId, $status = 'enabled')
		{
				$this->db->select('network_id');
				$this->db->from('networks');
				if (trim($status) != '' && (trim($status) == 'enabled' || trim($status) == 'disabled')) $this->db->where('network_status', $status);
				$this->db->where('network_id', $networkId);
				//$strSql  = 'SELECT network_id FROM networks WHERE network_status=\'enabled\' AND network_id=\''. trim($networkId) . '\'';
				$resSQL = $this->db->get();
				if ($resSQL->num_rows() > 0) return true;
				else  return false;
		}
		function isUserExist($networkId, $userId)
		{
				$strSql = 'SELECT nt.network_id FROM networks as nt
					INNER JOIN network_users AS nu ON nu.network_id = nt.network_id AND nu.network_id=' . $this->db->escape($networkId) . ' AND nu.user_id=' . $this->db->escape($userId) . ' AND nu.user_status=\'approved\' AND nu.is_deleted=\'0\'
					WHERE nt.network_status=\'enabled\' LIMIT 0, 1';
				$resSQL = $this->db->query($strSql);
				if ($resSQL->num_rows() > 0) return true;
				else  return false;
		}
		function getName($networkId)
		{
				$strSQL = 'SELECT IF(trim(network_name) = "" , network_city , network_name) as network_name FROM networks WHERE network_id=' . $this->db->escape(trim($networkId)) . ' AND network_status = "enabled"';
				$resSQL = $this->db->query($strSQL);
				$resArray = array();
				if ($resSQL->num_rows() > 0)
				{
						$resRow = $resSQL->result_array();
						$resArray[$networkId] = $resRow[0];
				}
				return $resArray;
		}
		function getNetworkDetails($networkId)
		{
				$this->db->from('networks');
				$this->db->where('network_id', $networkId);
				$networkQuery = $this->db->get();
				if ($networkQuery->num_rows() > 0)
				{
						$networkRow = $networkQuery->result_array();
						return $networkRow[0];
				}
				else  return false;
		}
		function getMembers($networkId, $orderBy = 'datestamp', $start = '', $limit = '')
		{
				$this->db->select('nu.user_id, u.username');
				$this->db->from('network_users as nu');
				$this->db->join('users as u', 'nu.user_id = u.user_id', 'inner');
				$this->db->where('nu.network_id', $networkId);
				$this->db->where('nu.user_status', 'approved');
				$this->db->where('nu.is_deleted', 0);
				if (trim($orderBy) == '') $this->db->order_by('datestamp', 'desc');
				if (trim($limit) != '' && is_numeric($limit))
				{
						if (trim($start) != '' && is_numeric($start)) $this->db->limit($limit, $start);
						else  $this->db->limit($limit);
				}
				$membersQuery = $this->db->get();
				$members = array();
				if ($membersQuery->num_rows() > 0)
				{
						foreach ($membersQuery->result_array() as $membersRow)
						{
								$members[$membersRow['user_id']]['username'] = $membersRow['username'];
								$members[$membersRow['user_id']]['user_avatar'] = $this->usermodel->getAvatar($membersRow['user_id']);
						}
				}
				return $members;
		}
		function getMembersCount($networkId)
		{
				$this->db->select('nu.user_id, u.username');
				$this->db->from('network_users as nu');
				$this->db->where('nu.network_id', $networkId);
				$this->db->where('nu.user_status', 'approved');
				$this->db->where('nu.is_deleted', 0);
				return $this->db->count_all_results();
		}
		function getUserNetwork($userId = '', $networkType = '', $orderBy = 'date_joined desc', $start = '', $limit = '')
		{
				if (trim($userId) == '') $userId = $this->session->userdata('user_id');
				$this->db->select('n.network_id, n.network_type, n.network_name, n.network_country, n.network_city, n.network_state, n.network_members');
				$this->db->from('network_users as nu');
				$this->db->join('networks as n', 'nu.network_id=n.network_id', 'INNER');
				$this->db->where('nu.user_status', 'approved');
				$this->db->where('nu.is_deleted', 0);
				$this->db->where('nu.user_id', $userId);
				$this->db->where('n.network_status', 'enabled');
				if (trim($networkType) != '') $this->db->where('n.network_type', $networkType);
				if (trim($orderBy) != '') $this->db->order_by($orderBy);
				if (trim($limit) != '' && is_numeric($limit))
				{
						if (trim($start) != '' && is_numeric($start)) $this->db->limit($limit, $start);
						else  $this->db->limit($limit);
				}
				$networksQuery = $this->db->get();
				$networks = array();
				if ($networksQuery->num_rows() > 0)
				{
						foreach ($networksQuery->result_array() as $networksRow)
						{
								$networks[$networksRow['network_id']] = $networksRow;
						}
				}
				return $networks;
		}
		function joinNetwork($joinConfig)
		{
				if (!isset($joinConfig['network_id']) || (isset($joinConfig['network_id']) && !is_numeric($joinConfig['network_id']))) return false;
				if (!isset($joinConfig['user_id']) || (isset($joinConfig['user_id']) && trim($joinConfig['user_id']) == '')) $joinConfig['user_id'] = $this->session->userdata('user_id');
				$this->db->insert('network_users', $joinConfig);
				if ($this->db->affected_rows() == 1)
				{
						$networkUserId = $this->db->insert_id();
						$this->db->set('network_members', 'network_members+1', false);
						$this->db->where('network_id', $joinConfig['network_id']);
						$this->db->update('networks');
				}
				else  return false;
		}
		function leaveNetwork($networkId, $userId = '')
		{
				if (trim($userId) == '') $userId = $this->session->userdata('user_id');
				$this->db->where('network_id', $networkId);
				$this->db->where('user_id', $userId);
				$this->db->limit(1);
				$this->db->delete('network_users');
				$this->db->set('network_members', 'network_members-1', false);
				$this->db->where('network_id', $networkId);
				$this->db->update('networks');
		}
		function isInvitationSent($networkId, $userId = '')
		{
				if (trim($userId) == '') $userId = $this->session->userdata('user_id');
				$this->db->select('network_user_id');
				$this->db->from('network_users');
				$this->db->where('network_id', $networkId);
				$this->db->where('user_id', $userId);
				$this->db->limit(1);
				$isInvitationSentQuery = $this->db->get();
				if ($isInvitationSentQuery->num_rows() > 0)
				{
						$isInvitationSentRow = $isInvitationSentQuery->result_array();
						return $isInvitationSentRow[0]['network_user_id'];
				}
				else  return false;
		}
		function updateInvitation($invitationId, $email)
		{
				$this->db->where('network_user_id', $invitationId);
				$this->db->limit(1);
				$this->db->update('network_users', array('user_email' => $email));
		}
		function activateUser($networkId, $confirmKey)
		{
				$this->db->where('network_id', $networkId);
				$this->db->where('confirm_key', $confirmKey);
				$this->db->limit(1);
				$this->db->update('network_users', array('user_status' => 'approved'));
		}
		function createNetwork($newNetwork)
		{
				if (!isset($newNetwork['user_id']) || (isset($newNetwork['user_id']) && trim($newNetwork['user_id']) == '')) $newNetwork['user_id'] = $this->session->userdata('user_id');
				$this->db->set($newNetwork);
				$this->db->set('datestamp', 'NOW()', false);
				$this->db->insert('networks', $newNetwork);
				if ($this->db->affected_rows() == 1) return $this->db->insert_id();
				else  return false;
		}
		#***************************************************************************
		#Method			: updateNetworkStatus
		#Description	: updates network status
		#Author
		#***************************************************************************
		function updateNetworkStatus($block_id, $status)
		{
				$networkStatus = array('network_status' => $status);
				$this->db->where('network_id', $block_id);
				$this->db->update('networks', $networkStatus);
		}
		function searchNetworks($suggest = '', $type = '', $status = '', $domain = '', $orderBy = '', $start = '', $limit = '')
		{
				$this->db->from('networks');
				$this->db->join('country', 'networks.network_country = country.country_id', 'inner');
				$this->db->join('state_province', 'networks.network_state = state_province.state_id', 'left');
				$this->db->like('network_name', $suggest);
				if ($type != '') $this->db->where('network_type', $type);
				if ($status != '') $this->db->where('network_status', $status);
				if ($domain != '') $this->db->like('network_email', $domain);
				if (trim($orderBy) != '') $this->db->order_by($orderBy);
				if (trim($limit) != '' && is_numeric($limit))
				{
						if (trim($start) != '' && is_numeric($start)) $this->db->limit($limit, $start);
						else  $this->db->limit($limit);
				}
				$resultQuery = $this->db->get();
				//echo $this->db->last_query();
				$result = array();
				if ($resultQuery->num_rows() > 0)
				{
						foreach ($resultQuery->result_array() as $resultRow)
						{
								$result[$resultRow['network_id']] = $resultRow;
						}
				}
				return $result;
		}
		function updateNetworkDetails($networkId, $networkDetails)
		{
				if (!isset($networkDetails['user_id']) || (isset($networkDetails['user_id']) && trim($networkDetails['user_id']) == '')) $networkDetails['user_id'] = $this->session->userdata('user_id');
				$this->db->set($networkDetails);
				$this->db->set('datestamp', 'NOW()', false);
				$this->db->where('network_id', $networkId);
				$this->db->update('networks');
				if ($this->db->affected_rows() == 1) return $this->db->insert_id();
				else  return false;
		}
		function updateNetworkByAdmin($networkId, $networkDetails)
		{
				$this->db->set($networkDetails);
				$this->db->set('datestamp', 'NOW()', false);
				$this->db->where('network_id', $networkId);
				$this->db->update('networks');
				if ($this->db->affected_rows() == 1) return $this->db->affected_rows();
				else  return false;
		}
		function isValidConfirmKey($networkId, $confirmKey, $userId = '')
		{
				if (trim($userId) == '') $userId = $this->session->userdata('user_id');
				$this->db->select('network_id');
				$this->db->from('networks');
				$this->db->where('network_id', $networkId);
				$this->db->where('user_id', $userId);
				$this->db->where('confirmation_key', $confirmKey);
				$this->db->where('network_status', 'nonconfirmed');
				$this->db->limit(1);
				$isExistQuery = $this->db->get();
				if ($isExistQuery->num_rows() > 0)
				{
						$isExistRow = $isExistQuery->result_array();
						return $isExistRow[0]['network_id'];
				}
				else  return false;
		}
}
?>