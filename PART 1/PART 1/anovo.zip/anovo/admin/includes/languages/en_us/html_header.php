<?php
if (array_search($CFG['html']['current_script_name'], $CFG['admin']['light_window_pages']) and !$CFG['remote_client']['is_ie'])
{
		echo '<?xml version="1.0"?>' . "\n";
}
require_once ($CFG['site']['project_path'] . 'common/classes/class_HeaderHandler.lib.php');
require_once ($CFG['site']['project_path'] . 'common/languages/' . $CFG['lang']['default'] . '/lists_array/paging_list_array.inc.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html lang="en-US" dir="ltr" xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="application/xhtml+xml; charset=UTF-8" />
<meta http-equiv="content-Language" content="en-US" />
<meta name="keywords" content="<?php echo $CFG['html']['meta']['keywords']; ?>" />
<meta name="description" content="<?php echo $CFG['html']['meta']['description']; ?>" />
<?php
if ($CFG['html']['meta']['MSSmartTagsPreventParsing'])
{
?>
<!-- Disable MSSmartTags -->
<meta name="MSSmartTagsPreventParsing" content="true" />
<?php
}
if (!$CFG['html']['meta']['imagetoolbar'])
{
?>
<!-- Disable IE6 image toolbar -->
<meta http-equiv="imagetoolbar" content="no" />
<?php
}
class HtmlHeaderFormHandler extends HeaderHandler
{
}
$headerfrm = new HtmlHeaderFormHandler();
$headerfrm->setDBObject($db);
$headerfrm->makeGlobalize($CFG, $LANG);
$headerfrm->setFormField('srch', '');
$headerfrm->setFormField('forum_id', '');
$headerfrm->setFormField('topic_id', '');
$headerfrm->setFormField('pg', '');
$headerfrm->sanitizeFormInputs($_REQUEST);

?>
<link rel="stylesheet" type="text/css" href="<?php echo $CFG['site']['url']; ?>admin/css/screen_admin.css" media="screen" />
<link href="<?php echo $CFG['site']['url']; ?>js/lightwindow/css/lightWindow.css" rel="stylesheet" type="text/css" />
<?php
if (chkToolTipAllowed())
{
?>
<link href="<?php echo $CFG['site']['url']; ?>css/tooltips.css" rel="stylesheet" type="text/css" />
<?php
}
?>
<link rel="stylesheet" type="text/css" href="<?php echo $CFG['site']['url']; ?>css/print.css" media="print" />
<link rel="shortcut icon" href="<?php echo $CFG['site']['url']; ?>favicon.ico" type="image/x-icon" />
<?php






?>
<!-- for link bar -->
<link rel="Home"     href="<?php echo URL($CFG['site']['url']); ?>" title="Home page" />
<link rel="Index"    href="<?php echo URL($CFG['site']['url']); ?>" title="Index" />
<link rel="search"   href="<?php echo '#'; ?>" title="Search this site" />
<link rel="contents" href="<?php echo '#'; ?>" title="Site map" />
<link rel="copyright" href="<?php echo URL($CFG['site']['url'] . 'copyright.php'); ?>" title="Copyright information" />
<link rel="author"   href="<?php echo URL($CFG['site']['url'] . 'author.php'); ?>" title="Author information" />
<script type="text/javascript" src="<?php echo $CFG['site']['url']; ?>js/lib/prototype.js"></script>
<script type="text/javascript" src="<?php echo $CFG['site']['url']; ?>js/scriptaculous/scriptaculous.js"></script>
<script type="text/javascript" src="<?php echo $CFG['site']['url']; ?>js/lightwindow/javascript/prototype.js"></script>
<script type="text/javascript" src="<?php echo $CFG['site']['url']; ?>js/script.js"></script>
<?php
if (chkToolTipAllowed())
{
?>
<script type="text/javascript"	src="<?php echo $CFG['site']['url']; ?>js/tooltips.js"></script>
<?php
}
?>
<script type="text/javascript">
	var SITE_URL = '<?php echo $CFG['site']['url']; ?>';
	var loadingSrc = '<img src="<?php echo $CFG['site']['url'] . 'images/loader.gif'; ?>" alt="loading..."/>';
	var processingSrc = '<img src="<?php echo $CFG['site']['url'] . 'images/processing.gif'; ?>" alt="loading..."/>';
</script>
<script type="text/javascript" src="<?php echo $CFG['site']['url']; ?>js/lightwindow/javascript/effects.js"></script>
<script type="text/javascript" src="<?php echo $CFG['site']['url']; ?>js/lightwindow/javascript/lightWindow.js"></script>
<script type="text/javascript" src="<?php echo $CFG['site']['url']; ?>js/browsersniff.js"></script>
<title><?php echo $CFG['site']['title']; ?></title>
</head>
<body>
<div id="selAlertbox" class="clsPopupConfirmation" style="display:none;position:absolute;">
  <p id="selAlertMessage"></p>
  <form name="formAlertBox" id="formAlertBox">
    <input type="button" class="clsSubmitButton" name="selAlertOkButton" id="selAlertOkButton" value="Ok" onClick="return hideAllBlocks();" />
  </form>
</div>
<!-- for ajax window -->
<div id="selAjaxWindow" class="clsVideoAudioUploadPopup" style="display:none;position:absolute;">
	<form name="frmAjaxWindow" id="frmAjaxWindow">
	</form>
	<div id="selAjaxWindowInnerDiv"></div>
</div>
<div id="hideScreen" style="z-index: 100; display: none;" class="VeilStyle1c">&nbsp;</div>
<div id="<?php echo $CFG['html']['page_id']; ?>" class="clsBodyContent">
<div id="selPageBody">

<!-- Accessibility Links -->
<div id="top">
  <ul>
    <li><a href="#main">Skip to main content</a></li>
    <li><a href="#selSubHeader">Skip to Navigation Links</a></li>
    <li><a href="#footer">Skip to Footer</a></li>
  </ul>
</div>
<!-- Header -->
<div id="header">
  <h1><a href="index.php" title="Browse to homepage"><?php echo $CFG['site']['name']; ?></a></h1>
  <?php

if ($CFG['lang']['is_multi_lang_support'])
{
?>
  <div id="selLang" lang="en">
    <h2>Choose Language</h2>
    <form name="form_lang" id="selFormLang" method="get" action="<?php echo URL($_SERVER['SCRIPT_NAME']); ?>" autocomplete="off">
      <select class="clsListBox" name="lang" id="lang" tabindex="1">
        <?php
		foreach ($CFG['lang']['available_languages'] as $lang_code => $lang_name)
		{
?>
        <option value="<?php echo $lang_code; ?>"<?php echo ($lang_code == $CFG['lang']['default']) ? ' selected="selected"' : ''; ?>><?php echo $lang_name; ?></option>
        <?php
		}
?>
      </select>
      <input type="submit" class="clsSubmitButton" name="change_lang" id="change_lang" tabindex="1" value="Change" title="Change Language" />
    </form>
  </div>
  <?php
}
$CFG['html']['stylesheet']['screen']['is_style_support'] = false;
if ($CFG['html']['stylesheet']['screen']['is_style_support'])
{
		$REQ_URI = $_SERVER['REQUEST_URI'];
		foreach ($CFG['html']['stylesheet']['screen']['available_stylesheets'] as $style_name => $style_title)
		{
				$REQ_URI = str_replace('?style=' . $style_title, '', $REQ_URI);
				$REQ_URI = str_replace('&style=' . $style_title, '', $REQ_URI);
		}
		$REQ_URI .= (strpos($REQ_URI, '?')) ? '&style=' : '?style=';
?>
<div class="clsAlternateStyle"> <div id="selStyle" class="clsAlternateStyleSheet" lang="en">
    <h2>Choose Style</h2>
<div class="clsAlternateSheet"><ul>
<li>Change theme now:</li>
	<li id="themeDefault" class="<?php echo $Default; ?>"><a href="<?php echo $REQ_URI . 'Default'; ?>"><img src="<?php echo $CFG['site']['url'] . 'images/bg-defaulttheme.png'; ?>" /></a></li>
	<li id="themeWhite" class="<?php echo $White; ?>"><a href="<?php echo $REQ_URI . 'White'; ?>"><img src="<?php echo $CFG['site']['url'] . 'images/bg-whitetheme.png'; ?>" /></a></li>
</ul></div>
</div></div>
  <?php
}
?>
</div>
<div>
<?php
$headerfrm->showConfigFilePages();
$headerfrm->showConfigVideoPlayerPages();
$headerfrm->showAnswersPages();
$headerfrm->showForumsPages();
$headerfrm->showBlogsPages();
$headerfrm->showMemberPages();
$headerfrm->showBannerPages();
$headerfrm->showNewsletterPages();
$headerfrm->showAvatarPages();
$headerfrm->showStaticPages();
?>
</div>
<!--<div id="sideBar">
  <!-- Side Bar1 -->
  <!--<div class="sideBar1">
    <!--<div id="selAdminNavLinks">
      <h3><span class="blcsidebartitle"> <span class="brcsidebartitle"> <span class="tlcsidebartitle"> <span class="trcsidebartitle">Admin Navigation Links</span></span></span></span></h3>
		<li class="questionCategory"><a href="questionCategory.php">Manage Categories</a></li>
        <li class="manageAnswers"><a href="manageAnswers.php">Manage Answers</a></li>
		<li class="forums"><a href="forums.php">Manage Forums</a></li>
		<li class="manageBlogs"><a href="manageBlogs.php">Manage Blogs</a>
	 		<ul>
	 			<li class="manageBlogCategory"><a href="manageBlogCategory.php">manage Blog Category</a></li>
	 		</ul>
	 	</li>
        <li class="ManageAnswersMembers"><a href="ManageAnswersMembers.php">Manage Answers Members</a></li>
		<li class="manageBanner"><a href="manageBanner.php">Manage Banner</a></li>
		<li class="addNewsLetter"><a href="addNewsLetter.php">News Leter</a></li>
		<li class="logout"><a href="../logout.php">Logout</a></li>
		<li class="members"><a href="../members/">Members</a></li>
      </ul>
    </div>
  </div>
</div>-->
<!-- Main -->
<div id="main">
<!-- Header ends -->
