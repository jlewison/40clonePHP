<?php

class IndexHandler extends FormHandler
{
		public function getUserOptions()
		{
				$user_options = array('recent_questions' => 'yes', 'popular_questions' => 'yes', 'best_of_answer' => 'yes', 'questions_with_videos' => 'yes', 'questions_with_audios' => 'yes', 'recent_forums' => 'yes', 'forums_with_most_replies' => 'yes', 'recent_blogs' => 'yes', 'blogs_with_most_comment' => 'yes', 'top_analyst' => 'yes', 'featured_analyst' => 'yes');
				if ($uid = $this->CFG['user']['user_id'])
				{
						$sql = 'SELECT index_block FROM ' . $this->CFG['db']['tbl']['users_ans_log'] . ' WHERE user_id=' . $this->dbObj->Param($uid);
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($uid));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
						if ($rs->PO_RecordCount())
						{
								$row = $rs->FetchRow();
								if ($row['index_block'])
								{
										$index_blocks = unserialize($row['index_block']);
										foreach ($index_blocks as $block => $value)
										{
												$user_options[$block] = $value;
										}
								}
						}
				}
				return $user_options;
		}
}
$indexhandler = new IndexHandler();
$indexhandler->setDBObject($db);
$indexhandler->setCfgLangGlobal($CFG, $LANG);
$indexhandler->setPageBlockNames(array('msg_form_error', 'form_recent_questions', 'form_popular_questions', 'form_recent_forums', 'form_recent_blogs', 'form_best_answer', 'form_featured_analyst', 'form_top_analyst', 'form_video_questions', 'form_audio_questions', 'form_forum_replies', 'form_blog_comments'));
$indexhandler->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$indexhandler->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$indexhandler->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$indexhandler->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$indexhandler->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$indexhandler->setFormField('search_question', '');
$user_options = $indexhandler->getUserOptions();
$indexhandler->setAllPageBlocksHide();
if ($indexhandler->isShowIndexBlock($CFG['admin']['index']['recent_questions'], $user_options['recent_questions'])) $indexhandler->setPageBlockShow('form_recent_questions');
if ($indexhandler->isShowIndexBlock($CFG['admin']['index']['popular_questions'], $user_options['popular_questions'])) $indexhandler->setPageBlockShow('form_popular_questions');
if (chkVideoAllowed('question') and $indexhandler->isShowIndexBlock($CFG['admin']['index']['questions_with_videos'], $user_options['questions_with_videos'])) $indexhandler->setPageBlockShow('form_video_questions');
if (chkAudioAllowed('question') and $indexhandler->isShowIndexBlock($CFG['admin']['index']['questions_with_audios'], $user_options['questions_with_audios'])) $indexhandler->setPageBlockShow('form_audio_questions');
if ($indexhandler->isShowIndexBlock($CFG['admin']['index']['best_of_answer'], $user_options['best_of_answer'])) $indexhandler->setPageBlockShow('form_best_answer');
if (chkAllowedModule(array('forums')) and $indexhandler->isShowIndexBlock($CFG['admin']['index']['recent_forums'], $user_options['recent_forums'])) $indexhandler->setPageBlockShow('form_recent_forums');
if (chkAllowedModule(array('forums')) and $indexhandler->isShowIndexBlock($CFG['admin']['index']['forums_with_most_replies'], $user_options['forums_with_most_replies'])) $indexhandler->setPageBlockShow('form_forum_replies');
if (chkAllowedModule(array('blog')) and $indexhandler->isShowIndexBlock($CFG['admin']['index']['recent_blogs'], $user_options['recent_blogs'])) $indexhandler->setPageBlockShow('form_recent_blogs');
if (chkAllowedModule(array('blog')) and $indexhandler->isShowIndexBlock($CFG['admin']['index']['blogs_with_most_comment'], $user_options['blogs_with_most_comment'])) $indexhandler->setPageBlockShow('form_blog_comments');
if ($indexhandler->isShowIndexBlock($CFG['admin']['index']['featured_analyst'], $user_options['featured_analyst'])) $indexhandler->setPageBlockShow('form_featured_analyst');
if ($indexhandler->isShowIndexBlock($CFG['admin']['index']['top_analyst'], $user_options['top_analyst'])) $indexhandler->setPageBlockShow('form_top_analyst');
$Widget = new Widget();
$CFG['mods']['is_include_only']['non_html_header_files'] = false;
$CFG['mods']['is_include_only']['html_header'] = true;
require ($CFG['site']['project_path'] . 'common/application_top.inc.php');


?>
<div id="selIndex">
  <?php
if ($indexhandler->isShowPageBlock('msg_form_error'))
{
?>
  <div id="selMsgError">
    <p><?php echo $LANG['msg_error_sorry']; ?> <?php echo $indexhandler->getCommonErrorMsg(); ?></p>
  </div>
  <?php
}
if ($indexhandler->isShowPageBlock('form_best_answer'))
{
?>
  <div id="selWidgetBlogs">
    <?php
		$Widget->widgetAutoScrolling('index', $CFG['admin']['index']['best_ans_questions_count']);
?>
  </div>
  <?php
}
else
{
?>
<script type="text/javascript" language="javascript" src="<?php echo $indexhandler->CFG['site']['url']; ?>js/mootools.ajax.js"></script>
<?php
}
if ($indexhandler->isShowPageBlock('form_recent_questions') || $indexhandler->isShowPageBlock('form_popular_questions') || $indexhandler->isShowPageBlock('form_video_questions') || $indexhandler->isShowPageBlock('form_audio_questions'))
{
		$recentQStyle = $popularQStyle = $videoQStyle = $audioQStyle = '';
?>
<div class="clsQuestionsLink"><ul>
	<?php if ($indexhandler->isShowPageBlock('form_recent_questions'))
		{
				$popularQStyle = $videoQStyle = $audioQStyle = 'style=display:none;';
?>
	<li id="selRecentQuestionsLI" class="clsLeftActiveQuestionsLink"><span id="selRecentQuestionsSPAN" class="clsRightActiveQuestionsLink"><a id="selRecentQuestionsA" class="clsMiddleActiveQuestionsLink" href="<?php echo $_SERVER['REQUEST_URI']; ?>" onclick="hideBlocks('selPopularQuestions','selVideoQuestions','selAudioQuestions');showBlocks('selRecentQuestions'); toggleNavBar(); return false;"><?php echo $LANG['common_recent_question_title']; ?></a></span></li>
	<?php } ?>
	<?php if ($indexhandler->isShowPageBlock('form_popular_questions'))
		{
				$videoQStyle = $audioQStyle = 'style=display:none;';
?>
		<?php if (!$popularQStyle)
				{ ?>
		<li id="selPopularQuestionsLI" class="clsLeftActiveQuestionsLink"><span id="selPopularQuestionsSPAN" class="clsRightActiveQuestionsLink"><a id="selPopularQuestionsA" class="clsMiddleActiveQuestionsLink" href="<?php echo $_SERVER['REQUEST_URI']; ?>" onclick="hideBlocks('selRecentQuestions','selVideoQuestions','selAudioQuestions');showBlocks('selPopularQuestions'); toggleNavBar(); return false;"><?php echo $LANG['common_popular_question_title']; ?></a></span></li>
		<?php }
				else
				{ ?>
		<li id="selPopularQuestionsLI" class="clsLeftInActiveQuestionsLink"><span id="selPopularQuestionsSPAN" class="clsRightInActiveQuestionsLink"><a id="selPopularQuestionsA" class="clsMiddleInActiveQuestionsLink" href="<?php echo $_SERVER['REQUEST_URI']; ?>" onclick="hideBlocks('selRecentQuestions','selVideoQuestions','selAudioQuestions');showBlocks('selPopularQuestions'); toggleNavBar(); return false;"><?php echo $LANG['common_popular_question_title']; ?></a></span></li>
		<?php } ?>
	<?php } ?>
	<?php if ($indexhandler->isShowPageBlock('form_video_questions'))
		{
				$audioQStyle = 'style=display:none;';
?>
		<?php if (!$videoQStyle)
				{ ?>
		<li id="selVideoQuestionsLI" class="clsLeftActiveQuestionsLink"><span id="selVideoQuestionsSPAN" class="clsRightActiveQuestionsLink"><a id="selVideoQuestionsA" class="clsMiddleActiveQuestionsLink" href="<?php echo $_SERVER['REQUEST_URI']; ?>" onclick="hideBlocks('selRecentQuestions','selPopularQuestions','selAudioQuestions');showBlocks('selVideoQuestions'); toggleNavBar(); return false;"><?php echo $LANG['common_video_question_title']; ?></a></span></li>
		<?php }
				else
				{ ?>
		<li id="selVideoQuestionsLI" class="clsLeftInActiveQuestionsLink"><span id="selVideoQuestionsSPAN" class="clsRightInActiveQuestionsLink"><a id="selVideoQuestionsA" class="clsMiddleInActiveQuestionsLink" href="<?php echo $_SERVER['REQUEST_URI']; ?>" onclick="hideBlocks('selRecentQuestions','selPopularQuestions','selAudioQuestions');showBlocks('selVideoQuestions'); toggleNavBar(); return false;"><?php echo $LANG['common_video_question_title']; ?></a></span></li>
		<?php } ?>
	<?php } ?>
	<?php if ($indexhandler->isShowPageBlock('form_audio_questions'))
		{ ?>
		<?php if (!$videoQStyle)
				{ ?>
		<li id="selAudioQuestionsLI" class="clsLeftActiveQuestionsLink"><span id="selAudioQuestionsSPAN" class="clsRightActiveQuestionsLink"><a id="selAudioQuestionsA" class="clsMiddleActiveQuestionsLink" href="<?php echo $_SERVER['REQUEST_URI']; ?>" onclick="hideBlocks('selRecentQuestions','selPopularQuestions','selVideoQuestions');showBlocks('selAudioQuestions'); toggleNavBar(); return false;"><?php echo $LANG['common_audio_question_title']; ?></a></span></li>
		<?php }
				else
				{ ?>
		<li id="selAudioQuestionsLI" class="clsLeftInActiveQuestionsLink"><span id="selAudioQuestionsSPAN" class="clsRightInActiveQuestionsLink"><a id="selAudioQuestionsA" class="clsMiddleInActiveQuestionsLink" href="<?php echo $_SERVER['REQUEST_URI']; ?>" onclick="hideBlocks('selRecentQuestions','selPopularQuestions','selVideoQuestions');showBlocks('selAudioQuestions'); toggleNavBar(); return false;"><?php echo $LANG['common_audio_question_title']; ?></a></span></li>
		<?php } ?>
	<?php } ?>
</ul></div>
<?php
}
if ($indexhandler->isShowPageBlock('form_recent_questions'))
{
?>
  <div id="selRecentQuestions" class="clsCommonIndexSection" <?php echo $recentQStyle; ?>>
    <?php
		$Widget->displayRecentQuestions($CFG['admin']['index']['recent_questions_count']);
?>
  </div>
  <?php
}
if ($indexhandler->isShowPageBlock('form_popular_questions'))
{
?>
  <div id="selPopularQuestions" class="clsCommonIndexSection"  <?php echo $popularQStyle; ?>>
    <?php
		$Widget->displayPopularQuestions($CFG['admin']['index']['popular_questions_count']);
?>
  </div>
  <?php
}
if ($indexhandler->isShowPageBlock('form_video_questions'))
{
?>
  <div id="selVideoQuestions" class="clsCommonIndexSection"  <?php echo $videoQStyle; ?>>
    <?php
		$Widget->displayVideoQuestions($CFG['admin']['index']['video_questions_count']);
?>
  </div>
  <?php
}
if ($indexhandler->isShowPageBlock('form_audio_questions'))
{
?>
  <div id="selAudioQuestions" class="clsCommonIndexSection"  <?php echo $audioQStyle; ?>>
    <?php
		$Widget->displayAudioQuestions($CFG['admin']['index']['audio_questions_count']);
?>
  </div>
  <?php
}
if ($indexhandler->isShowPageBlock('form_recent_forums') || $indexhandler->isShowPageBlock('form_forum_replies'))
{
		$recentFStyle = $replyFStyle = '';
?>
<div class="clsQuestionsLink"><ul>
	<?php if ($indexhandler->isShowPageBlock('form_recent_forums'))
		{
				$replyFStyle = 'style=display:none;';
?>
	<li id="selRecentForumsLI" class="clsLeftActiveQuestionsLink"><span id="selRecentForumsSPAN" class="clsRightActiveQuestionsLink"><a id="selRecentForumsA" class="clsMiddleActiveQuestionsLink" href="<?php echo $_SERVER['REQUEST_URI']; ?>" onclick="hideBlocks('selMostForumReplies');showBlocks('selRecentForums'); return false;"><?php echo $LANG['common_recent_forum_title']; ?></a></span></li>
	<?php } ?>
	<?php if ($indexhandler->isShowPageBlock('form_forum_replies'))
		{ ?>
		<?php if (!$replyFStyle)
				{ ?>
		<li id="selMostForumRepliesLI" class="clsLeftActiveQuestionsLink"><span id="selMostForumRepliesSPAN" class="clsRightActiveQuestionsLink"><a id="selMostForumRepliesA" class="clsMiddleActiveQuestionsLink" href="<?php echo $_SERVER['REQUEST_URI']; ?>" onclick="hideBlocks('selRecentForums');showBlocks('selMostForumReplies'); return false;"><?php echo $LANG['common_most_replied_forum_title']; ?></a></span></li>
		<?php }
				else
				{ ?>
		<li id="selMostForumRepliesLI" class="clsLeftInActiveQuestionsLink"><span id="selMostForumRepliesSPAN" class="clsRightInActiveQuestionsLink"><a id="selMostForumRepliesA" class="clsMiddleInActiveQuestionsLink" href="<?php echo $_SERVER['REQUEST_URI']; ?>" onclick="hideBlocks('selRecentForums');showBlocks('selMostForumReplies'); return false;"><?php echo $LANG['common_most_replied_forum_title']; ?></a></span></li>
		<?php } ?>
	<?php } ?>
</ul></div>
<?php
}
if ($indexhandler->isShowPageBlock('form_recent_forums'))
{
?>
  <div id="selRecentForums" class="clsCommonIndexSection" <?php echo $recentFStyle; ?>>
    <?php
		$Widget->displayRecentForums($CFG['admin']['index']['recent_forums_count']);
?>
  </div>
  <?php
}
if ($indexhandler->isShowPageBlock('form_forum_replies'))
{
?>
  <div id="selMostForumReplies" class="clsCommonIndexSection" <?php echo $replyFStyle; ?>>
    <?php
		$Widget->displayMostForumReplies($CFG['admin']['index']['most_forums_replies_count']);
?>
  </div>
  <?php
}
if ($indexhandler->isShowPageBlock('form_recent_blogs') || $indexhandler->isShowPageBlock('form_blog_comments'))
{
		$recentBStyle = $commentBStyle = '';
?>
<div class="clsQuestionsLink"><ul>
	<?php if ($indexhandler->isShowPageBlock('form_recent_blogs'))
		{
				$commentBStyle = 'style=display:none;';
?>
	<li id="selRecentBlogsLI" class="clsLeftActiveQuestionsLink"><span id="selRecentBlogsSPAN" class="clsRightActiveQuestionsLink"><a id="selRecentBlogsA" class="clsMiddleActiveQuestionsLink" href="<?php echo $_SERVER['REQUEST_URI']; ?>" onclick="hideBlocks('selMostBlogComments');showBlocks('selRecentBlogs'); return false;"><?php echo $LANG['common_recent_blog_title']; ?></a></span></li>
	<?php } ?>
	<?php if ($indexhandler->isShowPageBlock('form_blog_comments'))
		{ ?>
		<?php if (!$commentBStyle)
				{ ?>
		<li id="selMostBlogCommentsLI" class="clsLeftActiveQuestionsLink"><span id="selMostBlogCommentsSPAN" class="clsRightActiveQuestionsLink"><a id="selMostBlogCommentsA" class="clsMiddleActiveQuestionsLink" href="<?php echo $_SERVER['REQUEST_URI']; ?>" onclick="hideBlocks('selRecentBlogs');showBlocks('selMostBlogComments'); return false;"><?php echo $LANG['common_most_commented_blog_title']; ?></a></span></li>
		<?php }
				else
				{ ?>
		<li id="selMostBlogCommentsLI" class="clsLeftInActiveQuestionsLink"><span id="selMostBlogCommentsSPAN" class="clsRightInActiveQuestionsLink"><a id="selMostBlogCommentsA" class="clsMiddleInActiveQuestionsLink" href="<?php echo $_SERVER['REQUEST_URI']; ?>" onclick="hideBlocks('selRecentBlogs');showBlocks('selMostBlogComments'); return false;"><?php echo $LANG['common_most_commented_blog_title']; ?></a></span></li>
		<?php } ?>
	<?php } ?>
</ul></div>
<?php
}
if ($indexhandler->isShowPageBlock('form_recent_blogs'))
{
?>
  <div id="selRecentBlogs" class="clsCommonIndexSection" <?php echo $recentBStyle; ?>>
    <?php
		$Widget->displayRecentBlogs($CFG['admin']['index']['recent_blogs_count']);
?>
  </div>
  <?php
}
if ($indexhandler->isShowPageBlock('form_blog_comments'))
{
?>
  <div id="selMostBlogComments" class="clsCommonIndexSection" <?php echo $commentBStyle; ?>>
    <?php
		$Widget->displayMostBlogComments($CFG['admin']['index']['most_blogs_comments_count']);
?>
  </div>
  <?php
}
if ($indexhandler->isShowPageBlock('form_featured_analyst') || $indexhandler->isShowPageBlock('form_top_analyst'))
{
		$featuredBStyle = $topBStyle = '';
?>
<div class="clsQuestionsLink"><ul>
	<?php if ($indexhandler->isShowPageBlock('form_featured_analyst'))
		{
				$topBStyle = 'style=display:none;';
?>
	<li id="selFeaturedAnalystsLI" class="clsLeftActiveQuestionsLink"><span id="selFeaturedAnalystsSPAN" class="clsRightActiveQuestionsLink"><a id="selFeaturedAnalystsA" class="clsMiddleActiveQuestionsLink" href="<?php echo $_SERVER['REQUEST_URI']; ?>" onclick="hideBlocks('selTopAnalysts');showBlocks('selFeaturedAnalysts');toggleNavBar(); return false;"><?php echo $LANG['common_featured_analyst_title']; ?></a></span></li>
	<?php } ?>
	<?php if ($indexhandler->isShowPageBlock('form_top_analyst'))
		{ ?>
		<?php if (!$topBStyle)
				{ ?>
		<li id="selTopAnalystsLI" class="clsLeftActiveQuestionsLink"><span id="selTopAnalystsSPAN" class="clsRightActiveQuestionsLink"><a id="selTopAnalystsA" class="clsMiddleActiveQuestionsLink" href="<?php echo $_SERVER['REQUEST_URI']; ?>" onclick="hideBlocks('selFeaturedAnalysts');showBlocks('selTopAnalysts');toggleNavBar(); return false;"><?php echo $LANG['common_top_analyst_title']; ?></a></span></li>
		<?php }
				else
				{ ?>
		<li id="selTopAnalystsLI" class="clsLeftInActiveQuestionsLink"><span id="selTopAnalystsSPAN" class="clsRightInActiveQuestionsLink"><a id="selTopAnalystsA" class="clsMiddleInActiveQuestionsLink" href="<?php echo $_SERVER['REQUEST_URI']; ?>" onclick="hideBlocks('selFeaturedAnalysts');showBlocks('selTopAnalysts');toggleNavBar(); return false;"><?php echo $LANG['common_top_analyst_title']; ?></a></span></li>
		<?php } ?>
	<?php } ?>
</ul></div>
<?php
}
if ($indexhandler->isShowPageBlock('form_featured_analyst'))
{
?>
  <div id="selFeaturedAnalysts" class="clsCommonIndexSection" <?php echo $featuredBStyle; ?>>
    <?php
		$Widget->displayFeaturedAnalyst($CFG['admin']['index']['featured_analyst_count']);
?>
  </div>
  <?php
}
if ($indexhandler->isShowPageBlock('form_top_analyst'))
{
?>
  <div id="selTopAnalysts" class="clsCommonIndexSection" <?php echo $topBStyle; ?>>
    <?php
		$Widget->displayTopAnalyst($CFG['admin']['index']['top_analyst_count']);
?>
  </div>
  <?php
}

?>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>
<script type="text/javascript" language="javascript">
var hideBlocks = function(){
	for(var i=0;i<arguments.length;i++){
		var objName = arguments[i];
		var liName = objName+'LI';
		var spanName = objName+'SPAN';
		var aName = objName+'A';
		if(obj = $(objName)){
			obj.style.display = 'none';
			$(liName).className="clsLeftInActiveQuestionsLink";
			$(spanName).className="clsRightInActiveQuestionsLink";
			$(aName).className="clsMiddleInActiveQuestionsLink";
		}
	}
}
var showBlocks = function(){
	for(var i=0;i<arguments.length;i++){
		var objName = arguments[i];
		var liName = objName+'LI';
		var spanName = objName+'SPAN';
		var aName = objName+'A';
		if(obj = $(objName)){
			obj.style.display = '';
			$(liName).className="clsLeftActiveQuestionsLink";
			$(spanName).className="clsRightActiveQuestionsLink";
			$(aName).className="clsMiddleActiveQuestionsLink";
		}
	}
}
function showUserInfoPopup(url, pars, divname){

	// reset timer
	resetUserInfoTimer();

	// close old layer
	if(divObj) divObj.style.display = 'none';

	// get new layer and show it
	divObj = document.getElementById(divname);
	if(divObj)
		divObj.style.display = '';

	// if content exists
	if ($(divname).innerHTML){
		return;
	}

	//if there is no content
	$(divname).innerHTML = processingSrc;
	url = url+'?'+pars;
	new Ajax(url, {
		method: 'get',
		update: $(divname)
	}).request();
}
function hideUserInfoPopup(divname){
	closeUserPopupAndTimer();
}
</script>
