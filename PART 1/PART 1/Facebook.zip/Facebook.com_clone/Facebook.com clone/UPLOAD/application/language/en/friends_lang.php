<?php

/**
* Language File for friends
*
*
* @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
* @license
* @since 12/31/2007
*/
	$lang['page_title']								= 'Friends';
	$lang['friends_remove_friend_success_msg']		= 'Friend has been successfully removed.';
	$lang['friends_remove_friend_error_msg']		= 'Friend has not been removed.';
	$lang['friends_add_friend_success_msg']			= 'Friend has been successfully added and pending for approval.';
	$lang['friends_add_friend_error_msg']			= 'Friend has not been added.';
	$lang['friends_invite_email_validate_msg']		= 'Please give your friends email ids to invite.';
	$lang['friends_invite_result_new']				= 'We sent invitation to the following new account.';
	$lang['friends_invite_result_registered']		= 'We sent invitation to the following registered account.';
	$lang['friends_invite_result_registered_sent']	= 'You have already sent invitation to the following registered accounts and we sent invitation to them again.';
	$lang['friends_invite_result_already_friend']	= 'The following registered accounts already linked as your friends.';
	$lang['friends_invite_result_self_account']		= 'The following email already linked with your account.';
	$lang['friends_invite_result_unregistered_sent']= 'You have already sent invitation to the following un registered account and we sent invitation to them again.';
	$lang['friends_invite_result_invalid']			= 'The following email accounts are invalid.';
	$lang['friends_label_recently_updated']			= 'Recently Updated';
	$lang['friends_label_recently_added']			= 'Recently Added';
	$lang['friends_label_online']					= 'Online';
	$lang['friends_label_friends_list']				= 'Friends List';
	$lang['friends_label_online_now']				= 'Online Now';
	$lang['friends_label_invite_friends']			= 'Invite Friends';
	$lang['friends_label_friends']					= 'Friend(s)';
	$lang['friends_label_view_friends']				= 'View Friends';
	$lang['friends_label_remove_friend']			= 'Remove Friend';
	$lang['friends_label_you']						= 'You';
	$lang['friends_label_have_no']					= 'have no';// example: you have no 'online' friends
	$lang['friends_remove_confirm_msg']				= 'Do you really want to remove this friend';
	$lang['friends_label_displaying']				= 'Displaying';
	$lang['friends_label_out_of']					= 'out of';//example: Displaying 2 out of 10
	$lang['friends_label_your']						= 'Your';
	$lang['friends_label_name']						= 'Name';
	$lang['friends_label_invite_send_to']			= 'To';
	$lang['friends_label_invite_send_from']			= 'From';
	$lang['friends_label_invite_send_message']		= 'Message';
	$lang['friends_label_send_message']				= 'Send Message';
	$lang['friends_invite_blocked_user']			= 'The following email account user(s) has blocked you';


?>