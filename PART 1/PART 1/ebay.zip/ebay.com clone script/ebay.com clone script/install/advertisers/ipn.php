<?php //00461
// Copyright Notice
// Web Site URL:  http://www.zeeways.com
// Script Owner eMail: mail@zeeways.com
// Date: April, 2007
// Script Name: Zeeways Auction Website PHP Script
// Copyright Details: This script is not free.  Do not Remove this Copy Right notice.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the site administrator.');exit(199);
?>
4+oV5FMfoEOSSJ79pHrTnIvECvXhX6GODgurm/96EsCNBxvrmptoZf8dHTjhw9sZqXP52abZGeyY
gCmFLTQfyzzdc8vGAEnx2/EzjOTXiLbg3MPCOltRON1rh5sYU2/3zdzIMw5b40XLU44pNK0wr1Ih
WD1mApUzULxCZnZfWNfMZOVxHqDo0lUbT9WoxBnROCDEcrkp6TJqSUKaboWNX+j+Lhz7U3CjaRCg
kUFiRRA+TyipND7eHPfr+9QcD0nCS/Sjhab+jffm4OEyONp3j4w2MY/4uwXaOle4RlyWsBfyQgmX
C+Zk5Lwt5Yhpxdh7xYIPk/P1VoyI6JAH4g2JThjNHUKTxr71zONMPdNVWS7bXj6tzlTHAA43wjf6
6YDTC1wWei0GObXaX8YM2SLB5vVGVBxfANfUycK1HTkr5Uqh7Iz/UYaBKrvIQyetSSa2A4a4561I
4v4FCQc8LPgeOs8/9dJyFlVcSZNvCJhhNr2J484gNnn/AxTQoNuqKRXQoA6WgEGJT2yZD62WvX3v
DQ2BQbskBduHE/7IWRlPDTWA4/HSQQzc2nXeBD7yuPLxdgl9Ce94NWoQZEYnt8omhpNe9FmS628/
le6HOtMq6St8Id6bm9MBkEbBdiXV/t6l4zKr5lkThEgeHqx48yOlzwtd1MK3PGxZbLYopTVwXSFB
+A2rzCDjI2J35RixB224+5/SNFgmJyrlirJAWeV78PpA7KfLFmuXrlb84Gf3zZUNQhLwpbsMxBvl
owYcRoP6fmvMsqguBGD4/HjJNccf/1niam27sx0eq5XFwSDBNo80/Rk2k7rRgGeJWDPf/5iReoHg
VQmsH5jCMLi+xMn6MYB/JJqoM4a96R8HER/CD9IqE5IzwemiMePRmqIXgdt4NVTZrCpSDVpb1f/h
gZWZiCuLeAiHkR5p80QElO4JPO3daEvQGcxwk6ffz3v2694r0e2TN5wGusog+627dpyMS5AYzEVA
hfYNyQ6tE52D9iuPHidHlfz7GkJQ6DBnzmURwjbIYKGHbKu2iUf80S6sh94O6xI4+MCHtRwJdWmQ
kx9kNXHucKesSPGSorTf4zRqjE7deRlbRCyFXIFqiXOUgDCaJPLGprDLsVoJd7UtG8/bTdI8ECMB
Myx6cw4w/cHYre0pXvkIkgF6wLF19iC+YjOuBCscgERBPNkJeqf+t0Q+9bjm31bYLJUlGCuvXcR8
Mo/0MnSN0IrQzwiMdOUB9Mi+9Nv/7tO5FTlhJJOMRjTNxrG4EDA6j0sksCto3JOWi0CN3OkHWSR7
3g711HeUX/aiXT+2Q2MSBNRwcdE2GsK3GUnMI7Mi3ruM1Z+6s2dkAdkqR4j4qj3HQymgz66J4Hga
3tNYh5PtFjwgkCCPJjKCSrUhLPyPOL8D3Dwz0NQRwJrfUEJTt+/eYccMugJPR87EjdFyUZGEExW1
h0YfHxFyNcbylPfCoU7JbKvPxsJQZxaAGSymdK2xiYsa6RX8PW==