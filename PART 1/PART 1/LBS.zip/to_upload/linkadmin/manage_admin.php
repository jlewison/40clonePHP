<?php include('restrict.php'); include('../settings.php'); require_once('../Connections/apound.php'); ?>
<?php
mysql_select_db($database_apound, $apound);
$query_manADM = "SELECT * FROM ig_admin";
$manADM = mysql_query($query_manADM, $apound) or die(mysql_error());
$row_manADM = mysql_fetch_assoc($manADM);
$totalRows_manADM = mysql_num_rows($manADM);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Manage Admins - Link Bid Script Admin Panel</title>
<link rel="shortcut icon" href="img/favicon.ico" />
<link rel="stylesheet" type="text/css" href="admin.css" />
</head>

<body>
<?php include('header_tpl.php'); ?>
<h2>Manage Admins</h2>
<table width="770"  border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
  <tr>
    <td width="770"><?php $x = getenv("HTTP_HOST").getenv("REQUEST_URI"); echo("<font color=white>$x</font>"); ?></td>
  </tr>
</table>
<table width="770"  border="0" align="center" cellpadding="3" cellspacing="1" bgcolor="#FFFFFF">
  <tr>
    <td width="760" valign="top">&nbsp;
      <?php $upd = $_GET[upd]; if($upd == 'Y') { echo("<div align='center'><font color='red'><b>Update ... DONE</b></font></div>"); } else { } ?>
      <table border="0" align="center" cellpadding="3" cellspacing="3">
        <tr class="style80">
          <td colspan="5"><a href="admin_add.php" class="style82">Add new admin</a> </td>
        </tr>
        <tr bgcolor="#FFFF00" class="style80">
          <td>id</td>
          <td>name</td>
          <td>email</td>
          <td>edit</td>
          <td>delete</td>
        </tr>
        <?php do { ?>
        <tr class="style76">
          <td><?php echo $row_manADM['adid']; ?></td>
          <td><?php echo $row_manADM['name']; ?></td>
          <td><?php echo $row_manADM['email']; ?></td>
          <td align="center"><a href="admin_edit.php?id=<?php echo $row_manADM['adid'];?>"><img src="img/ico-edit.gif" alt="Edit" /></a></td>
          <td align="center"><a href="admin_delete.php?id=<?php echo $row_manADM['adid'];?>"><img src="img/ico-delete.gif" alt="Delete" /></a></td>
        </tr>
        <tr bgcolor="#CCCCCC" class="style76">
          <td height="1" colspan="5"></td>
        </tr>
        <?php } while ($row_manADM = mysql_fetch_assoc($manADM)); ?>
      </table>
    </td>
  </tr>
</table>
<?php include('footer_tpl.php'); ?>
</body>
</html>
<?php
mysql_free_result($manADM);
?>
