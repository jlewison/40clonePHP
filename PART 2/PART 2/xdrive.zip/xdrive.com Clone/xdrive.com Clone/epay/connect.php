<?
@mysql_connect('localhost', 'user', 'password') or die('Cannot connect to MySQL server');
@mysql_select_db('database');
?>