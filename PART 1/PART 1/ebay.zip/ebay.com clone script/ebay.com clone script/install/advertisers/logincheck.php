<?php //00461
// Copyright Notice
// Web Site URL:  http://www.zeeways.com
// Script Owner eMail: mail@zeeways.com
// Date: April, 2007
// Script Name: Zeeways Auction Website PHP Script
// Copyright Details: This script is not free.  Do not Remove this Copy Right notice.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the site administrator.');exit(199);
?>
4+oV50QgNbikWgES8n3BU1790yyqNy3WznMM286iApRU0N/u8+ZCuesvOEuAXBgSP0/M2pgZ+q9+
P6rvyT7XfG7uHdledFgfE14XXOjoLrhdv4Jy+KnXgD99VwdNxgwPTepZ69ZCphfo40Z/EyhLwfIi
W1PgSNiKQKWr6dHs7o1alz9nmB/UyBRlDiTGI515hBLPeieJo36xlfisnt4/CkSgeO0H1DEzCYe5
aGl9fTqPAh/3Ggh2Q2wybgOq34npzoskINwscd0HWtDZX1h9otCYLM4UcwpnbO04YB7PADpSVdRx
YlHWmxAXaBQcy9I7ZM28Ez8/asuXfO96lq6i4EejnzfO+EBDAWEGHpGUo6Z5w+5lsaf+JyLlXbvE
eMMpQ1kEh5uTW3b0d3b519VNsCBccFeXUlXknaHb1Tsc61wb2oyYJVncYPpYI/jZOhbH9O2OU9Ly
oBKcuSm8Xwd3f7kzkVo446nsB5UzA5vyaVzpFb2tSKnsDsvS81g6x9nf6R3y0L73pI0Ow2JjlObV
UvEpffiW/hTTfAYl5/7YlXcNxsLNGBJbB7Yos6PtSBepHENTxDYUKQYtToxzgwDHoBeaDjFbTWTM
x5knLFD0yAEn1X6PMGDhW9lXFKZ1YWUGNc2WmWYKg8hUFuX8z14E88FJI0O+0mTWOPCby4m2yZwQ
J5oqb2qD69A+pyUVpA/ww5qGSDN9RRgB3nZRcIy7n3hqhWcR7qy3v0G3m5FrDYN+lmwbDpeWN/mQ
qjV4jo+rRNFBRB9JlVw+scFlegireKEDDZuXpI+FMtYDo0r6tIMVpnInMSb1wWuO78Z1Sq66jthB
H5a=