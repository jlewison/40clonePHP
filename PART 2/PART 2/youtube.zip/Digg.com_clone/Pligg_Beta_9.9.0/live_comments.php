<?php
// The source code packaged with this file is Free Software, Copyright (C) 2005 by
// Ricardo Galli <gallir at uib dot es>.
// It's licensed under the AFFERO GENERAL PUBLIC LICENSE unless stated otherwise.
// You can get copies of the licenses here:
// 		http://www.affero.org/oagpl.html
// AFFERO GENERAL PUBLIC LICENSE is also included in the file called "COPYING".

include_once('Smarty.class.php');
$main_smarty = new Smarty;

include('config.php');
include(mnminclude.'html1.php');
include(mnminclude.'ts.php');
include(mnminclude.'link.php');
include(mnminclude.'tags.php');
include(mnminclude.'user.php');
include(mnminclude.'comment.php');
include(mnminclude.'smartyvariables.php');

// breadcrumbs and page title
$navwhere['text1'] = $main_smarty->get_config_vars('PLIGG_Visual_Breadcrumb_Live');
$navwhere['link1'] = getmyurl('live', '');
$navwhere['text2'] = $main_smarty->get_config_vars('PLIGG_Visual_Breadcrumb_Comments');
$navwhere['link2'] = getmyurl('comments', '');
$main_smarty->assign('navbar_where', $navwhere);
$main_smarty->assign('posttitle', " / " . $main_smarty->get_config_vars('PLIGG_Visual_Breadcrumb_Comments'));

// figure out what "page" of the results we're on
$offset = (get_current_page() - 1) * $top_users_size;

$select = "SELECT comment_id";
$from_where = " FROM " . table_comments . " ";
$order_by = " ORDER BY comment_id DESC";

// pagename
define('pagename', 'comments');
$main_smarty->assign('pagename', pagename);

// get the data to be displayed
$rows = $db->get_var("SELECT count(*) as count $from_where $order_by");
$comments = $db->get_results("$select $from_where $order_by LIMIT $offset,$top_users_size");

$comment = new Comment;
$user = new User;
$link = new Link;
if($comments) {
	foreach($comments as $dbcomment) {
		$comment->id = $dbcomment->comment_id;
		$comment->read();
		$live_item['comment_content'] = $comment->content;
		$user->id = $comment->author;
		$user->read();
		$live_item['comment_author'] = $user->username;
		$live_item['comment_date'] = txt_time_diff($comment->date);
		$link->id = $comment->link;
		$link->read();
		$live_item['comment_link_title'] = $link->title;
		$live_item['comment_link_url'] = $link->title_url;
		$live_items[] = $live_item;
	}
	$main_smarty->assign('live_items', $live_items);
}

// pagination
$main_smarty->assign('live_pagination', do_pages($rows, $top_users_size, "comments", true));
// sidebar
$main_smarty = do_sidebar($main_smarty);

// show the template
$main_smarty->assign('tpl_center', $the_template . '/live_comments_center');
$main_smarty->display($the_template . '/pligg.tpl');
?>
