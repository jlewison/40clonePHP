<?php
require_once('Connections/apound.php');

$colname_UPBID = "1";

$ucat = mysql_real_escape_string($_GET[ucat]);

	mysql_select_db($database_apound, $apound);
		$query_UPBID = "SELECT * FROM main WHERE dtu = '$ucat'";
		$UPBID = mysql_query($query_UPBID, $apound) or die(mysql_error());
		$row_UPBID = mysql_fetch_assoc($UPBID);
		$totalRows_UPBID = mysql_num_rows($UPBID);

$UPRGcategory = $row_UPBID['maincategory'];					
	mysql_select_db($database_apound, $apound);
		$query_LdetCAT = "SELECT * FROM categorylisting WHERE catlistid = '$UPRGcategory'";
		$LdetCAT = mysql_query($query_LdetCAT, $apound) or die(mysql_error());
		$row_LdetCAT = mysql_fetch_assoc($LdetCAT);
		$totalRows_LdetCAT = mysql_num_rows($LdetCAT);
?>