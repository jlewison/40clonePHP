<?php include('restrict.php'); include('../settings.php'); require_once('../Connections/apound.php'); ?>
<?php
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = (!get_magic_quotes_gpc()) ? addslashes($theValue) : $theValue;

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO template (template) VALUES (%s)",
                       GetSQLValueString($_POST['template'], "text"));

  mysql_select_db($database_apound, $apound);
  $Result1 = mysql_query($insertSQL, $apound) or die(mysql_error());

  $insertGoTo = "template_add.php?upd=Y";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}

mysql_select_db($database_apound, $apound);
$query_lstTe = "SELECT * FROM template";
$lstTe = mysql_query($query_lstTe, $apound) or die(mysql_error());
$row_lstTe = mysql_fetch_assoc($lstTe);
$totalRows_lstTe = mysql_num_rows($lstTe);
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Manage Templates - Link Bid Script Admin Panel</title>
<link rel="shortcut icon" href="img/favicon.ico" />
<link rel="stylesheet" type="text/css" href="admin.css" />
<style type="text/css">
<!--
.style84 {font-family: Verdana, Arial, Helvetica, sans-serif}
.style85 {font-size: 13px}
-->
</style>
</head>

<body>
<?php include('header_tpl.php'); ?>
<h2>Manage Templates</h2>
<table width="770"  border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
  <tr>
    <td width="770"><?php $x = getenv("HTTP_HOST").getenv("REQUEST_URI"); echo("<font color=white>$x</font>"); ?></td>
  </tr>
</table>
<table width="770"  border="0" align="center" cellpadding="3" cellspacing="1" bgcolor="#FFFFFF">
  <tr>
    <td width="760" valign="top">
    <?php $upd = $_GET[upd]; if($upd == 'Y') { echo("<div align='center'><font color='red'><b>Update ... DONE</b></font></div>"); } else { } ?>
    <table border="0" align="center" cellpadding="3" cellspacing="3">
      <tr bgcolor="#FFFF00" class="style80">
        <td>id</td>
        <td>template name </td>
        <td>delete</td>
      </tr>
      <?php do { ?>
      <tr class="style76">
        <td><?php echo $row_lstTe['teind']; ?></td>
        <td><?php echo $row_lstTe['template']; ?></td>
        <td align="center"><a href="template_delete.php?id=<?php echo $row_lstTe['teind'];?>"><img src="img/b_drop.png" width="16" height="16" border="0"></a></td>
      </tr>
      <?php } while ($row_lstTe = mysql_fetch_assoc($lstTe)); ?>
    </table>
      <table width="100%"  border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td>&nbsp;</td>
        </tr>
      </table>
      
      <form method="post" name="form1" action="<?php echo $editFormAction; ?>">
        <table align="center">
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">&nbsp;</td>
            <td><span class="style80">Add new template </span></td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">Template name:</td>
            <td><input name="template" type="text" class="edtab" value="" size="32"></td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style85">&nbsp;</td>
            <td><input type="submit" class="login-but" value="Insert record"></td>
          </tr>
        </table>
        <input type="hidden" name="MM_insert" value="form1">
      </form>
    </td>
  </tr>
</table>
<?php include('footer_tpl.php'); ?>
</body>
</html>
<?php
mysql_free_result($lstTe);
?>
