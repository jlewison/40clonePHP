<?php

class Marketplacemodel extends Model
{
		//Constructor
		var $userId;
		function Marketplacemodel()
		{
				parent::Model();
				$this->userId = $this->session->userdata('user_id');
				$this->load->model('networkModel');
		}
		function insertWant($valuesArray, $subCatCode)
		{
				if (strtoupper(trim($subCatCode)) == "JOB" || strtoupper(trim($subCatCode)) == "FREE")
				{
						$arrCat = $this->getMainCat($subCatCode);
						$subcatId = '-1';
				} elseif (strtoupper(trim($subCatCode)) != "")
				{
						$arrCat = $this->getSubCat($subCatCode);
						$subcatId = $arrCat[0]['sub_cat_id'];
				}
				# To get the Category ID and Sub Category ID - END
				$title = $valuesArray['title'];
				$description = $valuesArray['description'];
				$catId = $arrCat[0]['cat_id'];
				#UPDATE QUERY FOR PRODUCTS LIST - here title, cat_id, sub_cat_id, tag_id and decription are grouped
				$insertSql = "INSERT INTO products_wanted set cat_id = " . $catId . ",	sub_cat_id = " . $subcatId . ",	tag_id = '" . trim($valuesArray['hdnCatcode']) . "',item_title=" . $this->db->escape($title) . ",	item_description = " . $this->db->escape($description) . ",";
				switch (strtoupper(trim($subCatCode)))
				{
						case "BOOK":
								{
										$condition = $valuesArray['condition'];
										$isbn = $valuesArray['isbn'];
										$dataSql = " item_type = " . $this->db->escape($condition) . ",	ISBN_Code = " . $this->db->escape($isbn) . ",";
										break;
								}
						case "FURNITURE":
								{
										$condition = $valuesArray['condition'];
										$dataSql = " item_type = " . $this->db->escape($condition) . ",";
										break;
								}
						case "TICKET":
								{
										$dataSql = " ";
										break;
								}
						case "ELECTRONIC":
								{
										$condition = $valuesArray['condition'];
										$dataSql = " item_type = " . $this->db->escape($condition) . ",";
										break;
								}
						case "CAR":
								{
										$condition = $valuesArray['condition'];
										$dataSql = " item_type = " . $this->db->escape($condition) . ",";
										break;
								}
						case "OTHERSALE":
								{
										$dataSql = " ";
										break;
								}
						case "RENTAL":
								{
										$allowables = $this->getSelectedAllowables();
										$bedRoomsSelected = $valuesArray['bedRooms'];
										$bathRoomsSelected = $valuesArray['bathRooms'];
										$postalCode = (trim($valuesArray['postalCode']) == "") ? "NULL" : $this->db->escape($valuesArray['postalCode']);
										$dataSql = " bed_rooms = " . $bedRoomsSelected . ", bath_rooms = " . $bathRoomsSelected . ",postal_code = " . $postalCode . ", allowed_flag_ids = " . $allowables . ",";
										break;
								}
						case "SUBLET":
								{
										$allowables = $this->getSelectedAllowables();
										$bedRoomsSelected = $valuesArray['bedRooms'];
										$bathRoomsSelected = $valuesArray['bathRooms'];
										$postalCode = (trim($valuesArray['postalCode']) == "") ? "NULL" : $this->db->escape($valuesArray['postalCode']);
										$dataSql = " bed_rooms = " . $bedRoomsSelected . ", bath_rooms = " . $bathRoomsSelected . ",postal_code = " . $postalCode . ", allowed_flag_ids = " . $allowables . ",";
										break;
								}
						case "REALESTATE":
								{
										$allowables = $this->getSelectedAllowables();
										$bedRoomsSelected = $valuesArray['bedRooms'];
										$bathRoomsSelected = $valuesArray['bathRooms'];
										$postalCode = (trim($valuesArray['postalCode']) == "") ? "NULL" : $this->db->escape($valuesArray['postalCode']);
										$dataSql = " bed_rooms = " . $bedRoomsSelected . ", bath_rooms = " . $bathRoomsSelected . ",postal_code = " . $postalCode . ", allowed_flag_ids = " . $allowables . ",";
										break;
								}
						case "OTHERHOUSING":
								{
										$allowables = $this->getSelectedAllowables();
										$bedRoomsSelected = $valuesArray['bedRooms'];
										$bathRoomsSelected = $valuesArray['bathRooms'];
										$postalCode = (trim($valuesArray['postalCode']) == "") ? "NULL" : $this->db->escape($valuesArray['postalCode']);
										$dataSql = " bed_rooms = " . $bedRoomsSelected . ", bath_rooms = " . $bathRoomsSelected . ",postal_code = " . $postalCode . ", allowed_flag_ids = " . $allowables . ",";
										break;
								}
						case "FOUNDITEM":
								{
										$dataSql = "";
										break;
								}
						case "EVERYTHING":
								{
										$dataSql = "";
										break;
								}
								//job type, hours, other stuff, compensation, amount, cost_code
						case "JOB":
								{
										$itemType = "'" . $valuesArray['jobType'] . "'";
										$dataSql = " item_type = " . $itemType . ",";
										break;
								}
						case "FREE":
								{
										$dataSql = "";
										break;
								}
						default:
								{
										return "For this product no implementation done";
										break;
								}
				} //End of Switch
				$profFlag = isset($valuesArray['profileFlag']) ? "Y" : "N";
				$privacyFlag = isset($valuesArray['privacy']) ? "Y" : "N";
				$commonFldsSql = "	profile_want_flag = '" . $profFlag . "',	privacy_want_flag = '" . $privacyFlag . "', want_photos_ids = NULL, user_id =  " . $this->userId;
				$strSql = $insertSql . $dataSql . $commonFldsSql . ";";
				$this->db->query($strSql);
				if ($this->db->affected_rows() == 1) return $this->db->insert_id();
				else  return 0;
		}
		function getNetworkMarket($networkId, $start = '', $limit = '')
		{
				$strSQL = 'SELECT results.list_id,results.list_type,results.tag_id,results.item_title,DATE_FORMAT(results.date_created,"%d %M %Y") AS date_created,results.username,results.user_id FROM
					(
						SELECT pl.list_id, "list" AS list_type, pl.tag_id, pl.item_title, pl.date_created,u.username,pl.user_id FROM products_list AS pl 
						INNER JOIN list_networks AS lnt ON lnt.list_id = pl.list_id AND lnt.network_id IN (' . $networkId . ')
						INNER JOIN users AS u ON pl.user_id = u.user_id
						WHERE UPPER(TRIM(pl.privacy_list_flag)) = "Y"
						UNION ALL
						SELECT pl.wanted_id AS list_id, "want" AS list_type, pl.tag_id, pl.item_title, pl.date_created,u.username,pl.user_id FROM products_wanted AS pl 
						INNER JOIN want_networks AS lnt ON lnt.wanted_id = pl.wanted_id AND lnt.network_id IN (' . $networkId . ')
						INNER JOIN users AS u ON pl.user_id = u.user_id
						WHERE UPPER(TRIM(pl.privacy_want_flag)) = "Y"
					) AS results
					ORDER BY results.date_created DESC ';
				if (ereg('^[0-9]+$', $start) && ereg('^[0-9]+$', $limit))
				{
						$strSQL .= ' LIMIT ' . $start . ', ' . $limit;
				}
				$resSQL = $this->db->query($strSQL);
				$resArray = array();
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[] = $resRow;
						}
				}
				return $resArray;
		}
		function updateWant($valuesArray, $subCatCode)
		{
				if (strtoupper(trim($subCatCode)) == "JOB" || strtoupper(trim($subCatCode)) == "FREE")
				{
						$arrCat = $this->getMainCat($subCatCode);
						$subcatId = '-1';
				} elseif (strtoupper(trim($subCatCode)) != "")
				{
						$arrCat = $this->getSubCat($subCatCode);
						$subcatId = $arrCat[0]['sub_cat_id'];
				}
				# To get the Category ID and Sub Category ID - END
				$title = $valuesArray['title'];
				$description = $valuesArray['description'];
				$catId = $arrCat[0]['cat_id'];
				#UPDATE QUERY FOR PRODUCTS LIST - here title, cat_id, sub_cat_id, tag_id and decription are grouped
				$insertSql = "UPDATE products_wanted set cat_id = " . $catId . ",	sub_cat_id = " . $subcatId . ",	tag_id = '" . trim($valuesArray['hdnCatcode']) . "',item_title=" . $this->db->escape($title) . ",	item_description = " . $this->db->escape($description) . ",";
				switch (strtoupper(trim($subCatCode)))
				{
						case "BOOK":
								{
										$condition = $valuesArray['condition'];
										$isbn = $valuesArray['isbn'];
										$dataSql = " item_type = " . $this->db->escape($condition) . ",	ISBN_Code = " . $this->db->escape($isbn) . ",";
										break;
								}
						case "FURNITURE":
								{
										$condition = $valuesArray['condition'];
										$dataSql = " item_type = " . $this->db->escape($condition) . ",";
										break;
								}
						case "TICKET":
								{
										$dataSql = " ";
										break;
								}
						case "ELECTRONIC":
								{
										$condition = $valuesArray['condition'];
										$dataSql = " item_type = " . $this->db->escape($condition) . ",";
										break;
								}
						case "CAR":
								{
										$condition = $valuesArray['condition'];
										$dataSql = " item_type = " . $this->db->escape($condition) . ",";
										break;
								}
						case "OTHERSALE":
								{
										$dataSql = " ";
										break;
								}
						case "RENTAL":
								{
										$allowables = $this->getSelectedAllowables();
										$bedRoomsSelected = $valuesArray['bedRooms'];
										$bathRoomsSelected = $valuesArray['bathRooms'];
										$postalCode = (trim($valuesArray['postalCode']) == "") ? "NULL" : $this->db->escape($valuesArray['postalCode']);
										$dataSql = " bed_rooms = " . $bedRoomsSelected . ", bath_rooms = " . $bathRoomsSelected . ",postal_code = " . $postalCode . ", allowed_flag_ids = " . $allowables . ",";
										break;
								}
						case "SUBLET":
								{
										$allowables = $this->getSelectedAllowables();
										$bedRoomsSelected = $valuesArray['bedRooms'];
										$bathRoomsSelected = $valuesArray['bathRooms'];
										$postalCode = (trim($valuesArray['postalCode']) == "") ? "NULL" : $this->db->escape($valuesArray['postalCode']);
										$dataSql = " bed_rooms = " . $bedRoomsSelected . ", bath_rooms = " . $bathRoomsSelected . ",postal_code = " . $postalCode . ", allowed_flag_ids = " . $allowables . ",";
										break;
								}
						case "REALESTATE":
								{
										$allowables = $this->getSelectedAllowables();
										$bedRoomsSelected = $valuesArray['bedRooms'];
										$bathRoomsSelected = $valuesArray['bathRooms'];
										$postalCode = (trim($valuesArray['postalCode']) == "") ? "NULL" : $this->db->escape($valuesArray['postalCode']);
										$dataSql = " bed_rooms = " . $bedRoomsSelected . ", bath_rooms = " . $bathRoomsSelected . ",postal_code = " . $postalCode . ", allowed_flag_ids = " . $allowables . ",";
										break;
								}
						case "OTHERHOUSING":
								{
										$allowables = $this->getSelectedAllowables();
										$bedRoomsSelected = $valuesArray['bedRooms'];
										$bathRoomsSelected = $valuesArray['bathRooms'];
										$postalCode = (trim($valuesArray['postalCode']) == "") ? "NULL" : $this->db->escape($valuesArray['postalCode']);
										$dataSql = " bed_rooms = " . $bedRoomsSelected . ", bath_rooms = " . $bathRoomsSelected . ",postal_code = " . $postalCode . ", allowed_flag_ids = " . $allowables . ",";
										break;
								}
						case "FOUNDITEM":
								{
										$dataSql = "";
										break;
								}
						case "EVERYTHING":
								{
										$dataSql = "";
										break;
								}
								//job type, hours, other stuff, compensation, amount, cost_code
						case "JOB":
								{
										$itemType = "'" . $valuesArray['jobType'] . "'";
										$dataSql = " item_type = " . $itemType . ",";
										break;
								}
						case "FREE":
								{
										$dataSql = "";
										break;
								}
						default:
								{
										return "For this product no implementation done";
										break;
								}
				} //End of Switch
				$profFlag = (isset($valuesArray['profileFlag']) && $valuesArray['profileFlag'] == 'Y') ? "Y" : "N";
				$privacyFlag = (isset($valuesArray['privacy']) && $valuesArray['privacy'] == 'Y') ? "Y" : "N";
				$listId = $valuesArray['hdnListId'];
				$commonFldsSql = "	profile_want_flag = '" . $profFlag . "',	privacy_want_flag = '" . $privacyFlag . "', want_photos_ids = NULL, user_id =  " . $this->userId . ", date_modified = CURRENT_TIMESTAMP WHERE wanted_id = " . $this->db->escape($listId);
				$strSql = $insertSql . $dataSql . $commonFldsSql . ";";
				$this->db->query($strSql);
				if ($this->db->affected_rows() == 1) return $listId;
				else  return 0;
		}
		function insertList($valuesArray, $subCatCode)
		{
				if (strtoupper(trim($subCatCode)) == "JOB" || strtoupper(trim($subCatCode)) == "FREE")
				{
						$arrCat = $this->getMainCat($subCatCode);
						$subcatId = '-1';
				} elseif (strtoupper(trim($subCatCode)) != "")
				{
						$arrCat = $this->getSubCat($subCatCode);
						$subcatId = $arrCat[0]['sub_cat_id'];
				}
				# To get the Category ID and Sub Category ID - END
				$title = $valuesArray['title'];
				$description = $valuesArray['description'];
				$catId = $arrCat[0]['cat_id'];
				#UPDATE QUERY FOR PRODUCTS LIST - here title, cat_id, sub_cat_id, tag_id and decription are grouped
				$insertSql = "INSERT INTO products_list set cat_id = " . $catId . ",	sub_cat_id = " . $subcatId . ",	tag_id = '" . trim($valuesArray['hdnCatcode']) . "',item_title=" . $this->db->escape($title) . ",	item_description = " . $this->db->escape($description) . ",";
				switch (strtoupper(trim($subCatCode)))
				{
						case "BOOK":
								{
										$condition = $valuesArray['condition'];
										$cost = (trim($valuesArray['amount']) == "") ? "NULL" : trim($valuesArray['amount']);
										$isbn = $valuesArray['isbn'];
										$currency = trim($valuesArray['currencyCode']);
										$dataSql = " item_type = " . $this->db->escape($condition) . ",	item_cost = " . $cost . ",	ISBN_Code = " . $this->db->escape($isbn) . ", cost_code = " . $this->db->escape($currency) . ",";
										break;
								}
						case "FURNITURE":
								{
										$condition = $valuesArray['condition'];
										$cost = (trim($valuesArray['amount']) == "") ? "NULL" : trim($valuesArray['amount']);
										$currency = trim($valuesArray['currencyCode']);
										$dataSql = " item_type = " . $this->db->escape($condition) . ",	item_cost = " . $cost . ", cost_code = " . $this->db->escape($currency) . ",";
										break;
								}
						case "TICKET":
								{
										$cost = (trim($valuesArray['amount']) == "") ? "NULL" : trim($valuesArray['amount']);
										$currency = trim($valuesArray['currencyCode']);
										$dataSql = "item_cost = " . $cost . ", cost_code = " . $this->db->escape($currency) . ",";
										break;
								}
						case "ELECTRONIC":
								{
										$condition = $valuesArray['condition'];
										$cost = (trim($valuesArray['amount']) == "") ? "NULL" : trim($valuesArray['amount']);
										$currency = trim($valuesArray['currencyCode']);
										$dataSql = " item_type = " . $this->db->escape($condition) . ",	item_cost = " . $cost . ", cost_code = " . $this->db->escape($currency) . ",";
										break;
								}
						case "CAR":
								{
										$condition = $valuesArray['condition'];
										$cost = (trim($valuesArray['amount']) == "") ? "NULL" : trim($valuesArray['amount']);
										$currency = trim($valuesArray['currencyCode']);
										$dataSql = " item_type = " . $this->db->escape($condition) . ",	item_cost = " . $cost . ", cost_code = " . $this->db->escape($currency) . ",";
										break;
								}
						case "OTHERSALE":
								{
										$cost = (trim($valuesArray['amount']) == "") ? "NULL" : trim($valuesArray['amount']);
										$currency = trim($valuesArray['currencyCode']);
										$dataSql = " item_cost = " . $cost . ", cost_code = " . $this->db->escape($currency) . ",";
										break;
								}
						case "RENTAL":
								{
										$allowables = $this->getSelectedAllowables();
										$bedRoomsSelected = $valuesArray['bedRooms'];
										$bathRoomsSelected = $valuesArray['bathRooms'];
										$cost = (trim($valuesArray['amount']) == "") ? "NULL" : trim($valuesArray['amount']);
										$currency = trim($valuesArray['currencyCode']);
										$street = trim($valuesArray['street']);
										$street = (trim($street) == "") ? "NULL" : $this->db->escape($street);
										$crossStreet = trim($valuesArray['crossStreet']);
										$crossStreet = (trim($crossStreet) == "") ? "NULL" : $this->db->escape($crossStreet);
										$postalCode = (trim($valuesArray['postalCode']) == "") ? "NULL" : $this->db->escape($valuesArray['postalCode']);
										$squareFeet = (trim($valuesArray['squareFeet']) == "") ? "NULL" : trim($valuesArray['squareFeet']);
										$dataSql = " bed_rooms = " . $bedRoomsSelected . ", bath_rooms = " . $bathRoomsSelected . ", item_cost = " . $cost . ", cost_code = '" . $currency . "', street = " . $street . ", cross_street = " . $crossStreet . ", postal_code = " . $postalCode . ", square_feet = " . $squareFeet . ", allowed_flag_ids = " . $allowables . ",";
										break;
								}
						case "SUBLET":
								{
										$allowables = $this->getSelectedAllowables();
										$bedRoomsSelected = $valuesArray['bedRooms'];
										$bathRoomsSelected = $valuesArray['bathRooms'];
										$cost = (trim($valuesArray['amount']) == "") ? "NULL" : trim($valuesArray['amount']);
										$currency = trim($valuesArray['currencyCode']);
										$street = trim($valuesArray['street']);
										$street = (trim($street) == "") ? "NULL" : $this->db->escape($street);
										$crossStreet = trim($valuesArray['crossStreet']);
										$crossStreet = (trim($crossStreet) == "") ? "NULL" : $this->db->escape($crossStreet);
										$postalCode = (trim($valuesArray['postalCode']) == "") ? "NULL" : $this->db->escape($valuesArray['postalCode']);
										$squareFeet = (trim($valuesArray['squareFeet']) == "") ? "NULL" : trim($valuesArray['squareFeet']);
										$dataSql = " bed_rooms = " . $bedRoomsSelected . ", bath_rooms = " . $bathRoomsSelected . ", item_cost = " . $cost . ", cost_code = '" . $currency . "', street = " . $street . ", cross_street = " . $crossStreet . ", postal_code = " . $postalCode . ", square_feet = " . $squareFeet . ", allowed_flag_ids = " . $allowables . ",";
										break;
								}
						case "REALESTATE":
								{
										$allowables = $this->getSelectedAllowables();
										$bedRoomsSelected = $valuesArray['bedRooms'];
										$bathRoomsSelected = $valuesArray['bathRooms'];
										$cost = (trim($valuesArray['amount']) == "") ? "NULL" : trim($valuesArray['amount']);
										$currency = trim($valuesArray['currencyCode']);
										$street = trim($valuesArray['street']);
										$street = (trim($street) == "") ? "NULL" : $this->db->escape($street);
										$crossStreet = trim($valuesArray['crossStreet']);
										$crossStreet = (trim($crossStreet) == "") ? "NULL" : $this->db->escape($crossStreet);
										$postalCode = (trim($valuesArray['postalCode']) == "") ? "NULL" : $this->db->escape($valuesArray['postalCode']);
										$squareFeet = (trim($valuesArray['squareFeet']) == "") ? "NULL" : trim($valuesArray['squareFeet']);
										$dataSql = " bed_rooms = " . $bedRoomsSelected . ", bath_rooms = " . $bathRoomsSelected . ", item_cost = " . $cost . ", cost_code = '" . $currency . "', street = " . $street . ", cross_street = " . $crossStreet . ", postal_code = " . $postalCode . ", square_feet = " . $squareFeet . ", allowed_flag_ids = " . $allowables . ",";
										break;
								}
						case "OTHERHOUSING":
								{
										$allowables = $this->getSelectedAllowables();
										$bedRoomsSelected = $valuesArray['bedRooms'];
										$bathRoomsSelected = $valuesArray['bathRooms'];
										$street = trim($valuesArray['street']);
										$street = (trim($street) == "") ? "NULL" : $this->db->escape($street);
										$crossStreet = trim($valuesArray['crossStreet']);
										$crossStreet = (trim($crossStreet) == "") ? "NULL" : $this->db->escape($crossStreet);
										$postalCode = (trim($valuesArray['postalCode']) == "") ? "NULL" : $this->db->escape($valuesArray['postalCode']);
										$squareFeet = (trim($valuesArray['squareFeet']) == "") ? "NULL" : trim($valuesArray['squareFeet']);
										$dataSql = " bed_rooms = " . $bedRoomsSelected . ", bath_rooms = " . $bathRoomsSelected . ", street = " . $street . ", cross_street = " . $crossStreet . ", postal_code = " . $postalCode . ", square_feet = " . $squareFeet . ", allowed_flag_ids = " . $allowables . ",";
										break;
								}
						case "FOUNDITEM":
								{
										$dataSql = "";
										break;
								}
						case "EVERYTHING":
								{
										$dataSql = "";
										break;
								}
								//job type, hours, other stuff, compensation, amount, cost_code
						case "JOB":
								{
										$otherSuffIds = $this->getSelectedOtherStuffs();
										$itemType = "'" . $valuesArray['jobType'] . "'";
										$hoursChoice = "'" . $valuesArray['hours'] . "'";
										$compensationType = "'" . $valuesArray['compensation'] . "'";
										$itemCost = (trim($valuesArray['amount']) == "") ? "NULL" : trim($valuesArray['amount']);
										$costCode = "'" . $valuesArray['currencyCode'] . "'";
										$dataSql = " item_type = " . $itemType . ", hours_choice = " . $hoursChoice . ", compensation_type = " . $compensationType . ", item_cost = " . $itemCost . ", cost_code = " . $costCode . ", other_stuff_ids = " . $otherSuffIds . ",";
										break;
								}
						case "FREE":
								{
										$dataSql = "";
										break;
								}
						default:
								{
										return "For this product no implementation done";
										break;
								}
				} //End of Switch
				$profFlag = isset($valuesArray['profileFlag']) ? "Y" : "N";
				$privacyFlag = isset($valuesArray['privacy']) ? "Y" : "N";
				$commonFldsSql = "	profile_list_flag = '" . $profFlag . "',	privacy_list_flag = '" . $privacyFlag . "', list_photos_ids = NULL, user_id =  " . $this->userId;
				$strSql = $insertSql . $dataSql . $commonFldsSql . ";";
				$this->db->query($strSql);
				if ($this->db->affected_rows() == 1) return $this->db->insert_id();
				else  return 0;
		}
		function updateList($valuesArray, $subCatCode)
		{
				if (strtoupper(trim($subCatCode)) == "JOB" || strtoupper(trim($subCatCode)) == "FREE")
				{
						$arrCat = $this->getMainCat($subCatCode);
						$subcatId = '-1';
				} elseif (strtoupper(trim($subCatCode)) != "")
				{
						$arrCat = $this->getSubCat($subCatCode);
						$subcatId = $arrCat[0]['sub_cat_id'];
				}
				# To get the Category ID and Sub Category ID - END
				$title = $valuesArray['title'];
				$description = $valuesArray['description'];
				$catId = $arrCat[0]['cat_id'];
				#INSERT QUERY FOR PRODUCTS LIST - here title, cat_id, sub_cat_id, tag_id and decription are grouped
				$insertSql = "UPDATE products_list set cat_id = " . $catId . ",	sub_cat_id = " . $subcatId . ",	tag_id = '" . trim($valuesArray['hdnCatcode']) . "',item_title=" . $this->db->escape($title) . ",	item_description = " . $this->db->escape($description) . ",";
				switch (strtoupper(trim($subCatCode)))
				{
						case "BOOK":
								{
										$condition = $valuesArray['condition'];
										$cost = (trim($valuesArray['amount']) == "") ? "NULL" : trim($valuesArray['amount']);
										$isbn = $valuesArray['isbn'];
										$currency = trim($valuesArray['currencyCode']);
										$dataSql = " item_type = " . $this->db->escape($condition) . ",	item_cost = " . $cost . ",	ISBN_Code = " . $this->db->escape($isbn) . ", cost_code = " . $this->db->escape($currency) . ",";
										break;
								}
						case "FURNITURE":
								{
										$condition = $valuesArray['condition'];
										$cost = (trim($valuesArray['amount']) == "") ? "NULL" : trim($valuesArray['amount']);
										$currency = trim($valuesArray['currencyCode']);
										$dataSql = " item_type = " . $this->db->escape($condition) . ",	item_cost = " . $cost . ", cost_code = " . $this->db->escape($currency) . ",";
										break;
								}
						case "TICKET":
								{
										$cost = (trim($valuesArray['amount']) == "") ? "NULL" : trim($valuesArray['amount']);
										$currency = trim($valuesArray['currencyCode']);
										$dataSql = "item_cost = " . $cost . ", cost_code = " . $this->db->escape($currency) . ",";
										break;
								}
						case "ELECTRONIC":
								{
										$condition = $valuesArray['condition'];
										$cost = (trim($valuesArray['amount']) == "") ? "NULL" : trim($valuesArray['amount']);
										$currency = trim($valuesArray['currencyCode']);
										$dataSql = " item_type = " . $this->db->escape($condition) . ",	item_cost = " . $cost . ", cost_code = " . $this->db->escape($currency) . ",";
										break;
								}
						case "CAR":
								{
										$condition = $valuesArray['condition'];
										$cost = (trim($valuesArray['amount']) == "") ? "NULL" : trim($valuesArray['amount']);
										$currency = trim($valuesArray['currencyCode']);
										$dataSql = " item_type = " . $this->db->escape($condition) . ",	item_cost = " . $cost . ", cost_code = " . $this->db->escape($currency) . ",";
										break;
								}
						case "OTHERSALE":
								{
										$cost = (trim($valuesArray['amount']) == "") ? "NULL" : trim($valuesArray['amount']);
										$currency = trim($valuesArray['currencyCode']);
										$dataSql = " item_cost = " . $cost . ", cost_code = " . $this->db->escape($currency) . ",";
										break;
								}
						case "RENTAL":
								{
										$allowables = $this->getSelectedAllowables();
										$bedRoomsSelected = $valuesArray['bedRooms'];
										$bathRoomsSelected = $valuesArray['bathRooms'];
										$cost = (trim($valuesArray['amount']) == "") ? "NULL" : trim($valuesArray['amount']);
										$currency = trim($valuesArray['currencyCode']);
										$street = trim($valuesArray['street']);
										$street = (trim($street) == "") ? "NULL" : $this->db->escape($street);
										$crossStreet = trim($valuesArray['crossStreet']);
										$crossStreet = (trim($crossStreet) == "") ? "NULL" : $this->db->escape($crossStreet);
										$postalCode = (trim($valuesArray['postalCode']) == "") ? "NULL" : $this->db->escape($valuesArray['postalCode']);
										$squareFeet = (trim($valuesArray['squareFeet']) == "") ? "NULL" : trim($valuesArray['squareFeet']);
										$dataSql = " bed_rooms = " . $bedRoomsSelected . ", bath_rooms = " . $bathRoomsSelected . ", item_cost = " . $cost . ", cost_code = '" . $currency . "', street = " . $street . ", cross_street = " . $crossStreet . ", postal_code = " . $postalCode . ", square_feet = " . $squareFeet . ", allowed_flag_ids = " . $allowables . ",";
										break;
								}
						case "SUBLET":
								{
										$allowables = $this->getSelectedAllowables();
										$bedRoomsSelected = $valuesArray['bedRooms'];
										$bathRoomsSelected = $valuesArray['bathRooms'];
										$cost = (trim($valuesArray['amount']) == "") ? "NULL" : trim($valuesArray['amount']);
										$currency = trim($valuesArray['currencyCode']);
										$street = trim($valuesArray['street']);
										$street = (trim($street) == "") ? "NULL" : $this->db->escape($street);
										$crossStreet = trim($valuesArray['crossStreet']);
										$crossStreet = (trim($crossStreet) == "") ? "NULL" : $this->db->escape($crossStreet);
										$postalCode = (trim($valuesArray['postalCode']) == "") ? "NULL" : $this->db->escape($valuesArray['postalCode']);
										$squareFeet = (trim($valuesArray['squareFeet']) == "") ? "NULL" : trim($valuesArray['squareFeet']);
										$dataSql = " bed_rooms = " . $bedRoomsSelected . ", bath_rooms = " . $bathRoomsSelected . ", item_cost = " . $cost . ", cost_code = '" . $currency . "', street = " . $street . ", cross_street = " . $crossStreet . ", postal_code = " . $postalCode . ", square_feet = " . $squareFeet . ", allowed_flag_ids = " . $allowables . ",";
										break;
								}
						case "REALESTATE":
								{
										$allowables = $this->getSelectedAllowables();
										$bedRoomsSelected = $valuesArray['bedRooms'];
										$bathRoomsSelected = $valuesArray['bathRooms'];
										$cost = (trim($valuesArray['amount']) == "") ? "NULL" : trim($valuesArray['amount']);
										$currency = trim($valuesArray['currencyCode']);
										$street = trim($valuesArray['street']);
										$street = (trim($street) == "") ? "NULL" : $this->db->escape($street);
										$crossStreet = trim($valuesArray['crossStreet']);
										$crossStreet = (trim($crossStreet) == "") ? "NULL" : $this->db->escape($crossStreet);
										$postalCode = (trim($valuesArray['postalCode']) == "") ? "NULL" : $this->db->escape($valuesArray['postalCode']);
										$squareFeet = (trim($valuesArray['squareFeet']) == "") ? "NULL" : trim($valuesArray['squareFeet']);
										$dataSql = " bed_rooms = " . $bedRoomsSelected . ", bath_rooms = " . $bathRoomsSelected . ", item_cost = " . $cost . ", cost_code = '" . $currency . "', street = " . $street . ", cross_street = " . $crossStreet . ", postal_code = " . $postalCode . ", square_feet = " . $squareFeet . ", allowed_flag_ids = " . $allowables . ",";
										break;
								}
						case "OTHERHOUSING":
								{
										$allowables = $this->getSelectedAllowables();
										$bedRoomsSelected = $valuesArray['bedRooms'];
										$bathRoomsSelected = $valuesArray['bathRooms'];
										$street = trim($valuesArray['street']);
										$street = (trim($street) == "") ? "NULL" : $this->db->escape($street);
										$crossStreet = trim($valuesArray['crossStreet']);
										$crossStreet = (trim($crossStreet) == "") ? "NULL" : $this->db->escape($crossStreet);
										$postalCode = (trim($valuesArray['postalCode']) == "") ? "NULL" : $this->db->escape($valuesArray['postalCode']);
										$squareFeet = (trim($valuesArray['squareFeet']) == "") ? "NULL" : trim($valuesArray['squareFeet']);
										$dataSql = " bed_rooms = " . $bedRoomsSelected . ", bath_rooms = " . $bathRoomsSelected . ", street = " . $street . ", cross_street = " . $crossStreet . ", postal_code = " . $postalCode . ", square_feet = " . $squareFeet . ", allowed_flag_ids = " . $allowables . ",";
										break;
								}
						case "FOUNDITEM":
								{
										$dataSql = "";
										break;
								}
						case "EVERYTHING":
								{
										$dataSql = "";
										break;
								}
								//job type, hours, other stuff, compensation, amount, cost_code
						case "JOB":
								{
										$otherSuffIds = $this->getSelectedOtherStuffs();
										$itemType = "'" . $valuesArray['jobType'] . "'";
										$hoursChoice = "'" . $valuesArray['hours'] . "'";
										$compensationType = "'" . $valuesArray['compensation'] . "'";
										$itemCost = (trim($valuesArray['amount']) == "") ? "NULL" : trim($valuesArray['amount']);
										$costCode = "'" . $valuesArray['currencyCode'] . "'";
										$dataSql = " item_type = " . $itemType . ", hours_choice = " . $hoursChoice . ", compensation_type = " . $compensationType . ", item_cost = " . $itemCost . ", cost_code = " . $costCode . ", other_stuff_ids = " . $otherSuffIds . ",";
										break;
								}
						case "FREE":
								{
										$dataSql = "";
										break;
								}
						default:
								{
										return "For this product no implementation done";
										break;
								}
				} //End of Switch
				$profFlag = isset($valuesArray['profileFlag']) ? "Y" : "N";
				$privacyFlag = isset($valuesArray['privacy']) ? "Y" : "N";
				$listId = $valuesArray['hdnListId'];
				$commonFldsSql = "	profile_list_flag = '" . $profFlag . "',	privacy_list_flag = '" . $privacyFlag . "', list_photos_ids = NULL, user_id =  " . $this->userId . ", date_modified = CURRENT_TIMESTAMP WHERE list_id = " . $this->db->escape($listId);
				$strSql = $insertSql . $dataSql . $commonFldsSql . ";";
				//	echo $strSql;
				//	exit;
				$this->db->query($strSql);
				if ($this->db->affected_rows() == 1) return $listId;
				else  return 0;
		}
		function delPhotos($mode, $listId, $photoId)
		{
				if ($mode == 'list') $strSQL = "DELETE FROM list_photos WHERE list_id = " . $this->db->escape($listId) . " AND photo_id =" . $this->db->escape($photoId);
				else  $strSQL = "DELETE FROM want_photos WHERE wanted_id = " . $this->db->escape($listId) . " AND photo_id =" . $this->db->escape($photoId);
				$this->db->query($strSQL);
		}
		function getListDetail($mode, $listId)
		{
				if ($mode == 'list')
				{
						$strSQL = " SELECT item_title as title, item_description as description, item_type as `condition`, ifnull(convert(item_cost,char),'') as amount , cost_code as currencyCode, IFNULL(ISBN_Code,'') as isbn, profile_list_flag as profileFlag,privacy_list_flag as privacy, bed_rooms as bedRooms, bath_rooms as bathRooms, street as street, cross_street as crossStreet,postal_code as postalCode,square_feet as squareFeet,allowed_flag_ids as allowed_ids,hours_choice as `hours`,other_stuff_ids, compensation_type as compensation FROM products_list where is_deleted = 0 and is_approved = 'Y' and user_id = " . $this->userId . "  and list_id = " . $listId;
				}
				else
				{
						$strSQL = " SELECT item_title as title, item_description as description, item_type as `condition`, ifnull(convert(item_cost,char),'') as amount , cost_code as currencyCode, IFNULL(ISBN_Code,'') as isbn, profile_want_flag as profileFlag,privacy_want_flag as privacy, bed_rooms as bedRooms, bath_rooms as bathRooms, street as street, cross_street as crossStreet,postal_code as postalCode,square_feet as squareFeet,allowed_flag_ids as allowed_ids,hours_choice as `hours`,other_stuff_ids, compensation_type as compensation FROM products_wanted where is_deleted = 0 and is_approved = 'Y' and user_id = " . $this->userId . "   and wanted_id = " . $listId;
				}
				//echo $strSQL;
				$resSQL = $this->db->query($strSQL);
				$resArray = array();
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[] = $resRow;
						}
				}
				return $resArray;
		}
		function getListedNetworks($mode, $listId)
		{
				if ($mode == 'list')
				{
						$strSQL = 'SELECT network_id FROM list_networks WHERE list_id = ' . $this->db->escape($listId);
				}
				else
				{
						$strSQL = 'SELECT network_id FROM want_networks WHERE wanted_id = ' . $this->db->escape($listId);
				}
				$resSql = $this->db->query($strSQL);
				$resArray = array();
				if ($resSql->num_rows() > 0)
				{
						foreach ($resSql->result_array() as $resRow)
						{
								$resArray[] = $resRow;
						}
				}
				return $resArray;
		}
		function getListedPhotos($mode, $listId)
		{
				if ($mode == 'list')
				{
						$strSQL = 'SELECT list_id,photo_id,file_name FROM list_photos WHERE list_id = ' . $this->db->escape($listId);
				}
				else
				{
						$strSQL = 'SELECT wanted_id,photo_id,file_name FROM want_photos WHERE wanted_id = ' . $this->db->escape($listId);
				}
				$resSql = $this->db->query($strSQL);
				$resArray = array();
				if ($resSql->num_rows() > 0)
				{
						foreach ($resSql->result_array() as $resRow)
						{
								$resArray[] = $resRow;
						}
				}
				return $resArray;
		}
		function saveNetworks($listId, $networksArray, $mode)
		{
				$strDelNetworkSQL = 'DELETE FROM list_networks WHERE list_id =' . $this->db->escape($listId);
				if ($mode == 'want')
				{
						$strDelNetworkSQL = 'DELETE FROM want_networks WHERE wanted_id =' . $this->db->escape($listId);
				}
				$this->db->query($strDelNetworkSQL);
				foreach ($networksArray as $key => $val)
				{
						if ($mode == 'list')
						{
								$strSQL = 'INSERT INTO list_networks (list_id,network_id,user_id) VALUES ( ' . $this->db->escape($listId) . ',' . $this->db->escape($val) . ',' . $this->db->escape($this->userId) . ')';
						}
						else
						{
								$strSQL = 'INSERT INTO want_networks (wanted_id,network_id,user_id) VALUES ( ' . $this->db->escape($listId) . ',' . $this->db->escape($val) . ',' . $this->db->escape($this->userId) . ')';
						}
						//echo $strSQL;
						$this->db->query($strSQL);
				}
		}
		function getSelectedAllowables()
		{
				$ids = '';
				if (isset($_POST['chkAllowed']))
				{
						foreach ($_POST['chkAllowed'] as $key => $val)
						{
								$ids = ($ids == '') ? $val : $ids . ',' . $val;
						}
				}
				if (trim($ids) == "")
				{
						$ids = "NULL";
				}
				else
				{
						$ids = "'" . $ids . "'";
				}
				return $ids;
		}
		function getSelectedOtherStuffs()
		{
				$ids = '';
				if (isset($_POST['otherStuff']))
				{
						foreach ($_POST['otherStuff'] as $key => $val)
						{
								$ids = ($ids == '') ? $val : $ids . ',' . $val;
						}
				}
				if (trim($ids) == "")
				{
						$ids = "NULL";
				}
				else
				{
						$ids = "'" . $ids . "'";
				}
				return $ids;
		}
		function AddPhotos($listId, $extension, $mode)
		{
				if ($mode == 'list')
				{
						$newPhotosSQL = 'INSERT INTO list_photos(list_id,file_name,user_id) VALUES (
									' . $this->db->escape($listId) . ',' . $this->db->escape($extension) . ',' . $this->db->escape($this->userId) . ')';
				}
				else
				{
						$newPhotosSQL = 'INSERT INTO want_photos(wanted_id,file_name,user_id) VALUES (
									' . $this->db->escape($listId) . ',' . $this->db->escape($extension) . ',' . $this->db->escape($this->userId) . ')';
				}
				$this->db->query($newPhotosSQL);
				if ($this->db->affected_rows() == 1) return $this->db->insert_id();
				else  return 0;
		} // End of storePhotos
		function getCatListingsCount($networkId, $userId = '')
		{
				$condSQL = '';
				if (intval($networkId) > 0)
				{
						if (trim($userId) != '')
						{
								$condSQL = " AND pl.user_id = '" . trim($userId) . "'";
						}
						$strSql = 'SELECT pc.cat_id,pc.cat_name,pc.cat_code,(SELECT count(Distinct pl.list_id) as list_count FROM products_list as pl 
						INNER JOIN list_networks as lnt ON lnt.list_id = pl.list_id AND lnt.network_id  = "' . $networkId . '"
						WHERE pl.is_deleted = "0" AND pl.cat_id = pc.cat_id ' . $condSQL . ') as cnt
						FROM prod_category as pc 
						WHERE is_deleted = "0" AND is_approved = "Y"';
				}
				else
				{
						if (trim($userId) != '')
						{
								$condSQL = " AND pl.user_id = '" . trim($userId) . "'";
						}
						$strSql = 'SELECT pc.cat_id,pc.cat_name,pc.cat_code,(SELECT count(Distinct pl.list_id) as list_count FROM products_list as pl 
						INNER JOIN list_networks as lnt ON lnt.list_id = pl.list_id 
						WHERE pl.is_deleted = "0" AND pl.cat_id = pc.cat_id ' . $condSQL . ') as cnt
						FROM prod_category as pc 
						WHERE is_deleted = "0" AND is_approved = "Y"';
				}
				$resSQL = $this->db->query($strSql);
				$resArray = array();
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $row)
						{
								$resArray[] = $row;
						}
				}
				return $resArray;
		}
		function getCatWantedCount($networkId, $userId = '')
		{
				$condSQL = '';
				if (intval($networkId) > 0)
				{
						if (trim($userId) != '')
						{
								$condSQL = " AND pl.user_id = '" . trim($userId) . "'";
						}
						$strSql = 'SELECT pc.cat_id,pc.cat_alias_name as cat_name,pc.cat_code,(SELECT count(pl.wanted_id) as list_count FROM products_wanted as pl 
						INNER JOIN want_networks as lnt ON lnt.wanted_id = pl.wanted_id AND lnt.network_id  = "' . $networkId . '"
						WHERE pl.is_deleted = "0" AND pl.cat_id = pc.cat_id ' . $condSQL . ') as cnt
						FROM prod_category as pc 
						WHERE is_deleted = "0" AND is_approved = "Y"';
				}
				else
				{
						if (trim($userId) != '')
						{
								$condSQL = " AND pl.user_id = '" . trim($userId) . "'";
						}
						$strSql = 'SELECT pc.cat_id,pc.cat_alias_name as cat_name,pc.cat_code,(SELECT count(pl.wanted_id) as list_count FROM products_wanted as pl 
						INNER JOIN want_networks as lnt ON lnt.wanted_id = pl.wanted_id 
						WHERE pl.is_deleted = "0" AND pl.cat_id = pc.cat_id ' . $condSQL . ') as cnt
						FROM prod_category as pc 
						WHERE is_deleted = "0" AND is_approved = "Y"';
				}
				$resSQL = $this->db->query($strSql);
				$resArray = array();
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $row)
						{
								$resArray[] = $row;
						}
				}
				return $resArray;
		}
		function isMainCatExist($catId)
		{
				$strSql = 'SELECT cat_id FROM prod_category WHERE is_approved = "Y" AND is_deleted = "0" AND cat_id = "' . trim($catId) . '"';
				$resSQL = $this->db->query($strSql);
				return $resSQL->num_rows();
		}
		function getHomeListings($networkId, $catId, $mode, $start = '', $limit = '')
		{
				$networkCondList = '';
				$networkCondWant = '';
				$privacyListCond = '';
				$privacyWantCond = '';
				$catCond = '';
				if (ereg('^[0-9]+$', $catId)) $catCond = ' AND plist.cat_id = ' . $catId;
				if ($networkId > 0)
				{
						//check for whether he belongs or not to the network
						// if he belongs to that network then list the products belongs to the network apply the network filter in (2)
						// if he doesn't belongs to that network then apply the filter of nework with privacy policy flag in (2)
						$userExist = $this->networkModel->isUserExist($networkId, $this->userId);
						//if($userExist > 0)
						if ($userExist)
						{
								$networkCondList = ' INNER JOIN list_networks as lnt ON lnt.list_id = plist.list_id and lnt.network_id = "' . $networkId . '" ';
								$networkCondWant = ' INNER JOIN want_networks as lnt ON lnt.wanted_id = plist.wanted_id and lnt.network_id = "' . $networkId . '" ';
						}
						else
						{
								$networkCondList = ' INNER JOIN list_networks as lnt ON lnt.list_id = plist.list_id and lnt.network_id = "' . $networkId . '" ';
								$networkCondWant = ' INNER JOIN want_networks as lnt ON lnt.wanted_id = plist.wanted_id and lnt.network_id = "' . $networkId . '" ';
								$privacyListCond = ' AND (plist.privacy_list_flag OR plist.user_id = "' . $this->userId . '" )';
								$privacyWantCond = ' AND (plist.privacy_want_flag OR plist.user_id = "' . $this->userId . '" )';
						}
				}
				else //Else part of networkid > 0

				{
						// write query with privacy policy filter only and avoid network filter
						$privacyListCond = ' AND (plist.privacy_list_flag = "Y" OR plist.user_id = "' . $this->userId . '" )';
						$privacyWantCond = ' AND (plist.privacy_want_flag = "Y" OR plist.user_id = "' . $this->userId . '" )';
				} // End of networkid > 0
				if (trim($mode) == 'n')
				{
						// write query to get All kind of listings - (2)
						$strSQL = ' SELECT results.cat_name,results.email, results.username,results.list_id,results.cat_id, results.sub_cat_id, results.tag_id,results.item_title, results.item_description, results.list_type, DAYNAME(results.date_created)AS day_name,DATE_FORMAT(results.date_created,"%M, %d %Y") AS day_desc,results.file_name,results.user_id 
						FROM( 
							SELECT  pc.cat_name,users.email,users.user_id, users.username,plist.list_id,plist.cat_id,plist.sub_cat_id, plist.tag_id,plist.item_title, 	
								plist.item_description	, "list" AS list_type,plist.date_created,
								IFNULL((SELECT CONCAT_WS(".",CONCAT_WS("_",lp.list_id,lp.photo_id),lp.file_name) FROM list_photos AS lp WHERE lp.list_id = plist.list_id LIMIT 1),"") AS file_name 
							FROM 	products_list AS plist ' . $networkCondList . ' 
							INNER JOIN users ON plist.user_id = users.user_id AND user_status = "active" 
							INNER JOIN prod_category AS pc ON pc.cat_id = plist.cat_id AND pc.is_deleted = "0" AND pc.is_approved = "Y" 
							WHERE 	plist.is_deleted = "0" AND plist.is_approved = "Y" ' . $privacyListCond . $catCond . ' 
							GROUP BY 
								pc.cat_name,users.email,users.user_id, users.username,plist.list_id,plist.cat_id,plist.sub_cat_id, plist.tag_id,plist.item_title, 
								plist.item_description,  plist.date_created 
							UNION ALL 
							SELECT 	 pc.cat_alias_name as cat_name,users.email,users.user_id, users.username, plist.wanted_id AS list_id,plist.cat_id,plist.sub_cat_id, plist.tag_id,plist.item_title, 
								 plist.item_description, "want" AS list_type,plist.date_created ,
								 IFNULL((SELECT CONCAT_WS(".",CONCAT_WS("_",lp.wanted_id,lp.photo_id),lp.file_name) FROM want_photos AS lp WHERE lp.wanted_id = plist.wanted_id LIMIT 1),"") AS file_name 
							FROM 	 products_wanted AS plist ' . $networkCondWant . ' 
							INNER JOIN users ON plist.user_id = users.user_id AND user_status = "active" 
							INNER JOIN prod_category AS pc ON pc.cat_id = plist.cat_id AND pc.is_deleted = "0" AND pc.is_approved = "Y" 
							WHERE 	 plist.is_deleted = "0" AND plist.is_approved = "Y" ' . $privacyWantCond . $catCond . ' 
							GROUP BY pc.cat_name,users.email, users.user_id,users.username,plist.wanted_id, plist.cat_id,plist.sub_cat_id,plist.tag_id,plist.item_title, 
								 plist.item_description, plist.date_created  
						) AS results 
						ORDER by results.date_created DESC ';
				}
				else //Else part of Mode

				{
						if ($mode == 'list')
						{
								//write query to get listings from products_list table - (2)
								$strSQL = 'SELECT results.cat_name,results.email, results.username,results.list_id,results.cat_id, results.sub_cat_id, results.tag_id,results.item_title, results.item_description, results.list_type, DAYNAME(results.date_created)AS day_name,DATE_FORMAT(results.date_created,"%M, %d %Y") AS day_desc,results.file_name,results.user_id 
							FROM( 
								SELECT  pc.cat_name,users.email,users.user_id, users.username,plist.list_id,plist.cat_id,plist.sub_cat_id, plist.tag_id,plist.item_title, 	
									plist.item_description	, "list" AS list_type,plist.date_created,
									IFNULL((SELECT CONCAT_WS(".",CONCAT_WS("_",lp.list_id,lp.photo_id),lp.file_name) FROM list_photos AS lp WHERE lp.list_id = plist.list_id LIMIT 1),"") AS file_name 
								FROM 	products_list AS plist ' . $networkCondList . '
								INNER JOIN users ON plist.user_id = users.user_id AND user_status = "active" 
								INNER JOIN prod_category AS pc ON pc.cat_id = plist.cat_id AND pc.is_deleted = "0" AND pc.is_approved = "Y" 
								WHERE 	plist.is_deleted = "0" AND plist.is_approved = "Y" ' . $privacyListCond . $catCond . ' 
								GROUP BY 
									pc.cat_name,users.email,users.user_id, users.username,plist.list_id,plist.cat_id,plist.sub_cat_id, plist.tag_id,plist.item_title, 
									plist.item_description,  plist.date_created 
							) as results';
						}
						else
						{
								//write query to get listings from products_wanted table - (2)
								$strSQL = 'SELECT results.cat_name,results.email, results.username,results.list_id,results.cat_id, results.sub_cat_id, results.tag_id,results.item_title, results.item_description, results.list_type, DAYNAME(results.date_created)AS day_name,DATE_FORMAT(results.date_created,"%M, %d %Y") AS day_desc,results.file_name,results.user_id 
							FROM( 
								SELECT 	 pc.cat_alias_name as cat_name,users.email,users.user_id, users.username, plist.wanted_id AS list_id,plist.cat_id,plist.sub_cat_id, plist.tag_id,plist.item_title, 
									 plist.item_description, "want" AS list_type,plist.date_created ,
									 IFNULL((SELECT CONCAT_WS(".",CONCAT_WS("_",lp.wanted_id,lp.photo_id),lp.file_name) FROM want_photos AS lp WHERE lp.wanted_id = plist.wanted_id LIMIT 1),"") AS file_name 
								FROM 	 products_wanted AS plist  ' . $networkCondWant . ' 
								INNER JOIN users ON plist.user_id = users.user_id AND user_status = "active" 
								INNER JOIN prod_category AS pc ON pc.cat_id = plist.cat_id AND pc.is_deleted = "0" AND pc.is_approved = "Y" 
								WHERE 	 plist.is_deleted = "0" AND plist.is_approved = "Y"  ' . $privacyWantCond . $catCond . ' 
								GROUP BY pc.cat_name,users.email, users.user_id,users.username,plist.wanted_id, plist.cat_id,plist.sub_cat_id,plist.tag_id,plist.item_title, 
									 plist.item_description, plist.date_created 
							) AS results 
							ORDER by results.date_created DESC';
						}
				} // End of mode
				if (ereg('^[0-9]+$', $start) && ereg('^[0-9]+$', $limit))
				{
						$strSQL .= ' LIMIT ' . $start . ', ' . $limit;
				}
				$resListings = $this->db->query($strSQL);
				$listingArray = array();
				if ($resListings->num_rows() > 0)
				{
						foreach ($resListings->result_array() as $resRow)
						{
								$strKey = $resRow['list_id'] . '_' . $resRow['list_type'];
								$listingArray[$strKey] = $resRow;
								$listingArray[$strKey]['cat_info'] = $this->getCatInfo($resRow['tag_id']);
								$listingArray[$strKey]['avatar'] = $this->getMarketplaceImage($resRow['list_id'], $resRow['list_type'], true);
						}
				}
				return $listingArray;
		} // End of getHomeListings()
		function getHomeListingsCount($networkId, $catId, $mode)
		{
				$networkCondList = '';
				$networkCondWant = '';
				$privacyListCond = '';
				$privacyWantCond = '';
				$catCond = '';
				if (ereg('^[0-9]+$', $catId)) $catCond = ' AND plist.cat_id = ' . $catId;
				if ($networkId > 0)
				{
						//check for whether he belongs or not to the network
						// if he belongs to that network then list the products belongs to the network apply the network filter in (2)
						// if he doesn't belongs to that network then apply the filter of nework with privacy policy flag in (2)
						$userExist = $this->networkModel->isUserExist($networkId, $this->userId);
						if ($userExist > 0)
						{
								$networkCondList = ' INNER JOIN list_networks as lnt ON lnt.list_id = plist.list_id and lnt.network_id = "' . $networkId . '" ';
								$networkCondWant = ' INNER JOIN want_networks as lnt ON lnt.wanted_id = plist.wanted_id and lnt.network_id = "' . $networkId . '" ';
						}
						else
						{
								$networkCondList = ' INNER JOIN list_networks as lnt ON lnt.list_id = plist.list_id and lnt.network_id = "' . $networkId . '" ';
								$networkCondWant = ' INNER JOIN want_networks as lnt ON lnt.wanted_id = plist.wanted_id and lnt.network_id = "' . $networkId . '" ';
								$privacyListCond = ' AND (plist.privacy_list_flag OR plist.user_id = "' . $this->userId . '" )';
								$privacyWantCond = ' AND (plist.privacy_want_flag OR plist.user_id = "' . $this->userId . '" )';
						}
				}
				else //Else part of networkid > 0

				{
						// write query with privacy policy filter only and avoid network filter
						$privacyListCond = ' AND (plist.privacy_list_flag = "Y" OR plist.user_id = "' . $this->userId . '" )';
						$privacyWantCond = ' AND (plist.privacy_want_flag = "Y" OR plist.user_id = "' . $this->userId . '" )';
				} // End of networkid > 0
				if (trim($mode) == 'n')
				{
						// write query to get All kind of listings - (2)
						$strSQL = ' SELECT results.cat_name,results.email, results.username,results.list_id,results.cat_id, results.sub_cat_id, results.tag_id,results.item_title, results.item_description, results.list_type, DAYNAME(results.date_created)AS day_name,DATE_FORMAT(results.date_created,"%M, %d %Y") AS day_desc,results.file_name,results.user_id 
						FROM( 
							SELECT  pc.cat_name,users.email,users.user_id, users.username,plist.list_id,plist.cat_id,plist.sub_cat_id, plist.tag_id,plist.item_title, 	
								plist.item_description	, "list" AS list_type,plist.date_created,
								IFNULL((SELECT CONCAT_WS(".",CONCAT_WS("_",lp.list_id,lp.photo_id),lp.file_name) FROM list_photos AS lp WHERE lp.list_id = plist.list_id LIMIT 1),"") AS file_name 
							FROM 	products_list AS plist ' . $networkCondList . ' 
							INNER JOIN users ON plist.user_id = users.user_id AND user_status = "active" 
							INNER JOIN prod_category AS pc ON pc.cat_id = plist.cat_id AND pc.is_deleted = "0" AND pc.is_approved = "Y" 
							WHERE 	plist.is_deleted = "0" AND plist.is_approved = "Y" ' . $privacyListCond . $catCond . ' 
							GROUP BY 
								pc.cat_name,users.email,users.user_id, users.username,plist.list_id,plist.cat_id,plist.sub_cat_id, plist.tag_id,plist.item_title, 
								plist.item_description,  plist.date_created 
							UNION ALL 
							SELECT 	 pc.cat_alias_name as cat_name,users.email,users.user_id, users.username, plist.wanted_id AS list_id,plist.cat_id,plist.sub_cat_id, plist.tag_id,plist.item_title, 
								 plist.item_description, "want" AS list_type,plist.date_created ,
								 IFNULL((SELECT CONCAT_WS(".",CONCAT_WS("_",lp.wanted_id,lp.photo_id),lp.file_name) FROM want_photos AS lp WHERE lp.wanted_id = plist.wanted_id LIMIT 1),"") AS file_name 
							FROM 	 products_wanted AS plist ' . $networkCondWant . ' 
							INNER JOIN users ON plist.user_id = users.user_id AND user_status = "active" 
							INNER JOIN prod_category AS pc ON pc.cat_id = plist.cat_id AND pc.is_deleted = "0" AND pc.is_approved = "Y" 
							WHERE 	 plist.is_deleted = "0" AND plist.is_approved = "Y" ' . $privacyWantCond . $catCond . ' 
							GROUP BY pc.cat_name,users.email, users.user_id,users.username,plist.wanted_id, plist.cat_id,plist.sub_cat_id,plist.tag_id,plist.item_title, 
								 plist.item_description, plist.date_created  
						) AS results 
						ORDER by results.date_created DESC ';
				}
				else //Else part of Mode

				{
						if ($mode == 'list')
						{
								//write query to get listings from products_list table - (2)
								$strSQL = 'SELECT results.cat_name,results.email, results.username,results.list_id,results.cat_id, results.sub_cat_id, results.tag_id,results.item_title, results.item_description, results.list_type, DAYNAME(results.date_created)AS day_name,DATE_FORMAT(results.date_created,"%M, %d %Y") AS day_desc,results.file_name,results.user_id 
							FROM( 
								SELECT  pc.cat_name,users.email,users.user_id, users.username,plist.list_id,plist.cat_id,plist.sub_cat_id, plist.tag_id,plist.item_title, 	
									plist.item_description	, "list" AS list_type,plist.date_created,
									IFNULL((SELECT CONCAT_WS(".",CONCAT_WS("_",lp.list_id,lp.photo_id),lp.file_name) FROM list_photos AS lp WHERE lp.list_id = plist.list_id LIMIT 1),"") AS file_name 
								FROM 	products_list AS plist ' . $networkCondList . '
								INNER JOIN users ON plist.user_id = users.user_id AND user_status = "active" 
								INNER JOIN prod_category AS pc ON pc.cat_id = plist.cat_id AND pc.is_deleted = "0" AND pc.is_approved = "Y" 
								WHERE 	plist.is_deleted = "0" AND plist.is_approved = "Y" ' . $privacyListCond . $catCond . ' 
								GROUP BY 
									pc.cat_name,users.email,users.user_id, users.username,plist.list_id,plist.cat_id,plist.sub_cat_id, plist.tag_id,plist.item_title, 
									plist.item_description,  plist.date_created 
							) as results';
						}
						else
						{
								//write query to get listings from products_wanted table - (2)
								$strSQL = 'SELECT results.cat_name,results.email, results.username,results.list_id,results.cat_id, results.sub_cat_id, results.tag_id,results.item_title, results.item_description, results.list_type, DAYNAME(results.date_created)AS day_name,DATE_FORMAT(results.date_created,"%M, %d %Y") AS day_desc,results.file_name,results.user_id 
							FROM( 
								SELECT 	 pc.cat_alias_name as cat_name,users.email,users.user_id, users.username, plist.wanted_id AS list_id,plist.cat_id,plist.sub_cat_id, plist.tag_id,plist.item_title, 
									 plist.item_description, "want" AS list_type,plist.date_created ,
									 IFNULL((SELECT CONCAT_WS(".",CONCAT_WS("_",lp.wanted_id,lp.photo_id),lp.file_name) FROM want_photos AS lp WHERE lp.wanted_id = plist.wanted_id LIMIT 1),"") AS file_name 
								FROM 	 products_wanted AS plist  ' . $networkCondWant . ' 
								INNER JOIN users ON plist.user_id = users.user_id AND user_status = "active" 
								INNER JOIN prod_category AS pc ON pc.cat_id = plist.cat_id AND pc.is_deleted = "0" AND pc.is_approved = "Y" 
								WHERE 	 plist.is_deleted = "0" AND plist.is_approved = "Y"  ' . $privacyWantCond . $catCond . ' 
								GROUP BY pc.cat_name,users.email, users.user_id,users.username,plist.wanted_id, plist.cat_id,plist.sub_cat_id,plist.tag_id,plist.item_title, 
									 plist.item_description, plist.date_created 
							) AS results 
							ORDER by results.date_created DESC';
						}
				} // End of mode
				$resListings = $this->db->query($strSQL);
				return $resListings->num_rows();
		} // End of getHomeListings()
		function searchListings($networkId = '', $catId = '', $subCatCode = '', $mode = '', $txtSearch = '', $criteriaA = '', $criteriaB = '', $criteriaC = '', $start = '', $limit = '')
		{
				$networkCondList = '';
				$networkCondWant = '';
				$privacyListCond = '';
				$privacyWantCond = '';
				$catCond = '';
				if (trim($catId) != '') $catCond = ' AND plist.cat_id = ' . $catId;
				if ($networkId > 0)
				{
						$networkCondList = ' INNER JOIN list_networks as lnt ON lnt.list_id = plist.list_id and lnt.network_id = "' . $networkId . '" ';
						$networkCondWant = ' INNER JOIN want_networks as lnt ON lnt.wanted_id = plist.wanted_id and lnt.network_id = "' . $networkId . '" ';
				}
				else //Else part of networkid > 0

				{
						// write query with privacy policy filter only and avoid network filter
						$privacyListCond = ' AND (plist.privacy_list_flag = "Y" OR plist.user_id = "' . $this->userId . '" )';
						$privacyWantCond = ' AND (plist.privacy_want_flag = "Y" OR plist.user_id = "' . $this->userId . '" )';
				} // End of networkid > 0
				$subCatCodeCond = '';
				if ($subCatCode != '') $subCatCodeCond = ' AND plist.tag_id = ' . $this->db->escape($subCatCode);
				$txtSearchCond = '';
				if ($txtSearch != '') $txtSearchCond = ' AND ( plist.item_title like "%' . ($txtSearch) . '%" OR plist.item_description like "%' . ($txtSearch) . '%")';
				$criteriaABCond = '';
				if (ereg('^[0-9]+$', $criteriaA) && ereg('^[0-9]+$', $criteriaB)) $criteriaABCond = " AND (IFNULL(plist.item_cost,0) Between " . $criteriaA . " AND " . $criteriaB . ")";
				$criteriaCCond = '';
				if (trim($criteriaC) != '') $criteriaCCond = " AND plist.item_type = '" . $criteriaC . "'";
				if (trim($mode) == '')
				{
						// write query to get All kind of listings - (2)
						$strSQL = ' SELECT results.cat_name,results.email, results.username,results.list_id,results.cat_id, results.sub_cat_id, results.tag_id,results.item_title, results.item_description, results.list_type, DAYNAME(results.date_created)AS day_name,DATE_FORMAT(results.date_created,"%M, %d %Y") AS day_desc,results.file_name,results.user_id 
						FROM( 
							SELECT  pc.cat_name,users.email,users.user_id, users.username,plist.list_id,plist.cat_id,plist.sub_cat_id, plist.tag_id,plist.item_title, 	
								plist.item_description	, "list" AS list_type,plist.date_created,
								IFNULL((SELECT CONCAT_WS(".",CONCAT_WS("_",lp.list_id,lp.photo_id),lp.file_name) FROM list_photos AS lp WHERE lp.list_id = plist.list_id LIMIT 1),"") AS file_name 
							FROM 	products_list AS plist ' . $networkCondList . ' 
							INNER JOIN users ON plist.user_id = users.user_id AND user_status = "active" 
							INNER JOIN prod_category AS pc ON pc.cat_id = plist.cat_id AND pc.is_deleted = "0" AND pc.is_approved = "Y" 
							WHERE 	plist.is_deleted = "0" AND plist.is_approved = "Y" ' . $privacyListCond . $catCond . $subCatCodeCond . $txtSearchCond . $criteriaABCond . $criteriaCCond . ' 
							GROUP BY 
								pc.cat_name,users.email,users.user_id, users.username,plist.list_id,plist.cat_id,plist.sub_cat_id, plist.tag_id,plist.item_title, 
								plist.item_description,  plist.date_created 
							UNION ALL 
							SELECT 	 pc.cat_alias_name as cat_name,users.email,users.user_id, users.username, plist.wanted_id AS list_id,plist.cat_id,plist.sub_cat_id, plist.tag_id,plist.item_title, 
								 plist.item_description, "want" AS list_type,plist.date_created ,
								 IFNULL((SELECT CONCAT_WS(".",CONCAT_WS("_",lp.wanted_id,lp.photo_id),lp.file_name) FROM want_photos AS lp WHERE lp.wanted_id = plist.wanted_id LIMIT 1),"") AS file_name 
							FROM 	 products_wanted AS plist ' . $networkCondWant . ' 
							INNER JOIN users ON plist.user_id = users.user_id AND user_status = "active" 
							INNER JOIN prod_category AS pc ON pc.cat_id = plist.cat_id AND pc.is_deleted = "0" AND pc.is_approved = "Y" 
							WHERE 	 plist.is_deleted = "0" AND plist.is_approved = "Y" ' . $privacyWantCond . $catCond . $subCatCodeCond . $txtSearchCond . $criteriaABCond . $criteriaCCond . ' 
							GROUP BY pc.cat_name,users.email, users.user_id,users.username,plist.wanted_id, plist.cat_id,plist.sub_cat_id,plist.tag_id,plist.item_title, 
								 plist.item_description, plist.date_created  
						) AS results 
						ORDER by results.date_created DESC ';
				}
				else //Else part of Mode

				{
						if ($mode == 'list')
						{
								//write query to get listings from products_list table - (2)
								$strSQL = 'SELECT results.cat_name,results.email, results.username,results.list_id,results.cat_id, results.sub_cat_id, results.tag_id,results.item_title, results.item_description, results.list_type, DAYNAME(results.date_created)AS day_name,DATE_FORMAT(results.date_created,"%M, %d %Y") AS day_desc,results.file_name,results.user_id 
							FROM( 
								SELECT  pc.cat_name,users.email,users.user_id, users.username,plist.list_id,plist.cat_id,plist.sub_cat_id, plist.tag_id,plist.item_title, 	
									plist.item_description	, "list" AS list_type,plist.date_created,
									IFNULL((SELECT CONCAT_WS(".",CONCAT_WS("_",lp.list_id,lp.photo_id),lp.file_name) FROM list_photos AS lp WHERE lp.list_id = plist.list_id LIMIT 1),"") AS file_name 
								FROM 	products_list AS plist ' . $networkCondList . '
								INNER JOIN users ON plist.user_id = users.user_id AND user_status = "active" 
								INNER JOIN prod_category AS pc ON pc.cat_id = plist.cat_id AND pc.is_deleted = "0" AND pc.is_approved = "Y" 
								WHERE 	plist.is_deleted = "0" AND plist.is_approved = "Y" ' . $privacyListCond . $catCond . $subCatCodeCond . $txtSearchCond . $criteriaABCond . $criteriaCCond . ' 
								GROUP BY 
									pc.cat_name,users.email,users.user_id, users.username,plist.list_id,plist.cat_id,plist.sub_cat_id, plist.tag_id,plist.item_title, 
									plist.item_description,  plist.date_created 
							) as results';
						}
						else
						{
								//write query to get listings from products_wanted table - (2)
								$strSQL = 'SELECT results.cat_name,results.email, results.username,results.list_id,results.cat_id, results.sub_cat_id, results.tag_id,results.item_title, results.item_description, results.list_type, DAYNAME(results.date_created)AS day_name,DATE_FORMAT(results.date_created,"%M, %d %Y") AS day_desc,results.file_name,results.user_id 
							FROM( 
								SELECT 	 pc.cat_alias_name as cat_name,users.email,users.user_id, users.username, plist.wanted_id AS list_id,plist.cat_id,plist.sub_cat_id, plist.tag_id,plist.item_title, 
									 plist.item_description, "want" AS list_type,plist.date_created ,
									 IFNULL((SELECT CONCAT_WS(".",CONCAT_WS("_",lp.wanted_id,lp.photo_id),lp.file_name) FROM want_photos AS lp WHERE lp.wanted_id = plist.wanted_id LIMIT 1),"") AS file_name 
								FROM 	 products_wanted AS plist  ' . $networkCondWant . ' 
								INNER JOIN users ON plist.user_id = users.user_id AND user_status = "active" 
								INNER JOIN prod_category AS pc ON pc.cat_id = plist.cat_id AND pc.is_deleted = "0" AND pc.is_approved = "Y" 
								WHERE 	 plist.is_deleted = "0" AND plist.is_approved = "Y"  ' . $privacyWantCond . $catCond . $subCatCodeCond . $txtSearchCond . $criteriaABCond . $criteriaCCond . ' 
								GROUP BY pc.cat_name,users.email, users.user_id,users.username,plist.wanted_id, plist.cat_id,plist.sub_cat_id,plist.tag_id,plist.item_title, 
									 plist.item_description, plist.date_created 
							) AS results 
							ORDER by results.date_created DESC';
						}
				} // End of mode
				if (ereg('^[0-9]+$', $start) && ereg('^[0-9]+$', $limit))
				{
						$strSQL .= ' LIMIT ' . $start . ', ' . $limit;
				}
				$resListings = $this->db->query($strSQL);
				$listingArray = array();
				if ($resListings->num_rows() > 0)
				{
						foreach ($resListings->result_array() as $resRow)
						{
								$strKey = $resRow['list_id'] . '_' . $resRow['list_type'];
								$listingArray[$strKey] = $resRow;
								$listingArray[$strKey]['cat_info'] = $this->getCatInfo($resRow['tag_id']);
								$listingArray[$strKey]['avatar'] = $this->getMarketplaceImage($resRow['list_id'], $resRow['list_type'], true);
						}
				}
				return $listingArray;
		} // End of searchListings()
		function searchListingsCount($networkId = '', $catId = '', $subCatCode = '', $mode = '', $txtSearch = '', $criteriaA = '', $criteriaB = '', $criteriaC = '')
		{
				$networkCondList = '';
				$networkCondWant = '';
				$privacyListCond = '';
				$privacyWantCond = '';
				$catCond = '';
				if (trim($catId) != '') $catCond = ' AND plist.cat_id = ' . $catId;
				if ($networkId > 0)
				{
						$networkCondList = ' INNER JOIN list_networks as lnt ON lnt.list_id = plist.list_id and lnt.network_id = "' . $networkId . '" ';
						$networkCondWant = ' INNER JOIN want_networks as lnt ON lnt.wanted_id = plist.wanted_id and lnt.network_id = "' . $networkId . '" ';
				}
				else //Else part of networkid > 0

				{
						// write query with privacy policy filter only and avoid network filter
						$privacyListCond = ' AND (plist.privacy_list_flag = "Y" OR plist.user_id = "' . $this->userId . '" )';
						$privacyWantCond = ' AND (plist.privacy_want_flag = "Y" OR plist.user_id = "' . $this->userId . '" )';
				} // End of networkid > 0
				$subCatCodeCond = '';
				if ($subCatCode != '') $subCatCodeCond = ' AND plist.tag_id = ' . $this->db->escape($subCatCode);
				$txtSearchCond = '';
				if ($txtSearch != '') $txtSearchCond = ' AND ( plist.item_title like "%' . ($txtSearch) . '%" OR plist.item_description like "%' . ($txtSearch) . '%")';
				$criteriaABCond = '';
				if (ereg('^[0-9]+$', $criteriaA) && ereg('^[0-9]+$', $criteriaB)) $criteriaABCond = " AND (IFNULL(plist.item_cost,0) Between " . $criteriaA . " AND " . $criteriaB . ")";
				$criteriaCCond = '';
				if (trim($criteriaC) != '') $criteriaCCond = " AND plist.item_type = '" . $criteriaC . "'";
				if (trim($mode) == '')
				{
						// write query to get All kind of listings - (2)
						$strSQL = ' SELECT results.cat_name,results.email, results.username,results.list_id,results.cat_id, results.sub_cat_id, results.tag_id,results.item_title, results.item_description, results.list_type, DAYNAME(results.date_created)AS day_name,DATE_FORMAT(results.date_created,"%M, %d %Y") AS day_desc,results.file_name,results.user_id 
						FROM( 
							SELECT  pc.cat_name,users.email,users.user_id, users.username,plist.list_id,plist.cat_id,plist.sub_cat_id, plist.tag_id,plist.item_title, 	
								plist.item_description	, "list" AS list_type,plist.date_created,
								IFNULL((SELECT CONCAT_WS(".",CONCAT_WS("_",lp.list_id,lp.photo_id),lp.file_name) FROM list_photos AS lp WHERE lp.list_id = plist.list_id LIMIT 1),"") AS file_name 
							FROM 	products_list AS plist ' . $networkCondList . ' 
							INNER JOIN users ON plist.user_id = users.user_id AND user_status = "active" 
							INNER JOIN prod_category AS pc ON pc.cat_id = plist.cat_id AND pc.is_deleted = "0" AND pc.is_approved = "Y" 
							WHERE 	plist.is_deleted = "0" AND plist.is_approved = "Y" ' . $privacyListCond . $catCond . $subCatCodeCond . $txtSearchCond . $criteriaABCond . $criteriaCCond . ' 
							GROUP BY 
								pc.cat_name,users.email,users.user_id, users.username,plist.list_id,plist.cat_id,plist.sub_cat_id, plist.tag_id,plist.item_title, 
								plist.item_description,  plist.date_created 
							UNION ALL 
							SELECT 	 pc.cat_alias_name as cat_name,users.email,users.user_id, users.username, plist.wanted_id AS list_id,plist.cat_id,plist.sub_cat_id, plist.tag_id,plist.item_title, 
								 plist.item_description, "want" AS list_type,plist.date_created ,
								 IFNULL((SELECT CONCAT_WS(".",CONCAT_WS("_",lp.wanted_id,lp.photo_id),lp.file_name) FROM want_photos AS lp WHERE lp.wanted_id = plist.wanted_id LIMIT 1),"") AS file_name 
							FROM 	 products_wanted AS plist ' . $networkCondWant . ' 
							INNER JOIN users ON plist.user_id = users.user_id AND user_status = "active" 
							INNER JOIN prod_category AS pc ON pc.cat_id = plist.cat_id AND pc.is_deleted = "0" AND pc.is_approved = "Y" 
							WHERE 	 plist.is_deleted = "0" AND plist.is_approved = "Y" ' . $privacyWantCond . $catCond . $subCatCodeCond . $txtSearchCond . $criteriaABCond . $criteriaCCond . ' 
							GROUP BY pc.cat_name,users.email, users.user_id,users.username,plist.wanted_id, plist.cat_id,plist.sub_cat_id,plist.tag_id,plist.item_title, 
								 plist.item_description, plist.date_created  
						) AS results 
						ORDER by results.date_created DESC ';
				}
				else //Else part of Mode

				{
						if ($mode == 'list')
						{
								//write query to get listings from products_list table - (2)
								$strSQL = 'SELECT results.cat_name,results.email, results.username,results.list_id,results.cat_id, results.sub_cat_id, results.tag_id,results.item_title, results.item_description, results.list_type, DAYNAME(results.date_created)AS day_name,DATE_FORMAT(results.date_created,"%M, %d %Y") AS day_desc,results.file_name,results.user_id 
							FROM( 
								SELECT  pc.cat_name,users.email,users.user_id, users.username,plist.list_id,plist.cat_id,plist.sub_cat_id, plist.tag_id,plist.item_title, 	
									plist.item_description	, "list" AS list_type,plist.date_created,
									IFNULL((SELECT CONCAT_WS(".",CONCAT_WS("_",lp.list_id,lp.photo_id),lp.file_name) FROM list_photos AS lp WHERE lp.list_id = plist.list_id LIMIT 1),"") AS file_name 
								FROM 	products_list AS plist ' . $networkCondList . '
								INNER JOIN users ON plist.user_id = users.user_id AND user_status = "active" 
								INNER JOIN prod_category AS pc ON pc.cat_id = plist.cat_id AND pc.is_deleted = "0" AND pc.is_approved = "Y" 
								WHERE 	plist.is_deleted = "0" AND plist.is_approved = "Y" ' . $privacyListCond . $catCond . $subCatCodeCond . $txtSearchCond . $criteriaABCond . $criteriaCCond . ' 
								GROUP BY 
									pc.cat_name,users.email,users.user_id, users.username,plist.list_id,plist.cat_id,plist.sub_cat_id, plist.tag_id,plist.item_title, 
									plist.item_description,  plist.date_created 
							) as results';
						}
						else
						{
								//write query to get listings from products_wanted table - (2)
								$strSQL = 'SELECT results.cat_name,results.email, results.username,results.list_id,results.cat_id, results.sub_cat_id, results.tag_id,results.item_title, results.item_description, results.list_type, DAYNAME(results.date_created)AS day_name,DATE_FORMAT(results.date_created,"%M, %d %Y") AS day_desc,results.file_name,results.user_id 
							FROM( 
								SELECT 	 pc.cat_alias_name as cat_name,users.email,users.user_id, users.username, plist.wanted_id AS list_id,plist.cat_id,plist.sub_cat_id, plist.tag_id,plist.item_title, 
									 plist.item_description, "want" AS list_type,plist.date_created ,
									 IFNULL((SELECT CONCAT_WS(".",CONCAT_WS("_",lp.wanted_id,lp.photo_id),lp.file_name) FROM want_photos AS lp WHERE lp.wanted_id = plist.wanted_id LIMIT 1),"") AS file_name 
								FROM 	 products_wanted AS plist  ' . $networkCondWant . ' 
								INNER JOIN users ON plist.user_id = users.user_id AND user_status = "active" 
								INNER JOIN prod_category AS pc ON pc.cat_id = plist.cat_id AND pc.is_deleted = "0" AND pc.is_approved = "Y" 
								WHERE 	 plist.is_deleted = "0" AND plist.is_approved = "Y"  ' . $privacyWantCond . $catCond . $subCatCodeCond . $txtSearchCond . $criteriaABCond . $criteriaCCond . ' 
								GROUP BY pc.cat_name,users.email, users.user_id,users.username,plist.wanted_id, plist.cat_id,plist.sub_cat_id,plist.tag_id,plist.item_title, 
									 plist.item_description, plist.date_created 
							) AS results 
							ORDER by results.date_created DESC';
						}
				} // End of mode
				$resListings = $this->db->query($strSQL);
				return $resListings->num_rows();
		} // End of searchListings()
		function getUserListings($userIds, $catId, $mode, $start = '', $limit = '')
		{
				$networkCondList = '';
				$networkCondWant = '';
				$privacyListCond = '';
				$privacyWantCond = '';
				$catCond = '';
				if (trim($mode) == 'n')
				{
						// write query to get All kind of listings - (2)
						$strSQL = ' SELECT results.cat_name,results.email, results.username,results.list_id,results.cat_id, results.sub_cat_id, results.tag_id,results.item_title, results.item_description, results.list_type, DAYNAME(results.date_created)AS day_name,DATE_FORMAT(results.date_created,"%M, %d %Y") AS day_desc,results.file_name,results.user_id 
						FROM( 
							SELECT  pc.cat_name,users.email,users.user_id, users.username,plist.list_id,plist.cat_id,plist.sub_cat_id, plist.tag_id,plist.item_title, 	
								plist.item_description	, "list" AS list_type,plist.date_created,
								IFNULL((SELECT CONCAT_WS(".",CONCAT_WS("_",lp.list_id,lp.photo_id),lp.file_name) FROM list_photos AS lp WHERE lp.list_id = plist.list_id LIMIT 1),"") AS file_name 
							FROM 	products_list AS plist 
							INNER JOIN users ON plist.user_id = users.user_id AND user_status = "active" 
							INNER JOIN prod_category AS pc ON pc.cat_id = plist.cat_id AND pc.is_deleted = "0" AND pc.is_approved = "Y" 
							WHERE 	plist.is_deleted = "0" AND plist.is_approved = "Y"   AND plist.user_id in (' . $userIds . ') 
							GROUP BY 
								pc.cat_name,users.email,users.user_id, users.username,plist.list_id,plist.cat_id,plist.sub_cat_id, plist.tag_id,plist.item_title, 
								plist.item_description,  plist.date_created 
							UNION ALL 
							SELECT 	 pc.cat_alias_name as cat_name,users.email,users.user_id, users.username, plist.wanted_id AS list_id,plist.cat_id,plist.sub_cat_id, plist.tag_id,plist.item_title, 
								 plist.item_description, "want" AS list_type,plist.date_created ,
								 IFNULL((SELECT CONCAT_WS(".",CONCAT_WS("_",lp.wanted_id,lp.photo_id),lp.file_name) FROM want_photos AS lp WHERE lp.wanted_id = plist.wanted_id LIMIT 1),"") AS file_name 
							FROM 	 products_wanted AS plist  
							INNER JOIN users ON plist.user_id = users.user_id AND user_status = "active"  
							INNER JOIN prod_category AS pc ON pc.cat_id = plist.cat_id AND pc.is_deleted = "0" AND pc.is_approved = "Y" 
							WHERE 	 plist.is_deleted = "0" AND plist.is_approved = "Y"  AND plist.user_id in (' . $userIds . ') 
							GROUP BY pc.cat_name,users.email, users.user_id,users.username,plist.wanted_id, plist.cat_id,plist.sub_cat_id,plist.tag_id,plist.item_title, 
								 plist.item_description, plist.date_created  
						) AS results 
						ORDER by results.date_created DESC ';
				}
				else //Else part of Mode

				{
						if ($mode == 'list')
						{
								//write query to get listings from products_list table - (2)
								$strSQL = 'SELECT results.cat_name,results.email, results.username,results.list_id,results.cat_id, results.sub_cat_id, results.tag_id,results.item_title, results.item_description, results.list_type, DAYNAME(results.date_created)AS day_name,DATE_FORMAT(results.date_created,"%M, %d %Y") AS day_desc,results.file_name,results.user_id 
							FROM( 
								SELECT  pc.cat_name,users.email,users.user_id, users.username,plist.list_id,plist.cat_id,plist.sub_cat_id, plist.tag_id,plist.item_title, 	
									plist.item_description	, "list" AS list_type,plist.date_created,
									IFNULL((SELECT CONCAT_WS(".",CONCAT_WS("_",lp.list_id,lp.photo_id),lp.file_name) FROM list_photos AS lp WHERE lp.list_id = plist.list_id LIMIT 1),"") AS file_name 
								FROM 	products_list AS plist 
								INNER JOIN users ON plist.user_id = users.user_id AND user_status = "active" 
								INNER JOIN prod_category AS pc ON pc.cat_id = plist.cat_id AND pc.is_deleted = "0" AND pc.is_approved = "Y" 
								WHERE 	plist.is_deleted = "0" AND plist.is_approved = "Y"  AND plist.user_id in (' . $userIds . ') 
								GROUP BY 
									pc.cat_name,users.email,users.user_id, users.username,plist.list_id,plist.cat_id,plist.sub_cat_id, plist.tag_id,plist.item_title, 
									plist.item_description,  plist.date_created 
							) as results';
						}
						else
						{
								//write query to get listings from products_wanted table - (2)
								$strSQL = 'SELECT results.cat_name,results.email, results.username,results.list_id,results.cat_id, results.sub_cat_id, results.tag_id,results.item_title, results.item_description, results.list_type, DAYNAME(results.date_created)AS day_name,DATE_FORMAT(results.date_created,"%M, %d %Y") AS day_desc,results.file_name,results.user_id 
							FROM( 
								SELECT 	 pc.cat_alias_name as cat_name,users.email,users.user_id, users.username, plist.wanted_id AS list_id,plist.cat_id,plist.sub_cat_id, plist.tag_id,plist.item_title, 
									 plist.item_description, "want" AS list_type,plist.date_created ,
									 IFNULL((SELECT CONCAT_WS(".",CONCAT_WS("_",lp.wanted_id,lp.photo_id),lp.file_name) FROM want_photos AS lp WHERE lp.wanted_id = plist.wanted_id LIMIT 1),"") AS file_name 
								FROM 	 products_wanted AS plist  
								INNER JOIN users ON plist.user_id = users.user_id AND user_status = "active" 
								INNER JOIN prod_category AS pc ON pc.cat_id = plist.cat_id AND pc.is_deleted = "0" AND pc.is_approved = "Y" 
								WHERE 	 plist.is_deleted = "0" AND plist.is_approved = "Y"   AND plist.user_id in (' . $userIds . ')  
								GROUP BY pc.cat_name,users.email, users.user_id,users.username,plist.wanted_id, plist.cat_id,plist.sub_cat_id,plist.tag_id,plist.item_title, 
									 plist.item_description, plist.date_created 
							) AS results 
							ORDER by results.date_created DESC';
						}
				} // End of mode
				if (ereg('^[0-9]+$', $start) && ereg('^[0-9]+$', $limit))
				{
						$strSQL .= ' LIMIT ' . $start . ', ' . $limit;
				}
				//echo $strSQL;
				$resListings = $this->db->query($strSQL);
				$listingArray = array();
				if ($resListings->num_rows() > 0)
				{
						foreach ($resListings->result_array() as $resRow)
						{
								$strKey = $resRow['list_id'] . '_' . $resRow['list_type'];
								$listingArray[$strKey] = $resRow;
								$listingArray[$strKey]['cat_info'] = $this->getCatInfo($resRow['tag_id']);
								$listingArray[$strKey]['avatar'] = $this->getMarketplaceImage($resRow['list_id'], $resRow['list_type'], true);
						}
				}
				return $listingArray;
		} // End of getHomeListings()
		function getProfileListings($userIds, $start = '', $limit = '')
		{
				$networkCondList = '';
				$networkCondWant = '';
				$privacyListCond = '';
				$privacyWantCond = '';
				if ($userIds !== $this->userId)
				{
						$networks = $this->networkModel->getUserNetwork($this->userId);
						$networkIds = implode(',', array_keys($networks));
						if ($networkIds != '')
						{
								$networkCondList = ' INNER JOIN list_networks as lnt ON lnt.list_id = plist.list_id and lnt.network_id IN (' . $networkIds . ')';
								$networkCondWant = ' INNER JOIN want_networks as lnt ON lnt.wanted_id = plist.wanted_id and lnt.network_id IN (' . $networkIds . ')';
						}
						else //Else part of networkid > 0

						{
								// write query with privacy policy filter only and avoid network filter
								$privacyListCond = ' AND (plist.privacy_list_flag = "Y" AND plist.user_id = "' . $userIds . '" )';
								$privacyWantCond = ' AND (plist.privacy_want_flag = "Y" AND plist.user_id = "' . $userIds . '" )';
						} // End of networkid > 0
				}
				$strSQL = ' SELECT results.cat_name,results.email, results.username,results.list_id,results.cat_id, results.sub_cat_id, results.tag_id,results.item_title, results.item_description, results.list_type, DAYNAME(results.date_created)AS day_name,DATE_FORMAT(results.date_created,"%M, %d %Y") AS day_desc,results.file_name,results.user_id 
						FROM( 
							SELECT  pc.cat_name,users.email,users.user_id, users.username,plist.list_id,plist.cat_id,plist.sub_cat_id, plist.tag_id,plist.item_title, 	
								plist.item_description	, "list" AS list_type,plist.date_created,
								IFNULL((SELECT CONCAT_WS(".",CONCAT_WS("_",lp.list_id,lp.photo_id),lp.file_name) FROM list_photos AS lp WHERE lp.list_id = plist.list_id LIMIT 1),"") AS file_name 
							FROM 	products_list AS plist ' . $networkCondList . '
							INNER JOIN users ON plist.user_id = users.user_id AND user_status = "active" 
							INNER JOIN prod_category AS pc ON pc.cat_id = plist.cat_id AND pc.is_deleted = "0" AND pc.is_approved = "Y" 
							WHERE UPPER(TRIM(plist.profile_list_flag)) = "Y" AND plist.is_deleted = "0" AND plist.is_approved = "Y"   AND plist.user_id in (' . $userIds . ') ' . $privacyListCond . '
							GROUP BY 
								pc.cat_name,users.email,users.user_id, users.username,plist.list_id,plist.cat_id,plist.sub_cat_id, plist.tag_id,plist.item_title, 
								plist.item_description,  plist.date_created 
							UNION ALL 
							SELECT 	 pc.cat_alias_name as cat_name,users.email,users.user_id, users.username, plist.wanted_id AS list_id,plist.cat_id,plist.sub_cat_id, plist.tag_id,plist.item_title, 
								 plist.item_description, "want" AS list_type,plist.date_created ,
								 IFNULL((SELECT CONCAT_WS(".",CONCAT_WS("_",lp.wanted_id,lp.photo_id),lp.file_name) FROM want_photos AS lp WHERE lp.wanted_id = plist.wanted_id LIMIT 1),"") AS file_name 
							FROM 	 products_wanted AS plist  ' . $networkCondWant . '
							INNER JOIN users ON plist.user_id = users.user_id AND user_status = "active"  
							INNER JOIN prod_category AS pc ON pc.cat_id = plist.cat_id AND pc.is_deleted = "0" AND pc.is_approved = "Y" 
							WHERE UPPER(TRIM(plist.profile_want_flag)) = "Y" AND plist.is_deleted = "0" AND plist.is_approved = "Y"  AND plist.user_id in (' . $userIds . ') ' . $privacyWantCond . ' 
							GROUP BY pc.cat_name,users.email, users.user_id,users.username,plist.wanted_id, plist.cat_id,plist.sub_cat_id,plist.tag_id,plist.item_title, 
								 plist.item_description, plist.date_created  
						) AS results 
						ORDER by results.date_created DESC ';
				if (ereg('^[0-9]+$', $start) && ereg('^[0-9]+$', $limit))
				{
						$strSQL .= ' LIMIT ' . $start . ', ' . $limit;
				}
				$resListings = $this->db->query($strSQL);
				$listingArray = array();
				if ($resListings->num_rows() > 0)
				{
						foreach ($resListings->result_array() as $resRow)
						{
								$strKey = $resRow['list_id'] . '_' . $resRow['list_type'];
								$listingArray[$strKey] = $resRow;
								$listingArray[$strKey]['cat_info'] = $this->getCatInfo($resRow['tag_id']);
								$listingArray[$strKey]['avatar'] = $this->getMarketplaceImage($resRow['list_id'], $resRow['list_type'], true);
						}
				}
				return $listingArray;
		} // End of getHomeListings()
		function getProfileListingsCount($userIds)
		{
				$networkCondList = '';
				$networkCondWant = '';
				$privacyListCond = '';
				$privacyWantCond = '';
				if ($userIds !== $this->userId)
				{
						$networks = $this->networkModel->getUserNetwork($this->userId);
						$networkIds = implode(',', array_keys($networks));
						if ($networkIds != '')
						{
								$networkCondList = ' INNER JOIN list_networks as lnt ON lnt.list_id = plist.list_id and lnt.network_id IN (' . $networkIds . ')';
								$networkCondWant = ' INNER JOIN want_networks as lnt ON lnt.wanted_id = plist.wanted_id and lnt.network_id IN (' . $networkIds . ')';
						}
						else //Else part of networkid > 0

						{
								// write query with privacy policy filter only and avoid network filter
								$privacyListCond = ' AND (plist.privacy_list_flag = "Y" AND plist.user_id = "' . $userIds . '" )';
								$privacyWantCond = ' AND (plist.privacy_want_flag = "Y" AND plist.user_id = "' . $userIds . '" )';
						} // End of networkid > 0
				}
				$strSQL = ' SELECT results.cat_name,results.email, results.username,results.list_id,results.cat_id, results.sub_cat_id, results.tag_id,results.item_title, results.item_description, results.list_type, DAYNAME(results.date_created)AS day_name,DATE_FORMAT(results.date_created,"%M, %d %Y") AS day_desc,results.file_name,results.user_id 
						FROM( 
							SELECT  pc.cat_name,users.email,users.user_id, users.username,plist.list_id,plist.cat_id,plist.sub_cat_id, plist.tag_id,plist.item_title, 	
								plist.item_description	, "list" AS list_type,plist.date_created,
								IFNULL((SELECT CONCAT_WS(".",CONCAT_WS("_",lp.list_id,lp.photo_id),lp.file_name) FROM list_photos AS lp WHERE lp.list_id = plist.list_id LIMIT 1),"") AS file_name 
							FROM 	products_list AS plist ' . $networkCondList . '
							INNER JOIN users ON plist.user_id = users.user_id AND user_status = "active" 
							INNER JOIN prod_category AS pc ON pc.cat_id = plist.cat_id AND pc.is_deleted = "0" AND pc.is_approved = "Y" 
							WHERE UPPER(TRIM(plist.profile_list_flag)) = "Y" AND plist.is_deleted = "0" AND plist.is_approved = "Y"   AND plist.user_id in (' . $userIds . ') ' . $privacyListCond . '
							GROUP BY 
								pc.cat_name,users.email,users.user_id, users.username,plist.list_id,plist.cat_id,plist.sub_cat_id, plist.tag_id,plist.item_title, 
								plist.item_description,  plist.date_created 
							UNION ALL 
							SELECT 	 pc.cat_alias_name as cat_name,users.email,users.user_id, users.username, plist.wanted_id AS list_id,plist.cat_id,plist.sub_cat_id, plist.tag_id,plist.item_title, 
								 plist.item_description, "want" AS list_type,plist.date_created ,
								 IFNULL((SELECT CONCAT_WS(".",CONCAT_WS("_",lp.wanted_id,lp.photo_id),lp.file_name) FROM want_photos AS lp WHERE lp.wanted_id = plist.wanted_id LIMIT 1),"") AS file_name 
							FROM 	 products_wanted AS plist  ' . $networkCondWant . '
							INNER JOIN users ON plist.user_id = users.user_id AND user_status = "active"  
							INNER JOIN prod_category AS pc ON pc.cat_id = plist.cat_id AND pc.is_deleted = "0" AND pc.is_approved = "Y" 
							WHERE UPPER(TRIM(plist.profile_want_flag)) = "Y" AND plist.is_deleted = "0" AND plist.is_approved = "Y"  AND plist.user_id in (' . $userIds . ') ' . $privacyWantCond . ' 
							GROUP BY pc.cat_name,users.email, users.user_id,users.username,plist.wanted_id, plist.cat_id,plist.sub_cat_id,plist.tag_id,plist.item_title, 
								 plist.item_description, plist.date_created  
						) AS results 
						ORDER by results.date_created DESC ';
				$resListings = $this->db->query($strSQL);
				return $resListings->num_rows();
		} // End of getHomeListings()
		function getUserListingsCount($userIds, $catId, $mode)
		{
				$networkCondList = '';
				$networkCondWant = '';
				$privacyListCond = '';
				$privacyWantCond = '';
				$catCond = '';
				if (trim($mode) == 'n')
				{
						// write query to get All kind of listings - (2)
						$strSQL = ' SELECT results.cat_name,results.email, results.username,results.list_id,results.cat_id, results.sub_cat_id, results.tag_id,results.item_title, results.item_description, results.list_type, DAYNAME(results.date_created)AS day_name,DATE_FORMAT(results.date_created,"%M, %d %Y") AS day_desc,results.file_name,results.user_id 
						FROM( 
							SELECT  pc.cat_name,users.email,users.user_id, users.username,plist.list_id,plist.cat_id,plist.sub_cat_id, plist.tag_id,plist.item_title, 	
								plist.item_description	, "list" AS list_type,plist.date_created,
								IFNULL((SELECT CONCAT_WS(".",CONCAT_WS("_",lp.list_id,lp.photo_id),lp.file_name) FROM list_photos AS lp WHERE lp.list_id = plist.list_id LIMIT 1),"") AS file_name 
							FROM 	products_list AS plist 
							INNER JOIN users ON plist.user_id = users.user_id AND user_status = "active" 
							INNER JOIN prod_category AS pc ON pc.cat_id = plist.cat_id AND pc.is_deleted = "0" AND pc.is_approved = "Y" 
							WHERE 	plist.is_deleted = "0" AND plist.is_approved = "Y"   AND plist.user_id in (' . $userIds . ') 
							GROUP BY 
								pc.cat_name,users.email,users.user_id, users.username,plist.list_id,plist.cat_id,plist.sub_cat_id, plist.tag_id,plist.item_title, 
								plist.item_description,  plist.date_created 
							UNION ALL 
							SELECT 	 pc.cat_alias_name as cat_name,users.email,users.user_id, users.username, plist.wanted_id AS list_id,plist.cat_id,plist.sub_cat_id, plist.tag_id,plist.item_title, 
								 plist.item_description, "want" AS list_type,plist.date_created ,
								 IFNULL((SELECT CONCAT_WS(".",CONCAT_WS("_",lp.wanted_id,lp.photo_id),lp.file_name) FROM want_photos AS lp WHERE lp.wanted_id = plist.wanted_id LIMIT 1),"") AS file_name 
							FROM 	 products_wanted AS plist  
							INNER JOIN users ON plist.user_id = users.user_id AND user_status = "active"  
							INNER JOIN prod_category AS pc ON pc.cat_id = plist.cat_id AND pc.is_deleted = "0" AND pc.is_approved = "Y" 
							WHERE 	 plist.is_deleted = "0" AND plist.is_approved = "Y"  AND plist.user_id in (' . $userIds . ') 
							GROUP BY pc.cat_name,users.email, users.user_id,users.username,plist.wanted_id, plist.cat_id,plist.sub_cat_id,plist.tag_id,plist.item_title, 
								 plist.item_description, plist.date_created  
						) AS results 
						ORDER by results.date_created DESC ';
				}
				else //Else part of Mode

				{
						if ($mode == 'list')
						{
								//write query to get listings from products_list table - (2)
								$strSQL = 'SELECT results.cat_name,results.email, results.username,results.list_id,results.cat_id, results.sub_cat_id, results.tag_id,results.item_title, results.item_description, results.list_type, DAYNAME(results.date_created)AS day_name,DATE_FORMAT(results.date_created,"%M, %d %Y") AS day_desc,results.file_name,results.user_id 
							FROM( 
								SELECT  pc.cat_name,users.email,users.user_id, users.username,plist.list_id,plist.cat_id,plist.sub_cat_id, plist.tag_id,plist.item_title, 	
									plist.item_description	, "list" AS list_type,plist.date_created,
									IFNULL((SELECT CONCAT_WS(".",CONCAT_WS("_",lp.list_id,lp.photo_id),lp.file_name) FROM list_photos AS lp WHERE lp.list_id = plist.list_id LIMIT 1),"") AS file_name 
								FROM 	products_list AS plist 
								INNER JOIN users ON plist.user_id = users.user_id AND user_status = "active" 
								INNER JOIN prod_category AS pc ON pc.cat_id = plist.cat_id AND pc.is_deleted = "0" AND pc.is_approved = "Y" 
								WHERE 	plist.is_deleted = "0" AND plist.is_approved = "Y"  AND plist.user_id in (' . $userIds . ') 
								GROUP BY 
									pc.cat_name,users.email,users.user_id, users.username,plist.list_id,plist.cat_id,plist.sub_cat_id, plist.tag_id,plist.item_title, 
									plist.item_description,  plist.date_created 
							) as results';
						}
						else
						{
								//write query to get listings from products_wanted table - (2)
								$strSQL = 'SELECT results.cat_name,results.email, results.username,results.list_id,results.cat_id, results.sub_cat_id, results.tag_id,results.item_title, results.item_description, results.list_type, DAYNAME(results.date_created)AS day_name,DATE_FORMAT(results.date_created,"%M, %d %Y") AS day_desc,results.file_name,results.user_id 
							FROM( 
								SELECT 	 pc.cat_alias_name as cat_name,users.email,users.user_id, users.username, plist.wanted_id AS list_id,plist.cat_id,plist.sub_cat_id, plist.tag_id,plist.item_title, 
									 plist.item_description, "want" AS list_type,plist.date_created ,
									 IFNULL((SELECT CONCAT_WS(".",CONCAT_WS("_",lp.wanted_id,lp.photo_id),lp.file_name) FROM want_photos AS lp WHERE lp.wanted_id = plist.wanted_id LIMIT 1),"") AS file_name 
								FROM 	 products_wanted AS plist  
								INNER JOIN users ON plist.user_id = users.user_id AND user_status = "active" 
								INNER JOIN prod_category AS pc ON pc.cat_id = plist.cat_id AND pc.is_deleted = "0" AND pc.is_approved = "Y" 
								WHERE 	 plist.is_deleted = "0" AND plist.is_approved = "Y"   AND plist.user_id in (' . $userIds . ')  
								GROUP BY pc.cat_name,users.email, users.user_id,users.username,plist.wanted_id, plist.cat_id,plist.sub_cat_id,plist.tag_id,plist.item_title, 
									 plist.item_description, plist.date_created 
							) AS results 
							ORDER by results.date_created DESC';
						}
				} // End of mode
				$resListings = $this->db->query($strSQL);
				return $resListings->num_rows();
		} // End of getHomeListings()
		function getNetworks($name)
		{
				$strSQL = 'SELECT network_id , IF(network_name = "", network_city,network_name) as network_name FROM networks WHERE (network_name like "%' . $name . '%" OR  network_city like "%' . $name . '%" ) AND   network_status = "enabled"  LIMIT 0,30';
				$networkQuery = $this->db->query($strSQL);
				$network = array();
				if ($networkQuery->num_rows() > 0)
				{
						foreach ($networkQuery->result_array() as $networkRow)
						{
								$network[$networkRow['network_id']] = $networkRow['network_name'];
						}
				}
				return $network;
		}
		function getCatInfo($subCatCode)
		{
				$catArray = array();
				if (strtoupper(trim($subCatCode)) == "JOB" || strtoupper(trim($subCatCode)) == 'FREE')
				{
						$strSql = "SELECT 	pcat.cat_id,'-1' as sub_cat_id, pcat.cat_name,
							pcat.cat_alias_name, pcat.cat_code
							FROM 	prod_category as pcat
							WHERE	pcat.cat_code = '" . $subCatCode . "' AND pcat.is_deleted = 0 and
									pcat.is_approved = 'Y'";
						$resCatInfo = $this->db->query($strSql);
						if ($resCatInfo->num_rows() > 0)
						{
								foreach ($resCatInfo->result_array() as $resRow)
								{
										$catArray = $resRow;
								}
						}
				}
				else
				{
						$strSql = "SELECT  	pcat.cat_id,pcat.cat_name,pscat.sub_cat_id,pscat.sub_cat_name,
										pcat.cat_alias_name,pscat.sub_cat_code,pcat.cat_code
							FROM 		prod_category AS pcat
							INNER JOIN 	prod_sub_category AS pscat ON pcat.cat_id = pscat.cat_id AND
										upper(trim(pscat.sub_cat_code)) = '" . trim($subCatCode) . "' AND
										pscat.is_deleted = 0 AND pscat.is_approved = 'Y'
							WHERE 		pcat.is_deleted = 0 AND pcat.is_approved = 'Y' ";
						$resCatInfo = $this->db->query($strSql);
						if ($resCatInfo->num_rows() > 0)
						{
								foreach ($resCatInfo->result_array() as $resRow)
								{
										$catArray[] = $resRow;
								}
						}
				}
				return $catArray;
		}
		function getListInfo($listId, $mode)
		{
				if ($mode == 'list')
				{
						$strSql = "SELECT DATE_FORMAT(date_created,'%M %d,  %Y') as daydesc, item_title,
								item_description,IFNULL(list_nt_ids,'') as nt_ids,user_id,'list' as list_type, tag_id,list_id
						FROM 	products_list
						WHERE 	list_id = " . $listId . " and is_deleted = '0' and is_approved = 'Y'";
				}
				else
				{
						$strSql = "SELECT DATE_FORMAT(date_created,'%M %d,  %Y') as daydesc, item_title,
									item_description,IFNULL(want_nt_ids,'') as nt_ids,user_id,'want' as list_type, tag_id,wanted_id as list_id 
							FROM 	products_wanted
							WHERE 	wanted_id = " . $listId . " and is_deleted = '0' and is_approved = 'Y'";
				}
				$resList = $this->db->query($strSql);
				$resArray = array();
				if ($resList->num_rows() > 0)
				{
						foreach ($resList->result_array() as $resRow)
						{
								$resArray[] = $resRow;
						}
				}
				return $resArray;
		}
		function getListNetworkIds($listId, $mode)
		{
				if ($mode == 'list')
				{
						$strSql = "SELECT pl.list_id, pl.user_id, lnt.network_id, IF(trim(nt.network_name) = '', nt.network_city , nt.network_name) as network_name ,'list' AS list_type
						FROM products_list AS pl
						INNER JOIN list_networks AS lnt ON lnt.list_id = pl.list_id AND pl.is_deleted = '0' AND pl.is_approved = 'Y'
						INNER JOIN networks AS nt ON nt.network_id = lnt.network_id 
						WHERE pl.is_deleted = '0' AND pl.is_approved = 'Y' AND pl.list_id = '" . $listId . "'";
				}
				else
				{
						$strSql = "SELECT pl.wanted_id, pl.user_id, lnt.network_id, IF(trim(nt.network_name) = '', nt.network_city , nt.network_name) as network_name ,'want' AS list_type
						FROM products_wanted AS pl
						INNER JOIN want_networks AS lnt ON lnt.wanted_id = pl.wanted_id AND pl.is_deleted = '0' AND pl.is_approved = 'Y'
						INNER JOIN networks AS nt ON nt.network_id = lnt.network_id 
						WHERE pl.is_deleted = '0' AND pl.is_approved = 'Y' AND pl.wanted_id = '" . $listId . "'";
				}
				$resNetworks = $this->db->query($strSql);
				$networkArray = array();
				if ($resNetworks->num_rows() > 0)
				{
						foreach ($resNetworks->result_array() as $resRow)
						{
								$networkArray[] = $resRow;
						}
				}
				return $networkArray;
		}
		function getListPhotos($listId, $mode, $photoId = '')
		{
				$listPath = APPPATH . 'content/marketplace/list/';
				$wantPath = APPPATH . 'content/marketplace/want/';
				$arPhotos = array();
				if ($mode == 'list')
				{
						//$strSql = 	'SELECT CONCAT_WS(".",CONCAT_WS("_",list_id,photo_id),file_name) as file_name , photo_id FROM list_photos WHERE user_id = '.$this->userId.' AND list_id = "'.$listId.'"';
						$strSql = 'SELECT CONCAT_WS(".",CONCAT_WS("_",list_id,photo_id),file_name) as file_name , photo_id FROM list_photos WHERE  list_id = "' . $listId . '"';
				}
				else
				{
						//$strSql = 	'SELECT CONCAT_WS(".",CONCAT_WS("_",wanted_id,photo_id),file_name) as file_name, photo_id FROM want_photos WHERE user_id = '.$this->userId.' AND wanted_id = "'.$listId.'"';
						$strSql = 'SELECT CONCAT_WS(".",CONCAT_WS("_",wanted_id,photo_id),file_name) as file_name, photo_id FROM want_photos WHERE wanted_id = "' . $listId . '"';
				}
				$resRow = array();
				$resPhotos = $this->db->query($strSql);
				if ($resPhotos->num_rows() > 0)
				{
						foreach ($resPhotos->result_array() as $resRow)
						{
								$fileName = $resRow['file_name'];
								if ($mode == 'list')
								{
										$filePath = $listPath . $fileName;
								}
								else
								{
										$filePath = $wantPath . $fileName;
								}
								if (!file_exists($filePath))
								{
										$resRow['file_url'] = base_url() . 'application/images/default_avatar_thumb.jpg';
								}
								else
								{
										$resRow['file_url'] = base_url() . 'application/content/marketplace/' . $mode . '/' . $resRow['file_name'];
								}
								$arPhotos[] = $resRow;
						}
				}
				else
				{
						$resRow['file_url'] = base_url() . 'application/images/default_avatar_thumb.jpg';
						$arPhotos[] = array('file_url' => base_url() . 'application/images/default_avatar_thumb.jpg', 'file_name' => 'default_avatar_thumb.jpg', 'photo_id' => 0);
				}
				return $arPhotos;
		}
		function getMarketplaceImage($listId, $mode, $thumbnail = false, $relativeURL = false)
		{
				$arPhotos = array();
				$thumb = ($thumbnail == true) ? '_thumb' : '';
				if ($mode == 'list')
				{
						//$strSql = 	'SELECT CONCAT_WS(".",CONCAT_WS("_",list_id,photo_id),file_name) as file_name , photo_id FROM list_photos WHERE user_id = '.$this->userId.' AND list_id = "'.$listId.'"';
						$strSql = 'SELECT CONCAT_WS(".",CONCAT_WS("_",list_id,photo_id),file_name) as file_name , photo_id FROM list_photos WHERE  list_id = "' . $listId . '" LIMIT 0,1';
				}
				else
				{
						//$strSql = 	'SELECT CONCAT_WS(".",CONCAT_WS("_",wanted_id,photo_id),file_name) as file_name, photo_id FROM want_photos WHERE user_id = '.$this->userId.' AND wanted_id = "'.$listId.'"';
						$strSql = 'SELECT CONCAT_WS(".",CONCAT_WS("_",wanted_id,photo_id),file_name) as file_name, photo_id FROM want_photos WHERE wanted_id = "' . $listId . '" LIMIT 0,1';
				}
				$resPhotos = $this->db->query($strSql);
				if ($resPhotos->num_rows() > 0)
				{
						$resRow = $resPhotos->result_array();
						if (!$relativeURL) $userAvatar = base_url() . 'application/content/marketplace/' . $mode . '/' . $resRow[0]['file_name'];
						else  $userAvatar = 'content/marketplace/' . $mode . '/' . $resRow[0]['file_name'];
						if (!file_exists(APPPATH . 'content/marketplace/' . $mode . '/' . $resRow[0]['file_name']))
						{
								if (!$relativeURL) $userAvatar = base_url() . 'application/images/default_avatar' . $thumb . '.jpg';
								else  $userAvatar = 'images/default_avatar' . $thumb . '.jpg';
						}
				}
				else
				{
						if (!$relativeURL) $userAvatar = base_url() . 'application/images/default_avatar' . $thumb . '.jpg';
						else  $userAvatar = 'images/default_avatar' . $thumb . '.jpg';
				}
				return $userAvatar;
		}
		function deleteListPhotos($id, $mode)
		{
				if ($mode == 'list') $strSQL = 'DELETE FROM list_photos WHERE user_id = ' . $this->userId . ' AND list_id = ' . $id;
				else  $strSQL = 'DELETE FROM want_photos WHERE user_id = ' . $this->userId . ' AND wanted_id = ' . $id;
				$this->db->query($strSQL);
		}
		function deleteListNetworks($id, $mode)
		{
				if ($mode == 'list') $strSQL = 'DELETE FROM list_networks WHERE user_id = ' . $this->userId . ' AND list_id = ' . $id;
				else  $strSQL = 'DELETE FROM want_networks WHERE user_id = ' . $this->userId . ' AND wanted_id = ' . $id;
				$this->db->query($strSQL);
		}
		function deleteListing($id, $mode, $status)
		{
				if ($mode == 'list')
				{
						$strSQL = 'UPDATE products_list SET date_modified = CURRENT_TIMESTAMP, is_deleted = "1", list_status = ' . $this->db->escape($status) . '  WHERE user_id = ' . $this->userId . ' AND list_id = ' . $id;
						$postType = 'marketplace_list';
						$postId = $id;
				}
				else
				{
						$strSQL = 'UPDATE products_wanted SET date_modified = CURRENT_TIMESTAMP,is_deleted = "1" , list_status = ' . $this->db->escape($status) . '   WHERE user_id = ' . $this->userId . ' AND wanted_id = ' . $id;
						$postType = 'marketplace_want';
						$postId = $id;
				}
				$this->db->query($strSQL);
				$this->deletePostByType($postType, $postId);
		}
		function deletePostByType($postFor, $postForId)
		{
				//echo 'DELETE FROM posted_items WHERE post_type=\''.$postFor.'\' AND post_for_id='.$postForId;
				$sql = 'DELETE FROM posted_items WHERE post_type=\'' . $postFor . '\' AND post_for_id=' . $postForId;
				$this->db->query($sql);
				if ($this->db->affected_rows() > 0) return true;
				else  return false;
		} //end deletePostByType()
		function getMainCategory($mode = 'list')
		{
				$condSQL = '';
				if ($mode == 'want') $condSQL = ' AND cat_code != "FREE" ';
				$strSQL = 'SELECT cat_id, cat_name, cat_alias_name, cat_code, cat_desc, cat_logo FROM prod_category WHERE is_deleted ="0" AND is_approved = "Y" ' . $condSQL . ' ORDER BY cat_name, cat_alias_name';
				$resSQL = $this->db->query($strSQL);
				$resArray = array();
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[] = $resRow;
						}
				}
				return $resArray;
		}
		function getSubCategory($mainCatId = '', $subCatCode = '')
		{
				$condSQL = '';
				if (trim($mainCatId) != '') $condSQL .= " AND cat_id = " . $this->db->escape($mainCatId);
				if (trim($subCatCode) != '') $condSQL .= " AND sub_cat_code = " . $this->db->escape($subCatCode);
				$strSQL = 'SELECT cat_id, sub_cat_id, sub_cat_code, sub_cat_name, sub_cat_desc, sub_cat_logo FROM prod_sub_category WHERE is_deleted = "0" ' . $condSQL . ' AND is_approved = "Y" ORDER BY sub_cat_name ';
				$resSQL = $this->db->query($strSQL);
				$resArray = array();
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[] = $resRow;
						}
				}
				return $resArray;
		}
		function getMaincatName($mainCatId)
		{
				$strSQL = "SELECT cat_name, cat_alias_name FROM prod_category WHERE cat_id = " . $this->db->escape($mainCatId);
				$resSQL = $this->db->query($strSQL);
				$resArray = array();
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[] = $resRow;
						}
				}
				return $resArray;
		}
		function getItemCondition()
		{
				$strSQL = "SELECT detail_id, description, header_id FROM global_detail WHERE header_id = 'CONDITION_MP' AND is_deleted = 'N' AND is_approved = 'Y'";
				$resSQL = $this->db->query($strSQL);
				$resArray = array();
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[] = $resRow;
						}
				}
				return $resArray;
		}
		function getCurrencyCode()
		{
				$strSQL = "SELECT detail_id, description, header_id FROM global_detail WHERE header_id = 'CURRENCY_MP' AND is_deleted = 'N' AND is_approved = 'Y'";
				$resSQL = $this->db->query($strSQL);
				$resArray = array();
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[] = $resRow;
						}
				}
				return $resArray;
		}
		function getAllowedThings()
		{
				$strSQL = "SELECT detail_id, description, header_id FROM global_detail WHERE header_id = 'ALLOWED_MP' AND is_deleted = 'N' AND is_approved = 'Y'";
				$resSQL = $this->db->query($strSQL);
				$resArray = array();
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[] = $resRow;
						}
				}
				return $resArray;
		}
		function getMainCat($subCatCode)
		{
				$strSQL = 'SELECT cat_id, cat_code, cat_name, cat_alias_name FROM prod_category WHERE cat_code =' . $this->db->escape($subCatCode);
				$resArray = array();
				$resSQL = $this->db->query($strSQL);
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[] = $resRow;
						}
				}
				return $resArray;
		}
		function getSubCat($subCatCode)
		{
				$strSQL = " SELECT cat_id, sub_cat_id,sub_cat_code FROM prod_sub_category WHERE upper(trim(sub_cat_code)) = " . $this->db->escape($subCatCode);
				$resArray = array();
				$resSQL = $this->db->query($strSQL);
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[] = $resRow;
						}
				}
				return $resArray;
		}
		function getJobSubCategories()
		{
				$strSQL = "SELECT psc.cat_id, psc.sub_cat_code, psc.sub_cat_id, psc.sub_cat_name 
					FROM  prod_sub_category AS psc
					INNER JOIN prod_category AS pc ON pc.cat_id = psc.cat_id AND pc.cat_code = 'JOB' AND pc.is_deleted = '0' AND pc.is_approved = 'Y'
					WHERE psc.is_deleted = '0' AND psc.is_approved = 'Y'";
				$resSQL = $this->db->query($strSQL);
				$resArray = array();
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[] = $resRow;
						}
				}
				return $resArray;
		}
		function getOtherStuff()
		{
				$strSQL = "SELECT detail_id, description, header_id FROM global_detail WHERE header_id = 'OTHERS_STUFF_MP' AND is_deleted = 'N' AND is_approved = 'Y'";
				$resSQL = $this->db->query($strSQL);
				$resArray = array();
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[] = $resRow;
						}
				}
				return $resArray;
		}
		function getCompensation()
		{
				$strSQL = "SELECT detail_id, description, header_id FROM global_detail WHERE header_id = 'COMPENSATION_MP' AND is_deleted = 'N' AND is_approved = 'Y'";
				$resSQL = $this->db->query($strSQL);
				$resArray = array();
				if ($resSQL->num_rows() > 0)
				{
						foreach ($resSQL->result_array() as $resRow)
						{
								$resArray[] = $resRow;
						}
				}
				return $resArray;
		}
}
?>