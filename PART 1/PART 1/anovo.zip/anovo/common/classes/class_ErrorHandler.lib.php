<?php


if (!isset($CFG['debug']['debug_standalone_modules'])) $CFG['debug']['debug_standalone_modules'] = true;
class ErrorHandler
{
		private $dbObject = null;
		private $error_level = E_ALL;
		private $error_notify_email = null;
		private $source_before_errline = 2;
		private $source_after_errline = 2;
		private $error_stack_arr = null;
		private $error_log_name = null;
		private $error500_document = null;
		private $user_error_msg = 'Script error occured. Please retry later!';
		private $is_debug_mode = false;
		private $is_catch_fatal_error = false;
		private $debug_css_url = null;
		public function __construct()
		{
				if (!defined('E_STRICT')) define('E_STRICT', 2048);
				set_error_handler(array(&$this, 'normalErrorHandler'));
		}
		public function setErrorLevel($errlevel)
		{
				$this->error_level = $errlevel;
		}
		public function setErrorNotifyEmail($email)
		{
				$this->error_notify_email = $email;
		}
		public function setIsDebugMode($is_debug_mode)
		{
				$this->is_debug_mode = $is_debug_mode;
		}
		public function setIsCatchFatalError($is_catch_fatal_error)
		{
				$this->is_catch_fatal_error = $is_catch_fatal_error;
				ob_start(array(&$this, 'fatalErrorHandler'));
		}
		public function setNumSourceToFetch($num_before_error, $num_after_error)
		{
				$this->source_before_errline = $num_before_error;
				$this->source_after_errline = $num_after_error;
		}
		public function setDebugCSSURL($url)
		{
				$this->debug_css_url = $url;
		}
		private function _die()
		{
				echo $this->user_error_msg;
				exit(1);
		}
		private function _die500()
		{
				header('Status: 500');
				header('HTTP/1.0 500 Internal Server Error');
				if (!empty($this->error500_document)) readfile($this->error500_document);
				exit(1);
		}
		private function _formatDebugBacktrace($trace_arr)
		{
				$s = '';
				if (!empty($trace_arr))
				{
						array_shift($trace_arr);
						$tabs = count($trace_arr) - 1;
						foreach ($trace_arr as $arr)
						{
								$line = (isset($arr['line']) ? $arr['line'] : 'unknown');
								$file = (isset($arr['file']) ? $arr['file'] : 'unknown');
								for ($i = 0; $i < $tabs; ++$i) $s .= '  ';
								$s .= '<strong>Line: </strong>[' . $line . '] ' . $file . "\n";
								for ($i = 0; $i < $tabs; ++$i) $s .= '  ';
								$tabs -= 1;
								if (isset($arr['class'])) $s .= $arr['class'] . $arr['type'];
								$args = array();
								if (isset($arr['args']) && count($arr['args']) > 0)
										foreach ($arr['args'] as $v)
										{
												if (is_null($v)) $args[] = 'null';
												else
														if (is_array($v)) $args[] = 'Array[' . sizeof($v) . ']';
														else
																if (is_object($v)) $args[] = 'Object:' . get_class($v);
																else
																		if (is_bool($v)) $args[] = $v ? 'true' : 'false';
																		else
																		{
																				$v = (string )@$v;
																				$args[] = '"' . htmlspecialchars($v) . '"';
																		}
										}
								$s .= $arr['function'] . '(' . implode(', ', $args) . ')';
								$s .= "\n";
						}
				}
				return $s;
		}
		public function normalErrorHandler($errno, $errstr, $errfile, $errline, $errcontext_arr)
		{
				if (error_reporting() != 0)
				{
						$exclude_context_vars_arr = array('GLOBALS', '_POST', 'HTTP_POST_VARS', '_GET', 'HTTP_GET_VARS', '_COOKIE', 'HTTP_COOKIE_VARS', '_SERVER', 'HTTP_SERVER_VARS', '_ENV', 'HTTP_ENV_VARS', '_FILES', 'HTTP_POST_FILES', '_REQUEST', 'CFG', 'errHandler', 'buffer', 'db');
						$errcontext_fixed_arr = array();
						foreach ($errcontext_arr as $key => $val)
								if (!in_array($key, $exclude_context_vars_arr)) $errcontext_fixed_arr[$key] = $val;
						$errcontext_arr = $errcontext_fixed_arr;
						$errors_for_500 = array('DB Connection Error');
						if ($this->error_level & $errno)
						{
								$debug_trace = array();
								if ($errno != E_ERROR) $debug_trace = debug_backtrace();
								$this->error_stack_arr[] = array($errno, $errstr, $errfile, $errline, $errcontext_arr, $debug_trace);
						}
						switch ($errno)
						{
								case E_USER_ERROR:
										echo $this->processTrappedErrors();
										if (in_array($errstr, $errors_for_500)) $this->_die500();
										else  $this->_die();
										break;
						}
				}
		}
		private function _my_highlight_string($str)
		{
				if (!defined('T_ML_COMMENT')) define('T_ML_COMMENT', T_COMMENT);
				if (!defined('T_DOC_COMMENT')) define('T_DOC_COMMENT', T_ML_COMMENT);
				if (!defined('T_OLD_FUNCTION')) define('T_OLD_FUNCTION', T_FUNCTION);
				$colorize_map = array(T_INCLUDE => 'keyword', T_INCLUDE_ONCE => 'keyword', T_EVAL => 'keyword', T_REQUIRE => 'keyword', T_REQUIRE_ONCE => 'keyword', T_LOGICAL_OR => 'keyword', T_LOGICAL_XOR => 'keyword', T_LOGICAL_AND => 'keyword', T_PRINT => 'keyword', T_PLUS_EQUAL => 'keyword', T_MINUS_EQUAL => 'keyword', T_MUL_EQUAL => 'keyword', T_DIV_EQUAL => 'keyword', T_CONCAT_EQUAL => 'keyword', T_MOD_EQUAL => 'keyword', T_AND_EQUAL => 'keyword', T_OR_EQUAL => 'keyword', T_XOR_EQUAL => 'keyword', T_SL_EQUAL => 'keyword', T_SR_EQUAL => 'keyword', T_BOOLEAN_OR => 'keyword', T_BOOLEAN_AND => 'keyword', T_IS_EQUAL => 'keyword', T_IS_NOT_EQUAL => 'keyword', T_IS_IDENTICAL => 'keyword', T_IS_NOT_IDENTICAL => 'keyword', T_IS_SMALLER_OR_EQUAL => 'keyword', T_IS_GREATER_OR_EQUAL => 'keyword', T_SL => 'keyword', T_SR => 'keyword', T_INC => 'keyword', T_DEC => 'keyword', T_INT_CAST => 'keyword', T_DOUBLE_CAST => 'keyword', T_STRING_CAST => 'keyword', T_ARRAY_CAST => 'keyword', T_OBJECT_CAST => 'keyword',
						T_BOOL_CAST => 'keyword', T_UNSET_CAST => 'keyword', T_NEW => 'keyword', T_EXIT => 'keyword', T_IF => 'keyword', T_ELSEIF => 'keyword', T_ELSE => 'keyword', T_ENDIF => 'keyword', T_LNUMBER => 'default', T_DNUMBER => 'default', T_STRING => 'string', T_STRING_VARNAME => 'string', T_VARIABLE => 'default', T_NUM_STRING => 'string', T_INLINE_HTML => 'html', T_CHARACTER => 'default', T_BAD_CHARACTER => 'default', T_ENCAPSED_AND_WHITESPACE => 'default', T_CONSTANT_ENCAPSED_STRING => 'string', T_ECHO => 'keyword', T_DO => 'keyword', T_WHILE => 'keyword', T_ENDWHILE => 'keyword', T_FOR => 'keyword', T_ENDFOR => 'keyword', T_FOREACH => 'keyword', T_ENDFOREACH => 'keyword', T_DECLARE => 'keyword', T_ENDDECLARE => 'keyword', T_AS => 'keyword', T_SWITCH => 'keyword', T_ENDSWITCH => 'keyword', T_CASE => 'keyword', T_DEFAULT => 'keyword', T_BREAK => 'keyword', T_CONTINUE => 'keyword', T_OLD_FUNCTION => 'default', T_FUNCTION => 'default', T_CONST => 'default', T_RETURN => 'keyword', T_USE =>
						'default', T_GLOBAL => 'default', T_STATIC => 'default', T_VAR => 'default', T_UNSET => 'default', T_ISSET => 'default', T_EMPTY => 'default', T_CLASS => 'keyword', T_EXTENDS => 'keyword', T_OBJECT_OPERATOR => 'keyword', T_DOUBLE_ARROW => 'keyword', T_LIST => 'keyword', T_ARRAY => 'default', T_LINE => 'default', T_FILE => 'default', T_COMMENT => 'comment', T_ML_COMMENT => 'comment', T_OPEN_TAG => 'keyword', T_OPEN_TAG_WITH_ECHO => 'keyword', T_CLOSE_TAG => 'keyword', T_WHITESPACE => 'default', T_START_HEREDOC => 'keyword', T_END_HEREDOC => 'keyword', T_DOLLAR_OPEN_CURLY_BRACES => 'keyword', T_CURLY_OPEN => 'keyword', T_PAAMAYIM_NEKUDOTAYIM => 'keyword', T_DOUBLE_COLON => 'keyword');
				$tokens = token_get_all($str);
				$highlighted_str = '<code>';
				foreach ($tokens as $token)
				{
						if (is_string($token))
						{
								$token = htmlentities($token);
								$token = str_replace(array('  ', "\t"), array(' &nbsp;', ' &nbsp; &nbsp;'), $token);
								$highlighted_str .= $token;
						}
						else
								if (is_array($token))
								{
										list($id, $text) = $token;
										$text = htmlentities($text);
										$text = str_replace(array('  ', "\t"), array(' &nbsp;', ' &nbsp; &nbsp;'), $text);
										$highlighted_str .= '<font color="' . ini_get('highlight.' . $colorize_map[$id]) . '">' . $text . '</font>';
								}
				}
				$highlighted_str .= '</code>';
				return $highlighted_str;
		}
		private function _getSource($filename, $errline)
		{
				$source = "\t" . '<div class="clsDebugSource">' . "\n";
				$file_in_arr = file($filename);
				$errline -= 1;
				$source_begin_line = $errline - $this->source_before_errline;
				$source_end_line = 1 + $errline + $this->source_after_errline;
				if ($source_begin_line < 0) $source_begin_line = 0;
				$num_lines_in_file = count($file_in_arr);
				if ($source_end_line > $num_lines_in_file) $source_end_line = $num_lines_in_file;
				$tmp_highlighted_source = '';
				for ($i = $source_begin_line; $i < $source_end_line; ++$i)
				{
						$file_in_arr[$i] = rtrim($file_in_arr[$i]);
						if ($this->is_catch_fatal_error)
						{
								$tmp_highlight_line = $this->_my_highlight_string("<?php\n" . $file_in_arr[$i]);
								$expected_prefix = '<code><font color="' . ini_get('highlight.keyword') . '">&lt;?php' . "\n" . '</font>';
								if (strncasecmp($tmp_highlight_line, $expected_prefix, strlen($expected_prefix)) == 0) $tmp_highlight_line = '<code>' . substr($tmp_highlight_line, strlen($expected_prefix));
								else
								{
										$expected_prefix = '<code><font color="' . ini_get('highlight.default') . '">&lt;?</font><font color="' . ini_get('highlight.string') . '">php</font>';
										if (strncasecmp($tmp_highlight_line, $expected_prefix, strlen($expected_prefix)) == 0) $tmp_highlight_line = '<code>' . substr($tmp_highlight_line, strlen($expected_prefix));
								}
						}
						else
						{
								$tmp_highlight_line = highlight_string("<?php\n" . $file_in_arr[$i], true);
								$tmp_highlight_line = str_replace('&lt;?php<br />', '', $tmp_highlight_line);
						}
						$xhtml_convmap = array('<code>' => '', '</code>' => '', "\n" => '', '<font' => '<span', '</font>' => '</span>', 'color="' => 'style="color:');
						$tmp_highlight_line = strtr($tmp_highlight_line, $xhtml_convmap);
						if ($i == $errline) $tmp_highlighted_source .= "\t\t" . '<code><span class="clsDebugSourceLine"><span style="color:#999999">' . ($i + 1) . '</span> ' . $tmp_highlight_line . '</span></code><br />' . "\n";
						else  $tmp_highlighted_source .= "\t\t" . '<code><span style="color:#999999">' . ($i + 1) . '</span> ' . $tmp_highlight_line . '</code><br />' . "\n";
				}
				$source .= $tmp_highlighted_source;
				$source .= "\t" . '</div>' . "\n";
				return $source;
		}
		public function fatalErrorHandler($buffer)
		{
				if (preg_match("/(?:<b>)?(.*?error)(?:<\/b>)?: (.*?) in (?:<b>)?(.*?)(?:<\/b>)? on line (?:<b>)?(\d+)(?:<\/b>)?(?:<br \/>)?/i", $buffer, $matches))
				{
						foreach ($matches as $key => $val) $matches[$key] = trim(preg_replace("/<.*?>/", '', $val));
						$this->normalErrorHandler(E_ERROR, $matches[2], $matches[3], $matches[4], get_defined_vars());
						$errmsg = $this->processTrappedErrors();
						$buffer = preg_replace("/(.*?error.*?:.*? in .*? on line \d+)/i", $this->user_error_msg, $buffer);
						$buffer .= $errmsg;
				}
				return $buffer;
		}
		private function _my_var_export($array, $return = false)
		{
				$indent = '  ';
				$doublearrow = ' => ';
				$lineend = ",\n";
				$stringdelim = '\'';
				$newline = "\n";
				if (is_string($array)) $out = $stringdelim . $array . $stringdelim;
				else
						if (is_int($array)) $out = (string )$array;
						else
						{
								$out = 'array (' . "\n";
								foreach ($array as $key => $value)
								{
										if (is_string($key)) $key = $stringdelim . addslashes($key) . $stringdelim;
										if (is_string($value)) $value = $stringdelim . addslashes($value) . $stringdelim;
										else
												if (is_array($value))
												{
														$recur_array = explode($newline, $this->_my_var_export($value, true));
														$recur_newarr = array();
														foreach ($recur_array as $recur_line) $recur_newarr[] = $indent . $recur_line;
														$recur_array = implode($newline, $recur_newarr);
														$value = $newline . $recur_array;
												}
										$out .= $indent . $key . $doublearrow . $value . $lineend;
								}
								$out .= ')';
						}
						if ($return === true) return $out;
						else
						{
								echo $out;
								return;
						}
		}
		public function processTrappedErrors()
		{
				$errmsg = '';
				if (!empty($this->error_stack_arr))
				{
						$errortypes_arr = array(E_ERROR => 'Fatal Error', E_WARNING => 'Warning', E_PARSE => 'Parsing Error', E_NOTICE => 'Notice', E_CORE_ERROR => 'Core Error', E_CORE_WARNING => 'Core Warning', E_COMPILE_ERROR => 'Compile Error', E_COMPILE_WARNING => 'Compile Warning', E_USER_ERROR => 'User Error', E_USER_WARNING => 'User Warning', E_USER_NOTICE => 'User Notice', E_STRICT => 'Runtime Notice');
						$num_errors = count($this->error_stack_arr);
						if ($num_errors && $this->is_debug_mode) $errmsg .= '<div id="selDebugErrors">' . "\n";
						for ($i = 0; $i < $num_errors; ++$i)
						{
								if ($this->is_debug_mode)
								{
										$errmsg .= '<div class="clsDebugErrors">' . "\n";
										$errmsg .= "\t" . '<p><strong>Error: </strong>[' . $this->error_stack_arr[$i][0] . '] [' . $errortypes_arr[$this->error_stack_arr[$i][0]] . '] ' . $this->error_stack_arr[$i][1] . '<br />' . "\n";
										$errmsg .= "\t" . '<strong>Line: </strong>[' . $this->error_stack_arr[$i][3] . '] ' . $this->error_stack_arr[$i][2] . '<br />' . "\n";
										$errmsg .= "\t" . '<strong>Source:</strong></p>' . "\n";
										$errmsg .= $this->_getSource($this->error_stack_arr[$i][2], $this->error_stack_arr[$i][3]);
										$errmsg .= "\t" . '<p><strong>Debug Trace:</strong></p>' . "\n";
										$errmsg .= "\t" . '<pre class="clsDebugTrace">' . "\n" . $this->_formatDebugBacktrace($this->error_stack_arr[$i][5]) . "\n\t" . '</pre>' . "\n";
										$errmsg .= "\t" . '<p><strong>Context Variables:</strong></p>' . "\n";
										if ($this->is_catch_fatal_error) $errmsg .= "\t" . '<pre class="clsDebugContextVars">' . "\n" . htmlentities($this->_my_var_export($this->error_stack_arr[$i][4], true)) . "\n\t" . '</pre>' . "\n";
										else  $errmsg .= "\t" . '<pre class="clsDebugContextVars">' . "\n" . htmlentities(var_export($this->error_stack_arr[$i][4], true)) . "\n\t" . '</pre>' . "\n";
										$errmsg .= '</div>' . "\n";
								}
						}
						if ($num_errors && $this->is_debug_mode)
						{
								$errmsg .= '</div>' . "\n";
								$errmsg .= '<style type="text/css">' . "\n";
								$errmsg .= '@import url("' . $this->debug_css_url . '");' . "\n";
								$errmsg .= '</style>' . "\n";
								$errmsg .= '<script language="JavaScript" type="text/javascript">' . "\n";
								$errmsg .= '<!--' . "\n";
								$errmsg .= 'window.scroll(0, document.getElementById("selDebugErrors").offsetTop);' . "\n";
								$errmsg .= 'window.focus();' . "\n";
								$errmsg .= 'alert("PHP Error Handler:\n\n' . $num_errors . ' errors found!");' . "\n";
								$errmsg .= '//-->' . "\n";
								$errmsg .= '</script>' . "\n";
						}
				}
				return $errmsg;
		}
}
if ($CFG['debug']['debug_standalone_modules'])
{
		$errHandler = new ErrorHandler();
		$errHandler->setErrorLevel(E_ALL);
		$errHandler->setIsCatchFatalError(false);
		$errHandler->setIsDebugMode(true);
		for ($i = 0; $i < 5; ++$i) echo $a;
		$a = b;
		include ('nonoo');
		$a = ao();
		$errHandler->processTrappedErrors();
}
?>