<?php /* Smarty version 2.6.6, created on 2006-02-01 09:56:16
         compiled from admin/Admin_index.tpl */ ?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<link REL="SHORTCUT ICON" href="favicon.ico">
<title>.:: UploadGalaxy Control Panel ::.</title>
</head>
<body>
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" height="512">
  <tr>
    <td width="20%" height="510" bordercolor="#E7EFEF" bgcolor="#FFFFFF" rowspan="2">&nbsp;</td>
    <td width="60%" height="496" valign="top" bgcolor="#F5F5F5">
    <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" height="247">
      <tr>
        <td width="100%" height="68" bgcolor="#F1F1FA">
        <p align="center"><b><font size="5" face="Verdana">.:: Control Panel 
        ::.<br>
        </font></b><font size="1" face="Verdana" color="#0000FF">.:: <?php echo $this->_tpl_vars['site_name']; ?>
 
        ::.</font></td>
      </tr>
      <tr>
        <td width="100%" height="77" valign="top">
        <p align="center"><?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/adminheader.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
        </td>
      </tr>
      <tr>
        <td width="100%" height="101">
                <p align="center">
                <b><font size="2" face="Verdana" color="#008000"><?php echo $this->_tpl_vars['msg']; ?>
</font></b> <b>
        <font face="Verdana" size="2" color="#FF0000"><?php echo $this->_tpl_vars['err']; ?>
</font></b>
        <?php if ($_COOKIE['admin_uid']): ?>       
                <?php if ($_REQUEST['change'] == 'Personal'): ?>
                <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/admin_personal.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
                <?php endif; ?>
                <?php if ($_REQUEST['change'] == 'Config'): ?>
                <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/admin_config.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
                <?php endif; ?>
                <?php if ($_REQUEST['change'] == 'Packages'): ?>
                <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/admin_package.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
                <?php endif; ?>                
                <?php if ($_REQUEST['change'] == 'Abuse'): ?>
                <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/admin_abuse.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
                <?php endif; ?>
                <?php if ($_REQUEST['change'] == 'FInfo'): ?>
                <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/admin_file.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
                <?php endif; ?>
                <?php if ($_REQUEST['change'] == 'Server'): ?>
                <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/admin_server.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
                <?php endif; ?>
                <?php endif; ?>
        </td>
      </tr>
    </table>
    </td>
    <td width="20%" height="510" bgcolor="#FFFFFF" rowspan="2" VALIGN=TOP><BR><BR><BR><BR>&nbsp;
    <!--<p align="center"><?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "admin/adminheader1.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>-->
    </td>
  </tr>
  <tr>
    <td width="60%" height="14" valign="top" bgcolor="#003366">
    <p align="center"><font color="#FFFFFF" face="Verdana" size="1">Developed 
    and maintained by <b>Shaon</b></font></td>
  </tr>
</table>

</body>

</html>