<?php
require_once("include/vars.php");
require_once("include/config.php");
require_once("include/functions.php");

$id=isset($_REQUEST["id"])?$_REQUEST["id"]:0;
$qry="SELECT conf_optional FROM configuration WHERE conf_name='MAX_TIME'";
$rs=$conn->execute($qry);
$row=array();
$row=$rs->fields;
$maxtime=$row[0];


$qry="SELECT conf_optional FROM configuration WHERE conf_name='MAX_COUNT'";
$rs=$conn->execute($qry);
$row=array();
$row=$rs->fields;
$maxcount=$row[0];

$qry="SELECT idkey FROM fileinfo WHERE id='$id'";
$rs=$conn->execute($qry);

if($rs->recordcount()>0)
{
        $row=array();
        $row=$rs->fields;
        $link="<a href=\"download.php?id=".$row[0]."\" class=\"ltxt\">".HostURL()."download.php?id=".$row[0]."</a>";
}
else  $link="<span class=\"ltxt\"><font color=red>Sorry! Link doesn't exists</font><span>";
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title><?=SITE_NAME?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="templates/style.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="script.js"></script>
</head>

<body>
<table width="600" border="0" align="center" cellpadding="0" cellspacing="0" style="border: solid 1px #999999">
  <tr>
    <td><?php
        STemplate::display("header.tpl");
        ?></td>
  </tr>
  <tr>
    <td valign="top"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="2">
        <tr> 
          <td><table width="100%" border="0" align="center" cellpadding="2" cellspacing="0">
              <tr> 
                <td class="ltxt"><strong>Your file has been successfully sent!</strong></td>
              </tr>
              <tr> 
                <td class="ltxt"><p style="margin-left: 150; margin-right: 150">We've stored your file on our server and sent 
                  your recipient an email with instructions for retrieving it. 
                  The file will be available for 
                  <?=$maxtime?>
                  or 
                  <?=$maxcount?>
                  downloads.</p></td>
              </tr>
              <tr> 
                <td class="ltxt"><strong>Here is a link for your reference: </strong></td>
              </tr>
              <tr> 
                <td>
                  <?=$link?>
                </td>
              </tr>
            </table>
            <br> 
          </td>
        </tr>
      </table>
    </td>
  </tr>
  <tr>
    <td>
        <?php
        STemplate::display("footer.tpl");
        ?>
        </td>
  </tr>
</table>  
</body>
</html>
