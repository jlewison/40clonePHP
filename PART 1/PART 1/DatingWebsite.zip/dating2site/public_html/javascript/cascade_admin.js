function cascadeCountry(value) {
    http.open('get', 'cascade_admin.php?a=country&v=' + value );
    document.getElementById('txtstateprovince').innerHTML="&nbsp;&nbsp;"+loadingTag;
    http.onreadystatechange = handleResponse;
    http.send(null);
}

function cascadeState(value,v1) {
    http.open('get', 'cascade_admin.php?a=state&v=' + value  + '&v1=' + v1);
	document.getElementById('txtcounty').innerHTML="&nbsp;&nbsp;"+loadingTag;

    http.onreadystatechange = handleResponse;
    http.send(null);
}

function cascadeCounty(value,v1,v2) {
    http.open('get', 'cascade_admin.php?a=county&v=' + value
					+ '&v1=' + v1 + '&v2=' + v2);
	document.getElementById('txtcity').innerHTML="&nbsp;&nbsp;"+loadingTag;

    http.onreadystatechange = handleResponse;
    http.send(null);
}

function cascadeCity(value,v1,v2,v3) {
    http.open('get', 'cascade_admin.php?a=city&v=' + value
					+ '&v1=' + v1 + '&v2=' + v2 + '&v3=' + v3);
	document.getElementById('txtzip').innerHTML="&nbsp;&nbsp;"+loadingTag;

    http.onreadystatechange = handleResponse;
    http.send(null);
}

