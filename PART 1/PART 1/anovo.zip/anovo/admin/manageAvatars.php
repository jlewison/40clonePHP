<?php
require_once ('../common/config.inc.php');
require_once ('../common/configs/config_ans_photo.inc.php');
$CFG['lang']['include_files'][] = 'admin/includes/languages/%s/manageAvatars.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['mods']['include_files'][] = 'common/classes/class_Image.lib.php';
$CFG['html']['header'] = 'admin/includes/languages/%s/html_header.php';
$CFG['html']['footer'] = 'admin/includes/languages/%s/html_footer.php';
$CFG['db']['is_use_db'] = true;
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class ManageAvatarHandler extends FormHandler
{
		public function displayAvatars()
		{
				$avatar_img_arr = glob($this->CFG['site']['project_path'] . $this->CFG['admin']['avatar_path'] . "default_*");
				$no_of_avatar_img = count($avatar_img_arr);
?>
				<table class="clsCommonTable" cellpadding="0" summary="<?php $this->LANG['avatar_view_tbl_summary']; ?>">
					<tr>
						<th colspan="8"><input type="checkbox" name="checkall" id="checkall" tabindex="<?php echo $this->getTabIndex(); ?>" onclick="selectAll(this.form)"/>&nbsp;Select All</th>
					</tr>
<?php
				$cols = 0;
				foreach ($avatar_img_arr as $filename)
				{
						$img_file = substr($filename, strrpos($filename, 'avatars/') + 8);
						if ($cols == 0)
						{
?>
<tr>
<?php
						}
?>
	<td><input type="checkbox" name="avatar_ids[]" value="<?php echo $img_file ?>" onClick="disableHeading('formViewAvatar');" tabindex="<?php echo $this->getTabIndex(); ?>" /></td>
	<td><img src="<?php echo $this->CFG['site']['url'] . $this->CFG['admin']['avatar_path'] . $img_file; ?>" /></td>
<?php
						$cols++;
						if ($cols == 4)
						{
?>
</tr>
<?php
								$cols = 0;
						}
				}
?>
					<tr>
						<td colspan="8"  class="<?php echo $this->getCSSFormFieldCellClass('action'); ?>">
							<select name="action" id="action" tabindex="<?php echo $this->getTabIndex(); ?>" ><?php $this->populateFilterList($this->action_arr, $this->fields_arr['action']); ?></select>
							<a href="#" id="dAltMlti"></a>
							<input type="button" name="avatar_action" id="avatar_action" onclick="getMultiCheckBoxValue('formViewAvatar', 'checkall', '<?php echo $this->LANG['avatar_err_tip_select_avatar']; ?>', 'dAltMlti');if(multiCheckValue!=''){getAction()}" value="<?php echo $this->LANG['avatar_action']; ?>" tabindex="<?php echo $this->getTabIndex(); ?>" />
						</td>
					</tr>
				</table>
<?php
		}
		public function populateFilterList($array_to_expand, $highlight)
		{
				foreach ($array_to_expand as $key => $value)
				{
?>
		<option value="<?php echo $key; ?>" <?php echo ($key == $highlight) ? 'selected="selected"' : '' ?>><?php echo $value; ?></option>
<?php
				}
		}
		public function deleteAvatars()
		{
				$avatarImagePath = $this->CFG['site']['project_path'] . $this->CFG['admin']['avatar_path'];
				$avatarImageUrl = $this->CFG['site']['url'] . $this->CFG['admin']['avatar_path'];
				$avatar_img_arr = explode(',', $this->fields_arr['avatar_ids']);
				foreach ($avatar_img_arr as $avatar_img)
				{
						@unlink($avatarImagePath . $avatar_img);
						$avatarImageFullUrl = $avatarImageUrl . $avatar_img;
						$sql = 'UPDATE ' . $this->CFG['db']['tbl']['users'] . ' SET img_path=\'\'' . ' WHERE img_path=' . $this->dbObj->Param($avatarImageFullUrl);
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($avatarImageFullUrl));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				}
		}
		public function setIHObject($imObj)
		{
				$this->imageObj = $imObj;
		}
		public function chkValidFileType($field_name, $err_tip = '')
		{
				$this->EXTERN = strtolower(substr($_FILES[$field_name]['name'], strrpos($_FILES[$field_name]['name'], '.') + 1));
				if (!in_array($this->EXTERN, $this->CFG['admin']['ans_photos']['format_arr']))
				{
						$this->fields_err_tip_arr[$field_name] = $err_tip;
						return false;
				}
				return true;
		}
		public function chkValideFileSize($field_name, $err_tip = '')
		{
				$max_size = $this->CFG['admin']['ans_photos']['max_size'] * 1024;
				if ($_FILES[$field_name]['size'] > $max_size)
				{
						$this->fields_err_tip_arr[$field_name] = $err_tip;
						return false;
				}
				return true;
		}
		public function chkErrorInFile($field_name, $err_tip = '')
		{
				if ($_FILES[$field_name]['error'])
				{
						$this->fields_err_tip_arr[$field_name] = $err_tip;
						return false;
				}
				return true;
		}
		public function storeImagesTempServer($uploadUrl, $extern)
		{
				$this->imageObj->resize($this->CFG['admin']['ans_photos']['thumb_width'], $this->CFG['admin']['ans_photos']['thumb_height'], '-');
				$this->imageObj->output_resized($uploadUrl . 'T.' . $extern, strtoupper($extern));
		}
		public function photoUpload()
		{
				$extern = strtolower(substr($_FILES['avatar']['name'], strrpos($_FILES['avatar']['name'], '.') + 1));
				$this->setFormField('photo_ext', $extern);
				$image_name = 'default_avatar' . time();
				$imageObj = new ImageHandler($_FILES['avatar']['tmp_name']);
				$this->setIHObject($imageObj);
				$temp_dir = '../' . $this->CFG['admin']['ans_photos']['temp_folder'];
				$this->chkAndCreateFolder($temp_dir);
				$temp_file = $temp_dir . '/' . $image_name;
				$this->storeImagesTempServer($temp_file, $extern);
				$dir = $this->CFG['admin']['avatar_path'];
				$local_upload = true;
				if ($local_upload)
				{
						$dir = '../' . $this->CFG['admin']['avatar_path'];
						$this->chkAndCreateFolder($dir);
						$uploadUrl = $dir . $image_name;
						if ($this->CFG['admin']['ans_photos']['thumb_name'] == 'T')
						{
								copy($temp_file . 'T.' . $extern, $uploadUrl . 'T.' . $extern);
								unlink($temp_file . 'T.' . $extern);
						}
				}
		}
}
$avatarfrm = new ManageAvatarHandler();
$avatarfrm->setPageBlockNames(array('msg_form_error', 'msg_form_success', 'form_add_avatar', 'form_view_avatar', 'form_link_add_avatar', 'form_view_sub_avatar', 'form_link_add_sub_avatar', 'form_add_sub_avatar', 'form_link_view_avatar'));
$avatarfrm->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$avatarfrm->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$avatarfrm->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$avatarfrm->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$avatarfrm->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$avatarfrm->setDBObject($db);
$avatarfrm->setCfgLangGlobal($CFG, $LANG);
$avatarfrm->setFormField('user_id', '');
$avatarfrm->setFormField('avatar', '');
$avatarfrm->setFormField('avatar_name', '');
$avatarfrm->setFormField('action', '');
$avatarfrm->setFormField('avatar_ids', array());
$avatarfrm->setFormField('mode', '');
$action_arr = array('' => $LANG['avatar_select_action'], 'Delete' => $LANG['avatar_activate']);
$avatarfrm->action_arr = $action_arr;
$avatarfrm->setAllPageBlocksHide();
$avatarfrm->sanitizeFormInputs($_REQUEST);
$avatarfrm->setPageBlockShow('form_view_avatar');
$avatarfrm->setPageBlockShow('form_link_add_avatar');
$avatarfrm->setPageBlockShow('form_link_view_avatar');
if ($avatarfrm->isFormPOSTed($_POST, 'add_avatar'))
{
		if (isset($_FILES['avatar']) and $_FILES['avatar']['tmp_name'])
		{
				$avatarfrm->chkValidFileType('avatar', $LANG['err_tip_invalid_file_type']) and $avatarfrm->chkValideFileSize('avatar', $LANG['err_tip_invalid_file_size']) and $avatarfrm->chkErrorInFile('avatar', $LANG['err_tip_invalid_file']);
		}
		else
		{
				$avatarfrm->setPageBlockShow('msg_form_error');
				$avatarfrm->setFormFieldErrorTip('avatar', $LANG['err_tip_select_avatar']);
		}
		if ($avatarfrm->isValidFormInputs())
		{
				$avatarfrm->photoUpload();
				$avatarfrm->setAllPageBlocksHide();
				$success_message = $LANG['avatar_success_message'];
				$avatarfrm->setPageBlockShow('msg_form_success');
				$avatarfrm->setPageBlockShow('form_view_avatar');
				$avatarfrm->setPageBlockShow('form_link_add_avatar');
		}
		else
		{
				$avatarfrm->setAllPageBlocksHide();
				$avatarfrm->setPageBlockShow('form_link_add_avatar');
				$avatarfrm->setPageBlockShow('form_link_view_avatar');
				$avatarfrm->setPageBlockShow('form_add_avatar');
				$avatarfrm->setPageBlockShow('msg_form_error');
		}
} elseif ($avatarfrm->isFormPOSTed($_POST, 'confirm_action'))
{
		$avatarfrm->chkIsNotEmpty('avatar_ids', $LANG['avatar_err_tip_compulsory']) or $avatarfrm->setCommonErrorMsg($LANG['avatar_err_tip_select_avatar']);
		$avatarfrm->chkIsNotEmpty('action', $LANG['avatar_err_tip_compulsory']) or $avatarfrm->setCommonErrorMsg($LANG['avatar_err_tip_select_action']);
		if ($avatarfrm->isValidFormInputs())
		{
				$avatarfrm->setAllPageBlocksHide();
				$avatarfrm->setPageBlockShow('msg_form_success');
				$avatarfrm->setPageBlockShow('form_view_avatar');
				$avatarfrm->setPageBlockShow('form_link_add_avatar');
				switch ($avatarfrm->getFormField('action'))
				{
						case 'Delete':
								$avatarfrm->deleteAvatars();
								$success_message = $LANG['avatar_success_delete'];
								break;
				}
		}
		else
		{
				$avatarfrm->setAllPageBlocksHide();
				$avatarfrm->setPageBlockShow('msg_form_error');
		}
} elseif ($avatarfrm->isFormPOSTed($_POST, 'cancel'))
{
		Redirect2URL($CFG['site']['relative_url'] . 'manageAvatars.php');
} elseif ($avatarfrm->isPageGETed($_GET, 'mode') && $avatarfrm->isValidFormInputs())
{
		$mode = $avatarfrm->getFormField('mode');
		if (strcmp($mode, 'add') == 0)
		{
				$avatarfrm->setAllPageBlocksHide();
				$avatarfrm->setPageBlockShow('form_link_add_avatar');
				$avatarfrm->setPageBlockShow('form_link_view_avatar');
				$avatarfrm->setPageBlockShow('form_add_avatar');
		}
}




?>
<script type="text/javascript" language="javascript">
	var block_arr= new Array('selMsgConfirm');
	var replace_url = '<?php echo $CFG['site']['url']; ?>login.php';
	var please_select_action = '<?php echo $LANG['avatar_err_tip_select_action']; ?>';
	var confirm_message = '';
	function getAction()
		{
			var act_value = document.formViewAvatar.action.value;
			if(act_value)
				{
					switch (act_value)
						{
							case 'Delete':
								confirm_message = '<?php echo $LANG['avatar_delete_msg']; ?>';
								break;
						}
					$('confirmMessage').innerHTML = confirm_message;
					document.formConfirm.action.value = act_value;
					Confirmation('dAltMlti', 'selMsgConfirm', 'formConfirm', Array('avatar_ids'), Array(multiCheckValue), Array('value'), -25, -290, 'formViewAvatar');
				}
				else
					alert_manual(please_select_action, 'dAltMlti');
		}
</script>
<div id="selEditLinks">
	<h2 class="clsAvatarHeading"><?php echo $LANG['avatar_title']; ?></h2>
<div class="clsSubLink"><?php
if ($avatarfrm->isShowPageBlock('form_link_view_avatar'))
{
?>
		 <p><a href="manageAvatars.php"><?php echo $LANG['list_avatars']; ?></a></p>
<?php
}
if ($avatarfrm->isShowPageBlock('form_link_add_avatar'))
{
?>
		 <p><a href="manageAvatars.php?mode=add"><?php echo $LANG['avatar_link_add_avatar']; ?></a></p>
<?php
}
if ($avatarfrm->isShowPageBlock('form_link_add_sub_avatar'))
{
?>
		 <p><a href="manageAvatars.php?mode=addsubavatar"><?php echo $LANG['avatar_link_add_sub_avatar']; ?></a></p>
<?php
} ?></div><?php

if ($avatarfrm->isShowPageBlock('msg_form_error'))
{
?>
	<div id="selMsgError">
		 <p><?php echo $LANG['msg_error_sorry'] . ' ' . $avatarfrm->getCommonErrorMsg(); ?></p>
	</div>
<?php
}
if ($avatarfrm->isShowPageBlock('msg_form_success'))
{
?>
	<div id="selMsgSuccess">
		<p><?php echo $success_message; ?></p>
	</div>
<?php
}
if ($avatarfrm->isShowPageBlock('form_add_avatar'))
{
		$subTitle = $LANG['avatar_subtitle_add_avatar'];
		$borderColor = 'white';
?>
	<div id="selEditLinks" style="border:1px solid <?php echo $borderColor; ?>;padding:1em;margin:1em">
	<h2 class="clsNewAvatarTitle"><?php echo $subTitle; ?></h2>
		<form name="formAddAvatar" id="formAddAvatar" enctype="multipart/form-data" method="post" action="<?php echo URL($_SERVER['SCRIPT_NAME']); ?>?mode=<?php echo $avatarfrm->getFormField('mode'); ?>" autocomplete="off">
		<table class="clsCommonTable" summary="<?php echo $LANG['avatar_add_tbl_summary']; ?>">
		   <tr>
				<td class="<?php echo $avatarfrm->getCSSFormLabelCellClass('avatar'); ?>"><label for="avatar"><?php echo $LANG['avatar_name']; ?></label></td>
				<td class="<?php echo $avatarfrm->getCSSFormFieldCellClass('avatar'); ?>"><?php echo $avatarfrm->getFormFieldErrorTip('avatar'); ?>
					<input type="file" name="avatar" id="avatar" tabindex="<?php echo $avatarfrm->getTabIndex(); ?>" value="<?php echo $avatarfrm->getFormField('avatar'); ?>" />
				</td>
		   </tr>
		   <tr>
	           	<td>&nbsp;</td>
				<td class="<?php echo $avatarfrm->getCSSFormFieldCellClass('submit'); ?>">
					<input type="submit" class="clsSubmitButton clsMediumSubmitButton" name="add_avatar" id="add_avatar" tabindex="<?php echo $avatarfrm->getTabIndex(); ?>" value="<?php echo $LANG['avatar_add']; ?>" />&nbsp;
				</td>
		   </tr>
		</table>
		</form>
	</div>
<?php
}
if ($avatarfrm->isShowPageBlock('form_view_avatar'))
{
?>
	<!-- Confirmation Div -->
	<div id="selMsgConfirm" class="selMsgConfirm" style="display:none;position:absolute;">
		<form name="formConfirm" id="formConfirm" method="post" action="<?php echo URL($_SERVER['SCRIPT_NAME']); ?>" autocomplete="off">
		<p id="confirmMessage"></p>
		<table class="clsCommonTable" summary="<?php echo $LANG['avatar_confirm_tbl_summary']; ?>">
			<tr>
		      	<td>
				  	<input type="submit" class="clsSubmitButton" name="confirm_action" id="confirm_action" value="<?php echo $LANG['avatar_confirm']; ?>" tabindex="<?php echo $avatarfrm->getTabIndex(); ?>" /> &nbsp;
		          	<input type="button" class="clsSubmitButton" name="cancel" id="cancel" value="<?php echo $LANG['avatar_cancel']; ?>" tabindex="<?php echo $avatarfrm->getTabIndex(); ?>" onClick="return hideAllBlocks('formViewAvatar');" />
		          	<input type="hidden" name="avatar_ids" />
		          	<input type="hidden" name="action" />
				</td>
	  		</tr>
		</table>
		</form>
	</div>

	<div id="selViewLinks">
		<form name="formViewAvatar" id="formViewAvatar" method="post" action="<?php echo URL($_SERVER['SCRIPT_NAME']); ?>" autocomplete="off">
			<?php $avatarfrm->displayAvatars(); ?>
		</form>
	</div>
<?php
}
?>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>