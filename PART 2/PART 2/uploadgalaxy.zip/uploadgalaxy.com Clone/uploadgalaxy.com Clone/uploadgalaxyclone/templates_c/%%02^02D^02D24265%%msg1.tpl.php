<?php /* Smarty version 2.6.6, created on 2006-02-01 09:53:09
         compiled from msg1.tpl */ ?>
<?php echo '
<p class="mp">
We are glad to implement a new policy, which improves our service quality for the majority of our users: Lately, huge files of very few users were swamping our servers and lines, disturbing the downloads of most users sending normal sized files. Now we are making it fairer by reducing the maximum free file size from 500 MB to 250 MB and leveraging a nominal fee to become a premium member and being able to transfer files of more than 250 MB. This gives most users better performance and faster downloads, while still allowing a few power users to exchange huge files at a megacheap flatrate. 
Our new premium membership also allows professional users with less time to transfer files quicker, while home users - having more time and often downloading files all night long - can still enjoy ourfree service. 
We hope that you will understand and support our new policy, which is in the interest of the vast majority of Megaupload users. 
Today we are also introducing our ground breaking Uploader Rewards. Our new reward program pays money and cash prizes to our uploaders. This makes Megaupload the first and only site on the Internet paying you for hosting your files. The more popular your files, the more you make. Shareware developers, webmasters and file traders: You can now utilize Megaupload to reduce your hosting costs and increase your revenues. Our new, bigger and faster server park is ready for you. 
Sincerely, Your Megaupload Team
</p>
'; ?>