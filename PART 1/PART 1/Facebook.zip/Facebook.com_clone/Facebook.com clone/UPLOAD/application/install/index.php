<html>
<head>
<title>Installation of Kootali [x-MoBiLe] Nulled</title>
<link href="css/install.css" rel="stylesheet" type="text/css" />
</head>
<body>
	<h1>Installation of Kootali [x-MoBiLe] Nulled</h1>
    
	<div id="sys_req">
    	<h3>System Requirements - Check the following requirements before installation:</h3>        
    	<ul>
        	<li>Linux Server</li>
            <li>Apache version	- 2.2.4</li>
            <li>PHP version		- 5.2.1</li>
            <li>MySQL version	- 5.0.33</li>
			<li>Red5 version	- 0.5</li>
        </ul>
		
		<h3>Information you will need for installation:</h3>
		<ul>
		  <li>MySQL Host Name (usually 'localhost')</li>
		  <li>MySQL Username</li>
		  <li>MySQL Password</li>
		  <li>MySQL Database Name</li>
		  <li>The absolute URL to your installation root (ex. http://www.your-domain.com/)</li>
		</ul>
    </div>    
    
    <a href="install.php">I checked all the things. Everything is fine.</a>
        
</body>
</html>