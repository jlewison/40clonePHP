<?php
	$module_info['name'] = 'Thickbox';
	$module_info['desc'] = 'Thickbox is a script used to overlay content on the current page.  For documentation on Thickbox, visit: http://jquery.com/demo/thickbox/';
	$module_info['version'] = 0.1;
?>