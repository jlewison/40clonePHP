<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_apound = "localhost";  // usually "localhost"
$database_apound = "lbs15pack";  // enter name of the database
$username_apound = "lbs15pack";  //enter database user name
$password_apound = "lbs15pack";  //enter database password
$apound = mysql_pconnect($hostname_apound, $username_apound, $password_apound) or trigger_error(mysql_error(),E_USER_ERROR); 
?>