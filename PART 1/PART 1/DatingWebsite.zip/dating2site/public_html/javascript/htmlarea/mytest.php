<?php
	echo $txt1;
?>
<html>
<head>
<script type="text/javascript">
  _editor_url = './';
  _editor_lang = 'en';
</script>
<script type="text/javascript" src="htmlarea.js"></script>
<script type="text/javascript" src="dialog.js"></script>
<script tyle="text/javascript" src="lang/en.js"></script>

</head>


</head>
<body onload="HTMLArea.replace('txt1')">
<table width="700">
<tr><td width="700">
<form action="mytest.php" method="post">
<textarea name="txt1" id="txt1" style="width:100%;height:300px">

</textarea>
<input type="submit">
</form>
</td></tr>
</table>


</body>
</html>