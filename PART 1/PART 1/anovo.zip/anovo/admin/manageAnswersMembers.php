<?php
require_once ('../common/config.inc.php');
$CFG['lang']['include_files'][] = 'admin/includes/languages/%s/manageAnswersMembers.php';
$CFG['lang']['include_files'][] = 'common/email_templates/languages/%s/email_notify.inc.php';
$CFG['html']['header'] = 'admin/includes/languages/%s/html_header.php';
$CFG['html']['footer'] = 'admin/includes/languages/%s/html_footer.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['mods']['include_files'][] = 'common/classes/class_ListRecordsHandler.lib.php';
$CFG['mods']['is_include_only']['non_html_header_files'] = true;
if ($_POST) $CFG['mods']['include_files'][] = 'common/classes/phpmailer/class_PHPMailer.lib.php';
require ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class ManageMembersFormHandler extends ListRecordsHandler
{
		public function buildConditionQuery()
		{
				$this->sql_condition = 'u.' . $this->getUserTableField('user_id') . '=ua.user_id AND u.' . $this->getUserTableField('usr_status') . '!=\'Deleted\'';
				if ($search_text = $this->fields_arr['search_name'])
				{
						switch ($this->fields_arr['search_cat'])
						{
								case '1':
										$this->sql_condition .= ' AND u.' . $this->getUserTableField('name') . ' LIKE \'' . addslashes($search_text) . '%\'';
										break;
								case '2':
										$this->sql_condition .= ' AND u.' . $this->getUserTableField('email') . ' LIKE \'' . addslashes($search_text) . '\'';
										break;
						}
				}
		}
		public function buildSortQuery()
		{
				$this->sql_sort = $this->fields_arr['orderby_field'] . ' ' . $this->fields_arr['orderby'];
		}
		public function displayTopAnalysts()
		{
				if (!$this->isResultsFound())
				{
?>
					<div id="selMsgAlert">
						<p><?php echo $this->LANG['managemembers_no_records']; ?></p>
					</div>
					<?php
						return;
				}
				$pagingArr = array();
				if ($this->fields_arr['search_name']) $pagingArr[] = 'search_name';
				if ($this->fields_arr['search_cat']) $pagingArr[] = 'search_cat';
				if ($this->CFG['admin']['navigation']['top']) $this->populatePageLinks($this->getFormField('start'), $pagingArr);
?>
				<form name="form_manage_members" id="form_manage_members" method="post" action="<?php echo URL($_SERVER['PHP_SELF']); ?>">
				<table border="1" summary="display all analysts" id="selForumTable">
					<tr>
					 <th><input type="checkbox" class="clsCheckRadio" name="check_all" onclick = "CheckAll(document.form_manage_members.name, document.form_manage_members.check_all.name);" tabindex="<?php echo $this->getTabIndex(); ?> value="1" <?php if ($this->getFormField('check_all')) echo '"CHECKED"'; ?> /></th>
			         <th class="clsForumSubject"><?php echo $this->LANG['managemembers_name'] ?></th>
			         <th><?php echo $this->LANG['managemembers_points']; ?></th>
			         <th class="clsReplies"><?php echo $this->LANG['managemembers_questions']; ?></th>
					 <th class="clsReplies"><?php echo $this->LANG['managemembers_answers']; ?></th>
					 <th class="clsReplies"><?php echo $this->LANG['managemembers_abuse_questions_count']; ?></th>
					 <th class="clsReplies"><?php echo $this->LANG['managemembers_abuse_answers_count']; ?></th>
					 <th class="clsReplies"><?php echo $this->LANG['managemembers_is_blocked']; ?></th>
			         <th class="clsLastPost"><?php echo $this->LANG['managemembers_status'] ?></th>
			       </tr>
				<?php
				$i = 0;
				while ($row = $this->fetchResultRecord())
				{
						$userDetails = $this->getUserDetailsFromUsersTable($this->CFG['db']['tbl']['users'], $row['user_id']);
						if ($userDetails['usr_status'] == 'Ok') $status = 'Active';
						else  $status = 'Inactive';
?>
					<tr>
						<td class="clsSelectAllMember"><input type="checkbox" class="clsCheckRadio" name="user_ids[]" onclick="disableHeading('form_manage_members');" tabindex="<?php echo $this->getTabIndex(); ?>" value="<?php echo $row['user_id']; ?>" <?php if ((is_array($this->getFormField('user_ids'))) && (in_array($row['user_id'], $this->getFormField('user_ids')))) echo "CHECKED"; ?> /></td>
						<td>
							<?php if (chkUserImageAllowed())
						{ ?>
							<p id="selImageBorder"><?php displayUserImage($userDetails, 'small', false); ?></p>
							<?php } ?>
							<?php echo $row['analyst_by']; ?>  <span><a target="_blank" href="editMembers.php?uid=<?php echo $row['user_id']; ?>"><?php echo $this->LANG['managemembers_edit']; ?></a></span>
						</td>
						<td><?php echo $row['total_points']; ?></td>
						<td><?php echo $row['total_ques']; ?></td>
						<td><?php echo $row['total_ans']; ?></td>
						<td><?php echo $this->getAbuseQuestionsCount($row['user_id']); ?></td>
						<td><?php echo $this->getAbuseAnswersCount($row['user_id']); ?></td>
						<td><?php echo $row['is_blocked']; ?></td>
						<td><?php echo $status; ?></td>
					</tr>
				<?php
						$i++;
				}



?>
				      <tr>
				        <td colspan="9"  class="<?php echo $this->getCSSFormFieldCellClass('submit'); ?>">
						 <a href="#" id="dAltMlti"></a>
						 <select class="" name="action" id="action" tabindex="<?php echo $this->getTabIndex(); ?>" >
				            <option value="block_member" <?php if ($this->getFormField('action') == 'block_member') echo 'selected=\'selected\''; ?>><?php echo $this->LANG['managemembers_block_member']; ?></option>
				            <option value="unblock_member" <?php if ($this->getFormField('action') == 'unblock_member') echo 'selected=\'selected\''; ?>><?php echo $this->LANG['managemembers_unblock_member']; ?></option>
				            <option value="active_member" <?php if ($this->getFormField('action') == 'active_member') echo 'selected=\'selected\''; ?>><?php echo $this->LANG['managemembers_active_member']; ?></option>
				            <option value="inactive_member" <?php if ($this->getFormField('action') == 'inactive_member') echo 'selected=\'selected\''; ?>><?php echo $this->LANG['managemembers_inactive_member']; ?></option>
				          </select>
				          &nbsp;
				          <input type="button" class="clsSubmitButton" name="todo" id="todo" tabindex="<?php echo $this->getTabIndex(); ?>" value="<?php echo $this->LANG['managemembers_go']; ?>" onClick="if(getMultiCheckBoxValue('form_manage_members', 'check_all', '<?php echo 'Please select Member'; ?>', 'dAltMlti', -25, -290)){Confirmation('dAltMlti', 'selMsgConfirm', 'msgConfirmform', Array('user_ids', 'action', 'confirmMessage'), Array(multiCheckValue, document.form_manage_members.action.value, '<?php echo $this->LANG['confirm_message']; ?>'), Array('value', 'value', 'innerHTML'), -25, -290, 'form_manage_members');}" />
				        </td>
				      </tr>
				</table>
				</form>
				<?php
				if ($this->CFG['admin']['navigation']['bottom']) $this->populatePageLinks($this->getFormField('start'), $pagingArr);
		}
		public function getAbuseQuestionsCount($uid)
		{
				$sql = 'SELECT COUNT(ques_id) AS abuse_count FROM ' . $this->CFG['db']['tbl']['questions'] . ' WHERE user_id=' . $this->dbObj->Param('uid') . ' AND abuse_count>0';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($uid));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = $rs->FetchRow();
				return $row['abuse_count'];
		}
		public function getAbuseAnswersCount($uid)
		{
				$sql = 'SELECT COUNT(ans_id) AS abuse_count FROM ' . $this->CFG['db']['tbl']['answers'] . ' WHERE user_id=' . $this->dbObj->Param('uid') . ' AND abuse_count>0';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($uid));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = $rs->FetchRow();
				return $row['abuse_count'];
		}
		public function displaySearchOption()
		{
?>
		  <form name="selQuestionSearchs" id="selQuestionSearch" method="post" action="<?php echo URL($this->CFG['site']['relative_url'] . 'manageAnswersMembers.php'); ?>" autocomplete="off">
		    <table summary="<?php echo $this->LANG['managemembers_tbl_summary']; ?>">
		      <tr>
		        <td class="<?php echo $this->getCSSFormLabelCellClass('search_name'); ?>"><label for="search_name"><?php echo $this->LANG['managemembers_search_name']; ?></label></td>
		        <td class="<?php echo $this->getCSSFormFieldCellClass('search_name'); ?>"><?php echo $this->getFormFieldErrorTip('search_name'); ?>
		          <input type="text" class="clsTextBox" name="search_name" id="search_name" tabindex="2000" value="<?php echo $this->getFormField('search_name'); ?>" /></td>
		      </tr>
		      <tr>
		        <td class="<?php echo $this->getCSSFormLabelCellClass('search_cat'); ?>"><label for="search_cat"><?php echo $this->LANG['managemembers_search_cat']; ?></label></td>
		        <td class="<?php echo $this->getCSSFormFieldCellClass('search_cat'); ?>"><?php echo $this->getFormFieldErrorTip('search_cat'); ?>
		          <select class="clsCommonListBox" name="search_cat" id="search_cat" tabindex="2001">
		            <option value="1" <?php if ($this->getFormField('search_cat') == '1') echo 'selected=\'selected\''; ?>>Username</option>
		            <option value="2" <?php if ($this->getFormField('search_cat') == '2') echo 'selected=\'selected\''; ?>>email</option>
		          </select>
		        </td>
		      </tr>
		      <tr>
		        <td colspan="2"  class="<?php echo $this->getCSSFormFieldCellClass('submit'); ?>"><input type="submit" class="clsSubmitButton" name="go" tabindex="2010" value="<?php echo $this->LANG['managemembers_go']; ?>" /></td>
		      </tr>
		    </table>
			</form>
			<?php
		}
		public function updateStatus($is_block)
		{
				if (!$this->fields_arr['user_ids']) return;
				$id = $this->fields_arr['user_ids'];
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['users_ans_log'] . ' SET is_blocked=' . $this->dbObj->Param($is_block) . ' WHERE user_id IN (' . $id . ')';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($is_block));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function updateUserStatus($is_block)
		{
				if (!$this->fields_arr['user_ids']) return;
				$id = $this->fields_arr['user_ids'];
				if ($is_block == 'Ok') $this->sendActivatedMail($id);
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['users'] . ' SET usr_status=' . $this->dbObj->Param($is_block) . ' WHERE user_id IN (' . $id . ')';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($is_block));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function sendActivatedMail($ids)
		{
				$sql = 'SELECT ' . $this->getUserTableFields(array('user_id', 'name', 'email')) . ' FROM ' . $this->CFG['db']['tbl']['users'] . ' WHERE ' . $this->getUserTableField('usr_status') . '=\'ToActivate\'' . ' AND ' . $this->getUserTableField('user_id') . ' IN (' . $ids . ')';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				while ($row = $rs->FetchRow())
				{
						$activation_link = "<a target=\"_blank\" href=\"" . URL($this->CFG['site']['url']) . "\">" . URL($this->CFG['site']['url']) . "</a>";
						$subject = $this->getMailContent($this->LANG['admin_activation_subject'], array('username' => $row['name'], 'email' => $row['email'], 'sitename' => $this->CFG['site']['name'], 'link' => $activation_link));
						$content = $this->getMailContent($this->LANG['admin_activation_message'], array('username' => $row['name'], 'email' => $row['email'], 'sitename' => $this->CFG['site']['name'], 'link' => $activation_link));
						$this->_sendMail($row['email'], $subject, $content, $this->CFG['site']['noreply_name'], $this->CFG['site']['noreply_email']);
				}
		}
		private function _sendMail($to_email, $subject, $body, $sender_name, $sender_email)
		{
				$mail = new PHPMailer();
				$mail->AddAddress($to_email);
				$mail->FromName = $sender_name;
				$mail->From = $mail->Sender = $sender_email;
				$mail->Subject = $subject;
				$mail->Body = $body;
				$mail->IsMail();
				$mail->IsHTML(true);
				return ($mail->Send());
		}
		public function common_hidden($hidden_field = array())
		{
				foreach ($hidden_field as $hidden_name)
				{
?>

<input type="hidden" name="user_ids[]" value="<?php echo $hidden_name; ?>" />
<?php }
		}
}
$managefrm = new ManageMembersFormHandler();
$managefrm->setCfgLangGlobal($CFG, $LANG);
$managefrm->setPageBlockNames(array('form_search', 'form_analysts', 'show_form_confirm', 'msg_form_error', 'msg_form_success'));
$managefrm->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$managefrm->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$managefrm->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$managefrm->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$managefrm->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$managefrm->setFormField('search_question', '');
$managefrm->setFormField('search_name', '');
$managefrm->setFormField('search_cat', '');
$managefrm->setFormField('action', '');
$managefrm->setFormField('user_ids', array());
$managefrm->setFormField('check_all', '');
$pagename = 'Manage Answers Members';
$title = 'Manage Answers Members';
$managefrm->setDBObject($db);
$managefrm->numpg = $CFG['data_tbl']['numpg'];
$managefrm->setFormField('start', 0);
$managefrm->setFormField('numpg', $CFG['data_tbl']['numpg']);
$managefrm->setMinRecordSelectLimit($CFG['data_tbl']['min_record_select_limit']);
$managefrm->setMaxRecordSelectLimit($CFG['data_tbl']['max_record_select_limit']);
$managefrm->setNumPerPageListArr($CFG['data_tbl']['numperpage_list_arr']);
$managefrm->setTableNames(array());
$managefrm->setReturnColumns(array());
$managefrm->setFormField('orderby_field', '');
$managefrm->setFormField('orderby', '');
$managefrm->sanitizeFormInputs($_REQUEST);
$managefrm->setAllPageBlocksHide();
$managefrm->setPageBlockShow('form_search');
$managefrm->setPageBlockShow('form_analysts');
if ($managefrm->isFormPOSTed($_POST, 'confirm_action'))
{
		if ($managefrm->getFormField('action') == 'block_member')
		{
				$managefrm->updateStatus('Yes');
				$managefrm->setCommonErrorMsg($LANG['managemembers_block_success']);
		} elseif ($managefrm->getFormField('action') == 'unblock_member')
		{
				$managefrm->updateStatus('No');
				$managefrm->setCommonErrorMsg($LANG['managemembers_unblock_success']);
		} elseif ($managefrm->getFormField('action') == 'active_member')
		{
				$managefrm->updateUserStatus('Ok');
				$managefrm->setCommonErrorMsg($LANG['managemembers_active_success']);
		} elseif ($managefrm->getFormField('action') == 'inactive_member')
		{
				$managefrm->updateUserStatus('ToActivate');
				$managefrm->setCommonErrorMsg($LANG['managemembers_inactive_success']);
		}
		$managefrm->setPageBlockShow('msg_form_success');
}
$CFG['mods']['is_include_only']['non_html_header_files'] = false;
$CFG['mods']['is_include_only']['html_header'] = true;
require ($CFG['site']['project_path'] . 'common/application_top.inc.php');



?>
<script language="javascript">
	var block_arr= new Array('selMsgConfirm');
	var replace_url = '<?php echo $CFG['site']['url']; ?>login.php';
</script>
<div id="selListAll">
	<h2 class="clsMembersTitle"><?php echo $title; ?></h2>
<?php

if ($managefrm->isShowPageBlock('msg_form_error'))
{
?>
    	<div id="selMsgError">
      		<p>
<?php
		echo $LANG['questions_err_sorry'] . ' ' . $managefrm->getCommonErrorMsg();
?>
      		</p>
    	</div>
<?php
}
if ($managefrm->isShowPageBlock('msg_form_success'))
{
?>
	    <div id="selMsgSuccess">
	      	<p>
<?php
		echo $managefrm->getCommonErrorMsg();
?>
	      	</p>
	    </div>
    <?php
}
if ($managefrm->isShowPageBlock('form_search')) $managefrm->displaySearchOption();
if ($managefrm->isShowPageBlock('form_analysts'))
{
		$managefrm->setTableNames(array($CFG['db']['tbl']['users_ans_log'] . ' as ua', $CFG['db']['tbl']['users'] . ' as u'));
		$managefrm->setReturnColumns(array('ua.user_id', 'total_ques', 'is_blocked', 'total_ans', 'total_points', $managefrm->getUserTableField('name') . ' as analyst_by', 'TIMEDIFF(NOW(), date_updated) as date_updated'));
		$managefrm->setFormField('orderby_field', 'ua.total_points');
		$managefrm->setFormField('orderby', 'DESC');
		$managefrm->buildSelectQuery();
		$managefrm->buildConditionQuery();
		$managefrm->buildSortQuery();
		$managefrm->buildQuery();
		$managefrm->executeQuery();

?>
  <div id="selMsgConfirm" class="clsPopupConfirmation" style="display:none;position:absolute;">
		<p id="confirmMessage"></p>
		<form name="msgConfirmform" id="msgConfirmform" method="post" action="<?php echo URL($_SERVER['PHP_SELF']); ?>">
			<table summary="<?php echo $LANG['managemembers_tbl_summary']; ?>">
				<tr>
					<td>
						<input type="submit" class="clsSubmitButton" name="confirm_action" id="confirm_action" tabindex="<?php echo $managefrm->getTabIndex(); ?>" value="<?php echo $LANG['managemembers_yes']; ?>" />&nbsp;
						<input type="button" class="clsCancelButton" name="cancel" id="cancel" tabindex="<?php echo $managefrm->getTabIndex(); ?>" value="<?php echo $LANG['managemembers_no']; ?>"  onClick="return hideAllBlocks('form_manage_members');" />
						<input type="hidden" name="user_ids" id="user_ids" />
						<input type="hidden" name="action" id="action" />
							<?php $managefrm->populateHiddenFormFields(array('start', 'numpg', 'search_name', 'search_cat')); ?>
					</td>
				</tr>
			</table>
		</form>
	</div>


  <?php

		$managefrm->displayTopAnalysts();
}
?>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>