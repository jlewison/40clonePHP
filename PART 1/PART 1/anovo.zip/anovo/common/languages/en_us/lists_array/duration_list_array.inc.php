<?php
$CFG['lists_array']['duration'] = array('1H' => 'Last 1 hour', '12H' => 'Last 12 hours', '24H' => 'Last 24 hours', '3D' => 'Last 3 days', '5D' => 'Last 5 days', '1W' => 'Last 1 week', '1M' => 'Last 1 month', '12M' => 'Last 12 months');
?>