<?php

// the path to the module. the probably shouldn't be changed unless you rename the sidebar_stats folder(s)
define('page_statistics_path', my_pligg_base . '/modules/page_statistics/');

// the path to the module. the probably shouldn't be changed unless you rename the sidebar_stats folder(s)
define('page_statistics_lang_conf', '/modules/page_statistics/lang.conf');

// the path to the modules templates. the probably shouldn't be changed unless you rename the sidebar_stats folder(s)
define('page_statistics_tpl_path', '../modules/page_statistics/templates/');

?>