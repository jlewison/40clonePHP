<?php
require_once ('../common/config.inc.php');
require_once ('../common/configs/config_encoder.inc.php');
require_once ('../common/configs/config_ans_audio.inc.php');
$CFG['lang']['include_files'][] = 'members/includes/languages/%s/ansViewAudio.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['mods']['is_include_only']['non_html_header_files'] = true;
$CFG['is']['ajax_page'] = true;
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class ViewAudio extends FormHandler
{
		public $audio_details;
		public function populateAudioDetails()
		{
				$param_arr = explode('_', $this->fields_arr['pg']);
				$this->fields_arr['audio_for'] = $param_arr[0];
				$this->fields_arr['aid'] = $param_arr[1];
				$file_name = $this->CFG['admin']['video']['red5_flv_path'] . $this->fields_arr['aid'] . 'AUD.flv';
				if (is_file($file_name))
				{
						$temp_dir = '../' . $this->CFG['admin']['ans_audios']['temp_folder'];
						$this->chkAndCreateFolder($temp_dir);
						$temp_file = $temp_dir . $this->fields_arr['aid'] . 'AUD.flv';
						if (file_exists($temp_file)) @unlink($temp_file);
						copy($file_name, $temp_file);
						return true;
				}
				return false;
		}
		public function resetFieldsArray()
		{
				$this->setFormField('pg', '');
		}
}
$ViewAudio = new ViewAudio();
$ViewAudio->setDBObject($db);
$ViewAudio->makeGlobalize($CFG, $LANG);
if (!isAjax()) Redirect2URL($CFG['site']['url']);
$ViewAudio->setHeaderStart();
$ViewAudio->setPageBlockNames(array('msg_form_error', 'msg_form_success', 'audio_display'));
$ViewAudio->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$ViewAudio->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$ViewAudio->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$ViewAudio->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$ViewAudio->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$ViewAudio->resetFieldsArray();
$ViewAudio->setAllPageBlocksHide();
$ViewAudio->sanitizeFormInputs($_REQUEST);
if ($ViewAudio->isFormGETed($_REQUEST, 'pg'))
{
		if (!$ViewAudio->populateAudioDetails())
		{
				$ViewAudio->setAllPageBlocksHide();
				$ViewAudio->setCommonErrorMsg($LANG['error_audio']);
				$ViewAudio->setPageBlockShow('msg_form_error');
		}
		else
		{
				$ViewAudio->setPageBlockShow('audio_display');
		}
}



?>
<div id="selViewAudio" class="">
	<p class="clsPopupClose"><a href="#" onClick="return closLightWindow()"><?php echo $LANG['close']; ?></a></p>
	<div id="selLeftNavigation">
<?php
if ($ViewAudio->isShowPageBlock('msg_form_error'))
{
?>
		  <div id="selMsgError">
		    <p><?php echo $ViewAudio->getCommonErrorMsg(); ?></p>
		  </div>
<?php
}
if ($ViewAudio->isShowPageBlock('audio_display'))
{
		$player_url = $CFG['site']['url'] . 'files/flash/mp3_player/player.swf';
		$audios_folder = $CFG['admin']['ans_audios']['audio_folder'];
		$config_url = $CFG['site']['url'] . 'ansAudioConfigXmlCode.php?pg=previewmusic_' . $ViewAudio->getFormField('aid');
		$playlist_url = $CFG['site']['url'] . 'ansAudioPlaylistXmlCode.php?pg=previewmusic_' . $ViewAudio->getFormField('aid');
		echo '<div><object height="66" width="250"><param name="movie" value="' . $player_url . '?configXmlPath=' . $config_url . '&playListXmlPath=' . $playlist_url . '"></param><param name="wmode" value="' . $CFG['admin']['wmode_value'] . '" /><embed src="' . $player_url . '?configXmlPath=' . $config_url . '&playListXmlPath=' . $playlist_url . '" type="application/x-shockwave-flash" wmode="' . $CFG['admin']['wmode_value'] . '" height="66" width="250" wmode="' . $CFG['admin']['wmode_value'] . '"></embed></object></div>';
}
?>
	</div>
</div>
<?php


$ViewAudio->setHeaderEnd();
?>