<?php
$lang['page_title']	= 'Edit profile';
$lang['editprofileeducation_high_school']			= 'High School';
$lang['editprofileeducation_attended_for']			= 'Attended for';
$lang['editprofileeducation_concentration']			= 'Concentration';
$lang['editprofileeducation_concentration2']		= 'Second Concentration';
$lang['editprofileeducation_concentration3']		= 'Third Concentration';
$lang['editprofileeducation_college']				= 'College/University';
$lang['editprofileeducation_add_concentration']		= 'Add another concentration�';
$lang['editprofileeducation_remove_school']			= 'Remove this school...';
$lang['editprofileeducation_add_school']			= 'Add another school';
$lang['editprofileeducation_attended_college']		= 'College';
$lang['editprofileeducation_attended_graduate']		= 'Graduate School';
$lang['editprofileeducation_success_msg']			= 'Education profile updated successfully!';
?>