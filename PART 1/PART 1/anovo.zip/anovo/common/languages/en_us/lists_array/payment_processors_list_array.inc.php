<?php
$LANG_LIST_ARR['payment_processors'] = array('egold' => 'Egold', 'intgold' => 'Intgold', 'stormpay' => 'StormPay', 'pecunix' => 'Pecunix', 'ebullion' => 'Ebullion', 'bankwire' => 'Bank wire');
?>