<?php
class subscribedForum extends FormHandler
{
		public $user_details = array();
		public function populateForumDetails($topic_id)
		{
				$sql = 'SELECT forum_id, total_response, forum_topic, user_id' . ' FROM ' . $this->CFG['db']['tbl']['forum_topics'] . ' WHERE topic_id = ' . $this->dbObj->Param('topic_id');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($topic_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($row = $rs->FetchRow()) return $row;
				return false;
		}
		public function populateForumList()
		{
				$sql = 'SELECT content_id FROM ' . $this->CFG['db']['tbl']['user_bookmarked'] . ' WHERE content_type = \'Forum\' AND user_id = ' . $this->dbObj->Param('user_id');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->CFG['user']['user_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if (!$rs->PO_RecordCount())
				{
?>
					<div class="clsNoRecords">
						<p><?php echo $this->LANG['no_tags_subscribed']; ?></p>
					</div>
					<?php
						return;
				}
				while ($row = $rs->FetchRow())
				{
						$forum_details = $this->populateForumDetails($row['content_id']);
?>
<p><a href="<?php echo getUrl('forumsTopics.php?forum_id=' . $forum_details['forum_id'], 'forum/' . $forum_details['forum_id'] . '/'); ?>"><?php echo $forum_details['forum_topic']; ?></a></p>
<?php
				}
		}
		public function populateUserDetailsArr()
		{
				$sql = 'SELECT ' . $this->getUserTableFields(array('name')) . ' FROM' . ' ' . $this->CFG['db']['tbl']['users'] . ' WHERE' . ' user_id = ' . $this->dbObj->Param('user_id') . ' AND' . ' ' . $this->getUserTableField('usr_status') . '=\'OK\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['uid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($row = $rs->FetchRow())
				{
						$this->user_details = $row;
						return true;
				}
				return false;
		}
}
$subscribedForum = new subscribedForum();
$subscribedForum->setDBObject($db);
$subscribedForum->makeGlobalize($CFG, $LANG);
$subscribedForum->setPageBlockNames(array('msg_form_success', 'msg_form_error', 'forum_list_block'));
$subscribedForum->setFormField('uid', '');
$subscribedForum->sanitizeFormInputs($_REQUEST);
if (!$subscribedForum->getFormField('uid')) $subscribedForum->setFormField('uid', $CFG['user']['user_id']);
if ($subscribedForum->populateUserDetailsArr())
{
		$subscribedForum->setPageBlockShow('forum_list_block');
		$LANG['back_to_user_profile_user'] = str_replace('{user_name}', $subscribedForum->user_details['name'], $LANG['back_to_user_profile_user']);
		$LANG['back_to_user_profile'] = ($CFG['user']['user_id'] == $subscribedForum->getFormField('uid')) ? $LANG['back_to_user_profile'] : $LANG['back_to_user_profile_user'];
		$LANG['page_title_user_name'] = str_replace('{user_name}', $subscribedForum->user_details['name'], $LANG['page_title_user_name']);
		$LANG['page_title'] = ($subscribedForum->getFormField('uid') == $CFG['user']['user_id']) ? $LANG['page_title'] : $LANG['page_title_user_name'];
		$back_link = '<a href="' . getUrl($CFG['site']['relative_url'] . 'myanswers.php?uid=' . $subscribedForum->getFormField('uid'), $CFG['site']['relative_url'] . 'my/answers/' . $subscribedForum->getFormField('uid') . '/', false) . '">' . $LANG['back_to_user_profile'] . '</a>';
}
else
{
		$subscribedForum->setPageBlockShow('msg_form_error');
		$subscribedForum->setCommonErrorMsg($LANG['invalid_user']);
}



?>
<script language="javascript">
	var block_arr= new Array('selMsgConfirm');
</script>
<div id="selManageBlog">
<?php
if ($subscribedForum->isShowPageBlock('forum_list_block'))
{
		$display_username = $LANG['myanswers_subscribed'];
		$uid = $subscribedForum->getFormField('uid');
		$uname = $subscribedForum->user_details['name'];
		if ($CFG['user']['user_id'] != $uid)
		{
				$display_username = str_replace('{user_name}', $uname, $LANG['myanswers_subscribed_others']);
		}
?>
	<div class="clsQuestionsLink">
		<ul>
        <li class="clsSubscribe"><?php echo $display_username; ?></li>
			<li class="clsLeftInActiveQuestionsLink"><span class="clsRightInActiveQuestionsLink"><a class="clsMiddleInActiveQuestionsLink" href="<?php echo getUrl($CFG['site']['relative_url'] . 'mySubscribedTag.php?uid=' . $uid, $CFG['site']['relative_url'] . 'mysubscribedtag/' . $uid . '/', false); ?>"><?php echo $LANG['myanswers_subscribed_tag']; ?></a></span></li>
			<li class="clsLeftInActiveQuestionsLink"><span class="clsRightInActiveQuestionsLink"><a class="clsMiddleInActiveQuestionsLink" href="<?php echo getUrl($CFG['site']['relative_url'] . 'mySubscribedUser.php?uid=' . $uid, $CFG['site']['relative_url'] . 'mysubscribeduser/' . $uid . '/', false); ?>"><?php echo $LANG['myanswers_subscribed_user']; ?></a></span></li>
			<li class="clsLeftActiveQuestionsLink"><span class="clsRightActiveQuestionsLink"><a class="clsMiddleActiveQuestionsLink" href="<?php echo getUrl($CFG['site']['relative_url'] . 'mySubscribedForum.php?uid=' . $uid, $CFG['site']['relative_url'] . 'mysubscribedforum/' . $uid . '/', false); ?>"><?php echo $LANG['myanswers_subscribed_forum']; ?></a></span></li>
		</ul>
	</div>
<?php
}
if ($subscribedForum->isShowPageBlock('msg_form_error'))
{
?>
  	<div id="selMsgError">
   		<p><?php echo $subscribedForum->getCommonErrorMsg(); ?></p>
  	</div>
<?php
}
if ($subscribedForum->isShowPageBlock('msg_form_success'))
{
?>
	<div id="selMsgSuccess">
		<p><?php echo $subscribedForum->getCommonErrorMsg(); ?></p>
	</div>
<?php
}
if ($subscribedForum->isShowPageBlock('forum_list_block'))
{
?>
	<div id="selSubscribedTags" class="clsCommonIndexSection">
		<div id="selWidgetRecentQuestions" class="clsSubscribeForum clsSideBarSections">
			<?php $subscribedForum->populateForumList(); ?>
		</div>
	</div>
<?php
}
?>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>
