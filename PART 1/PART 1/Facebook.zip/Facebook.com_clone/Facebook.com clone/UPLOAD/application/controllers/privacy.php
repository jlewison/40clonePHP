<?php
/**
 * Privacy Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 16-12-2007
 */
class Privacy extends Controller
{
		//Constructor
		function Privacy()
		{
				parent::Controller();
				loginRequired();
				//Load the language file
				$this->lang->load('privacy', $this->config->item('language_code'));
				//Load the user model
				$this->load->model('usermodel');
		}
		//Default function
		function index()
		{
				$outputData['blockedUsers'] = $this->usermodel->getBlockedUsers();
				$outputData['blockedUsersCnt'] = count($outputData['blockedUsers']);
				$this->smartyextended->view('privacy', $outputData);
		}
		function profile()
		{
				$outputData['privacySetting'] = $this->usermodel->getPrivacySetting();
				$outputData['privacy'] = $this->usermodel->getPrivacy();
				if (isset($_POST) && is_array($_POST) && count($_POST) > 0)
				{
						$this->usermodel->setPrivacySetting($_POST);
						$this->usermodel->setPrivacySettingNetwork($this->input->post('chk_network'));
						$outputData['msg'] = $this->lang->line('privacy_profile_save_success');
				}
				$outputData['userJoinedInNw'] = $this->usermodel->isUserJoinedAnyNetworks();
				$outputData['userPrivacy'] = $this->usermodel->getUserPrivacySetting();
				$outputData['userNetworks'] = $this->usermodel->getUserNetworks();
				$outputData['userPrivacySettingNetwork'] = $this->usermodel->getUserPrivacySettingNetwork();
				$this->smartyextended->view('privacyprofile', $outputData);
		}
		function search()
		{
				if (isset($_POST) && is_array($_POST) && count($_POST) > 0)
				{
						$saveSettings = $this->input->post('searchSettingViewChk');
						if ($this->input->post('searchSettingView') != false)
						{
								$saveSettings[$this->input->post('searchSettingView')] = $this->input->post('searchSettingView');
								//some of my networks
								if ($this->input->post('searchSettingView') == 3)
								{
										$this->usermodel->setSearchSettingNetwork($this->input->post('chk_network'));
								}
						}
						$this->usermodel->setSearchSetting($saveSettings);
						if ($this->input->post('searchSettingView') == 1) //Everyone

						{
								$profileIds = '';
								$networkIds = '';
						} elseif ($this->input->post('searchSettingView') == 2) //All my networks and all my friends

						{
								$profileIds = '0';
								$friends = $this->usermodel->getFriends('', false);
								if (count($friends) > 0) $friends = array_keys($friends);
								if (is_array($friends) && count($friends) > 0) $profileIds = implode(',', $friends);
								$profileIds = ',' . trim($profileIds, ',') . ',';
								$networkIds = '0';
								$userNetworks = $this->usermodel->getUserNetworks();
								if (count($userNetworks) > 0) $userNetworks = array_keys($userNetworks);
								if (is_array($userNetworks) && count($userNetworks) > 0) $networkIds = implode(',', $userNetworks);
								$networkIds = ',' . trim($networkIds) . ',';
						} elseif ($this->input->post('searchSettingView') == 3) //Some of my networks and all my friends

						{
								$profileIds = '0';
								$friends = $this->usermodel->getFriends('', false);
								if (count($friends) > 0) $friends = array_keys($friends);
								if (is_array($friends) && count($friends) > 0) $profileIds = implode(',', $friends);
								$profileIds = ',' . trim($profileIds, ',') . ',';
								$networkIds = '0';
								$chkNetwork = $this->input->post('chk_network');
								if (is_array($chkNetwork) && count($chkNetwork) > 0) $networkIds = implode(',', $chkNetwork);
								$networkIds = ',' . trim($networkIds, ',') . ',';
						} elseif ($this->input->post('searchSettingView') == 4) //Only my friends

						{
								$profileIds = '0';
								$friends = $this->usermodel->getFriends('', false);
								if (count($friends) > 0) $friends = array_keys($friends);
								if (is_array($friends) && count($friends) > 0) $profileIds = implode(',', $friends);
								$networkIds = '0';
						}
						$profileIds = ($profileIds == ',,') ? '' : $profileIds;
						$networkIds = ($networkIds == ',,') ? '' : $networkIds;
						$moreSettings = array('college_network' => (isset($saveSettings[9]) && $saveSettings[9] == 9) ? 1 : 0, 'school_network' => (isset($saveSettings[10]) && $saveSettings[10] == 10) ? 1 : 0, 'company_network' => (isset($saveSettings[11]) && $saveSettings[11] == 11) ? 1 : 0, 'regional_network' => (isset($saveSettings[12]) && $saveSettings[12] == 12) ? 1 : 0, 'no_network' => (isset($saveSettings[13]) && $saveSettings[13] == 13) ? 1 : 0, );
						$this->usermodel->setSearchProfile('', $profileIds, $networkIds, $moreSettings);
						$outputData['msg'] = $this->lang->line('privacy_search_save_success');
				}
				$outputData['searchSettingView'] = $this->usermodel->getSearchSetting('view');
				$outputData['searchSettingProfile'] = $this->usermodel->getSearchSetting('profile');
				$outputData['searchSettingNetwork'] = $this->usermodel->getSearchSetting('network');
				$outputData['userSearchSetting'] = $this->usermodel->getUserSearchSetting();
				$outputData['userNetworks'] = $this->usermodel->getUserNetworks();
				$outputData['userSearchSettingNetworks'] = $this->usermodel->getUserSearchSettingNetwork();
				$this->smartyextended->view('privacysearch', $outputData);
		}
		function feed()
		{
				if (isset($_POST) && is_array($_POST) && count($_POST) > 0)
				{
						$this->usermodel->setFeedSetting($this->input->post('feedSetting'));
						$outputData['msg'] = $this->lang->line('privacy_feed_save_success');
				}
				$outputData['feedSetting'] = $this->usermodel->getFeedSetting();
				$outputData['userFeedSetting'] = $this->usermodel->getUserFeedSetting();
				$this->smartyextended->view('privacyfeed', $outputData);
		}
		function message()
		{
				if (isset($_POST) && is_array($_POST) && count($_POST) > 0)
				{
						$this->usermodel->setMessageSetting($this->input->post('messageSetting'));
						$outputData['msg'] = $this->lang->line('privacy_message_save_success');
				}
				$outputData['messageSetting'] = $this->usermodel->getMessageSetting();
				$outputData['userMessageSetting'] = $this->usermodel->getUserMessageSetting();
				$this->smartyextended->view('privacymessage', $outputData);
		}
		function block()
		{
				if ($this->uri->segment(3) == 'remove')
				{
						$this->usermodel->removeBlockedUser($this->uri->segment(4));
						//Set the flash data
						$this->session->set_flashdata('flash_msg', $this->lang->line('privacy_remove_save_success'));
						redirect('privacy');
				} elseif ($this->input->post('block_people') == 'blockPeople')
				{
						$userId = $this->input->post('blockUserId');
						$this->usermodel->blockUser($userId);
						//Set the flash data
						$this->session->set_flashdata('flash_msg', $this->lang->line('privacy_block_save_success'));
				}
				redirect('privacy');
		}
}

?>