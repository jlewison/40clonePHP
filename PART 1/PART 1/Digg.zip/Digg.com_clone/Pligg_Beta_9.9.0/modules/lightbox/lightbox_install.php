<?php
	$module_info['name'] = 'Lightbox';
	$module_info['desc'] = 'Lightbox is a script used to overlay private messages on the current page';
	$module_info['version'] = 0.1;
?>