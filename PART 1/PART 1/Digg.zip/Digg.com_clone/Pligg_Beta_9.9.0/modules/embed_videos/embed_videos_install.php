<?php
	$module_info['name'] = 'Embed Videos';
	$module_info['desc'] = 'Embed various video sites into Pligg through simple tags.';
	$module_info['version'] = 0.51;
?>