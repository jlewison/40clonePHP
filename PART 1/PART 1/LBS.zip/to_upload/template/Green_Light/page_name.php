<?php
//$step1 = str_replace("http", "", $wsn);
//$step2 = str_replace(":", "", $step1);
//$step3 = str_replace("/", "", $step2);
//$step4 = str_replace("www", "", $step3);
//$step5 = str_replace(".", "", $step4);
//$step6 = str_replace("html", "", $step5);
//$step7 = str_replace("htm", "", $step6);
//$step8 = str_replace("php", "", $step7);
//$wsseoname = "$step8";
$step8 = str_replace(" ", "-", $wsn);
$wsseoname = "$step8";
?>