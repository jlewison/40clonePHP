<?php
if (!$CFG['mods']['is_include_only']['html_header'])
{
		set_magic_quotes_runtime(0);
		if (ini_get('register_globals'))
		{
				if (isset($_REQUEST['GLOBALS']) || isset($_FILES['GLOBALS']))
				{
						die('GLOBALS overwrite attempt detected');
				}
				$noUnset = array('GLOBALS', '_GET', '_POST', '_COOKIE', '_REQUEST', '_SERVER', '_ENV', '_FILES');
				$input = array_merge($_GET, $_POST, $_COOKIE, $_SERVER, $_ENV, $_FILES, isset($_SESSION) && is_array($_SESSION) ? $_SESSION : array());
				foreach ($input as $k => $v)
				{
						if (!in_array($k, $noUnset) && isset($GLOBALS[$k]))
						{
								unset($GLOBALS[$k]);
						}
				}
		}
		if (get_magic_quotes_gpc())
		{
				function stripslashes_deep($value)
				{
						$value = is_array($value) ? array_map('stripslashes_deep', $value) : stripslashes($value);
						return $value;
				}
				$_POST = array_map('stripslashes_deep', $_POST);
				$_GET = array_map('stripslashes_deep', $_GET);
				$_COOKIE = array_map('stripslashes_deep', $_COOKIE);
				$_REQUEST = array_map('stripslashes_deep', $_REQUEST);
		}
		global $DEBUG_TRACE;
		function URL($url)
		{
				return $url;
		}
		function isValidLicense()
		{
				return true;
				global $CFG;
				$str = $CFG['app']['license_key'] . gethostbyaddr($_SERVER['SERVER_ADDR']) . 'rayzz';
				return ($CFG['app']['license_verified'] == md5($str));
		}
		if ($CFG['license'])
				if (!isset($CFG['app']['license_verified']) or (!function_exists('isValidLicense')) or !isValidLicense())
				{
						echo 'Invalid License';
						exit;
				}
		function ShowHelpTip($tip_key)
		{
				global $LANG, $CFG;
				$tip = $LANG['help'][$tip_key]['text'] . ': ' . str_replace("\n", '&#13;', $LANG['help'][$tip_key]['desc']);
?>
<a href="<?php echo $CFG['site']['url'] ?>help.php#<?php echo $tip_key; ?>" title="<?php echo $tip; ?>" class="clsHelp" id="Help_<?php echo $tip_key; ?>"><?php echo $LANG['help_text']; ?></a>
<?php
		}
		function ShowToolTip($tip_key = '')
		{
				if (!chkToolTipAllowed()) return;
				global $LANG, $CFG;
				$tool_tip = '';
				if ($tip_key and isset($LANG['help'][$tip_key])) $tool_tip = str_replace("\n", '&#13;', $LANG['help'][$tip_key]['desc']) . ' : ';
				$tool_tip .= $LANG['tooltip_required'];
				echo $tool_tip;
		}
		function FMT_DATE($date)
		{
				return $date;
		}
		function FMT_AMOUNT($amount)
		{
				global $CFG;
				$exponent = pow(10, $CFG['framework']['no_of_decimals']);
				return (floor($amount * $exponent) / $exponent);
		}
		function ExposeQuery($msg, $newline)
		{
				global $SQL_QUERIES;
				$SQL_QUERIES .= "\n" . $msg . "\n";
		}
		function DEBUG($var_name, $var_desc = '')
		{
				global $CFG, $DEBUG_TRACE;
				if ($CFG['debug']['is_debug_mode'])
				{
						$DEBUG_TRACE .= "\n" . $var_desc . ':';
						if (!is_array($var_name)) $var_name = htmlspecialchars($var_name);
						$DEBUG_TRACE .= print_r($var_name, true);
						if (is_array($var_name)) reset($var_name);
						$DEBUG_TRACE .= "\n";
				}
		}
		function Redirect2URL($url)
		{
				if (!headers_sent())
				{
						header('Location: ' . URL($url));
						if (stristr($_SERVER['SERVER_SIGNATURE'], 'IIS')) header('Refresh: 0;url=' . $url);
				}
				else
				{
						trigger_error('Headers already sent', E_USER_NOTICE);
						echo '<meta http-equiv="refresh" content="0; URL=' . URL($url) . '" />' . "\n";
						echo '<p>Please click this <a href="' . URL($url) . '">link</a> to continue...</p>' . "\n";
				}
				exit(0);
		}
		function getUrl($normal, $htaccess, $change = true)
		{
				global $CFG;
				if ($change)
				{
						if ($CFG['url']['rewrite']) return $CFG['site']['relative_url'] . $htaccess;
						return $CFG['site']['relative_url'] . $normal;
				}
				if ($CFG['url']['rewrite']) return $htaccess;
				return $normal;
		}
		function chkAllowedModule($module_arr = array())
		{
				global $CFG;
				foreach ($module_arr as $key => $value)
				{
						if (!isset($CFG['admin']['module'][$value]) or !$CFG['admin']['module'][$value]) return false;
				}
				return true;
		}
		function chkVideoAllowed($type)
		{
				global $CFG;
				if (!isset($CFG['admin']['module']['video']) or !$CFG['admin']['module']['video']) return false;
				if (!isset($CFG['admin'][$type]['video']) or !$CFG['admin'][$type]['video']) return false;
				return true;
		}
		function chkAudioAllowed($type)
		{
				global $CFG;
				if (!isset($CFG['admin']['module']['audio']) or !$CFG['admin']['module']['audio']) return false;
				if (!isset($CFG['admin'][$type]['audio']) or !$CFG['admin'][$type]['audio']) return false;
				return true;
		}
		function chkToolTipAllowed()
		{
				global $CFG;
				if (!isset($CFG['admin']['tool_tip']['allowed']) or !$CFG['admin']['tool_tip']['allowed']) return false;
				return true;
		}
		function chkUserImageAllowed()
		{
				global $CFG;
				if (!isset($CFG['admin']['profile_image']['allowed']) or !$CFG['admin']['profile_image']['allowed']) return false;
				return true;
		}
		function getImageName($text)
		{
				$text = md5($text);
				return substr($text, 0, 15);
		}
		function DISP_IMAGE($cfg_width = 0, $cfg_height = 0, $img_width = 0, $img_height = 0)
		{
				if ($cfg_width > 0 and $cfg_height > 0 and ($cfg_width < $img_width) and ($cfg_height < $img_height)) $attr = ($img_width > $img_height) ? " width=\"" . $cfg_width . "\"" : " height=\"" . $cfg_height . "\"";
				else
						if ($cfg_width > 0 and $cfg_width < $img_width) $attr = " width=\"" . $cfg_width . "\"";
						else
								if ($cfg_height > 0 and $cfg_height < $img_height) $attr = " height=\"" . $cfg_height . "\"";
								else  $attr = "";
				return $attr;
		}
		function isAjax()
		{
				return isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest';
		}
		function displayBlock($allowed_pages = array(), $reverse = false)
		{
				$script_name = substr($_SERVER['SCRIPT_NAME'], strrpos($_SERVER['SCRIPT_NAME'], '/') + 1);
				if (!$reverse)
				{
						if (in_array($script_name, $allowed_pages)) return true;
						return false;
				}
				else
				{
						if (!in_array($script_name, $allowed_pages)) return true;
						return false;
				}
		}
		function getTimeDiffernceFormat($time)
		{
				$date_added_pc = explode(':', $time);
				$date_added_pc[0] = intval($date_added_pc[0]);
				$date_added_pc[1] = intval($date_added_pc[1]);
				$date_added_pc[2] = intval($date_added_pc[2]);
				if ($date_added_pc[0])
				{
						$day = floor($date_added_pc[0] / 24);
						if ($day > 365)
						{
								$year = floor($day / 365);
								if ($year == 1) $time = $year . ' year ago';
								else  $time = $year . ' years ago';
						}
						else
								if ($day > 30)
								{
										$month = floor($day / 30);
										if ($month == 1) $time = $month . ' month ago';
										else  $time = $month . ' months ago';
								}
								else
										if ($day)
										{
												if ($day == 1) $time = $day . ' day ago';
												else  $time = $day . ' days ago';
										}
										else
										{
												if ($date_added_pc[0] == 1) $time = $date_added_pc[0] . ' hour ago';
												else  $time = $date_added_pc[0] . ' hours ago';
										}
				}
				else
						if ($date_added_pc[1])
						{
								if ($date_added_pc[1] == 1) $time = $date_added_pc[1] . ' minute ago';
								else  $time = $date_added_pc[1] . ' minutes ago';
						}
						else
						{
								if ($date_added_pc[2] == 1) $time = $date_added_pc[2] . ' second ago';
								else  $time = $date_added_pc[2] . ' seconds ago';
						}
						return $time;
		}
		function getTimeToGoFormat($time)
		{
				$date_added_pc = explode(':', $time);
				$date_added_pc[0] = intval($date_added_pc[0]);
				$date_added_pc[1] = intval($date_added_pc[1]);
				$date_added_pc[2] = intval($date_added_pc[2]);
				if ($date_added_pc[0])
				{
						$day = floor($date_added_pc[0] / 24);
						if ($day > 365)
						{
								$year = floor($day / 365);
								if ($year == 1) $time = $year . ' year left to answer';
								else  $time = $year . ' years left to answer';
						}
						else
								if ($day > 30)
								{
										$month = floor($day / 30);
										if ($month == 1) $time = $month . ' month left to answer';
										else  $time = $month . ' months left to answer';
								}
								else
										if ($day)
										{
												if ($day == 1) $time = $day . ' day left to answer';
												else  $time = $day . ' days left to answer';
										}
										else
										{
												if ($date_added_pc[0] == 1) $time = $date_added_pc[0] . ' hour left to answer';
												else  $time = $date_added_pc[0] . ' hours left to answer';
										}
				}
				else
						if ($date_added_pc[1])
						{
								if ($date_added_pc[1] == 1) $time = $date_added_pc[1] . ' minute left to answer';
								else  $time = $date_added_pc[1] . ' minutes left to answer';
						}
						else
						{
								if ($date_added_pc[2] == 1) $time = $date_added_pc[2] . ' second left to answer';
								else  $time = $date_added_pc[2] . ' seconds left to answer';
						}
						return $time;
		}
		$______ADVERTISEMENT_ID = array();
		function getAdvertisement($block)
		{
				global $CFG;
				global $db;
				global $______ADVERTISEMENT_ID;
				$current_page = $CFG['html']['current_script_name'];
				if (($current_page == 'myHome' and isset($_REQUEST['shtblt']))) return;
				$admin_add = true;
				if ($admin_add)
				{
						$sql = 'SELECT add_id, source FROM ' . $CFG['db']['tbl']['advertisement'] . ' WHERE' . ' post_from=\'Admin\' AND block=' . $db->Param('block') . ' AND status=\'activate\'';
						if ($CFG['admin']['banner']['impressions_date'])
						{
								$sql .= ' AND NOW()>=start_date AND (((allowed_impressions!=\'\' AND allowed_impressions!=0) AND' . ' (completed_impressions<allowed_impressions)) OR ((allowed_impressions=\'\'' . ' OR allowed_impressions=0) AND (end_date!=\'0000-00-00 00:00:00\'' . ' AND end_date>NOW()))) ORDER BY RAND() LIMIT 0,1';
						}
						$stmt = $db->Prepare($sql);
						$rs = $db->Execute($stmt, array($block));
						if (!$rs) trigger_error($db->ErrorNo() . ' ' . $db->ErrorMsg(), E_USER_ERROR);
						$total_count = $rs->PO_RecordCount();
						if (!$total_count) return false;
				}
				$add_array = array();
				$need = rand(1, $total_count);
				$i = 1;
				while ($row = $rs->FetchRow())
				{
						if ($need != $i)
						{
								$i++;
								continue;
						}
						$______ADVERTISEMENT_ID[$row['add_id']] = $row['add_id'];
						return html_entity_decode($row['source']);
				}
		}
		function updateAdvertisementCount()
		{
				global $______ADVERTISEMENT_ID;
				global $CFG;
				global $db;
				if (!$CFG['admin']['banner']['impressions_date']) return;
				if (sizeof($______ADVERTISEMENT_ID))
				{
						$sql = 'UPDATE ' . $CFG['db']['tbl']['advertisement'] . ' SET' . ' completed_impressions=completed_impressions+1' . ' WHERE add_id IN(' . implode(',', $______ADVERTISEMENT_ID) . ')';
						$stmt = $db->Prepare($sql);
						$rs = $db->Execute($stmt);
						if (!$rs) trigger_error($db->ErrorNo() . ' ' . $db->ErrorMsg(), E_USER_ERROR);
						$______ADVERTISEMENT_ID = array();
				}
		}
		function RedirectAjaxPage()
		{
				global $CFG;
				if ($CFG['is']['ajax_page'])
				{
						$url = $CFG['auth']['ajax_url'];
				}
				else
				{
						$url = $CFG['auth']['login_url'];
				}
				return $url;
		}
		function getUserProfileBadgeUrl($username = '', $append_script = true)
		{
				global $CFG;
				$badgeUrl = getUrl($CFG['site']['url'] . 'embedContent.php?embed=user&user=' . $username, $CFG['site']['url'] . 'embed/user/' . $username . '/', false);
				if ($append_script)
				{
						$badgeUrl = '<script src="' . $badgeUrl . '"></script>';
				}
				return $badgeUrl;
		}
		function getSearchString($tags)
		{
				return $tags = '[[:<:]]' . preg_replace('/\s+/', '|', $tags) . '[[:>:]]';
				$tags = trim($tags);
				while (strpos($tags, '  '))
				{
						$tags = str_replace('  ', ' ', $tags);
				}
				$tags = addslashes($tags);
				$tags_arr = explode(' ', $tags);
				$tags = '[[:<:]]' . implode('[[:>:]]|[[:<:]]', $tags_arr) . '[[:>:]]';
				return $tags;
		}
		function replaceChar($search_value, $replace, $text)
		{
				if (is_array($search_value))
				{
						foreach ($search_value as $key => $value) $text = str_replace($value, $replace, $text);
						return $text;
				}
				return str_replace($char, $replace, $text);
		}
		function getSearchRegularExpressionQuery($tags, $field_name, $extra = '')
		{
				global $CFG;
				$not_allowed_search_array = $CFG['admin']['not_allowed_chars'];
				$tags = replaceChar($not_allowed_search_array, '-', $tags);
				$tags = addslashes($tags);
				$additional_query = ' (' . $field_name . ' REGEXP \'' . getSearchString($tags) . '\') ' . $extra . ' ';
				return $additional_query;
		}
		function getQuestionBadgeUrl($qid = '', $append_script = true)
		{
				global $CFG;
				$badgeUrl = getUrl($CFG['site']['url'] . 'embedContent.php?embed=question&qid=' . $qid, $CFG['site']['url'] . 'embed/question/' . $qid . '/', false);
				if ($append_script)
				{
						$badgeUrl = '<script src="' . $badgeUrl . '"></script>';
				}
				return $badgeUrl;
		}
		function writeLog($file_name, $text)
		{
				$text = "\n\n=====================================================================================================\n\n" . $text;
				$fh = @fopen($file_name, "a");
				@fwrite($fh, $text);
				@fclose($fh);
		}
		function wordWrapManual($text, $length, $total_length = 0)
		{
				if ($total_length)
				{
						$text = strip_tags($text);
						if (strlen($text) > $total_length) $text = substr($text, 0, $total_length - 3) . '...';
						return wordwrap($text, $length, ' ', 1);
				}
				$str_length = strlen($text);
				$skip = 0;
				$returnvar = '';
				$wrap = 0;
				for ($i = 0; $i <= $str_length; $i = $i + 1)
				{
						$char = substr($text, $i, 1);
						if ($char == '<' || $char == '&') $skip = 1;
						elseif ($char == '>' || $char == ';') $skip = 0;
						elseif ($char == ' ') $wrap = 0;
						else
								if ($skip == 0) $wrap = $wrap + 1;
						$returnvar = $returnvar . $char;
						if ($wrap > $length)
						{
								$returnvar = $returnvar . ' ';
								$wrap = 0;
						}
				}
				return $returnvar;
		}
		function wordWrapManualWithSpace($string, $totlength, $total_length = 0)
		{
				$length = strlen($string);
				for ($i = 0; $i <= $length; $i = $i + 1)
				{
						$char = substr($string, $i, 1);
						if ($char == "<") $skip = 1;
						elseif ($char == ">") $skip = 0;
						elseif ($char == " ") $wrap = 0;
						if (!isset($skip)) $skip = 0;
						if (!isset($wrap)) $wrap = 0;
						if ($skip == 0) $wrap = $wrap + 1;
						if (!isset($returnvar)) $returnvar = '';
						$returnvar = $returnvar . $char;
						if ($wrap > $totlength)
						{
								$returnvar = $returnvar . " ";
								$wrap = 0;
						}
				}
				return $returnvar;
		}
		function stripString($str, $length = 25)
		{
				if (strlen($str) > $length) $str = substr($str, 0, ($length - 3)) . '...';
				return $str;
		}
		function getPopupId()
		{
				global $popup_id;
				return $popup_id += 1;
		}
		function displayUserImage($img_arr, $img_type, $showPopup = true, $contentDisplay = false)
		{
				global $CFG;
				if (chkUserImageAllowed())
				{
						$img_src = '';
						$width = '';
						$attr = '';
						$img_type_lc = strtolower($CFG['admin']['ans_photos'][$img_type . '_name']);
						if (isset($img_arr['image_path']) and !empty($img_arr['image_path']))
						{
								$img_src = $img_arr['image_path'];
								$attr = ' width="' . $CFG['admin']['ans_photos'][$img_type . '_width'] . '"';
						}
						else
								if (isset($img_arr['photo_ext']) and (!empty($img_arr['photo_ext'])))
								{
										$img_src = $img_arr['photo_server_url'] . $CFG['admin']['ans_photos']['folder'] . getImageName($img_arr['img_user_id']) . $CFG['admin']['ans_photos'][$img_type . '_name'] . '.' . $img_arr['photo_ext'];
										$attr = DISP_IMAGE($CFG['admin']['ans_photos'][$img_type . '_width'], $CFG['admin']['ans_photos'][$img_type . '_height'], $img_arr[$img_type_lc . '_width'], $img_arr[$img_type_lc . '_height']);
								} elseif (isset($img_arr['gender']) and !empty($img_arr['gender']))
								{
										$gender = strtoupper($img_arr['gender']);
										$img_src = $CFG['site']['url'] . 'images/no-female-' . $img_type . '.jpg';
										if ($gender == 'M' || $gender == 'MALE') $img_src = $CFG['site']['url'] . 'images/no-male-' . $img_type . '.jpg';
								}
						if ($img_src)
						{
								$altName = (isset($img_arr['asked_by'])) ? $img_arr['asked_by'] : ((isset($img_arr['answered_by'])) ? $img_arr['answered_by'] : ((isset($img_arr['name'])) ? $img_arr['name'] : ''));
								$altName = stripString($altName, $CFG['username']['short_length']);
								$user_url = getUrl($CFG['site']['relative_url'] . 'myanswers.php?uid=' . $img_arr['user_id'], $CFG['site']['relative_url'] . 'my/answers/' . $img_arr['user_id'] . '/', false);
								if (strpos($CFG['site']['relative_url'], 'admin/')) $user_url = getUrl($CFG['site']['url'] . 'members/myanswers.php?uid=' . $img_arr['user_id'], $CFG['site']['url'] . 'members/my/answers/' . $img_arr['user_id'] . '/', false);
								if ($showPopup)
								{
										$url = $CFG['site']['relative_url'] . 'userDetails.php';
										$pars = 'uid=' . $img_arr['user_id'];
										$popupDivId = 'popup_' . getPopupId();

?>
<div id="selDispUserImage">
	<?php
										$onmouseover = 'showUserInfoPopup(\'' . $url . '\', \'' . $pars . '\', \'' . $popupDivId . '\');';
										if ($contentDisplay)
										{
												$onmouseover .= 'changePopupDivPosition(\'' . $popupDivId . '\');';
										}
										$onmouseover = 'onmouseover="' . $onmouseover . '"';
?>
	<p id="selImageBorder"><a href="<?php echo $user_url; ?>" id="<?php echo 'img' . $popupDivId; ?>"><img src="<?php echo $img_src; ?>"<?php echo $attr; ?> alt="<?php echo $altName; ?>" <?php echo $onmouseover; ?> onmouseout="hideUserInfoPopup('<?php echo $popupDivId; ?>')" /></a></p>
	<div id="<?php echo $popupDivId; ?>" class="clsUserPopUp" style="display:none;" onmouseover="showUserInfoPopup('<?php echo $url; ?>', '<?php echo $pars; ?>', '<?php echo $popupDivId; ?>');" onmouseout="hideUserInfoPopup('<?php echo $popupDivId; ?>')"></div>
</div>
<?php
								}
								else
								{
?>
<span id="selDispUserImage"><a class="clsNoBorder" href="<?php echo $user_url; ?>"><img src="<?php echo $img_src; ?>"<?php echo $attr; ?> alt="<?php echo $altName; ?>" /></a></span>
<?php
								}
						}
				}
		}
		function displayForumUserSmallImage($img_arr, $showPopup = true, $contentDisplay = false)
		{
				displayUserImage($img_arr, 'small', $showPopup, $contentDisplay);
				return;
		}
		function displayBlogUserSmallImage($img_arr, $showPopup = true)
		{
				displayUserImage($img_arr, 'small', $showPopup);
				return;
		}
		function displayTopAnalystSmallImage($img_arr, $showPopup = true, $contentDisplay = false)
		{
				displayUserImage($img_arr, 'small', $showPopup, $contentDisplay);
				return;
		}
		function makeClickableLinks($text)
		{
				$text = eregi_replace('(((f|ht){1}tp://)[-a-zA-Z0-9@:%_\+.~#?&//=]+)', '<a href="\\1">\\1</a>', $text);
				$text = eregi_replace('(([[:space:]()[{}])|^)(www.[-a-zA-Z0-9@:%_\+.~#?&//=]+)', '\\1<a href="http://\\3">\\3</a>', $text);
				$text = eregi_replace('([_\.0-9a-z-]+@([0-9a-z][0-9a-z-]+\.)+[a-z]{2,3})', '<a href="mailto:\\1">\\1</a>', $text);
				return $text;
		}
		function isDemoSite()
		{
				global $CFG;
				if (isset($CFG['admin']['is_demo_site']) and $CFG['admin']['is_demo_site'] == true)
				{
						if (strstr($CFG['site']['url'], $CFG['admin']['demo_host_name']))
						{
								return true;
						}
				}
				return false;
		}
		function isDemoSiteAndDemoUser($user_id)
		{
				global $CFG;
				if (isset($CFG['admin']['is_demo_site']) and $CFG['admin']['is_demo_site'] == true)
				{
						if (strstr($CFG['site']['url'], $CFG['admin']['demo_host_name']))
						{
								$user_name = getUserName($user_id);
								if (in_array($user_name, $CFG['admin']['demo_user_name']))
								{
										return true;
								}
						}
				}
				return false;
		}
		function isDemoSiteAndDemoUserId($user_id)
		{
				global $CFG;
				if (isset($CFG['admin']['is_demo_site']) and $CFG['admin']['is_demo_site'] == true)
				{
						if (strstr($CFG['site']['url'], $CFG['admin']['demo_host_name']))
						{
								$demo_users = explode(',', $CFG['admin']['demo_user_ids']);
								if (in_array($user_id, $demo_users))
								{
										return true;
								}
						}
				}
				return false;
		}
		function getUserName($user_id)
		{
				global $db;
				global $CFG;
				$sql = 'SELECT name FROM  ' . $CFG['db']['tbl']['users'] . ' WHERE user_id=\'' . $user_id . '\'';
				$stmt = $db->Prepare($sql);
				$rs = $db->Execute($stmt);
				if (!$rs) trigger_error($db->ErrorNo() . ' ' . $db->ErrorMsg(), E_USER_ERROR);
				$row = array();
				if ($rs->PO_RecordCount())
				{
						$row = $rs->FetchRow();
						return strtolower($row['user_name']);
				}
				return false;
		}
		function populateRichTextEdit($field_name = '', $value = '', $useHtmlSpChars = true)
		{
				global $CFG;
				global $LANG;
				$param = $CFG['site']['name'] . 'page';
				$_SESSION[$param] = urlencode($value);
?>
	<script language="JavaScript" type="text/javascript" src="<?php echo $CFG['site']['url']; ?>js/richtext.js"></script>
	<script language="JavaScript" type="text/javascript">
		var palette_url = '<?php echo $CFG['site']['url'] . 'admin/palette.htm'; ?>';
		var field_name = '<?php echo $field_name; ?>';
		var filenameNew = "<?php echo $CFG['site']['url']; ?>richText.php?htmSpChar=<?php echo $useHtmlSpChars ? 1 : 0; ?>&source=<?php echo $param; ?>";
		function submitForm() {
			updateRTE('rte1');
			alert("rte1 = " + document.RTEDemo.rte1.value);
			return false;
		}
		initRTE("<?php echo $CFG['site']['url']; ?>admin/images/", "<?php echo $CFG['site']['url'] . 'admin/'; ?>", "");
	</script>
	<noscript><p><b><?php echo $LANG['javascript_enabled']; ?></b></p></noscript>
	<script language="JavaScript" type="text/javascript">
		if(!b.isFirefox())
			{
				writeRichText('rte1', '', 400, 200, true, false);
			}
	</script>
	<?php
				if ($useHtmlSpChars)
				{
						$value = htmlspecialchars($value);
				}
?>
	<input type="hidden" id="<?php echo $field_name; ?>" name="<?php echo $field_name; ?>" value="<?php echo ($value); ?>" />
	<script language="JavaScript" type="text/javascript">
		if(b.isFirefox())
			{
				writeRichText('rte1', '', 400, 200, true, false);
			}
	</script>
<?php
		}
		if ($CFG['feature']['gzip']['is_use_gzip'] && extension_loaded('zlib') && (PHP_VERSION >= '4'))
		{
				if ((int)ini_get('zlib.output_compression') < 1)
				{
						if (PHP_VERSION >= '4.0.4') ob_start('ob_gzhandler');
				}
				else  ini_set('zlib.output_compression_level', $CFG['feature']['gzip']['level']);
		}
		if ($CFG['debug']['is_custom_handler'])
		{
				require_once ($CFG['site']['project_path'] . 'common/classes/class_ErrorHandler.lib.php');
				$errHandler = new ErrorHandler();
				$errHandler->setErrorLevel($CFG['debug']['error_level']);
				$errHandler->setIsDebugMode($CFG['debug']['is_debug_mode']);
				$errHandler->setNumSourceToFetch($CFG['debug']['source_before_errline'], $CFG['debug']['source_after_errline']);
				$errHandler->setIsCatchFatalError($CFG['debug']['is_catch_fatal_error']);
				$errHandler->setErrorNotifyEmail($CFG['debug']['notify_email']);
				$errHandler->setDebugCSSURL($CFG['debug']['debug_css_url']);
		}
		if ($CFG['lang']['is_multi_lang_support'])
		{
				require_once ($CFG['site']['project_path'] . 'common/languages/select_language.inc.php');
		}
		require_once ($CFG['site']['project_path'] . 'common/languages/' . $CFG['lang']['default'] . '.inc.php');
		require_once ($CFG['site']['project_path'] . 'common/languages/' . $CFG['lang']['default'] . '/help.inc.php');
		if (isset($CFG['lang']['include_files']))
		{
				foreach ($CFG['lang']['include_files'] as $include_file)
				{
						require_once ($CFG['site']['project_path'] . sprintf($include_file, $CFG['lang']['default']));
				}
		}
		if ($CFG['ssl']['is_use_ssl'] && ((is_string($CFG['ssl']['secure_pages']) && $CFG['ssl']['secure_pages'] == '*') || (is_array($CFG['ssl']['secure_pages']) && in_array($_SERVER['SCRIPT_NAME'], $CFG['ssl']['secure_pages']))))
		{
				if (empty($_SERVER['HTTPS'])) Redirect2URL('https://' . substr($CFG['site']['current_url'], strlen('http://')));
		}
		else
				if (!empty($_SERVER['HTTPS'])) Redirect2URL('http://' . substr($CFG['site']['current_url'], strlen('https://')));
		if ($CFG['db']['is_use_db'])
		{
				if ($CFG['db']['abodb_lite'])
				{
						require_once ($CFG['site']['project_path'] . 'common/classes/adodb_lite/adodb.inc.php');
						$db = ADONewConnection($CFG['db']['abstraction']);
						$db->debug_console = $CFG['debug']['is_db_debug_mode'];
				}
				else
				{
						require_once ($CFG['site']['project_path'] . 'common/classes/adodb/adodb.inc.php');
						$db = NewADOConnection($CFG['db']['abstraction']);
						$db->debug = $CFG['debug']['is_db_debug_mode'];
						if ($CFG['debug']['is_db_debug_mode'])
						{
								global $SQL_QUERIES;
								define('ADODB_OUTP', 'ExposeQuery');
						}
				}
				if (!mysql_connect($CFG['db']['hostname'], $CFG['db']['username'], $CFG['db']['password'])) Redirect2URL("install.php");
				$db->Connect($CFG['db']['hostname'], $CFG['db']['username'], $CFG['db']['password'], $CFG['db']['name']);
				if (!$db) trigger_error('DB Connection Error', E_USER_ERROR);
		}
		if ($CFG['http_headers']['is_default_http_headers'])
		{
				if ($CFG['session']['is_session'])
				{
						if (!empty($CFG['session']['cache_limiter'])) session_cache_limiter($CFG['session']['cache_limiter']);
						if ($CFG['session']['is_custom_handler'] && $CFG['db']['is_use_db'])
						{
								require_once ($CFG['site']['project_path'] . 'common/classes/class_CustomSession.lib.php');
						}
						else  session_start();
				}
				require_once ($CFG['site']['project_path'] . 'common/http_headers.inc.php');
		}
		if ($CFG['auth']['is_authenticate'])
		{
				require_once ($CFG['site']['project_path'] . 'common/authentication/authenticate_user.inc.php');
		}
		if ($CFG['html']['stylesheet']['screen']['is_style_support'])
		{
		}
		if (isset($CFG['mods']['include_files']))
		{
				foreach ($CFG['mods']['include_files'] as $include_file)
				{
						require_once ($CFG['site']['project_path'] . sprintf($include_file, $CFG['lang']['default']));
				}
		}
}
if (!$CFG['mods']['is_include_only']['non_html_header_files'])
{
		if ($CFG['html']['is_use_header'])
		{
				require_once ($CFG['site']['project_path'] . '/includes/languages/' . $CFG['lang']['default'] . '/headerLanguage.php');
				if (!class_exists('FormHandler'))
				{
						require_once ($CFG['site']['project_path'] . 'common/classes/class_FormHandler.lib.php');
				}
				if (!class_exists('Widget'))
				{
						require_once ($CFG['site']['project_path'] . 'common/classes/class_Widget.lib.php');
				}
				require_once ($CFG['site']['project_path'] . 'common/classes/class_HeaderHandler.lib.php');
				require_once ($CFG['site']['project_path'] . 'common/languages/' . $CFG['lang']['default'] . '/lists_array/paging_list_array.inc.php');
				require_once ($CFG['site']['project_path'] . sprintf($CFG['html']['header'], $CFG['lang']['default']));
		}
}
?>
