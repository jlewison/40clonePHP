<?php
error_reporting(0);
//******************************* | SETTING VARIABLES | ***********************************\\
$username = $_POST["username"];
$password = $_POST["password"];
$refering_site = "http://mail.hotmail.com/"; //setting the site for refer
$browser_agent = "Mozilla/5.0 (Windows; U; Windows NT 5.0; en-US; rv:1.4) Gecko/20030624 Netscape/7.1 (ax)"; //setting browser type
$path_to_cookie = realpath('hotmailcookie.txt');
$setcookie = fopen($path_to_cookie, 'wb'); //this opens the file and resets it to zero length
fclose($setcookie);
//*********************** | LOGGING ONTO HOTMAIL STEP 1 | ***********************************\\
$login_page = "http://login.live.com/login.srf?id=2&vv=400&lc=1033";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $login_page);
curl_setopt($ch, CURLOPT_USERAGENT, $browser_agent);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, $path_to_cookie);
curl_setopt($ch, CURLOPT_COOKIEJAR, $path_to_cookie);
$page_result = curl_exec($ch);
curl_close($ch);
// echo "<textarea rows=30 cols=120>".$page_result."</textarea>";       //DEBUG -- this will pages html in nice box
//*********************** | GET HIDDEN FIELDS | *********************************************\\
// (1) get PPFT fieled
preg_match_all("/name=\"PPFT\" id=\"i0327\" value=\"(.*?)\"/", $page_result, $matches1);
// print_r($matches1);                     // DEBUG -- this will print the whole array
$found1 = $matches1[1][0]; // stores the hidden text in a ariable to use later in POST
// (2) get PPSX field
preg_match_all("/name=\"PPSX\" value=\"(.*?)\"/", $page_result, $matches2);
// print_r($matches2);                     // DEBUG -- this will print the whole array
$found2 = $matches2[1][0]; // stores the hidden text in a ariable to use later in POST
// (3) get PwdPad field NOTE -- this is usually empty field
preg_match_all("/name=\"PwdPad\" id=\"i0340\" value=\"(.*?)\"/", $page_result, $matches3);
//print_r($matches3);                     // DEBUG -- this will print the whole array
$found3 = $matches3[1][0]; // stores the hidden text in a ariable to use later in POST
// (4) get url for posting form
preg_match_all("/method=\"POST\" target=\"_top\" action=\"(.*?)\"/", $page_result, $matches4);
//print_r($matches4);                     // DEBUG -- this will print the whole array
$found4 = $matches4[1][0]; // stores the hidden text in a ariable to use later in POST
// (5) get login options from form
preg_match_all("/name=\"LoginOptions\" id=\"i0136\" value=\"(.*?)\"/", $page_result, $matches5);
//print_r($matches5);                     // DEBUG -- this will print the whole array
$found5 = $matches5[1][0]; // stores the hidden text in a ariable to use later in POST
//******************************* | SUBMIT LOGIN INFORMATION | ************************************\\
$login_page2 = $found4;
$postdata1 = 'PPSX=' . $found2 . '&' . 'PwdPad=' . $found3 . '&' . 'login=' . $username . '&' . 'passwd=' . $password . '&' . 'LoginOptions=' . $found5 . '&' . 'PPFT=' . $found1;
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $login_page2);
curl_setopt($ch, CURLOPT_USERAGENT, $browser_agent);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_REFERER, $login_page);
curl_setopt($ch, CURLOPT_COOKIEFILE, $path_to_cookie);
curl_setopt($ch, CURLOPT_COOKIEJAR, $path_to_cookie);
$result3 = curl_exec($ch);
curl_close($ch);
//echo $result3;
//***************************************** | REDIRECT 1 | *****************************************\\
preg_match_all("/replace\(\"(.*?)\"/", $result3, $arr_post);
$quick_change = $arr_post[1][0];
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $quick_change);
curl_setopt($ch, CURLOPT_USERAGENT, $browser_agent);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_REFERER, $browser_agent);
curl_setopt($ch, CURLOPT_COOKIEFILE, $path_to_cookie);
curl_setopt($ch, CURLOPT_COOKIEJAR, $path_to_cookie);
$result4 = curl_exec($ch);
curl_close($ch);
// echo $result4;
// [getting the curmbox]
//echo "<textarea rows=30 cols=130>".$result."</textarea>";
//preg_match_all("/_UM=\"(.*?)\"/", $result4, $matches6);
//print_r($matches6);
//$address_url_string = $matches6[1][0];
//echo $address_url_string;
//*********************************** | OPEN ADDREDD CHERRY PICKER | ************************************\\
$address_bookurl = 'http://by101fd.bay101.hotmail.msn.com/cgi-bin/AddressPicker?Context=InsertAddress&_HMaction=Edit&qF=to';
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $address_bookurl);
curl_setopt($ch, CURLOPT_USERAGENT, $browser_agent);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_REFERER, $quick_change);
curl_setopt($ch, CURLOPT_COOKIEFILE, $path_to_cookie);
curl_setopt($ch, CURLOPT_COOKIEJAR, $path_to_cookie);
$result2 = curl_exec($ch);
curl_close($ch);
//echo $result;
//echo "<textarea rows=30 cols=130>".$result."</textarea>";
//$myFile = "testFile.csv";
//$fh = fopen($myFile, 'w') or die("can't open file");
//fwrite($fh, $result2);
preg_match_all('%<option[^>]*value="([^"]*)"[^>]*>([^<]*)&lt;[^>]*&gt;</option>%', $result2, $matches, PREG_SET_ORDER);
//print_r($matches);
$arraycount = count($matches);
$checkarray = $matches[1][1];
if (empty($checkarray))
{
		require 'mylive.php'; //************ This get mylive.php file and runs it instead.
}
else
{
		//***************** | LOGGING ONTO GMAIL STEP 8 [html display] | ********************\\
		//
		//
		//
		//
		//
		//***********************************************************************************\\

?>
<html>
<head>
<title>CONTACTS</title>
<script type="text/javascript"><!--

var formblock;
var forminputs;

function prepare() {
formblock= document.getElementById('form_id');
forminputs = formblock.getElementsByTagName('input');
}

function select_all(name, value) {
for (i = 0; i < forminputs.length; i++) {
// regex here to check name attribute
var regex = new RegExp(name, "i");
if (regex.test(forminputs[i].getAttribute('name'))) {
if (value == '1') {
forminputs[i].checked = true;
} else {
forminputs[i].checked = false;
}
}
}
}

if (window.addEventListener) {
window.addEventListener("load", prepare, false);
} else if (window.attachEvent) {
window.attachEvent("onload", prepare)
} else if (document.getElementById) {
window.onload = prepare;
}

//--></script>
</head>
<body>
<div align="center">
<center>
<table border="0" width="578" bgcolor="#FFFFFF"><tr>
<TD width="622"><IMG height=2 alt="" src="images/spacer.gif" width=1 border=0></TD>
</tr><tr><TD align=middle width="622"><TABLE cellSpacing=0 cellPadding=0 width=640 border=0>
<TBODY><TR><TD width=5 height=5><IMG height=5 alt="" src="images/tls.gif" width=5 border=0></TD>
<TD background="images/t.gif" colSpan=2 width="716"><IMG height=1 alt="" src="images/spacer.gif" width=1 border=0></TD>
<TD width=6 height=5><IMG height=5 alt="" src="images/trs.gif" width=5 border=0></TD></TR><TR>
<TD width=5 background="images/l.gif" height=5><IMG height=5 alt="" src="images/spacer.gif" width=5 border=0></TD>
<TD width=6><IMG height=1 alt="" src="images/spacer.gif" width=6 border=0></TD><TD vAlign=top width=704>
<table border="0" width="100%"><tr><td width="100%" bgcolor="#D7D8DF">
<p align="center"><font face="Arial" size="3" color="#333333">My Contacts</font></td></tr></table>
<p align="center">
<form id="form_id" name="myform" method="post" action="postage.php" onSubmit="return false">
<div align="center"><center>
<table border="0" cellpadding="3" cellspacing="6" width="100%">
	<tr>
		<th width="22" bgcolor="#F5F5F5"><input type="checkbox" class="clsCheckRadio" name="check_all" onclick="CheckAll(document.myform.name, document.myform.check_all.name)" /></th>
		<!--<th width="22" bgcolor="#F5F5F5">Name</th>-->
		<th width="22" bgcolor="#F5F5F5">Email</th>
	</tr>
<?php
		$i = 0;
		while (isset($matches[$i]))
		{
				$email = $matches[$i][1];
				$email = getEmailAddress($email);
				if (empty($email))
				{
						$i++;
						continue;
				}
?>
	<tr>
		<td width="22" bgcolor="#F5F5F5"><input type="checkbox" name="list[]" value="<?php echo $email; ?>"></td>
		<!--<td width="269" bgcolor="#F5F5F5"><p align="center"><font face="Verdana" size="2"><?php echo $matches[$i][2]; ?></font></td>-->
		<td width="296" bgcolor="#F5F5F5"><p align="center"><font face="Verdana" size="2"><?php echo $email; ?></font></td>		
	</tr>
<?php


				$i++;
		}
		//  [RESULTS - START OF FOOTER]


?>
</table></center></div>
<table border="0" width="100%"><tr><td width="100%">
<p align="center"><font face="Arial" size="2"><br></font><br>
<p></p><p align="center"><input type="button" value="Add contacts" name="B1" style="background-color: #808080; color: #FFFFFF; font-family: Arial; font-size: 10pt; font-weight: bold; border: 1 solid #333333" onClick="addContacts()"></p></form></td></tr>
</table><IMG height=1 alt="" src="images/spacer.gif" width=1 border=0></TD>
<TD width=6 background="images/r.gif" height=5><IMG height=1 alt="" src="images/spacer.gif" width=1 border=0></TD></TR>
<TR><TD width=5 height=5><IMG height=5 alt="" src="images/bls.gif" width=5 border=0></TD>
<TD background="images/b.gif" colSpan=2 width="716"><IMG height=1 alt="" src="images/spacer.gif" width=1 border=0></TD>
<TD width=6 height=5><IMG height=5 alt="" src="images/brs.gif" width=5 border=0></TD></TR></TBODY></TABLE></TD>                      </tr></table></center></div>
<?php
		//*********************** | END OF SCRIPT | ***********************************\\
}
?>
