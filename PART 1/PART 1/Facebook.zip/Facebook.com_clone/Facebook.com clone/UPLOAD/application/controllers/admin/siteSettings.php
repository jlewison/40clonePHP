<?php
/**
 * Site settings Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 02/01/2008
 */
class SiteSettings extends controller
{
		function SiteSettings()
		{
				parent::controller();
				//check login
				if ($this->session->userdata('admin_logged_in') != 1 && $this->session->userdata('admin_id') == '') redirect('admin/login');
				//Load the language file
				$this->lang->load('admin/siteSettings', $this->config->item('language_code'));
		}
		function index()
		{
				$this->load->library('validation');
				$this->load->model('settingsmodel');
				$outputData['paginationSettings'] = $this->settingsmodel->getPaginationSettings();
				if (isset($_POST['site_settings'])) $this->_siteSettingsFrm();
				else
						if (isset($_POST['page_settings'])) $this->_paginationSettingsFrm($outputData['paginationSettings']);
				//
				if (!isset($_POST['site_settings']))
				{
						$outputData['settings'] = $this->settingsmodel->readAllSetting();
						if ($outputData['settings'] != false) $outputData['settingsArr'] = $outputData['settings'];
				}
				if ($this->validation->run() == false) $outputData['validationError'] = $this->validation->error_string;
				else
				{
						if (isset($_POST['site_settings']))
						{
								$this->settingsmodel->updateSiteSettings($_POST);
								//$this->settingsmodel->updatePagination($_POST);
								//Set the flash data
								$this->session->set_flashdata('successMsg', $this->lang->line('sitesettings_success_msg'));
								redirect('admin/siteSettings');
						}
						if (isset($_POST['page_settings']))
						{
								$this->settingsmodel->updatePagination($_POST);
								//Set the flash data
								$this->session->set_flashdata('successMsg', $this->lang->line('sitesettings_success_msg'));
								redirect('admin/siteSettings');
						}
				}
				$this->smartyextended->view('../admin/siteSettings', $outputData);
		}
		function _siteSettingsFrm()
		{
				$rules['admin_name'] = 'trim|required|alphanumeric';
				$rules['admin_email'] = 'trim|required|valid_email';
				$rules['site_name'] = 'trim|required|alphanumeric';
				$rules['site_title'] = 'trim|required|alphanumeric';
				$fields['admin_name'] = $this->lang->line('sitesettings_admin_name');
				$fields['admin_email'] = $this->lang->line('sitesettings_admin_email');
				$fields['site_name'] = $this->lang->line('sitesettings_site_name');
				$fields['site_title'] = $this->lang->line('sitesettings_site_title');
				$this->validation->set_rules($rules);
				$this->validation->set_fields($fields);
		}
		function _paginationSettingsFrm($paginationSettings)
		{
				foreach ($paginationSettings as $key => $val)
				{
						$rules[$val['page']] = 'trim|required|numeric|callback__numberCheck';
				}
				foreach ($paginationSettings as $key => $val)
				{
						$fields[$val['page']] = $val['page_desc'];
				}
				$this->validation->set_rules($rules);
				$this->validation->set_fields($fields);
		}
		function _numberCheck($value)
		{
				if ($value < 2)
				{
						$this->validation->set_message('_numberCheck', 'The %s should be greater than 1');
						return false;
				}
				else  return true;
		}
}
?>