<?php

include_once('init.php');

$list = $db->getAll('show tables');

print_r($list);


?>