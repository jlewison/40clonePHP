<?
$reg_reg_mail_subject="Commande";

$reg_reg_mail="commande de : $r_login";
?>