<?php
	$module_info['name'] = 'Ajax Contact Form';
	$module_info['desc'] = 'Add a contact form for your users to contact you';
	$module_info['version'] = 0.1;
?>