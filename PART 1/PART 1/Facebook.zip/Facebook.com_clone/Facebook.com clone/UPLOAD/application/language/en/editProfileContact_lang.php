<?php
$lang['page_title']	= 'Edit profile';
$lang['editprofilecontact_email']			= 'Emails';
$lang['editprofilecontact_screen_name']		= 'Screen Name(s)';
$lang['editprofilecontact_mobile_phone']	= 'Mobile Phone';
$lang['editprofilecontact_land_phone']		= 'Land Phone';
$lang['editprofilecontact_address']			= 'Address';
$lang['editprofilecontact_city']			= 'City';
$lang['editprofilecontact_country']			= 'Country';
$lang['editprofilecontact_state']			= 'State';
$lang['editprofilecontact_zip']				= 'Zip';
$lang['editprofilecontact_website']			= 'Website';
$lang['editprofilecontact_add_another']		= 'Add another screen name';
$lang['editprofilecontact_success_msg']		= 'Contact profile details updated successfully!';
?>