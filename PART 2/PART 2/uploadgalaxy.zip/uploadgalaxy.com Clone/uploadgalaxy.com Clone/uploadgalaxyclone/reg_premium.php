<?
include("include/config.php");
STemplate::display("reg_premium.tpl");
?>