<?php

   class pollOptionsData extends Data {

      var $table = POLLOPTS_TABLE;

      var $config = array (
  'table' => POLLOPTS_TABLE,
  'idField' => 'optionid',
  'addedMsg' => 'Osdate Polloptions %s Added',
  'added_err' => 'Can\\\'t Add Osdate Polloptions',
  'editMsg' => 'Osdate Polloptions %s Updated',
  'editErr' => 'Can\\\'t Update Osdate Polloptions',
  'delErr' => 'Can\\\'t Delete Osdate Polloptions',
  'delMsg' => 'Osdate Polloptions %s Deleted',
  'blankErr' => 'Osdate Polloptions Empty',
  'fields' => 
  array (
    'pollid' => 
    array (
      'name' => 'pollid',
      'description' => 'Pollid',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 1,
      'duplicate_ok' => 1,
    ),
    'opt' => 
    array (
      'name' => 'opt',
      'description' => 'Opt',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 255,
      'blank_ok' => 1,
      'duplicate_ok' => 1,
    ),
    'result' => 
    array (
      'name' => 'result',
      'description' => 'Result',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'enabled' => 
    array (
      'name' => 'enabled',
      'description' => 'Enabled',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 1,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
  ),
);   

      function pollOptionsData() {
      
         $this->Data($this->config);
      }
   }

?>
