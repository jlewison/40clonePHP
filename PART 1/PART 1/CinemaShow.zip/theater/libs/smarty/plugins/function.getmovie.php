<?php
function smarty_function_getmovie($params, &$smarty) {
	global $data;
	foreach ($data->movies->movie as $movie) {
		if ((int)$movie['id'] == (int)$params['value']['id']) {
			$smarty->assign($params['var'], $movie);
			break;
		}
	}
}