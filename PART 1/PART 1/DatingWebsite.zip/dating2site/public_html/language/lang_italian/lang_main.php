<?php
// The format of this file is ---> $lang['message'] = 'text';
//
// You should also try to set a locale and a character encoding (plus direction). The encoding and direction
// will be sent to the template. The locale may or may not work, it's dependent on OS support and the syntax
// varies ... give it your best guess!
//

$lang['ENCODING'] = 'iso-8859-15';
$lang['DIRECTION'] = 'ltr';
$lang['LEFT'] = 'sinistra';
$lang['RIGHT'] = 'destra';
$lang['DATE_FORMAT'] =  '%d %b, %Y'; // This should be changed to the default date format for your language, php date() format
$lang['DATE_TIME_FORMAT'] =  '%d %b, %Y %I:%M:%S %P'; // This should be changed to the default date format for your language, php date() format
$lang['DISPLAY_DATE_FORMAT'] =  'd M, Y';
$lang['DISPLAY_DATETIME_FORMAT'] = 'D d-M-Y H:i:s';
$lang['DB_ERROR'] = "La tua richiesta non pu� essere eseguita a causa di un errore non specificato del database.<br />Si prega di riprovare.";

$lang['main_menu'] = 'Menu Principale';
$lang['homepage'] = 'Homepage';
$lang['rate_photos'] = 'Valuta Foto';
$lang['forum'] = 'Forum';
$lang['manageforum'] = 'Gestione Forum';
$lang['chat'] = 'Chat';
$lang['managechat'] = 'Gestione Chat';
$lang['member_login'] = 'Accesso Membri';
$lang['featured_members'] = 'Membri Caratteristici';
$lang['quick_search'] = 'Ricerca Veloce';
$lang['my_searches'] = 'Mie Ricerche';
$lang['affiliates'] = 'Affiliato';
$lang['already_affiliate'] = 'Gi� un affiliato?';
$lang['referals'] = 'Referenti';
$lang['title_colon'] = 'Titolo:';
$lang['comments_colon'] = 'Commenti:';
$lang['feedback'] = 'Feedback';

$lang['profiles'] = 'Profilo';
$lang['profile_s'] = 'Profilo di USERNAME';
$lang['total_amt'] = 'Somma Totale';
$lang['banner_link'] = 'Striscione/Link';
$lang['clicks'] = 'Click';
$lang['finance_calc'] = 'Calcolatore Finanziario';
$lang['flash_chat_msg'] = 'FlashChat 4.1.0 e superiori includono una classe per integrare osDate. Prego acquistare FlashChat da <a href="www.tufat.com/chat.php" target="_blank">www.tufat.com/chat.php</a> e copiare i file in questa cartella. Successivamente eseguire l\'installazione di FlashChat, e specificare osDate come CMS con cui integrare FlashChat.';
$lang['flash_chat_admin_msg'] = 'FlashChat 4.1.0 e superiori includono una classe per integrare osDate. Prego acquistare FlashChat da <a href="www.tufat.com/chat.php" target="_blank">www.tufat.com/chat.php</a> e copiare i file in questa cartella. Successivamente eseguire l\'installazione di FlashChat, e specificare osDate come CMS con cui integrare FlashChat.';
$lang['affiliate_head_msg'] = 'Diventa un affiliato';
$lang['affiliate_head_msg2'] = 'Noi offriamo commissioni per i webmaster che indirizzano i visitatori verso il nostro sito.<br/>';
$lang['affiliate_success_msg1'] = 'L\'id del tuo account di affiliato �:';
$lang['affiliate_success_msg2'] = 'Ora puoi entrare nel tuo account di affiliato. ';
$lang['affiliate_login_title'] = "Login Affiliato";
$lang['password_changed_successfully'] = 'La tua password � stata cambiata con successo.';
$lang['affiliate_registration_success'] = 'Registrazione Affiliato Riuscita';
$lang['login_now'] = 'Entra Qui';
$lang['must_be_valid'] = 'Deve essere valido';
$lang['characters'] = 'caratteri';
$lang['email'] = 'Email:';
$lang['age'] = 'Et�';
$lang['years'] = 'anni';

$lang['all_states'] = 'Tutti gli Stati';
//
// These terms are used at Signup page
//
$lang['welcome'] = 'Benvenuto';
$lang['admin_welcome'] = 'Benvenuto <br /> nella <br />Pannello Amministratore<br /> SITENAME';
$lang['title'] = 'Benvenuto a SITENAME';
$lang['site_links'] = array(
	'home' => 'Casa',
	'signup_now' => 'Iscriviti Ora',
	'chat' => 'Chat',
	'forum' => 'Forum',
	'login' => 'Entra',
	'search' => 'Cerca',
	'aboutus' => 'Chi Siamo',
	'forgot' => 'Dimenticato Password/Login?',
	'contactus' => 'Contattaci',
	'privacy' => 'Privacy',
	'terms_of_use' => 'Termini di Uso',
	'services' => 'Servizi',
	'faq' => 'FAQ\'s',
	'articles' => 'Articoli',
	'affliates' => 'Affiliato',
	'invite_a_friend' => 'Invita un Amico',
	'feedback' => 'Feedback'
	);

$lang['success_stories'] = 'Storie di Successo';
$lang['members_login'] = 'Accesso Membri';
$lang['poll'] = 'Sondaggio';
$lang['news'] = 'Novit�';
$lang['articles'] = 'Articoli';
$lang['poll_result'] = 'Risultati Sondaggio';
$lang['view_poll_archive'] = 'Sondaggi Precedenti';
$lang['member_panel'] = 'Pannello Membri';
$lang['poll_errmsg1'] = 'Hai gi� votato per questo sondaggio. Prova un altro sondaggio un altro giorno.';
$lang['close'] = 'Chiudi';
$lang['all_stories'] = 'Tutte le Storie';
$lang['all_news'] = 'Tutte le Novit�';
$lang['more'] = 'pi�';
$lang['by'] = 'da';

$lang['dont_stay_alone'] = 'Non stare da solo,';
$lang['join_now_for_free'] = 'Entra Ora Gratis!';
$lang['special_offer'] = 'Offerta Speciale!';
$lang['welcome_to'] = 'Benvenuto a ';
$lang['welcome_to_site'] = 'Benvenuto a SITENAME';

$lang['offer_text'] = 'Guarda perch� SITENAME � il sito di relazioni che cresce pi� velocemente nel web. Crea il tuo profilo SITENAME per iniziare l\'eccitante viaggio per trovare l\'anima gemella.';

$lang['newest_profiles'] = 'Nuovi Profili';

$lang['edit_profile'] = 'Edita Profilo';
$lang['total_profiles'] = 'Profili Totali';
$lang['forgot'] = 'Dimenticato di Accedere?';
$lang['hide'] = 'Nascondi';
$lang['show'] = 'Mostra';
$lang['sex'] = 'Genere:';
$lang['sex_without_colon'] = 'Genere';
$lang['pageno'] = 'Pagina ';
$lang['page'] = 'Pagina';
$lang['previous'] = 'Precedente';
$lang['next'] = 'Successiva';
$lang['time_col'] = 'Ora:';

$lang['save_search'] = 'Salva Ricerca';
$lang['find_your_match'] = 'Trova Corrispondenza';

$lang['extended_search'] = 'Ricerca Estesa';
$lang['matches_found'] = 'I profili seguenti corrispondono ai tuoi criteri.';
$lang['timezone'] = 'Fuso Orario:';
$lang['next_section'] = 'Prossima Sezione';
$lang['sign_in'] = 'Iscrizione Membri';
$lang['member_panel'] = 'Pannello Membri';
$lang['aff_panel'] = 'Pannello Affiliati';
$lang['login_title'] = 'Area accesso Membri';
$lang['sign_out'] = 'Cancella Iscrizione';
$lang['login_submit'] = 'Accesso';

$lang['change_password'] = 'Cambia Password';
$lang['old_password'] = 'Vecchia Password:';
$lang['new_password'] = 'Nuova Password:';
$lang['confirm_password'] = 'Conferma Password:';
$lang['password_change_msg'] = 'La tua password � stata cambiata con successo.';

$lang['section_signup_title'] = 'Informazioni Iscrizione';
$lang['signup'] = 'Iscrizione';
$lang['section_basic_title'] = 'Informazioni di Base';
$lang['section_appearance_title'] = 'Aspetto Fisico';
$lang['section_interests_title'] = 'Interessi';
$lang['section_lifestyle_title'] = 'Stile di Vita';

$lang['signup_subtitle_login'] = 'Dettagli Accesso';
$lang['signup_subtitle_profile'] = 'Mio Profilo';
$lang['signup_subtitle_address'] = 'Indirizzo';
$lang['signup_subtitle_appearacnce'] = 'Aspetto Fisico';
$lang['signup_subtitle_preference'] = 'Preferenza Ricerca';

$lang['signup_username'] = 'Nome Utente:';
$lang['signup_password'] = 'Password:';
$lang['signup_confirm_password'] = 'Conferma Password:';

$lang['signup_firstname'] = 'Nome:';
$lang['signup_lastname'] = 'Cognome:';
$lang['signup_email'] = 'Indirizzo E-Mail:';
$lang['section_mypicture'] = 'Mie Immagini';
$lang['upload'] = 'Carica';
$lang['upload_pictures'] = 'Gestione Immagini';
$lang['upload_format_msgs'] = 'Solamente i file  .jpg or .gif or .png sono ammessi.';
$lang['thumbnail'] = 'Miniatura';
$lang['picture'] = 'Immagine';
$lang['signup_picture'] = 'Mia Immagine';
$lang['signup_picture2'] = 'Mia Immagine 2:';
$lang['signup_picture3'] = 'Mia Immagine 3:';
$lang['signup_picture4'] = 'Mia Immagine 4:';
$lang['signup_picture5'] = 'Mia Immagine 5:';

$lang['signup_gender'] = 'Io sono un';
$lang['signup_pref_age_range'] = 'Intervallo et� preferito';
$lang['signup_year_old'] = 'anni';
$lang['signup_birthday'] = 'Compleanno:';
$lang['signup_country'] = 'Nazione:';
$lang['signup_state_province'] = 'Stato / Provincia:';
$lang['signup_zip'] = 'CAP / Codice Postale:';
$lang['signup_city'] = 'Citt� / Localit�:';
$lang['signup_address1'] = 'Indirizzo, linea 1:';
$lang['signup_address2'] = 'Indirizzo, linea 2:';
$lang['signup_height'] = 'Altezza: ';
$lang['signup_feet'] = 'piedi';
$lang['signup_meter_inches'] = 'pollici [ metri se non in USA ]';
$lang['signup_weight'] = 'Peso:';
$lang['signup_pounds'] = 'libbre [ kg se non in USA ]';
$lang['signup_where_should_we_look'] = 'Dove dovremmo guardare?';
$lang['signup_view_online'] = "Gli altri membri possono vedere che sono collegato?";

$lang['signup_gender_values'] = array(
	'M' => 'Uomo',
	'F' => 'Donna',
	'C' => 'Coppia',
	'G' => 'Gruppo'
	);

$lang['signup_gender_look'] = array(
	'M' => 'Uomo',
	'F' => 'Donna',
	'C' => 'Coppia',
	'G' => 'Gruppo',
	'B' => 'Uomo o Donna',
	'A' => 'Ognuno di Questi'
	);

$lang['seeking'] = 'alla ricerca di';
$lang['looking_for_a'] = 'in cerca di un/a';
$lang['looking_for'] = 'In cerca di';

$lang['of'] = ' di ';
$lang['to'] = ' a ';
$lang['from'] = ' da ';
$lang['for'] = ' per ';
$lang['yes'] = 'Si';
$lang['no'] = 'No';
$lang['cancel'] = 'Annulla';

$lang['change'] = 'Cambia';
$lang['reset'] = 'Azzera';

//Commonly used words

$lang['required_info_indication'] = 'indica informazione necessaria';
$lang['required_info_indicator'] = '* ';
$lang['required_info_indicator_color'] = 'Red';
$lang['click_here'] = 'Clicca Qui';

$lang['datetime_dayval']['Sun'] = 'Dom';
$lang['datetime_dayval']['Mon'] = 'Lun';
$lang['datetime_dayval']['Tue'] = 'Mar';
$lang['datetime_dayval']['Wed'] = 'Mer';
$lang['datetime_dayval']['Thu'] = 'Gio';
$lang['datetime_dayval']['Fri'] = 'Ven';
$lang['datetime_dayval']['Sat'] = 'Sab';

$lang['error_msg_color'] = 'Red';
$lang['success_message'] = "Le informazioni inserite sono state salvate con successo.<br />Sarai rediretto automaticamente alla prossima sezione entro 5 secondi. Se la redirezione automatica non funziona, clicca sul link sotto..";
$lang['sendletter_success'] = 'La lettera � stata inviata con successo.';


/*****************Admin Section Labels********************/

//Commonly used labels
$lang['admin_login_title'] = 'Pannello Amministratore SITENAME';
$lang['home_title'] = 'SITENAME Home';
$lang['admin_title_msg'] =  'Pannello Amministratore SITENAME';
$lang['admin_login_msg'] = 'Accesso Amministratore';
$lang['admin_panel'] = 'Pannello Amministratore';
$lang['back'] = 'Indietro';
$lang['insert_msg'] = 'Inserisci nuovo ';
$lang['question_mark'] = '?';
$lang['id'] = 'Id:';
$lang['name'] = 'Nome: ';
$lang['name_col'] = 'Nome';
$lang['enabled'] = 'Abilitati:';
$lang['action'] = 'Azione';
$lang['edit'] = 'Edita';
$lang['delete'] = 'Cancella';
$lang['section'] = 'Sezione:';
$lang['insert_section'] = 'Inserisci nuova sezione';
$lang['modify_section'] = 'Modifica sezione';
$lang['modify_sections'] = 'Modifica sezioni';
$lang['delete_section'] = 'Cancella sezione';
$lang['delete_sections'] = 'Cancella sezioni';
$lang['enable_selected'] = 'Abilita';
$lang['disable_selected'] = 'Disabilita';
$lang['change_selected'] = 'Cambia';
$lang['delete_selected'] = 'Cancella';
$lang['no_select_msg'] = "Non hai selezionato un opzione. Prego premere il bottone INDIETRO del browser per selezionare una o pi� opzioni.";
$lang['delete_confirm_msg'] = 'Sei sicuro di volere cancellare questa sezione?';
$lang['delete_group_confirm_msg'] = 'Sei sicuro di voler cancellare queste sezioni? Questa azione non pu� essere revocata.';
$lang['enabled_values'] = array(
	'Y' => 'Si',
	'N' => 'No'
	);
$lang['display_control_type'] = array(
	'checkbox' => 'Casella di spunta',
	'radio' => 'Bottone Opzione',
	'select' => 'Lista a tendina',
	'textarea' => 'Input Testo'
	);
$lang['admin_error_color'] = 'Red';

$lang['col_head_srno'] = '#';
$lang['col_head_id'] = 'Id';
$lang['col_head_question'] = 'Domanda';
$lang['col_head_enabled'] = 'Abilitati';
$lang['col_head_name'] = 'Nome';
$lang['col_head_username'] = 'Nome Utente';
$lang['col_head_firstname'] = 'Nome';
$lang['col_head_lastname'] = 'Cognome';
$lang['col_head_fullname'] = 'Nome Completo';
$lang['col_head_status'] = 'Stato';
$lang['col_head_gender'] = 'Genere';
$lang['col_head_email'] = 'Email';
$lang['col_head_country'] = 'Nazione';
$lang['col_head_city'] = 'Citt�';
$lang['col_head_zip'] = 'CAP';
$lang['col_head_register_at'] = 'Registrato a';

$lang['section_title'] = 'Gestione Sezioni';
$lang['total_sections'] = 'Sezioni Totali:';
$lang['profile_title'] = 'Gestione Profilo';
$lang['total_profiles_found'] = 'Totale Profili Trovati:';
$lang['modify_profile'] = 'Modifica Profilo';

$lang['profile_signup_title'] = 'Informazioni Iscrizione';
$lang['profile_basic_title'] = 'Informazioni di Base';
$lang['profile_appearance_title'] = 'Aspetto Fisico';
$lang['profile_interests_title'] = 'Interessi';
$lang['profile_lifestyle_title'] = 'Stile di Vita';

$lang['profile_subtitle_login'] = 'Dettagli Accesso';
$lang['profile_subtitle_profile'] = 'Profilo';
$lang['profile_subtitle_address'] = 'Indirizzo';
$lang['profile_subtitle_appearacnce'] = 'Aspetto Fisico';
$lang['profile_subtitle_preference'] = 'Preferenze';
$lang['profile_delete_confirm_msg'] = 'Sei sicuro di voler cancellare questo profilo?';
$lang['delete_profile'] = 'Cancella profilo';
$lang['profile_username'] = 'Nome utente:';
$lang['profile_firstname'] = 'Nome:';
$lang['profile_lastname'] = 'Cognome:';
$lang['profile_email'] = 'Indirizzo Email:';
$lang['profile_gender'] = 'Genere:';
$lang['profile_birthday'] = 'Compleanno:';
$lang['profile_country'] = 'Nazione:';
$lang['profile_state_province'] = 'Stato / Provincia:';
$lang['profile_zip'] = 'CAP / Codice Postale:';
$lang['profile_city'] = 'Citt� / Localit�';
$lang['profile_address1'] = 'Indirizzo, linea 1:';
$lang['profile_address2'] = 'Indirizzo, linea 2:';
$lang['find'] = 'Trova';
$lang['search'] = 'Cerca';
$lang['AND'] = 'e';
$lang['OR'] = 'O';
$lang['order_by'] = 'Ordina per: ';
$lang['sort_by'] = 'Ordine';
$lang['sort_types'] = array(
	'asc' => 'Ascendente',
	'desc' => 'Discendente'
	);
$lang['search_results'] = 'Risultati Ricerca';
$lang['no_record_found'] = 'Nessun record corrispondente trovato.';
$lang['search_options'] = 'Opzioni di Ricerca';
$lang['search_simple'] = 'Ricerca Semplice';
$lang['search_advance'] = 'Cerca';
$lang['search_advance_results'] = 'Risultati Ricerca';
$lang['search_country'] = 'Cerca per Nazione';
$lang['search_states'] = 'Cerca per Stato';
$lang['search_zip'] = 'Cerca per CAP';
$lang['search_city'] = 'Cerca per Citt�';
$lang['search_wildcard_msg'] = 'Puoi inserire * nella casella di testo per cercare tutti i record.';
$lang['search_location'] = '<b>Cerca per Luogo:</b>';
$lang['select_state'] = 'Stato:';
$lang['enter_city'] = 'Citt�:';
$lang['enter_zip'] = 'CAP:';
$lang['enter_username'] = 'Nome utente:';
$lang['results_per_page'] = 'Risultati per Pagina';
$lang['search_results_per_page'] = array( 2 => 2, 5 => 5 , 10 => 10, 20 => 20, 50 => 50, 100 => 100 );
$lang['order'] = 'Ordine';
$lang['up'] = 'Su';
$lang['down'] = 'Gi�';

$lang['question'] = 'Domanda:';

$lang['maxlength'] = 'Lunghezza Massima:';
$lang['description'] = 'Descrizione:';
$lang['mandatory'] = 'Obbligatoria:';
$lang['guideline'] = 'Linea Guida:';
$lang['control_type'] = 'Controllo Display:';
$lang['include_extsearch'] = 'Includi nella Ricerca Estesa:';
$lang['head_extsearch'] = 'Intestazione Ricerca Estesa:';

$lang['delete_question'] = 'Cancella Domanda';
$lang['modify_question'] = 'Modifica Domanda';
$lang['questions_title'] = 'Gestione Domande';
$lang['total_options'] = 'Opzioni Totali:';
$lang['insert_question'] = 'Inserisci nuova domanda';
$lang['total_questions'] = 'Domande Totali:';
$lang['delete_questions'] = 'Cancella domande';
$lang['delete_group_questions_confirm_msg'] = 'Sei sicuro di voler cancellare queste domande? Questa azione non pu� essere revocata';

$lang['option'] = 'Opzioni';
$lang['answer'] = 'Risposta';
$lang['options_title'] = 'Opzioni Domanda';
$lang['col_head_answer'] = 'Risposta';
$lang['with_selected'] = 'Con selezionato';
$lang['ranging'] = 'Fascia';

// Instant messenger
$lang['instant_messenger'] = 'Messaggio Istantaneo';
$lang['instant_message'] = 'Messaggio Istantaneo';
$lang['im_from'] = 'Da:';
$lang['im_message'] = 'Messaggio:';
$lang['im_reply'] = 'Replica';
$lang['close_window'] = 'Chiudi Finestra';

// my matches
$lang['my_matches'] = 'Mie Anime Gemelle';
$lang['i_am_a'] = 'Io sono un';
$lang['Between'] = 'tra';
$lang['who_is_from'] = 'che viene da';
$lang['showing'] = 'Mostra';
$lang['your_search_preferences'] = 'Le tue preferenze di ricerca correnti:';
$lang['to_edit_search_preferences'] = 'per editare le preferenze di ricerca';

$lang['unapproved_user'] = 'Profili per Approvazione';
$lang['gbl_settings'] = 'Impostazioni Globali del Sito';
$lang['configurations'] = 'Configurazioni';
$lang['col_head_variable'] = 'Variabile';
$lang['col_head_value'] = 'Valore';

$lang['affiliate_title'] = 'Gestione Affiliati';
$lang['col_head_counter'] = 'Contatore';
$lang['col_head_status'] = 'Stato';

$lang['tell_later'] = 'Te lo dir� dopo';
$lang['view_profile'] = 'Guarda Profilo';
$lang['view_profile_errmsg1']  = 'Non hai ancora specificato le tue preferenze.<br />Prego specificare prima i dettagli del profilo.<br />';
$lang['view_profile_errmsg2'] = '<br />Clicca qui per specificare le preferenze ora.';
$lang['view_profile_errmsg3'] = 'L\'utente non ha ancora specificato i suoi dettagli del profilo.';
$lang['view_profile_restricted'] = 'Questo � un profilo riservato, che non puoi vedere.';
$lang['profile_notset'] = 'nessun profilo trovato per l\'utente.';
$lang['send_mail'] = 'Invia messaggio';
$lang['mail_messages'] = 'Messaggi';
$lang['col_head_subject'] = 'Oggetto';
$lang['col_head_sendtime'] = 'Data';

$lang['inbox'] = 'In arrivo';
$lang['sent'] = 'Inviato';
$lang['trashcan'] = 'Cestino';
$lang['reply'] = 'Rispondi';
$lang['read'] = 'Leggi';
$lang['unread'] = 'Non letto';
$lang['restore'] = 'Ripristina';
$lang['subject'] = 'Oggetto';
$lang['subject_colon'] = 'Oggetto:';
$lang['message'] = 'Messaggio';
$lang['send'] = 'Invia';

$lang['send_letter'] = 'Invia Lettera';
$lang['image_browser'] = 'Browser Immagini';
$lang['upload_image'] = 'Carica Immagine';
$lang['delete_image'] = 'Cancella Immagine';
$lang['show_image'] = 'Mostra Immagine';
$lang['send_invite'] = 'Invia Invito';
$lang['letter_title'] = 'Nuova Lettera';
$lang['from_email'] = 'Da EMail:';
$lang['from_name'] = 'Da Nome:';
$lang['send_to'] = 'Invia';
$lang['email_subject'] = 'Oggetto:';
$lang['save_as'] = 'Salva con nome';

$lang['no_message'] = 'Nessun nuovo messaggio nella casella Posta in Arrivo.';
$lang['descrip'] = 'Descrizione';

//forgot password words
$lang['forgotpass_msg1'] = "Promemoria Login";
$lang['forgotpass_msg2'] = "Prego fornire l\'indirizzo e-mail utilizzato al momento della creazione del profilo, per l\'invio del nome utente, con una nuova password. Una volta ricevuta la nuova password, la si dovrebbe cambiare immediatamente dopo l\'accesso, per sicurezza..";
$lang['retreieve_info'] = 'Invia';
$lang['forgotpass'] = 'Password dimenticata';

//Tell a friend
$lang['tellafriend'] = 'Invita un amico';
$lang['taf_msg1'] = 'Invita un amico a SITENAME';
$lang['taf_yourname'] = 'Il tuo nome:';
$lang['taf_youremail'] = 'La tua e-mail:';
$lang['taf_friendemail'] = "La e-mail dell\'amico:";

//Auto-mail
$lang['confirm_your_profile'] = 'Conferma la tua registrazione';
$lang['letter_not_avail'] = 'Modello lettera non disponibile';
$lang['confirm_letter_sent'] = 'Una e-mail di conferma ti � stata inviata all\'indirizzo e-mail specificato al momento della registrazione. Prego aprire la e-mail di conferma per completare la tua registrazione.';
$lang['letter_not_sent'] = 'Si � verificato un problema nell\'invio della e-mail. Si prega di contattare un amministratore.';
$lang['or'] = 'O';
$lang['enter_confirm_code'] = 'Inserisci sotto il tuo codice di conferma per completare il processo di registrazione.';
// Affiliate auto-mail

$lang['aff_email_subject'] = 'Conferma il tuo Account Affiliato';
$lang['aff_email_body'] = 'Grazie per aver creato un account affiliato in SITENAME. Prego inserisci questo URL nella barra indirizzo del tuo browser per completare la registrazione affiliato:<br><br>#ConfirmationLink#';

//Page management

$lang['manage_pages'] = 'Gestione Pagine';
$lang['pagetitle'] = 'Titolo:';
$lang['pagetext'] = 'Testo:';
$lang['pagekey'] = 'Chiave:';
$lang['addpage'] = 'Aggiungi pagina';
$lang['page'] = 'Pagina:';
$lang['addnew'] = 'Aggiungi Nuovo';
$lang['modpage'] = 'Modifica Pagina';
$lang['pagekey_help'] = 'www.yourdomain.com/index.php?page=YOUR_KEY';

$lang['y_o'] = 'y/o';
$lang['lastlogged'] = 'Ultimo accesso: ';
$lang['aff_stats'] = 'Statistiche Affiliati';
$lang['total_referrals'] = 'Totale utenti indirizzati';
$lang['regis_referals'] = 'Utenti indirizzati registrati';
$lang['globalconfigurations'] = 'Configurazioni Globali';

$lang['send_message_to'] = 'Invia Messaggio a';
$lang['writing_message'] = 'Scrittura messaggio per ';
$lang['search_at'] = 'Cerca a ';

//Rating module
$lang['rate_profile'] = 'Valutazione Profilo';
$lang['worst'] = 'Peggiore';
$lang['excellent'] = 'Eccellente';
$lang['rating'] = 'Valutazione';
$lang['submitrating'] = 'Invia valutazione';

//Payment Modules
$lang['mship_changed'] = 'Livello Adesione Modificato';
$lang['mship_changed_successfull'] = 'Il tuo livello adesione � stato cambiato in Gratis.';
$lang['no_payment'] = 'Nessun Pagamento Richiesto (Gratis)';
$lang['payment_modules'] = 'Moduli Pagamento';
$lang['payment_methods'] = 'Metodi Pagamento';
$lang['business'] = 'Affari:';
$lang['siteid'] = 'Id Sito:';
$lang['undefined_quantity'] = 'Quantit� Indefinita:';
$lang['no_shipping'] = 'Nessuna Spedizione:';
$lang['no_note'] = 'Nessuna Nota:';
$lang['on_off_values'] = array( 1 => 'Si', 0 => 'No' );
$lang['edit_payment_modules'] = 'Edita Modulo Pagamento';
$lang['trans_key'] = 'Chiave Transazione:';
$lang['trans_mode'] = 'Modo Transazione:';
$lang['trans_method'] = 'Metodo Transazione:';
$lang['username'] = 'Nome Utente:';
$lang['username_without_colon'] = 'Nome Utente';
$lang['country'] = 'Nazione';
$lang['country_colon'] = 'Nazione:';
$lang['state'] = 'Stato';
$lang['city'] = 'Citt�';
$lang['location_col'] = 'Luogo:';
$lang['location_no_col'] = 'Luogo';
$lang['zip_code'] = 'Codice CAP';
$lang['attached_files'] = 'File Allegati';
$lang['cc_owner'] = 'Possessore Carta di Credito:';
$lang['cc_number'] = 'Numero Carta di Credito:';
$lang['cc_type'] = 'Tipo Carta di Credito:';
$lang['cc_exp_date'] = 'Data scadenza Carta di Credito:';
$lang['cc_cvv_number'] = 'Cifre Controllo Carta di Credito:';
$lang['cvv_help'] = '(situate sul retro della carta di credito)';
$lang['continue'] = 'Continua';
$lang['trans_method_vals'] = array(
	'CC' => 'Carta di Credito',
	'ECHECK' => 'Assegno Elettronico'
	);
$lang['trans_mode_vals'] = array(
	'AUTH_CAPTURE' => 'AUTH_CAPTURE',
	'AUTH_ONLY' => 'AUTH_ONLY',
	'CAPTURE_ONLY' => 'CAPTURE_ONLY',
	'CREDIT' => 'CREDIT',
	'VOID' => 'VOID',
	'PRIOR_AUTH_CAPTURE' => 'PRIOR_AUTH_CAPTURE'
 );
$lang['cc_unknown'] = 'L\'emittente della Carta di Credito � sconosciuto. Prego riprovare con una carta di credito valida.';
$lang['cc_invalid_date'] = 'Data scadenza Carta di Credito non valida. Prego riprovare con una carta di credito valida.';
$lang['cc_invalid_number'] = 'Numero Carta di Credito non valido. Prego riprovare con una carta di credito valida.';
$lang['amount'] = 'Somma: ';
$lang['confirmation'] = 'Conferma';
$lang['confirm'] = 'Conferma';
$lang['upgrade_membership'] = 'Miglioramento adesione';
$lang['changeto'] = 'Cambia in';
$lang['current_mship_level'] = 'Livello adesione corrente:';
$lang['membership_status'] = 'Stato Adesione';
$lang['you_currently'] = 'Attualmente sei un ';
$lang['info_confirm'] = 'L\'informazione seguente � corretta?';
$lang['change_mship_to'] = 'Cambia livello adesione in ';
//Membership
$lang['permitmsg_1'] = 'Spiacente, il tuo livello adesione non include';
$lang['permitmsg_2'] = 'Per favore migliorare il tuo livello di adesione per usare ';
$lang['permitmsg_3'] = 'Diagramma Confronto Livelli di Adesione';
$lang['permitmsg_4'] = 'Nascondi diagramma confronto livelli di adesione';
$lang['membership_packages'] = 'Pacchetti Adesione';
$lang['membership_packages_compare'] = 'Confronto Pacchetti Adesione';
$lang['modify'] = 'Salva Modifiche';
$lang['manage_membership'] = 'Gestione Adesione';
$lang['privileges_msg'] = 'Privilegi';
$lang['price'] = 'Prezzo: ';
$lang['currency'] = 'Divisa: ';
$lang['choose_membership'] = 'Scegli un livello di adesione:';
$lang['add_membership'] = 'Aggiungi un nuovo tipo di adesione';
$lang['membership_types'] = 'Tipi di Adesione';
$lang['member'] = 'membro';

$lang['select_letter'] = 'Seleziona Lettera:';
$lang['body'] = 'Corpo:';
$lang['module'] = 'Modulo';
$lang['uninstall'] = 'Deinstalla';
$lang['install'] = 'Installa';
$lang['modify_option'] = 'Modifica Opzione';

$lang['only_jpg'] = 'Solo i file JPG or GIF or PNG sono ammessi.';
$lang['upload_unsuccessful'] = 'L\'immagine non pu� essere caricata.';
$lang['upload_successful'] = 'Le immagini sono caricate.';
$lang['between1'] = 'Tra';
$lang['and'] = 'ae';
$lang['profile_details'] = 'Dattagli Profilo';
$lang['personal_details'] = 'Dettagli Personali';


//Banner Management
$lang['manage_banners'] = 'Gestione Striscioni';
$lang['add_banners'] = 'Aggiungi Striscione';
$lang['edit_banners'] = 'Edita Striscione';
$lang['size'] = 'Dimensione';
$lang['size_px'] = 'Dimensione (px)';
$lang['banner_linkurl'] = 'Striscione / URL Link';
$lang['banner_sizes'] = array(
	'468X60' => '468 x 60',
	'100X500'=>'100 x 500',
	'120X120'=>'120 x 120'
);
$lang['banner_sizes_name'] = array( 'orizzontale', 'verticale', 'quadrato' );
$lang['startdate'] = 'Data Inizio:';
$lang['enddate'] = 'Data Fine:';
$lang['tooltip'] = 'Tooltip:';
$lang['linkurl'] = 'Link Url:';
$lang['banner'] = 'Striscione:';
$lang['total_banner'] = 'Striscioni Totali:';
$lang['online_users'] = 'Membri in linea: ';
$lang['site_statistics'] = 'Statistiche del Sito';
$lang['pending_profiles'] = 'Profili Pendenti';
$lang['active_profiles'] = 'Profili Attivi';
$lang['online_profiles'] = 'Profili in-linea';
$lang['pending_aff'] = 'Affiliati Pendenti';
$lang['total_affiliates'] = 'Affiliati Totali';
$lang['active_aff'] = 'Affiliati Attivi';
$lang['no_rating'] = 'Non classificati';

//SEO Words
$lang['seo'] = 'Impostazioni SEO';
$lang['seo_head'] = 'Search Engine Optimization';
$lang['sef_msg'] = 'URL Motori di Ricerca Amici';
$lang['seo_enable'] = 'Abilitazione Riscrittura URL usando mod_rewrite?';
$lang['yes_msg'] ='La riscrittura URL � una caratteristica disponibile solo utilizzando il web server Apache, con l\'estensione mod_rewrite abilitata. Prego assicurarsi che il web server abbia queste caratteristiche. Inoltre, ricordarsi di rinominare il file .htaccess.txt in .htaccess.';
$lang['keywords'] = 'Parole chiave:';
$lang['page_tags_msg'] = 'Titolo Pagina & Meta Tags';
$lang['max_255'] = 'Massimo 255 Caratteri';

//News / Story / Article Manangement
$lang['manage_news'] = 'Gestione Novit�';
$lang['manage_story'] = 'Gestione Storie';
$lang['manage_article'] = 'Gestione Articoli';
$lang['news_header'] = 'Intestazione';
$lang['total_news'] = 'Notizie Totali:';
$lang['total_articles'] = 'Totale Articoli:';
$lang['total_stories'] = 'Totale Storie:';
$lang['article_title'] = 'Titolo';
$lang['story_sender'] = 'Mittente';
$lang['story_sender_msg'] = 'Id Profilo [Digit]';
$lang['modify_article'] = 'Modifica Articolo';
$lang['modify_news'] = 'Modifica Novit�';
$lang['modify_story'] = 'Modifica Storia';
$lang['insert_article'] = 'Aggiungi Articolo';
$lang['insert_story'] = 'Aggiungi Storia';
$lang['insert_news'] = 'Aggiungi Novit�';
$lang['dat'] = 'Data:';

//Poll Words
$lang['manage_polls'] = 'Gestione Sondaggio';
$lang['modify_poll'] = 'Modifica Sondaggio';
$lang['total_polls'] = 'Totale Sondaggi';
$lang['poll'] = 'Poll';
$lang['add_polls'] = 'Aggiungi Sondaggio';
$lang['add_options'] = 'Aggiungi Opzioni';
$lang['active'] = 'Attivo';
$lang['activate'] = 'Attiva';
$lang['option'] = 'Opzione';
$lang['modify_options'] = 'Modifca Opzioni';
$lang['add_option_now'] = 'Aggiungi Opzione Ora.';
$lang['poll_options'] = 'Opzioni Sondaggio';
$lang['votes'] = 'Voto(i)';
$lang['first'] = 'Primo';
$lang['last'] = 'Ultimo';
$lang['filter_records'] = 'Filtra Record';
$lang['search_at'] = 'Cerca a';
$lang['criteria'] = 'Criteri';

//Admin Management
$lang['manage_admins'] = 'Gestione Amministratore';
$lang['total_admins'] = 'Ammin.Totali';
$lang['add_admin'] = 'Aggiungi Ammin.';
$lang['modify_admin'] = 'Modifica Ammin.';
$lang['fullname'] = 'Nome Completo';
$lang['please_be_sure'] = 'Prego assicurarsi di';
$lang['change_your_admin_pwd'] = 'cambiare la tua password di amministratore.';
$lang['superuser'] = 'Super Utente';
$lang['no_admin_user_msg1'] = 'Non esistono Amministratori non Super Utente. Si prega di crearne uno prima.';
$lang['no_admin_user_msg2'] = 'Per creare un utente Ammin. ora.';
$lang['access_denied'] = 'Accesso Negato';
$lang['not_authorize'] = 'Non sei autorizzato ad accedere a questa pagina. Prego contattare il Super Amministratore.';

//Admin Permissions Management
$lang['admin_permissions'] = 'Permessi Amministratore';
$lang['manage_admin_permissions'] = 'Gestione Permessi Amministratore';
$lang['admin_users'] = 'Utenti Ammin.';
$lang['permissions'] = 'Moduli';
$lang['superuser_noteditable'] = 'Nota: I Super Utenti non sono editabili.';
$lang['all'] = 'Tutto';
$lang['selected'] = 'Selezionato';
$lang['selected_users'] = 'Utenti Selezionati';
$lang['separate_users_by_coma'] = 'Inserire i nomi utenti separati da virgole';
$lang['admin_rights'] = array(
		'site_stats' 				=> 'Statistiche del Sito',
		'profie_approval'		 	=> 'Approvazione dei Prfili',
		'profile_mgt' 				=> 'Gestione Profili',
		'section_mgt' 				=> 'Gestione Sezioni',
		'affiliate_mgt' 			=> 'Gestione Affiliati',
		'affiliate_stats'		 	=> 'Statistiche Affiliati',
		'news_mgt' 					=> 'Gestione Novit�',
		'article_mgt' 				=> 'Gestione Articoli',
		'story_mgt'					=> 'Gestione Storie',
		'poll_mgt'		 			=> 'Gestione Sondaggi',
		'search' 					=> 'Ricerca',
		'ext_search'				=> 'Ricerca Estesa',
		'send_letter' 				=> 'Invio Lettera',
		'pages_mgt' 				=> 'Gestione Pagine',
		'chat' 						=> 'Chat',
		'chat_mgt' 					=> 'Gestione Chat',
		'forum_mgt' 				=> 'Gestione Forum',
		'mship_mgt' 				=> 'Gestione Adesioni',
		'payment_mgt' 				=> 'Moduli Pagamento',
		'banner_mgt' 				=> 'Gestione Striscioni',
		'seo_mgt' 					=> 'Impostazioni SEO',
		'admin_mgt' 				=> 'Gestione Ammin.',
		'admin_permit_mgt'			=> 'Permessi Ammin.',
		'global_mgt' 				=> 'Impostazioni Globali del Sito',
		'change_pwd'				=> 'Modifica Password',
		'cntry_mgt'					=> 'Gestione Nazioni/Stati/Citt�',
		'snaps_require_approval'	=> 'Approvazione Immagini',
		'featured_profiles_mgt'		=> 'Profili Caratteristici',
		'calendar_mgt'				=> 'Calendari',
		'event_mgt'					=> 'Approvazione Eventi',
		'import_mgt'				=> 'Importazione',
	/* Added in 2.0 */
      	'plugin_mgt'            	=> 'Gestione Plugin',
		'blog_mgt'					=> 'Gestione Blog',
		'profile_ratings'			=> 'Gestioni Valutazioni Profili',
		);

$lang['cntry_mgt']	= 'Gestione Nazioni / Stati / Citt�';
$lang['register_now'] = 'Registrati ora per unirti alla nostra comunit�!';
$lang['addtobuddylist'] = 'Aggiungi a Lista Amici';
$lang['addtobanlist'] = 'Aggiungi a Lista Interdetti';
$lang['addtohotlist'] = 'Aggiungi a Lista Bollenti';
$lang['buddylisthdr'] = 'Lista Amici';
$lang['banlisthdr'] = 'Lista Interdetti';
$lang['hotlisthdr'] = 'Lista Bollenti';
$lang['username_hdr'] = 'Nome Utente';
$lang['fullname_hdr'] = 'Nome Completo';
$lang['register'] = 'Registrati Ora';
$lang['featured_profiles'] = 'Profili Caratteristici';
$lang['bigger_pic_size'] = 'Dimensione immagine maggiore della dimensione permessa di '.$config['upload_snap_maxsize'].' KB.';
$lang['snaps_require_approval'] = 'Approvazione Immagini';
$lang['events_require_approval'] = 'Approvazione Eventi';
$lang['upload_picture_caption'] = 'Immagine Principale ';
$lang['upload_thumbnail_caption'] = 'Miniatura ';
$lang['Approve'] = 'Approva';
$lang['Remove'] = 'Rimuovi';
$lang['userdetails'] = 'Informazioni Utente';
$lang['pict'] = 'Immagine';
$lang['tnail'] = 'Miniatura';
$lang['reqact'] = 'Azione Desiderata';
$lang['newmemberlist'] = 'Nuovi Membri';
$lang['yearsold'] = 'anni';
$lang['Male'] = 'Maschio';
$lang['Female'] = 'Femmina';
$lang['showfulllist'] = 'Mostra Lista Completa';
$lang['featuredprofiles'] = 'Profili Caratteristici';
$lang['featured_profiles_hdr'] = 'Profili dei Membri Caratteristici';
$lang['nonfeatured_profiles_hdr'] = 'Membri Normali';
$lang['level_hdr'] = 'Livello';
$lang['date_from'] = 'Data Inizio';
$lang['date_upto'] = 'Data Fino a';
$lang['must_show'] = 'Deve Mostrare';
$lang['reqd_exposures'] = 'Esposizioni Richieste';
$lang['total_exposures'] = 'Esposizioni Totali';
$lang['add_featured'] = 'Aggiungi Profilo alla Lista Caratteristici';
$lang['mod_featured'] = 'Modifica Profilo nella Lista Caratteristici';
$lang['member_since'] = 'Membro Da';
$lang['invalid_username'] = 'Nome utente non valido';
$lang['weekcnt'] = 'Membri la Scorsa Settimana:';
$lang['totalgents'] = 'Totale Membri Maschi:';
$lang['totalfemales'] = 'Totale Membri Femmine:';
$lang['weeksnaps'] = 'Immagini la Scorsa Settimana:';
$lang['since_last_login'] = 'dall\'ultimo accesso';
$lang['sincelastlogin_hdr'] ='Dall\'ultimo accesso';
$lang['newmessages'] = 'Nuovi messaggi ricevuti:';
$lang['profileviewed'] = 'Numero di visioni del tuo profilo:';
$lang['winks_received'] = 'Numero di occhiolini ricevuti:';
$lang['send_wink'] = 'Invia un occhiolino';
$lang['listofviews'] = 'Lista dei membri che hanno visto il tuo profilo';
$lang['listofwinks'] = 'Lista dei membri che ti hanno mandato occhiolini';
$lang['winkslist'] = 'Lista Occhiolini';
$lang['viewslist'] = 'Lista Viste';
$lang['suggest_poll'] = 'Suggerisci un Sondaggio';
$lang['savepoll'] = 'Proponi Sondaggio';
$lang['moreoptions'] = 'Pi� Opzioni';
$lang['minimum_options'] = 'Almeno due opzioni necessarie';
$lang['pollsuggested'] = 'Grazie! Il tuo suggerimento per il sondaggio � stato inoltrato all\'Amministratore del Sito.';
$lang['suggested_by'] = 'Suggerito da:';
$lang['any_where'] = 'Ovunque';
$lang['memberpanel'] = "Home Page del Membro";
$lang['feedback_thanks'] = 'Grazie per il tuo feedback. Il tuo messaggio � stato inoltrato all\'Amministratore del Sito.';
$lang['cancel_hdr'] = 'Cancella Adesione';
$lang['cancel_txt01'] = 'Hai richiesto di cancellare la tua adesione a <b>SITENAME</b>.<br /><br />Sei sicuro di volerlo fare? ';
$lang['cancel_opt01'] = 'Si, sono sicuro';
$lang['cancel_opt02'] = 'No, non voglio cancellarmi ora';
$lang['cancel_domsg'] = 'Grazie per avere usato SITENAME. <br><br>Ci dispiace che tu non sia pi� con noi, ma sei benvenuto in ogni momento, e speriamo che tu abbia trovato utili i nostri servizi.';
$lang['cancel_nomsg'] = 'Grazie per utilizzare SITENAME.<br><br>Apprezziamo il tuo continuo supporto, e speriamo che tu abbia trovato i nostri servizi utili.';
$lang['reject'] = 'Rifiuta';
$lang['unread'] = 'Non letto';
$lang['membership_hdr'] = 'Livello Adesione';
$lang['edit_pict'] = 'Edita Immagine Principale';
$lang['edit_thmpnail'] = 'Edita Miniatura';
$lang['letter_options'] = 'Opzioni Lettera';
$lang['pic_gallery'] = 'Immagini';
$lang['reactivate'] = 'Riattiva utente';
$lang['cancel_list'] = 'Lista degli Utenti Cancellati';
$lang['cancel_date'] = 'Data Cancellazione';
$lang['language_opt'] = 'Opzione Linguaggio' ;
$lang['change_language'] = 'Cambia Linguaggio';
$lang['with_photo'] = 'chi ha una foto';
$lang['logintime'] = 'Ora Accesso';
$lang['manage_country_states'] = 'Gestione Nazioni/Stati';
$lang['manage_countries'] = 'Gestione Nazioni';
$lang['countries_count'] = 'Numero di Nazioni';
$lang['insert_country'] = 'Aggiungi nuova Nazione';
$lang['modify_country'] = 'Modifica Nazione';
$lang['country_code'] = 'Codice Nazione';
$lang['country_name'] = 'Nome Nazione';
$lang['manage_states'] = 'Gestione Stati';
$lang['states_count'] = 'Numero di Stati';
$lang['insert_state'] = 'Aggiungi nuovo Stato';
$lang['modify_state'] = 'Modifica Stato';
$lang['state_code'] = 'Codice Stato';
$lang['state_name'] = 'Nome Stato';
$lang['totalcouples'] = 'Totale Coppie di Membri:';
$lang['active_days'] = 'Valido per quanti giorni?';
$lang['activedays_array'] = array('1'=>'1','7'=>'7','30'=>'30','90'=>'90','180'=>'180','365'=>'365','999'=>'999' );
$lang['expired'] = 'La tua adesione � scaduta. <a href="payment.php" class="errors">Rinnova l\'adesione</a> e continua ad apprezzare i benefici di SITENAME';
$lang['compose'] = 'Componi';

$lang['logout_login']='Per provare la tua nuova password, esci e rientra di nuovo.';
$lang['makefeatured'] = 'Clicca qui per aggiungere questo profilo alla lista dei profili caratteristici';
$lang['col_head_gender_short'] = 'Gn';
$lang['no_subject'] = 'Nessun Oggetto';
$lang['admin_col_head_fullname'] = $lang['col_head_fullname'];
$lang['select_from_list'] = '--Select--';

$lang['default_tz'] = '0.00';

$lang['manage_counties'] = 'Contea / Provincia';
$lang['counties_count'] = 'Numero di Contee/Regioni';
$lang['insert_county'] = 'Aggiungi nuova Contea/Regione';
$lang['modify_county'] = 'Modifica Contea/Regione';
$lang['county_code'] = 'Codice Contea/Regione';
$lang['county_name'] = 'Nome Contea/Regione';
$lang['manage_cities'] = 'Citt�';
$lang['cities_count'] = ' Numero di Citt�';
$lang['insert_city'] = 'Aggiungi nuova Citt�';
$lang['modify_city'] = 'Modifica Citt�';
$lang['city_code'] = 'Codice Citt�';
$lang['city_name'] = 'Nome Citt�';
$lang['manage_zips'] = 'Codici CAP';
$lang['zips_count'] = 'Num di Codici CAP';
$lang['insert_zip'] = 'Aggiungi Codici CAP';
$lang['modify_zip'] = 'Modifica Codice CAP';
$lang['zip_code'] = 'Codice CAP';
$lang['show_form'] = 'Mostra Modulo:';
$lang['change_album'] = 'Aggiorna';


/* Following array is for Profile Window display heading conversion */
$lang['extsearchhead'] = array(
	'Marital Status'		=> 'Stato Civile',
	'Ethnicity'				=> 'Etnia',
	'Religion'				=> 'Religione',
	'Hobbies'				=> 'Hobby',
	'Height'				=> 'Altezza',
	'Body Type'				=> 'Tipo di Corpo',
	'Zodiac Sign'			=> 'Segno Zodiacale',
	'Eye color'				=> 'Colore Occhi',
	'Hair color'			=> 'Colore Capelli',
	'Body art'				=> 'Arte Corpora',
	'Best feature'			=> 'Migliore Caratteristica',
	'Hot spots'				=> 'Luoghi Preferiti',
	'Sports'				=> 'Sport',
	'Favorite things'  		=> 'Cose Preferite',
	'Last reading'			=> 'Ultima Lettura',
	'Common interests'		=> 'Interessi Comuni',
	'Sense of humor'		=> 'Senso dell\'umorismo',
	'Exercise'				=> 'Esercizio',
	'Daily diet'			=> 'Dieta Giornaliera',
	'Smoking'				=> 'Fumo',
	'Drinking'				=> 'Bere Alcolici',
	'Job schedule'			=> 'Orario di Lavoro',
	'Current annual income' => 'Reddito Annuo Corrente',
	'Living situation'		=> 'Situazione Abitativa',
	'Kids'					=> 'Figli',
	'Want children'			=> 'Desiderio di figli',
	'Weight'				=> 'Peso',
	'Employment status'		=> 'Stato occupazionale',
	'Education'				=> 'Studi',
	'Languages'				=> 'Lingue',
	'Referred by'			=> 'Appreso da',
);

/* user_stats */

$lang['your_user_stats'] = 'Statistiche Tuoi Utenti';
$lang['other_user_stats'] = 'Statistiche Altri Utenti';

$lang['user_stats'] = 'Statistiche Utenti';
$lang['users_match_your_search'] = 'Utenti che corrispondono ai tuoi criteri di ricerca';
$lang['in_your_country'] = 'Utenti che vivono nella tua nazione';
$lang['in_your_state'] = 'Utenti che vivono nel tuo stato/provincia';
$lang['in_your_county'] = 'Utenti che vivono nella tua contea/regione';
$lang['in_your_city'] = 'Utenti che vivono nella tua citt�';
$lang['in_your_zip'] = 'Utenti che hanno il tuo stesso CAP';
$lang['in_same_gender'] = 'Utenti del tuo stesso genere';
$lang['in_same_age'] = 'Utenti della tua et�';
$lang['above_lookagestart'] = 'Utenti con et� al di sopra del mio limite di et� minimo';
$lang['below_lookageend'] = 'Utenti con et� sotto il mio limite di et� massimo';
$lang['your_lookgender'] = 'Utenti con la tua stessa preferenza di genere';
$lang['in_look_country'] = 'Utenti che vivono nella tua nazione di ricerca';
$lang['in_look_state'] = 'Utenti che vivono nel tuo stato/provincia di ricerca';
$lang['in_look_county'] = 'Utenti che vivono nella tua tua contea/regione';
$lang['in_look_city'] = 'Utenti che vivono nella tua citt�';
$lang['in_look_zip'] = 'Utenti hanno il tuo stesso CAP';
$lang['in_same_timezone'] = 'Utenti che vivono nel tuo stesso fuso orario';
$lang['album_hdr'] = 'Album';
$lang['public'] = 'Pubblco';
$lang['calendar_admin'] = 'Calendario Ammin.';

$lang['mysettings'] = 'Mie Impostazioni';
$lang['user_lists'] = 'Cartelle';
$lang['login_settings'] = 'Impostazioni di Accesso';
$lang['no_pics'] = 'Nessuna immag.';
$lang['my_page'] = 'Mia Pagina';
$lang['write_new_msg'] = 'Scrivi nuovo messaggio';
$lang['view_winkslist'] = 'Vedi occhiolini';

// Import module
$lang['manage_import'] = 'Importa';
$lang['manage_import_datingpro'] = 'Importa da DatingPro';
$lang['manage_import_aedating'] = 'Importa da aeDating';
$lang['manage_import_section'] = 'Selezionare il modulo di importazione';
$lang['manage_import_select'] = 'Selezionare cosa importare';
$lang['module'] = 'Modulo';
$lang['imported'] = 'Importato';
$lang['import'] = 'Importa';
$lang['empty'] = 'Vuoto';
$lang['select_section'] = 'Selezionare Sezione per Domande';
$lang['import_db_configuration'] = 'Impostazione configurazione Database Sorgente';
$lang['db_name'] = 'Nome DB:';
$lang['db_host'] = 'Host DB:';
$lang['db_user'] = 'Utente DB:';
$lang['db_pass'] = 'Password DB:';
$lang['db_prefix'] = 'Prefisso Tabelle:';


// Calendar
$lang['calendar_title'] = 'Gestione Calendariio';
$lang['total_calendars'] = 'Calendari Totali:';
$lang['modify_calendar'] = 'Modifica calendario';
$lang['modify_calendars'] = 'Modifica calendari';
$lang['delete_calendar'] = 'Cancella calendario';
$lang['delete_calendars'] = 'Cancella calendari';

// Calendar Events
$lang['events_title'] = 'Gestione Eventi';
$lang['insert_event'] = 'Aggiungi Evento';
$lang['modify_event'] = 'Modifica Evento';
$lang['total_events'] = 'Eventi Selezionati';
$lang['event'] = 'Evento:';
$lang['calendar_field'] = 'Calendario:';
$lang['private_to'] = 'Privato per:';
$lang['date_from'] = 'Da Data:';
$lang['date_to'] = 'A Data:';
$lang['col_head_calendar'] = 'Calendario';
$lang['col_head_username'] = 'Utente';
$lang['col_head_fullname'] = 'Nome Completo';
$lang['col_head_event'] = 'Evento';
$lang['col_head_datefrom'] = 'Da Data';
$lang['col_head_dateto'] = 'A Data';
$lang['col_head_date'] = 'data';
$lang['col_head_description'] = 'Descrizione';

$lang['calendar_title'] = 'Calendario';
$lang['calendar'] = 'Calendario:';
$lang['event_title'] = 'Evento';
$lang['add_event'] = 'Aggiungi Evento';
$lang['delete_calendar_group_confirm_msg'] = 'Sei sicuro di voler cancellare questi calendari? Questa azione non pu� essere ripristinata.';
$lang['private_only'] = 'Solo Privato';
$lang['public_only'] = 'Solo Pubblico';
$lang['public_private'] = 'Pubblico e Privato';
$lang['total_events_found'] = 'Totale Eventi Trovati:';
$lang['start_date'] = 'Data Inizio';
$lang['start_time'] = 'Ora Inizio';
$lang['end_date'] = 'Data Fine';
$lang['end_time'] = 'Ora Fine';
$lang['event_description'] = 'Descrizione Evento';

$lang['more_events'] = 'pi� eventi >>';
$lang['daily_events_list'] = "Lista di eventi attivi ";
$lang['add_to_private'] = "Aggiungi a Privato";
$lang['close_window'] = "Chiudi Finestra";
$lang['main_window_closed'] = "Spiacente, hai chiuso la finestra principale.";
$lang['user_added1'] = "Utente ";
$lang['user_added2'] = " aggiunto a lista privati";
$lang['next_month'] = 'Mese Successivo';
$lang['previous_month'] = 'Mese Precedente';
$lang['next_week'] = 'Settimana Successiva';
$lang['previous_week'] = 'Settimana Precedente';
$lang['next_day'] = 'Giorno Successivo';
$lang['previous_day'] = 'Giorno Precedente';
$lang['view_day'] = 'Vista Giornaliera';
$lang['view_week'] = 'Vista Settimanale';
$lang['view_month'] = 'Vista Mensile';

$lang['watched_events'] = 'Eventi visualizzati';
$lang['event_notification'] = 'Notifica Eventi';

$lang['jump_to'] = 'Salta a';
$lang['ok'] = 'Ok';

$lang['recurring'] = "Ricorrente:";
$lang['recur_every'] = "ogni";

$lang['recuring_labels'] = array(
	'0' => 'mai',
	'1' => 'giorni',
	'2' => 'settimane',
	'3' => 'mesi',
	'4' => 'anni'
	);

$lang['calendat_filter_dates_range'] = "Intervallo Date Selezionato";
$lang['calendat_filter_last_year'] = "Scorso Anno";
$lang['calendat_filter_last_month'] = "Scorso Mese";
$lang['calendat_filter_last_week'] = "Scorsa Settimana";
$lang['calendat_filter_yesterday'] = "Ieri";


$lang['cannot_determine_membership'] = 'Il tuo livello di adesione non pu� essere determinato';
$lang['no_previous_polls'] = 'Non ci sono sondaggi precedenti.';
$lang['no_event_for_the_day'] = "Non ci sono eventi per questa data";
$lang['maxsize'] = 'Massima dimensione consentita (KB)';
$lang['views'] = 'Viste';

/******************************************/
/* ALL ERROR MESSAGES ARE DEFINED BELOW.  */
/******************************************/

// Affiliates error
$lang['affiliates_error'] = array(
	18 =>'Le password non corrispondono',
	20 =>'Tutti i campi sono richiesti.',
	21 =>'Tutti i campi sono richiesti.',
	25 =>'L\'indirizzo e-mail che hai inserito � gia registrato da un affiliato. Prego usare un altro indirizzo e-mail.'
);


// Javascript error messages
$lang['admin_js_error_msgs'] = array(
	'',
	'Prego selezionare prima una casella.',
	'Sei sicuro di voler procedere all\'eliminazione?',
	'Sei sicuro di voler cancellare questo striscione?'
	);

$lang['admin_js__delete_error_msgs'] = array('',
	1=> 'Sei sicuro di voler cancellare questa sezione? Questa azione non pu� essere revocata.',
	2=> 'Sei sicuro di voler cancellare questa domanda da questa sezione? Questa azione non pu� essere revocata.',
	3=> 'Sei sicuro di voler cancellare questa opzione della domanda? Questa azione non pu� essere revocata.',
	4=> 'Sei sicuro di voler cancellare questo profilo? Questa azione non pu� essere revocata.',
	5=> 'Sei sicuro di voler cancellare questi elementi novit�? Questa azione non pu� essere revocata.',
	6=> 'Sei sicuro di voler cancellare questa storia? Questa azione non pu� essere revocata.',
	7=> 'Sei sicuro di voler cancellare questo articolo? Questa azione non pu� essere revocata.',
	8=> 'Sei sicuro di voler cancellare questo sondaggio? Questa azione non pu� essere revocata.',
	9=> 'Sei sicuro di voler cancellare questa opzione di sondaggio? Questa azione non pu� essere revocata.',
	10=> 'Sei sicuro di voler cancellare questo striscione? Questa azione non pu� essere revocata.',
	11=> 'Sei sicuro di voler cancellare questo Amministratore? Questa azione non pu� essere revocata.',
/* Added in RC6 */
	12=>'Sei sicuro di voler cancellare questa nazione?',
	13=>'Sei sicuro di voler cancellare questo stato/provincia',
	14=>'Sei sicuro di voler cancellare queste nazioni?',
	15=>'Sei sicuro di voler cancellare questi stati/provincie?',
	16=>'Deve essere data l\'intestazione di ricerca estesa quando inclusa nella ricerca estesa.',
	17 => 'I nomi utenti devono essere inseriti quando l\'intervallo di nomi utente � selezionato.',
	18 => 'Sei sicuro di voler cancellare questi profili? Questa azione non pu� essere revocata.',
/* Added Release 1.0 */
	19=>'Sei sicuro di voler cancellare questa contea/regione?',
	20=>'Sei sicuro di voler cancellare queste contee/regioni?',
	21=>'Sei sicuro di voler cancellare questa citt�?',
	22=>'Sei sicuro di voler cancellare queste citt�?',
	23=>'Sei sicuro di voler cancellare questo CAP?',
	24=>'Sei sicuro di voler cancellare questi CAP?',

	25 => 'Sei sicuro di voler cancellare l\'evento? Questa azione non pu� essere revocata.',
	26 => 'Sei sicuro di voler cancellare questo calendario? Questa azione non pu� essere revocata.',
	27 => 'Sei sicuro di voler cancellare questa pagina? Questa azione non pu� essere revocata.',
	);


// Don't use double qoutes(") in the item's text
$lang['signup_js_errors'] = array(
	'username_noblank' => 'Prego inserire il nome utente.' ,
	'password_noblank' => 'Prego inserire la password.',
	'old_password_noblank' => 'La Vecchia Password deve essere specificata.',
	'new_password_noblank' => 'La Nuova Password deve essere specificata.',
	'con_password_noblank' => 'Conferma Password deve essere specificato.',
	'firstname_noblank' => 'Il nome deve essere specificato.',
	'name_noblank' => 'Prego inserire il tuo nome.',
	'lastname_noblank' => 'Il cognome deve essere specificato.',
	'email_noblank' => 'L\' EMail deve essere specificata.',
	'city_noblank' => 'La citt� deve essere specificata.',
	'zip_noblank' => 'Il CAP deve essere specificato.',
	'address1_noblank' => 'Almeno un indirizzi deve essere specificato.',
	'sectionname_noblank' => 'Prego inserire un nome per questa sezione.',
	'sendname_noblank' => 'Prego inserire il nome del mittente.',
	'calendarname_noblank' => 'Prego inserire un nome per questo calendario.',
	'comments_noblank' => 'Prego inserire i commenti che vuoi inviare',
	'question_noblank' => 'Prego inserire una domanda.',
	'extsearchhead_noblank' => 'Prego inserire l\'intestazione di ricerca estesa',
	'username_charset' => 'Solamente lettere, numeri e underscore \'_\' sono ammessi nel nome utente.',
	'password_charset' => 'Solamente lettere, numeri e underscore \'_\' sono ammessi nella password.',
	'firstname_charset' => 'Solamente lettere sono ammesse nel nome',
	'lastname_charset' => 'Solamente lettere sono ammesse nella password.',
	'city_charset' => 'Il nome della citt� deve essere alfabetico.',
	'zip_charset' => 'Solamente numeri sono ammessi nel CAP.',
	'address_charset' => 'Prego inserire un indirizzo valido.',
	'sectionname_charset' => 'Solamente lettere sono ammesse nel nome della sezione.',
	'calendarname_charset' => 'Solamente lettere sono ammesse nel nome del calendario.',
	'sendname_charset' => 'Solamente lettere sono ammesse nel nome mittente',
	'name_charset' => 'Prego usare lettere per i campi nome.',
	'maxlength_charset' => 'Prego immettere un numero intero per la massima lunghezza.',
	'email_notvalid' => 'Indirizzo EMail non valido.',
	'password_nomatch' => 'le password non corrispondono.',
	'password_outrange' => 'La lunghezza della password deve essere nell\'intervallo specificato.',
	'username_outrange' => 'Il numero di caratteri nel nome utente deve essere nell\'intevallo specificato.',
	'username_start_alpha' => 'Il nome utente deve iniziare con una lettera.',
	'ccowner_noblank' => 'Il Possessore della Carta di Credito deve essere specificato.',
	'ccnumber_noblank' => 'Il Numero della Carta di Credito deve essere specificato.',
	'cvvnumber_noblank' => 'Le Cifre di Controllo della Carta di Credito devono essere specificate.',
	'select_payment' => 'Prego selezionare prima un metodo di pagamento.',
	'stateprovince_noblank' => 'Il nome dello stato/provincia deve essere disponibile.',
	'subject_noblank'	=> 'L\'Oggetto della lettere deve essere immesso.',
	'county_noblank' => 'Inserire la Contea/Regione.',
	'county_charset' => 'Il nome della Contea/Regione deve essere alfabetico.',
	'timezone_noblank' => 'Il fuso orario deve essere specificato.',
/* Added in 2.0 */
	'ratingname_noblank' => 'Il nome della valutazione deve essere specificato.',
	'ratingname_charset' => 'Caratteri non validi nel nome della valutazione.',
	'about_me_noblank' 	=> 'Devi inserire a proposito di te stesso.',
	);

$lang['letter_errormsgs'] = array(
		0 => 'La tua password ti � stata inviata mediante e-mail. Controlla la tua casella e-mail.',
		1 => 'Prego inserire l\'indirizzo e-mail utilizzato al momento della registrazione.',
		2 => 'Modello per la lettera di password dimenticata non trovato. Prego contattare un amministratore.',
		4 => 'C\'� un problema nell\'invio della posta. Prego contattare un amministratore.',
		5 => 'Non sei un membro registrato di SITENAME. Prego inserire l\'indirizzo e-mail utilizzato al momento della registrazione.'
	);

$lang['taf_errormsgs'] = array(
		0 => 'L\'invito � stato inviato.',
		'sendername_noblank' => 'Prego inserire il tuo nome.',
		'senderemail_noblank' => 'Prego inserire la tua e-mail.',
		'recipientemail_noblank' => 'Prego inserire la e-mail del destinatario.',
		'sendername_charset' => 'Prego inserire solamente lettere nel tuo nome.',
		'senderemail_charset' => 'Prego inserire una e-mail valida.',
		'recipientemail_charset' => 'Prego inserire una e-mail valida del destinatario.',
		2 => 'Modello lettera D� a un Amico non trovata. Prego contattare un amministratore.',
		3 => 'C\'� un problema nell\'invio dell\'invito. Prego contattare un amministratore.',
	);
$lang['pages_errormsgs'] = array( '',
	1 => 'Titolo pagina mancante.',
	2 => 'Chiave pagina mancante.',
	3 => 'Testo pagina mancante.',
	4 => 'La chiave pagina esiste gi�. Prego scegliere un\'altra chiave.',
	5 => 'La pagina � cancellata.',
	);

$lang['article_error'] = array(
	1 => 'Titolo Articolo � un campo necessario.',
	2 => 'Testo Articolo � un campo necessario.',
	3 => 'Data Articolo � un campo necessario.'
);
$lang['story_error'] = array(
	1 => 'Intestazione Storia � un campo necessario.',
	2 => 'Testo Storia � un campo necessario.',
	3 => 'Data Storia � un campo necessario.',
	4 => 'Mittente Storia � un campo necessario.'
);
$lang['news_error'] = array(
	1 => 'Intestazione Novit� � un campo necessario.',
	2 => 'Testo Novit� � un campo necessario.',
	3 => 'Data Novit� � un campo necessario.'
);

$lang['mship_errors'] = array (
	1 => 'Nome � un campo necessario.',
	2 => 'Prezzo � un campo necessario.',
	3 => 'Divisa � un campo necessario.',
	4 => 'Nessun metodo di pagamento � disponibile quando si cambia il livello di adesione a Gratis.'
);
$lang['admin_error_msgs'] = array (
	'',
	'Sezione � un campo necessario.',
	'Prego completare tutti i campi richiesti'
	);
$lang['admin_error'] = array(
	'',
	1 => 'Nome Utente Amministratore non pu� essere vuoto.',
	2 => 'Password Amministratore non pu� essere vuota.',
	3 => 'Nome Completo Ammin. non pu� essere vuoto.',
	4 => 'Vecchia Password non pu� essere vuota.',
	5 => 'Nuova Password non pu� essere vuota.',
	6 => 'Conferma Password non pu� essere vuoto.',
	7 => 'Nuova Password e Conferma Password devono essere uguali.',
	8 => 'La Vecchia Password che hai immesso non � valida. Riprova.',
	9 => 'Il nome utente specificato � gia in uso. Prego sceglierne un altro.',
	/* added in 1.1.0 */
	10 => 'Prego utilizzare solamente testo come nome della sezione.'
);

$lang['banner_error_msgs'] = array( '',
	1 => 'Striscione non pu� essere lasciato vuoto.',
	2 => 'URL Link non pu� essere lasciato vuoto.',
	3 => 'Tooptip non pu� essere lasciato vuoto.',
	4 => 'Solo striscioni .jpg sono ammessi.',
	5 => 'La dimensione dello striscione � maggiore del limite consentito.'
);
$lang['poll_error'] = array(
	1 => 'Sondaggio non pu� essere lasciato vuoto',
	2 => 'Data Sondaggio non pu� essere lascita vuota',
	3 => 'Opzione non pu� essere vuota.',
	'txtpoll_noblank'  => 'Sondaggio � un campo necessario.',
	'txtpollopt_noblank'  => 'Opzione Sondaggio � un campo necessario.'
	);

$lang['datetime_month'] = array(
	1=>'Gennaio',
	2=>'Febbraio',
	3=>'Marzo',
	4=>'Aprile',
	5=>'Maggio',
	6=>'Giugno',
	7=>'Luglio',
	8=>'Agosto',
	9=>'Settembre',
	10=>'Ottobre',
	11=>'Novembre',
	12=>'Dicembre'
);
$lang['datetime_day'] = array(
	'sunday' => 'Domenica',
	'monday' => 'Luned�',
	'tuesday' => 'Marted�',
	'wednesday' => 'Mercoled�',
	'thursday' => 'Gioved�',
	'friday' => 'Venerd�',
	'saturday' => 'Sabato'
);

/* Release 1.0.2   */
$lang['settings_saved'] = 'Impostazioni salvate con successo';
$lang['select_image_first'] = 'Prego selezionare prima un immagine';

/* Release 1.1.0 additions */
$lang['day_names'] = array(
	'Sun' => 'Domenica',
	'Mon' => 'Luned�',
	'Tue' => 'Marted�',
	'Wed' => 'Mercoled�',
	'Thu' => 'Gioved�',
	'Fri' => 'Friday',
	'Sat' => 'Venerd�'
);
$lang['view_type'] = 'Guarda Tipo';
$lang['remember_me'] = 'Ricordami';
$lang['review'] = 'Riguarda';
$lang['spammers'] = 'Spammer';
$lang['addquestion'] = 'Aggiungi Domanda';
$lang['mainstats'] = 'Statistiche Principali';
$lang['osdate_version'] = 'Versione osDate';
$lang['signonstats'] = 'Statistiche Iscrizioni';
$lang['usersinpastminute'] = 'Utenti nello scorso minuto';
$lang['usersinpasthour'] = 'Utenti nella scorsa ora';
$lang['usersinpastday'] = 'Utenti nel giorno scorso';
$lang['usersinpastweek'] = 'Utenti nella settimana scorsa';
$lang['usersinpastmonth'] = 'Utenti nel mese scorso';
$lang['usersinpastyear'] = 'Utenti nell\'anno scorso';
$lang['usersinpast2years'] = 'Utenti nei 2 anni scorsi';
$lang['usersinpast5years'] = 'Utenti nei 5 anni scorsi';
$lang['usersinpast10years'] = 'Utenti nei 10 anni scorsi';
$lang['userstats'] = 'Statistiche Utenti';
$lang['totalusers'] = 'Utenti Totali';
$lang['totalactiveusers'] = 'Utenti Attivi Totali';
$lang['totalpendingusers'] = 'Utenti Pendenti Totali';
$lang['totalsuspendedusers'] = 'Utenti Sospesi Totali';
$lang['totalpictureusers'] = 'utenti totali che hanno immagini';
$lang['totalonlineusers'] = 'Utenti in linea';
$lang['visitorstats'] = 'Statistiche Visitatori';
$lang['sitestats'] = 'Statistiche Sito';
$lang['visitorstosite'] = 'Visitatori del sito';
$lang['mostactivepage'] = 'pagina pi� attiva';
$lang['timesfeedback'] = 'Numero Volte in cui � stato usato il modulo feedback';
$lang['timesim'] = 'Numero Volte in cui IM � stato usato';
$lang['timeswink'] = 'Numero Volte in cui � stato mandato un occhiolino';
$lang['timesmessage'] = 'Numero Volte in cui un messaggio � stato inviato a una casella posta';
$lang['timesinvitefriend'] = 'Numero Volte in cui � stato invitato un amico';
$lang['timeshowprofile'] = 'Numero Volte in cui � stato usato il Mostra Profilo';
$lang['timesonlineusers'] = 'Numero Volte in cui � stato cliccato utenti online';
$lang['timesbanner'] = 'Numero Volte in cui � stato cliccato uno striscione';
$lang['timesnewmember'] = 'Numero Volte in cui � stato cliccato lista dei nuovi membri';
$lang['timespoll'] = 'Numero Volte in cui � stato utlizzato il sondaggio';
$lang['timesgallery'] = 'Numero Volte in cui � stata usata la galleria immagini.';
$lang['timesaffiliates'] = 'Numero Volte in cui � stato utilizzato affiliati';
$lang['timessignup'] = 'Numero Volte in cui � stato cliccato iscrizioni';
$lang['timesnews'] = 'Numero Volte in cui � stato cliccato novit�';
$lang['timesstories'] = 'Numero Volte in cui � stato cliccato storie';
$lang['timessearchmatch'] = 'Numero Volte in cui � stato cliccato cerca corrispondenza';
$lang['no_affiliates'] = 'Numero di affiliati';
$lang['no_affiliate_refs'] = 'Numero di indirizzamenti affiliati';
$lang['no_pages_refs'] = 'Numero di indirizzamenti pagine';
$lang['no_polls'] = 'Numero di sondaggi';
$lang['no_news'] = 'Numero di elementi Novit�';
$lang['no_stories'] = 'Numero di storie';
$lang['no_langs'] = 'Numero di lingue disponibili';
$lang['glblgroups'] = 'Fruppo Impostazioni Globali';
$lang['accept_tos'] = 'Ho letto e accetto i <a href="javascript:popUpScrollWindow('."'tos.php','center',650,600);".'">Termini del Servizio</a>';
$lang['tos_must'] = 'Prego leggere e accettare i Termini del Servizio prima di registrarsi';
$lang['private_event'] = 'L\'informazione di questo evento � privata';
$lang['posted_by'] = 'Spedito da';

$lang['countries01']='Nazioni';
$lang['states01'] = 'Stati';
$lang['latitude'] = 'Latitudine';
$lang['longitude'] = 'Longitudine';
$lang['search_within'] = 'Cerca all\'interno di';
$lang['miles'] = ' miglia ';
$lang['kms'] = ' chilometri ';
$lang['no_search_results'] = '<font color=red><b>0 Risultati trovati</b></font><br /><br />Nessun risultato corrisponde ai tuoi criteri di ricerca. Forse dovresti espandere la tua ricerca. Prova a ridurre il numero di criteri, per esempio ricerca per altezza e et�, ma non per altezza, et� e tipo di corpo. Oppure, espandi l\'intervallo di ricerca, per esempio invece di cercare persone di et� 40 - 50, cerca persone di et� 30 - 60.<br /><br />';
$lang['expire_on'] = 'L\'adesione scade il';
$lang['expire_in'] = 'Giorni rimaneti alla scadenza adesione';
$lang['lang_to_load'] = 'Linguaggio da caricare';
$lang['load_lang'] = 'Carica Linguaggio';
$lang['manage_languages'] = 'Gestione Linguaggi';
$lang['manage_zips'] = 'Gestione Codici CAP';
$lang['file_not_found'] = 'Il dato file non � stato trovato nel sistema';
/* Modified in 1.1.0 */
$lang['success_mship_change'] = 'Grazie molte per aver aumentato/rinnovato la tua adesione. <br /><br />Il tuo livello di adesione � stato cambiato con successo a';
$lang['payment_cancel'] = 'Pagamento Cancellato';
$lang['checkout_cancel'] = 'Come richiesto, l\'elaborazione del pagamento � stata cancellata.';
$lang['useronlinetext'] = array(
	'online_now'		=> 	'Online Ora',
	'active_24hours'	=> 	'Attivo entro 24 ore',
	'active_3days'		=>	'Attivo entro 3 giorni',
	'active_1week'		=>	'Attivo entro 1 settimana',
	'active_1month'		=>	'Attivo entro 1 mese',
	'notactive'			=>	'Non attivo recentement'
);
$lang['useronlinecolor'] = array(
	'online_now'		=> 	'#FF0000',
	'active_24hours'	=> 	'#00AA00',
	'active_3days'		=>	'#AA00A0',
	'active_1week'		=>	'#0000AA',
	'active_1month'		=>	'#000000',
	'notactive'			=>	'#838383'
);

$lang['transactions_report'] = 'Rapporto Transazioni di Pagamento';
$lang['trans_count'] = 'Conto Transazioni';
$lang['pay_no'] = 'Pagamento Num.';
$lang['ref_no'] = 'Rif. Num.';
$lang['paid_thru'] = 'Pagamento da';
$lang['pay_status'] = 'Stato Pagamento';
$lang['trans_rep'] = 'Rapporto Pagamenti';
$lang['expiry_interval'] = array(
	'1'		=> '24 Ore',
	'3'		=>	'3 Giorni',
	'7'		=>	'7 Giorni',
	'15'	=>	'15 Giorni',
	'30'	=>	'30 Giorni',
	'0'		=>	'Scaduto'
	);
$lang['expiry_hdr'] = 'Lettera di Promemoria Scadenza Adesione';
$lang['expiry_ltr'] = 'Lettera di Scadenza Adesione';
$lang['expiry_select'] = 'Selezionare l\'intervallo di scadenza';
$lang['expiry_ltr_sent'] = 'Lettere di Promemoria Scadenza inviate';
$lang['searching_within'] = 'Ricerca entro';
$lang['payment_failed'] = 'Processo di Pagamento Fallito. Prego riprovare il pagamento.';
$lang['payment_fail'] = 'Pagamento Fallito';
$lang['deactivate'] = 'Disattivato';

$lang['open_search'] = 'Ricerca Aperta';
$lang['replace'] = 'Rimpiazza';
$lang['new'] = 'Nuovo';
$lang['no_save'] = 'Non Salvare';
$lang['modify_curr_search'] = 'Modificare i criteri di ricerca corrente';
$lang['perform_search'] = 'ed esegui la ricerca.';
$lang['start_new_search'] = 'Inizia una nuova ricerca';
$lang['use_empty_form'] = 'usando un modulo vuoto.';
$lang['of_zip_code'] = 'di questo codice CAP';

/* MOD START */

$lang['profile_ratings'] = 'Valutazione Profilo';
$lang['total_ratings'] = 'Totale Valutazioni';
$lang['delete_ratings'] = 'Cancella Valutazioni';
$lang['delete_rating_group_confirm_msg'] = 'Sei sicuro di voler cancellare queste valutazioni? Questa azione non pu� essere revocata.';
$lang['delete_rating_confirm_msg'] = 'Sei sicuro di voler cancellare questa valutazione? Questa azione non pu� essere revocata.';
$lang['modify_rating'] = 'Modifica Valutazione';
$lang['modify_ratings'] = 'Modifica Valutazioni';

$lang['glblsettings_groups']['50'] = 'Valutazioni Profili';
$lang['mod_lowtohigh']['Low to High'] = 'Basso a Alto';
$lang['mod_lowtohigh']['High to Low'] = 'Alto a Basso';
$lang['admin_rights']['profile_ratings'] = 'Valutazioni Profili';

$lang['custom_message'] = 'Messaggio su misura';
$lang['notify_me'] = 'Notificami quando il messaggio � stato letto.';
$lang['include_profile'] = 'Includi il mio profilo in questo messaggio.';
$lang['message_templates'] = 'Modelli messaggio';
$lang['my_templates'] = 'Miei Modelli';
$lang['template_select'] = 'Prego selezionare un modello';
$lang['template_intro'] = 'Se invii frequentemente gli stessi messaggi a potenziali anime gemelle, potresti creare un modello per questi messaggi, per digitare meno. Usando variabili del modello come [username] e [firstname], puoi rendere i tuoi modelli personalizzati per il destinatario.';

$lang['add_template'] = 'Aggiongi Modello';
$lang['return_message'] = 'Ritorna al Messaggio';
$lang['delete_template_confirm_msg'] = 'Sei sicuro di voler cancellare questo modello? Questa azione non pu� essere revocata.';
$lang['edit_template'] = 'Edita Modelli';

$lang['template_instructions'] = 'Le seguenti variabili modello sono disponibili: <br />
[username], [firstname], [city], [state], [country], [age]<br /><br />Puoi usare queste variabili modello per dare un tocco di personalizzazione ai tuoi messaggi, per esempio:<br /><br />ciao [firstname]!<br /><br />ho notato che vieni da [city].... anch\'io! :) penso che noi abbiamo una buona corrispondenza... mandami una e-mail se vuoi sapere di pi� su di me.<br /><br />Ciao,<br />Jamie';

$lang['your_comment'] = 'I tuoi commenti';
$lang['your_reply'] = 'La tua replica';
$lang['comment_note'] = 'Commenti pi� lunghi di 255 caratteri saranno troncati';
$lang['chars_remaining'] = 'caratteri rimanenti';

$lang['delete_comment_confirm_msg'] = 'Sei sicuro di voler cancellare questo commento? Questa azione non pu� essere revocata.';
$lang['no_msg_templates'] = 'Nessun modello di messaggio trovato.';
/* MOD END */

$lang['select'] = '- Seleziona -';
$lang['select_country'] = 'Seleziona Nazione';
$lang['select_state'] = 'Seleziona Stato/Provincia';
$lang['select_county'] = 'Seleziona Contea';
$lang['select_city'] = 'Seleziona Citt�';
$lang['confirm_success'] = 'Accesi sotto per appressare i benefici dell\'adesione.';
$lang['signup_success_message'] = '<b>Grazie!</b><br /><br />&nbsp;Ora sei un utente registrato di SITENAME.';
$lang['noone_online'] = 'Num Membri Online';
$lang['in_hot_list'] = 'Utente nella Lista Bollenti';
$lang['in_buddy_list'] = 'Utente nella Lista Amici';
$lang['in_ban_list'] = 'Utente nella Lista Interdetti';
$lang['delete_search'] = 'Cancella questa ricerca';
$lang['select_user_to_send_message'] = 'Seleziona un utente a cui inviare il tuo messaggio';
$lang['no_im_msgs'] = 'Num.Messaggi IM';
$lang['public_event'] = 'Questo evento � vedibile dal pubblico';
$lang['no_event_description'] = 'Nessuna descrizione fornita';
$lang['signup_js_errors']['country_noblank'] = 'Country should be selected';
$lang['msg_sent'] = 'Il tuo messagio � stato inviato';
$lang['forgotpass_msg4'] = 'Hai dimenticato il tuo login? Il tuo nome utente, con una nuova password, pu� essere inviato il tuo indirizzo e-mail. Prego fornire l\'indirizzo e-mail utilizzato durante la registrazione.';

/* 	Additions for new email messaging interface
	Vijay Nair
*/
$lang['send_a_message'] = 'Invia Messaggio';
$lang['flagged'] = 'Contrassegnato';
$lang['un_flagged'] = 'Non contrassegnato';
$lang['unflagged_msg1'] = 'Messaggi non contrassegnati pi� vecchi di ';
$lang['unflagged_msg2'] = ' giorni sono rimossi automaticamente.';
$lang['no_messages_in_box'] = 'Non ci sono messaggi in questa cartella di posta';
$lang['no_flagged_messages_in_box'] = 'Non ci sono messaggi contrassegnati in questa cartella di posta';
$lang['no_unflagged_messages_in_box'] = 'Non ci sono messaggi non contrassegnati in questa cartella di posta';
$lang['mark'] = 'Marca';
$lang['flag'] = 'Contrassegna';
$lang['unflag'] = 'Non contrassegnare';
$lang['msg_flagged'] = 'Messaggio contrassegnato';
$lang['msg_unflagged'] = 'Messaggio non contrassegnato';
$lang['msg_deleted'] = 'Messaggio cancellato';
$lang['sel_msgs_flagged'] = 'I messaggi selezionati sono contrassegnati';
$lang['sel_msgs_unflagged'] = 'I messaggi selezionati sono non contrassegnati';
$lang['sel_msgs_deleted'] = 'I messaggi selezionati sono cancellati';
$lang['sel_msgs_undeleted'] = 'I messaggi selezionati sono ripristinati';
$lang['sel_msgs_read'] = 'I messaggi selezionati sono marcati come letti';
$lang['sel_msgs_unread'] = 'I messaggi selezionati sono marcati come nuovi';
$lang['FROM1'] = 'Da';
$lang['no_thanks'] = 'D� \"No, grazie\"';
$lang['reply'] = 'Replica';
$lang['undelete'] = 'Ripristina';
$lang['back_to_messages'] = 'Torna ai messaggi';
$lang['replied'] = 'Replica inviata';
$lang['no_thanks_subject'] = 'Grazie, ma no grazie...';
$lang['total'] = 'Totale';
$lang['max_allowed'] = 'Massimo consentito';
$lang['im_msg_long'] = 'Messaggio IM ha dimensione maggiore del consentito ';
$lang['members'] = 'membri';
$lang['To1'] = 'A';

/* Items which are modified in 1.1.0 */


$lang['change_email'] = 'Cambia e-mail';

/* Changes made for letters  */
$lang['no_watched_event'] = 'Non stai guardanto nessun evento al momento.
<br /><br />Ci sono #eventcount# eventi che accadranno nei prossimi 30 giorni. <a "#calenderlink#">Apri il calendario</a> per vedere questi eventi.
<br /><br />Per guardare un evento, clicca l\'evento nel calendario, poi clicca l\'icona con la lente d\'ingrandimento. #glassicon#
<br /><br />Ogni evento che aggiungi scadr� quando l\'evento termina.';

$lang['no_thanks_message']['text'] = 'Ciao #recipient_username#,

Grazie per il tuo interesse, ma devo rispettosamente declinare. Spero che troverai la tua anima gemella su #site_name#.

Con i migliori auguri,
#sender_username#';

$lang['message_read']['text'] = "Caro/a #FirstName#,

Il messaggio che hai inviato a '#RecipientName#' � stato letto.

Buona Fortuna!
#AdminName#
SITENAME";


$lang['featured_profile_added']['text'] = "Caro/a #FirstName#,

Ci d� grande piacere includere il tuo profilo tra i Profili Caratteristici nela Lista dei Profili Caratteristici su <a href=\"#link#\">#siteName#</a>.

Il tuo profilo sar�presente da #FromDate# a #UptoDate#.

Questo accrescer� la visibilit� del tuo profilo potrebbero esserci molti pi� sguardi da potenziali anime gemelle.

Buona Fortuna!
#AdminName#
SITENAME";

$lang['wink_received']['text'] = "Caro/a #FirstName#,

Hai ricevuto un occhiolino dall\'utente '#SenderName#' di #siteName#.

Visita il sito <a href=\"#link#\">#siteName#</a> per inviare un messaggio a '#SenderName#' o ricambiare l\'occhiolino.

Buona Fortuna!
#AdminName#
SITENAME";

$lang['invite_a_friend']['text'] = "Ciao,

Ho trovato un bel sito di appuntamenti navigando nel web: #SiteUrl#.

Ho pensato che potesse essere interessante per te.

Visita #SiteUrl#.

#FromName#";

$lang['profile_confirmation_email']['text'] = "Caro/a #FirstName#,

Grazie per esserti registrato/a a #siteName#! Come nuovo membro della nostra comunit�, ti incoraggio ad esplorare i nostri servizi e le nostre caratteristiche.

Per confermare l\'aggiunta del tuo profilo, clicca sul link sotto. Oppure, se il link non � cliccabile, copialo ed incollalo nella barra indirizzo del tuo web browser, per accedervi direttamente.

#ConfirmationLink#=#ConfCode#

Se hai ancora aperto l\'ultimo passo della procedura di registrazione, puoi copiare il codice di conferma in quella schermata.

Il tuo codice di conferma �: #ConfCode#

Abbiamo annotato le seguenti informazioni per te:

Nome utente: #StrID#
Password: #Password#
E-Mail: #Email#

Per favore tieni queste informazioni in un luogo sicuro, cos� che sarai in grado di accedere a tutti i servizi e le caratteristiche disponibili per te. Alcuni servizi possono riciedere un livello di adesione pi� alto, che puoi ottenere qui:

#SiteUrl#payment.php

Grazie ancora per utilizzare i nostri servizi, speriamo che trovi la tua anima gemella!

#AdminName#
#siteName#";

/* Added in 1.1.1 */
$lang['loading'] = 'Caricamento..';


/* Changes in 1.1.3 */
$lang['support_currency'] = array(
		'USD' 	=> '$',
		'EUR'	=>'�',
		'INR'	=>'Rs.',
		'AUD'	=> 'AU$',
		'CD'	=> 'CAN$',
		'UKP'	=> chr(163)
		);


$lang['ratings'] = 'Valutazioni';
$lang['comment'] = 'Commento';
$lang['comments'] = 'Commanti';
$lang['loadaction'] = 'Seleziona l\'azione necessaria';
$lang['loadintodb'] = 'Carica nel DB';
$lang['createsql'] = 'Crea Script SQL';


/* Version 2.0 additions and modifications */
/* Modifications */
$lang['submit'] = 'Invia';
$lang['lang_ensure'] = 'Prima definisci un nuovo linguaggio e un nome file in config.php (vedere la definizione di $language_options e $language_files). Poi carica il file del linguaggio in nella directory /language/lang_xxxx/ come file lang_main.php prima di procedere. (xxxx � il nome del linguaggio in lettere minuscole. Per esempio: english, dutch, ecc.).<br /><br /><b>Per modificarlo e/o aggiungere nuovi elementi nella definizione esistente del linguaggio, esegui i cambiamenti necessari al file del linguaggio e ricaricalo.</b><br /><br />Per rimuovere definizioni del linguaggio gi� caricate per un certo linguaggio, seleziona il linguaggio e clicca il bottone "Rimuovi Linguaggio dal DB".';

/* $lang['rate_catefully'] is changed as below */
$lang['rate_carefully'] = 'Gli operatori di questo sito web non sono a conoscenza dell\'accuratezza o affidabilit� di queste valutazioni.<br />Le valutazioni sono inviate dagli utenti, e non sono esaminate dallo staff..';


$lang['privileges'] = array (
	'chat' 				=> 'Partecipa alle chat.',
	'blog'				=> 'Partecipa al blog.',
	'poll'				=> 'Partecipa ai sondaggi.',
	'forum'				=> 'Partecipa al forum.',
	'includeinsearch' 	=> 'Incluso nei risultati delle ricerche',
	'message'			=> 'Invio di messaggi alla casella posta',
	/* Added in 1.1.0 */
	'message_keep_cnt'  => 'Numero di messaggi da tenere.',
	'message_keep_days' => 'Numero di giorni in cui pu� essere tenuto un messaggio',
	/* rel 2.0 */
	'messages_per_day' 	=> 'Numero di messaggi inviabili ogni giorno.',
	/* Rel 1.0 added  */
	'allowim'			=> 'Consenti messaggi istantanei.',
	'uploadpicture'		=> 'Carica immagini',
	'uploadpicturecnt'	=> 'Numero di immagini che � possibile caricare.',
	'allowalbum'		=> 'Consenti album privati.',
	'event_mgt'			=> 'Consenti la gestione eventi.',
	/* Above is added in 1.0 */
	'seepictureprofile' => 'Guarda le immagini dei profili.',
	'favouritelist'		=> 'Gestione liste amici/interdetti/bollenti.',
	'sendwinks'			=> 'Invio occhiolini.',
	/* rel 2.0 */
	'winks_per_day' 	=> 'Numero di occhiolini inviabili ogni giorno.',
	'extsearch'			=> 'Esegui ricerca estesa.',
//	'fullsignup' 		=> 'Full signup.',
	/* RC6 Patch */
	'activedays'		=> 'Giorni validi per questo livello..',
	/* added in 2.0 */
	'saveprofiles'		=> 'Consenti salvataggio profili.',
	'saveprofilescnt'	=> 'Numero di profili che � possibile salvare.',
	'allow_videos'		=> 'Consenti il caricamento dei video.',
	'videoscnt'			=> 'Numero di video che � possibile caricare.',
	'allow_mysettings'	=> 'Consenti all\'utente di impostare le preferenze.',
	'allow_php121'		=> 'Consenti messaggi istantanei php121.',

);

/* 	Signup Error Messages
	These are the signup error messages, Please do not change the sequence.
*/

$lang['errormsgs']= array(
	00 => '',
	01 => 'Nome utente � un campo necessario.',
	02 => 'Password � un campo necessario.',
	03 => 'Conferma Password � un campo necessario.',
	04 => 'Nome � un campo necessario.',
	05 => 'Cognome � un campo necessario.',
	06 => 'Indirizzo e-mail � un campo necessario.',
	07 => 'Citt� � un campo necessario.',
	08 => 'CAP � un campo necessario..',
	09 => 'Indirizzo linea 1 � un campo necessario.',
	10 => 'La lunghezza massima di nome utente � 25 caratteri.',
	11 => 'La lunghezza massima di nome � 50 caratteri.',
	12 => 'La lunghezza massima di cognome � 50 caratteri.',
	13 => 'La lunghezza massima di e-mail � 255 caratteri.',
	14 => 'La lunghezza massima di Citt� � 100 caratteri.',
	15 => 'La lunghezza massima di indirizzo linea 1 � 255 caratteri.',
	16 => 'Nome utente deve iniziare con una lettera.',
	17 => 'Password deve iniziare con una lettera.',
	18 => 'Password e conferma passwod devono corrispondere.',
	19 => 'Prego inserire un indirizzo e-mail valido.',
	20 => 'L\'informazione richiesta deve essere inserita.',
	21 => 'Le credenziali di accesso che hai fornito non consentono l\'accesso al sistema. Prego controllare e ripetere l\'operazione.',
	22 => 'Il nome utente esiste gi�. Prego sceglierne uno diverso.',
	23 => 'La vecchia password che hai inserito non � corretta. Prego controlla la tua vecchia password e riprova.',
	25 => 'E-Mail gi� registrata.' ,
//	26 => "Your status is 'Not Active'. Please wait while activating or mail to administrator." ,
	27 => 'Impossibile trovare il messaggio.',
	28 => 'Prego selezionare prima un file.',
	29 => 'Formto file non supportato, prego sceglierne un altro',
	30 => 'La domanda � gia in cima.',
	31 => 'La domanda � gia in fondo.',
	32 => 'Grazie per i tuoi commenti. Il tuo feedback verr� esaminato il pi� presto.',
	33 => 'Il CAP non corrisponde allo stato specificato.',
	34 => 'CAP non valido',
	36 => 'Il tuo account � stato sospeso. Prego contattare l\'Amministratore per ulteriori dettagli.',
	37 => 'I tuoi invii sono stati declinati. Prego contattare l\'Amministratore per ulteriori dettagli.',
	38 => 'Hai specificato una data di nascita non valida. Prego controlla e prova ancora.',
	39 => 'La vecchia e nuova password non sono la stessa',
	40 => 'Et� iniziale deve essere minore o uguale a et� finale.',
	51 => 'Data iniziale deve essere prima della data finale',
	52 => 'Questo membro � gi� nella lista',
	53 => 'Data non valida',
	54 => 'Password o nome utente non valido',
	55 => 'Devi accedere per inviare un messaggio',
	56 => $lang['bigger_pic_size'],
	57 => $lang['only_jpg'],
	58 => $lang['upload_unsuccessful'],
	59 => 'Questo profilo � aggiunto alla lista',
	60 => 'La dimensione della miniatura eccede ('.$config['upload_snap_tnsize'].' X '.$config['upload_snap_tnsize'].')',
	61 => 'Codice di attivazione non valido',
	62 => 'Il nome utente � stato rimosso dalla lista.',
	63 => 'Questo utente � stato aggiunto alla tua Lista Amici',
	64 => 'Questo utente � stato aggiunto alla tua Lista Interdetti',
	65 => 'Questo utente � stato aggiunto alla tua Lista Bollenti',
	66 => 'Il tuo occhiolino � stato inviato a questo utente',
	67 => $lang['upload_successful'],
	68 => 'L\'immagine � stata approvata',
	69 => 'L\'immagine � stata rifiutata',
	70 => 'Il record sguardi � stato rimosso',
	71 => 'Il record occhiolini � stato rimosso',
	/* Added in RC6  */
	72 => 'L\'aacount utente � stato riattivato',
	73 => 'La nazione � stata aggiunta',
	74 => 'La nazione � stata cancellata',
	75 => 'Nome o codice della nazione gi� in uso',
	76 => 'La nazione � stata modificata',
	77 => 'Lo stato � stato aggiunto',
	78 => 'Lo stato � stato cancellato',
	79 => 'Codice o nome stato gi� in uso',
	80 => 'Lo stato � stato modificato',
	81 => 'Deve essere specificato il nome dello stato/provincia ',
	82 => 'Nessuna immagine � stata caricata da questo membro. ',
	83 => 'Il profilo � stato cancellato',
	84 => 'Il profili selezionati sono cancellati.',

	85 => 'Profilo/i selezionato/i attivato/i.',
	86 => 'Profilo/i selezionato/i rifiutato/i.',
	87 => 'Profilo/i selezionato/i sospeso/i.',

	26 => 'Il tuo profilo non � stato ancora attivato. <a href=\'completereg.php\'>Attiva il tuo account</a> inserendo il codice di conferma o usando il link fornito nella mail inviata all\' indirizzo e-mail fornito al momento della registrazione.',

//	26 => 'Your affiliate account hasn\'t yet been activated by an administrator. Please wait for this activation before using your affiliate account.',

	35 => 'Il tuo profilo non � ancora approvato.<br /> Per favore attendi l\'approvazione o contatta l\'Amministratore',

/* Release 1.0 additions/modifications  */

	88 => 'La contea/regione � stata aggiunta',
	89 => 'La contea/regione � stata cancellata',
	90 => 'Il codice o il nome della contea/regione � gi� in uso',
	91 => 'La contea/regione � stata modificata',
	92 => 'La citt� � stata aggiunta',
	93 => 'La citt� � stata cancellata',
	94 => 'Il nome o il codice della citt� � gi� in uso',
	95 => 'la citt� � stata modificata',
	96 => 'Il CAP � stato aggiunto',
	97 => 'Il CAP � stato cancellato',
	98 => 'Il CAP � gi� in uso',
	99 => 'Il CAP � stato modificato',
	100 => 'Contea/regione � un campo necessario',
	101 => 'password non valida',
	102 => 'L\'evento � stato approvato.',
	103 => 'L\'evento � stato rifiutato.',
	301 => 'Fuso Orario non valido',
	302 => 'L\'album � stato aggiornato',
/* 1.1.0 additions */
	104 => 'Il login che hai fornito non � stato trovato. Prego controlla e prova ancora, o usa l\'opzione sotto se non ricordi i dati.',
	105 => 'Utenti nella lista interdetti',
	/* Added in 2.0 */
	111 => 'Questo membro � gi� nella lista di membri caratteristici',
	120	=>	'Deve essere inserito il codice di sicurezza',
	121 => 'Codice di sicurezza non valido ',
	122 => 'Hai gi� inviato il numero di messaggi consentiti per oggi. Per favore riprova domani.',
	123 => 'Hai gi� inviato il numero di occhiolini consentiti per oggi. Per favore riprova domani.',
	124 => 'File video caricato',
	125 => 'Il file video non pu� essere caricato perch� il file ha un formato incompatibile.',
	126 => 'Devi inserire a proposito di te stesso.',
	128 => 'I nomi utente individuali dei membri che formano una coppia dovrebbero essere inseriti..',
	129 => 'I nomi utente devono essere gi� disponibili.',
	130 => 'Il file video non pu� essere convertito. Prego utilizzare video con formato .flv.',
	131 => 'Hai superato il numero di messaggi consentiti per il tuo livello di adesione.',
	201 => 'Hai gi� salvato profili nella lista dei profili guardati, fino al limite consentito.',
	202 => 'Questo profilo � aggiunto alla tua lista dei profili guardati.',
	203 => 'Qusto profilo � gi� nella lista dei profili guardati',
	);


$lang['alphanumeric'] = "0123456789.+-_#,/ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz ()_";
$lang['alphanum'] = "0123456789_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz ";
$lang['text'] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz '";
$lang['full_chars'] = "0123456789.+-_#,/ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz() _$+=;:?'";
/* Additions  in Version 2.0 */

$lang['save'] = 'Salve';
$lang['delete_zips'] = 'Cancella codici CAP';
$lang['zipcodes_sql_created'] = 'SQL file codici CAP creato ';
$lang['zipcodes_loaded'] = 'Codici CAP caricati da ';
$lang['delzips_msg'] = 'Tutti i codici CAP per questa nazione saranno cancellati';
$lang['delzips_succ'] = 'Codici CAP per #COUNTRY# cancellati';
$lang['wrong_zipfile'] = 'Questo file non � per la nazione #COUNTRY#';
$lang['load_states'] = 'Elaborazione file degli stati';
$lang['state_ensure'] = 'Prego caricare il file con i codici degli stati nella directory /states prima di elaborare. <br /><br />Il file dovrebbe contenere STATECODE e STATENAME separati da virgole.(senza intestazione)<br /><br /> Per cancellare i codici stato per una nazione, selezionare la nazione e premere il bottone "Cancella codici stato"';
$lang['statefile'] = 'File codifi stato';
$lang['delete_states'] = 'Cancella codici stato';
$lang['delstates_msg'] = 'Tutti i codici per questa nazione saranno cancellati';
$lang['delstates_succ'] = 'I codici stato per #COUNTRY# sono cancellati';
$lang['states_sql_created'] = 'File SQL con i codici stato creato ';
$lang['states_loaded'] = 'Codici stato caricati da ';
$lang['delete_lang'] = 'Rimuovi la lingua dal DB';
$lang['langfile_loaded'] = 'Definizioni della lingua per #LANGUAGE# caricate da ';
$lang['lang_deleted'] = 'Definizioni della lingua per #LANGUAGE# eliminate';
$lang['load_counties'] = 'Elabora il file contee';
$lang['countyfile'] = 'File codici contee';
$lang['county_ensure'] = 'Prego caricare il file con i codici delle contee/regioni nella directory /counties prima di elaborare. <br /><br />Il file dovrebbe contenere COUNTYCODE, COUNTYNAME e STATECODE separati da virgole.(stesso ordine, senza intestazione)<br /><br /> Per cancellare i codici contea/regione per uno stato, selezionare lo stato e premere il bottone "Cancella codici contee/regioni" ';
$lang['delete_counties'] = 'Cancella codici contee/regioni';
$lang['delcounties_msg'] = 'Tutti i codici contea/regione per questo stato saranno cancellati';
$lang['delcounties_succ'] = 'Codici Contea/Regione per #COUNTRY# cancellati';
$lang['counties_sql_created'] = 'File SQL con i codici contea/regione creato ';
$lang['counties_loaded'] = 'Codici Contea/Regione caricati da ';
$lang['load_cities'] = 'Elabora il file citt�';
$lang['cityfile'] = 'File codici citt�';
$lang['city_ensure'] = 'Prego caricare il file con i codici delle citt� nella directory /cities prima di elaborare. <br /><br />Il file dovrebbe contenere CITYCODE, CITYNAME, COUNTYCODE e STATECODE separati da virgole.(stesso ordine, senza intestazione)<br /><br /> Per cancellare i codici citt� per uno stato, selezionare lo stato e premere il bottone "Cancella codici citt�" ';
$lang['delete_cities'] = 'Cancella codici citt�';
$lang['delcities_msg'] = 'Tutti i codici citt� per questo stato saranno cancellati';
$lang['delcities_succ'] = 'I codici citt� per #COUNTRY# sono cancellati';
$lang['cities_sql_created'] = 'File SQL con i codici citt� creato ';
$lang['cities_loaded'] = 'Codici citt� caricati da ';
$lang['online'] = 'Online';
$lang['watchedprofiles_1'] = 'Aggiungi ai profili guardati';
$lang['watchedprofiles'] = 'Profili Guardati';


$lang['poll'] = 'Sondaggio';
$lang['section_poll_title'] = 'Sondaggio';
$lang['section_poll_list'] = 'Lista Sondaggi';
$lang['section_add_poll'] = 'Crea Sondaggio';
$lang['poll_subtitle_list'] = 'Lista Sondaggi';
$lang['poll_subtitle_add'] = 'Crea Sondaggio';
$lang['poll_subtitle_edit'] = 'Edita Sondaggio';
$lang['poll_number'] = 'Numero';
$lang['poll_active_hdr'] = 'Attivo';
$lang['poll_question_hdr'] = 'Domande';
$lang['poll_responses_hdr'] = 'Risposte';
$lang['no_poll_found'] = 'Nessun Sondaggio Trovato';
$lang['poll_question'] = 'Domanda';
$lang['poll_options'] = 'Opzioni';
$lang['poll_active'] = 'Attivo';
$lang['poll_minimum_two'] = 'Almeno due sono richieste.';
$lang['results_poll_title'] = 'Risultati';
$lang['poll_subtitle_results'] = 'Risultati Sondaggio';
$lang['take_poll_title'] = 'Esegui Sondaggio';
$lang['poll_entries'] = 'Sondaggio';


$lang['plugin_access'] = 'Plugin';
$lang['section_plugin_title'] = 'Plugins';
$lang['section_plugin_list'] = 'Lista Plugin';
$lang['section_add_plugin'] = 'Carica Plugin';
$lang['plugin_subtitle_list'] = 'Lista Plugin';
$lang['plugin_number'] = 'Numero';
$lang['plugin_name'] = 'Nome';
$lang['plugin_active'] = 'Attivo';
$lang['plugin_installed'] = 'Installato';
$lang['plugin_install'] = 'Installa';
$lang['no_plugin_found'] = 'Nessun Plugin trovato';
$lang['plugin_file'] = 'Carica il File Zip del Plugin';
$lang['plugin_subtitle_edit'] = 'Edita Plugin';
$lang['add_plugin_summary'] = 'La documentazione oer creare un plugin � compresa nell\'installazione di osDate.';

$lang['blog']['hdr'] = 'Blog';
$lang['admin_blog'] = 'Sito Blog';
$lang['blog_default_bad_words'] = 'xxx|levitra';
$lang['blog_bad_words'] = 'Parolacce';
$lang['blog_save_template'] = 'Salva come Modello';
$lang['blog_load_template'] = 'Carica Modello';
$lang['blog_bad_words_help'] = '(una parola per linea)';
$lang['blog_search_results'] = 'Risultati Ricerca Blog';
$lang['section_blog_info'] = 'Impostazioni Blog';
$lang['section_blog_list'] = 'Voci Blog';
$lang['section_blog_title'] = 'Blog';
$lang['blog_search_menu'] = 'Ricerca Blog';
$lang['blog_search_username'] = 'Nome Utente';
$lang['blog_search_title'] = 'Titolo';
$lang['blog_search_body'] = 'Testo';
$lang['blog_search_Date'] = 'Data';

$lang['blog_subtitle_list'] = 'Lista Blog';
$lang['blog_name'] = 'Nome Blog';
$lang['blog_description'] = 'Descrizione Blog';
$lang['blog_members_comment'] = 'Commenti dei membri';
$lang['blog_buddies_comment'] = 'Commenti degli Amici';
$lang['blog_members_vote'] = 'Voi dei Membri';
$lang['blog_gui_editor'] = 'Editor WYSIWYG';
$lang['blog_max_comments'] = 'Commanti massimi';
$lang['no_blog_found'] = 'Nessuna voce trovata';
$lang['section_add_blog'] = 'Crea Voce Blog';
$lang['blog_subtitle_add'] = 'Crea Voce Blog';
$lang['blog_subtitle_edit'] = 'Edita Blog';
$lang['blog_title'] = 'Titolo';
$lang['blog_story'] = 'Contenuto';
$lang['blog_posted_date'] = 'Data Invio';
$lang['blog_title_hdr'] = 'Titolo';
$lang['blog_rating_list_hdr'] = 'Valutazione';
$lang['blog_number'] = 'Numero';
$lang['blog_date_posted_hdr'] = 'Data';
$lang['blog_views_hdr'] = 'Viste';
$lang['blog_votes_hdr'] = 'Voti';
$lang['blog_votes1'] = 'voti';
$lang['blog_rating_hdr'] = 'basato su';
$lang['blog_submit_vote'] = 'Vota';
$lang['blog_add_vote'] = 'Vota ora';
$lang['view_blog'] = 'Vedi il Blog';
$lang['blog_entries'] = 'Blog:';
$lang['blog_creator'] = 'Autore';
$lang['blog_comments'] = 'Commenti';
$lang['add_comment'] = 'Tuoi commenti';
$lang['total_blogs_found'] = 'Totale voci blog trovate:';

$lang['blog_errors'] = array(
   'nosetup' => 'Le impostazioni iniziali del Blog devono essere specificate.' ,
   'name_noblank' => 'Il nome del Blog deve essere specificato.' ,
   'description_noblank' => 'La descrizione del Blog deve essere specificata. ',
   'date_posted_noblank' => 'La data di invio deve essere specificata.' ,
   'title_noblank' => 'Un titolo deve essere specificato.' ,
   'story_noblank' => 'Il contenuto deve essere specificato.' ,
   'max_stories_warning' => 'Hai raggionto il massimo numero di storie. Non � possibile aggiungere altre storie.' ,
   'comment_bad_word' => 'Il tuo commento contiene la parola vietata %s' ,
);
$lang['spell_check'] = 'Controllo Ortografia';

$lang['manage_import_webdate'] = 'Importazione da Webdate';
$lang['import_config'] = 'Configurazione';

$lang['forum_values'] = array(
   'None' => 'nessuno',
   'phpBB' => 'phpBB',
   'vBulletin' => 'vBulletin',
   'myBB' => 'myBB',
   'Phorum' => 'Phorum',
   );

$lang['photos_url'] = 'URL Home Page:';
$lang['ftp_username'] = 'Nome utente FTP:';
$lang['ftp_password'] = 'Password FTP :';
$lang['ftp_hostname'] = 'Hostname FTP:';
$lang['ftp_path'] = 'Percorso aeDating FTP:';
$lang['ftp_path_help'] = 'Percorso della directory di aeDating durante l\'accesso via FTP.  Es. public_html/aeDating';

$lang['nopicsloaded'] = 'Nessuna immagine';
$lang['loadedpicscnt'] = '#PICSCNT# immagine(i)';
$lang['loadedpicscnt1'] = '#PICSCNT# immagine';
$lang['picsloaded'] = 'Immagini caricate';
$lang['since'] = 'da';
$lang['unknown'] = 'Sconosciuto';

$lang['glblsettings_groups'] = array(
1	=>	'Informazioni Sito',
2	=> 	'Controlli Utente',
3	=>	'Controlli Calendario',
4	=>	'Impostazioni Posta',
5	=>	'Immagini del profilo e miniature',
6	=>	'Layout Pagina e Tabella',
);

$lang['who_is_online'] = 'Solo utenti online';
$lang['search_with_photo'] = 'Solo utenti con foto';
$lang['search_with_video'] = 'Solo utenti con video';
$lang['expire_on_hdr'] = 'Scade il';
$lang['expird'] = 'Scaduto';
$lang['pics'] = 'Immag.';
$lang['pic_deleted'] = 'La foto selezionata � stata rimossa';
$lang['entrycode_chars'] = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
$lang['enter_spamcode'] = 'Codice sicurezza';

/* Admin emails portion */


/* Modified in 2.0 */
$lang['payment_msg1'] = 'Metodi di pagamento dispponibili:';

$lang['wrong_activationcode'] = 'Il codice di conferma non � corretto o l\'account � gi� stato confermato.';

$lang['security_code_txt'] = 'Si prega di leggere il testo nell\'immagine sotto e inserire quel teto nella casella accanto ad essa. Ti viene richiesto di fare cos� per verificare che questa azione non sia eseguita da qualche processo automatizzato.';
$lang['additional_pics'] = 'Immagini aggiuntive';
$lang['view_all_pics'] = 'Guarda tutte le immagini';
$lang['insufficientPrivileges'] = 'Non disponi dei privilegi sufficienti per questa opzione. Prego migliora il tuo livello di adesione.';
$lang['username_part_msg'] = "Se non sei sicuro del nome utente, inserisci parte del nome utente per mostrare tutte le possibili ugualianze. Per esempio, immettendo 'user', verranno mostrati 'user123', 'someuser' ecc.";
$lang['featured_profiles_msg01'] = "Devi Mostrare: 'Si' dar� preferenza a questo profilo per essere selezionato ed essere mostrato nella lista profili caratteristici. 'No' ridurr� la possibilit� di venire selezionato. ";

$lang['featured_profiles_msg02'] = "Esposizioni richieste: Questo � il numero di esposizioni richieste prima che questo profilo sia tolto dalla lista caratteristici, se le esposizioni sono raggiunte prima della data di fine.";
$lang['lookup'] = 'Ottieni';
/* for use in shoutbox */
$lang['sb_by'] = 'Inviato da:';
$lang['sb_hdr'] = 'Scatola dell\'urlo';
$lang['sb_send'] = 'Invia';
$lang['sb_error'] = 'Il testo inserito supera la lunghezza consentita';
$lang['sb_msg_blank'] = 'Messaggio vuoto?';
$lang['sb_show_all'] = 'Mostra tutto';

$lang['upload_videos'] = 'Carica Video';
$lang['videoupload_format_msgs'] = 'Solo i file .swf o .flv sono consentiti.';
$lang['video'] = 'Video';
$lang['upload_videos_ext'] = 'flv, swf';
$lang['upload_video_caption'] = 'Carica video';
$lang['video_file'] = 'File Video';
$lang['vds'] = 'Vds';
$lang['manage_videos'] = 'Gestione video';
$lang['videos_loaded'] = 'Video caricati';
$lang['novideos_loaded'] = 'Nessun video';
$lang['loadedvdocnt'] = '#PICSCNT# video';
$lang['loadedvdocnt1'] = '#PICSCNT# video';
$lang['video_gallery'] = 'Galleria video';
$lang['picture_gallery'] = 'galleria Immagini';


/* New timezone display values Modified in 2.0 */
// These are displayed in the timezone select box
$lang['tz']['-25'] = '-- Seleziona --';
$lang['tz']['-12.00'] = '(GMT -12:00) Eniwetok, Kwajalein';
$lang['tz']['-11.00'] = '(GMT -11:00) Midway Island, Samoa';
$lang['tz']['-10.00'] = '(GMT -10:00) Hawaii';
$lang['tz']['-9.00'] = '(GMT -9:00) Alaska';
$lang['tz']['-8.00'] = '(GMT -8:00) Pacific Time (US & Canada)';
$lang['tz']['-7.00'] = '(GMT -7:00) Mountain Time (US & Canada)';
$lang['tz']['-6.00'] = '(GMT -6:00) Central Time (US & Canada), Mexico City';
$lang['tz']['-5.00'] = '(GMT -5:00) Eastern Time (US & Canada), Bogota, Lima';
$lang['tz']['-4.00'] = '(GMT -4:00) Atlantic Time (Canada), Caracas, La Paz';
$lang['tz']['-3.5'] = '(GMT -3:30) Newfoundland';
$lang['tz']['-3.00'] = '(GMT -3:00) Brazil, Buenos Aires, Georgetown';
$lang['tz']['-2.00'] = '(GMT -2:00) Mid-Atlantic';
$lang['tz']['-1.00'] = '(GMT -1:00 ora) Azores, Cape Verde Islands';
$lang['tz']['0.00'] = '(GMT) Western Europe Time, London, Lisbon, Casablanca';
$lang['tz']['1.00'] = '(GMT +1:00 ora) Brussels, Copenhagen, Madrid, Paris';
$lang['tz']['2.00'] = '(GMT +2:00) Kaliningrad, South Africa';
$lang['tz']['3.00'] = '(GMT +3:00) Baghdad, Riyadh, Moscow, St. Petersburg';
$lang['tz']['3.5'] = '(GMT +3:30) Tehran';
$lang['tz']['4'] = '(GMT +4:00) Abu Dhabi, Muscat, Baku, Tbilisi';
$lang['tz']['4.5'] = '(GMT +4:30) Kabul';
$lang['tz']['5.00'] = '(GMT +5:00) Ekaterinburg, Islamabad, Karachi, Tashkent';
$lang['tz']['5.5'] = '(GMT +5:30) Bombay, Calcutta, Madras, New Delhi';
$lang['tz']['6.00'] = '(GMT +6:00) Almaty, Dhaka, Colombo';
$lang['tz']['6.5'] = 'GMT + 6.30) ';
$lang['tz']['7.00'] = '(GMT +7:00) Bangkok, Hanoi, Jakarta';
$lang['tz']['8.00'] = '(GMT +8:00) Beijing, Perth, Singapore, Hong Kong';
$lang['tz']['9'] = '(GMT +9:00) Tokyo, Seoul, Osaka, Sapporo, Yakutsk';
$lang['tz']['9.5'] = '(GMT +9:30) Adelaide, Darwin';
$lang['tz']['10.00'] = '(GMT +10:00) Eastern Australia, Guam, Vladivostok';
$lang['tz']['11.00'] = '(GMT +11:00) Magadan, Solomon Islands, New Caledonia';
$lang['tz']['12.00'] = '(GMT +12:00) Auckland, Wellington, Fiji, Kamchatka';
$lang['tz']['13.00'] = '(GMT + 13)';

$lang['myprofile'] = 'Mio Profilo';
$lang['myblog'] = 'Mio Blob';
$lang['profilesearch'] = 'Ricerca Profilo';
$lang['mylists'] = 'Mie Liste';
$lang['bans'] = 'Interdetti';
$lang['mybuddies'] = 'Miei Amici';
$lang['hotprofiles'] = 'Profili Bollenti';
$lang['winks'] = 'Occhiolini';
$lang['tools'] = 'Strumenti';
$lang['picturegallery'] = 'Mia Galleria Immagini';
$lang['videogallery'] = 'Mia Galleria Video';
$lang['membership'] = 'Mia adesione';
$lang['adminhome'] = 'Home Amministratore';
$lang['membershdr'] = 'Membri';
$lang['memberprofiles'] = 'Profili dei membri';
$lang['membersearch'] = 'Ricerca Membri';
$lang['blogs'] = 'Blog';
$lang['blogsearch'] = 'Ricerca Blog';
$lang['affiliateshdr'] = 'Affiliati';
$lang['localities'] = 'Localit�';
$lang['contenthdr'] = 'Contenuto';
$lang['financial'] = 'Finanza';
$lang['plugins_hlp'] = 'I Plugin amministrativi sono utilizzabili solamente dall\'amministratore e dai moderatori con permessi amministrativi sufficienti, ed appaiono automaticamente nel fondo del menu amministratore a sinistra, quando sono attivati. I Plugin per i membri possono essere acceduti dal pannello membri';

/* HTML and some text emails */
$lang['no_thanks_message']['html'] = 'Ciao #recipient_username#,<br><br>Grazie per il tuo interesse, ma devo rispettosamente declinare. Spero che troverai la tua anima gemella su #site_name#.<br><br>Con i migliori auguri,<br><br>#sender_username#';
$lang['newpic']['html'] ='<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td class="module_head" width="100%" height="25"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25"><div class="module_head">#email_hdr_left#</div>
</td><td width="493" height="25"><div class="module_head">&nbsp;&nbsp;Nuova immagine caricata dall\'utente </div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" ><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="1"></td></tr><tr><td width="50%" valign="top" class="evenrow" >Caro Amministratore del Sito,
<br><br>L\'utente <a href="#SiteUrl#admin/showprofile.php?username=#UserName#">#UserName#</a> ha caricato una nuova immagine. <br><br>Nome utente: #UserName#<br>Immagine Num.: #PicNo#<br><br>#AdminName# <br>SITENAME<br></td><td valign="top" class="evenrow" align="cemter">#smallPic#
</td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['newpic']['text'] = "Caro Amministratore del Sito,

L\'utente #UserName# ha caricato una nuova immagine.

Nome utente: #UserName#
Immagine Num.: #PicNo#

#AdminName#
SITENAME";

$lang['newpic_sub'] = 'Messaggio daSITENAME : Nuova immagine caricata da un utente ';

$lang['newvideo']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25"><div class="module_head">#email_hdr_left#</div>
</td><td width="493" height="25"><div class="module_head">&nbsp;&nbsp;Nuovo video caricato da un utente! </div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" ><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">Caro Amministratore del Sito,<br><br>L\'utente #UserName# ha caricato un nuovo video. <br><br>Nome utente: #UserName#<br>Num Video.: #PicNo#<br><br>#AdminName#<br>SITENAME<br></td>
</tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['newvideo']['text'] = "Caro Amministratore del Sito,

L\'utente #UserName# ha caricato un nuovo video.

Nome utente: #UserName#
Num.Video: #PicNo#

#AdminName#
SITENAME";

$lang['newvideo_sub'] = 'SITENAME Message: New video loaded by user ';


/* old format
$lang['wink_received']['html'] = "Dear #FirstName#,<br><br>You have received a wink from #siteName# user '#SenderName#'.<br><br>Please visit <a href=\"#link#\">#siteName#</a> to send '#SenderName#' a message, or to reciprocate the wink.<br><br>Good Luck!<br>#AdminName#";
$lang['letter_winkreceived_sub'] = '#SITENAME# - You received a wink';

New format below
*/

$lang['mail']['hdr_text'] = '<font style="color:red; font-size: 9px;">Per smettere di ricevere questo tipo di e-mail, <a href="#SiteUrlLogin#">accedi</a> e modifica le tue preferenze dal menu utente.<br>Per assicurarti di ricevere queste e-mail, aggiungi <a href="mailto:#AdminEmail#">#AdminEmail#</a> alla tua rubrica ora.</font><br><br>';
$lang['mail']['hdr_html'] = '<table border=0 cellspacing=0 cellpadding=5 width="570"><tr><td ><font style="color:red; font-size: 9px;">Per smettere di ricevere questo tipo di e-mail, <a href="#SiteUrlLogin#">accedi</a> e modifica le tue preferenze e-mail dal menu utente.<br>per assicurarti di ricevere queste mail, aggiungi <a href="mailto:#AdminEmail#">#AdminEmail#</a> alla tua rubrica ora.</font></td></tr><tr><td height="6"></td></tr></table>';

$lang['letter_winkreceived_sub'] = 'Messaggio da SITENAME: #SenderName# ti ha fatto l\'occhiolino! ';
$lang['wink_received']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25px">#email_hdr_left#</td><td width="493" height="25" ><div class="module_head">&nbsp;&nbsp;#SenderName# ti ha fatto l\'occhiolino!</div>
</td></tr></table></div></td></tr><tr><td width="570" class="evenrow" colspan="2" ><div class="evenrow" ><table border="0" cellspacing="2" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="50%" valign="top">#smallProfile#</td><td width="50%" valign="top">Tra tutti i membri, #SenderName# ha fatto l\'occhiolino a te! Puoi continuare a flirtare ricambiando l\'occhiolino o inviando una e-mail.<br><br><a href="#SiteUrl#compose.php?recipient=#UserId#">Manda una E-mail #SenderName# adesso</a><br><br><a href="#SiteUrl#sendwinks.php?ref_id=#UserId#&amp;rtnurl=showprofile.php">Ricambia l\'occhiolino</a><br>
<br><b>Non interessato/a?</b><br>Informa #SenderName# del fatto che non sei interessato/a mandando un messaggio "No, grazie" <br><br><a href="#SiteUrl#compose.php?recipient=#UserId#&amp;reply=11">D� "No, grazie"</a><br><br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

/* old format
$lang['profile_confirmation_email']['html'] = "Dear #FirstName#,<br><br>Thank you for registering with #SiteName#! As the newest member of our community, I encourage you to explore our services and features.<br><br>To confirm your profile addition, please click the link below. Or, if the link is not clickable, copy and paste it into address bar of your web browser, to directly access it.<br><br><a href=\"#ConfirmationLink#=#ConfCode#\">#ConfirmationLink#=#ConfCode#</a><br><br>If you still have the final step of the registration wizard open, you can input your confirmation code on that screen.<br><br>Your confirmation code is: #ConfCode#<br><br>We have recorded the following registration information for you:<br><br>Username: #StrID#<br>Password: #Password#<br>E-Mail: #Email#<br><br>Please keep this information in a safe, secure place, so that you will be able to access all of the services and features available to you. Some services may require an upgrade to a higher membership level, which you can do here:<br><br>#SiteUrl#payment.php<br><br>Thanks again for using our services, and we hope that you find your match!<br><br>#AdminName#<br>#SiteName#";

New format below
*/
$lang['profile_confirmation_email_sub'] = 'Messaggio da SITENAME: Grazie per esserti registrato a SITENAME!';
$lang['profile_confirmation_email']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570">
<tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%">
<tr><td width="77" height="25" >#email_hdr_left#</td><td width="493"  height="25"><div class="module_head">&nbsp;&nbsp;#Welcome#!</div></td></tr></table></div></td></tr><tr><td width="570" class="evenrow" colspan="2" >
<div class="evenrow" ><table border=0 cellspacing=0 cellpadding=5 width="100%"><tr><td>Dear #FirstName#,<br><br>Thank you for registering with #siteName#! Come nuovo membro della nostra comunit�, ti incoraggio ad esplorare i nostri servizi e le nostre caratteristiche.<br><br>Per confermare l\'aggiunta del tuo profilo, clicca sul link sotto. Oppure, se il link non � cliccabile, copialo ed incollalo nella barra indirizzo del tuo web browser, per accedervi direttamente.<br><br>
<a href=\"#ConfirmationLink#=#ConfCode#\">#ConfirmationLink#=#ConfCode#</a><br><br>Se hai ancora aperto l\'ultimo passo della procedura di registrazione, puoi copiare il codice di conferma in quella schermata.<br><br>Il tuo codice di conferma �: <b>#ConfCode#</b><br><br>Abbiamo annotato le seguenti informazioni per te:<br>
<br>Nome utente: <b>#StrID#</b><br>Password: <b>#Password#</b><br>E-Mail: <b>#Email#</b><br><br>Per favore tieni queste informazioni in un luogo sicuro, cos� che sarai in grado di accedere a tutti i servizi e le caratteristiche disponibili per te. Alcuni servizi possono riciedere un livello di adesione pi� alto, che puoi ottenere qui:<br><br><a href="#SiteUrl#payment.php">#Upgrade#</a><br><br>Grazie ancora per utilizzare i nostri servizi, speriamo che trovi la tua anima gemella! <br><br>
#AdminName#<br>#siteName#</td></tr></table></div></td></tr>
<tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

/* old format
$lang['message_received']['text'] = "Dear #FirstName#,

You have received a message from SITENAME user '#SenderName#'.

Please visit <a href=\"#link#\">SITENAME</a> to reply to this message.

Good Luck!
#AdminName#";

$lang['message_received']['html'] = "Dear #FirstName#,<br><br>You have received a message from #siteName# user '#SenderName#'.<br><br>Please visit <a href=\"#link#\">#siteName#</a> to reply to this message.<br><br>Good Luck!<br>#AdminName#";

New format below
*/
$lang['message_received_sub'] = 'Messaggio da SITENAME: Hai un nuovo messaggio';
$lang['message_received']['text'] = "Caro/a #FirstName#,

Hai ricevuto un messaggio dall\'utente '#SenderName#' del sito SITENAME.

Per favore visita <a href=\"#link#\">SITENAME</a> per rispondere a questo messaggio.

Buona fortuna!
#AdminName#
SITENAME";

$lang['message_received']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25"><div class="module_head">
#email_hdr_left#</div></td><td width="493" ><div class="module_head">&nbsp;&nbsp;Nuovo messaggio da #SenderName#! </div></td></tr></table></div></td></tr><tr><td width="570" class="evenrow" colspan="2" ><div class="evenrow" ><table border="0" cellspacing="2" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="50%" valign="top" class="evenrow">
<table width="100%" border=0 cellspacing=0 cellpadding=0><tr><td width="25%" ><div class="newshead">#From#:</div></td><td width="75%">#SenderName#</td></tr><tr><td><div class="newshead">#TO#:</div></td><td>#UserName#</td></tr><tr><td  >
<div class="newshead">#Date#:</div></td><td>#MESSAGE_DATE# </td></tr><tr><td ><div class="newshead">#Subject#:</div></td><td>#MSG_SUBJECT#</td></tr><tr><td colspan="2" height="6">
</td></tr><tr><td colspan=2>Caro/a #FirstName#,<br><br>Hai ricevuto un messaggio da #SenderName#.<br><br>Per favore, visita <a href=\"#link#\">SITENAME</a> per rispondere a questo messaggio. <br><br>Buona fortuna!<br>#AdminName#<br>SITENAME<br></td></tr></table>
</td><td width="50%" valign="top" class="oddrow"><div class="oddrow">#smallProfile#</div></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

/* Old format
$lang['letter_featuredprofile_sub'] = '#SITENAME# - Featured Profiles List';
$lang['featured_profile_added']['html'] = "Dear #FirstName#,<br><br>It gives us great pleasure to include your profile in the Featured Profiles List on <a href=\"#link#\">#siteName#</a>.<br><br>Your profile will be featured from #FromDate# to #UptoDate#.<br><br>This will increase your profile visibility and may result in many more views from prospective matches.<br><br>Good Luck!<br>#AdminName#";

new format
*/
$lang['letter_featuredprofile_sub'] = 'Messaggio SITENAME: Il tuo profilo sar� presto incluso tra i profili caratteristici';
$lang['featured_profile_added']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr>
<td width="77" height="25" ><div class="module_head">#email_hdr_left#</div>
</td><td width="493" ><div class="module_head">&nbsp;&nbsp;Il tuo profilo sar� presto incluso tra i profili caratteristici </div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" >
<div class="evenrow"><table border="0" cellspacing="0" cellpadding="5"><tr><td width="100%" valign="top" class="evenrow">Dear #FirstName#,<br><br>
Ci d� grande piacere includere il tuo profilo nella lista dei profili caratteristici su <a href=\"#link#\">SITENAME</a>.<br><br>Il tuo profilo sar� tra quelli caratteristici da <b>#FromDate#</b> a <b>#UptoDate#</b>.<br>
<br>Questo accrescer� la visibilit� del tuo profilo potrebbero esserci molti pi� sguardi da potenziali anime gemelle.<br><br>Buona fortuna!<br>#AdminName# <br>SITENAME<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

/* old format

$lang['profile_activated_sub'] = '#SITENAME# - Your profile is activated';
$lang['profile_activated']['html'] = "Dear #FirstName#,<br><br>This is an automatic notification to inform you that your profile on #siteName# has been activated with the membership level of #MembershipLevel#. Come visit us soon at <a href=\"#link#\">#siteName#</a>.<br><br>Good Luck!<br>#AdminName#";

new format */

$lang['profile_activated_sub'] = 'Messaggio da SITENAME: Il tuo profilo � stato attivato!';
$lang['profile_activated']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" ><div class="module_head">
#email_hdr_left#</div></td><td width="493"><div class="module_head">&nbsp;&nbsp;Il tuo profilo � stato attivato!</div></td></tr></table></div></td></tr><tr>
<td width="100%" class="evenrow" colspan="2"><div class="evenrow"><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr>
<tr><td width="100%" valign="top" class="evenrow">Caro/a #FirstName#,<br><br>Ti diamo con piacere il benvenuto in SITENAME. <br><br>Il tuo profilo � stato attivato con il livello adesione di <b>#MembershipLevel#</b> valido fino a #ValidDate#.<br><br>Torna presto a visitarci a <a href=\"#link#\">SITENAME</a>.<br>
<br>Good Luck!<br>#AdminName# <br>SITENAME<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';
$lang['profile_activated']['text'] = "Caro/a #FirstName#,

Ti diamo con piacere il benvenuto in SITENAME.

Il tuo profilo � stato attivato con il livello di adesione di <b>#MembershipLevel#</b> valido fino a <b>#ValidDate#</b>.

Torna a visitarci presto a <a href=\"#link#\">SITENAME</a>.

Buona fortuna!
#AdminName#
SITENAME";

/* old format
$lang['profile_reactivated_sub'] = '#SITENAME# - Your profile is reactivated';
$lang['profile_reactivated']['html'] = "Dear #FirstName#,<br><br>This is an automatic notification to inform you that your profile on #siteName# has been reactivated with the membership level of #MembershipLevel#. Come visit us soon at <a href=\"#link#\">#siteName#</a>.<br><br>Good Luck!<br>#AdminName#";

New format
*/
$lang['profile_reactivated_sub'] = 'Messaggio da SITENAME: Il tuo profilo � stato riattivato!';
$lang['profile_reactivated']['text'] = "Caro/a #FirstName#,

Siamo felici di informarti che il tuo profilo � stato riattivato con il livello di adesione di <b>#MembershipLevel#</b> che scadr� il <b>#ValidDate#</b>.

Torna a visitarci presto a <a href=\"#link#\">SITENAME</a>.

Buona fortuna!
#AdminName#
SITENAME";

$lang['profile_reactivated']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head">
<div class="module_head">#email_hdr_left#</div></td><td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;Il tuo profilo � stato riattivato! </div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2">
<div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">Caro/a #FirstName#,<br><br>Siamo felici di informarti che il tuo profilo � stato riattivato con il livello di adesione di <b>#MembershipLevel#</b> che scadr� il <b>#ValidDate#</b>.<br>
<br>Torna a visitarci presto a <a href=\"#link#\">SITENAME</a>.<br><br>Buona fortuna!<br>#AdminName# <br>SITENAME<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

/* old format
$lang['added_banlist_sub'] = '#SITENAME# - Information message';
$lang['added_buddylist_sub'] = '#SITENAME# - Information message';
$lang['added_hotlist_sub'] = '#SITENAME# - Information message';

$lang['added_buddylist']['html'] = "Dear #FirstName#,<br><br>You have been added to #SenderName#'s Buddy List.<br><br>To view this user's profile, please visit <a href=\"#link#\">#siteName#</a>.<br><br>Good Luck!<br>#AdminName#";

$lang['added_hotlist']['html'] = "Dear #FirstName#,<br><br>You have been added to #SenderName#'s Hot List.<br><br>To view this user's profile, please visit <a href=\"#link#\">#siteName#</a>.<br><br>Good Luck!<br>#AdminName#";

$lang['added_banlist']['html'] = "Dear #FirstName#,<br><br>You have been added to #SenderName#'s Ban List.<br><br>To view this user's profile, please visit <a href=\"#link#\">#siteName#</a>.<br><br>#AdminName#";

$lang['added_buddylist']['text'] = "Dear #FirstName#,

You have been added to #SenderName#'s Buddy List.

To view this user's profile, please visit <a href=\"#link#\">#siteName#</a>.

Good Luck!
#AdminName#
SITENAME";

$lang['added_hotlist']['text'] = "Dear #FirstName#,

You have been added to #SenderName#'s Hot List.

To view this user's profile, please visit <a href=\"#link#\">#siteName#</a>.

Good Luck!
#AdminName#
SITENAME";

$lang['added_banlist']['text'] = "Dear #FirstName#,

You have been added to #SenderName#'s Ban List.

To view this user's profile, please visit <a href=\"#link#\">#siteName#</a>.

#AdminName#";

New format
*/
$lang['added_list_sub'] = "Messaggio da SITENAME: Sei stato aggiunto a #ListName# di #SenderName#!" ;
$lang['added_list']['text'] = "Caro/a #FirstName#,

Il membro #SenderName# ti ha aggiunto a #ListName#.

Per vedere il profilo dell\'utente, visita <a href=\"#link#\">SITENAME</a>.

Buona fortuna!
#AdminName#
SITENAME";
$lang['added_list']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25px" class="module_head">
<div class="module_head">#email_hdr_left#</div></td><td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;Sei stato aggiunto a #ListName# di #SenderName#!</div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" >
<div class="evenrow"><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="50%" valign="top" class="evenrow">Caro/a #FirstName#,<br><br>Il membro <b>#SenderName#</b> ti ha aggiunto a <b>#ListName#</b>.<br><br>Per vedere il profilo dell\'utente, visita <a href=\"#link#\">SITENAME</a>.<br><br>Buona fortuna!<br>#AdminName# <br>SITENAME<br></td><td valign="top">#smallProfile#</td>
</tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

/* old format
$lang['invite_a_friend_sub'] = 'Invite a Friend';
$lang['invite_a_friend']['html'] = "Hi,<br><br>I found a cool dating site while surfing the web: #Link#.<br>I thought it might be interesting to you.<br><br>#FromName#";

New format
*/
$lang['invite_a_friend_sub'] = "SITENAME Message: Invitation from #FromName#! ";
$lang['invite_a_friend']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="27" class="module_head" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" valign="top" ><div class="module_head" >#email_hdr_left#</div>
</td>
<td width="493" ><div class="module_head" >&nbsp;&nbsp;Invito da #FromName#!</div></td></tr></table></div></td></tr><tr><td width="100%" colspan="2" ><div class="evenrow"><table border="0" cellspacing="0" cellpadding="5" width="100%"><tr><td height="1"></td></tr><tr><td width="100%" valign="top" class="evenrow">Ciao,<br><br>Ho trovato un bel sito di appuntamenti navigando il web: <a href=\"#SiteUrl#\"><b>SITENAME</b></a><br>Penso che possa essere interesante per te.<br>
<br>Visita <a href=\"#SiteUrl#\">SITENAME</a>.<br><br>Buona fortuna!<br>#FromName# <br><br></td></tr></table></div>
</td></tr><tr><td height="6" class="evenrow" colspan="2" ></td></tr></table>';

/* old format
$lang['message_read_sub'] = '#SITENAME# - Information message';
$lang['message_read']['html'] = "Dear #FirstName#,<br><br>The message you sent to '#RecipientName#' has been read.<br><br>Good Luck!<br>#AdminName#";

New format */
$lang['message_read_sub'] = 'Messaggio da SITENAME: Il tuo messaggio a #RecipientName# � stato letto!';
$lang['message_read']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25">
<div class="module_head">#email_hdr_left#</div></td><td width="493" ><div class="module_head">&nbsp;&nbsp;Il tuo messaggio a #RecipientName# � stato letto! </div></td></tr></table></div></td></tr>
<tr><td width="100%" class="evenrow" colspan="2" >
<div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="50%" valign="top" class="evenrow">Caro/a #FirstName#,<br><br>Il messaggio che hai inviato a <b>#RecipientName#</b> � stato letto.<br><br>Per vedere il profilo di questo utente, per favore visita <a href=\"#link#\">SITENAME</a>.<br><br>Buona fortuna!<br>#AdminName# <br>SITENAME<br></td>
<td valign="top">#smallProfile#</td></tr></table>
</div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

/* old format
$lang['email_feedback_subject'] = 'Feedback from user of '.SITENAME;
$lang['feedback_email_to_admin']['text'] = 'Dear Site Administrator,

You have just received comments from a visitor to your dating site. The details are as follows:

Title: #txttitle#
Name: #txtname#
Email: #txtemail#
Country: #txtcountry#
Comments: #txtcomments#

Thanks,
#SITENAME# Daemon';

$lang['feedback_email_to_admin']['html'] = 'Dear Site Administrator,<br><br>You have just received comments from a visitor to your dating site. The details are as follows:<br><br>Title: #txttitle#<br>Name: #txtname#<br>Email: #txtemail#<br>Country: #txtcountry#<br>Comments: #txtcomments#<br><br>Thanks,<br>#SITENAME# Daemon';

New format */
$lang['email_feedback_subject'] = 'Messaggio da SITENAME: Feedback da un utente ';
$lang['feedback_email_to_admin']['text'] = 'Caro Amministratore del Sito,

	hai appena ricevuto un commento da un visitatore del tuo sito. I dettagli sono di seguito:

Titolo: #txttitle#
Nome: #txtname#
E-mail: #txtemail#
Nazione: #txtcountry#
Commenti: #txtcomments#

Grazie,
Demone di #siteName#';
$lang['feedback_email_to_admin']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25"><div class="module_head">
#email_hdr_left#</div></td><td width="493"><div class="module_head">&nbsp;&nbsp;Feedback da un utente  <div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" ><div class="evenrow" >
<table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr>
<tr><td width="100%" valign="top" class="evenrow">Caro Amministratore del Sito,<br><br>hai appena ricevuto un commento da un visitatore del tuo sito. I dettagli sono di seguito:<br><br><table cellspacing="4" cellpadding="2" border="0" width="100%"><tr><td width="20%"> Titolo:</td><td width="80%">#txttitle# </td></tr><tr><td>Nome:</td> <td>#txtname#</td></tr>
<tr><td>E-mail:</td><td>#txtemail#</td></tr><tr><td>Nazione:</td><td>#txtcountry#</td></tr><tr><td>Commenti:</td><td>#txtcomments#</td></tr></table><br>Grazie,<br>Demone di #siteName#<br><br></td></tr></table></div></td></tr></table> ';

/* old format
$lang['forgot_password_sub'] = 'Password Request';
$lang['forgot_password']['text'] = "Dear #Name#,

Your member ID: #ID#
Your password:  #Password#

To login, go here: #LoginLink#.

Thank you for using our services!

#SiteTitle# mail delivery system
<Auto-generated e-mail, please do not reply>";
$lang['forgot_password']['html'] = "Dear #Name#,<br><br>Your member ID: #ID#<br>Your password: #Password#<br><br>To login, go here: #LoginLink#.<br><br>Thank you for using our services!<br><br>#SiteTitle# mail delivery system<br><Auto-generated e-mail, please do not reply>";



New format */
$lang['forgot_password_sub'] = 'Messaggio da SITENAME: La tua richiesta di reset della password';
$lang['forgot_password']['text'] = "Caro/a #Name#,

  questo messaggio ti � stato inviato a seguito della tua richiesta di reset della password del tuo account.

Il tuo ID membro: #ID#
La tua nuova password:  #Password#

Per accedere, vai qui: #LoginLink#.

Grazie per utilizzare i nostri servizi!

#AdminName#
SITENAME";
$lang['forgot_password']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head"><div class="module_head">#email_hdr_left#</div></td>
<td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;La tua richiesta di reset della password</div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" ><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">Dear #Name#,<br>
<br>questo messaggio ti � stato inviato a seguito della tua richiesta di reset della password del tuo account.<br><br>Il tuo ID membro: <b>#ID#</b><br>La tua nuova password: <b>#Password#</b><br><br>Per accedere, vai qui: <a href=\"#LoginLink#\">SITENAME</a>.<br><br>Grazie per utilizzare i nostri servizi!<br><br>#AdminName#<br>SITENAME<br></td></tr> </table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

/* old format
$lang['expiry_ltr_sub'] = 'Reminder of Membership Expiry';
$lang['mship_expired_note']['text'] = "Dear #FirstName#,

This is an automatic notification to inform you that your Membership level of #MembershipLevel# in #siteName# expired on #ExpiryDate#.

Please <a href=\"#link#\">login to  #siteName#</a> to renew your membership and continue to enjoy our services.

Good Luck!
#AdminName#";
$lang['mship_expired_note']['html'] = "Dear #FirstName#,<br><br>This is an automatic notification to inform you that your Membership level of #MembershipLevel# in #siteName# expired on #ExpiryDate#.<br><br>Please <a href=\"#link#\">login to  #siteName#</a> to renew your membership and continue to enjoy our services.<br><br>Good Luck!<br>#AdminName#";

New format */
$lang['expiry_ltr_sub'] = 'Messaggio da SITENAME: Promemoria della scadenza dell\'adesione';

$lang['mship_expired_note']['text'] = "Caro/a #FirstName#,

Grazie per utilizzare SITENAME!

Questo messaggio per informarti che il tuo livello di adesione di #MembershipLevel# in SITENAME � scaduto il #ExpiryDate#.

Per favore <a href=\"#link#\">accedi a SITENAME</a> per rinnovare la tua adesione e continuare a beneficiare dei nostri servizi.

Buona fortuna!
#AdminName#
SITENAME";

$lang['mship_expired_note']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head"><div class="module_head">#email_hdr_left#</div></td>
<td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;La tua adesione � scaduta! </div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" ><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">Caro/a #FirstName#,<br>
<br>Grazie per utilizzare SITENAME!!<br><br>Questo messaggio per informarti che il tuo livello di adesione di <b>#MembershipLevel#</b> in <a href="\"#link#\"><b>SITENAME</b></a> � scaduto il <b>#ExpiryDate#</b>.<br><br>Per favore <a href=\"#link#\">accedi a SITENAME</a> per rinnovare la tua adesione e continuare a beneficiare dei nostri servizi.<br><br>Buona fortuna!<br>#AdminName# <br>SITENAME<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

/* old format
$lang['mship_expiry_note']['text'] = 'Dear #FirstName#,

This is an automatic notification to inform you that your Membership with #siteName# will expire on #ExpiryDate#.

Please <a href="#link#">log in to #siteName#</a> and renew your membership.

Good Luck!
#AdminName#';

$lang['mship_expiry_note']['html'] = 'Dear #FirstName#,<br><br>This is an automatic notification to inform you that your Membership with #siteName# will expire on #ExpiryDate#.<br><br>Please <a href="#link#">log in to #siteName#</a> and renew your membership.<br><br>Good Luck!<br>#AdminName#';


New format */
$lang['mship_expiry_note']['text'] = 'Caro/a #FirstName#,

Grazie per utilizzare SITENAME!

Questo messaggio per informarti che il tuo livello di adesione di #MembershipLevel# in SITENAME scadr� il #ExpiryDate#.

Per favore <a href=\"#link#\">accedi a SITENAME</a> per rinnovare la tua adesione e continuare a beneficiare dei nostri servizi.

Buona fortuna!
#AdminName#
SITENAME';

$lang['mship_expiry_note']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border="0" cellspacing="0" cellpadding="0" width="100%"><tr><td width="77" height="25" class="module_head"><div class="module_head">#email_hdr_left#</div></td><td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;Your membership will expire soon! </div></td></tr></table></div></td></tr>
<tr><td width="100%" class="evenrow" colspan="2" ><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">Caro/a #FirstName#,<br><br>Grazie per utilizzare SITENAME!<br><br>Questo messaggio per informarti che il tuo livello di adesione di <b>#MembershipLevel#</b> in <a href="\"#link#\"><b>SITENAME</b></a> scadr� il <b>#ExpiryDate#</b>.<br><br>Per favore <a href=\"#link#\">accedi a SITENAME</a> per rinnovare la tua adesione e continuare a beneficiare dei nostri servizi.<br>
<br>Buona fortuna!<br>#AdminName# <br>SITENAME<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

/* Newly added - mail to be sent to member when admin changes membership level */

$lang['profile_membership_changed_sub'] = 'Messaggio da SITENAME: Il tuo livello di adesione � cambiato!';
$lang['profile_membership_changed']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head">
<div class="module_head">#email_hdr_left#</div></td><td width="493" class="module_head" height="25"><div class="module_head">&nbsp;&nbsp;Il tuo livello di adesione � cambiato! </div></td></tr></table></div></td></tr>
<tr><td width="100%" class="evenrow" colspan="2"><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">Caro/a #FirstName#,<br><br>il tuo livello di adesione corrente <b>#CurrentLevel#</b> � stato cambiato in <b>#NewLevel#</b>, e scadr� il <b>#ValidDate#</b>.<br>
<br>Vieni a visitarci presto a <a href=\"#link#\">SITENAME</a>.<br><br>Buona fortuna!<br>#AdminName# <br>SITENAME<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['profile_membership_changed']['text'] = 'Caro/a #FirstName#,

il tuo livello di adesione corrente <b>#CurrentLevel#</b> � stato cambiato in <b>#NewLevel#</b>, e scadr� il <b>#ValidDate#</b>.

Vieni a visitarci presto a <a href=\"#link#\">SITENAME</a>.

Buona fortuna!
#AdminName#
SITENAME';

$lang['comment_received_sub'] = 'Messaggio da SITENAME: Un utente ha aggiunto un commento al tuo Blog!';
$lang['comment_received']['text'] = "Caro/a #FirstName#,

Hai ricevuto un commento dall\'utente '<b>#SenderName#</b>' di SITENAME.

Visita <a href=\"#link#\"><b>SITENAME</b></a> per vedere il commento da '<b>#SenderName#</b>'.

Buona fortuna!
#AdminName#
SITENAME";

$lang['comment_received']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head"><div class="module_head">#email_hdr_left#</div></td><td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;Un utente ha aggiunto un commento al tuo Blog! </div></td></tr></table></div></td></tr>
<tr><td width="100%" class="evenrow" colspan="2"><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">Caro/a #FirstName#,<br><br>Hai ricevuto un commento dall\'utente <b>#SenderName#</b> di SITENAME.<br><br>Visita <a href=\"#link#\"><b>SITENAME</b></a> per vedere il commento da <b>#SenderName#</b>.<br>
<br>Buona fortuna!<br>#AdminName# <br>SITENAME<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';
$lang['aff_added_sub'] = 'Messaggio da SITENAME: Sei stato aggiunto come affiliato!';
$lang['aff_added']['text'] = "Caro/a #Name#,

Siamo felici di informarti che sei stato aggiunto come affiliato di SITENAME.

Il tuo ID: #Affid#
La tua Password: #Password#

Per favore visita <a href=\"#SiteUrl#\"><b>SITENAME</b></a>, entra nella sezione affiliati e cambia la tua password il pi� presto possibile.

Buona fortuna!
#AdminName#
SITENAME";

$lang['aff_added']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head"><div class="module_head">#email_hdr_left#</div></td><td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;Sei stato aggiunto come affiliato! </div></td></tr></table></div></td></tr>
<tr><td width="100%" class="evenrow" colspan="2"><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">Caro/a #Name#,<br><br>Siamo felici di informarti che sei stato aggiunto come affiliato di SITENAME.<br><br><b>Il tuo ID: #Affid#</b><br><b>La tua Password: #Password#</b><br><br>Per favore visita <a href=\"#SiteUrl#\"><b>SITENAME</b></a>, entra nella sezione affiliati e cambia la tua password il pi� presto possibile.<br><br>Buona fortuna!<br>#AdminName# <br>SITENAME<br></td>
</tr></table></div>
</td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['aff_newpwd_sub'] = 'Messaggio da SITENAME: Il tuo account di affiliato!';
$lang['aff_newpwd']['text'] = "Caro/a #Name#,

Una nuova password � stata generata per il tuo account di affiliato a SITENAME su tua richiesta.

La tua nuova Password: #Password#

Per favore visita <a href=\"#SiteUrl#\"><b>SITENAME</b></a>, entra nella sezione affiliati e cambia la tua password il pi� presto possibile.

Buona fortuna!
#AdminName#
SITENAME";

$lang['aff_newpwd']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head"><div class="module_head">#email_hdr_left#</div></td>
<td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;Il tuo account di affiliato! </div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2"><div class="evenrow"><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">Caro/a #Name#,<br><br>Una nuova password � stata generata per il tuo account di affiliato a SITENAME su tua richiesta.<br>
<br><b>La tua nuova Password: #Password#</b><br><br>Per favore visita <a href=\"#SiteUrl#\"><b>SITENAME</b></a>, entra nella sezione affiliati e cambia la tua password il pi� presto possibile.<br><br>Buona fortuna!<br>#AdminName# <br>SITENAME<br></td></tr></table></div>
</td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['add_affiliate'] = 'Aggiungi un affiliato';
$lang['mod_affiliate'] = 'Modifica un affiliato';
$lang['aff_modified'] = 'L\'informazione sull\'affiliato � stata modificata';

$lang['newuser']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head"><div class="module_head">#email_hdr_left#</div></td>
<td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;Nuovo utente iscritto up!</div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" ><div class="evenrow"><table border="0" cellspacing="0" cellpadding="5"><tr><td width="100%" valign="top" class="evenrow">Caro Amministratore di Sistema,<br><br>Un nuovo utente si � iscritto al sito #siteName#.<br><br>Nome utente: <a href="#SiteUrl#admin/showprofile.php?username=#UserName#">#UserName#</a><br><br>#AdminName# <br>#siteName#<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['newuser']['text'] = "Caro Amministratore di Sistema,

Un nuovo utente si � iscritto al sito #siteName#.

Nome utente: #UserName#

#AdminName#
#siteName#";

$lang['newuser_sub'] = 'Nuovo utente iscritto';

/* Following user options are managed. Please modify only the description and not these keys */

$lang['user_choices'] = array(
	'email_message_received' 	=> "Invia una e-mail quando viene ricevuto un nuovo messaggio.",
	'email_wink_received'		=> "Invia una e-mail quando qualcuno mi fa l\'occhiolino.",
	'email_blog_commented'		=> "Invia una e-mail quando qualcuno aggiunge un commento al mio Blog.",
	'email_mship_expiry'		=> "Invia promemoria della scadenza dell\'adesione.",
	'email_message_read'		=> "Invia una e-mail quando il destinatario di un mio messaggio lo legge.",
	'email_buddy_list'			=> "Invia una e-mail quando qualcuno mi aggiunge alla lista di amici.",
	'email_ban_list'			=> "Invia una e-mail quando qualcuno mi aggiunge alla lista di interdetti.",
	'email_hot_list'			=> "Invia una e-mail quando qualcuno mi aggiunge alla lista dei bollenti.",
	"allow_buddy_view_album"	=> "Consenti agli utenti nella mia lista di amici di vedere i miei album privati.",
	"allow_hotlist_view_album"	=> "Consenti agli utenti nella mia lista di bollenti di vedere i miei album privati.",
	'email_match_mail_days'		=> "Frequenza, in giorni, di invio di e-mail \'mie anime gemelle\'. Inserisci 0 se non vuoi ricevere queste mail.",
	);
$lang['mysettings_updated'] = 'Le impostazioni delle tue preferenze sono state aggiornate.';
$lang['resend_conflink_hdr'] = 'Reinvia la e-mail di conferma';
$lang['resend_conflink_hdr1'] = 'Hai perso o non hai ricevuto la mail di conferma dopo la registrazione? Inserisci la e-mail utilizzata durante la registrazione per ottenere il re-invio della mail.';
$lang['resend_conflink_msg'] = 'La tua mail di conferma � stata reinviata.';
$lang['resend_conflink_msg1'] = 'Prego inserire l\'indirizzo e-mail fornito al momento della registrazione.';
$lang['resend_conflink_err1'] = 'Hai gi� confermato il tuo profilo. Utilizzare l\'opzione <a href="forgotpass.php">password dimenticata</a> per generare una nuova password.';
$lang['about_me'] = 'A proposito di me stesso.';
$lang['about_me_hlp'] = 'Inserisci una breve descrizione di te stesso, che interessi gli altri e aiuti a ottenere pi� responsi.';
$lang['aff_forgot_pass'] = 'Dimanticato la password? Inserisci il tuo indirizzo di e-mail qui per ricevere una nuova password:';
$lang['send_new_password'] = 'Invio nuova password';
$lang['not_a_member'] = 'Non sei membro?';
$lang['login_reminded'] = 'Memorizzazione del tuo nome utente e password.';
$lang['lost_confemail'] = 'Perso la e-mail di conferma?';
$lang['couple_usernames'] = 'Nomi utente di Coppie / Gruppi';
$lang['couple_usernames_hlp'] = 'Una coppia o un gruppo comprende due o pi� individui. Inserire i nomi utente dei membri della coppia o del gruppo nel campo di testo sotto. Per esempio: user_1,user_2,user_3. Questi utenti devono avere gi� i loro profili membro individuali.';
$lang['blog']['del01'] = 'Vuoi veramente cancellare questo commento?';
$lang['blog']['del02'] = 'Vuoi veramente cancellare il selezionato ';
$lang['blog']['del03'] = 'Vuoi veramente disinstallare questo ';
$lang['feat_prof_del_msg'] = 'Vuoi veramente rimuovere questo profilo dalla lista dei profili caratteristici?';
$lang['feat_prof_deleted'] = 'Il profilo selezionato � stato rimosso dalla lista dei profili caratteristici.';

$lang['mymatches_sub'] = 'Messaggio da SITENAME: Mail contenente i profili corrispondenti cercati';
$lang['mymatches_body']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25"><div class="module_head">#email_hdr_left#</div></td><td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;Mail contenente i profili corrispondenti cercati </div></td></tr></table></div></td></tr>
<tr><td width="570" class="evenrow" colspan="2" ><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="1"></td></tr><tr><td class="evenrow">Caro/a #FirstName#,<br><br>Di seguito si trova la lista dei profili corrispondenti ai criteri della tua ricerca.</td></tr>
<tr><td height="1" class="evenrow"> </td></tr><tr><td valign="top" class="evenrow">#matchedProfiles#</td></tr><tr><td class="evenrow" colspan="2">Per favore visita <a href=\"#link#\">SITENAME</a> per vedere questi profili.<br><br>Buona fortuna!<br>#AdminName#<br>SITENAME<br></td></tr></table></div> </td></tr></table>';

$lang['on'] = ' su ';

$lang['use_seo_username'] = 'Utilizzare il nome utente del profilo come parametro nell\'URL?<br /> Abilitare questa opzione dar� agli URL il formato "dominio/nomeutente". Disabilitare questa opzione dar� agli URL del profilo il formato "dominio/id.htm"';
$lang['leave_blank_no_change'] = '(lasciare vuoto per non modificare)';

$lang['adminltr']['html']='<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head"><div class="module_head">#email_hdr_left#</div></td><td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;#Subject#</div></td></tr></table></div></td></tr>
<tr><td width="100%" class="evenrow" colspan="2"><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">#LetterContent#</td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['adminltr']['text'] = '#LetterContent#';

/* Following is the section headers in appropriate languages */

$lang['sections'] = array(
	'1'	=> 	'Informazioni di Base',
	'2'	=>	'Aspetto Fisico',
	'3'	=>	'Vita Professionale',
	'4'	=>	'Stile di Vita',
	'5'	=>	'Interessi'	);

/* Following is for mail encoding */
$lang['mail_text_encoding'] = '7bit';
$lang['mail_html_encoding'] = '7bit';
$lang['mail_html_charset'] = 'ISO-8859-1';
$lang['mail_text_charset'] = 'ISO-8859-1';
$lang['mail_head_charset'] = 'ISO-8859-1';

$lang['split_file_names_hdr'] = 'File che si stanno caricando ora';
$lang['worst1'] = '(peggiore)';
$lang['best1'] = '(migliore)';
$lang['profile_auto_confirmed'] = 'Grazie per essere diventato membro di SITENAME.<br><br>Come gesto speciale, il tuo profilo � stato automaticmente confermato dal sistema.<br><br>Per favore <a href="index.php?page=login">entra</a> per beneficiare dei nostri servizi.<br><br>';
$lang['zipfile'] = 'Directory codici CAP';
$lang['zip_ensure'] = 'Prego carica il file con i codici CAP nella directory /zipcodes/countryname prima di procedere. Grandi file dovrebbero essere divisi in file pi� piccoli usando /admin/split_zipcodes_file.php. <br /><br />Il file dovrebbe contenere CAPCODE, LATITUDINE, LONGITUDINE, CODICESTATO, CODICECONTEA, CODICECITTA (in questo ordine. CODICESTATO, CODICECONTEA and CODICECITTA possono essere omessi ed aggiunti dopo) separati da virgole.<br /><br /><b>Prima di caricare i codici CAP per una nazione, cancellare prima i CAP per quella nazione per evitare di caricare dei dati duplicati.</b><br /><br />Per cancellare i codici CAP per una nazione, seleziona quella nazione e premi Cancella';
$lang['load_zips'] = 'Carica codici CAP';
$lang['zip_loaded'] = 'I codici CAP sono stati caricati da questo file ';
$lang['zip_load_over'] = 'Caricamento dei codici CAP per #COUNTRY# completo.';

$lang['admin_login_title'] = 'Pannello Amministratore SITENAME Administration';
$lang['home_title'] = 'SITENAME Home';
$lang['admin_title_msg'] =  'Pannello Ammin. SITENAME';

//Filter Records
$lang['filter_options'] = array(
	'id' => 'Id',
	'username' => 'Nome utente',
	'city' => 'Citt�',
	'zip' => 'CAP',
	'status' => 'Stato',
	'email'	=> 'E-mail',
	'gender' => 'Genere'
	);
$lang['loginagain'] = 'Esci e ri-accedi per beneficiare del nuovo status di adesione';
$lang['online_users_txt'] = 'membri collegati';

$lang['plugin'] = 'Strumenti Avanzati';

$lang['status_act'] = array(
	'approval' => 'Pendente',
	'active' => 'Attivo',
	'rejected' => 'Rifiutato',
	'suspended' => 'Sospeso',
	/* added in 1.1.0 */
	'cancel' => 'Cancella'
	);

$lang['status_enum'] = array(
	'approval' => 'Pendente',
	'active' => 'Attiva',
	'rejected' => 'Rifiuta',
	'suspended' => 'Sospeso',
	);

$lang['status_disp'] = array(
	'approval' => 'Pendente',
	'active' => 'Attiva',
	'rejected' => 'Rifiutato',
	'suspended' => 'Sospeso',
	/* added in 1.1.0 */
	'cancel' => 'Cancellato'
	);

?>
