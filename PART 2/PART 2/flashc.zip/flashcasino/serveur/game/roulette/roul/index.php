<html>
<head>
<title>European Roulette</title>
</head>

<style>
BODY {overflow: hidden}
</style>

<body marginheight="0" marginwidth="0" leftmargin="0" topmargin="0" bgcolor="#FFFFFF" >
<table cellpadding="0" cellspacing="0" border="0" height="100%" width="100%">
<tr>
<td width="100%">


<OBJECT HEIGHT="100%" WIDTH="100%" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" id="Flash" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000">
<PARAM VALUE="Roulette.swf?ROUNDSTOSHOWBANNER=1&amp;TIMELIMIT=10000000000&GAMESESSION=ROULETTE_9542&amp;REAL=1&amp;HelpURL=&URL_SERVLET=/game/roulette/roul/game.php&amp;URL_REDIRECTOR=/game/roulette/roul/index.php" NAME="movie">
<PARAM VALUE="false" NAME="menu">
<PARAM VALUE="best" NAME="quality">
<PARAM VALUE="true" NAME="devicefont">
<PARAM VALUE="#000000" NAME="bgcolor">
<EMBED PLUGINSPAGE="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" TYPE="application/x-shockwave-flash" HEIGHT=100% WIDTH=100% bgcolor="#000000" devicefont="true" quality="best" menu="false" name="Flash" src="Roulette.swf?ROUNDSTOSHOWBANNER=1&amp;GAMESESSION=ROULETTE_9542&amp;REAL=1&amp;URL_SERVLET=/game/roulette/roul/game.php&amp;URL_REDIRECTOR=/game/roulette/roul/index.php"></EMBED>
</OBJECT>



</td>
</tr>
</table>
</body>
</html>
