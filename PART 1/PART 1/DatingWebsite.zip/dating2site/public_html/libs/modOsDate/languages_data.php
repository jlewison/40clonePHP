<?php

   class languagesData extends Data {

      var $table = LANGUAGES_TABLE;

      var $config = array (
  'table' => LANGUAGES_TABLE,
  'idField' => 'osdate_languages_id',
  'addedMsg' => 'Osdate Languages %s Added',
  'added_err' => 'Can\\\'t Add Osdate Languages',
  'editMsg' => 'Osdate Languages %s Updated',
  'editErr' => 'Can\\\'t Update Osdate Languages',
  'delErr' => 'Can\\\'t Delete Osdate Languages',
  'delMsg' => 'Osdate Languages %s Deleted',
  'blankErr' => 'Osdate Languages Empty',
  'fields' => 
  array (
    'id' => 
    array (
      'name' => 'id',
      'description' => 'Id',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'lang' => 
    array (
      'name' => 'lang',
      'description' => 'Lang',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 30,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'mainkey' => 
    array (
      'name' => 'mainkey',
      'description' => 'Mainkey',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 100,
      'blank_ok' => 1,
      'duplicate_ok' => 1,
    ),
    'subkey' => 
    array (
      'name' => 'subkey',
      'description' => 'Subkey',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 100,
      'blank_ok' => 1,
      'duplicate_ok' => 1,
    ),
    'descr' => 
    array (
      'name' => 'descr',
      'description' => 'Descr',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 65535,
      'blank_ok' => 1,
      'duplicate_ok' => 1,
    ),
  ),
);   

      function languagesData() {
      
         $this->Data($this->config);
      }
   }

?>
