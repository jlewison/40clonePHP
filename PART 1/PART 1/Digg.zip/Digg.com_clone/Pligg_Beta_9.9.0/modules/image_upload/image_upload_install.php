<?php
	$module_info['name'] = 'Image Upload';
	$module_info['desc'] = 'Allows an image (JPG, GIF, PNG, WBMP) to be attached to submission. Requires Extra Fields to be enabled in Admin.';
	$module_info['version'] = 0.4;
	// $module_info['requires'][] = array('thickbox', 0.1);
?>