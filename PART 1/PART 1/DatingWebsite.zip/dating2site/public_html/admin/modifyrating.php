<?php
if ( !defined( 'SMARTY_DIR' ) ) {
	include_once( '../init.php' );
}
include ( 'sessioninc.php' );

define( 'PAGE_ID', 'profile_ratings' );
if ( !checkAdminPermission( PAGE_ID ) ) {
	header( 'location: not_authorize.php' );
	exit;
}

$id = trim( $_POST['txtid'] );

$rating = stripslashes(trim( $_POST['txtrating'] ));

$description = stripslashes(trim( $_POST['txtdescription'] ));

$enabled = trim( $_POST['txtenabled'] );

$err = 0;

if ( $rating == '' or $description == '' ) {
	$err = RATING_BLANK;
}

if ( $err != 0 ) {

	header ( 'location: manageratings.php?edit=' . $_POST['txtid'] . '&errid=' . $err );
	exit;
}

$sqlupd = 'UPDATE ! SET rating = ?, enabled = ?, description = ? WHERE id = ?';

$result = $db->query( $sqlupd, array( RATINGS_TABLE, $rating, $enabled, $description, $id  ) );

header ( 'location: manageratings.php' );
?>