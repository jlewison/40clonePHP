<?php include('restrict.php');
require_once('../Connections/apound.php');
$id = $_GET[id];
$link = mysql_pconnect($hostname_apound,$username_apound,$password_apound);
mysql_select_db($database_apound);
mysql_query("DELETE FROM categorylisting WHERE catlistid='$id'");
header("Location: manage_category.php?upd=Y");?>