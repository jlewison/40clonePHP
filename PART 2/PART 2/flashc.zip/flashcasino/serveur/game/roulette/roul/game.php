<?php

function winlimit( )
{
     $resultb=mysql_query("select * from game_bank where name='ttuz'");
$rowb=mysql_fetch_array($resultb);
$bank = $rowb[1];
$proc = $rowb[2];
$caswin = $bank/100*$proc;
      return $caswin;
}

function cash( $l )
{
    $table_cash = mysql_query("select * from users where login='$l'");
    $row = mysql_fetch_array( $table_cash );
    $cash = $row['cash'];
    return $cash;
}

function rnd1( )
{
    srand( ( double )microtime( ) * time( ) );
    $dig = rand( 0, 36 );
    return $dig;
}

function rnd2( $cell, $dig )
{
    $masvet0 = array( 0, 106 );
    $masvet1 = array( 1, 37, 61, 94, 106, 107, 130, 146, 149, 157, 160, 161 );
    $masvet2 = array( 2, 37, 38, 62, 94, 106, 107, 108, 130, 147, 149, 158, 159, 161 );
    $masvet3 = array( 3, 38, 63, 94, 106, 108, 130, 148, 149, 157, 160, 161 );
    $masvet4 = array( 4, 39, 61, 64, 95, 107, 109, 130, 131, 146, 149, 158, 159, 161 );
    $masvet5 = array( 5, 39, 40, 62, 65, 95, 107, 108, 109, 110, 130, 131, 147, 149, 157, 160, 161 );
    $masvet6 = array( 6, 40, 63, 95, 108, 110, 130, 131, 135, 148, 149, 158, 159, 161 );
    $masvet7 = array( 7, 41, 64, 67, 96, 109, 111, 131, 132, 146, 149, 157, 160, 161 );
    $masvet8 = array( 8, 41, 42, 65, 68, 96, 109, 110, 111, 112, 131, 132, 147, 149, 158, 159, 161 );
    $masvet9 = array( 9, 42, 66, 69, 96, 110, 112, 131, 132, 148, 149, 157, 160, 161 );
    $masvet10 = array( 10, 43, 67, 70, 97, 111, 113, 132, 133, 146, 149, 158, 159, 161 );
    $masvet11 = array( 11, 43, 44, 68, 71, 97, 111, 112, 113, 114, 132, 133, 147, 149, 158, 160, 161 );
    $masvet12 = array( 12, 44, 69, 72, 97, 112, 114, 132, 133, 148, 149, 157, 159, 161 );
    $masvet13 = array( 13, 45, 70, 73, 98, 113, 115, 133, 134, 146, 150, 158, 160, 161 );
    $masvet14 = array( 14, 45, 46, 71, 74, 98, 113, 114, 115, 116, 133, 134, 147, 150, 157, 159, 161 );
    $masvet15 = array( 15, 46, 72, 75, 98, 114, 116, 133, 134, 148, 150, 158, 160, 161 );
    $masvet16 = array( 16, 47, 73, 76, 99, 115, 117, 134, 146, 150, 157, 159, 161 );
    $masvet17 = array( 17, 47, 48, 74, 77, 99, 115, 116, 117, 118, 134, 135, 147, 150, 158, 160, 161 );
    $masvet18 = array( 18, 48, 75, 78, 99, 116, 118, 134, 135, 148, 150, 157, 159, 161 );
    $masvet19 = array( 19, 49, 76, 79, 100, 117, 119, 135, 136, 146, 150, 157, 160, 162 );
    $masvet20 = array( 20, 49, 50, 77, 80, 100, 117, 118, 119, 120, 135, 136, 147, 150, 158, 159, 162 );
    $masvet21 = array( 21, 50, 78, 81, 100, 118, 120, 135, 136, 148, 150, 157, 160, 162 );
    $masvet22 = array( 22, 51, 79, 82, 119, 121, 136, 137, 146, 150, 158, 159, 162 );
    $masvet23 = array( 23, 51, 52, 80, 83, 101, 119, 120, 121, 122, 136, 137, 147, 150, 157, 160, 162 );
    $masvet24 = array( 24, 52, 81, 84, 101, 120, 122, 136, 137, 148, 150, 158, 159, 162 );
    $masvet25 = array( 25, 53, 82, 85, 102, 121, 123, 137, 138, 146, 151, 157, 160, 162 );
    $masvet26 = array( 26, 53, 54, 83, 86, 102, 121, 122, 123, 124, 137, 138, 147, 151, 158, 159, 162 );
    $masvet27 = array( 27, 54, 84, 87, 102, 122, 124, 137, 138, 148, 151, 157, 160, 162 );
    $masvet28 = array( 28, 55, 85, 88, 103, 123, 125, 138, 139, 146, 151, 158, 159, 162 );
    $masvet29 = array( 29, 55, 56, 86, 89, 103, 123, 124, 125, 126, 138, 139, 147, 151, 158, 160, 162 );
    $masvet30 = array( 30, 56, 87, 90, 103, 124, 126, 138, 148, 151, 157, 159, 162 );
    $masvet31 = array( 31, 57, 88, 91, 104, 125, 127, 139, 140, 146, 151, 158, 160, 162 );
    $masvet32 = array( 32, 57, 58, 89, 92, 104, 125, 126, 127, 128, 139, 140, 147, 151, 157, 159, 162 );
    $masvet33 = array( 33, 58, 90, 93, 104, 126, 128, 139, 140, 148, 151, 158, 160, 162 );
    $masvet34 = array( 34, 59, 91, 105, 127, 140, 146, 151, 157, 159, 162 );
    $masvet35 = array( 35, 59, 60, 92, 105, 127, 128, 140, 147, 151, 158, 160, 162 );
    $masvet36 = array( 36, 60, 93, 105, 128, 140, 148, 151, 157, 159, 162 );
    $mas = ${ "masvet".$dig };
    $aa = in_array( $cell, $mas );
    return $aa;
}

error_reporting( 0 );
unset( $l );
session_start( );
session_register( $l );
if ( !isset( $l ) )
{
    header( "Location: ../../login.php" );
    exit( );

}


$date = date( "d.m.y" );
$time = date( "H:i:s" );
include( "../../../setup.php" );
$data_array = explode( "|", $BET );
$casbank = winlimit( );
$ams = 0;
while ( $ams < 10000 )
{
    $dig = rnd1( );
    $allbet = 0;
    $win = 0;
    $win2 = 0;
    $k = 0;
    for ( ; $k <= 162; ++$k )
    {
        if ( !( 0 < $data_array[$k] ) && !( $data_array[$k] != " " ) )
        {
            continue;
        }
        $allbet += $data_array[$k];
        $aa = rnd2( $k, $dig );
        if ( !( $aa == true ) )
        {
            continue;
        }
        if ( $k <= 36 && 0 <= $k )
        {
            $win = $win + $data_array[$k] * 33 + $data_array[$k];
            $win2 += $data_array[$k] * 34;
        }
        if ( 37 <= $k && $k <= 93 )
        {
            $win = $win + $data_array[$k] * 15 + $data_array[$k];
            $win2 += $data_array[$k] * 16;
        }
        if ( 94 <= $k && $k <= 105 )
        {
            $win = $win + $data_array[$k] * 9 + $data_array[$k];
            $win2 += $data_array[$k] * 10;
        }
        if ( 106 <= $k && $k <= 128 )
        {
            $win = $win + $data_array[$k] * 6 + $data_array[$k];
            $win2 += $data_array[$k] * 7;
        }
        if ( 130 <= $k && $k <= 140 )
        {
            $win = $win + $data_array[$k] * 3 + $data_array[$k];
            $win2 += $data_array[$k] * 4;
        }
        if ( 146 <= $k && $k <= 151 )
        {
            $win = $win + $data_array[$k] * 0 + $data_array[$k];
            $win2 += $data_array[$k] * 1;
        }
        if ( !( 157 <= $k ) && !( $k <= 162 ) )
        {
            continue;
        }
        $win = $win + $data_array[$k] * 2 + $data_array[$k];
        $win2 += $data_array[$k] * 2;
    }
    $prib = $win - $allbet;
    $prib_bet = $casbank + $allbet;
    ++$ams;
    if ( $prib_bet < $prib )
    {
        $ams = 12;
    }

if ( !( $prib < $prib_bet ) )
    {
        continue;
    }
    $ams = 12000;
}
mysql_query( "update users set cash=cash-'".$allbet."' where login='{$l}'" );



if ( $l != "demo" ) {
mysql_query( "update game_bank set bank=bank+'".$allbet."' where name='ttuz'" );

}
mysql_query( "update users set cash=cash+'".$win2."' where login='{$l}'" );

if ( $l != "demo" ) {
mysql_query( "update game_bank set bank=bank-'".$win2."' where name='ttuz'" );

}
if ( 0 < $allbet )
{
    $cash = cash( $l );
    mysql_query( "INSERT INTO stat_game VALUES('NULL','".$date."','{$time}','{$l}','{$cash}','{$allbet}','{$win2}','Roulette')" );
}
$cash = cash( $l );
echo "&masvet_id=1012&JACKPOT=0.00&PAYOUT=".$win."&NUMBER={$dig}&RESULT=OK&BALANCE={$cash}&";
?>
