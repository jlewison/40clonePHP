<?php
$LANG['registration_email_subject'] = 'Thanks for registering with {sitename}!';
$LANG['registration_email_content'] = 'Dear {username} ,

Thanks for registering with {sitename}. Your Login username is: {username}
and your password is: {password}

Regards,

The {sitename} team';
/**
 * @var string Registration Activatation Code Subject
 * @cfg_label Registration Activatation Code Subject -- {site_name}
 * @cfg_key activation_subject
 */
$LANG['activation_subject'] = '{site_name} - Your activation code';
/**
 * @var string Registration Activatation Code Content
 * @cfg_label Registration Activatation Code Content -- {user_name}{activation_link}{link}{site_name}
 * @cfg_key activation_message
 */
$LANG['activation_message'] = 'Dear {user_name},

Your activation code. Please click the following link to activate:
{activation_link}

To learn more, please visit {link}

Regards,
{site_name}';
/**
 * @var string Admin Activatation Code Subject
 * @cfg_label Admin Activatation Code Subject -- {site_name}
 * @cfg_key admin_activation_subject
 */
$LANG['admin_activation_subject'] = '{sitename} - Your account has beed activated';
/**
 * @var string Admin Activatation Code Content
 * @cfg_label Admin Activatation Code Content -- {user_name}{activation_link}{link}{site_name}
 * @cfg_key admin_activation_message
 */
$LANG['admin_activation_message'] = 'Dear {username},

Your account has been activated.

Please check the site {link}

Regards,
{sitename}';
/**
 * @var string ChangeEmail Activatation Code Subject
 * @cfg_label ChangeEmail Activatation Code Subject -- {site_name}
 * @cfg_key mailactivation_subject
 */
$LANG['mailactivation_subject'] = '{site_name} - Your email activation code';
/**
 * @var string ChangeEmail Activatation Code Content
 * @cfg_label ChangeEmail Activatation Code Content -- {user_name}{activation_link}{link}{site_name}
 * @cfg_key mailactivation_message
 */
$LANG['mailactivation_message'] = 'Dear {user_name},

Your email activation code. Please click the following link to activate your new email id:
{activation_link}

To learn more, please visit {link}

Regards,
{site_name}';
/**
 * @var string AdminChangeEmail Subject
 * @cfg_label AdminChangeEmail Subject -- {site_name}
 * @cfg_key admin_changemail_subject
 */
$LANG['admin_changemail_subject'] = '{sitename} - Your email has been changed';
/**
 * @var string AdminChangeEmail Content
 * @cfg_label AdminChangeEmail Content -- {user_name}{link}{site_name}
 * @cfg_key admin_mailchange_message
 */
$LANG['admin_mailchange_message'] = 'Dear {username},

Your email in {sitename} has been changed as
{email}

To learn more, please visit {link}

Regards,
{sitename}';

/**
 * @var string send question to friend
 * @cfg_label Subject -- {question}
 * @cfg_key send_question_to_friend_subject
 * @cfg_sub_head Email this Question
 */
$LANG['send_question_to_friend_subject'] = '{question}';
/**
 * @var string send quesion to friend
 * @cfg_label Body -- {username}, {sender name}, {question}, {sitename}, {question description}
 * @cfg_key send_question_to_friend_content
 */
$LANG['send_question_to_friend_content'] = 'Hi {username},

Your friend, {sender name}, asked us to let you know about the question {question} asked online at {sitename}.

Description of the Question
----------------------------------------------------------------------
{question description}

Regards,
The {sitename} team';
/**
 * @var string send answer reply mail subject
 * @cfg_label Subject -- {username}, {sender name}
 * @cfg_key answers_reply_email_subject
 * @cfg_sub_head Reply posted for question asked
 */
$LANG['answers_reply_email_subject'] = 'Dear {username} - {sender name} has replied your question';
/**
 * @var string send answer reply mail body
 * @cfg_label Body -- {username}, {sitename}, {sender name}, {question asked}, {question reply}, {link}
 * @cfg_key answers_reply_email_content
 */
$LANG['answers_reply_email_content'] = 'Dear {username},

{sitename} member, {sender name}, replied for your question
{question asked}

Reply from {sender name}
{question reply}

Use the below link to view the question
{link}

Regards,
The {sitename} team';
/**
 * @var string send question added mail subject
 * @cfg_label Subject -- {username}
 * @cfg_key question_added_email_subject
 * @cfg_sub_head email reminder to sent added question details
 */
$LANG['question_added_email_subject'] = 'Dear {username} - Question added related to your subscribed keywords';
/**
 * @var string send question added mail body
 * @cfg_label Body - {username}, {sitename}, {asked by}, {link}
 * @cfg_key question_added_email_content
 */
$LANG['question_added_email_content'] = 'Dear {username},

{sitename} member, {asked by}, asked question related to your subscribed keywords.
{question asked}

Use the below link to view the question
{link}

Regards,
The {sitename} team';
/**
 * @var string send best answer mail subject
 * @cfg_label Subject -- {username}
 * @cfg_key best_answer_email_subject
 * @cfg_sub_head Sending email notification for best answer choosed
 */
$LANG['best_answer_email_subject'] = 'Dear {username} - Your answer is best';
/**
 * @var string send best answer mail body
 * @cfg_label Body -- {username}, {sitename}, {sender name}, {question asked}, {question reply}, {link}
 * @cfg_key best_answer_email_content
 */
$LANG['best_answer_email_content'] = 'Dear {username},

{sitename} member, {sender name}, selected your answer as best for the question.
{question asked}

Best answer of {username}
{question reply}

Use the below link to view the question
{link}

Regards,
The {sitename} team';
/**
 * @var string send abuse answer mail subject
 * @cfg_label Subject -- {username}
 * @cfg_key abuse_answer_email_subject
 * @cfg_sub_head Sending email notification for abused answer
 */
$LANG['abuse_answer_email_subject'] = 'Dear {username} - Your answer is abused';
/**
 * @var string send abuse answer mail body
 * @cfg_label Body -- {username}, {sitename}, {question asked}, {username}, {question reply}, {link}
 * @cfg_key abuse_answer_email_content
 */
$LANG['abuse_answer_email_content'] = 'Dear {username},

One of {sitename} member, abused your answer for the question.
{question asked}

Abused answer of {username}
{question reply}

Use the below link to view the question
{link}

Regards,
The {sitename} team';
/**
 * @var string send abuse question mail subject
 * @cfg_label Subject -- {username}
 * @cfg_key abuse_question_email_subject
 * @cfg_sub_head Sending email notification for abused question
 */
$LANG['abuse_question_email_subject'] = 'Dear {username} - Your question is abused';
/**
 * @var string send abuse question mail body
 * @cfg_label Body -- {username}, {sitename}, {link}, {question asked}
 * @cfg_key abuse_question_email_content
 */
$LANG['abuse_question_email_content'] = 'Dear {username},

One of {sitename} member, abused your question.
{question asked}

Use the below link to view the question
{link}

Regards,
The {sitename} team';
/**
 * @var string send favorite question replied mail subject
 * @cfg_label Subject -- {username}
 * @cfg_key favorite_question_replied_email_subject
 * @cfg_sub_head email reminder to sent favorite question updated details
 */
$LANG['favorite_question_replied_email_subject'] = 'Dear {username} - Answer posted to your favorite questions';
/**
 * @var string send favorite question replied mail body
 * @cfg_label Body -- {username}, {sitename}, {question asked}, {link}
 * @cfg_key favorite_question_replied_email_content
 */
$LANG['favorite_question_replied_email_content'] = 'Dear {username},

{sitename} members, replied to your favorite question.
{question asked}

Use the below link to view the question
{link}

Regards,
The {sitename} team';
/**
 * @var string send favorite question
 * @cfg_label Subject -- {username}
 * @cfg_key question_subscribed_email_subject
 * @cfg_sub_head Alert for Favorite Question
 */
$LANG['question_subscribed_email_subject'] = 'Dear {username} - Reply posted related to your Favorite Question';
/**
 * @var string send favorite question reply added mail body
 * @cfg_label Body -- {username}, {question}, {sitename}, {link}
 * @cfg_key question_subscribed_email_content
 */
$LANG['question_subscribed_email_content'] = 'Dear {username},

Your favorite question {question} in {sitename} has got a reply.

Use the below link to view the replies.
{link}

Regards,
The {sitename} team';
/**
 * @var string send forum to friend subject
 * @cfg_label Subject -- {forum}
 * @cfg_key send_forum_to_friend_subject
 * @cfg_sub_head Email this forum
 */
$LANG['send_forum_to_friend_subject'] = '{forum}';
/**
 * @var string send forum to friend body
 * @cfg_label Body -- {sender name}, {forum}, {sitename}
 * @cfg_key send_forum_to_friend_content
 */
$LANG['send_forum_to_friend_content'] = 'Hi,

Your friend, {sender name}, asked us to let you know about the forum {forum} asked online at {sitename}.

Regards,
The {sitename} team';
/**
 * @var string response alert
 * @cfg_label Subject -- {username}
 * @cfg_key forum_subscribed_email_subject
 * @cfg_sub_head Alert for subscribed forums
 */
$LANG['forum_subscribed_email_subject'] = 'Dear {username} - Response added related to your subscribed Forum';
/**
 * @var string response alert
 * @cfg_label Body -- {username}, {forum topic}, {sitename}, {link}
 * @cfg_key forum_subscribed_email_content
 */
$LANG['forum_subscribed_email_content'] = 'Dear {username},

Your subscribed forum {forum topic} in {sitename} has got a response.

Use the below link to view the response.
{link}

Regards,
The {sitename} team';
/**
 * @var string send blog to friend subject
 * @cfg_label Subject -- {blog}
 * @cfg_key send_blog_to_friend_subject
 * @cfg_sub_head Email this blog
 */
$LANG['send_blog_to_friend_subject'] = '{blog}';
/**
 * @var string send blog to friend body
 * @cfg_label Body -- {blog}, {sender name}, {sitename}
 * @cfg_key send_blog_to_friend_content
 */
$LANG['send_blog_to_friend_content'] = 'Hi,

Your friend, {sender name}, asked us to let you know about the blog {blog} asked online at {sitename}.

Regards,
The {sitename} team';
/**
 * @var string send comment alert
 * @cfg_label Subject -- {username}
 * @cfg_key blog_subscribed_email_subject
 * @cfg_sub_head Alert for subscribed blogs
 */
$LANG['blog_subscribed_email_subject'] = 'Dear {username} - Comment added related to your subscribed Blog';
/**
 * @var string comment alert
 * @cfg_label Body -- {username}, {blog subject}, {sitename}, {link}, {sitename}
 * @cfg_key blog_subscribed_email_content
 */
$LANG['blog_subscribed_email_content'] = 'Dear {username},

Your subscribed blog {blog subject} in {sitename} has got a comment.

Use the below link to view the comment.
{link}

Regards,
The {sitename} team';
/**
 * @var string New mail received
 * @cfg_label New mail received subject -- {site_name}
 * @cfg_key new_mail_received_subject
 * @cfg_sub_head Internal Mail alert
 */
$LANG['new_mail_received_subject'] = 'New mail received - {site_name}';
/**
 * @var string New mail received
 * @cfg_label New mail received content -- {receiver_name}, {sender_name}, {mail_link}, {link}, {site_name}
 * @cfg_key new_mail_received_content
 */
$LANG['new_mail_received_content'] = 'Dear {receiver_name},

You have received a mail from {sender_name},

{mail_link}

To learn more, please visit {link}
Regards,
{site_name}';
?>