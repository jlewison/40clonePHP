<?php
require_once ('../common/config.inc.php');
require_once ('../common/configs/config_ans_photo.inc.php');
$CFG['lang']['include_files'][] = 'admin/includes/languages/%s/viewAnswers.php';
$CFG['lang']['include_files'][] = 'common/email_templates/languages/%s/email_notify.inc.php';
$CFG['html']['header'] = 'admin/includes/languages/%s/html_header.php';
$CFG['html']['footer'] = 'admin/includes/languages/%s/html_footer.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['mods']['include_files'][] = 'common/classes/class_ListRecordsHandler.lib.php';
$CFG['lang']['include_files'][] = 'common/languages/%s/help.inc.php';
$CFG['db']['is_use_db'] = true;
$CFG['mods']['is_include_only']['non_html_header_files'] = true;
if ($_POST) $CFG['mods']['include_files'][] = 'common/classes/phpmailer/class_PHPMailer.lib.php';
require ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class AnswerFormHandler extends ListRecordsHandler
{
		public function deleteQuestion()
		{
				$this->updateQuestionVideoStatus($this->question_details['video_id']);
				$this->updateQuestionAudioStatus($this->question_details['audio_id']);
				$sql = 'DELETE FROM ' . $this->CFG['db']['tbl']['questions'] . ' WHERE ques_id=' . $this->dbObj->Param('qid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['qid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$sql = 'SELECT video_id, audio_id FROM ' . $this->CFG['db']['tbl']['answers'] . ' WHERE ques_id=' . $this->dbObj->Param('qid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['qid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount())
				{
						while ($row = $rs->FetchRow())
						{
								$this->updateAnswerVideoStatus($row['video_id']);
								$this->updateAnswerAudioStatus($row['audio_id']);
						}
				}
				$sql = 'DELETE FROM ' . $this->CFG['db']['tbl']['answers'] . ' WHERE ques_id=' . $this->dbObj->Param('qid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['qid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$pcat_id = $this->question_details['pcat_id'];
				$cat_id = $this->question_details['cat_id'];
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['questions_category'] . ' SET total_questions=total_questions-1' . ' WHERE cat_id=' . $this->dbObj->Param($pcat_id) . ' OR cat_id=' . $this->dbObj->Param($cat_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($pcat_id, $cat_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['users_ans_log'] . ' SET total_ques=total_ques-1' . ', total_points=total_points-' . $this->CFG['admin']['ask_answers']['points'] . ' WHERE user_id=' . $this->dbObj->Param('uid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->CFG['user']['user_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function deleteQuestionVideo()
		{
				$this->updateQuestionVideoStatus($this->question_details['video_id']);
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['questions'] . ' SET video_id=0' . ' WHERE ques_id=' . $this->dbObj->Param('qid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['qid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function deleteQuestionAudio()
		{
				$this->updateQuestionAudioStatus($this->question_details['audio_id']);
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['questions'] . ' SET audio_id=0' . ' WHERE ques_id=' . $this->dbObj->Param('qid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['qid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function populateHidden($hidden_field = array())
		{
				foreach ($hidden_field as $hidden_name)
				{
?>
						<input type="hidden" name="<?php echo $hidden_name; ?>" value="<?php echo $this->fields_arr[$hidden_name]; ?>" />
<?php
				}
		}
		public function chkIsValidQuestion()
		{
				$this->chkIsNotEmpty('qid', $this->LANG['answers_err_tip_compulsory']);
				if (!$this->isValidFormInputs())
				{
						$this->setCommonErrorMsg($this->LANG['answers_err_invalid_question']);
						return false;
				}
				$sql = 'SELECT q.ques_id, q.video_id, q.audio_id, q.total_answer, q.pcat_id, q.cat_id, q.best_ans_id, q.description, q.total_stars, q.question, TIMEDIFF(NOW(), date_asked) as date_asked' . ', ' . $this->getUserTableField('name') . ' as asked_by, u.' . $this->getUserTableField('user_id') . ' as img_user_id, ' . $this->getUserTableFields(array('image_path', 'gender', 't_height', 't_width', 'photo_server_url', 'photo_ext'), false) . 'q.status, q.user_id' . ', q.video_id, q.audio_id, IF(status=\'Open\' AND date_closed>=NOW(), 1, 0) is_open FROM ' . $this->CFG['db']['tbl']['questions'] . ' AS q' . ', ' . $this->CFG['db']['tbl']['users'] . ' AS u' . ' WHERE q.user_id=u.' . $this->getUserTableField('user_id') . ' AND u.' . $this->getUserTableField('usr_status') . '=\'Ok\' AND q.ques_id=' . $this->dbObj->Param('qid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['qid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if (!$rs->PO_RecordCount())
				{
						$this->setCommonErrorMsg($this->LANG['answers_err_invalid_question']);
						return false;
				}
				$this->question_details = $rs->FetchRow();
				return true;
		}
		public function buildConditionQuery()
		{
				$this->sql_condition = 'a.user_id=u.' . $this->getUserTableField('user_id') . ' AND u.' . $this->getUserTableField('usr_status') . '=\'Ok\'' . ' AND a.ques_id=' . $this->fields_arr['qid'] . ' AND a.ans_id!=' . $this->question_details['best_ans_id'];
		}
		public function buildSortQuery()
		{
				$this->sql_sort = $this->fields_arr['orderby_field'] . ' ' . $this->fields_arr['orderby'];
		}
		public function printQuery()
		{
				print 'Query:<br>' . $this->sql;
		}
		public function chkIsValidAnswer($ans_id)
		{
				if (!$this->isValidFormInputs())
				{
						$this->setCommonErrorMsg($this->LANG['answers_err_invalid_answer']);
						return false;
				}
				$sql = 'SELECT a.ques_id, a.video_id, a.audio_id, a.user_id, a.answer, a.source, a.video_id, a.audio_id' . ' FROM ' . $this->CFG['db']['tbl']['answers'] . ' AS a' . ', ' . $this->CFG['db']['tbl']['questions'] . ' AS q, ' . $this->CFG['db']['tbl']['users'] . ' AS u' . ' WHERE a.ques_id=q.ques_id AND a.user_id=u.' . $this->getUserTableField('user_id') . ' AND q.status IN (\'Open\', \'Resolved\')' . ' AND u.' . $this->getUserTableField('usr_status') . '=\'Ok\' AND a.ans_id=' . $this->dbObj->Param('aid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($ans_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if (!$rs->PO_RecordCount())
				{
						$this->setCommonErrorMsg($this->LANG['answers_err_invalid_question']);
						return false;
				}
				$this->answer_details = $rs->FetchRow();
				$this->fields_arr['qid'] = $this->answer_details['ques_id'];
				return true;
		}
		public function displayBestAnswer()
		{
				if ($this->question_details['best_ans_id'])
				{
						$sql = 'SELECT a.ans_id, a.user_id, a.video_id, a.audio_id, a.answer, a.source, TIMEDIFF(NOW(), date_answered) as date_answered, a.video_id, a.audio_id' . ', u.' . $this->getUserTableField('user_id') . ' as img_user_id, ' . $this->getUserTableFields(array('image_path', 'gender', 't_height', 't_width', 'photo_server_url', 'photo_ext'), false) . $this->getUserTableField('name') . ' as answered_by' . ' FROM ' . $this->CFG['db']['tbl']['answers'] . ' AS a' . ', ' . $this->CFG['db']['tbl']['users'] . ' AS u' . ' WHERE a.user_id=u.' . $this->getUserTableField('user_id') . ' AND u.' . $this->getUserTableField('usr_status') . '=\'Ok\'' . ' AND a.ques_id=' . $this->dbObj->Param('qid') . ' AND a.ans_id=' . $this->dbObj->Param('aid') . ' ORDER BY a.ans_id DESC';
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['qid'], $this->question_details['best_ans_id']));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
						if (!$rs->PO_RecordCount()) return;
						$row = $rs->FetchRow();
						$best_ans_id = $this->question_details['best_ans_id'];
?>
					<tr>
						<td class="clsForumTitle">
						<div class="clsAnswers">
							<p><strong><?php echo $this->LANG['answers_best_answer']; ?></strong></p>
							<?php if (chkVideoAllowed('answer') and $row['video_id'])
						{ ?>
								<span><a id="video_add<?php echo $best_ans_id; ?>" href="<?php echo getUrl('ansViewVideo.php', 'ansViewVideo.php'); ?>?pg=Answer_<?php echo $row['video_id']; ?>" onClick="return openAjaxWindow('video_add<?php echo $best_ans_id; ?>', 50, -200);"><img src="<?php echo $this->CFG['site']['url'] . 'images/icon-video.png' ?>" alt="video available" /></a></span>
							<?php } ?>
							<?php if (chkAudioAllowed('answer') and $row['audio_id'])
						{ ?>
								<span><a id="audio_add<?php echo $best_ans_id; ?>" href="<?php echo getUrl('ansViewAudio.php', 'ansViewAudio.php'); ?>?pg=Answer_<?php echo $row['audio_id']; ?>" onClick="return openAjaxWindow('audio_add<?php echo $best_ans_id; ?>', 50, -100);"><img src="<?php echo $this->CFG['site']['url'] . 'images/icon-audio.png' ?>" alt="audio available" /></a></span>
							<?php } ?>
							<p><?php echo nl2br(wordWrapManual($row['answer'], 50)); ?></p>
							<?php if ($row['source'])
						{ ?>
								<p><?php echo $this->LANG['answers_sources']; ?>:</p>
								<p><?php echo nl2br(wordWrapManual($row['source'], 50)); ?></p>
							<?php } ?>
							<p>
								<span class="clsForumAuthor"><?php echo $this->LANG['answers_answered_by']; ?> <a href="<?php echo $this->CFG['site']['relative_url'] . 'viewMembers.php?uid=' . $row['user_id'] . '/'; ?>"><?php echo $row['answered_by']; ?></a></span>
								&nbsp;-&nbsp;
								<span><?php echo getTimeDiffernceFormat($row['date_answered']); ?></span>
								<?php if (chkVideoAllowed('answer') and $row['video_id'])
						{ ?>
								&nbsp;-&nbsp;
								<a id="anchorDelVideo"  href="#" title="<?php echo $this->LANG['delete_video']; ?>" onClick="return Confirmation('anchorDelVideo', 'selMsgConfirm', 'deleteForm', Array('act','aid', 'confirmation_msg'), Array('deletevideo','<?php echo $row['video_id']; ?>', '<?php echo $this->LANG['confirm_delete_video_message']; ?>'), Array('value','value', 'innerHTML'), -100, -500, 'selListAdvertisementForm');"><?php echo $this->LANG['delete_video']; ?></a>
								<?php } ?>
								<?php if (chkAudioAllowed('answer') and $row['audio_id'])
						{ ?>
								&nbsp;-&nbsp;
								<a id="anchorDelAudio"  href="#" title="<?php echo $this->LANG['delete_audio']; ?>" onClick="return Confirmation('anchorDelAudio', 'selMsgConfirm', 'deleteForm', Array('act','aid', 'confirmation_msg'), Array('deleteaudio','<?php echo $row['audio_id']; ?>', '<?php echo $this->LANG['confirm_delete_audio_message']; ?>'), Array('value','value', 'innerHTML'), -100, -500);"><?php echo $this->LANG['delete_audio']; ?></a>
								<?php } ?>
								&nbsp;-&nbsp;
								<a id="anchorRemoveBest"  href="#" title="<?php echo $this->LANG['delete_best_answer']; ?>" onClick="return Confirmation('anchorRemoveBest', 'selMsgConfirm', 'deleteForm', Array('act','aid', 'confirmation_msg'), Array('deleteBestAnswer','<?php echo $row['ans_id']; ?>', '<?php echo $this->LANG['confirm_delete_best_answer_message']; ?>'), Array('value','value', 'innerHTML'), -100, -500);"><?php echo $this->LANG['delete_best_answer']; ?></a>
								&nbsp;-&nbsp;
								<a id="anchorDeleteAnswer"  href="#" title="<?php echo $this->LANG['answers_delete']; ?>" onClick="return Confirmation('anchorDeleteAnswer', 'selMsgConfirm', 'deleteForm', Array('act','aid', 'confirmation_msg'), Array('deleteAnswer','<?php echo $row['ans_id']; ?>', '<?php echo $this->LANG['confirm_delete_message']; ?>'), Array('value','value', 'innerHTML'), -100, -500);"><?php echo $this->LANG['answers_delete']; ?></a>
							</p>
						</div>
						</td>
					</tr>
				<?php
				}
		}
		public function isFavoriteQuestion()
		{
				$sql = 'SELECT fav_id FROM ' . $this->CFG['db']['tbl']['users_favorite_questions'] . ' WHERE ques_id = ' . $this->dbObj->Param('qid') . ' AND user_id = ' . $this->dbObj->Param('uid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['qid'], $this->CFG['user']['user_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$ok = false;
				if ($rs->PO_RecordCount()) $ok = true;
				return $ok;
		}
		public function showAnotherQuestion()
		{
				$sql = 'SELECT ques_id FROM ' . $this->CFG['db']['tbl']['questions'] . ' WHERE ques_id<' . $this->dbObj->Param('qid') . ' AND status IN (\'Open\', \'Resolved\')' . ' ORDER BY ques_id DESC LIMIT 1';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['qid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount())
				{
						$row = $rs->FetchRow();
?>
						<p class="clsAnotherQuestion"><a href="<?php echo $this->CFG['site']['relative_url'] . 'viewAnswers.php?qid=' . $row['ques_id']; ?>"><?php echo $this->LANG['answers_show_another_question']; ?></a></p>
						<?php
				}
		}
		public function showCategoryNameInAdmin($cat_id)
		{
				$sql = 'SELECT cat_name, cat_id FROM ' . $this->CFG['db']['tbl']['questions_category'] . ' WHERE cat_id=' . $this->dbObj->Param('cat_id');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($cat_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount())
				{
						$row = $rs->FetchRow();
?>
						<span>In <a href="<?php echo $this->CFG['site']['relative_url']; ?>manageAnswers.php?go=1&search_cat=8&search_name=<?php echo $row['cat_name']; ?>"><?php echo $row['cat_name']; ?></a></span>
						&nbsp;-&nbsp;
						<?php
						return true;
				}
				return false;
		}
		public function displayQuestionDetails()
		{
				if (!$this->question_details) return false;
				$qid = $this->fields_arr['qid'];
				$anchor1 = 'selConPos_' . $qid;
				$qanchor = 'selConPos1_' . $qid;
?>
				<div id="selQuickLinks">
				<?php $this->showAnotherQuestion(); ?>
				<form name="questionDetails" id="questionDetails" method="post" action="<?php echo $_SERVER['REQUEST_URI']; ?>" autocomplete="off">
				<table summary="display question details" id="selAuthorTbl">
					<tr>
						<td class="clsForumTitle">
						<?php ?>
						<p class="clsBold"><strong><?php echo wordWrapManual($this->question_details['question'], 50); ?></strong></p>
						<?php if (chkVideoAllowed('question') and $this->question_details['video_id'])
				{ ?>
							<span><a id="video_add<?php echo $qid; ?>" href="<?php echo getUrl('ansViewVideo.php', 'ansViewVideo.php'); ?>?pg=Question_<?php echo $this->question_details['video_id']; ?>" onClick="return openAjaxWindow('video_add<?php echo $qid; ?>', 50, -200);"><img src="<?php echo $this->CFG['site']['url'] . 'images/icon-video.png' ?>" alt="video available" /></a></span>
						<?php } ?>
						<?php if (chkAudioAllowed('question') and $this->question_details['audio_id'])
				{ ?>
							<span><a id="audio_add<?php echo $qid; ?>" href="<?php echo getUrl('ansViewAudio.php', 'ansViewAudio.php'); ?>?pg=Question_<?php echo $this->question_details['audio_id']; ?>" onClick="return openAjaxWindow('audio_add<?php echo $qid; ?>', 50, -100);"><img src="<?php echo $this->CFG['site']['url'] . 'images/icon-audio.png' ?>" alt="audio available" /></a></span>
						<?php } ?>
						<p class="clsDesc"><?php echo nl2br(wordWrapManual($this->question_details['description'], 50)); ?></p>
						<p>
							<?php $this->showCategoryNameInAdmin($this->question_details['cat_id']); ?>
							<span class="clsForumAuthor"><?php echo $this->LANG['answers_asked_by']; ?> <a href="<?php echo $this->CFG['site']['relative_url'] . 'viewMembers.php?uid=' . $this->question_details['user_id']; ?>"><?php echo $this->question_details['asked_by']; ?></a></span>
							&nbsp;-&nbsp;
							<span><?php echo $this->question_details['total_answer']; ?>&nbsp;<?php echo $this->LANG['answers']; ?></span>
							&nbsp;-&nbsp;
							<span><?php echo getTimeDiffernceFormat($this->question_details['date_asked']); ?></span>
							&nbsp;-&nbsp;
							<span><a href="manageAnswers.php?qid=<?php echo $this->question_details['ques_id']; ?>&f=v"><?php echo $this->LANG['edit']; ?></a></span>
							&nbsp;-&nbsp;
							<span><a id="anchorDelQuestion"  href="#" title="<?php echo 'Delete question'; ?>" onClick="return Confirmation('anchorDelQuestion', 'selMsgConfirm', 'deleteForm', Array('act','aid', 'confirmation_msg'), Array('deleteQuestion','<?php echo $qid; ?>', '<?php echo $this->LANG['confirm_deletequestion_message']; ?>'), Array('value','value', 'innerHTML'), -100, -500);"><?php echo $this->LANG['answers_delete']; ?></a></span>
							<?php if (chkVideoAllowed('answer') and $this->question_details['video_id'])
				{ ?>
							&nbsp;-&nbsp;
							<a id="anchorDeleteQuestionVideo"  href="#" title="<?php echo $this->LANG['delete_video']; ?>" onClick="return Confirmation('anchorDeleteQuestionVideo', 'selMsgConfirm', 'deleteForm', Array('act','aid', 'confirmation_msg'), Array('deleteQuestionVideo','<?php echo $this->question_details['video_id']; ?>', '<?php echo $this->LANG['confirm_delete_video_message']; ?>'), Array('value','value', 'innerHTML'), -100, -500);"><?php echo $this->LANG['delete_video']; ?></a>
							<?php } ?>
							<?php if (chkAudioAllowed('answer') and $this->question_details['audio_id'])
				{ ?>
							&nbsp;-&nbsp;
							<a id="anchorDeleteQuestionAudio"  href="#" title="<?php echo $this->LANG['delete_audio']; ?>" onClick="return Confirmation('anchorDeleteQuestionAudio', 'selMsgConfirm', 'deleteForm', Array('act','aid', 'confirmation_msg'), Array('deleteQuestionAudio','<?php echo $this->question_details['audio_id']; ?>', '<?php echo $this->LANG['confirm_delete_audio_message']; ?>'), Array('value','value', 'innerHTML'), -100, -500);"><?php echo $this->LANG['delete_audio']; ?></a>
							<?php } ?>
							<?php if ($this->question_details['is_open'])
				{ ?>
							<ul>
							<li>
							<a id="anchorResolveQuestion"  href="#" title="<?php echo $this->LANG['answers_resolve_question']; ?>" onClick="return Confirmation('anchorResolveQuestion', 'selMsgConfirm', 'deleteForm', Array('act','qid', 'confirmation_msg'), Array('resolve','<?php echo $qid; ?>', '<?php echo $this->LANG['confirm_resolve_message']; ?>'), Array('value','value', 'innerHTML'), -100, -500);"><?php echo $this->LANG['answers_resolve_question']; ?></a>
							</li>
							</ul>
							<?php } ?>
						</p>
						</td>
					</tr>
					<?php $this->displayBestAnswer(); ?>
				</table>
				</form>
				</div>
				<?php
				if ($this->question_details['status'] == 'Open' && $this->question_details['user_id'] != $this->CFG['user']['user_id'])
				{
?>
					<span class="clsAnswerQuestion"><a target="_blank" href="<?php echo getUrl($this->CFG['site']['url'] . 'members/answer.php?action=reply&qid=' . $this->fields_arr['qid'], $this->CFG['site']['url'] . 'members/reply/answers/' . $this->fields_arr['qid'] . '/', false); ?>"><?php echo $this->LANG['answers_this_question']; ?></a></span>
					<?php
				}
		}
		public function displayAllAnswers()
		{
				if (!$this->isResultsFound())
				{
?>
					<div id="selMsgAlert">
						<p><?php echo $this->LANG['answers_not_added']; ?></p>
					</div>
					<?php
						return;
				}
				$pagingArr = array();
				if ($this->fields_arr['qid']) $pagingArr[] = 'qid';
				if ($this->CFG['admin']['navigation']['top']) $this->populatePageLinks($this->getFormField('start'), $pagingArr);
?>
		    	<form name="selListAdvertisementForm" id="selListAdvertisementForm" method="post" action="<?php echo $_SERVER['REQUEST_URI']; ?>" autocomplete="off">
				<table summary="<?php echo $this->LANG['display_all_answers']; ?>">
				<?php
				$id_cnt = 0;
				$anchor1 = '';
				$anchor = '';
				while ($row = $this->fetchResultRecord())
				{
						$ans_id = $row['ans_id'];
						$anchor = 'dAltMlti';
						$anchor1 = 'selConPos_' . $row['video_id'];
						$anchor2 = 'selConPoss_' . $row['audio_id'];
?>
					<tr>
						<td>
						<input type="checkbox" class="clsCheckRadio" name="aid[]" value="<?php echo $row['ans_id']; ?>" tabindex="<?php echo $this->getTabIndex(); ?>" />
						</td>
						<td>
						<div class="clsAnswers">
							<p><?php echo nl2br(wordWrapManual($row['answer'], 50)); ?></p>
							<?php if (chkVideoAllowed('answer') and $row['video_id'])
						{ ?>
								<span><a id="video_add<?php echo $ans_id; ?>" href="<?php echo getUrl('ansViewVideo.php', 'ansViewVideo.php'); ?>?pg=Answer_<?php echo $row['video_id']; ?>" onClick="return openAjaxWindow('video_add<?php echo $ans_id; ?>', 50, -200);"><img src="<?php echo $this->CFG['site']['url'] . 'images/icon-video.png' ?>" alt="video available" /></a></span>
							<?php } ?>
							<?php if (chkAudioAllowed('answer') and $row['audio_id'])
						{ ?>
								<span><a id="audio_add<?php echo $ans_id; ?>" href="<?php echo getUrl('ansViewAudio.php', 'ansViewAudio.php'); ?>?pg=Answer_<?php echo $row['audio_id']; ?>" onClick="return openAjaxWindow('audio_add<?php echo $ans_id; ?>', 50, -100);"><img src="<?php echo $this->CFG['site']['url'] . 'images/icon-audio.png' ?>" alt="audio available" /></a></span>
							<?php } ?>
							<?php if ($row['source'])
						{ ?>
								<p><?php echo $this->LANG['answers_sources']; ?>:</p>
								<p><?php echo nl2br($row['source']); ?></p>
							<?php } ?>
							<p>
								<span class="clsForumAuthor"><?php echo $this->LANG['answers_answered_by']; ?> <a href="<?php echo $this->CFG['site']['relative_url'] . 'viewMembers.php?uid=' . $row['user_id']; ?>"><?php echo $row['answered_by']; ?></a></span>
								&nbsp;-&nbsp;
								<span><?php echo getTimeDiffernceFormat($row['date_answered']); ?></span>
								<?php if ($this->CFG['admin']['abuse_answers']['allowed'] and $this->CFG['user']['user_id'] != $row['user_id'] and $this->question_details['status'] == 'Open')
						{ ?>
								&nbsp;-&nbsp;
								<span>(<?php echo $this->LANG['answers_abuse_count']; ?> <?php echo $row['abuse_count']; ?>)</span>
								<?php } ?>
								<?php if ($this->CFG['admin']['best_answers']['allowed'] and $this->CFG['user']['user_id'] == $this->question_details['user_id'] and $this->question_details['status'] == 'Open' and $this->question_details['best_ans_id'] == 0)
						{ ?>
								&nbsp;-&nbsp;
								<a id="<?php echo $anchor1; ?>"  href="#" title="<?php echo $this->LANG['answers_best_answer']; ?>" onClick="return Confirmation('<?php echo $anchor1; ?>', 'selMsgConfirm', 'deleteForm', Array('act','aid', 'confirmation_msg'), Array('bestanswer','<?php echo $row['ans_id']; ?>', '<?php echo $this->LANG['best_answer_confirm_message']; ?>'), Array('value','value', 'innerHTML'), -100, -500);"><?php echo $this->LANG['answers_best_answer']; ?></a>
								<?php } ?>
								<?php if (chkVideoAllowed('answer') and $row['video_id'])
						{ ?>
								&nbsp;-&nbsp;
								<a id="<?php echo $anchor1; ?>"  href="#" title="<?php echo $this->LANG['delete_video']; ?>" onClick="return Confirmation('<?php echo $anchor1; ?>', 'selMsgConfirm', 'deleteForm', Array('act','aid', 'confirmation_msg'), Array('deletevideo','<?php echo $row['video_id']; ?>', '<?php echo $this->LANG['confirm_delete_video_message']; ?>'), Array('value','value', 'innerHTML'), -100, -500);"><?php echo $this->LANG['delete_video']; ?></a>
								<?php } ?>
								<?php if (chkAudioAllowed('answer') and $row['audio_id'])
						{ ?>
								&nbsp;-&nbsp;
								<a id="<?php echo $anchor2; ?>"  href="#" title="<?php echo $this->LANG['delete_audio']; ?>" onClick="return Confirmation('<?php echo $anchor2; ?>', 'selMsgConfirm', 'deleteForm', Array('act','aid', 'confirmation_msg'), Array('deleteaudio','<?php echo $row['audio_id']; ?>', '<?php echo $this->LANG['confirm_delete_audio_message']; ?>'), Array('value','value', 'innerHTML'), -100, -500);"><?php echo $this->LANG['delete_audio']; ?></a>
								<?php } ?>
							</p>
						</div>
						</td>
					</tr>

				<?php
				}



?>
				<tr>
						<td colspan="2">
						<a href="#" id="<?php echo $anchor; ?>"></a>
						<input type="button" class="clsSubmitButton" name="delete_submit" id="delete_submit" tabindex="<?php echo $this->getTabIndex(); ?>" value="<?php echo 'Delete'; ?>" onClick="if(getMultiCheckBoxValue('selListAdvertisementForm', 'check_all', '<?php echo 'Please select atleast one answer'; ?>', '<?php echo $anchor; ?>', -100, -500)){Confirmation('<?php echo $anchor; ?>', 'selMsgConfirm', 'deleteForm', Array('aid', 'act', 'confirmation_msg'), Array(multiCheckValue, 'delete', '<?php echo nl2br($this->LANG['confirm_delete_message']); ?>'), Array('value', 'value', 'innerHTML'), -100, -500);}" />
						</td>
					</tr>
				</table>
				</form>
				<?php
				$pagingArr = array();
				if ($this->fields_arr['qid']) $pagingArr[] = 'qid';
				if ($this->CFG['admin']['navigation']['bottom']) $this->populatePageLinks($this->getFormField('start'), $pagingArr);
		}
		public function displaySearchOption()
		{
?>
		  <form name="selQuestionSearchs" id="selQuestionSearch" method="post" action="<?php echo URL($this->CFG['site']['relative_url'] . 'manageAnswers.php'); ?>" autocomplete="off">
		    <table summary="<?php echo $this->LANG['answers_tbl_summary']; ?>">
		      <tr>
		        <td class="<?php echo $this->getCSSFormLabelCellClass('search_name'); ?>"><label for="search_name"><?php echo $this->LANG['answers_search_name']; ?></label></td>
		        <td class="<?php echo $this->getCSSFormFieldCellClass('search_name'); ?>"><?php echo $this->getFormFieldErrorTip('search_name'); ?>
		          <input type="text" class="clsTextBox" name="search_name" id="search_name" tabindex="2000" value="<?php echo $this->getFormField('search_name'); ?>" /></td>
		      </tr>
		      <tr>
		        <td class="<?php echo $this->getCSSFormLabelCellClass('search_cat'); ?>"><label for="search_cat"><?php echo $this->LANG['answers_search_cat']; ?></label></td>
		        <td class="<?php echo $this->getCSSFormFieldCellClass('search_cat'); ?>"><?php echo $this->getFormFieldErrorTip('search_cat'); ?>
		          <select name="search_cat" id="search_cat" tabindex="2001">
		            <option value="1" <?php if ($this->getFormField('search_cat') == '1') echo 'selected=\'selected\''; ?>><?php echo $this->LANG['user_name']; ?></option>
		            <option value="2" <?php if ($this->getFormField('search_cat') == '2') echo 'selected=\'selected\''; ?>><?php echo $this->LANG['email']; ?></option>
					<option value="3" <?php if ($this->getFormField('search_cat') == '3') echo 'selected=\'selected\''; ?>><?php echo $this->LANG['open_questions']; ?></option>
					<option value="4" <?php if ($this->getFormField('search_cat') == '4') echo 'selected=\'selected\''; ?>><?php echo $this->LANG['resolved_questions']; ?></option>
					<option value="5" <?php if ($this->getFormField('search_cat') == '5') echo 'selected=\'selected\''; ?>><?php echo $this->LANG['blocked_questions']; ?></option>
					<option value="6" <?php if ($this->getFormField('search_cat') == '6') echo 'selected=\'selected\''; ?>><?php echo $this->LANG['questions']; ?></option>
					<option value="7" <?php if ($this->getFormField('search_cat') == '7') echo 'selected=\'selected\''; ?>><?php echo $this->LANG['tags']; ?></option>
					<option value="8" <?php if ($this->getFormField('search_cat') == '8') echo 'selected=\'selected\''; ?>><?php echo $this->LANG['categories']; ?></option>
		          </select>
		        </td>
		      </tr>
		      <tr>
		        <td colspan="2"  class="<?php echo $this->getCSSFormFieldCellClass('submit'); ?>"><input type="submit" class="clsSubmitButton" name="go" tabindex="2010" value="<?php echo $this->LANG['answers_go']; ?>" /></td>
		      </tr>
		    </table>
			</form>
			<?php
		}
		public function replyAnswers()
		{
?>
			<div class="clsReplyAnswers">
			<form name="selFormReplyAnswers" id="selFormReplyAnswers" method="post" action="<?php echo URL($_SERVER['REQUEST_URI']); ?>" autocomplete="off">
			<table summary="Post your answers">
				<tr>
					<td class="<?php echo $this->getCSSFormLabelCellClass('question'); ?>"><label for="question"><?php echo $this->LANG['question']; ?></label></td>
					<td class="<?php echo $this->getCSSFormFieldCellClass('question'); ?>"><?php echo $this->question_details['question']; ?></td>
				</tr>
				<tr>
					<td class="<?php echo $this->getCSSFormLabelCellClass('answer'); ?>"><label for="answer"><?php echo $this->LANG['your_answer']; ?></label></td>
					<td class="<?php echo $this->getCSSFormFieldCellClass('answer'); ?>"><?php echo $this->getFormFieldErrorTip('answer'); ?>
						<textarea class="clsTextBox" name="answer" id="answer" tabindex="<?php echo $this->getTabIndex(); ?>"><?php echo $this->getFormField('answer'); ?></textarea>
					</td>
				</tr>
				<tr>
					<td class="<?php echo $this->getCSSFormLabelCellClass('source'); ?>"><label for="source"><?php echo $this->LANG['know_your_source_list_it_here']; ?></label></td>
					<td class="<?php echo $this->getCSSFormFieldCellClass('source'); ?>"><?php echo $this->getFormFieldErrorTip('source'); ?>
						<textarea class="clsTextBox" name="source" id="source" tabindex="<?php echo $this->getTabIndex(); ?>"><?php echo $this->getFormField('source'); ?></textarea>
					</td>
				</tr>
				<tr>
					<td class="<?php echo $this->getCSSFormFieldCellClass('submit'); ?>" colspan="2">
						<input type="submit" class="clsSubmitButton clsMediumSubmitButton" name="submit" id="submit" tabindex="<?php echo $this->getTabIndex(); ?>" value="<?php echo $this->LANG['submit_your_answer']; ?>" />
						&nbsp;&nbsp;
						<input type="submit" class="clsCancelButton" name="cancel" id="cancel" tabindex="<?php echo $this->getTabIndex(); ?>" value="<?php echo $this->LANG['answers_cancel']; ?>" />
					</td>
				</tr>
			</table>
			</form>
			</div>
			<?php
		}
		public function abuseQuestion()
		{
?>
			<div class="clsAbuseQuestions">
			<form name="selFormAbuseQuestions" id="selFormAbuseQuestions" method="post" action="<?php echo URL($_SERVER['REQUEST_URI']); ?>">
			<table summary="Post your answers">
				<tr>
					<td class="<?php echo $this->getCSSFormLabelCellClass('reported'); ?>"><?php echo $this->LANG['answers_reported_by'] ?></td>
					<td class="<?php echo $this->getCSSFormFieldCellClass('reported'); ?>"><a href="<?php echo $this->CFG['site']['relative_url'] . 'viewMembers.php?uid=' . $this->CFG['user']['user_id']; ?>"><?php echo $this->CFG['user']['name']; ?></a></td>
				</tr>
				<tr>
					<td class="<?php echo $this->getCSSFormLabelCellClass('Question'); ?>"><?php echo $this->LANG['question']; ?></td>
					<td class="<?php echo $this->getCSSFormFieldCellClass('Question'); ?>"><a href="<?php echo $this->CFG['site']['relative_url'] . 'viewAnswers.php?qid=' . $this->fields_arr['qid']; ?>"><?php echo $this->question_details['question']; ?></a></td>
				</tr>
				<tr>
					<td class="<?php echo $this->getCSSFormLabelCellClass('reason'); ?>"><label for="reason"><?php echo $this->LANG['reason']; ?></label></td>
					<td class="<?php echo $this->getCSSFormFieldCellClass('reason'); ?>"><?php echo $this->getFormFieldErrorTip('reason'); ?>
						<textarea name="reason" id="reason" tabindex="<?php echo $this->getTabIndex(); ?>"><?php echo $this->getFormField('reason'); ?></textarea>
					</td>
				</tr>
				<tr>
					<td class="<?php echo $this->getCSSFormFieldCellClass('abuse_question'); ?>" colspan="2">
						<input type="submit" class="clsSubmitButton" name="abuse_question" id="abuse_question" tabindex="<?php echo $this->getTabIndex(); ?>" value="<?php echo $this->LANG['answers_submit']; ?>" />
						&nbsp;&nbsp;
						<input type="submit" class="clsCancelButton" name="cancel" id="cancel" tabindex="<?php echo $this->getTabIndex(); ?>" value="<?php echo $this->LANG['answers_cancel']; ?>" />
					</td>
				</tr>
			</table>
			</form>
			</div>
			<?php
		}
		public function abuseAnswer()
		{
?>
			<div class="clsAbuseAnswers">
			<form name="selFormAbuseAnswers" id="selFormAbuseAnswers" method="post" action="<?php echo URL($_SERVER['REQUEST_URI']); ?>">
			<table summary="Post your answers">
				<tr>
					<td class="<?php echo $this->getCSSFormLabelCellClass('reported'); ?>"><?php echo $this->LANG['answers_reported_by']; ?></td>
					<td class="<?php echo $this->getCSSFormFieldCellClass('reported'); ?>"><a href="<?php echo $this->CFG['site']['relative_url'] . 'viewMembers.php?uid=' . $this->CFG['user']['user_id']; ?>"><?php echo $this->CFG['user']['name']; ?></a></td>
				</tr>
				<tr>
					<td class="<?php echo $this->getCSSFormLabelCellClass('Question'); ?>"><?php echo $this->LANG['question']; ?></td>
					<td class="<?php echo $this->getCSSFormFieldCellClass('Question'); ?>"><a href="<?php echo $this->CFG['site']['relative_url'] . 'viewAnswers.php?qid=' . $this->fields_arr['qid']; ?>"><?php echo $this->question_details['question']; ?></a></td>
				</tr>
				<tr>
					<td class="<?php echo $this->getCSSFormLabelCellClass('Answer'); ?>"><?php $this->LANG['answers_answers']; ?></td>
					<td class="<?php echo $this->getCSSFormFieldCellClass('Answer'); ?>"><?php echo nl2br($this->answer_details['answer']); ?></td>
				</tr>
				<tr>
					<td class="<?php echo $this->getCSSFormLabelCellClass('reason'); ?>"><label for="reason"><?php echo $this->LANG['reason'] ?></label></td>
					<td class="<?php echo $this->getCSSFormFieldCellClass('reason'); ?>"><?php echo $this->getFormFieldErrorTip('reason'); ?>
						<textarea name="reason" id="reason" tabindex="<?php echo $this->getTabIndex(); ?>"><?php echo $this->getFormField('reason'); ?></textarea>
					</td>
				</tr>
				<tr>
					<td class="<?php echo $this->getCSSFormFieldCellClass('abuse_answer'); ?>" colspan="2">
						<input type="submit" class="clsSubmitButton" name="abuse_answer" id="abuse_answer" tabindex="<?php echo $this->getTabIndex(); ?>" value="<?php echo $this->LANG['answers_submit']; ?>" />
						&nbsp;&nbsp;
						<input type="submit" class="clsCancelButton" name="cancel" id="cancel" tabindex="<?php echo $this->getTabIndex(); ?>" value="<?php echo $this->LANG['answers_cancel']; ?>" />
					</td>
				</tr>
			</table>
			</form>
			</div>
			<?php
		}
		public function displayConfirmOption($action, $confirm_message, $hidden_array = array())
		{
?>
		  <div id="selMsgConfirm">
		    <form name="selFormConfirm" id="selFormConfirm" method="post" action="<?php echo URL($this->CFG['site']['relative_url'] . 'viewAnswers.php?qid=' . $this->fields_arr['qid']); ?>">
				<p><?php echo $confirm_message; ?></p>
		      <table summary="<?php echo $this->LANG['confirm_tbl_summary']; ?>" border="1">
		        <tr>
		          <td>
		            <input type="submit" class="clsSubmitButton" name="<?php echo $action; ?>" id="<?php echo $action; ?>" tabindex="<?php echo $this->getTabIndex(); ?>" value="<?php echo $this->LANG['answers_yes']; ?>" />
				  </td>
				  <td>
				  	<input type="submit" class="clsCancelButton" name="cancel" id="cancel" tabindex="<?php echo $this->getTabIndex(); ?>" value="<?php echo $this->LANG['answers_no']; ?>"  />
		          </td>
		        </tr>
			  </table>
			  <?php $this->populateHidden($hidden_array); ?>
			</form>
		  </div>
			<?php
		}
		public function updateAbuseQuestion()
		{
				$sql = 'SELECT abuse_id FROM ' . $this->CFG['db']['tbl']['abuse_questions'] . ' WHERE ques_id=' . $this->dbObj->Param('qid') . ' AND reported_by=' . $this->dbObj->Param('rid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['qid'], $this->CFG['user']['user_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if (!$rs->PO_RecordCount())
				{
						$sql = 'INSERT INTO ' . $this->CFG['db']['tbl']['abuse_questions'] . ' SET ques_id=' . $this->dbObj->Param('qid') . ', reported_by=' . $this->dbObj->Param('rid') . ', reason=' . $this->dbObj->Param('reason') . ', date_abused=NOW()';
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['qid'], $this->CFG['user']['user_id'], $this->fields_arr['reason']));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
						if ($this->dbObj->Affected_Rows())
						{
								$this->updateQuestionAbuseCount();
								$this->updateAbuseUserPoints($this->CFG['admin']['abuse_questions_points']['allowed'], $this->question_details['user_id'], $this->CFG['admin']['abuse_questions']['points']);
								$this->sendAbuseMailToAsker();
						}
				}
		}
		public function updateQuestionAbuseCount()
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['questions'] . ' SET abuse_count=abuse_count+1' . ' WHERE ques_id=' . $this->dbObj->Param('qid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['qid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function updateAbuseAnswer()
		{
				$sql = 'SELECT abuse_id FROM ' . $this->CFG['db']['tbl']['abuse_answers'] . ' WHERE ans_id=' . $this->dbObj->Param('aid') . ' AND reported_by=' . $this->dbObj->Param('rid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['aid'], $this->CFG['user']['user_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if (!$rs->PO_RecordCount())
				{
						$sql = 'INSERT INTO ' . $this->CFG['db']['tbl']['abuse_answers'] . ' SET ques_id=' . $this->dbObj->Param('qid') . ', ans_id=' . $this->dbObj->Param('aid') . ', reported_by=' . $this->dbObj->Param('rid') . ', reason=' . $this->dbObj->Param('reason') . ', date_abused=NOW()';
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['qid'], $this->fields_arr['aid'], $this->CFG['user']['user_id'], $this->fields_arr['reason']));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
						if ($this->dbObj->Affected_Rows())
						{
								$this->updateAnswerAbuseCount();
								$this->updateAbuseUserPoints($this->CFG['admin']['abuse_answers_points']['allowed'], $this->answer_details['user_id'], $this->CFG['admin']['abuse_answers']['points']);
								$this->sendAbuseMailToAnswerer();
						}
				}
		}
		public function updateAnswerAbuseCount()
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['answers'] . ' SET abuse_count=abuse_count+1' . ' WHERE ans_id=' . $this->dbObj->Param('aid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['aid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function updateAbuseUserPoints($config_abuse, $uid, $points)
		{
				if (!$config_abuse or $points == 0 or !isset($this->CFG['user']['user_id']) or empty($this->CFG['user']['user_id'])) return;
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['users_ans_log'] . ' SET total_points=total_points+' . $points . ', date_updated=NOW()' . ' WHERE user_id=' . $this->dbObj->Param('uid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($uid));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return;
		}
		public function updateBestAnswer()
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['questions'] . ' SET best_ans_id=' . $this->dbObj->Param('aid') . ' WHERE ques_id=' . $this->dbObj->Param('qid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['aid'], $this->fields_arr['qid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($this->dbObj->Affected_Rows()) $this->sendMailToAnswerer();
		}
		public function deleteAnswers($question_name, $answers_table, $users_ans_log_table, $ans_id)
		{
				$this->updateAnswerVideoStatus($this->answer_details['video_id']);
				$this->updateAnswerAudioStatus($this->answer_details['audio_id']);
				$sql = 'SELECT user_id FROM ' . $answers_table . ' WHERE ans_id IN (' . $this->dbObj->Param('aid') . ')';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($ans_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount())
				{
						$row = $rs->FetchRow();
						$sql = 'UPDATE ' . $users_ans_log_table . ' SET total_ans=total_ans-1,' . ' total_points=total_points-' . $this->CFG['admin']['reply_answers']['points'] . ' WHERE user_id=' . $this->dbObj->Param('uid');
						$stmt = $this->dbObj->Prepare($sql);
						$rs_user_log = $this->dbObj->Execute($stmt, array($row['user_id']));
						if (!$rs_user_log) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				}
				$sql = 'DELETE FROM ' . $answers_table . ' WHERE ans_id IN (' . $this->dbObj->Param('aid') . ')';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($ans_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$sql = 'UPDATE ' . $question_name . ' SET total_answer=total_answer-1 WHERE ques_id IN (' . $this->dbObj->Param('qid') . ')';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['qid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function removeBestAnswer()
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['questions'] . ' SET best_ans_id=0' . ' WHERE ques_id=' . $this->dbObj->Param('qid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['qid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function resolveQuestion()
		{
				if ($this->question_details['status'] == 'Open')
				{
						$sql = 'UPDATE ' . $this->CFG['db']['tbl']['questions'] . ' SET status=\'Resolved\'' . ' WHERE ques_id=' . $this->dbObj->Param('qid');
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['qid']));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				}
				return;
		}
		public function addAnswer()
		{
				if ($this->question_details['status'] == 'Open')
				{
						$this->insertAnswer();
						$this->updateQuestion();
						$this->updateUserAnswerLog();
						$this->sendMailToAsker();
				}
		}
		public function insertAnswer()
		{
				$sql = 'INSERT INTO ' . $this->CFG['db']['tbl']['answers'] . ' SET user_id=' . $this->dbObj->Param('uid') . ', ques_id=' . $this->dbObj->Param('qid') . ', answer=' . $this->dbObj->Param('answer') . ', source=' . $this->dbObj->Param('source') . ', date_answered=NOW()';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->CFG['user']['user_id'], $this->fields_arr['qid'], $this->fields_arr['answer'], $this->fields_arr['source']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return;
		}
		public function updateQuestion()
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['questions'] . ' SET total_answer=total_answer+1' . ', email_sent=\'No\', date_answered=NOW()' . ' WHERE ques_id=' . $this->dbObj->Param('qid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['qid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function updateUserAnswerLog()
		{
				if (!$this->CFG['admin']['reply_answers']['allowed']) return;
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['users_ans_log'] . ' SET total_ans=total_ans+1' . ', total_points=total_points+' . $this->CFG['admin']['reply_answers']['points'] . ', date_updated=NOW()' . ' WHERE user_id=' . $this->dbObj->Param('uid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->CFG['user']['user_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function sendMailToAsker()
		{
				if ($this->question_details['user_id'] == $this->CFG['user']['user_id']) return;
				$email_options = $this->getEmailOptionsOfUser($this->question_details['user_id']);
				if ($email_options['reply_mail'] == 'Yes')
				{
						$asker_details = $this->getUserDetailsFromUsersTable($this->CFG['db']['tbl']['users'], $this->question_details['user_id']);
						$answers_reply_subject = str_replace('{username}', $asker_details['name'], $this->LANG['answers_reply_email_subject']);
						$answers_reply_subject = str_replace('{sender name}', $this->CFG['user']['name'], $answers_reply_subject);
						$receiver_url = getUrl($this->CFG['site']['url'] . 'myanswers.php?uid=' . $this->question_details['user_id'], $this->CFG['site']['url'] . 'my/answers/' . $this->question_details['user_id'], false);
						$answers_reply_content = str_replace('{username}', '<a href="' . $receiver_url . '/">' . $asker_details['name'] . '</a>', $this->LANG['answers_reply_email_content']);
						$sender_url = getUrl($this->CFG['site']['url'] . 'myanswers.php?uid=' . $this->CFG['user']['user_id'], $this->CFG['site']['url'] . 'my/answers/' . $this->CFG['user']['user_id'] . '/', false);
						$sender_name = '<a href="' . $sender_url . '">' . $this->CFG['user']['name'] . '</a>';
						$answers_reply_content = str_replace('{sender name}', $sender_name, $answers_reply_content);
						$answers_reply_content = str_replace('{sitename}', $this->CFG['site']['name'], $answers_reply_content);
						$answers_reply_content = str_replace('{question asked}', '<strong>' . $this->question_details['question'] . '</strong>', $answers_reply_content);
						$answers_reply_content = str_replace('{question reply}', nl2br($this->fields_arr['answer']), $answers_reply_content);
						$question_link = getUrl($this->CFG['site']['url'] . 'answer.php?qid=' . $this->fields_arr['qid'] . '/', $this->CFG['site']['url'] . 'view/answers/' . $this->fields_arr['qid'] . '/', false);
						$answers_reply_content = str_replace('{link}', '<a href="' . $question_link . '">' . $question_link . '</a>', $answers_reply_content);
						$this->_sendMail($asker_details['email'], $answers_reply_subject, nl2br($answers_reply_content), $this->CFG['site']['noreply_name'], $this->CFG['site']['noreply_email']);
				}
		}
		public function sendMailToAnswerer()
		{
				if ($this->question_details['user_id'] != $this->CFG['user']['user_id']) return;
				$answer_details = $this->getAnswerDetails($this->fields_arr['aid']);
				$email_options = $this->getEmailOptionsOfUser($answer_details['user_id']);
				if ($email_options['best_ans_mail'] == 'Yes')
				{
						$answerer_details = $this->getUserDetailsFromUsersTable($this->CFG['db']['tbl']['users'], $answer_details['user_id']);
						$best_answers_subject = str_replace('{username}', $answerer_details['name'], $this->LANG['best_answer_email_subject']);
						$receiver_url = getUrl($this->CFG['site']['url'] . 'myanswers.php?uid=' . $answer_details['user_id'], $this->CFG['site']['url'] . 'my/answers/' . $answer_details['user_id'], false);
						$best_answers_content = str_replace('{username}', '<a href="' . $receiver_url . '/">' . $answerer_details['name'] . '</a>', $this->LANG['best_answer_email_content']);
						$sender_url = getUrl($this->CFG['site']['url'] . 'myanswers.php?uid=' . $this->CFG['user']['user_id'], $this->CFG['site']['url'] . 'my/answers/' . $this->CFG['user']['user_id'] . '/', false);
						$sender_name = '<a href="' . $sender_url . '">' . $this->CFG['user']['name'] . '</a>';
						$best_answers_content = str_replace('{sender name}', $sender_name, $best_answers_content);
						$best_answers_content = str_replace('{sitename}', $this->CFG['site']['name'], $best_answers_content);
						$best_answers_content = str_replace('{question asked}', '<strong>' . $this->question_details['question'] . '</strong>', $best_answers_content);
						$best_answers_content = str_replace('{question reply}', nl2br($answer_details['answer']), $best_answers_content);
						$question_link = getUrl($this->CFG['site']['url'] . 'answer.php?qid=' . $this->fields_arr['qid'] . '/', $this->CFG['site']['url'] . 'view/answers/' . $this->fields_arr['qid'] . '/', false);
						$best_answers_content = str_replace('{link}', '<a href="' . $question_link . '">' . $question_link . '</a>', $best_answers_content);
						$this->_sendMail($answerer_details['email'], $best_answers_subject, nl2br($best_answers_content), $this->CFG['site']['noreply_name'], $this->CFG['site']['noreply_email']);
				}
		}
		public function getAnswerDetails($aid)
		{
				$sql = 'SELECT user_id, answer FROM ' . $this->CFG['db']['tbl']['answers'] . ' WHERE ans_id=' . $this->dbObj->Param('aid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['aid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = $rs->FetchRow();
				return $row;
		}
		public function sendAbuseMailToAsker()
		{
				$email_options = $this->getEmailOptionsOfUser($this->question_details['user_id']);
				if ($email_options['abuse_mail'] == 'Yes')
				{
						$asker_details = $this->getUserDetailsFromUsersTable($this->CFG['db']['tbl']['users'], $this->question_details['user_id']);
						$abuse_question_subject = str_replace('{username}', $asker_details['name'], $this->LANG['abuse_question_email_subject']);
						$receiver_url = getUrl($this->CFG['site']['url'] . 'myanswers.php?uid=' . $this->question_details['user_id'], $this->CFG['site']['url'] . 'my/answers/' . $this->question_details['user_id'], false);
						$abuse_question_content = str_replace('{username}', '<a href="' . $receiver_url . '/">' . $asker_details['name'] . '</a>', $this->LANG['abuse_question_email_content']);
						$sender_url = getUrl($this->CFG['site']['url'] . 'myanswers.php?uid=' . $this->CFG['user']['user_id'], $this->CFG['site']['url'] . 'my/answers/' . $this->CFG['user']['user_id'] . '/', false);
						$sender_name = '<a href="' . $sender_url . '">' . $this->CFG['user']['name'] . '</a>';
						$abuse_question_content = str_replace('{sender name}', $sender_name, $abuse_question_content);
						$abuse_question_content = str_replace('{sitename}', $this->CFG['site']['name'], $abuse_question_content);
						$abuse_question_content = str_replace('{question asked}', '<strong>' . $this->question_details['question'] . '</strong>', $abuse_question_content);
						$question_link = getUrl($this->CFG['site']['url'] . 'answer.php?qid=' . $this->fields_arr['qid'] . '/', $this->CFG['site']['url'] . 'view/answers/' . $this->fields_arr['qid'] . '/', false);
						$abuse_question_content = str_replace('{link}', '<a href="' . $question_link . '">' . $question_link . '</a>', $abuse_question_content);
						$this->_sendMail($asker_details['email'], $abuse_question_subject, nl2br($abuse_question_content), $this->CFG['site']['noreply_name'], $this->CFG['site']['noreply_email']);
				}
		}
		public function sendAbuseMailToAnswerer()
		{
				$email_options = $this->getEmailOptionsOfUser($this->answer_details['user_id']);
				if ($email_options['abuse_mail'] == 'Yes')
				{
						$answerer_details = $this->getUserDetailsFromUsersTable($this->CFG['db']['tbl']['users'], $this->answer_details['user_id']);
						$abuse_answers_subject = str_replace('{username}', $answerer_details['name'], $this->LANG['abuse_answer_email_subject']);
						$receiver_url = getUrl($this->CFG['site']['url'] . 'myanswers.php?uid=' . $this->answer_details['user_id'], $this->CFG['site']['url'] . 'my/answers/' . $this->answer_details['user_id'], false);
						$abuse_answers_content = str_replace('{username}', '<a href="' . $receiver_url . '/">' . $answerer_details['name'] . '</a>', $this->LANG['abuse_answer_email_content']);
						$sender_url = getUrl($this->CFG['site']['url'] . 'myanswers.php?uid=' . $this->CFG['user']['user_id'], $this->CFG['site']['url'] . 'my/answers/' . $this->CFG['user']['user_id'] . '/', false);
						$sender_name = '<a href="' . $sender_url . '">' . $this->CFG['user']['name'] . '</a>';
						$abuse_answers_content = str_replace('{sender name}', $sender_name, $abuse_answers_content);
						$abuse_answers_content = str_replace('{sitename}', $this->CFG['site']['name'], $abuse_answers_content);
						$abuse_answers_content = str_replace('{question asked}', '<strong>' . $this->question_details['question'] . '</strong>', $abuse_answers_content);
						$abuse_answers_content = str_replace('{question reply}', nl2br($this->answer_details['answer']), $abuse_answers_content);
						$question_link = getUrl($this->CFG['site']['url'] . 'answer.php?qid=' . $this->fields_arr['qid'] . '/', $this->CFG['site']['url'] . 'view/answers/' . $this->fields_arr['qid'] . '/', false);
						$abuse_answers_content = str_replace('{link}', '<a href="' . $question_link . '">' . $question_link . '</a>', $abuse_answers_content);
						$this->_sendMail($answerer_details['email'], $abuse_answers_subject, nl2br($abuse_answers_content), $this->CFG['site']['noreply_name'], $this->CFG['site']['noreply_email']);
				}
		}
		private function _sendMail($to_email, $subject, $body, $sender_name, $sender_email)
		{
				$mail = new PHPMailer();
				$mail->AddAddress($to_email);
				$mail->FromName = $sender_name;
				$mail->From = $mail->Sender = $sender_email;
				$mail->Subject = $subject;
				$mail->Body = $body;
				$mail->IsMail();
				$mail->IsHTML(true);
				return ($mail->Send());
		}
		public function updateQuestionVideoStatus($video_id)
		{
				if (!$video_id) return;
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['ans_video'] . ' SET video_status=\'Deleted\'' . ' WHERE video_id=' . $this->dbObj->Param($video_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($video_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function updateQuestionAudioStatus($audio_id)
		{
				if (!$audio_id) return;
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['ans_audio'] . ' SET audio_status=\'Deleted\'' . ' WHERE audio_id=' . $this->dbObj->Param($audio_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($audio_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function updateAnswerVideoStatus($video_id)
		{
				if (!$video_id) return;
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['ans_video'] . ' SET video_status=\'Deleted\'' . ' WHERE video_id=' . $this->dbObj->Param($video_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($video_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($this->dbObj->Affected_Rows())
				{
						$sql = 'SELECT content_id FROM ' . $this->CFG['db']['tbl']['ans_video'] . ' WHERE video_id=' . $this->dbObj->Param($video_id);
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($video_id));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
						$row = $rs->FetchRow();
						$sql = 'UPDATE ' . $this->CFG['db']['tbl']['answers'] . ' SET' . ' video_id=0 WHERE' . ' ans_id=' . $this->dbObj->Param('ans_id');
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($row['content_id']));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
						$sql = 'SELECT ques_id FROM ' . $this->CFG['db']['tbl']['answers'] . ' WHERE' . ' ans_id=' . $this->dbObj->Param('ans_id');
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($row['content_id']));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
						$row = $rs->FetchRow();
						$sql = 'UPDATE ' . $this->CFG['db']['tbl']['questions'] . ' SET' . ' total_videos=total_videos-1 WHERE' . ' ques_id=' . $this->dbObj->Param('ques_id') . ' AND total_videos>0';
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($row['ques_id']));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				}
		}
		public function updateAnswerAudioStatus($audio_id)
		{
				if (!$audio_id) return;
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['ans_audio'] . ' SET audio_status=\'Deleted\'' . ' WHERE audio_id=' . $this->dbObj->Param($audio_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($audio_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($this->dbObj->Affected_Rows())
				{
						$sql = 'SELECT content_id FROM ' . $this->CFG['db']['tbl']['ans_audio'] . ' WHERE audio_id=' . $this->dbObj->Param($audio_id);
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($audio_id));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
						$row = $rs->FetchRow();
						$sql = 'UPDATE ' . $this->CFG['db']['tbl']['answers'] . ' SET' . ' audio_id=0 WHERE' . ' ans_id=' . $this->dbObj->Param('ans_id');
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($row['content_id']));
						$sql = 'SELECT ques_id FROM ' . $this->CFG['db']['tbl']['answers'] . ' WHERE' . ' ans_id=' . $this->dbObj->Param('ans_id');
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($row['content_id']));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
						$row = $rs->FetchRow();
						$sql = 'UPDATE ' . $this->CFG['db']['tbl']['questions'] . ' SET' . ' total_audios=total_audios-1 WHERE' . ' ques_id=' . $this->dbObj->Param('ques_id') . ' AND total_audios>0';
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($row['ques_id']));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				}
		}
}
$answers = new AnswerFormHandler();
$answers->setCfgLangGlobal($CFG, $LANG);
$answers->setPageBlockNames(array('form_search', 'form_add', 'form_abuse_question', 'form_abuse_answer', 'form_confirm', 'form_question', 'form_answers', 'msg_form_error', 'msg_form_success', 'form_information', 'form_best_answer'));
$answers->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$answers->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$answers->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$answers->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$answers->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$answers->setFormField('qid', '');
$answers->setFormField('aid', '');
$answers->setFormField('viid', '');
$answers->setFormField('auid', '');
$answers->setFormField('search_name', '');
$answers->setFormField('search_cat', '');
$answers->setFormField('answer', '');
$answers->setFormField('source', '');
$answers->setFormField('action', '');
$answers->setFormField('act', '');
$answers->setFormField('reason', '');
$answers->setFormField('str', '');
$answers->setFormField('msg', '');
$answers->numpg = $CFG['data_tbl']['numpg'];
$answers->setFormField('start', 0);
$answers->setFormField('numpg', $CFG['data_tbl']['numpg']);
$answers->setMinRecordSelectLimit($CFG['data_tbl']['min_record_select_limit']);
$answers->setMaxRecordSelectLimit($CFG['data_tbl']['max_record_select_limit']);
$answers->setNumPerPageListArr($CFG['data_tbl']['numperpage_list_arr']);
$answers->setTableNames(array());
$answers->setReturnColumns(array());
$answers->setFormField('orderby_field', '');
$answers->setFormField('orderby', '');
$pagename = 'View Answers';
$answers->setDBObject($db);
$answers->sanitizeFormInputs($_REQUEST);
$answers->setAllPageBlocksHide();
$answers->updateQuestionViews();
$title = $LANG['open_question'];
$title_image = 'open_question';
if ($answers->chkIsValidQuestion())
{
		if ($answers->question_details['status'] == 'Resolved')
		{
				$title = $LANG['resolved_question'];
				$title_image = 'resolved_question';
		}
		else
		{
				$title = $LANG['open_question'];
				$title_image = 'open_question';
		}
		$answers->setPageBlockShow('form_question');
		$answers->setPageBlockShow('form_answers');
		$hidden_array = array();
		if ($answers->isFormGETed($_GET, 'action'))
		{
				switch ($answers->getFormField('action'))
				{
						case 'reply':
								if ($answers->question_details['status'] == 'Open')
								{
										$answers->setPageBlockHide('form_question');
										$answers->setPageBlockHide('form_answers');
										$answers->setPageBlockShow('form_add');
										$title = $LANG['what_is_your_answer'];
										$title_image = 'what_is_your_answer';
								}
								else
								{
										$answers->setPageBlockShow('msg_form_error');
										$answers->setCommonErrorMsg($LANG['answers_err_not_open']);
								}
								break;
						case 'abusequestion':
								if ($answers->isValidFormInputs() and $answers->question_details['user_id'] != $CFG['user']['user_id'])
								{
										$answers->setPageBlockHide('form_question');
										$answers->setPageBlockHide('form_answers');
										$answers->setPageBlockShow('form_abuse_question');
										$title = $LANG['report_abuse'];
										$title_image = 'report_abuse';
								}
								else
								{
										$answers->setAllPageBlocksHide();
										$answers->setPageBlockShow('msg_form_error');
										$answers->setCommonErrorMsg($LANG['answers_err_invalid_action']);
								}
								break;
						case 'abuseanswer':
								if ($answers->isValidFormInputs() and $answers->answer_details['user_id'] != $CFG['user']['user_id'])
								{
										$answers->setPageBlockHide('form_question');
										$answers->setPageBlockHide('form_answers');
										$answers->setPageBlockShow('form_abuse_answer');
										$title = $LANG['report_abuse'];
										$title_image = 'report_abuse';
								}
								else
								{
										$answers->setAllPageBlocksHide();
										$answers->setPageBlockShow('msg_form_error');
										$answers->setCommonErrorMsg($LANG['answers_err_invalid_action']);
								}
								break;
						case 'edit':
								$answers->chkIsNotEmpty('aid', $LANG['answers_err_tip_compulsory']);
								if ($answers->isValidFormInputs())
								{
										$action = 'delete_answer';
										$hidden_array = array('aid');
										$confirm_message = $LANG['confirm_delete_message'];
										$answers->setPageBlockShow('form_confirm');
								}
								else
								{
										$answers->setAllPageBlocksHide();
										$answers->setPageBlockShow('msg_form_error');
										$answers->setPageBlockShow('form_question');
										$answers->setPageBlockShow('form_answers');
										$answers->setCommonErrorMsg($LANG['answers_err_invalid_action']);
								}
								break;
				}
		}
		if ($answers->isFormPOSTed($_POST, 'delete_add'))
		{
				switch ($answers->getFormField('act'))
				{
						case 'delete':
								$answers->chkIsNotEmpty('aid', $LANG['answers_err_tip_compulsory']);
								$ans_array = explode(',', $answers->getFormField('aid'));
								foreach ($ans_array as $value)
								{
										if ($answers->chkIsValidAnswer($value) and $answers->isValidFormInputs())
										{
												$answers->deleteAnswers($CFG['db']['tbl']['questions'], $CFG['db']['tbl']['answers'], $CFG['db']['tbl']['users_ans_log'], $value);
										}
								}
								$answers->setPageBlockShow('msg_form_success');
								$answers->setCommonErrorMsg($LANG['answers_deleted_successfully']);
								break;
						case 'deleteQuestion':
								$answers->deleteQuestion();
								Redirect2URL($CFG['site']['relative_url'] . 'manageAnswers.php?delmsg=1');
								break;
						case 'deleteQuestionVideo':
								$answers->deleteQuestionVideo();
								Redirect2URL($CFG['site']['relative_url'] . 'viewAnswers.php?qid=' . $answers->getFormField('qid') . '&msg=delquesvideo');
								break;
						case 'deleteQuestionAudio':
								$answers->deleteQuestionAudio();
								Redirect2URL($CFG['site']['relative_url'] . 'viewAnswers.php?qid=' . $answers->getFormField('qid') . '&msg=delquesaudio');
								break;
						case 'deletevideo':
								$answers->chkIsNotEmpty('aid', $LANG['answers_err_tip_compulsory']);
								if ($answers->isValidFormInputs())
								{
										$answers->updateAnswerVideoStatus($answers->getFormField('aid'));
										$answers->setPageBlockShow('msg_form_success');
										$answers->setCommonErrorMsg($LANG['answers_video_deleted_successfully']);
								}
								else
								{
										$answers->setPageBlockShow('msg_form_error');
								}
								break;
						case 'deleteaudio':
								$answers->chkIsNotEmpty('aid', $LANG['answers_err_tip_compulsory']);
								if ($answers->isValidFormInputs())
								{
										$answers->updateAnswerAudioStatus($answers->getFormField('aid'));
										$answers->setPageBlockShow('msg_form_success');
										$answers->setCommonErrorMsg($LANG['answers_audio_deleted_successfully']);
								}
								else
								{
										$answers->setPageBlockShow('msg_form_error');
								}
								break;
						case 'deleteBestAnswer':
								$answers->removeBestAnswer();
								$answers->setPageBlockShow('msg_form_success');
								$answers->setCommonErrorMsg($LANG['best_answers_deleted_successfully']);
								Redirect2URL($CFG['site']['relative_url'] . 'viewAnswers.php?qid=' . $answers->getFormField('qid') . '&msg=removebestans');
								break;
						case 'deleteAnswer':
								if ($answers->chkIsValidAnswer($answers->getFormField('aid')) and $answers->isValidFormInputs())
								{
										$answers->deleteAnswers($CFG['db']['tbl']['questions'], $CFG['db']['tbl']['answers'], $CFG['db']['tbl']['users_ans_log'], $answers->getFormField('aid'));
										$answers->removeBestAnswer();
								}
								$answers->setPageBlockShow('msg_form_success');
								$answers->setCommonErrorMsg($LANG['answers_deleted_successfully']);
								Redirect2URL($CFG['site']['relative_url'] . 'viewAnswers.php?qid=' . $answers->getFormField('qid') . '&msg=deleteans');
								break;
						case 'bestanswer':
								$answers->chkIsNotEmpty('aid', $LANG['answers_err_tip_compulsory']);
								if ($answers->isValidFormInputs() and $CFG['user']['user_id'] == $answers->question_details['user_id'] and $answers->question_details['status'] == 'Open' and $answers->question_details['best_ans_id'] == 0)
								{
										$answers->updateBestAnswer();
										$answers->setPageBlockShow('msg_form_success');
										$answers->setPageBlockShow('form_question');
										$answers->setPageBlockShow('form_answers');
										$answers->setCommonErrorMsg($LANG['answers_best_answer_added_successfully']);
								}
								else
								{
										$answers->setPageBlockShow('msg_form_error');
								}
								break;
						case 'resolve':
								$answers->resolveQuestion();
								$answers->question_details['status'] = 'Resolved';
								$answers->setPageBlockShow('msg_form_success');
								$answers->setCommonErrorMsg($LANG['answers_resolved_successfully']);
								Redirect2URL($CFG['site']['relative_url'] . 'viewAnswers.php?qid=' . $answers->getFormField('qid') . '&msg=resolved');
				}
		}
		if ($answers->isFormPOSTed($_POST, 'abuse_question'))
		{
				$answers->chkIsNotEmpty('reason', $LANG['answers_err_tip_compulsory']);
				if ($answers->isValidFormInputs() and $answers->question_details['user_id'] != $CFG['user']['user_id'])
				{
						$answers->updateAbuseQuestion();
						$answers->setPageBlockShow('msg_form_success');
						$answers->setPageBlockShow('form_question');
						$answers->setPageBlockShow('form_answers');
						$answers->setCommonErrorMsg($LANG['answers_question_abused_successfully']);
						Redirect2URL($CFG['site']['relative_url'] . 'viewAnswers.php?qid=' . $answers->getFormField('qid') . '&msg=2');
				}
				else
				{
						$answers->setPageBlockShow('msg_form_error');
				}
		}
		if ($answers->isFormPOSTed($_POST, 'abuse_answer'))
		{
				$answers->chkIsNotEmpty('reason', $LANG['answers_err_tip_compulsory']);
				if ($answers->isValidFormInputs() and $answers->answer_details['user_id'] != $CFG['user']['user_id'])
				{
						$answers->updateAbuseAnswer();
						$answers->setPageBlockShow('msg_form_success');
						$answers->setPageBlockShow('form_question');
						$answers->setPageBlockShow('form_answers');
						$answers->setCommonErrorMsg($LANG['answers_answer_abused_successfully']);
						Redirect2URL($CFG['site']['relative_url'] . 'viewAnswers.php?qid=' . $answers->getFormField('qid') . '&msg=3');
				}
				else
				{
						$answers->setPageBlockShow('msg_form_error');
				}
		}
		if ($answers->isFormPOSTed($_POST, 'submit'))
		{
				$answers->chkIsNotEmpty('answer', $LANG['answers_err_tip_compulsory']);
				if ($answers->question_details['status'] != 'Open')
				{
						$answers->setPageBlockShow('msg_form_error');
						$answers->setCommonErrorMsg($LANG['answers_err_not_open']);
				}
				if ($answers->isValidFormInputs())
				{
						$answers->addAnswer();
						$answers->setCommonErrorMsg($LANG['answers_added_successfully']);
						$answers->setPageBlockShow('msg_form_success');
						Redirect2URL($CFG['site']['relative_url'] . 'viewAnswers.php?qid=' . $answers->getFormField('qid') . '&msg=1');
				}
				else
				{
						$answers->setPageBlockShow('msg_form_error');
				}
		}
		if ($answers->isFormPOSTed($_POST, 'cancel'))
		{
				Redirect2URL($CFG['site']['relative_url'] . 'viewAnswers.php?qid=' . $answers->getFormField('qid'));
		}
		if ($answers->isFormGETed($_GET, 'msg'))
		{
				switch ($answers->getFormField('msg'))
				{
						case 2:
								$answers->setCommonErrorMsg($LANG['answers_question_abused_successfully']);
								break;
						case 3:
								$answers->setCommonErrorMsg($LANG['answers_answer_abused_successfully']);
								break;
						case 4:
								$answers->setCommonErrorMsg($LANG['answers_question_edited_successfully']);
								break;
						case 'removebestans':
								$answers->setCommonErrorMsg($LANG['best_answers_deleted_successfully']);
								break;
						case 'deleteans':
								$answers->setCommonErrorMsg($LANG['answers_deleted_successfully']);
								break;
						case 'resolved':
								$answers->setCommonErrorMsg($LANG['answers_resolved_successfully']);
								break;
						case 'delquesvideo':
								$answers->setCommonErrorMsg($LANG['question_video_deleted_successfully']);
								break;
						case 'delquesaudio':
								$answers->setCommonErrorMsg($LANG['question_audio_deleted_successfully']);
								break;
						default:
								$answers->setCommonErrorMsg($LANG['answers_added_successfully']);
								break;
				}
				$answers->setPageBlockShow('msg_form_success');
		}
}
else
{
		$answers->setPageBlockShow('msg_form_error');
}
$CFG['mods']['is_include_only']['non_html_header_files'] = false;
$CFG['mods']['is_include_only']['html_header'] = true;
require ($CFG['site']['project_path'] . 'common/application_top.inc.php');
?>
<script type="text/javascript" language="javascript">
	var block_arr= new Array('selMsgConfirm','selMsgConfirm1');
</script>
<div id="selListAll">
	<h2 class="clsOpenQuestion"><?php echo $title; ?></h2>
	<div id="selMisNavLinks">
	<ul>
		<li><a href="<?php echo $CFG['site']['relative_url']; ?>manageAnswers.php"><?php echo $LANG['back_to_questions']; ?></a></li>
	</ul>
	</div>
<?php

if ($answers->isShowPageBlock('msg_form_error'))
{
?>
    	<div id="selMsgError">
      		<p>
<?php
		echo $LANG['answers_err_sorry'] . ' ' . $answers->getCommonErrorMsg();
?>
      		</p>
    	</div>
<?php
}
if ($answers->isShowPageBlock('msg_form_success'))
{
?>
	    <div id="selMsgSuccess">
	      	<p>
<?php
		echo $answers->getCommonErrorMsg();
?>
	      	</p>
	    </div>
    <?php
}
if ($answers->isShowPageBlock('form_question'))
{
?>
<div id="selMsgConfirm" class="selMsgConfirm" style="display:none;position:absolute;">
<h3 id="confirmation_msg"></h3>
<form name="deleteForm" id="deleteForm" method="post" action="viewAnswers.php?qid=<?php echo $answers->getFormField('qid'); ?>" autocomplete="off">
	<table >
	  	<tr>
        	<td>
			  	<input type="submit" class="clsSubmitButton" name="delete_add" id="delete_add" value="<?php echo 'Yes'; ?>" tabindex="<?php echo $answers->getTabIndex(); ?>" /> &nbsp;
              	<input type="button" class="clsCancelButton" name="cancel" id="cancel" value="<?php echo 'No'; ?>" tabindex="<?php echo $answers->getTabIndex(); ?>" onClick="return hideAllBlocks();" />
              	<input type="hidden" name="aid" id="aid" />
				<input type="hidden" name="act" id="act" />
				<?php $answers->populateHidden(array()); ?>
			</td>
      	</tr>
	</table>
</form>
</div>
<?php
}
if ($answers->isShowPageBlock('form_confirm')) $answers->displayConfirmOption($action, $confirm_message, $hidden_array);
if ($answers->isShowPageBlock('form_search')) $answers->displaySearchOption();
if ($answers->isShowPageBlock('form_question')) $answers->displayQuestionDetails();
if ($answers->isShowPageBlock('form_answers'))
{
		$answers->setTableNames(array($CFG['db']['tbl']['answers'] . ' as a', $CFG['db']['tbl']['users'] . ' as u'));
		$answers->setReturnColumns(array('a.ans_id, a.user_id, a.answer, a.video_id, a.audio_id, a.source, a.abuse_count, TIMEDIFF(NOW(), date_answered) as date_answered' . ', u.' . $answers->getUserTableField('user_id') . ' as img_user_id, ' . $answers->getUserTableFields(array('image_path', 'gender', 't_height', 't_width', 'photo_server_url', 'photo_ext'), false) . $answers->getUserTableField('name') . ' as answered_by'));
		$answers->setFormField('orderby_field', 'a.ans_id');
		$answers->setFormField('orderby', 'DESC');
		$answers->buildSelectQuery();
		$answers->buildConditionQuery();
		$answers->buildSortQuery();
		$answers->buildQuery();
		$answers->executeQuery();
		$answers->displayAllAnswers();
}
if ($answers->isShowPageBlock('form_add')) $answers->replyAnswers();
if ($answers->isShowPageBlock('form_abuse_question')) $answers->abuseQuestion();
if ($answers->isShowPageBlock('form_abuse_answer')) $answers->abuseAnswer();
?>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>
