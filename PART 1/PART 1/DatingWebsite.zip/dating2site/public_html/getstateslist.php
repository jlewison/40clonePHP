<?php

include_once('init.php');

$countrycode=$_GET['country_code'];
$all=$_GET['all'];
$order='name';
$states = array();

$sql = 'select code, name from ! where countrycode = ? order by !';

$recs = $db->getAll($sql, array( STATES_TABLE, $countrycode, $order ) );

foreach ($recs as $rec) {

	$states[$rec['code']] = $rec['name'];

}

$recs = $states;

$states=array();

if ($all == 'Y' or $all == 'y') {

	$states['AA'] = ($recs['AA']!='')?$recs['AA']:'All States';

}
foreach ($recs as $key => $val) {

	if ($key != 'AA') {

		$states[$key] = $val;

	}
}

$t->assign('lookstates', $states);

$t->display('getstateslist.tpl');
?>