function onHover(evt,objectid) {
	elemSubMenu=document.getElementById('movie'+objectid);
	elemSubMenu.style.zIndex = 10000;
	try {
		if (evt.pageX || evt.pageY) {
			elemSubMenu.style.top = (evt.pageY+4) + "px";
			elemSubMenu.style.left = evt.pageX + "px";
		} else {
			elemSubMenu.style.top = (evt.clientY + document.body.scrollTop) + "px";
			elemSubMenu.style.left = (evt.clientX + document.body.scrollLeft) + "px";
		}
	} catch (e) {
	}
	elemSubMenu.style.display = 'block';
}
function unHover(objectid) {
	elemSubMenu=document.getElementById('movie'+objectid);
	elemSubMenu.style.display = 'none';
	elemSubMenu.style.zIndex = -1;
}

/* clear field value function: removes the default value onfocus, and adds back if nothing entered */

function fieldClear(obj) {
	if(obj.Val) {
		if (obj.value == '') { 
			obj.value = obj.Val;
			obj.Val = null;
			obj.first = null;
		} else {
			obj.Val = null;
		}
	} else if (!obj.first) { 
		obj.Val = obj.value;
		obj.value = ''; 
		obj.first = 'true';
	} 
}

function addBookmark(url){
	title = document.getElementById('title').text;
	try {
	if(window.sidebar){ // Firefox
		window.sidebar.addPanel(title, url,'');
	} else if(window.opera){ //Opera
		var a = document.createElement("A");
		a.rel = "sidebar";
		a.target = "_search";
		a.title = title;
		a.href = url;
		a.click();
	} else if(document.all){ //IE
		window.external.AddFavorite(url, title);
	}
	} catch (e) {
		alert("We're sorry, browser could not auto-add bookmark. Please add the bookmark manually")
	}
}