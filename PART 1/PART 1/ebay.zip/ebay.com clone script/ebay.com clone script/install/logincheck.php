<?php //00461
// Copyright Notice
// Web Site URL:  http://www.zeeways.com
// Script Owner eMail: mail@zeeways.com
// Date: April, 2007
// Script Name: Zeeways Auction Website PHP Script
// Copyright Details: This script is not free.  Do not Remove this Copy Right notice.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the site administrator.');exit(199);
?>
4+oV57UCGzk9QxWSG3RM+8MnG6HI6s7szN0oU+4Mo6GQ/keUmg7uFkC+dvDFDIlxfya9gBsLmeMz
8IOikCK5ccKwq6pziudsJJsVlj1W9VfGy0ffVV+b0gby8hM2QdazGSa1tDObyk3luIjJPpwlClOd
eSUsdf25zqBLhn4zb9UYAUJlJYprcXmL138qzYrpU3OZE9nxHEVQW4KqO61dN+W9YHcHNZf5WelB
HIJOvFM6idfpHp1YAM2M79QcD0nCS/Sjhab+jffm4OFzOLsssDqpfmV+J3MS0HaF5IOXKomMLQp3
8MWHKyoGCFXrRsYaV+o42fQOnDkouCiYQEE5Fkp6N9ND7jYEg5IN2BSTEdwJ9SHGyRRwdm9HISEv
UA6k2YkgkH+4gJLBBrGZNFGeALD3ZdO+vjIj7C+99fY30e2njFDJpSMb6gWdIXuApok5awcfUlHF
wrXGkRHCoz8zbdmWXJlsf37O3G53DNXkQXlxutsyxWexZAOj+TK9ZptxnaB9Kl3Wp6mD1fER1uME
Q4/sTKCNbIozcFO1Z+l9vlY8W/MgzVx3KGVo/wVfJJxxsUExlXOz1Ip+k9K1aJc7X7s+kxMb8ZCg
l6nUkF6aeKlbLzODcSqbO7lD6ARhvp8QVJfPoCLRfADLufEAN1AlMAIJRhA1hC30QFJSJfgz6eB5
0dtInPKOBbUvmzKob7c3r3CMs8z9B0y5CCXylR9OBrFWXrTYxXtRlmX4fgUTL8ESWNwaY9kk3n6q
2BMG4XKXYcrqLzPBZddUNCSGCnrmwzfpdnlBhcuhG56HgKtyelF157e=