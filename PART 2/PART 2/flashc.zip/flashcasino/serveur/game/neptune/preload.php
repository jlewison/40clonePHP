<?
Error_Reporting(E_ALL & ~E_NOTICE);
unset($l); 


session_start();
session_register($l);
if(!isset($l)){ 
header("Location: ../../login.php"); 
exit; 
}
include ("../../../setup.php");


$result=mysql_query("select * from users where login='$l'");
$row=mysql_fetch_array($result);


?>











<?
echo "Reg=0&GameName=neptunesworld&SWFname=neptunesworld_14.swf&HelpFile=/freegames/istruzioni/[LINGUA]/istruzioni.asp?game=neptunesworld&credits=$row[3]&Error=0&l=<? echo $l; ?>";
?>