<?php

   class articlesData extends Data {

      var $table = ARTICLES_TABLE;

      var $config = array (
  'table' => ARTICLES_TABLE,
  'idField' => 'articleid',
  'addedMsg' => 'Osdate Articles %s Added',
  'added_err' => 'Can\\\'t Add Osdate Articles',
  'editMsg' => 'Osdate Articles %s Updated',
  'editErr' => 'Can\\\'t Update Osdate Articles',
  'delErr' => 'Can\\\'t Delete Osdate Articles',
  'delMsg' => 'Osdate Articles %s Deleted',
  'blankErr' => 'Osdate Articles Empty',
  'fields' => 
  array (
    'dat' => 
    array (
      'name' => 'dat',
      'description' => 'Dat',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'title' => 
    array (
      'name' => 'title',
      'description' => 'Title',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 255,
      'blank_ok' => 1,
      'duplicate_ok' => 1,
    ),
    'text' => 
    array (
      'name' => 'text',
      'description' => 'Text',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 16777215,
      'blank_ok' => 1,
      'duplicate_ok' => 1,
    ),
  ),
);   

      function articlesData() {
      
         $this->Data($this->config);
      }
   }

?>
