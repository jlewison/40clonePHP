<?php require_once('../Connections/apound.php'); include('../settings.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}
?>
<?php
// *** Validate request to login to this site.
if (!isset($_SESSION)) {
  session_start();
}

$loginFormAction = $_SERVER['PHP_SELF'];
if (isset($_GET['accesscheck'])) {
  $_SESSION['PrevUrl'] = $_GET['accesscheck'];
}

if (isset($_POST['name'])) {
  $loginUsername=$_POST['name'];
  $password=$_POST['pass'];
  $MM_fldUserAuthorization = "";
  $MM_redirectLoginSuccess = "home.php";
  $MM_redirectLoginFailed = "error.php";
  $MM_redirecttoReferrer = false;
  mysql_select_db($database_apound, $apound);
  
  $LoginRS__query=sprintf("SELECT name, pass FROM ig_admin WHERE name=%s AND pass=%s",
    GetSQLValueString($loginUsername, "text"), GetSQLValueString($password, "text")); 
   
  $LoginRS = mysql_query($LoginRS__query, $apound) or die(mysql_error());
  $loginFoundUser = mysql_num_rows($LoginRS);
  if ($loginFoundUser) {
     $loginStrGroup = "";
    
    //declare two session variables and assign them
    $_SESSION['MM_Username'] = $loginUsername;
    $_SESSION['MM_UserGroup'] = $loginStrGroup;	      

    if (isset($_SESSION['PrevUrl']) && false) {
      $MM_redirectLoginSuccess = $_SESSION['PrevUrl'];	
    }
    header("Location: " . $MM_redirectLoginSuccess );
  }
  else {
    header("Location: ". $MM_redirectLoginFailed );
  }
}
?>
<?php require_once('../Connections/apound.php');
include('../settings.php');?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Link Bid Script - Admin Control Panel</title>
<link rel="shortcut icon" href="img/favicon.ico" />
<link rel="stylesheet" type="text/css" href="admin.css" />
</head>

<body>
<div class="login-top">
	<div class="login-logo"><a href="../linkadmin/home.php"><img src="img/login-top.gif" alt="Link Bid Script Admin Home" /></a></div>
	<div class="login-form">
	<form name="form1" method="POST" action="<?php echo $loginFormAction; ?>">
		<table valign="top"  border="0" align="center" cellpadding="2" cellspacing="1">
			<tr>
				<td>Username:</td>
				<td><input name="name" type="text" class="login-inp" id="name" /></td>
			</tr>
			<tr>
				<td>Password:</td>
				<td><input name="pass" type="password" class="login-inp" id="pass"  /></td>
			</tr>
			<tr>
				<td colspan="2" align="right"><input name="Submit" type="submit" class="login-but" value="Login" /></td>
			</tr>
			<tr>
				<td style="padding:10px 0 0 0;"><a href="forgot.php">Forgotten password?</a></td>
				<td style="padding:10px 0 0 0;" align="right"><a href="../">Back to directory homepage</a></td>
			</tr>
		</table>
	</form>
	</div>
</div>
<div class="creds">&copy;<?php echo date("Y");?> <a href="http://www.linkbidscript.com/" target="_blank">Link Bid Script</a></div>
</body>
</html>
