<?php
	$template_info['name'] = 'yGet'; // do not use the _ character. use - instead
	$template_info['desc'] = 'yGet';
	$template_info['author'] = 'Pligg Team';
	$template_info['support'] = 'http://forums.pligg.com/yget/';
	$template_info['version'] = 0.990;
	$template_info['designed_for_pligg_version'] = '9.9.0';
?>
