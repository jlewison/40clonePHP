<?php

   class pollipsData extends Data {

      var $table = POLLIPS_TABLE;

      var $config = array (
  'table' => POLLIPS_TABLE,
  'idField' => 'osdate_pollips_id',
  'addedMsg' => 'Osdate Pollips %s Added',
  'added_err' => 'Can\\\'t Add Osdate Pollips',
  'editMsg' => 'Osdate Pollips %s Updated',
  'editErr' => 'Can\\\'t Update Osdate Pollips',
  'delErr' => 'Can\\\'t Delete Osdate Pollips',
  'delMsg' => 'Osdate Pollips %s Deleted',
  'blankErr' => 'Osdate Pollips Empty',
  'fields' => 
  array (
    'ip' => 
    array (
      'name' => 'ip',
      'description' => 'Ip',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 15,
      'blank_ok' => 1,
      'duplicate_ok' => 1,
    ),
    'pollid' => 
    array (
      'name' => 'pollid',
      'description' => 'Pollid',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 1,
      'duplicate_ok' => 1,
    ),
    'time' => 
    array (
      'name' => 'time',
      'description' => 'Time',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 1,
      'duplicate_ok' => 1,
    ),
  ),
);   

      function pollipsData() {
      
         $this->Data($this->config);
      }
   }

?>
