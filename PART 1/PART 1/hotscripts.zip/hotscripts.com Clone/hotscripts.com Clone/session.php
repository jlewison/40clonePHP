<?php
session_start();
session_register("userid");
session_register("name");
//session_register("ID");
//session_register("ID");
?>
