<div class="outer">
	<div class="leftContainer">
		<div class="header">
			<a href="<?php echo("$path");?>" title="Welcome to <?php echo("$sitetitle");?>!"><img class="hLogo" src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/logo.gif" alt="Welcome to <?php echo("$sitetitle");?>!" /></a>
		</div>
		<div class="nav">
			<a href="<?php echo("$path");?>"><?php echo("$lang_11");?></a>
			<a href="<?php echo("$path");?>new-links.php"><?php echo("$lang_12");?></a>
			<?php if($p_top == 'Y') { ?><a href="<?php echo("$path");?>links.php"><?php echo("$lang_13");?></a><?php } else {} ?>
			<a href="<?php echo("$path");?>submit.php?su_categ=<?php echo("$su_categ");?>"><?php echo("$lang_14");?></a>
			<a href="<?php echo("$path");?>contact.php"><?php echo("$lang_15");?></a>
			<?php if($p_terms == 'Y') { ?><a href="<?php echo("$path");?>terms.php"><?php echo("$lang_16");?></a><?php } else {} ?>
			<?php if($p_about == 'Y') { ?><a href="<?php echo("$path");?>about.php"><?php echo("$lang_80");?></a><?php } else {} ?>
            <a href="<?php echo("$path");?>tags/"><?php echo("$lang_181");?></a>
		</div>
		<div class="sideBox">
			<h2><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/categories.gif" alt="Categories" /></h2>
			<ul>
				<?php do { ?><li><a href="<?php echo("$path");?><?php echo $row_categRL['categseoname']; ?>/"><?php echo $row_categRL['categoryname']; ?></a></li><?php
				$row_categRL = mysql_fetch_assoc($categRL);
				if (!isset($nested_categRL)) { $nested_categRL= 1; }
				} while ($row_categRL);
				?><li><a style="font-weight:bold;" href="<?php echo("$path");?>contact.php"><?php echo("$lang_21");?></a></li>
			</ul>
			<div class="navL">
				<?php
				if($alphacat == 'Y') { ?>
				<a href="<?php echo("$path");?>0-9.html">#</a><a href="<?php echo("$path");?>A.html">A</a><a href="<?php echo("$path");?>B.html">B</a><a href="<?php echo("$path");?>C.html">C</a><a href="<?php echo("$path");?>D.html">D</a><a href="<?php echo("$path");?>E.html">E</a><a href="<?php echo("$path");?>F.html">F</a><a href="<?php echo("$path");?>G.html">G</a><a href="<?php echo("$path");?>H.html">H</a><a href="<?php echo("$path");?>I.html">I</a><a href="<?php echo("$path");?>J.html">J</a><a href="<?php echo("$path");?>K.html">K</a><a href="<?php echo("$path");?>L.html">L</a><a href="<?php echo("$path");?>M.html">M</a><a href="<?php echo("$path");?>N.html">N</a><a href="<?php echo("$path");?>O.html">O</a><a href="<?php echo("$path");?>P.html">P</a><a href="<?php echo("$path");?>Q.html">Q</a><a href="<?php echo("$path");?>R.html">R</a><a href="<?php echo("$path");?>S.html">S</a><a href="<?php echo("$path");?>T.html">T</a><a href="<?php echo("$path");?>U.html">U</a><a href="<?php echo("$path");?>V.html">V</a><a href="<?php echo("$path");?>W.html">W</a><a href="<?php echo("$path");?>X.html">X</a><a href="<?php echo("$path");?>Y.html">Y</a><a href="<?php echo("$path");?>Z.html">Z</a>
				<?php }
				elseif($alphacat == 'N') { ?>
				<?php }
				else { ?>
				<a href="<?php echo("$path");?>0-9.html">#</a><a href="<?php echo("$path");?>A.html">A</a><a href="<?php echo("$path");?>B.html">B</a><a href="<?php echo("$path");?>C.html">C</a><a href="<?php echo("$path");?>D.html">D</a><a href="<?php echo("$path");?>E.html">E</a><a href="<?php echo("$path");?>F.html">F</a><a href="<?php echo("$path");?>G.html">G</a><a href="<?php echo("$path");?>H.html">H</a><a href="<?php echo("$path");?>I.html">I</a><a href="<?php echo("$path");?>J.html">J</a><a href="<?php echo("$path");?>K.html">K</a><a href="<?php echo("$path");?>L.html">L</a><a href="<?php echo("$path");?>M.html">M</a><a href="<?php echo("$path");?>N.html">N</a><a href="<?php echo("$path");?>O.html">O</a><a href="<?php echo("$path");?>P.html">P</a><a href="<?php echo("$path");?>Q.html">Q</a><a href="<?php echo("$path");?>R.html">R</a><a href="<?php echo("$path");?>S.html">S</a><a href="<?php echo("$path");?>T.html">T</a><a href="<?php echo("$path");?>U.html">U</a><a href="<?php echo("$path");?>V.html">V</a><a href="<?php echo("$path");?>W.html">W</a><a href="<?php echo("$path");?>X.html">X</a><a href="<?php echo("$path");?>Y.html">Y</a><a href="<?php echo("$path");?>Z.html">Z</a>
				<?php } ?>			
			</div>
			<div class="clear"></div>
		</div>
		<div class="leftBottom"></div>
	</div>
	<div class="rightContainer">
		<div class="topBid">
			<div class="tContent">
				<div class="topBidPrev"><a href="<?php echo $row_top_BID['site']; ?>" target="_blank" title="<?php echo $row_top_BID['title']; ?>"><img src="http://open.thumbshots.org/image.aspx?url=<?php echo $row_top_BID['site']; ?>" alt="<?php echo $row_top_BID['title']; ?>" height="68" width="84" /></a></div>
				<div style="float:left; width:450px;">
					<h2>Top Bid</h2>
					<h3 style="text-align:center;"><?php echo $row_top_BID['title']; ?></h3>
					<p><?php echo $row_top_BID['descr1']; ?></p>
				</div>
				<div class="clear"></div>
			</div>
			<div class="cBottom"></div>
		</div>
		<div class="wBack">
			<h2>Welcome To <?php echo("$sitetitle");?></h2>
			<p><?php echo("$welcometext");?></p>
		</div>
		<div class="mainContainer">
			<div class="search">
				<img style="float:left;" src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/sLeft.gif" alt="search left" />
				<img style="float:right;" src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/sRight.gif" alt="search right" />
				<form name="form1sea" id="form1sea" method="post" action="<?php echo("$path");?>search.php">
					<input name="q" type="text" class="searchInput" onfocus="this.value='';" value=" <?php echo("$lang_19");?>" size="40" />
					<input type="submit" name="button" class="searchBtn" value="<?php echo("$lang_20");?>" />
				</form>
			</div>
