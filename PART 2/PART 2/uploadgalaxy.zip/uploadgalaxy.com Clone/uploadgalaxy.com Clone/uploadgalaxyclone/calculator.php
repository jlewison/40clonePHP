<?php
/**
* http://cpaint.sourceforge.net
* 
* released under the terms of the GPL
* see http://www.fsf.org/licensing/licenses/gpl.txt for details
* 
* @package    CPAINT
* @access     public
* @author     Paul Sullivan <wiley14@gmail.com>
* @author     Dominique Stender <dstender@st-webdevelopment.de>
* @copyright  Copyright (c) 2005 Paul Sullivan, Dominique Stender - http://cpaint.sourceforge.net
*/
include("cpaint/cpaint2.inc.php");

$cp = new cpaint();
$cp->register('add');
$cp->start();
$cp->return_data();

function add($name) {
        global $cp;
        $cp->set_id("response");
        $cp->set_data(filesize($name));
        return;
        }
?>
