<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<script language="javascript" src="js/cal2.js" type="text/javascript"></script>
<script language="javascript" src="js/cal_conf2.js" type="text/javascript"></script>
</head>


<body>
<form name="Form1">
<p class="bodytxt1">
<input id="txtStart" readOnly type="text" size="30" name="txtStart">

<A href="#" onclick="showCal('Calendar1');">
<IMG style="WIDTH: 24px; HEIGHT: 16px" height="16" alt="Click here and select your date" src="img4.jpg" width="24" border="0">
</A>
</p>
</form>
</body>
</html>
