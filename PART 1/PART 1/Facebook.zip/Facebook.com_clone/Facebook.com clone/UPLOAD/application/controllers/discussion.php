<?php

/**
 * discussion Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 12-01-2008
 */
class discussion extends Controller
{
		//Constructor
		function discussion()
		{
				parent::Controller();
				//check login
				loginRequired();
				//Load the language file
				$this->lang->load('discussion', $this->config->item('language_code'));
				//Load the discussion board model
				$this->load->model('discussionboardmodel');
		}
		//Default function
		function index()
		{
				redirect('welcome');
		}
		function view()
		{
				$postedFor = $this->uri->segment(3);
				$postedForId = $this->uri->segment(4);
				$topicId = ($this->uri->segment(5) == 0) ? false : $this->uri->segment(5);
				//If topic not available
				$canView = false;
				if ($topicId != false && $this->discussionboardmodel->isTopicExist($postedFor, $topicId) == false)
				{
						//Set the flash data
						$this->session->set_flashdata('flash_msg', 'You are not allowed to view this discussion board.');
						redirect('welcome');
				}
				if ($postedFor == 'network')
				{
						//Load the network model
						$this->load->model('networkmodel');
						$networkDetails = $this->networkmodel->getNetworkDetails($postedForId);
						if ($networkDetails['network_type'] == 'region')
						{
								$outputData['canPost'] = 0;
								$canView = true;
						}
						else
						{
								$canView = $this->networkmodel->isUserExist($postedForId, $this->session->userdata('user_id'));
								if ($canView == false) $this->session->set_flashdata('flash_msg', 'You are not allowed to view this discussion board as you are not a member of the network.'); //Set the flash data
								else  $outputData['canPost'] = 1;
						}
				} elseif ($postedFor == 'group')
				{
						$this->load->model('groupsmodel');
						$groupInfo = $this->groupsmodel->getInfo($postedForId);
						if (count($groupInfo) > 0)
						{
								$isMember = $this->groupsmodel->isGroupMember($postedForId, $this->session->userdata('user_id'));
								if ($isMember == 1) $canView = true;
						}
				}
				if (trim($postedFor) != '' && trim($postedForId) != '' && $canView == true)
				{
						$outputData['currTab'] = 'view';
						$outputData['postedFor'] = $postedFor;
						$outputData['postedForId'] = $postedForId;
						$outputData['topicId'] = $topicId;
						//Load the pagination model
						$this->load->model('paginationmodel');
						$perPage = $this->paginationmodel->getPerPage('discussion_board');
						if ($topicId == false)
						{
								$start = (trim($this->uri->segment(6)) != '' && is_numeric($this->uri->segment(6)) && $this->uri->segment(6) > 0) ? $this->uri->segment(6) : 1;
								$start = ($start - 1) * $perPage;
						}
						else
						{
								$start = 0;
						}
						$outputData['topics'] = $this->discussionboardmodel->getDiscussionBoardTopic($postedFor, $postedForId, $topicId, '', 'date_added desc', $start, $perPage);
						$outputData['topicsCount'] = count($outputData['topics']);
						$outputData['topicsTotal'] = $this->discussionboardmodel->getDiscussionBoardTopicCount($postedFor, $postedForId, $topicId);
						if ($topicId != false)
						{
								$start = (trim($this->uri->segment(6)) != '' && is_numeric($this->uri->segment(6))) ? $this->uri->segment(6) : 1;
								$start = ($start - 1) * $perPage;
						}
						else  $start = 0;
						foreach ($outputData['topics'] as $currTopicId => $currTopicRow)
						{
								$outputData['topics'][$currTopicId]['posts'] = $this->discussionboardmodel->getDiscussionBoardPost($currTopicId, '', 'posted_date desc', $start, $perPage);
								$outputData['topics'][$currTopicId]['postsCount'] = count($outputData['topics'][$currTopicId]['posts']);
								$outputData['topics'][$currTopicId]['postsTotal'] = $this->discussionboardmodel->getDiscussionBoardPostCount($currTopicId);
								$recentPost = current($outputData['topics'][$currTopicId]['posts']);
								$outputData['topics'][$currTopicId]['last_updated_by'] = $recentPost['username'];
						}
						if ($topicId == false)
						{
								//For pagination
								$outputData['currentPage'] = (trim($this->uri->segment(6)) != '' && is_numeric($this->uri->segment(6))) ? $this->uri->segment(6) : 1;
								$outputData['totalPages'] = ($outputData['topicsTotal'] > 0) ? ceil($outputData['topicsTotal'] / $perPage) : 0;
								$outputData['pageUrl'] = base_url() . 'discussion/view/' . $postedFor . '/' . $postedForId . '/0/';
								$this->smartyextended->view('discussiontopic', $outputData);
						}
						else
						{
								//For pagination
								$outputData['currentPage'] = (trim($this->uri->segment(6)) != '' && is_numeric($this->uri->segment(6))) ? $this->uri->segment(6) : 1;
								$outputData['totalPages'] = ($outputData['topics'][$topicId]['postsTotal'] > 0) ? ceil($outputData['topics'][$topicId]['postsTotal'] / $perPage) : 0;
								$outputData['pageUrl'] = base_url() . 'discussion/view/' . $postedFor . '/' . $postedForId . '/' . $topicId . '/';
								$this->smartyextended->view('discussionpost', $outputData);
						}
				}
				else  redirect('welcome');
		}
		function create()
		{
				$postedFor = $this->uri->segment(3);
				$postedForId = $this->uri->segment(4);
				$topicId = $this->uri->segment(5);
				$parentId = ($this->uri->segment(6) == false && !is_numeric($this->uri->segment(6))) ? 0 : $this->uri->segment(6);
				$canPost = false;
				if ($postedFor == 'network')
				{
						//Load the network model
						$this->load->model('networkmodel');
						if ($this->networkmodel->isExist($postedForId))
								if ($this->networkmodel->isUserExist($postedForId, $this->session->userdata('user_id'))) $canPost = true;
				} elseif ($postedFor == 'group')
				{
						$this->load->model('groupsmodel');
						$groupInfo = $this->groupsmodel->getInfo($postedForId);
						if (count($groupInfo) > 0)
						{
								$isMember = $this->groupsmodel->isGroupMember($postedForId, $this->session->userdata('user_id'));
								if ($isMember == 1) $canPost = true;
						}
				}
				//If topic not available
				if ($topicId != '' && $this->discussionboardmodel->isTopicExist($postedFor, $topicId) == false) redirect('welcome');
				if (trim($postedFor) != '' && trim($postedForId) != '' && $canPost == true)
				{
						$outputData['currTab'] = 'create';
						$outputData['postedFor'] = $postedFor;
						$outputData['postedForId'] = $postedForId;
						$outputData['topicId'] = $topicId;
						$outputData['parentId'] = $parentId;
						//Load the validation lib
						$this->load->library('validation');
						//Apply the form rules
						if ($topicId == '') $this->_newDiscussionTopicFrmRules();
						else  $this->_newDiscussionPostFrmRules();
						if ($this->validation->run() == false)
						{
								//Oops! validation Error.
								$outputData['validationError'] = $this->validation->error_string;
								if ($topicId == '') $this->smartyextended->view('discussiontopic', $outputData);
								else
								{
										$outputData['topics'] = $this->discussionboardmodel->getDiscussionBoardTopic($postedFor, $postedForId, $topicId, '', 'date_added desc');
										$this->smartyextended->view('discussionpost', $outputData);
								}
						}
						else
						{
								if ($topicId == '')
								{
										$newTopicId = $this->discussionboardmodel->newDiscussionTopic($_POST);
										redirect('discussion/view/' . $postedFor . '/' . $postedForId . '#topic' . $newTopicId);
								}
								else
								{
										$newPostId = $this->discussionboardmodel->newDiscussionPost($_POST);
										//Load the user model
										$this->load->model('usermodel');
										$userFeedSettings = $this->usermodel->getUserFeedSetting();
										if (isset($userFeedSettings[7]) && $userFeedSettings[7] == 'yes')
										{
												//Load the minifeed model
												$this->load->model('minifeedmodel');
												$splVars = array('~~postedBy~~' => $this->session->userdata('username'), '~~postName~~' => (strlen($this->input->post('posted_content')) > 30) ? substr($this->input->post('posted_content'), 0, 27) . '...' : $this->input->post('posted_content'));
												$link1 = base_url() . 'discussion/view/' . $postedFor . '/' . $postedForId . '/' . $topicId . '#post' . $newPostId;
												$this->minifeedmodel->postMiniFeed('DISCUSSION_POST', $splVars, array($link1));
										}
										redirect('discussion/view/' . $postedFor . '/' . $postedForId . '/' . $topicId . '#post' . $newPostId);
								}
						}
				}
				else
				{
						if ($postedFor == 'network') redirect('network/view/' . $postedForId);
						elseif ($postedFor == 'group') redirect('groups/view/' . $postedForId);
						else  redirect('welcome');
				}
		}
		function editDiscussion()
		{
				$postedFor = $this->uri->segment(3);
				$postedForId = $this->uri->segment(4);
				$topicId = $this->uri->segment(5);
				$userId = $this->session->userdata('user_id');
				$canPost = false;
				if ($postedFor == 'network')
				{
						//Load the network model
						$this->load->model('networkmodel');
						if ($this->networkmodel->isExist($postedForId))
								if ($this->networkmodel->isUserExist($postedForId, $this->session->userdata('user_id'))) $canPost = true;
				}
				if ($canPost && $this->discussionboardmodel->isNetworkTopicExist($topicId, $userId))
				{
						//Load the discussion board model
						$this->load->model('discussionboardmodel');
						//Load the validation lib
						$this->load->library('validation');
						//Apply the form rules
						$this->_newDiscussionFrmRules();
						$outputData['networkDetails'] = $this->networkmodel->getNetworkDetails($networkId);
						$discussionTopic = $this->discussionboardmodel->getNetworkDiscussionTopic($networkId, $topicId);
						$discussionPost = array_pop($this->discussionboardmodel->getNetworkDiscussionPost($networkId, $topicId, 'posted_date desc', 0, 1));
						if ($this->validation->run() == false)
						{
								//Oops! validation Error.
								$outputData['validationError'] = $this->validation->error_string;
								if ($outputData['validationError'] == '')
								{
										$outputData['discussionTopic'] = $discussionTopic[$topicId];
										$outputData['discussionPost'] = $discussionPost;
								}
								$this->smartyextended->view('networkeditdiscussion', $outputData);
						}
						else
						{
								$this->discussionboardmodel->updateNetworkDiscussionTopic($topicId, $this->input->post('topic_title'));
								$this->discussionboardmodel->updateNetworkDiscussionPost($discussionPost['discussion_post_id'], $this->input->post('topic_content'));
								redirect('network/view/' . $networkId);
						}
				}
				else  redirect('network/browse');
		}
		function delete()
		{
				$postedFor = $this->uri->segment(3);
				$postedForId = $this->uri->segment(4);
				$topicId = $this->uri->segment(5);
				$postId = $this->uri->segment(6);
				if ($postId == false) $this->discussionboardmodel->deleteDiscussionTopic($topicId);
				else  $this->discussionboardmodel->deleteDiscussionPost($postId);
				redirect('discussion/view/' . $postedFor . '/' . $postedForId . '/' . $topicId);
		}
		function _newDiscussionTopicFrmRules()
		{
				$rules['discussion_topic'] = 'trim|required';
				$rules['posted_content'] = 'trim|required';
				$this->validation->set_rules($rules);
				$fields['discussion_topic'] = 'Topic Title';
				$fields['posted_content'] = 'Topic Content';
				$this->validation->set_fields($fields);
		}
		function _newDiscussionPostFrmRules()
		{
				$rules['posted_content'] = 'trim|required';
				$this->validation->set_rules($rules);
				$fields['posted_content'] = 'reply content';
				$this->validation->set_fields($fields);
		}
}
?>