<?php

/**
 * Login Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 2007-12-13
 */
class Register extends Controller
{
		//Constructor
		function Register()
		{
				parent::Controller();
				loggedInTakeIn();
				//Load the language file
				$this->lang->load('login', $this->config->item('language_code'));
				$this->lang->load('register', $this->config->item('language_code'));
		}
		function index()
		{
				//Load the required model, libraries, plugins.
				$this->load->model('registerModel');
				$this->load->model('usermodel');
				$this->load->library('validation');
				$this->load->plugin('captcha');
				//Set the form validation rules
				$this->_registerFrmRules();
				//Delete the old captcha images
				if (isset($_POST['time'])) @unlink(BASEPATH . '../application/images/captcha/' . $_POST['time'] . '.jpg');
				//Create the captcha image
				$randKey = rand();
				$vals = array('word' => $this->_randomPassword(5, $randKey), 'img_path' => BASEPATH . '../application/images/captcha/', 'img_url' => base_url() . 'application/images/captcha/', 'font_path' => BASEPATH . '../application/fonts/verdana.ttf', 'font_size' => 25, 'img_width' => 150, 'img_height' => 30, 'expiration' => 7200);
				$cap = create_captcha($vals);
				//set the output data
				$outputData['captcha'] = $cap;
				$outputData['randKey'] = $randKey;
				$outputData['lifeStage'] = $this->registerModel->getLifeStage();
				$outputData['schoolStatus'] = $this->registerModel->getSchoolStatus();
				$outputData['securityQuestions'] = $this->usermodel->getSecurityQuestions();
				//Do the validation
				if ($this->validation->run() == false || ($this->input->post('iam') == 3 && $this->input->post('high_school') == ''))
				{
						if ($this->input->post('iam') == 3 && $this->input->post('high_school') == '') $this->validation->error_string = $this->validation->error_string . $this->validation->_error_prefix . $this->lang->line('register_high_school_required') . $this->validation->_error_suffix;
						//Oops! validation Error.
						$outputData['validationError'] = $this->validation->error_string;
						$outputData['college_year'] = $this->input->post('college_Year') . '-' . date('m') . '-' . date('d');
						$outputData['highschool_year'] = $this->input->post('high_school_Year') . '-' . date('m') . '-' . date('d');
						$outputData['dateofbirth'] = $this->input->post('birthday_Year') . '-' . $this->input->post('birthday_Month') . '-' . $this->input->post('birthday_Day');
						$this->smartyextended->view('register', $outputData);
				}
				else
				{
						//Load the user model
						$this->load->model('usermodel');
						//Create the new user
						$newUserStatus = $this->usermodel->newUser($_POST);
						if ($newUserStatus != false)
						{
								//Registration completed succcess
								//Send the confirmation email
								$this->_sendConfirmEmail($this->input->post('register_name'), $this->input->post('register_email'));
								/* Send the confirmation E-Mail */
								$outputData['email'] = $this->input->post('register_email');
								$this->smartyextended->view('registersuccess', $outputData);
						}
						else
						{
								$outputData['validationError'] = $this->lang->line('register_error_email_exists');
								$this->smartyextended->view('register', $outputData);
						}
				}
		}
		function _registerFrmRules()
		{
				$rules['register_name'] = 'trim|required|alpha_dash_space|min_length[6]';
				$rules['iam'] = 'required';
				$rules['register_email'] = 'trim|required|valid_email';
				$rules['register_password'] = 'required|min_length[6]';
				$rules['birthday_Month'] = 'required|callback__dateCheck';
				$rules['security_answer'] = 'trim|required|alpha_dash_space|min_length[6]';
				$rules['captcha_response'] = 'required|callback__captcha_check';
				$rules['terms'] = 'required';
				$this->validation->set_rules($rules);
				$fields['register_name'] = $this->lang->line('register_fullname');
				$fields['iam'] = $this->lang->line('register_iam');
				$fields['register_email'] = $this->lang->line('register_email');
				$fields['register_password'] = $this->lang->line('register_password');
				$fields['security_answer'] = $this->lang->line('register_security_answer');
				$fields['captcha_response'] = $this->lang->line('register_captcha');
				$fields['terms'] = $this->lang->line('register_terms');
				$this->validation->set_fields($fields);
		}
		function _captcha_check($captcha)
		{
				$randomWord = $this->_randomPassword(5, $_POST['randKey']);
				if (trim($captcha) == '')
				{
						$this->validation->set_message('_captcha_check', $this->lang->line('register_the') . '%s' . $this->lang->line('register_requireds'));
						return false;
				} elseif ($randomWord != $this->input->post('captcha_response'))
				{
						$this->validation->set_message('_captcha_check', $this->lang->line('register_code_mismatch'));
						return false;
				}
				else
				{
						return true;
				}
		}
		function _dateCheck()
		{
				if (checkdate($this->input->post('birthday_Month'), $this->input->post('birthday_Day'), $this->input->post('birthday_Year')) == false)
				{
						$this->validation->set_message('_dateCheck', $this->lang->line('register_date_invalid'));
						return false;
				}
				else  return true;
		}
		function _randomPassword($length = 8, $seed = '')
		{
				$password = "";
				$possible = "0123456789";
				$i = 0;
				mt_srand(($seed == '') ? rand() : $seed);
				while ($i < $length)
				{
						$char = substr($possible, mt_rand(0, strlen($possible) - 1), 1);
						if (!strstr($password, $char))
						{
								$password .= $char;
								$i++;
						}
				}
				return $password;
		}
		function _sendConfirmEmail($username, $email)
		{
				$this->load->model('emailTemplateModel');
				$this->load->library('email');
				$emailTemplate = $this->emailTemplateModel->readEmailTemplate('register_confirm');
				/* Send the Confirm E-Mail as the register is confirmed successfully */
				$settings = $this->settingsmodel->readSetting('admin_email, admin_name, site_name, site_title');
				$adminEmail = $settings['admin_email'];
				$adminName = $settings['admin_name'];
				$confirmKey = md5(time());
				$confirmText = base_url() . 'register/confirm/' . $confirmKey;
				//Set the user activation key
				$this->usermodel->setUserActivationKey($email, $confirmKey);
				$splVars = array("~~receiverName~~" => $username, "~~siteName~~" => $settings['site_name'], "~~siteTitle~~" => $settings['site_title'], "~~attachUrl~~" => $confirmText, "~~adminEmail~~" => $adminEmail, "~~adminName~~" => $adminName);
				$subject = strtr($emailTemplate['template_subject'], $splVars);
				$message = strtr($emailTemplate['template_content'], $splVars);
				$this->email->from($adminEmail, $adminName);
				$this->email->to($email);
				$this->email->subject($subject);
				$this->email->message(nl2br($message));
				$this->email->send();
		}
		function confirm($confirmKey)
		{
				//Load the user model
				$this->load->model('usermodel');
				//setUserActive
				$this->usermodel->setUserActive($confirmKey);
				//Set the flash data
				$this->session->set_flashdata('flash_msg', $this->lang->line('register_confirm_success'));
				//go the login page
				redirect('login');
		}
}
?>