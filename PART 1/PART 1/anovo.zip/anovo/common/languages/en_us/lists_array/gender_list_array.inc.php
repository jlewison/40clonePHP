<?php
$LANG_LIST_ARR['gender'] = array('male' => 'Male', 'female' => 'Female');
?>