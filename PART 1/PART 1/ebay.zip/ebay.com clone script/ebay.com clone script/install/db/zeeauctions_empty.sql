# phpMyAdmin MySQL-Dump
# version 2.3.2
# http://www.phpmyadmin.net/ (download page)
#
# Host: localhost
# Generation Time: May 01, 2004 at 12:20 PM
# Server version: 4.00.04
# PHP Version: 4.2.3
# Database : `zeeauctions_empty`
# --------------------------------------------------------

#
# Table structure for table `zeeauctions_admin`
#

DROP TABLE IF EXISTS `zeeauctions_admin`;
CREATE TABLE `zeeauctions_admin` (
  `id` bigint(20) NOT NULL auto_increment,
  `admin_name` varchar(255) default NULL,
  `pwd` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_admin`
#

INSERT INTO `zeeauctions_admin` (`id`, `admin_name`, `pwd`) VALUES (1, 'admin', 'admin');
# --------------------------------------------------------

#
# Table structure for table `zeeauctions_ads`
#

DROP TABLE IF EXISTS `zeeauctions_ads`;
CREATE TABLE `zeeauctions_ads` (
  `id` bigint(20) NOT NULL auto_increment,
  `url` varchar(255) NOT NULL default '',
  `bannerurl` varchar(255) NOT NULL default '',
  `adv_id` bigint(20) NOT NULL default '0',
  `credits` bigint(20) NOT NULL default '0',
  `displays` bigint(20) NOT NULL default '0',
  `paid` varchar(255) NOT NULL default '',
  `approved` varchar(255) NOT NULL default '',
  `clicks` bigint(20) default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_ads`
#

# --------------------------------------------------------

#
# Table structure for table `zeeauctions_adv_transactions`
#

DROP TABLE IF EXISTS `zeeauctions_adv_transactions`;
CREATE TABLE `zeeauctions_adv_transactions` (
  `id` bigint(20) NOT NULL auto_increment,
  `description` varchar(255) default NULL,
  `amount` decimal(10,2) default NULL,
  `adv_id` bigint(20) default NULL,
  `date_submitted` timestamp(14) NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_adv_transactions`
#

# --------------------------------------------------------

#
# Table structure for table `zeeauctions_advertisers`
#

DROP TABLE IF EXISTS `zeeauctions_advertisers`;
CREATE TABLE `zeeauctions_advertisers` (
  `id` bigint(20) NOT NULL auto_increment,
  `uname` varchar(255) default NULL,
  `email` varchar(255) default NULL,
  `pwd` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_advertisers`
#

# --------------------------------------------------------

#
# Table structure for table `zeeauctions_auction_types`
#

DROP TABLE IF EXISTS `zeeauctions_auction_types`;
CREATE TABLE `zeeauctions_auction_types` (
  `id` bigint(20) NOT NULL auto_increment,
  `auction_name` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_auction_types`
#

INSERT INTO `zeeauctions_auction_types` (`id`, `auction_name`) VALUES (3, 'fixed'),
(2, 'dutch'),
(1, 'auction'),
(4, 'classified');
# --------------------------------------------------------

#
# Table structure for table `zeeauctions_banners`
#

DROP TABLE IF EXISTS `zeeauctions_banners`;
CREATE TABLE `zeeauctions_banners` (
  `id` bigint(20) NOT NULL auto_increment,
  `img_url` varchar(255) default NULL,
  `banner_link` varchar(255) default NULL,
  `width` int(11) default NULL,
  `height` int(11) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_banners`
#

# --------------------------------------------------------

#
# Table structure for table `zeeauctions_bids`
#

DROP TABLE IF EXISTS `zeeauctions_bids`;
CREATE TABLE `zeeauctions_bids` (
  `id` bigint(20) NOT NULL auto_increment,
  `pid` bigint(20) default NULL,
  `amount` decimal(10,2) default NULL,
  `uid` bigint(20) default NULL,
  `date_submitted` timestamp(14) NOT NULL,
  `notify_me` varchar(255) default 'no',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_bids`
#

# --------------------------------------------------------

#
# Table structure for table `zeeauctions_blocked`
#

DROP TABLE IF EXISTS `zeeauctions_blocked`;
CREATE TABLE `zeeauctions_blocked` (
  `id` bigint(20) NOT NULL auto_increment,
  `uid` bigint(20) default NULL,
  `blocked_user` bigint(20) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_blocked`
#

# --------------------------------------------------------

#
# Table structure for table `zeeauctions_categories`
#

DROP TABLE IF EXISTS `zeeauctions_categories`;
CREATE TABLE `zeeauctions_categories` (
  `id` bigint(20) NOT NULL auto_increment,
  `cat_name` varchar(255) default NULL,
  `pid` bigint(20) default NULL,
  `clicks` bigint(20) default NULL,
  `order_index` bigint(20) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_categories`
#

INSERT INTO `zeeauctions_categories` (`id`, `cat_name`, `pid`, `clicks`, `order_index`) VALUES (11, 'DVDs', 2, NULL, 16),
(2, 'Electronics', 0, NULL, 15),
(3, 'Furniture Goods', 0, NULL, 3),
(7, 'Monitors', 2, NULL, 11),
(9, 'Antiques', 0, NULL, 13),
(10, 'Books', 0, NULL, 14),
(12, 'Video Games', 0, NULL, 20),
(13, 'Travel', 0, NULL, 22),
(14, 'Toys', 0, NULL, 0),
(15, 'Household', 0, NULL, 2),
(16, 'new2', 15, NULL, 2),
(17, 'new1', 15, NULL, 2),
(19, 'newone', 16, NULL, -2),
(20, 'newtwo', 16, NULL, -1);
# --------------------------------------------------------

#
# Table structure for table `zeeauctions_config`
#

DROP TABLE IF EXISTS `zeeauctions_config`;
CREATE TABLE `zeeauctions_config` (
  `id` bigint(20) NOT NULL auto_increment,
  `admin_email` varchar(255) default NULL,
  `site_name` varchar(255) default NULL,
  `recperpage` int(11) default NULL,
  `pay_pal` varchar(255) default NULL,
  `no_of_images` int(11) default NULL,
  `agreement` longtext,
  `recinpanel` int(11) default NULL,
  `null_char` varchar(255) default NULL,
  `privacy` longtext,
  `legal` longtext,
  `terms` longtext,
  `username_len` int(11) default NULL,
  `pwd_len` int(11) default NULL,
  `site_root` varchar(255) default NULL,
  `featured_items` int(11) default NULL,
  `fp_images` int(11) default '0',
  `bonus` decimal(10,2) default NULL,
  `bold_rate` decimal(10,2) default NULL,
  `featured_rate` decimal(10,2) default NULL,
  `highlight_rate` decimal(10,2) default NULL,
  `free_images` int(10) default NULL,
  `image_rate` decimal(10,2) default NULL,
  `buy_images` int(10) default NULL,
  `welcome_msg` longtext,
  `max_period` int(10) default NULL,
  `fp_featured_rate` decimal(10,2) default NULL,
  `gallery_featured_rate` decimal(10,2) default NULL,
  `auction_item_fees` decimal(10,2) default '0.00',
  `fixed_item_fees` decimal(10,2) default '0.00',
  `classified_item_fees` decimal(10,2) default '0.00',
  `dutch_item_fees` decimal(10,2) default '0.00',
  `cur_id` bigint(20) default '1',
  `max_ext_period` int(11) default '0',
  `ext_cost` decimal(10,2) NOT NULL default '0.00',
  `image_size` bigint(20) default '0',
  `buy_now` decimal(10,2) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_config`
#

INSERT INTO `zeeauctions_config` (`id`, `admin_email`, `site_name`, `recperpage`, `pay_pal`, `no_of_images`, `agreement`, `recinpanel`, `null_char`, `privacy`, `legal`, `terms`, `username_len`, `pwd_len`, `site_root`, `featured_items`, `fp_images`, `bonus`, `bold_rate`, `featured_rate`, `highlight_rate`, `free_images`, `image_rate`, `buy_images`, `welcome_msg`, `max_period`, `fp_featured_rate`, `gallery_featured_rate`, `auction_item_fees`, `fixed_item_fees`, `classified_item_fees`, `dutch_item_fees`, `cur_id`, `max_ext_period`, `ext_cost`, `image_size`, `buy_now`) VALUES (1, 'admin@zeeauctions.com', 'ZeeAuctions.com :: List Anything Old or New For Free', 10, 'mail@zeeways.com', 10, 'Your Agreement Here\r\n', 6, '- -', '<font type=\'arial\' size=4><b>Privacy Policy</b></font>\r\n<font type=\'arial\' size=2><br>Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. <p>\r\nAdmin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. <p>Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. Admin privacy policies here. <p>\r\n</font>', '<font type=\'arial\' size=4><b>Legal Policy</b></font>\r\n<font type=\'arial\' size=2><br>Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.<p>Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.<p>Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.<p>Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.<p>Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.Legal privacy policies here.<p>', '<font type=\'arial\' size=4><b>Terms and Conditions</b></font>\r\n<font type=\'arial\' size=2><br>Terms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions here<p>Terms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions here<p>Terms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions here<p>Terms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions here<p>Terms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions here<p>Terms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions here<p>Terms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions here<p>Terms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions hereTerms & Conditions here<p>', 4, 4, 'http://www.zeeauctions.com', 5, 5, '1.00', '2.00', '1.00', '7.00', 3, '5.00', 3, 'Welcome to ZeeAuctions', 15, '1.00', '1.80', '0.50', '0.75', '1.50', '2.00', 1, 15, '0.05', 50000, '1.00');
# --------------------------------------------------------

#
# Table structure for table `zeeauctions_contacts`
#

DROP TABLE IF EXISTS `zeeauctions_contacts`;
CREATE TABLE `zeeauctions_contacts` (
  `id` bigint(20) NOT NULL auto_increment,
  `uid` bigint(20) default NULL,
  `contact_user` bigint(20) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_contacts`
#

# --------------------------------------------------------

#
# Table structure for table `zeeauctions_counters`
#

DROP TABLE IF EXISTS `zeeauctions_counters`;
CREATE TABLE `zeeauctions_counters` (
  `id` bigint(20) NOT NULL auto_increment,
  `zero` varchar(255) default NULL,
  `one` varchar(255) default NULL,
  `two` varchar(255) default NULL,
  `three` varchar(255) default NULL,
  `four` varchar(255) default NULL,
  `five` varchar(255) default NULL,
  `six` varchar(255) default NULL,
  `seven` varchar(255) default NULL,
  `eight` varchar(255) default NULL,
  `nine` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_counters`
#

INSERT INTO `zeeauctions_counters` (`id`, `zero`, `one`, `two`, `three`, `four`, `five`, `six`, `seven`, `eight`, `nine`) VALUES (1, '0.gif', '1.gif', '2.gif', '3.gif', '4.gif', '5.gif', '6.gif', '7.gif', '8.gif', '9.gif'),
(2, 'a0.gif', 'a1.gif', 'a2.gif', 'a3.gif', 'a4.gif', 'a5.gif', 'a6.gif', 'a7.gif', 'a8.gif', 'a9.gif');
# --------------------------------------------------------

#
# Table structure for table `zeeauctions_country`
#

DROP TABLE IF EXISTS `zeeauctions_country`;
CREATE TABLE `zeeauctions_country` (
  `country` varchar(255) NOT NULL default '',
  `id` bigint(20) NOT NULL auto_increment,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_country`
#

INSERT INTO `zeeauctions_country` (`country`, `id`) VALUES ('Afghanistan', 1),
('Albania', 2),
('Algeria', 3),
('Andorra', 4),
('Angola', 5),
('Anguilla', 6),
('Antigua & Barbuda', 7),
('Argentina', 8),
('Armenia', 9),
('Austria', 10),
('Azerbaijan', 11),
('Bahamas', 12),
('Bahrain', 13),
('Bangladesh', 14),
('Barbados', 15),
('Belarus', 16),
('Belgium', 17),
('Belize', 18),
('Belize', 19),
('Bermuda', 20),
('Bhutan', 21),
('Bolivia', 22),
('Bosnia and Herzegovina', 23),
('Botswana', 24),
('Brazil', 25),
('Brunei', 26),
('Bulgaria', 27),
('Burkina Faso', 28),
('Burundi', 29),
('Cambodia', 30),
('Cameroon', 31),
('Canada', 32),
('Cape Verde', 33),
('Cayman Islands', 34),
('Central African Republic', 35),
('Chad', 36),
('Chile', 37),
('China', 38),
('Colombia', 39),
('Comoros', 40),
('Congo', 41),
('Congo (DRC)', 42),
('Cook Islands', 43),
('Costa Rica', 44),
('Cote d\'Ivoire', 45),
('Croatia (Hrvatska)', 46),
('Cuba', 47),
('Cyprus', 48),
('Czech Republic', 49),
('Denmark', 50),
('Djibouti', 51),
('Dominica', 52),
('Dominican Republic', 53),
('East Timor', 54),
('Ecuador', 55),
('Egypt', 56),
('El Salvador', 57),
('Equatorial Guinea', 58),
('Eritrea', 59),
('Estonia', 60),
('Ethiopia', 61),
('Falkland Islands', 62),
('Faroe Islands', 63),
('Fiji Islands', 64),
('Finland', 65),
('France', 66),
('French Guiana', 67),
('French Polynesia', 68),
('Gabon', 69),
('Gambia', 70),
('Georgia', 71),
('Germany', 72),
('Ghana', 73),
('Gibraltar', 74),
('Greece', 75),
('Greenland', 76),
('Grenada', 77),
('Guadeloupe', 78),
('Guam', 79),
('Guatemala', 80),
('Guinea', 81),
('Guinea-Bissau', 82),
('Guyana', 83),
('Haiti', 84),
('Honduras', 85),
('Hong Kong SAR', 86),
('Hungary', 87),
('Iceland', 88),
('India', 89),
('Indonesia', 90),
('Iran', 91),
('Iraq', 92),
('Ireland', 93),
('Israel', 94),
('Italy', 95),
('Jamaica', 96),
('Japan', 97),
('Jordan', 98),
('Kazakhstan', 99),
('Kenya', 100),
('Kiribati', 101),
('Korea', 102),
('Kuwait', 103),
('Kyrgyzstan', 104),
('Laos', 105),
('Latvia', 106),
('Lebanon', 107),
('Lesotho', 108),
('Liberia', 109),
('Libya', 110),
('Liechtenstein', 111),
('Lithuania', 112),
('Luxembourg', 113),
('Macao SAR', 114),
('Macedonia', 115),
('Madagascar', 116),
('Malawi', 117),
('Malaysia', 118),
('Maldives', 119),
('Mali', 120),
('Malta', 121),
('Martinique', 122),
('Mauritania', 123),
('Mauritius', 124),
('Mayotte', 125),
('Mexico', 126),
('Micronesia', 127),
('Moldova', 128),
('Monaco', 129),
('Mongolia', 130),
('Montserrat', 131),
('Morocco', 132),
('Mozambique', 133),
('Myanmar', 134),
('Namibia', 135),
('Nauru', 136),
('Nepal', 137),
('Netherlands', 138),
('Netherlands Antilles', 139),
('New Caledonia', 140),
('New Zealand', 141),
('Nicaragua', 142),
('Niger', 143),
('Nigeria', 144),
('Niue', 145),
('Norfolk Island', 146),
('North Korea', 147),
('Norway', 148),
('Oman', 149),
('Pakistan', 150),
('Panama', 151),
('Papua New Guinea', 152),
('Paraguay', 153),
('Peru', 154),
('Philippines', 155),
('Pitcairn Islands', 156),
('Poland', 157),
('Portugal', 158),
('Puerto Rico', 159),
('Qatar', 160),
('Reunion', 161),
('Romania', 162),
('Russia', 163),
('Rwanda', 164),
('Samoa', 165),
('San Marino', 166),
('Sao Tome and Principe', 167),
('Saudi Arabia', 168),
('Senegal', 169),
('Serbia and Montenegro', 170),
('Seychelles', 171),
('Sierra Leone', 172),
('Singapore', 173),
('Slovakia', 174),
('Slovenia', 175),
('Solomon Islands', 176),
('Somalia', 177),
('South Africa', 178),
('Spain', 179),
('Sri Lanka', 180),
('St. Helena', 181),
('St. Kitts and Nevis', 182),
('St. Lucia', 183),
('St. Pierre and Miquelon', 184),
('St. Vincent & Grenadines', 185),
('Sudan', 186),
('Suriname', 187),
('Swaziland', 188),
('Sweden', 189),
('Switzerland', 190),
('Syria', 191),
('Taiwan', 192),
('Tajikistan', 193),
('Tanzania', 194),
('Thailand', 195),
('Togo', 196),
('Tokelau', 197),
('Tonga', 198),
('Trinidad and Tobago', 199),
('Tunisia', 200),
('Turkey', 201),
('Turkmenistan', 202),
('Turks and Caicos Islands', 203),
('Tuvalu', 204),
('Uganda', 205),
('Ukraine', 206),
('United Arab Emirates', 207),
('United Kingdom', 208),
('Uruguay', 209),
('USA', 210),
('Uzbekistan', 211),
('Vanuatu', 212),
('Venezuela', 213),
('Vietnam', 214),
('Virgin Islands', 215),
('Virgin Islands (British)', 216),
('Wallis and Futuna', 217),
('Yemen', 218),
('Yugoslavia', 219),
('Zambia', 220),
('Zimbabwe', 221);
# --------------------------------------------------------

#
# Table structure for table `zeeauctions_currency`
#

DROP TABLE IF EXISTS `zeeauctions_currency`;
CREATE TABLE `zeeauctions_currency` (
  `id` bigint(20) NOT NULL auto_increment,
  `cur_name` varchar(255) default NULL,
  `paypal_code` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_currency`
#

INSERT INTO `zeeauctions_currency` (`id`, `cur_name`, `paypal_code`) VALUES (1, '$', 'USD');
# --------------------------------------------------------

#
# Table structure for table `zeeauctions_desc`
#

DROP TABLE IF EXISTS `zeeauctions_desc`;
CREATE TABLE `zeeauctions_desc` (
  `id` bigint(20) NOT NULL auto_increment,
  `pid` bigint(20) default NULL,
  `add_desc` longtext,
  `date_submitted` timestamp(14) NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_desc`
#

# --------------------------------------------------------

#
# Table structure for table `zeeauctions_email_id`
#

DROP TABLE IF EXISTS `zeeauctions_email_id`;
CREATE TABLE `zeeauctions_email_id` (
  `id` bigint(20) NOT NULL auto_increment,
  `fname` varchar(255) default NULL,
  `lname` varchar(255) default NULL,
  `useremail` varchar(255) default NULL,
  `friend_email` longtext,
  `no_of_friends` int(11) default NULL,
  `sid` bigint(20) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_email_id`
#

# --------------------------------------------------------

#
# Table structure for table `zeeauctions_favourites`
#

DROP TABLE IF EXISTS `zeeauctions_favourites`;
CREATE TABLE `zeeauctions_favourites` (
  `id` bigint(20) NOT NULL auto_increment,
  `pid` bigint(20) default NULL,
  `uid` bigint(20) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_favourites`
#

# --------------------------------------------------------

#
# Table structure for table `zeeauctions_feedback`
#

DROP TABLE IF EXISTS `zeeauctions_feedback`;
CREATE TABLE `zeeauctions_feedback` (
  `id` bigint(20) NOT NULL auto_increment,
  `username` varchar(255) default NULL,
  `rating` varchar(50) default NULL,
  `comment` longtext,
  `by_id` varchar(255) default NULL,
  `pid` bigint(20) default '0',
  `date_submitted` timestamp(14) NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_feedback`
#

# --------------------------------------------------------

#
# Table structure for table `zeeauctions_forum_ans`
#

DROP TABLE IF EXISTS `zeeauctions_forum_ans`;
CREATE TABLE `zeeauctions_forum_ans` (
  `id` bigint(20) NOT NULL auto_increment,
  `ques_id` bigint(20) default NULL,
  `ans` longtext,
  `uid` bigint(20) default NULL,
  `postedon` timestamp(14) NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_forum_ans`
#

# --------------------------------------------------------

#
# Table structure for table `zeeauctions_forum_ques`
#

DROP TABLE IF EXISTS `zeeauctions_forum_ques`;
CREATE TABLE `zeeauctions_forum_ques` (
  `id` bigint(20) NOT NULL auto_increment,
  `uid` bigint(20) default NULL,
  `ques` longtext,
  `can_comment` longtext,
  `postedon` timestamp(14) NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_forum_ques`
#

# --------------------------------------------------------

#
# Table structure for table `zeeauctions_images`
#

DROP TABLE IF EXISTS `zeeauctions_images`;
CREATE TABLE `zeeauctions_images` (
  `id` bigint(20) NOT NULL auto_increment,
  `pid` bigint(20) default NULL,
  `url` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_images`
#

# --------------------------------------------------------

#
# Table structure for table `zeeauctions_mails`
#

DROP TABLE IF EXISTS `zeeauctions_mails`;
CREATE TABLE `zeeauctions_mails` (
  `id` bigint(20) NOT NULL auto_increment,
  `mailid` bigint(20) NOT NULL default '0',
  `fromid` varchar(255) NOT NULL default '',
  `subject` varchar(255) NOT NULL default '',
  `mail` longtext NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_mails`
#

INSERT INTO `zeeauctions_mails` (`id`, `mailid`, `fromid`, `subject`, `mail`) VALUES (2, 2, 'approval@zeeauctions.com', 'Your product has been Approved', 'Hi <fname> <lname>,\r\n\r\nYour product <productname> has been Approved for inclusion on the site.\r\nYou can view this product on <producturl>\r\n\r\nRegards,\r\nAdmin'),
(3, 3, 'disapproval@zeeauctions.com', 'Your product has been disapproved', 'Hi <fname> <lname>,\r\n\r\nYour product <productname> has been disapproved from inclusion on the site.\r\n\r\n\r\nRegards,\r\nAdmin\r\n'),
(4, 4, 'password@zeeauctions.com', 'Your password', 'Hi <fname> <lname>,\r\n\r\nHere is your login information:\r\n\r\nUsername:        <username>\r\nPassword:        <password>\r\nEmail:           <email>\r\n\r\n\r\nThanks for being part of our website.\r\n\r\nRegards,\r\nAdmin\r\nFor login click <loginurl>'),
(1, 1, 'welcome@zeeauctions.com', 'Welcome to zeeauctions.com', 'Hi <fname> <lname>,\r\n\r\nWelcome to zeeauctions.com.\r\n\r\nYour registration information is as follows:\r\n\r\nUsername:        <username>\r\nPassword:        <password>\r\nEmail:           <email>\r\n\r\nThanks for being part of our website.\r\n\r\nRegards,\r\nAdmin\r\nFor login click <loginurl>\r\n'),
(5, 5, 'admin@zeeauctions.com', 'Your product has been Posted', 'Hi <fname> <lname>,\r\n\r\nYour product <productname> has been Posted to our site.You can view this product at <producturl>.\r\n\r\n\r\nRegards,\r\nAdmin'),
(6, 6, 'admin@zeeauctions.com', 'A bid has been placed against your product', 'Hi <fname> <lname>,\r\n\r\nA bid of amount <currentbid> has been placed against your product <productname> from member <bidder_username>.\r\nTotal no of bids <noofbids> \r\n\r\n\r\nRegards,\r\nAdmin'),
(7, 7, 'admin@zeeauctions.com', 'Auction End', 'Hi <fname> <lname>,\r\nYour auction for product <productname> has been expired on <expired_date>.\r\n\r\n\r\nRegards,\r\nAdmin'),
(8, 8, 'admin@zeeauctions.com', 'Message from user.', 'Hi <fname> <lname>,\r\n\r\nYou have been recieved a message\r\nFrom ::  <sender_username>\r\nTitle :: <message_title>\r\nMessage :: <message_text>\r\nTime :: <message_time>\r\nDate :: <message_date>\r\n\r\n\r\nRegards,\r\nAdmin'),
(9, 9, 'admin@zeeauctions.com', 'Auction Winner', 'Hi <fname> <lname>,\r\n\r\nYou have been won the auction for the product <productname>.\r\nYou can order the product through email <seller_email>\r\n\r\nRegards,\r\nAdmin'),
(10, 10, 'admin@zeeauctions.com', 'Auction Closed', 'Hi <fname> <lname>,\r\n\r\nYou have closed the auction for the product <productname>.\r\nYou can contact buyer(s) contact information is as follows:\r\n <contact_information>\r\n\r\nRegards,\r\nAdmin'),
(11, 11, 'admin@zeeauctions.com', 'Auction Looser', 'Hi <fname> <lname>,\r\n\r\nUnfortunately your bid for product <productname> has not been choosed.\r\n\r\nRegards,\r\nAdmin'),
(12, 12, 'admin@zeeauctions.com', 'Purchase Request', 'Hi <fname> <lname>,\r\n\r\nAn order for your product <productname> of quantity <quantity> items @ <amount>  has been placed by <buyer_username>.\r\nYou can contact him/her at <contact_information>.\r\n\r\nRegards,\r\nAdmin'),
(13, 13, 'admin@zeeauctions.com', 'Order Placed', 'Hi <fname> <lname>,\r\n\r\nYour order of quantity <quantity> items @ <amount> of product <productname> has been placed.\r\nYou can contact seller at <seller_email>.\r\n\r\nRegards,\r\nAdmin'),
(14, 14, 'admin@zeeauctions.com', 'outbid mail', 'Hi <fname> <lname>,\r\n\r\nA bid more than your bid for the product <productname> has been placed.\r\n\r\nRegards,\r\nAdmin\r\n'),
(15, 15, 'admin@zeeauctions.com', 'Send Stat Mail', 'Hi \r\n\r\nThere are statistics information regarding your banner display on our site::\r\nBanner ::<bannerurl>\r\nDisplays::<displays>\r\ncredits ::<credits>\r\nbalance ::<balance>\r\n\r\nRegards,\r\nAdmin');
# --------------------------------------------------------

#
# Table structure for table `zeeauctions_member_feedback`
#

DROP TABLE IF EXISTS `zeeauctions_member_feedback`;
CREATE TABLE `zeeauctions_member_feedback` (
  `id` bigint(20) NOT NULL auto_increment,
  `fname` varchar(255) default NULL,
  `lname` varchar(255) default NULL,
  `email` varchar(255) default NULL,
  `url` varchar(255) default NULL,
  `title` varchar(255) default NULL,
  `comment` longtext,
  `uid` bigint(20) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_member_feedback`
#

# --------------------------------------------------------

#
# Table structure for table `zeeauctions_members`
#

DROP TABLE IF EXISTS `zeeauctions_members`;
CREATE TABLE `zeeauctions_members` (
  `id` bigint(20) NOT NULL auto_increment,
  `c_name` varchar(255) default NULL,
  `add1` varchar(255) default NULL,
  `add2` varchar(255) default NULL,
  `city` varchar(255) default NULL,
  `state` varchar(255) default NULL,
  `zip` varchar(50) default NULL,
  `country` varchar(255) default NULL,
  `home_phone` varchar(50) default NULL,
  `email` varchar(255) default NULL,
  `username` varchar(255) default NULL,
  `pwd` varchar(255) default NULL,
  `fname` varchar(255) default NULL,
  `lname` varchar(255) default NULL,
  `work_phone` varchar(50) default NULL,
  `logo_url` varchar(255) default NULL,
  `store_title` varchar(255) default NULL,
  `store_desc` longtext,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_members`
#

# --------------------------------------------------------

#
# Table structure for table `zeeauctions_messages`
#

DROP TABLE IF EXISTS `zeeauctions_messages`;
CREATE TABLE `zeeauctions_messages` (
  `id` bigint(20) NOT NULL auto_increment,
  `fid` bigint(20) NOT NULL default '0',
  `tid` bigint(20) NOT NULL default '0',
  `subject` mediumtext NOT NULL,
  `message` longtext NOT NULL,
  `tempdate` timestamp(14) NOT NULL,
  `onstamp` timestamp(14) NOT NULL,
  `msg_read` varchar(10) NOT NULL default '',
  `f_del` varchar(10) NOT NULL default '',
  `t_del` varchar(10) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_messages`
#

# --------------------------------------------------------

#
# Table structure for table `zeeauctions_plans`
#

DROP TABLE IF EXISTS `zeeauctions_plans`;
CREATE TABLE `zeeauctions_plans` (
  `id` bigint(20) NOT NULL auto_increment,
  `credits` bigint(20) NOT NULL default '0',
  `price` bigint(20) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_plans`
#

INSERT INTO `zeeauctions_plans` (`id`, `credits`, `price`) VALUES (8, 1000, 7),
(7, 10000, 36),
(6, 5000, 20);
# --------------------------------------------------------

#
# Table structure for table `zeeauctions_products`
#

DROP TABLE IF EXISTS `zeeauctions_products`;
CREATE TABLE `zeeauctions_products` (
  `id` bigint(20) NOT NULL auto_increment,
  `uid` bigint(20) NOT NULL default '0',
  `product_name` varchar(255) default NULL,
  `cid` bigint(20) default NULL,
  `aucid` bigint(20) default NULL,
  `auction_period` varchar(255) default NULL,
  `featured` varchar(10) default NULL,
  `approved` varchar(10) default NULL,
  `tmpdate` timestamp(14) NOT NULL,
  `date_submitted` timestamp(14) NOT NULL,
  `date_closed` timestamp(14) NOT NULL,
  `product_desc` longtext,
  `quantity` bigint(20) default NULL,
  `location` varchar(255) default NULL,
  `bid_inc` decimal(10,2) default NULL,
  `min_bid` decimal(10,2) default NULL,
  `no_of_views` bigint(20) default NULL,
  `ship_cost` decimal(10,2) default NULL,
  `who_pay_sc` varchar(255) default NULL,
  `status` varchar(255) default NULL,
  `winner` varchar(255) default NULL,
  `bold` varchar(10) default NULL,
  `highlight` varchar(10) default NULL,
  `purchased_images` int(10) default '0',
  `fp_featured` varchar(10) default NULL,
  `gallery_featured` varchar(10) default NULL,
  `auto_list` int(11) default '0',
  `done` int(11) default '0',
  `paypal_id` varchar(255) default NULL,
  `counter_id` bigint(20) default '0',
  `reserve_price` decimal(10,2) default '0.00',
  `buy_price` decimal(10,2) default '0.00',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_products`
#

# --------------------------------------------------------

#
# Table structure for table `zeeauctions_purchased`
#

DROP TABLE IF EXISTS `zeeauctions_purchased`;
CREATE TABLE `zeeauctions_purchased` (
  `id` bigint(20) NOT NULL auto_increment,
  `pid` bigint(20) default NULL,
  `uid` bigint(20) default NULL,
  `quantity` bigint(20) default NULL,
  `date_submitted` timestamp(14) NOT NULL,
  `email` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_purchased`
#

# --------------------------------------------------------

#
# Table structure for table `zeeauctions_ratings`
#

DROP TABLE IF EXISTS `zeeauctions_ratings`;
CREATE TABLE `zeeauctions_ratings` (
  `id` bigint(20) NOT NULL auto_increment,
  `sid` bigint(20) default NULL,
  `rating` int(11) default NULL,
  `ip` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_ratings`
#

# --------------------------------------------------------

#
# Table structure for table `zeeauctions_transactions`
#

DROP TABLE IF EXISTS `zeeauctions_transactions`;
CREATE TABLE `zeeauctions_transactions` (
  `id` bigint(20) NOT NULL auto_increment,
  `uid` bigint(20) default NULL,
  `amount` decimal(10,2) default NULL,
  `date_submitted` timestamp(14) NOT NULL,
  `description` longtext,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

#
# Dumping data for table `zeeauctions_transactions`
#


