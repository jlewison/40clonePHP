<?php
if ( !defined( 'SMARTY_DIR' ) ) {
	include_once( '../init.php' );
}

import_request_variables('pg');

/* Loads zip codes */

if ( $cntry != '' ) {
	if ($_REQUEST['delzip'] != '') {
		/* Delete zips for the country */

		$sql = 'delete from ! where countrycode = ?';

		$db->query($sql, array(ZIPCODES_TABLE, $cntry) );

		$msg = str_replace('#COUNTRY#', $lang['countries'][$cntry], get_lang('delzips_succ'));

		/* Analyze the table to adjust index values */
		$db->query('optimize table '.ZIPCODES_TABLE);
	}	elseif ($zipsdir != '') {
		$dirname = "../zipcodes/".$zipsdir;
		$filestoload=array();
		$filesdir = opendir($dirname);
		while($file = readdir($filesdir)) {
			if ($file != '.' && $file != '..' && !is_dir( $dirname.'/'.$file ) && substr_count($file, '.csv') > 0 ) {
				$filestoload[] = $file;

			}
		}
		sort($filestoload);
		reset($filestoload);


		$_SESSION['cntry_'.$cntry]['files'] = $filestoload;
		$_SESSION['cntry_'.$cntry]['filesdir'] = $dirname.'/';

		$t->assign('filestoload', $filestoload);

		$t->assign('filesdir', $dirname.'/');
		/* Analyze the table to adjust index values */
//		$db->query('optimize table '.ZIPCODES_TABLE);
	}
}

$t->assign('cntry', $cntry);

$t->assign('lang',$lang);

/* Get list of zip code files from the directory */
$files = array();
$dir = opendir("../zipcodes");
while($file = readdir($dir)) {
	$cntry_dir = '../zipcodes/'.$file;
	if ($file != '.' && $file != '..' && is_dir( $cntry_dir ) )
		$files[] = $file;
}

$t->assign('zipsdir',$zipsdir);

$t->assign('files', $files);

$t->assign('rendered_page', $t->fetch('admin/load_zips.tpl'));

$t->display('admin/index.tpl');

?>