<?PHP

/* Step-4 of installatin process.  */

/* Check if database can be connected */

$dsn = $dbtype . '://' . $dbuser . ':' . $dbpasswd . '@' . $dbhost . '/' .$dbname;
$db = @DB::connect( $dsn );
$db_valid = '1';
$errorLogin == '0';
if ( DB::isError($db) ) {
	$db_valid='0';
	if ( $db->code == -24 ) {
		$t->assign( 'errorLogin', 1 );
	} else if ( $db->code == -9 ) {
		$t->assign( 'errorLogin', 1 );
	}

} else {

	if ($dbtype == 'mysql') {

		$result = $db->getAll( "show tables" );
		$tablesexist=0;
		foreach (array_values($result) as $table_exist) {
			foreach ($table_exist as $k => $tablename) {
				if (strpos($tablename,$prefix) !== false && strpos($tablename,$prefix.'_fc_') === false) $tablesexist++;
			}
		}

		// check if we have rights

		if ( !DB::isError( $result ) ) {

			foreach ( $result as $index => $dbarray ) {

				$name = $dbarray[0];

				if ( $name == $dbname ) {
					$db_valid = '1';
					break;
				}
			}

		}

	} else {
		// if no rights - assume user entered valid db name
		// if not - this will be found in the next lines
		$db_valid = '1';
	}

	$db->disconnect();

}

if ($docroot == '' or !isset($docroot)) {
	$doc = explode('/',$_SERVER['SCRIPT_NAME']);
	if ($doc[2] != '') {
		$docroot = '/'.$doc[1].'/';
	} else {
		$docroot = '/';
	}
}
$t->assign('docroot', $docroot);
$_SESSION['replacearray']['DOC_ROOT'] = $docroot;
$t->assign('dbversion',$dbversion);
$t->assign('dbname', $dbname);
$t->assign('dbuser', $dbuser);
$t->assign('dbpasswd', $dbpasswd);
$t->assign('dbhost', $dbhost);
$t->assign('prefix', $prefix);
$t->assign('db_valid', $db_valid);
$t->assign('dbtype', $dbtype);
$t->assign('config_opt',$config_opt);
$t->assign( 'errorLogin', $errorLogin );

$_SESSION['replacearray']['DB_NAME'] = $dbname;
$_SESSION['replacearray']['DB_HOST'] = $dbhost;
$_SESSION['replacearray']['DB_USER'] = $dbuser;
$_SESSION['replacearray']['DB_PASS'] = $dbpasswd;
$_SESSION['replacearray']['DB_PREFIX'] = $prefix;
$_SESSION['replacearray']['DB_TYPE'] = $dbtype;
define ('DB_TYPE',$dbtype);
define ('DB_PREFIX',$prefix);
define ('DB_NAME',$dbname);
define ('DB_HOST',$dbhost);
define ('DB_USER',$dbuser);
define ('DB_PASS',$dbpasswd);

if ($errorLogin == '1' || $db_valid != '1' || ( $config_opt=='N' && $tablesexist > 0) || ( $config_opt=='U' && $tablesexist == 0) ) {

	$t->assign('tablesexist', $tablesexist);

	$t->assign('dispstep', $dispstep);

	$t->display('install/install_step3.tpl');

	include('footer.tpl');

	exit;
}


/* OK. Now the database is accessible.
   In case of upgrade, let us proceed.
   Otherwise, let us accept other parameters.
*/

if ($config_opt != 'U') {

	/* Insert and forced installation */
	include( 'countries.php' );
	if ($admin_name == '' or !isset($admin_name)) $admin_name='admin';
	$t->assign('admin_name', $admin_name);

	$t->assign('dispstep', $dispstep+1);
	$t->assign( 'countrytypeValues', $countrytypeValues );
	$t->assign( 'countrytypeNames', $countrytypeNames );
	$t->assign( 'countryType', $countryType );
	$t->assign( 'langType', $langType );
	$t->assign( 'defaultLangValues', $defaultLangValues );
	$t->assign( 'defaultLangNames', $defaultLangNames );

	$t->display('install/install_step4.tpl');

	include('footer.tpl');

	exit;
}

if ($config_opt == 'U') {

	/* Upgrade from earlier version */
	define ('DB_PREFIX', $prefix);

	$dsn = $dbtype . '://' . $dbuser . ':' . $dbpasswd . '@' . $dbhost . '/' .$dbname;
	$db = @DB::connect( $dsn );
	$db->setFetchMode( DB_FETCHMODE_ASSOC );

	/* Upgrade option */
	$_SESSION['upgrade']='1';
	$replace = array(
		'DB_USER'	=> $dbuser,
		'DB_NAME'	=> $dbname,
		'DB_HOST'	=> $dbhost,
		'DB_PASS'	=> $dbpasswd,
		'DB_TYPE'	=> $dbtype,
		'DB_PREFIX' => $prefix,
		'DOC_ROOT' 	=> $docroot,
		'OSDATE_INSTALLED' => 1,
		'DEFAULT_LANG' => "'".str_replace('lang_','',$_REQUEST['langType'])."'",
		'DEFAULT_COUNTRY' => $countryType,
		'VERSION'	=> OSDATE_VERSION
	);

	// do upgrade here
	$t->assign( 'upgrade', 1 );

	$t->display('install/install_step5.tpl');

	echo("<tr><td>Writing installation parameters to config.php file... ");flush();
	ob_start();

	$configData = getConfigData( $replace );

	$configCreated = writeConfig( $configData );

	ob_start();

	if ($configCreated) {
	//	copy(CONFIG_FILE, 'config.php');

		echo("Done</td></tr>");flush();
	} else {
		echo('<font color=red>failed</font>..<br />Process to write updated config.php file failed. Please check and <a href="install.php">restart installation process</a></td></tr>');flush();
		include('install_files/footer.tpl');
		exit;
	}

	$succ = upgradeWithFile( SQL_FILE );

	/* Clear cache directory */
	$cache_deleted = DeleteFiles($docroot.'cache/', '1');

	if ($succ === true) {
		echo('<tr><td><center><font size="+1"><b><br />Congratulations.<br /> Upgrade successfully completed</b></font></center></td></tr>
		<tr><td>&nbsp;</td></tr>');
		$t->assign('dispstep', $dispstep+1);
	} else {
		echo('<tr><td><font size="14px" color=red><center><br />Upgrade failed. Please check issues and then <a uhref="install.php"restart installation process</a>.</center></font></td></tr><tr><td>
		&nbsp;</td></tr>');
		exit;
	}
	$t->display('install/install_step5-1.tpl');

	include('footer.tpl');

	exit;
}
?>