<?php
/**
* http://cpaint.sourceforge.net
* 
* released under the terms of the GPL
* see http://www.fsf.org/licensing/licenses/gpl.txt for details
* 
* @package    CPAINT
* @access     public
* @author     Paul Sullivan <wiley14@gmail.com>
* @author     Dominique Stender <dstender@st-webdevelopment.de>
* @copyright  Copyright (c) 2005 Paul Sullivan, Dominique Stender - http://cpaint.sourceforge.net
*/
include("../cpaint2.inc.php");

$cp = new cpaint();
$cp->register('add');
$cp->start();
$cp->return_data();

function add($num1, $num2) {
        global $cp;
        $cp->set_id("response");
        $cp->set_data($num1 + $num2);
        return;
        }
?>
