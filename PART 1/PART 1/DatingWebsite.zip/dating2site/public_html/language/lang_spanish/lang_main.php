
<?php
// The format of this file is ---> $lang['message'] = 'text';
//
// You should also try to set a locale and a character encoding (plus direction). The encoding and direction
// will be sent to the template. The locale may or may not work, it's dependent on OS support and the syntax
// varies ... give it your best guess!
//

$lang['ENCODING'] = 'iso-8859-15';
$lang['DIRECTION'] = 'ltr';
$lang['LEFT'] = 'izquierda';
$lang['RIGHT'] = 'derecha';
$lang['DATE_FORMAT'] =  '%b %d, %Y'; // This should be changed to the default date format for your language, php date() format
$lang['DATE_TIME_FORMAT'] =  '%b %d, %Y %I:%M:%S %P'; // This should be changed to the default date format for your language, php date() format
$lang['DISPLAY_DATE_FORMAT'] =  'd, M, Y';
$lang['DISPLAY_DATETIME_FORMAT'] = 'D d-M-Y H:i:s';
$lang['DB_ERROR'] = "No se pudo llevar a cabo su pedido debido a un problema en la base de datos.<br />Int�ntelo de nuevo.";

$lang['main_menu'] = 'Men� principal';
$lang['homepage'] = 'P�gina de inicio';
$lang['rate_photos'] = 'Calificar Fotos';
$lang['forum'] = 'Foro';
$lang['manageforum'] = 'Administraci�n del Foro';
$lang['chat'] = 'Chat';
$lang['managechat'] = 'Administraci�n de Chat';
$lang['member_login'] = 'Inicio de Sesi�n';
$lang['featured_members'] = 'Miembros Destacados';
$lang['quick_search'] = 'B�squeda R�pida';
$lang['my_searches'] = 'Mis B�squedas';
$lang['affiliates'] = 'Afiliados';
$lang['already_affiliate'] = '�Eres un Afiliado?';
$lang['referals'] = 'Referencia';
$lang['title_colon'] = 'T�tulo:';
$lang['comments_colon'] = 'Comentarios:';
$lang['feedback'] = 'Contactos';

$lang['profiles'] = 'Perfiles';
$lang['profile_s'] = 'Perfil';
$lang['total_amt'] = 'Monto Total';
$lang['banner_link'] = 'Banner/v�nculo';
$lang['clicks'] = 'Clicks';
$lang['finance_calc'] = 'Calculadora Financiera';
$lang['flash_chat_msg'] = 'FlashChat 4.1.0 y m�s incluye una integraci�n para osDate. Por favor compre FlashChat a <a href="www.tufat.com/chat.php" target="_blank">www.tufat.com/chat.php</a> y copie los archivos a esta carpeta. Luego, ejecute el instalador de FlashChat, y especifique a osDate como el CMS a ser integrado.';
$lang['flash_chat_admin_msg'] = 'FlashChat 4.1.0 y m�s incluye una clase de integraci�n para osDate.Por favor compre FlashChat a <a href="www.tufat.com/chat.php" target="_blank">www.tufat.com/chat.php</a> y copie los archivos a esta carpeta. Luego, ejecute el instalador de FlashChat, y especifique a osDate como el CMS a ser integrado.';
$lang['affiliate_head_msg'] = 'Sea un afiliado';
$lang['affiliate_head_msg2'] = 'Le ofrecemos comisiones a los webmasters que ofrezcan visitar nuestro sitio.<br/>';
$lang['affiliate_success_msg1'] = 'Su cuenta de afiliado es:';
$lang['affiliate_success_msg2'] = 'Ya puede iniciar su sesi�n como afiliado. ';
$lang['affiliate_login_title'] = "Inicio de Sesis�n como Afiliado";
$lang['password_changed_successfully'] = 'Su contrase�a ha sido cambiada.';
$lang['affiliate_registration_success'] = 'Registro de Afiliado exitoso';
$lang['login_now'] = 'Inicio de Sesi�n Aqu�';
$lang['must_be_valid'] = 'Debe ser v�lido';
$lang['characters'] = 'caracteres';
$lang['email'] = 'Correo Electr�nico:';
$lang['age'] = 'Edad';
$lang['years'] = 'A�os';

$lang['all_states'] = 'Todos los Estados';
//
// These terms are used at Signup page
//
$lang['welcome'] = 'Bienvenido';
$lang['admin_welcome'] = 'Bienvenido <br /> a <br />' . 'SITENAME' . '<br /> Panel de Administraci�n';
$lang['title'] = 'Bienvenido ' . 'SITENAME';
$lang['site_links'] = array(
	'home' => 'Inicio',
	'signup_now' => 'Reg�strese',
	'chat' => 'Chat',
	'forum' => 'Foro',
	'login' => 'Inicio de Sesi�n',
	'search' => 'Buscar',
	'aboutus' => 'Sobre Nosotros',
	'forgot' => 'Se olvid� la Contrase�a/Usuario?',
	'contactus' => 'Contacte',
	'privacy' => 'Privacidad',
	'terms_of_use' => 'T�rminos de Uso',
	'services' => 'Servicios',
	'faq' => 'Preguntas Frecuentes',
	'articles' => 'Art�culos',
	'affliates' => 'Afiliados',
	'invite_a_friend' => 'Invitar a un amigo',
	'feedback' => 'Contactos'
	);

$lang['success_stories'] = 'Historias exitosas';
$lang['members_login'] = 'Inicio de sesi�n de miembro';
$lang['poll'] = 'Encuesta';
$lang['news'] = 'Noticias';
$lang['articles'] = 'Art�culos';
$lang['poll_result'] = 'Resultado de Encuesta';
$lang['view_poll_archive'] = 'Encuesta Previas';
$lang['member_panel'] = 'Panel de Miembros';
$lang['poll_errmsg1'] = 'Ya has votado en esta encuesta. Intenta otra encuesta, otro d�a.';
$lang['close'] = 'Cerrar';
$lang['all_stories'] = 'Todas las historias';
$lang['all_news'] = 'Todas las Noticias';
$lang['more'] = 'm�s';
$lang['by'] = 'por';

$lang['dont_stay_alone'] = 'No te quedes solo/a,';
$lang['join_now_for_free'] = 'Reg�strate �es gratis!';
$lang['special_offer'] = '�Oferta especial!';
$lang['welcome_to'] = 'Bienvenido/a a';
$lang['welcome_to_site'] = 'Bienvenido/a a '.'SITENAME';

$lang['offer_text'] = 'F�jate porqu� ' . 'SITENAME' . ' es el sitio para relacionarse con m�s crecimiento de la Web. Crea tu perfil en ' . 'SITENAME' . ' para iniciar un fascinante viaje hacia tu media naranja.';

$lang['newest_profiles'] = 'Perfiles Nuevos';

$lang['edit_profile'] = 'Editar Perfil';
$lang['total_profiles'] = 'Total de Perfiles';
$lang['forgot'] = '�olvidaste tu usuario?';
$lang['hide'] = 'Ocultar';
$lang['show'] = 'Mostrar';
$lang['sex'] = 'Sexo:';
$lang['sex_without_colon'] = 'Sexo';
$lang['pageno'] = 'P�gina ';
$lang['page'] = 'P�gina';
$lang['previous'] = 'Anterior';
$lang['next'] = 'Siguiente';
$lang['time_col'] = 'Hora:';

$lang['save_search'] = 'Guardar B�squeda';
$lang['find_your_match'] = 'Encuentra tu media naranja';
$lang['extended_search'] = 'B�squeda Extendida';
$lang['matches_found'] = 'Los siguientes perfiles son el resultado.';
$lang['timezone'] = 'Huso Horario:';
$lang['next_section'] = 'Siguiente Secci�n';
$lang['sign_in'] = 'Miembros inician sesi�n';
$lang['member_panel'] = 'Panel de miembros';
$lang['aff_panel'] = 'Panel de Afiliados';
$lang['login_title'] = 'Inicios de Sesi�n';
$lang['sign_out'] = 'Salir';
$lang['login_submit'] = 'Iniciar Sesi�n';

$lang['change_password'] = 'Cambiar contrase�a';
$lang['old_password'] = 'Contrase�a vieja:';
$lang['new_password'] = 'Contrase�a nueva:';
$lang['confirm_password'] = 'Confirmar contrase�a:';
$lang['password_change_msg'] = 'Se ha cambiado la contrase�a.';

$lang['section_signup_title'] = 'Informaci�n de ingreso';
$lang['signup'] = 'Ingresar';
$lang['section_basic_title'] = 'Informaci�n B�sica';
$lang['section_appearance_title'] = 'Apariencia F�sica';
$lang['section_interests_title'] = 'Intereses';
$lang['section_lifestyle_title'] = 'Estilo de Vida';

$lang['signup_subtitle_login'] = 'Detalles de Inicio de Sesi�n';
$lang['signup_subtitle_profile'] = 'Mi Perfil';
$lang['signup_subtitle_address'] = 'Direcci�n';
$lang['signup_subtitle_appearacnce'] = 'Apariencia F�sica';
$lang['signup_subtitle_preference'] = 'Preferencias de B�squeda';

$lang['signup_username'] = 'Usuario:';
$lang['signup_password'] = 'Contrase�a:';
$lang['signup_confirm_password'] = 'Confirmar Contrase�a:';

$lang['signup_firstname'] = 'Nombre:';
$lang['signup_lastname'] = 'Apellido:';
$lang['signup_email'] = 'Direcci�n de Correo Electr�nico:';
$lang['section_mypicture'] = 'Mis Fotos';
$lang['upload'] = 'Subir';
$lang['upload_pictures'] = 'Administrar Fotos';
$lang['upload_format_msgs'] = 'S�lo se permiten archivos .jpg o .gif o .bmp o .png';
$lang['thumbnail'] = 'Vista Previa';
$lang['picture'] = 'Fotograf�a';
$lang['signup_picture'] = 'Mi Foto';
$lang['signup_picture2'] = 'Mi Foto 2:';
$lang['signup_picture3'] = 'Mi Foto 3:';
$lang['signup_picture4'] = 'Mi Foto 4:';
$lang['signup_picture5'] = 'Mi Foto 5:';

$lang['signup_gender'] = 'Soy';
$lang['signup_pref_age_range'] = 'rango de edad preferido';
$lang['signup_year_old'] = 'a�os';
$lang['signup_birthday'] = 'Cumplea�os:';
$lang['signup_country'] = 'Pa�s';
$lang['signup_state_province'] = 'Estado / Provincia:';
$lang['signup_zip'] = 'C�digo Postal:';
$lang['signup_city'] = 'Ciudad / Localidad:';
$lang['signup_address1'] = 'Direcci�n, l�nea 1:';
$lang['signup_address2'] = 'Direcci�n, l�nea 2:';
$lang['signup_height'] = 'Altura: ';
$lang['signup_feet'] = 'pies';
$lang['signup_meter_inches'] = 'pulgadas [ metros si no eres de USA ]';
$lang['signup_weight'] = 'Peso:';
$lang['signup_pounds'] = 'libras [ kg afuera de USA ]';
$lang['signup_where_should_we_look'] = '�A d�nde miramos?';
$lang['signup_view_online'] = "Otros miembros pueden ver si estoy en l�nea?";

$lang['signup_gender_values'] = array(
	'M' => 'Hombre',
	'F' => 'Mujer',
	'C' => 'Pareja',
	'G' => 'Grupo'
	);

$lang['signup_gender_look'] = array(
	'M' => 'Hombre',
	'F' => 'Mujer',
	'C' => 'Pareja',
	'G' => 'Grupo',
	'B' => 'Hombre o Mujer',
	'A' => 'Cualquiera'
	);

$lang['seeking'] = 'busca a';
$lang['looking_for_a'] = ' busca a';
$lang['looking_for'] = 'busca';

$lang['of'] = ' de ';
$lang['to'] = ' a ';
$lang['from'] = ' desde ';
$lang['for'] = ' para ';
$lang['yes'] = 'Si';
$lang['no'] = 'No';
$lang['cancel'] = 'Cancelar';

$lang['change'] = 'Cambiar';
$lang['reset'] = 'Resetear';

//Commonly used words

$lang['required_info_indication'] = 'indica informaci�n requerida';
$lang['required_info_indicator'] = '* ';
$lang['required_info_indicator_color'] = 'Red';
$lang['click_here'] = 'Click Aqu�';

$lang['datetime_dayval']['Sun'] = 'Dom';
$lang['datetime_dayval']['Mon'] = 'Lun';
$lang['datetime_dayval']['Tue'] = 'Mar';
$lang['datetime_dayval']['Wed'] = 'Mie';
$lang['datetime_dayval']['Thu'] = 'Jue';
$lang['datetime_dayval']['Fri'] = 'Vie';
$lang['datetime_dayval']['Sat'] = 'Sab';

$lang['error_msg_color'] = 'Rojo';
$lang['success_message'] = "Se guard� la informaci�n que envi�.<br /> Ser� redireccionado autom�ticaente a la pr�xima secci�n en 5 segundos. Si no sucede, haga click en el v�nculo de abajo.";
$lang['sendletter_success'] = 'La carta ha sido enviado.';


/*****************Admin Section Labels********************/

//Commonly used labels
$lang['admin_login_title'] = 'SITENAME' . ' Panel de Administraci�n';
$lang['home_title'] = 'SITENAME' . ' Inicio';
$lang['admin_login_msg'] = 'Ingreso Administrador';
$lang['admin_title_msg'] = 'SITENAME' . ' Panel del Administrador';
$lang['admin_panel'] = 'Panel del Administrador';
$lang['back'] = 'Atr�s';
$lang['insert_msg'] = 'Insertar nuevo ';
$lang['question_mark'] = '?';
$lang['id'] = 'Id:';
$lang['name'] = 'Nombre: ';
$lang['name_col'] = 'Nombre';
$lang['enabled'] = 'Activado:';
$lang['action'] = 'Acci�n';
$lang['edit'] = 'Editar';
$lang['delete'] = 'Borrar';
$lang['section'] = 'Secci�n:';
$lang['insert_section'] = 'Insertar secci�n nueva';
$lang['modify_section'] = 'Modificar secci�n';
$lang['modify_sections'] = 'Modificar secciones';
$lang['delete_section'] = 'Borrar secci�n';
$lang['delete_sections'] = 'Borrar secciones';
$lang['enable_selected'] = 'Activar';
$lang['disable_selected'] = 'Desactivar';
$lang['change_selected'] = 'Cambiar';
$lang['delete_selected'] = 'Borrar';
$lang['no_select_msg'] = "No eligi� una opci�n. Por favor presione el bot�n Atr�s para elegir una o m�s opciones.";
$lang['delete_confirm_msg'] = '�Est� seguro de querer borrar esta secci�n?';
$lang['delete_group_confirm_msg'] = '�Est� seguro de querer borrar esta secci�n? Esta acci�n no se revierte.';
$lang['enabled_values'] = array(
	'Y' => 'Si',
	'N' => 'No'
	);
$lang['display_control_type'] = array(
	'checkbox' => 'casilla de verificaci�n',
	'radio' => 'Bot�n de opci�n',
	'select' => 'Lista desplegable',
	'textarea' => 'Ingresar Texto'
	);
$lang['admin_error_color'] = 'Rojo';

$lang['col_head_srno'] = '#';
$lang['col_head_id'] = 'Id';
$lang['col_head_question'] = 'Pregunta';
$lang['col_head_enabled'] = 'Activado';
$lang['col_head_name'] = 'Nombre';
$lang['col_head_username'] = 'Nombre de Usuario';
$lang['col_head_firstname'] = 'Nombre';
$lang['col_head_lastname'] = 'Apellido';
$lang['col_head_fullname'] = 'Nombre Completo';
$lang['col_head_status'] = 'Estado';
$lang['col_head_gender'] = 'Sexo';
$lang['col_head_email'] = 'Correo electr�nico';
$lang['col_head_country'] = 'Pa�s';
$lang['col_head_city'] = 'Ciudad';
$lang['col_head_zip'] = 'C�digo Postal';
$lang['col_head_register_at'] = 'Registrado en';

$lang['section_title'] = 'Administraci�n de Secci�n';
$lang['total_sections'] = 'Todas las Secciones:';
$lang['profile_title'] = 'Administraci�n de Perfil';
$lang['total_profiles_found'] = 'Total de Perfiles encontrados:';
$lang['modify_profile'] = 'Modificar Perfil';

$lang['profile_signup_title'] = 'Informaci�n de Registro';
$lang['profile_basic_title'] = 'Informaci�n B�sica';
$lang['profile_appearance_title'] = 'Apariencia F�sica';
$lang['profile_interests_title'] = 'Intereses';
$lang['profile_lifestyle_title'] = 'Estilo de Vida';

$lang['profile_subtitle_login'] = 'Detalle de Inicio de Sesi�n';
$lang['profile_subtitle_profile'] = 'Perfil';
$lang['profile_subtitle_address'] = 'Direcci�n';
$lang['profile_subtitle_appearacnce'] = 'Apariencia F�sica';
$lang['profile_subtitle_preference'] = 'Preferencias';
$lang['profile_delete_confirm_msg'] = '�Est� seguro/a que quiere borrar este perfil?';
$lang['delete_profile'] = 'Borrar perfil';
$lang['profile_username'] = 'Nombre de Usuario:';
$lang['profile_firstname'] = 'Nombre:';
$lang['profile_lastname'] = 'Apellido:';
$lang['profile_email'] = 'direcci�n Correo Electr�nico:';
$lang['profile_gender'] = 'Sexo:';
$lang['profile_birthday'] = 'Cumplea�os';
$lang['profile_country'] = 'Pa�s:';
$lang['profile_state_province'] = 'Estado / Provincia:';
$lang['profile_zip'] = 'C�digo Postal:';
$lang['profile_city'] = 'Ciudad / Localidad';
$lang['profile_address1'] = 'Direcci�n, L�nea 1:';
$lang['profile_address2'] = 'Direcci�n, L�nea 2:';
$lang['find'] = 'Encontrar';
$lang['search'] = 'Buscar';
$lang['AND'] = 'y';
$lang['OR'] = 'O';
$lang['order_by'] = 'Ordenar por: ';
$lang['sort_by'] = 'clasificar por';
$lang['sort_types'] = array(
	'asc' => 'Ascendente',
	'desc' => 'Descendente'
	);
$lang['search_results'] = 'Resultados de la B�squeda';
$lang['no_record_found'] = 'No se encontraron registros.';
$lang['search_options'] = 'Opciones de B�squeda';
$lang['search_simple'] = 'B�squeda simple';
$lang['search_advance'] = 'Buscar';
$lang['search_advance_results'] = 'Resultados de B�squeda';
$lang['search_country'] = 'Buscar por pa�s';
$lang['search_states'] = 'Buscar por Estado';
$lang['search_zip'] = 'Buscar por C�digo postal';
$lang['search_city'] = 'Buscar por Ciudad';
$lang['search_wildcard_msg'] = 'Puedes ingresar * para ver a todos los registros.';
$lang['search_location'] = '<b>Buscar por Ubicaci�n:</b>';
$lang['select_state'] = 'Estado:';
$lang['enter_city'] = 'Ciudad:';
$lang['enter_zip'] = 'C�digo postal:';
$lang['enter_username'] = 'Nombre de usuario:';
$lang['results_per_page'] = 'Resultados por p�gina';
$lang['search_results_per_page'] = array( 2 => 2, 5 => 5 , 10 => 10, 20 => 20, 50 => 50, 100 => 100 );
$lang['order'] = 'Orden';
$lang['up'] = 'arriba';
$lang['down'] = 'abajo';

$lang['question'] = 'Pregunta:';

$lang['maxlength'] = 'Longitud m�xima:';
$lang['description'] = 'Descripci�n:';
$lang['mandatory'] = 'Obligatorio:';
$lang['guideline'] = 'Pautas:';
$lang['control_type'] = 'Mostrar Control:';
$lang['include_extsearch'] = 'Incluir en b�squeda extendida:';
$lang['head_extsearch'] = 'Encabezado de b�squeda extendida:';

$lang['delete_question'] = 'Borrar Pregunta';
$lang['modify_question'] = 'Modificar Pregunta';
$lang['questions_title'] = 'Administraci�n de Preguntas';
$lang['total_options'] = 'Total de Opciones:';
$lang['insert_question'] = 'Agregar pregunta nueva';
$lang['total_questions'] = 'Total de Preguntas:';
$lang['delete_questions'] = 'Borrar preguntas';
$lang['delete_group_questions_confirm_msg'] = '�Est� seguro de que quiere borrar las preguntas? Esta acci�n no puede ser invertida';

$lang['option'] = 'Opciones';
$lang['answer'] = 'Respuesta';
$lang['options_title'] = 'Opciones de pregunta';
$lang['col_head_answer'] = 'Respuesta';
$lang['with_selected'] = 'Con elegido';
$lang['ranging'] = 'Desde';

// Instant messenger
$lang['instant_messenger'] = 'Mensajero instantaneo';
$lang['instant_message'] = 'Mensaje instantaneo';
$lang['im_from'] = 'De:';
$lang['im_message'] = 'Mensaje:';
$lang['im_reply'] = 'Responder';
$lang['close_window'] = 'Cerrar Ventana';

// my matches
$lang['my_matches'] = 'Mis coincidencias';
$lang['i_am_a'] = 'Soy';
$lang['Between'] = 'entre';
$lang['who_is_from'] = 'que est� de';
$lang['showing'] = 'mostrar';
$lang['your_search_preferences'] = 'Su preferencias de b�squeda:';
$lang['to_edit_search_preferences'] = 'editar preferencias de b�squeda';

$lang['unapproved_user'] = 'Perfiles a aprovar';
$lang['gbl_settings'] = 'Configuraci�n del Sitio';
$lang['configurations'] = 'Configuraci�n';
$lang['col_head_variable'] = 'Variable';
$lang['col_head_value'] = 'Valor';

$lang['affiliate_title'] = 'Administraci�n de Afiliados';
$lang['col_head_counter'] = 'Contador';
$lang['col_head_status'] = 'Estado';

$lang['tell_later'] = 'Te lo digo luego';
$lang['view_profile'] = 'Ver perfil';
$lang['view_profile_errmsg1']  = 'Todav�a no ha especificado sus preferencias.<br />Por favor especifique los detalles de su perfil primero.<br />';
$lang['view_profile_errmsg2'] = '<br />Haga click aqui para especificar sus preferencias ahora.';
$lang['view_profile_errmsg3'] = 'El usuario no ha especificado el detalle de su perfil.';
$lang['view_profile_restricted'] = 'Esto es un perfil restringido, el que usted no puede ver.';
$lang['profile_notset'] = 'No se encontr� perfila para el usuario.';
$lang['send_mail'] = 'Enviar mensaje';
$lang['mail_messages'] = 'Mensajes';
$lang['col_head_subject'] = 'Tema';
$lang['col_head_sendtime'] = 'Fecha';

$lang['inbox'] = 'Entrada';
$lang['sent'] = 'Enviado';
$lang['trashcan'] = 'Eliminados';
$lang['reply'] = 'Responder';
$lang['read'] = 'Leer';
$lang['unread'] = 'No leido';
$lang['restore'] = 'Restaurar';
$lang['subject'] = 'Tema';
$lang['subject_colon'] = 'Tema:';
$lang['message'] = 'Mensaje';
$lang['send'] = 'Enviar';

$lang['send_letter'] = 'Enviar carta';
$lang['image_browser'] = 'Buscar imagen';
$lang['upload_image'] = 'Subir imagen';
$lang['delete_image'] = 'Borrar imagen';
$lang['show_image'] = 'Mostrar imagen';
$lang['send_invite'] = 'Enviar invitaci�n';
$lang['letter_title'] = 'Nueva Carta';
$lang['from_email'] = 'Desde Correo Electr�nico:';
$lang['from_name'] = 'Desde nombre:';
$lang['send_to'] = 'Enviar';
$lang['email_subject'] = 'Tema:';
$lang['save_as'] = 'Guardar';

$lang['no_message'] = 'No hay mensajes nuevos en la bandeja de entrada.';
$lang['descrip'] = 'Descripci�n';

//forgot password words
$lang['forgotpass_msg1'] = "Recordar usuario";
$lang['forgotpass_msg2'] = "Por favor ingrese la direcci�n de correo electr�nico que us� para crear su perfil para que se le env�e su nombre de usuario con una contrase� nueva. Luego, deber�a cambiar la contrase�a despu�s de ingresar.";
$lang['retreieve_info'] = 'Enviar';
$lang['forgotpass'] = 'Olvid� la Contrase�a';

//Tell a friend
$lang['tellafriend'] = 'Invita un amigo';
$lang['taf_msg1'] = 'Invita un amigo a ' . 'SITENAME';
$lang['taf_yourname'] = 'Tu nombre:';
$lang['taf_youremail'] = 'Tu correo electr�nico:';
$lang['taf_friendemail'] = "correo electr�nico de tu amigo:";

//Auto-mail
$lang['confirm_your_profile'] = 'Confirma tu registro';
$lang['letter_not_avail'] = 'Plantilla de carta no disponible';
$lang['confirm_letter_sent'] = 'Se ha enviado un correo electr�nico para confirmar tu direcci�n de correo electr�nico. Por favor abra el correo de confirmaci�n para terminar su registro.';
$lang['letter_not_sent'] = 'Hubo un problema al enviar el correo electr�nico.Contacte al administrador.';
$lang['or'] = 'O';
$lang['enter_confirm_code'] = 'Ingrese su c�digo de confirmaci�n debajo para completar su registro.';
// Affiliate auto-mail

$lang['aff_email_subject'] = 'Confirmar su cuenta de afiliaci�n';
$lang['aff_email_body'] = 'Gracias por crear su cuenta de afiliado con ' . 'SITENAME' . '. Por favor ingrese esta direci�n a la barra de direcciones del navegador para completar su registro:<br><br>#ConfirmationLink#';

//Page management

$lang['manage_pages'] = 'Administraci�n de p�gina';
$lang['pagetitle'] = 'T�tulo:';
$lang['pagetext'] = 'Siguiente:';
$lang['pagekey'] = 'Clave:';
$lang['addpage'] = 'Agregar p�gina';
$lang['page'] = 'P�gina:';
$lang['addnew'] = 'Agregar nueva';
$lang['modpage'] = 'Modificar P�gina';
$lang['pagekey_help'] = 'www.yourdomain.com/index.php?page=YOUR_KEY';

$lang['y_o'] = 'y/o';
$lang['lastlogged'] = '�ltima vez que entr�: ';
$lang['aff_stats'] = 'Estad�sticas de Afiliado';
$lang['total_referrals'] = 'Total de Referidos';
$lang['regis_referals'] = 'Referidos Registrados';
$lang['globalconfigurations'] = 'Configuraci�n Global';

$lang['send_message_to'] = 'Enviar mensaje a ';
$lang['writing_message'] = 'Escribir mensaje para ';
$lang['search_at'] = 'Buscar en ';

//Rating module
$lang['rate_profile'] = 'Clasificar Perfil';
$lang['worst'] = 'Peor';
$lang['excellent'] = 'Excelente';
$lang['rating'] = 'Rating';
$lang['submitrating'] = 'Ingresar clasificaci�n';

//Payment Modules
$lang['mship_changed'] = 'Se cambi� el nivel de la membres�a';
$lang['mship_changed_successfull'] = 'Su nivel baj� a Gratuito.';
$lang['no_payment'] = 'No se necesita Pago (Gratis)';
$lang['payment_modules'] = 'M�dulos de pago';
$lang['payment_methods'] = 'M�todos de pago';
$lang['business'] = 'Negocios:';
$lang['siteid'] = 'ID de Sitio:';
$lang['undefined_quantity'] = 'Cantidad no identificada:';
$lang['no_shipping'] = 'Sin env�o:';
$lang['no_note'] = 'Sin nota:';
$lang['on_off_values'] = array( 1 => 'Si', 0 => 'No' );
$lang['edit_payment_modules'] = 'Editar M�dulos de pago';
$lang['trans_key'] = 'Llave de transacci�n:';
$lang['trans_mode'] = 'modo de transacci�n:';
$lang['trans_method'] = 'M�todo de Transacci�n:';
$lang['username'] = 'Nombre de Usuario:';
$lang['username_without_colon'] = 'Nombre de Usuario';
$lang['country'] = 'Pa�s';
$lang['country_colon'] = 'Pa�s:';
$lang['state'] = 'Estado';
$lang['city'] = 'Ciudad';
$lang['location_col'] = 'Ubicaci�n:';
$lang['location_no_col'] = 'Ubicaci�n';
$lang['zip_code'] = 'C�digo postal';
$lang['attached_files'] = 'Archivos adjuntos';
$lang['cc_owner'] = 'Due�o Tarjeta de Cr�dito:';
$lang['cc_number'] = 'N�mero de Tarjeta de Cr�dito:';
$lang['cc_type'] = 'Tipo de Tarjeta de Cr�dito:';
$lang['cc_exp_date'] = 'Fecha vencimiento de Tarjeta de Cr�dito:';
$lang['cc_cvv_number'] = 'N�mero de Tarjeta de Cr�dito:';
$lang['cvv_help'] = '(ubicado detr�s de la Tarjeta de Cr�dito)';
$lang['continue'] = 'Continuar';
$lang['trans_method_vals'] = array(
	'CC' => 'Tarjeta de Cr�dito',
	'ECHECK' => 'Cheque Electr�nico'
	);
$lang['trans_mode_vals'] = array(
	'AUTH_CAPTURE' => 'AUTH_CAPTURE',
	'AUTH_ONLY' => 'AUTH_ONLY',
	'CAPTURE_ONLY' => 'CAPTURE_ONLY',
	'CREDIT' => 'CREDIT',
	'VOID' => 'VOID',
	'PRIOR_AUTH_CAPTURE' => 'PRIOR_AUTH_CAPTURE'
 );
$lang['cc_unknown'] = 'La empresa de la tarjeta de cr�dito es desconocida. Por favor intente de nuevo con otra tarjeta de cr�dito.';
$lang['cc_invalid_date'] = 'La fecha de vencimiento de la tarjeta de cr�dito no es v�lido. Por favor intente de nuevo con otra tarjeta de cr�dito.';
$lang['cc_invalid_number'] = 'El numero de la tarjeta de cr�dito no es v�lido. Por favor intente de nuevo con otra tarjeta de cr�dito.';
$lang['amount'] = 'Monto: ';
$lang['confirmation'] = 'Confirmaci�n';
$lang['confirm'] = 'Confirmar';
$lang['upgrade_membership'] = 'Cambiar membres�a';
$lang['changeto'] = 'Cambiar a';
$lang['current_mship_level'] = 'Nivel actual de la membres�a:';
$lang['membership_status'] = 'Estado de la membres�a';
$lang['you_currently'] = 'Actualmentes eres un/a ';
$lang['info_confirm'] = '�Es la informaci�n correcta?';
$lang['change_mship_to'] = 'Cambiar el Nivel de la membres�a a';
//Membership
$lang['permitmsg_1'] = 'Lo lamento pero su membres�a no le permite';
$lang['permitmsg_2'] = 'Por favor cambie si membres�a para usar ';
$lang['permitmsg_3'] = 'Gr�fico de comparaci�n de membres�as';
$lang['permitmsg_4'] = 'Gr�fico oculto de comparaci�n de membres�as';
$lang['membership_packages'] = 'Paquetes de membres�as';
$lang['membership_packages_compare'] = 'Comparaci�n de paquetes de membres�as';
$lang['modify'] = 'Guardar cambios';
$lang['manage_membership'] = 'Administraci�n de membres�as';
$lang['privileges_msg'] = 'Privilegios';
$lang['price'] = 'Precio: ';
$lang['currency'] = 'Moneda: ';
$lang['choose_membership'] = 'Elija una membres�a:';
$lang['add_membership'] = 'Agregue un nuevo tipo de membres�a';
$lang['membership_types'] = 'Tipo de membres�as';
$lang['member'] = 'miembro';

$lang['select_letter'] = 'Elegir carta:';
$lang['body'] = 'Cuerpo:';
$lang['module'] = 'M�dulo';
$lang['uninstall'] = 'Desinstalar';
$lang['install'] = 'Instalar';
$lang['modify_option'] = 'Modificar opci�n';

$lang['only_jpg'] = 'S�lo se permiten archivos JPG o GIF o PNG o BMP.';
$lang['upload_unsuccessful'] = 'no se pudo subir la foto.';
$lang['upload_successful'] = 'Se subieron las fotos.';
$lang['between1'] = 'Entre';
$lang['and'] = 'y';
$lang['profile_details'] = 'Detalles del Perfil';
$lang['personal_details'] = 'Detalles personales';


//Banner Management
$lang['manage_banners'] = 'Administraci�n de Banners';
$lang['add_banners'] = 'Agregar Banner';
$lang['edit_banners'] = 'Editar Banner';
$lang['size'] = 'Tama�o';
$lang['size_px'] = 'Tama�o (px)';
$lang['banner_linkurl'] = 'Banner / Direcci�n de V�nculo';
$lang['banner_sizes'] = array(
	'468X60' => '468 x 60',
	'100X500'=>'100 x 500',
	'120X120'=>'120 x 120'
);
$lang['banner_sizes_name'] = array( 'horizontal', 'vertical', 'cuadrado' );
$lang['startdate'] = 'Fecha Inicio:';
$lang['enddate'] = 'Fecha Fin:';
$lang['tooltip'] = 'Informaci�n:';
$lang['linkurl'] = 'Direcci�n de V�nculo:';
$lang['banner'] = 'Banner:';
$lang['total_banner'] = 'Total de Banners:';
$lang['online_users'] = 'M�mbros Conectados: ';
$lang['site_statistics'] = 'Estad�sitcas del Sitio';
$lang['pending_profiles'] = 'Perfiles Pendientes';
$lang['active_profiles'] = 'Perfiles Activos';
$lang['online_profiles'] = 'Perfiles en l�nea';
$lang['pending_aff'] = 'Afiliados Pendientes';
$lang['total_affiliates'] = 'Total de Afiliados';
$lang['active_aff'] = 'Afiliados Activos';
$lang['no_rating'] = 'Sin calificar';

//SEO Words
$lang['seo'] = 'Configuraci�n SEO';
$lang['seo_head'] = 'Optimizaci�n para motores de b�squeda';
$lang['sef_msg'] = 'Direcciones Amistosas para motores de b�squeda';
$lang['seo_enable'] = 'Permitir reescritura de direcciones con mod_rewrite:';
$lang['yes_msg'] ='La reescristura de direcciones es posible s�lo cuando se usa el servidor Apache, con la extensi�n mod_rewrite habilitada. Aseg�rese de cumplir con estos requerimientos. Adem�s, renombre el archivo .htaccess.txt como .htaccess.';
$lang['keywords'] = 'Palabras clave:';
$lang['page_tags_msg'] = 'T�tulo & Etiquetas Meta';
$lang['max_255'] = 'M�ximo 255 caracteres';

//News / Story / Article Manangement
$lang['manage_news'] = 'Administraci�n de Noticias';
$lang['manage_story'] = 'Administraci�n de historia';
$lang['manage_article'] = 'Administraci�n de Art�culos';
$lang['news_header'] = 'Encabezado';
$lang['total_news'] = 'Total de Noticias:';
$lang['total_articles'] = 'Total de Art�culos:';
$lang['total_stories'] = 'Total de historia:';
$lang['article_title'] = 'T�tulo';
$lang['story_sender'] = 'Remitente';
$lang['story_sender_msg'] = 'Id de Perfil [N�m]';
$lang['modify_article'] = 'Modificar Art�culo';
$lang['modify_news'] = 'Modificar Noticias';
$lang['modify_story'] = 'Modificar historia';
$lang['insert_article'] = 'Agregar Art�culo';
$lang['insert_story'] = 'Agregar historia';
$lang['insert_news'] = 'Agregar Noticias';
$lang['dat'] = 'Fecha:';

//Poll Words
$lang['manage_polls'] = 'Administraci�n de Encuestas';
$lang['modify_poll'] = 'Modificar Encuestas';
$lang['total_polls'] = 'Total de Encuestas';
$lang['poll'] = 'Encuestas';
$lang['add_polls'] = 'Agregar Encuestas';
$lang['add_options'] = 'Agregar Opciones';
$lang['active'] = 'Activar';
$lang['activate'] = 'Activar';
$lang['option'] = 'Opci�n';
$lang['modify_options'] = 'Modificar Opciones';
$lang['add_option_now'] = 'Agregar Opci�n ahora';
$lang['poll_options'] = 'Opciones de Encuestas';
$lang['votes'] = 'Voto(s)';
//Filter Records
$lang['filter_options'] = array(
	'id' => 'Id',
	'username' => 'Usuario',
	'city' => 'Ciudad',
	'zip' => 'C�digo Postal',
	'status' => 'Estado'
	);
$lang['first'] = 'Primero';
$lang['last'] = '�ltimo';
$lang['filter_records'] = 'Filtrar Registros';
$lang['search_at'] = 'Buscar en';
$lang['criteria'] = 'Criterio';

//Admin Management
$lang['manage_admins'] = 'Administraci�n';
$lang['total_admins'] = 'Total de Administradores';
$lang['add_admin'] = 'Agregar Administrador';
$lang['modify_admin'] = 'Modificar Administrador';
$lang['fullname'] = 'Nombre Completo';
$lang['please_be_sure'] = 'Aseg�rese de';
$lang['change_your_admin_pwd'] = 'cambiar su contrase�a de administrador.';
$lang['superuser'] = 'Super Usuario';
$lang['no_admin_user_msg1'] = 'No hay ning�n Usuario no-super administrador. Por favor cree uno.';
$lang['no_admin_user_msg2'] = 'Para crear un nuevo administrador ahora';
$lang['access_denied'] = 'Acceso negado';
$lang['not_authorize'] = 'no tiene permiso para acceder a esta p�gina. Por favor contacte a su Super Administrador.';

//Admin Permissions Management
$lang['admin_permissions'] = 'Permisos de Administrador.';
$lang['manage_admin_permissions'] = 'Direcci�n de permisos de administrador';
$lang['admin_users'] = 'Usuarios Administrador';
$lang['permissions'] = 'M�dulos';
$lang['superuser_noteditable'] = 'Nota: los Super Usuarios no se pueden editar.';
$lang['all'] = 'Todos';
$lang['selected'] = 'Seleccionados';
$lang['selected_users'] = 'Usuarios Seleccionados';
$lang['separate_users_by_coma'] = 'Ingrese nombres de usuarios separados por comas';
$lang['admin_rights'] = array(
		'site_stats' 				=> 'Estad�sticas del sitio',
		'profie_approval'		 	=> 'Perfiles a Aprobar',
		'profile_mgt' 				=> 'Administraci�n de Perfiles',
		'section_mgt' 				=> 'Administraci�n de Secci�n',
		'affiliate_mgt' 			=> 'Administraci�n de afiliados',
		'affiliate_stats'		 	=> 'Estad�sticas de afiliados',
		'news_mgt' 					=> 'Estad�sticas de Noticias',
		'article_mgt' 				=> 'Administraci�n de Art�culos',
		'story_mgt'					=> 'Administraci�n de historia',
		'poll_mgt'		 			=> 'Administraci�n de Encuestas',
		'search' 					=> 'Buscar',
		'ext_search'				=> 'B�squeda Extendida',
		'send_letter' 				=> 'Enviar Carta',
		'pages_mgt' 				=> 'Administraci�n de P�ginas',
		'chat' 						=> 'Chat',
		'chat_mgt' 					=> 'Administraci�n de Chat',
		'forum_mgt' 				=> 'Administraci�n de Foros',
		'mship_mgt' 				=> 'Administraci�n de Membres�a',
		'payment_mgt' 				=> 'M�dulo de pagos',
		'banner_mgt' 				=> 'Administraci�n de Banners',
		'seo_mgt' 					=> 'Configuraci�n SEO',
		'admin_mgt' 				=> 'Direcci�n de Administrador',
		'admin_permit_mgt'			=> 'Permisos de Administrador',
		'global_mgt' 				=> 'Configuraci�n',
		'change_pwd'				=> 'Cambiar Contrase�a',
		'cntry_mgt'					=> 'Administrar Pa�s/Estados/Ciudades',
		'snaps_require_approval'	=> 'Aprobar Fotos',
		'featured_profiles_mgt'		=> 'perfiles destacados',
		'calendar_mgt'				=> 'Calendarios',
		'event_mgt'					=> 'Aprobar Eventos',
		'import_mgt'				=> 'Importar',
	/* Added in 2.0 */
      	'plugin_mgt'            	=> 'Administraci�n de complementos',
		'blog_mgt'					=> 'Administraci�n de Blog',
		'profile_ratings'			=> 'Administraci�n de Calificaci�n de Perfiles',
		);

$lang['cntry_mgt']	= 'Administrar Pa�s/Estados/Ciudades';
$lang['register_now'] = '�Reg�strese y �nase a nuestra compa��a!';
$lang['addtobuddylist'] = 'Agregar una lista de amigos';
$lang['addtobanlist'] = 'Agregar una lista de censurados';
$lang['addtohotlist'] = 'Agregar una lista de m�s buscados';
$lang['buddylisthdr'] = 'Lista de amigos';
$lang['banlisthdr'] = 'Lista de censurados';
$lang['hotlisthdr'] = 'Lista de m�s buscados';
$lang['username_hdr'] = 'Usuario';
$lang['fullname_hdr'] = 'Nombre completo';
$lang['register'] = 'Reg�strese';
$lang['featured_profiles'] = 'Perfiles Calificados';
$lang['bigger_pic_size'] = 'El tama�o de la foto es mayor a lo permitido '.$config['upload_snap_maxsize'].' KB.';
$lang['snaps_require_approval'] = 'Aprobar Fotos';
$lang['events_require_approval'] = 'Aprobar Eventos';
$lang['upload_picture_caption'] = 'Foto Principal ';
$lang['upload_thumbnail_caption'] = 'Vista Previa';
$lang['Approve'] = 'Aprobar';
$lang['Remove'] = 'Remover';
$lang['userdetails'] = 'Informaci�n de Usuario';
$lang['pict'] = 'Foto';
$lang['tnail'] = 'Vista Previa';
$lang['reqact'] = 'Acci�n deseada';
$lang['newmemberlist'] = 'Miembros recientes';
$lang['yearsold'] = 'de edad';
$lang['Male'] = 'Var�n';
$lang['Female'] = 'Mujer';
$lang['showfulllist'] = 'mostrar lista completa';
$lang['featuredprofiles'] = 'Perfiles Calificados';
$lang['featured_profiles_hdr'] = 'Perfiles de Miembros Destacados';
$lang['nonfeatured_profiles_hdr'] = 'Miembros Normales';
$lang['level_hdr'] = 'Nivel';
$lang['date_from'] = 'Inicio';
$lang['date_upto'] = 'Hasta';
$lang['must_show'] = 'debe mostrar';
$lang['reqd_exposures'] = 'Exposiciones requeridas';
$lang['total_exposures'] = 'Total de Exposiciones';
$lang['add_featured'] = 'Agregar perfil a la lista de destacados';
$lang['mod_featured'] = 'Modificar perfil en lista de destacados';
$lang['member_since'] = 'Miembro desde';
$lang['invalid_username'] = 'Usuario no v�lido';
$lang['weekcnt'] = 'Miembros de la semana anterior:';
$lang['totalgents'] = 'Total de Miembros varones:';
$lang['totalfemales'] = 'Total de Miembros mujeres:';
$lang['weeksnaps'] = 'Fotos de la semana anterior:';
$lang['since_last_login'] = 'desde la �ltima sesi�n';
$lang['sincelastlogin_hdr'] ='Desde la �ltima sesi�n';
$lang['newmessages'] = 'Nuevos mensajes:';
$lang['profileviewed'] = 'N�mero de visitas del perfil:';
$lang['winks_received'] = 'N�meros de gui�os recibidos:';
$lang['send_wink'] = 'Enviar Gui�o';
$lang['listofviews'] = 'Lista de miembros que visitaron su perfil';
$lang['listofwinks'] = 'Lista de miembros que enviaron gui�os';
$lang['winkslist'] = 'lista de gui�os';
$lang['viewslist'] = 'Lista visitas';
$lang['suggest_poll'] = 'Sugerir encuesta';
$lang['savepoll'] = 'Enviar encuesta';
$lang['moreoptions'] = 'M�s opciones';
$lang['minimum_options'] = 'Dos opciones como m�nimo';
$lang['pollsuggested'] = '�Gracias! Su sugerencia ha sido enviada.';
$lang['suggested_by'] = 'Sugerido por:';
$lang['any_where'] = 'Cualquier lugar';
$lang['memberpanel'] = "P�gina del Miembro";
$lang['feedback_thanks'] = 'Gracias por sus comentarios. Su mensaje ha sido enviado a Administrador del sitio.';
$lang['cancel_hdr'] = 'Cancelar membres�a';
$lang['cancel_txt01'] = 'Pid�o cancelar su membres�a a <b>'.'SITENAME'.'</b>.<br /><br />�Est� seguro/a? ';
$lang['cancel_opt01'] = 'Si, seguro';
$lang['cancel_opt02'] = 'No, no quiero hacerlo ahora';
$lang['cancel_domsg'] = 'Gracias por usar '.'SITENAME'.'. <br><br>lamentamos que no est� m�s con nosotros, pero invitamos a que venga en cualquier momento y esperamos que nos encuentre �tiles.';
$lang['cancel_nomsg'] = 'Gracias por usar '.'SITENAME'.'.<br><br>Apreciamos su patronazgo y esperamos que nuestros servicio le resulten �tiles.';
$lang['reject'] = 'Rechazar';
$lang['unread'] = 'No le�do';
$lang['membership_hdr'] = 'Nivel de membres�a';
$lang['edit_pict'] = 'Editar foto principal';
$lang['edit_thmpnail'] = 'Editar Vista previa';
$lang['letter_options'] = 'Opciones de Carta';
$lang['pic_gallery'] = 'Fotos';
$lang['reactivate'] = 'Reactivar usuario';
$lang['cancel_list'] = 'Lista de miembros cancelados';
$lang['cancel_date'] = 'Fecha de Cancelaci�n';
$lang['language_opt'] = 'opci�n de Idioma' ;
$lang['change_language'] = 'Cambiar Idioma';
$lang['with_photo'] = 'que tiene una foto';
$lang['logintime'] = 'Tiempo de Sesi�n';
$lang['manage_country_states'] = 'Administrar Pa�s/Estados';
$lang['manage_countries'] = 'Administrar Pa�ses';
$lang['countries_count'] = 'N�mero de Pa�ses';
$lang['insert_country'] = 'Agregar Pa�s';
$lang['modify_country'] = 'Modificar Pa�s';
$lang['country_code'] = 'C�digo de Pa�s';
$lang['country_name'] = 'Nombre de Pa�s';
$lang['manage_states'] = 'Administrar Estado';
$lang['states_count'] = 'N�mero de Estados';
$lang['insert_state'] = 'Agregar estado';
$lang['modify_state'] = 'Modificar Estado';
$lang['state_code'] = 'c�digo de Estado';
$lang['state_name'] = 'Nombre de Estado';
$lang['totalcouples'] = 'Total de parejas miembros:';
$lang['active_days'] = '�V�lido por cu�ntos d�as?';
$lang['activedays_array'] = array('1'=>'1','7'=>'7','30'=>'30','90'=>'90','180'=>'180','365'=>'365','999'=>'999' );
$lang['expired'] = 'Su membres�a expir�. <a href="payment.php" class="errors">Renueve su membres�a</a> y siga disfrutando de los beneficios de '. 'SITENAME';
$lang['compose'] = 'Componer';

$lang['logout_login']='Para probar su contrase�a nueva, salga e inicie la sesi�n de nuevo.';
$lang['makefeatured'] = 'Haga clic para agregar este perfil a lista de perfiles destacados';
$lang['col_head_gender_short'] = 'Gn';
$lang['no_subject'] = 'Sin tema';
$lang['admin_col_head_fullname'] = $lang['col_head_fullname'];
$lang['select_from_list'] = '--Select--';

$lang['default_tz'] = '0.00';

$lang['manage_counties'] = 'P�is / Districto';
$lang['counties_count'] = 'No. de Pa�s/Districtos';
$lang['insert_county'] = 'Agregar Pa�s/Districtos nuevos';
$lang['modify_county'] = 'Modificar Pa�s/Districto';
$lang['county_code'] = 'C�digo de Pa�s/Districto';
$lang['county_name'] = 'Nombre de Pa�s/Districto';
$lang['manage_cities'] = 'Ciudades/Pueblos';
$lang['cities_count'] = ' No. de Ciudades/Pueblos';
$lang['insert_city'] = 'Agregar Ciudad/Pueblo nuevo';
$lang['modify_city'] = 'Modificar Ciudad/Pueblo';
$lang['city_code'] = 'C�digo de Ciudad/Pueblo';
$lang['city_name'] = 'Nombre de Ciudad/Pueblo';
$lang['manage_zips'] = 'C�digo Postal';
$lang['zips_count'] = 'No. de C�digo Postal';
$lang['insert_zip'] = 'Agregar C�digo Postal';
$lang['modify_zip'] = 'Modificar C�digo Postal';
$lang['zip_code'] = 'C�digo Postal';
$lang['show_form'] = 'Mostrar Formulario:';
$lang['change_album'] = 'Actualizar';


/* Following array is for Profile Window display heading conversion */
$lang['extsearchhead'] = array(
	'Marital Status'		=> 'Estado Civil',
	'Ethnicity'				=> 'Identidad �tnica',
	'Religion'				=> 'Religi�n',
	'Hobbies'				=> 'Hobbis',
	'Height'				=> 'Altura',
	'Body Type'				=> 'Tipo Cuerpo',
	'Zodiac Sign'			=> 'Signo de Zod�aco',
	'Eye color'				=> 'color de ojo',
	'Hair color'			=> 'Color de Cabello',
	'Body art'				=> 'Arte corporal',
	'Best feature'			=> 'mejor caracter�stica',
	'Hot spots'				=> 'Lugares favoritos',
	'Sports'				=> 'Deportes',
	'Favorite things'  		=> 'Cosas favoritas',
	'Last reading'			=> '�ltima lectura',
	'Common interests'		=> 'interese comunes',
	'Sense of humor'		=> 'Sentido de humor',
	'Exercise'				=> 'Ejercicio',
	'Daily diet'			=> 'Dieta diaria',
	'Smoking'				=> 'Fumar',
	'Drinking'				=> 'Bebida',
	'Job schedule'			=> 'Horario de Trabajo',
	'Current annual income' => 'Ingreso Anual',
	'Living situation'		=> 'Situaci�n de vivienda',
	'Kids'					=> 'Ni�os',
	'Want children'			=> 'Desea ni�os',
	'Weight'				=> 'Peso',
	'Employment status'		=> 'Estado Empleo',
	'Education'				=> 'Educaci�n',
	'Languages'				=> 'Idiomas',
	'Referred by'			=> 'Referido por',
);

/* user_stats */

$lang['your_user_stats'] = 'Sus estad�sticas ';
$lang['other_user_stats'] = 'Sus otras estad�sticas';

$lang['user_stats'] = 'Estad�sticas de usuario';
$lang['users_match_your_search'] = 'Usuarios que comparten tu b�squeda';
$lang['in_your_country'] = 'Usuarios que viven en tu pa�s';
$lang['in_your_state'] = 'Usuarios que viven en tu estado/provincia';
$lang['in_your_county'] = 'Usuarios que viven en tu condado/distrito';
$lang['in_your_city'] = 'Usuarios que viven en tu ciudad/pueblo';
$lang['in_your_zip'] = 'Usuarios que viven en tu c�digo postal';
$lang['in_same_gender'] = 'Usuarios del mismo sexo';
$lang['in_same_age'] = 'Usuarios de la misma edad';
$lang['above_lookagestart'] = 'Usuarios mayores a mi l�mite de edad';
$lang['below_lookageend'] = 'Usuarios menores a mi l�mite de edad';
$lang['your_lookgender'] = 'Usuarios que comparten tu inclinaci�n sexual';
$lang['in_look_country'] = 'Usuarios que viven en pa�s de b�squeda';
$lang['in_look_state'] = 'Usuarios que viven en estado/provincia de b�squeda';
$lang['in_look_county'] = 'Usuarios que viven en condado/districto de b�squeda';
$lang['in_look_city'] = 'Usuarios que viven en ciudad/pueblo de b�squeda';
$lang['in_look_zip'] = 'Usuarios que viven en c�digo postal de b�squeda';
$lang['in_same_timezone'] = 'Usuarios que viven en tu horario de b�squeda';
$lang['album_hdr'] = 'Album';
$lang['public'] = 'P�blico';
$lang['calendar_admin'] = 'Calendario de Administraci�n';

$lang['mysettings'] = 'Mi configuraci�n';
$lang['user_lists'] = 'Carpetas';
$lang['login_settings'] = 'Configuraci�n de sesi�n';
$lang['no_pics'] = 'Sin fotos';
$lang['my_page'] = 'Mi p�gina';
$lang['write_new_msg'] = 'Escribir mensaje';
$lang['view_winkslist'] = 'Ver gui�os';

// Import module
$lang['manage_import'] = 'Importar';
$lang['manage_import_datingpro'] = 'Importar desde DatingPro';
$lang['manage_import_aedating'] = 'Importar desde aeDating';
$lang['manage_import_section'] = 'Seleccionar m�dulo de Importaci�n';
$lang['manage_import_select'] = 'Seleccionar qu� importar';
$lang['module'] = 'M�dulo';
$lang['imported'] = 'Importado';
$lang['import'] = 'Importar';
$lang['empty'] = 'Vac�o';
$lang['select_section'] = 'Seleccionar Secci�n para preguntas';
$lang['import_db_configuration'] = 'Establecer configuraci�n de la base de datos original';
$lang['db_name'] = 'Nombre DB:';
$lang['db_host'] = 'Servidor DB:';
$lang['db_user'] = 'Usuario DB:';
$lang['db_pass'] = 'Contrase�a DB:';
$lang['db_prefix'] = 'Prefijos de Tabla:';


// Calendar
$lang['calendar_title'] = 'Administraci�n de Calendario';
$lang['total_calendars'] = 'Total de Calendarios:';
$lang['modify_calendar'] = 'Modificar Calendario';
$lang['modify_calendars'] = 'Modificar Calendarios';
$lang['delete_calendar'] = 'Eliminar Calendario';
$lang['delete_calendars'] = 'Eliminar Calendarios';

// Calendar Events
$lang['events_title'] = 'Administraci�n de Eventos';
$lang['insert_event'] = 'Agregar Eventos';
$lang['modify_event'] = 'Modificar Evento';
$lang['total_events'] = 'Eventos Seleccionados';
$lang['event'] = 'Evento:';
$lang['calendar_field'] = 'Calendario:';
$lang['private_to'] = 'Privado para:';
$lang['date_from'] = 'Fecha desde:';
$lang['date_to'] = 'Fecha hasta:';
$lang['col_head_calendar'] = 'Calendario';
$lang['col_head_username'] = 'Usuario';
$lang['col_head_fullname'] = 'Nombre completo';
$lang['col_head_event'] = 'Evento';
$lang['col_head_datefrom'] = 'Fecha desde';
$lang['col_head_dateto'] = 'Fecha hasta';
$lang['col_head_date'] = 'Fecha';
$lang['col_head_description'] = 'Descripci�n';

$lang['calendar_title'] = 'Calendario';
$lang['calendar'] = 'Calendario:';
$lang['event_title'] = 'Evento';
$lang['add_event'] = 'Agregar Evento';
$lang['delete_calendar_group_confirm_msg'] = '�Realmente quiere eliminar estos calendarios? No se podr� revertir.';
$lang['private_only'] = 'S�lo Privado';
$lang['public_only'] = 'S�lo P�blico';
$lang['public_private'] = 'P�blico y Privado';
$lang['total_events_found'] = 'Total de Eventos encontrados:';
$lang['start_date'] = 'Fecha Inicio';
$lang['start_time'] = 'Hora de Inicio';
$lang['end_date'] = 'Fecha Final';
$lang['end_time'] = 'Hora Final';
$lang['event_description'] = 'Descripci�n de Evento';

$lang['more_events'] = 'M�s Eventos >>';
$lang['daily_events_list'] = "Lista de eventos en ";
$lang['add_to_private'] = "Agregar a la lista Privada";
$lang['close_window'] = "Cerrar Ventana";
$lang['main_window_closed'] = "Lamentablemente usted cerr� la ventana principal.";
$lang['user_added1'] = "Usuario ";
$lang['user_added2'] = " agregado a la lista privada";
$lang['next_month'] = 'Mes siguiente';
$lang['previous_month'] = 'Mes Anterior';
$lang['next_week'] = 'Semana siguiente';
$lang['previous_week'] = 'Semana Anterior';
$lang['next_day'] = 'Siguiente D�a';
$lang['previous_day'] = 'D�a Anterior';
$lang['view_day'] = 'Vista diaria';
$lang['view_week'] = 'Vista semanal';
$lang['view_month'] = 'Vista mensual';

$lang['watched_events'] = 'Eventos que mira';
$lang['event_notification'] = 'Informe de Eventos';

$lang['jump_to'] = 'Saltar';
$lang['ok'] = 'Aceptar';

$lang['recurring'] = "Recurrente:";
$lang['recur_every'] = "cada";

$lang['recuring_labels'] = array(
	'0' => 'nunca',
	'1' => 'd�as',
	'2' => 'semanas',
	'3' => 'meses',
	'4' => 'a�os'
	);

$lang['calendat_filter_dates_range'] = "Rango de Fechas seleccionado";
$lang['calendat_filter_last_year'] = "�ltimo A�o";
$lang['calendat_filter_last_month'] = "�ltimo Mes";
$lang['calendat_filter_last_week'] = "�ltima semana";
$lang['calendat_filter_yesterday'] = "Ayer";


$lang['cannot_determine_membership'] = 'No se pudo determinar su nivel de membres�a';
$lang['no_previous_polls'] = 'No hay encuestas previas.';
$lang['no_event_for_the_day'] = "No hay eventos para esta fecha";
$lang['maxsize'] = 'Tama�o m�ximo permitido (KB)';
$lang['views'] = 'Vistas';

/******************************************/
/* ALL ERROR MESSAGES ARE DEFINED BELOW.  */
/******************************************/

// Affiliates error
$lang['affiliates_error'] = array(
	18 =>'Las contrase�as no son iguales',
	20 =>'Se requieren todos los campos.',
	21 =>'Se requieren todos los campos.',
	25 =>'La direcci�n de correo electr�nico que ingres� ya fue ingresada como afiliado. Por favor use otra direccion de corero electr�nico.'
);


// Javascript error messages
$lang['admin_js_error_msgs'] = array(
	'',
	'Primero seleccione una casilla de verificaci�n.',
	'�Realmente quiere procesar esta eliminaci�n?',
	'�Est� seguro de querer eliminar este banner?'
	);

$lang['admin_js__delete_error_msgs'] = array('',
	1=> '�Est� seguro de querer eliminar esta secci�n? No se podr� revertir.',
	2=> '�Est� seguro de querer eliminar esta pregunta? No se podr� revertir.',
	3=> '�Est� seguro de querer eliminar esta opci�n a la pregunta? No se podr� revertir.',
	4=> '�Est� seguro de querer eliminar este perfil? No se podr� revertir.',
	5=> '�Est� seguro de querer eliminar esta noticia? No se podr� revertir.',
	6=> '�Est� seguro de querer eliminar esta historia? No se podr� revertir.',
	7=> '�Est� seguro de querer eliminar este art�culo? No se podr� revertir.',
	8=> '�Est� seguro de querer eliminar esta encuenta? No se podr� revertir.',
	9=> '�Est� seguro de querer eliminar este opci�n de encuesta? No se podr� revertir.',
	10=> '�Est� seguro de querer eliminar este banner? No se podr� revertir.',
	11=> '�Est� seguro de querer eliminar este administrador? No se podr� revertir.',
/* Added in RC6 */
	12=>'�Realmente quiere eliminar este pa�s?',
	13=>'�Realmente quiere eliminar este estado/provincia',
	14=>'�Realmente quiere eliminar estos paises?',
	15=>'�Realmente quiere eliminar estos estados/provincias?',
	16=>'La b�squeda extendida en el encabezado debe ser inclu�da en la b�squeda extendida.',
	17 => 'Se debe ingresar los nombres de usuarios cuando se selecciona el rango del nombre del usuario.',
	18 => '�Est� seguro de querer eliminar este perfil? No se podr� revertir.',
/* Added Release 1.0 */
	19=>'�Est� seguro de querer eliminar este condado/districto?',
	20=>'�Est� seguro de querer eliminar este condados/districtos?',
	21=>'�Est� seguro de querer eliminar este ciudad/pueblo?',
	22=>'�Est� seguro de querer eliminar este ciudades/pueblos?',
	23=>'�Est� seguro de querer eliminar este c�digo postal?',
	24=>'�Est� seguro de querer eliminar este c�digos postales?',

	25 => '�Est� seguro de querer eliminar este evento? No se podr� revertir.',
	26 => '�Est� seguro de querer eliminar este calendario? No se podr� revertir.',
	27 => '�Est� seguro de querer eliminar esta p�gina? No se podr� revertir.',
	);


// Don't use double qoutes(") in the item's text
$lang['signup_js_errors'] = array(
	'username_noblank' => 'Por favor ingrese nombre de usuario.' ,
	'password_noblank' => 'Por favor ingrese contrase�a.',
	'old_password_noblank' => 'Se debe especificar contrase�a vieja.',
	'new_password_noblank' => 'Se debe especificar contrase�a nueva.',
	'con_password_noblank' => 'Se debe especificar contrase�a de confirmaci�n.',
	'firstname_noblank' => 'Se debe especificar nombre.',
	'name_noblank' => 'Por favor ingrese su nombre.',
	'lastname_noblank' => 'Se debe especificar Apellido.',
	'email_noblank' => 'Se debe especificar correo electr�nico.',
	'city_noblank' => 'Se debe especificar ciudad/pueblo.',
	'zip_noblank' => 'Se debe especificar C�digo Postal.',
	'address1_noblank' => 'Se debe especificar al menos una direcci�n.',
	'sectionname_noblank' => 'Por favor ingrese un nombre para esta secci�n.',
	'sendname_noblank' => 'Por favor ingrese el nombre del remitente.',
	'calendarname_noblank' => 'Por favor ingrese el nombre de este calendario.',
	'comments_noblank' => 'Por favor ingrese comentarios que desea enviar.',
	'question_noblank' => 'Por favor ingrese una pregunta.',
	'extsearchhead_noblank' => 'Por favor ingrese encabezado de b�squeda extendida.',
	'username_charset' => 'Solo letras, n�meros y subrayados \'_\' que ser�n permitidos en el nombre de usuarios.',
	'password_charset' => 'Solo letras, n�meros y subrayados \'_\' que ser�n permitidos en la Contrase�a.',
	'firstname_charset' => 'S�lo se permiten letras en el nombre.',
	'lastname_charset' => 'S�lo se permiten letras en el apellido.',
	'city_charset' => 'El nombre de la ciudad debe ser alfab�tica.',
	'zip_charset' => 'S�lo se permiten n�meros en el c�digo postal.',
	'address_charset' => 'Por favor ingrese una direcci�n v�lida.',
	'sectionname_charset' => 'S�lo se permiten letras para la secci�n del nombre.',
	'calendarname_charset' => 'S�lo se permiten letras para el nombre del calendario.',
	'sendname_charset' => 'S�lo se permiten letras el nombre del remitente.',
	'name_charset' => 'Por favor use letras para el campo de nombre.',
	'maxlength_charset' => 'Por favor ingrese un n�mero entero para la longitud m�xima.',
	'email_notvalid' => 'La direcci�n de correo electr�nico no es v�lida.',
	'password_nomatch' => 'Las Contrase�as no son iguales.',
	'password_outrange' => 'La longitud de Contrase�a debe estar dentro del rango especificado.',
	'username_outrange' => 'El N�mero de caracteres en el nombre del usuario debe estar dentro del rango especificado.',
	'username_start_alpha' => 'El usuario debe empezar con una letra.',
	'ccowner_noblank' => 'Se debe especificar el due�o de la tarjeta de cr�dito.',
	'ccnumber_noblank' => 'Se debe especificar el n�mero de la tarjeta de cr�dito.',
	'cvvnumber_noblank' => 'Se debe especificar el n�mero de la tarjeta de cr�dito.',
	'select_payment' => 'Por favor seleccione el m�todo de pago.',
	'stateprovince_noblank' => 'El nombre del estado/provincia debe estar disponible.',
	'subject_noblank'	=> 'Se debe ingresar el sujeto de la carta.',
	'county_noblank' => 'Se debe ingresar Condado/Districto.',
	'county_charset' => 'El Condado/Districto debe ser alfab�tico.',
	'timezone_noblank' => 'Se debe agregar huso horario.',
/* Added in 2.0 */
	'ratingname_noblank' => 'Se debe especificar el nombre de la calificaci�n.',
	'ratingname_charset' => 'Caracteres inv�lidos en el nombre de la calificaci�n.',
	'about_me_noblank' 	=> 'Debe ingresar tus datos.',
	);

$lang['letter_errormsgs'] = array(
		0 => 'Se envi� tu Contrase�a por correo electr�nico. Por favor comprueba tu correo electr�nico.',
		1 => 'Por favor ingresa la direcci�n de correo electr�nico que usaste cuando te registraste.',
		2 => 'No se encontr� la plantilla de Contrase�a perdida. Por favor contacta un administrador.',
		4 => 'Hubo un problema al enviar un correo electr�nico.Por favor contacta el administrador.',
		5 => 'No eres un miembro registrado de SITENAME. Por favor ingrese el correo electr�nico que usaste al momento del registro.'
	);

$lang['taf_errormsgs'] = array(
		0 => 'La invitaci�n fue enviada.',
		'sendername_noblank' => 'Por favor ingresa tu nombre.',
		'senderemail_noblank' => 'Por favor ingresa tu correo electr�nico.',
		'recipientemail_noblank' => 'Por favor introduzca un correo electr�nico v�lido para el recipiente.',
		'sendername_charset' => 'Por favor ingresa s�lo letras en tu nombre.',
		'senderemail_charset' => 'Por favor ingresa un correo electr�nico v�lido.',
		'recipientemail_charset' => 'Por favor ingresa un correo electr�nico v�lido para el recipiente.',
		2 => 'No se encuentra Plantilla Cu�ntale a un Amigo. Por favor contacta al administrador.',
		3 => 'Hubo un problema al enviar la invitaci�n. Por favor contacte al administrador.',
	);
$lang['pages_errormsgs'] = array( '',
	1 => 'No se encuentra el t�tulo de la p�gina.',
	2 => 'No se encuentra clave de p�gina.',
	3 => 'No se encuentra texto de la p�gina.',
	4 => 'La clave de p�gina existe. por favor elija otra.',
	5 => 'La p�gina fue eliminada.',
	);

$lang['artile_error'] = array(
	1 => 'El t�tulo del Art�culo es un campo requerido.',
	2 => 'El texto del Art�culo es un campo requerido.',
	3 => 'La Fecha del Art�culo es un campo requerido.'
);
$lang['story_error'] = array(
	1 => 'El encabezado de la historia es un campo requerido.',
	2 => 'El texto de la historia es un campo requerido.',
	3 => 'La fecha de la historia es un campo requerido.',
	4 => 'El remitente de la historia es un campo requerido.'
);
$lang['news_error'] = array(
	1 => 'El encabezado de noticias es un campo requerido.',
	2 => 'El texto de noticias es un campo requerido.',
	3 => 'La fecha de noticias es un campo requerido.'
);

$lang['mship_errors'] = array (
	1 => 'El nombre es un campo requerido.',
	2 => 'El precio es un campo requerido.',
	3 => 'La moneda es un campo requerido.',
	4 => 'S�lo cuando el nivel de la membres�a es Gratis se permite No tener M�todo de Pago.'
);
$lang['admin_error_msgs'] = array (
	'',
	'Secci�n es un campo requerido.',
	'Por favor ingrese todos los campos requeridos.'
	);
$lang['admin_error'] = array(
	'',
	1 => 'El nombre de usuario no puede estar vac�o.',
	2 => 'La Contrase�a del administrador no puede estar vac�o.',
	3 => 'el nombre completo del Administrador no puede estar vac�o.',
	4 => 'La Contrase�a vieja no puede estar vac�a.',
	5 => 'La Contrase�a nueva no puede estar vac�a.',
	6 => 'La Contrase�a de confirmaci�n no puede estar vac�a.',
	7 => 'La Contrase�a nueva y la Contrase�a de confirmaci�n deben ser iguales.',
	8 => 'Lae Contrase�a vieja que ingres� es incorrecta. Vuelva a intentar.',
	9 => 'El nombre de usuario ya est� en uso. Elija otro.',
	/* added in 1.1.0 */
	10 => 'Por favor elija valores de texto s�lo en nombre de secci�n'
);

$lang['banner_error_msgs'] = array( '',
	1 => 'El Banner no puede estar vac�o.',
	2 => 'La direcci�n del V�nculo no puede estar vac�o.',
	3 => 'Ayuda no puede estar vac�a.',
	4 => 'S�lo se permite banners .jpg.',
	5 => 'El tama�o del banner es m�s grande que el l�mite permitido.'
);
$lang['poll_error'] = array(
	1 => 'La encuesta no puede estar vac�a.',
	2 => 'La fecha de encuesta no puede estar vac�a.',
	3 => 'La opci�n no puede estar vac�a.',
	'txtpoll_noblank'  => 'Encuesta es un campo requerido.',
	'txtpollopt_noblank'  => 'La opci�n de encuesta es un campo requerido.'
	);

$lang['datetime_month'] = array(
	1=>'Enero',
	2=>'Febrero',
	3=>'Marzo',
	4=>'Abril',
	5=>'Mayo',
	6=>'Junio',
	7=>'Julio',
	8=>'Augosto',
	9=>'Septiembre',
	10=>'Octubre',
	11=>'Noviembre',
	12=>'Diciembre'
);
$lang['datetime_day'] = array(
	'sunday' => 'Domingo',
	'monday' => 'Lunes',
	'tuesday' => 'Martes',
	'wednesday' => 'Mi�rcoles',
	'thursday' => 'Jueves',
	'friday' => 'Viernes',
	'saturday' => 'S�bado'
);

/* Release 1.0.2   */
$lang['settings_saved'] = 'Ajustes salvados satisfactoriamente';
$lang['select_image_first'] = 'Por favor seleccione la imagen primero';

/* Release 1.1.0 additions */
$lang['day_names'] = array(
	'Sun' => 'Domingo',
	'Mon' => 'Lunes',
	'Tue' => 'Martes',
	'Wed' => 'Mi�rcoles',
	'Thu' => 'Jueves',
	'Fri' => 'Viernes',
	'Sat' => 'S�bado'
);
$lang['view_type'] = 'Tipo de Vista';
$lang['remember_me'] = 'Recu�rdame';
$lang['review'] = 'Reveer';
$lang['spammers'] = 'Spammers';
$lang['addquestion'] = 'Agregar pregunta';
$lang['mainstats'] = 'Estad�sticas principales';
$lang['osdate_version'] = 'Versi�n de osDate';
$lang['signonstats'] = 'Estad�sticas de Signon';
$lang['usersinpastminute'] = 'Usuarios en los �ltimos minutos';
$lang['usersinpasthour'] = 'Usuarios en los �ltima hora';
$lang['usersinpastday'] = 'Usuarios en los �ltimo d�a';
$lang['usersinpastweek'] = 'Usuarios en los �ltima semana';
$lang['usersinpastmonth'] = 'Usuarios en los �ltimo mes';
$lang['usersinpastyear'] = 'Usuarios en los �ltimo a�o';
$lang['usersinpast2years'] = 'Usuarios en los �ltimos 2 a�os';
$lang['usersinpast5years'] = 'Usuarios en los �ltimos 5 a�os';
$lang['usersinpast10years'] = 'Usuarios en los �ltimos 10 a�os';
$lang['userstats'] = 'Estad�sticas de Usuario';
$lang['totalusers'] = 'Total de Usuarios';
$lang['totalactiveusers'] = 'Total de usuarios activos';
$lang['totalpendingusers'] = 'Total de usuarios pendientes';
$lang['totalsuspendedusers'] = 'Total de usuarios suspendidos';
$lang['totalpictureusers'] = 'Total de usuarios con fotos';
$lang['totalonlineusers'] = 'Usuarios en l�nea';
$lang['visitorstats'] = 'Estad�sticas de Visitas';
$lang['sitestats'] = 'Estad�sticas del Sitio';
$lang['visitorstosite'] = 'Visita al sitio';
$lang['mostactivepage'] = 'La p�gina m�s activa';
$lang['timesfeedback'] = 'Las veces que el formulario de contacto fue usado';
$lang['timesim'] = 'Las veces que fue usada IM';
$lang['timeswink'] = 'Las veces que se envi� un gui�o';
$lang['timesmessage'] = 'Las veces que se envi� un mensaje a la bandeja de entrada';
$lang['timesinvitefriend'] = 'Las veces que se us� invitar a un amigo';
$lang['timeshowprofile'] = 'Las veces que se us� un perfil';
$lang['timesonlineusers'] = 'Las veces que se hizo click en usuarios en l�nea';
$lang['timesbanner'] = 'Las veces que se hizo click en banner';
$lang['timesnewmember'] = 'Las veces que se hizo click en miembros nuevos';
$lang['timespoll'] = 'Las veces que se us� las encuestas';
$lang['timesgallery'] = 'Las veces que se us� la galer�a de fotos';
$lang['timesaffiliates'] = 'Las veces que se hizo click en afiliados';
$lang['timessignup'] = 'Las veces que se hizo click en registrarse';
$lang['timesnews'] = 'Las veces que se hizo click en noticias';
$lang['timesstories'] = 'Las veces que se hizo click en historias';
$lang['timessearchmatch'] = 'Las veces que se hizo click en buscar coincidencias';
$lang['no_affiliates'] = 'N�mero de afiliados';
$lang['no_affiliate_refs'] = 'N�mero de referidos por afiliados';
$lang['no_pages_refs'] = 'N�mero de p�ginas referidas';
$lang['no_polls'] = 'N�mero de encuestas';
$lang['no_news'] = 'N�mero de items de noticias';
$lang['no_stories'] = 'N�mero de historias';
$lang['no_langs'] = 'N�mero de idiomas disponibles';
$lang['glblgroups'] = 'Grupo de configuraci�n global';
$lang['accept_tos'] = 'He le�do y acepto los <a href="javascript:popUpScrollWindow('."'tos.php','center',650,600);".'">T�rminos del servicio</a>';
$lang['tos_must'] = 'Por favor lea y acepte los T�rminos del Servicio antes de registrarse';
$lang['private_event'] = 'Esta informaci�n es privada';
$lang['posted_by'] = 'Publicado por';

$lang['countries01']='Pa�ses';
$lang['states01'] = 'Estados';
$lang['latitude'] = 'Latitud';
$lang['longitude'] = 'Longitud';
$lang['search_within'] = 'Buscar dentro';
$lang['miles'] = ' millas ';
$lang['kms'] = ' kil�metros ';
$lang['no_search_results'] = '<font color=red><b>0 Resultados encontrados</b></font><br /><br />No hay resultados que coincidan con su b�squeda. Tal vez quiere ampliar su b�squeda. Intenta reducir la b�squeda, por ejemplo por altura y edad, pero no por altura, edad y tipo de cuerpo. O, ampl�a el rango de tu b�squeda. Por ejemplo, en vez de buscar personas entre 40 y 50, busca personas entre 30 y 60.<br /><br />';
$lang['expire_on'] = 'La membres�a expira en';
$lang['expire_in'] = 'D�as que faltan hasta que la membres�a expire';
$lang['lang_to_load'] = 'idioma a cargar';
$lang['load_lang'] = 'Cargar idioma';
$lang['manage_languages'] = 'Administrar idiomas';
$lang['manage_zips'] = 'Administrar C�digo postal';
$lang['zipfile'] = 'Archivo de C�digo postal';
$lang['zip_loaded'] = 'Se cargan los C�digos postales desde un archivo ';
$lang['file_not_found'] = 'Dicho archivo no se encuentra en el sistema';
/* Modified in 1.1.0 */
$lang['success_mship_change'] = 'Muchas Gracias por actualizar/renovar su membres�a. <br /><br />Su nivel de socios fue cambiado satisfactoriamente ';
$lang['payment_cancel'] = 'Pago cancelado';
$lang['checkout_cancel'] = 'Como lo pidi�, su pago fue cancelado.';
$lang['useronlinetext'] = array(
	'online_now'		=> 	'En l�nea Ahora',
	'active_24hours'	=> 	'Activo dentro de 24 Horas',
	'active_3days'		=>	'Activo dentro de 3 D�a',
	'active_1week'		=>	'Activo dentro de 1 semana',
	'active_1month'		=>	'Activo dentro de 1 mes',
	'notactive'			=>	'No estar� activo'
);
$lang['useronlinecolor'] = array(
	'online_now'		=> 	'#FF0000',
	'active_24hours'	=> 	'#00AA00',
	'active_3days'		=>	'#AA00A0',
	'active_1week'		=>	'#0000AA',
	'active_1month'		=>	'#000000',
	'notactive'			=>	'#838383'
);

$lang['transactions_report'] = 'Informe de transacciones de pagos';
$lang['trans_count'] = 'C�lculo de transacciones';
$lang['pay_no'] = 'N�mero de Pago';
$lang['ref_no'] = 'Nro. Ref.';
$lang['paid_thru'] = 'Pagado por';
$lang['pay_status'] = 'Estado de Pago';
$lang['trans_rep'] = 'Informe de Pagos';
$lang['expiry_interval'] = array(
	'1'		=> '24 Horas',
	'3'		=>	'3 D�as',
	'7'		=>	'7 D�as',
	'15'	=>	'15 D�as',
	'30'	=>	'30 D�as',
	'0'		=>	'Expir�'
	);
$lang['expiry_hdr'] = 'Carta de recordatorio por Expiraci�n de Membres�a';
$lang['expiry_ltr'] = 'Carta por Expiraci�n de Membres�a';
$lang['expiry_select'] = 'Seleccionar int�rvalo de Expiraci�n';
$lang['expird'] = 'Expir�';
$lang['expiry_ltr_sent'] = 'Se enviaron las Cartas por Expiraci�n de Membres�a';
$lang['searching_within'] = 'B�scar dentro';
$lang['payment_failed'] = 'El proceso de pago fall�. Vu�lvalo a intentar.';
$lang['payment_fail'] = 'Fallo en el Pago';
$lang['deactivate'] = 'Desactivado';

$lang['open_search'] = 'Abrir B�squeda';
$lang['replace'] = 'Reemplazar';
$lang['new'] = 'Nuevo';
$lang['no_save'] = 'No guardar';
$lang['modify_curr_search'] = 'modificar criterios de b�squeda';
$lang['perform_search'] = 'y hacer b�squeda.';
$lang['start_new_search'] = 'Iniciar una b�squeda';
$lang['use_empty_form'] = 'usar un formulario vac�o.';
$lang['of_zip_code'] = 'de este c�digo postal';

/* MOD START */

$lang['profile_ratings'] = 'Calificar Perfil';
$lang['total_ratings'] = 'Total de Calificaciones';
$lang['delete_ratings'] = 'Eliminar Calificaciones';
$lang['delete_rating_group_confirm_msg'] = '�Est� seguro que quiere borrar estos ratings? No se podr� revertir.';
$lang['delete_rating_confirm_msg'] = '�Est� seguro que quiere borrar este rating? No se podr� revertir.';
$lang['modify_rating'] = 'Modificar Calificaciones';
$lang['modify_ratings'] = 'Modificar Calificaciones';

$lang['glblsettings_groups']['50'] = 'Calificaci�n de Perfil';
$lang['mod_lowtohigh']['Low to High'] = 'Bajo a Alto';
$lang['mod_lowtohigh']['High to Low'] = 'Alto a Bajo';
$lang['admin_rights']['profile_ratings'] = 'Calificaci�n de Perfiles';

$lang['custom_message'] = 'Mensaje Personalizado';
$lang['notify_me'] = 'Informarme cuando mi mensaje sea le�do.';
$lang['include_profile'] = 'Incluir mi perfil en este mensaje.';
$lang['message_templates'] = 'Plantilla de Mensajes';
$lang['my_templates'] = 'Mis Plantillas';
$lang['template_select'] = 'Por favor selecciona una plantilla';
$lang['template_intro'] = 'Si env�as mensajes frecuentemente los mismo mensajes a tus potenciales contactos, puedes crear plantillas para estos mensajes para reducir tu escritura. Al usar variables en las plantillas como [username] y [firstname], puede personalizar tus plantillas.';

$lang['add_template'] = 'Agregar Plantilla';
$lang['return_message'] = 'Volver al mensaje';
$lang['delete_template_confirm_msg'] = '�Realmente quieres eliminar esta Plantilla? No se podr� revertir.';
$lang['edit_template'] = 'Editar Plantilla';

$lang['template_instructions'] = 'Las siguientes variables en las plantillas son variables disponibles: <br />
[username], [firstname], [city], [state], [country], [age]<br /><br />Puedes usar estas variables en las plantillas para personalizar tus mensajes, por ejemplo:<br /><br />hi [firstname]!<br /><br />Me d� cuentas de que eres de [city].... �Yo tambi�n! :) Creo que podemos llevarnos bien... escr�beme si quieres saber m�s sobre mi.<br /><br />Saludos<br />Carlos';

$lang['your_comment'] = 'tus comentarios';
$lang['your_reply'] = 'Tu respuesta';
$lang['comment_note'] = 'Los comentarios mayores a 255 caracteres ser� acortados';
$lang['chars_remaining'] = 'son los caracteres que quedan';

$lang['delete_comment_confirm_msg'] = '�Realmente quieres eliminar este comentario? No se podr� revertir.';
$lang['no_msg_templates'] = 'No se encontraron plantillas.';
/* MOD END */

$lang['select'] = '- Seleccionar -';
$lang['select_country'] = 'Seleccionar Pa�s';
$lang['select_state'] = 'Seleccionar Estado/Provincia';
$lang['select_county'] = 'Seleccionar Condado';
$lang['select_city'] = 'Seleccionar Ciudad';
$lang['confirm_success'] = 'Inicia la sesi�n para disfrutar los beneficios de los miembros.';
$lang['signup_success_message'] = '<b>�Gracias!</b><br /><br />&nbsp;Ahora eres un usuario registrado de SITENAME.';
$lang['noone_online'] = 'Sin miembros en l�nea';
$lang['in_hot_list'] = 'El Usuario est� en la lista Calientes';
$lang['in_buddy_list'] = 'El usuario en la lista de amigos';
$lang['in_ban_list'] = 'El usuario est� en la lista de prohibidos';
$lang['delete_search'] = 'Borrar esta b�squeda';
$lang['select_user_to_send_message'] = 'Seleccionar un usuario para enviarle un mensaje';
$lang['no_im_msgs'] = 'Sin mensajes IM';
$lang['public_event'] = 'Esto lo puede ver el p�blico';
$lang['no_event_description'] = 'Sin descripci�n';
$lang['signup_js_errors']['country_noblank'] = 'El pa�s debe ser elegidos';
$lang['msg_sent'] = 'El mensaje ha sido enviado';
$lang['forgotpass_msg4'] = '�Olvidaste tu nombre de usuario? Tu nombre de usuario, con una contrase�a nueva, ser�n enviados a tu direcci�n de correo electr�nico. por favor usa la direcci�n que ingresaste al registrarte.';

/* 	Additions for new email messaging interface
	Vijay Nair
*/
$lang['send_a_message'] = 'Enviar mensaje';
$lang['flagged'] = 'Filtrar';
$lang['un_flagged'] = 'No Filtrar';
$lang['unflagged_msg1'] = 'no filtrar mensajes mas que ';
$lang['unflagged_msg2'] = ' d�as ser�n eliminados autom�ticamente.';
$lang['no_messages_in_box'] = 'No hay mensajes en la carpeta de la bandeja de entrada';
$lang['no_flagged_messages_in_box'] = 'No hay mensajes filtrados en este buz�n';
$lang['no_unflagged_messages_in_box'] = 'No hay mensajes no-filtrados en este buz�n';
$lang['mark'] = 'Marcar';
$lang['flag'] = 'Filtrar';
$lang['unflag'] = 'No-Filtrar';
$lang['msg_flagged'] = 'El mensaje est� filtrado';
$lang['msg_unflagged'] = 'El mensaje no est� filtrado';
$lang['msg_deleted'] = 'El mensaje est� eliminado';
$lang['sel_msgs_flagged'] = 'Los mensajes seleccionados est�n filtrados';
$lang['sel_msgs_unflagged'] = 'Los mensajes seleccionados no est� filtrados';
$lang['sel_msgs_deleted'] = 'Los mensajes seleccionados fueron eliminados';
$lang['sel_msgs_undeleted'] = 'Los mensajes seleccionados fueron recuperados';
$lang['sel_msgs_read'] = 'Los mensajes seleccionados est�n marcados como le�dos';
$lang['sel_msgs_unread'] = 'Los mensajes seleccionados est�n marcados como nuevos';
$lang['FROM1'] = 'De';
$lang['no_thanks'] = 'Di \"No Gracias\"';
$lang['reply'] = 'Respuesta';
$lang['undelete'] = 'Recuperar';
$lang['back_to_messages'] = 'Volver a Mensajes';
$lang['replied'] = 'Respuesta enviada';
$lang['no_thanks_subject'] = 'Gracias, pero No Gracias...';
$lang['total'] = 'Total';
$lang['max_allowed'] = 'M�ximo permitido';
$lang['im_msg_long'] = 'el mensaje IM es m�s grande de lo permitido ';
$lang['members'] = 'miembros';
$lang['To1'] = 'A';

/* Items which are modified in 1.1.0 */


$lang['change_email'] = 'Cambiar Correo electr�nico';

/* Changes made for letters  */
$lang['no_watched_event'] = 'No est�s viendo eventos ahora.
<br /><br />Hay #eventcount# eventos durante los siguintes 30 d�as. <a "#calenderlink#">Abrir el calendario</a> para verlos.
<br /><br />Para ver un evento, haz click en el calendario, y luego en el �cono de la lupa. #glassicon#
<br /><br />Cada item que agregues expirar� luego de que termine el evento.';

$lang['no_thanks_message']['text'] = 'Hola #recipient_username#,

Gracias por tu inter�s, pero debo rechazo tu invitaci�n. Espero que encuentres a alguien en el futuro #site_name#.

Saludos,
#sender_username#';

$lang['message_read']['text'] = "Estimado/a #FirstName#,

el mensaje fue enviado a '#RecipientName#' ha sido le�do.

�Buena Suerte!
#AdminName#
SITENAME";


$lang['featured_profile_added']['text'] = "Estimado/a #FirstName#,

Me da gran placer incluir su perfil en la lista de Perfiles Destacados en <a href=\"#link#\">#siteName#</a>.

Su perfil estar� destacado desde #FromDate# hasta #UptoDate#.

Esto aumentar� las posibilidades de ser visto y puede terminar en m�s visitas de posibles candiatos/as.

�Buena Suerte!
#AdminName#
SITENAME";

$lang['wink_received']['text'] = "Estimado/a #FirstName#,

Has recibido un gui�o de parte del usuario '#SenderName#' de #siteName#.

Por favor visita <a href=\"#link#\">#siteName#</a> para enviar a '#SenderName#' un mensaje, o devuelve el gui�o.

�Buena Suerte!
#AdminName#
SITENAME";

$lang['invite_a_friend']['text'] = "Hola,

Mientras navegaba por la Web encontr� un sitio muy bueno para hacer citas: #SiteUrl#.
Pens� que te pod�a gustar.

Visita #SiteUrl#.

#FromName#";

$lang['profile_confirmation_email']['text'] = "Estimado/a #FirstName#,

�Gracias por registrarse en #SiteName#! Como el miembro m�s nuevo de la comunidad, Le recomiendo que explore nuestros servicios y caracter�sticas.

Para confirmar su perfil, por favor haz click en el v�nculo de abajo. Y si no puede hacer click, c�pialo y p�galo en la barra de direcciones de tu navegador, para acceder a �l.

#ConfirmationLink#=#ConfCode#

Si todav�a tienes el ayudante de registro abierto, puedes ingresar el c�digo de confirmaci�n que se muestra.

Tu c�digo de confirmaci�n es: #ConfCode#

Hemos registrado la siguiente informaci�n:

Nombre de usuario: #StrID#
Contrase�a: #Password#
Correo electr�nico: #Email#

por favor mant�n esta informaci�n en un lugar seguro, para que puedas acceder a todos los servicio y caracter�sticas disponibles. Es posible que necesite llevar el nivel de mebres�a para acceder a algunos servicios, que puedes hacer aqu�:

#SiteUrl#payment.php

Gracias por usar nuestros servicios, Y �Esperamos que encuentres a quien buscar!

#AdminName#
#SiteName#";

/* Added in 1.1.1 */
$lang['loading'] = 'Cargando..';


/* Changes in 1.1.3 */
$lang['support_currency'] = array(
		'USD' 	=> '$',
		'EUR'	=>'�',
		'INR'	=>'Rs.',
		'AUD'	=> 'AU$',
		'CD'	=> 'CAN$',
		'UKP'	=> chr(163)
		);


$lang['ratings'] = 'Calificaciones';
$lang['comment'] = 'Comentario';
$lang['comments'] = 'Comentarios';
$lang['loadaction'] = 'Se necesita que hagas una selecci�n';
$lang['loadintodb'] = 'Cargar a la DB';
$lang['createsql'] = 'Crear script SQLt';

$lang['load_zips'] = 'Procesar archivo de C�digo Postal';



/* Version 2.0 additions and modifications */
/* Modifications */
$lang['zip_ensure'] = 'Por favor cargar archivo de C�digo Postal al directorio antes de continuar. <br /><br />El archivo debe contener  C�digo Postal, LATITUD, LONGITUD, C�digo de Estado, C�digo de Condado, C�digo de ciudad (en este orden. C�digo de estado, Se pueden omitir y agregar luego: C�digo de Condado y C�digo de ciudad) separados por comas.<br /><br />Para eliminar C�digo Postales de un Pa�s, debe seleccionar el pa�s y presionar el bot�n Eliminar';
$lang['submit'] = 'Enviar';
$lang['lang_ensure'] = 'Primero defina un archivo de idioma y un nombre de archivos en config.php (ver definiciones de $language_options y $language_files). Entonces cargar el archivo de idiomas en el directorio /idiomase/lang_xxxx/ es el archivo lang_main.php antes de seguir. (xxxx es el nombre del idioma en min�sculas. Por ejemplo: Ingl�s, Holand�s, etc.).<br /><br /><b>Para modificar y/o para agregar entradas existentes a la definici�n de idiomas, por favor haz los cambios necesario al archivo del idioma y vu�lvelo a cargar.</b><br /><br />Para remover definiciones para un idioma, selecciona el idioma y haz click en el bot�n "Eliminar el Idioma de la DB".';

/* $lang['rate_catefully'] is changed as below */
$lang['rate_carefully'] = 'Los operadores de este sitio no har�n reclamos por la precisi�n y confiabilidad de estas calificaciones.<br />Las calificaciones son hechas por usuarios, pero el personal las revisa.';


$lang['privileges'] = array (
	'chat' 				=> 'Participar en chat.',
	'blog'				=> 'Participar en blog.',
	'poll'				=> 'Participar en encuesta.',
	'forum'				=> 'Participar en foro.',
	'includeinsearch' 	=> 'Incluir en los resultados.',
	'message'			=> 'Enviar el mensaje a la bandeja de correo.',
	/* Added in 1.1.0 */
	'message_keep_cnt'  => 'N�mero de mensajes a mantener.',
	'message_keep_days' => 'N�mero de d�as que se mantendr�n los mensajes.',
	/* rel 2.0 */
	'messages_per_day' 	=> 'N�mero de mensajes que pueden ser enviados por d�a.',
	/* Rel 1.0 added  */
	'allowim'			=> 'Permitir mensajes intant�neos.',
	'uploadpicture'		=> 'Subir fotos.',
	'uploadpicturecnt'	=> 'C�lculos de fotos subidas.',
	'allowalbum'		=> 'Permitir �lbums privados.',
	'event_mgt'			=> 'Permitir administrador de eventos.',
	/* Above is added in 1.0 */
	'seepictureprofile' => 'Ver las fotos de perfiles.',
	'favouritelist'		=> 'Administrador lista de amigos/prohibidos/caliente.',
	'sendwinks'			=> 'Enviar gui�os.',
	/* rel 2.0 */
	'winks_per_day' 	=> 'N�meros de gui�os que pueden ser enviados por d�a.',
	'extsearch'			=> 'Realizar b�squeda extendida.',
	'fullsignup' 		=> 'Ingreso Completo.',
	/* RC6 Patch */
	'activedays'		=> 'D�as v�lidos para este Nivel.',
	/* added in 2.0 */
	'saveprofiles'		=> 'Permitir guardar el perfil.',
	'saveprofilescnt'	=> 'N�mero de perfiles permitidos que se guarden.',
	'allow_videos'		=> 'Permitir que se suban videos.',
	'videoscnt'			=> 'N�mero de videos permitidos que se guarden.',
	'allow_mysettings'	=> 'Permitir establecer perferencias del usuario.',
	'allow_php121'		=> 'Permitir mensajes instant�neos de php121.',

);

/* 	Signup Error Messages
	These are the signup error messages, Please do not change the sequence.
*/

$lang['errormsgs']= array(
	00 => '',
	01 => 'Nombre de Usuario es un campo requerido.',
	02 => 'Contrase�a es un campo requerido.',
	03 => 'Confirmar Contrase�a es un campo requerido.',
	04 => 'Nombre es un campo requerido.',
	05 => 'Apellido es un campo requerido.',
	06 => 'Direcci�n de Correo electr�nico es un campo requerido.',
	07 => 'Ciudad es un campo requerido.',
	08 => 'C�digo Postal es un campo requerido.',
	09 => 'L�nea de Direcci�n es un campo requerido.',
	10 => 'Longitud M�xima de Nombre de Usuario es de 25 caracteres.',
	11 => 'Longitud M�xima de Nombre es de 50 caracteres.',
	12 => 'Longitud M�xima de Apellido es de 50 caracteres.',
	13 => 'Longitud M�xima Direcci�n de Correo-e es de 255 caracteres.',
	14 => 'Longitud M�xima Ciudad es de 100 caracteres.',
	15 => 'Longitud M�xima L�nea de Direcci�n 1 es de 255 caracteres.',
	16 => 'Nombre de Usuario debe iniciar con una letra.',
	17 => 'Contrase�a debe iniciar con una letra.',
	18 => 'Contrase�a y confirmaci�n de Contrase�a debe coincidir.',
	19 => 'Por favor Ingrese una direcci�n de correo electr�nico v�lida',
	20 => 'La informaci�n requerida debe ser ingresada.',
	21 => 'Las credenciales de sesi�n que has provisto no permite acceso al sistema. Por favor verifique el ingreso y vuelva a intentar.',
	22 => 'El Nombre de Usuario ya existe, por favor elija otro.',
	23 => 'La Contrase�a vieja que has provisto no es correcta. Por favor verifique su Contrase�a vieja y vuelve a intentar.',
	25 => 'El correo electr�nico ya est� registrado.' ,
//	26 => "Su estado es 'No activo'. Por favor espere mientras activa su administrador." ,
	27 => 'No se puede encontrar mensaje.',
	28 => 'Por favor seleccione un archivo primero.',
	29 => 'El formato de archivo no soportado, por favor elija otro',
	30 => 'La pregunta ya se encuentra al inicio.',
	31 => 'La pregunta ya se encuentra al final.',
	32 => 'Gracias pos us comentarios. Pronto se procesaran sus comentarios ser�n procesados.',
	33 => 'El c�digo postal no coincide el rango especificado.',
	34 => 'El c�digo postal no es v�lido',
	36 => 'Su cuenta ha sido suspendida. Por favor contacte un administrador para m�s detalles.',
	37 => 'Sus ingresos fueron desechados. Por favor contacte un administrador para m�s detalles.',
	38 => 'Has especificado una fecha de nacimiento inv�lida. Verif�quela y vuelve a interntarlo.',
	39 => 'La Contrase�a nueva y la vieja deben coincidir',
	40 => 'la edad desde debe ser menor que la edad hasta',
	51 => 'La fecha de principio debe ser antes de la fecha de final',
	52 => 'Este miembro ya est� en la lista',
	53 => 'Fecha no v�lida',
	54 => 'Nombre de Usuario o Contrase�a No v�lidos',
	55 => 'Debe iniciar la sesi�n para enviar un mensaje',
	56 => $lang['bigger_pic_size'],
	57 => $lang['only_jpg'],
	58 => $lang['upload_unsuccessful'],
	59 => 'Este perfil se agrega a la lista',
	60 => 'El tama�o de la vista previa excede el m�ximo ('.$config['upload_snap_tnsize'].' X '.$config['upload_snap_tnsize'].')',
	61 => 'C�digo no v�lido de activaci�n',
	62 => 'El Nombre de Usuario fue removido de la lista',
	63 => 'Este Usuario ha sido agregado a la lista de amigos',
	64 => 'Este Usuario ha sido agregado a la lista de prohibidos',
	65 => 'Este Usuario ha sido agregado a la lista de Calientes',
	66 => 'Tu gui�o ha sido enviado a este usuario',
	67 => $lang['upload_successful'],
	68 => 'La foto ha sido aprobada',
	69 => 'La foto ha sido ha sido rechazada',
	70 => 'El registro de vistas ha sido removido',
	71 => 'El registro de gui�os ha sido removido',
	/* Added in RC6  */
	72 => 'El c�lculo de usuario ha sido reactivado',
	73 => 'El pa�s ha sido agregado',
	74 => 'El pa�s ha sido eliminado',
	75 => 'El c�digo de pa�s o nombre se encuentra en uso',
	76 => 'El Pa�s ha sido modificado',
	77 => 'El estado ha sido agregado',
	78 => 'El estado ha sido eliminado',
	79 => 'C�digo estatal o nombre ya esta en uso',
	80 => 'El estado ha sido modificado',
	81 => 'El nombre de estado/provincia debe ser especificado',
	82 => 'Ninguna imagen ha sido subida por este usuario. ',
	83 => 'El perfil ha sido borrado',
	84 => 'Los perfiles seleccionados son borrados.',

	85 => 'El perfil Seleccionado fue activado.',
	86 => 'El perfil Seleccionado fue rechazado.',
	87 => 'El perfil Seleccionado fue suspendido.',

	26 => 'Tu perfil no ha sido activado. <a href=\'completereg.php\'>Activar tu cuenta</a> al ingresa el c�digo de confirmaci�n al usar el v�nculo en el correo que se envi� por el correo electr�nico al registrase.',

//	26 => 'Tu cuenta de afiliado no ha sido activado por alg�n administrador. Por favor espera esta activaci�n antes de usar tu cuenta de afiliado.',

	35 => 'Tu perfil no fue aceptado.<br /> Espera a que te apruebe o contacte el Administrador',

/* Release 1.0 additions/modifications  */

	88 => 'El condado/districto ha sido agregado',
	89 => 'El condado/districto ha sido eliminado',
	90 => 'El c�digo de condado/districto ya est� en uso',
	91 => 'El condado/districto ha sido modificado',
	92 => 'La ciudad/pueblo ha sido agregado',
	93 => 'La ciudad/pueblo ha sido borrada',
	94 => 'El c�digo o nombre de Ciudad/pueblo se encuentra en uso',
	95 => 'La ciudad/pueblo ha sifo modificado',
	96 => 'El c�digo postal ha sido agregado',
	97 => 'El c�digo postal ha sido eliminado',
	98 => 'El c�digo postal se encuentra en uso',
	99 => 'El c�digo postal ha sido modificado',
	100 => 'Condado/Districto es una campo requerido',
	101 => 'Contrase�a No v�lida',
	102 => 'El evento no ha sido aprobado.',
	103 => 'El evento no ha sido rechazado.',
/* 1.1.0 additions */
	104 => 'El inicio que ha sido provisto no puede ser encontrado. Por favor verifique sus ingreso de nuevo, o use la opci�n detr�s para recordarla.',
	105 => 'El usuario est� en la lista de prohibidos',
	111 => 'Este miembro ya  est� en la lista de miembros destacada. ',
	/* Added in 2.0 */
	130 => 'El archivo de v�deo no puede ser convertido. Por favor use v�deo con formato .flv. ',
	131 => 'Usted ha excedido el n�mero de mensajes permitidos para su nivel de socios ',
	120	=> 'El c�digo de seguridad de ser ingresado',
	121 => 'C�digo de seguridad no v�lido ',
	122 => 'Ya has enviado el n�mero de mensajes permitidos por hoy. Por favor prueba ma�ana.',
	123 => 'Ya has enviado el n�mero de gui�os permitidos por hoy. Por favor prueba ma�ana.',
	124 => 'Se carg� el archivo de video',
	125 => 'El archivo de Video no fue cargado porque al subir los archivos hubo una falla.',
	126 => 'Debe ingresar sobre t�.',
	128 => 'El nombre de usuario individual de miembros que forman la pareja deber�a ser entrado.',
	129 => 'Nombres de Usuario debe estar disponible.',
	201 => 'Ya has guardado perfiles en la lista de seguimiento hasta tu l�mite',
	202 => 'Este perfil se agreg� a tu lista de perfiles seguidos',
	203 => 'Este perfil se ha agregado la lista de seguimiento',
	301 => 'Huso Horario No v�lido',
	302 => 'El �lbum ha sido actualizado',	
	);


$lang['alphanumeric'] = "0123456789.+-_#,/ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz ()_";
$lang['alphanum'] = "0123456789_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz ";
$lang['text'] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz '";
$lang['full_chars'] = "0123456789.+-_#,/ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz() _$+=;:'";
/* Additions  in Version 2.0 */

$lang['save'] = 'guardar';
$lang['delete_zips'] = 'Eliminar c�digo postal';
$lang['zipcodes_sql_created'] = 'Archivo sql de c�digos postales creado ';
$lang['zipcodes_loaded'] = 'Se cargaron los c�digos postales';
$lang['delzips_msg'] = 'Se eliminar�n todos los c�digos postales para este pa�s';
$lang['delzips_succ'] = 'Se eliminaron los c�digos postales para #COUNTRY#';
$lang['wrong_zipfile'] = 'Este archivo para este pa�s #COUNTRY#';
$lang['load_states'] = 'Procesar archivo de estados';
$lang['state_ensure'] = 'Por favor cargar archivo de c�digos de estados a directorio/estados antes de procesar. <br /><br />El archivo debe contener STATECODE y STATENAME separado por comas.(sin encabezado)<br /><br /> Los c�digos de estado por pa�s, seleccione el pa�s y presione el bot�n "Eliminar C�digos de Estado"';
$lang['statefile'] = 'Archivo de c�digos de estado';
$lang['delete_states'] = 'Borrar c�digos de estado';
$lang['delstates_msg'] = 'todos los c�digos de estado para esta pa�s ser� borrados';
$lang['delstates_succ'] = 'Los c�digos de estado �ra #COUNTRY#';
$lang['states_sql_created'] = 'El archivo sql para c�digos de estado fue creado ';
$lang['states_loaded'] = 'Se cargaron lso c�digos de estado ';
$lang['delete_lang'] = 'Remover idiomas de la BD';
$lang['langfile_loaded'] = 'Las definiciones para el idioma de #LANGUAGE# se cargan desde ';
$lang['lang_deleted'] = 'Se borraron las Definiciones para el idioma para #LANGUAGE#';
$lang['load_counties'] = 'Procesar archivo de Condados';
$lang['countyfile'] = 'Archivo de c�digos de Condados';
$lang['county_ensure'] = 'Por favor cargue el archivo de c�digos de condado/districto al directorio antes de procesar. <br /><br />El ingreso de archivo debe contener COUNTYCODE, COUNTYNAME y STATECODE separados por comas.(mismo orden, sin encabezado)<br /><br /> Para borrar los c�digos de condado/districto para un pa�s, selecciona el pa�s y presiona el bot�n "Eliminar C�digos de Condado"';
$lang['delete_counties'] = 'Eliminar c�digos de condados';
$lang['delcounties_msg'] = 'Todos los c�digos de condados/districtos ser� eliminados';
$lang['delcounties_succ'] = 'Los c�digos de Condado/Districto seleccionado para #COUNTRY# fueron eliminados';
$lang['counties_sql_created'] = 'Se creo archivo sql Condado/Districto ';
$lang['counties_loaded'] = 'Se cargaron los c�digos de Condado/Districto ';
$lang['load_cities'] = 'Procesar archivos de Ciudades';
$lang['cityfile'] = 'C�digos de archivos  de ciudad';
$lang['city_ensure'] = 'Por favor carga el archivo de c�digos para ciudad/pueblo al directorio antes de procesar. <br /><br />El archivo debe contener CITYCODE, CITYNAME, COUNTYCODE y STATECODE separado por comas.(mismo orden, sin encabezado)<br /><br /> Para eliminar los c�digo de ciudad/pueblo, seleccione el pa�s y presione el bot�n "Eliminar c�digos de Ciudad"';
$lang['delete_cities'] = 'Elimar c�digo de ciudad';
$lang['delcities_msg'] = 'Todos los c�digo/pueblo para este pa�s ser�n eliminados';
$lang['delcities_succ'] = 'Se elimar�n los c�digos de ciudad/pueblo para #COUNTRY#';
$lang['cities_sql_created'] = 'Se cre� el archivo sql para Ciudad/Pueblo ';
$lang['cities_loaded'] = 'Cargar los C�digos Ciudad/Pueblo desde ';
$lang['online'] = 'En l�nea';
$lang['watchedprofiles_1'] = 'Agregar a perfiles seguidos';
$lang['watchedprofiles'] = 'Perfiles seguidos';


$lang['poll'] = 'Encuesta';
$lang['section_poll_title'] = 'Encuesta';
$lang['section_poll_list'] = 'Lista de Encuesta';
$lang['section_add_poll'] = 'Crear Encuesta';
$lang['poll_subtitle_list'] = 'Lista de Encuesta';
$lang['poll_subtitle_add'] = 'Crear Encuesta';
$lang['poll_subtitle_edit'] = 'Editar Encuesta';
$lang['poll_number'] = 'N�mero';
$lang['poll_active_hdr'] = 'Activa';
$lang['poll_question_hdr'] = 'Preguntas';
$lang['poll_responses_hdr'] = 'Respuestas';
$lang['no_poll_found'] = 'No se encontraron Encuestas';
$lang['poll_question'] = 'Pregunta';
$lang['poll_options'] = 'Opciones';
$lang['poll_active'] = 'Activa';
$lang['poll_minimum_two'] = 'Al menos se necesita 2.';
$lang['results_poll_title'] = 'Resultados';
$lang['poll_subtitle_results'] = 'Resultados de la Encuesta';
$lang['take_poll_title'] = 'Tomar Encuesta';
$lang['poll_entries'] = 'Encuesta';


$lang['plugin'] = 'Complementos';
$lang['plugin_access'] = 'Acceso a Membres�a';
$lang['section_plugin_title'] = 'Complementos';
$lang['section_plugin_list'] = 'Lista de Complementos';
$lang['section_add_plugin'] = 'cargar Complementos';
$lang['plugin_subtitle_list'] = 'Lista de Complementos';
$lang['plugin_number'] = 'N�mero';
$lang['plugin_name'] = 'Nombre';
$lang['plugin_active'] = 'Activo';
$lang['plugin_installed'] = 'Instalado';
$lang['plugin_install'] = 'Instalado';
$lang['no_plugin_found'] = 'Se en encontraron complementos';
$lang['plugin_file'] = 'Subir archivo de complemento Zip';
$lang['plugin_subtitle_edit'] = 'Editar Complemento';
$lang['add_plugin_summary'] = 'La documentaci�n para creaci�n de Complementos se incluye la instalaci�n de osDate.';

$lang['blog']['hdr'] = 'Blog';
$lang['admin_blog'] = 'Sitio de Blog';
$lang['blog_default_bad_words'] = 'xxx|levitra';
$lang['blog_bad_words'] = 'Malas palabras';
$lang['blog_save_template'] = 'Guardar como plantilla';
$lang['blog_load_template'] = 'Cargar plantilla';
$lang['blog_bad_words_help'] = '(una palabra por l�nea)';
$lang['blog_search_results'] = 'B�squeda en Blog';
$lang['section_blog_info'] = 'Configuraci�n de Blog';
$lang['section_blog_list'] = 'Entradas del Blog';
$lang['section_blog_title'] = 'Blog';
$lang['blog_search_menu'] = 'B�squeda en Blog';
$lang['blog_search_username'] = 'Nombre de Usuario';
$lang['blog_search_title'] = 'T�tulo';
$lang['blog_search_body'] = 'Texto';
$lang['blog_search_Date'] = 'Fecha';

$lang['blog_subtitle_list'] = 'Lista de Blog';
$lang['blog_name'] = 'Nombre Blog';
$lang['blog_description'] = 'Descripci�n de Blog';
$lang['blog_members_comment'] = 'Comentarios de Miembros';
$lang['blog_buddies_comment'] = 'Comentarios de Amigos';
$lang['blog_members_vote'] = 'Voto de Miembros';
$lang['blog_gui_editor'] = 'Editor WYSIWYG';
$lang['blog_max_comments'] = 'Nro de Comentarios m�ximo';
$lang['no_blog_found'] = 'No se encontraron entradas';
$lang['section_add_blog'] = 'Crea entradas de Blog';
$lang['blog_subtitle_add'] = 'Crea entrada de Blog';
$lang['blog_subtitle_edit'] = 'Editar Blog';
$lang['blog_title'] = 'T�tulo';
$lang['blog_story'] = 'Contenido';
$lang['blog_posted_date'] = 'Fecha de Publicaci�n';
$lang['blog_title_hdr'] = 'T�tulo';
$lang['blog_rating_list_hdr'] = 'Calificaci�n';
$lang['blog_number'] = 'N�meros';
$lang['blog_date_posted_hdr'] = 'Fecha';
$lang['blog_views_hdr'] = 'Vista';
$lang['blog_votes_hdr'] = 'Votos';
$lang['blog_votes1'] = 'votos';
$lang['blog_rating_hdr'] = 'basado en';
$lang['blog_submit_vote'] = 'Voto';
$lang['blog_add_vote'] = 'Vota ahora';
$lang['view_blog'] = 'Ver Blog';
$lang['blog_entries'] = 'Blog:';
$lang['blog_creator'] = 'Autor';
$lang['blog_comments'] = 'Comentarios';
$lang['add_comment'] = 'Tus comentarios';
$lang['total_blogs_found'] = 'N�mero de entradas encontradas:';

$lang['blog_errors'] = array(
   'nosetup' => 'Se debe especificar la configuraci�n del inicio del Blog.' ,
   'name_noblank' => 'Se debe especificar nombre Blog.' ,
   'description_noblank' => 'Se debe describir Blog. ',
   'date_posted_noblank' => 'Se debe especificar fecha de publicaci�n.' ,
   'title_noblank' => 'Se debe especificar t�tulo.' ,
   'story_noblank' => 'Se debe especificar historia.' ,
   'max_stories_warning' => 'Has alncanzado el n�mero m�ximo de historias. No se puede agregar m�s.' ,
   'comment_bad_word' => 'Tu comentario contiene la palabra prohibida %s' ,
);
$lang['spell_check'] = 'Ortograf�a';

$lang['manage_import_webdate'] = 'Importar desde fecha Web';
$lang['import_config'] = 'Configuraci�n';

$lang['forum_values'] = array(
   'None' => 'Ninguno',
   'phpBB' => 'phpBB',
   'vBulletin' => 'vBulletin',
   'myBB' => 'myBB',
   'Phorum' => 'Phorum',
   );

$lang['photos_url'] = 'P�gina de inicio:';
$lang['ftp_username'] = 'Nombre de usuario:';
$lang['ftp_password'] = 'Contrase�a FTP:';
$lang['ftp_hostname'] = 'Servidor FTP:';
$lang['ftp_path'] = 'Ruta FTP aeDating:';
$lang['ftp_path_help'] = 'Path a el directorio aeDating registrado via ftp.  Ex. public_html/aeDating';

$lang['nopicsloaded'] = 'Sin fotos';
$lang['loadedpicscnt'] = 'foto(s) #PICSCNT# ';
$lang['loadedpicscnt1'] = 'foto #PICSCNT# ';
$lang['picsloaded'] = 'Fotos cargadas';
$lang['since'] = 'desde';
$lang['unknown'] = 'desconocido';

$lang['glblsettings_groups'] = array(
1	=>	'Informaci�n del Sitio',
2	=> 	'Controles del Usuario',
3	=>	'Controles de Calendario',
4	=>	'Configuraci�n de Correo',
5	=>	'Fotos y Vista Previas de de perfil',
6	=>	'Organizaci�n de P�gina y Tabla',
);

$lang['who_is_online'] = 'S�lo usuarios en l�nea';
$lang['search_with_photo'] = 'usuarios con fotos';
$lang['search_with_video'] = 'Usuarios con video';
$lang['expire_on_hdr'] = 'Expira en';
$lang['expird'] = 'Expir�';
$lang['pics'] = 'Fotos';
$lang['pic_deleted'] = 'Se remueve Fotograf�a seleccionada ';
$lang['entrycode_chars'] = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
$lang['enter_spamcode'] = 'C�digo de Seguridad';

/* Admin emails portion */

$lang['newpic']['html'] ='<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td class="module_head" width="100%" height="25"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25"><div class="module_head">#email_hdr_left#</div>
</td><td width="493" height="25"><div class="module_head">&nbsp;&nbsp;Nueva foto cargada por un usuario </div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" ><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="1"></td></tr><tr><td width="50%" valign="top" class="evenrow" >Estimado Administrador del sitio,
<br><br>El usuario <a href="#SiteUrl#admin/showprofile.php?username=#UserName#">#UserName#</a>ha cargado una foto nueva. <br><br>Nombre de usuario: #UserName#<br>Foto No.: #PicNo#<br><br>#AdminName# <br>SITENAME<br></td><td valign="top" class="evenrow" align="cemter">#smallPic#
</td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';


$lang['newpic']['text'] = "Estimado Administrador del sitio,

El usuario  #UserName# ha cargado una foto nueva.

Nombre de usuario: #UserName#
Foto No.: #PicNo#

#AdminName#
SITENAME";

$lang['newpic_sub'] = 'Mensaje de SITENAME: foto nueva cargada por usuario ';

$lang['newvideo']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25"><div class="module_head">#email_hdr_left#</div>
</td><td width="493" height="25"><div class="module_head">&nbsp;&nbsp;Nuevo video cargado por un usuario! </div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" ><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">Estimado  Administrador del sitio,<br><br>El usuario #UserName# ha cargado un nuevo video. <br><br>Nombre de usuario: #UserName#<br>Video No.: #PicNo#<br><br>#AdminName#<br>SITENAME<br></td>
</tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';


$lang['newvideo']['text'] = "Estimado Administrador del sitio,

El usuario #UserName# ha cargado un video nuevo.

Nombre de usuario: #UserName#
Video No.: #PicNo#

#AdminName#
SITENAME";

$lang['newvideo_sub'] = 'Mensaje de SITENAME: Un usuario ha cargado un video nuevo ';

/* Modified in 2.0 */
$lang['payment_msg1'] = 'M�todos de pago disponibles:';

$lang['wrong_activationcode'] = 'El c�digo de confirmaci�n especificado no es correcto o la cuenta ha sido confirmada.';

$lang['security_code_txt'] = 'por favor lea el texto en la foto dada abajo y escriba el texto en la caja cercana. Se le pide que haga esto para verificar la acci�n se realiza por un ser humano.';
$lang['additional_pics'] = 'Fotos adicionales';
$lang['view_all_pics'] = 'Vea todas las fotos';
$lang['insufficientPrivileges'] = 'No tienes suficientes privilegios para esta opci�n. Por favor actualize su nivel de membres�a.';
$lang['username_part_msg'] = "Si no est� seguro del usuario, ingrese cualquier parte para mostrar todas las posibles coincidencias. Por ejemplo, al ingresar 'user' se mostrar� 'user123', 'someuser', etc."
;
$lang['featured_profiles_msg01'] = "Debe mostrar: 'Si' si prefiere que este perfil sea elegido para mostrarlo en la lista de perfiles destacados. 'No' reducir� la posibilidad de ser seleccionado/a. ";

$lang['featured_profiles_msg02'] = "Exposiciones requeridas es el n�mero de Exposiciones requeridas antes de que el perfil sea sacado de la lista de perfiles destacados, si las Exposiciones se archivan antes de su fecha de expiraci�n";
$lang['lookup'] = 'Obtener';
/* for use in shoutbox */
$lang['sb_by'] = 'Publicado por:';
$lang['sb_hdr'] = 'Shoutbox';
$lang['sb_send'] = 'Enviar';
$lang['sb_error'] = 'Se ingres� texto mayor a lo permitido';
$lang['sb_msg_blank'] = '�Mensaje Shoutbox vac�o?';
$lang['sb_show_all'] = 'Mostrar todo';

$lang['upload_videos'] = 'Subir videos';
$lang['videoupload_format_msgs'] = 'S�lo se permite archivos .swf or .flv.';
$lang['video'] = 'Video';
$lang['upload_videos_ext'] = 'flv, swf';
$lang['upload_video_caption'] = 'Subir Video';
$lang['video_file'] = 'Archivo de Video';
$lang['vds'] = 'Vds';
$lang['manage_videos'] = 'Administrar videos';
$lang['videos_loaded'] = 'Cargar Videos';
$lang['novideos_loaded'] = 'Sin Videos';
$lang['loadedvdocnt'] = '#PICSCNT# video(s)';
$lang['loadedvdocnt1'] = '#PICSCNT# video';
$lang['video_gallery'] = 'Galer�a de Video';
$lang['picture_gallery'] = 'Galer�a de fotos';


/* New timezone display values Modified in 2.0 */
// These are displayed in the timezone select box
$lang['tz']['-25'] = '-- Select --';
$lang['tz']['-12.00'] = '(GMT -12:00) Eniwetok, Kwajalein';
$lang['tz']['-11.00'] = '(GMT -11:00) Midway Island, Samoa';
$lang['tz']['-10.00'] = '(GMT -10:00) Hawaii';
$lang['tz']['-9.00'] = '(GMT -9:00) Alaska';
$lang['tz']['-8.00'] = '(GMT -8:00) Pacific Time (US & Canada)';
$lang['tz']['-7.00'] = '(GMT -7:00) Mountain Time (US & Canada)';
$lang['tz']['-6.00'] = '(GMT -6:00) Central Time (US & Canada), Mexico City';
$lang['tz']['-5.00'] = '(GMT -5:00) Eastern Time (US & Canada), Bogota, Lima';
$lang['tz']['-4.00'] = '(GMT -4:00) Atlantic Time (Canada), Caracas, La Paz';
$lang['tz']['-3.5'] = '(GMT -3:30) Newfoundland';
$lang['tz']['-3.00'] = '(GMT -3:00) Brazil, Buenos Aires, Georgetown';
$lang['tz']['-2.00'] = '(GMT -2:00) Mid-Atlantic';
$lang['tz']['-1.00'] = '(GMT -1:00 hour) Azores, Cape Verde Islands';
$lang['tz']['0.00'] = '(GMT) Western Europe Time, London, Lisbon, Casablanca';
$lang['tz']['1.00'] = '(GMT +1:00 hour) Brussels, Copenhagen, Madrid, Paris';
$lang['tz']['2.00'] = '(GMT +2:00) Kaliningrad, South Africa';
$lang['tz']['3.00'] = '(GMT +3:00) Baghdad, Riyadh, Moscow, St. Petersburg';
$lang['tz']['3.5'] = '(GMT +3:30) Tehran';
$lang['tz']['4'] = '(GMT +4:00) Abu Dhabi, Muscat, Baku, Tbilisi';
$lang['tz']['4.5'] = '(GMT +4:30) Kabul';
$lang['tz']['5.00'] = '(GMT +5:00) Ekaterinburg, Islamabad, Karachi, Tashkent';
$lang['tz']['5.5'] = '(GMT +5:30) Bombay, Calcutta, Madras, New Delhi';
$lang['tz']['6.00'] = '(GMT +6:00) Almaty, Dhaka, Colombo';
$lang['tz']['6.5'] = 'GMT + 6.30) ';
$lang['tz']['7.00'] = '(GMT +7:00) Bangkok, Hanoi, Jakarta';
$lang['tz']['8.00'] = '(GMT +8:00) Beijing, Perth, Singapore, Hong Kong';
$lang['tz']['9'] = '(GMT +9:00) Tokyo, Seoul, Osaka, Sapporo, Yakutsk';
$lang['tz']['9.5'] = '(GMT +9:30) Adelaide, Darwin';
$lang['tz']['10.00'] = '(GMT +10:00) Eastern Australia, Guam, Vladivostok';
$lang['tz']['11.00'] = '(GMT +11:00) Magadan, Solomon Islands, New Caledonia';
$lang['tz']['12.00'] = '(GMT +12:00) Auckland, Wellington, Fiji, Kamchatka';
$lang['tz']['13.00'] = '(GMT + 13)';

$lang['myprofile'] = 'Mi perfil';
$lang['myblog'] = 'Mi Blog';
$lang['profilesearch'] = 'Buscar perfil';
$lang['mylists'] = 'Mis Listas';
$lang['bans'] = 'Prohibidos';
$lang['mybuddies'] = 'Mis amigos';
$lang['hotprofiles'] = 'Perfiles Calientes';
$lang['winks'] = 'Gui�os';
$lang['tools'] = 'Herramientas';
$lang['picturegallery'] = 'Mi galer�a de fotos';
$lang['videogallery'] = 'Mi galer�a de fotos';
$lang['membership'] = 'Mi membres�a';
$lang['adminhome'] = 'Inicio Administrador';
$lang['membershdr'] = 'Miembros';
$lang['memberprofiles'] = 'Perfiles de Miembros';
$lang['membersearch'] = 'Buscar Miembros';
$lang['blogs'] = 'Blogs';
$lang['blogsearch'] = 'Buscar Blogs';
$lang['affiliateshdr'] = 'Afiliados';
$lang['localities'] = 'Localidades';
$lang['contenthdr'] = 'Contenido';
$lang['financial'] = 'Financiero';
$lang['plugins_hlp'] = 'Se puede usar Complementos de Administrativos administradores y moderadores con suficientes permisos, y aparece autom�ticamente al final del men� de izquierda cuando se activa. Se puede acceder a los complementos de miembros desde el panel de miembros';

/* HTML and some text emails */
$lang['no_thanks_message']['html'] = 'Hola #recipient_username#,<br><br>Gracias por tu inter�s, pero debe rechazar tu invitaci�n. Espero que encuentres a alguien en el futuro en #site_name#.<br><br>Saludos,<br><br>#sender_username#';


/* old format
$lang['wink_received']['html'] = "Estimado #FirstName#,<br><br>Has recibido un gui�o de parte de un usuario de #siteName#  '#SenderName#'.<br><br>Por favor visita <a href=\"#link#\">#siteName#</a> para enviar '#SenderName#' un mensaje, env�ale un gui�o.<br><br>�Buena Suerte!<br>#AdminName#";
$lang['letter_winkreceived_sub'] = '#SITENAME# - Has recibido un gui�o';

New format below
*/

$lang['mail']['hdr_text'] = '<font style="color:red; font-size: 9px;">Para dejar de recibir este tipo de correos, <a href="#SiteUrl#">ingresa a</a> y cambia tus preferencias de correo en el men� del usuario.<br>Para asegurarse que reciba estos correos agrega <a href="mailto:#AdminEmail#">#AdminEmail#</a> a tu libro de direcciones ahora.</font><br><br>';
$lang['mail']['hdr_html'] = '<table border=0 cellspacing=0 cellpadding=5 width="570"><tr><td ><font style="color:red; font-size: 9px;">Para dejar de recibir estos correos electr�nicos, <a href="#SiteUrlLogin#">ingresa</a> y cambia tus preferencias de correo en el men� del usuario.<br>Para asegurarse que reciba estos correos electr�nicos,  por favor agregue <a href="mailto:#AdminEmail#">#AdminEmail#</a> a tu libro de direcciones ahora.</font></td></tr><tr><td height="6"></td></tr></table>';

$lang['letter_winkreceived_sub'] = 'Mensaje SITENAME Message: �#SenderName# te ha hecho un gui�o! ';
$lang['wink_received']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25px">#email_hdr_left#</td><td width="493" height="25" ><div class="module_head">&nbsp;&nbsp;#SenderName# te ha hecho un gui�o!</div>
</td></tr></table></div></td></tr><tr><td width="570" class="evenrow" colspan="2" ><div class="evenrow" ><table border="0" cellspacing="2" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="50%" valign="top">#smallProfile#</td><td width="50%" valign="top">
		� De todos los miembros, #SenderName# te ha elegido para hacerte un 
		gui�o! Usted puede guardar la coqueter�a por atras del gui�o, o enviando 
		un correo electr�nico.<br><br><a href="#SiteUrl#compose.php?recipient=#UserId#">E-mail #SenderName# now</a><br><br><a href="#SiteUrl#sendwinks.php?ref_id=#UserId#&amp;rtnurl=showprofile.php">Return the wink</a><br>
<br><b>No Interesado?</b><br>De a&nbsp; #SenderName# al saber de esto usted no 
		esta interesado por enviar un mensaje de&nbsp; "No, gracias" <br><br>
		<a href="#SiteUrl#compose.php?recipient=#UserId#&reply=11">Dice "No, 
		gracias"</a><br><br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';


/* old format
$lang['profile_confirmation_email']['html'] = "Estimado/a #FirstName#,<br><br>Gracias por registrarse a #SiteName#! As the newest member of our community, I encourage you to explore our services and features.<br><br>To confirm your profile addition, please click the link below. Or, if the link is not clickable, copy and paste it into address bar of your web browser, to directly access it.<br><br><a href=\"#ConfirmationLink#=#ConfCode#\">#ConfirmationLink#=#ConfCode#</a><br><br>If you still have the final step of the registration wizard open, you can input your confirmation code on that screen.<br><br>Your confirmation code is: #ConfCode#<br><br>We have recorded the following registration information for you:<br><br>Nombre de usuario: #StrID#<br>Password: #Password#<br>E-Mail: #Email#<br><br>Please keep this information in a safe, secure place, so that you will be able to access all of the services and features available to you. Some services may require an upgrade to a higher membership level, which you can do here:<br><br>#SiteUrl#payment.php<br><br>Gracias por usar nuestros servicio, �esperamos que encuentres a quie buscas!<br><br>#AdminName#<br>#SiteName#";

New format below
*/
$lang['profile_confirmation_email_sub'] = 'Mensaje SITENAME: Gracias por registrarse a SITENAME!';
$lang['profile_confirmation_email']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570">
<tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%">
<tr><td width="77" height="25" >#email_hdr_left#</td><td width="493"  height="25"><div class="module_head">&nbsp;&nbsp;#Welcome#!</div></td></tr></table></div></td></tr><tr><td width="570" class="evenrow" colspan="2" >
<div class="evenrow" ><table border=0 cellspacing=0 cellpadding=5 width="100%"><tr><td> Estimado /a  #FirstName#,<br><br> Gracias por registrarse en  #siteName#! Como el miembro m�s nuevo de la comunidad, le recomiendo que explore nuestros servicios y caracter�sticas.<br><br> Para confirmar su perfil, por favor haz click en el v�nculo de abajo. Y si no puede hacer click, c�pialo y p�galo en la barra de direcciones de tu navegador, para acceder a �l.<br><br>
<a href=\"#ConfirmationLink#=#ConfCode#\">#ConfirmationLink#=#ConfCode#</a><br><br> Si todav�a tienes el ayudante de registro abierto, puedes ingresar el c�digo de confirmaci�n que se muestra.<br><br> Su c�digo de confirmaci�n es: <b>#ConfCode#</b><br><br> Hemos registrado la siguiente informaci�n de registro para usted:<br>
<br> Nombre de usuario:  <b>#StrID#</b><br> Contrase�a:  <b>#Password#</b><br> Correo electr�nico: <b>#Email#</b><br><br> por favor mant�n esta informaci�n en un lugar seguro, para que puedas acceder a todos los servicio y caracter�sticas disponibles. Es posible que necesite llevar el nivel de mebres�a para acceder a algunos servicios, que puedes hacer aqu�:<br><br><a href="#SiteUrl#payment.php">#Upgrade#</a><br><br> Gracias por usar nuestros servicios, Y �Esperamos que encuentres a quien buscar! <br><br>
#AdminName#<br>#siteName#</td></tr></table></div></td></tr>
<tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';


/* old format
$lang['message_received']['text'] = "Estimado/a #FirstName#,

Has recibido un mensaje del usuario de SITENAME,  '#SenderName#'.

Por favor visita <a href=\"#link#\">SITENAME</a> para responder este mensaje.

�Buena Suerte!
#AdminName#";

$lang['message_received']['html'] = "Estimado/a #FirstName#,<br><br>Has recibido un mensaje del usuario de #siteName#, '#SenderName#'.<br><br>Por favor visita <a href=\"#link#\">#siteName#</a>  para responder este mensaje.<br><br>�Buena Suerte!<br>#AdminName#";

New format below
*/
$lang['message_received_sub'] = 'Mensaje SITENAME: RE: solo para tu informaci�n...';
$lang['message_received']['text'] = "Estimado/a #FirstName#,

Has recibido un mensaje del usuario de SITENAME, '#SenderName#'.

Por favor visita  <a href=\"#link#\">SITENAME</a> para responder este mensaje.

�Buena Suerte!
#AdminName#
SITENAME";

$lang['message_received']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25"><div class="module_head">
#email_hdr_left#</div></td><td width="493" ><div class="module_head">&nbsp;&nbsp;�Un munsaje nuevo de #SenderName#! </div></td></tr></table></div></td></tr><tr><td width="570" class="evenrow" colspan="2" ><div class="evenrow" ><table border="0" cellspacing="2" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="50%" valign="top" class="evenrow">
<table width="100%" border=0 cellspacing=0 cellpadding=0><tr><td width="25%" ><div class="newshead">#De#:</div></td><td width="75%">#SenderName#</td></tr><tr><td><div class="newshead">#A#:</div></td><td>#UserName#</td></tr><tr><td  >
<div class="newshead">#Fecha#:</div></td><td>#MESSAGE_DATE# </td></tr><tr><td ><div class="newshead">#Tema#:</div></td><td>#MSG_SUBJECT#</td></tr><tr><td colspan="2" height="6">
</td></tr><tr><td colspan=2>Estimado/a #FirstName#,<br><br>As recibido un mensaje de #SenderName#.<br><br>Por favor visita <a href=\"#link#\">SITENAME</a> para responder este mensaje. <br><br>Buena suerte!<br>#AdminName#<br>SITENAME<br></td></tr></table>
</td><td width="50%" valign="top" class="oddrow"><div class="oddrow">#smallProfile#</div></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

/* Old format
$lang['letter_featuredprofile_sub'] = '#SITENAME# - Lista de perfiles destacados';
$lang['featured_profile_added']['html'] = "Estimado/a #FirstName#,<br><br>Nos da gran placer incluir tu perfil en la lista de perfiles destacados en <a href=\"#link#\">#siteName#</a>.<br><br>Tu perfil estar� destacado desde #FromDate# hasta #UptoDate#.<br><br>Esto aumentar� tus posibilidades de que te vean y puede conseguirte m�s visitas y m�s coincidencias<br><br>�Buena suerte!<br>#AdminName#";

new format
*/
$lang['letter_featuredprofile_sub'] = 'Mensaje SITENAME: �Tu perfil pronto estar� destacado!';
$lang['featured_profile_added']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr>
<td width="77" height="25" ><div class="module_head">#email_hdr_left#</div>
</td><td width="493" ><div class="module_head">&nbsp;&nbsp;� Tu perfil pronto estar� desatacado! </div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" >
<div class="evenrow"><table border="0" cellspacing="0" cellpadding="5"><tr><td width="100%" valign="top" class="evenrow">
	Estimado/a #FirstName#,<br><br>
	Nos da mucho placer incluir tu perfil en la lista de Perfiles Destacados <a href=\"#link#\">SITENAME</a>.<br><br>
	�Tu perfil pronto estar� destacado! <b>#FromDate#</b> hasta <b>#UptoDate#</b>.<br>
<br>Esto aumentar� tus posibilidades de que te vean y puede conseguir m�s 
	visitas y m�s coincidencias.<br><br>!Buena Suerte!<br>#AdminName# <br>SITENAME<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

/* old format

$lang['profile_activated_sub'] = '#SITENAME# - �Tu perfil est� activado!';
$lang['profile_activated']['html'] = "Estimado/a #FirstName#,<br><br>Esta es una notifiaci�n autom�tica para informarte que tu perfil en #siteName# ha sido activado con esta membres�a #MembershipLevel#. Ven y visitanos en <a href=\"#link#\">#siteName#</a>.<br><br>�Buena Suerte!<br>#AdminName#";

new format */

$lang['profile_activated_sub'] = 'Mensaje: SITENAME:  �Tu perfil est� activado!';

$lang['profile_activated']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" ><div class="module_head">
#email_hdr_left#</div></td><td width="493"><div class="module_head">&nbsp;&nbsp;�Tu 
		perfil est� activado!</div></td></tr></table></div></td></tr><tr>
<td width="100%" class="evenrow" colspan="2"><div class="evenrow"><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr>
<tr><td width="100%" valign="top" class="evenrow">Estimado/a #FirstName#,<br><br>
	Nos da mucho placer darte la bienvenida a SITENAME. <br><br>Tu perfil est� 
	activado con el nivel <b>#MembershipLevel#</b> v�lido hasta #ValidDate#.<br><br>
	Ven y vis�tanos en&nbsp; <a href=\"#link#\">SITENAME</a>.<br>
<br>�Buena Suerte!<br>#AdminName# <br>SITENAME<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['profile_activated']['text'] = "Estimado/a #FirstName#,

Nos da gran placer darle la bienvenida a SITENAME.

Tu perfil ha sido activado con el nivel de membres�a <b>#MembershipLevel#</b> v�lida hasta <b>#ValidDate#</b>.

Ven y visitanos en <a href=\"#link#\">SITENAME</a>.

�Buena Suerte!
#AdminName#
SITENAME";

/* old format
$lang['profile_reactivated_sub'] = '#SITENAME# - �Tu perfil est� reactivado!';
$lang['profile_reactivated']['html'] = "Estimado/a #FirstName#,<br><br>Este es un informe autom�tico para informarle que su perfil en #siteName# ha sido reactivado con el nivel de membres�a de #MembershipLevel#. Ven y vis�tanos en <a href=\"#link#\">#siteName#</a>.<br><br>�Buena Suerte!<br>#AdminName#";

New format
*/
$lang['profile_reactivated_sub'] = 'Mensaje: SITENAME  �Tu perfil est� reactivado!';
$lang['profile_reactivated']['text'] = "Estimado/a #FirstName#,

Estmos complacidos de informarte que tu perfil ha sido reactivado con el nivel de<b>#MembershipLevel#</b> que expira el <b>#ValidDate#</b>.

Ven y visitanos en  <a href=\"#link#\">SITENAME</a>.

�Buena Suerte!
#AdminName#
SITENAME";

$lang['profile_reactivated']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head">
<div class="module_head">#email_hdr_left#</div></td><td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;�Tu 
	perfil est� reactivado! </div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2">
<div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">
	Estimado/a #FirstName#,<br><br>Estamos felices de informarle que su perfil 
	es reactivado con el nivel de membres�a <b>#MembershipLevel#</b> que expira 
	el <b>#ValidDate#</b>.<br>
<br>Ven y vis�tanos en <a href=\"#link#\">SITENAME</a>.<br><br>�Buena Suerte!<br>#AdminName# <br>SITENAME<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';


/* old format
$lang['added_banlist_sub'] = '#SITENAME# - Mensaje con informaci�n';
$lang['added_buddylist_sub'] = '#SITENAME# - Mensaje con informaci�n';
$lang['added_hotlist_sub'] = '#SITENAME# - Mensaje con informaci�n';

$lang['added_buddylist']['html'] = "Estimado/a #FirstName#,<br><br>Has sido agregado/a a la lista de amigos de . #SenderName#. <br><br>Para ver su perfil visita <a href=\"#link#\">#siteName#</a>.<br><br>�Buena Suerte!<br>#AdminName#";

$lang['added_hotlist']['html'] = "Estimado/a #FirstName#,<br><br>Has sido agregado/a a la lista Caliente de #SenderName#.<br><br>Para ver su perfil visita <a href=\"#link#\">#siteName#</a>.<br><br>�Buena Suerte!<br>#AdminName#";

$lang['added_banlist']['html'] = "Estimado/a #FirstName#,<br><br>Has sido agregado/a a la lista de prohibidos de #SenderName#.<br><br>Para ver su perfil visita <a href=\"#link#\">#siteName#</a>.<br><br>#AdminName#";

$lang['added_buddylist']['text'] = "Estimado/a #FirstName#,

Has sido agregado/a a la lista de amigos de #SenderName#.

Para ver su perfil visita <a href=\"#link#\">#siteName#</a>.

�Buena Suerte!
#AdminName#
SITENAME";

$lang['added_hotlist']['text'] = "Estimado/a #FirstName#,

Has sido agregado/a a lista caliente de #SenderName#.

Para ver su perfil visita <a href=\"#link#\">#siteName#</a>.

�Buena Suerte!
#AdminName#
SITENAME";

$lang['added_banlist']['text'] = "Estimado/a #FirstName#,

Has sido agregado/a a la lista de prohibidos #SenderName#.

Para ver su perfil visita <a href=\"#link#\">#siteName#</a>.

#AdminName#";

New format
*/
$lang['added_list_sub'] = "Mensaje:SITENAME Has sido agregado/a a #SenderName#'s #ListName#!";
$lang['added_list']['text'] = "Estimado/a #FirstName#,

El miembro #SenderName# te agreg� a  su lista #ListName#.

Para ver su perfil visita <a href=\"#link#\">SITENAME</a>.

�Buena Suerte!
#AdminName#
SITENAME";

$lang['added_list']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25px" class="module_head">
<div class="module_head">#email_hdr_left#</div></td><td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;�Has 
	sido agregado por #SenderName# a #ListName#!</div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" >
<div class="evenrow"><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="50%" valign="top" class="evenrow">
	Estimado/a #FirstName#,<br><br>El miembro <b>#SenderName#</b> te agreg� a&nbsp; <b>#ListName#</b> 
	del miembro<br><br>Para ver el perfil de este usuario, por favor visite
	<a href=\"#link#\">SITENAME</a>.<br><br>�Buena Suerte!<br>#AdminName# <br>SITENAME<br></td><td valign="top">#smallProfile#</td>
</tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

/* old format
$lang['invite_a_friend_sub'] = 'Invitar a un Amigo';
$lang['invite_a_friend']['html'] = "Hola,<br><br>Encontr� un sitio para citas mientras navegaba por internet: #Link#.<br>Pens� que te pod�a interesar.<br><br>#FromName#";

New format
*/
$lang['invite_a_friend_sub'] = "Mensaje:SITENAME Invitaci�n de #FromName#! ";
$lang['invite_a_friend']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="27" class="module_head" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" valign="top" ><div class="module_head" >#email_hdr_left#</div>
</td>
<td width="493" ><div class="module_head" >&nbsp;&nbsp;�Invitaci�n de #FromName#!</div></td></tr></table></div></td></tr><tr><td width="100%" colspan="2" ><div class="evenrow"><table border="0" cellspacing="0" cellpadding="5" width="100%"><tr><td height="1"></td></tr><tr><td width="100%" valign="top" class="evenrow">Hola,<br><br>
	Encontr� un sitio para citas mientras navegaba por internet: <a href=\"#SiteUrl#\"><b>SITENAME</b></a><br>
	Pens� que te pod�a interesar.<p>
<br>Visita <a href=\"#SiteUrl#\">SITENAME</a>.<br><br>�Buena Suerte!<br>#FromName# <br><br></td></tr></table></div>
</td></tr><tr><td height="6" class="evenrow" colspan="2" ></td></tr></table>';

/* old format
$lang['message_read_sub'] = '#SITENAME# - Mensaje con informaci�n';
$lang['message_read']['html'] = "Estimado/a #FirstName#,<br><br>The message you sent to '#RecipientName#' has been read.<br><br>�Buena Suerte!<br>#AdminName#";

New format */
$lang['message_read_sub'] = 'Mensaje: SITENAME: Su mensaje #RecipientName# es le�do!';
$lang['message_read']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25">
<div class="module_head">#email_hdr_left#</div></td><td width="493" ><div class="module_head">&nbsp;� 
	Se ley� tu mensaje a #RecipientName# ! </div></td></tr></table></div></td></tr>
<tr><td width="100%" class="evenrow" colspan="2" >
<div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="50%" valign="top" class="evenrow">
	Estimado/a #FirstName#,<br><br>El mensaje que enviaste a <b>#RecipientName#</b> 
	fue le�do.<br><br>Para ver el perfil de este usuario, por favor visite
	<a href=\"#link#\">SITENAME</a>.<br><br>�Buena Suerte!<br>#AdminName# <br>SITENAME<br></td>
<td valign="top">#smallProfile#</td></tr></table>
</div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

/* old format
$lang['email_feedback_subject'] = 'Comentario de parte de '.SITENAME;
$lang['feedback_email_to_admin']['text'] = 'Estimado Admin. del sitio,

Has recibido comments from a visitor to your dating site. Estos son los detalle:

T�tulo: #txttitle#
Nombre: #txtname#
Correo-E: #txtemail#
Pa�s: #txtcountry#
Comentarios: #txtcomments#

Gracias,
#SITENAME# Daemon';

$lang['feedback_email_to_admin']['html'] = 'Estimado Administrador  del sitio,<br><br> Usted acaba de recibir comentarios de un visitante en su sitio. Estos son los detalle:<br><br>T�tulo: #txttitle#<br>Nombre: #txtname#<br>Correo Electr�nico: #txtemail#<br>Pa�s: #txtcountry#<br>Comentarios: #txtcomments#<br><br>Gracias,<br>#SITENAME# Daemon';

New format */
$lang['email_feedback_subject'] = 'Mensaje: SITENAME: Comentario de parte de  ';
$lang['feedback_email_to_admin']['text'] = 'Estimado Administrador del sitio,

Has recibido comentarios desde un visitante de tu sitio. Estos son los detalle:

T�tulo: #txttitle#
Nombre: #txtname#
Correo Electr�nico: #txtemail#
Pa�s: #txtcountry#
Comentarios: #txtcomments#

Gracias,
SITENAME Daemon';
$lang['feedback_email_to_admin']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25"><div class="module_head">
#email_hdr_left#</div></td><td width="493"><div class="module_head">&nbsp;&nbsp; Comentario de parte de <div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" ><div class="evenrow" >
<table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr>
<tr><td width="100%" valign="top" class="evenrow"> Estimado Administrador del sitio,<br><br> Has recibido un correo de un visitante de su sitio. Estos son los detalle:<br><br><table cellspacing="4" cellpadding="2" border="0" width="100%"><tr><td width="20%"> T�tulo:</td><td width="80%">#txttitle# </td></tr><tr><td>Nombre:</td> <td>#txtname#</td></tr>
<tr><td>Correo Electr�nico:</td><td>#txtemail#</td></tr><tr><td>Pa�s:</td><td>#txtcountry#</td></tr><tr><td>Comentarios:</td><td>#txtcomments#</td></tr></table><br>Thanks,<br>#siteName# Daemon<br><br></td></tr></table></div></td></tr></table> ';


/* old format
$lang['forgot_password_sub'] = 'Contrase�a Request';
$lang['forgot_password']['text'] = "Estimado #Name#,

Tu ID de miembro: #ID#
Tu contrase�a:  #Password#

Para iniciar la sesi�n haz click aqu�: #LoginLink#.

�Gracias por usar nuestros servicios!

#SiteTitle# sistema de env�o de correos electr�nicos
<Correo-e generado autom�ticamente, no responder>";
$lang['forgot_password']['html'] = "Estimado/a  #Name#,<br><br>Tu ID de miembro: #ID#<br>Tu Contrase�a: #Password#<br><br>Para iniciar la sesi�n haz click aqu�: #LoginLink#.<br><br>�Gracias por usar nuestros servicios!<br><br>#SiteTitle# sistema de env�o de correos electr�nicos<br><Correo-e generado autom�ticamente, no responder>";



New format */
$lang['forgot_password_sub'] = 'Mensaje: SITENAME: Su pedido de cambio de Contrase�a';
$lang['forgot_password']['text'] = "Estimado/a  #Name#,

Esto hace referencia a su pedido de inicio de la Contrase�a para acceder a su cuenta.

Tu ID de miembro: #ID#
Su nueva Contrase�a:  #Password#

Para iniciar la sesi�n haz click aqu�: #LoginLink#.

�Gracias por usar nuestros servicios!

#AdminName#
SITENAME";
$lang['forgot_password']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head"><div class="module_head">#email_hdr_left#</div></td>
<td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;Su 
	pedido de cambio de contrase�a </div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" ><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">
		Estimado/a #Name#,<br>
<br>Esto tiene referencia a su petici�n para limpiar la contrase�a para tener 
		acceso a su cuenta.<br><br>Su ID de miembro: <b>#ID#</b><br>Su nueva 
		contrase�a: <b>#Password#</b><br><br>Para iniciar la sesi�n haz click 
		aqu�: <a href=\"#LoginLink#\">SITENAME</a>.<br><br>�Gracias por usar 
		nuestros servicios!<br><br>#AdminName#<br>SITENAME<br></td></tr> </table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

/* old format
$lang['expiry_ltr_sub'] = 'Recordatorio de Expiraci�n de Membres�a';
$lang['mship_expired_note']['text'] = "Estimado/a #FirstName#,

Esta es una notifiaci�n autom�tica para informarle que el nivel de su membres�a es de #MembershipLevel# en #siteName# expira en #ExpiryDate#.

Pro favor <ahref=\"#link#\">login to  #siteName#</a> to renew your membership and continue to enjoy our services.

�Buena Suerte!
#AdminName#";
$lang['mship_expired_note']['html'] = "Estimado/a #FirstName#,<br><br>Esta es una notifiaci�n autom�tica para informarle que el nivel de su membres�a es de #MembershipLevel# in #siteName# expira en #ExpiryDate#.<br><br>Por favor <ahref=\"#link#\">inicie la sesi�n en  #siteName#</a> para renovar su membres�a y continuar disfrutando nuestros servicios.<br><br>�Buena Suerte!<br>#AdminName#";

New format */
$lang['expiry_ltr_sub'] = 'Mensaje: SITENAME: Recordatorio de expiraci�n de Membres�a';

$lang['mship_expired_note']['text'] = "Estimado/a #FirstName#,

Gracias por usar SITENAME!

Es para informarle que su nivel de membres�a es de#MembershipLevel# in SITENAME expir� el #ExpiryDate#.

Por favor <ahref=\"#link#\">inicie ses�on en SITENAME</a> para renovar su membres�a y continuar disfrutando nuestros servicios.

�Buena Suerte!
#AdminName#
SITENAME";

$lang['mship_expired_note']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head"><div class="module_head">#email_hdr_left#</div></td>
<td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;�Su membres�a ha expirado! </div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" ><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">Estimado/a #FirstName#,<br>
<br>Gracias por usar SITENAME!<br><br>Es para informarle  que su nivel de membres�a es <b>#MembershipLevel#</b> en <a href="\"#link#\"><b>SITENAME</b></a> expira el <b>#ExpiryDate#</b>.<br><br>Por favor inicie sesi�n en  <a href=\"#link#\">SITENAME</a> para renovar su membres�a y continuar disfrutando de nuestros servicios.<br><br>�Buena Suerte!<br>#AdminName# <br>SITENAME<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

/* old format
$lang['mship_expiry_note']['text'] = 'Estimado/a #FirstName#,

Es para informarle que su membres�a con #siteName# expirar� el #ExpiryDate#.

Por favor <ahref="#link#">inicie la sesi�n#siteName#</a> y renueve la membres�a.

�Buena Suerte!
#AdminName#';

$lang['mship_expiry_note']['html'] = 'Estimado/a #FirstName#,<br><br>Es para informarle que su membres�a con #siteName# expirar� pronto el#ExpiryDate#.<br><br>Por favor <ahref="#link#">inicie la sesi�n#siteName#</a> y renueve la membres�a.<br><br>�Buena Suerte!<br>#AdminName#';


New format */
$lang['mship_expiry_note']['text'] = 'Estimado/a #FirstName#,

Gracias por usar SITENAME!

Es para informarle que su nivel de membres�a es de#MembershipLevel# in SITENAME expirar� pronto el#ExpiryDate#.

Por favor <ahref="#link#">inicie la sesi�n en SITENAME</a> y renueve su membres�a y continue disfrutando de nuestros servicios.

�Buena Suerte!
#AdminName#
SITENAME';

$lang['mship_expiry_note']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head">
<div class="module_head">#email_hdr_left#</div></td><td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;�Su membres�a expirar� pronto!</div></td></tr></table></div></td></tr>
<tr><td width="100%" class="evenrow" colspan="2" ><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">Estimado/a #FirstName#,<br><br>Gracias por usar SITENAME!<br><br>Es para informarle que su nivel de membres�a es de <b>#MembershipLevel#</b> en <a href="\"#link#\"><b>SITENAME</b></a> expirar� pronto el <b>#ExpiryDate#</b>.<br><br>Por favor inicie ses�on en <a href=\"#link#\">SITENAME</a> para renovar su membres�a y continuar disfrutando nuestros servicios.<br>
<br>�Buena Suerte!<br>#AdminName# <br>SITENAME<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

/* Newly added - mail to be sent to member when admin changes membership level */

$lang['profile_membership_changed_sub'] = 'Mensaje: SITENAME:  Su nivel de membres�a ha cambiado!';
$lang['profile_membership_changed']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head">
<div class="module_head">#email_hdr_left#</div></td><td width="493" class="module_head" height="25"><div class="module_head">&nbsp;&nbsp;�Su nivel de membres�a ha cabiado! </div></td></tr></table></div></td></tr>
<tr><td width="100%" class="evenrow" colspan="2"><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">Estimado/a #FirstName#,<br><br>Tu nivel de membres�a es <b>#CurrentLevel#</b> se cambia a <b>#NewLevel#</b>, que ezpira el <b>#ValidDate#</b>.<br>
<br>Ven y visitanos en <a href=\"#link#\">SITENAME</a>.<br><br>�Buena Suerte!<br>#AdminName# <br>SITENAME<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['profile_membership_changed']['text'] = "Estimado/a #FirstName#,

Tu nivel de membres�a es  <b>#CurrentLevel#</b> se cambia a <b>#NewLevel#</b> que expira el <b>#ValidDate#</b>.

Ven y visitanos en  <a href=\"#link#\">SITENAME</a>.

�Buena Suerte!
#AdminName#
SITENAME
";

$lang['comment_received_sub'] = 'Mensaje: SITENAME: Un usuario agreg� un comentaario en tu blog';
$lang['comment_received']['text'] = "Estimado/a #FirstName#,

Has recibido un comentario del usuario SITENAME'<b>#SenderName#</b>'.

Por favor visita<a href=\"#link#\"><b>SITENAME</b></a> para ver el comentario del usuario '<b>#SenderName#</b>'.

�Buena Suerte!
#AdminName#
SITENAME";

$lang['comment_received']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head"><div class="module_head">#email_hdr_left#</div></td><td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;�Un usuario ageg� un comentario en tu blog! </div></td></tr></table></div></td></tr>
<tr><td width="100%" class="evenrow" colspan="2"><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">Estimado/a #FirstName#,<br><br>Has recibido un comentario del usuario SITENAME <b>#SenderName#</b>.<br><br>Por favor visita <a href=\"#link#\"><b>SITENAME</b></a> para ver el comentario de <b>#SenderName#</b>.<br>
<br>�Buena Suerte!<br>#AdminName# <br>SITENAME<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';
$lang['aff_added_sub'] = 'Mensaje: SITENAME: �Se agreg� como Afiliado!';
$lang['aff_added']['text'] = "Estimado/a  #Name#,

Estamos complacido en informarle que se agreg� como afiliado conSITENAME.

Su ID: #Affid#
Su Contrase�a: #Password#

Por favor visita<a href=\"#SiteUrl#\"><b>SITENAME</b></a> e inicie sesi�n a la secci�n de afiliado y cambie la contrase�a en bien pueda.

�Buena Suerte!
#AdminName#
SITENAME";

$lang['aff_added']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head"><div class="module_head">#email_hdr_left#</div></td><td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;�Se agreg� como afiliado! </div></td></tr></table></div></td></tr>
<tr><td width="100%" class="evenrow" colspan="2"><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">Estimado/a #Name#,<br><br>Estamos complacido en informarle que se agreg� como afiliado con SITENAME.<br><br><b>Su ID: #Affid#</b><br><b>Su contrase�a: #Password#</b><br><br>Por favor visita <a href=\"#SiteUrl#\"><b>SITENAME</b></a> e inicie sesi�n a la secci�n de afiliado y cambie la contrase�a ni bien pueda.<br><br>�Buena Suerte!<br>#AdminName# <br>SITENAME<br></td>
</tr></table></div>
</td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['aff_newpwd_sub'] = 'Mensaje: SITENAME: �Su cuenta de Afiliado!';
$lang['aff_newpwd']['text'] = "Estimado/a  #Name#,

Se gener� una contrase�a nueva para su cuenta de afiliado enSITENAME como pedido..

Su nueva contrase�a: #Password#

Por favor visita<a href=\"#SiteUrl#\"><b>SITENAME</b></a> e inicie sesi�n a la secci�n de afiliado y cambie la contrase�a en bien pueda.

�Buena Suerte!
#AdminName#
SITENAME";

$lang['aff_newpwd']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head"><div class="module_head">#email_hdr_left#</div></td>
<td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;�Su cuenta de afiliado! </div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2"><div class="evenrow"><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">Estimado/s #Name#,<br><br>Se gener� una contrase�a nueva para su cuenta de afiliado en SITENAME seg�n su pedido.<br>
<br><b>Su contrase�a: #Password#</b><br><br>Por favor visita <a href=\"#SiteUrl#\"><b>SITENAME</b></a> e inicie sesi�n a la secci�n de afiliado y cambie la contrase�a ni bien pueda.<br><br>�Buena Suerte!<br>#AdminName# <br>SITENAME<br></td></tr></table></div>
</td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['add_affiliate'] = 'Agregue un afiliado';
$lang['mod_affiliate'] = 'Modifique un afiliado';
$lang['aff_modified'] = 'La informaci�n de afiliado es modificada';

$lang['newuser']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head"><div class="module_head">#email_hdr_left#</div></td>
<td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;�Se registro un nuevo usuario!</div></td></tr></table></div></td></tr><tr><td width="100%" class="evenrow" colspan="2" ><div class="evenrow"><table border="0" cellspacing="0" cellpadding="5"><tr><td width="100%" valign="top" class="evenrow">Estimado Administrador del Sitio,<br><br>un nuevo usuario ingreso a #siteName#.<br><br>Nombre de usuario: <a href="#SiteUrl#admin/showprofile.php?username=#UserName#">#UserName#</a><br><br>#AdminName# <br>#siteName#<br></td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['newuser']['text'] = "Estimado Administrador del sitio,

Un nuevo usuario ingres� a #SiteName#.

Nombre de usuario: #UserName#

#AdminName#
SITENAME";

$lang['newuser_sub'] = 'Se registr� un usuario nuevo';

/* Following user options are managed. Please modify only the description and not these keys */

$lang['user_choices'] = array(
	'email_message_received' 	=> "Enviar correo electr�nico cuando se reciba un nuevo mensaje.",
	'email_wink_received'		=> "Enviar correo electr�nico cuando alguie me gui�e.",
	'email_blog_commented'		=> "Enviar correo electr�nico cuando alguien agregue un comentario en mi blog.",
	'email_mship_expiry'		=> "Enviar recordatorio de expiraci�n de membres�a.",
	'email_message_read'		=> "Enviar correo electr�nico cuando el reci�piente de mi mensaje lo lea.",
	'email_buddy_list'			=> "Enviar correo electr�nico cuando alguien me agregue a lista de amigos.",
	'email_ban_list'			=> "Enviar correo electr�nico cuando alguien me agregue a su lista de prohibidos.",
	'email_hot_list'			=> "Enviar correo electr�nico cuando alguien me agregue a su lista Caliente.",
	"allow_buddy_view_album"	=> "Permitir a los usuarios en lista de amigos que vean mis �lbums privados.",
	"allow_hotlist_view_album"	=> "Permitir a los usuarios en lista que vea mis �lbums privados.",
	'email_match_mail_days'		=> "Frecuencia, de d�as, para enviar correos \'my matches\'. Ingrese 0 si no quiere recibir gui�os.",
	);
$lang['mysettings_updated'] = 'Sus preferencias de recepci�n de correo est� actualizadas';
$lang['mysettings_updated'] = 'Sus preferencias de recepci�n de correo est� actualizadas';
$lang['resend_conflink_hdr'] = 'Re-enviar el correo de confirmaci�n';
$lang['resend_conflink_hdr1'] = 'Perdi� o no recibi� correo de confirmaci�n despu�s del registro? Ingrese el correo que us� durante el registro para re-enviar el mensaje.';
$lang['resend_conflink_msg'] = 'Su correo de confirmaci�n fue re-enviado.';
$lang['resend_conflink_msg1'] = 'Por favor ingresa la direcci�n de correo electr�nico que diste al momento de registrarte.';
$lang['resend_conflink_err1'] = 'Ya has confirmado tu perfil. Por favor usa el v�nculo si<a href="forgotpass.php">olvid� la contrase�a</a> para generar una contrase�a nueva.';
$lang['about_me'] = 'Sobre mi';
$lang['about_me_hlp'] = 'Ingresa una peque�a descripci�n sobre t�, que le interese a otros y pueda ayudar a conseguite m�s respuestas.';
$lang['aff_forgot_pass'] = '�Olvidaste tu contrase�a? Ingresa tu direcci�n de correo para recibir tu contrase�a:';
$lang['send_new_password'] = 'Enviar contrase�a nueva';
$lang['not_a_member'] = '�No eres miembro?';
$lang['login_reminded'] = 'Recu�rda tu nombre de usuario y contrase�a.';
$lang['lost_confemail'] = '�Perdiste tu correo de confirmaci�n?';
$lang['couple_usernames'] = 'Pareja / Grupo de Nombres de Usuario';
$lang['couple_usernames_hlp'] = 'Una pareja o un grupo tiene dos o m�s individuos. Por favor ingresa los Nombres de Usuario de los miembros de esta pareja o grupo en el siguiente campo de texto. Por ejemplo: usuario_1,usuario_2,usuario_3. Estos usuario deben tener una cuenta de perfiles individuales con anterioridad.';
$lang['blog']['del01'] = '�Realmente quieres eliminar este comentario?';
$lang['blog']['del02'] = '�Realmente quieres eliminar la selecci�n? ';
$lang['blog']['del03'] = '�Realmente quiere desinstalar esto? ';
$lang['feat_prof_del_msg'] = '�Quieres remover este perfil de la lista de perfiles destacados?';
$lang['feat_prof_deleted'] = 'Se removi� el perfil seleccionado de la lista de perfiles destacados.';

$lang['mymatches_sub'] = 'Mensaje: SITENAME: �Tu correo electr�nico con resultado de la b�squeda!';
$lang['mymatches_body']['html'] = '<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td width="77" height="25">#email_hdr_left#</td><td width="493" class="module_head" >&nbsp;&nbsp;�Tu mail con resultado de la b�squeda! </td></tr><tr><td width="570" class="evenrow" colspan="2" style="padding: 5px;"><table border="0" cellspacing="2" cellpadding="2"><tr><td height="6"></td></tr><tr><td class="evenrow">Estimado/a #FirstName#,<br><br>La siguiente es una lista de perfiles que coinciden con tu b�squeda.</td></tr><tr><td height="10" class="evenrow"> </td></tr><tr><td valign="top" class="evenrow">#matchedProfiles#</td></tr><tr><td height="10" class="evenrow"> </td></tr><tr><td class="evenrow">Por favor visita<a href=\"#link#\">SITENAME</a> para ver estos perfiles.<br><br>�Buena Suerte!<br>#AdminName#<br>SITENAME<br></td></tr></table> </td></tr></table>';
$lang['on'] = ' si ';

$lang['use_seo_username'] = 'Usa el nombre del usuario del perfil como par�metro de la URL. Permitirlo le dar� al perfil el formato "domain/username". Al no permitir esta opci�n dar� direcciones de perfil con el formato "domain/id.htm"';
$lang['leave_blank_no_change'] = '(deja vac�o si no hay cambio)';

$lang['adminltr']['html']='<table border=0 cellpadding="0" cellspacing="0" width="570"><tr><td height="25" width="100%"><div class="module_head"><table border=0 cellspacing=0 cellpadding=0 width="100%"><tr><td width="77" height="25" class="module_head"><div class="module_head">#email_hdr_left#</div></td><td width="493" class="module_head" ><div class="module_head">&nbsp;&nbsp;#Subject#</div></td></tr></table></div></td></tr>
<tr><td width="100%" class="evenrow" colspan="2"><div class="evenrow" ><table border="0" cellspacing="0" cellpadding="5"><tr><td height="2"></td></tr><tr><td width="100%" valign="top" class="evenrow">#LetterContent#</td></tr></table></div></td></tr><tr><td height="6" colspan="2" class="evenrow"></td></tr></table> ';

$lang['adminltr']['text'] = '#LetterContent#';

$lang['sections'] = array(
	'1' => 'Informaci�n b�sica ',
	'2' => 'Aspecto F�sico ',
	'3' => 'Vida Profesional ',
	'4' => 'Modo de vivir',
	'5' => 'Intereses' );

/* Following is for mail encoding */
$lang['mail_text_encoding'] = '7bit';
$lang['mail_html_encoding'] = '7bit';
$lang['mail_html_charset'] = 'ISO-8859-15';
$lang['mail_text_charset'] = 'ISO-8859-15';
$lang['mail_head_charset'] = 'ISO-8859-15';

	$lang['split_file_names_hdr'] = 'Los archivos son cargados ahora ';
$lang['worst1'] = '(peor)';
$lang['best1'] = '(mejor)';
	$lang['profile_auto_confirmed'] = 'Gracias por hacerse miembro SITENAME.<br><br> Como un gesto especial, nuestro sistema autom�ticamente ha confirmado su perfil.<br><br>Please <a href="index.php?page=login">login</a> Disfrutar de nuestros servicios.<br><br>';
	$lang['zip_load_over'] = 'La carga de los c�digos postales para #COUNTRY# fue completado.';
//Filter Records
$lang['filter_options'] = array(
	'id' => 'N�mero de Identificaci�n',
	'username' => 'Nombre de Usuario',
	'city' => 'Ciudad',
	'zip' => 'C�digo Postal',
	'status' => 'Estado',
	'email'	=> 'Correo Electr�nico',
	'gender' => 'G�nero'
	);
	$lang['loginagain'] = 'Salga e ingrese nuevamente para disfrutar de estado de socios nuevo';
	$lang['online_users_txt'] = 'Miembros en l�nea ';

	$lang['status_disp'] = array(
	'approval' => 'Pendiente',
	'active' => 'Activo',
	'rejected' => 'Rechazado',
	'suspended' => 'Suspendido',
	/* added in 1.1.0 */
	'cancel' => 'Cancelado'
	);

$lang['status_enum'] = array(
	'approval' => 'Pendiente',
	'active' => 'Activo',
	'rejected' => 'Rechazado',
	'suspended' => 'Suspendido',
	);
$lang['status_act'] = array(
	'approval' => 'Pendiente',
	'active' => 'Activado',
	'rejected' => 'Rechazado',
	'suspended' => 'Suspendido',
	/* added in 1.1.0 */
	'cancel' => 'Cancelar'
	);

?>
