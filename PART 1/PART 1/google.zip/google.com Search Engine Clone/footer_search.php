</td>
<td background="images/blu_line.gif" width="10"></td>
    <td width="200" valign="top"><div align="center">Sponsored Links</div><br>
	
<script type="text/javascript"><!--
google_ad_client = "pub-1348335941961536";
google_ad_width = 160;
google_ad_height = 600;
google_ad_format = "160x600_as";
google_ad_type = "text_image";
google_ad_channel ="";
google_color_border = "FFFFFF";
google_color_bg = "FFFFFF";
google_color_link = "FFFFFF";
google_color_url = "008000";
google_color_text = "000000";
//--></script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
	
	</td>
  </tr>
</table>
<p>&nbsp;</p>
      <table width="100%"  border="0" cellspacing="0" cellpadding="10" id="table1">
        <tr>
          <td bgcolor="#e5ecf9">
			<p align="center">
            <td align="center" bgcolor="#e5ecf9"><form name="googleFrm" method="get" action="search.php" onsubmit="return checkform(this);">
      <table width="100%"  border="0" cellspacing="0" cellpadding="10">
        <tr>
          <td>
			<p align="center">
			<img border="0" src="/images/logo_small.gif"> <input name="query" type="text" id="query" value="<?php echo $_GET['query'];?>" size="40">
              <input type="submit" value="Search Again">
              <input name="www" type="hidden" id="www" value="true">
              </td>
        </tr>
      </table>
</body>
</table>
<p align="center">Copyright 2006 by EnDLeSs-4uM.CoM� - All rights reserved. 
Legal Docs� Attached</p>

</html>