<?
Error_Reporting(E_ALL & ~E_NOTICE);
if ($pus<>""){
setcookie ("par", $pus,time()+60*60*24*30); 
}
$r_login = str_replace('..',"",$r_login);
$r_login = str_replace('.',"",$r_login);
$r_login = str_replace('/',"",$r_login);
$r_login = str_replace('>',"",$r_login);
$r_login = str_replace('<',"",$r_login);

include ("fun.php");

include ("setup.php");


require ("trace_ip.php");

?>








<!DOCTYPE php PUBLIC "-//W3C//DTD php 4.01 Transitional//EN">
<html lang="en">

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Play casino games at Online Casino</title>
<META NAME="description" CONTENT="Experience first-class online casino action at flash Casino. Play for free or for real money. Play exciting casino gambling games - slots, blackjack, video poker, craps, roulette and over 30 other games. play our free online casino games to play casino for free or real money.
">
<META NAME="keywords" CONTENT="online casino, gambling, free casino games, online casinos, best casino, top gambling, internet casino, flash casino, internet gambling, cyber casino, online betting, play casino, online blackjack, online roulette, online slot machine, poker, baccarat, craps, keno, slots, online casinos
">
<meta name="robots" content="all">
<META NAME="expires" CONTENT="never">
<META NAME="language" CONTENT="en">
<META NAME="distribution" CONTENT="Global">
<META NAME="publisher" CONTENT="flash casino">
<META NAME="copyright" CONTENT="Copyright 2008 flash casino">
<base >
<link href="template/v3/stylev3.css" rel="stylesheet" type="text/css">

<script type="text/javascript" language="javascript">
function popup(file){
	var leftPos = (screen.availWidth-760) / 2
	var topPos = (screen.availHeight-500) / 2
	showHelpWin = window.open(file,'','width=760,height=500,scrollbars=yes,resizable=yes,titlebar=0,top=' + topPos + ',left=' + leftPos);
}
function popup1(file) {
	var leftPos = (screen.availWidth-803) / 2
	var topPos = (screen.availHeight-560) / 2
	showHelpWin = window.open(file,'','width=803,height=560,scrollbars=yes,resizable=yes,titlebar=0,top=' + topPos + ',left=' + leftPos);
}
function popup2(file) {
	var leftPos = (screen.availWidth-803) / 2
	var topPos = (screen.availHeight-560) / 2
	showHelpWin = window.open(file,'','width=400,height=300,scrollbars=no,resizable=no,titlebar=0,top=' + topPos + ',left=' + leftPos);
}
</script>






<bgsound src="Sound_1.mp3" loop="-1">






</head>

<div id="ToolTip" style="position:absolute; min-width: 100px; max-width: 225px; top: 0px; left: 0px; z-index:10000; visibility:hidden;"></div>
<table cellpadding="0" cellspacing="0" border="0" width="100%">
	<tr class="top1">
		<td>&nbsp;</td>
			<td width="778" align="right"><img src="template/v3/i/b.gif" height="35" width="1" border="0" align="left"><img src="template/v3/i/dollar.jpg" align="left"  border="0"><a href="index.php"><img src="template/v3/i/euro.jpg" align="left"  border="0"></a><a href="http://index.php"><img src="template/v3/i/pound.jpg" align="left"  border="0"></a>Experience first class, high speed casino games action! Play casino games for free / real money 24/7</td>
		<td>&nbsp;</td>
	</tr>
</table>
<table cellpadding="0" cellspacing="0" border="0" width="100%">
	<tr class="top2">
		<td><img src="template/v3/i/b.gif" height="27" width="1" border="0"></td>
		<td class="top2" valign="top" align="center">
			<table cellpadding="0" cellspacing="0" border="0" align="center">
				<tr>
					<td class="top2_menu"><a href="index.php" class="sel" >Home</a>|<a href="promotions.php"  >Promotions</a>|<a href="preview.php"  >Preview</a>|<a href="cashier.php"  >Cashier</a>|<a href="support.php"  >24/7 Support</a>|<a href="fair_gaming.php"  >Fair Gaming</a>|<a href="reg.php"  <b>register</b></a>|<a href="indexuk.php"><img src="template/v3/i/flag_uk.jpg" border="0" align="absmiddle"></a><a href="index.php"><img src="template/v3/i/flag_ca.jpg" border="0" align="absmiddle"></a><a href="indexes.php"><img src="template/v3/i/flag_sp.jpg" border="0" align="absmiddle"></a><a href="indexit.php"><img src="template/v3/i/flag_it.jpg" border="0" align="absmiddle"></a><a href="indexfr.php"><img src="template/v3/i/flag_fr.jpg" border="0" align="absmiddle"></a><a href="indexde.php"><img src="template/v3/i/flag_de.jpg" border="0" align="absmiddle"></a><a href="indexpt.php"><img src="template/v3/i/flag_pt.jpg" border="0" align="absmiddle"></a><a href="indexgr.php"><img src="template/v3/i/flag_gr.jpg" border="0" align="absmiddle"></a></td>
					<td align="right" valign="bottom"></td>
				</tr>
			</table>
		</td>
	</tr>
</table>









