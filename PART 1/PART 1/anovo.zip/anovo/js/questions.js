var curBest = '';
var scrolledIndexCount = 1;
var bestId = 0;
var left_to_right = false;
var isPrevNextControl = false;
getAnotherBestAnswer = function(nav, bestId){
	isScrolling = false;
	allBest = $$('div.jsBestAnswers');
	for(i=0; i<allBest.length; i++){
		d = allBest[i];
		d.setStyle("display", "none");
	}
	bestDiv = 'best_' + bestId;
	curDiv = bestDiv;
	$(bestDiv).setStyle("display", "block");

	if (nav == 'next') {
		jsBestLeft.include(bestId)
		jsBestRight.remove(bestId);
	}else{
		jsBestLeft.remove(bestId)
		jsBestRight.include(bestId);
	}
	jsBestAnswerContainer = bestDiv
	if (mooSlider) {
		var slider = new Fx.Slide(jsBestAnswerContainer, {duration: 500, mode: 'horizontal'})
		slider.hide();
	}
	target = $(jsBestAnswerContainer);


	target.setStyles({
		//'position':'relative'
		}
	);
	if (mooSlider) {
		slider.slideIn();
	}


	if (mooTransition) {
	var xStart = bestAnswerStartsFrom;
	var xEnd = bestAnswerEndsTo;

	xEnd = 0;
	target.setStyles({
							'position':'absolute',
						//	'top': 0,
							'left': xStart + 'px'

						});

		var fx = new Fx.Styles(target, {duration: 500, wait: false});
		fx.stop()

		fx.options.transition = Fx.Transitions.linear
		fx.start({
			//'top': 0,
			'left': xEnd + 'px'

		});

	}
	isScrolling = true;
	mooSlider = false;
	mooTransition = true;
	isPrevNextControl = false;
	//clearInterval(jsTimerAutoScrollBestAnswer);
}

showPauseButton = function(){
	$('jsButtonPause').setStyle('display', 'inline');
	$('jsButtonPlay').setStyle('display', 'none');
}

showPlayButton = function(){
	$('jsButtonPlay').setStyle('display', 'inline');
	$('jsButtonPause').setStyle('display', 'none');
}

pauseBestAnswer = function(){
	scrollBest = false;
	showPlayButton();
	clearInterval(jsTimerAutoScrollBestAnswer);
}

playBestAnswer = function(){
	scrollBest = true;
	showPauseButton();
	autoScrollBestAnswer();
	scrollBestAnswer();
}
prevAnswer = function(){
	mooSlider = true;
	mooTransition = false;
	scrolledIndexCount--;
	scrolledIndexCount--;
	pauseBestAnswer();
	scrollBest = true;
	autoScrollBestAnswer();
	isPrevNextControl = true;
}
nextAnswer = function(){
	pauseBestAnswer();
	scrollBest = true;
	autoScrollBestAnswer();
	isPrevNextControl = true;
}

curIndex = 0;
scrollBestAnswer = function(){
	if(jsTimerAutoScrollBestAnswer != null){
		clearInterval(jsTimerAutoScrollBestAnswer);
	}
	if( o = $('jsBestAnswerContainer')){
//		autoScrollBestAnswer();
		jsTimerAutoScrollBestAnswer = setInterval("autoScrollBestAnswer()", jsBestAnswerScrollTime);
	}
}

autoScrollBestAnswer = function(){
	if((!isPrevNextControl) && (!scrollBest || !isScrolling)){
		return;
	}/*
	if (isPrevNextControl) {
		return;
	}*/
	var totalCount = jsBestAnswerSet.length;
	if (scrolledIndexCount < 0) {
		scrolledIndexCount = totalCount - 1;
	}
	if (scrolledIndexCount >= totalCount)
		{
			scrolledIndexCount = 0;
		}
	bestId = jsBestAnswerSet[scrolledIndexCount];
	scrolledIndexCount++;
	getAnotherBestAnswer('next', bestId);
}