<?php /* Smarty version 2.6.6, created on 2006-03-11 11:09:00
         compiled from report_abuse.tpl */ ?>
<html>

<head>
<title>Welcome Mr. <?php echo $_COOKIE['uname']; ?>
</title>
<!--<?php echo '-->
<link href="templates/style.css" rel="stylesheet" type="text/css">
<!--'; ?>
-->

</head>

<body>
<p align=center>
<table border="0" width="600" height="129" cellspacing="0" cellpadding="0">
  <tr>
    <td width="600" height="250" valign="top">
      <table border="0" width="100%" cellspacing="0" cellpadding="0" height="336">
        <tr>
          <td width="100%" height="29" colspan="2">
<!---------------------------------------------------------------->          
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "header.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<!---------------------------------------------------------------->
          </td>
        </tr>
        <tr>
          <td width="100%" height="29" colspan="2">
          <p align="left">
          <b><font face="Verdana" size="2" color="#7777D2">Report Abuse</font></b>
          </p>
          </td>
        </tr>
        <tr>
          <td width="84%" height="49" bgcolor="#F2F2FF">
            &nbsp;
          </td>
          <td width="16%" height="49" bgcolor="#F2F2FF">
          <?php if ($_COOKIE['admin_uid']): ?>
            <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%">
                  <tr>
                    <td width="179%" align=right>
                    <p>
                    <a class="link" href="index.php">Upload</a></p></td>
                  </tr>
                  <tr>
                    <td width="179%" align=right>
                    <p>
                    <a class="link" title="Go to my  file manager..." href="welcome_premium.php">
                    File Manager</a></p></td>
                  </tr>
                  <tr>
                    <td width="179%" align=right>
                    <a class="link1" title="Log out" href="logout.php">Logout</a></td>
                  </tr>
                  </table>
              <?php endif; ?>    
          </td>
        </tr>
        
        
        <tr>
          <td width="100%" height="18" align="center" colspan="2">
          <p align="left">
          </td>
        </tr>
        
        
        <tr>
          <td width="100%" height="137" valign="top" colspan="2">          
            <form>
            <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" height="106">
              <tr>
                <td width="47%" align="right" height="31" style="text-align: right">Reporter's 
                E-mail</td>
                <td width="2%" align="right" height="31">&nbsp;</td>
                <td width="51%" height="31" style="text-align: left">
                <input type="text" name="reporter" size="28" class="txtbx" value="<?php echo $_COOKIE['email']; ?>
"></td>
              </tr>
              <tr>
                <td width="47%" align="right" height="33" style="text-align: right">File Key</td>
                <td width="2%" align="right" height="33">&nbsp;</td>
                <td width="51%" height="33" style="text-align: left">
                <input type="text" name="filekey" size="28" class="txtbx"></td>
              </tr>
              <tr>
                <td width="47%" align="right" height="32" style="text-align: right">Report</td>
                <td width="2%" align="right" height="32">&nbsp;</td>
                <td width="51%" height="32" style="text-align: left">
                <textarea rows="4" name="report" cols="20" class="txtbx"></textarea></td>
              </tr>
              <tr>
                <td width="47%" align="right" height="35" style="text-align: right">&nbsp;</td>
                <td width="2%" align="right" height="35">&nbsp;</td>
                <td width="51%" height="35" style="text-align: left">
                <input type="submit" value="Submit" name="action" class="btn"></td>
              </tr>
            </table>
            </form>
          </td>
        </tr>
        <tr>
          <td width="100%" height="30" colspan="2">
          
          
          </td>
        </tr>
        <tr>
          <td width="100%" height="48" bgcolor="#F7F3FF" colspan="2"></td>
        </tr>
        <tr>
<!--------------------------------------------------------------------------------------------------------->        
   <td width="100%" height="25" colspan="2">
<p align="center"><?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "bottom_link.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
          
          </td>
<!--------------------------------------------------------------------------------------------------------->                  
        </tr>
      </table>
    </td>
  </tr>
  <tr>
    <td width="600" height="25"><img border="0" src="images/bottomLine.gif" width="600" height="18">      
    </td>
  </tr>
  <tr>
    <td width="600" height="109" valign="top" align="center">
 <p>&nbsp;</p>
<!--------------------------------------------------------------------------------------------------------->             
      <p><b><font color="#FF0000">Important Service Announcement:</font><br>      
      <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "msg1title.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
      </b></p>
      <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "msg1.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>      
<!--------------------------------------------------------------------------------------------------------->              
      </td>
  </tr>
  <tr>
    <td width="600" height="15" valign="top">
    <p align="center"><?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>      
      </td>
  </tr>
</table>
</body>

</html>