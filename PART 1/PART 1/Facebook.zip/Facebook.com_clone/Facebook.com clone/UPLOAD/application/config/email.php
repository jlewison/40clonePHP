<?php
$config['protocol'] = 'sendmail'; // "smtp", "sendmail" or "nativemail"
$config['mailtype'] = 'html'; // "html", "text"
$config['useragent'] = 'StandardMail'; // "html", "text"
/*
$config['smtp_host'] 		= 'smtp.gmail.com';		// smtp.swiftmailer.org
$config['smtp_port'] 		= 465;					// remote port of the SMTP server
$config['smtp_user'] 		= '';					// username for SMTP, if any or false
$config['smtp_pass'] 		= '';					// Password for SMTP, if any or false
*/
//$config['sendmail_path']	= "/usr/sbin/sendmail -bs";	// including the -bs options
?>