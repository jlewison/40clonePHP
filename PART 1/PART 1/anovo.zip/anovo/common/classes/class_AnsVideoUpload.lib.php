<?php
if (class_exists('ListRecordsHandler'))
{
		class test1 extends ListRecordsHandler
		{
		}
}
else
{
		class test1 extends FormHandler
		{
		}
}
class VideoUploadLib extends test1
{
		public $___error_msg;
		public function setIHObject($imObj)
		{
				$this->imageObj = $imObj;
		}
		public function videoToFrame($source_filename, $temp_dir, $total_frames, $scale)
		{
				if (substr($temp_dir, strlen($temp_dir) - 1) == '/') $t_dir = substr($temp_dir, 0, strlen($temp_dir) - 1);
				else  $t_dir = $temp_dir;
				$total_frames = $total_frames + 1;
				for ($i = 1; $i <= 27; $i += 8)
				{
						if ($this->CFG['debug']['store_log'])
						{
								$log_str = 'Video to Frame Conversion:' . "\r\n";
								$log_str .= $this->CFG['admin']['video']['mplayer_path'] . "\"" . " " . $source_filename . " -nosound -vo jpeg:outdir=" . $t_dir . " -ss " . $i . " -frames " . $total_frames;
								$this->writetoTempFile($log_str);
						}
						exec("\"" . $this->CFG['admin']['video']['mplayer_path'] . "\"" . " " . $source_filename . " -nosound -vo jpeg:outdir=" . $t_dir . " -ss " . $i . " -frames " . $total_frames);
				}
				for ($k = 1; $k < $total_frames; $k++)
				{
						$from = $temp_dir . str_pad($k + 1, 8, '0', STR_PAD_LEFT) . '.' . $this->CFG['video']['image']['extensions'];
						$to = $temp_dir . str_pad($k, 8, '0', STR_PAD_LEFT) . '.' . $this->CFG['video']['image']['extensions'];
						if (is_file($from))
						{
								if ($this->CFG['debug']['store_log'])
								{
										$log_str = 'Video to Frame Conversion Success:' . "\r\n";
										$this->writetoTempFile($log_str);
								}
								if (is_file($to)) unlink($to);
								copy($from, $to);
						}
						else
						{
								if ($this->CFG['debug']['store_log'])
								{
										$log_str = 'Video to Frame Conversion Failed:' . "\r\n";
										$this->writetoTempFile($log_str);
								}
						}
				}
				$file = $temp_dir . str_pad($total_frames, 8, '0', STR_PAD_LEFT) . '.' . $this->CFG['video']['image']['extensions'];
				if (is_file($file)) unlink($file);
		}
		public function getServerDetails($server_for = 'Ans_video')
		{
				$sql = 'SELECT server_url, ftp_server, ftp_folder, ftp_usrename, ftp_password FROM' . ' ' . $this->CFG['db']['tbl']['server_settings'] . ' WHERE server_for=' . $this->dbObj->Param('Ans_video') . ' AND server_status=\'Yes\' LIMIT 0,1';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($server_for));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if (!$rs->PO_RecordCount()) return false;
				$this->FTP_SERVER = '';
				$this->FTP_FOLDER = '';
				$this->FTP_USERNAME = '';
				$this->FTP_PASSWORD = '';
				$this->FTP_SERVER_URL = '';
				while ($row = $rs->FetchRow())
				{
						$this->FTP_SERVER = $row['ftp_server'];
						$this->FTP_FOLDER = $row['ftp_folder'];
						$this->FTP_USERNAME = $row['ftp_usrename'];
						$this->FTP_PASSWORD = $row['ftp_password'];
						$this->FTP_SERVER_URL = $row['server_url'];
						return true;
				}
				if (isset($this->FTP_SERVER) and $this->FTP_SERVER) return true;
				return false;
		}
		public function activateVideoFile()
		{
				$dir_thumb = '../' . $this->CFG['admin']['ans_videos']['thumbnail_folder'];
				$dir_video = '../' . $this->CFG['admin']['ans_videos']['video_folder'];
				$temp_dir = '../' . $this->CFG['admin']['ans_videos']['temp_folder'];
				$tempurl = $temp_dir . $this->VIDEO_NAME;
				$local_upload = true;
				if ($this->getServerDetails())
				{
						if ($FtpObj = new FtpHandler($this->FTP_SERVER, $this->FTP_USERNAME, $this->FTP_PASSWORD))
						{
								if ($this->FTP_FOLDER) $FtpObj->changeDirectory($this->FTP_FOLDER);
								$dir_thumb = $this->CFG['admin']['ans_videos']['thumbnail_folder'];
								$dir_video = $this->CFG['admin']['ans_videos']['video_folder'];
								$FtpObj->makeDirectory($dir_thumb);
								$FtpObj->makeDirectory($dir_video);
								if (is_file($tempurl . 'T.' . $this->CFG['video']['image']['extensions']))
								{
										$FtpObj->moveTo($tempurl . 'T.' . $this->CFG['video']['image']['extensions'], $dir_thumb . $this->VIDEO_NAME . 'T.' . $this->CFG['video']['image']['extensions']);
										unlink($tempurl . 'T.' . $this->CFG['video']['image']['extensions']);
								}
								if (is_file($tempurl . '.flv'))
								{
										$FtpObj->moveTo($tempurl . '.flv', $dir_video . $this->VIDEO_NAME . '.flv');
										unlink($tempurl . '.flv');
								}
								if (is_file($tempurl . '.' . $this->VIDEO_EXT))
								{
										unlink($tempurl . '.' . $this->VIDEO_EXT);
								}
								$FtpObj->ftpClose();
								$SERVER_URL = $this->FTP_SERVER_URL;
								$local_upload = false;
						}
				}
				if ($local_upload)
				{
						$upload_dir_thumb = $dir_thumb;
						$upload_dir_video = $dir_video;
						$this->chkAndCreateFolder($upload_dir_thumb);
						$this->chkAndCreateFolder($upload_dir_video);
						$uploadUrlThumb = $upload_dir_thumb . $this->VIDEO_NAME;
						$uploadUrlVideo = $upload_dir_video . $this->VIDEO_NAME;
						if (is_file($tempurl . 'T.' . $this->CFG['video']['image']['extensions']))
						{
								copy($tempurl . 'T.' . $this->CFG['video']['image']['extensions'], $uploadUrlThumb . 'T.' . $this->CFG['video']['image']['extensions']);
								unlink($tempurl . 'T.' . $this->CFG['video']['image']['extensions']);
						}
						if (is_file($tempurl . '.flv'))
						{
								copy($tempurl . '.flv', $uploadUrlVideo . '.flv');
								unlink($tempurl . '.flv');
						}
						if (is_file($tempurl . '.' . $this->VIDEO_EXT))
						{
								unlink($tempurl . '.' . $this->VIDEO_EXT);
						}
						$SERVER_URL = $this->CFG['site']['url'];
				}
				if (isset($SERVER_URL))
				{
						$sql = 'UPDATE ' . $this->CFG['db']['tbl']['ans_video'] . ' SET' . ' video_server_url=' . $this->dbObj->Param('video_server_url') . ', video_status=\'Ok\' WHERE' . ' video_id=' . $this->dbObj->Param('video_id');
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($SERVER_URL, $this->VIDEO_ID));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
						if ($this->VIDEO_FOR == 'Question')
						{
								$sql = 'UPDATE ' . $this->CFG['db']['tbl']['questions'] . ' SET' . ' video_id=' . $this->dbObj->Param('video_id') . ' WHERE' . ' ques_id=' . $this->dbObj->Param('ques_id');
								$stmt = $this->dbObj->Prepare($sql);
								$rs = $this->dbObj->Execute($stmt, array($this->VIDEO_ID, $this->CONTENT_ID));
								if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
						}
						else
								if ($this->VIDEO_FOR == 'Answer')
								{
										$sql = 'UPDATE ' . $this->CFG['db']['tbl']['answers'] . ' SET' . ' video_id=' . $this->dbObj->Param('video_id') . ' WHERE' . ' ans_id=' . $this->dbObj->Param('ans_id');
										$stmt = $this->dbObj->Prepare($sql);
										$rs = $this->dbObj->Execute($stmt, array($this->VIDEO_ID, $this->CONTENT_ID));
										if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
										if ($this->dbObj->Affected_Rows())
										{
												$sql = 'SELECT ques_id FROM ' . $this->CFG['db']['tbl']['answers'] . ' WHERE' . ' ans_id=' . $this->dbObj->Param('ans_id');
												$stmt = $this->dbObj->Prepare($sql);
												$rs = $this->dbObj->Execute($stmt, array($this->CONTENT_ID));
												if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
												$row = $rs->FetchRow();
												$sql = 'UPDATE ' . $this->CFG['db']['tbl']['questions'] . ' SET' . ' total_videos=total_videos+1 WHERE' . ' ques_id=' . $this->dbObj->Param('ques_id');
												$stmt = $this->dbObj->Prepare($sql);
												$rs = $this->dbObj->Execute($stmt, array($row['ques_id']));
												if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
										}
								}
						return true;
				}
				return false;
		}
		public function populateVideoDetails($video_id, $status = 'No')
		{
				$sql = 'SELECT video_id, video_ext, t_width, t_height, content_id, video_for FROM' . ' ' . $this->CFG['db']['tbl']['ans_video'] . ' WHERE' . ' video_id=' . $this->dbObj->Param('video_id') . ' AND' . ' video_encoded_status=' . $this->dbObj->Param('video_encoded_status') . ' LIMIT 0,1';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($video_id, $status));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($row = $rs->FetchRow())
				{
						$this->VIDEO_WIDTH = $row['t_width'];
						$this->VIDEO_HEIGHT = $row['t_height'];
						$this->VIDEO_ID = $row['video_id'];
						$this->VIDEO_NAME = getImageName($row['video_id']);
						$this->VIDEO_EXT = $row['video_ext'];
						$this->CONTENT_ID = $row['content_id'];
						$this->VIDEO_FOR = $row['video_for'];
						return true;
				}
				return false;
		}
		public function storeImagesTempServer($uploadUrl, $extern)
		{
				$this->imageObj->resize($this->CFG['admin']['ans_videos']['thumb_width'], $this->CFG['admin']['ans_videos']['thumb_height'], '-');
				$this->imageObj->output_resized($uploadUrl . 'T.' . $extern, strtoupper($extern));
				$image_info = getImageSize($uploadUrl . 'T.' . $extern);
				$this->T_WIDTH = $image_info[0];
				$this->T_HEIGHT = $image_info[1];
		}
		public function getPlayingTime($text_arr)
		{
				$vdoname = $text_arr;
				exec($this->CFG['admin']['video']['mplayer_path'] . ' -vo null -ao null -frames 0 -identify ' . $vdoname, $p);
				while (list($k, $v) = each($p))
				{
						if ($length = strstr($v, 'ID_LENGTH=')) break;
				}
				$lx = explode("=", $length);
				$duration = $lx[1];
				$min = floor($duration / 60);
				$sec = round($duration - ($min * 60));
				$min = str_pad($min, 2, '0', STR_PAD_LEFT);
				$sec = str_pad($sec, 2, '0', STR_PAD_LEFT);
				return $min . ':' . $sec;
		}
		public function videoEncode($video_id)
		{
				if ($this->populateVideoDetails($video_id))
				{
						$source_filename = '../' . $this->CFG['admin']['ans_videos']['temp_folder'] . $this->VIDEO_NAME . '.' . $this->VIDEO_EXT;
						$store_dir = '../' . $this->CFG['admin']['ans_videos']['temp_folder'];
						if ($this->CFG['debug']['store_log'])
						{
								$log_str = "\n Before Uploading \n" . $source_filename . "\n";
								$log_str .= "\n User Name: " . $this->CFG['user']['name'] . "\n";
								$log_str .= "\n Video Name: " . $this->VIDEO_NAME . "\n";
								$log_str .= "\n Date: " . date("F j, Y, g:i a") . "\n";
								$this->writetoTempFile($log_str);
						}
						if (is_file($source_filename))
						{
								$this->changeEncodedStatus('Partial');
								$temp_dir = '../' . $this->CFG['admin']['ans_videos']['temp_folder'] . $this->VIDEO_NAME . '/';
								$this->chkAndCreateFolder($temp_dir);
								$temp_file = $temp_dir . '00000001.' . $this->CFG['video']['image']['extensions'];
								$final_name = $store_dir . $this->VIDEO_NAME . 'T.' . $this->CFG['video']['image']['extensions'];
								$this->videoToFrame($source_filename, $temp_dir, 1, $this->CFG['admin']['ans_videos']['thumb_width'] . ':' . $this->CFG['admin']['ans_videos']['thumb_height']);
								if ($this->CFG['debug']['store_log'])
								{
										$log_str = "\n videoToFrame created successfully \n" . $source_filename . "\n";
										$log_str .= "\n User Name: " . $this->CFG['user']['name'] . "\n";
										$log_str .= "\n Video Name: " . $this->VIDEO_NAME . "\n";
										$log_str .= "\n Date: " . date("F j, Y, g:i a") . "\n";
										$this->writetoTempFile($log_str);
								}
								if (is_file(sprintf($temp_file, 1)))
								{
										copy($temp_file, $final_name);
										unlink($temp_file);
										$this->removeDirectory($temp_dir);
										$result = exec("\"" . $this->CFG['admin']['video']['flvtool2_path'] . "\" -UP " . $source_filename);
										if ($this->CFG['debug']['store_log'])
										{
												$log_str = "\n Flvtool2 start \n Flvtool2 execution Result \n" . @implode("\n", $result);
												$log_str .= "\n Execute Query : " . "\"" . $this->CFG['admin']['video']['flvtool2_path'] . "\" -UP " . $source_filename;
												$log_str .= "\n Flvtool2 execution Output \n" . @implode("\n", $p) . "\n Flvtool2 End \n";
												$log_str .= "\n User Name: " . $this->CFG['user']['name'] . "\n";
												$log_str .= "\n Video Name: " . $this->VIDEO_NAME . "\n";
												$log_str .= "\n Date: " . date("F j, Y, g:i a") . "\n";
												$this->writetoTempFile($log_str);
										}
										$this->setFormField('playing_time', $this->getPlayingTime($source_filename));
										if ($this->CFG['debug']['store_log'])
										{
												$log_str = "\n Playing time calculated successfully \n" . $source_filename . "\n";
												$log_str .= "\n User Name: " . $this->CFG['user']['name'] . "\n";
												$log_str .= "\n Video Name: " . $this->VIDEO_NAME . "\n";
												$log_str .= "\n Date: " . date("F j, Y, g:i a") . "\n";
												$log_str .= "\n Playing Time: " . $this->fields_arr['playing_time'] . "\n";
												$log_str .= "\n $temp_file " . (is_file($temp_file) ? ' is a file' : 'NOT a file') . "\n";
												$this->writetoTempFile($log_str);
										}
										$temp_file = $store_dir . $this->VIDEO_NAME;
										$imageObj = new ImageHandler($temp_file . 'T.' . $this->CFG['video']['image']['extensions']);
										$this->setIHObject($imageObj);
										$this->storeImagesTempServer($temp_file, $this->CFG['video']['image']['extensions']);
										if ($this->CFG['debug']['store_log'])
										{
												$log_str = "\n Created images successfully\n" . $source_filename . "\n";
												$log_str .= "\n User Name: " . $this->CFG['user']['name'] . "\n";
												$log_str .= "\n Video Name: " . $this->VIDEO_NAME . "\n";
												$log_str .= "\n Date: " . date("F j, Y, g:i a") . "\n";
												$this->writetoTempFile($log_str);
										}
										$this->updateVideoTable($this->VIDEO_ID);
										$this->activateVideoFile();
										if ($this->CFG['debug']['store_log'])
										{
												$log_str = "\n Activated the video successfully\n" . $source_filename . "\n";
												$log_str .= "\n User Name: " . $this->CFG['user']['name'] . "\n";
												$log_str .= "\n Video Name: " . $this->VIDEO_NAME . "\n";
												$log_str .= "\n Date: " . date("F j, Y, g:i a") . "\n";
												$this->writetoTempFile($log_str);
										}
								}
								else
								{
										$this->removeDirectory($temp_dir);
										$this->video_uploaded_success = false;
										if (is_file($source_filename)) unlink($source_filename);
										$this->deleteVideoTable();
								}
						}
				}
		}
		public function updateVideoTable($video_id)
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['ans_video'] . ' SET' . ' t_width=' . $this->dbObj->Param('t_width') . ', t_height=' . $this->dbObj->Param('t_height') . ',' . ' video_encoded_status=\'Yes\',' . ' playing_time=' . $this->dbObj->Param('playing_time') . ' WHERE video_id=' . $this->dbObj->Param('video_id');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->T_WIDTH, $this->T_HEIGHT, $this->fields_arr['playing_time'], $this->VIDEO_ID));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function changeEncodedStatus($status)
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['ans_video'] . ' SET' . ' video_encoded_status=' . $this->dbObj->Param('video_encoded_status') . ' WHERE video_id=' . $this->dbObj->Param('video_id');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($status, $this->VIDEO_ID));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function deleteVideoTable()
		{
				$sql = 'DELETE FROM ' . $this->CFG['db']['tbl']['ans_video'] . ' WHERE' . ' video_id=' . $this->dbObj->Param('video_id');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->VIDEO_ID));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function activateAudioFile()
		{
				$dir_audio = '../' . $this->CFG['admin']['ans_audios']['audio_folder'];
				$temp_dir = '../' . $this->CFG['admin']['ans_audios']['temp_folder'];
				$tempurl = $temp_dir . $this->AUDIO_NAME;
				$local_upload = true;
				if ($this->getServerDetails('Ans_audio'))
				{
						$dir_audio = $this->CFG['admin']['ans_audios']['audio_folder'];
						if ($FtpObj = new FtpHandler($this->FTP_SERVER, $this->FTP_USERNAME, $this->FTP_PASSWORD))
						{
								if ($this->FTP_FOLDER) $FtpObj->changeDirectory($this->FTP_FOLDER);
								$FtpObj->makeDirectory($dir_audio);
								if (is_file($tempurl . '.' . $this->AUDIO_EXT))
								{
										$FtpObj->moveTo($tempurl . '.' . $this->AUDIO_EXT, $dir_audio . $this->AUDIO_NAME . '.' . $this->AUDIO_EXT);
										unlink($tempurl . '.' . $this->AUDIO_EXT);
								}
								$FtpObj->ftpClose();
								$SERVER_URL = $this->FTP_SERVER_URL;
								$local_upload = false;
						}
				}
				if ($local_upload)
				{
						$upload_dir_audio = $dir_audio;
						$this->chkAndCreateFolder($upload_dir_audio);
						$uploadUrlAudio = $upload_dir_audio . $this->AUDIO_NAME;
						if (is_file($tempurl . '.' . $this->AUDIO_EXT))
						{
								copy($tempurl . '.' . $this->AUDIO_EXT, $uploadUrlAudio . '.' . $this->AUDIO_EXT);
								unlink($tempurl . '.' . $this->AUDIO_EXT);
						}
						$SERVER_URL = $this->CFG['site']['url'];
				}
				if (isset($SERVER_URL))
				{
						$sql = 'UPDATE ' . $this->CFG['db']['tbl']['ans_audio'] . ' SET' . ' audio_ext=\'flv\', audio_server_url=' . $this->dbObj->Param('audio_server_url') . ', audio_status=\'Ok\' WHERE' . ' audio_id=' . $this->dbObj->Param('audio_id');
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($SERVER_URL, $this->AUDIO_ID));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
						if ($this->AUDIO_FOR == 'Question')
						{
								$sql = 'UPDATE ' . $this->CFG['db']['tbl']['questions'] . ' SET' . ' audio_id=' . $this->dbObj->Param('audio_id') . ' WHERE' . ' ques_id=' . $this->dbObj->Param('ques_id');
								$stmt = $this->dbObj->Prepare($sql);
								$rs = $this->dbObj->Execute($stmt, array($this->AUDIO_ID, $this->CONTENT_ID));
								if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
						}
						else
								if ($this->AUDIO_FOR == 'Answer')
								{
										$sql = 'UPDATE ' . $this->CFG['db']['tbl']['answers'] . ' SET' . ' audio_id=' . $this->dbObj->Param('audio_id') . ' WHERE' . ' ans_id=' . $this->dbObj->Param('ans_id');
										$stmt = $this->dbObj->Prepare($sql);
										$rs = $this->dbObj->Execute($stmt, array($this->AUDIO_ID, $this->CONTENT_ID));
										if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
										if ($this->dbObj->Affected_Rows())
										{
												$sql = 'SELECT ques_id FROM ' . $this->CFG['db']['tbl']['answers'] . ' WHERE' . ' ans_id=' . $this->dbObj->Param('ans_id');
												$stmt = $this->dbObj->Prepare($sql);
												$rs = $this->dbObj->Execute($stmt, array($this->CONTENT_ID));
												if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
												$row = $rs->FetchRow();
												$sql = 'UPDATE ' . $this->CFG['db']['tbl']['questions'] . ' SET' . ' total_audios=total_audios+1 WHERE' . ' ques_id=' . $this->dbObj->Param('ques_id');
												$stmt = $this->dbObj->Prepare($sql);
												$rs = $this->dbObj->Execute($stmt, array($row['ques_id']));
												if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
										}
								}
						return true;
				}
				return false;
		}
		public function populateAudioDetails($audio_id, $status = 'No')
		{
				$sql = 'SELECT audio_id, audio_ext, content_id, audio_for FROM' . ' ' . $this->CFG['db']['tbl']['ans_audio'] . ' WHERE' . ' audio_id=' . $this->dbObj->Param('audio_id') . ' AND' . ' audio_encoded_status=' . $this->dbObj->Param('audio_encoded_status') . ' LIMIT 0,1';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($audio_id, $status));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($row = $rs->FetchRow())
				{
						$this->AUDIO_ID = $row['audio_id'];
						$this->AUDIO_NAME = getImageName($row['audio_id']);
						$this->AUDIO_EXT = $row['audio_ext'];
						$this->CONTENT_ID = $row['content_id'];
						$this->AUDIO_FOR = $row['audio_for'];
						return true;
				}
				return false;
		}
		public function audioEncode($audio_id)
		{
				if ($this->populateAudioDetails($audio_id))
				{
						$source = '../' . $this->CFG['admin']['ans_audios']['temp_folder'] . $this->AUDIO_NAME;
						$source_filename = $source . '.' . $this->AUDIO_EXT;
						$store_dir = '../' . $this->CFG['admin']['ans_audios']['temp_folder'];
						if ($this->CFG['debug']['store_log'])
						{
								$log_str = "\n Before Uploading \n" . $source_filename . "\n";
								$log_str .= "\n User Name: " . $this->CFG['user']['name'] . "\n";
								$log_str .= "\n Audio Name: " . $this->AUDIO_NAME . "\n";
								$log_str .= "\n Date: " . date("F j, Y, g:i a") . "\n";
								$this->writetoTempFile($log_str);
						}
						if (is_file($source_filename))
						{
								$result = exec("\"" . $this->CFG['admin']['video']['flvtool2_path'] . "\" -UP " . $source_filename);
								if ($this->CFG['debug']['store_log'])
								{
										$log_str = "\n Flvtool2 start \n Flvtool2 execution Result \n" . @implode("\n", $result);
										$log_str .= "\n Execute Query : " . "\"" . $this->CFG['admin']['video']['flvtool2_path'] . "\" -UP " . $source_filename;
										$log_str .= "\n Flvtool2 execution Output \n" . @implode("\n", $p) . "\n Flvtool2 End \n";
										$log_str .= "\n User Name: " . $this->CFG['user']['name'] . "\n";
										$log_str .= "\n Audio Name: " . $this->VIDEO_NAME . "\n";
										$log_str .= "\n Date: " . date("F j, Y, g:i a") . "\n";
										$this->writetoTempFile($log_str);
								}
								$this->AUDIO_EXT = 'flv';
								$this->changeAudioEncodedStatus('Yes');
								$this->activateAudioFile();
								if ($this->CFG['debug']['store_log'])
								{
										$log_str = "\n Activated audio successfully \n" . $source_filename . "\n";
										$log_str .= "\n User Name: " . $this->CFG['user']['name'] . "\n";
										$log_str .= "\n Audio Name: " . $this->AUDIO_NAME . "\n";
										$log_str .= "\n Date: " . date("F j, Y, g:i a") . "\n";
										$this->writetoTempFile($log_str);
								}
						}
						else
						{
								$this->audio_uploaded_success = false;
								if (is_file($source_filename)) unlink($source_filename);
								$this->deleteAudioTable();
						}
				}
		}
		public function changeAudioEncodedStatus($status)
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['ans_audio'] . ' SET' . ' audio_encoded_status=' . $this->dbObj->Param('audio_encoded_status') . ' WHERE audio_id=' . $this->dbObj->Param('audio_id');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($status, $this->AUDIO_ID));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function deleteAudioTable()
		{
				$sql = 'DELETE FROM ' . $this->CFG['db']['tbl']['ans_audio'] . ' WHERE' . ' audio_id=' . $this->dbObj->Param('audio_id');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->AUDIO_ID));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
}
?>