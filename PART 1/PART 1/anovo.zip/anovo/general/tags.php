<?php
class TagCloudHandler extends FormHandler
{
		public function populateTags()
		{
				if ($this->fields_arr['t'] == 'search')
				{
						$sql = 'SELECT tag_name, search_count AS tag_count FROM ' . $this->CFG['db']['tbl']['tags'];
						$sql .= ' WHERE search_count>0 AND total_count>0';
						$orderSql = ' ORDER BY search_count DESC';
				}
				else
				{
						$sql = 'SELECT tag_name, total_count AS tag_count FROM ' . $this->CFG['db']['tbl']['tags'];
						$sql .= ' WHERE total_count>0';
						$orderSql = ' ORDER BY total_count DESC';
				}
				$sql .= $orderSql . ' LIMIT 0, ' . $this->CFG['admin']['tags_count'];
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount() > 0)
				{
						$resultArray = array();
						while ($row = $rs->FetchRow())
						{
								$resultArray[] = $row;
						}
						if ($this->fields_arr['s'] == 'a')
						{
								foreach ($resultArray as $key => $row)
								{
										$tag_name[$key] = strtolower($row['tag_name']);
								}
								array_multisort($tag_name, SORT_ASC, $resultArray);
						}
						$alphabetLI = $questionsLI = '';
						$alphabetSPAN = $questionsSPAN = '';
						$alphabetA = $questionsA = '';
						$clsActiveForumLinksLeft = 'clsActiveForumLinksLeft';
						$clsActiveForumLinksRight = 'clsActiveForumLinksRight';
						$clsActiveForumLinksMiddle = 'clsActiveForumLinksMiddle';
						$alphaClass = $freqClass = '';
						if ($this->fields_arr['s'] == 'a')
						{
								$alphabetLI = $clsActiveForumLinksLeft;
								$alphabetSPAN = $clsActiveForumLinksRight;
								$alphabetA = $clsActiveForumLinksMiddle;
						}
						if ($this->fields_arr['s'] == 'f')
						{
								$questionsLI = $clsActiveForumLinksLeft;
								$questionsSPAN = $clsActiveForumLinksRight;
								$questionsA = $clsActiveForumLinksMiddle;
						}
?>
<div class="clsCommonTags"><ul class="clsForumLinks">
<li class="<?php echo $alphabetLI; ?>"><span class="<?php echo $alphabetSPAN; ?>"><a class="<?php echo $alphabetA; ?>" href="<?php echo getUrl('tags.php?t=' . $this->fields_arr['t'] . '&s=a', 'tags/?t=' . $this->fields_arr['t'] . '&s=a'); ?>"><?php echo $this->LANG['tags_alphabetically'] ?></a></span></li>

<li class="<?php echo $questionsLI; ?>"><span class="<?php echo $questionsSPAN; ?>"><a class="<?php echo $questionsA; ?>" href="<?php echo getUrl('tags.php?t=' . $this->fields_arr['t'] . '&s=f', 'tags/?t=' . $this->fields_arr['t'] . '&s=f'); ?>"><?php echo $this->LANG['tags_frequency'] ?></a>
</span></li>
</ul>
<div class="clsTags">
<?php
						$classes = array('clsTagStyleBlue', 'clsTagStyleGrey', 'clsTagStyleGreen', 'clsTagStyleRed');
						$tagClassArray = array();
						foreach ($resultArray as $row)
						{
								$tagArray[$row['tag_name']] = $row['tag_count'];
								$class = $classes[rand(0, count($classes)) % count($classes)];
								$tagClassArray[$row['tag_name']] = $class;
						}
						$tagArray = $this->setFontSizeInsteadOfSearchCount($tagArray);
						foreach ($tagArray as $tag => $fontSize)
						{
								$url = getUrl($this->CFG['site']['relative_url'] . 'questions.php?view=search&tags=' . $tag, $this->CFG['site']['relative_url'] . 'answers/search/?tags=' . $tag, false);
								$class = $tagClassArray[$tag];
								$fontSizeClass = 'style="font-size:' . $fontSize . 'px"';
?>
<span class="<?php echo $class; ?>"><a href="<?php echo $url; ?>" <?php echo $fontSizeClass; ?>><?php echo $tag; ?></a></span>
<?php
						}
?>
</div></div>
<?php
				}
				else
				{
?>
<div id="selMsgSuccess">
  	<p><?php echo $this->LANG['no_tags_found']; ?></p>
</div>
<?php
				}
		}
}
$Tag = new TagCloudHandler();
$Tag->setDBObject($db);
$Tag->makeGlobalize($CFG, $LANG);
$Tag->setPageBlockNames(array('allTagBlock'));
$Tag->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$Tag->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$Tag->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$Tag->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$Tag->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$Tag->setFormField('t', 'freq');
$Tag->setFormField('s', 'a');
$Tag->setAllPageBlocksHide();
$Tag->setPageBlockShow('allTagBlock');
$Tag->sanitizeFormInputs($_REQUEST);
$type_title = $LANG['common_top_tags_title'];
if ($Tag->getFormField('t') == 'search') $type_title = $LANG['common_top_search_tags_title'];
?>
<div id="selGroupCreate">
	<h2><span><?php echo $LANG['page_title']; ?> - <?php echo $type_title; ?></span></h2>
<?php
if ($Tag->isShowPageBlock('allTagBlock'))
{
		$Tag->populateTags();
}
?>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>