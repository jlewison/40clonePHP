<?php
require_once ('../common/config.inc.php');
$CFG['lang']['include_files'][] = 'admin/includes/languages/%s/addNewsLetter.php';
$CFG['lang']['include_files'][] = 'common/languages/%s/lists_array/gender_list_array.inc.php';
$CFG['mods']['include_files'][] = 'common/languages/%s/lists_array/months_list_array.inc.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['mods']['include_files'][] = 'common/classes/class_ListRecordsHandler.lib.php';
$CFG['mods']['include_files'][] = 'common/classes/phpmailer/class_PHPMailer.lib.php';
$CFG['html']['header'] = 'admin/includes/languages/%s/html_header.php';
$CFG['html']['footer'] = 'admin/includes/languages/%s/html_footer.php';
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class addNewsLetter extends FormHandler
{
		public function insertFormFieldsInTable($tableName, $fields_to_insert_arr = array())
		{
				$sql = 'INSERT INTO ' . $tableName . ' SET date_added = NOW(), ';
				foreach ($fields_to_insert_arr as $field_name)
						if (isset($this->fields_arr[$field_name])) $sql .= $field_name . '=\'' . addslashes($this->fields_arr[$field_name]) . '\', ';
				$sql = substr($sql, 0, strrpos($sql, ','));
				$stmt = $this->dbObj->Prepare($sql);
				$result_set = $this->dbObj->Execute($stmt);
				if (!$result_set) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return ($this->dbObj->Insert_ID());
		}
		public function isEmpty($value)
		{
				$is_not_empty = is_string($value) ? trim($value) == '' : empty($value);
				return $is_not_empty;
		}
		public function checkDateFieldSets()
		{
				$doj_s_d = $this->fields_arr['doj_s_d'];
				$doj_s_m = $this->fields_arr['doj_s_m'];
				$doj_s_y = $this->fields_arr['doj_s_y'];
				$doj_e_d = $this->fields_arr['doj_e_d'];
				$doj_e_m = $this->fields_arr['doj_e_m'];
				$doj_e_y = $this->fields_arr['doj_e_y'];
				$dob_s_d = $this->fields_arr['dob_s_d'];
				$dob_s_m = $this->fields_arr['dob_s_m'];
				$dob_s_y = $this->fields_arr['dob_s_y'];
				$dob_e_d = $this->fields_arr['dob_e_d'];
				$dob_e_m = $this->fields_arr['dob_e_m'];
				$dob_e_y = $this->fields_arr['dob_e_y'];
				$login_s_d = $this->fields_arr['login_s_d'];
				$login_s_m = $this->fields_arr['login_s_m'];
				$login_s_y = $this->fields_arr['login_s_y'];
				$dateFields = array();
				if ($doj_s_d and $doj_s_m and $doj_s_y)
				{
						$doj_start = sprintf("%04d-%02d-%02d 00:00", $doj_s_y, $doj_s_m, $doj_s_d);
						$this->fields_arr['doj_start'] = $doj_start;
						$dateFields[] = 'doj_start';
						$dateFields[] = 'doj_s_y';
						$dateFields[] = 'doj_s_m';
						$dateFields[] = 'doj_s_d';
				}
				if ($doj_e_d and $doj_e_m and $doj_e_y)
				{
						$doj_end = sprintf("%04d-%02d-%02d 00:00", $doj_e_y, $doj_e_m, $doj_e_d);
						$this->fields_arr['doj_end'] = $doj_end;
						$dateFields[] = 'doj_end';
						$dateFields[] = 'doj_e_y';
						$dateFields[] = 'doj_e_m';
						$dateFields[] = 'doj_e_d';
				}
				if ($dob_s_d and $dob_s_m and $dob_s_y)
				{
						$dob_start = sprintf("%04d-%02d-%02d 00:00", $dob_s_y, $dob_s_m, $dob_s_d);
						$this->fields_arr['dob_start'] = $dob_start;
						$dateFields[] = 'dob_start';
						$dateFields[] = 'dob_s_y';
						$dateFields[] = 'dob_s_m';
						$dateFields[] = 'dob_s_d';
				}
				if ($dob_e_d and $dob_e_m and $dob_e_y)
				{
						$dob_end = sprintf("%04d-%02d-%02d 00:00", $dob_e_y, $dob_e_m, $dob_e_d);
						$this->fields_arr['dob_end'] = $dob_end;
						$dateFields[] = 'dob_end';
						$dateFields[] = 'dob_e_y';
						$dateFields[] = 'dob_e_m';
						$dateFields[] = 'dob_e_d';
				}
				if ($login_s_d and $login_s_m and $login_s_y)
				{
						$login_start = sprintf("%04d-%02d-%02d 00:00", $login_s_y, $login_s_m, $login_s_d);
						$this->fields_arr['login_start'] = $login_start;
						$dateFields[] = 'login_start';
						$dateFields[] = 'login_s_y';
						$dateFields[] = 'login_s_m';
						$dateFields[] = 'login_s_d';
				}
				return $dateFields;
		}
		public function canSearchWithTag()
		{
				$tagz = $this->fields_arr['tagz'];
				$tagz = trim($tagz);
				$return = false;
				if ($tagz)
				{
						$length = strlen($tagz);
						if ($length > 2)
						{
								$return = true;
						}
				}
				return $return;
		}
		public function buildConditionQuery()
		{
				$dateFields = $this->checkDateFieldSets();
				$sql_condition = " usr_status!='Deleted'";
				$condition = '';
				if (!$this->isEmpty($this->fields_arr["uname"]))
				{
						$sql_condition .= " AND " . $this->getUserTableField('name') . " LIKE '%" . addslashes($this->fields_arr['uname']) . "%' ";
				}
				if (!$this->isEmpty($this->fields_arr["email"]))
				{
						$sql_condition .= " AND email LIKE '%" . addslashes($this->fields_arr['email']) . "%' ";
				}
				if (!$this->isEmpty($this->fields_arr["fname"]))
				{
						$sql_condition .= " AND first_name LIKE '%" . addslashes($this->fields_arr['fname']) . "%' ";
				}
				if (!$this->isEmpty($this->fields_arr["lname"]))
				{
						$sql_condition .= " AND last_name LIKE '%" . addslashes($this->fields_arr['lname']) . "%' ";
				}
				if (!$this->isEmpty($this->fields_arr["tagz"]) and $this->canSearchWithTag())
				{
						$sql_condition .= " AND " . getSearchRegularExpressionQuery($this->fields_arr["tagz"], "profile_tags", "");
				}
				if (!$this->isEmpty($this->fields_arr['doj_start']))
				{
						$dojStart = $this->fields_arr['doj_start'];
						$sql_condition .= " AND " . $this->getUserTableField('doj') . " >= '" . addslashes($dojStart) . "'";
				}
				if (!$this->isEmpty($this->fields_arr['doj_end']))
				{
						$dojEnd = $this->fields_arr['doj_end'];
						$sql_condition .= " AND " . $this->getUserTableField('doj') . " <= '" . addslashes($dojEnd) . "'";
				}
				if (!$this->isEmpty($this->fields_arr['dob_start']))
				{
						$dobStart = $this->fields_arr['dob_start'];
						$sql_condition .= " AND " . $this->getUserTableField('dob') . " >= '" . addslashes($dobStart) . "'";
				}
				if (!$this->isEmpty($this->fields_arr['dob_end']))
				{
						$dobEnd = $this->fields_arr['dob_end'];
						$sql_condition .= " AND " . $this->getUserTableField('dob') . " <= '" . addslashes($dobEnd) . "'";
				}
				if (!$this->isEmpty($this->fields_arr['login_start']))
				{
						$loginStart = $this->fields_arr['login_start'];
						$sql_condition .= " AND " . $this->getUserTableField('last_logged') . " <= '" . addslashes($loginStart) . "'";
				}
				if (!$this->isEmpty($this->fields_arr['gender']))
				{
						$sql_condition .= " AND " . $this->getUserTableField('gender') . "='" . addslashes($this->fields_arr['gender']) . "'";
				}
				$statusOk = $this->fields_arr['user_status_Ok'];
				$statusDeActivate = $this->fields_arr['user_status_ToActivate'];
				$statusLocked = $this->fields_arr['user_status_Locked'];
				if ($statusOk or $statusDeActivate or $statusLocked)
				{
						$statusCondition = '( 0 ';
						$statusCondition .= $statusOk ? " OR usr_status='Ok'" : '';
						$statusCondition .= $statusDeActivate ? " OR usr_status='ToActivate'" : '';
						$statusCondition .= $statusLocked ? " OR usr_status='Locked'" : '';
						$statusCondition .= ')';
						$sql_condition .= ' AND ' . $statusCondition;
				}
				$this->fields_arr['sql_condition'] = $sql_condition;
		}
		public function populateYearsListCurrent($highlight_y, $min_year, $max_year)
		{
				for ($y = $min_year; $y <= $max_year; ++$y)
				{
?>
	<option value="<?php echo $y; ?>"<?php echo ($highlight_y == $y) ? ' selected="selected"' : ''; ?>><?php echo $y; ?></option>
<?php
				}
		}
}
$addnewsletter = new addNewsLetter();
$min_doj_year = date("Y") - 5;
$max_doj_year = date("Y");
$min_dob_year = date("Y") - 75;
$max_dob_year = date("Y");
$addnewsletter->setPageBlockNames(array('msg_form_error', 'msg_form_success', 'form_add_letter', 'form_confirm'));
$addnewsletter->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$addnewsletter->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$addnewsletter->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$addnewsletter->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$addnewsletter->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$addnewsletter->setDBObject($db);
$addnewsletter->makeGlobalize($CFG, $LANG);
$addnewsletter->setFormField('subject', '');
$addnewsletter->setFormField('body', '');
$addnewsletter->setFormField('email', '');
$addnewsletter->setFormField('uname', '');
$addnewsletter->setFormField('fname', '');
$addnewsletter->setFormField('lname', '');
$addnewsletter->setFormField('tagz', '');
$addnewsletter->setFormField('gender', '');
$addnewsletter->setFormField('sql_condition', '');
$addnewsletter->setFormField('user_status_Ok', '');
$addnewsletter->setFormField('user_status_ToActivate', '');
$addnewsletter->setFormField('user_status_Locked', '');
$addnewsletter->setFormField('test_users', '');
$addnewsletter->setFormField('mail_error', '');
$addnewsletter->setFormField('dob_start', '');
$addnewsletter->setFormField('dob_s_d', '');
$addnewsletter->setFormField('dob_s_m', '');
$addnewsletter->setFormField('dob_s_y', '');
$addnewsletter->setFormField('dob_end', '');
$addnewsletter->setFormField('dob_e_d', '');
$addnewsletter->setFormField('dob_e_m', '');
$addnewsletter->setFormField('dob_e_y', '');
$addnewsletter->setFormField('doj_start', '');
$addnewsletter->setFormField('doj_s_d', '');
$addnewsletter->setFormField('doj_s_m', '');
$addnewsletter->setFormField('doj_s_y', '');
$addnewsletter->setFormField('doj_end', '');
$addnewsletter->setFormField('doj_e_d', '');
$addnewsletter->setFormField('doj_e_m', '');
$addnewsletter->setFormField('doj_e_y', '');
$addnewsletter->setFormField('based_user_settings', 'Yes');
$addnewsletter->setFormField('login_start', '');
$addnewsletter->setFormField('login_s_d', '');
$addnewsletter->setFormField('login_s_m', '');
$addnewsletter->setFormField('login_s_y', '');
$addnewsletter->setFormField('withPhotoVideoFriends', '');
$addnewsletter->setFormField('search', '');
$addnewsletter->setMonthsListArr($LANG_LIST_ARR['months']);
$addnewsletter->setYearsListMinMax(date('Y') - 1, date('Y') + 1);
$addnewsletter->setAllPageBlocksHide();
$addnewsletter->setPageBlockShow('form_search');
$addnewsletter->setPageBlockShow('form_add_letter');
if ($addnewsletter->isFormPOSTed($_POST, 'addstock'))
{
		$addnewsletter->sanitizeFormInputs($_POST);
		$addnewsletter->chkIsNotEmpty('subject', $LANG['addletter_err_tip_compulsory']);
		$addnewsletter->chkIsNotEmpty('body', $LANG['addletter_err_tip_compulsory']);
		if ($addnewsletter->isValidFormInputs())
		{
				$addnewsletter->buildConditionQuery();
				$addnewsletter->setPageBlockShow('form_confirm');
				$addnewsletter->setPageBlockShow('form_add_letter');
		}
		else
		{
				$addnewsletter->setAllPageBlocksHide();
				$addnewsletter->setPageBlockShow('msg_form_error');
				$addnewsletter->setPageBlockShow('form_add_letter');
		}
} elseif ($addnewsletter->isFormPOSTed($_POST, 'cancelstock'))
{
		Redirect2URL($CFG['site']['url'] . "admin/addNewsLetter.php");
} elseif ($addnewsletter->isFormPOSTed($_POST, 'submit_confirm'))
{
		$addnewsletter->sanitizeFormInputs($_POST);
		$addnewsletter->chkIsNotEmpty('subject', $LANG['addletter_err_tip_compulsory']);
		$addnewsletter->chkIsNotEmpty('body', $LANG['addletter_err_tip_compulsory']);
		if ($addnewsletter->isValidFormInputs())
		{
				$comment = html_entity_decode($addnewsletter->getFormField('body'));
				$addnewsletter->setFormField('body', $comment);
				$addnewsletter->setAllPageBlocksHide();
				$succesMsg = $LANG['addletter_success_message'];
				$addnewsletter->setPageBlockShow('msg_form_success');
				$inputArr = array('subject', 'body', 'sql_condition', 'based_user_settings');
				$currentEventId = $addnewsletter->insertFormFieldsInTable($CFG['db']['tbl']['news_letter'], $inputArr);
				$addnewsletter->setFormField('subject', '');
				$addnewsletter->setFormField('body', '');
				$addnewsletter->setPageBlockShow('form_add_letter');
		}
		else
		{
				$addnewsletter->setAllPageBlocksHide();
				$addnewsletter->setPageBlockShow('msg_form_error');
				$addnewsletter->setPageBlockShow('form_add_letter');
		}
}

?>
<div id="selAddNewsLetter">
	<h2 class="clsNewsLetterTitle"><?php echo $LANG['addletter_title']; ?></h2>
<?php

if ($addnewsletter->isShowPageBlock('msg_form_error'))
{
?>
<div id="selMsgError">
	 <p><?php echo $LANG['addletter_err_tip_error'] . ' ' . $addnewsletter->getCommonErrorMsg(); ?></p>
</div>
<?php
}
if ($addnewsletter->isShowPageBlock('msg_form_success'))
{
?>
<div id="selMsgSuccess">
 	<p><?php echo $succesMsg; ?></p>
</div>
<?php
}
if ($addnewsletter->isShowPageBlock('form_confirm'))
{
?>
		<form name="form_search_ad" id="selFormselSearchAdd" method="post" action="<?php echo URL($_SERVER['PHP_SELF']); ?>" autocomplete="off">
					<tr>
					<td colspan="2">
<?php
		echo $LANG['addletter_confirm'];
		$addnewsletter->populateHidden(array('subject', 'body', 'sql_condition', 'based_user_settings'));
?>
					</td>

				<tr>
					<td><input class="clsSubmitButton" type="submit" name="submit_confirm" value="<?php echo $LANG['addletter_yes']; ?>" tabindex="<?php echo $addnewsletter->getTabIndex(); ?>"</td>
					<td><input class="clsSubmitButton" type="submit" name="submit_cancel" value="<?php echo $LANG['addletter_no']; ?>" tabindex="<?php echo $addnewsletter->getTabIndex(); ?>"</td>
				</tr>
			</table>
		</form>
<?php
}
if (!$addnewsletter->isShowPageBlock('form_confirm') and ($addnewsletter->isShowPageBlock('form_add_letter')))
{
		$submitName = '';
		$submitName = $LANG['addletter_add'];
?>
		<form name="form_editBuySelltype" id="selFormEditBuyselltype" method="post" action="<?php echo URL($_SERVER['PHP_SELF']); ?>" autocomplete="off">
			<table summary="<?php echo $LANG['addletter_tbl_summary']; ?>">
				<tr>
			        <th colspan="2"><?php echo $LANG['addletter_special_code_title']; ?></th>
			    </tr>
			      <tr>
			        <td colspan="2"><ul class="clsBottomBorder">
			            <li>{email}</li>
			            <li>{password}</li>
			            <li>{username}</li>
			          </ul></td>
			      </tr>
	        <tr>
	          <td class="<?php echo $addnewsletter->getCSSFormLabelCellClass('uname'); ?>"><?php ?><label for="uname"><?php echo $LANG['search_user_name']; ?></label></td>
	          <td class="<?php echo $addnewsletter->getCSSFormFieldCellClass('uname'); ?>"><?php echo $addnewsletter->getFormFieldErrorTip('uname'); ?><input type="text" class="clsTextBox" name="uname" id="uname" tabindex="<?php echo $addnewsletter->getTabIndex(); ?>" value="<?php echo $addnewsletter->getFormField('uname'); ?>" /></td>
			</tr>
		   <!--<tr>
		     <td class="<?php echo $addnewsletter->getCSSFormLabelCellClass('fname'); ?>"><?php ?><label for="first_name"><?php echo $LANG['search_first_name']; ?></label></td>
	         <td class="<?php echo $addnewsletter->getCSSFormFieldCellClass('fname'); ?>"><?php echo $addnewsletter->getFormFieldErrorTip('fname'); ?><input type="text" class="clsTextBox" name="fname" id="fname" tabindex="<?php echo $addnewsletter->getTabIndex(); ?>" value="<?php echo $addnewsletter->getFormField('fname'); ?>" /></td>
			</tr>
	       <tr>
	         <td class="<?php echo $addnewsletter->getCSSFormLabelCellClass('lname'); ?>"><?php ?><label for="first_name"><?php echo $LANG['search_last_name']; ?></label></td>
	         <td class="<?php echo $addnewsletter->getCSSFormFieldCellClass('lname'); ?>"><?php echo $addnewsletter->getFormFieldErrorTip('lname'); ?><input type="text" class="clsTextBox" name="lname" id="lname" tabindex="<?php echo $addnewsletter->getTabIndex(); ?>" value="<?php echo $addnewsletter->getFormField('lname'); ?>" /></td>
			</tr>-->
			<tr>
			  <td class="<?php echo $addnewsletter->getCSSFormLabelCellClass('email'); ?>"><?php ?><label for="email"><?php echo $LANG['search_email']; ?></label></td>
	          <td class="<?php echo $addnewsletter->getCSSFormFieldCellClass('email'); ?>"><?php echo $addnewsletter->getFormFieldErrorTip('email'); ?><input type="text" class="clsTextBox" name="email" id="email" tabindex="<?php echo $addnewsletter->getTabIndex(); ?>" value="<?php echo $addnewsletter->getFormField('email'); ?>" /></td>
	        </tr>

			 <tr>
	          <td class="<?php echo $addnewsletter->getCSSFormLabelCellClass('gender'); ?>"><?php ?><label for="gender"><?php echo $LANG['search_sex']; ?></label></td>
	          <td class="<?php echo $addnewsletter->getCSSFormFieldCellClass('gender'); ?>"><?php echo $addnewsletter->getFormFieldErrorTip('gender'); ?>
			  <select class="clsCommonListBox" name="gender" id="gender" tabindex="<?php echo $addnewsletter->getTabIndex(); ?>">
			  	<option value=""><?php echo $LANG['search_sex_option_both']; ?></option>
				<?php
		$addnewsletter->generalPopulateArray($LANG_LIST_ARR['gender'], $addnewsletter->getFormField('gender'));
?>
			  </select>
			 </td>
			 </tr>
			 <tr>
				<td class="<?php echo $addnewsletter->getCSSFormLabelCellClass('doj_s_d'); ?>"><?php ?><label for="dob_s_d"><?php echo $LANG['search_doj']; ?></label></td>
				<td  class="<?php echo $addnewsletter->getCSSFormFieldCellClass('doj_s_d'); ?>">
					<p>
						<label for="doj_s_d"><label for="doj_s_d"><?php echo $LANG['search_results_label_doj_from']; ?></label></label>
						<select name="doj_s_d" id="doj_s_d" tabindex="<?php echo $addnewsletter->getTabIndex(); ?>" >
						<option value="">-</option>
						<?php $addnewsletter->populateDaysList($addnewsletter->getFormField('doj_s_d')); ?>
						</select>
						<select name="doj_s_m" id="doj_s_m" tabindex="<?php echo $addnewsletter->getTabIndex(); ?>" >
						<option value="">-</option>
						<?php $addnewsletter->populateMonthsList($addnewsletter->getFormField('doj_s_m')); ?>
						</select>
						<select name="doj_s_y" id="doj_s_y" tabindex="<?php echo $addnewsletter->getTabIndex(); ?>" >
						<option value="">-</option>
						<?php $addnewsletter->populateYearsListCurrent($addnewsletter->getFormField('doj_s_y'), $min_doj_year, $max_doj_year); ?>
						</select>
					</p>
					<p>
						<label for="doj_e_d"><label for="doj_e_d"><?php echo $LANG['search_results_label_doj_to']; ?></label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
						<select name="doj_e_d" id="doj_e_d" tabindex="<?php echo $addnewsletter->getTabIndex(); ?>" >
						<option value="">-</option>
						<?php $addnewsletter->populateDaysList($addnewsletter->getFormField('doj_e_d')); ?>
						</select>
						<select name="doj_e_m" id="doj_e_m" tabindex="<?php echo $addnewsletter->getTabIndex(); ?>" >
						<option value="">-</option>
						<?php $addnewsletter->populateMonthsList($addnewsletter->getFormField('doj_e_m')); ?>
						</select>
						<select name="doj_e_y" id="doj_e_y" tabindex="<?php echo $addnewsletter->getTabIndex(); ?>" >
						<option value="">-</option>
						<?php $addnewsletter->populateYearsListCurrent($addnewsletter->getFormField('doj_e_y'), $min_doj_year, $max_doj_year); ?>
						</select>
					</p>
				</td>
			</tr>
			<!-- <tr>
				<td class="<?php echo $addnewsletter->getCSSFormLabelCellClass('dob_s_d'); ?>"><?php ?><label for="dob_s_d"><?php echo $LANG['search_dob']; ?></label></td>
				<td  class="<?php echo $addnewsletter->getCSSFormFieldCellClass('dob_s_d'); ?>">
					<p>
						<label for="dob_s_d"><label for="dob_s_d"><?php echo $LANG['search_results_label_dob_from']; ?></label></label>
						<select name="dob_s_d" id="dob_s_d" tabindex="<?php echo $addnewsletter->getTabIndex(); ?>" >
						<option value="">-</option>
						<?php $addnewsletter->populateDaysList($addnewsletter->getFormField('dob_s_d')); ?>
						</select>
						<select name="dob_s_m" id="dob_s_m" tabindex="<?php echo $addnewsletter->getTabIndex(); ?>" >
						<option value="">-</option>
						<?php $addnewsletter->populateMonthsList($addnewsletter->getFormField('dob_s_m')); ?>
						</select>
						<select name="dob_s_y" id="dob_s_y" tabindex="<?php echo $addnewsletter->getTabIndex(); ?>" >
						<option value="">-</option>
						<?php $addnewsletter->populateYearsListCurrent($addnewsletter->getFormField('dob_s_y'), $min_dob_year, $max_dob_year); ?>
						</select>
					</p>
					<p>
						<label for="dob_e_d"><label for="dob_e_d"><?php echo $LANG['search_results_label_dob_to']; ?></label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
						<select name="dob_e_d" id="dob_e_d" tabindex="<?php echo $addnewsletter->getTabIndex(); ?>" >
						<option value="">-</option>
						<?php $addnewsletter->populateDaysList($addnewsletter->getFormField('dob_e_d')); ?>
						</select>
						<select name="dob_e_m" id="dob_e_m" tabindex="<?php echo $addnewsletter->getTabIndex(); ?>" >
						<option value="">-</option>
						<?php $addnewsletter->populateMonthsList($addnewsletter->getFormField('dob_e_m')); ?>
						</select>
						<select name="dob_e_y" id="dob_e_y" tabindex="<?php echo $addnewsletter->getTabIndex(); ?>" >
						<option value="">-</option>
						<?php $addnewsletter->populateYearsListCurrent($addnewsletter->getFormField('dob_e_y'), $min_dob_year, $max_dob_year); ?>
						</select>
					</p>
				</td>
			</tr>-->
					<tr>
			<td><label for="login_s_d"><?php echo $LANG['search_results_label_last_logged']; ?></label></td>
				<td  class="<?php echo $addnewsletter->getCSSFormFieldCellClass('login_s_d'); ?>">
					<p>
						<label for="login_s_d"><label for="login_s_d"><?php echo $LANG['search_results_label_last_logged_from']; ?></label>&nbsp;</label>
						<select name="login_s_d" id="login_s_d" tabindex="<?php echo $addnewsletter->getTabIndex(); ?>" >
						<option value="">-</option>
						<?php $addnewsletter->populateDaysList($addnewsletter->getFormField('login_s_d')); ?>
						</select>
						<select name="login_s_m" id="login_s_m" tabindex="<?php echo $addnewsletter->getTabIndex(); ?>" >
						<option value="">-</option>
						<?php $addnewsletter->populateMonthsList($addnewsletter->getFormField('login_s_m')); ?>
						</select>
						<select name="login_s_y" id="login_s_y" tabindex="<?php echo $addnewsletter->getTabIndex(); ?>" >
						<option value="">-</option>
						<?php $addnewsletter->populateYearsListCurrent($addnewsletter->getFormField('login_s_y'), $min_doj_year, $max_doj_year); ?>
						</select>
					</p>
				</td>
		</tr>
			<tr>
			 <td><label for=""><?php echo $LANG['search_results_label_status']; ?></label></td>
			 <td  class="<?php echo $addnewsletter->getCSSFormFieldCellClass('user_status_Ok'); ?>">
			 	<span><input type="checkbox" class="clsCheckRadio" value="Ok" id="user_status_Ok" name="user_status_Ok"  <?php echo $addnewsletter->isCheckedCheckBox('user_status_Ok'); ?> tabindex="<?php echo $addnewsletter->getTabIndex(); ?>"/><label for="user_status_Ok"><?php echo $LANG['search_results_label_status_active']; ?></label></span>
				<span><input type="checkbox" class="clsCheckRadio" value="ToActivate" id="user_status_ToActivate" name="user_status_ToActivate" <?php echo $addnewsletter->isCheckedCheckBox('user_status_ToActivate'); ?> tabindex="<?php echo $addnewsletter->getTabIndex(); ?>"/><label for="user_status_ToActivate"><?php echo $LANG['search_results_label_status_in_active']; ?></label></span>
				<span><input type="checkbox" class="clsCheckRadio" value="Locked" id="user_status_Locked" name="user_status_Locked" <?php echo $addnewsletter->isCheckedCheckBox('user_status_Locked'); ?> tabindex="<?php echo $addnewsletter->getTabIndex(); ?>"/><label for="user_status_Locked"><?php echo $LANG['search_results_label_status_locked']; ?></label></span>
			 </td>
	        </tr>
			<tr>
			 <td><label for=""><?php echo $LANG['search_results_label_based_user_settings']; ?></label></td>
			 <td  class="<?php echo $addnewsletter->getCSSFormFieldCellClass('based_user_settings'); ?>">
			 	<span><input type="radio" class="clsCheckRadio" value="Yes" id="based_user_settings_Yes" name="based_user_settings"  <?php echo $addnewsletter->isCheckedRadio('based_user_settings', 'Yes'); ?> tabindex="<?php echo $addnewsletter->getTabIndex(); ?>"/><label for="based_user_settings_Yes"><?php echo $LANG['search_results_label_yes']; ?></label></span>
				<span><input type="radio" class="clsCheckRadio" value="No" id="based_user_settings_No" name="based_user_settings" <?php echo $addnewsletter->isCheckedRadio('based_user_settings', 'No'); ?> tabindex="<?php echo $addnewsletter->getTabIndex(); ?>"/><label for="based_user_settings_No"><?php echo $LANG['search_results_label_no']; ?></label></span>
			 </td>
	        </tr>
						<tr>
					<td class="<?php echo $addnewsletter->getCSSFormLabelCellClass('subject'); ?>"><label for="subject"><?php echo $LANG['addletter_subject']; ?></label></td>
					<td class="<?php echo $addnewsletter->getCSSFormFieldCellClass('subject'); ?>"><?php echo $addnewsletter->getFormFieldErrorTip('subject'); ?><input type="text" class="clsTextBox" name="subject" id="subject" tabindex="<?php echo $addnewsletter->getTabIndex(); ?>" value="<?php echo stripslashes($addnewsletter->getFormField('subject')); ?>" /></td>
				</tr>
			    <tr>
					<td class="<?php echo $addnewsletter->getCSSFormLabelCellClass('body'); ?>"><label for="body"><?php echo $LANG['addletter_body']; ?></label></td>
					<td class="<?php echo $addnewsletter->getCSSFormFieldCellClass('body'); ?>"><?php echo $addnewsletter->getFormFieldErrorTip('body'); ?>
						<textarea name="body" id="body" tabindex="<?php echo $addnewsletter->getTabIndex(); ?>"><?php echo stripslashes($addnewsletter->getFormField('body')); ?></textarea>
					</td>
			    </tr>
			   	<tr>
                <td>&nbsp;</td>
		   			<td class="<?php echo $addnewsletter->getCSSFormFieldCellClass('submit'); ?>">
						<a href="#" id="dAltMlti"></a>
						<input type="submit" class="clsSubmitButton" name="addstock" id="addstock" tabindex="<?php echo $addnewsletter->getTabIndex(); ?>" value="<?php echo $submitName; ?>"  />
					</td>
				</tr>
			</table>
		</form>
<?php
}
?>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>
