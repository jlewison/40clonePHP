<?php
/**
*
*
*
* @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
* @license
* @version SVN:$Id
* @since 2007-06-18
*/
$lang['othersettings_title'] 					= 'Common Admin Settings';
$lang['othersettings_total_albums'] 			= 'Total albums user can create';
$lang['othersettings_total_photos'] 			= 'Total photos for each album';
$lang['othersettings_total_groups'] 			= 'Total groups user can create';
$lang['othersettings_total_groups_user_join'] 	= 'Total groups user can join';
$lang['othersettings_total_events'] 			= 'Total event user can create';
$lang['othersettings_total_events_user_join'] 	= 'Total event user can join';
$lang['othersettings_submit'] 					= 'Save changes';
$lang['othersettings_success_msg']				= 'Other settings updated successfully!';
?>