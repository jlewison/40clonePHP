<? include ("header.php"); ?>




















<table cellpadding="0" cellspacing="0" border="0" width="100%">
	<tr class="top3">
		<td colspan="3"><img src="template/v3/i/b.gif" border="0" height="15" width="1"></td>
	</tr>
	<tr class="top4">
		<td>&nbsp;</td>
		<td align="center">
			<table cellpadding="0" cellspacing="0" border="0" width="778">
				<tr>
					<td valign="top" height="109"><object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" width="257" height="109" id="logo" align="middle"><param name="movie" value="flash/logo.swf" /><param name="quality" value="high" /><param name="wmode" value="transparent" /><param name="bgcolor" value="#ffffff" /><embed src="flash/logo.swf" quality="high" wmode="transparent" bgcolor="#ffffff" width="257" height="109" name="rotator" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /></object></td>
					<td valign="top" height="109"><img src="template/v3/i/content12.jpg" border="0"></td>
					<td rowspan="3" valign="top" class="box_right"><object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" width="204" height="128" id="innerstar" align="middle"><param name="allowScriptAccess" value="sameDomain" /><param name="movie" value="flash/innerstar.swf" /><param name="quality" value="high" /><param name="wmode" value="transparent" /><param name="bgcolor" value="#ffffff" /><embed src="flash/innerstar.swf" quality="high" wmode="transparent" bgcolor="#ffffff" width="204" height="128" name="innerstar" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /></object><a href="promotions.php"><img src="template/v3/i/innerstar-1b2.gif" border="0"></a>
						<table cellpadding="0" cellspacing="0" border="0">
	<? include ("mg.php"); ?>					</td>
				</tr>
				<tr>
					<td class="subtitle_path" colspan="2" valign="top" height="35"><div><a href="index.php"><img src="template/v3/i/home_ico.jpg" border="0" vspace="0" style="margin-left: 36px;margin-right: 27px" align="left"></a></div>Preview</td>
				</tr>
				<tr>
					<td colspan="2" class="content" valign="top"><img src="template/v3/i/b.gif" width="1" height="500" border="0" align="left"><h2> <span> Games</span></h2>
<br>
<table cellpadding="0" cellspacing="0" border="0" width="500">
	<tr>
		<td class="preview_td"><a href="javascript:popup2('preview_card_games.php');"><img src="template/v3/i/preview_cards.jpg"></a><a href="javascript:popup2('preview_table_games.php');"><img src="template/v3/i/preview_table.jpg"></a><a href="javascript:popup2('preview_single_line.php');"><img src="template/v3/i/preview_single_line.jpg"></a></td>
	</tr>
	<tr>
		<td height="5">&nbsp;</td>
	</tr>
	<tr>
		<td class="preview_td"><a href="javascript:popup2('preview_multi_line.php');"><img src="template/v3/i/preview_multiline.jpg"></a><a href="javascript:popup2('preview_specials.php');"><img src="template/v3/i/preview_specials.jpg"></a><a href="javascript:popup2('preview_vpoker.php');"><img src="template/v3/i/preview_vpoker.jpg"></a></td>
	</tr>
	<tr>
		<td height="5">&nbsp;</td>
	</tr>
	<tr>
		<td class="preview_td"><a href="javascript:popup2('preview_progressive.php');"><img src="template/v3/i/preview_progressive.jpg"></a></td>
	</tr>
</table></td>
				</tr>
				<tr>
					<td colspan="2" valign="bottom" class="content_bot"><img src="template/v3/i/content_bot.jpg" border="0"></td>
					<td class="box_right" valign="bottom"><img src="template/v3/i/box_right_bot.jpg" border="0"></td>
				</tr>
			</table>
		</td>
		<td>&nbsp;</td>
	</tr>
<?		include ("footer.php") ?>		