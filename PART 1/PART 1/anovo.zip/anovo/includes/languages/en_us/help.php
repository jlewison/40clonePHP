<?php
$LANG['help_title'] = 'Help';
?>