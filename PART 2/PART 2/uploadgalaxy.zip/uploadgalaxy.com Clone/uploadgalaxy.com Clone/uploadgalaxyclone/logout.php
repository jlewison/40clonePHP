<?
setcookie('uname','');
setcookie('uid','');
setcookie('email','');
header("location: index.php");
?>
