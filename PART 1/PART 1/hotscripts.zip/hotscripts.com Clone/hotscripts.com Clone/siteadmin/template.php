<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
TD {
	font-family: Tahoma, Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
	color: #666666;
	text-decoration: none;
}
-->
</style>
</head>

<body link="#000000" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<div align="left">
  <table width="900" border="0" cellpadding="4" cellspacing="0">
    <tr> 
      <td width="178" valign="top" bgcolor="#CCCCCC"><p><font size="2" face="Tahoma, Verdana, Arial, Helvetica, sans-serif"><strong><strong><a href="adminhome.php">home</a></strong><br>
          <br>
          <strong><a href="browsecats.php">categories<br>
          <br>
          </a><a href="members.php">members</a><br>
          <br>
          </strong></strong></font> <font size="2" face="Tahoma, Verdana, Arial, Helvetica, sans-serif"><strong><strong><a href="software.php">software<br>
          <br>
          </a></strong></strong> <strong> <a href="feedback.php">feedback</a><br>
          <br>
          <a href="mem_feedback.php">member feedback<br>
          </a><a href="featured_ads.php"><br>
          features ads</a><br>
          <br>
          <a href="sponsered.php">sponsors</a><a href="config.php"> <br>
          <br>
          config</a></strong></font></p>
        <p><font size="2" face="Tahoma, Verdana, Arial, Helvetica, sans-serif"><strong><a href="admin.php">change 
          password<br>
          </a> <a href="mailing_list.php"><br>
          mailing list</a><br>
          <br>
          <a href="email.php">email</a><br>
          <br>
          <a href="emailall.php">email all</a><a href="siteemails.php"><br>
          <br>
          config emails<br>
          </a><br>
          <a href="plans.php">banner plans<br>
          </a><br>
          <a href="ads.php">banner ads</a></strong> </font></p>
        <p><font size="2" face="Tahoma, Verdana, Arial, Helvetica, sans-serif"><strong><a href="link_ads.php">link 
          to us banners</a></strong><br>
          <strong><strong><a href="logout.php"><br>
          logout</a></strong></strong></font></p>
        <p><strong><font size="2" face="Tahoma, Verdana, Arial, Helvetica, sans-serif"><img src="spacer.gif" width="178" height="9"></font></strong></p></td>
      <td width="706" valign="top"><div align="center">
          <table width="671" border="0" cellspacing="0" cellpadding="4">
            <tr>
              <td><font size="2" face="Tahoma, Verdana, Arial, Helvetica, sans-serif"><strong><font color="#000000" size="3">Administration 
                Panel</font><br>
                </strong></font></td>
            </tr>
            <tr>
              <td>
                <? main();?>
              </td>
            </tr>
          </table>
        </div></td>
    </tr>
  </table>
</div>
<p>&nbsp;</p>
</body>
</html>
