<?
include("../include/config.php");
include("../include/class.ftp.php");
$n=array();
$n=$_REQUEST['dlt'];

if($_REQUEST['req']=="Delete Selected Entry")
{
 for($i=0;$i<count($n);$i++)
 {
  $fid=$n[$i];
  $sql="delete from fileinfo where dir='$fid'";
  $conn->execute($sql);
 }
}

if($_REQUEST['req']=="Delete Selected Files")
{
for($i=0;$i<count($n);$i++)
{
 $fid=$n[$i];
 $sql="select * from fileinfo where dir='$fid'";
 $rs=$conn->execute($sql);
 
 //----------------------------------------------------------------------------------------
        $id=$rs->fields['server'];
        $sql="select * from server where id='$id'";
        $res=$conn->execute($sql);
        $server=$res->fields;
        $ran=md5(microtime());
        //mkdir();exit;
        if(!file_exists($config['TEMP_DIR'])) {mkdir("TMP");chmod($config['TEMP_DIR'],777);}
        
        $tmpdir=$config['TEMP_DIR']."/".$ran;
        mkdir($tmpdir);
        $tmpdir.="/".$myfile[0];
        //mkdir("TMP/tmp_".$ran);exit;
        $dl_path=$server['updir']."/".$rs->fields['dir']."/".$rs->fields['file_name'];
        $myFTP=new ahm_FTP($server['name'],0,$server['uname'],$server['upass']);
        $myFTP->Connect();
        $myFTP->LogIn();
        $myFTP->Remove($dl_path);
        @ftp_rmdir($server['updir']."/".$myfile[2]);
        $myFTP->LogOut();

//----------------------------------------------------------------------------------------
 $stat=$rs->fields['status'];
 if($stat==0){
 $sql="update fileinfo set link_status=0 where dir='$fid'";
 $rs=$conn->execute($sql);
}
}
}
header("location: admin_index.php?change=FInfo");
?>
