<?php

$CFG['admin']['module']['login'] = true;
$CFG['admin']['module']['registration'] = true;
$CFG['admin']['module']['forums'] = true;
$CFG['admin']['module']['blog'] = true;
$CFG['admin']['module']['mail'] = true;
$CFG['admin']['module']['video'] = true;
$CFG['admin']['question']['video'] = true;
$CFG['admin']['answer']['video'] = true;
$CFG['admin']['module']['audio'] = true;
$CFG['admin']['question']['audio'] = true;
$CFG['admin']['answer']['audio'] = true;
?>