<?php
/**
 * Email templates settings Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 02/01/2008
 */
class EmailTemplates extends controller
{
		function EmailTemplates()
		{
				parent::controller();
				//check login
				if ($this->session->userdata('admin_logged_in') != 1 && $this->session->userdata('admin_id') == '') redirect('admin/login');
				//Load the language file
				$this->lang->load('admin/emailTemplates', $this->config->item('language_code'));
		}
		function index()
		{
				$this->load->library('validation');
				$this->load->model('emailtemplatemodel');
				$outputData['emailTemplates'] = $this->emailtemplatemodel->getEmailTemplate();
				$outputData['emailTemplates_list'] = true;
				$outputData['emailTemplates_edit'] = false;
				$this->smartyextended->view('../admin/emailtemplates', $outputData);
		}
		function editTemplate()
		{
				$this->load->model('emailtemplatemodel');
				$outputData['emailTemplates_list'] = false;
				$outputData['emailTemplates_edit'] = true;
				$template_id = $this->uri->segment(4);
				$this->load->library('validation');
				$this->_emailtemplatesFrm();
				if (!isset($_POST['email_template']))
				{
						$outputData['templates'] = $this->emailtemplatemodel->readEmailTemplate($template_id);
						if ($outputData['templates'] != false) $outputData['templatesArr'] = $outputData['templates'];
				}
				if (isset($_POST['cancel_template'])) redirect('admin/emailTemplates');
				if ($this->validation->run() == false) $outputData['validationError'] = $this->validation->error_string;
				else
				{
						if (isset($_POST['email_template']))
						{
								$this->emailtemplatemodel->updateEmailTemplate($_POST);
								//Set the flash data
								$this->session->set_flashdata('successMsg', $this->lang->line('emailtemplates_success_msg'));
								redirect('admin/emailTemplates/editTemplate/' . $_POST['template_key']);
						}
				}
				$this->smartyextended->view('../admin/emailtemplates', $outputData);
		}
		function _emailtemplatesFrm()
		{
				$rules['template_subject'] = 'trim|required|alphanumeric';
				$rules['template_content'] = 'trim|required|alphanumeric';
				$fields['template_subject'] = $this->lang->line('emailtemplates_mail_subject');
				$fields['template_content'] = $this->lang->line('emailtemplates_mail_content');
				$this->validation->set_rules($rules);
				$this->validation->set_fields($fields);
		}
}
?>