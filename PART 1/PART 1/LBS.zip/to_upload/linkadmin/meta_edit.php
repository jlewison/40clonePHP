<?php include('restrict.php'); include('../settings.php'); require_once('../Connections/apound.php'); ?>
<?php
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = (!get_magic_quotes_gpc()) ? addslashes($theValue) : $theValue;

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form1")) {
  $updateSQL = sprintf("UPDATE meta SET m_title=%s, m_keyword=%s, m_description=%s WHERE m_id=%s",
                       GetSQLValueString($_POST['m_title'], "text"),
                       GetSQLValueString($_POST['m_keyword'], "text"),
                       GetSQLValueString($_POST['m_description'], "text"),
                       GetSQLValueString($_POST['m_id'], "int"));

  mysql_select_db($database_apound, $apound);
  $Result1 = mysql_query($updateSQL, $apound) or die(mysql_error());

  $updateGoTo = "meta.php?upd=Y";
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $updateGoTo));
}
$m_id = $_GET[m_id];
mysql_select_db($database_apound, $apound);
$query_METE = "SELECT * FROM meta WHERE meta.m_id = '$m_id'";
$METE = mysql_query($query_METE, $apound) or die(mysql_error());
$row_METE = mysql_fetch_assoc($METE);
$totalRows_METE = mysql_num_rows($METE);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>Edit Meta Tags - Link Bid Script Admin Panel</title>
<link rel="shortcut icon" href="img/favicon.ico" />
<link rel="stylesheet" type="text/css" href="admin.css" />
<style type="text/css">
<!--
.style80 {padding-right:10px;}
.style85 {font-size: 12px}
#admnav li {
	padding-top: 0px;
	padding-bottom: 0px;
	margin-top: 0px;
	margin-bottom: 0px;
}
#admnav ul {
	padding-top: 0px;
	padding-bottom: 0px;
	margin-top: 0px;
	margin-bottom: 0px;
}
.style86 {
	color: #CC0000;
	text-decoration: none;
}
-->
</style>
</head>

<body>
<?php $x = getenv("HTTP_HOST").getenv("REQUEST_URI"); ?>
<?php include('header_tpl.php'); ?>
<h2>Edit Meta Tags</h2>
<form method="post" name="form1" action="<?php echo $editFormAction; ?>">
  <table align="center">
    <tr bgcolor="#FFFFCC">
      <td height="24" colspan="2" align="right" nowrap class="style80">Page: <?php $mpage = $_GET[page]; ?><?php echo("$mpage"); ?></td>
    </tr>
    <tr valign="baseline">
      <td colspan="2" align="right" nowrap>&nbsp;</td>
      </tr>
    <tr valign="baseline">
      <td nowrap align="right" valign="top"><span class="style67 style82">Meta Title : </span></td>
      <td><textarea name="m_title" cols="65" rows="3"><?php echo $row_METE['m_title']; ?></textarea>
      </td>
    </tr>
    <tr valign="baseline">
      <td nowrap align="right" valign="top"><span class="style67 style82">Meta Keyword: </span></td>
      <td><textarea name="m_keyword" cols="65" rows="5"><?php echo $row_METE['m_keyword']; ?></textarea>
      </td>
    </tr>
    <tr valign="baseline">
      <td nowrap align="right" valign="top"><span class="style67 style82">Meta Description: </span></td>
      <td><textarea name="m_description" cols="65" rows="5"><?php echo $row_METE['m_description']; ?></textarea>
      </td>
    </tr>
    <tr valign="baseline">
      <td nowrap align="right">&nbsp;</td>
      <td><input type="submit" class="login-but" value="Update record"></td>
    </tr>
  </table>
  <input type="hidden" name="MM_update" value="form1">
  <input type="hidden" name="m_id" value="<?php echo $row_METE['m_id']; ?>">
</form>

<?php include('footer_tpl.php'); ?>
</body>
</html>
<?php
mysql_free_result($METE);
?>
