<?php


//To test this class in standalone mode with test cases
//found at the end of this class...
if (!isset($CFG['debug']['debug_standalone_modules']))
		$CFG['debug']['debug_standalone_modules'] = true;;



class DB
	{
		const BEGIN_TRANSACTION = 1;	//Variable to store the BEGIN_TRANSACTION value
		const END_TRANSACTION = 2;		//Variable to store the END_TRANSACTION value

		private $db_connect_id;		//Variable to store the  Connection
		private $query_result;		//Variable to store Query Result
		private $row = array();		//Variable to store the fetched Records
		private $rowset = array();	//Variable to store the Records
		private $num_queries = 0; 	//Variable to store the Number of Queries
		private $queries_time_arr = array(); //To trace time taken for each queries
		private $in_transaction = 0;	//Variable to store the Transaction Result


		 /**
		  * DB::__construct()
		  *
		  * @param  string $sqlserver Name of the Server
		  * @param  string $sqluser Name of the User
		  * @param  string $sqlpassword Password for the given user
		  * @param  string $database Database name
		  * @param  boolean $persistency Is Persistent connection
		  * @return resource $db_connect_id on successful connection with the database or
		  * 			     False on failure
		  * @access public
	      */
	    public function __construct($sqlserver, $sqluser, $sqlpassword, $database, $persistency = true)
			{
				$this->persistency = $persistency;
				$this->user = $sqluser;
				$this->password = $sqlpassword;
				$this->server = $sqlserver;
				$this->dbname = $database;

				$this->db_connect_id = ($this->persistency) ? mysql_pconnect($this->server, $this->user, $this->password) : mysql_connect($this->server, $this->user, $this->password);
				if ( $this->db_connect_id )
					{
						if ( $database != '' )
							{
								$this->dbname = $database;
								$dbselect = mysql_select_db($this->dbname);
								if ( !$dbselect )
									{
										mysql_close($this->db_connect_id);
										$this->db_connect_id = $dbselect;
									}
							}
						return $this->db_connect_id;
					}
				  else
						return false;
			}


		/**
		 * DB::dbClose()
		 *
		 * @return boolean True on success or
		 * 			       False on failure
		 * @access public
		 */
		public function dbClose()
			{
				if ( $this->db_connect_id )
					{
						// Commit any remaining transactions
						if ( $this->in_transaction )
							mysql_query('COMMIT', $this->db_connect_id);
						return mysql_close($this->db_connect_id);
					}
					else
						return false;
			}


		/**
		 * DB::dbQuery()
		 *
		 * @param string $query Query
		 * @param boolean $transaction Is Transaction?
		 * @return resource Query result on successful execution of the query or
		 * 				    False on failure
		 * @access public
		 */
		public function dbQuery($query = '', $transaction = FALSE)
			{
				unset($this->query_result); // Remove any pre-existing queries
				if ( $query != '' )
					{
						$this->num_queries++;
						if ( $transaction == self::BEGIN_TRANSACTION && !$this->in_transaction )
							{
								$result = mysql_query('BEGIN', $this->db_connect_id);
								if (!$result)
										return false;
								$this->in_transaction = TRUE;
							}
						$query_time_start = explode(' ', microtime()); //track timings
						$this->query_result = mysql_query($query, $this->db_connect_id);
						$query_time_end = explode(' ', microtime());  //track query timings
						$query_time_total = number_format(($query_time_end[1] + $query_time_end[0] - ($query_time_start[1] + $query_time_start[0])), 5);
						$this->queries_time_arr[][$query] = $query_time_total; //save query timings
					}
				  else if ( $transaction == self::END_TRANSACTION && $this->in_transaction )
						$result = mysql_query('COMMIT', $this->db_connect_id);
				if ( $this->query_result )
					{
						unset($this->row[(int)$this->query_result]);
						unset($this->rowset[(int)$this->query_result]);
						if ( $transaction == self::END_TRANSACTION && $this->in_transaction )
							{
								$this->in_transaction = FALSE;
								if ( !mysql_query('COMMIT', $this->db_connect_id) )
									{
										mysql_query('ROLLBACK', $this->db_connect_id);
										return false;
									}
							}
						return $this->query_result;
					}
				  else if ( $this->in_transaction )
							{
								mysql_query('ROLLBACK', $this->db_connect_id);
								$this->in_transaction = FALSE;
							}
						return false;
			}


		/**
		 * DB::dbNumRows()
		 *
		 * @param Resource ID $query_id Id number for the query
		 * @return integer Number of rows on successful execution of the query or
		 * 				   False on failure
		 * @access public
		 */
		public function dbNumRows($query_id = 0)
			{
				if ( !$query_id )
					$query_id = $this->query_result;
				return ( $query_id ) ? mysql_num_rows($query_id) : false;
			}


		/**
		 * DB::dbAffectedRows()
		 *
		 * @return integer Number of updated Rows on Success or
		 *                 False on failure
		 * @access public
		 */
		public function dbAffectedRows()
			{
				return ( $this->db_connect_id ) ? mysql_affected_rows($this->db_connect_id) : false;
			}


		/**
		 * DB::dbNumFields()
		 *
		 * @param Resource ID $query_id Id of the query
		 * @return array Number of fields on Success or
		 * 				 False on failure
		 * @access public
		 */
		public function dbNumFields($query_id = 0)
			{
				if ( !$query_id )
					$query_id = $this->query_result;
				return ( $query_id ) ? mysql_num_fields($query_id) : false;
			}


		/**
		 * DB::dbFieldName()
		 *
		 * @param $offset Distance of the record from the starting
		 * @param Resource ID $query_id Id of the query
		 * @return string Field name on success or
		 * 				  False on failure
		 * @access public
		 */
		public function dbFieldName($offset, $query_id = 0)
			{
				if ( !$query_id )
					$query_id = $this->query_result;
				return ( $query_id ) ? mysql_field_name($query_id, $offset) : false;
			}


		/**
		 * DB::dbFieldType()
		 *
		 * @param $offset Distance of the record from the starting
		 * @param Resource ID $query_id Id of the query
		 * @return string Field Type on Success or
		 * 		          False on failure
		 * @access public
		 */
		public function dbFieldType($offset, $query_id = 0)
			{
				if ( !$query_id )
					$query_id = $this->query_result;
				return ( $query_id ) ? mysql_field_type($query_id, $offset) : false;
			}


		/**
		 * DB::dbFetchRow()
		 *
		 * @param Resource ID $query_id Id of the query
		 * @return array Fetched row records (associative array) on Success or
		 *               False on failure
		 * @access public
		 */
		public function dbFetchRow($query_id = 0)
			{
				if ( !$query_id )
					$query_id = $this->query_result;
				if ( $query_id )
					{
						$this->row[(int)$query_id] = mysql_fetch_array($query_id, MYSQL_ASSOC);
						return $this->row[(int)$query_id];
					}
				 else
					return false;
			}


		/**
		 * DB::dbFetchRowSet()
		 *
		 * @param Resource ID $query_id Id of the query
		 * @return array The Records on Success or
		 * 				 False on failure
		 * @access public
		 */
		public function dbFetchRowSet($query_id = 0)
			{
				if ( !$query_id )
					$query_id = $this->query_result;
				if ( $query_id )
					{
						unset($this->rowset[(int)$query_id]);
						unset($this->row[(int)$query_id]);
						while($this->rowset[(int)$query_id] = mysql_fetch_array($query_id, MYSQL_ASSOC))
							$result[] = $this->rowset[(int)$query_id];
						return $result;
					}
				 else
					return false;
			}


		/**
		 * DB::dbFetchField()
		 *
		 * @param string $field Name of the field
		 * @param integer $rownum Row number
		 * @param Resource ID $query_id Id of the query
		 * @return array The Records on Success or
		 * 				 False on failure
		 * @access public
		 */
		public function dbFetchField($field, $rownum = -1, $query_id = 0)
			{
				if ( !$query_id )
					$query_id = $this->query_result;
				if ( $query_id )
					{
						if ( $rownum > -1 )
							$result = mysql_result($query_id, $rownum, $field);
						else
							{
								if ( empty($this->row[(int)$query_id]) && empty($this->rowset[(int)$query_id]) )
									{
										if ( $this->sql_fetchrow() )
											$result = $this->row[(int)$query_id][$field];
									}
								 else
									{
										if ( $this->rowset[(int)$query_id] )
											$result = $this->rowset[(int)$query_id][$field];
										else if ( $this->row[(int)$query_id] )
											$result = $this->row[(int)$query_id][$field];
									}
							}
						return $result;
					}
				 else
					return false;
			}


		/**
		 * DB::dbRowSeek()
		 *
		 * @param $rownum Row number
		 * @param Resource ID $query_id Id of the query
		 * @return boolean True/False
		 * @access public
		 */
		public function dbRowSeek($rownum, $query_id = 0)
			{
				if ( !$query_id )
					$query_id = $this->query_result;
				return ( $query_id ) ? mysql_data_seek($query_id, $rownum) : false;
			}


		/**
		 * DB::dbNextId()
		 *
		 * @return integer Next (inserted) record id or
		 * 				   False on failure
		 * @access public
		 */
		public function dbNextId()
			{
				return ( $this->db_connect_id ) ? mysql_insert_id($this->db_connect_id) : false;
			}

		/**
		 * DB::dbFreeResult()
		 *
		 * @param Resource ID $query_id Id of the query
		 * @return boolean True on Success or
		 * 				   False on failure
		 * @access public
		 */
		public function dbFreeResult($query_id = 0)
			{
				if ( !$query_id )
					$query_id = $this->query_result;
				if ( $query_id )
					{
						unset($this->row[(int)$query_id]);
						unset($this->rowset[(int)$query_id]);
						mysql_free_result($query_id);
						return true;
					}
				 else
					return false;
			}

		/**
		 * DB::dbError()
		 *
		 * @return array $result Error with message and error code (integer).
		 * @access public
		 */
		public function dbError()
			{
				$result['message'] = mysql_error($this->db_connect_id);
				$result['code'] = mysql_errno($this->db_connect_id);
				return $result;
			}

		/**
		 * DB::getQueryTimings()
		 *
		 * @return array
		 */
		public function getQueryTimings()
			{
				return $this->queries_time_arr;
			}
	}


/****************************************/
/*----Test cases in standalone mode-----*/
/****************************************/
if ($CFG['debug']['debug_standalone_modules'])
	{
		//Connect the DB or throw errors...
		$db = new DB($CFG['db']['hostname'], $CFG['db']['username'], $CFG['db']['password'], $CFG['db']['name'], true);
		if (!$db)
				trigger_error('DB Connection Error', E_USER_ERROR);
	}
?>