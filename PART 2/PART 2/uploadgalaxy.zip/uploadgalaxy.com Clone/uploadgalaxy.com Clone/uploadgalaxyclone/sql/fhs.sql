# phpMyAdmin SQL Dump
# version 2.5.7
# http://www.phpmyadmin.net
#
# Host: localhost
# Generation Time: Mar 11, 2006 at 12:07 PM
# Server version: 4.0.20
# PHP Version: 5.0.1
# 
# Database : `fhs`
# 

# --------------------------------------------------------

#
# Table structure for table `abuse_reported_files`
#

CREATE TABLE `abuse_reported_files` (
  `id` int(11) NOT NULL auto_increment,
  `dir` text NOT NULL,
  `name` text NOT NULL,
  `sender` text,
  `reporter` text NOT NULL,
  `content` longtext NOT NULL,
  `mime_type` text NOT NULL,
  `size` int(11) NOT NULL default '0',
  `report` text NOT NULL,
  `entry` int(11) NOT NULL default '0',
  `timeout` int(11) NOT NULL default '0',
  `status` int(11) NOT NULL default '0',
  `server` text NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=9 ;

#
# Dumping data for table `abuse_reported_files`
#


# --------------------------------------------------------

#
# Table structure for table `admin`
#

CREATE TABLE `admin` (
  `uid` int(11) NOT NULL auto_increment,
  `uname` varchar(15) NOT NULL default '',
  `pwd` varchar(15) NOT NULL default '',
  `email` varchar(50) NOT NULL default '',
  PRIMARY KEY  (`uid`),
  UNIQUE KEY `uname` (`uname`)
) TYPE=MyISAM AUTO_INCREMENT=3 ;

#
# Dumping data for table `admin`
#

INSERT INTO `admin` VALUES (1, 'admin', 'admin', 'admin@sendmail.com');
INSERT INTO `admin` VALUES (2, 'shaon', '1', 'shaon@yahoo.com');

# --------------------------------------------------------

#
# Table structure for table `adminlog`
#

CREATE TABLE `adminlog` (
  `uid` int(11) NOT NULL default '0',
  `timein` int(11) NOT NULL default '0',
  `timeout` int(11) default NULL,
  `ip` varchar(16) default NULL
) TYPE=MyISAM;

#
# Dumping data for table `adminlog`
#


# --------------------------------------------------------

#
# Table structure for table `configuration`
#

CREATE TABLE `configuration` (
  `conf_id` int(11) NOT NULL auto_increment,
  `conf_name` varchar(20) NOT NULL default '',
  `conf_value` text,
  `conf_optional` varchar(250) default NULL,
  PRIMARY KEY  (`conf_id`)
) TYPE=MyISAM AUTO_INCREMENT=17 ;

#
# Dumping data for table `configuration`
#

INSERT INTO `configuration` VALUES (1, 'MAX_SIZE', '1024', '1 MB');
INSERT INTO `configuration` VALUES (2, 'MIME_TYPES', '', '');
INSERT INTO `configuration` VALUES (3, 'MAX_COUNT', '50', 'a limited number of');
INSERT INTO `configuration` VALUES (4, 'MAX_TIME', '7', '7 Days');
INSERT INTO `configuration` VALUES (5, 'AUTO_FILE_DELETE', 'Yes', '');
INSERT INTO `configuration` VALUES (6, 'DAILY_TRANSFER', '959618', '11-03-2006');
INSERT INTO `configuration` VALUES (16, 'TIME_OUT_ABUSE', '', '60 days');
INSERT INTO `configuration` VALUES (7, 'PRE_MAX_SIZE', '102400', '100 MB');
INSERT INTO `configuration` VALUES (8, 'MAX_DL', '102400', '100 MB');
INSERT INTO `configuration` VALUES (9, 'PAY_TO', 'grizzly@technologybasement.com', 'PayPal Account');
INSERT INTO `configuration` VALUES (10, 'FRE_BW', '1024', '1KB');
INSERT INTO `configuration` VALUES (11, 'PRE_BW', '10240', '10 KB');
INSERT INTO `configuration` VALUES (12, 'LIMIT_SPEED', 'Yes', 'Enable or Disable Download speed limiting');
INSERT INTO `configuration` VALUES (13, 'RET_PATH', '', NULL);
INSERT INTO `configuration` VALUES (14, 'UP_DIR', '../uploads', 'Location of upload directory');
INSERT INTO `configuration` VALUES (15, 'ADMIN_MAIL', 'admin@uploadgalaxy.com', NULL);

# --------------------------------------------------------

#
# Table structure for table `fileinfo`
#

CREATE TABLE `fileinfo` (
  `id` int(11) NOT NULL auto_increment,
  `idkey` varchar(30) NOT NULL default '',
  `dir` varchar(30) NOT NULL default '',
  `mime_type` varchar(50) default NULL,
  `file_name` varchar(200) NOT NULL default '',
  `size` bigint(20) NOT NULL default '0',
  `upload_time` int(11) default '0',
  `no_of_dwnld` int(11) default '0',
  `expire_time` int(11) default '0',
  `max_dwnld` int(11) default '0',
  `link_status` tinyint(4) default '1',
  `recipient` varchar(50) NOT NULL default '',
  `sender` varchar(50) default NULL,
  `server` text NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `dir` (`dir`),
  UNIQUE KEY `idkey` (`idkey`)
) TYPE=MyISAM AUTO_INCREMENT=8 ;

#
# Dumping data for table `fileinfo`
#

INSERT INTO `fileinfo` VALUES (3, 'UXpELWHHN6bqWe1JX1Na', 'u5Dtbk1jdR6ao1Q7kowr', 'image/pjpeg', 'bg.jpg', 1905, 1142103011, 1, 1142707811, 50, 0, 'shaon@yahoo.com', '', '5');
INSERT INTO `fileinfo` VALUES (4, 'nboiOcwMexoNoUbXbrP1', 'qUhjsQmZyknM2B9k84ew', 'application/x-zip-compressed', 'getpaid.zip', 222622, 1142103083, 0, 1142707883, 50, 1, 'shaon@yahoo.com', '', '4');
INSERT INTO `fileinfo` VALUES (5, 'RN9S8uvEAHBb6rfTbRQR', 'j2izbwz6XonIg1oHLAu1', 'text/plain', 'mysite.txt', 4824, 1142103138, 3, 1142707938, 50, 1, 'shaon@yahoo.com', '', '5');
INSERT INTO `fileinfo` VALUES (6, '3BZ10RyXhgoK0vmkFwpA', 'mviQlz2RIpJYoOBbQtEV', 'application/x-zip-compressed', 'getpaid2.zip', 244739, 1142103735, 1, 1142708535, 50, 1, 'proshaon@yahoo.com', 'proshaon@yahoo.com', '7');
INSERT INTO `fileinfo` VALUES (7, 'KWMK8n5vbLvLbkFkr5i5', '8co9dVb1DNlLA31BFkV9', 'text/plain', 'scrollbar.htm', 2857, 1142104237, 0, 1142709037, 50, 0, 'shaon@yahoo.com', 'aaaaa@aaaaa.aaa', '5');

# --------------------------------------------------------

#
# Table structure for table `premium_package`
#

CREATE TABLE `premium_package` (
  `pid` int(11) NOT NULL auto_increment,
  `pacname` varchar(15) NOT NULL default '',
  `pactime` int(11) NOT NULL default '0',
  `pacrate` int(11) default NULL,
  PRIMARY KEY  (`pid`),
  UNIQUE KEY `pactime` (`pactime`),
  UNIQUE KEY `pacname` (`pacname`)
) TYPE=MyISAM AUTO_INCREMENT=6 ;

#
# Dumping data for table `premium_package`
#

INSERT INTO `premium_package` VALUES (1, 'Golden', 0, 99);
INSERT INTO `premium_package` VALUES (2, 'Silver', 365, 65);
INSERT INTO `premium_package` VALUES (3, 'Instant', 7, 15);
INSERT INTO `premium_package` VALUES (5, 'Today', 1, 2);

# --------------------------------------------------------

#
# Table structure for table `premium_user`
#

CREATE TABLE `premium_user` (
  `uid` int(11) NOT NULL auto_increment,
  `uname` varchar(15) NOT NULL default '',
  `fname` varchar(15) NOT NULL default '',
  `lname` varchar(15) NOT NULL default '',
  `adrs1` varchar(80) NOT NULL default '',
  `adrs2` varchar(80) default NULL,
  `city` varchar(15) NOT NULL default '',
  `country` varchar(15) NOT NULL default '',
  `email` varchar(30) NOT NULL default '',
  `paypal` varchar(30) NOT NULL default '',
  `pass` varchar(15) NOT NULL default '',
  `website` varchar(30) default NULL,
  `pac_time` int(11) NOT NULL default '-1',
  `buy_time` int(11) NOT NULL default '-1',
  PRIMARY KEY  (`uid`),
  UNIQUE KEY `uname` (`uname`)
) TYPE=MyISAM AUTO_INCREMENT=3 ;

#
# Dumping data for table `premium_user`
#

INSERT INTO `premium_user` VALUES (1, 'asdfgh', 'hfgh', 'hfgh', 'hfghfghfgh', 'hfghfhfgh', 'fgdfg', 'gfdgd', 'proshaon@yahoo.com', 'gdgdfg', '1234', 'sfsdfsf', -1, 11313344);
INSERT INTO `premium_user` VALUES (2, 'aaaaa', 'aaaaa', 'aaaaa', 'aaaaa', '', 'aaaaa', 'aaaaa', 'aaaaa@aaaaa.aaa', 'aaaaa@aaaaa.aaa', 'aaaaa', 'aaa.aaaaa.aaa', 7, 5232542);

# --------------------------------------------------------

#
# Table structure for table `server`
#

CREATE TABLE `server` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(40) NOT NULL default '',
  `size` int(20) NOT NULL default '0',
  `used` int(11) NOT NULL default '0',
  `priority` int(11) NOT NULL default '0',
  `uname` text NOT NULL,
  `upass` text NOT NULL,
  `updir` text NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `priority` (`priority`)
) TYPE=MyISAM AUTO_INCREMENT=8 ;

#
# Dumping data for table `server`
#

INSERT INTO `server` VALUES (7, 'localhost', 200, 248615, 3, 'root', 'triadpass', 'uploads');
INSERT INTO `server` VALUES (2, 'localhost', 200, 222622, 1, 'root', 'triadpass', 'upload2');
INSERT INTO `server` VALUES (5, 'localhost', 209715200, 9586, 4, 'root', 'triadpass', 'upload3');
INSERT INTO `server` VALUES (4, 'localhost', 209715200, 222622, 2, 'root', 'triadpass', 'upload4');
