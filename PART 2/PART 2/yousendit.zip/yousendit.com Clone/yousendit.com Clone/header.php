<table width="795" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
          <td width="794"><p align="center"><img src="images/yourlogo.jpg" width="493" height="125"></p>
    </td>
          <td width="1" valign="top">&nbsp;</td>
  </tr>
        <tr> 
          <td height="20" colspan="2"><div align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="index.php">Upload</a>          |<a href="aboutus.php">About
                  Us</a> | <a href="privacy.php">Privacy
                  policy</a> | <a href="terms.php">Terms of service</a> | <a href="mailto:admin@popscript.com">Contact</a> </font></div></td>
        </tr>
      </table>
