<?php
require_once ('../common/config.inc.php');
$CFG['lang']['include_files'][] = 'common/email_templates/languages/%s/email_notify.inc.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['auth']['is_authenticate'] = false;
$CFG['html']['is_use_footer'] = false;
$CFG['mods']['is_include_only']['non_html_header_files'] = true;
$CFG['mods']['include_files'][] = 'common/classes/phpmailer/class_PHPMailer.lib.php';
ini_set('max_execution_time', 0);
require ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class QuestionReminderFormHandler extends FormHandler
{
		public function getCronMasterDetails($table_name, $cron_for)
		{
				$sql = 'SELECT upto_id FROM ' . $table_name . ' WHERE cron_for = ' . $this->dbObj->Param($cron_for) . ' AND status = \'Started\' limit 0,1';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($cron_for));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount())
				{
						$row = $rs->FetchRow();
						return $row;
				}
				return false;
		}
		public function updateCronMaster($table_name, $cron_for, $status, $new_old, $upto = 0, $total = 0)
		{
				$val_arr = array();
				$val_arr[] = $status;
				$sql = 'UPDATE ' . $table_name . ' SET ' . 'status=' . $this->dbObj->Param($status);
				$sql .= ', upto_id = ' . $this->dbObj->Param($upto);
				$val_arr[] = $upto;
				if ($total == 0) $sql .= ', total = ' . $this->dbObj->Param($total);
				else  $sql .= ', total = total + ' . $this->dbObj->Param($total);
				$val_arr[] = $total;
				if ($new_old == 'new')
				{
						$sql .= ', start_time = ' . $this->dbObj->SQLDate('Y-m-d H:i:s');
						$sql .= ', tot_finished_crons = tot_finished_crons + 1';
				}
				$sql .= ' WHERE cron_for = ' . $this->dbObj->Param($cron_for);
				$val_arr[] = $cron_for;
				$stmt = $this->dbObj->Prepare($sql);
				$result = $this->dbObj->Execute($stmt, $val_arr);
				if (!$result) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function emailQuestionDetails($upto_id, $check_count)
		{
				$sql = 'SELECT ques_id, total_answer, total_stars, question, tags, TIMEDIFF(NOW(), date_asked) as date_asked, q.user_id' . ', ' . $this->getUserTableField('name') . ' as asked_by, q.status' . ' FROM ' . $this->CFG['db']['tbl']['questions'] . ' AS q, ' . $this->CFG['db']['tbl']['users'] . ' AS u' . ' WHERE q.status = \'Open\' AND q.email_sent=\'No\' AND q.user_id=u.' . $this->getUserTableField('user_id') . ' AND u.' . $this->getUserTableField('usr_status') . '=\'Ok\'' . ' ORDER BY ques_id ASC limit 0, 1';
				$stmt = $this->dbObj->Prepare($sql);
				$rsques = $this->dbObj->Execute($stmt);
				if (!$rsques) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$rowques = $rsques->FetchRow();
				if ($rowques['tags'])
				{
						$sql = 'SELECT user_id FROM ' . $this->CFG['db']['tbl']['users_ans_log'] . ' WHERE  user_id > ' . $this->dbObj->Param($upto_id) . ' AND ' . getSearchRegularExpressionQuery($rowques['tags'], 'subscribe_keywords') . ' ORDER BY user_id ASC limit 0, ' . $this->dbObj->Param($check_count);
						$stmt = $this->dbObj->Prepare($sql);
						$rsuserslog = $this->dbObj->Execute($stmt, array($upto_id, $check_count));
						if ($count = $rsuserslog->PO_RecordCount())
						{
								while ($rowuser = $rsuserslog->FetchRow())
								{
										$ret_arr = array('user_id' => $rowuser['user_id'], 'count' => $count);
										$asker_details = $this->getUserDetailsFromUsersTable($this->CFG['db']['tbl']['users'], $rowques['user_id']);
										$admin_id = $this->getAdminUserId($this->CFG['db']['tbl']['users']);
										$email_options = $this->getEmailOptionsOfUser($rowuser['user_id']);
										$send_email = false;
										if ($email_options['keyword_mail'] == 'Yes')
										{
												$reminder_subject = $this->LANG['question_added_email_subject'];
												$reminder_content = $this->LANG['question_added_email_content'];
												$send_email = true;
										}
										if (!$send_email) continue;
										$receiver_details = $this->getUserDetailsFromUsersTable($this->CFG['db']['tbl']['users'], $rowuser['user_id']);
										$reminder_subject = str_replace('{username}', $receiver_details['name'], $reminder_subject);
										$reminder_content = str_replace('{username}', $receiver_details['name'], $reminder_content);
										$asker_url = getUrl($this->CFG['site']['url'] . 'myanswers.php?uid=' . $rowques['user_id'], $this->CFG['site']['url'] . 'my/answers/' . $rowques['user_id'], false);
										$asker_name = '<a href="' . $asker_url . '/">' . $asker_details['name'] . '</a>';
										$reminder_content = str_replace('{asked by}', $asker_name, $reminder_content);
										$reminder_content = str_replace('{sitename}', $this->CFG['site']['name'], $reminder_content);
										$reminder_content = str_replace('{question asked}', '<strong>' . $rowques['question'] . '</strong>', $reminder_content);
										$question_link = getUrl($this->CFG['site']['url'] . 'answers.php?qid=' . $rowques['ques_id'], $this->CFG['site']['url'] . 'view/answers/' . $rowques['ques_id'] . '/', false);
										$reminder_content = str_replace('{link}', '<a href="' . $question_link . '">' . $question_link . '</a>', $reminder_content);
										$this->_sendMail($receiver_details['email'], $reminder_subject, nl2br($reminder_content), $this->CFG['site']['noreply_name'], $this->CFG['site']['noreply_email']);
								}
								return $ret_arr;
						}
				}
				$this->updateQuestionTableEmailSentStatus($rowques['ques_id']);
				return false;
		}
		private function _sendMail($to_email, $subject, $body, $sender_name, $sender_email)
		{
				$mail = new PHPMailer();
				$mail->AddAddress($to_email);
				$mail->FromName = $sender_name;
				$mail->From = $mail->Sender = $sender_email;
				$mail->Subject = $subject;
				$mail->Body = $body;
				$mail->IsMail();
				$mail->IsHTML(true);
				return ($mail->Send());
		}
		public function updateQuestionTableEmailSentStatus($qid)
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['questions'] . ' SET email_sent=\'Yes\'' . ' WHERE ques_id=' . $this->dbObj->Param('qid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($qid));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function isFavoriteQuestion($uid, $qid)
		{
				$sql = 'SELECT bookmark_id as fav_id FROM ' . $this->CFG['db']['tbl']['user_bookmarked'] . ' WHERE content_id = ' . $this->dbObj->Param('qid') . ' AND user_id = ' . $this->dbObj->Param('uid') . ' AND content_type = \'Question\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($qid, $uid));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$ok = false;
				if ($rs->PO_RecordCount()) $ok = true;
				return $ok;
		}
		public function getAdminUserId($user_table)
		{
				$sql = 'SELECT ' . $this->getUserTableField('user_id') . ' AS user_id FROM ' . $user_table . ' WHERE ' . $this->getUserTableField('user_access') . ' = \'Admin\' LIMIT 1';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = array('user_id' => 1);
				if ($rs->PO_RecordCount())
				{
						$row = $rs->FetchRow();
				}
				return $row['user_id'];
		}
}
$reminder = new QuestionReminderFormHandler();
$reminder->setDBObject($db);
$reminder->setCfgLangGlobal($CFG, $LANG);
$reminder->member_url = $CFG['site']['url'] . $CFG['redirect']['member'] . '/';
if ($cron_arr = $reminder->getCronMasterDetails($CFG['db']['tbl']['cron_master'], 'Question'))
{
		if ($autoindex_arr = $reminder->emailQuestionDetails($cron_arr['upto_id'], $CFG['question']['send_count'])) $reminder->updateCronMaster($CFG['db']['tbl']['cron_master'], 'Question', 'Started', 'old', $autoindex_arr['user_id'], $autoindex_arr['count']);
		else  $reminder->updateCronMaster($CFG['db']['tbl']['cron_master'], 'Question', 'Started', 'new');
}
else  $reminder->updateCronMaster($CFG['db']['tbl']['cron_master'], 'Question', 'Started', 'new');
require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>
