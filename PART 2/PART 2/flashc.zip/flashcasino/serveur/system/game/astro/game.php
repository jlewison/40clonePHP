<?
error_reporting(0);
unset($l); 
session_start();
session_register($l);
if(!isset($l)){ 
header("Location: ../../login.php"); 
exit; 
}

include ("../../../setup.php");


if ($cash < 0){$cash=0;}
if ($bet=="" && $bet<>0.2 && $bet<>1 && $bet<>5 && $bet<>10 && $bet<>50){ $bet="0.20";}



$result=mysql_query("select * from users where login='$l'");
$row=mysql_fetch_array($result);



$resultk=mysql_query("select * from jackpot where name='ttuz'");
$rowk=mysql_fetch_array($resultk);

if ($mon==0 or $mon==""){
echo "&sp=1";
echo "&login=$l";













echo "&cash=$row[3]&jackpot=$rowk[1]";/////////////////////////////////////////////








}





if ($mon==1 && $row[3]>=$bet){
$win=0;





$beta = $bet/10;

mysql_query("update users set cash=cash-'$bet' where login='$l'");


if ( $l != "demo" ) {


mysql_query("update game_bank set bank=bank+'$bet' where name='ttuz'");

}




if ( $l != "demo" ) {

mysql_query("update jackpot set astro=astro+'$beta' where name='ttuz'");

}







 srand ((double) microtime()*1000000);
$sim1=rand(2,7);
$sim2=rand(2,7);
$sim3=rand(2,7);
srand ((double) microtime()*1000000);
$sim11=rand(0,10);
$sim12=rand(0,10);
$sim13=rand(0,10);
if ($sim11==5){ $sim1=1; }
if ($sim12==5){ $sim2=1; }
if ($sim13==5){ $sim3=1; }




if ($sim1==7 && $sim2==7 && $sim3==7 && $rowk[14]=="yes" )




{ 



$win=$rowk[1];


mysql_query("update jackpot set astro='1000' where name='ttuz'");



 }
















if ($sim1==2 && $sim2==2 && $sim3==2){ $win=$bet*150; }
if ($sim1==3 && $sim2==3 && $sim3==3){ $win=$bet*100; }
if ($sim1==4 && $sim2==4 && $sim3==4){ $win=$bet*50; }
if ($sim1==5 && $sim2==5 && $sim3==5){ $win=$bet*25; }
if ($sim1==6 && $sim2==6 && $sim3==6){ $win=50; }
if ($sim1==1 or $sim3==1){ $win=$bet*2; }
if ($sim1==1 && $sim2==1 || $sim2==1 && $sim3==1){ $win=$bet*5; }



$resultb=mysql_query("select * from game_bank where name='ttuz'");

$resultk=mysql_query("select * from jackpot where name='ttuz'");

$rowb=mysql_fetch_array($resultb);
$rowk=mysql_fetch_array($resultk);
$jackpot = $rowk[1];
$bank = $rowb[1];
$proc = $rowb[2];
$caswin = $bank/100*$proc;
if ($win>=$caswin) { 
$win=0;
srand ((double) microtime()*1000000);
$sim1=rand(6,7);
$sim2=rand(2,5);
$sim3=rand(2,7);
}
////////////////

if ($win>0){
mysql_query("update users set cash=cash+'$win' where login='$l'");

if ( $l != "demo" ) {


mysql_query("update game_bank set bank=bank-'$win' where name='ttuz'");

}


}




$date=date("d.m.y");
$time=date("H:i:s");
$sqls="INSERT INTO stat_game VALUES('NULL','$date','$time','$l','$row[3]','$bet','$win','astro')";
mysql_query($sqls);

for ($i = 1; $i<=300000; $i++)
{
$marat=$marat+10;
}



$result=mysql_query("select * from users where login='$l'");
$row=mysql_fetch_array($result);


echo "&login=$l";
echo "&cash=$row[3]";
echo "&sim1=$sim1";
echo "&sim2=$sim2";
echo "&sim3=$sim3";
echo "&win=$win";
echo "&bet=$bet";
echo "&spins=1";
echo "&sp=1";
echo "&jackpot=$rowk[1]";

}



?>