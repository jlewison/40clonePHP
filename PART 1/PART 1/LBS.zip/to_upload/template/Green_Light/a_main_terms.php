<?php include('template/Green_Light/b_inside_top.php');?>

<td valign="top">

<div class="page-header"><h1><?php echo("$lang_126");?></h1></div>
<div class="box" style="margin-left:10px">
	<div class="box-cap-left">
		<div class="box-cap-right">
			<div class="box-cap"></div>
		</div>
	</div>
	<div class="box-left">
		<div class="box-right"><?php echo("$termsdetails");?></div>
	</div>
	<div class="box-bottom-left">
		<div class="box-bottom-right">
		</div>
	</div>
</div>	

</div>

<?php include('template/Green_Light/b_footer_tpl.php'); ?>