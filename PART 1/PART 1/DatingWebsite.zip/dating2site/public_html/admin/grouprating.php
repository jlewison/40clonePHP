<?php
if ( !defined( 'SMARTY_DIR' ) ) {
	include_once( '../init.php' );
}
include ( 'sessioninc.php' );

define( 'PAGE_ID', 'profile_ratings' );

if ( !checkAdminPermission( PAGE_ID ) ) {

	header( 'location: not_authorize.php' );
	exit;
}

$arr = $_POST[ 'txtcheck' ];

if ( count( $arr ) == 0 ) {

	header( 'location: manageratings.php?msg=' . urlencode(get_lang('no_select_msg')) );
	exit;
}

$sql = 'UPDATE ! SET enabled = ? WHERE id = ?';

if ( $_POST['groupaction'] == get_lang('enable_selected') ) {

	foreach ( $arr as $id ) {

		$result = $db->query( $sql, array( RATINGS_TABLE, 'Y', $id) );
	}
	header ( 'location: manageratings.php' );
	exit;

} elseif ($_POST['groupaction'] == get_lang('disable_selected') ) {

	foreach ( $arr as $id ) {

		$result = $db->query( $sql, array( RATINGS_TABLE, 'N', $id) );
	}
	header ( 'location: manageratings.php' );
	exit;

}

// Editing rating
foreach ( $arr as $ratingid ) {

	$sqledit = 'SELECT id, rating, enabled from ! Where id = ?';

	$row = $db->getRow( $sqledit, array( RATINGS_TABLE, $ratingid) );

	$data[] = $row;

}

$t->assign( 'lang', $lang );

$t->assign( 'error', get_lang('admin_error_msgs', $_GET['errid'] ) );

$t->assign( 'data', $data );

if ( $_POST['groupaction'] == get_lang('change_selected') ) {

	$t->assign('rendered_page', $t->fetch('admin/groupratingedit.tpl' ));

} elseif ($_POST['groupaction'] == get_lang('delete_selected') ) {

	$t->assign('rendered_page', $t->fetch('admin/groupratingdel.tpl' ));

}

$t->display('admin/index.tpl');

?>