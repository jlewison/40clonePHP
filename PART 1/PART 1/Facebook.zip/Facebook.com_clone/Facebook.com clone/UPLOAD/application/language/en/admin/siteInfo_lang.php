<?php
$lang['siteinfo_title'] 			= 'Site Information';
$lang['siteinfo_total_members'] 	= 'Total Members';
$lang['siteinfo_total_groups'] 		= 'Total Groups';
$lang['siteinfo_total_events'] 		= 'Total Events';
$lang['siteinfo_total_albums'] 		= 'Total Albums';
?>