<?php //00461
// Copyright Notice
// Web Site URL:  http://www.zeeways.com
// Script Owner eMail: mail@zeeways.com
// Date: April, 2007
// Script Name: Zeeways Auction Website PHP Script
// Copyright Details: This script is not free.  Do not Remove this Copy Right notice.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the site administrator.');exit(199);
?>
4+oV5Bgxjj/aaWiGvG0Z/3efJ+bbJ4cCGg50X9+iCLXxoPE5rnzegLZCZZEQCTpqMZYu2AFz/kCR
sAfzp7Yp6aBTJjZjWUTIASOAjtPDLMDA6S71RxneMBblItf8e4iTX6aRJx/qD8DGHqbt2+VUtXg9
gl6Y/FZrxEehjNTEaRD2Cr4uoGEBCiMro1Mkt8Ubsz8V98nc9+g47pcboMegcHF4yzl/xduGPO/9
Zo8NzgBfSapXsvDCLoStbgOq34npzoskINwscd0HW/baJNELaiM57xH1wMo6+lfZPhK+NUodHdIr
1BlZhATbHRaS9K1ZLb6A7Crc5QPMEZ8flhxMUPBZ813TYm2EkyGRciTYdF2cYEfemyM71DoVf1OX
aRJz9okuUIVM/WhNJmt118uBSafaw4GfDPxTivKOkhr+XPu5fuCj0sYQdaFCrj2gIOMAvIFQxk+t
lGKPASyb6u3kGwZPx1r39pXBCMlGg4jWXbXHN6kkMXCjSBGrkQoGnoaNphYRcQLPS3sOh5saqOfC
P19ldGBo6F2+2RELMdJOo5tZv0sHeWpyGajCgTp4+uDLNY/xgfKDFzpRBOvt+7dz2CFls+2XXFkM
dyumz8MkdZBMRo8jgIwe0GKmmq9kCLnc3IR/javIp+R9IhrWs05d+WOZRziRPf9XQhKNaPMQ5jDT
/N1cWPxWekdw/0eE0o2vv/+RDXJ60kEoB4/kbeGIIiZhKJyGYE3SyC4rPQd0AqfrKBtvkPwp/C+q
VuHgEMki1GVh5RsJZhCcSACXrCHB799eUU7KcuDu6yxTLYi2OfGNRnHkTDmEhoeVg/C26dXKI7+N
nNgLgGfMYr2DAjkC5wacFimXquoks3cIFjH7+g9Qe1EIXkKMPAjQj7hOHHoyjrYDOhdnElMqehxK
yfCrPpVRMxNgifZIhbl7bZbUGfrqOnRi5lnbV4BCuwyzwLI3NG+eD83cZRH/buC+IWPjTeS+LHAH
QpSJxLgWKHY3Zsp9WmUQS2gi3GngL0==