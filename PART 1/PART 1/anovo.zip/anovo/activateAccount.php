<?php
require_once ('./common/config.inc.php');
$CFG['lang']['include_files'][] = 'includes/languages/%s/activateAccount.php';
$CFG['lang']['include_files'][] = 'common/email_templates/languages/%s/email_notify.inc.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['lang']['include_files'][] = 'common/languages/%s/help.inc.php';
$CFG['html']['header'] = 'members/includes/languages/' . $CFG['lang']['default'] . '/html_header.php';
$CFG['html']['footer'] = 'members/includes/languages/' . $CFG['lang']['default'] . '/html_footer.php';
if ($_POST) $CFG['mods']['include_files'][] = 'common/classes/phpmailer/class_PHPMailer.lib.php';
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class verifyMailHandler extends FormHandler
{
		public function isNotVerified($table_name, $field_name, $password, $verified_err_tip = '', $invalid_err_tip = '', $locked_err_tip = '')
		{
				$sql = 'SELECT user_id, email, name, usr_status FROM ' . $table_name . ' WHERE substring(md5(user_id), 1, 8) = ' . $this->dbObj->Param('field_name') . ' AND password = ' . $this->dbObj->Param('password') . ' AND usr_status!=\'Deleted\' LIMIT 0,1';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr[$field_name], md5($this->fields_arr[$password])));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($row = $rs->FetchRow())
				{
						$this->fields_arr['name'] = $row['name'];
						$this->fields_arr['user_id'] = $row['user_id'];
						$this->fields_arr['email'] = $row['email'];
						if ($row['usr_status'] == 'ToActivate')
						{
								$this->setIndirectFormField('user_id', $row['user_id']);
								return true;
						}
						else
								if ($row['usr_status'] == 'Ok')
								{
										$this->setCommonErrorMsg($verified_err_tip);
										return false;
								}
								else
										if ($row['usr_status'] == 'Locked')
										{
												$this->setCommonErrorMsg($locked_err_tip);
												return false;
										}
										else
										{
										}
				}
				else
				{
						$this->setCommonErrorMsg($invalid_err_tip);
						return false;
				}
		}
		public function updateIsVerifiedInUserMailsTable($table_name, $user_id, $err_tip = '')
		{
				$sql = 'UPDATE ' . $table_name . ' SET usr_status = \'Ok\'' . ' WHERE user_id = ' . $this->dbObj->Param('user_id');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($user_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				return true;
		}
		public function chkIsValidCode()
		{
				$sql = 'SELECT user_id, name, usr_status, password, email FROM ' . $this->CFG['db']['tbl']['users'] . ' WHERE substring(md5(user_id), 1, 8) = ' . $this->dbObj->Param('field_name') . ' AND usr_status!=\'Deleted\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['code']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($row = $rs->FetchRow())
				{
						$this->fields_arr['name'] = $row['name'];
						$this->fields_arr['user_id'] = $row['user_id'];
						$this->fields_arr['email'] = $row['email'];
						if ($row['usr_status'] == 'ToActivate')
						{
								$this->setIndirectFormField('user_id', $row['user_id']);
								return true;
						}
						else
								if ($row['usr_status'] == 'Ok')
								{
										$this->setCommonErrorMsg($this->LANG['err_tip_verified']);
										return false;
								}
								else
										if ($row['usr_status'] == 'Locked')
										{
												$this->setCommonErrorMsg($this->LANG['err_tip_locked']);
												return false;
										}
				}
				else
				{
						$this->setCommonErrorMsg($this->LANG['err_tip_invalid_link']);
						return false;
				}
		}
		public function sendActivationCode($field_email, $activation_subj, $activation_msg, $sender_name, $sender_email)
		{
				$is_ok = $this->_sendMail($this->fields_arr[$field_email], $activation_subj, $activation_msg, $sender_name, $sender_email);
				return $is_ok;
		}
		private function _sendMail($to_email, $subject, $body, $sender_name, $sender_email)
		{
				$mail = new PHPMailer();
				$mail->AddAddress($to_email);
				$mail->FromName = $sender_name;
				$mail->From = $mail->Sender = $sender_email;
				$mail->Subject = $subject;
				$mail->Body = $body;
				$mail->IsMail();
				$mail->IsHTML(true);
				return ($mail->Send());
		}
		public function updateUserLog($table_name, $ip, $session_id)
		{
				$sql = 'UPDATE ' . $table_name . ' SET ' . $this->getUserTableField('last_logged') . '=NOW(), ' . $this->getUserTableField('num_visits') . '=' . $this->getUserTableField('num_visits') . '+1, ' . $this->getUserTableField('ip') . '=\'' . $ip . '\', ' . $this->getUserTableField('session') . '=\'' . $session_id . '\'' . ' WHERE ' . $this->getUserTableField('user_id') . '=' . $this->dbObj->Param('user_id');
				$stmt = $this->dbObj->Prepare($sql);
				$result = $this->dbObj->Execute($stmt, array($this->user_details_arr['user_id']));
				if (!$result) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function saveUserVarsInSession($ip)
		{
				$_SESSION = array();
				$_SESSION['user']['user_id'] = $this->user_details_arr['user_id'];
				$_SESSION['user']['name'] = $this->user_details_arr['name'];
				$_SESSION['user']['time_zone'] = $this->user_details_arr['time_zone'];
				$_SESSION['user']['pref_lang'] = $this->user_details_arr['pref_lang'];
				$_SESSION['user']['last_logged'] = $this->user_details_arr['last_logged'];
				$_SESSION['user']['num_visits'] = $this->user_details_arr['num_visits'];
				$_SESSION['user']['email'] = $this->user_details_arr['email'];
				$_SESSION['user']['is_logged_in'] = true;
				$_SESSION['user']['is_admin'] = false;
				$_SESSION['user']['useragent_hash'] = md5($_SERVER['HTTP_USER_AGENT']);
				$_SESSION['user']['ip'] = $ip;
		}
		public function getUserDetailsThis($table_name)
		{
				$sql = 'SELECT ' . $this->getUserTableFields(array('user_id', 'name', 'last_logged', 'email', 'time_zone', 'pref_lang', 'num_visits')) . ' FROM ' . $table_name . ' WHERE ' . $this->getUserTableField('user_id') . ' =' . $this->dbObj->Param($this->fields_arr['user_id']) . ' AND ' . $this->getUserTableField('usr_status') . '=\'Ok\' AND ' . $this->getUserTableField('user_access') . '= \'User\'';
				$condition_fields_value_arr = array($this->fields_arr['user_id']);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, $condition_fields_value_arr);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount())
				{
						$is_ok = true;
						$this->user_details_arr = $rs->FetchRow();
				}
				return false;
		}
}
$verifyfrm = new verifyMailHandler();
$verifyfrm->setDBObject($db);
$verifyfrm->makeGlobalize($CFG, $LANG);
$verifyfrm->setPageBlockNames(array('msg_form_error', 'msg_form_success', 'form_verifymail'));
$verifyfrm->setCSSFormFieldErrorTipClass('clsFormFieldErrTip');
$verifyfrm->setCSSFormLabelCellDefaultClass('clsFormLabelCellDefault');
$verifyfrm->setCSSFormFieldCellDefaultClass('clsFormFieldCellDefault');
$verifyfrm->setCSSFormLabelCellErrorClass('clsFormLabelCellError');
$verifyfrm->setCSSFormFieldCellErrorClass('clsFormFieldCellError');
$verifyfrm->setFormField('code', '');
$verifyfrm->setFormField('password', '');
$verifyfrm->setFormField('user_id', '');
$verifyfrm->setAllPageBlocksHide();
$verifyfrm->setPageBlockShow('form_verifymail');
$verifyfrm->sanitizeFormInputs($_REQUEST);
$activated_account = false;
if ($verifyfrm->isFormGETed($_GET, 'code') and !$CFG['admin']['ask_password_to_activation'])
{
		if ($verifyfrm->chkIsValidCode())
		{
				$verifyfrm->updateIsVerifiedInUserMailsTable($CFG['db']['tbl']['users'], $verifyfrm->getFormField('user_id'));
				$activated_account = true;
				$verifyfrm->setAllPageBlocksHide();
				$verifyfrm->setPageBlockShow('msg_form_success');
		}
		else
		{
				$verifyfrm->setAllPageBlocksHide();
				$verifyfrm->setPageBlockShow('msg_form_error');
		}
}
else
		if ($verifyfrm->isFormPOSTed($_POST, 'password') and $CFG['admin']['ask_password_to_activation'])
		{
				if ($verifyfrm->chkIsNotEmpty('password', $LANG['err_tip_compulsory']) and ($verifyfrm->isNotVerified($CFG['db']['tbl']['users'], 'code', 'password', $LANG['err_tip_verified'], $LANG['err_tip_invalid'], $LANG['err_tip_locked'])) and ($verifyfrm->updateIsVerifiedInUserMailsTable($CFG['db']['tbl']['users'], $verifyfrm->getFormField('user_id'))))
				{
						$activated_account = true;
						$verifyfrm->setAllPageBlocksHide();
						$verifyfrm->setPageBlockShow('msg_form_success');
				}
				else
				{
						$verifyfrm->setAllPageBlocksHide();
						$verifyfrm->setPageBlockShow('msg_form_error');
						$verifyfrm->setIndirectFormField('password', '');
						$verifyfrm->setPageBlockShow('form_verifymail');
				}
		}
if ($activated_account)
{
		$user_id = $verifyfrm->getFormField('user_id');
		$verifyfrm->getUserDetailsThis($CFG['db']['tbl']['users']);
		$activation_link = "<a target=\"_blank\" href=\"" . URL($CFG['site']['url']) . "\">" . URL($CFG['site']['url']) . "</a>";
		$subject = $verifyfrm->getMailContent($LANG['registration_email_subject'], array('username' => $verifyfrm->user_details_arr['name'], 'email' => $verifyfrm->user_details_arr['email'], 'password' => $verifyfrm->getFormField('password'), 'sitename' => $CFG['site']['name'], 'link' => $activation_link));
		$content = $verifyfrm->getMailContent($LANG['registration_email_content'], array('username' => $verifyfrm->user_details_arr['name'], 'email' => $verifyfrm->user_details_arr['email'], 'password' => $verifyfrm->getFormField('password'), 'sitename' => $CFG['site']['name'], 'link' => $activation_link));
		$verifyfrm->sendActivationCode('email', $subject, $content, $CFG['site']['noreply_name'], $CFG['site']['noreply_email']);
		$verifyfrm->updateUserLog($CFG['db']['tbl']['users'], $CFG['remote_client']['ip'], session_id());
		$verifyfrm->saveUserVarsInSession($CFG['remote_client']['ip']);
		Redirect2URL($CFG['site']['url'] . 'members/welcome.php');
}



?>
<div id="selVerifyMail">
	<h2><span><?php echo $LANG['verifymail_title']; ?></span></h2>
<?php
if ($verifyfrm->isShowPageBlock('msg_form_error'))
{
?>
	<div id="selMsgError">
		 <p><?php echo $LANG['msg_error_sorry'] . ' ' . $verifyfrm->getCommonErrorMsg(); ?></p>
	</div>
<?php
}
if ($verifyfrm->isShowPageBlock('msg_form_success'))
{
?>
	<div id="selMsgSuccess">
		<p><?php echo $LANG['verified_successfully']; ?></p>
	</div>
<?php
}
if ($verifyfrm->isShowPageBlock('form_verifymail') and $CFG['admin']['ask_password_to_activation'])
{
?>
	<form name="form_verifymail" id="selFormVerifyMail" method="post" action="<?php echo URL($_SERVER['REQUEST_URI']); ?>" autocomplete="off">
		<input type="hidden" name="code" id="code" value="<?php echo $verifyfrm->getFormField('code'); ?>" />
		<table summary="<?php echo $LANG['verifymail_tbl_summary']; ?>" class="clsTwoColumnTbl">
			<tr>
				<td class="<?php echo $verifyfrm->getCSSFormLabelCellClass('password'); ?>"><?php ShowHelpTip('password'); ?><label for="password"><?php echo $LANG['verifymail_password']; ?></label></td>
				<td class="<?php echo $verifyfrm->getCSSFormFieldCellClass('password'); ?>"><?php echo $verifyfrm->getFormFieldErrorTip('password'); ?><input type="password" class="clsTextBox" name="password" id="password" tabindex="1" value="<?php echo $verifyfrm->getFormField('password'); ?>" /></td>
		    </tr>
		    <tr>
				<td class="<?php echo $verifyfrm->getCSSFormFieldCellClass('submit'); ?>" colspan="2"><input type="submit" class="clsSubmitButton" name="verifymail" id="verifymail" tabindex="2" value="<?php echo $LANG['verifymail_submit']; ?>" /></td>
			</tr>
		</table>
	</form>
<?php
}
?>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>
