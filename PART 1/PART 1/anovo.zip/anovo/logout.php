<?php
require_once ('./common/config.inc.php');
session_start();
$_SESSION = array();
if (isset($_COOKIE[session_name()]))
{
		setcookie(session_name(), '', time() - 42000, '/');
}
if (isset($_COOKIE[$CFG['cookie']['name'] . '_login']))
{
		setcookie($CFG['cookie']['name'] . '_login', '', time() + 60 * 60 * 24 * 365, '/');
}
session_destroy();
session_write_close();
$CFG['lang']['include_files'][] = 'includes/languages/%s/logout.php';
$CFG['html']['header'] = 'members/includes/languages/%s/html_header.php';
$CFG['html']['footer'] = 'members/includes/languages/%s/html_footer.php';
$CFG['db']['is_use_db'] = true;
require ($CFG['site']['project_path'] . 'common/application_top.inc.php');
?>
<div id="selLogout">
	<h2><?php echo $LANG['logout_title']; ?></h2>
	<div id="selMsgSuccess">
		<p><?php echo $LANG['logout_message']; ?></p>
	</div>
</div>
<?php
require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>
