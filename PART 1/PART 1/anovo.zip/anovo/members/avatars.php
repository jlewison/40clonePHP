<?php
require_once ('../common/config.inc.php');
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['db']['is_use_db'] = true;
$CFG['html']['is_use_header'] = false;
$CFG['html']['is_use_footer'] = false;
$CFG['http_headers']['is_cache'] = false;
$CFG['http_headers']['is_use_if_modified_since'] = false;
$CFG['is']['ajax_page'] = true;
require_once ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class AvatarHandler extends FormHandler
{
		public function displayAvatars()
		{
				$avatar_img_arr = glob($this->CFG['site']['project_path'] . $this->CFG['admin']['avatar_path'] . "default_*");
				$no_of_avatar_img = count($avatar_img_arr);
				$imgCnt = 0;
				$dispCnt = 0;
				$start = $this->fields_arr['s'];
				$limit = $this->fields_arr['l'];
?>
<div>
<?php
				if ($start > 1)
				{
?>
<span id="loadingAvatars1"><a href="<?php echo $_SERVER['REQUEST_URI']; ?>" onclick="showAvatars('<?php echo $this->CFG['site']['relative_url'] ?>avatars.php?uid=<?php echo $this->fields_arr['uid']; ?>', 's=<?php echo ($start - 1); ?>', 'selShowAvatarImages'); return false;"><img src="<?php echo $this->CFG['site']['url'] . 'images/rewind.gif'; ?>" alt="Previous" /></a></span>
<?php
				}
				else
				{
?>
<span><img src="<?php echo $this->CFG['site']['url'] . 'images/rewind_grey.gif'; ?>" alt="Previous" /></span>
<?php
				}
				if ($start == 1 and $this->isMember())
				{
						$user_details_arr = $this->getUserDetailsFromUsersTable($this->CFG['db']['tbl']['users'], $this->fields_arr['uid']);
						if (($user_details_arr['photo_server_url'] and $user_details_arr['photo_ext']) or $user_details_arr['image_path'])
						{
								if (isset($user_details_arr['image_path']) and !empty($user_details_arr['image_path']))
								{
										$img_src = $user_details_arr['image_path'];
										$attr = ' width="' . $this->CFG['admin']['ans_photos']['thumb_width'] . '"';
								}
								else
										if (isset($user_details_arr['photo_ext']) and (!empty($user_details_arr['photo_ext'])))
										{
												$img_src = $user_details_arr['photo_server_url'] . $this->CFG['admin']['ans_photos']['folder'] . getImageName($user_details_arr['img_user_id']) . $this->CFG['admin']['ans_photos']['thumb_name'] . '.' . $user_details_arr['photo_ext'];
												$attr = DISP_IMAGE($this->CFG['admin']['ans_photos']['thumb_width'], $this->CFG['admin']['ans_photos']['thumb_height'], $user_details_arr[$img_type_lc . '_width'], $user_details_arr[$img_type_lc . '_height']);
										} elseif (isset($user_details_arr['gender']) and !empty($user_details_arr['gender']))
										{
												$gender = strtoupper($user_details_arr['gender']);
												$img_src = $this->CFG['site']['url'] . 'images/no-female-' . 'thumb.jpg';
												if ($gender == 'M' || $gender == 'MALE') $img_src = $this->CFG['site']['url'] . 'images/no-male-' . 'thumb.jpg';
										}
								if ($img_src)
								{
?>
<span><a href="<?php echo $_SERVER['REQUEST_URI']; ?>" onclick="selectAvatar(0); return false;"><img src="<?php echo $img_src; ?>"<?php echo $attr; ?> alt="existing image" /></a></span>
<?php
										$no_of_avatar_img++;
										$imgCnt++;
										$dispCnt++;
								}
						}
				}
				foreach ($avatar_img_arr as $filename)
				{
						if ($imgCnt++ < $start) continue;
						$dispCnt++;
						$img_file = substr($filename, strrpos($filename, 'avatars/') + 8);
?>
<span><a href="<?php echo $this->CFG['site']['url'] . $this->CFG['admin']['avatar_path'] . $img_file; ?>" onclick="selectAvatar('<?php echo $this->CFG['site']['url'] . $this->CFG['admin']['avatar_path'] . $img_file; ?>'); return false;"><img src="<?php echo $this->CFG['site']['url'] . $this->CFG['admin']['avatar_path'] . $img_file; ?>" alt="<?php echo $img_file; ?>"/></a></span>
<?php
						if ($dispCnt == $limit) break;
				}
				if ($start < ($no_of_avatar_img - $limit))
				{
?>
<span id="loadingAvatars2"><a href="<?php echo $_SERVER['REQUEST_URI']; ?>" onclick="showAvatars('<?php echo $this->CFG['site']['relative_url'] ?>avatars.php?uid=<?php echo $this->fields_arr['uid']; ?>', 's=<?php echo ($start + 1); ?>', 'selShowAvatarImages'); return false;"><img src="<?php echo $this->CFG['site']['url'] . 'images/forward.gif'; ?>" alt="Next" /></a></span>
<?php
				}
				else
				{
?>
<span><img src="<?php echo $this->CFG['site']['url'] . 'images/forward_grey.gif'; ?>" alt="Next" /></span>
<?php
				}
?>
</div>
<?php
		}
}
$answerRating = new AvatarHandler();
$answerRating->setDBObject($db);
$answerRating->makeGlobalize($CFG, $LANG);
$answerRating->setFormField('uid', $CFG['user']['user_id']);
$answerRating->setFormField('s', 1);
$answerRating->setFormField('l', 4);
$answerRating->sanitizeFormInputs($_REQUEST);
$answerRating->displayAvatars();
die();
require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>
