<?php //00461
// Copyright Notice
// Web Site URL:  http://www.zeeways.com
// Script Owner eMail: mail@zeeways.com
// Date: April, 2007
// Script Name: Zeeways Auction Website PHP Script
// Copyright Details: This script is not free.  Do not Remove this Copy Right notice.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the site administrator.');exit(199);
?>
4+oV5AL83hywh/Amr/ERd48CP1X0hwBxH2EVAgIi5raGlwj/V5HELHsJZfatYlDQoLOkm7gGDTkk
apjOZ5JmA2YYlYj6t22qN23Obbvw19iAThxsdI963XK0WnL9P2AUh/9eqAQyB4u/xXIrUTH66/Gi
J0AwJ8E2MglDJk0IzwMXfgsFEHLBrdlH96zf9Fu0lxsqovqHzngfukLpMdLO1MlxDYamUg8OK1/9
5cMB8zfke/NmRvoLsEKrbgOq34npzoskINwscd0HWmLUZqH9qeMLKPgtqPmP3WTO3E7AxbmwA0pL
rUq1i9WfT8BzYygJniUiI+s2kRaxN87X3QXFn2uzau3Esf5TIoMyFzxgUPYgUKbdn1Epg8A/paYi
89hxxDcSE4g7j2iVqZKErlIIeSmmNcawtiNevTnhwRGXwKlMB5RWDk1rAw/AmLlaSLAc2LexRwE8
E0oEdb7EIZLoNspTX2nmWf5AqRJi3Rksb9f3R/6zS1wUtduX4lIQy520WkvcK35nvcrHLSCxHhQ+
7XwkSlBr9EpaIzW9mu0phdjGUJGzaeLYeDQFZ2fIvi85SZxPC5O4G5vRZktYUjn8V6947gggYrdf
b6D6CJbgap8D4nmKI5KruFdg2slSSyEZC5s9z1xRHZbU6NX1FPhquMC+cLSvH1C9z6adFtr1/zBl
oouZHCRHXxM0XmtiHdaOVzaEPBi+mYI27dgWMKZMvF+nmfAAYzVgEDQ2e/DsGyDGELrBXreV3wEm
9gg8J3yovR/AL0S+JJNDIvIPLiYlBAPbdxs7AT4LwauuDsuXaNSTKdTxN8YDd8KOPRQT03Lr/mOl
TmB5XKy7vJYbSdhzkub4Wix8cDK3Z+cEKb36VJUfKCwALi7msCfvBOsfAmNMdqPQ6MfC6sPSGnxC
HO7QNm8nrWZoeIxEliwB6fxvC1KZZpHbVJzRJnM4nHfYxH15UAsdnKG164qh3ob/0sr/iVIdlRZE
T1ct9G41BA0awPE2aPTC7SOilzW8wnGPcVaFb8O07LNp7UTY/tx1CUe/NMgqyCUOb/PmNAKWVa9m
xnNvhfeRwC4=