<?php
////////////////////////////////////////////////////////////// 
// Rapidsendit Clone V.1.1  Purchased from Rapidsendit.com ///
// flatFileHost lives on! Credits To Jim For The Foundtion ///
//////////////////////////////////////////////////////////////

include("./config.php");
if(isset($_GET['act'])){$act = $_GET['act'];}else{$act = "null";}
session_start();
include("./header.php");

if($enable_filelist==false){
echo "<font face='Verdana' size='2'>This page is disabled.</font>";
include("./footer.php");
die();
}
?>
<h1 face='Verdana'>Uploaded Files</h1>
<p><table width="90%" cellpadding="0" cellspacing="0" border="0">
<tr><td>#</td><td width="50%"><a href=files.php?sortby=filename style=color:black><font face='Verdana' size='2'><b>Filename</b></font></a></td><td><a href=files.php style=color:black><font face='Verdana' size='2'><b>DLs</b></font></a></td><td><font face='Verdana' size='2'><b>Size</b></font></td><td><b><font face='Verdana' size='2'>Last Download</b></font></td></tr>
<tr><td colspan=5 height=10></td></tr>
<?php

if(isset($_GET['act'])){$act = $_GET['act'];}else{$act = "null";}
 
// Rename PATHTO with the mapname where you keep the config.php
include("./config.php");
 
 
if($enable_filelist == false){
echo "<font face='Verdana' size='2'>The top10 is disabled.</font>";
die();
}
 
$order = array();
$dirname = "./storagedata";
$dh = opendir( $dirname ) or die("couldn't open directory");
while ( $file = readdir( $dh ) ) {
if ($file != '.' && $file != '..' && $file != '.htaccess') {
			   if($i % 2 == 0) { $bgcolor = "background-color: #d3dde7;"; } else if ($i % 2 != 0) {$bgcolor = "background-color: #f5f5dc;";}
$i++;

	$fh = fopen ("./storagedata/".$file, r);
	$list= explode('|', fgets($fh));
	$filecrc = str_replace(".txt","",$file);
	if (isset($_GET['sortby'])) {
		$order[] = $list[0].','.$filecrc.','.$list[4].",".$list[3];
	} else {
	    $order[] = $list[4].','.$filecrc.','.$list[0].",".$list[3];
	}
	fclose ($fh);
}
}
 
if (isset($_GET['sortby'])) {
	sort($order, SORT_STRING);
} else {
	sort($order, SORT_NUMERIC);
	$order = array_reverse($order);
}

$i = 1;
foreach($order as $line)
{
  $line = explode(',', $line);

  if (isset($_GET['sortby'])) {
  	echo "<tr><td>".$i."</td><td><font face='Verdana' size='1'><a href=\"" . $scripturl . "download.php?file=" . $line[1] . "\">".$line[0]."</a></td><td>".$line[2]."</font></td>";
  } else {
  	echo "<tr style='$bgcolor'><td>".$i."</td><td><font face='Verdana' size='1'><a href=\"" . $scripturl . "download.php?file=" . $line[1] . "\">".$line[2]."</a></td><td>".$line[0]."</font></td>";
  }

// Rename PATHTO with the mapname where you keep the "storage" map
 $filesize = filesize("./storage/".$line[1]);
  $filesize = ($filesize / 1048576);
 
  if ($filesize < 1)
  {
     $filesize = round($filesize*1024,0);
     echo "<td><font face='Verdana' size='1'>" . $filesize . " KB</font></td>";
 
  }
  else
    {
     $filesize = round($filesize,0);
     echo "<td><font face='Verdana' size='1'>" . $filesize . " MB</font></td>";
     
  }
echo "<td><font face='Verdana' size='1'>".date('Y-m-d G:i', $line[3])."</font></td></tr>";
$i++;
 
}
?>

</table>

<BR>
<BR>

<?
function total_size($dir) {
$handle = opendir($dir);
while($file = readdir($handle)) {
$total = $total + filesize ($dir.$file);
  if((is_dir($dir.$file.'/')) &&($file != '..')&&($file != '.'))
  {
  $total = $total + total_size($dir.$file.'/');
  }
}
return $total;
}

$total = total_size('storage/');
$total = $total / 1048576;
$total = round($total,0);
echo "<span style=color:gray><font face='Verdana' size='2'>Total Size: " . $total." MB</font></span>";

include("./footer.php");
?>
