<?
//Edit this part!
$domain = "http://imageshack.modthisname.spiderhost.hu"; 	//your domain, eg "http://domain.com/upload", no ending slash!


//Optional (don't edit if you don't know what you are doing)
$max_size = 153600000000000000000000000000000000000;          			//max. allowed size
$max_size_mb = "1,5";					// max. allowed size IN MB 
$tsize = "300";						//thumbnails size (pixel)
$path = "images/";   					//your image path, where the images should be uploaded to
$tpath = "thumbs/";					//your thumbnails path
?>