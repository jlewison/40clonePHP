<?php

error_reporting(E_ALL);
class feedsProcessingAPI
{
		var $simplePie;
		var $timeout;
		var $cacheLocation;
		var $cacheMinutes;
		var $dateFormat;
		var $template;
		var $error;
		var $feed;
		var $autodiscover;
		var $items;
		var $callbackFunctions;
		function feedsProcessingAPI()
		{
				$this->absolutePath = preg_replace("/\\\/", "/", dirname(__file__));
				$this->relativePath = preg_replace("/" . preg_replace("/\//", "\/", $_SERVER["DOCUMENT_ROOT"]) . "/i", "", $this->absolutePath);
				$this->timeout = 20;
				$this->cacheLocation = $this->absolutePath . "/cache/";
				$this->cacheMinutes = 30;
				$this->dateFormat = "M d Y H:i";
				$this->template = "default";
				$this->feed = array();
				$this->items = array();
				$this->callbackFunctions = array();
				require_once $this->absolutePath . "/includes/simplepie.php";
				$this->simplePie = new SimplePie();
		}
		function get($url)
		{
				if (file_exists($this->cacheLocation))
				{
						if (is_writable($this->cacheLocation))
						{
								$this->simplePie->set_timeout($this->timeout);
								$this->simplePie->cache_location($this->cacheLocation);
								$this->simplePie->cache_max_minutes($this->cacheMinutes);
								$this->simplePie->feed_url($url);
								if (@$this->simplePie->init())
								{
										$this->feed["copyright"] = $this->simplePie->get_feed_copyright();
										$this->feed["description"] = $this->simplePie->get_feed_description();
										$this->feed["language"] = $this->simplePie->get_feed_language();
										$this->feed["title"] = $this->simplePie->get_feed_title();
										$this->feed["link"] = $this->simplePie->get_feed_link();
										$this->items = $this->simplePie->get_items();
								}
								else
								{
										$this->error = 1;
										return false;
								}
						}
						else
						{
								$this->error = 2;
								return false;
						}
				}
				else
				{
						$this->error = 3;
						return false;
				}
				return true;
		}
		function setCallBackFunction($depth, $callbackFunctionName)
		{
				if (function_exists($callbackFunctionName))
				{
						$depth = explode(".", $depth);
						$evaluableString = "";
						foreach ($depth as $level)
						{
								$evaluableString .= "[\"" . $level . "\"]";
						}
						$this->callbackFunctions[$evaluableString] = $callbackFunctionName;
						return true;
				}
				else
				{
						$this->error = 5;
						return false;
				}
		}
		function parse($items = 0, $toVar = true)
		{
				require_once $this->absolutePath . "/includes/class.xtemplate.php";
				$arr = array();
				if (file_exists($this->absolutePath . "/templates/" . $this->template . "/template.xtpl"))
				{
						$xtpl = new XTemplate($this->absolutePath . "/templates/" . $this->template . "/template.xtpl");
						$xtpl->assign("feed", $this->feed);
						$counter = 0;
						foreach ($this->items as $item)
						{
								$item->autodiscover = array();
								$item->autodiscover["id"] = $item->get_id();
								$item->autodiscover["category"] = $item->get_category();
								$arr[$counter]['title'] = $item->autodiscover["title"] = $item->get_title();
								$item->autodiscover["description"] = $item->get_description();
								$desc = strip_tags($item->autodiscover["description"]);
								$arr[$counter]['description'] = substr($desc, 0, 500) . '...';
								$pattern = "/[A-Z]+[A-Z]+/";
								preg_match_all($pattern, $desc, $matches);
								$arr[$counter]['tags'] = implode(' ', array_unique($matches[0]));
								$arr[$counter]['link'] = $item->autodiscover["link"] = $item->get_link();
								$arr[$counter]['date'] = $item->autodiscover["date"] = $item->get_date($this->dateFormat);
								$author = $item->get_author();
								if (is_object($author))
								{
										$item->autodiscover["author"] = array("email" => $author->get_email(), "link" => $author->get_link(), "name" => $author->get_name());
								}
								if ($items == 0 || ($items != 0 && ++$counter <= $items))
								{
										foreach ($this->callbackFunctions as $depth => $functionName)
										{
												eval("\$item->data" . $depth . "=" . $functionName . "(\$item->data" . $depth . ");");
										}
										$xtpl->assign("autodiscover", $item->autodiscover);
										$xtpl->assign("item", $item->data);
										$xtpl->parse("main.item");
								}
						}
						$xtpl->parse("main");
						if ($toVar)
						{
								return $arr;
						}
						else
						{
								$xtpl->out("main");
						}
				}
				else
				{
						$this->error = 4;
						return false;
				}
		}
}

?>
