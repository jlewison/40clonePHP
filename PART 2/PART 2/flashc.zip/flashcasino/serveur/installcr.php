<? error_reporting(0); include ("setup.php");

// ��������� ������� ���������� ����
 $table1 = "CREATE TABLE `game_sessions` (
  `id` bigint(20) NOT NULL auto_increment,
  `login` varchar(12) default NULL,
  `state` varchar(250) default NULL,
  `cr_tstamp` datetime default NULL,
  `cashin` decimal(12,2) default NULL,
  `cashchange` decimal(12,2) default NULL,
  `lastact_tstamp` datetime default NULL,
  `gameid` bigint(20) default NULL,
  `active` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1364 ;";


$table2 = "CREATE TABLE `crzsettings` (
`id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(80) NOT NULL default '',
  `value` varchar(100) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=39 ;";


mysql_db_query($dbname, $table1);
mysql_db_query($dbname, $table2);


$sql1 = "INSERT INTO `crzsettings` VALUES (1, 'bonus_freq', '50');";
mysql_query($sql1);

$sql2 = "INSERT INTO `crzsettings` VALUES (2, 'banana_freq', '50');";
mysql_query($sql2);

$sql3 = "INSERT INTO `crzsettings` VALUES (3, 'bonus_min', '22');";
mysql_query($sql3);

$sql4 = "INSERT INTO `crzsettings` VALUES (4, 'bonus_max', '50');";
mysql_query($sql4);

$sql5 = "INSERT INTO `crzsettings` VALUES (5, 'bonus2_50', '50');";
mysql_query($sql5);

$sql6 = "INSERT INTO `crzsettings` VALUES (6, 'bonus2_100', '100');";
mysql_query($sql6);

$sql7 = "INSERT INTO `crzsettings` VALUES (7, 'bonus2_150', '150');";
mysql_query($sql7);

$sql8 = "INSERT INTO `crzsettings` VALUES (8, 'bonus2_200', '200');";
mysql_query($sql8);

$sql9 = "INSERT INTO `crzsettings` VALUES (9, 'bonus2_250', '250');";
mysql_query($sql9);

$sql10 = "INSERT INTO `crzsettings` VALUES (11, 'wl,1,1', '500');";
mysql_query($sql10);

$sql11 = "INSERT INTO `crzsettings` VALUES (12, 'wl,1,2', '400');";
mysql_query($sql11);

$sql12 = "INSERT INTO `crzsettings` VALUES (13, 'wl,1,3', '500');";
mysql_query($sql12);

$sql13 = "INSERT INTO `crzsettings` VALUES (14, 'wl,2,1', '800');";
mysql_query($sql13);

$sql14 = "INSERT INTO `crzsettings` VALUES (15, 'wl,2,2', '900');";
mysql_query($sql14);

$sql15 = "INSERT INTO `crzsettings` VALUES (16, 'wl,2,3', '1000');";
mysql_query($sql15);

$sql16 = "INSERT INTO `crzsettings` VALUES (17, 'wl,3,1', '300');";
mysql_query($sql16);

$sql17 = "INSERT INTO `crzsettings` VALUES (18, 'wl,3,2', '800');";
mysql_query($sql17);

$sql18 = "INSERT INTO `crzsettings` VALUES (19, 'wl,3,3', '900');";
mysql_query($sql18);

$sql19 = "INSERT INTO `crzsettings` VALUES (20, 'wl,4,1', '900');";
mysql_query($sql19);

$sql20 = "INSERT INTO `crzsettings` VALUES (21, 'wl,4,2', '1000');";
mysql_query($sql20);

$sql21 = "INSERT INTO `crzsettings` VALUES (22, 'wl,4,3', '900');";
mysql_query($sql21);

$sql22 = "INSERT INTO `crzsettings` VALUES (23, 'wl,5,1', '900');";
mysql_query($sql22);

$sql23 = "INSERT INTO `crzsettings` VALUES (24, 'wl,5,2', '170');";
mysql_query($sql23);

$sql24 = "INSERT INTO `crzsettings` VALUES (25, 'wl,5,3', '300');";
mysql_query($sql24);

$sql25 = "INSERT INTO `crzsettings` VALUES (26, 'wl,6,1', '60');";
mysql_query($sql25);

$sql26 = "INSERT INTO `crzsettings` VALUES (27, 'wl,6,2', '70');";
mysql_query($sql26);

$sql27 = "INSERT INTO `crzsettings` VALUES (28, 'wl,6,3', '80');";
mysql_query($sql27);

$sql28 = "INSERT INTO `crzsettings` VALUES (29, 'wl,7,1', '70');";
mysql_query($sql28);

$sql29 = "INSERT INTO `crzsettings` VALUES (30, 'wl,7,2', '90');";
mysql_query($sql29);

$sql30 = "INSERT INTO `crzsettings` VALUES (31, 'wl,7,3', '100');";
mysql_query($sql30);

$sql31 = "INSERT INTO `crzsettings` VALUES (32, 'wl,8,1', '70');";
mysql_query($sql31);

$sql32 = "INSERT INTO `crzsettings` VALUES (33, 'wl,8,2', '123');";
mysql_query($sql32);

$sql33 = "INSERT INTO `crzsettings` VALUES (34, 'wl,8,3', '345');";
mysql_query($sql33);

$sql34 = "INSERT INTO `crzsettings` VALUES (35, 'wl,9,1', '50');";
mysql_query($sql34);

$sql35 = "INSERT INTO `crzsettings` VALUES (36, 'wl,9,2', '51');";
mysql_query($sql35);

$sql36 = "INSERT INTO `crzsettings` VALUES (37, 'wl,9,3', '52');";
mysql_query($sql36);

$sql37 = "INSERT INTO `crzsettings` VALUES (38, 'double_freq', '7');";
mysql_query($sql37);



$sql38 = "INSERT INTO `crzsettings` VALUES (39, 'get_more_than_bet_freq', '52');";
mysql_query($sql38);

$sql39 = "INSERT INTO `crzsettings` VALUES (40, 'max_part_of_bank_at_once', '7');";
mysql_query($sql39);

$sql40 = "INSERT INTO `crzsettings` VALUES (41, 'max_gain_at_once', '52');";
mysql_query($sql40);

$sql41 = "INSERT INTO `crzsettings` VALUES (42, 'max_gain_in_double', '7');";
mysql_query($sql41);

$sql42 = "INSERT INTO `crzsettings` VALUES (43, 'max_gain_on_rope', '52');";
mysql_query($sql42);

$sql43 = "INSERT INTO `crzsettings` VALUES (44, 'max_super_prize', '7');";
mysql_query($sql43);


echo "<b>Installation complete.</b><br>";
mysql_query($sql1);
echo "<b>Installation complete..</b><br>";
mysql_query($sql2);
echo "<b>Installation complete...</b><br>";
mysql_query($sql3);
echo "<b>Installation complete....</b><br>";
echo "<br><br><b>���� ������� ������������! �� ���������� ���� ���� ��������!</b><br>"; 
?>