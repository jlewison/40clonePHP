<?php include('template/redtheme/top_side.php');?>

<!--
###################################################################################
#######################                                     #######################
#######################   M A I N   S E C T I O N   Start   #######################
#######################                                     #######################
###################################################################################
--> 
   <div class="wBack"><?php echo("$welcometext");?></div>

<?php if($htL == 'Y') { ?> 

<!-- HOME PAGE TOP LINKS - START -->
    
<div id="central">


<h1><?php echo("$lang_9");?> <?php echo("$lnbhome");?> <?php echo("$lang_10");?></h1>

<div id="stop">
<a href="<?php echo("$path");?>linkstopxml.php" target="_blank"><img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/xml.gif" alt="RSS Feed" border="0" /></a>
 <?php echo("$lang_3");?> <?php echo("$lnbhome");?> <?php echo("$lang_4");?>
</div>
<br />
<?php $currentPage = $_SERVER["PHP_SELF"];?>

<?php do { ?>

<div class="listing">
	<?php $wsn = $row_lista['title']; 
    
		$step8 = str_replace(" ", "-", $wsn);
		$wsseoname = "$step8"; ?>
		
            <h3><a href="<?php echo $row_lista['site']; ?>" target="_blank"><?php echo $row_lista['title']; ?></a></h3>

            <?php echo $row_lista['descr1']; ?>

<div class="listingD">          
<?php echo $row_lista['site']; ?> :: <?php echo("$lang_5");?> <?php echo $row_lista['stad']; ?> :: <?php if($fremode == 'N') { ?> <?php echo $row_lista['bid']; ?> <?php //echo("$lang_6");?> <?php } else { } ?> 
<?php
$htf_category = $row_lista['maincategory'];
$query_LdetCAT = "SELECT * FROM categorylisting WHERE catlistid = '$htf_category'";
$LdetCAT = mysql_query($query_LdetCAT, $apound) or die(mysql_error());
$row_LdetCAT = mysql_fetch_assoc($LdetCAT);
$totalRows_LdetCAT = mysql_num_rows($LdetCAT);
?>
<!--<a href="<?php echo("$path");?><?php echo $row_LdetCAT['categseoname']; ?>/"><?php echo $row_LdetCAT['categoryname'] ?></a>-->

<a href="<?php echo("$path");?><?php echo $row_lista['dtu'];?>/<?php echo("$wsseoname"); ?>.html"><?php echo("$lang_7");?></a>
<?php if($fremode == 'N') { ?> <a href="<?php echo("$path");?>upgrade.php?ucat=<?php echo $row_lista['dtu']; ?>"><?php echo("$lang_8");?></a> <?php } else { } ?>
</div>              
<div class="linkStats">
          <?php if($prenabled == 'Y' and $enb_home == 'Y') { ?>

	<?php include('pr_update_home.php');?>
	
		<?php if($enb_google == 'Y') { ?>
			<img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/googleIcon.gif" /> <?php echo $row_lista['google']; ?>
		<?php } else {} ?>
		
		<?php if($enb_yahoo == 'Y') { ?>
			<img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/yahooIcon.gif" /> <?php echo $row_lista['yahoo']; ?>
		<?php } else {} ?>
		
		<?php if($enb_msn == 'Y') { ?>
			<img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/msnIcon.gif" /> <?php echo $row_lista['msn']; ?>
		<?php } else {} ?>
		
		<?php if($enb_alexa == 'Y') { ?>
			<img src="<?php echo("$path");?>template/<?php echo("$lbdtemplate");?>/images/alexaIcon.gif" /> <?php echo $row_lista['alexa']; ?>
		<?php } else {} ?>

<?php } else {} ?>
</div>

</div>

<?php } while ($row_lista = mysql_fetch_assoc($lista)); ?>

</div>


<!-- HOME PAGE TOP LINKS - END -->

<?php }
else { }
?>

<!--
###################################################################################
#######################                                     #######################
#######################    M A I N   S E C T I O N   End    #######################
#######################                                     #######################
###################################################################################
-->

<?php include('template/redtheme/bottom_side.php');?>
<?php include('template/redtheme/footer.php'); ?>