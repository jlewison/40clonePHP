<?php
if ( !defined( 'SMARTY_DIR' ) ) {
	include_once( '../init.php' );
}

include( 'sessioninc.php' );

include(LIB_DIR . 'plugin_class.php');

$plugin = new Plugin();



// If user clicked the remove button and confirmed the delete, delete it
// 
if ( $_GET['action'] == 'delete' && $_GET['delete'] == 'Y' ) {

   $plugin->deletePlugin($_GET['name']);
}
elseif ( $_POST['action'] == 'multiple_delete'  ) {

  $plugin->multipleDeletePlugin($_POST['delete']);

}
elseif ( $_GET['action'] == 'install'  ) {

    $plugin->installPlugin($_GET['name']);
}

if ( $plugin->getErrorMessage() ) {

      $t->assign ( 'error_message', $plugin->getErrorMessage() );
}
else {

      $t->assign ( 'error_message', '' );
}

$t->assign('list', $plugin->getAllPlugins() );


$js = '<script type="text/javascript" src="'. DOC_ROOT . 'javascript/functions.js"></script>';
$t->assign('addtional_javascript', $js);

// Make the page
// 
$t->assign('rendered_page', $t->fetch('admin/pluginlist.tpl') );

$t->display( 'admin/index.tpl' );

exit;

?>