<?php

	$qry='';

	$qry='x_amount='.$_POST['x_amount'].'&invoice_num='.$_POST['x_invoice_num'].'&pay_txn_id='.$_POST['pay_txn_id'].'&x_response_reason_code='.$response_code;

	header('location: checkout_process.php?'.$qry);

?>