<?php
/**
* ForgotPassword Page
*
*
* @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
* @license
* @since 12/17/2007
*/
$lang['page_title']	= 'Trouble Accessing Your Account?';
$lang['forgotpassword_note_email']	= 'Forgot your password? Enter your login email below.';
$lang['forgotpassword_note_secret']	= 'Forgot your password? Enter your secret question answer below. We will send you an email with a link to reset your password.';
$lang['forgotpassword_note_help']	= 'If you have a different problem accessing your account, please see our';
$lang['forgotpassword_help']	= 'Login Problems Help Page';
$lang['forgotpassword_email']	= 'Email';
$lang['forgotpassword_secret_answer']	= 'Secret Answer';
$lang['forgotpassword_secret_question']	= 'Secret Question';
$lang['forgotpassword_submit']	= 'Reset Password';
$lang['forgotpassword_success_msg']	= 'Your password has been reset successfully and also an email has been sent.';
$lang['forgotpassword_failure_msg']	= 'Sorry! Error in sending mail.';
$lang['forgotpassword_invalid_email']	= 'Unregistered Email Address.';
$lang['forgotpassword_invalid_question']	= 'Sorry!,You have not setted secret question';
$lang['forgotpassword_invalid_secret_answer']	= 'Invalid secret answer.';

$lang['forgotpassword_invalid_']	= '';
?>