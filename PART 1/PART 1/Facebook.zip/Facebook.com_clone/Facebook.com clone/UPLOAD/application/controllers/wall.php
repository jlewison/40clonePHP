<?php
/**
 * wall Page
 *
 *
 * @copyright Copyright (c) 2008 [x-MoBiLe] Nulled
 * @license
 * @since 1/18/2008
 */
class wall extends Controller
{
		//Constructor
		function wall()
		{
				parent::Controller();
				loginRequired();
				//Load the language file
				$this->lang->load('wall', $this->config->item('language_code'));
				$this->load->model('wallmodel');
		}
		//Default function
		function index()
		{
				redirect('welcome');
		}
		function view()
		{
				$for = $this->uri->segment(3);
				$forId = $this->uri->segment(4);
				$outputData['wallFor'] = $for;
				$outputData['wallForId'] = $forId;
				if ($this->wallmodel->isExist($for, $forId))
				{
						$outputData['noResults'] = 0;
						if ($this->uri->segment(5) == 'delete')
						{
								$this->wallmodel->deleteWall($this->input->post('wall_id'));
								//Set the flash data
								$this->session->set_flashdata('flash_msg', $this->lang->line('wall_your') . $this->lang->line('wall_delete_success'));
								redirect('wall/view/' . $for . '/' . $forId);
						}
						//Load the pagination model
						$this->load->model('paginationmodel');
						//Load the pagination language file
						$this->lang->load('pagination', $this->config->item('language_code'));
						$perPage = $this->paginationmodel->getPerPage('wall');
						$start = (trim($this->uri->segment(5)) != '' && is_numeric($this->uri->segment(5)) && $this->uri->segment(5) > 0) ? $this->uri->segment(5) : 1;
						$start = ($start - 1) * $perPage;
						$outputData['wall'] = $this->wallmodel->getWall($for, $forId, 'wall_date desc', $start, $perPage);
						$outputData['wallCount'] = count($outputData['wall']);
						$outputData['wallTotal'] = $this->wallmodel->getWallCount($for, $forId);
						$outputData['currentPage'] = (trim($this->uri->segment(5)) != '' && is_numeric($this->uri->segment(5))) ? $this->uri->segment(5) : 1;
						$outputData['totalPages'] = ($outputData['wallTotal'] > $perPage) ? ceil(($outputData['wallTotal'] / $perPage)) : 0;
						$outputData['pageUrl'] = base_url() . 'wall/view/' . $for . '/' . $forId . '/';
						$this->smartyextended->view('wall', $outputData);
				}
				else
				{
						$outputData['noResults'] = 1;
						$this->smartyextended->view('wall', $outputData);
				}
		}
		function create()
		{
				$prefix = ($this->uri->segment(3) == 'inline') ? 'inline_' : '';
				if (trim($this->input->post($prefix . 'wall_content')) != '')
				{
						$newWall = array('wall_for' => $this->input->post($prefix . 'wall_for'), 'wall_for_id' => $this->input->post($prefix . 'wall_for_id'), 'wall_content' => $this->input->post($prefix . 'wall_content'));
						$newWallId = $this->wallmodel->createWall($newWall);
						//Load the user model
						$this->load->model('usermodel');
						$userFeedSettings = $this->usermodel->getUserFeedSetting();
						if (isset($userFeedSettings[2]) && $userFeedSettings[2] == 'yes')
						{
								//Load the minifeed model
								$this->load->model('minifeedmodel');
								$splVars = array('~~postedBy~~' => $this->usermodel->getName(), '~~postedFor~~' => $this->input->post($prefix . 'wall_for_name'), '~~postedIn~~' => $newWall['wall_for']);
								$this->minifeedmodel->postMiniFeed('WALL_POST', $splVars, array($this->input->post($prefix . 'wall_for_link')));
						}
						$tpl = '';
						if ($this->uri->segment(3) == 'inline')
						{
								$outputData['wallRow'] = $this->wallmodel->getWallById($newWallId);
								$outputData['wallFor'] = $this->input->post($prefix . 'wall_for');
								$outputData['wallForId'] = $this->input->post($prefix . 'wall_for_id');
								$tpl = $this->smartyextended->view('wallinfo', $outputData, true);
						}
						$msg = 'success';
						$msgInfo = $this->lang->line('wall_create_success');
				}
				else
				{
						$msg = 'error';
						$msgInfo = $this->lang->line('wall_enter_comment');
						$tpl = '';
				}
				echo json_encode(array('msg' => $msg, 'msgInfo' => $msgInfo, 'tpl' => $tpl));
		}
		function delete()
		{
				$this->wallmodel->deleteWall($this->input->post('wall_id'));
				$wallFor = $this->input->post('wall_for');
				$wallForId = $this->input->post('wall_for_id');
				//Load the pagination model
				$this->load->model('paginationmodel');
				//Load the pagination language file
				$this->lang->load('pagination', $this->config->item('language_code'));
				$perPage = $this->paginationmodel->getPerPage('wall');
				$walls = $this->wallmodel->getWall($wallFor, $wallForId, 'wall_date desc', 0, $perPage);
				$tpl = '';
				if (count($walls) == $perPage)
				{
						$outputData['wallRow'] = end($walls);
						$outputData['wallFor'] = $wallFor;
						$outputData['wallForId'] = $wallForId;
						$tpl = $this->smartyextended->view('wallinfo', $outputData, true);
				}
				$msgInfo = $this->lang->line('wall_delete_success');
				echo json_encode(array('msg' => 'success', 'msgInfo' => $msgInfo, 'tpl' => $tpl));
		}
}
?>