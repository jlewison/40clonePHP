<?php

/* This is the program which checks for cache and takes necessary action.
 *  Vijay Nair
 *
 * This works only for the index.php
 *
 */

/* Now we are ready to process */

include_once(FULL_PATH.'includes/internal/osdate_cache.php');

if ( $_SERVER['SCRIPT_NAME'] == DOC_ROOT.'index.php' ) {
	if ($_SERVER['QUERY_STRING'] == '') {
	/* This is the initial index page */
		$cached_data = checkCache('page_' . $_SERVER['REQUEST_URI'] );
		if (!$cached_data) return true;
		echo($cached_data);
		exit;
	} elseif  ( $_SERVER['QUERY_STRING']!= '' ) {
		$qrystr = $_SERVER['QUERY_STRING'];
		if (substr_count($qrystr,'page=') > 0) {
			$cached_data = checkCache('page_' . $_SERVER['REQUEST_URI'] );
			if (!$cached_data) return true;
			echo($cached_data);
			exit;
		}
	}

} elseif ($_SERVER['SCRIPT_NAME'] == DOC_ROOT.'showprofile.php' ) {
	/* showprofile */
	$cached_data = checkCache('page_' . $_SERVER['REQUEST_URI']);
	if (!$cached_data) return true;
	echo($cached_data);
	exit;
}
?>