<tr>
	<td align=right>Username:</td>
	<td><input type=text name=susername size=25 maxlength=15></td>
	<td><input type=submit name=submit2 value='Next Step -->'></td>
</tr>