<?php
class subscribedTag extends FormHandler
{
		public $user_details = array();
		public function populateTagList()
		{
				$sql = 'SELECT subscribe_keywords FROM ' . $this->CFG['db']['tbl']['users_ans_log'] . ' WHERE user_id = ' . $this->dbObj->Param('user_id');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['uid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$found = false;
				if ($rs->PO_RecordCount())
				{
						$row = $rs->FetchRow();
						$subscribed_tags = array();
						if (trim($row['subscribe_keywords']))
						{
								$subscribed_tags = explode(' ', trim($row['subscribe_keywords']));
								$found = true;
?>
						<div class="clsSideBarContents">
						<?php
								$classes = array('clsTagStyleBlue', 'clsTagStyleGrey', 'clsTagStyleGreen', 'clsTagStyleRed');
								$tagClassArray = array();
								$tagArray = array();
								foreach ($subscribed_tags as $eachTag)
								{
										$tagArray[$eachTag] = $this->getTagQuestionsCount($eachTag);
										$class = $classes[rand(0, count($classes)) % count($classes)];
										$tagClassArray[$eachTag] = $class;
								}

								$tagArray = $this->setFontSizeInsteadOfSearchCount($tagArray);
								$cntTags = 0;
								foreach ($tagArray as $tag => $fontSize)
								{
										$url = getUrl($this->CFG['site']['relative_url'] . 'questions.php?view=search&tags=' . $tag, $this->CFG['site']['relative_url'] . 'answers/search/?tags=' . $tag, false);
										$class = $tagClassArray[$tag];
										$fontSizeClass = 'style="font-size:' . $fontSize . 'px"';
										$cntTags++;
?>
		                    	<span class="<?php echo $class; ?>"><a href="<?php echo $url; ?>" <?php echo $fontSizeClass; ?>><?php echo $tag; ?></a></span>
		                    	<?php
								}
?>
						</div>
						<?php
						}
				}
				if (!$found)
				{
?>
					<div class="clsNoRecords">
						<p><?php echo $this->LANG['no_tags_subscribed']; ?></p>
					</div>
					<?php
				}
?>
				<?php
		}
		public function getTagQuestionsCount($tag_name)
		{
				$sql = 'SELECT total_count FROM ' . $this->CFG['db']['tbl']['tags'] . ' WHERE tag_name=' . $this->dbObj->Param($tag_name);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($tag_name));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row['total_count'] = 0;
				if ($rs->PO_RecordCount()) $row = $rs->FetchRow();
				return $row['total_count'];
		}
		public function populateUserDetails()
		{
				$sql = 'SELECT ' . $this->getUserTableFields(array('name')) . ' FROM' . ' ' . $this->CFG['db']['tbl']['users'] . ' WHERE' . ' user_id = ' . $this->dbObj->Param('user_id') . ' AND' . ' ' . $this->getUserTableField('usr_status') . '=\'OK\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['uid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($row = $rs->FetchRow())
				{
						$this->user_details = $row;
						return true;
				}
				return false;
		}
}

$subscribedTag = new subscribedTag();
$subscribedTag->setDBObject($db);
$subscribedTag->makeGlobalize($CFG, $LANG);

$subscribedTag->setPageBlockNames(array('msg_form_success', 'msg_form_error', 'tag_list_block'));

$subscribedTag->setFormField('uid', '');
$subscribedTag->sanitizeFormInputs($_REQUEST);
if (!$subscribedTag->getFormField('uid')) $subscribedTag->setFormField('uid', $CFG['user']['user_id']);
if ($subscribedTag->populateUserDetails())
{
		$subscribedTag->setPageBlockShow('tag_list_block');
		$LANG['back_to_user_profile_user'] = str_replace('{user_name}', $subscribedTag->user_details['name'], $LANG['back_to_user_profile_user']);
		$LANG['back_to_user_profile'] = ($CFG['user']['user_id'] == $subscribedTag->getFormField('uid')) ? $LANG['back_to_user_profile'] : $LANG['back_to_user_profile_user'];
		$LANG['page_title_user_name'] = str_replace('{user_name}', $subscribedTag->user_details['name'], $LANG['page_title_user_name']);
		$LANG['page_title'] = ($subscribedTag->getFormField('uid') == $CFG['user']['user_id']) ? $LANG['page_title'] : $LANG['page_title_user_name'];
		$back_link = '<a href="' . getUrl($CFG['site']['relative_url'] . 'myanswers.php?uid=' . $subscribedTag->getFormField('uid'), $CFG['site']['relative_url'] . 'my/answers/' . $subscribedTag->getFormField('uid') . '/', false) . '">' . $LANG['back_to_user_profile'] . '</a>';
}
else
{
		$subscribedTag->setPageBlockShow('msg_form_error');
		$subscribedTag->setCommonErrorMsg($LANG['invalid_user']);
}



?>
<script language="javascript">
	var block_arr= new Array('selMsgConfirm');
</script>
<div id="selManageBlog">
<?php
if ($subscribedTag->isShowPageBlock('tag_list_block'))
{
		$display_username = $LANG['myanswers_subscribed'];
		$uid = $subscribedTag->getFormField('uid');
		$uname = $subscribedTag->user_details['name'];
		if ($CFG['user']['user_id'] != $uid)
		{
				$display_username = str_replace('{user_name}', $uname, $LANG['myanswers_subscribed_others']);
		}
?>
	<div class="clsQuestionsLink">
		<ul>
        <li class="clsSubscribe"><?php echo $display_username; ?></li>
			<li class="clsLeftActiveQuestionsLink"><span class="clsRightActiveQuestionsLink"><a class="clsMiddleActiveQuestionsLink" href="<?php echo getUrl($CFG['site']['relative_url'] . 'mySubscribedTag.php?uid=' . $uid, $CFG['site']['relative_url'] . 'mysubscribedtag/' . $uid . '/', false); ?>"><?php echo $LANG['myanswers_subscribed_tag']; ?></a></span></li>
			<li class="clsLeftInActiveQuestionsLink"><span class="clsRightInActiveQuestionsLink"><a class="clsMiddleInActiveQuestionsLink" href="<?php echo getUrl($CFG['site']['relative_url'] . 'mySubscribedUser.php?uid=' . $uid, $CFG['site']['relative_url'] . 'mysubscribeduser/' . $uid . '/', false); ?>"><?php echo $LANG['myanswers_subscribed_user']; ?></a></span></li>
			<li class="clsLeftInActiveQuestionsLink"><span class="clsRightInActiveQuestionsLink"><a class="clsMiddleInActiveQuestionsLink" href="<?php echo getUrl($CFG['site']['relative_url'] . 'mySubscribedForum.php?uid=' . $uid, $CFG['site']['relative_url'] . 'mysubscribedforum/' . $uid . '/', false); ?>"><?php echo $LANG['myanswers_subscribed_forum']; ?></a></span></li>
		</ul>
	</div>
<?php
}
if ($subscribedTag->isShowPageBlock('msg_form_error'))
{
?>
  	<div id="selMsgError">
   		<p><?php echo $subscribedTag->getCommonErrorMsg(); ?></p>
  	</div>
<?php
}
if ($subscribedTag->isShowPageBlock('msg_form_success'))
{
?>
	<div id="selMsgSuccess">
		<p><?php echo $subscribedTag->getCommonErrorMsg(); ?></p>
	</div>
<?php
}
if ($subscribedTag->isShowPageBlock('tag_list_block'))
{
?>
	<div id="selSubscribedTags" class="clsCommonIndexSection">
		<div id="selWidgetRecentQuestions" class="clsSideBarSections">
			<?php $subscribedTag->populateTagList(); ?>
		</div>
	</div>
<?php
}
?>
</div>
<?php

require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>
