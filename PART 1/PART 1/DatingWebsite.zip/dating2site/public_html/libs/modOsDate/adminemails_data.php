<?php

   class adminemailsData extends Data {

      var $table = ADMINEMAILS_TABLE;

      var $config = array (
  'table' => ADMINEMAILS_TABLE,
  'idField' => 'osdate_adminemails_id',
  'addedMsg' => 'Osdate Adminemails %s Added',
  'added_err' => 'Can\\\'t Add Osdate Adminemails',
  'editMsg' => 'Osdate Adminemails %s Updated',
  'editErr' => 'Can\\\'t Update Osdate Adminemails',
  'delErr' => 'Can\\\'t Delete Osdate Adminemails',
  'delMsg' => 'Osdate Adminemails %s Deleted',
  'blankErr' => 'Osdate Adminemails Empty',
  'fields' => 
  array (
    'id' => 
    array (
      'name' => 'id',
      'description' => 'Id',
      'type' => 'number',
      'min_len' => 0,
      'max_len' => 11,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
    'email' => 
    array (
      'name' => 'email',
      'description' => 'Email',
      'type' => 'text',
      'min_len' => 0,
      'max_len' => 100,
      'blank_ok' => 0,
      'duplicate_ok' => 1,
    ),
  ),
);   

      function adminemailsData() {
      
         $this->Data($this->config);
      }
   }

?>
