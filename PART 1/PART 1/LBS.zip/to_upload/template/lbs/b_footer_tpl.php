<div id="footer">
  <p>&copy; <?php echo date("Y");?>  <a href="<?php echo("$path");?>" target="_blank" title="<?php echo("$sitetitle");?>"><?php echo("$sitetitle");?></a> &nbsp;&nbsp;&nbsp;&nbsp;<?php echo("$lang_149");?> <a href="http://www.linkbidscript.com/"><?php echo("$lang_150");?></a></p>
  </div>
