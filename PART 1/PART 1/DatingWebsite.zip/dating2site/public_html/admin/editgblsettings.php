<?php

if ( !defined( 'SMARTY_DIR' ) ) {
	include_once( '../init.php' );
}

include ( 'sessioninc.php' );

$glblgroup = 1;
if ($_REQUEST['glblgroup']) {
	$glblgroup = $_REQUEST['glblgroup'];
} elseif ($_REQUEST['txtglblgroup']) {
	$glblgroup = $_REQUEST['txtglblgroup'];
}


// include ( '../includes/internal/Functions.php');

define( 'PAGE_ID', 'global_mgt' );

if ( !checkAdminPermission( PAGE_ID ) ) {

	header( 'location: not_authorize.php' );
	exit;
}

$mships = $db->getAll('select roleid, name from ! ', array(MEMBERSHIP_TABLE) );

$memberships = array();

foreach ($mships as $row ) {
	$memberships[$row['roleid']] = $row['name'];
}

$t->assign('memberships', $memberships);

if ( $_POST['frm'] == 'frmEditConfig' ) {

	if ($_POST['txtconfigvariable'] == 'enable_php121') {

		include ("../php121/install_php121_osdate.php");
	}

	$sql = 'UPDATE ! SET config_value = ? WHERE config_variable = ?';

	$rs = $db->query( $sql, array( CONFIG_TABLE, trim( $_POST['txtconfigvalue'] ), trim( $_POST['txtconfigvariable'] ) ) );

	if ($_POST['txtconfigvariable'] == 'skin_name' || $_POST['txtconfigvariable'] == 'site_name') {

		/* Change in template. Copy the files to the curent directory */

		/* Remove files from templates_c directory */
		if ( $handle = opendir( TEMPLATE_C_DIR ) ) {
			while ( false !== ( $file = readdir( $handle ) ) ) {
				if ( $file != '.' && $file != '..' && $file != 'index.html' ) {
					unlink( TEMPLATE_C_DIR . $file );
				}
			}
			closedir($handle);

	}
		/* Remove cache files */
		if ( $handle = opendir( CACHE_DIR ) ) {
			while ( false !== ( $file = readdir( $handle ) ) ) {
				if ( $file != '.' && $file != '..' && $file != 'index.html' && $file != 'index.htm') {
					unlink( CACHE_DIR . $file );
				}
			}
			closedir($handle);
		}
	}
	if ($_POST['txtconfigvariable'] == 'forum_installed') {
		$sql = 'UPDATE ! SET config_value = ? WHERE config_variable = ?';

		$rs = $db->query( $sql, array( CONFIG_TABLE, 'None', 'forum_path' ) );

	}
	header( 'location: editgblsettings.php?glblgroup='.$glblgroup) ;
	exit;
}

$sql = 'SELECT config_variable, config_value, description, groupid FROM ! WHERE config_variable not in ( ?, ?)  and groupid = ?';

$rs = $db->getAll( $sql, array( CONFIG_TABLE, 'enable_mod_rewrite','seo_username',  $glblgroup ) );

$confdata = array();

$t->assign('glblgroups', get_lang_values('glblsettings_groups'));

$t->assign('glblgroup', $glblgroup);

foreach ( $rs as $row ) {
	$row['config_value'] = htmlspecialchars( $row['config_value'] );
	$confdata[] = $row;
}

$t->assign ( 'confdata', $confdata );

$temp_dirs = array();

if ( $handle = opendir( TEMPLATE_DIR ) ) {

    while (false !== ( $file = readdir( $handle ) ) ) {

		if ( $file != '.' && $file != '..'  && $file != 'pages' && $file != 'install') {

			if ( is_dir( TEMPLATE_DIR . $file ) ) {

				$temp_dirs[$file] = $file;

			}
		}
    }

    closedir($handle);
}

asort($temp_dirs);
reset($temp_dirs);

$t->assign ( 'template_dirs', $temp_dirs );

$t->assign('lang', $lang);


$t->assign('rendered_page', $t->fetch('admin/editgblsettings.tpl'));

$t->display( 'admin/index.tpl' );

$db->disconnect();
?>