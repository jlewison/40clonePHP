<?php include('restrict.php'); include('../settings.php'); require_once('../Connections/apound.php'); ?>
<?php
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = (!get_magic_quotes_gpc()) ? addslashes($theValue) : $theValue;

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO ig_admin (name, pass, email) VALUES (%s, %s, %s)",
                       GetSQLValueString($_POST['name'], "text"),
                       GetSQLValueString($_POST['pass'], "text"),
                       GetSQLValueString($_POST['email'], "text"));

  mysql_select_db($database_apound, $apound);
  $Result1 = mysql_query($insertSQL, $apound) or die(mysql_error());

  $insertGoTo = "manage_admin.php?upd=Y";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Add Admin</title>
<link href="admin.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.style84 {font-family: Verdana, Arial, Helvetica, sans-serif}
.style86 {font-size: 13px}
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
-->
</style>
</head>

<body>
<?php include('header_tpl.php'); ?>
<h2>Add Admin</h2>
<table width="770"  border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="770" bgcolor="#FFFFFF"><?php $x = getenv("HTTP_HOST").getenv("REQUEST_URI"); echo("<font color=white>$x</font>"); ?></td>
  </tr>
</table>
<table width="770"  border="0" align="center" cellpadding="3" cellspacing="1" bgcolor="#FFFFFF">
  <tr>
    <td width="760" valign="top"><form method="post" name="form1" action="<?php echo $editFormAction; ?>">
        <table width="6" height="1" align="center" cellpadding="6" cellspacing="1">
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style86">Name:</td>
            <td><input name="name" type="text" class="edtab" value="" size="32"></td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style86">Pass:</td>
            <td><input name="pass" type="password" class="edtab" value="" size="32"></td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style86">Email:</td>
            <td><input name="email" type="text" class="edtab" value="" size="32"></td>
          </tr>
          <tr valign="baseline">
            <td align="right" nowrap class="style82 style84 style86">&nbsp;</td>
            <td><input type="submit" class="login-but" value="Insert record"></td>
          </tr>
        </table>
        <input type="hidden" name="MM_insert" value="form1">
      </form>
    </td>
  </tr>
</table>
<?php include('footer_tpl.php'); ?>
</body>
</html>