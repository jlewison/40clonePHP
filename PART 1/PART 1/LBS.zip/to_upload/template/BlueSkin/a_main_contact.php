<?php include('template/BlueSkin/top_side.php');?>
<!--
###################################################################################
#######################                                     #######################
#######################   M A I N   S E C T I O N   Start   #######################
#######################                                     #######################
###################################################################################
-->
<div id="central">
  <h1><?php echo("$lang_93");?></h1>

<form name="form1" method="post" action="contact.php">
  <table  border="0" align="center" cellpadding="6" cellspacing="1" id="contact">
    <tr>
      <td align="right"><?php echo("$lang_81");?></td>
      <td><span id="spryselect1">
        <select name="cf_reason" id="cf_reason">
          <option value="Advert">Advertising Inquiry</option>
          <option value="Common" selected>Common inquiry</option>
          <option value="Listing">Listing Problem</option>
          <option value="Report">Report a bug</option>
          <option value="Suggest">Suggest Category</option>
        </select>
        <span class="selectRequiredMsg"><?php echo("$lang_87");?></span></span></td>
    </tr>
    <tr>
      <td align="right"><?php echo("$lang_82");?></td>
      <td><span id="sprytextfield1">
        <input name="cf_name" type="text" id="cf_name" size="51" />
        <span class="textfieldRequiredMsg"><?php echo("$lang_88");?></span></span></td>
    </tr>
    <tr>
      <td align="right"><?php echo("$lang_83");?></td>
      <td><span id="sprytextfield2">
        <input name="cf_email" type="text" id="cf_email" size="51" />
        <span class="textfieldRequiredMsg"><?php echo("$lang_89");?></span><span class="textfieldInvalidFormatMsg"><?php echo("$lang_90");?></span></span></td>
    </tr>
    <tr>
      <td align="right"><?php echo("$lang_84");?></td>
      <td><span id="spryselect2">
        <select name="cf_country" id="cf_country">
          <option value="0">Select Country</option>
          <option value="AF">AF - Afghanistan</option>
          <option value="AL">AL - Albania</option>
          <option value="DZ">DZ - Algeria</option>
          <option value="AS">AS - American Samoa</option>
          <option value="AD">AD - Andorra</option>
          <option value="AO">AO - Angola</option>
          <option value="AI">AI - Anguilla</option>
          <option value="AQ">AQ - Antarctica</option>
          <option value="AG">AG - Antigua and Bar</option>
          <option value="AR">AR - Argentina</option>
          <option value="AM">AM - Armenia</option>
          <option value="AW">AW - Aruba</option>
          <option value="AT">AT - Austria</option>
          <option value="AZ">AZ - Azerbaijan</option>
          <option value="BS">BS - Bahamas</option>
          <option value="BH">BH - Bahrain</option>
          <option value="BD">BD - Bangladesh</option>
          <option value="BB">BB - Barbados</option>
          <option value="BY">BY - Belarus</option>
          <option value="BE">BE - Belgium</option>
          <option value="BZ">BZ - Belize</option>
          <option value="BJ">BJ - Benin</option>
          <option value="BM">BM - Bermuda</option>
          <option value="BT">BT - Bhutan</option>
          <option value="BO">BO - Bolivia</option>
          <option value="BA">BA - Bosnia and Herz</option>
          <option value="BW">BW - Botswana</option>
          <option value="BV">BV - Bouvet Island</option>
          <option value="BR">BR - Brazil</option>
          <option value="IO">IO - British Indian </option>
          <option value="BN">BN - Brunei Darussal</option>
          <option value="BG">BG - Bulgaria</option>
          <option value="BF">BF - Burkina Faso</option>
          <option value="BI">BI - Burundi</option>
          <option value="KH">KH - Cambodia</option>
          <option value="CM">CM - Cameroon</option>
          <option value="CA">CA - Canada</option>
          <option value="CV">CV - Cape Verde</option>
          <option value="KY">KY - Cayman Islands</option>
          <option value="CF">CF - Central African</option>
          <option value="TD">TD - Chad</option>
          <option value="CL">CL - Chile</option>
          <option value="CN">CN - China</option>
          <option value="CX">CX - Christmas Islan</option>
          <option value="CC">CC - Cocos (Keeling)</option>
          <option value="CO">CO - Colombia</option>
          <option value="KM">KM - Comoros</option>
          <option value="CG">CG - Congo</option>
          <option value="CK">CK - Cook Islands</option>
          <option value="CR">CR - Costa Rica</option>
          <option value="CI">CI - Cote D'Ivoire</option>
          <option value="HR">HR - Croatia</option>
          <option value="CU">CU - Cuba</option>
          <option value="CY">CY - Cyprus</option>
          <option value="CZ">CZ - Czech Republic</option>
          <option value="DK">DK - Denmark</option>
          <option value="DJ">DJ - Djibouti</option>
          <option value="DM">DM - Dominica</option>
          <option value="DO">DO - Dominican Repub</option>
          <option value="TP">TP - East Timor</option>
          <option value="EC">EC - Ecuador</option>
          <option value="EG">EG - Egypt</option>
          <option value="SV">SV - El Salvador</option>
          <option value="GQ">GQ - Equatorial Guin</option>
          <option value="ER">ER - Eritrea</option>
          <option value="EE">EE - Estonia</option>
          <option value="ET">ET - Ethiopia</option>
          <option value="FK">FK - Falkland Island</option>
          <option value="FO">FO - Faroe Islands</option>
          <option value="FJ">FJ - Fiji</option>
          <option value="FI">FI - Finland</option>
          <option value="FR">FR - France</option>
          <option value="FX">FX - France, Metropo</option>
          <option value="GF">GF - French Guiana</option>
          <option value="PF">PF - French Polynesi</option>
          <option value="TF">TF - French Southern</option>
          <option value="GA">GA - Gabon</option>
          <option value="GM">GM - Gambia</option>
          <option value="GE">GE - Georgia</option>
          <option value="DE">DE - Germany</option>
          <option value="GH">GH - Ghana</option>
          <option value="GI">GI - Gibraltar</option>
          <option value="GR">GR - Greece</option>
          <option value="GL">GL - Greenland</option>
          <option value="GD">GD - Grenada</option>
          <option value="GP">GP - Guadeloupe</option>
          <option value="GU">GU - Guam</option>
          <option value="GT">GT - Guatemala</option>
          <option value="GN">GN - Guinea</option>
          <option value="GW">GW - Guinea-bissau</option>
          <option value="GY">GY - Guyana</option>
          <option value="HT">HT - Haiti</option>
          <option value="HM">HM - Heard and Mc Do</option>
          <option value="HN">HN - Honduras</option>
          <option value="HK">HK - Hong Kong</option>
          <option value="HU">HU - Hungary</option>
          <option value="IS">IS - Iceland</option>
          <option value="ID">ID - In&lt;font colo</option>
          <option value="IN">IN - India</option>
          <option value="IR">IR - Iran (Islamic R</option>
          <option value="IQ">IQ - Iraq</option>
          <option value="IE">IE - Ireland</option>
          <option value="IL">IL - Israel</option>
          <option value="IT">IT - Italy</option>
          <option value="JM">JM - Jamaica</option>
          <option value="JP">JP - Japan</option>
          <option value="JO">JO - Jordan</option>
          <option value="KZ">KZ - Kazakhstan</option>
          <option value="KE">KE - Kenya</option>
          <option value="KI">KI - Kiribati</option>
          <option value="KP">KP - Korea, Democrat</option>
          <option value="KR">KR - Korea, Republic</option>
          <option value="KW">KW - Kuwait</option>
          <option value="KG">KG - Kyrgyzstan</option>
          <option value="LA">LA - Lao People's De</option>
          <option value="LV">LV - Latvia</option>
          <option value="LB">LB - Lebanon</option>
          <option value="LS">LS - Lesotho</option>
          <option value="LR">LR - Liberia</option>
          <option value="LY">LY - Libyan Arab Jam</option>
          <option value="LI">LI - Liechtenstein</option>
          <option value="LT">LT - Lithuania</option>
          <option value="LU">LU - Luxembourg</option>
          <option value="MO">MO - Macau</option>
          <option value="MK">MK - Macedonia, The </option>
          <option value="MG">MG - Madagascar</option>
          <option value="MW">MW - Malawi</option>
          <option value="MY">MY - Malaysia</option>
          <option value="MV">MV - Maldives</option>
          <option value="ML">ML - Mali</option>
          <option value="MT">MT - Malta</option>
          <option value="MH">MH - Marshall Island</option>
          <option value="MQ">MQ - Martinique</option>
          <option value="MR">MR - Mauritania</option>
          <option value="MU">MU - Mauritius</option>
          <option value="YT">YT - Mayotte</option>
          <option value="MX">MX - Mexico</option>
          <option value="FM">FM - Micronesia, Fed</option>
          <option value="MD">MD - Moldova, Republ</option>
          <option value="MC">MC - Monaco</option>
          <option value="MN">MN - Mongolia</option>
          <option value="MS">MS - Montserrat</option>
          <option value="MA">MA - Morocco</option>
          <option value="MZ">MZ - Mozambique</option>
          <option value="MM">MM - Myanmar</option>
          <option value="NA">NA - Namibia</option>
          <option value="NR">NR - Nauru</option>
          <option value="NP">NP - Nepal</option>
          <option value="NL">NL - Netherlands</option>
          <option value="AN">AN - Netherlands Ant</option>
          <option value="NC">NC - New Caledonia</option>
          <option value="NZ">NZ - New Zealand</option>
          <option value="NI">NI - Nicaragua</option>
          <option value="NE">NE - Niger</option>
          <option value="NG">NG - Nigeria</option>
          <option value="NU">NU - Niue</option>
          <option value="NF">NF - Norfolk Island</option>
          <option value="MP">MP - Northern Marian</option>
          <option value="NO">NO - Norway</option>
          <option value="OM">OM - Oman</option>
          <option value="PK">PK - Pakistan</option>
          <option value="PW">PW - Palau</option>
          <option value="PA">PA - Panama</option>
          <option value="PG">PG - Papua New Guine</option>
          <option value="PY">PY - Paraguay</option>
          <option value="PE">PE - Peru</option>
          <option value="PH">PH - Philippines</option>
          <option value="PN">PN - Pitcairn</option>
          <option value="PL">PL - Poland</option>
          <option value="PT">PT - Portugal</option>
          <option value="PR">PR - Puerto Rico</option>
          <option value="QA">QA - Qatar</option>
          <option value="RE">RE - Reunion</option>
          <option value="RO">RO - Romania</option>
          <option value="RU">RU - Russian Federat</option>
          <option value="RW">RW - Rwanda</option>
          <option value="KN">KN - Saint Kitts and</option>
          <option value="LC">LC - Saint Lucia</option>
          <option value="VC">VC - Saint Vincent a</option>
          <option value="WS">WS - Samoa</option>
          <option value="SM">SM - San Marino</option>
          <option value="ST">ST - Sao Tome and Pr</option>
          <option value="SA">SA - Saudi Arabia</option>
          <option value="SN">SN - Senegal</option>
          <option value="SC">SC - Seychelles</option>
          <option value="SL">SL - Sierra Leone</option>
          <option value="SG">SG - Singapore</option>
          <option value="SK">SK - Slovakia (Slova</option>
          <option value="SI">SI - Slovenia</option>
          <option value="SB">SB - Solomon Islands</option>
          <option value="SO">SO - Somalia</option>
          <option value="ZA">ZA - South Africa</option>
          <option value="GS">GS - South Georgia a</option>
          <option value="ES">ES - Spain</option>
          <option value="LK">LK - Sri Lanka</option>
          <option value="SH">SH - St. Helena</option>
          <option value="PM">PM - St. Pierre and </option>
          <option value="SD">SD - Sudan</option>
          <option value="SR">SR - Suriname</option>
          <option value="SJ">SJ - Svalbard and Ja</option>
          <option value="SZ">SZ - Swaziland</option>
          <option value="SE">SE - Sweden</option>
          <option value="CH">CH - Switzerland</option>
          <option value="SY">SY - Syrian Arab Rep</option>
          <option value="TW">TW - Taiwan</option>
          <option value="TJ">TJ - Tajikistan</option>
          <option value="TZ">TZ - Tanzania, Unite</option>
          <option value="TH">TH - Thailand</option>
          <option value="TG">TG - Togo</option>
          <option value="TK">TK - Tokelau</option>
          <option value="TO">TO - Tonga</option>
          <option value="TT">TT - Trinidad and To</option>
          <option value="TN">TN - Tunisia</option>
          <option value="TR">TR - Turkey</option>
          <option value="TM">TM - Turkmenistan</option>
          <option value="TC">TC - Turks and Caico</option>
          <option value="TV">TV - Tuvalu</option>
          <option value="UG">UG - Uganda</option>
          <option value="UA">UA - Ukraine</option>
          <option value="AE">AE - United Arab Emi</option>
          <option value="UK" selected>UK - United Kingdom</option>
          <option value="US">US - United States</option>
          <option value="UM">UM - United States M</option>
          <option value="UY">UY - Uruguay</option>
          <option value="UZ">UZ - Uzbekistan</option>
          <option value="VU">VU - Vanuatu</option>
          <option value="VA">VA - Vatican City St</option>
          <option value="VE">VE - Venezuela</option>
          <option value="VN">VN - Viet Nam</option>
          <option value="VG">VG - Virgin Islands </option>
          <option value="VI">VI - Virgin Islands </option>
          <option value="WF">WF - Wallis and Futu</option>
          <option value="EH">EH - Western Sahara</option>
          <option value="YE">YE - Yemen</option>
          <option value="YU">YU - Yugoslavia</option>
          <option value="ZR">ZR - Zaire</option>
          <option value="ZM">ZM - Zambia</option>
          <option value="ZW">ZW - Zimbabwe</option>
        </select>
        <br/>
        <span class="selectRequiredMsg"><?php echo("$lang_91");?></span></span></td>
    </tr>
    <tr>
      <td align="right"><?php echo("$lang_85");?></td>
      <td><span id="sprytextarea1">
        <textarea name="cf_message" cols="40" rows="6" class="searchforminp3" id="cf_message"></textarea>
        <span class="textareaRequiredMsg"><?php echo("$lang_92");?></span></span></td>
    </tr>
    <tr>
      <td align="right"><?php echo("$lang_86");?></td>
      <td><span id="sprytextfield3">
        <input name="number" type="text" class="searchforminp4" id=\&quot;number\&quot; />
        <span class="textfieldRequiredMsg"><?php echo("$lang_92");?></span></span></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><img src="random_image.php"></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><input name="Submit" type="submit" value="Submit"></td>
    </tr>
  </table>
</form>
<script type="text/javascript">
<!--
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2", "email");
var spryselect1 = new Spry.Widget.ValidationSelect("spryselect1");
var spryselect2 = new Spry.Widget.ValidationSelect("spryselect2");
var sprytextarea1 = new Spry.Widget.ValidationTextarea("sprytextarea1");
var sprytextfield3 = new Spry.Widget.ValidationTextField("sprytextfield3");
//-->
</script>
</div>
<!--
###################################################################################
#######################                                     #######################
#######################    M A I N   S E C T I O N   End    #######################
#######################                                     #######################
###################################################################################
-->
<?php include('template/BlueSkin/bottom_side.php');?>
<?php include('template/BlueSkin/footer.php'); ?>
