<?php

define('ISNOTEMPTY', 1 << 0);
define('ISVALIDALPHA', 1 << 1);
define('ISVALIDALPHANUMERIC', 1 << 2);
define('ISNUMERIC', 1 << 3);
define('ISREAL', 1 << 4);
define('ISVALIDEMAIL', 1 << 5);
define('ISVALIDPHONENO', 1 << 6);
define('ISVALIDURL', 1 << 7);
define('ISCUSTOMFUN', 1 << 8);
if (!isset($CFG['debug']['debug_standalone_modules'])) $CFG['debug']['debug_standalone_modules'] = true;
class FormHandler
{
		protected $common_error_message = '';
		protected $common_success_message = '';
		protected $fields_arr = array();
		protected $fields_err_tip_arr = array();
		protected $page_block_show_stat_arr = array();
		protected $css_class_arr = array();
		protected $countries_list_arr;
		protected $months_list_arr;
		protected $years_list_config;
		protected $is_allow_dynamic_fields = false;
		public $tab_index = 1000;
		public function __construct()
		{
		}
		public function setFormField($field_name, $field_value, $validation_scheme = null, $custom_validation_fun_name = null)
		{
				$this->fields_arr[$field_name] = $field_value;
				if (isset($validation_scheme))
				{
						$this->validation_scheme_arr[$field_name] = $validation_scheme;
						$this->custom_validation_fun_name[$field_name] = $custom_validation_fun_name;
				}
		}
		public function setIndirectFormField($field_name, $field_value)
		{
				$this->setFormField($field_name, $field_value);
		}
		public function setDisplayVar($field_name, $field_value)
		{
				$this->setFormField($field_name, $field_value);
		}
		public function getFormField($field_name)
		{
				return $this->fields_arr[$field_name];
		}
		public function getDisplayVar($field_name)
		{
				return $this->getFormField($field_name);
		}
		public function setCommonErrorMsg($err_msg)
		{
				$this->common_error_message = $err_msg;
		}
		public function getCommonErrorMsg()
		{
				return $this->common_error_message;
		}
		public function setCommonSuccessMsg($success_msg)
		{
				$this->common_success_message = $success_msg;
		}
		public function getCommonSuccessMsg()
		{
				return $this->common_success_message;
		}
		public function setPageBlockNames($block_names_arr = array())
		{
				foreach ($block_names_arr as $block_name) $this->page_block_show_stat_arr[$block_name] = false;
		}
		public function setPageBlockShow($block_name)
		{
				$this->page_block_show_stat_arr[$block_name] = true;
		}
		public function setPageBlockHide($block_name)
		{
				$this->page_block_show_stat_arr[$block_name] = false;
		}
		public function setAllPageBlocksShow()
		{
				foreach ($this->page_block_show_stat_arr as $block_name => $is_show) $this->page_block_show_stat_arr[$block_name] = true;
		}
		public function setAllPageBlocksHide()
		{
				foreach ($this->page_block_show_stat_arr as $block_name => $is_show) $this->page_block_show_stat_arr[$block_name] = false;
		}
		public function isShowPageBlock($block_name)
		{
				return $this->page_block_show_stat_arr[$block_name];
		}
		public function setCSSFormFieldErrorTipClass($class_name)
		{
				$this->css_class_arr['form_field_err_tip'] = $class_name;
		}
		public function setCSSFormLabelCellDefaultClass($class_name)
		{
				$this->css_class_arr['form_label_cell_default'] = $class_name;
		}
		public function setCSSFormLabelCellErrorClass($class_name)
		{
				$this->css_class_arr['form_label_cell_error'] = $class_name;
		}
		public function setCSSFormFieldCellDefaultClass($class_name)
		{
				$this->css_class_arr['form_field_cell_default'] = $class_name;
		}
		public function setCSSFormFieldCellErrorClass($class_name)
		{
				$this->css_class_arr['form_field_cell_error'] = $class_name;
		}
		public function getCSSFormLabelCellClass($field_name)
		{
				$class_name = isset($this->fields_err_tip_arr[$field_name]) ? 'form_label_cell_error' : 'form_label_cell_default';
				return $this->css_class_arr[$class_name];
		}
		public function getCSSFormFieldCellClass($field_name)
		{
				$class_name = isset($this->fields_err_tip_arr[$field_name]) ? 'form_field_cell_error' : 'form_field_cell_default';
				return $this->css_class_arr[$class_name];
		}
		public function isFormPOSTed($post_arr, $form_submit_name = '')
		{
				return $form_submit_name ? isset($post_arr[$form_submit_name]) : $post_arr;
		}
		public function isFormGETed($get_arr, $form_submit_name = '')
		{
				return $form_submit_name ? isset($get_arr[$form_submit_name]) : $get_arr;
		}
		public function isPageGETed($get_arr, $var_name = '')
		{
				return $this->isFormGETed($get_arr, $var_name);
		}
		public function sanitizeFormInputs($request_arr)
		{
				foreach ($this->fields_arr as $field_name => $default_value)
						if (isset($request_arr[$field_name]))
						{
								if (is_string($request_arr[$field_name])) $this->fields_arr[$field_name] = htmlspecialchars(trim($request_arr[$field_name]));
								else
										if (is_array($request_arr[$field_name]))
										{
												foreach ($request_arr[$field_name] as $sub_key => $sub_value) $this->fields_arr[$field_name][$sub_key] = htmlspecialchars(trim($sub_value));
										}
										else  trigger_error('Developer Notice: Unexpected field type (' . gettype($request_arr[$field_name]) . '). FormHandler needs fix.', E_USER_ERROR);
						}
						else  $this->fields_arr[$field_name] = $default_value;
		}
		public function validateFormFields()
		{
				if (isset($this->validation_scheme_arr))
				{
				}
		}
		public function getSanitizedFormField($field_name)
		{
				return htmlspecialchars(trim($this->fields_arr[$field_name]));
		}
		public function chkIsNotEmpty($field_name, $err_tip = '')
		{
				$is_ok = (is_string($this->fields_arr[$field_name])) ? ($this->fields_arr[$field_name] != '') : (!empty($this->fields_arr[$field_name]));
				if (!$is_ok) $this->fields_err_tip_arr[$field_name] = $err_tip;
				return $is_ok;
		}
		public function chkIsNumeric($field_name, $err_tip = '')
		{
				$is_ok = ctype_digit($this->fields_arr[$field_name]);
				if (!$is_ok) $this->fields_err_tip_arr[$field_name] = $err_tip;
				return $is_ok;
		}
		public function chkIsReal($field_name, $err_tip = '')
		{
				$is_ok = is_numeric($this->fields_arr[$field_name]);
				if (!$is_ok) $this->fields_err_tip_arr[$field_name] = $err_tip;
				return $is_ok;
		}
		public function chkIsAlpha($field_name, $err_tip = '')
		{
				$is_ok = ctype_alpha($this->fields_arr[$field_name]);
				if (!$is_ok) $this->fields_err_tip_arr[$field_name] = $err_tip;
				return $is_ok;
		}
		public function chkIsAlphaNumeric($field_name, $err_tip = '')
		{
				$is_ok = ctype_alnum($this->fields_arr[$field_name]);
				if (!$is_ok) $this->fields_err_tip_arr[$field_name] = $err_tip;
				return $is_ok;
		}
		public function chkIsValidEmail($field_name, $err_tip = '', $is_chk_mxrr = false)
		{
				$is_ok = (eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$", $this->fields_arr[$field_name]));
				if (!$is_ok) $this->fields_err_tip_arr[$field_name] = $err_tip;
				return $is_ok;
		}
		public function chkIsValidURL($field_name, $err_tip = '', $is_chk_real = false)
		{
				$is_ok = (preg_match("/^http.+\..+$/i", $this->fields_arr[$field_name]));
				if (!$is_ok) $this->fields_err_tip_arr[$field_name] = $err_tip;
				return $is_ok;
		}
		public function chkIsValidPhoneNumber($field_name, $err_tip = '', $regex = "")
		{
				$is_ok = (preg_match($regex, $this->fields_arr[$field_name]));
				if (!$is_ok) $this->fields_err_tip_arr[$field_name] = $err_tip;
				return $is_ok;
		}
		public function chkIsValidFormat($field_name, $err_tip = '', $regex = "")
		{
				$is_ok = (preg_match($regex, $this->fields_arr[$field_name]));
				if (!$is_ok) $this->fields_err_tip_arr[$field_name] = $err_tip;
				return $is_ok;
		}
		public function getFormFieldErrorTip($field_name)
		{
				return (isset($this->fields_err_tip_arr[$field_name]) and $this->fields_err_tip_arr[$field_name]) ? '<span class="' . $this->css_class_arr['form_field_err_tip'] . '">' . $this->fields_err_tip_arr[$field_name] . '</span>' : '';
		}
		public function isValidFormInputs()
		{
				return (!$this->fields_err_tip_arr && !$this->common_error_message);
		}
		public function setCountriesListArr($countries_list_arr, $first_option_arr = array())
		{
				$this->countries_list_arr = $first_option_arr + $countries_list_arr;
		}
		public function populateCountriesList($highlight_country)
		{
				foreach ($this->countries_list_arr as $abbrev => $country_name)
				{
?>
	<option value="<?php echo $abbrev; ?>"<?php echo ($highlight_country == $abbrev) ? ' selected="selected"' : ''; ?>><?php echo $country_name; ?></option>
<?php
				}
		}
		public function populateDaysList($highlight_d)
		{
				for ($d = 1; $d <= 31; ++$d)
				{
?>
	<option value="<?php echo $d; ?>"<?php echo ($highlight_d == $d) ? ' selected="selected"' : ''; ?>><?php echo $d; ?></option>
<?php
				}
		}
		public function setMonthsListArr($months_list_arr, $first_option_arr = array())
		{
				$this->months_list_arr = $first_option_arr + $months_list_arr;
		}
		public function populateMonthsList($highlight_m)
		{
				foreach ($this->months_list_arr as $key => $month_name)
				{
?>
	<option value="<?php echo $key; ?>"<?php echo ($highlight_m == $key) ? ' selected="selected"' : ''; ?>><?php echo $month_name; ?></option>
<?php
				}
		}
		public function setYearsListMinMax($min_year, $max_year)
		{
				$this->years_list_config['min_year'] = $min_year;
				$this->years_list_config['max_year'] = $max_year;
		}
		public function populateYearsList($highlight_y)
		{
				for ($y = $this->years_list_config['min_year']; $y <= $this->years_list_config['max_year']; ++$y)
				{
?>
	<option value="<?php echo $y; ?>"<?php echo ($highlight_y == $y) ? ' selected="selected"' : ''; ?>><?php echo $y; ?></option>
<?php
				}
		}
		public function populateHidden($hidden_field = array())
		{
				foreach ($hidden_field as $hidden_name)
				{
?>
						<input type="hidden" name="<?php echo $hidden_name; ?>" id="<?php echo $hidden_name; ?>" value="<?php echo $this->fields_arr[$hidden_name]; ?>" />
<?php
				}
		}
		public function showFormFields()
		{
				echo '<pre>';
				print_r($this->fields_arr);
				echo '</pre>';
		}
		public function showFormFieldErrors()
		{
				echo '<pre>';
				print_r($this->fields_err_tip_arr);
				echo '</pre>';
		}
		public function setFormFieldErrorTip($field_name = '', $err_tip = '')
		{
				$this->fields_err_tip_arr[$field_name] = $err_tip;
		}
		public function getFormArrayField($field_name, $index)
		{
				if (isset($this->fields_arr[$field_name][$index])) return $this->fields_arr[$field_name][$index];
		}
		public function getFormArrayFieldErrorTip($field_name, $index)
		{
				return (isset($this->fields_err_tip_arr[$field_name][$index]) and $this->fields_err_tip_arr[$field_name][$index]) ? '<span class="' . $this->css_class_arr['form_field_err_tip'] . '">' . $this->fields_err_tip_arr[$field_name][$index] . '</span>' : '';
		}
		public function getCSSFormArrayFieldCellClass($field_name, $index)
		{
				$class_name = isset($this->fields_err_tip_arr[$field_name][$index]) ? 'form_field_cell_error' : 'form_field_cell_default';
				return $this->css_class_arr[$class_name];
		}
		public function getCSSFormArrayLabelCellClass($field_name, $index)
		{
				$class_name = isset($this->fields_err_tip_arr[$field_name][$index]) ? 'form_label_cell_error' : 'form_label_cell_default';
				return $this->css_class_arr[$class_name];
		}
		public function chkIsNotEmptyArrayFields($field_name, $min_allowed, $err_msg = '')
		{
				if (is_array($this->fields_arr[$field_name]))
				{
						foreach ($this->fields_arr[$field_name] as $key => $value)
								if (is_string($value)) $this->fields_arr[$field_name][$key] = htmlspecialchars(trim(strtoupper($value)));
						$not_ok_count = 0;
						if (count($this->fields_arr[$field_name]) == 0)
						{
								$this->common_error_message = sprintf($err_msg, $min_allowed);
								return false;
						}
						foreach ($this->fields_arr[$field_name] as $index => $val)
						{
								$is_ok = (is_string($this->fields_arr[$field_name][$index])) ? ($this->fields_arr[$field_name][$index] != '') : (!empty($this->fields_arr[$field_name][$index]));
								if (!$is_ok)
								{
										$not_ok_count += 1;
								}
						}
						if ($not_ok_count <= (count($this->fields_arr[$field_name]) - -$min_allowed)) return true;
						$this->common_error_message = sprintf($err_msg, $min_allowed);
						return false;
				}
				$this->common_error_message = sprintf($err_msg, $min_allowed);
				return false;
		}
		public function isUrlExists($url)
		{
				if (function_exists('curl_init'))
				{
						$ch = @curl_init();
						if ($ch)
						{
								curl_setopt($ch, CURLOPT_URL, $url);
								curl_setopt($ch, CURLOPT_HEADER, 0);
								curl_setopt($ch, CURLOPT_NOBODY, 1);
								curl_setopt($ch, CURLOPT_RANGE, "0-1");
								curl_setopt($ch, CURLOPT_RETURNTRANSFER, 0);
								curl_setopt($ch, CURLOPT_TIMEOUT, 10);
								$result = curl_exec($ch);
								$errno = curl_errno($ch);
								curl_close($ch);
								if ($errno == 0) return true;
								else  return false;
						}
						else  return true;
				}
				return true;
		}
		public function isUserAnswerLogExists()
		{
				$sql = 'SELECT log_id FROM ' . $this->CFG['db']['tbl']['users_ans_log'] . ' WHERE user_id=' . $this->dbObj->Param('uid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->CFG['user']['user_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$ok = false;
				if ($rs->PO_RecordCount()) $ok = true;
				return $ok;
		}
		public function updateUsersAnswerLog()
		{
				if (!isset($this->CFG['user']['user_id']) or empty($this->CFG['user']['user_id']) or (!$this->CFG['admin']['view_answers']['allowed'])) return false;
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['users_ans_log'] . ' SET total_points=total_points+' . $this->CFG['admin']['view_answers']['points'] . ',' . ' date_updated=NOW(), date_viewed=NOW()' . ' WHERE user_id=' . $this->dbObj->Param('uid') . ' AND datediff(date_viewed, now()) != 0';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->CFG['user']['user_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($this->dbObj->Affected_Rows()) return true;
				return false;
		}
		public function insertUsersAnswerLog()
		{
				$uid = $this->CFG['user']['user_id'];
				$sql = 'SELECT 1 FROM ' . $this->CFG['db']['tbl']['users_ans_log'] . ' WHERE user_id=' . $this->dbObj->Param($uid);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($uid));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if (!$rs->PO_RecordCount())
				{
						$sql = 'INSERT INTO ' . $this->CFG['db']['tbl']['users_ans_log'] . ' SET user_id=' . $this->dbObj->Param($uid);
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($uid));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				}
		}
		public function insertAdvanceSearch()
		{
				$uid = $this->CFG['user']['user_id'];
				$sql = 'SELECT 1 FROM ' . $this->CFG['db']['tbl']['advanced_search'] . ' WHERE user_id=' . $this->dbObj->Param($uid);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($uid));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if (!$rs->PO_RecordCount())
				{
						$sql = 'INSERT INTO ' . $this->CFG['db']['tbl']['advanced_search'] . ' SET user_id=' . $this->dbObj->Param($uid);
						$stmt = $this->dbObj->Prepare($sql);
						$rs = $this->dbObj->Execute($stmt, array($uid));
						if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				}
		}
		public function getUserLog($uid)
		{
				$sql = 'SELECT total_ques, total_ans, total_points' . ', DATE_FORMAT(date_updated,\'%D %b %Y\') as date_updated' . ' FROM ' . $this->CFG['db']['tbl']['users_ans_log'] . ' WHERE user_id=' . $this->dbObj->Param($uid);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($uid));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$user_ans_log = array('total_ques' => '0', 'total_ans' => '0', 'total_points' => '0', 'date_updated' => '');
				if ($rs->PO_RecordCount()) $user_ans_log = $rs->FetchRow();
				return $user_ans_log;
		}
		public function updateQuestionViews()
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['questions'] . ' SET total_views=total_views+1' . ' WHERE ques_id=' . $this->dbObj->Param('qid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($this->fields_arr['qid']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function getQuestionDetails($ques_id = 0)
		{
				$questionDetails = array();
				$sql = 'SELECT q.ques_id, q.total_answer, q.cat_id, q.best_ans_id, q.status, q.total_stars, q.question, TIMEDIFF(NOW(), date_asked) as date_asked' . ', ' . $this->getUserTableField('name') . ' as asked_by, ' . $this->getUserTableFields(array('image_path', 'gender', 't_height', 't_width', 'photo_server_url', 'photo_ext', 's_width', 's_height'), false) . ' q.user_id' . ', q.user_id AS img_user_id, video_id, audio_id, IF(status=\'Open\' AND date_closed>=NOW(), 1, 0) is_open, TIMEDIFF(date_closed, NOW()) as date_closed' . ', q.total_videos, q.total_audios FROM ' . $this->CFG['db']['tbl']['questions'] . ' AS q, ' . $this->CFG['db']['tbl']['users'] . ' AS u' . ' WHERE q.ques_id=' . $this->dbObj->Param($ques_id) . ' AND q.user_id=u.' . $this->getUserTableField('user_id') . ' AND q.status IN (\'Open\', \'Resolved\')' . ' AND u.' . $this->getUserTableField('usr_status') . '=\'Ok\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($ques_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount())
				{
						$questionDetails = $rs->FetchRow();
						$questionDetails['question_link'] = '<a href="' . getUrl($this->CFG['site']['relative_url'] . 'answer.php?qid=' . $questionDetails['ques_id'], $this->CFG['site']['relative_url'] . 'view/answers/' . $questionDetails['ques_id'] . '/', false) . '">' . wordWrapManual($questionDetails['question'], $this->CFG['admin']['question']['line_length'], $this->CFG['admin']['question']['short_length']) . '</a>';
						$questionDetails['asked_by_link'] = '<a href="' . getUrl($this->CFG['site']['relative_url'] . 'myanswers.php?uid=' . $questionDetails['user_id'], $this->CFG['site']['relative_url'] . 'my/answers/' . $questionDetails['user_id'] . '/', false) . '">' . stripString($questionDetails['asked_by'], $this->CFG['username']['medium_length']) . '</a>';
				}
				return $questionDetails;
		}
		public function isSubCategoryExists($cat_table, $parent_id)
		{
				$sql = 'SELECT 1 FROM ' . $cat_table . ' WHERE parent_id=' . $this->dbObj->Param($parent_id) . ' AND status=\'1\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($parent_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$ok = false;
				if ($rs->PO_RecordCount()) $ok = true;
				return $ok;
		}
		public function getUserTableFields($user_fields, $trim = true)
		{
				$str = '';
				foreach ($user_fields as $field)
				{
						if (isset($this->CFG['users'][$field]) and $this->CFG['users'][$field]) $str .= $this->CFG['users'][$field] . ' AS ' . $field . ', ';
				}
				if ($trim) $str = substr($str, 0, strrpos($str, ', '));
				return $str;
		}
		public function getUserTableField($user_field)
		{
				return $this->CFG['users'][$user_field];
		}
		public function showCategoryName($cat_id)
		{
				$sql = 'SELECT cat_name, cat_id FROM ' . $this->CFG['db']['tbl']['questions_category'] . ' WHERE cat_id=' . $this->dbObj->Param('cat_id');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($cat_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount())
				{
						$row = $rs->FetchRow();
?>
<span>In <a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'questions.php?cid=' . $row['cat_id'], $this->CFG['site']['relative_url'] . 'answers/dir/' . $row['cat_id'] . '/', false); ?>"><?php echo $row['cat_name']; ?></a></span>
<?php
						return true;
				}
				return false;
		}
		public function isAllowedToAsk()
		{
				$uid = $this->CFG['user']['user_id'];
				$sql = 'SELECT 1 FROM ' . $this->CFG['db']['tbl']['users_ans_log'] . ' WHERE user_id=' . $this->dbObj->Param($uid) . ' AND is_blocked=\'No\'';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($uid));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount()) return true;
				return false;
		}
		public function chkIsIntenalMailAllowed($user_id)
		{
				$sql = 'SELECT internal_mail FROM ' . $this->CFG['db']['tbl']['users_ans_log'] . ' WHERE user_id=' . $this->dbObj->Param($user_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($user_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$ok = true;
				if ($rs->PO_RecordCount())
				{
						$row = $rs->FetchRow();
						if ($row['internal_mail'] == 'No') $ok = false;
				}
				return $ok;
		}
		public function getUserDetailsFromUsersTable($user_table, $user_id)
		{
				$sql = 'SELECT ' . $this->getUserTableFields(array('user_id', 'name', 'email', 'image_path', 'bio', 'gender', 'usr_status', 'user_access', 't_height', 't_width', 's_height', 's_width', 'photo_server_url', 'photo_ext')) . ', ' . $this->getUserTableField('user_id') . ' AS img_user_id' . ' FROM ' . $user_table . ' WHERE ' . $this->getUserTableField('user_id') . ' = ' . $this->dbObj->Param($user_id);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($user_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = array('name' => '', 'email' => '', 'image_path' => '', 'gender' => '', 'usr_status' => '', 'user_access' => '', 'img_user_id' => '', 't_height' => '', 't_width' => '', 's_height' => '', 's_width' => '', 'photo_server_url' => '', 'photo_ext' => '');
				if ($rs->PO_RecordCount())
				{
						$row = $rs->FetchRow();
				}
				return $row;
		}
		public function getMailContent($content, $fieldsArr)
		{
				$content = nl2br($content);
				$chkArray = array('forum', 'blog', 'email', 'password', 'username', 'question', 'sitename', 'link', 'sender name', 'sender comment', 'question description');
				foreach ($chkArray as $value)
				{
						$toReplace = '{' . $value . '}';
						if (array_key_exists($value, $fieldsArr)) $content = str_replace($toReplace, $fieldsArr[$value], $content);
						else  $content = str_replace($toReplace, '', $content);
				}
				return $content;
		}
		public function getEmailOptionsOfUser($uid)
		{
				$sql = 'SELECT subscribe_keywords, keyword_mail, reply_mail, favorite_mail, best_ans_mail, abuse_mail' . ' FROM ' . $this->CFG['db']['tbl']['users_ans_log'] . ' WHERE user_id=' . $this->dbObj->Param('uid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($uid));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = array('subscribe_keywords' => '', 'keyword_mail' => 'Yes', 'reply_mail' => 'Yes', 'favorite_mail' => 'Yes', 'best_ans_mail' => 'Yes', 'abuse_mail' => 'Yes');
				if ($rs->PO_RecordCount()) $row = $rs->FetchRow();
				return $row;
		}
		public function displayAnswersTopLinks()
		{
				$currentPage = $this->CFG['html']['current_script_name'];
				$clsActiveMisNavLinks = 'clsActiveMisNavLinks';
				$myanswers = $topAnalysts = $askQuestions = $openQuestions = $resolvedQuestions = '';
				$$currentPage = $clsActiveMisNavLinks;
				if ($currentPage == 'questions')
				{
						if ($this->fields_arr['view'] == 'open')
						{
								$openQuestions = $clsActiveMisNavLinks;
						} elseif ($this->fields_arr['view'] == 'resolved')
						{
								$resolvedQuestions = $clsActiveMisNavLinks;
						} elseif ($this->fields_arr['view'] == 'ask')
						{
								$askQuestions = $clsActiveMisNavLinks;
						}
				}
?>
<div id="selAnswersLink"><ul>
	<li class="<?php echo $askQuestions; ?>"><span><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'questions.php?view=ask', $this->CFG['site']['relative_url'] . 'answers/ask/', false); ?>"><?php echo $this->LANG['ask_a_question']; ?></a></span></li>
	<li class="<?php echo $openQuestions; ?>"><span><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'questions.php?view=open', $this->CFG['site']['relative_url'] . 'answers/open/', false); ?>"><?php echo $this->LANG['open_questions']; ?></a></span></li>
	<li class="<?php echo $resolvedQuestions; ?>"><span><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'questions.php?view=resolved', $this->CFG['site']['relative_url'] . 'answers/resolved/', false); ?>"><?php echo $this->LANG['resolved_questions']; ?></a></span></li>
	<?php if ($this->CFG['user']['user_id'])
				{ ?>
	<li class="<?php echo $myanswers; ?>"><span><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'myanswers.php', $this->CFG['site']['relative_url'] . 'my/answers/', false); ?>"><?php echo $this->LANG['my_answers']; ?></a></span></li>
	<?php }
				else
				{ ?>
	<li><span><a href="<?php echo getUrl($this->CFG['site']['url'] . 'login.php', $this->CFG['site']['url'] . 'login/', false); ?>"><?php echo $this->LANG['my_answers']; ?></a></span></li>
	<?php } ?>
	<li class="<?php echo $topAnalysts; ?>"><span><a href="<?php echo getUrl($this->CFG['site']['relative_url'] . 'topAnalysts.php', $this->CFG['site']['relative_url'] . 'top/analysts/', false); ?>"><?php echo $this->LANG['top_analysts']; ?></a></span></li>
</ul></div>

<?php
		}
		public function encodeUrl($str)
		{
				$str = str_replace('&', '||', $str);
				return str_replace('?', '|', $str);
		}
		public function decodeUrl($str)
		{
				$str = str_replace('||', '&', $str);
				return str_replace('|', '?', $str);
		}
		public function check_date($end_date)
		{
				$end_date_arr = explode(' ', $end_date);
				$end_time_arr = explode(':', $end_date_arr[1]);
				$end_day_arr = explode('-', $end_date_arr[0]);
				$cur_date = mktime(date('H'), date('i'), date('s'), date('m'), date('d'), date('Y'));
				$end_date = mktime($end_time_arr[0], $end_time_arr[1], $end_time_arr[2], $end_day_arr[1], $end_day_arr[2], $end_day_arr[0]);
				if ($end_date < $cur_date)
				{
						$xone = 60 * 60 * 24;
						$xmin = 60 * 60;
						$xsec = 60;
						$diff = $cur_date - $end_date;
						$day = intval($diff / $xone);
						$rday = $diff - $day * $xone;
						$hou = intval($rday / $xmin);
						$rday = $rday - $hou * $xmin;
						$min = intval($rday / $xsec);
						$rday = $rday - $min * $xsec;
						$sec = $rday;
						$hou = str_pad(intval($hou), 2, '0', STR_PAD_LEFT);
						$min = str_pad(intval($min), 2, '0', STR_PAD_LEFT);
						$sec = str_pad(intval($sec), 2, '0', STR_PAD_LEFT);
						if ($day > 0) $end_within = $day . ' ' . 'days';
						elseif ($day == 0 and $hou > 0) $end_within = $hou . ' ' . 'hours';
						elseif ($day == 0 and $hou == 0 and $min > 0) $end_within = $min . ' ' . 'minutes';
						elseif ($day == 0 and $hou == 0 and $min == 0 and $sec > 0) $end_within = $sec . ' ' . 'seconds';
						return '  (' . $end_within . ' ' . 'ago' . ')';
				}
				else
				{
						return '';
				}
		}
		public function setDBObject($dbObj)
		{
				$this->dbObj = $dbObj;
		}
		public function makeGlobalize($CFG = array(), $LANG = array())
		{
				$this->CFG = $CFG;
				$this->LANG = $LANG;
		}
		public function setCfgLangGlobal($CFG = array(), $LANG = array())
		{
				$this->makeGlobalize($CFG, $LANG);
		}
		public function getTabIndex()
		{
				return $this->tab_index += 5;
		}
		public function isCheckedCheckBox($field_name)
		{
				if ($this->fields_arr[$field_name]) return ' checked';
				return;
		}
		public function isCheckedCheckBoxArray($field_name, $value)
		{
				if (in_array($value, $this->fields_arr[$field_name])) return ' checked';
				return;
		}
		public function isCheckedRadio($field_name, $value)
		{
				if ($this->fields_arr[$field_name] == $value) return ' checked';
				return;
		}
		public function chkAndCreateFolder($folderName)
		{
				$folder_arr = explode('/', $folderName);
				$folderName = '';
				foreach ($folder_arr as $key => $value)
				{
						$folderName .= $value . '/';
						if ($value == '..' or $value == '.') continue;
						if (!is_dir($folderName))
						{
								mkdir($folderName);
								@chmod($folderName, 0777);
						}
				}
		}
		public function populateBWNumbers($start_no, $end_no, $highlight_value = '')
		{
				if ($start_no > $end_no)
				{
						for ($start_no; $start_no >= $end_no; $start_no--)
						{
								$selected = $highlight_value == $start_no ? ' selected' : '';
?>
<option value="<?php echo $start_no; ?>"<?php echo $selected; ?>><?php echo $start_no; ?></option>
<?php
						}
				}
				else
				{
						for ($start_no; $start_no <= $end_no; $start_no++)
						{
								$selected = $highlight_value == $start_no ? ' selected' : '';
?>
<option value="<?php echo $start_no; ?>"<?php echo $selected; ?>><?php echo $start_no; ?></option>
<?php
						}
				}
		}
		public function generalPopulateArray($list, $highlight_value = '')
		{
				foreach ($list as $key => $value)
				{
						$selected = $highlight_value == $key ? ' selected' : '';
?>
<option value="<?php echo $key; ?>"<?php echo $selected; ?>><?php echo $value; ?></option>
<?php
				}
		}
		public function chkIsCorrectDate($date = 0, $month = 0, $year = 0, $date_field = '', $err_tip_empty = '', $err_tip_invalid = '')
		{
				if (empty($date) or empty($month) or empty($year))
				{
						$this->fields_err_tip_arr[$date_field] = $err_tip_empty;
						return false;
				}
				if (checkdate(intval($month), intval($date), intval($year)))
				{
						$month = (strlen($month) < 2) ? '0' . $month : $month;
						$date = (strlen($date) < 2) ? '0' . $date : $date;
						$this->fields_arr[$date_field] = $year . '-' . $month . '-' . $date;
						$ok = true;
				}
				else
				{
						$this->fields_err_tip_arr[$date_field] = $err_tip_invalid;
						$ok = false;
				}
				return $ok;
		}
		public function setHeaderStart()
		{
				ob_start();
				header("Pragma: no-cache");
				header("Cache-Control: no-cache, must-revalidate");
				header("Expires: 0");
				header("Content-type: text/css; charset=iso-8859-1");
		}
		public function setHeaderEnd()
		{
				ob_end_flush();
		}
		public function isMember()
		{
				return isset($this->CFG['user']['user_id']) and $this->CFG['user']['user_id'];
		}
		public function isMe($user_id)
		{
				if (!$this->isMember()) return false;
				if ($user_id == $this->CFG['user']['user_id']) return true;
				return false;
		}
		public function isAjax()
		{
				return (isset($this->fields_arr['ajax_page']) and $this->fields_arr['ajax_page']) ? true : false;
		}
		public function changeTitle($title)
		{
				return ereg_replace('[^a-zA-Z0-9]', '_', $title);
		}
		public function createEmptyTableColumn($total_limit, $finished_limit)
		{
				if ($total_limit > $finished_limit)
				{
?>
	<td colspan="<?php echo ($total_limit - $finished_limit); ?>">&nbsp;</td>
<?php
				}
		}
		public function chkIsValidString($field_name, $err_tip = '', $char = '')
		{
				$text = $this->fields_arr[$field_name];
				if (ereg('^[' . $char . ']+$', $text))
				{
						return true;
				}
				$this->fields_err_tip_arr[$field_name] = $err_tip;
				return false;
		}
		public function removeDirectory($dirname)
		{
				if (is_dir($dirname))
				{
						$result = array();
						if (substr($dirname, -1) != '/')
						{
								$dirname .= '/';
						}
						$handle = opendir($dirname);
						while (false !== ($file = readdir($handle)))
						{
								if ($file != '.' && $file != '..')
								{
										$path = $dirname . $file;
										if (is_dir($path))
										{
												$result = array_merge($result, $this->removeDirectory($path));
										}
										else
										{
												unlink($path);
												$result[] .= $path;
										}
								}
						}
						closedir($handle);
						rmdir($dirname);
						$result[] .= $dirname;
						return $result;
				}
				else
				{
						return false;
				}
		}
		public function isFavoriteContent($cid, $ctype)
		{
				$sql = 'SELECT bookmark_id FROM ' . $this->CFG['db']['tbl']['user_bookmarked'] . ' WHERE content_id = ' . $this->dbObj->Param('content_id') . ' AND' . ' content_type = ' . $this->dbObj->Param('content_type') . ' AND' . ' user_id = ' . $this->dbObj->Param('user_id');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($cid, $ctype, $this->CFG['user']['user_id']));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$ok = false;
				if ($rs->PO_RecordCount()) $ok = true;
				return $ok;
		}
		public function isIgnoredUser($cid)
		{
				$uid = $this->CFG['user']['user_id'];
				$sql = 'SELECT 1 FROM ' . $this->CFG['db']['tbl']['user_ignored'] . ' WHERE user_id=' . $this->dbObj->Param($uid) . ' AND ignored_id=' . $this->dbObj->Param($cid);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($uid, $cid));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$ok = false;
				if ($rs->PO_RecordCount()) $ok = true;
				return $ok;
		}
		public function removeDuplicateKeywords($keywords)
		{
				$not_allowed_search_array = $this->CFG['admin']['not_allowed_chars'];
				$keywords = replaceChar($not_allowed_search_array, '', $keywords);
				$keywords_arr = explode(' ', $keywords);
				$keywords_arr = array_unique($keywords_arr);
				foreach ($keywords_arr as $key => $value)
				{
						$len = strlen($value);
						if (!($len >= $this->CFG['admin']['tag_min_size'] and $len <= $this->CFG['admin']['tag_max_size'])) unset($keywords_arr[$key]);
				}
				$keywords = implode(' ', $keywords_arr);
				return trim($keywords);
		}
		public function getUserDetails($user_id, $fields_list = array())
		{
				$fields_list_arr = $fields_list;
				$fields_list = implode(',', $fields_list);
				$sql = 'SELECT ' . $fields_list . ' FROM ' . $this->CFG['db']['tbl']['users'] . ' WHERE user_id=' . $this->dbObj->Param('user_id');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($user_id));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($row = $rs->FetchRow()) $this->UserDetails[$user_id] = $row;
				else
				{
						foreach ($fields_list_arr as $key => $value)
						{
								$this->UserDetails[$user_id][$value] = '';
						}
				}
		}
		public function checkIsValidDate($day_field, $month_field, $year_field, $merge_field, $err_tip = '')
		{
				if (!$this->fields_arr[$month_field] and !$this->fields_arr[$day_field] and !$this->fields_arr[$year_field]) return true;
				if ($this->fields_arr[$month_field] and $this->fields_arr[$day_field] and $this->fields_arr[$year_field])
				{
						if (checkdate($this->fields_arr[$month_field], $this->fields_arr[$day_field], $this->fields_arr[$year_field])) return true;
				}
				$this->fields_err_tip_arr[$merge_field] = $err_tip;
				return false;
		}
		public function isShowIndexBlock($block, $userAllowed = 'yes')
		{
				$ok = true;
				switch ($block)
				{
						case 'no':
								$ok = false;
								break;
						case 'yes':
								if ($userAllowed != 'yes') $ok = false;
								break;
				}
				return $ok;
		}
		public function setFontSizeInsteadOfSearchCount($tag_array = array())
		{
				$formattedArray = $tag_array;
				$max_qty = max(array_values($formattedArray));
				$min_qty = min(array_values($formattedArray));
				$max_font_size = 28;
				$min_font_size = 12;
				$spread = $max_qty - $min_qty;
				if (0 == $spread)
				{
						$spread = 1;
				}
				$step = ($max_font_size - $min_font_size) / ($spread);
				foreach ($tag_array as $catname => $count)
				{
						$size = $min_font_size + ($count - $min_qty) * $step;
						$formattedArray[$catname] = ceil($size);
				}
				return $formattedArray;
		}
		public function getUserStyle($uid)
		{
				$user_style = 'Default';
				$sql = 'SELECT style FROM ' . $this->CFG['db']['tbl']['users_ans_log'] . ' WHERE user_id=' . $this->dbObj->Param($uid);
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($uid));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount())
				{
						$row = $rs->FetchRow();
						$style_titles = array_values($this->CFG['html']['stylesheet']['screen']['available_stylesheets']);
						if (in_array($row['style'], $style_titles)) $user_style = $row['style'];
				}
				return $user_style;
		}
		public function createErrorLogFile($type)
		{
				$temp_dir = $this->CFG['admin']['logfile_path'];
				$this->chkAndCreateFolder($temp_dir);
				$temp_file_path = $temp_dir . $this->CFG['user']['user_id'] . $type . '.txt';
				$this->fp = fopen($temp_file_path, 'w');
		}
		public function writetoTempFile($video_upload_str)
		{
				if ($this->fp)
				{
						$video_upload_str .= "\r\n" . "===================================================================================== " . "\r\n\r\n";
						fwrite($this->fp, $video_upload_str);
				}
		}
		public function closeErrorLogFile()
		{
				if ($this->fp)
				{
						fclose($this->fp);
				}
		}
		public function chkIsQuestionAbusedAlready($qid)
		{
				$uid = $this->CFG['user']['user_id'];
				$sql = 'SELECT 1 FROM ' . $this->CFG['db']['tbl']['abuse_questions'] . ' WHERE ques_id=' . $this->dbObj->Param('qid') . ' AND reported_by=' . $this->dbObj->Param('uid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($qid, $uid));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount()) return true;
				return false;
		}
		public function chkIsForumAbusedAlready($tid)
		{
				$uid = $this->CFG['user']['user_id'];
				$sql = 'SELECT 1 FROM ' . $this->CFG['db']['tbl']['abuse_forum'] . ' WHERE topic_id=' . $this->dbObj->Param('tid') . ' AND reported_by=' . $this->dbObj->Param('uid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($tid, $uid));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount()) return true;
				return false;
		}
		public function chkIsBlogAbusedAlready($bid)
		{
				$uid = $this->CFG['user']['user_id'];
				$sql = 'SELECT 1 FROM ' . $this->CFG['db']['tbl']['abuse_blog'] . ' WHERE blog_id=' . $this->dbObj->Param('bid') . ' AND reported_by=' . $this->dbObj->Param('uid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($bid, $uid));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount()) return true;
				return false;
		}
		public function chkIsAnswerAbusedAlready($aid)
		{
				$uid = $this->CFG['user']['user_id'];
				$sql = 'SELECT 1 FROM ' . $this->CFG['db']['tbl']['abuse_answers'] . ' WHERE ans_id=' . $this->dbObj->Param('aid') . ' AND reported_by=' . $this->dbObj->Param('uid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($aid, $uid));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount()) return true;
				return false;
		}
		public function getActivationCode($text)
		{
				return substr(md5($text), 0, 8);
		}
}
if ($CFG['debug']['debug_standalone_modules'])
{
}

?>
