<?php
	$module_info['name'] = 'Admin Totals';
	$module_info['desc'] = 'Makes sure the "totals" table is up-to-date.';
	$module_info['version'] = 0.1;
	// $module_info['requires'][] = '';
	// this is where you set the modules "name" and "version" that is required
	// if more that one module is required then just make a copy of that line
?>