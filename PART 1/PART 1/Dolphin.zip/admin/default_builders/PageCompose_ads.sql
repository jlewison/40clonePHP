INSERT INTO `PageCompose` VALUES(NULL, 'ads', '960px', '', '_Advertisement Photos', 1, 0, 'AdPhotos', '', 1, 50, 'non,memb', 0);
INSERT INTO `PageCompose` VALUES(NULL, 'ads', '960px', '', '_Actions', 1, 1, 'ActionList', '', 1, 50, 'non,memb', 0);
INSERT INTO `PageCompose` VALUES(NULL, 'ads', '960px', '', '_Comments', 1, 2, 'ViewComments', '', 1, 50, 'non,memb', 0);
INSERT INTO `PageCompose` VALUES(NULL, 'ads', '960px', '', '_Info', 2, 0, 'AdInfo', '', 1, 50, 'non,memb', 0);
INSERT INTO `PageCompose` VALUES(NULL, 'ads', '960px', '', '_Description', 2, 1, 'Description', '', 1, 50, 'non,memb', 0);
INSERT INTO `PageCompose` VALUES(NULL, 'ads', '960px', '', '_Users Other Listing', 2, 2, 'UserOtherAds', '', 1, 50, 'non,memb', 0);
INSERT INTO `PageCompose` VALUES(NULL, 'ads', '960px', '', '_BoonEx News', 0, 0, 'RSS', 'http://www.boonex.com/unity/blog/featured_posts/?rss=1#4', 1, 50, 'non,memb', 0);
