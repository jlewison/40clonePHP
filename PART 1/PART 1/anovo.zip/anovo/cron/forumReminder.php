<?php
require_once ('../common/config.inc.php');
$CFG['lang']['include_files'][] = 'common/email_templates/languages/%s/email_notify.inc.php';
$CFG['mods']['include_files'][] = 'common/classes/class_FormHandler.lib.php';
$CFG['auth']['is_authenticate'] = false;
$CFG['html']['is_use_footer'] = false;
$CFG['mods']['is_include_only']['non_html_header_files'] = true;
$CFG['mods']['include_files'][] = 'common/classes/phpmailer/class_PHPMailer.lib.php';
ini_set('max_execution_time', 0);
require ($CFG['site']['project_path'] . 'common/application_top.inc.php');
class ForumReminderFormHandler extends FormHandler
{
		public function getCronMasterDetails($table_name, $cron_for)
		{
				$sql = 'SELECT upto_id FROM ' . $table_name . ' WHERE cron_for = ' . $this->dbObj->Param($cron_for) . ' AND status = \'Started\' limit 0,1';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($cron_for));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount())
				{
						$row = $rs->FetchRow();
						return $row;
				}
				return false;
		}
		public function updateCronMaster($table_name, $cron_for, $status, $new_old, $upto = 0, $total = 0)
		{
				$val_arr = array();
				$val_arr[] = $status;
				$sql = 'UPDATE ' . $table_name . ' SET ' . 'status=' . $this->dbObj->Param($status);
				$sql .= ', upto_id = ' . $this->dbObj->Param($upto);
				$val_arr[] = $upto;
				if ($total == 0) $sql .= ', total = ' . $this->dbObj->Param($total);
				else  $sql .= ', total = total + ' . $this->dbObj->Param($total);
				$val_arr[] = $total;
				if ($new_old == 'new')
				{
						$sql .= ', start_time = ' . $this->dbObj->SQLDate('Y-m-d H:i:s');
						$sql .= ', tot_finished_crons = tot_finished_crons + 1';
				}
				$sql .= ' WHERE cron_for = ' . $this->dbObj->Param($cron_for);
				$val_arr[] = $cron_for;
				$stmt = $this->dbObj->Prepare($sql);
				$result = $this->dbObj->Execute($stmt, $val_arr);
				if (!$result) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function emailForumDetails($upto_id, $check_count)
		{
				$sql = 'SELECT max( response_id ) as response , topic_id , email_sent FROM ' . $this->CFG['db']['tbl']['forum_response'] . ' WHERE email_sent <> \'Yes\' GROUP BY topic_id' . ' ORDER BY response ASC LIMIT 0, 1';
				$stmt = $this->dbObj->Prepare($sql);
				$rsques = $this->dbObj->Execute($stmt);
				if (!$rsques) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rsques->PO_RecordCount())
				{
						$rowforum = $rsques->FetchRow();
						$sql = 'SELECT user_id FROM ' . $this->CFG['db']['tbl']['user_bookmarked'] . ' WHERE user_id > ' . $this->dbObj->Param($upto_id) . ' AND content_id = ' . $rowforum['topic_id'] . ' AND content_type = \'Forum\'' . ' ORDER BY user_id ASC limit 0, ' . $this->dbObj->Param($check_count);
						$stmt = $this->dbObj->Prepare($sql);
						$rsusersbookmark = $this->dbObj->Execute($stmt, array($upto_id, $check_count));
						if (!$rsusersbookmark) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
						if ($count = $rsusersbookmark->PO_RecordCount())
						{
								$forum_id = $this->getForumTopicDetails($this->CFG['db']['tbl']['forum_topics'], $rowforum['topic_id']);
								$admin_id = $this->getAdminUserId($this->CFG['db']['tbl']['users']);
								while ($rowsusersbookmark = $rsusersbookmark->FetchRow())
								{
										$ret_arr = array('user_id' => $rowsusersbookmark['user_id'], 'count' => $count);
										$reminder_subject = $this->LANG['forum_subscribed_email_subject'];
										$reminder_content = $this->LANG['forum_subscribed_email_content'];
										$send_email = true;
										if (!$send_email) continue;
										$receiver_details = $this->getUserDetailsFromUsersTable($this->CFG['db']['tbl']['users'], $rowsusersbookmark['user_id']);
										$reminder_subject = str_replace('{username}', $receiver_details['name'], $reminder_subject);
										$reminder_content = str_replace('{username}', $receiver_details['name'], $reminder_content);
										$reminder_content = str_replace('{sitename}', $this->CFG['site']['name'], $reminder_content);
										$reminder_content = str_replace('{forum topic}', '<strong>' . $forum_id[1] . '</strong>', $reminder_content);
										$question_link = getUrl($this->CFG['site']['url'] . 'forumsResponses.php?forum_id=' . $forum_id[0] . '&topic_id=' . $rowforum['topic_id'], $this->CFG['site']['url'] . 'forum/' . $forum_id[0] . '/' . $rowforum['topic_id'] . '/', false);
										$reminder_content = str_replace('{link}', '<a href="' . $question_link . '">' . $question_link . '</a>', $reminder_content);
										$this->_sendMail($receiver_details['email'], $reminder_subject, nl2br($reminder_content), $this->CFG['site']['noreply_name'], $this->CFG['site']['noreply_email']);
								}
								return $ret_arr;
						}
						$this->updateForumResponseTableEmailSentStatus($rowforum['topic_id']);
				}
				return false;
		}
		private function _sendMail($to_email, $subject, $body, $sender_name, $sender_email)
		{
				$mail = new PHPMailer();
				$mail->AddAddress($to_email);
				$mail->FromName = $sender_name;
				$mail->From = $mail->Sender = $sender_email;
				$mail->Subject = $subject;
				$mail->Body = $body;
				$mail->IsMail();
				$mail->IsHTML(true);
				return ($mail->Send());
		}
		public function getForumTopicDetails($table, $topic_field)
		{
				$sql = 'SELECT forum_id, forum_topic FROM ' . $table . ' WHERE topic_id =' . $topic_field;
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				if ($rs->PO_RecordCount())
				{
						$row = $rs->FetchRow();
				}
				return array($row['forum_id'], $row['forum_topic']);
		}
		public function updateForumResponseTableEmailSentStatus($qid)
		{
				$sql = 'UPDATE ' . $this->CFG['db']['tbl']['forum_response'] . ' SET email_sent=\'Yes\'' . ' WHERE topic_id=' . $this->dbObj->Param('qid');
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt, array($qid));
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
		}
		public function getAdminUserId($user_table)
		{
				$sql = 'SELECT ' . $this->getUserTableField('user_id') . ' AS user_id FROM ' . $user_table . ' WHERE ' . $this->getUserTableField('user_access') . ' = \'Admin\' LIMIT 1';
				$stmt = $this->dbObj->Prepare($sql);
				$rs = $this->dbObj->Execute($stmt);
				if (!$rs) trigger_error($this->dbObj->ErrorNo() . ' ' . $this->dbObj->ErrorMsg(), E_USER_ERROR);
				$row = array('user_id' => 1);
				if ($rs->PO_RecordCount())
				{
						$row = $rs->FetchRow();
				}
				return $row['user_id'];
		}
}
$reminder = new ForumReminderFormHandler();
$reminder->setDBObject($db);
$reminder->setCfgLangGlobal($CFG, $LANG);
$reminder->member_url = $CFG['site']['url'] . $CFG['redirect']['member'] . '/';
if ($cron_arr = $reminder->getCronMasterDetails($CFG['db']['tbl']['cron_master'], 'forums'))
{
		if ($autoindex_arr = $reminder->emailForumDetails($cron_arr['upto_id'], $CFG['question']['send_count'])) $reminder->updateCronMaster($CFG['db']['tbl']['cron_master'], 'forums', 'Started', 'old', $autoindex_arr['user_id'], $autoindex_arr['count']);
		else  $reminder->updateCronMaster($CFG['db']['tbl']['cron_master'], 'forums', 'Started', 'new');
}
else  $reminder->updateCronMaster($CFG['db']['tbl']['cron_master'], 'forums', 'Started', 'new');
require_once ($CFG['site']['project_path'] . 'common/application_bottom.inc.php');
?>
