var session_check = 'heck||||||||||valid||||||||login';
var addBlogComment = function()
	{
		var url		= arguments[0];
		var pars 	= arguments[1];
		var f = '';
		var frm = document.addComments;
		for (var i=0;i<frm.elements.length;i++)
			{
				var e=frm.elements[i];
				if (e.type!='button')
					{
						var ovalue = Trim(e.value);
						if(ovalue)
							{
								ovalue = replace_string(ovalue, '\n', '<br />');
								f += ovalue;
								e.value = '';
							}
						else
							{
								e.value = '';
								e.focus();
								alert_manual("Enter comment", "selAddComment");
								return false;
							}
					}
			}
		var pars = pars+'&comment='+escape(f);

		var myAjax = new Ajax.Request(
								url,
								{
								method: 'get',
								parameters: pars,
								onComplete: ajaxResultBlogComment
								});
		expand = true;
		//callAjaxBlogComment(currpath);
		Element.update('ss', '0 (Limit 1000)');
		return false;
	}
function callAjaxBlogComment(path)
	{
		new AG_ajax(path, 'ajaxResultBlogComment');
		return false;
	}
function ajaxResultBlogComment(originalRequest)
	{
		data = originalRequest.responseText;
		data = unescape(data);
		var obj = document.getElementById('selCommentBlock');
		if (data.indexOf('**--***!!!')>=1){
			data = data.split('***--***!!!');
			obj.innerHTML = data[1];
			setEditTimerValue(data[0]);
			var le = commentsArray.length+1;
			commentsArray[le] = data[0];
		}else{
			obj.innerHTML = data;
		}
		return;
	}

//delete comment
var tr_delete;
function deleteCommand(url, pars, div_id)
	{
		if(confirm(deleteConfirmation))
			{
				tr_delete = div_id;
				beforeDeleteResult();
				var myAjax = new Ajax.Request(
										url,
										{
										method: 'get',
										parameters: pars,
										onComplete: deleteResult
										});
			}
		return false;
	}

function beforeDeleteResult()
	{
		var obj;

		if(obj = document.getElementById(tr_delete))
			obj.style.display = 'none';

		if(obj = document.getElementById(tr_delete+'_1'))
			obj.style.display = 'none';

		if(obj = document.getElementById('total_comments1'))
			{
				total_comments = parseInt(obj.innerHTML)-1;
				obj.innerHTML = total_comments;
			}

		if(obj = document.getElementById('total_comments2'))
			{
				total_comments = parseInt(obj.innerHTML)-1
				obj.innerHTML = total_comments;
			}

		if(total_comments && total_comments<=minimum_counts)
			{
				if(obj = document.getElementById('view_all_comments'))
					obj.style.display = 'none';
			}

		if(obj = document.getElementById('totalComments'))
			obj.innerHTML = parseInt(obj.innerHTML)-1;
	}

function deleteResult(data)
	{
		$('selMsgSuccess').innerHTML = 'Comment deleted successfully';
	}