<?php
$pr_id = $row_catPcatLN['dtu'];
$url = $row_catPcatLN['site'];

	mysql_select_db($database_apound, $apound);
		$query_Gpr = "SELECT * FROM main WHERE main.dtu = '$pr_id'";
		$Gpr = mysql_query($query_Gpr, $apound) or die(mysql_error());
		$row_Gpr = mysql_fetch_assoc($Gpr);
		$totalRows_Gpr = mysql_num_rows($Gpr);

$pr_date = $row_Gpr['pr_date'];

if($pr_date == '') { 
	$alexa = get_alexa($url);
	$google = google_backs($url);
	$msn = msn_backs($url);
	$yahoo = yahoo_backs($url);
	$pr_now_date = date("Y-m-d");
	
		$link = mysql_pconnect($hostname_apound,$username_apound,$password_apound);
		mysql_select_db($database_apound);
		mysql_query("UPDATE main SET google='$google' WHERE dtu='$pr_id'");
		mysql_query("UPDATE main SET yahoo='$yahoo' WHERE dtu='$pr_id'");
		mysql_query("UPDATE main SET msn='$msn' WHERE dtu='$pr_id'");
		mysql_query("UPDATE main SET alexa='$alexa' WHERE dtu='$pr_id'");
		mysql_query("UPDATE main SET pr_date='$pr_now_date' WHERE dtu='$pr_id'");
}
elseif($pr_date <> '') {
	mysql_select_db($database_apound, $apound);
		$query_GprU = "SELECT * FROM main WHERE main.dtu = '$pr_id'";
		$GprU = mysql_query($query_GprU, $apound) or die(mysql_error());
		$row_GprU = mysql_fetch_assoc($GprU);
		$totalRows_GprU = mysql_num_rows($GprU);

	$old_date = $row_GprU['pr_date'];
	$new_date = date("Y-m-d");
	$diff_date = abs(strtotime(date('y-m-d'))-strtotime($old_date)) / 86400;
	
		if($diff_date > '10') {
				$alexa = get_alexa($url);
				$google = google_backs($url);
				$msn = msn_backs($url);
				$yahoo = yahoo_backs($url);
				$pr_now_date = date("Y-m-d");
				
					$link = mysql_pconnect($hostname_apound,$username_apound,$password_apound);
					mysql_select_db($database_apound);
						mysql_query("UPDATE main SET google='$google' WHERE dtu='$pr_id'");
						mysql_query("UPDATE main SET yahoo='$yahoo' WHERE dtu='$pr_id'");
						mysql_query("UPDATE main SET msn='$msn' WHERE dtu='$pr_id'");
						mysql_query("UPDATE main SET alexa='$alexa' WHERE dtu='$pr_id'");
						mysql_query("UPDATE main SET pr_date='$pr_now_date' WHERE dtu='$pr_id'");
		}
		else {}
	
	
}
else {}
?>