<?php
$lang['page_title']	= 'Edit profile';
$lang['editprofilepicture_success_msg']					= 'Your picture has been uploaded successfully.
You may have to refresh the page to see your new picture. It has also been added to your Profile Pictures album.';

$lang['editprofilepicture_current_picture']				= 'Current Picture';
$lang['editprofilepicture_invalid_file']				= 'The image you are trying to upload does not exist OR not valid.';
$lang['editprofilepicture_current_picture_note']		= 'You can select a profile photo from your Profile Picture Album.';
$lang['editprofilepicture_upload_picture']				= 'Upload Picture';
$lang['editprofilepicture_upload_picture_error_msg']	= 'Please select a valid image for upload.';
$lang['editprofilepicture_remove_picture']				= 'Remove Picture';
$lang['editprofilepicture_file_size_note']				= 'File size limit 4 MB. If your upload does not work, try a smaller picture';
$lang['editprofilepicture_remove_picture_note']			= 'You can remove this picture, but be sure to upload another or we will display a question mark in its place.';
$lang['editprofilepicture_certify']						= 'I certify that I have the right to distribute this picture and that it does not violate the Terms of Use.';
$lang['editprofilepicture_allowed_extensions_note']		= 'You can upload a JPG, GIF or PNG file.';
$lang['editprofilepicture_upload_error']				= 'You can only upload a JPG, GIF or PNG file.';
$lang['editprofilepicture_certify_error_msg']			= 'You must certify that you have permission to upload this picture and that it does not violate our Terms of Use.<br>
Please click the checkbox to certify';

$lang['editprofilepicture_remove_picture_confirm_title']	= 'Remove Picture?';
$lang['editprofilepicture_remove_picture_confirm_message']	= 'Are you sure you want to remove this picture?';
$lang['editprofilepicture_upload_resolutionerror']				= 'Please upload some higher resolution picture (greater than 50*50)';
?>