<?php
$CFG['admin']['ans_photos']['folder'] = 'files/ans_photos/';
$CFG['admin']['ans_photos']['temp_folder'] = 'files/temp_files/ans_temp_photos/';
$CFG['admin']['ans_photos']['large_width'] = 120;
$CFG['admin']['ans_photos']['large_height'] = 120;
$CFG['admin']['ans_photos']['large_name'] = 'T';
$CFG['admin']['ans_photos']['thumb_width'] = 90;
$CFG['admin']['ans_photos']['thumb_height'] = 90;
$CFG['admin']['ans_photos']['thumb_name'] = 'T';
$CFG['admin']['ans_photos']['small_width'] = 40;
$CFG['admin']['ans_photos']['small_height'] = 40;
$CFG['admin']['ans_photos']['small_name'] = 'S';
$CFG['admin']['ans_photos']['format_arr'] = array('jpg', 'jpeg', 'gif');
$CFG['admin']['ans_photos']['max_size'] = 5000;
?>