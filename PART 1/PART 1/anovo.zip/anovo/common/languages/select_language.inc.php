<?php
$ua_lang_signatures = array(
		'en_us' => 'en([-_][[:alpha:]]{2})?|english');

$requested_lang = $CFG['lang']['default'];
$is_set_cookie_session = false;
if (!empty($_GET['lang']))
{

		$requested_lang = $_GET['lang'];
		$is_set_cookie_session = true;
}
else
		if (!empty($_POST['lang']))
		{

				$requested_lang = $_POST['lang'];
				$is_set_cookie_session = true;
		}
		else
				if (!empty($_COOKIE['lang'])) $requested_lang = $_COOKIE['lang'];
				else
						if (!empty($_SESSION['user']['pref_lang'])) $requested_lang = $_SESSION['user']['pref_lang'];
						else
								if (!empty($_SERVER['HTTP_ACCEPT_LANGUAGE']))
								{
										foreach ($ua_lang_signatures as $key => $value)
										{
												if (preg_match('/^(' . $value . ')(;q=[0-9]\\.[0-9])?$/i', $_SERVER['HTTP_ACCEPT_LANGUAGE']))
												{
														$requested_lang = $key;
														break;
												}
										}
								}
								else
										if (!empty($_SERVER['HTTP_USER_AGENT']))
										{
												foreach ($ua_lang_signatures as $key => $value)
												{
														if (preg_match('/(\(|\[|;[[:space:]])(' . $value . ')(;|\]|\))/i', $_SERVER['HTTP_USER_AGENT']))
														{
																$requested_lang = $key;
																break;
														}
												}
										}
if ($is_set_cookie_session or $requested_lang != $CFG['lang']['default'])
{
		if (isset($CFG['lang']['available_languages'][$requested_lang]) && ((is_string($CFG['lang']['enabled_languages']) && $CFG['lang']['enabled_languages'] == '*') || (is_array($CFG['lang']['enabled_languages']) && in_array($requested_lang, $CFG['lang']['enabled_languages']))))
		{
				$CFG['lang']['default'] = $requested_lang;

				setcookie('lang', $requested_lang, time() + 4320000, '/');

				$_SESSION['user']['pref_lang'] = $requested_lang;
		}
}
?>