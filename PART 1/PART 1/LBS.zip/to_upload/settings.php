<?php error_reporting (E_ALL ^ E_NOTICE);
require_once('Connections/apound.php');
mysql_select_db($database_apound, $apound);
$query_AST = "SELECT * FROM confset";
$AST = mysql_query($query_AST, $apound) or die(mysql_error());
$row_AST = mysql_fetch_assoc($AST);
$totalRows_AST = mysql_num_rows($AST);
$google_m = $row_AST['google_m'];
$google_m_k = $row_AST['google_m_k'];
$path = $row_AST['path'];
$paypal = $row_AST['paypal'];
$paypalcurrency = $row_AST['paypalcurrency'];
$contactmail = $row_AST['contactmail'];
$adminmail = $row_AST['adminmail'];
$currency_O = $row_AST['currency'];
$currencymail_O = $row_AST['currencymail'];
$pathmail = $row_AST['pathmail'];
$frommail = $row_AST['frommail'];
$contactmailsubject = $row_AST['contactmailsubject'];
$domainname = $row_AST['domainname'];
$sitetitle = $row_AST['sitetitle'];
$lbdtemplate = $row_AST['lbdtemplate'];
$alphacat = $row_AST['alphacat'];
$prenabled = $row_AST['prenabled'];
$screenshot = $row_AST['screenshot'];
$buymailsubject = $row_AST['buymailsubject'];
$buymailmessage = $row_AST['buymailmessage'];
$bidmailsubject = $row_AST['bidmailsubject'];
$bidmailmessage = $row_AST['bidmailmessage'];
$htL = $row_AST['htL'];
$minbid = $row_AST['minbid'];
$minup = $row_AST['minup'];
$lexv = $row_AST['lexv'];
$fremode = $row_AST['fremode'];
$fmwb = $row_AST['fmwb'];
$fmau = $row_AST['fmau'];
$langu_id = $row_AST['langu_id'];
$p_about = $row_AST['p_about'];
$p_top = $row_AST['p_top'];
$asubm = $row_AST['asubm'];
$p_terms = $row_AST['p_terms'];
$linkbacka = $row_AST['linkbacka'];
$query_LAID = "SELECT * FROM `language` WHERE langu_id = '$langu_id'";
$LAID = mysql_query($query_LAID, $apound) or die(mysql_error());
$row_LAID = mysql_fetch_assoc($LAID);
$totalRows_LAID = mysql_num_rows($LAID);
$my_lang = $row_LAID['langu_name'];
include("$my_lang.php");
mysql_free_result($LAID);
mysql_free_result($AST);
$categ = $_GET[categ];
$name = $_GET[name];
$ucat = mysql_real_escape_string($_GET[ucat]);
$pageNum_lista = $_GET[pageNum_lista];
$totalRows_lista = $_GET[totalRows_lista];
$link = $_GET[link];
$q = $_POST[q];
$newbid = $_POST[newbid];
$oldbid = $_POST[oldbid];
$bidid = $_POST[bidid];
$url = mysql_real_escape_string($_POST[url]);
$keyword = mysql_real_escape_string($_POST[keyword]);
$deeptf = mysql_real_escape_string($_POST[deeptf]);
$dfurl = mysql_real_escape_string($_POST[dfurl]);
$deepts = mysql_real_escape_string($_POST[deepts]);
$dsurl = mysql_real_escape_string($_POST[dsurl]);
$deeptt = mysql_real_escape_string($_POST[deeptt]);
$dturl = mysql_real_escape_string($_POST[dturl]);
$email = mysql_real_escape_string($_POST[email]);
$Submit = $_POST[Submit];
$email = $_POST[email];
$descr1 = mysql_real_escape_string($_POST[descr1]);
$descr2 = mysql_real_escape_string($_POST[descr2]);
$mdesc = mysql_real_escape_string($_POST[mdesc]);
$mword = mysql_real_escape_string($_POST[mword]);
$bid = $_POST[bid];
$submit = $_POST[submit];
$category = $_GET[category];
$categseoname = $_POST[categseoname];
$categdesc = $_POST[categdesc];
$categmdesc = $_POST[categmdesc];
$categmkw = $_POST[categmkw];
$selectc = mysql_real_escape_string($_POST[selectc]);
$cf_name = $_POST[cf_name];
$cf_email = $_POST[cf_email];
$cf_country = $_POST[cf_country];
$cf_message = $_POST[cf_message];

// Enable or Disable the aplication public section - LBS 1.5

mysql_select_db($database_apound, $apound);
$query_ONF = "SELECT onoff FROM confset";
$ONF = mysql_query($query_ONF, $apound) or die(mysql_error());
$row_ONF = mysql_fetch_assoc($ONF);
$totalRows_ONF = mysql_num_rows($ONF);

$onoff = $row_ONF['onoff'];

mysql_free_result($ONF);

// welcome text

$query_WTCS = "SELECT * FROM welcome";
$WTCS = mysql_query($query_WTCS, $apound) or die(mysql_error());
$row_WTCS = mysql_fetch_assoc($WTCS);
$totalRows_WTCS = mysql_num_rows($WTCS);
$welcometext = $row_WTCS['wecontent'];
mysql_free_result($WTCS);


// CAPTCHA SETTINGS
$query_RIS = "SELECT * FROM captcha";
$RIS = mysql_query($query_RIS, $apound) or die(mysql_error());
$row_RIS = mysql_fetch_assoc($RIS);
$totalRows_RIS = mysql_num_rows($RIS);
$chp_onoff = $row_RIS['chp_onoff'];
$chp_distors = $row_RIS['chp_distors'];
$chp_leng = $row_RIS['chp_leng'];
$chp_typ = $row_RIS['chp_typ'];
$chp_simp  = $row_RIS['chp_simp']; 
mysql_free_result($RIS);

//mysql_select_db($database_apound, $apound);
$query_curENS = "SELECT * FROM currency WHERE currency.curid = '$currency_O'";
$curENS = mysql_query($query_curENS, $apound) or die(mysql_error());
$row_curENS = mysql_fetch_assoc($curENS);
$totalRows_curENS = mysql_num_rows($curENS);
$currency = $row_curENS['cursign'];

//mysql_select_db($database_apound, $apound);
$query_curENAS = "SELECT * FROM currency WHERE currency.curid = '$currencymail_O'";
$curENAS = mysql_query($query_curENAS, $apound) or die(mysql_error());
$row_curENAS = mysql_fetch_assoc($curENAS);
$totalRows_curENAS = mysql_num_rows($curENAS);
$currencymail = $row_curENAS['curenc'];

//mysql_select_db($database_apound, $apound);
$query_GGaD = "SELECT * FROM adsense";
$GGaD = mysql_query($query_GGaD, $apound) or die(mysql_error());
$row_GGaD = mysql_fetch_assoc($GGaD);
$totalRows_GGaD = mysql_num_rows($GGaD);
$adsensecode = $row_GGaD['adsensecode'];

//mysql_select_db($database_apound, $apound);
$query_TRMS = "SELECT * FROM terms";
$TRMS = mysql_query($query_TRMS, $apound) or die(mysql_error());
$row_TRMS = mysql_fetch_assoc($TRMS);
$totalRows_TRMS = mysql_num_rows($TRMS);
$termsdetails = $row_TRMS['termsdetails'];

//mysql_select_db($database_apound, $apound);
$query_LNBP = "SELECT * FROM linknumber";
$LNBP = mysql_query($query_LNBP, $apound) or die(mysql_error());
$row_LNBP = mysql_fetch_assoc($LNBP);
$totalRows_LNBP = mysql_num_rows($LNBP);
$lnbhome = $row_LNBP['lnbhome'];
$lnbcategory = $row_LNBP['lnbcategory'];
$lnbalphabet = $row_LNBP['lnbalphabet'];
$lnbtoplinks = $row_LNBP['lnbtoplinks'];
$lnbnewlinks = $row_LNBP['lnbnewlinks'];

//mysql_select_db($database_apound, $apound);
$query_FLD = "SELECT * FROM field_config";
$FLD = mysql_query($query_FLD, $apound) or die(mysql_error());
$row_FLD = mysql_fetch_assoc($FLD);
$totalRows_FLD = mysql_num_rows($FLD);
$maxtitle = $row_FLD['maxtitle'];
$maxdesc = $row_FLD['maxdesc'];
$maxexdesc = $row_FLD['maxexdesc'];
$maxmdesc = $row_FLD['maxmdesc'];
$maxkword = $row_FLD['maxkword'];
$deepenable = $row_FLD['deepenable'];


// listing order START - LBS 1.5

mysql_select_db($database_apound, $apound);
$query_LO = "SELECT HP_ordby_F, HP_ordby_O, TL_ordby_F, TL_ordby_O, CL_ordby_F, CL_ordby_O, AL_ordby_F, AL_ordby_O FROM confset";
$LO = mysql_query($query_LO, $apound) or die(mysql_error());
$row_LO = mysql_fetch_assoc($LO);
$totalRows_LO = mysql_num_rows($LO);

// home page listing order
$HP_ordby_F = $row_LO['HP_ordby_F'];
$HP_ordby_O = $row_LO['HP_ordby_O'];

// top links page listing order
$TL_ordby_F = $row_LO['TL_ordby_F'];
$TL_ordby_O = $row_LO['TL_ordby_O'];

// category page listing order
$CL_ordby_F = $row_LO['CL_ordby_F'];
$CL_ordby_O = $row_LO['CL_ordby_O'];

// alphabet page listing order
$AL_ordby_F = $row_LO['AL_ordby_F'];
$AL_ordby_O = $row_LO['AL_ordby_O'];

mysql_free_result($LO);
// listing order END - LBS 1.5


//categories start - home page
//mysql_select_db($database_apound, $apound);
$query_categRL = "SELECT categoryname, categseoname FROM categorylisting WHERE categorylisting.categenable = 'Y' AND categorylisting.parentid = '0' ORDER BY categorylisting.categoryname ASC";
$categRL = mysql_query($query_categRL, $apound) or die(mysql_error());
$row_categRL = mysql_fetch_assoc($categRL);
$totalRows_categRL = mysql_num_rows($categRL);
//categories end - homepage

// home page top five start
$maxRows_lista = "$lnbhome";
$pageNum_lista = 0;
if (isset($_GET['pageNum_lista'])) {
  $pageNum_lista = $_GET['pageNum_lista'];
}
$startRow_lista = $pageNum_lista * $maxRows_lista;

//mysql_select_db($database_apound, $apound);

if($lexv == '30') {
$query_lista = "SELECT * FROM main WHERE main.avail = 'Y' AND main.paid = 'Y' AND TO_DAYS(NOW()) < TO_DAYS(stad)+30 ORDER BY main.$HP_ordby_F $HP_ordby_O";
}
elseif($lexv == '60') {
$query_lista = "SELECT * FROM main WHERE main.avail = 'Y' AND main.paid = 'Y' AND TO_DAYS(NOW()) < TO_DAYS(stad)+60 ORDER BY main.$HP_ordby_F $HP_ordby_O";
}
elseif($lexv == '90') {
$query_lista = "SELECT * FROM main WHERE main.avail = 'Y' AND main.paid = 'Y' AND TO_DAYS(NOW()) < TO_DAYS(stad)+90 ORDER BY main.$HP_ordby_F $HP_ordby_O";
}
elseif($lexv == 'LIMITED') {
$query_lista = "SELECT * FROM main WHERE main.avail = 'Y' AND main.paid = 'Y' AND TO_DAYS(NOW()) < TO_DAYS(stod) ORDER BY main.$HP_ordby_F $HP_ordby_O";
}
else {
$query_lista = "SELECT * FROM main WHERE main.avail = 'Y' AND main.paid = 'Y' ORDER BY main.$HP_ordby_F $HP_ordby_O";
}
$query_limit_lista = sprintf("%s LIMIT %d, %d", $query_lista, $startRow_lista, $maxRows_lista);
$lista = mysql_query($query_limit_lista, $apound) or die(mysql_error());
$row_lista = mysql_fetch_assoc($lista);

if (isset($_GET['totalRows_lista'])) {
  $totalRows_lista = $_GET['totalRows_lista'];
} else {
  $all_lista = mysql_query($query_lista);
  $totalRows_lista = mysql_num_rows($all_lista);
}
$totalPages_lista = ceil($totalRows_lista/$maxRows_lista)-1;

$queryString_lista = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_lista") == false && 
        stristr($param, "totalRows_lista") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_lista = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_lista = sprintf("&totalRows_lista=%d%s", $totalRows_lista, $queryString_lista);
$srf = "/";
//home page top five end

// category name for hom page top five - start
//$htf_category = $row_lista['maincategory'];
//mysql_select_db($database_apound, $apound);
/* $query_LdetCAT = "SELECT * FROM categorylisting WHERE catlistid = '$htf_category'";
$LdetCAT = mysql_query($query_LdetCAT, $apound) or die(mysql_error());
$row_LdetCAT = mysql_fetch_assoc($LdetCAT);
$totalRows_LdetCAT = mysql_num_rows($LdetCAT); */
// category name for hom page top five - end

// top bidder start
//mysql_select_db($database_apound, $apound);
if($lexv == 'LIMITED') {
$query_top_BID = "SELECT * FROM main WHERE TO_DAYS(NOW()) < TO_DAYS(stod) AND main.avail = 'Y' AND main.paid = 'Y' ORDER BY main.bid DESC";
}
else {
$query_top_BID = "SELECT * FROM main WHERE main.avail = 'Y' AND main.paid = 'Y' ORDER BY main.bid DESC";
}
$top_BID = mysql_query($query_top_BID, $apound) or die(mysql_error());
$row_top_BID = mysql_fetch_assoc($top_BID);
$totalRows_top_BID = mysql_num_rows($top_BID);
// top bidder end

$bascat = $_GET[bascat];

// PR Management Start
mysql_select_db($database_apound, $apound);
$query_PRCus = "SELECT confset.indc, confset.prenabled, confset.pr_google, confset.pr_yahoo, confset.pr_msn, confset.pr_alexa, confset.prp_latest, confset.prp_category, confset.prp_details, confset.prp_home, confset.prp_links, confset.prp_list, confset.prp_search FROM confset";
$PRCus = mysql_query($query_PRCus, $apound) or die(mysql_error());
$row_PRCus = mysql_fetch_assoc($PRCus);
$totalRows_PRCus = mysql_num_rows($PRCus);

$enb_google = $row_PRCus['pr_google'];
$enb_yahoo = $row_PRCus['pr_yahoo'];
$enb_msn = $row_PRCus['pr_msn'];
$enb_alexa = $row_PRCus['pr_alexa'];

$enb_latest = $row_PRCus['prp_latest'];
$enb_category = $row_PRCus['prp_category'];
$enb_details = $row_PRCus['prp_details'];
$enb_home = $row_PRCus['prp_home'];
$enb_links = $row_PRCus['prp_links'];
$enb_list = $row_PRCus['prp_list'];
$enb_search = $row_PRCus['prp_search'];

// PR Management End

//meta latest.php
mysql_select_db($database_apound, $apound);
$query_mlatest = "SELECT * FROM meta WHERE meta.m_page = 'latest.php'";
$mlatest = mysql_query($query_mlatest, $apound) or die(mysql_error());
$row_mlatest = mysql_fetch_assoc($mlatest);
$totalRows_mlatest = mysql_num_rows($mlatest);

$latest_title = $row_mlatest['m_title'];
$latest_keyword = $row_mlatest['m_keyword'];
$latest_description = $row_mlatest['m_description'];

//meta category.php
mysql_select_db($database_apound, $apound);
$query_mcategory = "SELECT * FROM meta WHERE meta.m_page = 'category.php'";
$mcategory = mysql_query($query_mcategory, $apound) or die(mysql_error());
$row_mcategory = mysql_fetch_assoc($mcategory);
$totalRows_mcategory = mysql_num_rows($mcategory);

$category_title = $row_mcategory['m_title'];
$category_keyword = $row_mcategory['m_keyword'];
$category_description = $row_mcategory['m_description'];

//meta details.php
mysql_select_db($database_apound, $apound);
$query_mdetails = "SELECT * FROM meta WHERE meta.m_page = 'details.php'";
$mdetails = mysql_query($query_mdetails, $apound) or die(mysql_error());
$row_mdetails = mysql_fetch_assoc($mdetails);
$totalRows_mdetails = mysql_num_rows($mdetails);

$details_title = $row_mdetails['m_title'];
$details_keyword = $row_mdetails['m_keyword'];
$details_description = $row_mdetails['m_description'];

//meta index.php
mysql_select_db($database_apound, $apound);
$query_mindex = "SELECT * FROM meta WHERE meta.m_page = 'index.php'";
$mindex = mysql_query($query_mindex, $apound) or die(mysql_error());
$row_mindex = mysql_fetch_assoc($mindex);
$totalRows_mindex = mysql_num_rows($mindex);

$index_title = $row_mindex['m_title'];
$index_keyword = $row_mindex['m_keyword'];
$index_description = $row_mindex['m_description'];

//meta links.php
mysql_select_db($database_apound, $apound);
$query_mlinks = "SELECT * FROM meta WHERE meta.m_page = 'links.php'";
$mlinks = mysql_query($query_mlinks, $apound) or die(mysql_error());
$row_mlinks = mysql_fetch_assoc($mlinks);
$totalRows_mlinks = mysql_num_rows($mlinks);

$links_title = $row_mlinks['m_title'];
$links_keyword = $row_mlinks['m_keyword'];
$links_description = $row_mlinks['m_description'];

//meta list.php
mysql_select_db($database_apound, $apound);
$query_mlist = "SELECT * FROM meta WHERE meta.m_page = 'list.php'";
$mlist = mysql_query($query_mlist, $apound) or die(mysql_error());
$row_mlist = mysql_fetch_assoc($mlist);
$totalRows_mlist = mysql_num_rows($mlist);

$list_title = $row_mlist['m_title'];
$list_keyword = $row_mlist['m_keyword'];
$list_description = $row_mlist['m_description'];

//meta search.php
mysql_select_db($database_apound, $apound);
$query_msearch = "SELECT * FROM meta WHERE meta.m_page = 'search.php'";
$msearch = mysql_query($query_msearch, $apound) or die(mysql_error());
$row_msearch = mysql_fetch_assoc($msearch);
$totalRows_msearch = mysql_num_rows($msearch);

$search_title = $row_msearch['m_title'];
$search_keyword = $row_msearch['m_keyword'];
$search_description = $row_msearch['m_description'];

//meta about.php
mysql_select_db($database_apound, $apound);
$query_mabout = "SELECT * FROM meta WHERE meta.m_page = 'about.php'";
$mabout = mysql_query($query_mabout, $apound) or die(mysql_error());
$row_mabout = mysql_fetch_assoc($mabout);
$totalRows_mabout = mysql_num_rows($mabout);

$about_title = $row_mabout['m_title'];
$about_keyword = $row_mabout['m_keyword'];
$about_description = $row_mabout['m_description'];

//meta contact.php
mysql_select_db($database_apound, $apound);
$query_mcontact = "SELECT * FROM meta WHERE meta.m_page = 'contact.php'";
$mcontact = mysql_query($query_mcontact, $apound) or die(mysql_error());
$row_mcontact = mysql_fetch_assoc($mcontact);
$totalRows_mcontact = mysql_num_rows($mcontact);

$contact_title = $row_mcontact['m_title'];
$contact_keyword = $row_mcontact['m_keyword'];
$contact_description = $row_mcontact['m_description'];

//meta processing.php
mysql_select_db($database_apound, $apound);
$query_mprocessing = "SELECT * FROM meta WHERE meta.m_page = 'processing.php'";
$mprocessing = mysql_query($query_mprocessing, $apound) or die(mysql_error());
$row_mprocessing = mysql_fetch_assoc($mprocessing);
$totalRows_mprocessing = mysql_num_rows($mprocessing);

$processing_title = $row_mprocessing['m_title'];
$processing_keyword = $row_mprocessing['m_keyword'];
$processing_description = $row_mprocessing['m_description'];

//meta sorry.php
mysql_select_db($database_apound, $apound);
$query_msorry = "SELECT * FROM meta WHERE meta.m_page = 'sorry.php'";
$msorry = mysql_query($query_msorry, $apound) or die(mysql_error());
$row_msorry = mysql_fetch_assoc($msorry);
$totalRows_msorry = mysql_num_rows($msorry);

$sorry_title = $row_msorry['m_title'];
$sorry_keyword = $row_msorry['m_keyword'];
$sorry_description = $row_msorry['m_description'];

//meta terms.php
mysql_select_db($database_apound, $apound);
$query_mterms = "SELECT * FROM meta WHERE meta.m_page = 'terms.php'";
$mterms = mysql_query($query_mterms, $apound) or die(mysql_error());
$row_mterms = mysql_fetch_assoc($mterms);
$totalRows_mterms = mysql_num_rows($mterms);

$terms_title = $row_mterms['m_title'];
$terms_keyword = $row_mterms['m_keyword'];
$terms_description = $row_mterms['m_description'];

//meta thankyou.php
mysql_select_db($database_apound, $apound);
$query_mthankyou = "SELECT * FROM meta WHERE meta.m_page = 'thankyou.php'";
$mthankyou = mysql_query($query_mthankyou, $apound) or die(mysql_error());
$row_mthankyou = mysql_fetch_assoc($mthankyou);
$totalRows_mthankyou = mysql_num_rows($mthankyou);

$thankyou_title = $row_mthankyou['m_title'];
$thankyou_keyword = $row_mthankyou['m_keyword'];
$thankyou_description = $row_mthankyou['m_description'];

//meta update.php
mysql_select_db($database_apound, $apound);
$query_mupdate = "SELECT * FROM meta WHERE meta.m_page = 'update.php'";
$mupdate = mysql_query($query_mupdate, $apound) or die(mysql_error());
$row_mupdate = mysql_fetch_assoc($mupdate);
$totalRows_mupdate = mysql_num_rows($mupdate);

$update_title = $row_mupdate['m_title'];
$update_keyword = $row_mupdate['m_keyword'];
$update_description = $row_mupdate['m_description'];

//meta upgrade.php
mysql_select_db($database_apound, $apound);
$query_mupgrade = "SELECT * FROM meta WHERE meta.m_page = 'upgrade.php'";
$mupgrade = mysql_query($query_mupgrade, $apound) or die(mysql_error());
$row_mupgrade = mysql_fetch_assoc($mupgrade);
$totalRows_mupgrade = mysql_num_rows($mupgrade);

$upgrade_title = $row_mupgrade['m_title'];
$upgrade_keyword = $row_mupgrade['m_keyword'];
$upgrade_description = $row_mupgrade['m_description'];

// contact page with image or no
mysql_select_db($database_apound, $apound);
$query_cntIM = "SELECT confset.cntIM FROM confset";
$cntIM = mysql_query($query_cntIM, $apound) or die(mysql_error());
$row_cntIM = mysql_fetch_assoc($cntIM);
$totalRows_cntIM = mysql_num_rows($cntIM);
$cntIM = $row_cntIM['cntIM'];

// google cse
mysql_select_db($database_apound, $apound);
$query_gCSE = "SELECT * FROM google_cse";
$gCSE = mysql_query($query_gCSE, $apound) or die(mysql_error());
$row_gCSE = mysql_fetch_assoc($gCSE);
$totalRows_gCSE = mysql_num_rows($gCSE);
$cse_on = $row_gCSE['cse_on'];
if($cse_on == 'Y') { $cse_main = $row_gCSE['cse_main']; } else { $cse_main = ''; }

/* #################### Now all the below are for LBS 1.5 ############################ */

// define public stats enable or disable

$query_PSS = "SELECT pstats FROM confset";
$PSS = mysql_query($query_PSS, $apound) or die(mysql_error());
$row_PSS = mysql_fetch_assoc($PSS);
$totalRows_PSS = mysql_num_rows($PSS);

$pse = $row_PSS['pstats'];

mysql_free_result($PSS);

// Bad Word Filter - LBS 1.5

mysql_select_db($database_apound, $apound);
$query_BWC = "SELECT * FROM word_b";
$BWC = mysql_query($query_BWC, $apound) or die(mysql_error());
$row_BWC = mysql_fetch_assoc($BWC);
$totalRows_BWC = mysql_num_rows($BWC);
$badword = $row_BWC['w_bad'];
mysql_free_result($BWC);

// Admin stats LINKS ALL

$query_PSLf = "SELECT * FROM main";
$PSLf = mysql_query($query_PSLf, $apound) or die(mysql_error());
$row_PSLf = mysql_fetch_assoc($PSLf);
$totalRows_PSLf = mysql_num_rows($PSLf);
$adm_link_f = "$totalRows_PSLf";
mysql_free_result($PSLf);

// Admin stats LINKS active

$query_PSLa = "SELECT * FROM main WHERE avail = 'Y'";
$PSLa = mysql_query($query_PSLa, $apound) or die(mysql_error());
$row_PSLa = mysql_fetch_assoc($PSLa);
$totalRows_PSLa = mysql_num_rows($PSLa);
$adm_link_a = "$totalRows_PSLa";
mysql_free_result($PSLa);

// Admin stats LINKS pending

$query_PSLp = "SELECT * FROM main WHERE avail = 'N'";
$PSLp = mysql_query($query_PSLp, $apound) or die(mysql_error());
$row_PSLp = mysql_fetch_assoc($PSLp);
$totalRows_PSLp = mysql_num_rows($PSLp);
$adm_link_p = "$totalRows_PSLp";
mysql_free_result($PSLp);

// Admin stats CATEGORIES

$query_PSTa = "SELECT * FROM categorylisting WHERE categenable = 'Y'";
$PSTa = mysql_query($query_PSTa, $apound) or die(mysql_error());
$row_PSTa = mysql_fetch_assoc($PSTa);
$totalRows_PSTa = mysql_num_rows($PSTa);
$a_categ_a = "$totalRows_PSTa";
mysql_free_result($PSTa);

// public stats LINKS

if($pse == 'Y') {
	$query_PSL = "SELECT * FROM main WHERE avail = 'Y'";
	$PSL = mysql_query($query_PSL, $apound) or die(mysql_error());
	$row_PSL = mysql_fetch_assoc($PSL);
	$totalRows_PSL = mysql_num_rows($PSL);
	$s_link = "$lang_146 $totalRows_PSL |";
	mysql_free_result($PSL);
	}
else {}


// public stats CATEGORIES

if($pse == 'Y') {
	$query_PST = "SELECT * FROM categorylisting WHERE categenable = 'Y'";
	$PST = mysql_query($query_PST, $apound) or die(mysql_error());
	$row_PST = mysql_fetch_assoc($PST);
	$totalRows_PST = mysql_num_rows($PST);
	$s_categ = "$lang_148 $totalRows_PST";
	mysql_free_result($PST);
	}
else {}
?>