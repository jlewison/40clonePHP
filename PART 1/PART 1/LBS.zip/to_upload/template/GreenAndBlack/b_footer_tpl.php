<div id="footer">
	<ul>
		<li><a href="<?php echo("$path");?>"><?php echo("$lang_11");?></a> | </li>
		<li><a href="<?php echo("$path");?>new-links.php"><?php echo("$lang_12");?></a> | </li>
		<?php if($p_top == 'Y') { ?><li><a href="<?php echo("$path");?>links.php"><?php echo("$lang_13");?></a> | </li><?php } else {} ?>
		<li><a href="<?php echo("$path");?>submit.php?su_categ="><?php echo("$lang_14");?></a> | </li>
		<?php if($p_about == 'Y') { ?><li><a href="<?php echo("$path");?>about.php"><?php echo("$lang_22");?></a> | </li><?php } else {} ?>
		<?php if($p_terms == 'Y') { ?><li><a href="<?php echo("$path");?>terms.php"><?php echo("$lang_16");?></a> | </li><?php } else {} ?>
		<li><a href="<?php echo("$path");?>contact.php"><?php echo("$lang_23");?></a></li>
	</ul>
	&copy; <?php echo date("Y");?> <a href="<?php echo("$path");?>" target="_blank" title="<?php echo("$sitetitle");?>"><?php echo("$sitetitle");?></a> | <?php echo("$lang_149");?> <a href="http://www.linkbidscript.com/"><?php echo("$lang_150");?></a> | Template by Ozami Internet Directory
</div>