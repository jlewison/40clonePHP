<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

if (function_exists('json_encode'))
{
		return;
}
else
{
		require_once (APPPATH . 'helpers/JSON.php');
		function json_encode($data = null)
		{
				$json = new Services_JSON();
				if ($data == null) return false;
				return $json->encode($data);
		}
		function json_decode($data = null)
		{
				$json = new Services_JSON();
				if ($data == null) return false;
				return $json->decode($data);
		}
}
?>